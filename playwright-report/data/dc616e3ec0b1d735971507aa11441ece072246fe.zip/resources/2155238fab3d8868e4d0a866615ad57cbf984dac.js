// angular:polyfills:angular:polyfills
import "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zone__js.js?v=cf17c1b4";
//# debugId=99d4862d-eab9-5077-ba11-247c52c808fb


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFuZ3VsYXI6cG9seWZpbGxzOmFuZ3VsYXI6cG9seWZpbGxzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnem9uZS5qcyc7Il0sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTzsiLCJuYW1lcyI6W10sImRlYnVnSWQiOiI5OWQ0ODYyZC1lYWI5LTUwNzctYmExMS0yNDdjNTJjODA4ZmIifQ==