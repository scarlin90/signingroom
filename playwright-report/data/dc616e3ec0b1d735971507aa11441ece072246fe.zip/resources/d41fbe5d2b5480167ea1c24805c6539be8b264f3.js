import { t as _defineProperty } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/defineProperty-wQpB4Zl9.js?v=cf17c1b4";
import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
import { Bt as computed, Cl as truncateMiddle, Cr as TracingService, Ec as Injector, El as ɵɵdefineInjector, Fn as Injectable, Hc as RuntimeError, Lt as ResourceImpl, Pc as NgZone, Pn as Inject, Tc as InjectionToken, Ti as performanceMarkFeature, Tl as ɵɵdefineInjectable, Ui as setClassMetadata, Vt as encapsulateResourceError, Wc as TransferState, Wt as linkedSignal, Xc as assertInInjectionContext, Yt as APP_BOOTSTRAP_LISTENER, _c as EnvironmentInjector, bl as signal, dc as CSP_NONCE, dr as Service, fl as makeEnvironmentProviders, io as ɵɵdefineService, kl as ɵɵinject, mc as DestroyRef, no as ɵɵdefineNgModule, ol as inject, pc as DOCUMENT, pl as makeStateKey, qn as NgModule, qt as untracked, tl as formatRuntimeError, tn as ApplicationRef, vl as runInInjectionContext, zc as PendingTasks } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/core-BV_jmGG7.js?v=cf17c1b4";
import { Ft as concatMap, Qt as filter, Sn as of, Yn as Observable, fn as map, lt as finalize, x as switchMap } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zipWith-DkrnN79P.js?v=cf17c1b4";
import { t as _asyncToGenerator } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/asyncToGenerator-B0cJ8fiL.js?v=cf17c1b4";
import { n as parseCookieValue, o as PlatformLocation, t as XhrFactory } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/_xhr-chunk-CYugLJIp.js?v=cf17c1b4";
//#region node_modules/@angular/common/fesm2022/_module-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _FetchBackend;
var _HttpXsrfCookieExtractor;
var _HttpXsrfTokenExtractor;
var _HttpXsrfInterceptor;
var _HttpBackend;
var _HttpInterceptorHandler;
var _HttpHandler;
var _HttpClient;
var _JsonpClientBackend;
var _JsonpInterceptor;
var _HttpXhrBackend;
var _HttpClientXsrfModule;
var _HttpClientModule;
var _HttpClientJsonpModule;
var HttpHeaders = class HttpHeaders {
	constructor(headers) {
		_defineProperty(this, "headers", void 0);
		_defineProperty(this, "normalizedNames", /* @__PURE__ */ new Map());
		_defineProperty(this, "lazyInit", void 0);
		_defineProperty(this, "lazyUpdate", null);
		if (!headers) this.headers = /* @__PURE__ */ new Map();
		else if (typeof headers === "string") this.lazyInit = () => {
			this.headers = /* @__PURE__ */ new Map();
			headers.split("\n").forEach((line) => {
				const index = line.indexOf(":");
				if (index > 0) {
					const name = line.slice(0, index);
					const value = line.slice(index + 1).trim();
					this.addHeaderEntry(name, value);
				}
			});
		};
		else if (typeof Headers !== "undefined" && headers instanceof Headers) {
			this.headers = /* @__PURE__ */ new Map();
			headers.forEach((value, name) => {
				this.addHeaderEntry(name, value);
			});
		} else this.lazyInit = () => {
			if (typeof ngDevMode === "undefined" || ngDevMode) assertValidHeaders(headers);
			this.headers = /* @__PURE__ */ new Map();
			Object.entries(headers).forEach(([name, values]) => {
				this.setHeaderEntries(name, values);
			});
		};
	}
	has(name) {
		this.init();
		return this.headers.has(name.toLowerCase());
	}
	get(name) {
		this.init();
		const values = this.headers.get(name.toLowerCase());
		return values && values.length > 0 ? values[0] : null;
	}
	keys() {
		this.init();
		return Array.from(this.normalizedNames.values());
	}
	getAll(name) {
		this.init();
		return this.headers.get(name.toLowerCase()) || null;
	}
	append(name, value) {
		return this.clone({
			name,
			value,
			op: "a"
		});
	}
	set(name, value) {
		return this.clone({
			name,
			value,
			op: "s"
		});
	}
	delete(name, value) {
		return this.clone({
			name,
			value,
			op: "d"
		});
	}
	maybeSetNormalizedName(name, lcName) {
		if (!this.normalizedNames.has(lcName)) this.normalizedNames.set(lcName, name);
	}
	init() {
		if (!!this.lazyInit) {
			if (this.lazyInit instanceof HttpHeaders) this.copyFrom(this.lazyInit);
			else this.lazyInit();
			this.lazyInit = null;
			if (!!this.lazyUpdate) {
				this.lazyUpdate.forEach((update) => this.applyUpdate(update));
				this.lazyUpdate = null;
			}
		}
	}
	copyFrom(other) {
		other.init();
		for (const [key, values] of other.headers.entries()) {
			this.headers.set(key, values);
			this.normalizedNames.set(key, other.normalizedNames.get(key));
		}
	}
	clone(update) {
		const clone = new HttpHeaders();
		clone.lazyInit = !!this.lazyInit && this.lazyInit instanceof HttpHeaders ? this.lazyInit : this;
		clone.lazyUpdate = (this.lazyUpdate || []).concat([update]);
		return clone;
	}
	applyUpdate(update) {
		const key = update.name.toLowerCase();
		switch (update.op) {
			case "a":
			case "s":
				let value = update.value;
				if (typeof value === "string") value = [value];
				if (value.length === 0) return;
				this.maybeSetNormalizedName(update.name, key);
				const base = update.op === "a" ? (this.headers.get(key) || []).slice() : [];
				base.push(...value);
				this.headers.set(key, base);
				break;
			case "d":
				const toDelete = update.value;
				if (toDelete === void 0) {
					this.headers.delete(key);
					this.normalizedNames.delete(key);
				} else {
					const valuesToDelete = Array.isArray(toDelete) ? toDelete : [toDelete];
					let existing = this.headers.get(key);
					if (!existing) return;
					existing = existing.filter((value) => valuesToDelete.indexOf(value) === -1);
					if (existing.length === 0) {
						this.headers.delete(key);
						this.normalizedNames.delete(key);
					} else this.headers.set(key, existing);
				}
				break;
		}
	}
	addHeaderEntry(name, value) {
		const key = name.toLowerCase();
		this.maybeSetNormalizedName(name, key);
		if (this.headers.has(key)) this.headers.get(key).push(value);
		else this.headers.set(key, [value]);
	}
	setHeaderEntries(name, values) {
		const headerValues = (Array.isArray(values) ? values : [values]).map((value) => value.toString());
		const key = name.toLowerCase();
		this.headers.set(key, headerValues);
		this.maybeSetNormalizedName(name, key);
	}
	forEach(fn) {
		this.init();
		Array.from(this.normalizedNames.keys()).forEach((key) => fn(this.normalizedNames.get(key), this.headers.get(key)));
	}
};
function assertValidHeaders(headers) {
	for (const [key, value] of Object.entries(headers)) if (!(typeof value === "string" || typeof value === "number") && !Array.isArray(value)) throw new Error(`Unexpected value of the \`${key}\` header provided. Expecting either a string, a number or an array, but got: \`${value}\`.`);
}
var HttpContextToken = class {
	constructor(defaultValue) {
		_defineProperty(this, "defaultValue", void 0);
		this.defaultValue = defaultValue;
	}
};
var HttpContext = class {
	constructor() {
		_defineProperty(this, "map", /* @__PURE__ */ new Map());
	}
	set(token, value) {
		this.map.set(token, value);
		return this;
	}
	get(token) {
		if (!this.map.has(token)) this.map.set(token, token.defaultValue());
		return this.map.get(token);
	}
	delete(token) {
		this.map.delete(token);
		return this;
	}
	has(token) {
		return this.map.has(token);
	}
	keys() {
		return this.map.keys();
	}
};
var HttpUrlEncodingCodec = class {
	encodeKey(key) {
		return standardEncoding(key);
	}
	encodeValue(value) {
		return standardEncoding(value);
	}
	decodeKey(key) {
		return decodeURIComponent(key);
	}
	decodeValue(value) {
		return decodeURIComponent(value);
	}
};
function paramParser(rawParams, codec) {
	const map = /* @__PURE__ */ new Map();
	if (rawParams.length > 0) rawParams.replace(/^\?/, "").split("&").forEach((param) => {
		const eqIdx = param.indexOf("=");
		const [key, val] = eqIdx == -1 ? [codec.decodeKey(param), ""] : [codec.decodeKey(param.slice(0, eqIdx)), codec.decodeValue(param.slice(eqIdx + 1))];
		const list = map.get(key) || [];
		list.push(val);
		map.set(key, list);
	});
	return map;
}
var STANDARD_ENCODING_REGEX = /%(\d[a-f0-9])/gi;
var STANDARD_ENCODING_REPLACEMENTS = {
	"40": "@",
	"3A": ":",
	"24": "$",
	"2C": ",",
	"3B": ";",
	"3D": "=",
	"3F": "?",
	"2F": "/"
};
function standardEncoding(v) {
	return encodeURIComponent(v).replace(STANDARD_ENCODING_REGEX, (s, t) => {
		var _STANDARD_ENCODING_RE;
		return (_STANDARD_ENCODING_RE = STANDARD_ENCODING_REPLACEMENTS[t]) !== null && _STANDARD_ENCODING_RE !== void 0 ? _STANDARD_ENCODING_RE : s;
	});
}
function valueToString(value) {
	return `${value}`;
}
var HttpParams = class HttpParams {
	constructor(options = {}) {
		_defineProperty(this, "map", void 0);
		_defineProperty(this, "encoder", void 0);
		_defineProperty(this, "updates", null);
		_defineProperty(this, "cloneFrom", null);
		this.encoder = options.encoder || new HttpUrlEncodingCodec();
		if (options.fromString) {
			if (options.fromObject) throw new RuntimeError(2805, ngDevMode && "Cannot specify both fromString and fromObject.");
			this.map = paramParser(options.fromString, this.encoder);
		} else if (!!options.fromObject) {
			this.map = /* @__PURE__ */ new Map();
			Object.keys(options.fromObject).forEach((key) => {
				const value = options.fromObject[key];
				const values = Array.isArray(value) ? value.map(valueToString) : [valueToString(value)];
				this.map.set(key, values);
			});
		} else this.map = null;
	}
	has(param) {
		this.init();
		return this.map.has(param);
	}
	get(param) {
		this.init();
		const res = this.map.get(param);
		return !!res ? res[0] : null;
	}
	getAll(param) {
		this.init();
		return this.map.get(param) || null;
	}
	keys() {
		this.init();
		return Array.from(this.map.keys());
	}
	append(param, value) {
		return this.clone({
			param,
			value,
			op: "a"
		});
	}
	appendAll(params) {
		const updates = [];
		Object.keys(params).forEach((param) => {
			const value = params[param];
			if (Array.isArray(value)) value.forEach((_value) => {
				updates.push({
					param,
					value: _value,
					op: "a"
				});
			});
			else updates.push({
				param,
				value,
				op: "a"
			});
		});
		return this.clone(updates);
	}
	set(param, value) {
		return this.clone({
			param,
			value,
			op: "s"
		});
	}
	delete(param, value) {
		return this.clone({
			param,
			value,
			op: "d"
		});
	}
	toString() {
		this.init();
		return this.keys().map((key) => {
			const eKey = this.encoder.encodeKey(key);
			return this.map.get(key).map((value) => eKey + "=" + this.encoder.encodeValue(value)).join("&");
		}).filter((param) => param !== "").join("&");
	}
	clone(update) {
		const clone = new HttpParams({ encoder: this.encoder });
		clone.cloneFrom = this.cloneFrom || this;
		clone.updates = (this.updates || []).concat(update);
		return clone;
	}
	init() {
		if (this.map === null) this.map = /* @__PURE__ */ new Map();
		if (this.cloneFrom !== null) {
			this.cloneFrom.init();
			for (const [key, values] of this.cloneFrom.map.entries()) this.map.set(key, values);
			this.updates.forEach((update) => {
				switch (update.op) {
					case "a":
					case "s":
						const base = update.op === "a" ? (this.map.get(update.param) || []).slice() : [];
						base.push(valueToString(update.value));
						this.map.set(update.param, base);
						break;
					case "d": if (update.value !== void 0) {
						const base = (this.map.get(update.param) || []).slice();
						const idx = base.indexOf(valueToString(update.value));
						if (idx !== -1) base.splice(idx, 1);
						if (base.length > 0) this.map.set(update.param, base);
						else this.map.delete(update.param);
					} else {
						this.map.delete(update.param);
						break;
					}
				}
			});
			this.cloneFrom = this.updates = null;
		}
	}
};
function mightHaveBody(method) {
	switch (method) {
		case "DELETE":
		case "GET":
		case "HEAD":
		case "OPTIONS":
		case "JSONP": return false;
		default: return true;
	}
}
function isArrayBuffer(value) {
	return typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer;
}
function isBlob(value) {
	return typeof Blob !== "undefined" && value instanceof Blob;
}
function isFormData(value) {
	return typeof FormData !== "undefined" && value instanceof FormData;
}
function isUrlSearchParams(value) {
	return typeof URLSearchParams !== "undefined" && value instanceof URLSearchParams;
}
var CONTENT_TYPE_HEADER = "Content-Type";
var ACCEPT_HEADER = "Accept";
var TEXT_CONTENT_TYPE = "text/plain";
var JSON_CONTENT_TYPE = "application/json";
var ACCEPT_HEADER_VALUE = `${JSON_CONTENT_TYPE}, ${TEXT_CONTENT_TYPE}, */*`;
var HttpRequest = class HttpRequest {
	constructor(method, url, third, fourth) {
		var _this$headers, _this$context;
		_defineProperty(this, "url", void 0);
		_defineProperty(this, "body", null);
		_defineProperty(this, "headers", void 0);
		_defineProperty(this, "context", void 0);
		_defineProperty(this, "reportProgress", false);
		_defineProperty(this, "reportUploadProgress", false);
		_defineProperty(this, "reportDownloadProgress", false);
		_defineProperty(this, "withCredentials", false);
		_defineProperty(this, "credentials", void 0);
		_defineProperty(this, "keepalive", false);
		_defineProperty(this, "cache", void 0);
		_defineProperty(this, "priority", void 0);
		_defineProperty(this, "mode", void 0);
		_defineProperty(this, "redirect", void 0);
		_defineProperty(this, "referrer", void 0);
		_defineProperty(this, "integrity", void 0);
		_defineProperty(this, "referrerPolicy", void 0);
		_defineProperty(this, "responseType", "json");
		_defineProperty(this, "method", void 0);
		_defineProperty(this, "params", void 0);
		_defineProperty(this, "urlWithParams", void 0);
		_defineProperty(this, "transferCache", void 0);
		_defineProperty(this, "timeout", void 0);
		this.url = url;
		this.method = method.toUpperCase();
		let options;
		if (mightHaveBody(this.method) || !!fourth) {
			this.body = third !== void 0 ? third : null;
			options = fourth;
		} else options = third;
		if (options) {
			this.reportProgress = !!options.reportProgress;
			this.reportUploadProgress = !!options.reportUploadProgress;
			this.reportDownloadProgress = !!options.reportDownloadProgress;
			this.withCredentials = !!options.withCredentials;
			this.keepalive = !!options.keepalive;
			if (!!options.responseType) this.responseType = options.responseType;
			if (options.headers) this.headers = options.headers;
			if (options.context) this.context = options.context;
			if (options.params) this.params = options.params;
			if (options.priority) this.priority = options.priority;
			if (options.cache) this.cache = options.cache;
			if (options.credentials) this.credentials = options.credentials;
			if (typeof options.timeout === "number") {
				if (options.timeout < 1 || !Number.isInteger(options.timeout)) throw new RuntimeError(2822, ngDevMode ? "`timeout` must be a positive integer value" : "");
				this.timeout = options.timeout;
			}
			if (options.mode) this.mode = options.mode;
			if (options.redirect) this.redirect = options.redirect;
			if (options.integrity) this.integrity = options.integrity;
			if (options.referrer !== void 0) this.referrer = options.referrer;
			if (options.referrerPolicy) this.referrerPolicy = options.referrerPolicy;
			this.transferCache = options.transferCache;
		}
		(_this$headers = this.headers) !== null && _this$headers !== void 0 || (this.headers = new HttpHeaders());
		(_this$context = this.context) !== null && _this$context !== void 0 || (this.context = new HttpContext());
		if (!this.params) {
			this.params = new HttpParams();
			this.urlWithParams = url;
		} else {
			const params = this.params.toString();
			if (params.length === 0) this.urlWithParams = url;
			else {
				let urlWithoutFragment = url;
				let fragment = "";
				const hashIdx = url.indexOf("#");
				if (hashIdx !== -1) {
					fragment = url.substring(hashIdx);
					urlWithoutFragment = url.substring(0, hashIdx);
				}
				const qIdx = urlWithoutFragment.indexOf("?");
				const sep = qIdx === -1 ? "?" : qIdx < urlWithoutFragment.length - 1 ? "&" : "";
				this.urlWithParams = urlWithoutFragment + sep + params + fragment;
			}
		}
	}
	serializeBody() {
		if (this.body === null) return null;
		if (typeof this.body === "string" || isArrayBuffer(this.body) || isBlob(this.body) || isFormData(this.body) || isUrlSearchParams(this.body)) return this.body;
		if (this.body instanceof HttpParams) return this.body.toString();
		if (typeof this.body === "object" || typeof this.body === "boolean" || Array.isArray(this.body)) return JSON.stringify(this.body);
		return this.body.toString();
	}
	detectContentTypeHeader() {
		if (this.body === null) return null;
		if (isFormData(this.body)) return null;
		if (isBlob(this.body)) return this.body.type || null;
		if (isArrayBuffer(this.body)) return null;
		if (typeof this.body === "string") return TEXT_CONTENT_TYPE;
		if (this.body instanceof HttpParams) return "application/x-www-form-urlencoded;charset=UTF-8";
		if (typeof this.body === "object" || typeof this.body === "number" || typeof this.body === "boolean") return JSON_CONTENT_TYPE;
		return null;
	}
	clone(update = {}) {
		var _update$keepalive, _update$referrer, _update$transferCache, _update$timeout, _update$withCredentia, _update$reportProgres, _update$reportUploadP, _update$reportDownloa, _update$context;
		const method = update.method || this.method;
		const url = update.url || this.url;
		const responseType = update.responseType || this.responseType;
		const keepalive = (_update$keepalive = update.keepalive) !== null && _update$keepalive !== void 0 ? _update$keepalive : this.keepalive;
		const priority = update.priority || this.priority;
		const cache = update.cache || this.cache;
		const mode = update.mode || this.mode;
		const redirect = update.redirect || this.redirect;
		const credentials = update.credentials || this.credentials;
		const referrer = (_update$referrer = update.referrer) !== null && _update$referrer !== void 0 ? _update$referrer : this.referrer;
		const integrity = update.integrity || this.integrity;
		const referrerPolicy = update.referrerPolicy || this.referrerPolicy;
		const transferCache = (_update$transferCache = update.transferCache) !== null && _update$transferCache !== void 0 ? _update$transferCache : this.transferCache;
		const timeout = (_update$timeout = update.timeout) !== null && _update$timeout !== void 0 ? _update$timeout : this.timeout;
		const body = update.body !== void 0 ? update.body : this.body;
		const withCredentials = (_update$withCredentia = update.withCredentials) !== null && _update$withCredentia !== void 0 ? _update$withCredentia : this.withCredentials;
		const reportProgress = (_update$reportProgres = update.reportProgress) !== null && _update$reportProgres !== void 0 ? _update$reportProgres : this.reportProgress;
		const reportUploadProgress = (_update$reportUploadP = update.reportUploadProgress) !== null && _update$reportUploadP !== void 0 ? _update$reportUploadP : this.reportUploadProgress;
		const reportDownloadProgress = (_update$reportDownloa = update.reportDownloadProgress) !== null && _update$reportDownloa !== void 0 ? _update$reportDownloa : this.reportDownloadProgress;
		let headers = update.headers || this.headers;
		let params = update.params || this.params;
		const context = (_update$context = update.context) !== null && _update$context !== void 0 ? _update$context : this.context;
		if (update.setHeaders !== void 0) headers = Object.keys(update.setHeaders).reduce((headers, name) => headers.set(name, update.setHeaders[name]), headers);
		if (update.setParams) params = Object.keys(update.setParams).reduce((params, param) => params.set(param, update.setParams[param]), params);
		return new HttpRequest(method, url, body, {
			params,
			headers,
			context,
			reportProgress,
			reportUploadProgress,
			reportDownloadProgress,
			responseType,
			withCredentials,
			transferCache,
			keepalive,
			cache,
			priority,
			timeout,
			mode,
			redirect,
			credentials,
			referrer,
			integrity,
			referrerPolicy
		});
	}
};
var HttpEventType;
(function(HttpEventType) {
	HttpEventType[HttpEventType["Sent"] = 0] = "Sent";
	HttpEventType[HttpEventType["UploadProgress"] = 1] = "UploadProgress";
	HttpEventType[HttpEventType["ResponseHeader"] = 2] = "ResponseHeader";
	HttpEventType[HttpEventType["DownloadProgress"] = 3] = "DownloadProgress";
	HttpEventType[HttpEventType["Response"] = 4] = "Response";
	HttpEventType[HttpEventType["User"] = 5] = "User";
})(HttpEventType || (HttpEventType = {}));
var HttpResponseBase = class {
	constructor(init, defaultStatus = 200, defaultStatusText = "OK") {
		_defineProperty(this, "headers", void 0);
		_defineProperty(this, "status", void 0);
		_defineProperty(this, "statusText", void 0);
		_defineProperty(this, "url", void 0);
		_defineProperty(this, "ok", void 0);
		_defineProperty(this, "type", void 0);
		_defineProperty(this, "redirected", void 0);
		_defineProperty(this, "responseType", void 0);
		this.headers = init.headers || new HttpHeaders();
		this.status = init.status !== void 0 ? init.status : defaultStatus;
		this.statusText = init.statusText || defaultStatusText;
		this.url = init.url || null;
		this.redirected = init.redirected;
		this.responseType = init.responseType;
		this.ok = this.status >= 200 && this.status < 300;
	}
};
var HttpHeaderResponse = class HttpHeaderResponse extends HttpResponseBase {
	constructor(init = {}) {
		super(init);
		_defineProperty(this, "type", HttpEventType.ResponseHeader);
	}
	clone(update = {}) {
		return new HttpHeaderResponse({
			headers: update.headers || this.headers,
			status: update.status !== void 0 ? update.status : this.status,
			statusText: update.statusText || this.statusText,
			url: update.url || this.url || void 0
		});
	}
};
var HttpResponse = class HttpResponse extends HttpResponseBase {
	constructor(init = {}) {
		super(init);
		_defineProperty(this, "body", void 0);
		_defineProperty(this, "type", HttpEventType.Response);
		this.body = init.body !== void 0 ? init.body : null;
	}
	clone(update = {}) {
		var _update$redirected, _update$responseType;
		return new HttpResponse({
			body: update.body !== void 0 ? update.body : this.body,
			headers: update.headers || this.headers,
			status: update.status !== void 0 ? update.status : this.status,
			statusText: update.statusText || this.statusText,
			url: update.url || this.url || void 0,
			redirected: (_update$redirected = update.redirected) !== null && _update$redirected !== void 0 ? _update$redirected : this.redirected,
			responseType: (_update$responseType = update.responseType) !== null && _update$responseType !== void 0 ? _update$responseType : this.responseType
		});
	}
};
var HttpErrorResponse = class extends HttpResponseBase {
	constructor(init) {
		super(init, 0, "Unknown Error");
		_defineProperty(this, "name", "HttpErrorResponse");
		_defineProperty(this, "message", void 0);
		_defineProperty(this, "error", void 0);
		_defineProperty(this, "ok", false);
		if (this.status >= 200 && this.status < 300) this.message = `Http failure during parsing for ${init.url || "(unknown url)"}`;
		else this.message = `Http failure response for ${init.url || "(unknown url)"}: ${init.status} ${init.statusText}`;
		this.error = init.error || null;
	}
};
var HTTP_STATUS_CODE_OK = 200;
var HTTP_STATUS_CODE_NO_CONTENT = 204;
var HttpStatusCode;
(function(HttpStatusCode) {
	HttpStatusCode[HttpStatusCode["Continue"] = 100] = "Continue";
	HttpStatusCode[HttpStatusCode["SwitchingProtocols"] = 101] = "SwitchingProtocols";
	HttpStatusCode[HttpStatusCode["Processing"] = 102] = "Processing";
	HttpStatusCode[HttpStatusCode["EarlyHints"] = 103] = "EarlyHints";
	HttpStatusCode[HttpStatusCode["Ok"] = 200] = "Ok";
	HttpStatusCode[HttpStatusCode["Created"] = 201] = "Created";
	HttpStatusCode[HttpStatusCode["Accepted"] = 202] = "Accepted";
	HttpStatusCode[HttpStatusCode["NonAuthoritativeInformation"] = 203] = "NonAuthoritativeInformation";
	HttpStatusCode[HttpStatusCode["NoContent"] = 204] = "NoContent";
	HttpStatusCode[HttpStatusCode["ResetContent"] = 205] = "ResetContent";
	HttpStatusCode[HttpStatusCode["PartialContent"] = 206] = "PartialContent";
	HttpStatusCode[HttpStatusCode["MultiStatus"] = 207] = "MultiStatus";
	HttpStatusCode[HttpStatusCode["AlreadyReported"] = 208] = "AlreadyReported";
	HttpStatusCode[HttpStatusCode["ImUsed"] = 226] = "ImUsed";
	HttpStatusCode[HttpStatusCode["MultipleChoices"] = 300] = "MultipleChoices";
	HttpStatusCode[HttpStatusCode["MovedPermanently"] = 301] = "MovedPermanently";
	HttpStatusCode[HttpStatusCode["Found"] = 302] = "Found";
	HttpStatusCode[HttpStatusCode["SeeOther"] = 303] = "SeeOther";
	HttpStatusCode[HttpStatusCode["NotModified"] = 304] = "NotModified";
	HttpStatusCode[HttpStatusCode["UseProxy"] = 305] = "UseProxy";
	HttpStatusCode[HttpStatusCode["Unused"] = 306] = "Unused";
	HttpStatusCode[HttpStatusCode["TemporaryRedirect"] = 307] = "TemporaryRedirect";
	HttpStatusCode[HttpStatusCode["PermanentRedirect"] = 308] = "PermanentRedirect";
	HttpStatusCode[HttpStatusCode["BadRequest"] = 400] = "BadRequest";
	HttpStatusCode[HttpStatusCode["Unauthorized"] = 401] = "Unauthorized";
	HttpStatusCode[HttpStatusCode["PaymentRequired"] = 402] = "PaymentRequired";
	HttpStatusCode[HttpStatusCode["Forbidden"] = 403] = "Forbidden";
	HttpStatusCode[HttpStatusCode["NotFound"] = 404] = "NotFound";
	HttpStatusCode[HttpStatusCode["MethodNotAllowed"] = 405] = "MethodNotAllowed";
	HttpStatusCode[HttpStatusCode["NotAcceptable"] = 406] = "NotAcceptable";
	HttpStatusCode[HttpStatusCode["ProxyAuthenticationRequired"] = 407] = "ProxyAuthenticationRequired";
	HttpStatusCode[HttpStatusCode["RequestTimeout"] = 408] = "RequestTimeout";
	HttpStatusCode[HttpStatusCode["Conflict"] = 409] = "Conflict";
	HttpStatusCode[HttpStatusCode["Gone"] = 410] = "Gone";
	HttpStatusCode[HttpStatusCode["LengthRequired"] = 411] = "LengthRequired";
	HttpStatusCode[HttpStatusCode["PreconditionFailed"] = 412] = "PreconditionFailed";
	HttpStatusCode[HttpStatusCode["PayloadTooLarge"] = 413] = "PayloadTooLarge";
	HttpStatusCode[HttpStatusCode["UriTooLong"] = 414] = "UriTooLong";
	HttpStatusCode[HttpStatusCode["UnsupportedMediaType"] = 415] = "UnsupportedMediaType";
	HttpStatusCode[HttpStatusCode["RangeNotSatisfiable"] = 416] = "RangeNotSatisfiable";
	HttpStatusCode[HttpStatusCode["ExpectationFailed"] = 417] = "ExpectationFailed";
	HttpStatusCode[HttpStatusCode["ImATeapot"] = 418] = "ImATeapot";
	HttpStatusCode[HttpStatusCode["MisdirectedRequest"] = 421] = "MisdirectedRequest";
	HttpStatusCode[HttpStatusCode["UnprocessableEntity"] = 422] = "UnprocessableEntity";
	HttpStatusCode[HttpStatusCode["Locked"] = 423] = "Locked";
	HttpStatusCode[HttpStatusCode["FailedDependency"] = 424] = "FailedDependency";
	HttpStatusCode[HttpStatusCode["TooEarly"] = 425] = "TooEarly";
	HttpStatusCode[HttpStatusCode["UpgradeRequired"] = 426] = "UpgradeRequired";
	HttpStatusCode[HttpStatusCode["PreconditionRequired"] = 428] = "PreconditionRequired";
	HttpStatusCode[HttpStatusCode["TooManyRequests"] = 429] = "TooManyRequests";
	HttpStatusCode[HttpStatusCode["RequestHeaderFieldsTooLarge"] = 431] = "RequestHeaderFieldsTooLarge";
	HttpStatusCode[HttpStatusCode["UnavailableForLegalReasons"] = 451] = "UnavailableForLegalReasons";
	HttpStatusCode[HttpStatusCode["InternalServerError"] = 500] = "InternalServerError";
	HttpStatusCode[HttpStatusCode["NotImplemented"] = 501] = "NotImplemented";
	HttpStatusCode[HttpStatusCode["BadGateway"] = 502] = "BadGateway";
	HttpStatusCode[HttpStatusCode["ServiceUnavailable"] = 503] = "ServiceUnavailable";
	HttpStatusCode[HttpStatusCode["GatewayTimeout"] = 504] = "GatewayTimeout";
	HttpStatusCode[HttpStatusCode["HttpVersionNotSupported"] = 505] = "HttpVersionNotSupported";
	HttpStatusCode[HttpStatusCode["VariantAlsoNegotiates"] = 506] = "VariantAlsoNegotiates";
	HttpStatusCode[HttpStatusCode["InsufficientStorage"] = 507] = "InsufficientStorage";
	HttpStatusCode[HttpStatusCode["LoopDetected"] = 508] = "LoopDetected";
	HttpStatusCode[HttpStatusCode["NotExtended"] = 510] = "NotExtended";
	HttpStatusCode[HttpStatusCode["NetworkAuthenticationRequired"] = 511] = "NetworkAuthenticationRequired";
})(HttpStatusCode || (HttpStatusCode = {}));
var XSSI_PREFIX$1 = /^\)\]\}',?\n/;
var HTTP_FETCH_MAX_RESPONSE_SIZE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HTTP_FETCH_MAX_RESPONSE_SIZE" : "", { factory: () => null });
var FetchBackend = class {
	constructor() {
		var _inject$fetch, _inject;
		_defineProperty(this, "fetchImpl", (_inject$fetch = (_inject = inject(FetchFactory, { optional: true })) === null || _inject === void 0 ? void 0 : _inject.fetch) !== null && _inject$fetch !== void 0 ? _inject$fetch : ((...args) => globalThis.fetch(...args)));
		_defineProperty(this, "ngZone", inject(NgZone));
		_defineProperty(this, "destroyRef", inject(DestroyRef));
		_defineProperty(this, "maxResponseSize", inject(HTTP_FETCH_MAX_RESPONSE_SIZE));
	}
	handle(request) {
		return new Observable((observer) => {
			const aborter = new AbortController();
			let done = false;
			const wrappedObserver = {
				next: (val) => {
					if (val.type === HttpEventType.Response) done = true;
					observer.next(val);
				},
				error: (err) => {
					done = true;
					observer.error(err);
				},
				complete: () => {
					done = true;
					observer.complete();
				}
			};
			this.doRequest(request, aborter.signal, wrappedObserver).then(noop, (error) => wrappedObserver.error(new HttpErrorResponse({ error })));
			let timeoutId;
			if (request.timeout) timeoutId = this.ngZone.runOutsideAngular(() => setTimeout(() => {
				if (!aborter.signal.aborted) aborter.abort(new DOMException("signal timed out", "TimeoutError"));
			}, request.timeout));
			return () => {
				if (timeoutId !== void 0) clearTimeout(timeoutId);
				if (!done && !aborter.signal.aborted) aborter.abort();
			};
		});
	}
	doRequest(request, signal, observer) {
		var _this = this;
		return _asyncToGenerator(function* () {
			const init = _this.createRequestInit(request);
			let response;
			try {
				const fetchPromise = _this.ngZone.runOutsideAngular(() => _this.fetchImpl(request.urlWithParams, _objectSpread2({ signal }, init)));
				silenceSuperfluousUnhandledPromiseRejection(fetchPromise);
				observer.next({ type: HttpEventType.Sent });
				response = yield fetchPromise;
			} catch (error) {
				var _error$status;
				observer.error(new HttpErrorResponse({
					error,
					status: (_error$status = error.status) !== null && _error$status !== void 0 ? _error$status : 0,
					statusText: error.statusText,
					url: request.urlWithParams,
					headers: error.headers
				}));
				return;
			}
			const headers = new HttpHeaders(response.headers);
			const statusText = response.statusText;
			const url = response.url || request.urlWithParams;
			let status = response.status;
			let body = null;
			const reportDownloadProgress = request.reportProgress || request.reportDownloadProgress;
			if (reportDownloadProgress) observer.next(new HttpHeaderResponse({
				headers,
				status,
				statusText,
				url
			}));
			if (response.body) {
				var _response$headers$get;
				const contentType = (_response$headers$get = response.headers.get(CONTENT_TYPE_HEADER)) !== null && _response$headers$get !== void 0 ? _response$headers$get : "";
				const contentLength = response.headers.get("content-length");
				const contentLengthValue = contentLength !== null ? Number(contentLength) : NaN;
				if (_this.maxResponseSize !== null && Number.isFinite(contentLengthValue) && contentLengthValue > _this.maxResponseSize) throwBodyTooLargeError(_this.maxResponseSize);
				const chunks = [];
				const reader = response.body.getReader();
				let receivedLength = 0;
				let decoder;
				let partialText;
				const reqZone = typeof Zone !== "undefined" && Zone.current;
				let canceled = false;
				yield _this.ngZone.runOutsideAngular(_asyncToGenerator(function* () {
					while (true) {
						if (_this.destroyRef.destroyed) {
							yield reader.cancel();
							canceled = true;
							break;
						}
						const { done, value } = yield reader.read();
						if (done) break;
						chunks.push(value);
						receivedLength += value.length;
						if (_this.maxResponseSize !== null && receivedLength > _this.maxResponseSize) {
							yield reader.cancel();
							throwBodyTooLargeError(_this.maxResponseSize);
						}
						if (reportDownloadProgress) {
							var _partialText, _decoder;
							partialText = request.responseType === "text" ? ((_partialText = partialText) !== null && _partialText !== void 0 ? _partialText : "") + ((_decoder = decoder) !== null && _decoder !== void 0 ? _decoder : decoder = getTextDecoder(contentType)).decode(value, { stream: true }) : void 0;
							const reportProgress = () => observer.next({
								type: HttpEventType.DownloadProgress,
								total: Number.isFinite(contentLengthValue) ? contentLengthValue : void 0,
								loaded: receivedLength,
								partialText
							});
							reqZone ? reqZone.run(reportProgress) : reportProgress();
						}
					}
				}));
				if (canceled) {
					observer.complete();
					return;
				}
				const chunksAll = _this.concatChunks(chunks, receivedLength);
				try {
					body = _this.parseBody(request, chunksAll, contentType, status);
				} catch (error) {
					observer.error(new HttpErrorResponse({
						error,
						headers: new HttpHeaders(response.headers),
						status: response.status,
						statusText: response.statusText,
						url: response.url || request.urlWithParams
					}));
					return;
				}
			}
			if (status === 0) status = body ? HTTP_STATUS_CODE_OK : 0;
			const ok = status >= 200 && status < 300;
			const redirected = response.redirected;
			const responseType = response.type;
			if (ok) {
				observer.next(new HttpResponse({
					body,
					headers,
					status,
					statusText,
					url,
					redirected,
					responseType
				}));
				observer.complete();
			} else observer.error(new HttpErrorResponse({
				error: body,
				headers,
				status,
				statusText,
				url,
				redirected,
				responseType
			}));
		})();
	}
	parseBody(request, binContent, contentType, status) {
		switch (request.responseType) {
			case "json":
				const text = new TextDecoder().decode(binContent).replace(XSSI_PREFIX$1, "");
				if (text === "") return null;
				try {
					return JSON.parse(text);
				} catch (e) {
					if (status < 200 || status >= 300) return text;
					throw e;
				}
			case "text": return getTextDecoder(contentType).decode(binContent);
			case "blob": return new Blob([binContent], { type: contentType });
			case "arraybuffer": return binContent.buffer;
		}
	}
	createRequestInit(req) {
		if (req.reportUploadProgress) throw new RuntimeError(2824, ngDevMode && "The FetchBackend does not support upload progress reporting. Please use `withXhr()` on your `provideHttpClient()` configuration if you want to report upload progress.");
		const headers = {};
		let credentials;
		credentials = req.credentials;
		if (req.withCredentials) {
			(typeof ngDevMode === "undefined" || ngDevMode) && warningOptionsMessage(req);
			credentials = "include";
		}
		req.headers.forEach((name, values) => headers[name] = values.join(","));
		if (!req.headers.has(ACCEPT_HEADER)) headers[ACCEPT_HEADER] = ACCEPT_HEADER_VALUE;
		if (!req.headers.has(CONTENT_TYPE_HEADER)) {
			const detectedType = req.detectContentTypeHeader();
			if (detectedType !== null) headers[CONTENT_TYPE_HEADER] = detectedType;
		}
		return {
			body: req.serializeBody(),
			method: req.method,
			headers,
			credentials,
			keepalive: req.keepalive,
			cache: req.cache,
			priority: req.priority,
			mode: req.mode,
			redirect: req.redirect,
			referrer: req.referrer,
			integrity: req.integrity,
			referrerPolicy: req.referrerPolicy
		};
	}
	concatChunks(chunks, totalLength) {
		const chunksAll = new Uint8Array(totalLength);
		let position = 0;
		for (const chunk of chunks) {
			chunksAll.set(chunk, position);
			position += chunk.length;
		}
		return chunksAll;
	}
};
_FetchBackend = FetchBackend;
_defineProperty(FetchBackend, "ɵfac", function FetchBackend_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FetchBackend)();
});
_defineProperty(FetchBackend, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _FetchBackend,
	factory: _FetchBackend.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FetchBackend, [{ type: Service }], null, null);
})();
var FetchFactory = class {};
function noop() {}
function warningOptionsMessage(req) {
	if (req.credentials && req.withCredentials) console.warn(formatRuntimeError(2819, `Angular detected that a \`HttpClient\` request has both \`withCredentials: true\` and \`credentials: '${req.credentials}'\` options. The \`withCredentials\` option is overriding the explicit \`credentials\` setting to 'include'. Consider removing \`withCredentials\` and using \`credentials: '${req.credentials}'\` directly for clarity.`));
}
function silenceSuperfluousUnhandledPromiseRejection(promise) {
	promise.then(noop, noop);
}
function throwBodyTooLargeError(maxResponseSize) {
	throw new RuntimeError(-2825, ngDevMode && `Fetch response body exceeded the configured buffer limit (${maxResponseSize} bytes).`);
}
var CHARSET_REGEX = /charset=\s*["']?([^;"'\s]+)["']?/i;
function getTextDecoder(contentType) {
	const match = contentType.match(CHARSET_REGEX);
	if (match !== null) try {
		return new TextDecoder(match[1]);
	} catch (_unused) {}
	return new TextDecoder();
}
var XSRF_ENABLED = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "XSRF_ENABLED" : "", { factory: () => true });
var XSRF_DEFAULT_COOKIE_NAME = "XSRF-TOKEN";
var XSRF_COOKIE_NAME = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "XSRF_COOKIE_NAME" : "", { factory: () => XSRF_DEFAULT_COOKIE_NAME });
var XSRF_DEFAULT_HEADER_NAME = "X-XSRF-TOKEN";
var XSRF_HEADER_NAME = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "XSRF_HEADER_NAME" : "", { factory: () => XSRF_DEFAULT_HEADER_NAME });
var HttpXsrfCookieExtractor = class {
	constructor() {
		_defineProperty(this, "cookieName", inject(XSRF_COOKIE_NAME));
		_defineProperty(this, "doc", inject(DOCUMENT));
		_defineProperty(this, "lastCookieString", "");
		_defineProperty(this, "lastToken", null);
		_defineProperty(this, "parseCount", 0);
	}
	getToken() {
		const cookieString = this.doc.cookie || "";
		if (cookieString !== this.lastCookieString) {
			this.parseCount++;
			this.lastToken = parseCookieValue(cookieString, this.cookieName);
			this.lastCookieString = cookieString;
		}
		return this.lastToken;
	}
};
_HttpXsrfCookieExtractor = HttpXsrfCookieExtractor;
_defineProperty(HttpXsrfCookieExtractor, "ɵfac", function HttpXsrfCookieExtractor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpXsrfCookieExtractor)();
});
_defineProperty(HttpXsrfCookieExtractor, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _HttpXsrfCookieExtractor,
	factory: _HttpXsrfCookieExtractor.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpXsrfCookieExtractor, [{ type: Service }], null, null);
})();
var HttpXsrfTokenExtractor = class {};
_HttpXsrfTokenExtractor = HttpXsrfTokenExtractor;
_defineProperty(HttpXsrfTokenExtractor, "ɵfac", function HttpXsrfTokenExtractor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpXsrfTokenExtractor)();
});
_defineProperty(HttpXsrfTokenExtractor, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpXsrfTokenExtractor,
	factory: function HttpXsrfTokenExtractor_Factory(__ngFactoryType__) {
		let __ngConditionalFactory__ = null;
		if (__ngFactoryType__) __ngConditionalFactory__ = new (__ngFactoryType__ || _HttpXsrfTokenExtractor)();
		else __ngConditionalFactory__ = ɵɵinject(HttpXsrfCookieExtractor);
		return __ngConditionalFactory__;
	},
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpXsrfTokenExtractor, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useExisting: HttpXsrfCookieExtractor
		}]
	}], null, null);
})();
function xsrfInterceptorFn(req, next) {
	if (!inject(XSRF_ENABLED) || req.method === "GET" || req.method === "HEAD") return next(req);
	try {
		const locationHref = inject(PlatformLocation).href;
		const { origin: locationOrigin } = new URL(locationHref);
		const { origin: requestOrigin } = new URL(req.url, locationOrigin);
		if (locationOrigin !== requestOrigin) return next(req);
	} catch (_unused2) {
		return next(req);
	}
	const token = inject(HttpXsrfTokenExtractor).getToken();
	const headerName = inject(XSRF_HEADER_NAME);
	if (token != null && !req.headers.has(headerName)) req = req.clone({ headers: req.headers.set(headerName, token) });
	return next(req);
}
var HttpXsrfInterceptor = class {
	constructor() {
		_defineProperty(this, "injector", inject(EnvironmentInjector));
	}
	intercept(initialRequest, next) {
		return runInInjectionContext(this.injector, () => xsrfInterceptorFn(initialRequest, (downstreamRequest) => next.handle(downstreamRequest)));
	}
};
_HttpXsrfInterceptor = HttpXsrfInterceptor;
_defineProperty(HttpXsrfInterceptor, "ɵfac", function HttpXsrfInterceptor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpXsrfInterceptor)();
});
_defineProperty(HttpXsrfInterceptor, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpXsrfInterceptor,
	factory: _HttpXsrfInterceptor.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpXsrfInterceptor, [{ type: Injectable }], null, null);
})();
function interceptorChainEndFn(req, finalHandlerFn) {
	return finalHandlerFn(req);
}
function adaptLegacyInterceptorToChain(chainTailFn, interceptor) {
	return (initialRequest, finalHandlerFn) => interceptor.intercept(initialRequest, { handle: (downstreamRequest) => chainTailFn(downstreamRequest, finalHandlerFn) });
}
function chainedInterceptorFn(chainTailFn, interceptorFn, injector) {
	return (initialRequest, finalHandlerFn) => runInInjectionContext(injector, () => interceptorFn(initialRequest, (downstreamRequest) => chainTailFn(downstreamRequest, finalHandlerFn)));
}
var HTTP_INTERCEPTORS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HTTP_INTERCEPTORS" : "");
var HTTP_INTERCEPTOR_FNS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HTTP_INTERCEPTOR_FNS" : "", { factory: () => [xsrfInterceptorFn] });
var HTTP_ROOT_INTERCEPTOR_FNS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HTTP_ROOT_INTERCEPTOR_FNS" : "");
var REQUESTS_CONTRIBUTE_TO_STABILITY = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "REQUESTS_CONTRIBUTE_TO_STABILITY" : "", { factory: () => true });
function legacyInterceptorFnFactory() {
	let chain = null;
	return (req, handler) => {
		if (chain === null) {
			var _inject2;
			chain = ((_inject2 = inject(HTTP_INTERCEPTORS, { optional: true })) !== null && _inject2 !== void 0 ? _inject2 : []).reduceRight(adaptLegacyInterceptorToChain, interceptorChainEndFn);
		}
		const pendingTasks = inject(PendingTasks);
		if (inject(REQUESTS_CONTRIBUTE_TO_STABILITY)) {
			const removeTask = pendingTasks.add();
			return chain(req, handler).pipe(finalize(removeTask));
		} else return chain(req, handler);
	};
}
var HttpBackend = class {};
_HttpBackend = HttpBackend;
_defineProperty(HttpBackend, "ɵfac", function HttpBackend_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpBackend)();
});
_defineProperty(HttpBackend, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpBackend,
	factory: function HttpBackend_Factory(__ngFactoryType__) {
		let __ngConditionalFactory__ = null;
		if (__ngFactoryType__) __ngConditionalFactory__ = new (__ngFactoryType__ || _HttpBackend)();
		else __ngConditionalFactory__ = ɵɵinject(FetchBackend);
		return __ngConditionalFactory__;
	},
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpBackend, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useExisting: FetchBackend
		}]
	}], null, null);
})();
var HttpInterceptorHandler = class {
	constructor(backend, injector) {
		_defineProperty(this, "backend", void 0);
		_defineProperty(this, "injector", void 0);
		_defineProperty(this, "chain", null);
		_defineProperty(this, "pendingTasks", inject(PendingTasks));
		_defineProperty(this, "contributeToStability", inject(REQUESTS_CONTRIBUTE_TO_STABILITY));
		this.backend = backend;
		this.injector = injector;
		if ((typeof ngDevMode === "undefined" || ngDevMode) && true) this.backend.isTestingBackend;
	}
	handle(initialRequest) {
		if (this.chain === null) {
			const parentHandler = this.injector.get(HttpHandler, null, { skipSelf: true });
			const isDelegating = parentHandler !== null && this.backend === parentHandler;
			const rootInterceptorFns = this.injector.get(HTTP_ROOT_INTERCEPTOR_FNS, [], isDelegating ? { self: true } : void 0);
			const dedupedInterceptorFns = Array.from(/* @__PURE__ */ new Set([...this.injector.get(HTTP_INTERCEPTOR_FNS), ...rootInterceptorFns]));
			this.chain = dedupedInterceptorFns.reduceRight((nextSequencedFn, interceptorFn) => chainedInterceptorFn(nextSequencedFn, interceptorFn, this.injector), interceptorChainEndFn);
		}
		const chain = this.chain;
		if (this.contributeToStability) {
			const removeTask = this.pendingTasks.add();
			return untracked(() => chain(initialRequest, (downstreamRequest) => this.backend.handle(downstreamRequest))).pipe(finalize(removeTask));
		} else return untracked(() => chain(initialRequest, (downstreamRequest) => this.backend.handle(downstreamRequest)));
	}
};
_HttpInterceptorHandler = HttpInterceptorHandler;
_defineProperty(HttpInterceptorHandler, "ɵfac", function HttpInterceptorHandler_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpInterceptorHandler)(ɵɵinject(HttpBackend), ɵɵinject(EnvironmentInjector));
});
_defineProperty(HttpInterceptorHandler, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpInterceptorHandler,
	factory: _HttpInterceptorHandler.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpInterceptorHandler, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: HttpBackend }, { type: EnvironmentInjector }], null);
})();
var HttpHandler = class {};
_HttpHandler = HttpHandler;
_defineProperty(HttpHandler, "ɵfac", function HttpHandler_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpHandler)();
});
_defineProperty(HttpHandler, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpHandler,
	factory: function HttpHandler_Factory(__ngFactoryType__) {
		let __ngConditionalFactory__ = null;
		if (__ngFactoryType__) __ngConditionalFactory__ = new (__ngFactoryType__ || _HttpHandler)();
		else __ngConditionalFactory__ = ɵɵinject(HttpInterceptorHandler);
		return __ngConditionalFactory__;
	},
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpHandler, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useExisting: HttpInterceptorHandler
		}]
	}], null, null);
})();
function addBody(options, body) {
	return _objectSpread2({ body }, options);
}
var HttpClient = class {
	constructor(handler) {
		_defineProperty(this, "handler", void 0);
		this.handler = handler;
	}
	request(first, url, options = {}) {
		let req;
		if (first instanceof HttpRequest) req = first;
		else {
			let headers = void 0;
			if (options.headers instanceof HttpHeaders) headers = options.headers;
			else headers = new HttpHeaders(options.headers);
			let params = void 0;
			if (!!options.params) if (options.params instanceof HttpParams) params = options.params;
			else params = new HttpParams({ fromObject: options.params });
			req = new HttpRequest(first, url, options.body !== void 0 ? options.body : null, {
				headers,
				context: options.context,
				params,
				reportProgress: options.reportProgress,
				reportUploadProgress: options.reportUploadProgress,
				reportDownloadProgress: options.reportDownloadProgress,
				responseType: options.responseType || "json",
				withCredentials: options.withCredentials,
				transferCache: options.transferCache,
				keepalive: options.keepalive,
				priority: options.priority,
				cache: options.cache,
				mode: options.mode,
				redirect: options.redirect,
				credentials: options.credentials,
				referrer: options.referrer,
				referrerPolicy: options.referrerPolicy,
				integrity: options.integrity,
				timeout: options.timeout
			});
		}
		const events$ = of(req).pipe(concatMap((req) => this.handler.handle(req)));
		if (first instanceof HttpRequest || options.observe === "events") return events$;
		const res$ = events$.pipe(filter((event) => event instanceof HttpResponse));
		switch (options.observe || "body") {
			case "body": switch (req.responseType) {
				case "arraybuffer": return res$.pipe(map((res) => {
					if (res.body !== null && !(res.body instanceof ArrayBuffer)) throw new RuntimeError(2806, ngDevMode && "Response is not an ArrayBuffer.");
					return res.body;
				}));
				case "blob": return res$.pipe(map((res) => {
					if (res.body !== null && !(res.body instanceof Blob)) throw new RuntimeError(2807, ngDevMode && "Response is not a Blob.");
					return res.body;
				}));
				case "text": return res$.pipe(map((res) => {
					if (res.body !== null && typeof res.body !== "string") throw new RuntimeError(2808, ngDevMode && "Response is not a string.");
					return res.body;
				}));
				default: return res$.pipe(map((res) => res.body));
			}
			case "response": return res$;
			default: throw new RuntimeError(2809, ngDevMode && `Unreachable: unhandled observe type ${options.observe}}`);
		}
	}
	delete(url, options = {}) {
		return this.request("DELETE", url, options);
	}
	get(url, options = {}) {
		return this.request("GET", url, options);
	}
	head(url, options = {}) {
		return this.request("HEAD", url, options);
	}
	jsonp(url, callbackParam) {
		return this.request("JSONP", url, {
			params: new HttpParams().append(callbackParam, "JSONP_CALLBACK"),
			observe: "body",
			responseType: "json"
		});
	}
	options(url, options = {}) {
		return this.request("OPTIONS", url, options);
	}
	patch(url, body, options = {}) {
		return this.request("PATCH", url, addBody(options, body));
	}
	post(url, body, options = {}) {
		return this.request("POST", url, addBody(options, body));
	}
	put(url, body, options = {}) {
		return this.request("PUT", url, addBody(options, body));
	}
};
_HttpClient = HttpClient;
_defineProperty(HttpClient, "ɵfac", function HttpClient_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpClient)(ɵɵinject(HttpHandler));
});
_defineProperty(HttpClient, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpClient,
	factory: _HttpClient.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpClient, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: HttpHandler }], null);
})();
var nextRequestId = 0;
var foreignDocument;
var JSONP_ERR_NO_CALLBACK = "JSONP injected script did not invoke callback.";
var JSONP_ERR_WRONG_METHOD = "JSONP requests must use JSONP request method.";
var JSONP_ERR_WRONG_RESPONSE_TYPE = "JSONP requests must use Json response type.";
var JSONP_ERR_HEADERS_NOT_SUPPORTED = "JSONP requests do not support headers.";
var JSONP_ERR_UNSAFE_URL = "JSONP requests only support absolute URLs with HTTP(S) protocols.";
var JsonpCallbackContext = class {};
function jsonpCallbackContext() {
	if (typeof window === "object") return window;
	return {};
}
var JsonpClientBackend = class {
	constructor(callbackMap, document) {
		_defineProperty(this, "callbackMap", void 0);
		_defineProperty(this, "document", void 0);
		_defineProperty(this, "resolvedPromise", Promise.resolve());
		_defineProperty(this, "nonce", inject(CSP_NONCE, { optional: true }));
		this.callbackMap = callbackMap;
		this.document = document;
		if (typeof ngDevMode === "undefined" || ngDevMode) console.warn("JSONP support is deprecated as it can cause XSS vulnerabilities, and will be removed in a future version of Angular. Please use standard HTTP requests instead.");
	}
	nextCallback() {
		return `ng_jsonp_callback_${nextRequestId++}`;
	}
	handle(req) {
		if (req.method !== "JSONP") throw new RuntimeError(2810, ngDevMode && JSONP_ERR_WRONG_METHOD);
		else if (req.responseType !== "json") throw new RuntimeError(2811, ngDevMode && JSONP_ERR_WRONG_RESPONSE_TYPE);
		if (req.headers.keys().length > 0) throw new RuntimeError(2812, ngDevMode && JSONP_ERR_HEADERS_NOT_SUPPORTED);
		if (!this.isAllowedJsonpUrl(req.urlWithParams)) throw new RuntimeError(2826, ngDevMode && JSONP_ERR_UNSAFE_URL);
		return new Observable((observer) => {
			const callback = this.nextCallback();
			const url = req.urlWithParams.replace(/=JSONP_CALLBACK(&|$)/, `=${callback}$1`);
			const node = this.document.createElement("script");
			node.src = url;
			if (this.nonce) node.setAttribute("nonce", this.nonce);
			let body = null;
			let finished = false;
			this.callbackMap[callback] = (data) => {
				delete this.callbackMap[callback];
				body = data;
				finished = true;
			};
			const cleanup = () => {
				node.removeEventListener("load", onLoad);
				node.removeEventListener("error", onError);
				node.remove();
				delete this.callbackMap[callback];
			};
			const onLoad = () => {
				this.resolvedPromise.then(() => {
					cleanup();
					if (!finished) {
						observer.error(new HttpErrorResponse({
							url,
							status: 0,
							statusText: "JSONP Error",
							error: /* @__PURE__ */ new Error(JSONP_ERR_NO_CALLBACK)
						}));
						return;
					}
					observer.next(new HttpResponse({
						body,
						status: HTTP_STATUS_CODE_OK,
						statusText: "OK",
						url
					}));
					observer.complete();
				});
			};
			const onError = (error) => {
				cleanup();
				observer.error(new HttpErrorResponse({
					error,
					status: 0,
					statusText: "JSONP Error",
					url
				}));
			};
			node.addEventListener("load", onLoad);
			node.addEventListener("error", onError);
			this.document.body.appendChild(node);
			observer.next({ type: HttpEventType.Sent });
			return () => {
				if (!finished) this.removeListeners(node);
				cleanup();
			};
		});
	}
	removeListeners(script) {
		var _foreignDocument;
		(_foreignDocument = foreignDocument) !== null && _foreignDocument !== void 0 || (foreignDocument = this.document.implementation.createHTMLDocument());
		foreignDocument.adoptNode(script);
	}
	isAllowedJsonpUrl(url) {
		return /^https?:\/\//i.test(url);
	}
};
_JsonpClientBackend = JsonpClientBackend;
_defineProperty(JsonpClientBackend, "ɵfac", function JsonpClientBackend_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _JsonpClientBackend)(ɵɵinject(JsonpCallbackContext), ɵɵinject(DOCUMENT));
});
_defineProperty(JsonpClientBackend, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _JsonpClientBackend,
	factory: _JsonpClientBackend.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(JsonpClientBackend, [{ type: Injectable }], () => [{ type: JsonpCallbackContext }, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [DOCUMENT]
		}]
	}], null);
})();
function jsonpInterceptorFn(req, next) {
	if (req.method === "JSONP") return inject(JsonpClientBackend).handle(req);
	return next(req);
}
var JsonpInterceptor = class {
	constructor(injector) {
		_defineProperty(this, "injector", void 0);
		this.injector = injector;
	}
	intercept(initialRequest, next) {
		return runInInjectionContext(this.injector, () => jsonpInterceptorFn(initialRequest, (downstreamRequest) => next.handle(downstreamRequest)));
	}
};
_JsonpInterceptor = JsonpInterceptor;
_defineProperty(JsonpInterceptor, "ɵfac", function JsonpInterceptor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _JsonpInterceptor)(ɵɵinject(EnvironmentInjector));
});
_defineProperty(JsonpInterceptor, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _JsonpInterceptor,
	factory: _JsonpInterceptor.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(JsonpInterceptor, [{ type: Injectable }], () => [{ type: EnvironmentInjector }], null);
})();
var XSSI_PREFIX = /^\)\]\}',?\n/;
function validateXhrCompatibility(req) {
	for (const { property, errorCode } of [
		{
			property: "keepalive",
			errorCode: 2813
		},
		{
			property: "cache",
			errorCode: 2814
		},
		{
			property: "priority",
			errorCode: 2815
		},
		{
			property: "mode",
			errorCode: 2816
		},
		{
			property: "redirect",
			errorCode: 2817
		},
		{
			property: "credentials",
			errorCode: 2818
		},
		{
			property: "integrity",
			errorCode: 2820
		},
		{
			property: "referrer",
			errorCode: 2821
		},
		{
			property: "referrerPolicy",
			errorCode: 2823
		}
	]) if (req[property]) console.warn(formatRuntimeError(errorCode, `Angular detected that a \`HttpClient\` request with the \`${property}\` option was sent using XHR, which does not support it. To use the \`${property}\` option, use the Fetch API by removing \`withXhr()\` from the \`provideHttpClient()\` call.`));
}
var HttpXhrBackend = class {
	constructor(xhrFactory) {
		_defineProperty(this, "xhrFactory", void 0);
		_defineProperty(this, "tracingService", inject(TracingService, { optional: true }));
		this.xhrFactory = xhrFactory;
	}
	maybePropagateTrace(fn) {
		var _this$tracingService;
		return ((_this$tracingService = this.tracingService) === null || _this$tracingService === void 0 ? void 0 : _this$tracingService.propagate) ? this.tracingService.propagate(fn) : fn;
	}
	handle(req) {
		if (req.method === "JSONP") throw new RuntimeError(-2800, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot make a JSONP request without JSONP support. To fix the problem, either add the \`withJsonpSupport()\` call (if \`provideHttpClient()\` is used) or import the \`HttpClientJsonpModule\` in the root NgModule.`);
		ngDevMode && validateXhrCompatibility(req);
		const xhrFactory = this.xhrFactory;
		return of(null).pipe(switchMap(() => {
			return new Observable((observer) => {
				const xhr = xhrFactory.build();
				xhr.open(req.method, req.urlWithParams);
				if (req.withCredentials) xhr.withCredentials = true;
				req.headers.forEach((name, values) => xhr.setRequestHeader(name, values.join(",")));
				if (!req.headers.has(ACCEPT_HEADER)) xhr.setRequestHeader(ACCEPT_HEADER, ACCEPT_HEADER_VALUE);
				if (!req.headers.has(CONTENT_TYPE_HEADER)) {
					const detectedType = req.detectContentTypeHeader();
					if (detectedType !== null) xhr.setRequestHeader(CONTENT_TYPE_HEADER, detectedType);
				}
				if (req.timeout) xhr.timeout = req.timeout;
				if (req.responseType) {
					const responseType = req.responseType.toLowerCase();
					xhr.responseType = responseType !== "json" ? responseType : "text";
				}
				const reqBody = req.serializeBody();
				let headerResponse = null;
				const partialFromXhr = () => {
					if (headerResponse !== null) return headerResponse;
					const statusText = xhr.statusText || "OK";
					const headers = new HttpHeaders(xhr.getAllResponseHeaders());
					const url = xhr.responseURL || req.url;
					headerResponse = new HttpHeaderResponse({
						headers,
						status: xhr.status,
						statusText,
						url
					});
					return headerResponse;
				};
				const onLoad = this.maybePropagateTrace(() => {
					let { headers, status, statusText, url } = partialFromXhr();
					let body = null;
					if (status !== HTTP_STATUS_CODE_NO_CONTENT) body = typeof xhr.response === "undefined" ? xhr.responseText : xhr.response;
					if (status === 0) status = !!body ? HTTP_STATUS_CODE_OK : 0;
					let ok = status >= 200 && status < 300;
					if (req.responseType === "json" && typeof body === "string") {
						const originalBody = body;
						body = body.replace(XSSI_PREFIX, "");
						try {
							body = body !== "" ? JSON.parse(body) : null;
						} catch (error) {
							body = originalBody;
							if (ok) {
								ok = false;
								body = {
									error,
									text: body
								};
							}
						}
					}
					if (ok) {
						observer.next(new HttpResponse({
							body,
							headers,
							status,
							statusText,
							url: url || void 0
						}));
						observer.complete();
					} else observer.error(new HttpErrorResponse({
						error: body,
						headers,
						status,
						statusText,
						url: url || void 0
					}));
				});
				const onError = this.maybePropagateTrace((error) => {
					const { url } = partialFromXhr();
					const res = new HttpErrorResponse({
						error,
						status: xhr.status || 0,
						statusText: xhr.statusText || "Unknown Error",
						url: url || void 0
					});
					observer.error(res);
				});
				let onTimeout = onError;
				if (req.timeout) onTimeout = this.maybePropagateTrace((_) => {
					const { url } = partialFromXhr();
					const res = new HttpErrorResponse({
						error: new DOMException("Request timed out", "TimeoutError"),
						status: xhr.status || 0,
						statusText: xhr.statusText || "Request timeout",
						url: url || void 0
					});
					observer.error(res);
				});
				let sentHeaders = false;
				const onDownProgress = this.maybePropagateTrace((event) => {
					if (!sentHeaders) {
						observer.next(partialFromXhr());
						sentHeaders = true;
					}
					let progressEvent = {
						type: HttpEventType.DownloadProgress,
						loaded: event.loaded
					};
					if (event.lengthComputable) progressEvent.total = event.total;
					if (req.responseType === "text" && !!xhr.responseText) progressEvent.partialText = xhr.responseText;
					observer.next(progressEvent);
				});
				const onUpProgress = this.maybePropagateTrace((event) => {
					let progress = {
						type: HttpEventType.UploadProgress,
						loaded: event.loaded
					};
					if (event.lengthComputable) progress.total = event.total;
					observer.next(progress);
				});
				xhr.addEventListener("load", onLoad);
				xhr.addEventListener("error", onError);
				xhr.addEventListener("timeout", onTimeout);
				xhr.addEventListener("abort", onError);
				const reportUploadProgress = req.reportProgress || req.reportUploadProgress;
				const reportDownloadProgress = req.reportProgress || req.reportDownloadProgress;
				if (reportDownloadProgress) xhr.addEventListener("progress", onDownProgress);
				if (reportUploadProgress && reqBody !== null && xhr.upload) xhr.upload.addEventListener("progress", onUpProgress);
				xhr.send(reqBody);
				observer.next({ type: HttpEventType.Sent });
				return () => {
					xhr.removeEventListener("error", onError);
					xhr.removeEventListener("abort", onError);
					xhr.removeEventListener("load", onLoad);
					xhr.removeEventListener("timeout", onTimeout);
					if (reportDownloadProgress) xhr.removeEventListener("progress", onDownProgress);
					if (reportUploadProgress && reqBody !== null && xhr.upload) xhr.upload.removeEventListener("progress", onUpProgress);
					if (xhr.readyState !== xhr.DONE) xhr.abort();
				};
			});
		}));
	}
};
_HttpXhrBackend = HttpXhrBackend;
_defineProperty(HttpXhrBackend, "ɵfac", function HttpXhrBackend_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpXhrBackend)(ɵɵinject(XhrFactory));
});
_defineProperty(HttpXhrBackend, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HttpXhrBackend,
	factory: _HttpXhrBackend.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpXhrBackend, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: XhrFactory }], null);
})();
var HttpFeatureKind;
(function(HttpFeatureKind) {
	HttpFeatureKind[HttpFeatureKind["Interceptors"] = 0] = "Interceptors";
	HttpFeatureKind[HttpFeatureKind["LegacyInterceptors"] = 1] = "LegacyInterceptors";
	HttpFeatureKind[HttpFeatureKind["CustomXsrfConfiguration"] = 2] = "CustomXsrfConfiguration";
	HttpFeatureKind[HttpFeatureKind["NoXsrfProtection"] = 3] = "NoXsrfProtection";
	HttpFeatureKind[HttpFeatureKind["JsonpSupport"] = 4] = "JsonpSupport";
	HttpFeatureKind[HttpFeatureKind["RequestsMadeViaParent"] = 5] = "RequestsMadeViaParent";
	HttpFeatureKind[HttpFeatureKind["Fetch"] = 6] = "Fetch";
	HttpFeatureKind[HttpFeatureKind["Xhr"] = 7] = "Xhr";
})(HttpFeatureKind || (HttpFeatureKind = {}));
function makeHttpFeature(kind, providers) {
	return {
		ɵkind: kind,
		ɵproviders: providers
	};
}
function provideHttpClient(...features) {
	if (ngDevMode) {
		const featureKinds = new Set(features.map((f) => f.ɵkind));
		if (featureKinds.has(HttpFeatureKind.NoXsrfProtection) && featureKinds.has(HttpFeatureKind.CustomXsrfConfiguration)) throw new Error(`Configuration error: found both withXsrfConfiguration() and withNoXsrfProtection() in the same call to provideHttpClient(), which is a contradiction.`);
		const hasBackendOverride = featureKinds.has(HttpFeatureKind.Fetch) || featureKinds.has(HttpFeatureKind.Xhr);
		if (featureKinds.has(HttpFeatureKind.RequestsMadeViaParent) && hasBackendOverride) throw new Error(`Configuration error: withRequestsMadeViaParent() cannot be combined with withFetch() or withXhr() in the same call to provideHttpClient().`);
	}
	const providers = [
		HttpClient,
		FetchBackend,
		HttpInterceptorHandler,
		{
			provide: HttpHandler,
			useExisting: HttpInterceptorHandler
		},
		{
			provide: HttpBackend,
			useFactory: () => {
				return inject(FetchBackend);
			}
		},
		{
			provide: HTTP_INTERCEPTOR_FNS,
			useValue: xsrfInterceptorFn,
			multi: true
		}
	];
	for (const feature of features) providers.push(...feature.ɵproviders);
	return makeEnvironmentProviders(providers);
}
function withInterceptors(interceptorFns) {
	return makeHttpFeature(HttpFeatureKind.Interceptors, interceptorFns.map((interceptorFn) => {
		return {
			provide: HTTP_INTERCEPTOR_FNS,
			useValue: interceptorFn,
			multi: true
		};
	}));
}
var LEGACY_INTERCEPTOR_FN = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "LEGACY_INTERCEPTOR_FN" : "");
function withInterceptorsFromDi() {
	return makeHttpFeature(HttpFeatureKind.LegacyInterceptors, [{
		provide: LEGACY_INTERCEPTOR_FN,
		useFactory: legacyInterceptorFnFactory
	}, {
		provide: HTTP_INTERCEPTOR_FNS,
		useExisting: LEGACY_INTERCEPTOR_FN,
		multi: true
	}]);
}
function withXsrfConfiguration({ cookieName, headerName }) {
	const providers = [];
	if (cookieName !== void 0) providers.push({
		provide: XSRF_COOKIE_NAME,
		useValue: cookieName
	});
	if (headerName !== void 0) providers.push({
		provide: XSRF_HEADER_NAME,
		useValue: headerName
	});
	return makeHttpFeature(HttpFeatureKind.CustomXsrfConfiguration, providers);
}
function withNoXsrfProtection() {
	return makeHttpFeature(HttpFeatureKind.NoXsrfProtection, [{
		provide: XSRF_ENABLED,
		useValue: false
	}]);
}
function withJsonpSupport() {
	return makeHttpFeature(HttpFeatureKind.JsonpSupport, [
		JsonpClientBackend,
		{
			provide: JsonpCallbackContext,
			useFactory: jsonpCallbackContext
		},
		{
			provide: HTTP_INTERCEPTOR_FNS,
			useValue: jsonpInterceptorFn,
			multi: true
		}
	]);
}
function withRequestsMadeViaParent() {
	return makeHttpFeature(HttpFeatureKind.RequestsMadeViaParent, [{
		provide: HttpBackend,
		useFactory: () => {
			const handlerFromParent = inject(HttpHandler, {
				skipSelf: true,
				optional: true
			});
			if (ngDevMode && handlerFromParent === null) throw new Error("withRequestsMadeViaParent() can only be used when the parent injector also configures HttpClient");
			return handlerFromParent;
		}
	}]);
}
function withFetch() {
	return makeHttpFeature(HttpFeatureKind.Fetch, [FetchBackend, {
		provide: HttpBackend,
		useExisting: FetchBackend
	}]);
}
function withXhr() {
	return makeHttpFeature(HttpFeatureKind.Xhr, [HttpXhrBackend, {
		provide: HttpBackend,
		useExisting: HttpXhrBackend
	}]);
}
var HttpClientXsrfModule = class HttpClientXsrfModule {
	static disable() {
		return {
			ngModule: HttpClientXsrfModule,
			providers: [withNoXsrfProtection().ɵproviders]
		};
	}
	static withOptions(options = {}) {
		return {
			ngModule: HttpClientXsrfModule,
			providers: withXsrfConfiguration(options).ɵproviders
		};
	}
};
_HttpClientXsrfModule = HttpClientXsrfModule;
_defineProperty(HttpClientXsrfModule, "ɵfac", function HttpClientXsrfModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpClientXsrfModule)();
});
_defineProperty(HttpClientXsrfModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({ type: _HttpClientXsrfModule }));
_defineProperty(HttpClientXsrfModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({ providers: [
	HttpXsrfInterceptor,
	{
		provide: HTTP_INTERCEPTORS,
		useExisting: HttpXsrfInterceptor,
		multi: true
	},
	{
		provide: HttpXsrfTokenExtractor,
		useClass: HttpXsrfCookieExtractor
	},
	withXsrfConfiguration({
		cookieName: XSRF_DEFAULT_COOKIE_NAME,
		headerName: XSRF_DEFAULT_HEADER_NAME
	}).ɵproviders,
	{
		provide: XSRF_ENABLED,
		useValue: true
	}
] }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpClientXsrfModule, [{
		type: NgModule,
		args: [{ providers: [
			HttpXsrfInterceptor,
			{
				provide: HTTP_INTERCEPTORS,
				useExisting: HttpXsrfInterceptor,
				multi: true
			},
			{
				provide: HttpXsrfTokenExtractor,
				useClass: HttpXsrfCookieExtractor
			},
			withXsrfConfiguration({
				cookieName: XSRF_DEFAULT_COOKIE_NAME,
				headerName: XSRF_DEFAULT_HEADER_NAME
			}).ɵproviders,
			{
				provide: XSRF_ENABLED,
				useValue: true
			}
		] }]
	}], null, null);
})();
var HttpClientModule = class {};
_HttpClientModule = HttpClientModule;
_defineProperty(HttpClientModule, "ɵfac", function HttpClientModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpClientModule)();
});
_defineProperty(HttpClientModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({ type: _HttpClientModule }));
_defineProperty(HttpClientModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({ providers: [provideHttpClient(withInterceptorsFromDi(), withXhr())] }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpClientModule, [{
		type: NgModule,
		args: [{ providers: [provideHttpClient(withInterceptorsFromDi(), withXhr())] }]
	}], null, null);
})();
var HttpClientJsonpModule = class {};
_HttpClientJsonpModule = HttpClientJsonpModule;
_defineProperty(HttpClientJsonpModule, "ɵfac", function HttpClientJsonpModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HttpClientJsonpModule)();
});
_defineProperty(HttpClientJsonpModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({ type: _HttpClientJsonpModule }));
_defineProperty(HttpClientJsonpModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({ providers: [withJsonpSupport().ɵproviders] }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HttpClientJsonpModule, [{
		type: NgModule,
		args: [{ providers: [withJsonpSupport().ɵproviders] }]
	}], null, null);
})();
//#endregion
//#region node_modules/@angular/common/fesm2022/http.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var HTTP_TRANSFER_CACHE_ORIGIN_MAP = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HTTP_TRANSFER_CACHE_ORIGIN_MAP" : "");
var BODY = "b";
var HEADERS = "h";
var STATUS = "s";
var STATUS_TEXT = "st";
var REQ_URL = "u";
var RESPONSE_TYPE = "rt";
var CACHE_OPTIONS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "HTTP_TRANSFER_STATE_CACHE_OPTIONS" : "");
var ALLOWED_METHODS = ["GET", "HEAD"];
function canUseOrCacheRequest(req, options) {
	const { isCacheActive, filter, includePostRequests, includeRequestsWithAuthHeaders, includeRequestsWithCredentials, includeNonCacheableRequests } = options;
	const { transferCache: requestOptions, method: requestMethod } = req;
	if (!isCacheActive || requestOptions === false || requestMethod === "POST" && !includePostRequests && !requestOptions || requestMethod !== "POST" && !ALLOWED_METHODS.includes(requestMethod) || !includeRequestsWithAuthHeaders && hasAuthHeaders(req) || !includeRequestsWithCredentials && hasOutgoingCredentials(req) || !includeNonCacheableRequests && (hasUncacheableCacheControl(req.headers) || isNonCacheableRequest(req.cache)) || (filter === null || filter === void 0 ? void 0 : filter(req)) === false) return false;
	return true;
}
function getHeadersToInclude(options, requestOptions) {
	return typeof requestOptions === "object" && requestOptions.includeHeaders ? requestOptions.includeHeaders : options.includeHeaders;
}
function retrieveStateFromCache(req, options, transferState, originMap, storeKey, skipUseCacheChecks = false) {
	if (!skipUseCacheChecks && !canUseOrCacheRequest(req, options)) return null;
	if (originMap) throw new RuntimeError(2803, ngDevMode && "Angular detected that the `HTTP_TRANSFER_CACHE_ORIGIN_MAP` token is configured and present in the client side code. Please ensure that this token is only provided in the server code of the application.");
	if (!storeKey) {
		const requestUrl = req.url;
		storeKey = makeCacheKey(req, requestUrl);
	}
	const response = transferState.get(storeKey, null);
	if (!response) return null;
	const { [BODY]: undecodedBody, [RESPONSE_TYPE]: responseType, [HEADERS]: httpHeaders, [STATUS]: status, [STATUS_TEXT]: statusText, [REQ_URL]: url } = response;
	let body = undecodedBody;
	switch (responseType) {
		case "arraybuffer":
			body = fromBase64(undecodedBody);
			break;
		case "blob":
			body = new Blob([fromBase64(undecodedBody)]);
			break;
	}
	let headers = new HttpHeaders(httpHeaders);
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		const { transferCache: requestOptions } = req;
		const headersToInclude = getHeadersToInclude(options, requestOptions);
		headers = appendMissingHeadersDetection(req.url, headers, headersToInclude !== null && headersToInclude !== void 0 ? headersToInclude : []);
	}
	return new HttpResponse({
		body,
		headers,
		status,
		statusText,
		url
	});
}
function transferCacheInterceptorFn(req, next) {
	const options = inject(CACHE_OPTIONS);
	if (!canUseOrCacheRequest(req, options)) return next(req);
	const transferState = inject(TransferState);
	inject(HTTP_TRANSFER_CACHE_ORIGIN_MAP, { optional: true });
	const requestUrl = req.url;
	const cachedResponse = retrieveStateFromCache(req, options, transferState, null, makeCacheKey(req, requestUrl), true);
	if (cachedResponse) return of(cachedResponse);
	return next(req);
}
function hasAuthHeaders(req) {
	const headers = req.headers;
	return headers.has("authorization") || headers.has("proxy-authorization") || headers.has("cookie");
}
var UNCACHEABLE_CACHE_CONTROL_DIRECTIVES = /* @__PURE__ */ new Set([
	"no-store",
	"private",
	"no-cache"
]);
function hasUncacheableCacheControl(headers) {
	const cacheControl = headers.get("cache-control");
	if (!cacheControl) return false;
	return cacheControl.split(",").some((directive) => {
		const directiveName = directive.split("=", 1)[0].trim().toLowerCase();
		return UNCACHEABLE_CACHE_CONTROL_DIRECTIVES.has(directiveName);
	});
}
function isNonCacheableRequest(cache) {
	return cache === "no-cache" || cache === "no-store";
}
function hasOutgoingCredentials(req) {
	const { withCredentials, credentials } = req;
	return withCredentials || credentials === "include" || credentials === "same-origin";
}
function sortAndConcatParams(params) {
	const searchParams = new URLSearchParams(params instanceof URLSearchParams ? params : params.toString());
	searchParams.sort();
	return searchParams.toString();
}
function makeCacheKey(request, mappedRequestUrl) {
	const { params, method, responseType } = request;
	const encodedParams = sortAndConcatParams(params);
	let serializedBody = request.serializeBody();
	if (serializedBody instanceof URLSearchParams) serializedBody = sortAndConcatParams(serializedBody);
	else if (typeof serializedBody !== "string") serializedBody = "";
	return makeStateKey(generateHash([
		method,
		responseType,
		mappedRequestUrl,
		serializedBody,
		encodedParams
	].join("\0")));
}
function fromBase64(base64) {
	const binary = atob(base64);
	return Uint8Array.from(binary, (c) => c.charCodeAt(0)).buffer;
}
function withHttpTransferCache(cacheOptions) {
	return [
		{
			provide: CACHE_OPTIONS,
			useFactory: () => {
				performanceMarkFeature("NgHttpTransferCache");
				return _objectSpread2({ isCacheActive: true }, cacheOptions);
			}
		},
		{
			provide: HTTP_ROOT_INTERCEPTOR_FNS,
			useValue: transferCacheInterceptorFn,
			multi: true
		},
		{
			provide: APP_BOOTSTRAP_LISTENER,
			multi: true,
			useFactory: () => {
				const appRef = inject(ApplicationRef);
				const cacheState = inject(CACHE_OPTIONS);
				return () => {
					appRef.whenStable().then(() => {
						cacheState.isCacheActive = false;
					});
				};
			}
		}
	];
}
function appendMissingHeadersDetection(url, headers, headersToInclude) {
	const warningProduced = /* @__PURE__ */ new Set();
	return new Proxy(headers, { get(target, prop) {
		const value = Reflect.get(target, prop);
		if (typeof value !== "function" || !(/* @__PURE__ */ new Set([
			"get",
			"has",
			"getAll"
		])).has(prop)) return value;
		return (headerName) => {
			const key = (prop + ":" + headerName).toLowerCase();
			if (!headersToInclude.includes(headerName) && !warningProduced.has(key)) {
				warningProduced.add(key);
				const truncatedUrl = truncateMiddle(url);
				console.warn(formatRuntimeError(-2802, `Angular detected that the \`${headerName}\` header is accessed, but the value of the header was not transferred from the server to the client by the HttpTransferCache. To include the value of the \`${headerName}\` header for the \`${truncatedUrl}\` request, use the \`includeHeaders\` list. The \`includeHeaders\` can be defined either on a request level by adding the \`transferCache\` parameter, or on an application level by adding the \`httpCacheTransfer.includeHeaders\` argument to the \`provideClientHydration()\` call. `));
			}
			return value.apply(target, [headerName]);
		};
	} });
}
var SHA256_ROUND_CONSTANTS = /* @__PURE__ */ new Uint32Array([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
var textEncoder;
function generateHash(value) {
	var _textEncoder;
	(_textEncoder = textEncoder) !== null && _textEncoder !== void 0 || (textEncoder = new TextEncoder());
	const inputBytes = textEncoder.encode(value);
	let hashState0 = 1779033703;
	let hashState1 = 3144134277;
	let hashState2 = 1013904242;
	let hashState3 = 2773480762;
	let hashState4 = 1359893119;
	let hashState5 = 2600822924;
	let hashState6 = 528734635;
	let hashState7 = 1541459225;
	const messageLengthInBits = inputBytes.length * 8;
	const paddedLengthInBytes = (inputBytes.length + 8 >> 6) + 1 << 6;
	const paddedBytes = new Uint8Array(paddedLengthInBytes);
	paddedBytes.set(inputBytes);
	paddedBytes[inputBytes.length] = 128;
	const paddedBytesView = new DataView(paddedBytes.buffer);
	const lowBits = messageLengthInBits >>> 0;
	const highBits = messageLengthInBits / 4294967296 >>> 0;
	paddedBytesView.setUint32(paddedLengthInBytes - 8, highBits, false);
	paddedBytesView.setUint32(paddedLengthInBytes - 4, lowBits, false);
	const messageSchedule = /* @__PURE__ */ new Uint32Array(64);
	for (let chunkOffset = 0; chunkOffset < paddedLengthInBytes; chunkOffset += 64) {
		for (let i = 0; i < 16; i++) messageSchedule[i] = paddedBytesView.getUint32(chunkOffset + i * 4, false);
		for (let i = 16; i < 64; i++) {
			const prevWord15 = messageSchedule[i - 15];
			const sigma0 = ((prevWord15 >>> 7 | prevWord15 << 25) ^ (prevWord15 >>> 18 | prevWord15 << 14) ^ prevWord15 >>> 3) >>> 0;
			const prevWord2 = messageSchedule[i - 2];
			const sigma1 = ((prevWord2 >>> 17 | prevWord2 << 15) ^ (prevWord2 >>> 19 | prevWord2 << 13) ^ prevWord2 >>> 10) >>> 0;
			messageSchedule[i] = messageSchedule[i - 16] + sigma0 + messageSchedule[i - 7] + sigma1 >>> 0;
		}
		let workingStateA = hashState0;
		let workingStateB = hashState1;
		let workingStateC = hashState2;
		let workingStateD = hashState3;
		let workingStateE = hashState4;
		let workingStateF = hashState5;
		let workingStateG = hashState6;
		let workingStateH = hashState7;
		for (let i = 0; i < 64; i++) {
			const capitalSigma1 = ((workingStateE >>> 6 | workingStateE << 26) ^ (workingStateE >>> 11 | workingStateE << 21) ^ (workingStateE >>> 25 | workingStateE << 7)) >>> 0;
			const chFunction = (workingStateE & workingStateF ^ ~workingStateE & workingStateG) >>> 0;
			const temp1 = workingStateH + capitalSigma1 + chFunction + SHA256_ROUND_CONSTANTS[i] + messageSchedule[i] >>> 0;
			const temp2 = (((workingStateA >>> 2 | workingStateA << 30) ^ (workingStateA >>> 13 | workingStateA << 19) ^ (workingStateA >>> 22 | workingStateA << 10)) >>> 0) + ((workingStateA & workingStateB ^ workingStateA & workingStateC ^ workingStateB & workingStateC) >>> 0) >>> 0;
			workingStateH = workingStateG;
			workingStateG = workingStateF;
			workingStateF = workingStateE;
			workingStateE = workingStateD + temp1 >>> 0;
			workingStateD = workingStateC;
			workingStateC = workingStateB;
			workingStateB = workingStateA;
			workingStateA = temp1 + temp2 >>> 0;
		}
		hashState0 = hashState0 + workingStateA >>> 0;
		hashState1 = hashState1 + workingStateB >>> 0;
		hashState2 = hashState2 + workingStateC >>> 0;
		hashState3 = hashState3 + workingStateD >>> 0;
		hashState4 = hashState4 + workingStateE >>> 0;
		hashState5 = hashState5 + workingStateF >>> 0;
		hashState6 = hashState6 + workingStateG >>> 0;
		hashState7 = hashState7 + workingStateH >>> 0;
	}
	return [
		hashState0,
		hashState1,
		hashState2,
		hashState3,
		hashState4,
		hashState5,
		hashState6,
		hashState7
	].map((x) => x.toString(16).padStart(8, "0")).join("");
}
var httpResource = (() => {
	const jsonFn = makeHttpResourceFn("json");
	jsonFn.arrayBuffer = makeHttpResourceFn("arraybuffer");
	jsonFn.blob = makeHttpResourceFn("blob");
	jsonFn.text = makeHttpResourceFn("text");
	return jsonFn;
})();
function makeHttpResourceFn(responseType) {
	return function httpResource(request, options) {
		var _options$injector;
		if (ngDevMode && !(options === null || options === void 0 ? void 0 : options.injector)) assertInInjectionContext(httpResource);
		const injector = (_options$injector = options === null || options === void 0 ? void 0 : options.injector) !== null && _options$injector !== void 0 ? _options$injector : inject(Injector);
		const cacheOptions = injector.get(CACHE_OPTIONS, null, { optional: true });
		const transferState = injector.get(TransferState, null, { optional: true });
		const originMap = injector.get(HTTP_TRANSFER_CACHE_ORIGIN_MAP, null, { optional: true });
		const getInitialStream = (req) => {
			if (cacheOptions && transferState && req) {
				const cachedResponse = retrieveStateFromCache(req, cacheOptions, transferState, originMap);
				if (cachedResponse) try {
					const body = cachedResponse.body;
					return signal({ value: (options === null || options === void 0 ? void 0 : options.parse) ? options.parse(body) : body });
				} catch (e) {
					if (typeof ngDevMode === "undefined" || ngDevMode) console.warn(`Angular detected an error while parsing the cached response for the httpResource at \`${req.url}\`. The resource will fall back to its default value and try again asynchronously.`, e);
				}
			}
		};
		return new HttpResourceImpl(injector, (ctx) => normalizeRequest(ctx, request, responseType), options === null || options === void 0 ? void 0 : options.defaultValue, options === null || options === void 0 ? void 0 : options.debugName, options === null || options === void 0 ? void 0 : options.parse, options === null || options === void 0 ? void 0 : options.equal, getInitialStream);
	};
}
function normalizeRequest(ctx, request, responseType) {
	var _unwrappedRequest$met, _unwrappedRequest$bod;
	let unwrappedRequest = typeof request === "function" ? request(ctx) : request;
	if (unwrappedRequest === void 0) return;
	else if (typeof unwrappedRequest === "string") unwrappedRequest = { url: unwrappedRequest };
	const headers = unwrappedRequest.headers instanceof HttpHeaders ? unwrappedRequest.headers : new HttpHeaders(unwrappedRequest.headers);
	const params = unwrappedRequest.params instanceof HttpParams ? unwrappedRequest.params : new HttpParams({ fromObject: unwrappedRequest.params });
	return new HttpRequest((_unwrappedRequest$met = unwrappedRequest.method) !== null && _unwrappedRequest$met !== void 0 ? _unwrappedRequest$met : "GET", unwrappedRequest.url, (_unwrappedRequest$bod = unwrappedRequest.body) !== null && _unwrappedRequest$bod !== void 0 ? _unwrappedRequest$bod : null, {
		headers,
		params,
		reportProgress: unwrappedRequest.reportProgress,
		withCredentials: unwrappedRequest.withCredentials,
		keepalive: unwrappedRequest.keepalive,
		cache: unwrappedRequest.cache,
		priority: unwrappedRequest.priority,
		mode: unwrappedRequest.mode,
		redirect: unwrappedRequest.redirect,
		responseType,
		context: unwrappedRequest.context,
		transferCache: unwrappedRequest.transferCache,
		credentials: unwrappedRequest.credentials,
		referrer: unwrappedRequest.referrer,
		referrerPolicy: unwrappedRequest.referrerPolicy,
		integrity: unwrappedRequest.integrity,
		timeout: unwrappedRequest.timeout
	});
}
var HttpResourceImpl = class extends ResourceImpl {
	constructor(injector, request, defaultValue, debugName, parse, equal, getInitialStream) {
		super(request, ({ params: request, abortSignal }) => {
			let sub;
			let aborted = false;
			const onAbort = () => {
				aborted = true;
				sub === null || sub === void 0 || sub.unsubscribe();
			};
			abortSignal.addEventListener("abort", onAbort);
			const stream = signal({ value: void 0 }, ...ngDevMode ? [{ debugName: "stream" }] : []);
			let resolve;
			const promise = new Promise((r) => resolve = r);
			const send = (value) => {
				stream.set(value);
				resolve === null || resolve === void 0 || resolve(stream);
				resolve = void 0;
			};
			sub = this.client.request(request).subscribe({
				next: (event) => {
					switch (event.type) {
						case HttpEventType.Response:
							this._headers.set(event.headers);
							this._statusCode.set(event.status);
							try {
								send({ value: parse ? parse(event.body) : event.body });
							} catch (error) {
								send({ error: encapsulateResourceError(error) });
							}
							break;
						case HttpEventType.DownloadProgress:
							this._progress.set(event);
							break;
					}
				},
				error: (error) => {
					if (error instanceof HttpErrorResponse) {
						this._headers.set(error.headers);
						this._statusCode.set(error.status);
					}
					send({ error });
					abortSignal.removeEventListener("abort", onAbort);
				},
				complete: () => {
					if (resolve) send({ error: new RuntimeError(991, ngDevMode && "Resource completed before producing a value") });
					abortSignal.removeEventListener("abort", onAbort);
				}
			});
			if (aborted) sub.unsubscribe();
			return promise;
		}, defaultValue, equal, debugName, injector, void 0, getInitialStream);
		_defineProperty(this, "client", void 0);
		_defineProperty(this, "_headers", linkedSignal(_objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_headers" } : {}), {}, {
			source: this.extRequest,
			computation: () => void 0
		})));
		_defineProperty(this, "_progress", linkedSignal(_objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_progress" } : {}), {}, {
			source: this.extRequest,
			computation: () => void 0
		})));
		_defineProperty(this, "_statusCode", linkedSignal(_objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_statusCode" } : {}), {}, {
			source: this.extRequest,
			computation: () => void 0
		})));
		_defineProperty(this, "headers", computed(() => this.status() === "resolved" || this.status() === "error" ? this._headers() : void 0, ...ngDevMode ? [{ debugName: "headers" }] : []));
		_defineProperty(this, "progress", this._progress.asReadonly());
		_defineProperty(this, "statusCode", this._statusCode.asReadonly());
		this.client = injector.get(HttpClient);
	}
	set(value) {
		super.set(value);
		this._headers.set(void 0);
		this._progress.set(void 0);
		this._statusCode.set(void 0);
	}
};
//#endregion
export { JsonpClientBackend as A, withXhr as B, HttpRequest as C, HttpUrlEncodingCodec as D, HttpStatusCode as E, withInterceptors as F, withInterceptorsFromDi as I, withJsonpSupport as L, REQUESTS_CONTRIBUTE_TO_STABILITY as M, provideHttpClient as N, HttpXhrBackend as O, withFetch as P, withNoXsrfProtection as R, HttpParams as S, HttpResponseBase as T, withXsrfConfiguration as V, HttpFeatureKind as _, HTTP_FETCH_MAX_RESPONSE_SIZE as a, HttpHeaders as b, HttpBackend as c, HttpClientModule as d, HttpClientXsrfModule as f, HttpEventType as g, HttpErrorResponse as h, FetchBackend as i, JsonpInterceptor as j, HttpXsrfTokenExtractor as k, HttpClient as l, HttpContextToken as m, httpResource as n, HTTP_INTERCEPTORS as o, HttpContext as p, withHttpTransferCache as r, HTTP_ROOT_INTERCEPTOR_FNS as s, HTTP_TRANSFER_CACHE_ORIGIN_MAP as t, HttpClientJsonpModule as u, HttpHandler as v, HttpResponse as w, HttpInterceptorHandler as x, HttpHeaderResponse as y, withRequestsMadeViaParent as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHR0cC1ESEFaWlN6aC5qcyIsIm5hbWVzIjpbIl9SdW50aW1lRXJyb3IiLCJ0aGlzIiwiRmV0Y2hCYWNrZW5kIiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiX2Zvcm1hdFJ1bnRpbWVFcnJvciIsIkh0dHBYc3JmQ29va2llRXh0cmFjdG9yIiwiSHR0cFhzcmZUb2tlbkV4dHJhY3RvciIsImkwLsm1ybVpbmplY3QiLCJIdHRwWHNyZkludGVyY2VwdG9yIiwiSHR0cEJhY2tlbmQiLCJIdHRwSW50ZXJjZXB0b3JIYW5kbGVyIiwiaTAuRW52aXJvbm1lbnRJbmplY3RvciIsIkh0dHBIYW5kbGVyIiwiSHR0cENsaWVudCIsIkpzb25wQ2xpZW50QmFja2VuZCIsIkpzb25wSW50ZXJjZXB0b3IiLCJfVHJhY2luZ1NlcnZpY2UiLCJIdHRwWGhyQmFja2VuZCIsIkh0dHBDbGllbnRYc3JmTW9kdWxlIiwiSHR0cENsaWVudE1vZHVsZSIsIkh0dHBDbGllbnRKc29ucE1vZHVsZSIsIl9SdW50aW1lRXJyb3IiLCJfdHJ1bmNhdGVNaWRkbGUiLCJfZm9ybWF0UnVudGltZUVycm9yIiwiX1Jlc291cmNlSW1wbCIsIl9lbmNhcHN1bGF0ZVJlc291cmNlRXJyb3IiXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvY29tbW9uL2Zlc20yMDIyL19tb2R1bGUtY2h1bmsubWpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0Bhbmd1bGFyL2NvbW1vbi9mZXNtMjAyMi9odHRwLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjIyLjEuMlxuICogKGMpIDIwMTAtMjAyNiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuZGV2L1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0ICogYXMgaTAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCBJbmplY3Rpb25Ub2tlbiwgaW5qZWN0LCBOZ1pvbmUsIERlc3Ryb3lSZWYsIMm1Zm9ybWF0UnVudGltZUVycm9yIGFzIF9mb3JtYXRSdW50aW1lRXJyb3IsIFNlcnZpY2UsIEVudmlyb25tZW50SW5qZWN0b3IsIHJ1bkluSW5qZWN0aW9uQ29udGV4dCwgRE9DVU1FTlQsIEluamVjdGFibGUsIFBlbmRpbmdUYXNrcywgybVDb25zb2xlIGFzIF9Db25zb2xlLCB1bnRyYWNrZWQsIENTUF9OT05DRSwgSW5qZWN0LCDJtVRyYWNpbmdTZXJ2aWNlIGFzIF9UcmFjaW5nU2VydmljZSwgbWFrZUVudmlyb25tZW50UHJvdmlkZXJzLCBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZmluYWxpemUsIGNvbmNhdE1hcCwgZmlsdGVyLCBtYXAsIHN3aXRjaE1hcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmltcG9ydCB7IHBhcnNlQ29va2llVmFsdWUsIFhockZhY3RvcnkgfSBmcm9tICcuL194aHItY2h1bmsubWpzJztcbmltcG9ydCB7IFBsYXRmb3JtTG9jYXRpb24gfSBmcm9tICcuL19wbGF0Zm9ybV9sb2NhdGlvbi1jaHVuay5tanMnO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgb2YsIGZyb20gfSBmcm9tICdyeGpzJztcbmNsYXNzIEh0dHBIZWFkZXJzIHtcbiAgaGVhZGVycztcbiAgbm9ybWFsaXplZE5hbWVzID0gbmV3IE1hcCgpO1xuICBsYXp5SW5pdDtcbiAgbGF6eVVwZGF0ZSA9IG51bGw7XG4gIGNvbnN0cnVjdG9yKGhlYWRlcnMpIHtcbiAgICBpZiAoIWhlYWRlcnMpIHtcbiAgICAgIHRoaXMuaGVhZGVycyA9IG5ldyBNYXAoKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBoZWFkZXJzID09PSAnc3RyaW5nJykge1xuICAgICAgdGhpcy5sYXp5SW5pdCA9ICgpID0+IHtcbiAgICAgICAgdGhpcy5oZWFkZXJzID0gbmV3IE1hcCgpO1xuICAgICAgICBoZWFkZXJzLnNwbGl0KCdcXG4nKS5mb3JFYWNoKGxpbmUgPT4ge1xuICAgICAgICAgIGNvbnN0IGluZGV4ID0gbGluZS5pbmRleE9mKCc6Jyk7XG4gICAgICAgICAgaWYgKGluZGV4ID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmFtZSA9IGxpbmUuc2xpY2UoMCwgaW5kZXgpO1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBsaW5lLnNsaWNlKGluZGV4ICsgMSkudHJpbSgpO1xuICAgICAgICAgICAgdGhpcy5hZGRIZWFkZXJFbnRyeShuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgSGVhZGVycyAhPT0gJ3VuZGVmaW5lZCcgJiYgaGVhZGVycyBpbnN0YW5jZW9mIEhlYWRlcnMpIHtcbiAgICAgIHRoaXMuaGVhZGVycyA9IG5ldyBNYXAoKTtcbiAgICAgIGhlYWRlcnMuZm9yRWFjaCgodmFsdWUsIG5hbWUpID0+IHtcbiAgICAgICAgdGhpcy5hZGRIZWFkZXJFbnRyeShuYW1lLCB2YWx1ZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5sYXp5SW5pdCA9ICgpID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgICAgIGFzc2VydFZhbGlkSGVhZGVycyhoZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmhlYWRlcnMgPSBuZXcgTWFwKCk7XG4gICAgICAgIE9iamVjdC5lbnRyaWVzKGhlYWRlcnMpLmZvckVhY2goKFtuYW1lLCB2YWx1ZXNdKSA9PiB7XG4gICAgICAgICAgdGhpcy5zZXRIZWFkZXJFbnRyaWVzKG5hbWUsIHZhbHVlcyk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9XG4gIH1cbiAgaGFzKG5hbWUpIHtcbiAgICB0aGlzLmluaXQoKTtcbiAgICByZXR1cm4gdGhpcy5oZWFkZXJzLmhhcyhuYW1lLnRvTG93ZXJDYXNlKCkpO1xuICB9XG4gIGdldChuYW1lKSB7XG4gICAgdGhpcy5pbml0KCk7XG4gICAgY29uc3QgdmFsdWVzID0gdGhpcy5oZWFkZXJzLmdldChuYW1lLnRvTG93ZXJDYXNlKCkpO1xuICAgIHJldHVybiB2YWx1ZXMgJiYgdmFsdWVzLmxlbmd0aCA+IDAgPyB2YWx1ZXNbMF0gOiBudWxsO1xuICB9XG4gIGtleXMoKSB7XG4gICAgdGhpcy5pbml0KCk7XG4gICAgcmV0dXJuIEFycmF5LmZyb20odGhpcy5ub3JtYWxpemVkTmFtZXMudmFsdWVzKCkpO1xuICB9XG4gIGdldEFsbChuYW1lKSB7XG4gICAgdGhpcy5pbml0KCk7XG4gICAgcmV0dXJuIHRoaXMuaGVhZGVycy5nZXQobmFtZS50b0xvd2VyQ2FzZSgpKSB8fCBudWxsO1xuICB9XG4gIGFwcGVuZChuYW1lLCB2YWx1ZSkge1xuICAgIHJldHVybiB0aGlzLmNsb25lKHtcbiAgICAgIG5hbWUsXG4gICAgICB2YWx1ZSxcbiAgICAgIG9wOiAnYSdcbiAgICB9KTtcbiAgfVxuICBzZXQobmFtZSwgdmFsdWUpIHtcbiAgICByZXR1cm4gdGhpcy5jbG9uZSh7XG4gICAgICBuYW1lLFxuICAgICAgdmFsdWUsXG4gICAgICBvcDogJ3MnXG4gICAgfSk7XG4gIH1cbiAgZGVsZXRlKG5hbWUsIHZhbHVlKSB7XG4gICAgcmV0dXJuIHRoaXMuY2xvbmUoe1xuICAgICAgbmFtZSxcbiAgICAgIHZhbHVlLFxuICAgICAgb3A6ICdkJ1xuICAgIH0pO1xuICB9XG4gIG1heWJlU2V0Tm9ybWFsaXplZE5hbWUobmFtZSwgbGNOYW1lKSB7XG4gICAgaWYgKCF0aGlzLm5vcm1hbGl6ZWROYW1lcy5oYXMobGNOYW1lKSkge1xuICAgICAgdGhpcy5ub3JtYWxpemVkTmFtZXMuc2V0KGxjTmFtZSwgbmFtZSk7XG4gICAgfVxuICB9XG4gIGluaXQoKSB7XG4gICAgaWYgKCEhdGhpcy5sYXp5SW5pdCkge1xuICAgICAgaWYgKHRoaXMubGF6eUluaXQgaW5zdGFuY2VvZiBIdHRwSGVhZGVycykge1xuICAgICAgICB0aGlzLmNvcHlGcm9tKHRoaXMubGF6eUluaXQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5sYXp5SW5pdCgpO1xuICAgICAgfVxuICAgICAgdGhpcy5sYXp5SW5pdCA9IG51bGw7XG4gICAgICBpZiAoISF0aGlzLmxhenlVcGRhdGUpIHtcbiAgICAgICAgdGhpcy5sYXp5VXBkYXRlLmZvckVhY2godXBkYXRlID0+IHRoaXMuYXBwbHlVcGRhdGUodXBkYXRlKSk7XG4gICAgICAgIHRoaXMubGF6eVVwZGF0ZSA9IG51bGw7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvcHlGcm9tKG90aGVyKSB7XG4gICAgb3RoZXIuaW5pdCgpO1xuICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVzXSBvZiBvdGhlci5oZWFkZXJzLmVudHJpZXMoKSkge1xuICAgICAgdGhpcy5oZWFkZXJzLnNldChrZXksIHZhbHVlcyk7XG4gICAgICB0aGlzLm5vcm1hbGl6ZWROYW1lcy5zZXQoa2V5LCBvdGhlci5ub3JtYWxpemVkTmFtZXMuZ2V0KGtleSkpO1xuICAgIH1cbiAgfVxuICBjbG9uZSh1cGRhdGUpIHtcbiAgICBjb25zdCBjbG9uZSA9IG5ldyBIdHRwSGVhZGVycygpO1xuICAgIGNsb25lLmxhenlJbml0ID0gISF0aGlzLmxhenlJbml0ICYmIHRoaXMubGF6eUluaXQgaW5zdGFuY2VvZiBIdHRwSGVhZGVycyA/IHRoaXMubGF6eUluaXQgOiB0aGlzO1xuICAgIGNsb25lLmxhenlVcGRhdGUgPSAodGhpcy5sYXp5VXBkYXRlIHx8IFtdKS5jb25jYXQoW3VwZGF0ZV0pO1xuICAgIHJldHVybiBjbG9uZTtcbiAgfVxuICBhcHBseVVwZGF0ZSh1cGRhdGUpIHtcbiAgICBjb25zdCBrZXkgPSB1cGRhdGUubmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIHN3aXRjaCAodXBkYXRlLm9wKSB7XG4gICAgICBjYXNlICdhJzpcbiAgICAgIGNhc2UgJ3MnOlxuICAgICAgICBsZXQgdmFsdWUgPSB1cGRhdGUudmFsdWU7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgdmFsdWUgPSBbdmFsdWVdO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5tYXliZVNldE5vcm1hbGl6ZWROYW1lKHVwZGF0ZS5uYW1lLCBrZXkpO1xuICAgICAgICBjb25zdCBiYXNlID0gdXBkYXRlLm9wID09PSAnYScgPyAodGhpcy5oZWFkZXJzLmdldChrZXkpIHx8IFtdKS5zbGljZSgpIDogW107XG4gICAgICAgIGJhc2UucHVzaCguLi52YWx1ZSk7XG4gICAgICAgIHRoaXMuaGVhZGVycy5zZXQoa2V5LCBiYXNlKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkJzpcbiAgICAgICAgY29uc3QgdG9EZWxldGUgPSB1cGRhdGUudmFsdWU7XG4gICAgICAgIGlmICh0b0RlbGV0ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgdGhpcy5oZWFkZXJzLmRlbGV0ZShrZXkpO1xuICAgICAgICAgIHRoaXMubm9ybWFsaXplZE5hbWVzLmRlbGV0ZShrZXkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IHZhbHVlc1RvRGVsZXRlID0gQXJyYXkuaXNBcnJheSh0b0RlbGV0ZSkgPyB0b0RlbGV0ZSA6IFt0b0RlbGV0ZV07XG4gICAgICAgICAgbGV0IGV4aXN0aW5nID0gdGhpcy5oZWFkZXJzLmdldChrZXkpO1xuICAgICAgICAgIGlmICghZXhpc3RpbmcpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgZXhpc3RpbmcgPSBleGlzdGluZy5maWx0ZXIodmFsdWUgPT4gdmFsdWVzVG9EZWxldGUuaW5kZXhPZih2YWx1ZSkgPT09IC0xKTtcbiAgICAgICAgICBpZiAoZXhpc3RpbmcubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLmhlYWRlcnMuZGVsZXRlKGtleSk7XG4gICAgICAgICAgICB0aGlzLm5vcm1hbGl6ZWROYW1lcy5kZWxldGUoa2V5KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5oZWFkZXJzLnNldChrZXksIGV4aXN0aW5nKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIGFkZEhlYWRlckVudHJ5KG5hbWUsIHZhbHVlKSB7XG4gICAgY29uc3Qga2V5ID0gbmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIHRoaXMubWF5YmVTZXROb3JtYWxpemVkTmFtZShuYW1lLCBrZXkpO1xuICAgIGlmICh0aGlzLmhlYWRlcnMuaGFzKGtleSkpIHtcbiAgICAgIHRoaXMuaGVhZGVycy5nZXQoa2V5KS5wdXNoKHZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5oZWFkZXJzLnNldChrZXksIFt2YWx1ZV0pO1xuICAgIH1cbiAgfVxuICBzZXRIZWFkZXJFbnRyaWVzKG5hbWUsIHZhbHVlcykge1xuICAgIGNvbnN0IGhlYWRlclZhbHVlcyA9IChBcnJheS5pc0FycmF5KHZhbHVlcykgPyB2YWx1ZXMgOiBbdmFsdWVzXSkubWFwKHZhbHVlID0+IHZhbHVlLnRvU3RyaW5nKCkpO1xuICAgIGNvbnN0IGtleSA9IG5hbWUudG9Mb3dlckNhc2UoKTtcbiAgICB0aGlzLmhlYWRlcnMuc2V0KGtleSwgaGVhZGVyVmFsdWVzKTtcbiAgICB0aGlzLm1heWJlU2V0Tm9ybWFsaXplZE5hbWUobmFtZSwga2V5KTtcbiAgfVxuICBmb3JFYWNoKGZuKSB7XG4gICAgdGhpcy5pbml0KCk7XG4gICAgQXJyYXkuZnJvbSh0aGlzLm5vcm1hbGl6ZWROYW1lcy5rZXlzKCkpLmZvckVhY2goa2V5ID0+IGZuKHRoaXMubm9ybWFsaXplZE5hbWVzLmdldChrZXkpLCB0aGlzLmhlYWRlcnMuZ2V0KGtleSkpKTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0VmFsaWRIZWFkZXJzKGhlYWRlcnMpIHtcbiAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoaGVhZGVycykpIHtcbiAgICBpZiAoISh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpICYmICFBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmV4cGVjdGVkIHZhbHVlIG9mIHRoZSBcXGAke2tleX1cXGAgaGVhZGVyIHByb3ZpZGVkLiBgICsgYEV4cGVjdGluZyBlaXRoZXIgYSBzdHJpbmcsIGEgbnVtYmVyIG9yIGFuIGFycmF5LCBidXQgZ290OiBcXGAke3ZhbHVlfVxcYC5gKTtcbiAgICB9XG4gIH1cbn1cbmNsYXNzIEh0dHBDb250ZXh0VG9rZW4ge1xuICBkZWZhdWx0VmFsdWU7XG4gIGNvbnN0cnVjdG9yKGRlZmF1bHRWYWx1ZSkge1xuICAgIHRoaXMuZGVmYXVsdFZhbHVlID0gZGVmYXVsdFZhbHVlO1xuICB9XG59XG5jbGFzcyBIdHRwQ29udGV4dCB7XG4gIG1hcCA9IG5ldyBNYXAoKTtcbiAgc2V0KHRva2VuLCB2YWx1ZSkge1xuICAgIHRoaXMubWFwLnNldCh0b2tlbiwgdmFsdWUpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGdldCh0b2tlbikge1xuICAgIGlmICghdGhpcy5tYXAuaGFzKHRva2VuKSkge1xuICAgICAgdGhpcy5tYXAuc2V0KHRva2VuLCB0b2tlbi5kZWZhdWx0VmFsdWUoKSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm1hcC5nZXQodG9rZW4pO1xuICB9XG4gIGRlbGV0ZSh0b2tlbikge1xuICAgIHRoaXMubWFwLmRlbGV0ZSh0b2tlbik7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgaGFzKHRva2VuKSB7XG4gICAgcmV0dXJuIHRoaXMubWFwLmhhcyh0b2tlbik7XG4gIH1cbiAga2V5cygpIHtcbiAgICByZXR1cm4gdGhpcy5tYXAua2V5cygpO1xuICB9XG59XG5jbGFzcyBIdHRwVXJsRW5jb2RpbmdDb2RlYyB7XG4gIGVuY29kZUtleShrZXkpIHtcbiAgICByZXR1cm4gc3RhbmRhcmRFbmNvZGluZyhrZXkpO1xuICB9XG4gIGVuY29kZVZhbHVlKHZhbHVlKSB7XG4gICAgcmV0dXJuIHN0YW5kYXJkRW5jb2RpbmcodmFsdWUpO1xuICB9XG4gIGRlY29kZUtleShrZXkpIHtcbiAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KGtleSk7XG4gIH1cbiAgZGVjb2RlVmFsdWUodmFsdWUpIHtcbiAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgfVxufVxuZnVuY3Rpb24gcGFyYW1QYXJzZXIocmF3UGFyYW1zLCBjb2RlYykge1xuICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gIGlmIChyYXdQYXJhbXMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHJhd1BhcmFtcy5yZXBsYWNlKC9eXFw/LywgJycpLnNwbGl0KCcmJyk7XG4gICAgcGFyYW1zLmZvckVhY2gocGFyYW0gPT4ge1xuICAgICAgY29uc3QgZXFJZHggPSBwYXJhbS5pbmRleE9mKCc9Jyk7XG4gICAgICBjb25zdCBba2V5LCB2YWxdID0gZXFJZHggPT0gLTEgPyBbY29kZWMuZGVjb2RlS2V5KHBhcmFtKSwgJyddIDogW2NvZGVjLmRlY29kZUtleShwYXJhbS5zbGljZSgwLCBlcUlkeCkpLCBjb2RlYy5kZWNvZGVWYWx1ZShwYXJhbS5zbGljZShlcUlkeCArIDEpKV07XG4gICAgICBjb25zdCBsaXN0ID0gbWFwLmdldChrZXkpIHx8IFtdO1xuICAgICAgbGlzdC5wdXNoKHZhbCk7XG4gICAgICBtYXAuc2V0KGtleSwgbGlzdCk7XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIG1hcDtcbn1cbmNvbnN0IFNUQU5EQVJEX0VOQ09ESU5HX1JFR0VYID0gLyUoXFxkW2EtZjAtOV0pL2dpO1xuY29uc3QgU1RBTkRBUkRfRU5DT0RJTkdfUkVQTEFDRU1FTlRTID0ge1xuICAnNDAnOiAnQCcsXG4gICczQSc6ICc6JyxcbiAgJzI0JzogJyQnLFxuICAnMkMnOiAnLCcsXG4gICczQic6ICc7JyxcbiAgJzNEJzogJz0nLFxuICAnM0YnOiAnPycsXG4gICcyRic6ICcvJ1xufTtcbmZ1bmN0aW9uIHN0YW5kYXJkRW5jb2Rpbmcodikge1xuICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHYpLnJlcGxhY2UoU1RBTkRBUkRfRU5DT0RJTkdfUkVHRVgsIChzLCB0KSA9PiBTVEFOREFSRF9FTkNPRElOR19SRVBMQUNFTUVOVFNbdF0gPz8gcyk7XG59XG5mdW5jdGlvbiB2YWx1ZVRvU3RyaW5nKHZhbHVlKSB7XG4gIHJldHVybiBgJHt2YWx1ZX1gO1xufVxuY2xhc3MgSHR0cFBhcmFtcyB7XG4gIG1hcDtcbiAgZW5jb2RlcjtcbiAgdXBkYXRlcyA9IG51bGw7XG4gIGNsb25lRnJvbSA9IG51bGw7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMuZW5jb2RlciA9IG9wdGlvbnMuZW5jb2RlciB8fCBuZXcgSHR0cFVybEVuY29kaW5nQ29kZWMoKTtcbiAgICBpZiAob3B0aW9ucy5mcm9tU3RyaW5nKSB7XG4gICAgICBpZiAob3B0aW9ucy5mcm9tT2JqZWN0KSB7XG4gICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI4MDUsIG5nRGV2TW9kZSAmJiAnQ2Fubm90IHNwZWNpZnkgYm90aCBmcm9tU3RyaW5nIGFuZCBmcm9tT2JqZWN0LicpO1xuICAgICAgfVxuICAgICAgdGhpcy5tYXAgPSBwYXJhbVBhcnNlcihvcHRpb25zLmZyb21TdHJpbmcsIHRoaXMuZW5jb2Rlcik7XG4gICAgfSBlbHNlIGlmICghIW9wdGlvbnMuZnJvbU9iamVjdCkge1xuICAgICAgdGhpcy5tYXAgPSBuZXcgTWFwKCk7XG4gICAgICBPYmplY3Qua2V5cyhvcHRpb25zLmZyb21PYmplY3QpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBvcHRpb25zLmZyb21PYmplY3Rba2V5XTtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAodmFsdWVUb1N0cmluZykgOiBbdmFsdWVUb1N0cmluZyh2YWx1ZSldO1xuICAgICAgICB0aGlzLm1hcC5zZXQoa2V5LCB2YWx1ZXMpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubWFwID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgaGFzKHBhcmFtKSB7XG4gICAgdGhpcy5pbml0KCk7XG4gICAgcmV0dXJuIHRoaXMubWFwLmhhcyhwYXJhbSk7XG4gIH1cbiAgZ2V0KHBhcmFtKSB7XG4gICAgdGhpcy5pbml0KCk7XG4gICAgY29uc3QgcmVzID0gdGhpcy5tYXAuZ2V0KHBhcmFtKTtcbiAgICByZXR1cm4gISFyZXMgPyByZXNbMF0gOiBudWxsO1xuICB9XG4gIGdldEFsbChwYXJhbSkge1xuICAgIHRoaXMuaW5pdCgpO1xuICAgIHJldHVybiB0aGlzLm1hcC5nZXQocGFyYW0pIHx8IG51bGw7XG4gIH1cbiAga2V5cygpIHtcbiAgICB0aGlzLmluaXQoKTtcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh0aGlzLm1hcC5rZXlzKCkpO1xuICB9XG4gIGFwcGVuZChwYXJhbSwgdmFsdWUpIHtcbiAgICByZXR1cm4gdGhpcy5jbG9uZSh7XG4gICAgICBwYXJhbSxcbiAgICAgIHZhbHVlLFxuICAgICAgb3A6ICdhJ1xuICAgIH0pO1xuICB9XG4gIGFwcGVuZEFsbChwYXJhbXMpIHtcbiAgICBjb25zdCB1cGRhdGVzID0gW107XG4gICAgT2JqZWN0LmtleXMocGFyYW1zKS5mb3JFYWNoKHBhcmFtID0+IHtcbiAgICAgIGNvbnN0IHZhbHVlID0gcGFyYW1zW3BhcmFtXTtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICB2YWx1ZS5mb3JFYWNoKF92YWx1ZSA9PiB7XG4gICAgICAgICAgdXBkYXRlcy5wdXNoKHtcbiAgICAgICAgICAgIHBhcmFtLFxuICAgICAgICAgICAgdmFsdWU6IF92YWx1ZSxcbiAgICAgICAgICAgIG9wOiAnYSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB1cGRhdGVzLnB1c2goe1xuICAgICAgICAgIHBhcmFtLFxuICAgICAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgICAgICBvcDogJ2EnXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiB0aGlzLmNsb25lKHVwZGF0ZXMpO1xuICB9XG4gIHNldChwYXJhbSwgdmFsdWUpIHtcbiAgICByZXR1cm4gdGhpcy5jbG9uZSh7XG4gICAgICBwYXJhbSxcbiAgICAgIHZhbHVlLFxuICAgICAgb3A6ICdzJ1xuICAgIH0pO1xuICB9XG4gIGRlbGV0ZShwYXJhbSwgdmFsdWUpIHtcbiAgICByZXR1cm4gdGhpcy5jbG9uZSh7XG4gICAgICBwYXJhbSxcbiAgICAgIHZhbHVlLFxuICAgICAgb3A6ICdkJ1xuICAgIH0pO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHRoaXMuaW5pdCgpO1xuICAgIHJldHVybiB0aGlzLmtleXMoKS5tYXAoa2V5ID0+IHtcbiAgICAgIGNvbnN0IGVLZXkgPSB0aGlzLmVuY29kZXIuZW5jb2RlS2V5KGtleSk7XG4gICAgICByZXR1cm4gdGhpcy5tYXAuZ2V0KGtleSkubWFwKHZhbHVlID0+IGVLZXkgKyAnPScgKyB0aGlzLmVuY29kZXIuZW5jb2RlVmFsdWUodmFsdWUpKS5qb2luKCcmJyk7XG4gICAgfSkuZmlsdGVyKHBhcmFtID0+IHBhcmFtICE9PSAnJykuam9pbignJicpO1xuICB9XG4gIGNsb25lKHVwZGF0ZSkge1xuICAgIGNvbnN0IGNsb25lID0gbmV3IEh0dHBQYXJhbXMoe1xuICAgICAgZW5jb2RlcjogdGhpcy5lbmNvZGVyXG4gICAgfSk7XG4gICAgY2xvbmUuY2xvbmVGcm9tID0gdGhpcy5jbG9uZUZyb20gfHwgdGhpcztcbiAgICBjbG9uZS51cGRhdGVzID0gKHRoaXMudXBkYXRlcyB8fCBbXSkuY29uY2F0KHVwZGF0ZSk7XG4gICAgcmV0dXJuIGNsb25lO1xuICB9XG4gIGluaXQoKSB7XG4gICAgaWYgKHRoaXMubWFwID09PSBudWxsKSB7XG4gICAgICB0aGlzLm1hcCA9IG5ldyBNYXAoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuY2xvbmVGcm9tICE9PSBudWxsKSB7XG4gICAgICB0aGlzLmNsb25lRnJvbS5pbml0KCk7XG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlc10gb2YgdGhpcy5jbG9uZUZyb20ubWFwLmVudHJpZXMoKSkge1xuICAgICAgICB0aGlzLm1hcC5zZXQoa2V5LCB2YWx1ZXMpO1xuICAgICAgfVxuICAgICAgdGhpcy51cGRhdGVzLmZvckVhY2godXBkYXRlID0+IHtcbiAgICAgICAgc3dpdGNoICh1cGRhdGUub3ApIHtcbiAgICAgICAgICBjYXNlICdhJzpcbiAgICAgICAgICBjYXNlICdzJzpcbiAgICAgICAgICAgIGNvbnN0IGJhc2UgPSB1cGRhdGUub3AgPT09ICdhJyA/ICh0aGlzLm1hcC5nZXQodXBkYXRlLnBhcmFtKSB8fCBbXSkuc2xpY2UoKSA6IFtdO1xuICAgICAgICAgICAgYmFzZS5wdXNoKHZhbHVlVG9TdHJpbmcodXBkYXRlLnZhbHVlKSk7XG4gICAgICAgICAgICB0aGlzLm1hcC5zZXQodXBkYXRlLnBhcmFtLCBiYXNlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ2QnOlxuICAgICAgICAgICAgaWYgKHVwZGF0ZS52YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGJhc2UgPSAodGhpcy5tYXAuZ2V0KHVwZGF0ZS5wYXJhbSkgfHwgW10pLnNsaWNlKCk7XG4gICAgICAgICAgICAgIGNvbnN0IGlkeCA9IGJhc2UuaW5kZXhPZih2YWx1ZVRvU3RyaW5nKHVwZGF0ZS52YWx1ZSkpO1xuICAgICAgICAgICAgICBpZiAoaWR4ICE9PSAtMSkge1xuICAgICAgICAgICAgICAgIGJhc2Uuc3BsaWNlKGlkeCwgMSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKGJhc2UubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIHRoaXMubWFwLnNldCh1cGRhdGUucGFyYW0sIGJhc2UpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMubWFwLmRlbGV0ZSh1cGRhdGUucGFyYW0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0aGlzLm1hcC5kZWxldGUodXBkYXRlLnBhcmFtKTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgdGhpcy5jbG9uZUZyb20gPSB0aGlzLnVwZGF0ZXMgPSBudWxsO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gbWlnaHRIYXZlQm9keShtZXRob2QpIHtcbiAgc3dpdGNoIChtZXRob2QpIHtcbiAgICBjYXNlICdERUxFVEUnOlxuICAgIGNhc2UgJ0dFVCc6XG4gICAgY2FzZSAnSEVBRCc6XG4gICAgY2FzZSAnT1BUSU9OUyc6XG4gICAgY2FzZSAnSlNPTlAnOlxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuZnVuY3Rpb24gaXNBcnJheUJ1ZmZlcih2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIEFycmF5QnVmZmVyICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyO1xufVxuZnVuY3Rpb24gaXNCbG9iKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgaW5zdGFuY2VvZiBCbG9iO1xufVxuZnVuY3Rpb24gaXNGb3JtRGF0YSh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIEZvcm1EYXRhICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZvcm1EYXRhO1xufVxuZnVuY3Rpb24gaXNVcmxTZWFyY2hQYXJhbXModmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiBVUkxTZWFyY2hQYXJhbXMgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgVVJMU2VhcmNoUGFyYW1zO1xufVxuY29uc3QgQ09OVEVOVF9UWVBFX0hFQURFUiA9ICdDb250ZW50LVR5cGUnO1xuY29uc3QgQUNDRVBUX0hFQURFUiA9ICdBY2NlcHQnO1xuY29uc3QgVEVYVF9DT05URU5UX1RZUEUgPSAndGV4dC9wbGFpbic7XG5jb25zdCBKU09OX0NPTlRFTlRfVFlQRSA9ICdhcHBsaWNhdGlvbi9qc29uJztcbmNvbnN0IEFDQ0VQVF9IRUFERVJfVkFMVUUgPSBgJHtKU09OX0NPTlRFTlRfVFlQRX0sICR7VEVYVF9DT05URU5UX1RZUEV9LCAqLypgO1xuY2xhc3MgSHR0cFJlcXVlc3Qge1xuICB1cmw7XG4gIGJvZHkgPSBudWxsO1xuICBoZWFkZXJzO1xuICBjb250ZXh0O1xuICByZXBvcnRQcm9ncmVzcyA9IGZhbHNlO1xuICByZXBvcnRVcGxvYWRQcm9ncmVzcyA9IGZhbHNlO1xuICByZXBvcnREb3dubG9hZFByb2dyZXNzID0gZmFsc2U7XG4gIHdpdGhDcmVkZW50aWFscyA9IGZhbHNlO1xuICBjcmVkZW50aWFscztcbiAga2VlcGFsaXZlID0gZmFsc2U7XG4gIGNhY2hlO1xuICBwcmlvcml0eTtcbiAgbW9kZTtcbiAgcmVkaXJlY3Q7XG4gIHJlZmVycmVyO1xuICBpbnRlZ3JpdHk7XG4gIHJlZmVycmVyUG9saWN5O1xuICByZXNwb25zZVR5cGUgPSAnanNvbic7XG4gIG1ldGhvZDtcbiAgcGFyYW1zO1xuICB1cmxXaXRoUGFyYW1zO1xuICB0cmFuc2ZlckNhY2hlO1xuICB0aW1lb3V0O1xuICBjb25zdHJ1Y3RvcihtZXRob2QsIHVybCwgdGhpcmQsIGZvdXJ0aCkge1xuICAgIHRoaXMudXJsID0gdXJsO1xuICAgIHRoaXMubWV0aG9kID0gbWV0aG9kLnRvVXBwZXJDYXNlKCk7XG4gICAgbGV0IG9wdGlvbnM7XG4gICAgaWYgKG1pZ2h0SGF2ZUJvZHkodGhpcy5tZXRob2QpIHx8ICEhZm91cnRoKSB7XG4gICAgICB0aGlzLmJvZHkgPSB0aGlyZCAhPT0gdW5kZWZpbmVkID8gdGhpcmQgOiBudWxsO1xuICAgICAgb3B0aW9ucyA9IGZvdXJ0aDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3B0aW9ucyA9IHRoaXJkO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucykge1xuICAgICAgdGhpcy5yZXBvcnRQcm9ncmVzcyA9ICEhb3B0aW9ucy5yZXBvcnRQcm9ncmVzcztcbiAgICAgIHRoaXMucmVwb3J0VXBsb2FkUHJvZ3Jlc3MgPSAhIW9wdGlvbnMucmVwb3J0VXBsb2FkUHJvZ3Jlc3M7XG4gICAgICB0aGlzLnJlcG9ydERvd25sb2FkUHJvZ3Jlc3MgPSAhIW9wdGlvbnMucmVwb3J0RG93bmxvYWRQcm9ncmVzcztcbiAgICAgIHRoaXMud2l0aENyZWRlbnRpYWxzID0gISFvcHRpb25zLndpdGhDcmVkZW50aWFscztcbiAgICAgIHRoaXMua2VlcGFsaXZlID0gISFvcHRpb25zLmtlZXBhbGl2ZTtcbiAgICAgIGlmICghIW9wdGlvbnMucmVzcG9uc2VUeXBlKSB7XG4gICAgICAgIHRoaXMucmVzcG9uc2VUeXBlID0gb3B0aW9ucy5yZXNwb25zZVR5cGU7XG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5oZWFkZXJzKSB7XG4gICAgICAgIHRoaXMuaGVhZGVycyA9IG9wdGlvbnMuaGVhZGVycztcbiAgICAgIH1cbiAgICAgIGlmIChvcHRpb25zLmNvbnRleHQpIHtcbiAgICAgICAgdGhpcy5jb250ZXh0ID0gb3B0aW9ucy5jb250ZXh0O1xuICAgICAgfVxuICAgICAgaWYgKG9wdGlvbnMucGFyYW1zKSB7XG4gICAgICAgIHRoaXMucGFyYW1zID0gb3B0aW9ucy5wYXJhbXM7XG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5wcmlvcml0eSkge1xuICAgICAgICB0aGlzLnByaW9yaXR5ID0gb3B0aW9ucy5wcmlvcml0eTtcbiAgICAgIH1cbiAgICAgIGlmIChvcHRpb25zLmNhY2hlKSB7XG4gICAgICAgIHRoaXMuY2FjaGUgPSBvcHRpb25zLmNhY2hlO1xuICAgICAgfVxuICAgICAgaWYgKG9wdGlvbnMuY3JlZGVudGlhbHMpIHtcbiAgICAgICAgdGhpcy5jcmVkZW50aWFscyA9IG9wdGlvbnMuY3JlZGVudGlhbHM7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIG9wdGlvbnMudGltZW91dCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgaWYgKG9wdGlvbnMudGltZW91dCA8IDEgfHwgIU51bWJlci5pc0ludGVnZXIob3B0aW9ucy50aW1lb3V0KSkge1xuICAgICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI4MjIsIG5nRGV2TW9kZSA/ICdgdGltZW91dGAgbXVzdCBiZSBhIHBvc2l0aXZlIGludGVnZXIgdmFsdWUnIDogJycpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMudGltZW91dCA9IG9wdGlvbnMudGltZW91dDtcbiAgICAgIH1cbiAgICAgIGlmIChvcHRpb25zLm1vZGUpIHtcbiAgICAgICAgdGhpcy5tb2RlID0gb3B0aW9ucy5tb2RlO1xuICAgICAgfVxuICAgICAgaWYgKG9wdGlvbnMucmVkaXJlY3QpIHtcbiAgICAgICAgdGhpcy5yZWRpcmVjdCA9IG9wdGlvbnMucmVkaXJlY3Q7XG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5pbnRlZ3JpdHkpIHtcbiAgICAgICAgdGhpcy5pbnRlZ3JpdHkgPSBvcHRpb25zLmludGVncml0eTtcbiAgICAgIH1cbiAgICAgIGlmIChvcHRpb25zLnJlZmVycmVyICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5yZWZlcnJlciA9IG9wdGlvbnMucmVmZXJyZXI7XG4gICAgICB9XG4gICAgICBpZiAob3B0aW9ucy5yZWZlcnJlclBvbGljeSkge1xuICAgICAgICB0aGlzLnJlZmVycmVyUG9saWN5ID0gb3B0aW9ucy5yZWZlcnJlclBvbGljeTtcbiAgICAgIH1cbiAgICAgIHRoaXMudHJhbnNmZXJDYWNoZSA9IG9wdGlvbnMudHJhbnNmZXJDYWNoZTtcbiAgICB9XG4gICAgdGhpcy5oZWFkZXJzID8/PSBuZXcgSHR0cEhlYWRlcnMoKTtcbiAgICB0aGlzLmNvbnRleHQgPz89IG5ldyBIdHRwQ29udGV4dCgpO1xuICAgIGlmICghdGhpcy5wYXJhbXMpIHtcbiAgICAgIHRoaXMucGFyYW1zID0gbmV3IEh0dHBQYXJhbXMoKTtcbiAgICAgIHRoaXMudXJsV2l0aFBhcmFtcyA9IHVybDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgcGFyYW1zID0gdGhpcy5wYXJhbXMudG9TdHJpbmcoKTtcbiAgICAgIGlmIChwYXJhbXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHRoaXMudXJsV2l0aFBhcmFtcyA9IHVybDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxldCB1cmxXaXRob3V0RnJhZ21lbnQgPSB1cmw7XG4gICAgICAgIGxldCBmcmFnbWVudCA9ICcnO1xuICAgICAgICBjb25zdCBoYXNoSWR4ID0gdXJsLmluZGV4T2YoJyMnKTtcbiAgICAgICAgaWYgKGhhc2hJZHggIT09IC0xKSB7XG4gICAgICAgICAgZnJhZ21lbnQgPSB1cmwuc3Vic3RyaW5nKGhhc2hJZHgpO1xuICAgICAgICAgIHVybFdpdGhvdXRGcmFnbWVudCA9IHVybC5zdWJzdHJpbmcoMCwgaGFzaElkeCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcUlkeCA9IHVybFdpdGhvdXRGcmFnbWVudC5pbmRleE9mKCc/Jyk7XG4gICAgICAgIGNvbnN0IHNlcCA9IHFJZHggPT09IC0xID8gJz8nIDogcUlkeCA8IHVybFdpdGhvdXRGcmFnbWVudC5sZW5ndGggLSAxID8gJyYnIDogJyc7XG4gICAgICAgIHRoaXMudXJsV2l0aFBhcmFtcyA9IHVybFdpdGhvdXRGcmFnbWVudCArIHNlcCArIHBhcmFtcyArIGZyYWdtZW50O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBzZXJpYWxpemVCb2R5KCkge1xuICAgIGlmICh0aGlzLmJvZHkgPT09IG51bGwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHRoaXMuYm9keSA9PT0gJ3N0cmluZycgfHwgaXNBcnJheUJ1ZmZlcih0aGlzLmJvZHkpIHx8IGlzQmxvYih0aGlzLmJvZHkpIHx8IGlzRm9ybURhdGEodGhpcy5ib2R5KSB8fCBpc1VybFNlYXJjaFBhcmFtcyh0aGlzLmJvZHkpKSB7XG4gICAgICByZXR1cm4gdGhpcy5ib2R5O1xuICAgIH1cbiAgICBpZiAodGhpcy5ib2R5IGluc3RhbmNlb2YgSHR0cFBhcmFtcykge1xuICAgICAgcmV0dXJuIHRoaXMuYm9keS50b1N0cmluZygpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHRoaXMuYm9keSA9PT0gJ29iamVjdCcgfHwgdHlwZW9mIHRoaXMuYm9keSA9PT0gJ2Jvb2xlYW4nIHx8IEFycmF5LmlzQXJyYXkodGhpcy5ib2R5KSkge1xuICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHRoaXMuYm9keSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmJvZHkudG9TdHJpbmcoKTtcbiAgfVxuICBkZXRlY3RDb250ZW50VHlwZUhlYWRlcigpIHtcbiAgICBpZiAodGhpcy5ib2R5ID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKGlzRm9ybURhdGEodGhpcy5ib2R5KSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmIChpc0Jsb2IodGhpcy5ib2R5KSkge1xuICAgICAgcmV0dXJuIHRoaXMuYm9keS50eXBlIHx8IG51bGw7XG4gICAgfVxuICAgIGlmIChpc0FycmF5QnVmZmVyKHRoaXMuYm9keSkpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHRoaXMuYm9keSA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHJldHVybiBURVhUX0NPTlRFTlRfVFlQRTtcbiAgICB9XG4gICAgaWYgKHRoaXMuYm9keSBpbnN0YW5jZW9mIEh0dHBQYXJhbXMpIHtcbiAgICAgIHJldHVybiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkO2NoYXJzZXQ9VVRGLTgnO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHRoaXMuYm9keSA9PT0gJ29iamVjdCcgfHwgdHlwZW9mIHRoaXMuYm9keSA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHRoaXMuYm9keSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICByZXR1cm4gSlNPTl9DT05URU5UX1RZUEU7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNsb25lKHVwZGF0ZSA9IHt9KSB7XG4gICAgY29uc3QgbWV0aG9kID0gdXBkYXRlLm1ldGhvZCB8fCB0aGlzLm1ldGhvZDtcbiAgICBjb25zdCB1cmwgPSB1cGRhdGUudXJsIHx8IHRoaXMudXJsO1xuICAgIGNvbnN0IHJlc3BvbnNlVHlwZSA9IHVwZGF0ZS5yZXNwb25zZVR5cGUgfHwgdGhpcy5yZXNwb25zZVR5cGU7XG4gICAgY29uc3Qga2VlcGFsaXZlID0gdXBkYXRlLmtlZXBhbGl2ZSA/PyB0aGlzLmtlZXBhbGl2ZTtcbiAgICBjb25zdCBwcmlvcml0eSA9IHVwZGF0ZS5wcmlvcml0eSB8fCB0aGlzLnByaW9yaXR5O1xuICAgIGNvbnN0IGNhY2hlID0gdXBkYXRlLmNhY2hlIHx8IHRoaXMuY2FjaGU7XG4gICAgY29uc3QgbW9kZSA9IHVwZGF0ZS5tb2RlIHx8IHRoaXMubW9kZTtcbiAgICBjb25zdCByZWRpcmVjdCA9IHVwZGF0ZS5yZWRpcmVjdCB8fCB0aGlzLnJlZGlyZWN0O1xuICAgIGNvbnN0IGNyZWRlbnRpYWxzID0gdXBkYXRlLmNyZWRlbnRpYWxzIHx8IHRoaXMuY3JlZGVudGlhbHM7XG4gICAgY29uc3QgcmVmZXJyZXIgPSB1cGRhdGUucmVmZXJyZXIgPz8gdGhpcy5yZWZlcnJlcjtcbiAgICBjb25zdCBpbnRlZ3JpdHkgPSB1cGRhdGUuaW50ZWdyaXR5IHx8IHRoaXMuaW50ZWdyaXR5O1xuICAgIGNvbnN0IHJlZmVycmVyUG9saWN5ID0gdXBkYXRlLnJlZmVycmVyUG9saWN5IHx8IHRoaXMucmVmZXJyZXJQb2xpY3k7XG4gICAgY29uc3QgdHJhbnNmZXJDYWNoZSA9IHVwZGF0ZS50cmFuc2ZlckNhY2hlID8/IHRoaXMudHJhbnNmZXJDYWNoZTtcbiAgICBjb25zdCB0aW1lb3V0ID0gdXBkYXRlLnRpbWVvdXQgPz8gdGhpcy50aW1lb3V0O1xuICAgIGNvbnN0IGJvZHkgPSB1cGRhdGUuYm9keSAhPT0gdW5kZWZpbmVkID8gdXBkYXRlLmJvZHkgOiB0aGlzLmJvZHk7XG4gICAgY29uc3Qgd2l0aENyZWRlbnRpYWxzID0gdXBkYXRlLndpdGhDcmVkZW50aWFscyA/PyB0aGlzLndpdGhDcmVkZW50aWFscztcbiAgICBjb25zdCByZXBvcnRQcm9ncmVzcyA9IHVwZGF0ZS5yZXBvcnRQcm9ncmVzcyA/PyB0aGlzLnJlcG9ydFByb2dyZXNzO1xuICAgIGNvbnN0IHJlcG9ydFVwbG9hZFByb2dyZXNzID0gdXBkYXRlLnJlcG9ydFVwbG9hZFByb2dyZXNzID8/IHRoaXMucmVwb3J0VXBsb2FkUHJvZ3Jlc3M7XG4gICAgY29uc3QgcmVwb3J0RG93bmxvYWRQcm9ncmVzcyA9IHVwZGF0ZS5yZXBvcnREb3dubG9hZFByb2dyZXNzID8/IHRoaXMucmVwb3J0RG93bmxvYWRQcm9ncmVzcztcbiAgICBsZXQgaGVhZGVycyA9IHVwZGF0ZS5oZWFkZXJzIHx8IHRoaXMuaGVhZGVycztcbiAgICBsZXQgcGFyYW1zID0gdXBkYXRlLnBhcmFtcyB8fCB0aGlzLnBhcmFtcztcbiAgICBjb25zdCBjb250ZXh0ID0gdXBkYXRlLmNvbnRleHQgPz8gdGhpcy5jb250ZXh0O1xuICAgIGlmICh1cGRhdGUuc2V0SGVhZGVycyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBoZWFkZXJzID0gT2JqZWN0LmtleXModXBkYXRlLnNldEhlYWRlcnMpLnJlZHVjZSgoaGVhZGVycywgbmFtZSkgPT4gaGVhZGVycy5zZXQobmFtZSwgdXBkYXRlLnNldEhlYWRlcnNbbmFtZV0pLCBoZWFkZXJzKTtcbiAgICB9XG4gICAgaWYgKHVwZGF0ZS5zZXRQYXJhbXMpIHtcbiAgICAgIHBhcmFtcyA9IE9iamVjdC5rZXlzKHVwZGF0ZS5zZXRQYXJhbXMpLnJlZHVjZSgocGFyYW1zLCBwYXJhbSkgPT4gcGFyYW1zLnNldChwYXJhbSwgdXBkYXRlLnNldFBhcmFtc1twYXJhbV0pLCBwYXJhbXMpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEh0dHBSZXF1ZXN0KG1ldGhvZCwgdXJsLCBib2R5LCB7XG4gICAgICBwYXJhbXMsXG4gICAgICBoZWFkZXJzLFxuICAgICAgY29udGV4dCxcbiAgICAgIHJlcG9ydFByb2dyZXNzLFxuICAgICAgcmVwb3J0VXBsb2FkUHJvZ3Jlc3MsXG4gICAgICByZXBvcnREb3dubG9hZFByb2dyZXNzLFxuICAgICAgcmVzcG9uc2VUeXBlLFxuICAgICAgd2l0aENyZWRlbnRpYWxzLFxuICAgICAgdHJhbnNmZXJDYWNoZSxcbiAgICAgIGtlZXBhbGl2ZSxcbiAgICAgIGNhY2hlLFxuICAgICAgcHJpb3JpdHksXG4gICAgICB0aW1lb3V0LFxuICAgICAgbW9kZSxcbiAgICAgIHJlZGlyZWN0LFxuICAgICAgY3JlZGVudGlhbHMsXG4gICAgICByZWZlcnJlcixcbiAgICAgIGludGVncml0eSxcbiAgICAgIHJlZmVycmVyUG9saWN5XG4gICAgfSk7XG4gIH1cbn1cbnZhciBIdHRwRXZlbnRUeXBlO1xuKGZ1bmN0aW9uIChIdHRwRXZlbnRUeXBlKSB7XG4gIEh0dHBFdmVudFR5cGVbSHR0cEV2ZW50VHlwZVtcIlNlbnRcIl0gPSAwXSA9IFwiU2VudFwiO1xuICBIdHRwRXZlbnRUeXBlW0h0dHBFdmVudFR5cGVbXCJVcGxvYWRQcm9ncmVzc1wiXSA9IDFdID0gXCJVcGxvYWRQcm9ncmVzc1wiO1xuICBIdHRwRXZlbnRUeXBlW0h0dHBFdmVudFR5cGVbXCJSZXNwb25zZUhlYWRlclwiXSA9IDJdID0gXCJSZXNwb25zZUhlYWRlclwiO1xuICBIdHRwRXZlbnRUeXBlW0h0dHBFdmVudFR5cGVbXCJEb3dubG9hZFByb2dyZXNzXCJdID0gM10gPSBcIkRvd25sb2FkUHJvZ3Jlc3NcIjtcbiAgSHR0cEV2ZW50VHlwZVtIdHRwRXZlbnRUeXBlW1wiUmVzcG9uc2VcIl0gPSA0XSA9IFwiUmVzcG9uc2VcIjtcbiAgSHR0cEV2ZW50VHlwZVtIdHRwRXZlbnRUeXBlW1wiVXNlclwiXSA9IDVdID0gXCJVc2VyXCI7XG59KShIdHRwRXZlbnRUeXBlIHx8IChIdHRwRXZlbnRUeXBlID0ge30pKTtcbmNsYXNzIEh0dHBSZXNwb25zZUJhc2Uge1xuICBoZWFkZXJzO1xuICBzdGF0dXM7XG4gIHN0YXR1c1RleHQ7XG4gIHVybDtcbiAgb2s7XG4gIHR5cGU7XG4gIHJlZGlyZWN0ZWQ7XG4gIHJlc3BvbnNlVHlwZTtcbiAgY29uc3RydWN0b3IoaW5pdCwgZGVmYXVsdFN0YXR1cyA9IDIwMCwgZGVmYXVsdFN0YXR1c1RleHQgPSAnT0snKSB7XG4gICAgdGhpcy5oZWFkZXJzID0gaW5pdC5oZWFkZXJzIHx8IG5ldyBIdHRwSGVhZGVycygpO1xuICAgIHRoaXMuc3RhdHVzID0gaW5pdC5zdGF0dXMgIT09IHVuZGVmaW5lZCA/IGluaXQuc3RhdHVzIDogZGVmYXVsdFN0YXR1cztcbiAgICB0aGlzLnN0YXR1c1RleHQgPSBpbml0LnN0YXR1c1RleHQgfHwgZGVmYXVsdFN0YXR1c1RleHQ7XG4gICAgdGhpcy51cmwgPSBpbml0LnVybCB8fCBudWxsO1xuICAgIHRoaXMucmVkaXJlY3RlZCA9IGluaXQucmVkaXJlY3RlZDtcbiAgICB0aGlzLnJlc3BvbnNlVHlwZSA9IGluaXQucmVzcG9uc2VUeXBlO1xuICAgIHRoaXMub2sgPSB0aGlzLnN0YXR1cyA+PSAyMDAgJiYgdGhpcy5zdGF0dXMgPCAzMDA7XG4gIH1cbn1cbmNsYXNzIEh0dHBIZWFkZXJSZXNwb25zZSBleHRlbmRzIEh0dHBSZXNwb25zZUJhc2Uge1xuICBjb25zdHJ1Y3Rvcihpbml0ID0ge30pIHtcbiAgICBzdXBlcihpbml0KTtcbiAgfVxuICB0eXBlID0gSHR0cEV2ZW50VHlwZS5SZXNwb25zZUhlYWRlcjtcbiAgY2xvbmUodXBkYXRlID0ge30pIHtcbiAgICByZXR1cm4gbmV3IEh0dHBIZWFkZXJSZXNwb25zZSh7XG4gICAgICBoZWFkZXJzOiB1cGRhdGUuaGVhZGVycyB8fCB0aGlzLmhlYWRlcnMsXG4gICAgICBzdGF0dXM6IHVwZGF0ZS5zdGF0dXMgIT09IHVuZGVmaW5lZCA/IHVwZGF0ZS5zdGF0dXMgOiB0aGlzLnN0YXR1cyxcbiAgICAgIHN0YXR1c1RleHQ6IHVwZGF0ZS5zdGF0dXNUZXh0IHx8IHRoaXMuc3RhdHVzVGV4dCxcbiAgICAgIHVybDogdXBkYXRlLnVybCB8fCB0aGlzLnVybCB8fCB1bmRlZmluZWRcbiAgICB9KTtcbiAgfVxufVxuY2xhc3MgSHR0cFJlc3BvbnNlIGV4dGVuZHMgSHR0cFJlc3BvbnNlQmFzZSB7XG4gIGJvZHk7XG4gIGNvbnN0cnVjdG9yKGluaXQgPSB7fSkge1xuICAgIHN1cGVyKGluaXQpO1xuICAgIHRoaXMuYm9keSA9IGluaXQuYm9keSAhPT0gdW5kZWZpbmVkID8gaW5pdC5ib2R5IDogbnVsbDtcbiAgfVxuICB0eXBlID0gSHR0cEV2ZW50VHlwZS5SZXNwb25zZTtcbiAgY2xvbmUodXBkYXRlID0ge30pIHtcbiAgICByZXR1cm4gbmV3IEh0dHBSZXNwb25zZSh7XG4gICAgICBib2R5OiB1cGRhdGUuYm9keSAhPT0gdW5kZWZpbmVkID8gdXBkYXRlLmJvZHkgOiB0aGlzLmJvZHksXG4gICAgICBoZWFkZXJzOiB1cGRhdGUuaGVhZGVycyB8fCB0aGlzLmhlYWRlcnMsXG4gICAgICBzdGF0dXM6IHVwZGF0ZS5zdGF0dXMgIT09IHVuZGVmaW5lZCA/IHVwZGF0ZS5zdGF0dXMgOiB0aGlzLnN0YXR1cyxcbiAgICAgIHN0YXR1c1RleHQ6IHVwZGF0ZS5zdGF0dXNUZXh0IHx8IHRoaXMuc3RhdHVzVGV4dCxcbiAgICAgIHVybDogdXBkYXRlLnVybCB8fCB0aGlzLnVybCB8fCB1bmRlZmluZWQsXG4gICAgICByZWRpcmVjdGVkOiB1cGRhdGUucmVkaXJlY3RlZCA/PyB0aGlzLnJlZGlyZWN0ZWQsXG4gICAgICByZXNwb25zZVR5cGU6IHVwZGF0ZS5yZXNwb25zZVR5cGUgPz8gdGhpcy5yZXNwb25zZVR5cGVcbiAgICB9KTtcbiAgfVxufVxuY2xhc3MgSHR0cEVycm9yUmVzcG9uc2UgZXh0ZW5kcyBIdHRwUmVzcG9uc2VCYXNlIHtcbiAgbmFtZSA9ICdIdHRwRXJyb3JSZXNwb25zZSc7XG4gIG1lc3NhZ2U7XG4gIGVycm9yO1xuICBvayA9IGZhbHNlO1xuICBjb25zdHJ1Y3Rvcihpbml0KSB7XG4gICAgc3VwZXIoaW5pdCwgMCwgJ1Vua25vd24gRXJyb3InKTtcbiAgICBpZiAodGhpcy5zdGF0dXMgPj0gMjAwICYmIHRoaXMuc3RhdHVzIDwgMzAwKSB7XG4gICAgICB0aGlzLm1lc3NhZ2UgPSBgSHR0cCBmYWlsdXJlIGR1cmluZyBwYXJzaW5nIGZvciAke2luaXQudXJsIHx8ICcodW5rbm93biB1cmwpJ31gO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm1lc3NhZ2UgPSBgSHR0cCBmYWlsdXJlIHJlc3BvbnNlIGZvciAke2luaXQudXJsIHx8ICcodW5rbm93biB1cmwpJ306ICR7aW5pdC5zdGF0dXN9ICR7aW5pdC5zdGF0dXNUZXh0fWA7XG4gICAgfVxuICAgIHRoaXMuZXJyb3IgPSBpbml0LmVycm9yIHx8IG51bGw7XG4gIH1cbn1cbmNvbnN0IEhUVFBfU1RBVFVTX0NPREVfT0sgPSAyMDA7XG5jb25zdCBIVFRQX1NUQVRVU19DT0RFX05PX0NPTlRFTlQgPSAyMDQ7XG52YXIgSHR0cFN0YXR1c0NvZGU7XG4oZnVuY3Rpb24gKEh0dHBTdGF0dXNDb2RlKSB7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiQ29udGludWVcIl0gPSAxMDBdID0gXCJDb250aW51ZVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlN3aXRjaGluZ1Byb3RvY29sc1wiXSA9IDEwMV0gPSBcIlN3aXRjaGluZ1Byb3RvY29sc1wiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlByb2Nlc3NpbmdcIl0gPSAxMDJdID0gXCJQcm9jZXNzaW5nXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiRWFybHlIaW50c1wiXSA9IDEwM10gPSBcIkVhcmx5SGludHNcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJPa1wiXSA9IDIwMF0gPSBcIk9rXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiQ3JlYXRlZFwiXSA9IDIwMV0gPSBcIkNyZWF0ZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJBY2NlcHRlZFwiXSA9IDIwMl0gPSBcIkFjY2VwdGVkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTm9uQXV0aG9yaXRhdGl2ZUluZm9ybWF0aW9uXCJdID0gMjAzXSA9IFwiTm9uQXV0aG9yaXRhdGl2ZUluZm9ybWF0aW9uXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTm9Db250ZW50XCJdID0gMjA0XSA9IFwiTm9Db250ZW50XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiUmVzZXRDb250ZW50XCJdID0gMjA1XSA9IFwiUmVzZXRDb250ZW50XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiUGFydGlhbENvbnRlbnRcIl0gPSAyMDZdID0gXCJQYXJ0aWFsQ29udGVudFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIk11bHRpU3RhdHVzXCJdID0gMjA3XSA9IFwiTXVsdGlTdGF0dXNcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJBbHJlYWR5UmVwb3J0ZWRcIl0gPSAyMDhdID0gXCJBbHJlYWR5UmVwb3J0ZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJJbVVzZWRcIl0gPSAyMjZdID0gXCJJbVVzZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJNdWx0aXBsZUNob2ljZXNcIl0gPSAzMDBdID0gXCJNdWx0aXBsZUNob2ljZXNcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJNb3ZlZFBlcm1hbmVudGx5XCJdID0gMzAxXSA9IFwiTW92ZWRQZXJtYW5lbnRseVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIkZvdW5kXCJdID0gMzAyXSA9IFwiRm91bmRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJTZWVPdGhlclwiXSA9IDMwM10gPSBcIlNlZU90aGVyXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTm90TW9kaWZpZWRcIl0gPSAzMDRdID0gXCJOb3RNb2RpZmllZFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlVzZVByb3h5XCJdID0gMzA1XSA9IFwiVXNlUHJveHlcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJVbnVzZWRcIl0gPSAzMDZdID0gXCJVbnVzZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJUZW1wb3JhcnlSZWRpcmVjdFwiXSA9IDMwN10gPSBcIlRlbXBvcmFyeVJlZGlyZWN0XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiUGVybWFuZW50UmVkaXJlY3RcIl0gPSAzMDhdID0gXCJQZXJtYW5lbnRSZWRpcmVjdFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIkJhZFJlcXVlc3RcIl0gPSA0MDBdID0gXCJCYWRSZXF1ZXN0XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiVW5hdXRob3JpemVkXCJdID0gNDAxXSA9IFwiVW5hdXRob3JpemVkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiUGF5bWVudFJlcXVpcmVkXCJdID0gNDAyXSA9IFwiUGF5bWVudFJlcXVpcmVkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiRm9yYmlkZGVuXCJdID0gNDAzXSA9IFwiRm9yYmlkZGVuXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTm90Rm91bmRcIl0gPSA0MDRdID0gXCJOb3RGb3VuZFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIk1ldGhvZE5vdEFsbG93ZWRcIl0gPSA0MDVdID0gXCJNZXRob2ROb3RBbGxvd2VkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTm90QWNjZXB0YWJsZVwiXSA9IDQwNl0gPSBcIk5vdEFjY2VwdGFibGVcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJQcm94eUF1dGhlbnRpY2F0aW9uUmVxdWlyZWRcIl0gPSA0MDddID0gXCJQcm94eUF1dGhlbnRpY2F0aW9uUmVxdWlyZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJSZXF1ZXN0VGltZW91dFwiXSA9IDQwOF0gPSBcIlJlcXVlc3RUaW1lb3V0XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiQ29uZmxpY3RcIl0gPSA0MDldID0gXCJDb25mbGljdFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIkdvbmVcIl0gPSA0MTBdID0gXCJHb25lXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTGVuZ3RoUmVxdWlyZWRcIl0gPSA0MTFdID0gXCJMZW5ndGhSZXF1aXJlZFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlByZWNvbmRpdGlvbkZhaWxlZFwiXSA9IDQxMl0gPSBcIlByZWNvbmRpdGlvbkZhaWxlZFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlBheWxvYWRUb29MYXJnZVwiXSA9IDQxM10gPSBcIlBheWxvYWRUb29MYXJnZVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlVyaVRvb0xvbmdcIl0gPSA0MTRdID0gXCJVcmlUb29Mb25nXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiVW5zdXBwb3J0ZWRNZWRpYVR5cGVcIl0gPSA0MTVdID0gXCJVbnN1cHBvcnRlZE1lZGlhVHlwZVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlJhbmdlTm90U2F0aXNmaWFibGVcIl0gPSA0MTZdID0gXCJSYW5nZU5vdFNhdGlzZmlhYmxlXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiRXhwZWN0YXRpb25GYWlsZWRcIl0gPSA0MTddID0gXCJFeHBlY3RhdGlvbkZhaWxlZFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIkltQVRlYXBvdFwiXSA9IDQxOF0gPSBcIkltQVRlYXBvdFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIk1pc2RpcmVjdGVkUmVxdWVzdFwiXSA9IDQyMV0gPSBcIk1pc2RpcmVjdGVkUmVxdWVzdFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlVucHJvY2Vzc2FibGVFbnRpdHlcIl0gPSA0MjJdID0gXCJVbnByb2Nlc3NhYmxlRW50aXR5XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTG9ja2VkXCJdID0gNDIzXSA9IFwiTG9ja2VkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiRmFpbGVkRGVwZW5kZW5jeVwiXSA9IDQyNF0gPSBcIkZhaWxlZERlcGVuZGVuY3lcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJUb29FYXJseVwiXSA9IDQyNV0gPSBcIlRvb0Vhcmx5XCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiVXBncmFkZVJlcXVpcmVkXCJdID0gNDI2XSA9IFwiVXBncmFkZVJlcXVpcmVkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiUHJlY29uZGl0aW9uUmVxdWlyZWRcIl0gPSA0MjhdID0gXCJQcmVjb25kaXRpb25SZXF1aXJlZFwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlRvb01hbnlSZXF1ZXN0c1wiXSA9IDQyOV0gPSBcIlRvb01hbnlSZXF1ZXN0c1wiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlJlcXVlc3RIZWFkZXJGaWVsZHNUb29MYXJnZVwiXSA9IDQzMV0gPSBcIlJlcXVlc3RIZWFkZXJGaWVsZHNUb29MYXJnZVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlVuYXZhaWxhYmxlRm9yTGVnYWxSZWFzb25zXCJdID0gNDUxXSA9IFwiVW5hdmFpbGFibGVGb3JMZWdhbFJlYXNvbnNcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJJbnRlcm5hbFNlcnZlckVycm9yXCJdID0gNTAwXSA9IFwiSW50ZXJuYWxTZXJ2ZXJFcnJvclwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIk5vdEltcGxlbWVudGVkXCJdID0gNTAxXSA9IFwiTm90SW1wbGVtZW50ZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJCYWRHYXRld2F5XCJdID0gNTAyXSA9IFwiQmFkR2F0ZXdheVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIlNlcnZpY2VVbmF2YWlsYWJsZVwiXSA9IDUwM10gPSBcIlNlcnZpY2VVbmF2YWlsYWJsZVwiO1xuICBIdHRwU3RhdHVzQ29kZVtIdHRwU3RhdHVzQ29kZVtcIkdhdGV3YXlUaW1lb3V0XCJdID0gNTA0XSA9IFwiR2F0ZXdheVRpbWVvdXRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJIdHRwVmVyc2lvbk5vdFN1cHBvcnRlZFwiXSA9IDUwNV0gPSBcIkh0dHBWZXJzaW9uTm90U3VwcG9ydGVkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiVmFyaWFudEFsc29OZWdvdGlhdGVzXCJdID0gNTA2XSA9IFwiVmFyaWFudEFsc29OZWdvdGlhdGVzXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiSW5zdWZmaWNpZW50U3RvcmFnZVwiXSA9IDUwN10gPSBcIkluc3VmZmljaWVudFN0b3JhZ2VcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJMb29wRGV0ZWN0ZWRcIl0gPSA1MDhdID0gXCJMb29wRGV0ZWN0ZWRcIjtcbiAgSHR0cFN0YXR1c0NvZGVbSHR0cFN0YXR1c0NvZGVbXCJOb3RFeHRlbmRlZFwiXSA9IDUxMF0gPSBcIk5vdEV4dGVuZGVkXCI7XG4gIEh0dHBTdGF0dXNDb2RlW0h0dHBTdGF0dXNDb2RlW1wiTmV0d29ya0F1dGhlbnRpY2F0aW9uUmVxdWlyZWRcIl0gPSA1MTFdID0gXCJOZXR3b3JrQXV0aGVudGljYXRpb25SZXF1aXJlZFwiO1xufSkoSHR0cFN0YXR1c0NvZGUgfHwgKEh0dHBTdGF0dXNDb2RlID0ge30pKTtcbmNvbnN0IFhTU0lfUFJFRklYJDEgPSAvXlxcKVxcXVxcfScsP1xcbi87XG5jb25zdCBERUZBVUxUX1NTUl9NQVhfUkVTUE9OU0VfQk9EWV9TSVpFID0gMTAyNCAqIDEwMjQ7XG5jb25zdCBIVFRQX0ZFVENIX01BWF9SRVNQT05TRV9TSVpFID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdIVFRQX0ZFVENIX01BWF9SRVNQT05TRV9TSVpFJyA6ICcnLCB7XG4gIGZhY3Rvcnk6ICgpID0+IHR5cGVvZiBuZ1NlcnZlck1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nU2VydmVyTW9kZSA/IERFRkFVTFRfU1NSX01BWF9SRVNQT05TRV9CT0RZX1NJWkUgOiBudWxsXG59KTtcbmNsYXNzIEZldGNoQmFja2VuZCB7XG4gIGZldGNoSW1wbCA9IGluamVjdChGZXRjaEZhY3RvcnksIHtcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9KT8uZmV0Y2ggPz8gKCguLi5hcmdzKSA9PiBnbG9iYWxUaGlzLmZldGNoKC4uLmFyZ3MpKTtcbiAgbmdab25lID0gaW5qZWN0KE5nWm9uZSk7XG4gIGRlc3Ryb3lSZWYgPSBpbmplY3QoRGVzdHJveVJlZik7XG4gIG1heFJlc3BvbnNlU2l6ZSA9IGluamVjdChIVFRQX0ZFVENIX01BWF9SRVNQT05TRV9TSVpFKTtcbiAgaGFuZGxlKHJlcXVlc3QpIHtcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUob2JzZXJ2ZXIgPT4ge1xuICAgICAgY29uc3QgYWJvcnRlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICAgIGxldCBkb25lID0gZmFsc2U7XG4gICAgICBjb25zdCB3cmFwcGVkT2JzZXJ2ZXIgPSB7XG4gICAgICAgIG5leHQ6IHZhbCA9PiB7XG4gICAgICAgICAgaWYgKHZhbC50eXBlID09PSBIdHRwRXZlbnRUeXBlLlJlc3BvbnNlKSB7XG4gICAgICAgICAgICBkb25lID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgb2JzZXJ2ZXIubmV4dCh2YWwpO1xuICAgICAgICB9LFxuICAgICAgICBlcnJvcjogZXJyID0+IHtcbiAgICAgICAgICBkb25lID0gdHJ1ZTtcbiAgICAgICAgICBvYnNlcnZlci5lcnJvcihlcnIpO1xuICAgICAgICB9LFxuICAgICAgICBjb21wbGV0ZTogKCkgPT4ge1xuICAgICAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgICAgIG9ic2VydmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICB0aGlzLmRvUmVxdWVzdChyZXF1ZXN0LCBhYm9ydGVyLnNpZ25hbCwgd3JhcHBlZE9ic2VydmVyKS50aGVuKG5vb3AsIGVycm9yID0+IHdyYXBwZWRPYnNlcnZlci5lcnJvcihuZXcgSHR0cEVycm9yUmVzcG9uc2Uoe1xuICAgICAgICBlcnJvclxuICAgICAgfSkpKTtcbiAgICAgIGxldCB0aW1lb3V0SWQ7XG4gICAgICBpZiAocmVxdWVzdC50aW1lb3V0KSB7XG4gICAgICAgIHRpbWVvdXRJZCA9IHRoaXMubmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGlmICghYWJvcnRlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgICAgYWJvcnRlci5hYm9ydChuZXcgRE9NRXhjZXB0aW9uKCdzaWduYWwgdGltZWQgb3V0JywgJ1RpbWVvdXRFcnJvcicpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIHJlcXVlc3QudGltZW91dCkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgaWYgKHRpbWVvdXRJZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFkb25lICYmICFhYm9ydGVyLnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgICAgYWJvcnRlci5hYm9ydCgpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0pO1xuICB9XG4gIGFzeW5jIGRvUmVxdWVzdChyZXF1ZXN0LCBzaWduYWwsIG9ic2VydmVyKSB7XG4gICAgY29uc3QgaW5pdCA9IHRoaXMuY3JlYXRlUmVxdWVzdEluaXQocmVxdWVzdCk7XG4gICAgbGV0IHJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBmZXRjaFByb21pc2UgPSB0aGlzLm5nWm9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB0aGlzLmZldGNoSW1wbChyZXF1ZXN0LnVybFdpdGhQYXJhbXMsIHtcbiAgICAgICAgc2lnbmFsLFxuICAgICAgICAuLi5pbml0XG4gICAgICB9KSk7XG4gICAgICBzaWxlbmNlU3VwZXJmbHVvdXNVbmhhbmRsZWRQcm9taXNlUmVqZWN0aW9uKGZldGNoUHJvbWlzZSk7XG4gICAgICBvYnNlcnZlci5uZXh0KHtcbiAgICAgICAgdHlwZTogSHR0cEV2ZW50VHlwZS5TZW50XG4gICAgICB9KTtcbiAgICAgIHJlc3BvbnNlID0gYXdhaXQgZmV0Y2hQcm9taXNlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBvYnNlcnZlci5lcnJvcihuZXcgSHR0cEVycm9yUmVzcG9uc2Uoe1xuICAgICAgICBlcnJvcixcbiAgICAgICAgc3RhdHVzOiBlcnJvci5zdGF0dXMgPz8gMCxcbiAgICAgICAgc3RhdHVzVGV4dDogZXJyb3Iuc3RhdHVzVGV4dCxcbiAgICAgICAgdXJsOiByZXF1ZXN0LnVybFdpdGhQYXJhbXMsXG4gICAgICAgIGhlYWRlcnM6IGVycm9yLmhlYWRlcnNcbiAgICAgIH0pKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyhyZXNwb25zZS5oZWFkZXJzKTtcbiAgICBjb25zdCBzdGF0dXNUZXh0ID0gcmVzcG9uc2Uuc3RhdHVzVGV4dDtcbiAgICBjb25zdCB1cmwgPSByZXNwb25zZS51cmwgfHwgcmVxdWVzdC51cmxXaXRoUGFyYW1zO1xuICAgIGxldCBzdGF0dXMgPSByZXNwb25zZS5zdGF0dXM7XG4gICAgbGV0IGJvZHkgPSBudWxsO1xuICAgIGNvbnN0IHJlcG9ydERvd25sb2FkUHJvZ3Jlc3MgPSByZXF1ZXN0LnJlcG9ydFByb2dyZXNzIHx8IHJlcXVlc3QucmVwb3J0RG93bmxvYWRQcm9ncmVzcztcbiAgICBpZiAocmVwb3J0RG93bmxvYWRQcm9ncmVzcykge1xuICAgICAgb2JzZXJ2ZXIubmV4dChuZXcgSHR0cEhlYWRlclJlc3BvbnNlKHtcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBzdGF0dXNUZXh0LFxuICAgICAgICB1cmxcbiAgICAgIH0pKTtcbiAgICB9XG4gICAgaWYgKHJlc3BvbnNlLmJvZHkpIHtcbiAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoQ09OVEVOVF9UWVBFX0hFQURFUikgPz8gJyc7XG4gICAgICBjb25zdCBjb250ZW50TGVuZ3RoID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtbGVuZ3RoJyk7XG4gICAgICBjb25zdCBjb250ZW50TGVuZ3RoVmFsdWUgPSBjb250ZW50TGVuZ3RoICE9PSBudWxsID8gTnVtYmVyKGNvbnRlbnRMZW5ndGgpIDogTmFOO1xuICAgICAgaWYgKHRoaXMubWF4UmVzcG9uc2VTaXplICE9PSBudWxsICYmIE51bWJlci5pc0Zpbml0ZShjb250ZW50TGVuZ3RoVmFsdWUpICYmIGNvbnRlbnRMZW5ndGhWYWx1ZSA+IHRoaXMubWF4UmVzcG9uc2VTaXplKSB7XG4gICAgICAgIHRocm93Qm9keVRvb0xhcmdlRXJyb3IodGhpcy5tYXhSZXNwb25zZVNpemUpO1xuICAgICAgfVxuICAgICAgY29uc3QgY2h1bmtzID0gW107XG4gICAgICBjb25zdCByZWFkZXIgPSByZXNwb25zZS5ib2R5LmdldFJlYWRlcigpO1xuICAgICAgbGV0IHJlY2VpdmVkTGVuZ3RoID0gMDtcbiAgICAgIGxldCBkZWNvZGVyO1xuICAgICAgbGV0IHBhcnRpYWxUZXh0O1xuICAgICAgY29uc3QgcmVxWm9uZSA9IHR5cGVvZiBab25lICE9PSAndW5kZWZpbmVkJyAmJiBab25lLmN1cnJlbnQ7XG4gICAgICBsZXQgY2FuY2VsZWQgPSBmYWxzZTtcbiAgICAgIGF3YWl0IHRoaXMubmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKGFzeW5jICgpID0+IHtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICBpZiAodGhpcy5kZXN0cm95UmVmLmRlc3Ryb3llZCkge1xuICAgICAgICAgICAgYXdhaXQgcmVhZGVyLmNhbmNlbCgpO1xuICAgICAgICAgICAgY2FuY2VsZWQgPSB0cnVlO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGRvbmUsXG4gICAgICAgICAgICB2YWx1ZVxuICAgICAgICAgIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuICAgICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgICAgY2h1bmtzLnB1c2godmFsdWUpO1xuICAgICAgICAgIHJlY2VpdmVkTGVuZ3RoICs9IHZhbHVlLmxlbmd0aDtcbiAgICAgICAgICBpZiAodGhpcy5tYXhSZXNwb25zZVNpemUgIT09IG51bGwgJiYgcmVjZWl2ZWRMZW5ndGggPiB0aGlzLm1heFJlc3BvbnNlU2l6ZSkge1xuICAgICAgICAgICAgYXdhaXQgcmVhZGVyLmNhbmNlbCgpO1xuICAgICAgICAgICAgdGhyb3dCb2R5VG9vTGFyZ2VFcnJvcih0aGlzLm1heFJlc3BvbnNlU2l6ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChyZXBvcnREb3dubG9hZFByb2dyZXNzKSB7XG4gICAgICAgICAgICBwYXJ0aWFsVGV4dCA9IHJlcXVlc3QucmVzcG9uc2VUeXBlID09PSAndGV4dCcgPyAocGFydGlhbFRleHQgPz8gJycpICsgKGRlY29kZXIgPz89IGdldFRleHREZWNvZGVyKGNvbnRlbnRUeXBlKSkuZGVjb2RlKHZhbHVlLCB7XG4gICAgICAgICAgICAgIHN0cmVhbTogdHJ1ZVxuICAgICAgICAgICAgfSkgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICBjb25zdCByZXBvcnRQcm9ncmVzcyA9ICgpID0+IG9ic2VydmVyLm5leHQoe1xuICAgICAgICAgICAgICB0eXBlOiBIdHRwRXZlbnRUeXBlLkRvd25sb2FkUHJvZ3Jlc3MsXG4gICAgICAgICAgICAgIHRvdGFsOiBOdW1iZXIuaXNGaW5pdGUoY29udGVudExlbmd0aFZhbHVlKSA/IGNvbnRlbnRMZW5ndGhWYWx1ZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgbG9hZGVkOiByZWNlaXZlZExlbmd0aCxcbiAgICAgICAgICAgICAgcGFydGlhbFRleHRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmVxWm9uZSA/IHJlcVpvbmUucnVuKHJlcG9ydFByb2dyZXNzKSA6IHJlcG9ydFByb2dyZXNzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGlmIChjYW5jZWxlZCkge1xuICAgICAgICBvYnNlcnZlci5jb21wbGV0ZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBjaHVua3NBbGwgPSB0aGlzLmNvbmNhdENodW5rcyhjaHVua3MsIHJlY2VpdmVkTGVuZ3RoKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGJvZHkgPSB0aGlzLnBhcnNlQm9keShyZXF1ZXN0LCBjaHVua3NBbGwsIGNvbnRlbnRUeXBlLCBzdGF0dXMpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgb2JzZXJ2ZXIuZXJyb3IobmV3IEh0dHBFcnJvclJlc3BvbnNlKHtcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgICBoZWFkZXJzOiBuZXcgSHR0cEhlYWRlcnMocmVzcG9uc2UuaGVhZGVycyksXG4gICAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgICAgICAgc3RhdHVzVGV4dDogcmVzcG9uc2Uuc3RhdHVzVGV4dCxcbiAgICAgICAgICB1cmw6IHJlc3BvbnNlLnVybCB8fCByZXF1ZXN0LnVybFdpdGhQYXJhbXNcbiAgICAgICAgfSkpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzdGF0dXMgPT09IDApIHtcbiAgICAgIHN0YXR1cyA9IGJvZHkgPyBIVFRQX1NUQVRVU19DT0RFX09LIDogMDtcbiAgICB9XG4gICAgY29uc3Qgb2sgPSBzdGF0dXMgPj0gMjAwICYmIHN0YXR1cyA8IDMwMDtcbiAgICBjb25zdCByZWRpcmVjdGVkID0gcmVzcG9uc2UucmVkaXJlY3RlZDtcbiAgICBjb25zdCByZXNwb25zZVR5cGUgPSByZXNwb25zZS50eXBlO1xuICAgIGlmIChvaykge1xuICAgICAgb2JzZXJ2ZXIubmV4dChuZXcgSHR0cFJlc3BvbnNlKHtcbiAgICAgICAgYm9keSxcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBzdGF0dXNUZXh0LFxuICAgICAgICB1cmwsXG4gICAgICAgIHJlZGlyZWN0ZWQsXG4gICAgICAgIHJlc3BvbnNlVHlwZVxuICAgICAgfSkpO1xuICAgICAgb2JzZXJ2ZXIuY29tcGxldGUoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb2JzZXJ2ZXIuZXJyb3IobmV3IEh0dHBFcnJvclJlc3BvbnNlKHtcbiAgICAgICAgZXJyb3I6IGJvZHksXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIHN0YXR1cyxcbiAgICAgICAgc3RhdHVzVGV4dCxcbiAgICAgICAgdXJsLFxuICAgICAgICByZWRpcmVjdGVkLFxuICAgICAgICByZXNwb25zZVR5cGVcbiAgICAgIH0pKTtcbiAgICB9XG4gIH1cbiAgcGFyc2VCb2R5KHJlcXVlc3QsIGJpbkNvbnRlbnQsIGNvbnRlbnRUeXBlLCBzdGF0dXMpIHtcbiAgICBzd2l0Y2ggKHJlcXVlc3QucmVzcG9uc2VUeXBlKSB7XG4gICAgICBjYXNlICdqc29uJzpcbiAgICAgICAgY29uc3QgdGV4dCA9IG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShiaW5Db250ZW50KS5yZXBsYWNlKFhTU0lfUFJFRklYJDEsICcnKTtcbiAgICAgICAgaWYgKHRleHQgPT09ICcnKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGlmIChzdGF0dXMgPCAyMDAgfHwgc3RhdHVzID49IDMwMCkge1xuICAgICAgICAgICAgcmV0dXJuIHRleHQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH1cbiAgICAgIGNhc2UgJ3RleHQnOlxuICAgICAgICByZXR1cm4gZ2V0VGV4dERlY29kZXIoY29udGVudFR5cGUpLmRlY29kZShiaW5Db250ZW50KTtcbiAgICAgIGNhc2UgJ2Jsb2InOlxuICAgICAgICByZXR1cm4gbmV3IEJsb2IoW2JpbkNvbnRlbnRdLCB7XG4gICAgICAgICAgdHlwZTogY29udGVudFR5cGVcbiAgICAgICAgfSk7XG4gICAgICBjYXNlICdhcnJheWJ1ZmZlcic6XG4gICAgICAgIHJldHVybiBiaW5Db250ZW50LmJ1ZmZlcjtcbiAgICB9XG4gIH1cbiAgY3JlYXRlUmVxdWVzdEluaXQocmVxKSB7XG4gICAgaWYgKHJlcS5yZXBvcnRVcGxvYWRQcm9ncmVzcykge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjgyNCwgbmdEZXZNb2RlICYmICdUaGUgRmV0Y2hCYWNrZW5kIGRvZXMgbm90IHN1cHBvcnQgdXBsb2FkIHByb2dyZXNzIHJlcG9ydGluZy4gUGxlYXNlIHVzZSBgd2l0aFhocigpYCBvbiB5b3VyIGBwcm92aWRlSHR0cENsaWVudCgpYCBjb25maWd1cmF0aW9uIGlmIHlvdSB3YW50IHRvIHJlcG9ydCB1cGxvYWQgcHJvZ3Jlc3MuJyk7XG4gICAgfVxuICAgIGNvbnN0IGhlYWRlcnMgPSB7fTtcbiAgICBsZXQgY3JlZGVudGlhbHM7XG4gICAgY3JlZGVudGlhbHMgPSByZXEuY3JlZGVudGlhbHM7XG4gICAgaWYgKHJlcS53aXRoQ3JlZGVudGlhbHMpIHtcbiAgICAgICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIHdhcm5pbmdPcHRpb25zTWVzc2FnZShyZXEpO1xuICAgICAgY3JlZGVudGlhbHMgPSAnaW5jbHVkZSc7XG4gICAgfVxuICAgIHJlcS5oZWFkZXJzLmZvckVhY2goKG5hbWUsIHZhbHVlcykgPT4gaGVhZGVyc1tuYW1lXSA9IHZhbHVlcy5qb2luKCcsJykpO1xuICAgIGlmICghcmVxLmhlYWRlcnMuaGFzKEFDQ0VQVF9IRUFERVIpKSB7XG4gICAgICBoZWFkZXJzW0FDQ0VQVF9IRUFERVJdID0gQUNDRVBUX0hFQURFUl9WQUxVRTtcbiAgICB9XG4gICAgaWYgKCFyZXEuaGVhZGVycy5oYXMoQ09OVEVOVF9UWVBFX0hFQURFUikpIHtcbiAgICAgIGNvbnN0IGRldGVjdGVkVHlwZSA9IHJlcS5kZXRlY3RDb250ZW50VHlwZUhlYWRlcigpO1xuICAgICAgaWYgKGRldGVjdGVkVHlwZSAhPT0gbnVsbCkge1xuICAgICAgICBoZWFkZXJzW0NPTlRFTlRfVFlQRV9IRUFERVJdID0gZGV0ZWN0ZWRUeXBlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgYm9keTogcmVxLnNlcmlhbGl6ZUJvZHkoKSxcbiAgICAgIG1ldGhvZDogcmVxLm1ldGhvZCxcbiAgICAgIGhlYWRlcnMsXG4gICAgICBjcmVkZW50aWFscyxcbiAgICAgIGtlZXBhbGl2ZTogcmVxLmtlZXBhbGl2ZSxcbiAgICAgIGNhY2hlOiByZXEuY2FjaGUsXG4gICAgICBwcmlvcml0eTogcmVxLnByaW9yaXR5LFxuICAgICAgbW9kZTogcmVxLm1vZGUsXG4gICAgICByZWRpcmVjdDogcmVxLnJlZGlyZWN0LFxuICAgICAgcmVmZXJyZXI6IHJlcS5yZWZlcnJlcixcbiAgICAgIGludGVncml0eTogcmVxLmludGVncml0eSxcbiAgICAgIHJlZmVycmVyUG9saWN5OiByZXEucmVmZXJyZXJQb2xpY3lcbiAgICB9O1xuICB9XG4gIGNvbmNhdENodW5rcyhjaHVua3MsIHRvdGFsTGVuZ3RoKSB7XG4gICAgY29uc3QgY2h1bmtzQWxsID0gbmV3IFVpbnQ4QXJyYXkodG90YWxMZW5ndGgpO1xuICAgIGxldCBwb3NpdGlvbiA9IDA7XG4gICAgZm9yIChjb25zdCBjaHVuayBvZiBjaHVua3MpIHtcbiAgICAgIGNodW5rc0FsbC5zZXQoY2h1bmssIHBvc2l0aW9uKTtcbiAgICAgIHBvc2l0aW9uICs9IGNodW5rLmxlbmd0aDtcbiAgICB9XG4gICAgcmV0dXJuIGNodW5rc0FsbDtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBGZXRjaEJhY2tlbmRfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEZldGNoQmFja2VuZCkoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogRmV0Y2hCYWNrZW5kLFxuICAgIGZhY3Rvcnk6IEZldGNoQmFja2VuZC7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEZldGNoQmFja2VuZCwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBGZXRjaEZhY3Rvcnkge31cbmZ1bmN0aW9uIG5vb3AoKSB7fVxuZnVuY3Rpb24gd2FybmluZ09wdGlvbnNNZXNzYWdlKHJlcSkge1xuICBpZiAocmVxLmNyZWRlbnRpYWxzICYmIHJlcS53aXRoQ3JlZGVudGlhbHMpIHtcbiAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyODE5LCBgQW5ndWxhciBkZXRlY3RlZCB0aGF0IGEgXFxgSHR0cENsaWVudFxcYCByZXF1ZXN0IGhhcyBib3RoIFxcYHdpdGhDcmVkZW50aWFsczogdHJ1ZVxcYCBhbmQgXFxgY3JlZGVudGlhbHM6ICcke3JlcS5jcmVkZW50aWFsc30nXFxgIG9wdGlvbnMuIFRoZSBcXGB3aXRoQ3JlZGVudGlhbHNcXGAgb3B0aW9uIGlzIG92ZXJyaWRpbmcgdGhlIGV4cGxpY2l0IFxcYGNyZWRlbnRpYWxzXFxgIHNldHRpbmcgdG8gJ2luY2x1ZGUnLiBDb25zaWRlciByZW1vdmluZyBcXGB3aXRoQ3JlZGVudGlhbHNcXGAgYW5kIHVzaW5nIFxcYGNyZWRlbnRpYWxzOiAnJHtyZXEuY3JlZGVudGlhbHN9J1xcYCBkaXJlY3RseSBmb3IgY2xhcml0eS5gKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIHNpbGVuY2VTdXBlcmZsdW91c1VuaGFuZGxlZFByb21pc2VSZWplY3Rpb24ocHJvbWlzZSkge1xuICBwcm9taXNlLnRoZW4obm9vcCwgbm9vcCk7XG59XG5mdW5jdGlvbiB0aHJvd0JvZHlUb29MYXJnZUVycm9yKG1heFJlc3BvbnNlU2l6ZSkge1xuICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigtMjgyNSwgbmdEZXZNb2RlICYmIGBGZXRjaCByZXNwb25zZSBib2R5IGV4Y2VlZGVkIHRoZSBjb25maWd1cmVkIGJ1ZmZlciBsaW1pdCAoJHttYXhSZXNwb25zZVNpemV9IGJ5dGVzKS5gKTtcbn1cbmNvbnN0IENIQVJTRVRfUkVHRVggPSAvY2hhcnNldD1cXHMqW1wiJ10/KFteO1wiJ1xcc10rKVtcIiddPy9pO1xuZnVuY3Rpb24gZ2V0VGV4dERlY29kZXIoY29udGVudFR5cGUpIHtcbiAgY29uc3QgbWF0Y2ggPSBjb250ZW50VHlwZS5tYXRjaChDSEFSU0VUX1JFR0VYKTtcbiAgaWYgKG1hdGNoICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIobWF0Y2hbMV0pO1xuICAgIH0gY2F0Y2gge31cbiAgfVxuICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCk7XG59XG5jb25zdCBYU1JGX0VOQUJMRUQgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ1hTUkZfRU5BQkxFRCcgOiAnJywge1xuICBmYWN0b3J5OiAoKSA9PiB0cnVlXG59KTtcbmNvbnN0IFhTUkZfREVGQVVMVF9DT09LSUVfTkFNRSA9ICdYU1JGLVRPS0VOJztcbmNvbnN0IFhTUkZfQ09PS0lFX05BTUUgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ1hTUkZfQ09PS0lFX05BTUUnIDogJycsIHtcbiAgZmFjdG9yeTogKCkgPT4gWFNSRl9ERUZBVUxUX0NPT0tJRV9OQU1FXG59KTtcbmNvbnN0IFhTUkZfREVGQVVMVF9IRUFERVJfTkFNRSA9ICdYLVhTUkYtVE9LRU4nO1xuY29uc3QgWFNSRl9IRUFERVJfTkFNRSA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnWFNSRl9IRUFERVJfTkFNRScgOiAnJywge1xuICBmYWN0b3J5OiAoKSA9PiBYU1JGX0RFRkFVTFRfSEVBREVSX05BTUVcbn0pO1xuY2xhc3MgSHR0cFhzcmZDb29raWVFeHRyYWN0b3Ige1xuICBjb29raWVOYW1lID0gaW5qZWN0KFhTUkZfQ09PS0lFX05BTUUpO1xuICBkb2MgPSBpbmplY3QoRE9DVU1FTlQpO1xuICBsYXN0Q29va2llU3RyaW5nID0gJyc7XG4gIGxhc3RUb2tlbiA9IG51bGw7XG4gIHBhcnNlQ291bnQgPSAwO1xuICBnZXRUb2tlbigpIHtcbiAgICBpZiAodHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdTZXJ2ZXJNb2RlKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgY29va2llU3RyaW5nID0gdGhpcy5kb2MuY29va2llIHx8ICcnO1xuICAgIGlmIChjb29raWVTdHJpbmcgIT09IHRoaXMubGFzdENvb2tpZVN0cmluZykge1xuICAgICAgdGhpcy5wYXJzZUNvdW50Kys7XG4gICAgICB0aGlzLmxhc3RUb2tlbiA9IHBhcnNlQ29va2llVmFsdWUoY29va2llU3RyaW5nLCB0aGlzLmNvb2tpZU5hbWUpO1xuICAgICAgdGhpcy5sYXN0Q29va2llU3RyaW5nID0gY29va2llU3RyaW5nO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5sYXN0VG9rZW47XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSHR0cFhzcmZDb29raWVFeHRyYWN0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEh0dHBYc3JmQ29va2llRXh0cmFjdG9yKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBIdHRwWHNyZkNvb2tpZUV4dHJhY3RvcixcbiAgICBmYWN0b3J5OiBIdHRwWHNyZkNvb2tpZUV4dHJhY3Rvci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEh0dHBYc3JmQ29va2llRXh0cmFjdG9yLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIEh0dHBYc3JmVG9rZW5FeHRyYWN0b3Ige1xuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBIdHRwWHNyZlRva2VuRXh0cmFjdG9yX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBIdHRwWHNyZlRva2VuRXh0cmFjdG9yKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBIdHRwWHNyZlRva2VuRXh0cmFjdG9yLFxuICAgIGZhY3Rvcnk6IGZ1bmN0aW9uIEh0dHBYc3JmVG9rZW5FeHRyYWN0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgbGV0IF9fbmdDb25kaXRpb25hbEZhY3RvcnlfXyA9IG51bGw7XG4gICAgICBpZiAoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgICAgX19uZ0NvbmRpdGlvbmFsRmFjdG9yeV9fID0gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBIdHRwWHNyZlRva2VuRXh0cmFjdG9yKSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLyogQHRzLWlnbm9yZSAqL1xuICAgICAgICBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X18gPSBpMC7Jtcm1aW5qZWN0KEh0dHBYc3JmQ29va2llRXh0cmFjdG9yKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X187XG4gICAgfSxcbiAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShIdHRwWHNyZlRva2VuRXh0cmFjdG9yLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVkSW46ICdyb290JyxcbiAgICAgIHVzZUV4aXN0aW5nOiBIdHRwWHNyZkNvb2tpZUV4dHJhY3RvclxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiB4c3JmSW50ZXJjZXB0b3JGbihyZXEsIG5leHQpIHtcbiAgaWYgKCFpbmplY3QoWFNSRl9FTkFCTEVEKSB8fCByZXEubWV0aG9kID09PSAnR0VUJyB8fCByZXEubWV0aG9kID09PSAnSEVBRCcpIHtcbiAgICByZXR1cm4gbmV4dChyZXEpO1xuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgbG9jYXRpb25IcmVmID0gaW5qZWN0KFBsYXRmb3JtTG9jYXRpb24pLmhyZWY7XG4gICAgY29uc3Qge1xuICAgICAgb3JpZ2luOiBsb2NhdGlvbk9yaWdpblxuICAgIH0gPSBuZXcgVVJMKGxvY2F0aW9uSHJlZik7XG4gICAgY29uc3Qge1xuICAgICAgb3JpZ2luOiByZXF1ZXN0T3JpZ2luXG4gICAgfSA9IG5ldyBVUkwocmVxLnVybCwgbG9jYXRpb25PcmlnaW4pO1xuICAgIGlmIChsb2NhdGlvbk9yaWdpbiAhPT0gcmVxdWVzdE9yaWdpbikge1xuICAgICAgcmV0dXJuIG5leHQocmVxKTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBuZXh0KHJlcSk7XG4gIH1cbiAgY29uc3QgdG9rZW4gPSBpbmplY3QoSHR0cFhzcmZUb2tlbkV4dHJhY3RvcikuZ2V0VG9rZW4oKTtcbiAgY29uc3QgaGVhZGVyTmFtZSA9IGluamVjdChYU1JGX0hFQURFUl9OQU1FKTtcbiAgaWYgKHRva2VuICE9IG51bGwgJiYgIXJlcS5oZWFkZXJzLmhhcyhoZWFkZXJOYW1lKSkge1xuICAgIHJlcSA9IHJlcS5jbG9uZSh7XG4gICAgICBoZWFkZXJzOiByZXEuaGVhZGVycy5zZXQoaGVhZGVyTmFtZSwgdG9rZW4pXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIG5leHQocmVxKTtcbn1cbmNsYXNzIEh0dHBYc3JmSW50ZXJjZXB0b3Ige1xuICBpbmplY3RvciA9IGluamVjdChFbnZpcm9ubWVudEluamVjdG9yKTtcbiAgaW50ZXJjZXB0KGluaXRpYWxSZXF1ZXN0LCBuZXh0KSB7XG4gICAgcmV0dXJuIHJ1bkluSW5qZWN0aW9uQ29udGV4dCh0aGlzLmluamVjdG9yLCAoKSA9PiB4c3JmSW50ZXJjZXB0b3JGbihpbml0aWFsUmVxdWVzdCwgZG93bnN0cmVhbVJlcXVlc3QgPT4gbmV4dC5oYW5kbGUoZG93bnN0cmVhbVJlcXVlc3QpKSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSHR0cFhzcmZJbnRlcmNlcHRvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgSHR0cFhzcmZJbnRlcmNlcHRvcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogSHR0cFhzcmZJbnRlcmNlcHRvcixcbiAgICBmYWN0b3J5OiBIdHRwWHNyZkludGVyY2VwdG9yLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoSHR0cFhzcmZJbnRlcmNlcHRvciwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBpbnRlcmNlcHRvckNoYWluRW5kRm4ocmVxLCBmaW5hbEhhbmRsZXJGbikge1xuICByZXR1cm4gZmluYWxIYW5kbGVyRm4ocmVxKTtcbn1cbmZ1bmN0aW9uIGFkYXB0TGVnYWN5SW50ZXJjZXB0b3JUb0NoYWluKGNoYWluVGFpbEZuLCBpbnRlcmNlcHRvcikge1xuICByZXR1cm4gKGluaXRpYWxSZXF1ZXN0LCBmaW5hbEhhbmRsZXJGbikgPT4gaW50ZXJjZXB0b3IuaW50ZXJjZXB0KGluaXRpYWxSZXF1ZXN0LCB7XG4gICAgaGFuZGxlOiBkb3duc3RyZWFtUmVxdWVzdCA9PiBjaGFpblRhaWxGbihkb3duc3RyZWFtUmVxdWVzdCwgZmluYWxIYW5kbGVyRm4pXG4gIH0pO1xufVxuZnVuY3Rpb24gY2hhaW5lZEludGVyY2VwdG9yRm4oY2hhaW5UYWlsRm4sIGludGVyY2VwdG9yRm4sIGluamVjdG9yKSB7XG4gIHJldHVybiAoaW5pdGlhbFJlcXVlc3QsIGZpbmFsSGFuZGxlckZuKSA9PiBydW5JbkluamVjdGlvbkNvbnRleHQoaW5qZWN0b3IsICgpID0+IGludGVyY2VwdG9yRm4oaW5pdGlhbFJlcXVlc3QsIGRvd25zdHJlYW1SZXF1ZXN0ID0+IGNoYWluVGFpbEZuKGRvd25zdHJlYW1SZXF1ZXN0LCBmaW5hbEhhbmRsZXJGbikpKTtcbn1cbmNvbnN0IEhUVFBfSU5URVJDRVBUT1JTID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdIVFRQX0lOVEVSQ0VQVE9SUycgOiAnJyk7XG5jb25zdCBIVFRQX0lOVEVSQ0VQVE9SX0ZOUyA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnSFRUUF9JTlRFUkNFUFRPUl9GTlMnIDogJycsIHtcbiAgZmFjdG9yeTogKCkgPT4gW3hzcmZJbnRlcmNlcHRvckZuXVxufSk7XG5jb25zdCBIVFRQX1JPT1RfSU5URVJDRVBUT1JfRk5TID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdIVFRQX1JPT1RfSU5URVJDRVBUT1JfRk5TJyA6ICcnKTtcbmNvbnN0IFJFUVVFU1RTX0NPTlRSSUJVVEVfVE9fU1RBQklMSVRZID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdSRVFVRVNUU19DT05UUklCVVRFX1RPX1NUQUJJTElUWScgOiAnJywge1xuICBmYWN0b3J5OiAoKSA9PiB0cnVlXG59KTtcbmZ1bmN0aW9uIGxlZ2FjeUludGVyY2VwdG9yRm5GYWN0b3J5KCkge1xuICBsZXQgY2hhaW4gPSBudWxsO1xuICByZXR1cm4gKHJlcSwgaGFuZGxlcikgPT4ge1xuICAgIGlmIChjaGFpbiA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgaW50ZXJjZXB0b3JzID0gaW5qZWN0KEhUVFBfSU5URVJDRVBUT1JTLCB7XG4gICAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgICB9KSA/PyBbXTtcbiAgICAgIGNoYWluID0gaW50ZXJjZXB0b3JzLnJlZHVjZVJpZ2h0KGFkYXB0TGVnYWN5SW50ZXJjZXB0b3JUb0NoYWluLCBpbnRlcmNlcHRvckNoYWluRW5kRm4pO1xuICAgIH1cbiAgICBjb25zdCBwZW5kaW5nVGFza3MgPSBpbmplY3QoUGVuZGluZ1Rhc2tzKTtcbiAgICBjb25zdCBjb250cmlidXRlVG9TdGFiaWxpdHkgPSBpbmplY3QoUkVRVUVTVFNfQ09OVFJJQlVURV9UT19TVEFCSUxJVFkpO1xuICAgIGlmIChjb250cmlidXRlVG9TdGFiaWxpdHkpIHtcbiAgICAgIGNvbnN0IHJlbW92ZVRhc2sgPSBwZW5kaW5nVGFza3MuYWRkKCk7XG4gICAgICByZXR1cm4gY2hhaW4ocmVxLCBoYW5kbGVyKS5waXBlKGZpbmFsaXplKHJlbW92ZVRhc2spKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGNoYWluKHJlcSwgaGFuZGxlcik7XG4gICAgfVxuICB9O1xufVxuY2xhc3MgSHR0cEJhY2tlbmQge1xuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBIdHRwQmFja2VuZF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgSHR0cEJhY2tlbmQpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0YWJsZSh7XG4gICAgdG9rZW46IEh0dHBCYWNrZW5kLFxuICAgIGZhY3Rvcnk6IGZ1bmN0aW9uIEh0dHBCYWNrZW5kX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIGxldCBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X18gPSBudWxsO1xuICAgICAgaWYgKF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICAgIF9fbmdDb25kaXRpb25hbEZhY3RvcnlfXyA9IG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgSHR0cEJhY2tlbmQpKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvKiBAdHMtaWdub3JlICovXG4gICAgICAgIF9fbmdDb25kaXRpb25hbEZhY3RvcnlfXyA9IGkwLsm1ybVpbmplY3QoRmV0Y2hCYWNrZW5kKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X187XG4gICAgfSxcbiAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShIdHRwQmFja2VuZCwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlZEluOiAncm9vdCcsXG4gICAgICB1c2VFeGlzdGluZzogRmV0Y2hCYWNrZW5kXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmxldCBmZXRjaEJhY2tlbmRXYXJuaW5nRGlzcGxheWVkID0gZmFsc2U7XG5jbGFzcyBIdHRwSW50ZXJjZXB0b3JIYW5kbGVyIHtcbiAgYmFja2VuZDtcbiAgaW5qZWN0b3I7XG4gIGNoYWluID0gbnVsbDtcbiAgcGVuZGluZ1Rhc2tzID0gaW5qZWN0KFBlbmRpbmdUYXNrcyk7XG4gIGNvbnRyaWJ1dGVUb1N0YWJpbGl0eSA9IGluamVjdChSRVFVRVNUU19DT05UUklCVVRFX1RPX1NUQUJJTElUWSk7XG4gIGNvbnN0cnVjdG9yKGJhY2tlbmQsIGluamVjdG9yKSB7XG4gICAgdGhpcy5iYWNrZW5kID0gYmFja2VuZDtcbiAgICB0aGlzLmluamVjdG9yID0gaW5qZWN0b3I7XG4gICAgaWYgKCh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICFmZXRjaEJhY2tlbmRXYXJuaW5nRGlzcGxheWVkKSB7XG4gICAgICBjb25zdCBpc1Rlc3RpbmdCYWNrZW5kID0gdGhpcy5iYWNrZW5kLmlzVGVzdGluZ0JhY2tlbmQ7XG4gICAgICBpZiAodHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdTZXJ2ZXJNb2RlICYmICEodGhpcy5iYWNrZW5kIGluc3RhbmNlb2YgRmV0Y2hCYWNrZW5kKSAmJiAhaXNUZXN0aW5nQmFja2VuZCkge1xuICAgICAgICBmZXRjaEJhY2tlbmRXYXJuaW5nRGlzcGxheWVkID0gdHJ1ZTtcbiAgICAgICAgaW5qZWN0b3IuZ2V0KF9Db25zb2xlKS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjgwMSwgJ0FuZ3VsYXIgZGV0ZWN0ZWQgdGhhdCBgSHR0cENsaWVudGAgaXMgbm90IGNvbmZpZ3VyZWQgJyArIFwidG8gdXNlIGBmZXRjaGAgQVBJcy4gSXQncyBzdHJvbmdseSByZWNvbW1lbmRlZCB0byBcIiArICdlbmFibGUgYGZldGNoYCBmb3IgYXBwbGljYXRpb25zIHRoYXQgdXNlIFNlcnZlci1TaWRlIFJlbmRlcmluZyAnICsgJ2ZvciBiZXR0ZXIgcGVyZm9ybWFuY2UgYW5kIGNvbXBhdGliaWxpdHkuICcgKyAnVG8gZW5hYmxlIGBmZXRjaGAsIHJlbW92ZSB0aGUgYHdpdGhYaHIoKWAgZmVhdHVyZSBmcm9tIHRoZSBgcHJvdmlkZUh0dHBDbGllbnQoKWAgY2FsbCcpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaGFuZGxlKGluaXRpYWxSZXF1ZXN0KSB7XG4gICAgaWYgKHRoaXMuY2hhaW4gPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHBhcmVudEhhbmRsZXIgPSB0aGlzLmluamVjdG9yLmdldChIdHRwSGFuZGxlciwgbnVsbCwge1xuICAgICAgICBza2lwU2VsZjogdHJ1ZVxuICAgICAgfSk7XG4gICAgICBjb25zdCBpc0RlbGVnYXRpbmcgPSBwYXJlbnRIYW5kbGVyICE9PSBudWxsICYmIHRoaXMuYmFja2VuZCA9PT0gcGFyZW50SGFuZGxlcjtcbiAgICAgIGNvbnN0IHJvb3RJbnRlcmNlcHRvckZucyA9IHRoaXMuaW5qZWN0b3IuZ2V0KEhUVFBfUk9PVF9JTlRFUkNFUFRPUl9GTlMsIFtdLCBpc0RlbGVnYXRpbmcgPyB7XG4gICAgICAgIHNlbGY6IHRydWVcbiAgICAgIH0gOiB1bmRlZmluZWQpO1xuICAgICAgY29uc3QgZGVkdXBlZEludGVyY2VwdG9yRm5zID0gQXJyYXkuZnJvbShuZXcgU2V0KFsuLi50aGlzLmluamVjdG9yLmdldChIVFRQX0lOVEVSQ0VQVE9SX0ZOUyksIC4uLnJvb3RJbnRlcmNlcHRvckZuc10pKTtcbiAgICAgIHRoaXMuY2hhaW4gPSBkZWR1cGVkSW50ZXJjZXB0b3JGbnMucmVkdWNlUmlnaHQoKG5leHRTZXF1ZW5jZWRGbiwgaW50ZXJjZXB0b3JGbikgPT4gY2hhaW5lZEludGVyY2VwdG9yRm4obmV4dFNlcXVlbmNlZEZuLCBpbnRlcmNlcHRvckZuLCB0aGlzLmluamVjdG9yKSwgaW50ZXJjZXB0b3JDaGFpbkVuZEZuKTtcbiAgICB9XG4gICAgY29uc3QgY2hhaW4gPSB0aGlzLmNoYWluO1xuICAgIGlmICh0aGlzLmNvbnRyaWJ1dGVUb1N0YWJpbGl0eSkge1xuICAgICAgY29uc3QgcmVtb3ZlVGFzayA9IHRoaXMucGVuZGluZ1Rhc2tzLmFkZCgpO1xuICAgICAgcmV0dXJuIHVudHJhY2tlZCgoKSA9PiBjaGFpbihpbml0aWFsUmVxdWVzdCwgZG93bnN0cmVhbVJlcXVlc3QgPT4gdGhpcy5iYWNrZW5kLmhhbmRsZShkb3duc3RyZWFtUmVxdWVzdCkpKS5waXBlKGZpbmFsaXplKHJlbW92ZVRhc2spKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHVudHJhY2tlZCgoKSA9PiBjaGFpbihpbml0aWFsUmVxdWVzdCwgZG93bnN0cmVhbVJlcXVlc3QgPT4gdGhpcy5iYWNrZW5kLmhhbmRsZShkb3duc3RyZWFtUmVxdWVzdCkpKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSHR0cEludGVyY2VwdG9ySGFuZGxlcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEh0dHBJbnRlcmNlcHRvckhhbmRsZXIpKGkwLsm1ybVpbmplY3QoSHR0cEJhY2tlbmQpLCBpMC7Jtcm1aW5qZWN0KGkwLkVudmlyb25tZW50SW5qZWN0b3IpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogSHR0cEludGVyY2VwdG9ySGFuZGxlcixcbiAgICBmYWN0b3J5OiBIdHRwSW50ZXJjZXB0b3JIYW5kbGVyLsm1ZmFjLFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEh0dHBJbnRlcmNlcHRvckhhbmRsZXIsIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogSHR0cEJhY2tlbmRcbiAgfSwge1xuICAgIHR5cGU6IGkwLkVudmlyb25tZW50SW5qZWN0b3JcbiAgfV0sIG51bGwpO1xufSkoKTtcbmNsYXNzIEh0dHBIYW5kbGVyIHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSHR0cEhhbmRsZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEh0dHBIYW5kbGVyKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBIdHRwSGFuZGxlcixcbiAgICBmYWN0b3J5OiBmdW5jdGlvbiBIdHRwSGFuZGxlcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICBsZXQgX19uZ0NvbmRpdGlvbmFsRmFjdG9yeV9fID0gbnVsbDtcbiAgICAgIGlmIChfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgICBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X18gPSBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEh0dHBIYW5kbGVyKSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLyogQHRzLWlnbm9yZSAqL1xuICAgICAgICBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X18gPSBpMC7Jtcm1aW5qZWN0KEh0dHBJbnRlcmNlcHRvckhhbmRsZXIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIF9fbmdDb25kaXRpb25hbEZhY3RvcnlfXztcbiAgICB9LFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEh0dHBIYW5kbGVyLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVkSW46ICdyb290JyxcbiAgICAgIHVzZUV4aXN0aW5nOiBIdHRwSW50ZXJjZXB0b3JIYW5kbGVyXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGFkZEJvZHkob3B0aW9ucywgYm9keSkge1xuICByZXR1cm4ge1xuICAgIGJvZHksXG4gICAgLi4ub3B0aW9uc1xuICB9O1xufVxuY2xhc3MgSHR0cENsaWVudCB7XG4gIGhhbmRsZXI7XG4gIGNvbnN0cnVjdG9yKGhhbmRsZXIpIHtcbiAgICB0aGlzLmhhbmRsZXIgPSBoYW5kbGVyO1xuICB9XG4gIHJlcXVlc3QoZmlyc3QsIHVybCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgbGV0IHJlcTtcbiAgICBpZiAoZmlyc3QgaW5zdGFuY2VvZiBIdHRwUmVxdWVzdCkge1xuICAgICAgcmVxID0gZmlyc3Q7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCBoZWFkZXJzID0gdW5kZWZpbmVkO1xuICAgICAgaWYgKG9wdGlvbnMuaGVhZGVycyBpbnN0YW5jZW9mIEh0dHBIZWFkZXJzKSB7XG4gICAgICAgIGhlYWRlcnMgPSBvcHRpb25zLmhlYWRlcnM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKG9wdGlvbnMuaGVhZGVycyk7XG4gICAgICB9XG4gICAgICBsZXQgcGFyYW1zID0gdW5kZWZpbmVkO1xuICAgICAgaWYgKCEhb3B0aW9ucy5wYXJhbXMpIHtcbiAgICAgICAgaWYgKG9wdGlvbnMucGFyYW1zIGluc3RhbmNlb2YgSHR0cFBhcmFtcykge1xuICAgICAgICAgIHBhcmFtcyA9IG9wdGlvbnMucGFyYW1zO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHBhcmFtcyA9IG5ldyBIdHRwUGFyYW1zKHtcbiAgICAgICAgICAgIGZyb21PYmplY3Q6IG9wdGlvbnMucGFyYW1zXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlcSA9IG5ldyBIdHRwUmVxdWVzdChmaXJzdCwgdXJsLCBvcHRpb25zLmJvZHkgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMuYm9keSA6IG51bGwsIHtcbiAgICAgICAgaGVhZGVycyxcbiAgICAgICAgY29udGV4dDogb3B0aW9ucy5jb250ZXh0LFxuICAgICAgICBwYXJhbXMsXG4gICAgICAgIHJlcG9ydFByb2dyZXNzOiBvcHRpb25zLnJlcG9ydFByb2dyZXNzLFxuICAgICAgICByZXBvcnRVcGxvYWRQcm9ncmVzczogb3B0aW9ucy5yZXBvcnRVcGxvYWRQcm9ncmVzcyxcbiAgICAgICAgcmVwb3J0RG93bmxvYWRQcm9ncmVzczogb3B0aW9ucy5yZXBvcnREb3dubG9hZFByb2dyZXNzLFxuICAgICAgICByZXNwb25zZVR5cGU6IG9wdGlvbnMucmVzcG9uc2VUeXBlIHx8ICdqc29uJyxcbiAgICAgICAgd2l0aENyZWRlbnRpYWxzOiBvcHRpb25zLndpdGhDcmVkZW50aWFscyxcbiAgICAgICAgdHJhbnNmZXJDYWNoZTogb3B0aW9ucy50cmFuc2ZlckNhY2hlLFxuICAgICAgICBrZWVwYWxpdmU6IG9wdGlvbnMua2VlcGFsaXZlLFxuICAgICAgICBwcmlvcml0eTogb3B0aW9ucy5wcmlvcml0eSxcbiAgICAgICAgY2FjaGU6IG9wdGlvbnMuY2FjaGUsXG4gICAgICAgIG1vZGU6IG9wdGlvbnMubW9kZSxcbiAgICAgICAgcmVkaXJlY3Q6IG9wdGlvbnMucmVkaXJlY3QsXG4gICAgICAgIGNyZWRlbnRpYWxzOiBvcHRpb25zLmNyZWRlbnRpYWxzLFxuICAgICAgICByZWZlcnJlcjogb3B0aW9ucy5yZWZlcnJlcixcbiAgICAgICAgcmVmZXJyZXJQb2xpY3k6IG9wdGlvbnMucmVmZXJyZXJQb2xpY3ksXG4gICAgICAgIGludGVncml0eTogb3B0aW9ucy5pbnRlZ3JpdHksXG4gICAgICAgIHRpbWVvdXQ6IG9wdGlvbnMudGltZW91dFxuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IGV2ZW50cyQgPSBvZihyZXEpLnBpcGUoY29uY2F0TWFwKHJlcSA9PiB0aGlzLmhhbmRsZXIuaGFuZGxlKHJlcSkpKTtcbiAgICBpZiAoZmlyc3QgaW5zdGFuY2VvZiBIdHRwUmVxdWVzdCB8fCBvcHRpb25zLm9ic2VydmUgPT09ICdldmVudHMnKSB7XG4gICAgICByZXR1cm4gZXZlbnRzJDtcbiAgICB9XG4gICAgY29uc3QgcmVzJCA9IGV2ZW50cyQucGlwZShmaWx0ZXIoZXZlbnQgPT4gZXZlbnQgaW5zdGFuY2VvZiBIdHRwUmVzcG9uc2UpKTtcbiAgICBzd2l0Y2ggKG9wdGlvbnMub2JzZXJ2ZSB8fCAnYm9keScpIHtcbiAgICAgIGNhc2UgJ2JvZHknOlxuICAgICAgICBzd2l0Y2ggKHJlcS5yZXNwb25zZVR5cGUpIHtcbiAgICAgICAgICBjYXNlICdhcnJheWJ1ZmZlcic6XG4gICAgICAgICAgICByZXR1cm4gcmVzJC5waXBlKG1hcChyZXMgPT4ge1xuICAgICAgICAgICAgICBpZiAocmVzLmJvZHkgIT09IG51bGwgJiYgIShyZXMuYm9keSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI4MDYsIG5nRGV2TW9kZSAmJiAnUmVzcG9uc2UgaXMgbm90IGFuIEFycmF5QnVmZmVyLicpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiByZXMuYm9keTtcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICBjYXNlICdibG9iJzpcbiAgICAgICAgICAgIHJldHVybiByZXMkLnBpcGUobWFwKHJlcyA9PiB7XG4gICAgICAgICAgICAgIGlmIChyZXMuYm9keSAhPT0gbnVsbCAmJiAhKHJlcy5ib2R5IGluc3RhbmNlb2YgQmxvYikpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyODA3LCBuZ0Rldk1vZGUgJiYgJ1Jlc3BvbnNlIGlzIG5vdCBhIEJsb2IuJyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcmV0dXJuIHJlcy5ib2R5O1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgIGNhc2UgJ3RleHQnOlxuICAgICAgICAgICAgcmV0dXJuIHJlcyQucGlwZShtYXAocmVzID0+IHtcbiAgICAgICAgICAgICAgaWYgKHJlcy5ib2R5ICE9PSBudWxsICYmIHR5cGVvZiByZXMuYm9keSAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyODA4LCBuZ0Rldk1vZGUgJiYgJ1Jlc3BvbnNlIGlzIG5vdCBhIHN0cmluZy4nKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICByZXR1cm4gcmVzLmJvZHk7XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgY2FzZSAnanNvbic6XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJldHVybiByZXMkLnBpcGUobWFwKHJlcyA9PiByZXMuYm9keSkpO1xuICAgICAgICB9XG4gICAgICBjYXNlICdyZXNwb25zZSc6XG4gICAgICAgIHJldHVybiByZXMkO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjgwOSwgbmdEZXZNb2RlICYmIGBVbnJlYWNoYWJsZTogdW5oYW5kbGVkIG9ic2VydmUgdHlwZSAke29wdGlvbnMub2JzZXJ2ZX19YCk7XG4gICAgfVxuICB9XG4gIGRlbGV0ZSh1cmwsIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoJ0RFTEVURScsIHVybCwgb3B0aW9ucyk7XG4gIH1cbiAgZ2V0KHVybCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnR0VUJywgdXJsLCBvcHRpb25zKTtcbiAgfVxuICBoZWFkKHVybCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnSEVBRCcsIHVybCwgb3B0aW9ucyk7XG4gIH1cbiAganNvbnAodXJsLCBjYWxsYmFja1BhcmFtKSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnSlNPTlAnLCB1cmwsIHtcbiAgICAgIHBhcmFtczogbmV3IEh0dHBQYXJhbXMoKS5hcHBlbmQoY2FsbGJhY2tQYXJhbSwgJ0pTT05QX0NBTExCQUNLJyksXG4gICAgICBvYnNlcnZlOiAnYm9keScsXG4gICAgICByZXNwb25zZVR5cGU6ICdqc29uJ1xuICAgIH0pO1xuICB9XG4gIG9wdGlvbnModXJsLCBvcHRpb25zID0ge30pIHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KCdPUFRJT05TJywgdXJsLCBvcHRpb25zKTtcbiAgfVxuICBwYXRjaCh1cmwsIGJvZHksIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoJ1BBVENIJywgdXJsLCBhZGRCb2R5KG9wdGlvbnMsIGJvZHkpKTtcbiAgfVxuICBwb3N0KHVybCwgYm9keSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnUE9TVCcsIHVybCwgYWRkQm9keShvcHRpb25zLCBib2R5KSk7XG4gIH1cbiAgcHV0KHVybCwgYm9keSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCgnUFVUJywgdXJsLCBhZGRCb2R5KG9wdGlvbnMsIGJvZHkpKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBIdHRwQ2xpZW50X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgSHR0cENsaWVudCkoaTAuybXJtWluamVjdChIdHRwSGFuZGxlcikpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBIdHRwQ2xpZW50LFxuICAgIGZhY3Rvcnk6IEh0dHBDbGllbnQuybVmYWMsXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoSHR0cENsaWVudCwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBIdHRwSGFuZGxlclxuICB9XSwgbnVsbCk7XG59KSgpO1xubGV0IG5leHRSZXF1ZXN0SWQgPSAwO1xubGV0IGZvcmVpZ25Eb2N1bWVudDtcbmNvbnN0IEpTT05QX0VSUl9OT19DQUxMQkFDSyA9ICdKU09OUCBpbmplY3RlZCBzY3JpcHQgZGlkIG5vdCBpbnZva2UgY2FsbGJhY2suJztcbmNvbnN0IEpTT05QX0VSUl9XUk9OR19NRVRIT0QgPSAnSlNPTlAgcmVxdWVzdHMgbXVzdCB1c2UgSlNPTlAgcmVxdWVzdCBtZXRob2QuJztcbmNvbnN0IEpTT05QX0VSUl9XUk9OR19SRVNQT05TRV9UWVBFID0gJ0pTT05QIHJlcXVlc3RzIG11c3QgdXNlIEpzb24gcmVzcG9uc2UgdHlwZS4nO1xuY29uc3QgSlNPTlBfRVJSX0hFQURFUlNfTk9UX1NVUFBPUlRFRCA9ICdKU09OUCByZXF1ZXN0cyBkbyBub3Qgc3VwcG9ydCBoZWFkZXJzLic7XG5jb25zdCBKU09OUF9FUlJfVU5TQUZFX1VSTCA9ICdKU09OUCByZXF1ZXN0cyBvbmx5IHN1cHBvcnQgYWJzb2x1dGUgVVJMcyB3aXRoIEhUVFAoUykgcHJvdG9jb2xzLic7XG5jbGFzcyBKc29ucENhbGxiYWNrQ29udGV4dCB7fVxuZnVuY3Rpb24ganNvbnBDYWxsYmFja0NvbnRleHQoKSB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiB3aW5kb3c7XG4gIH1cbiAgcmV0dXJuIHt9O1xufVxuY2xhc3MgSnNvbnBDbGllbnRCYWNrZW5kIHtcbiAgY2FsbGJhY2tNYXA7XG4gIGRvY3VtZW50O1xuICByZXNvbHZlZFByb21pc2UgPSBQcm9taXNlLnJlc29sdmUoKTtcbiAgbm9uY2UgPSBpbmplY3QoQ1NQX05PTkNFLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSk7XG4gIGNvbnN0cnVjdG9yKGNhbGxiYWNrTWFwLCBkb2N1bWVudCkge1xuICAgIHRoaXMuY2FsbGJhY2tNYXAgPSBjYWxsYmFja01hcDtcbiAgICB0aGlzLmRvY3VtZW50ID0gZG9jdW1lbnQ7XG4gICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgY29uc29sZS53YXJuKCdKU09OUCBzdXBwb3J0IGlzIGRlcHJlY2F0ZWQgYXMgaXQgY2FuIGNhdXNlIFhTUyB2dWxuZXJhYmlsaXRpZXMsIGFuZCB3aWxsIGJlIHJlbW92ZWQgJyArICdpbiBhIGZ1dHVyZSB2ZXJzaW9uIG9mIEFuZ3VsYXIuIFBsZWFzZSB1c2Ugc3RhbmRhcmQgSFRUUCByZXF1ZXN0cyBpbnN0ZWFkLicpO1xuICAgIH1cbiAgfVxuICBuZXh0Q2FsbGJhY2soKSB7XG4gICAgcmV0dXJuIGBuZ19qc29ucF9jYWxsYmFja18ke25leHRSZXF1ZXN0SWQrK31gO1xuICB9XG4gIGhhbmRsZShyZXEpIHtcbiAgICBpZiAocmVxLm1ldGhvZCAhPT0gJ0pTT05QJykge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjgxMCwgbmdEZXZNb2RlICYmIEpTT05QX0VSUl9XUk9OR19NRVRIT0QpO1xuICAgIH0gZWxzZSBpZiAocmVxLnJlc3BvbnNlVHlwZSAhPT0gJ2pzb24nKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyODExLCBuZ0Rldk1vZGUgJiYgSlNPTlBfRVJSX1dST05HX1JFU1BPTlNFX1RZUEUpO1xuICAgIH1cbiAgICBpZiAocmVxLmhlYWRlcnMua2V5cygpLmxlbmd0aCA+IDApIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI4MTIsIG5nRGV2TW9kZSAmJiBKU09OUF9FUlJfSEVBREVSU19OT1RfU1VQUE9SVEVEKTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmlzQWxsb3dlZEpzb25wVXJsKHJlcS51cmxXaXRoUGFyYW1zKSkge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjgyNiwgbmdEZXZNb2RlICYmIEpTT05QX0VSUl9VTlNBRkVfVVJMKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKG9ic2VydmVyID0+IHtcbiAgICAgIGNvbnN0IGNhbGxiYWNrID0gdGhpcy5uZXh0Q2FsbGJhY2soKTtcbiAgICAgIGNvbnN0IHVybCA9IHJlcS51cmxXaXRoUGFyYW1zLnJlcGxhY2UoLz1KU09OUF9DQUxMQkFDSygmfCQpLywgYD0ke2NhbGxiYWNrfSQxYCk7XG4gICAgICBjb25zdCBub2RlID0gdGhpcy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcbiAgICAgIG5vZGUuc3JjID0gdXJsO1xuICAgICAgaWYgKHRoaXMubm9uY2UpIHtcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ25vbmNlJywgdGhpcy5ub25jZSk7XG4gICAgICB9XG4gICAgICBsZXQgYm9keSA9IG51bGw7XG4gICAgICBsZXQgZmluaXNoZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuY2FsbGJhY2tNYXBbY2FsbGJhY2tdID0gZGF0YSA9PiB7XG4gICAgICAgIGRlbGV0ZSB0aGlzLmNhbGxiYWNrTWFwW2NhbGxiYWNrXTtcbiAgICAgICAgYm9keSA9IGRhdGE7XG4gICAgICAgIGZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgIH07XG4gICAgICBjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuICAgICAgICBub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBvbkxvYWQpO1xuICAgICAgICBub2RlLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Vycm9yJywgb25FcnJvcik7XG4gICAgICAgIG5vZGUucmVtb3ZlKCk7XG4gICAgICAgIGRlbGV0ZSB0aGlzLmNhbGxiYWNrTWFwW2NhbGxiYWNrXTtcbiAgICAgIH07XG4gICAgICBjb25zdCBvbkxvYWQgPSAoKSA9PiB7XG4gICAgICAgIHRoaXMucmVzb2x2ZWRQcm9taXNlLnRoZW4oKCkgPT4ge1xuICAgICAgICAgIGNsZWFudXAoKTtcbiAgICAgICAgICBpZiAoIWZpbmlzaGVkKSB7XG4gICAgICAgICAgICBvYnNlcnZlci5lcnJvcihuZXcgSHR0cEVycm9yUmVzcG9uc2Uoe1xuICAgICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICAgIHN0YXR1czogMCxcbiAgICAgICAgICAgICAgc3RhdHVzVGV4dDogJ0pTT05QIEVycm9yJyxcbiAgICAgICAgICAgICAgZXJyb3I6IG5ldyBFcnJvcihKU09OUF9FUlJfTk9fQ0FMTEJBQ0spXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIG9ic2VydmVyLm5leHQobmV3IEh0dHBSZXNwb25zZSh7XG4gICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgc3RhdHVzOiBIVFRQX1NUQVRVU19DT0RFX09LLFxuICAgICAgICAgICAgc3RhdHVzVGV4dDogJ09LJyxcbiAgICAgICAgICAgIHVybFxuICAgICAgICAgIH0pKTtcbiAgICAgICAgICBvYnNlcnZlci5jb21wbGV0ZSgpO1xuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgICBjb25zdCBvbkVycm9yID0gZXJyb3IgPT4ge1xuICAgICAgICBjbGVhbnVwKCk7XG4gICAgICAgIG9ic2VydmVyLmVycm9yKG5ldyBIdHRwRXJyb3JSZXNwb25zZSh7XG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgc3RhdHVzOiAwLFxuICAgICAgICAgIHN0YXR1c1RleHQ6ICdKU09OUCBFcnJvcicsXG4gICAgICAgICAgdXJsXG4gICAgICAgIH0pKTtcbiAgICAgIH07XG4gICAgICBub2RlLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBvbkxvYWQpO1xuICAgICAgbm9kZS5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsIG9uRXJyb3IpO1xuICAgICAgdGhpcy5kb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG5vZGUpO1xuICAgICAgb2JzZXJ2ZXIubmV4dCh7XG4gICAgICAgIHR5cGU6IEh0dHBFdmVudFR5cGUuU2VudFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBpZiAoIWZpbmlzaGVkKSB7XG4gICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcnMobm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgY2xlYW51cCgpO1xuICAgICAgfTtcbiAgICB9KTtcbiAgfVxuICByZW1vdmVMaXN0ZW5lcnMoc2NyaXB0KSB7XG4gICAgZm9yZWlnbkRvY3VtZW50ID8/PSB0aGlzLmRvY3VtZW50LmltcGxlbWVudGF0aW9uLmNyZWF0ZUhUTUxEb2N1bWVudCgpO1xuICAgIGZvcmVpZ25Eb2N1bWVudC5hZG9wdE5vZGUoc2NyaXB0KTtcbiAgfVxuICBpc0FsbG93ZWRKc29ucFVybCh1cmwpIHtcbiAgICByZXR1cm4gL15odHRwcz86XFwvXFwvL2kudGVzdCh1cmwpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEpzb25wQ2xpZW50QmFja2VuZF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEpzb25wQ2xpZW50QmFja2VuZCkoaTAuybXJtWluamVjdChKc29ucENhbGxiYWNrQ29udGV4dCksIGkwLsm1ybVpbmplY3QoRE9DVU1FTlQpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogSnNvbnBDbGllbnRCYWNrZW5kLFxuICAgIGZhY3Rvcnk6IEpzb25wQ2xpZW50QmFja2VuZC7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEpzb25wQ2xpZW50QmFja2VuZCwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IEpzb25wQ2FsbGJhY2tDb250ZXh0XG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtET0NVTUVOVF1cbiAgICB9XVxuICB9XSwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24ganNvbnBJbnRlcmNlcHRvckZuKHJlcSwgbmV4dCkge1xuICBpZiAocmVxLm1ldGhvZCA9PT0gJ0pTT05QJykge1xuICAgIHJldHVybiBpbmplY3QoSnNvbnBDbGllbnRCYWNrZW5kKS5oYW5kbGUocmVxKTtcbiAgfVxuICByZXR1cm4gbmV4dChyZXEpO1xufVxuY2xhc3MgSnNvbnBJbnRlcmNlcHRvciB7XG4gIGluamVjdG9yO1xuICBjb25zdHJ1Y3RvcihpbmplY3Rvcikge1xuICAgIHRoaXMuaW5qZWN0b3IgPSBpbmplY3RvcjtcbiAgfVxuICBpbnRlcmNlcHQoaW5pdGlhbFJlcXVlc3QsIG5leHQpIHtcbiAgICByZXR1cm4gcnVuSW5JbmplY3Rpb25Db250ZXh0KHRoaXMuaW5qZWN0b3IsICgpID0+IGpzb25wSW50ZXJjZXB0b3JGbihpbml0aWFsUmVxdWVzdCwgZG93bnN0cmVhbVJlcXVlc3QgPT4gbmV4dC5oYW5kbGUoZG93bnN0cmVhbVJlcXVlc3QpKSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSnNvbnBJbnRlcmNlcHRvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEpzb25wSW50ZXJjZXB0b3IpKGkwLsm1ybVpbmplY3QoaTAuRW52aXJvbm1lbnRJbmplY3RvcikpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBKc29ucEludGVyY2VwdG9yLFxuICAgIGZhY3Rvcnk6IEpzb25wSW50ZXJjZXB0b3IuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShKc29ucEludGVyY2VwdG9yLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuRW52aXJvbm1lbnRJbmplY3RvclxuICB9XSwgbnVsbCk7XG59KSgpO1xuY29uc3QgWFNTSV9QUkVGSVggPSAvXlxcKVxcXVxcfScsP1xcbi87XG5mdW5jdGlvbiB2YWxpZGF0ZVhockNvbXBhdGliaWxpdHkocmVxKSB7XG4gIGNvbnN0IHVuc3VwcG9ydGVkT3B0aW9ucyA9IFt7XG4gICAgcHJvcGVydHk6ICdrZWVwYWxpdmUnLFxuICAgIGVycm9yQ29kZTogMjgxM1xuICB9LCB7XG4gICAgcHJvcGVydHk6ICdjYWNoZScsXG4gICAgZXJyb3JDb2RlOiAyODE0XG4gIH0sIHtcbiAgICBwcm9wZXJ0eTogJ3ByaW9yaXR5JyxcbiAgICBlcnJvckNvZGU6IDI4MTVcbiAgfSwge1xuICAgIHByb3BlcnR5OiAnbW9kZScsXG4gICAgZXJyb3JDb2RlOiAyODE2XG4gIH0sIHtcbiAgICBwcm9wZXJ0eTogJ3JlZGlyZWN0JyxcbiAgICBlcnJvckNvZGU6IDI4MTdcbiAgfSwge1xuICAgIHByb3BlcnR5OiAnY3JlZGVudGlhbHMnLFxuICAgIGVycm9yQ29kZTogMjgxOFxuICB9LCB7XG4gICAgcHJvcGVydHk6ICdpbnRlZ3JpdHknLFxuICAgIGVycm9yQ29kZTogMjgyMFxuICB9LCB7XG4gICAgcHJvcGVydHk6ICdyZWZlcnJlcicsXG4gICAgZXJyb3JDb2RlOiAyODIxXG4gIH0sIHtcbiAgICBwcm9wZXJ0eTogJ3JlZmVycmVyUG9saWN5JyxcbiAgICBlcnJvckNvZGU6IDI4MjNcbiAgfV07XG4gIGZvciAoY29uc3Qge1xuICAgIHByb3BlcnR5LFxuICAgIGVycm9yQ29kZVxuICB9IG9mIHVuc3VwcG9ydGVkT3B0aW9ucykge1xuICAgIGlmIChyZXFbcHJvcGVydHldKSB7XG4gICAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcihlcnJvckNvZGUsIGBBbmd1bGFyIGRldGVjdGVkIHRoYXQgYSBcXGBIdHRwQ2xpZW50XFxgIHJlcXVlc3Qgd2l0aCB0aGUgXFxgJHtwcm9wZXJ0eX1cXGAgb3B0aW9uIHdhcyBzZW50IHVzaW5nIFhIUiwgd2hpY2ggZG9lcyBub3Qgc3VwcG9ydCBpdC4gVG8gdXNlIHRoZSBcXGAke3Byb3BlcnR5fVxcYCBvcHRpb24sIHVzZSB0aGUgRmV0Y2ggQVBJIGJ5IHJlbW92aW5nIFxcYHdpdGhYaHIoKVxcYCBmcm9tIHRoZSBcXGBwcm92aWRlSHR0cENsaWVudCgpXFxgIGNhbGwuYCkpO1xuICAgIH1cbiAgfVxufVxuY2xhc3MgSHR0cFhockJhY2tlbmQge1xuICB4aHJGYWN0b3J5O1xuICB0cmFjaW5nU2VydmljZSA9IGluamVjdChfVHJhY2luZ1NlcnZpY2UsIHtcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9KTtcbiAgY29uc3RydWN0b3IoeGhyRmFjdG9yeSkge1xuICAgIHRoaXMueGhyRmFjdG9yeSA9IHhockZhY3Rvcnk7XG4gIH1cbiAgbWF5YmVQcm9wYWdhdGVUcmFjZShmbikge1xuICAgIHJldHVybiB0aGlzLnRyYWNpbmdTZXJ2aWNlPy5wcm9wYWdhdGUgPyB0aGlzLnRyYWNpbmdTZXJ2aWNlLnByb3BhZ2F0ZShmbikgOiBmbjtcbiAgfVxuICBoYW5kbGUocmVxKSB7XG4gICAgaWYgKHJlcS5tZXRob2QgPT09ICdKU09OUCcpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKC0yODAwLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBgQ2Fubm90IG1ha2UgYSBKU09OUCByZXF1ZXN0IHdpdGhvdXQgSlNPTlAgc3VwcG9ydC4gVG8gZml4IHRoZSBwcm9ibGVtLCBlaXRoZXIgYWRkIHRoZSBcXGB3aXRoSnNvbnBTdXBwb3J0KClcXGAgY2FsbCAoaWYgXFxgcHJvdmlkZUh0dHBDbGllbnQoKVxcYCBpcyB1c2VkKSBvciBpbXBvcnQgdGhlIFxcYEh0dHBDbGllbnRKc29ucE1vZHVsZVxcYCBpbiB0aGUgcm9vdCBOZ01vZHVsZS5gKTtcbiAgICB9XG4gICAgbmdEZXZNb2RlICYmIHZhbGlkYXRlWGhyQ29tcGF0aWJpbGl0eShyZXEpO1xuICAgIGNvbnN0IHhockZhY3RvcnkgPSB0aGlzLnhockZhY3Rvcnk7XG4gICAgY29uc3Qgc291cmNlID0gdHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdTZXJ2ZXJNb2RlICYmIHhockZhY3RvcnkuybVsb2FkSW1wbCA/IGZyb20oeGhyRmFjdG9yeS7JtWxvYWRJbXBsKCkpIDogb2YobnVsbCk7XG4gICAgcmV0dXJuIHNvdXJjZS5waXBlKHN3aXRjaE1hcCgoKSA9PiB7XG4gICAgICByZXR1cm4gbmV3IE9ic2VydmFibGUob2JzZXJ2ZXIgPT4ge1xuICAgICAgICBjb25zdCB4aHIgPSB4aHJGYWN0b3J5LmJ1aWxkKCk7XG4gICAgICAgIHhoci5vcGVuKHJlcS5tZXRob2QsIHJlcS51cmxXaXRoUGFyYW1zKTtcbiAgICAgICAgaWYgKHJlcS53aXRoQ3JlZGVudGlhbHMpIHtcbiAgICAgICAgICB4aHIud2l0aENyZWRlbnRpYWxzID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXEuaGVhZGVycy5mb3JFYWNoKChuYW1lLCB2YWx1ZXMpID0+IHhoci5zZXRSZXF1ZXN0SGVhZGVyKG5hbWUsIHZhbHVlcy5qb2luKCcsJykpKTtcbiAgICAgICAgaWYgKCFyZXEuaGVhZGVycy5oYXMoQUNDRVBUX0hFQURFUikpIHtcbiAgICAgICAgICB4aHIuc2V0UmVxdWVzdEhlYWRlcihBQ0NFUFRfSEVBREVSLCBBQ0NFUFRfSEVBREVSX1ZBTFVFKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJlcS5oZWFkZXJzLmhhcyhDT05URU5UX1RZUEVfSEVBREVSKSkge1xuICAgICAgICAgIGNvbnN0IGRldGVjdGVkVHlwZSA9IHJlcS5kZXRlY3RDb250ZW50VHlwZUhlYWRlcigpO1xuICAgICAgICAgIGlmIChkZXRlY3RlZFR5cGUgIT09IG51bGwpIHtcbiAgICAgICAgICAgIHhoci5zZXRSZXF1ZXN0SGVhZGVyKENPTlRFTlRfVFlQRV9IRUFERVIsIGRldGVjdGVkVHlwZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChyZXEudGltZW91dCkge1xuICAgICAgICAgIHhoci50aW1lb3V0ID0gcmVxLnRpbWVvdXQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlcS5yZXNwb25zZVR5cGUpIHtcbiAgICAgICAgICBjb25zdCByZXNwb25zZVR5cGUgPSByZXEucmVzcG9uc2VUeXBlLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgeGhyLnJlc3BvbnNlVHlwZSA9IHJlc3BvbnNlVHlwZSAhPT0gJ2pzb24nID8gcmVzcG9uc2VUeXBlIDogJ3RleHQnO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlcUJvZHkgPSByZXEuc2VyaWFsaXplQm9keSgpO1xuICAgICAgICBsZXQgaGVhZGVyUmVzcG9uc2UgPSBudWxsO1xuICAgICAgICBjb25zdCBwYXJ0aWFsRnJvbVhociA9ICgpID0+IHtcbiAgICAgICAgICBpZiAoaGVhZGVyUmVzcG9uc2UgIT09IG51bGwpIHtcbiAgICAgICAgICAgIHJldHVybiBoZWFkZXJSZXNwb25zZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3Qgc3RhdHVzVGV4dCA9IHhoci5zdGF0dXNUZXh0IHx8ICdPSyc7XG4gICAgICAgICAgY29uc3QgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh4aHIuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzKCkpO1xuICAgICAgICAgIGNvbnN0IHVybCA9IHhoci5yZXNwb25zZVVSTCB8fCByZXEudXJsO1xuICAgICAgICAgIGhlYWRlclJlc3BvbnNlID0gbmV3IEh0dHBIZWFkZXJSZXNwb25zZSh7XG4gICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgc3RhdHVzOiB4aHIuc3RhdHVzLFxuICAgICAgICAgICAgc3RhdHVzVGV4dCxcbiAgICAgICAgICAgIHVybFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiBoZWFkZXJSZXNwb25zZTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgb25Mb2FkID0gdGhpcy5tYXliZVByb3BhZ2F0ZVRyYWNlKCgpID0+IHtcbiAgICAgICAgICBsZXQge1xuICAgICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgIHN0YXR1c1RleHQsXG4gICAgICAgICAgICB1cmxcbiAgICAgICAgICB9ID0gcGFydGlhbEZyb21YaHIoKTtcbiAgICAgICAgICBsZXQgYm9keSA9IG51bGw7XG4gICAgICAgICAgaWYgKHN0YXR1cyAhPT0gSFRUUF9TVEFUVVNfQ09ERV9OT19DT05URU5UKSB7XG4gICAgICAgICAgICBib2R5ID0gdHlwZW9mIHhoci5yZXNwb25zZSA9PT0gJ3VuZGVmaW5lZCcgPyB4aHIucmVzcG9uc2VUZXh0IDogeGhyLnJlc3BvbnNlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc3RhdHVzID09PSAwKSB7XG4gICAgICAgICAgICBzdGF0dXMgPSAhIWJvZHkgPyBIVFRQX1NUQVRVU19DT0RFX09LIDogMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgbGV0IG9rID0gc3RhdHVzID49IDIwMCAmJiBzdGF0dXMgPCAzMDA7XG4gICAgICAgICAgaWYgKHJlcS5yZXNwb25zZVR5cGUgPT09ICdqc29uJyAmJiB0eXBlb2YgYm9keSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIGNvbnN0IG9yaWdpbmFsQm9keSA9IGJvZHk7XG4gICAgICAgICAgICBib2R5ID0gYm9keS5yZXBsYWNlKFhTU0lfUFJFRklYLCAnJyk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBib2R5ID0gYm9keSAhPT0gJycgPyBKU09OLnBhcnNlKGJvZHkpIDogbnVsbDtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgIGJvZHkgPSBvcmlnaW5hbEJvZHk7XG4gICAgICAgICAgICAgIGlmIChvaykge1xuICAgICAgICAgICAgICAgIG9rID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgYm9keSA9IHtcbiAgICAgICAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgICAgICAgdGV4dDogYm9keVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKG9rKSB7XG4gICAgICAgICAgICBvYnNlcnZlci5uZXh0KG5ldyBIdHRwUmVzcG9uc2Uoe1xuICAgICAgICAgICAgICBib2R5LFxuICAgICAgICAgICAgICBoZWFkZXJzLFxuICAgICAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgICAgIHN0YXR1c1RleHQsXG4gICAgICAgICAgICAgIHVybDogdXJsIHx8IHVuZGVmaW5lZFxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgb2JzZXJ2ZXIuY29tcGxldGUoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb2JzZXJ2ZXIuZXJyb3IobmV3IEh0dHBFcnJvclJlc3BvbnNlKHtcbiAgICAgICAgICAgICAgZXJyb3I6IGJvZHksXG4gICAgICAgICAgICAgIGhlYWRlcnMsXG4gICAgICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICAgICAgc3RhdHVzVGV4dCxcbiAgICAgICAgICAgICAgdXJsOiB1cmwgfHwgdW5kZWZpbmVkXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3Qgb25FcnJvciA9IHRoaXMubWF5YmVQcm9wYWdhdGVUcmFjZShlcnJvciA9PiB7XG4gICAgICAgICAgY29uc3Qge1xuICAgICAgICAgICAgdXJsXG4gICAgICAgICAgfSA9IHBhcnRpYWxGcm9tWGhyKCk7XG4gICAgICAgICAgY29uc3QgcmVzID0gbmV3IEh0dHBFcnJvclJlc3BvbnNlKHtcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgc3RhdHVzOiB4aHIuc3RhdHVzIHx8IDAsXG4gICAgICAgICAgICBzdGF0dXNUZXh0OiB4aHIuc3RhdHVzVGV4dCB8fCAnVW5rbm93biBFcnJvcicsXG4gICAgICAgICAgICB1cmw6IHVybCB8fCB1bmRlZmluZWRcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBvYnNlcnZlci5lcnJvcihyZXMpO1xuICAgICAgICB9KTtcbiAgICAgICAgbGV0IG9uVGltZW91dCA9IG9uRXJyb3I7XG4gICAgICAgIGlmIChyZXEudGltZW91dCkge1xuICAgICAgICAgIG9uVGltZW91dCA9IHRoaXMubWF5YmVQcm9wYWdhdGVUcmFjZShfID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgdXJsXG4gICAgICAgICAgICB9ID0gcGFydGlhbEZyb21YaHIoKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IG5ldyBIdHRwRXJyb3JSZXNwb25zZSh7XG4gICAgICAgICAgICAgIGVycm9yOiBuZXcgRE9NRXhjZXB0aW9uKCdSZXF1ZXN0IHRpbWVkIG91dCcsICdUaW1lb3V0RXJyb3InKSxcbiAgICAgICAgICAgICAgc3RhdHVzOiB4aHIuc3RhdHVzIHx8IDAsXG4gICAgICAgICAgICAgIHN0YXR1c1RleHQ6IHhoci5zdGF0dXNUZXh0IHx8ICdSZXF1ZXN0IHRpbWVvdXQnLFxuICAgICAgICAgICAgICB1cmw6IHVybCB8fCB1bmRlZmluZWRcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgb2JzZXJ2ZXIuZXJyb3IocmVzKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgc2VudEhlYWRlcnMgPSBmYWxzZTtcbiAgICAgICAgY29uc3Qgb25Eb3duUHJvZ3Jlc3MgPSB0aGlzLm1heWJlUHJvcGFnYXRlVHJhY2UoZXZlbnQgPT4ge1xuICAgICAgICAgIGlmICghc2VudEhlYWRlcnMpIHtcbiAgICAgICAgICAgIG9ic2VydmVyLm5leHQocGFydGlhbEZyb21YaHIoKSk7XG4gICAgICAgICAgICBzZW50SGVhZGVycyA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldCBwcm9ncmVzc0V2ZW50ID0ge1xuICAgICAgICAgICAgdHlwZTogSHR0cEV2ZW50VHlwZS5Eb3dubG9hZFByb2dyZXNzLFxuICAgICAgICAgICAgbG9hZGVkOiBldmVudC5sb2FkZWRcbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChldmVudC5sZW5ndGhDb21wdXRhYmxlKSB7XG4gICAgICAgICAgICBwcm9ncmVzc0V2ZW50LnRvdGFsID0gZXZlbnQudG90YWw7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChyZXEucmVzcG9uc2VUeXBlID09PSAndGV4dCcgJiYgISF4aHIucmVzcG9uc2VUZXh0KSB7XG4gICAgICAgICAgICBwcm9ncmVzc0V2ZW50LnBhcnRpYWxUZXh0ID0geGhyLnJlc3BvbnNlVGV4dDtcbiAgICAgICAgICB9XG4gICAgICAgICAgb2JzZXJ2ZXIubmV4dChwcm9ncmVzc0V2ZW50KTtcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IG9uVXBQcm9ncmVzcyA9IHRoaXMubWF5YmVQcm9wYWdhdGVUcmFjZShldmVudCA9PiB7XG4gICAgICAgICAgbGV0IHByb2dyZXNzID0ge1xuICAgICAgICAgICAgdHlwZTogSHR0cEV2ZW50VHlwZS5VcGxvYWRQcm9ncmVzcyxcbiAgICAgICAgICAgIGxvYWRlZDogZXZlbnQubG9hZGVkXG4gICAgICAgICAgfTtcbiAgICAgICAgICBpZiAoZXZlbnQubGVuZ3RoQ29tcHV0YWJsZSkge1xuICAgICAgICAgICAgcHJvZ3Jlc3MudG90YWwgPSBldmVudC50b3RhbDtcbiAgICAgICAgICB9XG4gICAgICAgICAgb2JzZXJ2ZXIubmV4dChwcm9ncmVzcyk7XG4gICAgICAgIH0pO1xuICAgICAgICB4aHIuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsIG9uTG9hZCk7XG4gICAgICAgIHhoci5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsIG9uRXJyb3IpO1xuICAgICAgICB4aHIuYWRkRXZlbnRMaXN0ZW5lcigndGltZW91dCcsIG9uVGltZW91dCk7XG4gICAgICAgIHhoci5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uRXJyb3IpO1xuICAgICAgICBjb25zdCByZXBvcnRVcGxvYWRQcm9ncmVzcyA9IHJlcS5yZXBvcnRQcm9ncmVzcyB8fCByZXEucmVwb3J0VXBsb2FkUHJvZ3Jlc3M7XG4gICAgICAgIGNvbnN0IHJlcG9ydERvd25sb2FkUHJvZ3Jlc3MgPSByZXEucmVwb3J0UHJvZ3Jlc3MgfHwgcmVxLnJlcG9ydERvd25sb2FkUHJvZ3Jlc3M7XG4gICAgICAgIGlmIChyZXBvcnREb3dubG9hZFByb2dyZXNzKSB7XG4gICAgICAgICAgeGhyLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgb25Eb3duUHJvZ3Jlc3MpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXBvcnRVcGxvYWRQcm9ncmVzcyAmJiByZXFCb2R5ICE9PSBudWxsICYmIHhoci51cGxvYWQpIHtcbiAgICAgICAgICB4aHIudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgb25VcFByb2dyZXNzKTtcbiAgICAgICAgfVxuICAgICAgICB4aHIuc2VuZChyZXFCb2R5KTtcbiAgICAgICAgb2JzZXJ2ZXIubmV4dCh7XG4gICAgICAgICAgdHlwZTogSHR0cEV2ZW50VHlwZS5TZW50XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIHhoci5yZW1vdmVFdmVudExpc3RlbmVyKCdlcnJvcicsIG9uRXJyb3IpO1xuICAgICAgICAgIHhoci5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uRXJyb3IpO1xuICAgICAgICAgIHhoci5yZW1vdmVFdmVudExpc3RlbmVyKCdsb2FkJywgb25Mb2FkKTtcbiAgICAgICAgICB4aHIucmVtb3ZlRXZlbnRMaXN0ZW5lcigndGltZW91dCcsIG9uVGltZW91dCk7XG4gICAgICAgICAgaWYgKHJlcG9ydERvd25sb2FkUHJvZ3Jlc3MpIHtcbiAgICAgICAgICAgIHhoci5yZW1vdmVFdmVudExpc3RlbmVyKCdwcm9ncmVzcycsIG9uRG93blByb2dyZXNzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHJlcG9ydFVwbG9hZFByb2dyZXNzICYmIHJlcUJvZHkgIT09IG51bGwgJiYgeGhyLnVwbG9hZCkge1xuICAgICAgICAgICAgeGhyLnVwbG9hZC5yZW1vdmVFdmVudExpc3RlbmVyKCdwcm9ncmVzcycsIG9uVXBQcm9ncmVzcyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSAhPT0geGhyLkRPTkUpIHtcbiAgICAgICAgICAgIHhoci5hYm9ydCgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgIH0pKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBIdHRwWGhyQmFja2VuZF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEh0dHBYaHJCYWNrZW5kKShpMC7Jtcm1aW5qZWN0KFhockZhY3RvcnkpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogSHR0cFhockJhY2tlbmQsXG4gICAgZmFjdG9yeTogSHR0cFhockJhY2tlbmQuybVmYWMsXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoSHR0cFhockJhY2tlbmQsIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogWGhyRmFjdG9yeVxuICB9XSwgbnVsbCk7XG59KSgpO1xudmFyIEh0dHBGZWF0dXJlS2luZDtcbihmdW5jdGlvbiAoSHR0cEZlYXR1cmVLaW5kKSB7XG4gIEh0dHBGZWF0dXJlS2luZFtIdHRwRmVhdHVyZUtpbmRbXCJJbnRlcmNlcHRvcnNcIl0gPSAwXSA9IFwiSW50ZXJjZXB0b3JzXCI7XG4gIEh0dHBGZWF0dXJlS2luZFtIdHRwRmVhdHVyZUtpbmRbXCJMZWdhY3lJbnRlcmNlcHRvcnNcIl0gPSAxXSA9IFwiTGVnYWN5SW50ZXJjZXB0b3JzXCI7XG4gIEh0dHBGZWF0dXJlS2luZFtIdHRwRmVhdHVyZUtpbmRbXCJDdXN0b21Yc3JmQ29uZmlndXJhdGlvblwiXSA9IDJdID0gXCJDdXN0b21Yc3JmQ29uZmlndXJhdGlvblwiO1xuICBIdHRwRmVhdHVyZUtpbmRbSHR0cEZlYXR1cmVLaW5kW1wiTm9Yc3JmUHJvdGVjdGlvblwiXSA9IDNdID0gXCJOb1hzcmZQcm90ZWN0aW9uXCI7XG4gIEh0dHBGZWF0dXJlS2luZFtIdHRwRmVhdHVyZUtpbmRbXCJKc29ucFN1cHBvcnRcIl0gPSA0XSA9IFwiSnNvbnBTdXBwb3J0XCI7XG4gIEh0dHBGZWF0dXJlS2luZFtIdHRwRmVhdHVyZUtpbmRbXCJSZXF1ZXN0c01hZGVWaWFQYXJlbnRcIl0gPSA1XSA9IFwiUmVxdWVzdHNNYWRlVmlhUGFyZW50XCI7XG4gIEh0dHBGZWF0dXJlS2luZFtIdHRwRmVhdHVyZUtpbmRbXCJGZXRjaFwiXSA9IDZdID0gXCJGZXRjaFwiO1xuICBIdHRwRmVhdHVyZUtpbmRbSHR0cEZlYXR1cmVLaW5kW1wiWGhyXCJdID0gN10gPSBcIlhoclwiO1xufSkoSHR0cEZlYXR1cmVLaW5kIHx8IChIdHRwRmVhdHVyZUtpbmQgPSB7fSkpO1xuZnVuY3Rpb24gbWFrZUh0dHBGZWF0dXJlKGtpbmQsIHByb3ZpZGVycykge1xuICByZXR1cm4ge1xuICAgIMm1a2luZDoga2luZCxcbiAgICDJtXByb3ZpZGVyczogcHJvdmlkZXJzXG4gIH07XG59XG5mdW5jdGlvbiBwcm92aWRlSHR0cENsaWVudCguLi5mZWF0dXJlcykge1xuICBpZiAobmdEZXZNb2RlKSB7XG4gICAgY29uc3QgZmVhdHVyZUtpbmRzID0gbmV3IFNldChmZWF0dXJlcy5tYXAoZiA9PiBmLsm1a2luZCkpO1xuICAgIGlmIChmZWF0dXJlS2luZHMuaGFzKEh0dHBGZWF0dXJlS2luZC5Ob1hzcmZQcm90ZWN0aW9uKSAmJiBmZWF0dXJlS2luZHMuaGFzKEh0dHBGZWF0dXJlS2luZC5DdXN0b21Yc3JmQ29uZmlndXJhdGlvbikpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgQ29uZmlndXJhdGlvbiBlcnJvcjogZm91bmQgYm90aCB3aXRoWHNyZkNvbmZpZ3VyYXRpb24oKSBhbmQgd2l0aE5vWHNyZlByb3RlY3Rpb24oKSBpbiB0aGUgc2FtZSBjYWxsIHRvIHByb3ZpZGVIdHRwQ2xpZW50KCksIHdoaWNoIGlzIGEgY29udHJhZGljdGlvbi5gKTtcbiAgICB9XG4gICAgY29uc3QgaGFzQmFja2VuZE92ZXJyaWRlID0gZmVhdHVyZUtpbmRzLmhhcyhIdHRwRmVhdHVyZUtpbmQuRmV0Y2gpIHx8IGZlYXR1cmVLaW5kcy5oYXMoSHR0cEZlYXR1cmVLaW5kLlhocik7XG4gICAgaWYgKGZlYXR1cmVLaW5kcy5oYXMoSHR0cEZlYXR1cmVLaW5kLlJlcXVlc3RzTWFkZVZpYVBhcmVudCkgJiYgaGFzQmFja2VuZE92ZXJyaWRlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYENvbmZpZ3VyYXRpb24gZXJyb3I6IHdpdGhSZXF1ZXN0c01hZGVWaWFQYXJlbnQoKSBjYW5ub3QgYmUgY29tYmluZWQgd2l0aCB3aXRoRmV0Y2goKSBvciB3aXRoWGhyKCkgaW4gdGhlIHNhbWUgY2FsbCB0byBwcm92aWRlSHR0cENsaWVudCgpLmApO1xuICAgIH1cbiAgfVxuICBjb25zdCBwcm92aWRlcnMgPSBbSHR0cENsaWVudCwgRmV0Y2hCYWNrZW5kLCBIdHRwSW50ZXJjZXB0b3JIYW5kbGVyLCB7XG4gICAgcHJvdmlkZTogSHR0cEhhbmRsZXIsXG4gICAgdXNlRXhpc3Rpbmc6IEh0dHBJbnRlcmNlcHRvckhhbmRsZXJcbiAgfSwge1xuICAgIHByb3ZpZGU6IEh0dHBCYWNrZW5kLFxuICAgIHVzZUZhY3Rvcnk6ICgpID0+IHtcbiAgICAgIHJldHVybiBpbmplY3QoRmV0Y2hCYWNrZW5kKTtcbiAgICB9XG4gIH0sIHtcbiAgICBwcm92aWRlOiBIVFRQX0lOVEVSQ0VQVE9SX0ZOUyxcbiAgICB1c2VWYWx1ZTogeHNyZkludGVyY2VwdG9yRm4sXG4gICAgbXVsdGk6IHRydWVcbiAgfV07XG4gIGZvciAoY29uc3QgZmVhdHVyZSBvZiBmZWF0dXJlcykge1xuICAgIHByb3ZpZGVycy5wdXNoKC4uLmZlYXR1cmUuybVwcm92aWRlcnMpO1xuICB9XG4gIHJldHVybiBtYWtlRW52aXJvbm1lbnRQcm92aWRlcnMocHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhJbnRlcmNlcHRvcnMoaW50ZXJjZXB0b3JGbnMpIHtcbiAgcmV0dXJuIG1ha2VIdHRwRmVhdHVyZShIdHRwRmVhdHVyZUtpbmQuSW50ZXJjZXB0b3JzLCBpbnRlcmNlcHRvckZucy5tYXAoaW50ZXJjZXB0b3JGbiA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JfRk5TLFxuICAgICAgdXNlVmFsdWU6IGludGVyY2VwdG9yRm4sXG4gICAgICBtdWx0aTogdHJ1ZVxuICAgIH07XG4gIH0pKTtcbn1cbmNvbnN0IExFR0FDWV9JTlRFUkNFUFRPUl9GTiA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnTEVHQUNZX0lOVEVSQ0VQVE9SX0ZOJyA6ICcnKTtcbmZ1bmN0aW9uIHdpdGhJbnRlcmNlcHRvcnNGcm9tRGkoKSB7XG4gIHJldHVybiBtYWtlSHR0cEZlYXR1cmUoSHR0cEZlYXR1cmVLaW5kLkxlZ2FjeUludGVyY2VwdG9ycywgW3tcbiAgICBwcm92aWRlOiBMRUdBQ1lfSU5URVJDRVBUT1JfRk4sXG4gICAgdXNlRmFjdG9yeTogbGVnYWN5SW50ZXJjZXB0b3JGbkZhY3RvcnlcbiAgfSwge1xuICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JfRk5TLFxuICAgIHVzZUV4aXN0aW5nOiBMRUdBQ1lfSU5URVJDRVBUT1JfRk4sXG4gICAgbXVsdGk6IHRydWVcbiAgfV0pO1xufVxuZnVuY3Rpb24gd2l0aFhzcmZDb25maWd1cmF0aW9uKHtcbiAgY29va2llTmFtZSxcbiAgaGVhZGVyTmFtZVxufSkge1xuICBjb25zdCBwcm92aWRlcnMgPSBbXTtcbiAgaWYgKGNvb2tpZU5hbWUgIT09IHVuZGVmaW5lZCkge1xuICAgIHByb3ZpZGVycy5wdXNoKHtcbiAgICAgIHByb3ZpZGU6IFhTUkZfQ09PS0lFX05BTUUsXG4gICAgICB1c2VWYWx1ZTogY29va2llTmFtZVxuICAgIH0pO1xuICB9XG4gIGlmIChoZWFkZXJOYW1lICE9PSB1bmRlZmluZWQpIHtcbiAgICBwcm92aWRlcnMucHVzaCh7XG4gICAgICBwcm92aWRlOiBYU1JGX0hFQURFUl9OQU1FLFxuICAgICAgdXNlVmFsdWU6IGhlYWRlck5hbWVcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gbWFrZUh0dHBGZWF0dXJlKEh0dHBGZWF0dXJlS2luZC5DdXN0b21Yc3JmQ29uZmlndXJhdGlvbiwgcHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhOb1hzcmZQcm90ZWN0aW9uKCkge1xuICByZXR1cm4gbWFrZUh0dHBGZWF0dXJlKEh0dHBGZWF0dXJlS2luZC5Ob1hzcmZQcm90ZWN0aW9uLCBbe1xuICAgIHByb3ZpZGU6IFhTUkZfRU5BQkxFRCxcbiAgICB1c2VWYWx1ZTogZmFsc2VcbiAgfV0pO1xufVxuZnVuY3Rpb24gd2l0aEpzb25wU3VwcG9ydCgpIHtcbiAgcmV0dXJuIG1ha2VIdHRwRmVhdHVyZShIdHRwRmVhdHVyZUtpbmQuSnNvbnBTdXBwb3J0LCBbSnNvbnBDbGllbnRCYWNrZW5kLCB7XG4gICAgcHJvdmlkZTogSnNvbnBDYWxsYmFja0NvbnRleHQsXG4gICAgdXNlRmFjdG9yeToganNvbnBDYWxsYmFja0NvbnRleHRcbiAgfSwge1xuICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JfRk5TLFxuICAgIHVzZVZhbHVlOiBqc29ucEludGVyY2VwdG9yRm4sXG4gICAgbXVsdGk6IHRydWVcbiAgfV0pO1xufVxuZnVuY3Rpb24gd2l0aFJlcXVlc3RzTWFkZVZpYVBhcmVudCgpIHtcbiAgcmV0dXJuIG1ha2VIdHRwRmVhdHVyZShIdHRwRmVhdHVyZUtpbmQuUmVxdWVzdHNNYWRlVmlhUGFyZW50LCBbe1xuICAgIHByb3ZpZGU6IEh0dHBCYWNrZW5kLFxuICAgIHVzZUZhY3Rvcnk6ICgpID0+IHtcbiAgICAgIGNvbnN0IGhhbmRsZXJGcm9tUGFyZW50ID0gaW5qZWN0KEh0dHBIYW5kbGVyLCB7XG4gICAgICAgIHNraXBTZWxmOiB0cnVlLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZVxuICAgICAgfSk7XG4gICAgICBpZiAobmdEZXZNb2RlICYmIGhhbmRsZXJGcm9tUGFyZW50ID09PSBudWxsKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignd2l0aFJlcXVlc3RzTWFkZVZpYVBhcmVudCgpIGNhbiBvbmx5IGJlIHVzZWQgd2hlbiB0aGUgcGFyZW50IGluamVjdG9yIGFsc28gY29uZmlndXJlcyBIdHRwQ2xpZW50Jyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gaGFuZGxlckZyb21QYXJlbnQ7XG4gICAgfVxuICB9XSk7XG59XG5mdW5jdGlvbiB3aXRoRmV0Y2goKSB7XG4gIHJldHVybiBtYWtlSHR0cEZlYXR1cmUoSHR0cEZlYXR1cmVLaW5kLkZldGNoLCBbRmV0Y2hCYWNrZW5kLCB7XG4gICAgcHJvdmlkZTogSHR0cEJhY2tlbmQsXG4gICAgdXNlRXhpc3Rpbmc6IEZldGNoQmFja2VuZFxuICB9XSk7XG59XG5mdW5jdGlvbiB3aXRoWGhyKCkge1xuICByZXR1cm4gbWFrZUh0dHBGZWF0dXJlKEh0dHBGZWF0dXJlS2luZC5YaHIsIFtIdHRwWGhyQmFja2VuZCwge1xuICAgIHByb3ZpZGU6IEh0dHBCYWNrZW5kLFxuICAgIHVzZUV4aXN0aW5nOiBIdHRwWGhyQmFja2VuZFxuICB9XSk7XG59XG5jbGFzcyBIdHRwQ2xpZW50WHNyZk1vZHVsZSB7XG4gIHN0YXRpYyBkaXNhYmxlKCkge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogSHR0cENsaWVudFhzcmZNb2R1bGUsXG4gICAgICBwcm92aWRlcnM6IFt3aXRoTm9Yc3JmUHJvdGVjdGlvbigpLsm1cHJvdmlkZXJzXVxuICAgIH07XG4gIH1cbiAgc3RhdGljIHdpdGhPcHRpb25zKG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogSHR0cENsaWVudFhzcmZNb2R1bGUsXG4gICAgICBwcm92aWRlcnM6IHdpdGhYc3JmQ29uZmlndXJhdGlvbihvcHRpb25zKS7JtXByb3ZpZGVyc1xuICAgIH07XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSHR0cENsaWVudFhzcmZNb2R1bGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEh0dHBDbGllbnRYc3JmTW9kdWxlKSgpO1xuICB9O1xuICBzdGF0aWMgybVtb2QgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lTmdNb2R1bGUoe1xuICAgIHR5cGU6IEh0dHBDbGllbnRYc3JmTW9kdWxlXG4gIH0pO1xuICBzdGF0aWMgybVpbmogPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0b3Ioe1xuICAgIHByb3ZpZGVyczogW0h0dHBYc3JmSW50ZXJjZXB0b3IsIHtcbiAgICAgIHByb3ZpZGU6IEhUVFBfSU5URVJDRVBUT1JTLFxuICAgICAgdXNlRXhpc3Rpbmc6IEh0dHBYc3JmSW50ZXJjZXB0b3IsXG4gICAgICBtdWx0aTogdHJ1ZVxuICAgIH0sIHtcbiAgICAgIHByb3ZpZGU6IEh0dHBYc3JmVG9rZW5FeHRyYWN0b3IsXG4gICAgICB1c2VDbGFzczogSHR0cFhzcmZDb29raWVFeHRyYWN0b3JcbiAgICB9LCB3aXRoWHNyZkNvbmZpZ3VyYXRpb24oe1xuICAgICAgY29va2llTmFtZTogWFNSRl9ERUZBVUxUX0NPT0tJRV9OQU1FLFxuICAgICAgaGVhZGVyTmFtZTogWFNSRl9ERUZBVUxUX0hFQURFUl9OQU1FXG4gICAgfSkuybVwcm92aWRlcnMsIHtcbiAgICAgIHByb3ZpZGU6IFhTUkZfRU5BQkxFRCxcbiAgICAgIHVzZVZhbHVlOiB0cnVlXG4gICAgfV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShIdHRwQ2xpZW50WHNyZk1vZHVsZSwgW3tcbiAgICB0eXBlOiBOZ01vZHVsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZXJzOiBbSHR0cFhzcmZJbnRlcmNlcHRvciwge1xuICAgICAgICBwcm92aWRlOiBIVFRQX0lOVEVSQ0VQVE9SUyxcbiAgICAgICAgdXNlRXhpc3Rpbmc6IEh0dHBYc3JmSW50ZXJjZXB0b3IsXG4gICAgICAgIG11bHRpOiB0cnVlXG4gICAgICB9LCB7XG4gICAgICAgIHByb3ZpZGU6IEh0dHBYc3JmVG9rZW5FeHRyYWN0b3IsXG4gICAgICAgIHVzZUNsYXNzOiBIdHRwWHNyZkNvb2tpZUV4dHJhY3RvclxuICAgICAgfSwgd2l0aFhzcmZDb25maWd1cmF0aW9uKHtcbiAgICAgICAgY29va2llTmFtZTogWFNSRl9ERUZBVUxUX0NPT0tJRV9OQU1FLFxuICAgICAgICBoZWFkZXJOYW1lOiBYU1JGX0RFRkFVTFRfSEVBREVSX05BTUVcbiAgICAgIH0pLsm1cHJvdmlkZXJzLCB7XG4gICAgICAgIHByb3ZpZGU6IFhTUkZfRU5BQkxFRCxcbiAgICAgICAgdXNlVmFsdWU6IHRydWVcbiAgICAgIH1dXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIEh0dHBDbGllbnRNb2R1bGUge1xuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBIdHRwQ2xpZW50TW9kdWxlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBIdHRwQ2xpZW50TW9kdWxlKSgpO1xuICB9O1xuICBzdGF0aWMgybVtb2QgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lTmdNb2R1bGUoe1xuICAgIHR5cGU6IEh0dHBDbGllbnRNb2R1bGVcbiAgfSk7XG4gIHN0YXRpYyDJtWluaiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3Rvcih7XG4gICAgcHJvdmlkZXJzOiBbcHJvdmlkZUh0dHBDbGllbnQod2l0aEludGVyY2VwdG9yc0Zyb21EaSgpLCB3aXRoWGhyKCkpXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEh0dHBDbGllbnRNb2R1bGUsIFt7XG4gICAgdHlwZTogTmdNb2R1bGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVyczogW3Byb3ZpZGVIdHRwQ2xpZW50KHdpdGhJbnRlcmNlcHRvcnNGcm9tRGkoKSwgd2l0aFhocigpKV1cbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY2xhc3MgSHR0cENsaWVudEpzb25wTW9kdWxlIHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gSHR0cENsaWVudEpzb25wTW9kdWxlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBIdHRwQ2xpZW50SnNvbnBNb2R1bGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtW1vZCA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVOZ01vZHVsZSh7XG4gICAgdHlwZTogSHR0cENsaWVudEpzb25wTW9kdWxlXG4gIH0pO1xuICBzdGF0aWMgybVpbmogPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0b3Ioe1xuICAgIHByb3ZpZGVyczogW3dpdGhKc29ucFN1cHBvcnQoKS7JtXByb3ZpZGVyc11cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShIdHRwQ2xpZW50SnNvbnBNb2R1bGUsIFt7XG4gICAgdHlwZTogTmdNb2R1bGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVyczogW3dpdGhKc29ucFN1cHBvcnQoKS7JtXByb3ZpZGVyc11cbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuZXhwb3J0IHsgRmV0Y2hCYWNrZW5kLCBIVFRQX0ZFVENIX01BWF9SRVNQT05TRV9TSVpFLCBIVFRQX0lOVEVSQ0VQVE9SUywgSFRUUF9ST09UX0lOVEVSQ0VQVE9SX0ZOUywgSHR0cEJhY2tlbmQsIEh0dHBDbGllbnQsIEh0dHBDbGllbnRKc29ucE1vZHVsZSwgSHR0cENsaWVudE1vZHVsZSwgSHR0cENsaWVudFhzcmZNb2R1bGUsIEh0dHBDb250ZXh0LCBIdHRwQ29udGV4dFRva2VuLCBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cEV2ZW50VHlwZSwgSHR0cEZlYXR1cmVLaW5kLCBIdHRwSGFuZGxlciwgSHR0cEhlYWRlclJlc3BvbnNlLCBIdHRwSGVhZGVycywgSHR0cEludGVyY2VwdG9ySGFuZGxlciwgSHR0cFBhcmFtcywgSHR0cFJlcXVlc3QsIEh0dHBSZXNwb25zZSwgSHR0cFJlc3BvbnNlQmFzZSwgSHR0cFN0YXR1c0NvZGUsIEh0dHBVcmxFbmNvZGluZ0NvZGVjLCBIdHRwWGhyQmFja2VuZCwgSHR0cFhzcmZUb2tlbkV4dHJhY3RvciwgSnNvbnBDbGllbnRCYWNrZW5kLCBKc29ucEludGVyY2VwdG9yLCBSRVFVRVNUU19DT05UUklCVVRFX1RPX1NUQUJJTElUWSwgcHJvdmlkZUh0dHBDbGllbnQsIHdpdGhGZXRjaCwgd2l0aEludGVyY2VwdG9ycywgd2l0aEludGVyY2VwdG9yc0Zyb21EaSwgd2l0aEpzb25wU3VwcG9ydCwgd2l0aE5vWHNyZlByb3RlY3Rpb24sIHdpdGhSZXF1ZXN0c01hZGVWaWFQYXJlbnQsIHdpdGhYaHIsIHdpdGhYc3JmQ29uZmlndXJhdGlvbiB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9X21vZHVsZS1jaHVuay5tanMubWFwIiwiLyoqXG4gKiBAbGljZW5zZSBBbmd1bGFyIHYyMi4xLjJcbiAqIChjKSAyMDEwLTIwMjYgR29vZ2xlIExMQy4gaHR0cHM6Ly9hbmd1bGFyLmRldi9cbiAqIExpY2Vuc2U6IE1JVFxuICovXG5cbmltcG9ydCB7IEhUVFBfUk9PVF9JTlRFUkNFUFRPUl9GTlMsIEh0dHBSZXNwb25zZSwgSHR0cEhlYWRlcnMsIEh0dHBFcnJvclJlc3BvbnNlLCBIdHRwRXZlbnRUeXBlLCBIdHRwQ2xpZW50LCBIdHRwUGFyYW1zLCBIdHRwUmVxdWVzdCB9IGZyb20gJy4vX21vZHVsZS1jaHVuay5tanMnO1xuZXhwb3J0IHsgRmV0Y2hCYWNrZW5kLCBIVFRQX0lOVEVSQ0VQVE9SUywgSHR0cEJhY2tlbmQsIEh0dHBDbGllbnRKc29ucE1vZHVsZSwgSHR0cENsaWVudE1vZHVsZSwgSHR0cENsaWVudFhzcmZNb2R1bGUsIEh0dHBDb250ZXh0LCBIdHRwQ29udGV4dFRva2VuLCBIdHRwRmVhdHVyZUtpbmQsIEh0dHBIYW5kbGVyLCBIdHRwSGVhZGVyUmVzcG9uc2UsIEh0dHBSZXNwb25zZUJhc2UsIEh0dHBTdGF0dXNDb2RlLCBIdHRwVXJsRW5jb2RpbmdDb2RlYywgSHR0cFhockJhY2tlbmQsIEh0dHBYc3JmVG9rZW5FeHRyYWN0b3IsIEpzb25wQ2xpZW50QmFja2VuZCwgSnNvbnBJbnRlcmNlcHRvciwgcHJvdmlkZUh0dHBDbGllbnQsIHdpdGhGZXRjaCwgd2l0aEludGVyY2VwdG9ycywgd2l0aEludGVyY2VwdG9yc0Zyb21EaSwgd2l0aEpzb25wU3VwcG9ydCwgd2l0aE5vWHNyZlByb3RlY3Rpb24sIHdpdGhSZXF1ZXN0c01hZGVWaWFQYXJlbnQsIHdpdGhYaHIsIHdpdGhYc3JmQ29uZmlndXJhdGlvbiwgSFRUUF9GRVRDSF9NQVhfUkVTUE9OU0VfU0laRSBhcyDJtUhUVFBfRkVUQ0hfTUFYX1JFU1BPTlNFX1NJWkUsIEh0dHBJbnRlcmNlcHRvckhhbmRsZXIgYXMgybVIdHRwSW50ZXJjZXB0aW5nSGFuZGxlciwgUkVRVUVTVFNfQ09OVFJJQlVURV9UT19TVEFCSUxJVFkgYXMgybVSRVFVRVNUU19DT05UUklCVVRFX1RPX1NUQUJJTElUWSB9IGZyb20gJy4vX21vZHVsZS1jaHVuay5tanMnO1xuaW1wb3J0IHsgSW5qZWN0aW9uVG9rZW4sIEFQUF9CT09UU1RSQVBfTElTVEVORVIsIMm1cGVyZm9ybWFuY2VNYXJrRmVhdHVyZSBhcyBfcGVyZm9ybWFuY2VNYXJrRmVhdHVyZSwgaW5qZWN0LCBBcHBsaWNhdGlvblJlZiwgVHJhbnNmZXJTdGF0ZSwgbWFrZVN0YXRlS2V5LCDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCDJtXRydW5jYXRlTWlkZGxlIGFzIF90cnVuY2F0ZU1pZGRsZSwgybVmb3JtYXRSdW50aW1lRXJyb3IgYXMgX2Zvcm1hdFJ1bnRpbWVFcnJvciwgYXNzZXJ0SW5JbmplY3Rpb25Db250ZXh0LCBJbmplY3Rvciwgc2lnbmFsLCDJtVJlc291cmNlSW1wbCBhcyBfUmVzb3VyY2VJbXBsLCBsaW5rZWRTaWduYWwsIGNvbXB1dGVkLCDJtWVuY2Fwc3VsYXRlUmVzb3VyY2VFcnJvciBhcyBfZW5jYXBzdWxhdGVSZXNvdXJjZUVycm9yIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBvZiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0ICcuL194aHItY2h1bmsubWpzJztcbmltcG9ydCAnLi9fcGxhdGZvcm1fbG9jYXRpb24tY2h1bmsubWpzJztcblxuY29uc3QgSFRUUF9UUkFOU0ZFUl9DQUNIRV9PUklHSU5fTUFQID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdIVFRQX1RSQU5TRkVSX0NBQ0hFX09SSUdJTl9NQVAnIDogJycpO1xuY29uc3QgQk9EWSA9ICdiJztcbmNvbnN0IEhFQURFUlMgPSAnaCc7XG5jb25zdCBTVEFUVVMgPSAncyc7XG5jb25zdCBTVEFUVVNfVEVYVCA9ICdzdCc7XG5jb25zdCBSRVFfVVJMID0gJ3UnO1xuY29uc3QgUkVTUE9OU0VfVFlQRSA9ICdydCc7XG5jb25zdCBDQUNIRV9PUFRJT05TID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdIVFRQX1RSQU5TRkVSX1NUQVRFX0NBQ0hFX09QVElPTlMnIDogJycpO1xuY29uc3QgQUxMT1dFRF9NRVRIT0RTID0gWydHRVQnLCAnSEVBRCddO1xuZnVuY3Rpb24gY2FuVXNlT3JDYWNoZVJlcXVlc3QocmVxLCBvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBpc0NhY2hlQWN0aXZlLFxuICAgIGZpbHRlcixcbiAgICBpbmNsdWRlUG9zdFJlcXVlc3RzLFxuICAgIGluY2x1ZGVSZXF1ZXN0c1dpdGhBdXRoSGVhZGVycyxcbiAgICBpbmNsdWRlUmVxdWVzdHNXaXRoQ3JlZGVudGlhbHMsXG4gICAgaW5jbHVkZU5vbkNhY2hlYWJsZVJlcXVlc3RzXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCB7XG4gICAgdHJhbnNmZXJDYWNoZTogcmVxdWVzdE9wdGlvbnMsXG4gICAgbWV0aG9kOiByZXF1ZXN0TWV0aG9kXG4gIH0gPSByZXE7XG4gIGlmICghaXNDYWNoZUFjdGl2ZSB8fCByZXF1ZXN0T3B0aW9ucyA9PT0gZmFsc2UgfHwgcmVxdWVzdE1ldGhvZCA9PT0gJ1BPU1QnICYmICFpbmNsdWRlUG9zdFJlcXVlc3RzICYmICFyZXF1ZXN0T3B0aW9ucyB8fCByZXF1ZXN0TWV0aG9kICE9PSAnUE9TVCcgJiYgIUFMTE9XRURfTUVUSE9EUy5pbmNsdWRlcyhyZXF1ZXN0TWV0aG9kKSB8fCAhaW5jbHVkZVJlcXVlc3RzV2l0aEF1dGhIZWFkZXJzICYmIGhhc0F1dGhIZWFkZXJzKHJlcSkgfHwgIWluY2x1ZGVSZXF1ZXN0c1dpdGhDcmVkZW50aWFscyAmJiBoYXNPdXRnb2luZ0NyZWRlbnRpYWxzKHJlcSkgfHwgIWluY2x1ZGVOb25DYWNoZWFibGVSZXF1ZXN0cyAmJiAoaGFzVW5jYWNoZWFibGVDYWNoZUNvbnRyb2wocmVxLmhlYWRlcnMpIHx8IGlzTm9uQ2FjaGVhYmxlUmVxdWVzdChyZXEuY2FjaGUpKSB8fCBmaWx0ZXI/LihyZXEpID09PSBmYWxzZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGdldEhlYWRlcnNUb0luY2x1ZGUob3B0aW9ucywgcmVxdWVzdE9wdGlvbnMpIHtcbiAgcmV0dXJuIHR5cGVvZiByZXF1ZXN0T3B0aW9ucyA9PT0gJ29iamVjdCcgJiYgcmVxdWVzdE9wdGlvbnMuaW5jbHVkZUhlYWRlcnMgPyByZXF1ZXN0T3B0aW9ucy5pbmNsdWRlSGVhZGVycyA6IG9wdGlvbnMuaW5jbHVkZUhlYWRlcnM7XG59XG5mdW5jdGlvbiByZXRyaWV2ZVN0YXRlRnJvbUNhY2hlKHJlcSwgb3B0aW9ucywgdHJhbnNmZXJTdGF0ZSwgb3JpZ2luTWFwLCBzdG9yZUtleSwgc2tpcFVzZUNhY2hlQ2hlY2tzID0gZmFsc2UpIHtcbiAgaWYgKCFza2lwVXNlQ2FjaGVDaGVja3MgJiYgIWNhblVzZU9yQ2FjaGVSZXF1ZXN0KHJlcSwgb3B0aW9ucykpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAodHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgIW5nU2VydmVyTW9kZSAmJiBvcmlnaW5NYXApIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyODAzLCBuZ0Rldk1vZGUgJiYgJ0FuZ3VsYXIgZGV0ZWN0ZWQgdGhhdCB0aGUgYEhUVFBfVFJBTlNGRVJfQ0FDSEVfT1JJR0lOX01BUGAgdG9rZW4gaXMgY29uZmlndXJlZCBhbmQgJyArICdwcmVzZW50IGluIHRoZSBjbGllbnQgc2lkZSBjb2RlLiBQbGVhc2UgZW5zdXJlIHRoYXQgdGhpcyB0b2tlbiBpcyBvbmx5IHByb3ZpZGVkIGluIHRoZSAnICsgJ3NlcnZlciBjb2RlIG9mIHRoZSBhcHBsaWNhdGlvbi4nKTtcbiAgfVxuICBpZiAoIXN0b3JlS2V5KSB7XG4gICAgY29uc3QgcmVxdWVzdFVybCA9IHR5cGVvZiBuZ1NlcnZlck1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nU2VydmVyTW9kZSAmJiBvcmlnaW5NYXAgPyBtYXBSZXF1ZXN0T3JpZ2luVXJsKHJlcS51cmwsIG9yaWdpbk1hcCkgOiByZXEudXJsO1xuICAgIHN0b3JlS2V5ID0gbWFrZUNhY2hlS2V5KHJlcSwgcmVxdWVzdFVybCk7XG4gIH1cbiAgY29uc3QgcmVzcG9uc2UgPSB0cmFuc2ZlclN0YXRlLmdldChzdG9yZUtleSwgbnVsbCk7XG4gIGlmICghcmVzcG9uc2UpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCB7XG4gICAgW0JPRFldOiB1bmRlY29kZWRCb2R5LFxuICAgIFtSRVNQT05TRV9UWVBFXTogcmVzcG9uc2VUeXBlLFxuICAgIFtIRUFERVJTXTogaHR0cEhlYWRlcnMsXG4gICAgW1NUQVRVU106IHN0YXR1cyxcbiAgICBbU1RBVFVTX1RFWFRdOiBzdGF0dXNUZXh0LFxuICAgIFtSRVFfVVJMXTogdXJsXG4gIH0gPSByZXNwb25zZTtcbiAgbGV0IGJvZHkgPSB1bmRlY29kZWRCb2R5O1xuICBzd2l0Y2ggKHJlc3BvbnNlVHlwZSkge1xuICAgIGNhc2UgJ2FycmF5YnVmZmVyJzpcbiAgICAgIGJvZHkgPSBmcm9tQmFzZTY0KHVuZGVjb2RlZEJvZHkpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnYmxvYic6XG4gICAgICBib2R5ID0gbmV3IEJsb2IoW2Zyb21CYXNlNjQodW5kZWNvZGVkQm9keSldKTtcbiAgICAgIGJyZWFrO1xuICB9XG4gIGxldCBoZWFkZXJzID0gbmV3IEh0dHBIZWFkZXJzKGh0dHBIZWFkZXJzKTtcbiAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgIGNvbnN0IHtcbiAgICAgIHRyYW5zZmVyQ2FjaGU6IHJlcXVlc3RPcHRpb25zXG4gICAgfSA9IHJlcTtcbiAgICBjb25zdCBoZWFkZXJzVG9JbmNsdWRlID0gZ2V0SGVhZGVyc1RvSW5jbHVkZShvcHRpb25zLCByZXF1ZXN0T3B0aW9ucyk7XG4gICAgaGVhZGVycyA9IGFwcGVuZE1pc3NpbmdIZWFkZXJzRGV0ZWN0aW9uKHJlcS51cmwsIGhlYWRlcnMsIGhlYWRlcnNUb0luY2x1ZGUgPz8gW10pO1xuICB9XG4gIHJldHVybiBuZXcgSHR0cFJlc3BvbnNlKHtcbiAgICBib2R5LFxuICAgIGhlYWRlcnMsXG4gICAgc3RhdHVzLFxuICAgIHN0YXR1c1RleHQsXG4gICAgdXJsXG4gIH0pO1xufVxuZnVuY3Rpb24gdHJhbnNmZXJDYWNoZUludGVyY2VwdG9yRm4ocmVxLCBuZXh0KSB7XG4gIGNvbnN0IG9wdGlvbnMgPSBpbmplY3QoQ0FDSEVfT1BUSU9OUyk7XG4gIGlmICghY2FuVXNlT3JDYWNoZVJlcXVlc3QocmVxLCBvcHRpb25zKSkge1xuICAgIHJldHVybiBuZXh0KHJlcSk7XG4gIH1cbiAgY29uc3QgdHJhbnNmZXJTdGF0ZSA9IGluamVjdChUcmFuc2ZlclN0YXRlKTtcbiAgY29uc3Qgb3JpZ2luTWFwID0gaW5qZWN0KEhUVFBfVFJBTlNGRVJfQ0FDSEVfT1JJR0lOX01BUCwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICBjb25zdCByZXF1ZXN0VXJsID0gdHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdTZXJ2ZXJNb2RlICYmIG9yaWdpbk1hcCA/IG1hcFJlcXVlc3RPcmlnaW5VcmwocmVxLnVybCwgb3JpZ2luTWFwKSA6IHJlcS51cmw7XG4gIGNvbnN0IHN0b3JlS2V5ID0gbWFrZUNhY2hlS2V5KHJlcSwgcmVxdWVzdFVybCk7XG4gIGNvbnN0IGNhY2hlZFJlc3BvbnNlID0gcmV0cmlldmVTdGF0ZUZyb21DYWNoZShyZXEsIG9wdGlvbnMsIHRyYW5zZmVyU3RhdGUsIG51bGwsIHN0b3JlS2V5LCB0cnVlKTtcbiAgaWYgKGNhY2hlZFJlc3BvbnNlKSB7XG4gICAgcmV0dXJuIG9mKGNhY2hlZFJlc3BvbnNlKTtcbiAgfVxuICBjb25zdCBldmVudCQgPSBuZXh0KHJlcSk7XG4gIGlmICh0eXBlb2YgbmdTZXJ2ZXJNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ1NlcnZlck1vZGUpIHtcbiAgICByZXR1cm4gZXZlbnQkLnBpcGUodGFwKGV2ZW50ID0+IHtcbiAgICAgIGlmIChldmVudCBpbnN0YW5jZW9mIEh0dHBSZXNwb25zZSkge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgaGVhZGVycyxcbiAgICAgICAgICBib2R5LFxuICAgICAgICAgIHN0YXR1cyxcbiAgICAgICAgICBzdGF0dXNUZXh0XG4gICAgICAgIH0gPSBldmVudDtcbiAgICAgICAgaWYgKCFvcHRpb25zLmluY2x1ZGVOb25DYWNoZWFibGVSZXF1ZXN0cyAmJiAoaGFzVW5jYWNoZWFibGVDYWNoZUNvbnRyb2woaGVhZGVycykgfHwgaGFzU2V0Q29va2llSGVhZGVyKGhlYWRlcnMpKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgdHJhbnNmZXJDYWNoZTogcmVxdWVzdE9wdGlvbnMsXG4gICAgICAgICAgcmVzcG9uc2VUeXBlXG4gICAgICAgIH0gPSByZXE7XG4gICAgICAgIGNvbnN0IGhlYWRlcnNUb0luY2x1ZGUgPSBnZXRIZWFkZXJzVG9JbmNsdWRlKG9wdGlvbnMsIHJlcXVlc3RPcHRpb25zKTtcbiAgICAgICAgdHJhbnNmZXJTdGF0ZS5zZXQoc3RvcmVLZXksIHtcbiAgICAgICAgICBbQk9EWV06IHJlc3BvbnNlVHlwZSA9PT0gJ2FycmF5YnVmZmVyJyB8fCByZXNwb25zZVR5cGUgPT09ICdibG9iJyA/IHRvQmFzZTY0KGJvZHkpIDogYm9keSxcbiAgICAgICAgICBbSEVBREVSU106IGdldEZpbHRlcmVkSGVhZGVycyhoZWFkZXJzLCBoZWFkZXJzVG9JbmNsdWRlKSxcbiAgICAgICAgICBbU1RBVFVTXTogc3RhdHVzLFxuICAgICAgICAgIFtTVEFUVVNfVEVYVF06IHN0YXR1c1RleHQsXG4gICAgICAgICAgW1JFUV9VUkxdOiByZXF1ZXN0VXJsLFxuICAgICAgICAgIFtSRVNQT05TRV9UWVBFXTogcmVzcG9uc2VUeXBlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pKTtcbiAgfVxuICByZXR1cm4gZXZlbnQkO1xufVxuZnVuY3Rpb24gaGFzQXV0aEhlYWRlcnMocmVxKSB7XG4gIGNvbnN0IGhlYWRlcnMgPSByZXEuaGVhZGVycztcbiAgcmV0dXJuIGhlYWRlcnMuaGFzKCdhdXRob3JpemF0aW9uJykgfHwgaGVhZGVycy5oYXMoJ3Byb3h5LWF1dGhvcml6YXRpb24nKSB8fCBoZWFkZXJzLmhhcygnY29va2llJyk7XG59XG5jb25zdCBVTkNBQ0hFQUJMRV9DQUNIRV9DT05UUk9MX0RJUkVDVElWRVMgPSBuZXcgU2V0KFsnbm8tc3RvcmUnLCAncHJpdmF0ZScsICduby1jYWNoZSddKTtcbmZ1bmN0aW9uIGhhc1VuY2FjaGVhYmxlQ2FjaGVDb250cm9sKGhlYWRlcnMpIHtcbiAgY29uc3QgY2FjaGVDb250cm9sID0gaGVhZGVycy5nZXQoJ2NhY2hlLWNvbnRyb2wnKTtcbiAgaWYgKCFjYWNoZUNvbnRyb2wpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGNhY2hlQ29udHJvbC5zcGxpdCgnLCcpLnNvbWUoZGlyZWN0aXZlID0+IHtcbiAgICBjb25zdCBkaXJlY3RpdmVOYW1lID0gZGlyZWN0aXZlLnNwbGl0KCc9JywgMSlbMF0udHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgcmV0dXJuIFVOQ0FDSEVBQkxFX0NBQ0hFX0NPTlRST0xfRElSRUNUSVZFUy5oYXMoZGlyZWN0aXZlTmFtZSk7XG4gIH0pO1xufVxuZnVuY3Rpb24gaGFzU2V0Q29va2llSGVhZGVyKGhlYWRlcnMpIHtcbiAgcmV0dXJuIGhlYWRlcnMuaGFzKCdzZXQtY29va2llJyk7XG59XG5mdW5jdGlvbiBpc05vbkNhY2hlYWJsZVJlcXVlc3QoY2FjaGUpIHtcbiAgcmV0dXJuIGNhY2hlID09PSAnbm8tY2FjaGUnIHx8IGNhY2hlID09PSAnbm8tc3RvcmUnO1xufVxuZnVuY3Rpb24gaGFzT3V0Z29pbmdDcmVkZW50aWFscyhyZXEpIHtcbiAgY29uc3Qge1xuICAgIHdpdGhDcmVkZW50aWFscyxcbiAgICBjcmVkZW50aWFsc1xuICB9ID0gcmVxO1xuICByZXR1cm4gd2l0aENyZWRlbnRpYWxzIHx8IGNyZWRlbnRpYWxzID09PSAnaW5jbHVkZScgfHwgY3JlZGVudGlhbHMgPT09ICdzYW1lLW9yaWdpbic7XG59XG5mdW5jdGlvbiBnZXRGaWx0ZXJlZEhlYWRlcnMoaGVhZGVycywgaW5jbHVkZUhlYWRlcnMpIHtcbiAgaWYgKCFpbmNsdWRlSGVhZGVycykge1xuICAgIHJldHVybiB7fTtcbiAgfVxuICBjb25zdCBoZWFkZXJzTWFwID0ge307XG4gIGZvciAoY29uc3Qga2V5IG9mIGluY2x1ZGVIZWFkZXJzKSB7XG4gICAgY29uc3QgdmFsdWVzID0gaGVhZGVycy5nZXRBbGwoa2V5KTtcbiAgICBpZiAodmFsdWVzICE9PSBudWxsKSB7XG4gICAgICBoZWFkZXJzTWFwW2tleV0gPSB2YWx1ZXM7XG4gICAgfVxuICB9XG4gIHJldHVybiBoZWFkZXJzTWFwO1xufVxuZnVuY3Rpb24gc29ydEFuZENvbmNhdFBhcmFtcyhwYXJhbXMpIHtcbiAgY29uc3Qgc2VhcmNoUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXJhbXMgaW5zdGFuY2VvZiBVUkxTZWFyY2hQYXJhbXMgPyBwYXJhbXMgOiBwYXJhbXMudG9TdHJpbmcoKSk7XG4gIHNlYXJjaFBhcmFtcy5zb3J0KCk7XG4gIHJldHVybiBzZWFyY2hQYXJhbXMudG9TdHJpbmcoKTtcbn1cbmZ1bmN0aW9uIG1ha2VDYWNoZUtleShyZXF1ZXN0LCBtYXBwZWRSZXF1ZXN0VXJsKSB7XG4gIGNvbnN0IHtcbiAgICBwYXJhbXMsXG4gICAgbWV0aG9kLFxuICAgIHJlc3BvbnNlVHlwZVxuICB9ID0gcmVxdWVzdDtcbiAgY29uc3QgZW5jb2RlZFBhcmFtcyA9IHNvcnRBbmRDb25jYXRQYXJhbXMocGFyYW1zKTtcbiAgbGV0IHNlcmlhbGl6ZWRCb2R5ID0gcmVxdWVzdC5zZXJpYWxpemVCb2R5KCk7XG4gIGlmIChzZXJpYWxpemVkQm9keSBpbnN0YW5jZW9mIFVSTFNlYXJjaFBhcmFtcykge1xuICAgIHNlcmlhbGl6ZWRCb2R5ID0gc29ydEFuZENvbmNhdFBhcmFtcyhzZXJpYWxpemVkQm9keSk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIHNlcmlhbGl6ZWRCb2R5ICE9PSAnc3RyaW5nJykge1xuICAgIHNlcmlhbGl6ZWRCb2R5ID0gJyc7XG4gIH1cbiAgY29uc3Qga2V5ID0gW21ldGhvZCwgcmVzcG9uc2VUeXBlLCBtYXBwZWRSZXF1ZXN0VXJsLCBzZXJpYWxpemVkQm9keSwgZW5jb2RlZFBhcmFtc10uam9pbignXFwwJyk7XG4gIGNvbnN0IGhhc2ggPSBnZW5lcmF0ZUhhc2goa2V5KTtcbiAgcmV0dXJuIG1ha2VTdGF0ZUtleShoYXNoKTtcbn1cbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZmZlcikge1xuICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlcik7XG4gIGNvbnN0IENIVU5LX1NJWkUgPSAweDgwMDA7XG4gIGxldCBiaW5hcnlTdHJpbmcgPSAnJztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlcy5sZW5ndGg7IGkgKz0gQ0hVTktfU0laRSkge1xuICAgIGNvbnN0IGNodW5rID0gYnl0ZXMuc3ViYXJyYXkoaSwgaSArIENIVU5LX1NJWkUpO1xuICAgIGJpbmFyeVN0cmluZyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KG51bGwsIGNodW5rKTtcbiAgfVxuICByZXR1cm4gYnRvYShiaW5hcnlTdHJpbmcpO1xufVxuZnVuY3Rpb24gZnJvbUJhc2U2NChiYXNlNjQpIHtcbiAgY29uc3QgYmluYXJ5ID0gYXRvYihiYXNlNjQpO1xuICBjb25zdCBieXRlcyA9IFVpbnQ4QXJyYXkuZnJvbShiaW5hcnksIGMgPT4gYy5jaGFyQ29kZUF0KDApKTtcbiAgcmV0dXJuIGJ5dGVzLmJ1ZmZlcjtcbn1cbmZ1bmN0aW9uIHdpdGhIdHRwVHJhbnNmZXJDYWNoZShjYWNoZU9wdGlvbnMpIHtcbiAgcmV0dXJuIFt7XG4gICAgcHJvdmlkZTogQ0FDSEVfT1BUSU9OUyxcbiAgICB1c2VGYWN0b3J5OiAoKSA9PiB7XG4gICAgICBfcGVyZm9ybWFuY2VNYXJrRmVhdHVyZSgnTmdIdHRwVHJhbnNmZXJDYWNoZScpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaXNDYWNoZUFjdGl2ZTogdHJ1ZSxcbiAgICAgICAgLi4uY2FjaGVPcHRpb25zXG4gICAgICB9O1xuICAgIH1cbiAgfSwge1xuICAgIHByb3ZpZGU6IEhUVFBfUk9PVF9JTlRFUkNFUFRPUl9GTlMsXG4gICAgdXNlVmFsdWU6IHRyYW5zZmVyQ2FjaGVJbnRlcmNlcHRvckZuLFxuICAgIG11bHRpOiB0cnVlXG4gIH0sIHtcbiAgICBwcm92aWRlOiBBUFBfQk9PVFNUUkFQX0xJU1RFTkVSLFxuICAgIG11bHRpOiB0cnVlLFxuICAgIHVzZUZhY3Rvcnk6ICgpID0+IHtcbiAgICAgIGNvbnN0IGFwcFJlZiA9IGluamVjdChBcHBsaWNhdGlvblJlZik7XG4gICAgICBjb25zdCBjYWNoZVN0YXRlID0gaW5qZWN0KENBQ0hFX09QVElPTlMpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgYXBwUmVmLndoZW5TdGFibGUoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICBjYWNoZVN0YXRlLmlzQ2FjaGVBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgICB9O1xuICAgIH1cbiAgfV07XG59XG5mdW5jdGlvbiBhcHBlbmRNaXNzaW5nSGVhZGVyc0RldGVjdGlvbih1cmwsIGhlYWRlcnMsIGhlYWRlcnNUb0luY2x1ZGUpIHtcbiAgY29uc3Qgd2FybmluZ1Byb2R1Y2VkID0gbmV3IFNldCgpO1xuICByZXR1cm4gbmV3IFByb3h5KGhlYWRlcnMsIHtcbiAgICBnZXQodGFyZ2V0LCBwcm9wKSB7XG4gICAgICBjb25zdCB2YWx1ZSA9IFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCk7XG4gICAgICBjb25zdCBtZXRob2RzID0gbmV3IFNldChbJ2dldCcsICdoYXMnLCAnZ2V0QWxsJ10pO1xuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ2Z1bmN0aW9uJyB8fCAhbWV0aG9kcy5oYXMocHJvcCkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGhlYWRlck5hbWUgPT4ge1xuICAgICAgICBjb25zdCBrZXkgPSAocHJvcCArICc6JyArIGhlYWRlck5hbWUpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmICghaGVhZGVyc1RvSW5jbHVkZS5pbmNsdWRlcyhoZWFkZXJOYW1lKSAmJiAhd2FybmluZ1Byb2R1Y2VkLmhhcyhrZXkpKSB7XG4gICAgICAgICAgd2FybmluZ1Byb2R1Y2VkLmFkZChrZXkpO1xuICAgICAgICAgIGNvbnN0IHRydW5jYXRlZFVybCA9IF90cnVuY2F0ZU1pZGRsZSh1cmwpO1xuICAgICAgICAgIGNvbnNvbGUud2FybihfZm9ybWF0UnVudGltZUVycm9yKC0yODAyLCBgQW5ndWxhciBkZXRlY3RlZCB0aGF0IHRoZSBcXGAke2hlYWRlck5hbWV9XFxgIGhlYWRlciBpcyBhY2Nlc3NlZCwgYnV0IHRoZSB2YWx1ZSBvZiB0aGUgaGVhZGVyIGAgKyBgd2FzIG5vdCB0cmFuc2ZlcnJlZCBmcm9tIHRoZSBzZXJ2ZXIgdG8gdGhlIGNsaWVudCBieSB0aGUgSHR0cFRyYW5zZmVyQ2FjaGUuIGAgKyBgVG8gaW5jbHVkZSB0aGUgdmFsdWUgb2YgdGhlIFxcYCR7aGVhZGVyTmFtZX1cXGAgaGVhZGVyIGZvciB0aGUgXFxgJHt0cnVuY2F0ZWRVcmx9XFxgIHJlcXVlc3QsIGAgKyBgdXNlIHRoZSBcXGBpbmNsdWRlSGVhZGVyc1xcYCBsaXN0LiBUaGUgXFxgaW5jbHVkZUhlYWRlcnNcXGAgY2FuIGJlIGRlZmluZWQgZWl0aGVyIGAgKyBgb24gYSByZXF1ZXN0IGxldmVsIGJ5IGFkZGluZyB0aGUgXFxgdHJhbnNmZXJDYWNoZVxcYCBwYXJhbWV0ZXIsIG9yIG9uIGFuIGFwcGxpY2F0aW9uIGAgKyBgbGV2ZWwgYnkgYWRkaW5nIHRoZSBcXGBodHRwQ2FjaGVUcmFuc2Zlci5pbmNsdWRlSGVhZGVyc1xcYCBhcmd1bWVudCB0byB0aGUgYCArIGBcXGBwcm92aWRlQ2xpZW50SHlkcmF0aW9uKClcXGAgY2FsbC4gYCkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWx1ZS5hcHBseSh0YXJnZXQsIFtoZWFkZXJOYW1lXSk7XG4gICAgICB9O1xuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBtYXBSZXF1ZXN0T3JpZ2luVXJsKHVybCwgb3JpZ2luTWFwKSB7XG4gIGNvbnN0IG9yaWdpbiA9IG5ldyBVUkwodXJsLCAncmVzb2x2ZTovLycpLm9yaWdpbjtcbiAgY29uc3QgbWFwcGVkT3JpZ2luID0gb3JpZ2luTWFwW29yaWdpbl07XG4gIGlmICghbWFwcGVkT3JpZ2luKSB7XG4gICAgcmV0dXJuIHVybDtcbiAgfVxuICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgdmVyaWZ5TWFwcGVkT3JpZ2luKG1hcHBlZE9yaWdpbik7XG4gIH1cbiAgcmV0dXJuIHVybC5yZXBsYWNlKG9yaWdpbiwgbWFwcGVkT3JpZ2luKTtcbn1cbmZ1bmN0aW9uIHZlcmlmeU1hcHBlZE9yaWdpbih1cmwpIHtcbiAgaWYgKG5ldyBVUkwodXJsLCAncmVzb2x2ZTovLycpLnBhdGhuYW1lICE9PSAnLycpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyODA0LCAnQW5ndWxhciBkZXRlY3RlZCBhIFVSTCB3aXRoIGEgcGF0aCBzZWdtZW50IGluIHRoZSB2YWx1ZSBwcm92aWRlZCBmb3IgdGhlICcgKyBgXFxgSFRUUF9UUkFOU0ZFUl9DQUNIRV9PUklHSU5fTUFQXFxgIHRva2VuOiAke3VybH0uIFRoZSBtYXAgc2hvdWxkIG9ubHkgY29udGFpbiBvcmlnaW5zIGAgKyAnd2l0aG91dCBhbnkgb3RoZXIgc2VnbWVudHMuJyk7XG4gIH1cbn1cbmNvbnN0IFNIQTI1Nl9ST1VORF9DT05TVEFOVFMgPSAvKiBAX19QVVJFX18gKi9uZXcgVWludDMyQXJyYXkoWzB4NDI4YTJmOTgsIDB4NzEzNzQ0OTEsIDB4YjVjMGZiY2YsIDB4ZTliNWRiYTUsIDB4Mzk1NmMyNWIsIDB4NTlmMTExZjEsIDB4OTIzZjgyYTQsIDB4YWIxYzVlZDUsIDB4ZDgwN2FhOTgsIDB4MTI4MzViMDEsIDB4MjQzMTg1YmUsIDB4NTUwYzdkYzMsIDB4NzJiZTVkNzQsIDB4ODBkZWIxZmUsIDB4OWJkYzA2YTcsIDB4YzE5YmYxNzQsIDB4ZTQ5YjY5YzEsIDB4ZWZiZTQ3ODYsIDB4MGZjMTlkYzYsIDB4MjQwY2ExY2MsIDB4MmRlOTJjNmYsIDB4NGE3NDg0YWEsIDB4NWNiMGE5ZGMsIDB4NzZmOTg4ZGEsIDB4OTgzZTUxNTIsIDB4YTgzMWM2NmQsIDB4YjAwMzI3YzgsIDB4YmY1OTdmYzcsIDB4YzZlMDBiZjMsIDB4ZDVhNzkxNDcsIDB4MDZjYTYzNTEsIDB4MTQyOTI5NjcsIDB4MjdiNzBhODUsIDB4MmUxYjIxMzgsIDB4NGQyYzZkZmMsIDB4NTMzODBkMTMsIDB4NjUwYTczNTQsIDB4NzY2YTBhYmIsIDB4ODFjMmM5MmUsIDB4OTI3MjJjODUsIDB4YTJiZmU4YTEsIDB4YTgxYTY2NGIsIDB4YzI0YjhiNzAsIDB4Yzc2YzUxYTMsIDB4ZDE5MmU4MTksIDB4ZDY5OTA2MjQsIDB4ZjQwZTM1ODUsIDB4MTA2YWEwNzAsIDB4MTlhNGMxMTYsIDB4MWUzNzZjMDgsIDB4Mjc0ODc3NGMsIDB4MzRiMGJjYjUsIDB4MzkxYzBjYjMsIDB4NGVkOGFhNGEsIDB4NWI5Y2NhNGYsIDB4NjgyZTZmZjMsIDB4NzQ4ZjgyZWUsIDB4NzhhNTYzNmYsIDB4ODRjODc4MTQsIDB4OGNjNzAyMDgsIDB4OTBiZWZmZmEsIDB4YTQ1MDZjZWIsIDB4YmVmOWEzZjcsIDB4YzY3MTc4ZjJdKTtcbmxldCB0ZXh0RW5jb2RlcjtcbmZ1bmN0aW9uIGdlbmVyYXRlSGFzaCh2YWx1ZSkge1xuICB0ZXh0RW5jb2RlciA/Pz0gbmV3IFRleHRFbmNvZGVyKCk7XG4gIGNvbnN0IGlucHV0Qnl0ZXMgPSB0ZXh0RW5jb2Rlci5lbmNvZGUodmFsdWUpO1xuICBsZXQgaGFzaFN0YXRlMCA9IDB4NmEwOWU2Njc7XG4gIGxldCBoYXNoU3RhdGUxID0gMHhiYjY3YWU4NTtcbiAgbGV0IGhhc2hTdGF0ZTIgPSAweDNjNmVmMzcyO1xuICBsZXQgaGFzaFN0YXRlMyA9IDB4YTU0ZmY1M2E7XG4gIGxldCBoYXNoU3RhdGU0ID0gMHg1MTBlNTI3ZjtcbiAgbGV0IGhhc2hTdGF0ZTUgPSAweDliMDU2ODhjO1xuICBsZXQgaGFzaFN0YXRlNiA9IDB4MWY4M2Q5YWI7XG4gIGxldCBoYXNoU3RhdGU3ID0gMHg1YmUwY2QxOTtcbiAgY29uc3QgbWVzc2FnZUxlbmd0aEluQml0cyA9IGlucHV0Qnl0ZXMubGVuZ3RoICogODtcbiAgY29uc3QgcGFkZGVkTGVuZ3RoSW5CeXRlcyA9IChpbnB1dEJ5dGVzLmxlbmd0aCArIDggPj4gNikgKyAxIDw8IDY7XG4gIGNvbnN0IHBhZGRlZEJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkocGFkZGVkTGVuZ3RoSW5CeXRlcyk7XG4gIHBhZGRlZEJ5dGVzLnNldChpbnB1dEJ5dGVzKTtcbiAgcGFkZGVkQnl0ZXNbaW5wdXRCeXRlcy5sZW5ndGhdID0gMHg4MDtcbiAgY29uc3QgcGFkZGVkQnl0ZXNWaWV3ID0gbmV3IERhdGFWaWV3KHBhZGRlZEJ5dGVzLmJ1ZmZlcik7XG4gIGNvbnN0IGxvd0JpdHMgPSBtZXNzYWdlTGVuZ3RoSW5CaXRzID4+PiAwO1xuICBjb25zdCBoaWdoQml0cyA9IG1lc3NhZ2VMZW5ndGhJbkJpdHMgLyAweDEwMDAwMDAwMCA+Pj4gMDtcbiAgcGFkZGVkQnl0ZXNWaWV3LnNldFVpbnQzMihwYWRkZWRMZW5ndGhJbkJ5dGVzIC0gOCwgaGlnaEJpdHMsIGZhbHNlKTtcbiAgcGFkZGVkQnl0ZXNWaWV3LnNldFVpbnQzMihwYWRkZWRMZW5ndGhJbkJ5dGVzIC0gNCwgbG93Qml0cywgZmFsc2UpO1xuICBjb25zdCBtZXNzYWdlU2NoZWR1bGUgPSBuZXcgVWludDMyQXJyYXkoNjQpO1xuICBmb3IgKGxldCBjaHVua09mZnNldCA9IDA7IGNodW5rT2Zmc2V0IDwgcGFkZGVkTGVuZ3RoSW5CeXRlczsgY2h1bmtPZmZzZXQgKz0gNjQpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDE2OyBpKyspIHtcbiAgICAgIG1lc3NhZ2VTY2hlZHVsZVtpXSA9IHBhZGRlZEJ5dGVzVmlldy5nZXRVaW50MzIoY2h1bmtPZmZzZXQgKyBpICogNCwgZmFsc2UpO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gMTY7IGkgPCA2NDsgaSsrKSB7XG4gICAgICBjb25zdCBwcmV2V29yZDE1ID0gbWVzc2FnZVNjaGVkdWxlW2kgLSAxNV07XG4gICAgICBjb25zdCBzaWdtYTAgPSAoKHByZXZXb3JkMTUgPj4+IDcgfCBwcmV2V29yZDE1IDw8IDI1KSBeIChwcmV2V29yZDE1ID4+PiAxOCB8IHByZXZXb3JkMTUgPDwgMTQpIF4gcHJldldvcmQxNSA+Pj4gMykgPj4+IDA7XG4gICAgICBjb25zdCBwcmV2V29yZDIgPSBtZXNzYWdlU2NoZWR1bGVbaSAtIDJdO1xuICAgICAgY29uc3Qgc2lnbWExID0gKChwcmV2V29yZDIgPj4+IDE3IHwgcHJldldvcmQyIDw8IDE1KSBeIChwcmV2V29yZDIgPj4+IDE5IHwgcHJldldvcmQyIDw8IDEzKSBeIHByZXZXb3JkMiA+Pj4gMTApID4+PiAwO1xuICAgICAgbWVzc2FnZVNjaGVkdWxlW2ldID0gbWVzc2FnZVNjaGVkdWxlW2kgLSAxNl0gKyBzaWdtYTAgKyBtZXNzYWdlU2NoZWR1bGVbaSAtIDddICsgc2lnbWExID4+PiAwO1xuICAgIH1cbiAgICBsZXQgd29ya2luZ1N0YXRlQSA9IGhhc2hTdGF0ZTA7XG4gICAgbGV0IHdvcmtpbmdTdGF0ZUIgPSBoYXNoU3RhdGUxO1xuICAgIGxldCB3b3JraW5nU3RhdGVDID0gaGFzaFN0YXRlMjtcbiAgICBsZXQgd29ya2luZ1N0YXRlRCA9IGhhc2hTdGF0ZTM7XG4gICAgbGV0IHdvcmtpbmdTdGF0ZUUgPSBoYXNoU3RhdGU0O1xuICAgIGxldCB3b3JraW5nU3RhdGVGID0gaGFzaFN0YXRlNTtcbiAgICBsZXQgd29ya2luZ1N0YXRlRyA9IGhhc2hTdGF0ZTY7XG4gICAgbGV0IHdvcmtpbmdTdGF0ZUggPSBoYXNoU3RhdGU3O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNjQ7IGkrKykge1xuICAgICAgY29uc3QgY2FwaXRhbFNpZ21hMSA9ICgod29ya2luZ1N0YXRlRSA+Pj4gNiB8IHdvcmtpbmdTdGF0ZUUgPDwgMjYpIF4gKHdvcmtpbmdTdGF0ZUUgPj4+IDExIHwgd29ya2luZ1N0YXRlRSA8PCAyMSkgXiAod29ya2luZ1N0YXRlRSA+Pj4gMjUgfCB3b3JraW5nU3RhdGVFIDw8IDcpKSA+Pj4gMDtcbiAgICAgIGNvbnN0IGNoRnVuY3Rpb24gPSAod29ya2luZ1N0YXRlRSAmIHdvcmtpbmdTdGF0ZUYgXiB+d29ya2luZ1N0YXRlRSAmIHdvcmtpbmdTdGF0ZUcpID4+PiAwO1xuICAgICAgY29uc3QgdGVtcDEgPSB3b3JraW5nU3RhdGVIICsgY2FwaXRhbFNpZ21hMSArIGNoRnVuY3Rpb24gKyBTSEEyNTZfUk9VTkRfQ09OU1RBTlRTW2ldICsgbWVzc2FnZVNjaGVkdWxlW2ldID4+PiAwO1xuICAgICAgY29uc3QgY2FwaXRhbFNpZ21hMCA9ICgod29ya2luZ1N0YXRlQSA+Pj4gMiB8IHdvcmtpbmdTdGF0ZUEgPDwgMzApIF4gKHdvcmtpbmdTdGF0ZUEgPj4+IDEzIHwgd29ya2luZ1N0YXRlQSA8PCAxOSkgXiAod29ya2luZ1N0YXRlQSA+Pj4gMjIgfCB3b3JraW5nU3RhdGVBIDw8IDEwKSkgPj4+IDA7XG4gICAgICBjb25zdCBtYWpGdW5jdGlvbiA9ICh3b3JraW5nU3RhdGVBICYgd29ya2luZ1N0YXRlQiBeIHdvcmtpbmdTdGF0ZUEgJiB3b3JraW5nU3RhdGVDIF4gd29ya2luZ1N0YXRlQiAmIHdvcmtpbmdTdGF0ZUMpID4+PiAwO1xuICAgICAgY29uc3QgdGVtcDIgPSBjYXBpdGFsU2lnbWEwICsgbWFqRnVuY3Rpb24gPj4+IDA7XG4gICAgICB3b3JraW5nU3RhdGVIID0gd29ya2luZ1N0YXRlRztcbiAgICAgIHdvcmtpbmdTdGF0ZUcgPSB3b3JraW5nU3RhdGVGO1xuICAgICAgd29ya2luZ1N0YXRlRiA9IHdvcmtpbmdTdGF0ZUU7XG4gICAgICB3b3JraW5nU3RhdGVFID0gd29ya2luZ1N0YXRlRCArIHRlbXAxID4+PiAwO1xuICAgICAgd29ya2luZ1N0YXRlRCA9IHdvcmtpbmdTdGF0ZUM7XG4gICAgICB3b3JraW5nU3RhdGVDID0gd29ya2luZ1N0YXRlQjtcbiAgICAgIHdvcmtpbmdTdGF0ZUIgPSB3b3JraW5nU3RhdGVBO1xuICAgICAgd29ya2luZ1N0YXRlQSA9IHRlbXAxICsgdGVtcDIgPj4+IDA7XG4gICAgfVxuICAgIGhhc2hTdGF0ZTAgPSBoYXNoU3RhdGUwICsgd29ya2luZ1N0YXRlQSA+Pj4gMDtcbiAgICBoYXNoU3RhdGUxID0gaGFzaFN0YXRlMSArIHdvcmtpbmdTdGF0ZUIgPj4+IDA7XG4gICAgaGFzaFN0YXRlMiA9IGhhc2hTdGF0ZTIgKyB3b3JraW5nU3RhdGVDID4+PiAwO1xuICAgIGhhc2hTdGF0ZTMgPSBoYXNoU3RhdGUzICsgd29ya2luZ1N0YXRlRCA+Pj4gMDtcbiAgICBoYXNoU3RhdGU0ID0gaGFzaFN0YXRlNCArIHdvcmtpbmdTdGF0ZUUgPj4+IDA7XG4gICAgaGFzaFN0YXRlNSA9IGhhc2hTdGF0ZTUgKyB3b3JraW5nU3RhdGVGID4+PiAwO1xuICAgIGhhc2hTdGF0ZTYgPSBoYXNoU3RhdGU2ICsgd29ya2luZ1N0YXRlRyA+Pj4gMDtcbiAgICBoYXNoU3RhdGU3ID0gaGFzaFN0YXRlNyArIHdvcmtpbmdTdGF0ZUggPj4+IDA7XG4gIH1cbiAgcmV0dXJuIFtoYXNoU3RhdGUwLCBoYXNoU3RhdGUxLCBoYXNoU3RhdGUyLCBoYXNoU3RhdGUzLCBoYXNoU3RhdGU0LCBoYXNoU3RhdGU1LCBoYXNoU3RhdGU2LCBoYXNoU3RhdGU3XS5tYXAoeCA9PiB4LnRvU3RyaW5nKDE2KS5wYWRTdGFydCg4LCAnMCcpKS5qb2luKCcnKTtcbn1cblxuY29uc3QgaHR0cFJlc291cmNlID0gKCgpID0+IHtcbiAgY29uc3QganNvbkZuID0gbWFrZUh0dHBSZXNvdXJjZUZuKCdqc29uJyk7XG4gIGpzb25Gbi5hcnJheUJ1ZmZlciA9IG1ha2VIdHRwUmVzb3VyY2VGbignYXJyYXlidWZmZXInKTtcbiAganNvbkZuLmJsb2IgPSBtYWtlSHR0cFJlc291cmNlRm4oJ2Jsb2InKTtcbiAganNvbkZuLnRleHQgPSBtYWtlSHR0cFJlc291cmNlRm4oJ3RleHQnKTtcbiAgcmV0dXJuIGpzb25Gbjtcbn0pKCk7XG5mdW5jdGlvbiBtYWtlSHR0cFJlc291cmNlRm4ocmVzcG9uc2VUeXBlKSB7XG4gIHJldHVybiBmdW5jdGlvbiBodHRwUmVzb3VyY2UocmVxdWVzdCwgb3B0aW9ucykge1xuICAgIGlmIChuZ0Rldk1vZGUgJiYgIW9wdGlvbnM/LmluamVjdG9yKSB7XG4gICAgICBhc3NlcnRJbkluamVjdGlvbkNvbnRleHQoaHR0cFJlc291cmNlKTtcbiAgICB9XG4gICAgY29uc3QgaW5qZWN0b3IgPSBvcHRpb25zPy5pbmplY3RvciA/PyBpbmplY3QoSW5qZWN0b3IpO1xuICAgIGNvbnN0IGNhY2hlT3B0aW9ucyA9IGluamVjdG9yLmdldChDQUNIRV9PUFRJT05TLCBudWxsLCB7XG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0pO1xuICAgIGNvbnN0IHRyYW5zZmVyU3RhdGUgPSBpbmplY3Rvci5nZXQoVHJhbnNmZXJTdGF0ZSwgbnVsbCwge1xuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9KTtcbiAgICBjb25zdCBvcmlnaW5NYXAgPSBpbmplY3Rvci5nZXQoSFRUUF9UUkFOU0ZFUl9DQUNIRV9PUklHSU5fTUFQLCBudWxsLCB7XG4gICAgICBvcHRpb25hbDogdHJ1ZVxuICAgIH0pO1xuICAgIGNvbnN0IGdldEluaXRpYWxTdHJlYW0gPSByZXEgPT4ge1xuICAgICAgaWYgKGNhY2hlT3B0aW9ucyAmJiB0cmFuc2ZlclN0YXRlICYmIHJlcSkge1xuICAgICAgICBjb25zdCBjYWNoZWRSZXNwb25zZSA9IHJldHJpZXZlU3RhdGVGcm9tQ2FjaGUocmVxLCBjYWNoZU9wdGlvbnMsIHRyYW5zZmVyU3RhdGUsIG9yaWdpbk1hcCk7XG4gICAgICAgIGlmIChjYWNoZWRSZXNwb25zZSkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBib2R5ID0gY2FjaGVkUmVzcG9uc2UuYm9keTtcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IG9wdGlvbnM/LnBhcnNlID8gb3B0aW9ucy5wYXJzZShib2R5KSA6IGJvZHk7XG4gICAgICAgICAgICByZXR1cm4gc2lnbmFsKHtcbiAgICAgICAgICAgICAgdmFsdWU6IHBhcnNlZFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oYEFuZ3VsYXIgZGV0ZWN0ZWQgYW4gZXJyb3Igd2hpbGUgcGFyc2luZyB0aGUgY2FjaGVkIHJlc3BvbnNlIGZvciB0aGUgaHR0cFJlc291cmNlIGF0IFxcYCR7cmVxLnVybH1cXGAuIGAgKyBgVGhlIHJlc291cmNlIHdpbGwgZmFsbCBiYWNrIHRvIGl0cyBkZWZhdWx0IHZhbHVlIGFuZCB0cnkgYWdhaW4gYXN5bmNocm9ub3VzbHkuYCwgZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH07XG4gICAgcmV0dXJuIG5ldyBIdHRwUmVzb3VyY2VJbXBsKGluamVjdG9yLCBjdHggPT4gbm9ybWFsaXplUmVxdWVzdChjdHgsIHJlcXVlc3QsIHJlc3BvbnNlVHlwZSksIG9wdGlvbnM/LmRlZmF1bHRWYWx1ZSwgb3B0aW9ucz8uZGVidWdOYW1lLCBvcHRpb25zPy5wYXJzZSwgb3B0aW9ucz8uZXF1YWwsIGdldEluaXRpYWxTdHJlYW0pO1xuICB9O1xufVxuZnVuY3Rpb24gbm9ybWFsaXplUmVxdWVzdChjdHgsIHJlcXVlc3QsIHJlc3BvbnNlVHlwZSkge1xuICBsZXQgdW53cmFwcGVkUmVxdWVzdCA9IHR5cGVvZiByZXF1ZXN0ID09PSAnZnVuY3Rpb24nID8gcmVxdWVzdChjdHgpIDogcmVxdWVzdDtcbiAgaWYgKHVud3JhcHBlZFJlcXVlc3QgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH0gZWxzZSBpZiAodHlwZW9mIHVud3JhcHBlZFJlcXVlc3QgPT09ICdzdHJpbmcnKSB7XG4gICAgdW53cmFwcGVkUmVxdWVzdCA9IHtcbiAgICAgIHVybDogdW53cmFwcGVkUmVxdWVzdFxuICAgIH07XG4gIH1cbiAgY29uc3QgaGVhZGVycyA9IHVud3JhcHBlZFJlcXVlc3QuaGVhZGVycyBpbnN0YW5jZW9mIEh0dHBIZWFkZXJzID8gdW53cmFwcGVkUmVxdWVzdC5oZWFkZXJzIDogbmV3IEh0dHBIZWFkZXJzKHVud3JhcHBlZFJlcXVlc3QuaGVhZGVycyk7XG4gIGNvbnN0IHBhcmFtcyA9IHVud3JhcHBlZFJlcXVlc3QucGFyYW1zIGluc3RhbmNlb2YgSHR0cFBhcmFtcyA/IHVud3JhcHBlZFJlcXVlc3QucGFyYW1zIDogbmV3IEh0dHBQYXJhbXMoe1xuICAgIGZyb21PYmplY3Q6IHVud3JhcHBlZFJlcXVlc3QucGFyYW1zXG4gIH0pO1xuICByZXR1cm4gbmV3IEh0dHBSZXF1ZXN0KHVud3JhcHBlZFJlcXVlc3QubWV0aG9kID8/ICdHRVQnLCB1bndyYXBwZWRSZXF1ZXN0LnVybCwgdW53cmFwcGVkUmVxdWVzdC5ib2R5ID8/IG51bGwsIHtcbiAgICBoZWFkZXJzLFxuICAgIHBhcmFtcyxcbiAgICByZXBvcnRQcm9ncmVzczogdW53cmFwcGVkUmVxdWVzdC5yZXBvcnRQcm9ncmVzcyxcbiAgICB3aXRoQ3JlZGVudGlhbHM6IHVud3JhcHBlZFJlcXVlc3Qud2l0aENyZWRlbnRpYWxzLFxuICAgIGtlZXBhbGl2ZTogdW53cmFwcGVkUmVxdWVzdC5rZWVwYWxpdmUsXG4gICAgY2FjaGU6IHVud3JhcHBlZFJlcXVlc3QuY2FjaGUsXG4gICAgcHJpb3JpdHk6IHVud3JhcHBlZFJlcXVlc3QucHJpb3JpdHksXG4gICAgbW9kZTogdW53cmFwcGVkUmVxdWVzdC5tb2RlLFxuICAgIHJlZGlyZWN0OiB1bndyYXBwZWRSZXF1ZXN0LnJlZGlyZWN0LFxuICAgIHJlc3BvbnNlVHlwZSxcbiAgICBjb250ZXh0OiB1bndyYXBwZWRSZXF1ZXN0LmNvbnRleHQsXG4gICAgdHJhbnNmZXJDYWNoZTogdW53cmFwcGVkUmVxdWVzdC50cmFuc2ZlckNhY2hlLFxuICAgIGNyZWRlbnRpYWxzOiB1bndyYXBwZWRSZXF1ZXN0LmNyZWRlbnRpYWxzLFxuICAgIHJlZmVycmVyOiB1bndyYXBwZWRSZXF1ZXN0LnJlZmVycmVyLFxuICAgIHJlZmVycmVyUG9saWN5OiB1bndyYXBwZWRSZXF1ZXN0LnJlZmVycmVyUG9saWN5LFxuICAgIGludGVncml0eTogdW53cmFwcGVkUmVxdWVzdC5pbnRlZ3JpdHksXG4gICAgdGltZW91dDogdW53cmFwcGVkUmVxdWVzdC50aW1lb3V0XG4gIH0pO1xufVxuY2xhc3MgSHR0cFJlc291cmNlSW1wbCBleHRlbmRzIF9SZXNvdXJjZUltcGwge1xuICBjbGllbnQ7XG4gIF9oZWFkZXJzID0gbGlua2VkU2lnbmFsKHtcbiAgICAuLi4obmdEZXZNb2RlID8ge1xuICAgICAgZGVidWdOYW1lOiBcIl9oZWFkZXJzXCJcbiAgICB9IDoge30pLFxuICAgIHNvdXJjZTogdGhpcy5leHRSZXF1ZXN0LFxuICAgIGNvbXB1dGF0aW9uOiAoKSA9PiB1bmRlZmluZWRcbiAgfSk7XG4gIF9wcm9ncmVzcyA9IGxpbmtlZFNpZ25hbCh7XG4gICAgLi4uKG5nRGV2TW9kZSA/IHtcbiAgICAgIGRlYnVnTmFtZTogXCJfcHJvZ3Jlc3NcIlxuICAgIH0gOiB7fSksXG4gICAgc291cmNlOiB0aGlzLmV4dFJlcXVlc3QsXG4gICAgY29tcHV0YXRpb246ICgpID0+IHVuZGVmaW5lZFxuICB9KTtcbiAgX3N0YXR1c0NvZGUgPSBsaW5rZWRTaWduYWwoe1xuICAgIC4uLihuZ0Rldk1vZGUgPyB7XG4gICAgICBkZWJ1Z05hbWU6IFwiX3N0YXR1c0NvZGVcIlxuICAgIH0gOiB7fSksXG4gICAgc291cmNlOiB0aGlzLmV4dFJlcXVlc3QsXG4gICAgY29tcHV0YXRpb246ICgpID0+IHVuZGVmaW5lZFxuICB9KTtcbiAgaGVhZGVycyA9IGNvbXB1dGVkKCgpID0+IHRoaXMuc3RhdHVzKCkgPT09ICdyZXNvbHZlZCcgfHwgdGhpcy5zdGF0dXMoKSA9PT0gJ2Vycm9yJyA/IHRoaXMuX2hlYWRlcnMoKSA6IHVuZGVmaW5lZCwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgZGVidWdOYW1lOiBcImhlYWRlcnNcIlxuICB9XSA6IFtdKSk7XG4gIHByb2dyZXNzID0gdGhpcy5fcHJvZ3Jlc3MuYXNSZWFkb25seSgpO1xuICBzdGF0dXNDb2RlID0gdGhpcy5fc3RhdHVzQ29kZS5hc1JlYWRvbmx5KCk7XG4gIGNvbnN0cnVjdG9yKGluamVjdG9yLCByZXF1ZXN0LCBkZWZhdWx0VmFsdWUsIGRlYnVnTmFtZSwgcGFyc2UsIGVxdWFsLCBnZXRJbml0aWFsU3RyZWFtKSB7XG4gICAgc3VwZXIocmVxdWVzdCwgKHtcbiAgICAgIHBhcmFtczogcmVxdWVzdCxcbiAgICAgIGFib3J0U2lnbmFsXG4gICAgfSkgPT4ge1xuICAgICAgbGV0IHN1YjtcbiAgICAgIGxldCBhYm9ydGVkID0gZmFsc2U7XG4gICAgICBjb25zdCBvbkFib3J0ID0gKCkgPT4ge1xuICAgICAgICBhYm9ydGVkID0gdHJ1ZTtcbiAgICAgICAgc3ViPy51bnN1YnNjcmliZSgpO1xuICAgICAgfTtcbiAgICAgIGFib3J0U2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0Jywgb25BYm9ydCk7XG4gICAgICBjb25zdCBzdHJlYW0gPSBzaWduYWwoe1xuICAgICAgICB2YWx1ZTogdW5kZWZpbmVkXG4gICAgICB9LCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICAgICAgZGVidWdOYW1lOiBcInN0cmVhbVwiXG4gICAgICB9XSA6IFtdKSk7XG4gICAgICBsZXQgcmVzb2x2ZTtcbiAgICAgIGNvbnN0IHByb21pc2UgPSBuZXcgUHJvbWlzZShyID0+IHJlc29sdmUgPSByKTtcbiAgICAgIGNvbnN0IHNlbmQgPSB2YWx1ZSA9PiB7XG4gICAgICAgIHN0cmVhbS5zZXQodmFsdWUpO1xuICAgICAgICByZXNvbHZlPy4oc3RyZWFtKTtcbiAgICAgICAgcmVzb2x2ZSA9IHVuZGVmaW5lZDtcbiAgICAgIH07XG4gICAgICBzdWIgPSB0aGlzLmNsaWVudC5yZXF1ZXN0KHJlcXVlc3QpLnN1YnNjcmliZSh7XG4gICAgICAgIG5leHQ6IGV2ZW50ID0+IHtcbiAgICAgICAgICBzd2l0Y2ggKGV2ZW50LnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgSHR0cEV2ZW50VHlwZS5SZXNwb25zZTpcbiAgICAgICAgICAgICAgdGhpcy5faGVhZGVycy5zZXQoZXZlbnQuaGVhZGVycyk7XG4gICAgICAgICAgICAgIHRoaXMuX3N0YXR1c0NvZGUuc2V0KGV2ZW50LnN0YXR1cyk7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgc2VuZCh7XG4gICAgICAgICAgICAgICAgICB2YWx1ZTogcGFyc2UgPyBwYXJzZShldmVudC5ib2R5KSA6IGV2ZW50LmJvZHlcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBzZW5kKHtcbiAgICAgICAgICAgICAgICAgIGVycm9yOiBfZW5jYXBzdWxhdGVSZXNvdXJjZUVycm9yKGVycm9yKVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBIdHRwRXZlbnRUeXBlLkRvd25sb2FkUHJvZ3Jlc3M6XG4gICAgICAgICAgICAgIHRoaXMuX3Byb2dyZXNzLnNldChldmVudCk7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IGVycm9yID0+IHtcbiAgICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBIdHRwRXJyb3JSZXNwb25zZSkge1xuICAgICAgICAgICAgdGhpcy5faGVhZGVycy5zZXQoZXJyb3IuaGVhZGVycyk7XG4gICAgICAgICAgICB0aGlzLl9zdGF0dXNDb2RlLnNldChlcnJvci5zdGF0dXMpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBzZW5kKHtcbiAgICAgICAgICAgIGVycm9yXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgYWJvcnRTaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkFib3J0KTtcbiAgICAgICAgfSxcbiAgICAgICAgY29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgICBpZiAocmVzb2x2ZSkge1xuICAgICAgICAgICAgc2VuZCh7XG4gICAgICAgICAgICAgIGVycm9yOiBuZXcgX1J1bnRpbWVFcnJvcig5OTEsIG5nRGV2TW9kZSAmJiAnUmVzb3VyY2UgY29tcGxldGVkIGJlZm9yZSBwcm9kdWNpbmcgYSB2YWx1ZScpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYWJvcnRTaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkFib3J0KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoYWJvcnRlZCkge1xuICAgICAgICBzdWIudW5zdWJzY3JpYmUoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBwcm9taXNlO1xuICAgIH0sIGRlZmF1bHRWYWx1ZSwgZXF1YWwsIGRlYnVnTmFtZSwgaW5qZWN0b3IsIHVuZGVmaW5lZCwgZ2V0SW5pdGlhbFN0cmVhbSk7XG4gICAgdGhpcy5jbGllbnQgPSBpbmplY3Rvci5nZXQoSHR0cENsaWVudCk7XG4gIH1cbiAgc2V0KHZhbHVlKSB7XG4gICAgc3VwZXIuc2V0KHZhbHVlKTtcbiAgICB0aGlzLl9oZWFkZXJzLnNldCh1bmRlZmluZWQpO1xuICAgIHRoaXMuX3Byb2dyZXNzLnNldCh1bmRlZmluZWQpO1xuICAgIHRoaXMuX3N0YXR1c0NvZGUuc2V0KHVuZGVmaW5lZCk7XG4gIH1cbn1cblxuZXhwb3J0IHsgSFRUUF9UUkFOU0ZFUl9DQUNIRV9PUklHSU5fTUFQLCBIdHRwQ2xpZW50LCBIdHRwRXJyb3JSZXNwb25zZSwgSHR0cEV2ZW50VHlwZSwgSHR0cEhlYWRlcnMsIEh0dHBQYXJhbXMsIEh0dHBSZXF1ZXN0LCBIdHRwUmVzcG9uc2UsIGh0dHBSZXNvdXJjZSwgSFRUUF9ST09UX0lOVEVSQ0VQVE9SX0ZOUyBhcyDJtUhUVFBfUk9PVF9JTlRFUkNFUFRPUl9GTlMsIHdpdGhIdHRwVHJhbnNmZXJDYWNoZSBhcyDJtXdpdGhIdHRwVHJhbnNmZXJDYWNoZSB9O1xuXG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMV0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVlBLElBQU0sY0FBTixNQUFNLFlBQVk7Q0FLaEIsWUFBWSxTQUFTO3dCQUpyQixXQUFBLEtBQUEsQ0FBQTt3QkFDQSxtQ0FBa0IsSUFBSSxJQUFJLENBQUE7d0JBQzFCLFlBQUEsS0FBQSxDQUFBO3dCQUNBLGNBQWEsSUFBQTtFQUVYLElBQUksQ0FBQyxTQUNILEtBQUssMEJBQVUsSUFBSSxJQUFJO09BQ2xCLElBQUksT0FBTyxZQUFZLFVBQzVCLEtBQUssaUJBQWlCO0dBQ3BCLEtBQUssMEJBQVUsSUFBSSxJQUFJO0dBQ3ZCLFFBQVEsTUFBTSxJQUFJLENBQUMsQ0FBQyxTQUFRLFNBQVE7SUFDbEMsTUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHO0lBQzlCLElBQUksUUFBUSxHQUFHO0tBQ2IsTUFBTSxPQUFPLEtBQUssTUFBTSxHQUFHLEtBQUs7S0FDaEMsTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUs7S0FDekMsS0FBSyxlQUFlLE1BQU0sS0FBSztJQUNqQztHQUNGLENBQUM7RUFDSDtPQUNLLElBQUksT0FBTyxZQUFZLGVBQWUsbUJBQW1CLFNBQVM7R0FDdkUsS0FBSywwQkFBVSxJQUFJLElBQUk7R0FDdkIsUUFBUSxTQUFTLE9BQU8sU0FBUztJQUMvQixLQUFLLGVBQWUsTUFBTSxLQUFLO0dBQ2pDLENBQUM7RUFDSCxPQUNFLEtBQUssaUJBQWlCO0dBQ3BCLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsbUJBQW1CLE9BQU87R0FFNUIsS0FBSywwQkFBVSxJQUFJLElBQUk7R0FDdkIsT0FBTyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLFlBQVk7SUFDbEQsS0FBSyxpQkFBaUIsTUFBTSxNQUFNO0dBQ3BDLENBQUM7RUFDSDtDQUVKO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsS0FBSyxLQUFLO0VBQ1YsT0FBTyxLQUFLLFFBQVEsSUFBSSxLQUFLLFlBQVksQ0FBQztDQUM1QztDQUNBLElBQUksTUFBTTtFQUNSLEtBQUssS0FBSztFQUNWLE1BQU0sU0FBUyxLQUFLLFFBQVEsSUFBSSxLQUFLLFlBQVksQ0FBQztFQUNsRCxPQUFPLFVBQVUsT0FBTyxTQUFTLElBQUksT0FBTyxLQUFLO0NBQ25EO0NBQ0EsT0FBTztFQUNMLEtBQUssS0FBSztFQUNWLE9BQU8sTUFBTSxLQUFLLEtBQUssZ0JBQWdCLE9BQU8sQ0FBQztDQUNqRDtDQUNBLE9BQU8sTUFBTTtFQUNYLEtBQUssS0FBSztFQUNWLE9BQU8sS0FBSyxRQUFRLElBQUksS0FBSyxZQUFZLENBQUMsS0FBSztDQUNqRDtDQUNBLE9BQU8sTUFBTSxPQUFPO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0dBQ2hCO0dBQ0E7R0FDQSxJQUFJO0VBQ04sQ0FBQztDQUNIO0NBQ0EsSUFBSSxNQUFNLE9BQU87RUFDZixPQUFPLEtBQUssTUFBTTtHQUNoQjtHQUNBO0dBQ0EsSUFBSTtFQUNOLENBQUM7Q0FDSDtDQUNBLE9BQU8sTUFBTSxPQUFPO0VBQ2xCLE9BQU8sS0FBSyxNQUFNO0dBQ2hCO0dBQ0E7R0FDQSxJQUFJO0VBQ04sQ0FBQztDQUNIO0NBQ0EsdUJBQXVCLE1BQU0sUUFBUTtFQUNuQyxJQUFJLENBQUMsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNLEdBQ2xDLEtBQUssZ0JBQWdCLElBQUksUUFBUSxJQUFJO0NBRXpDO0NBQ0EsT0FBTztFQUNMLElBQUksQ0FBQyxDQUFDLEtBQUssVUFBVTtHQUNuQixJQUFJLEtBQUssb0JBQW9CLGFBQzNCLEtBQUssU0FBUyxLQUFLLFFBQVE7UUFFM0IsS0FBSyxTQUFTO0dBRWhCLEtBQUssV0FBVztHQUNoQixJQUFJLENBQUMsQ0FBQyxLQUFLLFlBQVk7SUFDckIsS0FBSyxXQUFXLFNBQVEsV0FBVSxLQUFLLFlBQVksTUFBTSxDQUFDO0lBQzFELEtBQUssYUFBYTtHQUNwQjtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLE9BQU87RUFDZCxNQUFNLEtBQUs7RUFDWCxLQUFLLE1BQU0sQ0FBQyxLQUFLLFdBQVcsTUFBTSxRQUFRLFFBQVEsR0FBRztHQUNuRCxLQUFLLFFBQVEsSUFBSSxLQUFLLE1BQU07R0FDNUIsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLLE1BQU0sZ0JBQWdCLElBQUksR0FBRyxDQUFDO0VBQzlEO0NBQ0Y7Q0FDQSxNQUFNLFFBQVE7RUFDWixNQUFNLFFBQVEsSUFBSSxZQUFZO0VBQzlCLE1BQU0sV0FBVyxDQUFDLENBQUMsS0FBSyxZQUFZLEtBQUssb0JBQW9CLGNBQWMsS0FBSyxXQUFXO0VBQzNGLE1BQU0sY0FBYyxLQUFLLGNBQWMsQ0FBQyxFQUFBLENBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztFQUMxRCxPQUFPO0NBQ1Q7Q0FDQSxZQUFZLFFBQVE7RUFDbEIsTUFBTSxNQUFNLE9BQU8sS0FBSyxZQUFZO0VBQ3BDLFFBQVEsT0FBTyxJQUFmO0dBQ0UsS0FBSztHQUNMLEtBQUs7SUFDSCxJQUFJLFFBQVEsT0FBTztJQUNuQixJQUFJLE9BQU8sVUFBVSxVQUNuQixRQUFRLENBQUMsS0FBSztJQUVoQixJQUFJLE1BQU0sV0FBVyxHQUNuQjtJQUVGLEtBQUssdUJBQXVCLE9BQU8sTUFBTSxHQUFHO0lBQzVDLE1BQU0sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLLFFBQVEsSUFBSSxHQUFHLEtBQUssQ0FBQyxFQUFBLENBQUcsTUFBTSxJQUFJLENBQUM7SUFDMUUsS0FBSyxLQUFLLEdBQUcsS0FBSztJQUNsQixLQUFLLFFBQVEsSUFBSSxLQUFLLElBQUk7SUFDMUI7R0FDRixLQUFLO0lBQ0gsTUFBTSxXQUFXLE9BQU87SUFDeEIsSUFBSSxhQUFhLEtBQUEsR0FBVztLQUMxQixLQUFLLFFBQVEsT0FBTyxHQUFHO0tBQ3ZCLEtBQUssZ0JBQWdCLE9BQU8sR0FBRztJQUNqQyxPQUFPO0tBQ0wsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLFFBQVEsSUFBSSxXQUFXLENBQUMsUUFBUTtLQUNyRSxJQUFJLFdBQVcsS0FBSyxRQUFRLElBQUksR0FBRztLQUNuQyxJQUFJLENBQUMsVUFDSDtLQUVGLFdBQVcsU0FBUyxRQUFPLFVBQVMsZUFBZSxRQUFRLEtBQUssTUFBTSxFQUFFO0tBQ3hFLElBQUksU0FBUyxXQUFXLEdBQUc7TUFDekIsS0FBSyxRQUFRLE9BQU8sR0FBRztNQUN2QixLQUFLLGdCQUFnQixPQUFPLEdBQUc7S0FDakMsT0FDRSxLQUFLLFFBQVEsSUFBSSxLQUFLLFFBQVE7SUFFbEM7SUFDQTtFQUNKO0NBQ0Y7Q0FDQSxlQUFlLE1BQU0sT0FBTztFQUMxQixNQUFNLE1BQU0sS0FBSyxZQUFZO0VBQzdCLEtBQUssdUJBQXVCLE1BQU0sR0FBRztFQUNyQyxJQUFJLEtBQUssUUFBUSxJQUFJLEdBQUcsR0FDdEIsS0FBSyxRQUFRLElBQUksR0FBRyxDQUFDLENBQUMsS0FBSyxLQUFLO09BRWhDLEtBQUssUUFBUSxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUM7Q0FFakM7Q0FDQSxpQkFBaUIsTUFBTSxRQUFRO0VBQzdCLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUSxNQUFNLElBQUksU0FBUyxDQUFDLE1BQU0sRUFBQSxDQUFHLEtBQUksVUFBUyxNQUFNLFNBQVMsQ0FBQztFQUM5RixNQUFNLE1BQU0sS0FBSyxZQUFZO0VBQzdCLEtBQUssUUFBUSxJQUFJLEtBQUssWUFBWTtFQUNsQyxLQUFLLHVCQUF1QixNQUFNLEdBQUc7Q0FDdkM7Q0FDQSxRQUFRLElBQUk7RUFDVixLQUFLLEtBQUs7RUFDVixNQUFNLEtBQUssS0FBSyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFRLFFBQU8sR0FBRyxLQUFLLGdCQUFnQixJQUFJLEdBQUcsR0FBRyxLQUFLLFFBQVEsSUFBSSxHQUFHLENBQUMsQ0FBQztDQUNqSDtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsU0FBUztDQUNuQyxLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLE9BQU8sR0FDL0MsSUFBSSxFQUFFLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxhQUFhLENBQUMsTUFBTSxRQUFRLEtBQUssR0FDbkYsTUFBTSxJQUFJLE1BQU0sNkJBQTZCLElBQUksa0ZBQXVGLE1BQU0sSUFBSTtBQUd4SjtBQUNBLElBQU0sbUJBQU4sTUFBdUI7Q0FFckIsWUFBWSxjQUFjO3dCQUQxQixnQkFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLGVBQWU7Q0FDdEI7QUFDRjtBQUNBLElBQU0sY0FBTixNQUFrQjs7d0JBQ2hCLHVCQUFNLElBQUksSUFBSSxDQUFBOztDQUNkLElBQUksT0FBTyxPQUFPO0VBQ2hCLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSztFQUN6QixPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU87RUFDVCxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksS0FBSyxHQUNyQixLQUFLLElBQUksSUFBSSxPQUFPLE1BQU0sYUFBYSxDQUFDO0VBRTFDLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSztDQUMzQjtDQUNBLE9BQU8sT0FBTztFQUNaLEtBQUssSUFBSSxPQUFPLEtBQUs7RUFDckIsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLO0NBQzNCO0NBQ0EsT0FBTztFQUNMLE9BQU8sS0FBSyxJQUFJLEtBQUs7Q0FDdkI7QUFDRjtBQUNBLElBQU0sdUJBQU4sTUFBMkI7Q0FDekIsVUFBVSxLQUFLO0VBQ2IsT0FBTyxpQkFBaUIsR0FBRztDQUM3QjtDQUNBLFlBQVksT0FBTztFQUNqQixPQUFPLGlCQUFpQixLQUFLO0NBQy9CO0NBQ0EsVUFBVSxLQUFLO0VBQ2IsT0FBTyxtQkFBbUIsR0FBRztDQUMvQjtDQUNBLFlBQVksT0FBTztFQUNqQixPQUFPLG1CQUFtQixLQUFLO0NBQ2pDO0FBQ0Y7QUFDQSxTQUFTLFlBQVksV0FBVyxPQUFPO0NBQ3JDLE1BQU0sc0JBQU0sSUFBSSxJQUFJO0NBQ3BCLElBQUksVUFBVSxTQUFTLEdBRXJCLFVBRHlCLFFBQVEsT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQzdDLENBQUMsQ0FBQyxTQUFRLFVBQVM7RUFDdEIsTUFBTSxRQUFRLE1BQU0sUUFBUSxHQUFHO0VBQy9CLE1BQU0sQ0FBQyxLQUFLLE9BQU8sU0FBUyxLQUFLLENBQUMsTUFBTSxVQUFVLEtBQUssR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLFVBQVUsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLEdBQUcsTUFBTSxZQUFZLE1BQU0sTUFBTSxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQ2xKLE1BQU0sT0FBTyxJQUFJLElBQUksR0FBRyxLQUFLLENBQUM7RUFDOUIsS0FBSyxLQUFLLEdBQUc7RUFDYixJQUFJLElBQUksS0FBSyxJQUFJO0NBQ25CLENBQUM7Q0FFSCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLDBCQUEwQjtBQUNoQyxJQUFNLGlDQUFpQztDQUNyQyxNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtBQUNSO0FBQ0EsU0FBUyxpQkFBaUIsR0FBRztDQUMzQixPQUFPLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxRQUFRLDBCQUEwQixHQUFHLE1BQU07O2lFQUErQixRQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFNO0VBQUM7QUFDaEg7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUM1QixPQUFPLEdBQUc7QUFDWjtBQUNBLElBQU0sYUFBTixNQUFNLFdBQVc7Q0FLZixZQUFZLFVBQVUsQ0FBQyxHQUFHO3dCQUoxQixPQUFBLEtBQUEsQ0FBQTt3QkFDQSxXQUFBLEtBQUEsQ0FBQTt3QkFDQSxXQUFVLElBQUE7d0JBQ1YsYUFBWSxJQUFBO0VBRVYsS0FBSyxVQUFVLFFBQVEsV0FBVyxJQUFJLHFCQUFxQjtFQUMzRCxJQUFJLFFBQVEsWUFBWTtHQUN0QixJQUFJLFFBQVEsWUFDVixNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLGdEQUFnRDtHQUU3RixLQUFLLE1BQU0sWUFBWSxRQUFRLFlBQVksS0FBSyxPQUFPO0VBQ3pELE9BQU8sSUFBSSxDQUFDLENBQUMsUUFBUSxZQUFZO0dBQy9CLEtBQUssc0JBQU0sSUFBSSxJQUFJO0dBQ25CLE9BQU8sS0FBSyxRQUFRLFVBQVUsQ0FBQyxDQUFDLFNBQVEsUUFBTztJQUM3QyxNQUFNLFFBQVEsUUFBUSxXQUFXO0lBQ2pDLE1BQU0sU0FBUyxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sSUFBSSxhQUFhLElBQUksQ0FBQyxjQUFjLEtBQUssQ0FBQztJQUN0RixLQUFLLElBQUksSUFBSSxLQUFLLE1BQU07R0FDMUIsQ0FBQztFQUNILE9BQ0UsS0FBSyxNQUFNO0NBRWY7Q0FDQSxJQUFJLE9BQU87RUFDVCxLQUFLLEtBQUs7RUFDVixPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUs7Q0FDM0I7Q0FDQSxJQUFJLE9BQU87RUFDVCxLQUFLLEtBQUs7RUFDVixNQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSztFQUM5QixPQUFPLENBQUMsQ0FBQyxNQUFNLElBQUksS0FBSztDQUMxQjtDQUNBLE9BQU8sT0FBTztFQUNaLEtBQUssS0FBSztFQUNWLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLO0NBQ2hDO0NBQ0EsT0FBTztFQUNMLEtBQUssS0FBSztFQUNWLE9BQU8sTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLENBQUM7Q0FDbkM7Q0FDQSxPQUFPLE9BQU8sT0FBTztFQUNuQixPQUFPLEtBQUssTUFBTTtHQUNoQjtHQUNBO0dBQ0EsSUFBSTtFQUNOLENBQUM7Q0FDSDtDQUNBLFVBQVUsUUFBUTtFQUNoQixNQUFNLFVBQVUsQ0FBQztFQUNqQixPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsU0FBUSxVQUFTO0dBQ25DLE1BQU0sUUFBUSxPQUFPO0dBQ3JCLElBQUksTUFBTSxRQUFRLEtBQUssR0FDckIsTUFBTSxTQUFRLFdBQVU7SUFDdEIsUUFBUSxLQUFLO0tBQ1g7S0FDQSxPQUFPO0tBQ1AsSUFBSTtJQUNOLENBQUM7R0FDSCxDQUFDO1FBRUQsUUFBUSxLQUFLO0lBQ1g7SUFDTztJQUNQLElBQUk7R0FDTixDQUFDO0VBRUwsQ0FBQztFQUNELE9BQU8sS0FBSyxNQUFNLE9BQU87Q0FDM0I7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixPQUFPLEtBQUssTUFBTTtHQUNoQjtHQUNBO0dBQ0EsSUFBSTtFQUNOLENBQUM7Q0FDSDtDQUNBLE9BQU8sT0FBTyxPQUFPO0VBQ25CLE9BQU8sS0FBSyxNQUFNO0dBQ2hCO0dBQ0E7R0FDQSxJQUFJO0VBQ04sQ0FBQztDQUNIO0NBQ0EsV0FBVztFQUNULEtBQUssS0FBSztFQUNWLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxLQUFJLFFBQU87R0FDNUIsTUFBTSxPQUFPLEtBQUssUUFBUSxVQUFVLEdBQUc7R0FDdkMsT0FBTyxLQUFLLElBQUksSUFBSSxHQUFHLENBQUMsQ0FBQyxLQUFJLFVBQVMsT0FBTyxNQUFNLEtBQUssUUFBUSxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQzlGLENBQUMsQ0FBQyxDQUFDLFFBQU8sVUFBUyxVQUFVLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRztDQUMzQztDQUNBLE1BQU0sUUFBUTtFQUNaLE1BQU0sUUFBUSxJQUFJLFdBQVcsRUFDM0IsU0FBUyxLQUFLLFFBQ2hCLENBQUM7RUFDRCxNQUFNLFlBQVksS0FBSyxhQUFhO0VBQ3BDLE1BQU0sV0FBVyxLQUFLLFdBQVcsQ0FBQyxFQUFBLENBQUcsT0FBTyxNQUFNO0VBQ2xELE9BQU87Q0FDVDtDQUNBLE9BQU87RUFDTCxJQUFJLEtBQUssUUFBUSxNQUNmLEtBQUssc0JBQU0sSUFBSSxJQUFJO0VBRXJCLElBQUksS0FBSyxjQUFjLE1BQU07R0FDM0IsS0FBSyxVQUFVLEtBQUs7R0FDcEIsS0FBSyxNQUFNLENBQUMsS0FBSyxXQUFXLEtBQUssVUFBVSxJQUFJLFFBQVEsR0FDckQsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNO0dBRTFCLEtBQUssUUFBUSxTQUFRLFdBQVU7SUFDN0IsUUFBUSxPQUFPLElBQWY7S0FDRSxLQUFLO0tBQ0wsS0FBSztNQUNILE1BQU0sT0FBTyxPQUFPLE9BQU8sT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLEVBQUEsQ0FBRyxNQUFNLElBQUksQ0FBQztNQUMvRSxLQUFLLEtBQUssY0FBYyxPQUFPLEtBQUssQ0FBQztNQUNyQyxLQUFLLElBQUksSUFBSSxPQUFPLE9BQU8sSUFBSTtNQUMvQjtLQUNGLEtBQUssS0FDSCxJQUFJLE9BQU8sVUFBVSxLQUFBLEdBQVc7TUFDOUIsTUFBTSxRQUFRLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxLQUFLLENBQUMsRUFBQSxDQUFHLE1BQU07TUFDdEQsTUFBTSxNQUFNLEtBQUssUUFBUSxjQUFjLE9BQU8sS0FBSyxDQUFDO01BQ3BELElBQUksUUFBUSxJQUNWLEtBQUssT0FBTyxLQUFLLENBQUM7TUFFcEIsSUFBSSxLQUFLLFNBQVMsR0FDaEIsS0FBSyxJQUFJLElBQUksT0FBTyxPQUFPLElBQUk7V0FFL0IsS0FBSyxJQUFJLE9BQU8sT0FBTyxLQUFLO0tBRWhDLE9BQU87TUFDTCxLQUFLLElBQUksT0FBTyxPQUFPLEtBQUs7TUFDNUI7S0FDRjtJQUNKO0dBQ0YsQ0FBQztHQUNELEtBQUssWUFBWSxLQUFLLFVBQVU7RUFDbEM7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxjQUFjLFFBQVE7Q0FDN0IsUUFBUSxRQUFSO0VBQ0UsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUssU0FDSCxPQUFPO0VBQ1QsU0FDRSxPQUFPO0NBQ1g7QUFDRjtBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLE9BQU8sT0FBTyxnQkFBZ0IsZUFBZSxpQkFBaUI7QUFDaEU7QUFDQSxTQUFTLE9BQU8sT0FBTztDQUNyQixPQUFPLE9BQU8sU0FBUyxlQUFlLGlCQUFpQjtBQUN6RDtBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE9BQU8sT0FBTyxhQUFhLGVBQWUsaUJBQWlCO0FBQzdEO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTztDQUNoQyxPQUFPLE9BQU8sb0JBQW9CLGVBQWUsaUJBQWlCO0FBQ3BFO0FBQ0EsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxvQkFBb0I7QUFDMUIsSUFBTSxzQkFBc0IsR0FBRyxrQkFBa0IsSUFBSSxrQkFBa0I7QUFDdkUsSUFBTSxjQUFOLE1BQU0sWUFBWTtDQXdCaEIsWUFBWSxRQUFRLEtBQUssT0FBTyxRQUFROzt3QkF2QnhDLE9BQUEsS0FBQSxDQUFBO3dCQUNBLFFBQU8sSUFBQTt3QkFDUCxXQUFBLEtBQUEsQ0FBQTt3QkFDQSxXQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBaUIsS0FBQTt3QkFDakIsd0JBQXVCLEtBQUE7d0JBQ3ZCLDBCQUF5QixLQUFBO3dCQUN6QixtQkFBa0IsS0FBQTt3QkFDbEIsZUFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBWSxLQUFBO3dCQUNaLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQUEsS0FBQSxDQUFBO3dCQUNBLGtCQUFBLEtBQUEsQ0FBQTt3QkFDQSxnQkFBZSxNQUFBO3dCQUNmLFVBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxpQkFBQSxLQUFBLENBQUE7d0JBQ0EsV0FBQSxLQUFBLENBQUE7RUFFRSxLQUFLLE1BQU07RUFDWCxLQUFLLFNBQVMsT0FBTyxZQUFZO0VBQ2pDLElBQUk7RUFDSixJQUFJLGNBQWMsS0FBSyxNQUFNLEtBQUssQ0FBQyxDQUFDLFFBQVE7R0FDMUMsS0FBSyxPQUFPLFVBQVUsS0FBQSxJQUFZLFFBQVE7R0FDMUMsVUFBVTtFQUNaLE9BQ0UsVUFBVTtFQUVaLElBQUksU0FBUztHQUNYLEtBQUssaUJBQWlCLENBQUMsQ0FBQyxRQUFRO0dBQ2hDLEtBQUssdUJBQXVCLENBQUMsQ0FBQyxRQUFRO0dBQ3RDLEtBQUsseUJBQXlCLENBQUMsQ0FBQyxRQUFRO0dBQ3hDLEtBQUssa0JBQWtCLENBQUMsQ0FBQyxRQUFRO0dBQ2pDLEtBQUssWUFBWSxDQUFDLENBQUMsUUFBUTtHQUMzQixJQUFJLENBQUMsQ0FBQyxRQUFRLGNBQ1osS0FBSyxlQUFlLFFBQVE7R0FFOUIsSUFBSSxRQUFRLFNBQ1YsS0FBSyxVQUFVLFFBQVE7R0FFekIsSUFBSSxRQUFRLFNBQ1YsS0FBSyxVQUFVLFFBQVE7R0FFekIsSUFBSSxRQUFRLFFBQ1YsS0FBSyxTQUFTLFFBQVE7R0FFeEIsSUFBSSxRQUFRLFVBQ1YsS0FBSyxXQUFXLFFBQVE7R0FFMUIsSUFBSSxRQUFRLE9BQ1YsS0FBSyxRQUFRLFFBQVE7R0FFdkIsSUFBSSxRQUFRLGFBQ1YsS0FBSyxjQUFjLFFBQVE7R0FFN0IsSUFBSSxPQUFPLFFBQVEsWUFBWSxVQUFVO0lBQ3ZDLElBQUksUUFBUSxVQUFVLEtBQUssQ0FBQyxPQUFPLFVBQVUsUUFBUSxPQUFPLEdBQzFELE1BQU0sSUFBSUEsYUFBYyxNQUFNLFlBQVksK0NBQStDLEVBQUU7SUFFN0YsS0FBSyxVQUFVLFFBQVE7R0FDekI7R0FDQSxJQUFJLFFBQVEsTUFDVixLQUFLLE9BQU8sUUFBUTtHQUV0QixJQUFJLFFBQVEsVUFDVixLQUFLLFdBQVcsUUFBUTtHQUUxQixJQUFJLFFBQVEsV0FDVixLQUFLLFlBQVksUUFBUTtHQUUzQixJQUFJLFFBQVEsYUFBYSxLQUFBLEdBQ3ZCLEtBQUssV0FBVyxRQUFRO0dBRTFCLElBQUksUUFBUSxnQkFDVixLQUFLLGlCQUFpQixRQUFRO0dBRWhDLEtBQUssZ0JBQWdCLFFBQVE7RUFDL0I7RUFDQSxDQUFBLGdCQUFBLEtBQUssYUFBQSxRQUFBLGtCQUFBLEtBQUEsTUFBTCxLQUFLLFVBQVksSUFBSSxZQUFZO0VBQ2pDLENBQUEsZ0JBQUEsS0FBSyxhQUFBLFFBQUEsa0JBQUEsS0FBQSxNQUFMLEtBQUssVUFBWSxJQUFJLFlBQVk7RUFDakMsSUFBSSxDQUFDLEtBQUssUUFBUTtHQUNoQixLQUFLLFNBQVMsSUFBSSxXQUFXO0dBQzdCLEtBQUssZ0JBQWdCO0VBQ3ZCLE9BQU87R0FDTCxNQUFNLFNBQVMsS0FBSyxPQUFPLFNBQVM7R0FDcEMsSUFBSSxPQUFPLFdBQVcsR0FDcEIsS0FBSyxnQkFBZ0I7UUFDaEI7SUFDTCxJQUFJLHFCQUFxQjtJQUN6QixJQUFJLFdBQVc7SUFDZixNQUFNLFVBQVUsSUFBSSxRQUFRLEdBQUc7SUFDL0IsSUFBSSxZQUFZLElBQUk7S0FDbEIsV0FBVyxJQUFJLFVBQVUsT0FBTztLQUNoQyxxQkFBcUIsSUFBSSxVQUFVLEdBQUcsT0FBTztJQUMvQztJQUNBLE1BQU0sT0FBTyxtQkFBbUIsUUFBUSxHQUFHO0lBQzNDLE1BQU0sTUFBTSxTQUFTLEtBQUssTUFBTSxPQUFPLG1CQUFtQixTQUFTLElBQUksTUFBTTtJQUM3RSxLQUFLLGdCQUFnQixxQkFBcUIsTUFBTSxTQUFTO0dBQzNEO0VBQ0Y7Q0FDRjtDQUNBLGdCQUFnQjtFQUNkLElBQUksS0FBSyxTQUFTLE1BQ2hCLE9BQU87RUFFVCxJQUFJLE9BQU8sS0FBSyxTQUFTLFlBQVksY0FBYyxLQUFLLElBQUksS0FBSyxPQUFPLEtBQUssSUFBSSxLQUFLLFdBQVcsS0FBSyxJQUFJLEtBQUssa0JBQWtCLEtBQUssSUFBSSxHQUN4SSxPQUFPLEtBQUs7RUFFZCxJQUFJLEtBQUssZ0JBQWdCLFlBQ3ZCLE9BQU8sS0FBSyxLQUFLLFNBQVM7RUFFNUIsSUFBSSxPQUFPLEtBQUssU0FBUyxZQUFZLE9BQU8sS0FBSyxTQUFTLGFBQWEsTUFBTSxRQUFRLEtBQUssSUFBSSxHQUM1RixPQUFPLEtBQUssVUFBVSxLQUFLLElBQUk7RUFFakMsT0FBTyxLQUFLLEtBQUssU0FBUztDQUM1QjtDQUNBLDBCQUEwQjtFQUN4QixJQUFJLEtBQUssU0FBUyxNQUNoQixPQUFPO0VBRVQsSUFBSSxXQUFXLEtBQUssSUFBSSxHQUN0QixPQUFPO0VBRVQsSUFBSSxPQUFPLEtBQUssSUFBSSxHQUNsQixPQUFPLEtBQUssS0FBSyxRQUFRO0VBRTNCLElBQUksY0FBYyxLQUFLLElBQUksR0FDekIsT0FBTztFQUVULElBQUksT0FBTyxLQUFLLFNBQVMsVUFDdkIsT0FBTztFQUVULElBQUksS0FBSyxnQkFBZ0IsWUFDdkIsT0FBTztFQUVULElBQUksT0FBTyxLQUFLLFNBQVMsWUFBWSxPQUFPLEtBQUssU0FBUyxZQUFZLE9BQU8sS0FBSyxTQUFTLFdBQ3pGLE9BQU87RUFFVCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLFNBQVMsQ0FBQyxHQUFHOztFQUNqQixNQUFNLFNBQVMsT0FBTyxVQUFVLEtBQUs7RUFDckMsTUFBTSxNQUFNLE9BQU8sT0FBTyxLQUFLO0VBQy9CLE1BQU0sZUFBZSxPQUFPLGdCQUFnQixLQUFLO0VBQ2pELE1BQU0sYUFBQSxvQkFBWSxPQUFPLGVBQUEsUUFBQSxzQkFBQSxLQUFBLElBQUEsb0JBQWEsS0FBSztFQUMzQyxNQUFNLFdBQVcsT0FBTyxZQUFZLEtBQUs7RUFDekMsTUFBTSxRQUFRLE9BQU8sU0FBUyxLQUFLO0VBQ25DLE1BQU0sT0FBTyxPQUFPLFFBQVEsS0FBSztFQUNqQyxNQUFNLFdBQVcsT0FBTyxZQUFZLEtBQUs7RUFDekMsTUFBTSxjQUFjLE9BQU8sZUFBZSxLQUFLO0VBQy9DLE1BQU0sWUFBQSxtQkFBVyxPQUFPLGNBQUEsUUFBQSxxQkFBQSxLQUFBLElBQUEsbUJBQVksS0FBSztFQUN6QyxNQUFNLFlBQVksT0FBTyxhQUFhLEtBQUs7RUFDM0MsTUFBTSxpQkFBaUIsT0FBTyxrQkFBa0IsS0FBSztFQUNyRCxNQUFNLGlCQUFBLHdCQUFnQixPQUFPLG1CQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFpQixLQUFLO0VBQ25ELE1BQU0sV0FBQSxrQkFBVSxPQUFPLGFBQUEsUUFBQSxvQkFBQSxLQUFBLElBQUEsa0JBQVcsS0FBSztFQUN2QyxNQUFNLE9BQU8sT0FBTyxTQUFTLEtBQUEsSUFBWSxPQUFPLE9BQU8sS0FBSztFQUM1RCxNQUFNLG1CQUFBLHdCQUFrQixPQUFPLHFCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFtQixLQUFLO0VBQ3ZELE1BQU0sa0JBQUEsd0JBQWlCLE9BQU8sb0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQWtCLEtBQUs7RUFDckQsTUFBTSx3QkFBQSx3QkFBdUIsT0FBTywwQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBd0IsS0FBSztFQUNqRSxNQUFNLDBCQUFBLHdCQUF5QixPQUFPLDRCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUEwQixLQUFLO0VBQ3JFLElBQUksVUFBVSxPQUFPLFdBQVcsS0FBSztFQUNyQyxJQUFJLFNBQVMsT0FBTyxVQUFVLEtBQUs7RUFDbkMsTUFBTSxXQUFBLGtCQUFVLE9BQU8sYUFBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxrQkFBVyxLQUFLO0VBQ3ZDLElBQUksT0FBTyxlQUFlLEtBQUEsR0FDeEIsVUFBVSxPQUFPLEtBQUssT0FBTyxVQUFVLENBQUMsQ0FBQyxRQUFRLFNBQVMsU0FBUyxRQUFRLElBQUksTUFBTSxPQUFPLFdBQVcsS0FBSyxHQUFHLE9BQU87RUFFeEgsSUFBSSxPQUFPLFdBQ1QsU0FBUyxPQUFPLEtBQUssT0FBTyxTQUFTLENBQUMsQ0FBQyxRQUFRLFFBQVEsVUFBVSxPQUFPLElBQUksT0FBTyxPQUFPLFVBQVUsTUFBTSxHQUFHLE1BQU07RUFFckgsT0FBTyxJQUFJLFlBQVksUUFBUSxLQUFLLE1BQU07R0FDeEM7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUFDO0NBQ0g7QUFDRjtBQUNBLElBQUk7Q0FDSCxTQUFVLGVBQWU7Q0FDeEIsY0FBYyxjQUFjLFVBQVUsS0FBSztDQUMzQyxjQUFjLGNBQWMsb0JBQW9CLEtBQUs7Q0FDckQsY0FBYyxjQUFjLG9CQUFvQixLQUFLO0NBQ3JELGNBQWMsY0FBYyxzQkFBc0IsS0FBSztDQUN2RCxjQUFjLGNBQWMsY0FBYyxLQUFLO0NBQy9DLGNBQWMsY0FBYyxVQUFVLEtBQUs7QUFDN0MsRUFBQSxDQUFHLGtCQUFrQixnQkFBZ0IsQ0FBQyxFQUFFO0FBQ3hDLElBQU0sbUJBQU4sTUFBdUI7Q0FTckIsWUFBWSxNQUFNLGdCQUFnQixLQUFLLG9CQUFvQixNQUFNO3dCQVJqRSxXQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxjQUFBLEtBQUEsQ0FBQTt3QkFDQSxPQUFBLEtBQUEsQ0FBQTt3QkFDQSxNQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFBLEtBQUEsQ0FBQTt3QkFDQSxjQUFBLEtBQUEsQ0FBQTt3QkFDQSxnQkFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLFVBQVUsS0FBSyxXQUFXLElBQUksWUFBWTtFQUMvQyxLQUFLLFNBQVMsS0FBSyxXQUFXLEtBQUEsSUFBWSxLQUFLLFNBQVM7RUFDeEQsS0FBSyxhQUFhLEtBQUssY0FBYztFQUNyQyxLQUFLLE1BQU0sS0FBSyxPQUFPO0VBQ3ZCLEtBQUssYUFBYSxLQUFLO0VBQ3ZCLEtBQUssZUFBZSxLQUFLO0VBQ3pCLEtBQUssS0FBSyxLQUFLLFVBQVUsT0FBTyxLQUFLLFNBQVM7Q0FDaEQ7QUFDRjtBQUNBLElBQU0scUJBQU4sTUFBTSwyQkFBMkIsaUJBQWlCO0NBQ2hELFlBQVksT0FBTyxDQUFDLEdBQUc7RUFDckIsTUFBTSxJQUFJO3dCQUVaLFFBQU8sY0FBYyxjQUFBO0NBRHJCO0NBRUEsTUFBTSxTQUFTLENBQUMsR0FBRztFQUNqQixPQUFPLElBQUksbUJBQW1CO0dBQzVCLFNBQVMsT0FBTyxXQUFXLEtBQUs7R0FDaEMsUUFBUSxPQUFPLFdBQVcsS0FBQSxJQUFZLE9BQU8sU0FBUyxLQUFLO0dBQzNELFlBQVksT0FBTyxjQUFjLEtBQUs7R0FDdEMsS0FBSyxPQUFPLE9BQU8sS0FBSyxPQUFPLEtBQUE7RUFDakMsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxJQUFNLGVBQU4sTUFBTSxxQkFBcUIsaUJBQWlCO0NBRTFDLFlBQVksT0FBTyxDQUFDLEdBQUc7RUFDckIsTUFBTSxJQUFJO3dCQUZaLFFBQUEsS0FBQSxDQUFBO3dCQUtBLFFBQU8sY0FBYyxRQUFBO0VBRm5CLEtBQUssT0FBTyxLQUFLLFNBQVMsS0FBQSxJQUFZLEtBQUssT0FBTztDQUNwRDtDQUVBLE1BQU0sU0FBUyxDQUFDLEdBQUc7O0VBQ2pCLE9BQU8sSUFBSSxhQUFhO0dBQ3RCLE1BQU0sT0FBTyxTQUFTLEtBQUEsSUFBWSxPQUFPLE9BQU8sS0FBSztHQUNyRCxTQUFTLE9BQU8sV0FBVyxLQUFLO0dBQ2hDLFFBQVEsT0FBTyxXQUFXLEtBQUEsSUFBWSxPQUFPLFNBQVMsS0FBSztHQUMzRCxZQUFZLE9BQU8sY0FBYyxLQUFLO0dBQ3RDLEtBQUssT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFBO0dBQy9CLGFBQUEscUJBQVksT0FBTyxnQkFBQSxRQUFBLHVCQUFBLEtBQUEsSUFBQSxxQkFBYyxLQUFLO0dBQ3RDLGVBQUEsdUJBQWMsT0FBTyxrQkFBQSxRQUFBLHlCQUFBLEtBQUEsSUFBQSx1QkFBZ0IsS0FBSztFQUM1QyxDQUFDO0NBQ0g7QUFDRjtBQUNBLElBQU0sb0JBQU4sY0FBZ0MsaUJBQWlCO0NBSy9DLFlBQVksTUFBTTtFQUNoQixNQUFNLE1BQU0sR0FBRyxlQUFlO3dCQUxoQyxRQUFPLG1CQUFBO3dCQUNQLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLE1BQUssS0FBQTtFQUdILElBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxTQUFTLEtBQ3RDLEtBQUssVUFBVSxtQ0FBbUMsS0FBSyxPQUFPO09BRTlELEtBQUssVUFBVSw2QkFBNkIsS0FBSyxPQUFPLGdCQUFnQixJQUFJLEtBQUssT0FBTyxHQUFHLEtBQUs7RUFFbEcsS0FBSyxRQUFRLEtBQUssU0FBUztDQUM3QjtBQUNGO0FBQ0EsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSw4QkFBOEI7QUFDcEMsSUFBSTtDQUNILFNBQVUsZ0JBQWdCO0NBQ3pCLGVBQWUsZUFBZSxjQUFjLE9BQU87Q0FDbkQsZUFBZSxlQUFlLHdCQUF3QixPQUFPO0NBQzdELGVBQWUsZUFBZSxnQkFBZ0IsT0FBTztDQUNyRCxlQUFlLGVBQWUsZ0JBQWdCLE9BQU87Q0FDckQsZUFBZSxlQUFlLFFBQVEsT0FBTztDQUM3QyxlQUFlLGVBQWUsYUFBYSxPQUFPO0NBQ2xELGVBQWUsZUFBZSxjQUFjLE9BQU87Q0FDbkQsZUFBZSxlQUFlLGlDQUFpQyxPQUFPO0NBQ3RFLGVBQWUsZUFBZSxlQUFlLE9BQU87Q0FDcEQsZUFBZSxlQUFlLGtCQUFrQixPQUFPO0NBQ3ZELGVBQWUsZUFBZSxvQkFBb0IsT0FBTztDQUN6RCxlQUFlLGVBQWUsaUJBQWlCLE9BQU87Q0FDdEQsZUFBZSxlQUFlLHFCQUFxQixPQUFPO0NBQzFELGVBQWUsZUFBZSxZQUFZLE9BQU87Q0FDakQsZUFBZSxlQUFlLHFCQUFxQixPQUFPO0NBQzFELGVBQWUsZUFBZSxzQkFBc0IsT0FBTztDQUMzRCxlQUFlLGVBQWUsV0FBVyxPQUFPO0NBQ2hELGVBQWUsZUFBZSxjQUFjLE9BQU87Q0FDbkQsZUFBZSxlQUFlLGlCQUFpQixPQUFPO0NBQ3RELGVBQWUsZUFBZSxjQUFjLE9BQU87Q0FDbkQsZUFBZSxlQUFlLFlBQVksT0FBTztDQUNqRCxlQUFlLGVBQWUsdUJBQXVCLE9BQU87Q0FDNUQsZUFBZSxlQUFlLHVCQUF1QixPQUFPO0NBQzVELGVBQWUsZUFBZSxnQkFBZ0IsT0FBTztDQUNyRCxlQUFlLGVBQWUsa0JBQWtCLE9BQU87Q0FDdkQsZUFBZSxlQUFlLHFCQUFxQixPQUFPO0NBQzFELGVBQWUsZUFBZSxlQUFlLE9BQU87Q0FDcEQsZUFBZSxlQUFlLGNBQWMsT0FBTztDQUNuRCxlQUFlLGVBQWUsc0JBQXNCLE9BQU87Q0FDM0QsZUFBZSxlQUFlLG1CQUFtQixPQUFPO0NBQ3hELGVBQWUsZUFBZSxpQ0FBaUMsT0FBTztDQUN0RSxlQUFlLGVBQWUsb0JBQW9CLE9BQU87Q0FDekQsZUFBZSxlQUFlLGNBQWMsT0FBTztDQUNuRCxlQUFlLGVBQWUsVUFBVSxPQUFPO0NBQy9DLGVBQWUsZUFBZSxvQkFBb0IsT0FBTztDQUN6RCxlQUFlLGVBQWUsd0JBQXdCLE9BQU87Q0FDN0QsZUFBZSxlQUFlLHFCQUFxQixPQUFPO0NBQzFELGVBQWUsZUFBZSxnQkFBZ0IsT0FBTztDQUNyRCxlQUFlLGVBQWUsMEJBQTBCLE9BQU87Q0FDL0QsZUFBZSxlQUFlLHlCQUF5QixPQUFPO0NBQzlELGVBQWUsZUFBZSx1QkFBdUIsT0FBTztDQUM1RCxlQUFlLGVBQWUsZUFBZSxPQUFPO0NBQ3BELGVBQWUsZUFBZSx3QkFBd0IsT0FBTztDQUM3RCxlQUFlLGVBQWUseUJBQXlCLE9BQU87Q0FDOUQsZUFBZSxlQUFlLFlBQVksT0FBTztDQUNqRCxlQUFlLGVBQWUsc0JBQXNCLE9BQU87Q0FDM0QsZUFBZSxlQUFlLGNBQWMsT0FBTztDQUNuRCxlQUFlLGVBQWUscUJBQXFCLE9BQU87Q0FDMUQsZUFBZSxlQUFlLDBCQUEwQixPQUFPO0NBQy9ELGVBQWUsZUFBZSxxQkFBcUIsT0FBTztDQUMxRCxlQUFlLGVBQWUsaUNBQWlDLE9BQU87Q0FDdEUsZUFBZSxlQUFlLGdDQUFnQyxPQUFPO0NBQ3JFLGVBQWUsZUFBZSx5QkFBeUIsT0FBTztDQUM5RCxlQUFlLGVBQWUsb0JBQW9CLE9BQU87Q0FDekQsZUFBZSxlQUFlLGdCQUFnQixPQUFPO0NBQ3JELGVBQWUsZUFBZSx3QkFBd0IsT0FBTztDQUM3RCxlQUFlLGVBQWUsb0JBQW9CLE9BQU87Q0FDekQsZUFBZSxlQUFlLDZCQUE2QixPQUFPO0NBQ2xFLGVBQWUsZUFBZSwyQkFBMkIsT0FBTztDQUNoRSxlQUFlLGVBQWUseUJBQXlCLE9BQU87Q0FDOUQsZUFBZSxlQUFlLGtCQUFrQixPQUFPO0NBQ3ZELGVBQWUsZUFBZSxpQkFBaUIsT0FBTztDQUN0RCxlQUFlLGVBQWUsbUNBQW1DLE9BQU87QUFDMUUsRUFBQSxDQUFHLG1CQUFtQixpQkFBaUIsQ0FBQyxFQUFFO0FBQzFDLElBQU0sZ0JBQWdCO0FBRXRCLElBQU0sK0JBQStCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLGlDQUFpQyxJQUFJLEVBQzNJLGVBQTBHLEtBQzVHLENBQUM7QUFDRCxJQUFNLGVBQU4sTUFBbUI7Ozt3QkFDakIsY0FBQSxpQkFBQSxVQUFZLE9BQU8sY0FBYyxFQUMvQixVQUFVLEtBQ1osQ0FBQyxPQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFFBQUcsV0FBQSxRQUFBLGtCQUFBLEtBQUEsSUFBQSxrQkFBVyxHQUFHLFNBQVMsV0FBVyxNQUFNLEdBQUcsSUFBSSxFQUFBO3dCQUNuRCxVQUFTLE9BQU8sTUFBTSxDQUFBO3dCQUN0QixjQUFhLE9BQU8sVUFBVSxDQUFBO3dCQUM5QixtQkFBa0IsT0FBTyw0QkFBNEIsQ0FBQTs7Q0FDckQsT0FBTyxTQUFTO0VBQ2QsT0FBTyxJQUFJLFlBQVcsYUFBWTtHQUNoQyxNQUFNLFVBQVUsSUFBSSxnQkFBZ0I7R0FDcEMsSUFBSSxPQUFPO0dBQ1gsTUFBTSxrQkFBa0I7SUFDdEIsT0FBTSxRQUFPO0tBQ1gsSUFBSSxJQUFJLFNBQVMsY0FBYyxVQUM3QixPQUFPO0tBRVQsU0FBUyxLQUFLLEdBQUc7SUFDbkI7SUFDQSxRQUFPLFFBQU87S0FDWixPQUFPO0tBQ1AsU0FBUyxNQUFNLEdBQUc7SUFDcEI7SUFDQSxnQkFBZ0I7S0FDZCxPQUFPO0tBQ1AsU0FBUyxTQUFTO0lBQ3BCO0dBQ0Y7R0FDQSxLQUFLLFVBQVUsU0FBUyxRQUFRLFFBQVEsZUFBZSxDQUFDLENBQUMsS0FBSyxPQUFNLFVBQVMsZ0JBQWdCLE1BQU0sSUFBSSxrQkFBa0IsRUFDdkgsTUFDRixDQUFDLENBQUMsQ0FBQztHQUNILElBQUk7R0FDSixJQUFJLFFBQVEsU0FDVixZQUFZLEtBQUssT0FBTyx3QkFBd0IsaUJBQWlCO0lBQy9ELElBQUksQ0FBQyxRQUFRLE9BQU8sU0FDbEIsUUFBUSxNQUFNLElBQUksYUFBYSxvQkFBb0IsY0FBYyxDQUFDO0dBRXRFLEdBQUcsUUFBUSxPQUFPLENBQUM7R0FFckIsYUFBYTtJQUNYLElBQUksY0FBYyxLQUFBLEdBQ2hCLGFBQWEsU0FBUztJQUV4QixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsT0FBTyxTQUMzQixRQUFRLE1BQU07R0FFbEI7RUFDRixDQUFDO0NBQ0g7Q0FDQSxVQUFnQixTQUFTLFFBQVEsVUFBQTs7d0NBQVU7R0FDekMsTUFBTSxPQUFPQyxNQUFLLGtCQUFrQixPQUFPO0dBQzNDLElBQUk7R0FDSixJQUFJO0lBQ0YsTUFBTSxlQUFlQSxNQUFLLE9BQU8sd0JBQXdCQSxNQUFLLFVBQVUsUUFBUSxlQUFBLGVBQUEsRUFDOUUsT0FBQSxHQUNHLElBQ0wsQ0FBQyxDQUFDO0lBQ0YsNENBQTRDLFlBQVk7SUFDeEQsU0FBUyxLQUFLLEVBQ1osTUFBTSxjQUFjLEtBQ3RCLENBQUM7SUFDRCxXQUFXLE1BQU07R0FDbkIsU0FBUyxPQUFPOztJQUNkLFNBQVMsTUFBTSxJQUFJLGtCQUFrQjtLQUNuQztLQUNBLFNBQUEsZ0JBQVEsTUFBTSxZQUFBLFFBQUEsa0JBQUEsS0FBQSxJQUFBLGdCQUFVO0tBQ3hCLFlBQVksTUFBTTtLQUNsQixLQUFLLFFBQVE7S0FDYixTQUFTLE1BQU07SUFDakIsQ0FBQyxDQUFDO0lBQ0Y7R0FDRjtHQUNBLE1BQU0sVUFBVSxJQUFJLFlBQVksU0FBUyxPQUFPO0dBQ2hELE1BQU0sYUFBYSxTQUFTO0dBQzVCLE1BQU0sTUFBTSxTQUFTLE9BQU8sUUFBUTtHQUNwQyxJQUFJLFNBQVMsU0FBUztHQUN0QixJQUFJLE9BQU87R0FDWCxNQUFNLHlCQUF5QixRQUFRLGtCQUFrQixRQUFRO0dBQ2pFLElBQUksd0JBQ0YsU0FBUyxLQUFLLElBQUksbUJBQW1CO0lBQ25DO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQyxDQUFDO0dBRUosSUFBSSxTQUFTLE1BQU07O0lBQ2pCLE1BQU0sZUFBQSx3QkFBYyxTQUFTLFFBQVEsSUFBSSxtQkFBbUIsT0FBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBSztJQUNqRSxNQUFNLGdCQUFnQixTQUFTLFFBQVEsSUFBSSxnQkFBZ0I7SUFDM0QsTUFBTSxxQkFBcUIsa0JBQWtCLE9BQU8sT0FBTyxhQUFhLElBQUk7SUFDNUUsSUFBSUEsTUFBSyxvQkFBb0IsUUFBUSxPQUFPLFNBQVMsa0JBQWtCLEtBQUsscUJBQXFCQSxNQUFLLGlCQUNwRyx1QkFBdUJBLE1BQUssZUFBZTtJQUU3QyxNQUFNLFNBQVMsQ0FBQztJQUNoQixNQUFNLFNBQVMsU0FBUyxLQUFLLFVBQVU7SUFDdkMsSUFBSSxpQkFBaUI7SUFDckIsSUFBSTtJQUNKLElBQUk7SUFDSixNQUFNLFVBQVUsT0FBTyxTQUFTLGVBQWUsS0FBSztJQUNwRCxJQUFJLFdBQVc7SUFDZixNQUFNQSxNQUFLLE9BQU8sa0JBQUEsa0JBQUEsYUFBOEI7S0FDOUMsT0FBTyxNQUFNO01BQ1gsSUFBSUEsTUFBSyxXQUFXLFdBQVc7T0FDN0IsTUFBTSxPQUFPLE9BQU87T0FDcEIsV0FBVztPQUNYO01BQ0Y7TUFDQSxNQUFNLEVBQ0osTUFDQSxVQUNFLE1BQU0sT0FBTyxLQUFLO01BQ3RCLElBQUksTUFDRjtNQUVGLE9BQU8sS0FBSyxLQUFLO01BQ2pCLGtCQUFrQixNQUFNO01BQ3hCLElBQUlBLE1BQUssb0JBQW9CLFFBQVEsaUJBQWlCQSxNQUFLLGlCQUFpQjtPQUMxRSxNQUFNLE9BQU8sT0FBTztPQUNwQix1QkFBdUJBLE1BQUssZUFBZTtNQUM3QztNQUNBLElBQUksd0JBQXdCOztPQUMxQixjQUFjLFFBQVEsaUJBQWlCLFdBQUEsZUFBVSxpQkFBQSxRQUFBLGlCQUFBLEtBQUEsSUFBQSxlQUFlLFFBQUEsV0FBTyxhQUFBLFFBQUEsYUFBQSxLQUFBLElBQUEsV0FBQSxVQUFZLGVBQWUsV0FBVyxFQUFBLENBQUcsT0FBTyxPQUFPLEVBQzVILFFBQVEsS0FDVixDQUFDLElBQUksS0FBQTtPQUNMLE1BQU0sdUJBQXVCLFNBQVMsS0FBSztRQUN6QyxNQUFNLGNBQWM7UUFDcEIsT0FBTyxPQUFPLFNBQVMsa0JBQWtCLElBQUkscUJBQXFCLEtBQUE7UUFDbEUsUUFBUTtRQUNSO09BQ0YsQ0FBQztPQUNELFVBQVUsUUFBUSxJQUFJLGNBQWMsSUFBSSxlQUFlO01BQ3pEO0tBQ0Y7SUFDRixDQUFBLENBQUM7SUFDRCxJQUFJLFVBQVU7S0FDWixTQUFTLFNBQVM7S0FDbEI7SUFDRjtJQUNBLE1BQU0sWUFBWUEsTUFBSyxhQUFhLFFBQVEsY0FBYztJQUMxRCxJQUFJO0tBQ0YsT0FBT0EsTUFBSyxVQUFVLFNBQVMsV0FBVyxhQUFhLE1BQU07SUFDL0QsU0FBUyxPQUFPO0tBQ2QsU0FBUyxNQUFNLElBQUksa0JBQWtCO01BQ25DO01BQ0EsU0FBUyxJQUFJLFlBQVksU0FBUyxPQUFPO01BQ3pDLFFBQVEsU0FBUztNQUNqQixZQUFZLFNBQVM7TUFDckIsS0FBSyxTQUFTLE9BQU8sUUFBUTtLQUMvQixDQUFDLENBQUM7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLFdBQVcsR0FDYixTQUFTLE9BQU8sc0JBQXNCO0dBRXhDLE1BQU0sS0FBSyxVQUFVLE9BQU8sU0FBUztHQUNyQyxNQUFNLGFBQWEsU0FBUztHQUM1QixNQUFNLGVBQWUsU0FBUztHQUM5QixJQUFJLElBQUk7SUFDTixTQUFTLEtBQUssSUFBSSxhQUFhO0tBQzdCO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0YsQ0FBQyxDQUFDO0lBQ0YsU0FBUyxTQUFTO0dBQ3BCLE9BQ0UsU0FBUyxNQUFNLElBQUksa0JBQWtCO0lBQ25DLE9BQU87SUFDUDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRixDQUFDLENBQUM7RUFFTixDQUFBLENBQUEsQ0FBQTs7Q0FDQSxVQUFVLFNBQVMsWUFBWSxhQUFhLFFBQVE7RUFDbEQsUUFBUSxRQUFRLGNBQWhCO0dBQ0UsS0FBSztJQUNILE1BQU0sT0FBTyxJQUFJLFlBQVksQ0FBQyxDQUFDLE9BQU8sVUFBVSxDQUFDLENBQUMsUUFBUSxlQUFlLEVBQUU7SUFDM0UsSUFBSSxTQUFTLElBQ1gsT0FBTztJQUVULElBQUk7S0FDRixPQUFPLEtBQUssTUFBTSxJQUFJO0lBQ3hCLFNBQVMsR0FBRztLQUNWLElBQUksU0FBUyxPQUFPLFVBQVUsS0FDNUIsT0FBTztLQUVULE1BQU07SUFDUjtHQUNGLEtBQUssUUFDSCxPQUFPLGVBQWUsV0FBVyxDQUFDLENBQUMsT0FBTyxVQUFVO0dBQ3RELEtBQUssUUFDSCxPQUFPLElBQUksS0FBSyxDQUFDLFVBQVUsR0FBRyxFQUM1QixNQUFNLFlBQ1IsQ0FBQztHQUNILEtBQUssZUFDSCxPQUFPLFdBQVc7RUFDdEI7Q0FDRjtDQUNBLGtCQUFrQixLQUFLO0VBQ3JCLElBQUksSUFBSSxzQkFDTixNQUFNLElBQUlELGFBQWMsTUFBTSxhQUFhLHdLQUF3SztFQUVyTixNQUFNLFVBQVUsQ0FBQztFQUNqQixJQUFJO0VBQ0osY0FBYyxJQUFJO0VBQ2xCLElBQUksSUFBSSxpQkFBaUI7R0FDdkIsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjLHNCQUFzQixHQUFHO0dBQzVFLGNBQWM7RUFDaEI7RUFDQSxJQUFJLFFBQVEsU0FBUyxNQUFNLFdBQVcsUUFBUSxRQUFRLE9BQU8sS0FBSyxHQUFHLENBQUM7RUFDdEUsSUFBSSxDQUFDLElBQUksUUFBUSxJQUFJLGFBQWEsR0FDaEMsUUFBUSxpQkFBaUI7RUFFM0IsSUFBSSxDQUFDLElBQUksUUFBUSxJQUFJLG1CQUFtQixHQUFHO0dBQ3pDLE1BQU0sZUFBZSxJQUFJLHdCQUF3QjtHQUNqRCxJQUFJLGlCQUFpQixNQUNuQixRQUFRLHVCQUF1QjtFQUVuQztFQUNBLE9BQU87R0FDTCxNQUFNLElBQUksY0FBYztHQUN4QixRQUFRLElBQUk7R0FDWjtHQUNBO0dBQ0EsV0FBVyxJQUFJO0dBQ2YsT0FBTyxJQUFJO0dBQ1gsVUFBVSxJQUFJO0dBQ2QsTUFBTSxJQUFJO0dBQ1YsVUFBVSxJQUFJO0dBQ2QsVUFBVSxJQUFJO0dBQ2QsV0FBVyxJQUFJO0dBQ2YsZ0JBQWdCLElBQUk7RUFDdEI7Q0FDRjtDQUNBLGFBQWEsUUFBUSxhQUFhO0VBQ2hDLE1BQU0sWUFBWSxJQUFJLFdBQVcsV0FBVztFQUM1QyxJQUFJLFdBQVc7RUFDZixLQUFLLE1BQU0sU0FBUyxRQUFRO0dBQzFCLFVBQVUsSUFBSSxPQUFPLFFBQVE7R0FDN0IsWUFBWSxNQUFNO0VBQ3BCO0VBQ0EsT0FBTztDQUNUO0FBUUY7OzhCQVBTLFFBQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0NBQzdELE9BQU8sS0FBSyxxQkFBcUJFLGVBQWM7QUFDakQsQ0FBQTs4QkFDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxTQUFTQSxjQUFhO0FBQ3hCLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjQyxpQkFBcUIsY0FBYyxDQUFDLEVBQ3JGLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sZUFBTixNQUFtQixDQUFDO0FBQ3BCLFNBQVMsT0FBTyxDQUFDO0FBQ2pCLFNBQVMsc0JBQXNCLEtBQUs7Q0FDbEMsSUFBSSxJQUFJLGVBQWUsSUFBSSxpQkFDekIsUUFBUSxLQUFLQyxtQkFBb0IsTUFBTSx5R0FBeUcsSUFBSSxZQUFZLCtLQUErSyxJQUFJLFlBQVksMEJBQTBCLENBQUM7QUFFOVg7QUFDQSxTQUFTLDRDQUE0QyxTQUFTO0NBQzVELFFBQVEsS0FBSyxNQUFNLElBQUk7QUFDekI7QUFDQSxTQUFTLHVCQUF1QixpQkFBaUI7Q0FDL0MsTUFBTSxJQUFJSixhQUFjLE9BQU8sYUFBYSw2REFBNkQsZ0JBQWdCLFNBQVM7QUFDcEk7QUFDQSxJQUFNLGdCQUFnQjtBQUN0QixTQUFTLGVBQWUsYUFBYTtDQUNuQyxNQUFNLFFBQVEsWUFBWSxNQUFNLGFBQWE7Q0FDN0MsSUFBSSxVQUFVLE1BQ1osSUFBSTtFQUNGLE9BQU8sSUFBSSxZQUFZLE1BQU0sRUFBRTtDQUNqQyxTQUFBLFNBQVEsQ0FBQztDQUVYLE9BQU8sSUFBSSxZQUFZO0FBQ3pCO0FBQ0EsSUFBTSxlQUFlLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLGlCQUFpQixJQUFJLEVBQzNHLGVBQWUsS0FDakIsQ0FBQztBQUNELElBQU0sMkJBQTJCO0FBQ2pDLElBQU0sbUJBQW1CLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHFCQUFxQixJQUFJLEVBQ25ILGVBQWUseUJBQ2pCLENBQUM7QUFDRCxJQUFNLDJCQUEyQjtBQUNqQyxJQUFNLG1CQUFtQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxxQkFBcUIsSUFBSSxFQUNuSCxlQUFlLHlCQUNqQixDQUFDO0FBQ0QsSUFBTSwwQkFBTixNQUE4Qjs7d0JBQzVCLGNBQWEsT0FBTyxnQkFBZ0IsQ0FBQTt3QkFDcEMsT0FBTSxPQUFPLFFBQVEsQ0FBQTt3QkFDckIsb0JBQW1CLEVBQUE7d0JBQ25CLGFBQVksSUFBQTt3QkFDWixjQUFhLENBQUE7O0NBQ2IsV0FBVztFQUlULE1BQU0sZUFBZSxLQUFLLElBQUksVUFBVTtFQUN4QyxJQUFJLGlCQUFpQixLQUFLLGtCQUFrQjtHQUMxQyxLQUFLO0dBQ0wsS0FBSyxZQUFZLGlCQUFpQixjQUFjLEtBQUssVUFBVTtHQUMvRCxLQUFLLG1CQUFtQjtFQUMxQjtFQUNBLE9BQU8sS0FBSztDQUNkO0FBUUY7O3lDQVBTLFFBQU8sU0FBUyxnQ0FBZ0MsbUJBQW1CO0NBQ3hFLE9BQU8sS0FBSyxxQkFBcUJLLDBCQUF5QjtBQUM1RCxDQUFBO3lDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLHlCQUF3QjtBQUNuQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0YsaUJBQXFCLHlCQUF5QixDQUFDLEVBQ2hHLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0seUJBQU4sTUFBNkIsQ0FrQjdCOzt3Q0FqQlMsUUFBTyxTQUFTLCtCQUErQixtQkFBbUI7Q0FDdkUsT0FBTyxLQUFLLHFCQUFxQkcseUJBQXdCO0FBQzNELENBQUE7d0NBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9BO0NBQ1AsU0FBUyxTQUFTLCtCQUErQixtQkFBbUI7RUFDbEUsSUFBSSwyQkFBMkI7RUFDL0IsSUFBSSxtQkFDRiwyQkFBMkIsS0FBSyxxQkFBcUJBLHlCQUF3QjtPQUc3RSwyQkFBMkJDLFNBQVksdUJBQXVCO0VBRWhFLE9BQU87Q0FDVDtDQUNBLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0osaUJBQXFCLHdCQUF3QixDQUFDO0VBQy9GLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxZQUFZO0dBQ1osYUFBYTtFQUNmLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILFNBQVMsa0JBQWtCLEtBQUssTUFBTTtDQUNwQyxJQUFJLENBQUMsT0FBTyxZQUFZLEtBQUssSUFBSSxXQUFXLFNBQVMsSUFBSSxXQUFXLFFBQ2xFLE9BQU8sS0FBSyxHQUFHO0NBRWpCLElBQUk7RUFDRixNQUFNLGVBQWUsT0FBTyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQzlDLE1BQU0sRUFDSixRQUFRLG1CQUNOLElBQUksSUFBSSxZQUFZO0VBQ3hCLE1BQU0sRUFDSixRQUFRLGtCQUNOLElBQUksSUFBSSxJQUFJLEtBQUssY0FBYztFQUNuQyxJQUFJLG1CQUFtQixlQUNyQixPQUFPLEtBQUssR0FBRztDQUVuQixTQUFBLFVBQVE7RUFDTixPQUFPLEtBQUssR0FBRztDQUNqQjtDQUNBLE1BQU0sUUFBUSxPQUFPLHNCQUFzQixDQUFDLENBQUMsU0FBUztDQUN0RCxNQUFNLGFBQWEsT0FBTyxnQkFBZ0I7Q0FDMUMsSUFBSSxTQUFTLFFBQVEsQ0FBQyxJQUFJLFFBQVEsSUFBSSxVQUFVLEdBQzlDLE1BQU0sSUFBSSxNQUFNLEVBQ2QsU0FBUyxJQUFJLFFBQVEsSUFBSSxZQUFZLEtBQUssRUFDNUMsQ0FBQztDQUVILE9BQU8sS0FBSyxHQUFHO0FBQ2pCO0FBQ0EsSUFBTSxzQkFBTixNQUEwQjs7d0JBQ3hCLFlBQVcsT0FBTyxtQkFBbUIsQ0FBQTs7Q0FDckMsVUFBVSxnQkFBZ0IsTUFBTTtFQUM5QixPQUFPLHNCQUFzQixLQUFLLGdCQUFnQixrQkFBa0IsaUJBQWdCLHNCQUFxQixLQUFLLE9BQU8saUJBQWlCLENBQUMsQ0FBQztDQUMxSTtBQVFGOztxQ0FQUyxRQUFPLFNBQVMsNEJBQTRCLG1CQUFtQjtDQUNwRSxPQUFPLEtBQUsscUJBQXFCSyxzQkFBcUI7QUFDeEQsQ0FBQTtxQ0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0E7Q0FDUCxTQUFTQSxxQkFBb0I7QUFDL0IsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNMLGlCQUFxQixxQkFBcUIsQ0FBQyxFQUM1RixNQUFNLFdBQ1IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxTQUFTLHNCQUFzQixLQUFLLGdCQUFnQjtDQUNsRCxPQUFPLGVBQWUsR0FBRztBQUMzQjtBQUNBLFNBQVMsOEJBQThCLGFBQWEsYUFBYTtDQUMvRCxRQUFRLGdCQUFnQixtQkFBbUIsWUFBWSxVQUFVLGdCQUFnQixFQUMvRSxTQUFRLHNCQUFxQixZQUFZLG1CQUFtQixjQUFjLEVBQzVFLENBQUM7QUFDSDtBQUNBLFNBQVMscUJBQXFCLGFBQWEsZUFBZSxVQUFVO0NBQ2xFLFFBQVEsZ0JBQWdCLG1CQUFtQixzQkFBc0IsZ0JBQWdCLGNBQWMsaUJBQWdCLHNCQUFxQixZQUFZLG1CQUFtQixjQUFjLENBQUMsQ0FBQztBQUNyTDtBQUNBLElBQU0sb0JBQW9CLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHNCQUFzQixFQUFFO0FBQ3JILElBQU0sdUJBQXVCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHlCQUF5QixJQUFJLEVBQzNILGVBQWUsQ0FBQyxpQkFBaUIsRUFDbkMsQ0FBQztBQUNELElBQU0sNEJBQTRCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLDhCQUE4QixFQUFFO0FBQ3JJLElBQU0sbUNBQW1DLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHFDQUFxQyxJQUFJLEVBQ25KLGVBQWUsS0FDakIsQ0FBQztBQUNELFNBQVMsNkJBQTZCO0NBQ3BDLElBQUksUUFBUTtDQUNaLFFBQVEsS0FBSyxZQUFZO0VBQ3ZCLElBQUksVUFBVSxNQUFNOztHQUlsQixVQUFBLFdBSHFCLE9BQU8sbUJBQW1CLEVBQzdDLFVBQVUsS0FDWixDQUFDLE9BQUEsUUFBQSxhQUFBLEtBQUEsSUFBQSxXQUFLLENBQUMsRUFBQSxDQUNjLFlBQVksK0JBQStCLHFCQUFxQjtFQUN2RjtFQUNBLE1BQU0sZUFBZSxPQUFPLFlBQVk7RUFFeEMsSUFEOEIsT0FBTyxnQ0FDYixHQUFHO0dBQ3pCLE1BQU0sYUFBYSxhQUFhLElBQUk7R0FDcEMsT0FBTyxNQUFNLEtBQUssT0FBTyxDQUFDLENBQUMsS0FBSyxTQUFTLFVBQVUsQ0FBQztFQUN0RCxPQUNFLE9BQU8sTUFBTSxLQUFLLE9BQU87Q0FFN0I7QUFDRjtBQUNBLElBQU0sY0FBTixNQUFrQixDQWtCbEI7OzZCQWpCUyxRQUFPLFNBQVMsb0JBQW9CLG1CQUFtQjtDQUM1RCxPQUFPLEtBQUsscUJBQXFCTSxjQUFhO0FBQ2hELENBQUE7NkJBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9BO0NBQ1AsU0FBUyxTQUFTLG9CQUFvQixtQkFBbUI7RUFDdkQsSUFBSSwyQkFBMkI7RUFDL0IsSUFBSSxtQkFDRiwyQkFBMkIsS0FBSyxxQkFBcUJBLGNBQWE7T0FHbEUsMkJBQTJCRixTQUFZLFlBQVk7RUFFckQsT0FBTztDQUNUO0NBQ0EsWUFBWTtBQUNkLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSixpQkFBcUIsYUFBYSxDQUFDO0VBQ3BGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxZQUFZO0dBQ1osYUFBYTtFQUNmLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUVILElBQU0seUJBQU4sTUFBNkI7Q0FNM0IsWUFBWSxTQUFTLFVBQVU7d0JBTC9CLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQVEsSUFBQTt3QkFDUixnQkFBZSxPQUFPLFlBQVksQ0FBQTt3QkFDbEMseUJBQXdCLE9BQU8sZ0NBQWdDLENBQUE7RUFFN0QsS0FBSyxVQUFVO0VBQ2YsS0FBSyxXQUFXO0VBQ2hCLEtBQUssT0FBTyxjQUFjLGVBQWUsY0FBYyxNQUM1QixLQUFLLFFBQVE7Q0FNMUM7Q0FDQSxPQUFPLGdCQUFnQjtFQUNyQixJQUFJLEtBQUssVUFBVSxNQUFNO0dBQ3ZCLE1BQU0sZ0JBQWdCLEtBQUssU0FBUyxJQUFJLGFBQWEsTUFBTSxFQUN6RCxVQUFVLEtBQ1osQ0FBQztHQUNELE1BQU0sZUFBZSxrQkFBa0IsUUFBUSxLQUFLLFlBQVk7R0FDaEUsTUFBTSxxQkFBcUIsS0FBSyxTQUFTLElBQUksMkJBQTJCLENBQUMsR0FBRyxlQUFlLEVBQ3pGLE1BQU0sS0FDUixJQUFJLEtBQUEsQ0FBUztHQUNiLE1BQU0sd0JBQXdCLE1BQU0scUJBQUssSUFBSSxJQUFJLENBQUMsR0FBRyxLQUFLLFNBQVMsSUFBSSxvQkFBb0IsR0FBRyxHQUFHLGtCQUFrQixDQUFDLENBQUM7R0FDckgsS0FBSyxRQUFRLHNCQUFzQixhQUFhLGlCQUFpQixrQkFBa0IscUJBQXFCLGlCQUFpQixlQUFlLEtBQUssUUFBUSxHQUFHLHFCQUFxQjtFQUMvSztFQUNBLE1BQU0sUUFBUSxLQUFLO0VBQ25CLElBQUksS0FBSyx1QkFBdUI7R0FDOUIsTUFBTSxhQUFhLEtBQUssYUFBYSxJQUFJO0dBQ3pDLE9BQU8sZ0JBQWdCLE1BQU0saUJBQWdCLHNCQUFxQixLQUFLLFFBQVEsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsVUFBVSxDQUFDO0VBQ3RJLE9BQ0UsT0FBTyxnQkFBZ0IsTUFBTSxpQkFBZ0Isc0JBQXFCLEtBQUssUUFBUSxPQUFPLGlCQUFpQixDQUFDLENBQUM7Q0FFN0c7QUFVRjs7d0NBVFMsUUFBTyxTQUFTLCtCQUErQixtQkFBbUI7Q0FFdkUsT0FBTyxLQUFLLHFCQUFxQk8seUJBQXdCSCxTQUFZLFdBQVcsR0FBR0EsU0FBWUksbUJBQXNCLENBQUM7QUFDeEgsQ0FBQTt3Q0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0Q7Q0FDUCxTQUFTQSx3QkFBdUI7Q0FDaEMsWUFBWTtBQUNkLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjUCxpQkFBcUIsd0JBQXdCLENBQUM7RUFDL0YsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFlBQVksT0FDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNLFlBQ1IsR0FBRyxFQUNELE1BQU1RLG9CQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxjQUFOLE1BQWtCLENBa0JsQjs7NkJBakJTLFFBQU8sU0FBUyxvQkFBb0IsbUJBQW1CO0NBQzVELE9BQU8sS0FBSyxxQkFBcUJDLGNBQWE7QUFDaEQsQ0FBQTs2QkFDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0E7Q0FDUCxTQUFTLFNBQVMsb0JBQW9CLG1CQUFtQjtFQUN2RCxJQUFJLDJCQUEyQjtFQUMvQixJQUFJLG1CQUNGLDJCQUEyQixLQUFLLHFCQUFxQkEsY0FBYTtPQUdsRSwyQkFBMkJMLFNBQVksc0JBQXNCO0VBRS9ELE9BQU87Q0FDVDtDQUNBLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0osaUJBQXFCLGFBQWEsQ0FBQztFQUNwRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsWUFBWTtHQUNaLGFBQWE7RUFDZixDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxTQUFTLFFBQVEsU0FBUyxNQUFNO0NBQzlCLE9BQUEsZUFBQSxFQUNFLEtBQUEsR0FDRyxPQUNMO0FBQ0Y7QUFDQSxJQUFNLGFBQU4sTUFBaUI7Q0FFZixZQUFZLFNBQVM7d0JBRHJCLFdBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxVQUFVO0NBQ2pCO0NBQ0EsUUFBUSxPQUFPLEtBQUssVUFBVSxDQUFDLEdBQUc7RUFDaEMsSUFBSTtFQUNKLElBQUksaUJBQWlCLGFBQ25CLE1BQU07T0FDRDtHQUNMLElBQUksVUFBVSxLQUFBO0dBQ2QsSUFBSSxRQUFRLG1CQUFtQixhQUM3QixVQUFVLFFBQVE7UUFFbEIsVUFBVSxJQUFJLFlBQVksUUFBUSxPQUFPO0dBRTNDLElBQUksU0FBUyxLQUFBO0dBQ2IsSUFBSSxDQUFDLENBQUMsUUFBUSxRQUNaLElBQUksUUFBUSxrQkFBa0IsWUFDNUIsU0FBUyxRQUFRO1FBRWpCLFNBQVMsSUFBSSxXQUFXLEVBQ3RCLFlBQVksUUFBUSxPQUN0QixDQUFDO0dBR0wsTUFBTSxJQUFJLFlBQVksT0FBTyxLQUFLLFFBQVEsU0FBUyxLQUFBLElBQVksUUFBUSxPQUFPLE1BQU07SUFDbEY7SUFDQSxTQUFTLFFBQVE7SUFDakI7SUFDQSxnQkFBZ0IsUUFBUTtJQUN4QixzQkFBc0IsUUFBUTtJQUM5Qix3QkFBd0IsUUFBUTtJQUNoQyxjQUFjLFFBQVEsZ0JBQWdCO0lBQ3RDLGlCQUFpQixRQUFRO0lBQ3pCLGVBQWUsUUFBUTtJQUN2QixXQUFXLFFBQVE7SUFDbkIsVUFBVSxRQUFRO0lBQ2xCLE9BQU8sUUFBUTtJQUNmLE1BQU0sUUFBUTtJQUNkLFVBQVUsUUFBUTtJQUNsQixhQUFhLFFBQVE7SUFDckIsVUFBVSxRQUFRO0lBQ2xCLGdCQUFnQixRQUFRO0lBQ3hCLFdBQVcsUUFBUTtJQUNuQixTQUFTLFFBQVE7R0FDbkIsQ0FBQztFQUNIO0VBQ0EsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxXQUFVLFFBQU8sS0FBSyxRQUFRLE9BQU8sR0FBRyxDQUFDLENBQUM7RUFDdkUsSUFBSSxpQkFBaUIsZUFBZSxRQUFRLFlBQVksVUFDdEQsT0FBTztFQUVULE1BQU0sT0FBTyxRQUFRLEtBQUssUUFBTyxVQUFTLGlCQUFpQixZQUFZLENBQUM7RUFDeEUsUUFBUSxRQUFRLFdBQVcsUUFBM0I7R0FDRSxLQUFLLFFBQ0gsUUFBUSxJQUFJLGNBQVo7SUFDRSxLQUFLLGVBQ0gsT0FBTyxLQUFLLEtBQUssS0FBSSxRQUFPO0tBQzFCLElBQUksSUFBSSxTQUFTLFFBQVEsRUFBRSxJQUFJLGdCQUFnQixjQUM3QyxNQUFNLElBQUlILGFBQWMsTUFBTSxhQUFhLGlDQUFpQztLQUU5RSxPQUFPLElBQUk7SUFDYixDQUFDLENBQUM7SUFDSixLQUFLLFFBQ0gsT0FBTyxLQUFLLEtBQUssS0FBSSxRQUFPO0tBQzFCLElBQUksSUFBSSxTQUFTLFFBQVEsRUFBRSxJQUFJLGdCQUFnQixPQUM3QyxNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLHlCQUF5QjtLQUV0RSxPQUFPLElBQUk7SUFDYixDQUFDLENBQUM7SUFDSixLQUFLLFFBQ0gsT0FBTyxLQUFLLEtBQUssS0FBSSxRQUFPO0tBQzFCLElBQUksSUFBSSxTQUFTLFFBQVEsT0FBTyxJQUFJLFNBQVMsVUFDM0MsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSwyQkFBMkI7S0FFeEUsT0FBTyxJQUFJO0lBQ2IsQ0FBQyxDQUFDO0lBRUosU0FDRSxPQUFPLEtBQUssS0FBSyxLQUFJLFFBQU8sSUFBSSxJQUFJLENBQUM7R0FDekM7R0FDRixLQUFLLFlBQ0gsT0FBTztHQUNULFNBQ0UsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSx1Q0FBdUMsUUFBUSxRQUFRLEVBQUU7RUFDeEc7Q0FDRjtDQUNBLE9BQU8sS0FBSyxVQUFVLENBQUMsR0FBRztFQUN4QixPQUFPLEtBQUssUUFBUSxVQUFVLEtBQUssT0FBTztDQUM1QztDQUNBLElBQUksS0FBSyxVQUFVLENBQUMsR0FBRztFQUNyQixPQUFPLEtBQUssUUFBUSxPQUFPLEtBQUssT0FBTztDQUN6QztDQUNBLEtBQUssS0FBSyxVQUFVLENBQUMsR0FBRztFQUN0QixPQUFPLEtBQUssUUFBUSxRQUFRLEtBQUssT0FBTztDQUMxQztDQUNBLE1BQU0sS0FBSyxlQUFlO0VBQ3hCLE9BQU8sS0FBSyxRQUFRLFNBQVMsS0FBSztHQUNoQyxRQUFRLElBQUksV0FBVyxDQUFDLENBQUMsT0FBTyxlQUFlLGdCQUFnQjtHQUMvRCxTQUFTO0dBQ1QsY0FBYztFQUNoQixDQUFDO0NBQ0g7Q0FDQSxRQUFRLEtBQUssVUFBVSxDQUFDLEdBQUc7RUFDekIsT0FBTyxLQUFLLFFBQVEsV0FBVyxLQUFLLE9BQU87Q0FDN0M7Q0FDQSxNQUFNLEtBQUssTUFBTSxVQUFVLENBQUMsR0FBRztFQUM3QixPQUFPLEtBQUssUUFBUSxTQUFTLEtBQUssUUFBUSxTQUFTLElBQUksQ0FBQztDQUMxRDtDQUNBLEtBQUssS0FBSyxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQzVCLE9BQU8sS0FBSyxRQUFRLFFBQVEsS0FBSyxRQUFRLFNBQVMsSUFBSSxDQUFDO0NBQ3pEO0NBQ0EsSUFBSSxLQUFLLE1BQU0sVUFBVSxDQUFDLEdBQUc7RUFDM0IsT0FBTyxLQUFLLFFBQVEsT0FBTyxLQUFLLFFBQVEsU0FBUyxJQUFJLENBQUM7Q0FDeEQ7QUFVRjs7NEJBVFMsUUFBTyxTQUFTLG1CQUFtQixtQkFBbUI7Q0FFM0QsT0FBTyxLQUFLLHFCQUFxQmEsYUFBWU4sU0FBWSxXQUFXLENBQUM7QUFDdkUsQ0FBQTs0QkFDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT007Q0FDUCxTQUFTQSxZQUFXO0NBQ3BCLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1YsaUJBQXFCLFlBQVksQ0FBQztFQUNuRixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsWUFBWSxPQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU0sWUFDUixDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQUksZ0JBQWdCO0FBQ3BCLElBQUk7QUFDSixJQUFNLHdCQUF3QjtBQUM5QixJQUFNLHlCQUF5QjtBQUMvQixJQUFNLGdDQUFnQztBQUN0QyxJQUFNLGtDQUFrQztBQUN4QyxJQUFNLHVCQUF1QjtBQUM3QixJQUFNLHVCQUFOLE1BQTJCLENBQUM7QUFDNUIsU0FBUyx1QkFBdUI7Q0FDOUIsSUFBSSxPQUFPLFdBQVcsVUFDcEIsT0FBTztDQUVULE9BQU8sQ0FBQztBQUNWO0FBQ0EsSUFBTSxxQkFBTixNQUF5QjtDQU92QixZQUFZLGFBQWEsVUFBVTt3QkFObkMsZUFBQSxLQUFBLENBQUE7d0JBQ0EsWUFBQSxLQUFBLENBQUE7d0JBQ0EsbUJBQWtCLFFBQVEsUUFBUSxDQUFBO3dCQUNsQyxTQUFRLE9BQU8sV0FBVyxFQUN4QixVQUFVLEtBQ1osQ0FBQyxDQUFBO0VBRUMsS0FBSyxjQUFjO0VBQ25CLEtBQUssV0FBVztFQUNoQixJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLFFBQVEsS0FBSyxpS0FBc0s7Q0FFdkw7Q0FDQSxlQUFlO0VBQ2IsT0FBTyxxQkFBcUI7Q0FDOUI7Q0FDQSxPQUFPLEtBQUs7RUFDVixJQUFJLElBQUksV0FBVyxTQUNqQixNQUFNLElBQUlILGFBQWMsTUFBTSxhQUFhLHNCQUFzQjtPQUM1RCxJQUFJLElBQUksaUJBQWlCLFFBQzlCLE1BQU0sSUFBSUEsYUFBYyxNQUFNLGFBQWEsNkJBQTZCO0VBRTFFLElBQUksSUFBSSxRQUFRLEtBQUssQ0FBQyxDQUFDLFNBQVMsR0FDOUIsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSwrQkFBK0I7RUFFNUUsSUFBSSxDQUFDLEtBQUssa0JBQWtCLElBQUksYUFBYSxHQUMzQyxNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLG9CQUFvQjtFQUVqRSxPQUFPLElBQUksWUFBVyxhQUFZO0dBQ2hDLE1BQU0sV0FBVyxLQUFLLGFBQWE7R0FDbkMsTUFBTSxNQUFNLElBQUksY0FBYyxRQUFRLHdCQUF3QixJQUFJLFNBQVMsR0FBRztHQUM5RSxNQUFNLE9BQU8sS0FBSyxTQUFTLGNBQWMsUUFBUTtHQUNqRCxLQUFLLE1BQU07R0FDWCxJQUFJLEtBQUssT0FDUCxLQUFLLGFBQWEsU0FBUyxLQUFLLEtBQUs7R0FFdkMsSUFBSSxPQUFPO0dBQ1gsSUFBSSxXQUFXO0dBQ2YsS0FBSyxZQUFZLGFBQVksU0FBUTtJQUNuQyxPQUFPLEtBQUssWUFBWTtJQUN4QixPQUFPO0lBQ1AsV0FBVztHQUNiO0dBQ0EsTUFBTSxnQkFBZ0I7SUFDcEIsS0FBSyxvQkFBb0IsUUFBUSxNQUFNO0lBQ3ZDLEtBQUssb0JBQW9CLFNBQVMsT0FBTztJQUN6QyxLQUFLLE9BQU87SUFDWixPQUFPLEtBQUssWUFBWTtHQUMxQjtHQUNBLE1BQU0sZUFBZTtJQUNuQixLQUFLLGdCQUFnQixXQUFXO0tBQzlCLFFBQVE7S0FDUixJQUFJLENBQUMsVUFBVTtNQUNiLFNBQVMsTUFBTSxJQUFJLGtCQUFrQjtPQUNuQztPQUNBLFFBQVE7T0FDUixZQUFZO09BQ1osdUJBQU8sSUFBSSxNQUFNLHFCQUFxQjtNQUN4QyxDQUFDLENBQUM7TUFDRjtLQUNGO0tBQ0EsU0FBUyxLQUFLLElBQUksYUFBYTtNQUM3QjtNQUNBLFFBQVE7TUFDUixZQUFZO01BQ1o7S0FDRixDQUFDLENBQUM7S0FDRixTQUFTLFNBQVM7SUFDcEIsQ0FBQztHQUNIO0dBQ0EsTUFBTSxXQUFVLFVBQVM7SUFDdkIsUUFBUTtJQUNSLFNBQVMsTUFBTSxJQUFJLGtCQUFrQjtLQUNuQztLQUNBLFFBQVE7S0FDUixZQUFZO0tBQ1o7SUFDRixDQUFDLENBQUM7R0FDSjtHQUNBLEtBQUssaUJBQWlCLFFBQVEsTUFBTTtHQUNwQyxLQUFLLGlCQUFpQixTQUFTLE9BQU87R0FDdEMsS0FBSyxTQUFTLEtBQUssWUFBWSxJQUFJO0dBQ25DLFNBQVMsS0FBSyxFQUNaLE1BQU0sY0FBYyxLQUN0QixDQUFDO0dBQ0QsYUFBYTtJQUNYLElBQUksQ0FBQyxVQUNILEtBQUssZ0JBQWdCLElBQUk7SUFFM0IsUUFBUTtHQUNWO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsZ0JBQWdCLFFBQVE7O0VBQ3RCLENBQUEsbUJBQUEscUJBQUEsUUFBQSxxQkFBQSxLQUFBLE1BQUEsa0JBQW9CLEtBQUssU0FBUyxlQUFlLG1CQUFtQjtFQUNwRSxnQkFBZ0IsVUFBVSxNQUFNO0NBQ2xDO0NBQ0Esa0JBQWtCLEtBQUs7RUFDckIsT0FBTyxnQkFBZ0IsS0FBSyxHQUFHO0NBQ2pDO0FBU0Y7O29DQVJTLFFBQU8sU0FBUywyQkFBMkIsbUJBQW1CO0NBRW5FLE9BQU8sS0FBSyxxQkFBcUJjLHFCQUFvQlAsU0FBWSxvQkFBb0IsR0FBR0EsU0FBWSxRQUFRLENBQUM7QUFDL0csQ0FBQTtvQ0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT087Q0FDUCxTQUFTQSxvQkFBbUI7QUFDOUIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNYLGlCQUFxQixvQkFBb0IsQ0FBQyxFQUMzRixNQUFNLFdBQ1IsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNLHFCQUNSLEdBQUc7RUFDRCxNQUFNLEtBQUE7RUFDTixZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLFFBQVE7RUFDakIsQ0FBQztDQUNILENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsU0FBUyxtQkFBbUIsS0FBSyxNQUFNO0NBQ3JDLElBQUksSUFBSSxXQUFXLFNBQ2pCLE9BQU8sT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sR0FBRztDQUU5QyxPQUFPLEtBQUssR0FBRztBQUNqQjtBQUNBLElBQU0sbUJBQU4sTUFBdUI7Q0FFckIsWUFBWSxVQUFVO3dCQUR0QixZQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssV0FBVztDQUNsQjtDQUNBLFVBQVUsZ0JBQWdCLE1BQU07RUFDOUIsT0FBTyxzQkFBc0IsS0FBSyxnQkFBZ0IsbUJBQW1CLGlCQUFnQixzQkFBcUIsS0FBSyxPQUFPLGlCQUFpQixDQUFDLENBQUM7Q0FDM0k7QUFTRjs7a0NBUlMsUUFBTyxTQUFTLHlCQUF5QixtQkFBbUI7Q0FFakUsT0FBTyxLQUFLLHFCQUFxQlksbUJBQWtCUixTQUFZSSxtQkFBc0IsQ0FBQztBQUN4RixDQUFBO2tDQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPSTtDQUNQLFNBQVNBLGtCQUFpQjtBQUM1QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1osaUJBQXFCLGtCQUFrQixDQUFDLEVBQ3pGLE1BQU0sV0FDUixDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU1RLG9CQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxjQUFjO0FBQ3BCLFNBQVMseUJBQXlCLEtBQUs7Q0E2QnJDLEtBQUssTUFBTSxFQUNULFVBQ0EsZUFDRztFQS9CdUI7R0FDMUIsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtFQUFHO0dBQ0QsVUFBVTtHQUNWLFdBQVc7RUFDYjtDQUlzQixHQUNwQixJQUFJLElBQUksV0FDTixRQUFRLEtBQUtQLG1CQUFvQixXQUFXLDZEQUE2RCxTQUFTLHdFQUF3RSxTQUFTLDhGQUE4RixDQUFDO0FBR3hTO0FBQ0EsSUFBTSxpQkFBTixNQUFxQjtDQUtuQixZQUFZLFlBQVk7d0JBSnhCLGNBQUEsS0FBQSxDQUFBO3dCQUNBLGtCQUFpQixPQUFPWSxnQkFBaUIsRUFDdkMsVUFBVSxLQUNaLENBQUMsQ0FBQTtFQUVDLEtBQUssYUFBYTtDQUNwQjtDQUNBLG9CQUFvQixJQUFJOztFQUN0QixTQUFBLHVCQUFPLEtBQUssb0JBQUEsUUFBQSx5QkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHFCQUFnQixhQUFZLEtBQUssZUFBZSxVQUFVLEVBQUUsSUFBSTtDQUM5RTtDQUNBLE9BQU8sS0FBSztFQUNWLElBQUksSUFBSSxXQUFXLFNBQ2pCLE1BQU0sSUFBSWhCLGFBQWMsUUFBUSxPQUFPLGNBQWMsZUFBZSxjQUFjLHNOQUFzTjtFQUUxUyxhQUFhLHlCQUF5QixHQUFHO0VBQ3pDLE1BQU0sYUFBYSxLQUFLO0VBRXhCLE9BRDRILEdBQUcsSUFDbkgsQ0FBQyxDQUFDLEtBQUssZ0JBQWdCO0dBQ2pDLE9BQU8sSUFBSSxZQUFXLGFBQVk7SUFDaEMsTUFBTSxNQUFNLFdBQVcsTUFBTTtJQUM3QixJQUFJLEtBQUssSUFBSSxRQUFRLElBQUksYUFBYTtJQUN0QyxJQUFJLElBQUksaUJBQ04sSUFBSSxrQkFBa0I7SUFFeEIsSUFBSSxRQUFRLFNBQVMsTUFBTSxXQUFXLElBQUksaUJBQWlCLE1BQU0sT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ2xGLElBQUksQ0FBQyxJQUFJLFFBQVEsSUFBSSxhQUFhLEdBQ2hDLElBQUksaUJBQWlCLGVBQWUsbUJBQW1CO0lBRXpELElBQUksQ0FBQyxJQUFJLFFBQVEsSUFBSSxtQkFBbUIsR0FBRztLQUN6QyxNQUFNLGVBQWUsSUFBSSx3QkFBd0I7S0FDakQsSUFBSSxpQkFBaUIsTUFDbkIsSUFBSSxpQkFBaUIscUJBQXFCLFlBQVk7SUFFMUQ7SUFDQSxJQUFJLElBQUksU0FDTixJQUFJLFVBQVUsSUFBSTtJQUVwQixJQUFJLElBQUksY0FBYztLQUNwQixNQUFNLGVBQWUsSUFBSSxhQUFhLFlBQVk7S0FDbEQsSUFBSSxlQUFlLGlCQUFpQixTQUFTLGVBQWU7SUFDOUQ7SUFDQSxNQUFNLFVBQVUsSUFBSSxjQUFjO0lBQ2xDLElBQUksaUJBQWlCO0lBQ3JCLE1BQU0sdUJBQXVCO0tBQzNCLElBQUksbUJBQW1CLE1BQ3JCLE9BQU87S0FFVCxNQUFNLGFBQWEsSUFBSSxjQUFjO0tBQ3JDLE1BQU0sVUFBVSxJQUFJLFlBQVksSUFBSSxzQkFBc0IsQ0FBQztLQUMzRCxNQUFNLE1BQU0sSUFBSSxlQUFlLElBQUk7S0FDbkMsaUJBQWlCLElBQUksbUJBQW1CO01BQ3RDO01BQ0EsUUFBUSxJQUFJO01BQ1o7TUFDQTtLQUNGLENBQUM7S0FDRCxPQUFPO0lBQ1Q7SUFDQSxNQUFNLFNBQVMsS0FBSywwQkFBMEI7S0FDNUMsSUFBSSxFQUNGLFNBQ0EsUUFDQSxZQUNBLFFBQ0UsZUFBZTtLQUNuQixJQUFJLE9BQU87S0FDWCxJQUFJLFdBQVcsNkJBQ2IsT0FBTyxPQUFPLElBQUksYUFBYSxjQUFjLElBQUksZUFBZSxJQUFJO0tBRXRFLElBQUksV0FBVyxHQUNiLFNBQVMsQ0FBQyxDQUFDLE9BQU8sc0JBQXNCO0tBRTFDLElBQUksS0FBSyxVQUFVLE9BQU8sU0FBUztLQUNuQyxJQUFJLElBQUksaUJBQWlCLFVBQVUsT0FBTyxTQUFTLFVBQVU7TUFDM0QsTUFBTSxlQUFlO01BQ3JCLE9BQU8sS0FBSyxRQUFRLGFBQWEsRUFBRTtNQUNuQyxJQUFJO09BQ0YsT0FBTyxTQUFTLEtBQUssS0FBSyxNQUFNLElBQUksSUFBSTtNQUMxQyxTQUFTLE9BQU87T0FDZCxPQUFPO09BQ1AsSUFBSSxJQUFJO1FBQ04sS0FBSztRQUNMLE9BQU87U0FDTDtTQUNBLE1BQU07UUFDUjtPQUNGO01BQ0Y7S0FDRjtLQUNBLElBQUksSUFBSTtNQUNOLFNBQVMsS0FBSyxJQUFJLGFBQWE7T0FDN0I7T0FDQTtPQUNBO09BQ0E7T0FDQSxLQUFLLE9BQU8sS0FBQTtNQUNkLENBQUMsQ0FBQztNQUNGLFNBQVMsU0FBUztLQUNwQixPQUNFLFNBQVMsTUFBTSxJQUFJLGtCQUFrQjtNQUNuQyxPQUFPO01BQ1A7TUFDQTtNQUNBO01BQ0EsS0FBSyxPQUFPLEtBQUE7S0FDZCxDQUFDLENBQUM7SUFFTixDQUFDO0lBQ0QsTUFBTSxVQUFVLEtBQUsscUJBQW9CLFVBQVM7S0FDaEQsTUFBTSxFQUNKLFFBQ0UsZUFBZTtLQUNuQixNQUFNLE1BQU0sSUFBSSxrQkFBa0I7TUFDaEM7TUFDQSxRQUFRLElBQUksVUFBVTtNQUN0QixZQUFZLElBQUksY0FBYztNQUM5QixLQUFLLE9BQU8sS0FBQTtLQUNkLENBQUM7S0FDRCxTQUFTLE1BQU0sR0FBRztJQUNwQixDQUFDO0lBQ0QsSUFBSSxZQUFZO0lBQ2hCLElBQUksSUFBSSxTQUNOLFlBQVksS0FBSyxxQkFBb0IsTUFBSztLQUN4QyxNQUFNLEVBQ0osUUFDRSxlQUFlO0tBQ25CLE1BQU0sTUFBTSxJQUFJLGtCQUFrQjtNQUNoQyxPQUFPLElBQUksYUFBYSxxQkFBcUIsY0FBYztNQUMzRCxRQUFRLElBQUksVUFBVTtNQUN0QixZQUFZLElBQUksY0FBYztNQUM5QixLQUFLLE9BQU8sS0FBQTtLQUNkLENBQUM7S0FDRCxTQUFTLE1BQU0sR0FBRztJQUNwQixDQUFDO0lBRUgsSUFBSSxjQUFjO0lBQ2xCLE1BQU0saUJBQWlCLEtBQUsscUJBQW9CLFVBQVM7S0FDdkQsSUFBSSxDQUFDLGFBQWE7TUFDaEIsU0FBUyxLQUFLLGVBQWUsQ0FBQztNQUM5QixjQUFjO0tBQ2hCO0tBQ0EsSUFBSSxnQkFBZ0I7TUFDbEIsTUFBTSxjQUFjO01BQ3BCLFFBQVEsTUFBTTtLQUNoQjtLQUNBLElBQUksTUFBTSxrQkFDUixjQUFjLFFBQVEsTUFBTTtLQUU5QixJQUFJLElBQUksaUJBQWlCLFVBQVUsQ0FBQyxDQUFDLElBQUksY0FDdkMsY0FBYyxjQUFjLElBQUk7S0FFbEMsU0FBUyxLQUFLLGFBQWE7SUFDN0IsQ0FBQztJQUNELE1BQU0sZUFBZSxLQUFLLHFCQUFvQixVQUFTO0tBQ3JELElBQUksV0FBVztNQUNiLE1BQU0sY0FBYztNQUNwQixRQUFRLE1BQU07S0FDaEI7S0FDQSxJQUFJLE1BQU0sa0JBQ1IsU0FBUyxRQUFRLE1BQU07S0FFekIsU0FBUyxLQUFLLFFBQVE7SUFDeEIsQ0FBQztJQUNELElBQUksaUJBQWlCLFFBQVEsTUFBTTtJQUNuQyxJQUFJLGlCQUFpQixTQUFTLE9BQU87SUFDckMsSUFBSSxpQkFBaUIsV0FBVyxTQUFTO0lBQ3pDLElBQUksaUJBQWlCLFNBQVMsT0FBTztJQUNyQyxNQUFNLHVCQUF1QixJQUFJLGtCQUFrQixJQUFJO0lBQ3ZELE1BQU0seUJBQXlCLElBQUksa0JBQWtCLElBQUk7SUFDekQsSUFBSSx3QkFDRixJQUFJLGlCQUFpQixZQUFZLGNBQWM7SUFFakQsSUFBSSx3QkFBd0IsWUFBWSxRQUFRLElBQUksUUFDbEQsSUFBSSxPQUFPLGlCQUFpQixZQUFZLFlBQVk7SUFFdEQsSUFBSSxLQUFLLE9BQU87SUFDaEIsU0FBUyxLQUFLLEVBQ1osTUFBTSxjQUFjLEtBQ3RCLENBQUM7SUFDRCxhQUFhO0tBQ1gsSUFBSSxvQkFBb0IsU0FBUyxPQUFPO0tBQ3hDLElBQUksb0JBQW9CLFNBQVMsT0FBTztLQUN4QyxJQUFJLG9CQUFvQixRQUFRLE1BQU07S0FDdEMsSUFBSSxvQkFBb0IsV0FBVyxTQUFTO0tBQzVDLElBQUksd0JBQ0YsSUFBSSxvQkFBb0IsWUFBWSxjQUFjO0tBRXBELElBQUksd0JBQXdCLFlBQVksUUFBUSxJQUFJLFFBQ2xELElBQUksT0FBTyxvQkFBb0IsWUFBWSxZQUFZO0tBRXpELElBQUksSUFBSSxlQUFlLElBQUksTUFDekIsSUFBSSxNQUFNO0lBRWQ7R0FDRixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0NBQ0o7QUFVRjs7Z0NBVFMsUUFBTyxTQUFTLHVCQUF1QixtQkFBbUI7Q0FFL0QsT0FBTyxLQUFLLHFCQUFxQmlCLGlCQUFnQlYsU0FBWSxVQUFVLENBQUM7QUFDMUUsQ0FBQTtnQ0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT1U7Q0FDUCxTQUFTQSxnQkFBZTtDQUN4QixZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNkLGlCQUFxQixnQkFBZ0IsQ0FBQztFQUN2RixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsWUFBWSxPQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU0sV0FDUixDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQUk7Q0FDSCxTQUFVLGlCQUFpQjtDQUMxQixnQkFBZ0IsZ0JBQWdCLGtCQUFrQixLQUFLO0NBQ3ZELGdCQUFnQixnQkFBZ0Isd0JBQXdCLEtBQUs7Q0FDN0QsZ0JBQWdCLGdCQUFnQiw2QkFBNkIsS0FBSztDQUNsRSxnQkFBZ0IsZ0JBQWdCLHNCQUFzQixLQUFLO0NBQzNELGdCQUFnQixnQkFBZ0Isa0JBQWtCLEtBQUs7Q0FDdkQsZ0JBQWdCLGdCQUFnQiwyQkFBMkIsS0FBSztDQUNoRSxnQkFBZ0IsZ0JBQWdCLFdBQVcsS0FBSztDQUNoRCxnQkFBZ0IsZ0JBQWdCLFNBQVMsS0FBSztBQUNoRCxFQUFBLENBQUcsb0JBQW9CLGtCQUFrQixDQUFDLEVBQUU7QUFDNUMsU0FBUyxnQkFBZ0IsTUFBTSxXQUFXO0NBQ3hDLE9BQU87RUFDTCxPQUFPO0VBQ1AsWUFBWTtDQUNkO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixHQUFHLFVBQVU7Q0FDdEMsSUFBSSxXQUFXO0VBQ2IsTUFBTSxlQUFlLElBQUksSUFBSSxTQUFTLEtBQUksTUFBSyxFQUFFLEtBQUssQ0FBQztFQUN2RCxJQUFJLGFBQWEsSUFBSSxnQkFBZ0IsZ0JBQWdCLEtBQUssYUFBYSxJQUFJLGdCQUFnQix1QkFBdUIsR0FDaEgsTUFBTSxJQUFJLE1BQU0sdUpBQXVKO0VBRXpLLE1BQU0scUJBQXFCLGFBQWEsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLLGFBQWEsSUFBSSxnQkFBZ0IsR0FBRztFQUMxRyxJQUFJLGFBQWEsSUFBSSxnQkFBZ0IscUJBQXFCLEtBQUssb0JBQzdELE1BQU0sSUFBSSxNQUFNLDRJQUE0STtDQUVoSztDQUNBLE1BQU0sWUFBWTtFQUFDO0VBQVk7RUFBYztFQUF3QjtHQUNuRSxTQUFTO0dBQ1QsYUFBYTtFQUNmO0VBQUc7R0FDRCxTQUFTO0dBQ1Qsa0JBQWtCO0lBQ2hCLE9BQU8sT0FBTyxZQUFZO0dBQzVCO0VBQ0Y7RUFBRztHQUNELFNBQVM7R0FDVCxVQUFVO0dBQ1YsT0FBTztFQUNUO0NBQUM7Q0FDRCxLQUFLLE1BQU0sV0FBVyxVQUNwQixVQUFVLEtBQUssR0FBRyxRQUFRLFVBQVU7Q0FFdEMsT0FBTyx5QkFBeUIsU0FBUztBQUMzQztBQUNBLFNBQVMsaUJBQWlCLGdCQUFnQjtDQUN4QyxPQUFPLGdCQUFnQixnQkFBZ0IsY0FBYyxlQUFlLEtBQUksa0JBQWlCO0VBQ3ZGLE9BQU87R0FDTCxTQUFTO0dBQ1QsVUFBVTtHQUNWLE9BQU87RUFDVDtDQUNGLENBQUMsQ0FBQztBQUNKO0FBQ0EsSUFBTSx3QkFBd0IsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksMEJBQTBCLEVBQUU7QUFDN0gsU0FBUyx5QkFBeUI7Q0FDaEMsT0FBTyxnQkFBZ0IsZ0JBQWdCLG9CQUFvQixDQUFDO0VBQzFELFNBQVM7RUFDVCxZQUFZO0NBQ2QsR0FBRztFQUNELFNBQVM7RUFDVCxhQUFhO0VBQ2IsT0FBTztDQUNULENBQUMsQ0FBQztBQUNKO0FBQ0EsU0FBUyxzQkFBc0IsRUFDN0IsWUFDQSxjQUNDO0NBQ0QsTUFBTSxZQUFZLENBQUM7Q0FDbkIsSUFBSSxlQUFlLEtBQUEsR0FDakIsVUFBVSxLQUFLO0VBQ2IsU0FBUztFQUNULFVBQVU7Q0FDWixDQUFDO0NBRUgsSUFBSSxlQUFlLEtBQUEsR0FDakIsVUFBVSxLQUFLO0VBQ2IsU0FBUztFQUNULFVBQVU7Q0FDWixDQUFDO0NBRUgsT0FBTyxnQkFBZ0IsZ0JBQWdCLHlCQUF5QixTQUFTO0FBQzNFO0FBQ0EsU0FBUyx1QkFBdUI7Q0FDOUIsT0FBTyxnQkFBZ0IsZ0JBQWdCLGtCQUFrQixDQUFDO0VBQ3hELFNBQVM7RUFDVCxVQUFVO0NBQ1osQ0FBQyxDQUFDO0FBQ0o7QUFDQSxTQUFTLG1CQUFtQjtDQUMxQixPQUFPLGdCQUFnQixnQkFBZ0IsY0FBYztFQUFDO0VBQW9CO0dBQ3hFLFNBQVM7R0FDVCxZQUFZO0VBQ2Q7RUFBRztHQUNELFNBQVM7R0FDVCxVQUFVO0dBQ1YsT0FBTztFQUNUO0NBQUMsQ0FBQztBQUNKO0FBQ0EsU0FBUyw0QkFBNEI7Q0FDbkMsT0FBTyxnQkFBZ0IsZ0JBQWdCLHVCQUF1QixDQUFDO0VBQzdELFNBQVM7RUFDVCxrQkFBa0I7R0FDaEIsTUFBTSxvQkFBb0IsT0FBTyxhQUFhO0lBQzVDLFVBQVU7SUFDVixVQUFVO0dBQ1osQ0FBQztHQUNELElBQUksYUFBYSxzQkFBc0IsTUFDckMsTUFBTSxJQUFJLE1BQU0sa0dBQWtHO0dBRXBILE9BQU87RUFDVDtDQUNGLENBQUMsQ0FBQztBQUNKO0FBQ0EsU0FBUyxZQUFZO0NBQ25CLE9BQU8sZ0JBQWdCLGdCQUFnQixPQUFPLENBQUMsY0FBYztFQUMzRCxTQUFTO0VBQ1QsYUFBYTtDQUNmLENBQUMsQ0FBQztBQUNKO0FBQ0EsU0FBUyxVQUFVO0NBQ2pCLE9BQU8sZ0JBQWdCLGdCQUFnQixLQUFLLENBQUMsZ0JBQWdCO0VBQzNELFNBQVM7RUFDVCxhQUFhO0NBQ2YsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxJQUFNLHVCQUFOLE1BQU0scUJBQXFCO0NBQ3pCLE9BQU8sVUFBVTtFQUNmLE9BQU87R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLHFCQUFxQixDQUFDLENBQUMsVUFBVTtFQUMvQztDQUNGO0NBQ0EsT0FBTyxZQUFZLFVBQVUsQ0FBQyxHQUFHO0VBQy9CLE9BQU87R0FDTCxVQUFVO0dBQ1YsV0FBVyxzQkFBc0IsT0FBTyxDQUFDLENBQUM7RUFDNUM7Q0FDRjtBQXVCRjs7c0NBdEJTLFFBQU8sU0FBUyw2QkFBNkIsbUJBQW1CO0NBQ3JFLE9BQU8sS0FBSyxxQkFBcUJlLHVCQUFzQjtBQUN6RCxDQUFBO3NDQUNPLFFBQXNCLGlDQUFvQixFQUMvQyxNQUFNQSxzQkFDUixDQUFDLENBQUE7c0NBQ00sUUFBc0IsaUNBQW9CLEVBQy9DLFdBQVc7Q0FBQztDQUFxQjtFQUMvQixTQUFTO0VBQ1QsYUFBYTtFQUNiLE9BQU87Q0FDVDtDQUFHO0VBQ0QsU0FBUztFQUNULFVBQVU7Q0FDWjtDQUFHLHNCQUFzQjtFQUN2QixZQUFZO0VBQ1osWUFBWTtDQUNkLENBQUMsQ0FBQyxDQUFDO0NBQVk7RUFDYixTQUFTO0VBQ1QsVUFBVTtDQUNaO0FBQUMsRUFDSCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2YsaUJBQXFCLHNCQUFzQixDQUFDO0VBQzdGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxXQUFXO0dBQUM7R0FBcUI7SUFDL0IsU0FBUztJQUNULGFBQWE7SUFDYixPQUFPO0dBQ1Q7R0FBRztJQUNELFNBQVM7SUFDVCxVQUFVO0dBQ1o7R0FBRyxzQkFBc0I7SUFDdkIsWUFBWTtJQUNaLFlBQVk7R0FDZCxDQUFDLENBQUMsQ0FBQztHQUFZO0lBQ2IsU0FBUztJQUNULFVBQVU7R0FDWjtFQUFDLEVBQ0gsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxtQkFBTixNQUF1QixDQVV2Qjs7a0NBVFMsUUFBTyxTQUFTLHlCQUF5QixtQkFBbUI7Q0FDakUsT0FBTyxLQUFLLHFCQUFxQmdCLG1CQUFrQjtBQUNyRCxDQUFBO2tDQUNPLFFBQXNCLGlDQUFvQixFQUMvQyxNQUFNQSxrQkFDUixDQUFDLENBQUE7a0NBQ00sUUFBc0IsaUNBQW9CLEVBQy9DLFdBQVcsQ0FBQyxrQkFBa0IsdUJBQXVCLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDcEUsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNoQixpQkFBcUIsa0JBQWtCLENBQUM7RUFDekYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFdBQVcsQ0FBQyxrQkFBa0IsdUJBQXVCLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFDcEUsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSx3QkFBTixNQUE0QixDQVU1Qjs7dUNBVFMsUUFBTyxTQUFTLDhCQUE4QixtQkFBbUI7Q0FDdEUsT0FBTyxLQUFLLHFCQUFxQmlCLHdCQUF1QjtBQUMxRCxDQUFBO3VDQUNPLFFBQXNCLGlDQUFvQixFQUMvQyxNQUFNQSx1QkFDUixDQUFDLENBQUE7dUNBQ00sUUFBc0IsaUNBQW9CLEVBQy9DLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFVBQVUsRUFDM0MsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNqQixpQkFBcUIsdUJBQXVCLENBQUM7RUFDOUYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLFVBQVUsRUFDM0MsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHOzs7Ozs7OztBQ3BqRUgsSUFBTSxpQ0FBaUMsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksbUNBQW1DLEVBQUU7QUFDL0ksSUFBTSxPQUFPO0FBQ2IsSUFBTSxVQUFVO0FBQ2hCLElBQU0sU0FBUztBQUNmLElBQU0sY0FBYztBQUNwQixJQUFNLFVBQVU7QUFDaEIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxnQkFBZ0IsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksc0NBQXNDLEVBQUU7QUFDakksSUFBTSxrQkFBa0IsQ0FBQyxPQUFPLE1BQU07QUFDdEMsU0FBUyxxQkFBcUIsS0FBSyxTQUFTO0NBQzFDLE1BQU0sRUFDSixlQUNBLFFBQ0EscUJBQ0EsZ0NBQ0EsZ0NBQ0EsZ0NBQ0U7Q0FDSixNQUFNLEVBQ0osZUFBZSxnQkFDZixRQUFRLGtCQUNOO0NBQ0osSUFBSSxDQUFDLGlCQUFpQixtQkFBbUIsU0FBUyxrQkFBa0IsVUFBVSxDQUFDLHVCQUF1QixDQUFDLGtCQUFrQixrQkFBa0IsVUFBVSxDQUFDLGdCQUFnQixTQUFTLGFBQWEsS0FBSyxDQUFDLGtDQUFrQyxlQUFlLEdBQUcsS0FBSyxDQUFDLGtDQUFrQyx1QkFBdUIsR0FBRyxLQUFLLENBQUMsZ0NBQWdDLDJCQUEyQixJQUFJLE9BQU8sS0FBSyxzQkFBc0IsSUFBSSxLQUFLLE9BQUEsV0FBQSxRQUFBLFdBQUEsS0FBQSxJQUFBLEtBQUEsSUFBTSxPQUFTLEdBQUcsT0FBTSxPQUM5YixPQUFPO0NBRVQsT0FBTztBQUNUO0FBQ0EsU0FBUyxvQkFBb0IsU0FBUyxnQkFBZ0I7Q0FDcEQsT0FBTyxPQUFPLG1CQUFtQixZQUFZLGVBQWUsaUJBQWlCLGVBQWUsaUJBQWlCLFFBQVE7QUFDdkg7QUFDQSxTQUFTLHVCQUF1QixLQUFLLFNBQVMsZUFBZSxXQUFXLFVBQVUscUJBQXFCLE9BQU87Q0FDNUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHFCQUFxQixLQUFLLE9BQU8sR0FDM0QsT0FBTztDQUVULElBQTRELFdBQzFELE1BQU0sSUFBSWtCLGFBQWMsTUFBTSxhQUFhLDJNQUFxTjtDQUVsUSxJQUFJLENBQUMsVUFBVTtFQUNiLE1BQU0sYUFBMEgsSUFBSTtFQUNwSSxXQUFXLGFBQWEsS0FBSyxVQUFVO0NBQ3pDO0NBQ0EsTUFBTSxXQUFXLGNBQWMsSUFBSSxVQUFVLElBQUk7Q0FDakQsSUFBSSxDQUFDLFVBQ0gsT0FBTztDQUVULE1BQU0sR0FDSCxPQUFPLGdCQUNQLGdCQUFnQixlQUNoQixVQUFVLGNBQ1YsU0FBUyxTQUNULGNBQWMsYUFDZCxVQUFVLFFBQ1Q7Q0FDSixJQUFJLE9BQU87Q0FDWCxRQUFRLGNBQVI7RUFDRSxLQUFLO0dBQ0gsT0FBTyxXQUFXLGFBQWE7R0FDL0I7RUFDRixLQUFLO0dBQ0gsT0FBTyxJQUFJLEtBQUssQ0FBQyxXQUFXLGFBQWEsQ0FBQyxDQUFDO0dBQzNDO0NBQ0o7Q0FDQSxJQUFJLFVBQVUsSUFBSSxZQUFZLFdBQVc7Q0FDekMsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUFXO0VBQ2pELE1BQU0sRUFDSixlQUFlLG1CQUNiO0VBQ0osTUFBTSxtQkFBbUIsb0JBQW9CLFNBQVMsY0FBYztFQUNwRSxVQUFVLDhCQUE4QixJQUFJLEtBQUssU0FBUyxxQkFBQSxRQUFBLHFCQUFBLEtBQUEsSUFBQSxtQkFBb0IsQ0FBQyxDQUFDO0NBQ2xGO0NBQ0EsT0FBTyxJQUFJLGFBQWE7RUFDdEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsMkJBQTJCLEtBQUssTUFBTTtDQUM3QyxNQUFNLFVBQVUsT0FBTyxhQUFhO0NBQ3BDLElBQUksQ0FBQyxxQkFBcUIsS0FBSyxPQUFPLEdBQ3BDLE9BQU8sS0FBSyxHQUFHO0NBRWpCLE1BQU0sZ0JBQWdCLE9BQU8sYUFBYTtDQUN4QixPQUFPLGdDQUFnQyxFQUN2RCxVQUFVLEtBQ1osQ0FBQztDQUNELE1BQU0sYUFBMEgsSUFBSTtDQUVwSSxNQUFNLGlCQUFpQix1QkFBdUIsS0FBSyxTQUFTLGVBQWUsTUFEMUQsYUFBYSxLQUFLLFVBQ3FELEdBQUcsSUFBSTtDQUMvRixJQUFJLGdCQUNGLE9BQU8sR0FBRyxjQUFjO0NBK0IxQixPQTdCZSxLQUFLLEdBNkJSO0FBQ2Q7QUFDQSxTQUFTLGVBQWUsS0FBSztDQUMzQixNQUFNLFVBQVUsSUFBSTtDQUNwQixPQUFPLFFBQVEsSUFBSSxlQUFlLEtBQUssUUFBUSxJQUFJLHFCQUFxQixLQUFLLFFBQVEsSUFBSSxRQUFRO0FBQ25HO0FBQ0EsSUFBTSx1REFBdUMsSUFBSSxJQUFJO0NBQUM7Q0FBWTtDQUFXO0FBQVUsQ0FBQztBQUN4RixTQUFTLDJCQUEyQixTQUFTO0NBQzNDLE1BQU0sZUFBZSxRQUFRLElBQUksZUFBZTtDQUNoRCxJQUFJLENBQUMsY0FDSCxPQUFPO0NBRVQsT0FBTyxhQUFhLE1BQU0sR0FBRyxDQUFDLENBQUMsTUFBSyxjQUFhO0VBQy9DLE1BQU0sZ0JBQWdCLFVBQVUsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3BFLE9BQU8scUNBQXFDLElBQUksYUFBYTtDQUMvRCxDQUFDO0FBQ0g7QUFJQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3BDLE9BQU8sVUFBVSxjQUFjLFVBQVU7QUFDM0M7QUFDQSxTQUFTLHVCQUF1QixLQUFLO0NBQ25DLE1BQU0sRUFDSixpQkFDQSxnQkFDRTtDQUNKLE9BQU8sbUJBQW1CLGdCQUFnQixhQUFhLGdCQUFnQjtBQUN6RTtBQWNBLFNBQVMsb0JBQW9CLFFBQVE7Q0FDbkMsTUFBTSxlQUFlLElBQUksZ0JBQWdCLGtCQUFrQixrQkFBa0IsU0FBUyxPQUFPLFNBQVMsQ0FBQztDQUN2RyxhQUFhLEtBQUs7Q0FDbEIsT0FBTyxhQUFhLFNBQVM7QUFDL0I7QUFDQSxTQUFTLGFBQWEsU0FBUyxrQkFBa0I7Q0FDL0MsTUFBTSxFQUNKLFFBQ0EsUUFDQSxpQkFDRTtDQUNKLE1BQU0sZ0JBQWdCLG9CQUFvQixNQUFNO0NBQ2hELElBQUksaUJBQWlCLFFBQVEsY0FBYztDQUMzQyxJQUFJLDBCQUEwQixpQkFDNUIsaUJBQWlCLG9CQUFvQixjQUFjO01BQzlDLElBQUksT0FBTyxtQkFBbUIsVUFDbkMsaUJBQWlCO0NBSW5CLE9BQU8sYUFETSxhQUREO0VBQUM7RUFBUTtFQUFjO0VBQWtCO0VBQWdCO0NBQWEsQ0FBQyxDQUFDLEtBQUssSUFDN0QsQ0FDTCxDQUFDO0FBQzFCO0FBV0EsU0FBUyxXQUFXLFFBQVE7Q0FDMUIsTUFBTSxTQUFTLEtBQUssTUFBTTtDQUUxQixPQURjLFdBQVcsS0FBSyxTQUFRLE1BQUssRUFBRSxXQUFXLENBQUMsQ0FDOUMsQ0FBQyxDQUFDO0FBQ2Y7QUFDQSxTQUFTLHNCQUFzQixjQUFjO0NBQzNDLE9BQU87RUFBQztHQUNOLFNBQVM7R0FDVCxrQkFBa0I7SUFDaEIsdUJBQXdCLHFCQUFxQjtJQUM3QyxPQUFBLGVBQUEsRUFDRSxlQUFlLEtBQUEsR0FDWixZQUNMO0dBQ0Y7RUFDRjtFQUFHO0dBQ0QsU0FBUztHQUNULFVBQVU7R0FDVixPQUFPO0VBQ1Q7RUFBRztHQUNELFNBQVM7R0FDVCxPQUFPO0dBQ1Asa0JBQWtCO0lBQ2hCLE1BQU0sU0FBUyxPQUFPLGNBQWM7SUFDcEMsTUFBTSxhQUFhLE9BQU8sYUFBYTtJQUN2QyxhQUFhO0tBQ1gsT0FBTyxXQUFXLENBQUMsQ0FBQyxXQUFXO01BQzdCLFdBQVcsZ0JBQWdCO0tBQzdCLENBQUM7SUFDSDtHQUNGO0VBQ0Y7Q0FBQztBQUNIO0FBQ0EsU0FBUyw4QkFBOEIsS0FBSyxTQUFTLGtCQUFrQjtDQUNyRSxNQUFNLGtDQUFrQixJQUFJLElBQUk7Q0FDaEMsT0FBTyxJQUFJLE1BQU0sU0FBUyxFQUN4QixJQUFJLFFBQVEsTUFBTTtFQUNoQixNQUFNLFFBQVEsUUFBUSxJQUFJLFFBQVEsSUFBSTtFQUV0QyxJQUFJLE9BQU8sVUFBVSxjQUFjLGtCQUFDLElBRGhCLElBQUk7R0FBQztHQUFPO0dBQU87RUFBUSxDQUNMLEVBQUEsQ0FBRSxJQUFJLElBQUksR0FDbEQsT0FBTztFQUVULFFBQU8sZUFBYztHQUNuQixNQUFNLE9BQU8sT0FBTyxNQUFNLFdBQUEsQ0FBWSxZQUFZO0dBQ2xELElBQUksQ0FBQyxpQkFBaUIsU0FBUyxVQUFVLEtBQUssQ0FBQyxnQkFBZ0IsSUFBSSxHQUFHLEdBQUc7SUFDdkUsZ0JBQWdCLElBQUksR0FBRztJQUN2QixNQUFNLGVBQWVDLGVBQWdCLEdBQUc7SUFDeEMsUUFBUSxLQUFLQyxtQkFBb0IsT0FBTywrQkFBK0IsV0FBVywrSkFBeUssV0FBVyxzQkFBc0IsYUFBYSwwUkFBOFMsQ0FBQztHQUMxbEI7R0FDQSxPQUFPLE1BQU0sTUFBTSxRQUFRLENBQUMsVUFBVSxDQUFDO0VBQ3pDO0NBQ0YsRUFDRixDQUFDO0FBQ0g7QUFpQkEsSUFBTSx5Q0FBd0MsSUFBSSxZQUFZO0NBQUM7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7QUFBVSxDQUFDO0FBQzl6QixJQUFJO0FBQ0osU0FBUyxhQUFhLE9BQU87O0NBQzNCLENBQUEsZUFBQSxpQkFBQSxRQUFBLGlCQUFBLEtBQUEsTUFBQSxjQUFnQixJQUFJLFlBQVk7Q0FDaEMsTUFBTSxhQUFhLFlBQVksT0FBTyxLQUFLO0NBQzNDLElBQUksYUFBYTtDQUNqQixJQUFJLGFBQWE7Q0FDakIsSUFBSSxhQUFhO0NBQ2pCLElBQUksYUFBYTtDQUNqQixJQUFJLGFBQWE7Q0FDakIsSUFBSSxhQUFhO0NBQ2pCLElBQUksYUFBYTtDQUNqQixJQUFJLGFBQWE7Q0FDakIsTUFBTSxzQkFBc0IsV0FBVyxTQUFTO0NBQ2hELE1BQU0sdUJBQXVCLFdBQVcsU0FBUyxLQUFLLEtBQUssS0FBSztDQUNoRSxNQUFNLGNBQWMsSUFBSSxXQUFXLG1CQUFtQjtDQUN0RCxZQUFZLElBQUksVUFBVTtDQUMxQixZQUFZLFdBQVcsVUFBVTtDQUNqQyxNQUFNLGtCQUFrQixJQUFJLFNBQVMsWUFBWSxNQUFNO0NBQ3ZELE1BQU0sVUFBVSx3QkFBd0I7Q0FDeEMsTUFBTSxXQUFXLHNCQUFzQixlQUFnQjtDQUN2RCxnQkFBZ0IsVUFBVSxzQkFBc0IsR0FBRyxVQUFVLEtBQUs7Q0FDbEUsZ0JBQWdCLFVBQVUsc0JBQXNCLEdBQUcsU0FBUyxLQUFLO0NBQ2pFLE1BQU0sa0NBQWtCLElBQUksWUFBWSxFQUFFO0NBQzFDLEtBQUssSUFBSSxjQUFjLEdBQUcsY0FBYyxxQkFBcUIsZUFBZSxJQUFJO0VBQzlFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQ3RCLGdCQUFnQixLQUFLLGdCQUFnQixVQUFVLGNBQWMsSUFBSSxHQUFHLEtBQUs7RUFFM0UsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksS0FBSztHQUM1QixNQUFNLGFBQWEsZ0JBQWdCLElBQUk7R0FDdkMsTUFBTSxXQUFXLGVBQWUsSUFBSSxjQUFjLE9BQU8sZUFBZSxLQUFLLGNBQWMsTUFBTSxlQUFlLE9BQU87R0FDdkgsTUFBTSxZQUFZLGdCQUFnQixJQUFJO0dBQ3RDLE1BQU0sV0FBVyxjQUFjLEtBQUssYUFBYSxPQUFPLGNBQWMsS0FBSyxhQUFhLE1BQU0sY0FBYyxRQUFRO0dBQ3BILGdCQUFnQixLQUFLLGdCQUFnQixJQUFJLE1BQU0sU0FBUyxnQkFBZ0IsSUFBSSxLQUFLLFdBQVc7RUFDOUY7RUFDQSxJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLGdCQUFnQjtFQUNwQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0dBQzNCLE1BQU0sa0JBQWtCLGtCQUFrQixJQUFJLGlCQUFpQixPQUFPLGtCQUFrQixLQUFLLGlCQUFpQixPQUFPLGtCQUFrQixLQUFLLGlCQUFpQixRQUFRO0dBQ3JLLE1BQU0sY0FBYyxnQkFBZ0IsZ0JBQWdCLENBQUMsZ0JBQWdCLG1CQUFtQjtHQUN4RixNQUFNLFFBQVEsZ0JBQWdCLGdCQUFnQixhQUFhLHVCQUF1QixLQUFLLGdCQUFnQixPQUFPO0dBRzlHLE1BQU0sV0FGa0Isa0JBQWtCLElBQUksaUJBQWlCLE9BQU8sa0JBQWtCLEtBQUssaUJBQWlCLE9BQU8sa0JBQWtCLEtBQUssaUJBQWlCLFNBQVMsT0FDakosZ0JBQWdCLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLGdCQUFnQixtQkFBbUIsT0FDMUU7R0FDOUMsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsZ0JBQWdCLGdCQUFnQixVQUFVO0dBQzFDLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsZ0JBQWdCO0dBQ2hCLGdCQUFnQixRQUFRLFVBQVU7RUFDcEM7RUFDQSxhQUFhLGFBQWEsa0JBQWtCO0VBQzVDLGFBQWEsYUFBYSxrQkFBa0I7RUFDNUMsYUFBYSxhQUFhLGtCQUFrQjtFQUM1QyxhQUFhLGFBQWEsa0JBQWtCO0VBQzVDLGFBQWEsYUFBYSxrQkFBa0I7RUFDNUMsYUFBYSxhQUFhLGtCQUFrQjtFQUM1QyxhQUFhLGFBQWEsa0JBQWtCO0VBQzVDLGFBQWEsYUFBYSxrQkFBa0I7Q0FDOUM7Q0FDQSxPQUFPO0VBQUM7RUFBWTtFQUFZO0VBQVk7RUFBWTtFQUFZO0VBQVk7RUFBWTtDQUFVLENBQUMsQ0FBQyxLQUFJLE1BQUssRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtBQUMzSjtBQUVBLElBQU0sc0JBQXNCO0NBQzFCLE1BQU0sU0FBUyxtQkFBbUIsTUFBTTtDQUN4QyxPQUFPLGNBQWMsbUJBQW1CLGFBQWE7Q0FDckQsT0FBTyxPQUFPLG1CQUFtQixNQUFNO0NBQ3ZDLE9BQU8sT0FBTyxtQkFBbUIsTUFBTTtDQUN2QyxPQUFPO0FBQ1QsRUFBQSxDQUFHO0FBQ0gsU0FBUyxtQkFBbUIsY0FBYztDQUN4QyxPQUFPLFNBQVMsYUFBYSxTQUFTLFNBQVM7O0VBQzdDLElBQUksYUFBYSxFQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxLQUFBLElBQUMsUUFBUyxXQUN6Qix5QkFBeUIsWUFBWTtFQUV2QyxNQUFNLFlBQUEsb0JBQUEsWUFBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLEtBQUEsSUFBVyxRQUFTLGNBQUEsUUFBQSxzQkFBQSxLQUFBLElBQUEsb0JBQVksT0FBTyxRQUFRO0VBQ3JELE1BQU0sZUFBZSxTQUFTLElBQUksZUFBZSxNQUFNLEVBQ3JELFVBQVUsS0FDWixDQUFDO0VBQ0QsTUFBTSxnQkFBZ0IsU0FBUyxJQUFJLGVBQWUsTUFBTSxFQUN0RCxVQUFVLEtBQ1osQ0FBQztFQUNELE1BQU0sWUFBWSxTQUFTLElBQUksZ0NBQWdDLE1BQU0sRUFDbkUsVUFBVSxLQUNaLENBQUM7RUFDRCxNQUFNLG9CQUFtQixRQUFPO0dBQzlCLElBQUksZ0JBQWdCLGlCQUFpQixLQUFLO0lBQ3hDLE1BQU0saUJBQWlCLHVCQUF1QixLQUFLLGNBQWMsZUFBZSxTQUFTO0lBQ3pGLElBQUksZ0JBQ0YsSUFBSTtLQUNGLE1BQU0sT0FBTyxlQUFlO0tBRTVCLE9BQU8sT0FBTyxFQUNaLFFBQUEsWUFBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLEtBQUEsSUFGYSxRQUFTLFNBQVEsUUFBUSxNQUFNLElBQUksSUFBSSxLQUd0RCxDQUFDO0lBQ0gsU0FBUyxHQUFHO0tBQ1YsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUN0QyxRQUFRLEtBQUsseUZBQXlGLElBQUksSUFBSSxxRkFBMEYsQ0FBQztJQUU3TTtHQUVKO0VBRUY7RUFDQSxPQUFPLElBQUksaUJBQWlCLFdBQVUsUUFBTyxpQkFBaUIsS0FBSyxTQUFTLFlBQVksR0FBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFHLFFBQVMsY0FBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFjLFFBQVMsV0FBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFXLFFBQVMsT0FBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFPLFFBQVMsT0FBTyxnQkFBZ0I7Q0FDeEw7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLEtBQUssU0FBUyxjQUFjOztDQUNwRCxJQUFJLG1CQUFtQixPQUFPLFlBQVksYUFBYSxRQUFRLEdBQUcsSUFBSTtDQUN0RSxJQUFJLHFCQUFxQixLQUFBLEdBQ3ZCO01BQ0ssSUFBSSxPQUFPLHFCQUFxQixVQUNyQyxtQkFBbUIsRUFDakIsS0FBSyxpQkFDUDtDQUVGLE1BQU0sVUFBVSxpQkFBaUIsbUJBQW1CLGNBQWMsaUJBQWlCLFVBQVUsSUFBSSxZQUFZLGlCQUFpQixPQUFPO0NBQ3JJLE1BQU0sU0FBUyxpQkFBaUIsa0JBQWtCLGFBQWEsaUJBQWlCLFNBQVMsSUFBSSxXQUFXLEVBQ3RHLFlBQVksaUJBQWlCLE9BQy9CLENBQUM7Q0FDRCxPQUFPLElBQUksYUFBQSx3QkFBWSxpQkFBaUIsWUFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBVSxPQUFPLGlCQUFpQixNQUFBLHdCQUFLLGlCQUFpQixVQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFRLE1BQU07RUFDNUc7RUFDQTtFQUNBLGdCQUFnQixpQkFBaUI7RUFDakMsaUJBQWlCLGlCQUFpQjtFQUNsQyxXQUFXLGlCQUFpQjtFQUM1QixPQUFPLGlCQUFpQjtFQUN4QixVQUFVLGlCQUFpQjtFQUMzQixNQUFNLGlCQUFpQjtFQUN2QixVQUFVLGlCQUFpQjtFQUMzQjtFQUNBLFNBQVMsaUJBQWlCO0VBQzFCLGVBQWUsaUJBQWlCO0VBQ2hDLGFBQWEsaUJBQWlCO0VBQzlCLFVBQVUsaUJBQWlCO0VBQzNCLGdCQUFnQixpQkFBaUI7RUFDakMsV0FBVyxpQkFBaUI7RUFDNUIsU0FBUyxpQkFBaUI7Q0FDNUIsQ0FBQztBQUNIO0FBQ0EsSUFBTSxtQkFBTixjQUErQkMsYUFBYztDQTRCM0MsWUFBWSxVQUFVLFNBQVMsY0FBYyxXQUFXLE9BQU8sT0FBTyxrQkFBa0I7RUFDdEYsTUFBTSxVQUFVLEVBQ2QsUUFBUSxTQUNSLGtCQUNJO0dBQ0osSUFBSTtHQUNKLElBQUksVUFBVTtHQUNkLE1BQU0sZ0JBQWdCO0lBQ3BCLFVBQVU7SUFDVixRQUFBLFFBQUEsUUFBQSxLQUFBLEtBQUEsSUFBSyxZQUFZO0dBQ25CO0dBQ0EsWUFBWSxpQkFBaUIsU0FBUyxPQUFPO0dBQzdDLE1BQU0sU0FBUyxPQUFPLEVBQ3BCLE9BQU8sS0FBQSxFQUNULEdBQUcsR0FBSSxZQUFZLENBQUMsRUFDbEIsV0FBVyxTQUNiLENBQUMsSUFBSSxDQUFDLENBQUU7R0FDUixJQUFJO0dBQ0osTUFBTSxVQUFVLElBQUksU0FBUSxNQUFLLFVBQVUsQ0FBQztHQUM1QyxNQUFNLFFBQU8sVUFBUztJQUNwQixPQUFPLElBQUksS0FBSztJQUNoQixZQUFBLFFBQUEsWUFBQSxLQUFBLEtBQUEsUUFBVSxNQUFNO0lBQ2hCLFVBQVUsS0FBQTtHQUNaO0dBQ0EsTUFBTSxLQUFLLE9BQU8sUUFBUSxPQUFPLENBQUMsQ0FBQyxVQUFVO0lBQzNDLE9BQU0sVUFBUztLQUNiLFFBQVEsTUFBTSxNQUFkO01BQ0UsS0FBSyxjQUFjO09BQ2pCLEtBQUssU0FBUyxJQUFJLE1BQU0sT0FBTztPQUMvQixLQUFLLFlBQVksSUFBSSxNQUFNLE1BQU07T0FDakMsSUFBSTtRQUNGLEtBQUssRUFDSCxPQUFPLFFBQVEsTUFBTSxNQUFNLElBQUksSUFBSSxNQUFNLEtBQzNDLENBQUM7T0FDSCxTQUFTLE9BQU87UUFDZCxLQUFLLEVBQ0gsT0FBT0MseUJBQTBCLEtBQUssRUFDeEMsQ0FBQztPQUNIO09BQ0E7TUFDRixLQUFLLGNBQWM7T0FDakIsS0FBSyxVQUFVLElBQUksS0FBSztPQUN4QjtLQUNKO0lBQ0Y7SUFDQSxRQUFPLFVBQVM7S0FDZCxJQUFJLGlCQUFpQixtQkFBbUI7TUFDdEMsS0FBSyxTQUFTLElBQUksTUFBTSxPQUFPO01BQy9CLEtBQUssWUFBWSxJQUFJLE1BQU0sTUFBTTtLQUNuQztLQUNBLEtBQUssRUFDSCxNQUNGLENBQUM7S0FDRCxZQUFZLG9CQUFvQixTQUFTLE9BQU87SUFDbEQ7SUFDQSxnQkFBZ0I7S0FDZCxJQUFJLFNBQ0YsS0FBSyxFQUNILE9BQU8sSUFBSUosYUFBYyxLQUFLLGFBQWEsNkNBQTZDLEVBQzFGLENBQUM7S0FFSCxZQUFZLG9CQUFvQixTQUFTLE9BQU87SUFDbEQ7R0FDRixDQUFDO0dBQ0QsSUFBSSxTQUNGLElBQUksWUFBWTtHQUVsQixPQUFPO0VBQ1QsR0FBRyxjQUFjLE9BQU8sV0FBVyxVQUFVLEtBQUEsR0FBVyxnQkFBZ0I7d0JBL0YxRSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFXLGFBQUEsZUFBQSxlQUFBLENBQUEsR0FDTCxZQUFZLEVBQ2QsV0FBVyxXQUNiLElBQUksQ0FBQyxDQUFBLEdBQUEsQ0FBQSxHQUFBO0dBQ0wsUUFBUSxLQUFLO0dBQ2IsbUJBQW1CLEtBQUE7R0FDckIsQ0FBQyxDQUFBO3dCQUNELGFBQVksYUFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNOLFlBQVksRUFDZCxXQUFXLFlBQ2IsSUFBSSxDQUFDLENBQUEsR0FBQSxDQUFBLEdBQUE7R0FDTCxRQUFRLEtBQUs7R0FDYixtQkFBbUIsS0FBQTtHQUNyQixDQUFDLENBQUE7d0JBQ0QsZUFBYyxhQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ1IsWUFBWSxFQUNkLFdBQVcsY0FDYixJQUFJLENBQUMsQ0FBQSxHQUFBLENBQUEsR0FBQTtHQUNMLFFBQVEsS0FBSztHQUNiLG1CQUFtQixLQUFBO0dBQ3JCLENBQUMsQ0FBQTt3QkFDRCxXQUFVLGVBQWUsS0FBSyxPQUFPLE1BQU0sY0FBYyxLQUFLLE9BQU8sTUFBTSxVQUFVLEtBQUssU0FBUyxJQUFJLEtBQUEsR0FBVyxHQUFJLFlBQVksQ0FBQyxFQUNqSSxXQUFXLFVBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQUNSLFlBQVcsS0FBSyxVQUFVLFdBQVcsQ0FBQTt3QkFDckMsY0FBYSxLQUFLLFlBQVksV0FBVyxDQUFBO0VBc0V2QyxLQUFLLFNBQVMsU0FBUyxJQUFJLFVBQVU7Q0FDdkM7Q0FDQSxJQUFJLE9BQU87RUFDVCxNQUFNLElBQUksS0FBSztFQUNmLEtBQUssU0FBUyxJQUFJLEtBQUEsQ0FBUztFQUMzQixLQUFLLFVBQVUsSUFBSSxLQUFBLENBQVM7RUFDNUIsS0FBSyxZQUFZLElBQUksS0FBQSxDQUFTO0NBQ2hDO0FBQ0YifQ==