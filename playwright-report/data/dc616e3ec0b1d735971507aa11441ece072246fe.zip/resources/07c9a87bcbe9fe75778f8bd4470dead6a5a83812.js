import { t as _defineProperty } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/defineProperty-wQpB4Zl9.js?v=cf17c1b4";
import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
import { $n as Output, Bt as computed, Dn as Host, Do as ɵɵgetInheritedFactory, Ec as Injector, El as ɵɵdefineInjector, En as ElementRef, Hc as RuntimeError, In as Input, Jo as ɵɵlistener, Kc as Version, Mr as afterNextRender, O as booleanAttribute, Pn as Inject, Qn as Optional, Tc as InjectionToken, Ui as setClassMetadata, ao as ɵɵdirectiveInject, ba as ɵɵclassProp, bl as signal, ca as ɵɵNgOnChangesFeature, dr as Service, el as effect, ia as ɵɵControlFeature, io as ɵɵdefineService, ir as Renderer2, la as ɵɵProvidersFeature, mc as DestroyRef, nl as forwardRef, no as ɵɵdefineNgModule, ol as inject, pr as SkipSelf, qn as NgModule, qt as untracked, r as ChangeDetectorRef, sa as ɵɵInheritDefinitionFeature, tn as ApplicationRef, to as ɵɵdefineDirective, ur as Self, va as ɵɵattribute, vi as isPromise, wn as Directive, yc as EventEmitter, yi as isSubscribable } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/core-BV_jmGG7.js?v=cf17c1b4";
import { Cn as from, Wn as Subject, fn as map, rr as Subscription } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zipWith-DkrnN79P.js?v=cf17c1b4";
import { f as forkJoin } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/esm5-1bPjeIHk.js?v=cf17c1b4";
import { s as getDOM } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/_xhr-chunk-CYugLJIp.js?v=cf17c1b4";
//#region node_modules/@angular/forms/fesm2022/forms.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _BaseControlValueAccessor;
var _BuiltInControlValueAccessor;
var _CheckboxControlValueAccessor;
var _DefaultValueAccessor;
var _AbstractValidatorDirective;
var _MaxValidator;
var _MinValidator;
var _RequiredValidator;
var _CheckboxRequiredValidator;
var _EmailValidator;
var _MinLengthValidator;
var _MaxLengthValidator;
var _PatternValidator;
var _NgControlStatus;
var _NgControlStatusGroup;
var _NgForm;
var _AbstractFormGroupDirective;
var _NgModelGroup;
var _NgModel;
var _ɵNgNoValidate;
var _NumberValueAccessor;
var _RadioControlRegistry;
var _RadioControlValueAccessor;
var _RangeValueAccessor;
var _AbstractFormDirective;
var _FormArrayDirective;
var _FormControlDirective;
var _FormGroupName;
var _FormArrayName;
var _FormControlName;
var _FormGroupDirective;
var _SelectControlValueAccessor;
var _NgSelectOption;
var _SelectMultipleControlValueAccessor;
var _ɵNgSelectMultipleOption;
var _ɵInternalFormsSharedModule;
var _FormBuilder;
var _NonNullableFormBuilder;
var _UntypedFormBuilder;
var _FormsModule;
var _ReactiveFormsModule;
var BaseControlValueAccessor = class {
	constructor(_renderer, _elementRef) {
		_defineProperty(this, "_renderer", void 0);
		_defineProperty(this, "_elementRef", void 0);
		_defineProperty(this, "onChange", (_) => {});
		_defineProperty(this, "onTouched", () => {});
		this._renderer = _renderer;
		this._elementRef = _elementRef;
	}
	setProperty(key, value) {
		this._renderer.setProperty(this._elementRef.nativeElement, key, value);
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	setDisabledState(isDisabled) {
		this.setProperty("disabled", isDisabled);
	}
};
_BaseControlValueAccessor = BaseControlValueAccessor;
_defineProperty(BaseControlValueAccessor, "ɵfac", function BaseControlValueAccessor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _BaseControlValueAccessor)(ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef));
});
_defineProperty(BaseControlValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({ type: _BaseControlValueAccessor }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BaseControlValueAccessor, [{ type: Directive }], () => [{ type: Renderer2 }, { type: ElementRef }], null);
})();
var BuiltInControlValueAccessor = class extends BaseControlValueAccessor {};
_BuiltInControlValueAccessor = BuiltInControlValueAccessor;
_defineProperty(BuiltInControlValueAccessor, "ɵfac", /* @__PURE__ */ (() => {
	let ɵBuiltInControlValueAccessor_BaseFactory;
	return function BuiltInControlValueAccessor_Factory(__ngFactoryType__) {
		return (ɵBuiltInControlValueAccessor_BaseFactory || (ɵBuiltInControlValueAccessor_BaseFactory = ɵɵgetInheritedFactory(_BuiltInControlValueAccessor)))(__ngFactoryType__ || _BuiltInControlValueAccessor);
	};
})());
_defineProperty(BuiltInControlValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _BuiltInControlValueAccessor,
	features: [ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BuiltInControlValueAccessor, [{ type: Directive }], null, null);
})();
var NG_VALUE_ACCESSOR = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "NgValueAccessor" : "");
var CHECKBOX_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => CheckboxControlValueAccessor),
	multi: true
};
var CheckboxControlValueAccessor = class extends BuiltInControlValueAccessor {
	writeValue(value) {
		this.setProperty("checked", value);
	}
};
_CheckboxControlValueAccessor = CheckboxControlValueAccessor;
_defineProperty(CheckboxControlValueAccessor, "ɵfac", /* @__PURE__ */ (() => {
	let ɵCheckboxControlValueAccessor_BaseFactory;
	return function CheckboxControlValueAccessor_Factory(__ngFactoryType__) {
		return (ɵCheckboxControlValueAccessor_BaseFactory || (ɵCheckboxControlValueAccessor_BaseFactory = ɵɵgetInheritedFactory(_CheckboxControlValueAccessor)))(__ngFactoryType__ || _CheckboxControlValueAccessor);
	};
})());
_defineProperty(CheckboxControlValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _CheckboxControlValueAccessor,
	selectors: [
		[
			"input",
			"type",
			"checkbox",
			"formControlName",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"checkbox",
			"formControl",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"checkbox",
			"ngModel",
			"",
			3,
			"ngNoCva",
			""
		]
	],
	hostBindings: function CheckboxControlValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("change", function CheckboxControlValueAccessor_change_HostBindingHandler($event) {
			return ctx.onChange($event.target.checked);
		})("blur", function CheckboxControlValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		});
	},
	standalone: false,
	features: [ɵɵProvidersFeature([CHECKBOX_VALUE_ACCESSOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CheckboxControlValueAccessor, [{
		type: Directive,
		args: [{
			selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]",
			host: {
				"(change)": "onChange($any($event.target).checked)",
				"(blur)": "onTouched()"
			},
			providers: [CHECKBOX_VALUE_ACCESSOR],
			standalone: false
		}]
	}], null, null);
})();
var DEFAULT_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => DefaultValueAccessor),
	multi: true
};
function _isAndroid() {
	const userAgent = getDOM() ? getDOM().getUserAgent() : "";
	return /android (\d+)/.test(userAgent.toLowerCase());
}
var COMPOSITION_BUFFER_MODE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "CompositionEventMode" : "");
var DefaultValueAccessor = class extends BaseControlValueAccessor {
	constructor(renderer, elementRef, _compositionMode) {
		super(renderer, elementRef);
		_defineProperty(this, "_compositionMode", void 0);
		_defineProperty(this, "_composing", false);
		this._compositionMode = _compositionMode;
		if (this._compositionMode == null) this._compositionMode = !_isAndroid();
	}
	writeValue(value) {
		const normalizedValue = value == null ? "" : value;
		this.setProperty("value", normalizedValue);
	}
	_handleInput(value) {
		if (!this._compositionMode || this._compositionMode && !this._composing) this.onChange(value);
	}
	_compositionStart() {
		this._composing = true;
	}
	_compositionEnd(value) {
		this._composing = false;
		this._compositionMode && this.onChange(value);
	}
};
_DefaultValueAccessor = DefaultValueAccessor;
_defineProperty(DefaultValueAccessor, "ɵfac", function DefaultValueAccessor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DefaultValueAccessor)(ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(COMPOSITION_BUFFER_MODE, 8));
});
_defineProperty(DefaultValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _DefaultValueAccessor,
	selectors: [
		[
			"input",
			"formControlName",
			"",
			3,
			"type",
			"checkbox",
			3,
			"ngNoCva",
			""
		],
		[
			"textarea",
			"formControlName",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"formControl",
			"",
			3,
			"type",
			"checkbox",
			3,
			"ngNoCva",
			""
		],
		[
			"textarea",
			"formControl",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"ngModel",
			"",
			3,
			"type",
			"checkbox",
			3,
			"ngNoCva",
			""
		],
		[
			"textarea",
			"ngModel",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"",
			"ngDefaultControl",
			""
		]
	],
	hostBindings: function DefaultValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("input", function DefaultValueAccessor_input_HostBindingHandler($event) {
			return ctx._handleInput($event.target.value);
		})("blur", function DefaultValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		})("compositionstart", function DefaultValueAccessor_compositionstart_HostBindingHandler() {
			return ctx._compositionStart();
		})("compositionend", function DefaultValueAccessor_compositionend_HostBindingHandler($event) {
			return ctx._compositionEnd($event.target.value);
		});
	},
	standalone: false,
	features: [ɵɵProvidersFeature([DEFAULT_VALUE_ACCESSOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultValueAccessor, [{
		type: Directive,
		args: [{
			selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]",
			host: {
				"(input)": "_handleInput($any($event.target).value)",
				"(blur)": "onTouched()",
				"(compositionstart)": "_compositionStart()",
				"(compositionend)": "_compositionEnd($any($event.target).value)"
			},
			providers: [DEFAULT_VALUE_ACCESSOR],
			standalone: false
		}]
	}], () => [
		{ type: Renderer2 },
		{ type: ElementRef },
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [COMPOSITION_BUFFER_MODE]
			}]
		}
	], null);
})();
function isEmptyInputValue(value) {
	return value == null || lengthOrSize(value) === 0;
}
function lengthOrSize(value) {
	if (value == null) return null;
	else if (Array.isArray(value) || typeof value === "string") return value.length;
	else if (value instanceof Set) return value.size;
	return null;
}
var NG_VALIDATORS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "NgValidators" : "");
var NG_ASYNC_VALIDATORS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "NgAsyncValidators" : "");
var EMAIL_REGEXP = /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
var Validators = class {
	static min(min) {
		return minValidator(min);
	}
	static max(max) {
		return maxValidator(max);
	}
	static required(control) {
		return requiredValidator(control);
	}
	static requiredTrue(control) {
		return requiredTrueValidator(control);
	}
	static email(control) {
		return emailValidator(control);
	}
	static minLength(minLength) {
		return minLengthValidator(minLength);
	}
	static maxLength(maxLength) {
		return maxLengthValidator(maxLength);
	}
	static pattern(pattern) {
		return patternValidator(pattern);
	}
	static nullValidator(control) {
		return nullValidator();
	}
	static compose(validators) {
		return compose(validators);
	}
	static composeAsync(validators) {
		return composeAsync(validators);
	}
};
function minValidator(min) {
	return (control) => {
		if (control.value == null || min == null) return null;
		const value = parseFloat(control.value);
		return !isNaN(value) && value < min ? { "min": {
			"min": min,
			"actual": control.value
		} } : null;
	};
}
function maxValidator(max) {
	return (control) => {
		if (control.value == null || max == null) return null;
		const value = parseFloat(control.value);
		return !isNaN(value) && value > max ? { "max": {
			"max": max,
			"actual": control.value
		} } : null;
	};
}
function requiredValidator(control) {
	return isEmptyInputValue(control.value) ? { "required": true } : null;
}
function requiredTrueValidator(control) {
	return control.value === true ? null : { "required": true };
}
function emailValidator(control) {
	if (isEmptyInputValue(control.value)) return null;
	return EMAIL_REGEXP.test(control.value) ? null : { "email": true };
}
function minLengthValidator(minLength) {
	return (control) => {
		var _control$value$length, _control$value;
		const length = (_control$value$length = (_control$value = control.value) === null || _control$value === void 0 ? void 0 : _control$value.length) !== null && _control$value$length !== void 0 ? _control$value$length : lengthOrSize(control.value);
		if (length === null || length === 0) return null;
		return length < minLength ? { "minlength": {
			"requiredLength": minLength,
			"actualLength": length
		} } : null;
	};
}
function maxLengthValidator(maxLength) {
	return (control) => {
		var _control$value$length2, _control$value2;
		const length = (_control$value$length2 = (_control$value2 = control.value) === null || _control$value2 === void 0 ? void 0 : _control$value2.length) !== null && _control$value$length2 !== void 0 ? _control$value$length2 : lengthOrSize(control.value);
		if (length !== null && length > maxLength) return { "maxlength": {
			"requiredLength": maxLength,
			"actualLength": length
		} };
		return null;
	};
}
function patternValidator(pattern) {
	if (!pattern) return nullValidator;
	let regex;
	let regexStr;
	if (typeof pattern === "string") {
		regexStr = "";
		if (pattern.charAt(0) !== "^") regexStr += "^";
		regexStr += pattern;
		if (pattern.charAt(pattern.length - 1) !== "$") regexStr += "$";
		regex = new RegExp(regexStr);
	} else {
		regexStr = pattern.toString();
		regex = pattern;
	}
	return (control) => {
		if (isEmptyInputValue(control.value)) return null;
		const value = control.value;
		return regex.test(value) ? null : { "pattern": {
			"requiredPattern": regexStr,
			"actualValue": value
		} };
	};
}
function nullValidator(control) {
	return null;
}
function isPresent(o) {
	return o != null;
}
function toObservable(value) {
	const obs = isPromise(value) ? from(value) : value;
	if ((typeof ngDevMode === "undefined" || ngDevMode) && !isSubscribable(obs)) {
		let errorMessage = `Expected async validator to return Promise or Observable.`;
		if (typeof value === "object") errorMessage += " Are you using a synchronous validator where an async validator is expected?";
		throw new RuntimeError(-1101, errorMessage);
	}
	return obs;
}
function mergeErrors(arrayOfErrors) {
	let res = {};
	arrayOfErrors.forEach((errors) => {
		res = errors != null ? _objectSpread2(_objectSpread2({}, res), errors) : res;
	});
	return Object.keys(res).length === 0 ? null : res;
}
function executeValidators(control, validators) {
	return validators.map((validator) => validator(control));
}
function isValidatorFn(validator) {
	return !validator.validate;
}
function normalizeValidators(validators) {
	return validators.map((validator) => {
		return isValidatorFn(validator) ? validator : (c) => validator.validate(c);
	});
}
function compose(validators) {
	if (!validators) return null;
	const presentValidators = validators.filter(isPresent);
	if (presentValidators.length == 0) return null;
	return function(control) {
		return mergeErrors(executeValidators(control, presentValidators));
	};
}
function composeValidators(validators) {
	return validators != null ? compose(normalizeValidators(validators)) : null;
}
function composeAsync(validators) {
	if (!validators) return null;
	const presentValidators = validators.filter(isPresent);
	if (presentValidators.length == 0) return null;
	return function(control) {
		return forkJoin(executeValidators(control, presentValidators).map(toObservable)).pipe(map(mergeErrors));
	};
}
function composeAsyncValidators(validators) {
	return validators != null ? composeAsync(normalizeValidators(validators)) : null;
}
function mergeValidators(controlValidators, dirValidator) {
	if (controlValidators === null) return [dirValidator];
	return Array.isArray(controlValidators) ? [...controlValidators, dirValidator] : [controlValidators, dirValidator];
}
function getControlValidators(control) {
	return control._rawValidators;
}
function getControlAsyncValidators(control) {
	return control._rawAsyncValidators;
}
function makeValidatorsArray(validators) {
	if (!validators) return [];
	return Array.isArray(validators) ? validators : [validators];
}
function hasValidator(validators, validator) {
	return Array.isArray(validators) ? validators.includes(validator) : validators === validator;
}
function addValidators(validators, currentValidators) {
	const current = makeValidatorsArray(currentValidators);
	makeValidatorsArray(validators).forEach((v) => {
		if (!hasValidator(current, v)) current.push(v);
	});
	return current;
}
function removeValidators(validators, currentValidators) {
	return makeValidatorsArray(currentValidators).filter((v) => !hasValidator(validators, v));
}
var AbstractControlDirective = class {
	constructor() {
		_defineProperty(this, "_composedValidatorFn", void 0);
		_defineProperty(this, "_composedAsyncValidatorFn", void 0);
		_defineProperty(this, "_rawValidators", []);
		_defineProperty(this, "_rawAsyncValidators", []);
		_defineProperty(this, "_onDestroyCallbacks", []);
	}
	get value() {
		return this.control ? this.control.value : null;
	}
	get valid() {
		return this.control ? this.control.valid : null;
	}
	get invalid() {
		return this.control ? this.control.invalid : null;
	}
	get pending() {
		return this.control ? this.control.pending : null;
	}
	get disabled() {
		return this.control ? this.control.disabled : null;
	}
	get enabled() {
		return this.control ? this.control.enabled : null;
	}
	get errors() {
		return this.control ? this.control.errors : null;
	}
	get pristine() {
		return this.control ? this.control.pristine : null;
	}
	get dirty() {
		return this.control ? this.control.dirty : null;
	}
	get touched() {
		return this.control ? this.control.touched : null;
	}
	get status() {
		return this.control ? this.control.status : null;
	}
	get untouched() {
		return this.control ? this.control.untouched : null;
	}
	get statusChanges() {
		return this.control ? this.control.statusChanges : null;
	}
	get valueChanges() {
		return this.control ? this.control.valueChanges : null;
	}
	get path() {
		return null;
	}
	_setValidators(validators) {
		this._rawValidators = validators || [];
		this._composedValidatorFn = composeValidators(this._rawValidators);
	}
	_setAsyncValidators(validators) {
		this._rawAsyncValidators = validators || [];
		this._composedAsyncValidatorFn = composeAsyncValidators(this._rawAsyncValidators);
	}
	get validator() {
		return this._composedValidatorFn || null;
	}
	get asyncValidator() {
		return this._composedAsyncValidatorFn || null;
	}
	_registerOnDestroy(fn) {
		this._onDestroyCallbacks.push(fn);
	}
	_invokeOnDestroyCallbacks() {
		this._onDestroyCallbacks.forEach((fn) => fn());
		this._onDestroyCallbacks = [];
	}
	reset(value = void 0) {
		var _this$control;
		(_this$control = this.control) === null || _this$control === void 0 || _this$control.reset(value);
	}
	hasError(errorCode, path) {
		return this.control ? this.control.hasError(errorCode, path) : false;
	}
	getError(errorCode, path) {
		return this.control ? this.control.getError(errorCode, path) : null;
	}
};
var ControlContainer = class extends AbstractControlDirective {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "name", void 0);
	}
	get formDirective() {
		return null;
	}
	get path() {
		return null;
	}
};
var formControlNameExample = `
  <div [formGroup]="myGroup">
    <input formControlName="firstName">
  </div>

  In your class:

  this.myGroup = new FormGroup({
      firstName: new FormControl()
  });`;
var formGroupNameExample = `
  <div [formGroup]="myGroup">
      <div formGroupName="person">
        <input formControlName="firstName">
      </div>
  </div>

  In your class:

  this.myGroup = new FormGroup({
      person: new FormGroup({ firstName: new FormControl() })
  });`;
var formArrayNameExample = `
  <div [formGroup]="myGroup">
    <div formArrayName="cities">
      <div *ngFor="let city of cityArray.controls; index as i">
        <input [formControlName]="i">
      </div>
    </div>
  </div>

  In your class:

  this.cityArray = new FormArray([new FormControl('SF')]);
  this.myGroup = new FormGroup({
    cities: this.cityArray
  });`;
var ngModelGroupExample = `
  <form>
      <div ngModelGroup="person">
        <input [(ngModel)]="person.name" name="firstName">
      </div>
  </form>`;
var ngModelWithFormGroupExample = `
  <div [formGroup]="myGroup">
      <input formControlName="firstName">
      <input [(ngModel)]="showMoreControls" [ngModelOptions]="{standalone: true}">
  </div>
`;
var VERSION = /* @__PURE__ */ new Version("22.1.2");
function controlParentException(nameOrIndex) {
	return new RuntimeError(1050, `formControlName must be used with a parent formGroup or formArray directive. You'll want to add a formGroup/formArray
      directive and pass it an existing FormGroup/FormArray instance (you can create one in your class).

      ${describeFormControl(nameOrIndex)}

    Example:

    ${formControlNameExample}`);
}
function describeFormControl(nameOrIndex) {
	if (nameOrIndex == null || nameOrIndex === "") return "";
	return `Affected Form Control ${typeof nameOrIndex === "string" ? "name" : "index"}: "${nameOrIndex}"`;
}
function ngModelGroupException() {
	return new RuntimeError(1051, `formControlName cannot be used with an ngModelGroup parent. It is only compatible with parents
      that also have a "form" prefix: formGroupName, formArrayName, or formGroup.

      Option 1:  Update the parent to be formGroupName (reactive form strategy)

      ${formGroupNameExample}

      Option 2: Use ngModel instead of formControlName (template-driven strategy)

      ${ngModelGroupExample}`);
}
function missingFormException() {
	return new RuntimeError(1052, `formGroup expects a FormGroup instance. Please pass one in.

      Example:

      ${formControlNameExample}`);
}
function groupParentException() {
	return new RuntimeError(1053, `formGroupName must be used with a parent formGroup directive.  You'll want to add a formGroup
    directive and pass it an existing FormGroup instance (you can create one in your class).

    Example:

    ${formGroupNameExample}`);
}
function arrayParentException() {
	return new RuntimeError(1054, `formArrayName must be used with a parent formGroup directive.  You'll want to add a formGroup
      directive and pass it an existing FormGroup instance (you can create one in your class).

      Example:

      ${formArrayNameExample}`);
}
var disabledAttrWarning = `
  It looks like you're using the disabled attribute with a reactive form directive. If you set disabled to true
  when you set up this control in your component class, the disabled attribute will actually be set in the DOM for
  you. We recommend using this approach to avoid 'changed after checked' errors.

  Example:
  // Specify the \`disabled\` property at control creation time:
  form = new FormGroup({
    first: new FormControl({value: 'Nancy', disabled: true}, Validators.required),
    last: new FormControl('Drew', Validators.required)
  });

  // Controls can also be enabled/disabled after creation:
  form.get('first')?.enable();
  form.get('last')?.disable();
`;
var asyncValidatorsDroppedWithOptsWarning = `
  It looks like you're constructing using a FormControl with both an options argument and an
  async validators argument. Mixing these arguments will cause your async validators to be dropped.
  You should either put all your validators in the options object, or in separate validators
  arguments. For example:

  // Using validators arguments
  fc = new FormControl(42, Validators.required, myAsyncValidator);

  // Using AbstractControlOptions
  fc = new FormControl(42, {validators: Validators.required, asyncValidators: myAV});

  // Do NOT mix them: async validators will be dropped!
  fc = new FormControl(42, {validators: Validators.required}, /* Oops! */ myAsyncValidator);
`;
function ngModelWarning(directiveName) {
	return `
  It looks like you're using ngModel on the same form field as ${directiveName}.
  Support for using the ngModel input property and ngModelChange event with
  reactive form directives has been deprecated in Angular v6 and will be removed
  in a future version of Angular.

  For more information on this, see our API docs here:
  https://${VERSION.major !== "0" ? `v${VERSION.major}.` : ""}angular.dev/api/forms/${directiveName === "formControl" ? "FormControlDirective" : "FormControlName"}
  `;
}
function describeKey(isFormGroup, key) {
	return isFormGroup ? `with name: '${key}'` : `at index: ${key}`;
}
function noControlsError(isFormGroup) {
	return `
    There are no form controls registered with this ${isFormGroup ? "group" : "array"} yet. If you're using ngModel,
    you may want to check next tick (e.g. use setTimeout).
  `;
}
function missingControlError(isFormGroup, key) {
	return `Cannot find form control ${describeKey(isFormGroup, key)}`;
}
function missingControlValueError(isFormGroup, key) {
	return `Must supply a value for form control ${describeKey(isFormGroup, key)}`;
}
var VALID = "VALID";
var INVALID = "INVALID";
var PENDING = "PENDING";
var DISABLED = "DISABLED";
var ControlEvent = class {};
var ValueChangeEvent = class extends ControlEvent {
	constructor(value, source) {
		super();
		_defineProperty(this, "value", void 0);
		_defineProperty(this, "source", void 0);
		this.value = value;
		this.source = source;
	}
};
var PristineChangeEvent = class extends ControlEvent {
	constructor(pristine, source) {
		super();
		_defineProperty(this, "pristine", void 0);
		_defineProperty(this, "source", void 0);
		this.pristine = pristine;
		this.source = source;
	}
};
var TouchedChangeEvent = class extends ControlEvent {
	constructor(touched, source) {
		super();
		_defineProperty(this, "touched", void 0);
		_defineProperty(this, "source", void 0);
		this.touched = touched;
		this.source = source;
	}
};
var StatusChangeEvent = class extends ControlEvent {
	constructor(status, source) {
		super();
		_defineProperty(this, "status", void 0);
		_defineProperty(this, "source", void 0);
		this.status = status;
		this.source = source;
	}
};
var FormSubmittedEvent = class extends ControlEvent {
	constructor(source) {
		super();
		_defineProperty(this, "source", void 0);
		this.source = source;
	}
};
var FormResetEvent = class extends ControlEvent {
	constructor(source) {
		super();
		_defineProperty(this, "source", void 0);
		this.source = source;
	}
};
function pickValidators(validatorOrOpts) {
	return (isOptionsObj(validatorOrOpts) ? validatorOrOpts.validators : validatorOrOpts) || null;
}
function coerceToValidator(validator) {
	return Array.isArray(validator) ? composeValidators(validator) : validator || null;
}
function pickAsyncValidators(asyncValidator, validatorOrOpts) {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		if (isOptionsObj(validatorOrOpts) && asyncValidator) console.warn(asyncValidatorsDroppedWithOptsWarning);
	}
	return (isOptionsObj(validatorOrOpts) ? validatorOrOpts.asyncValidators : asyncValidator) || null;
}
function coerceToAsyncValidator(asyncValidator) {
	return Array.isArray(asyncValidator) ? composeAsyncValidators(asyncValidator) : asyncValidator || null;
}
function isOptionsObj(validatorOrOpts) {
	return validatorOrOpts != null && !Array.isArray(validatorOrOpts) && typeof validatorOrOpts === "object";
}
function assertControlPresent(parent, isGroup, key) {
	const controls = parent.controls;
	if (!(isGroup ? Object.keys(controls) : controls).length) throw new RuntimeError(1e3, typeof ngDevMode === "undefined" || ngDevMode ? noControlsError(isGroup) : "");
	if (!hasOwnControl(controls, key)) throw new RuntimeError(1001, typeof ngDevMode === "undefined" || ngDevMode ? missingControlError(isGroup, key) : "");
}
function assertAllValuesPresent(control, isGroup, value) {
	control._forEachChild((_, key) => {
		if (value[key] === void 0) throw new RuntimeError(-1002, typeof ngDevMode === "undefined" || ngDevMode ? missingControlValueError(isGroup, key) : "");
	});
}
var AbstractControl = class {
	constructor(validators, asyncValidators) {
		_defineProperty(this, "_pendingDirty", false);
		_defineProperty(this, "_hasOwnPendingAsyncValidator", null);
		_defineProperty(this, "_pendingTouched", false);
		_defineProperty(this, "_onCollectionChange", () => {});
		_defineProperty(this, "_updateOn", void 0);
		_defineProperty(this, "_hasRequired", signal(false, ...ngDevMode ? [{ debugName: "_hasRequired" }] : []));
		_defineProperty(this, "_parent", null);
		_defineProperty(this, "_asyncValidationSubscription", void 0);
		_defineProperty(this, "_composedValidatorFn", void 0);
		_defineProperty(this, "_composedAsyncValidatorFn", void 0);
		_defineProperty(this, "_rawValidators", void 0);
		_defineProperty(this, "_rawAsyncValidators", void 0);
		_defineProperty(this, "value", void 0);
		_defineProperty(this, "_status", computed(() => this.statusReactive(), ...ngDevMode ? [{ debugName: "_status" }] : []));
		_defineProperty(this, "statusReactive", signal(void 0, ...ngDevMode ? [{ debugName: "statusReactive" }] : []));
		_defineProperty(this, "errors", void 0);
		_defineProperty(this, "_pristine", computed(() => this.pristineReactive(), ...ngDevMode ? [{ debugName: "_pristine" }] : []));
		_defineProperty(this, "pristineReactive", signal(true, ...ngDevMode ? [{ debugName: "pristineReactive" }] : []));
		_defineProperty(this, "_touched", computed(() => this.touchedReactive(), ...ngDevMode ? [{ debugName: "_touched" }] : []));
		_defineProperty(this, "touchedReactive", signal(false, ...ngDevMode ? [{ debugName: "touchedReactive" }] : []));
		_defineProperty(this, "_events", new Subject());
		_defineProperty(this, "events", this._events.asObservable());
		_defineProperty(this, "valueChanges", void 0);
		_defineProperty(this, "statusChanges", void 0);
		_defineProperty(this, "_onDisabledChange", []);
		this._assignValidators(validators);
		this._assignAsyncValidators(asyncValidators);
	}
	get validator() {
		return this._composedValidatorFn;
	}
	set validator(validatorFn) {
		this._rawValidators = this._composedValidatorFn = validatorFn;
		this._updateHasRequiredValidator();
	}
	get asyncValidator() {
		return this._composedAsyncValidatorFn;
	}
	set asyncValidator(asyncValidatorFn) {
		this._rawAsyncValidators = this._composedAsyncValidatorFn = asyncValidatorFn;
	}
	get parent() {
		return this._parent;
	}
	get status() {
		return untracked(this.statusReactive);
	}
	set status(v) {
		untracked(() => this.statusReactive.set(v));
	}
	get valid() {
		return this.status === VALID;
	}
	get invalid() {
		return this.status === INVALID;
	}
	get pending() {
		return this.status === PENDING;
	}
	get disabled() {
		return this.status === DISABLED;
	}
	get enabled() {
		return this.status !== DISABLED;
	}
	get pristine() {
		return untracked(this.pristineReactive);
	}
	set pristine(v) {
		untracked(() => this.pristineReactive.set(v));
	}
	get dirty() {
		return !this.pristine;
	}
	get touched() {
		return untracked(this.touchedReactive);
	}
	set touched(v) {
		untracked(() => this.touchedReactive.set(v));
	}
	get untouched() {
		return !this.touched;
	}
	get updateOn() {
		return this._updateOn ? this._updateOn : this.parent ? this.parent.updateOn : "change";
	}
	setValidators(validators) {
		this._assignValidators(validators);
	}
	setAsyncValidators(validators) {
		this._assignAsyncValidators(validators);
	}
	addValidators(validators) {
		this.setValidators(addValidators(validators, this._rawValidators));
	}
	addAsyncValidators(validators) {
		this.setAsyncValidators(addValidators(validators, this._rawAsyncValidators));
	}
	removeValidators(validators) {
		this.setValidators(removeValidators(validators, this._rawValidators));
	}
	removeAsyncValidators(validators) {
		this.setAsyncValidators(removeValidators(validators, this._rawAsyncValidators));
	}
	hasValidator(validator) {
		return hasValidator(this._rawValidators, validator);
	}
	hasAsyncValidator(validator) {
		return hasValidator(this._rawAsyncValidators, validator);
	}
	clearValidators() {
		this.validator = null;
	}
	clearAsyncValidators() {
		this.asyncValidator = null;
	}
	markAsTouched(opts = {}) {
		var _opts$sourceControl;
		const changed = this.touched === false;
		this.touched = true;
		const sourceControl = (_opts$sourceControl = opts.sourceControl) !== null && _opts$sourceControl !== void 0 ? _opts$sourceControl : this;
		if (!opts.onlySelf) {
			var _this$_parent;
			(_this$_parent = this._parent) === null || _this$_parent === void 0 || _this$_parent.markAsTouched(_objectSpread2(_objectSpread2({}, opts), {}, { sourceControl }));
		}
		if (changed && opts.emitEvent !== false) this._events.next(new TouchedChangeEvent(true, sourceControl));
	}
	markAllAsDirty(opts = {}) {
		this.markAsDirty({
			onlySelf: true,
			emitEvent: opts.emitEvent,
			sourceControl: this
		});
		this._forEachChild((control) => control.markAllAsDirty(opts));
	}
	markAllAsTouched(opts = {}) {
		this.markAsTouched({
			onlySelf: true,
			emitEvent: opts.emitEvent,
			sourceControl: this
		});
		this._forEachChild((control) => control.markAllAsTouched(opts));
	}
	markAsUntouched(opts = {}) {
		var _opts$sourceControl2;
		const changed = this.touched === true;
		this.touched = false;
		this._pendingTouched = false;
		const sourceControl = (_opts$sourceControl2 = opts.sourceControl) !== null && _opts$sourceControl2 !== void 0 ? _opts$sourceControl2 : this;
		this._forEachChild((control) => {
			control.markAsUntouched({
				onlySelf: true,
				emitEvent: opts.emitEvent,
				sourceControl
			});
		});
		if (!opts.onlySelf) {
			var _this$_parent2;
			(_this$_parent2 = this._parent) === null || _this$_parent2 === void 0 || _this$_parent2._updateTouched(opts, sourceControl);
		}
		if (changed && opts.emitEvent !== false) this._events.next(new TouchedChangeEvent(false, sourceControl));
	}
	markAsDirty(opts = {}) {
		var _opts$sourceControl3;
		const changed = this.pristine === true;
		this.pristine = false;
		const sourceControl = (_opts$sourceControl3 = opts.sourceControl) !== null && _opts$sourceControl3 !== void 0 ? _opts$sourceControl3 : this;
		if (!opts.onlySelf) {
			var _this$_parent3;
			(_this$_parent3 = this._parent) === null || _this$_parent3 === void 0 || _this$_parent3.markAsDirty(_objectSpread2(_objectSpread2({}, opts), {}, { sourceControl }));
		}
		if (changed && opts.emitEvent !== false) this._events.next(new PristineChangeEvent(false, sourceControl));
	}
	markAsPristine(opts = {}) {
		var _opts$sourceControl4;
		const changed = this.pristine === false;
		this.pristine = true;
		this._pendingDirty = false;
		const sourceControl = (_opts$sourceControl4 = opts.sourceControl) !== null && _opts$sourceControl4 !== void 0 ? _opts$sourceControl4 : this;
		this._forEachChild((control) => {
			control.markAsPristine({
				onlySelf: true,
				emitEvent: opts.emitEvent
			});
		});
		if (!opts.onlySelf) {
			var _this$_parent4;
			(_this$_parent4 = this._parent) === null || _this$_parent4 === void 0 || _this$_parent4._updatePristine(opts, sourceControl);
		}
		if (changed && opts.emitEvent !== false) this._events.next(new PristineChangeEvent(true, sourceControl));
	}
	markAsPending(opts = {}) {
		var _opts$sourceControl5;
		this.status = PENDING;
		const sourceControl = (_opts$sourceControl5 = opts.sourceControl) !== null && _opts$sourceControl5 !== void 0 ? _opts$sourceControl5 : this;
		if (opts.emitEvent !== false) {
			this._events.next(new StatusChangeEvent(this.status, sourceControl));
			this.statusChanges.emit(this.status);
		}
		if (!opts.onlySelf) {
			var _this$_parent5;
			(_this$_parent5 = this._parent) === null || _this$_parent5 === void 0 || _this$_parent5.markAsPending(_objectSpread2(_objectSpread2({}, opts), {}, { sourceControl }));
		}
	}
	disable(opts = {}) {
		var _opts$sourceControl6;
		const skipPristineCheck = this._parentMarkedDirty(opts.onlySelf);
		this.status = DISABLED;
		this.errors = null;
		this._forEachChild((control) => {
			control.disable(_objectSpread2(_objectSpread2({}, opts), {}, { onlySelf: true }));
		});
		this._updateValue();
		const sourceControl = (_opts$sourceControl6 = opts.sourceControl) !== null && _opts$sourceControl6 !== void 0 ? _opts$sourceControl6 : this;
		if (opts.emitEvent !== false) {
			this._events.next(new ValueChangeEvent(this.value, sourceControl));
			this._events.next(new StatusChangeEvent(this.status, sourceControl));
			this.valueChanges.emit(this.value);
			this.statusChanges.emit(this.status);
		}
		this._updateAncestors(_objectSpread2(_objectSpread2({}, opts), {}, { skipPristineCheck }), this);
		this._onDisabledChange.forEach((changeFn) => changeFn(true));
	}
	enable(opts = {}) {
		const skipPristineCheck = this._parentMarkedDirty(opts.onlySelf);
		this.status = VALID;
		this._forEachChild((control) => {
			control.enable(_objectSpread2(_objectSpread2({}, opts), {}, { onlySelf: true }));
		});
		this.updateValueAndValidity({
			onlySelf: true,
			emitEvent: opts.emitEvent
		});
		this._updateAncestors(_objectSpread2(_objectSpread2({}, opts), {}, { skipPristineCheck }), this);
		this._onDisabledChange.forEach((changeFn) => changeFn(false));
	}
	_updateAncestors(opts, sourceControl) {
		if (!opts.onlySelf) {
			var _this$_parent6, _this$_parent8;
			(_this$_parent6 = this._parent) === null || _this$_parent6 === void 0 || _this$_parent6.updateValueAndValidity(opts);
			if (!opts.skipPristineCheck) {
				var _this$_parent7;
				(_this$_parent7 = this._parent) === null || _this$_parent7 === void 0 || _this$_parent7._updatePristine({}, sourceControl);
			}
			(_this$_parent8 = this._parent) === null || _this$_parent8 === void 0 || _this$_parent8._updateTouched({}, sourceControl);
		}
	}
	setParent(parent) {
		this._parent = parent;
	}
	getRawValue() {
		return this.value;
	}
	updateValueAndValidity(opts = {}) {
		var _opts$sourceControl7;
		this._setInitialStatus();
		this._updateValue();
		if (this.enabled) {
			const shouldHaveEmitted = this._cancelExistingSubscription();
			this.errors = this._runValidator();
			this.status = this._calculateStatus();
			if (this.status === VALID || this.status === PENDING) this._runAsyncValidator(shouldHaveEmitted, opts.emitEvent);
		}
		const sourceControl = (_opts$sourceControl7 = opts.sourceControl) !== null && _opts$sourceControl7 !== void 0 ? _opts$sourceControl7 : this;
		if (opts.emitEvent !== false) {
			this._events.next(new ValueChangeEvent(this.value, sourceControl));
			this._events.next(new StatusChangeEvent(this.status, sourceControl));
			this.valueChanges.emit(this.value);
			this.statusChanges.emit(this.status);
		}
		if (!opts.onlySelf) {
			var _this$_parent9;
			(_this$_parent9 = this._parent) === null || _this$_parent9 === void 0 || _this$_parent9.updateValueAndValidity(_objectSpread2(_objectSpread2({}, opts), {}, { sourceControl }));
		}
	}
	_updateTreeValidity(opts = { emitEvent: true }) {
		this._forEachChild((ctrl) => ctrl._updateTreeValidity(opts));
		this.updateValueAndValidity({
			onlySelf: true,
			emitEvent: opts.emitEvent
		});
	}
	_setInitialStatus() {
		this.status = this._allControlsDisabled() ? DISABLED : VALID;
	}
	_runValidator() {
		return this.validator ? this.validator(this) : null;
	}
	_runAsyncValidator(shouldHaveEmitted, emitEvent) {
		if (this.asyncValidator) {
			this.status = PENDING;
			this._hasOwnPendingAsyncValidator = {
				emitEvent: emitEvent !== false,
				shouldHaveEmitted: shouldHaveEmitted !== false
			};
			const obs = toObservable(this.asyncValidator(this));
			this._asyncValidationSubscription = obs.subscribe((errors) => {
				this._hasOwnPendingAsyncValidator = null;
				this.setErrors(errors, {
					emitEvent,
					shouldHaveEmitted
				});
			});
		}
	}
	_cancelExistingSubscription() {
		if (this._asyncValidationSubscription) {
			var _ref, _this$_hasOwnPendingA, _this$_hasOwnPendingA2;
			this._asyncValidationSubscription.unsubscribe();
			const shouldHaveEmitted = (_ref = ((_this$_hasOwnPendingA = this._hasOwnPendingAsyncValidator) === null || _this$_hasOwnPendingA === void 0 ? void 0 : _this$_hasOwnPendingA.emitEvent) || ((_this$_hasOwnPendingA2 = this._hasOwnPendingAsyncValidator) === null || _this$_hasOwnPendingA2 === void 0 ? void 0 : _this$_hasOwnPendingA2.shouldHaveEmitted)) !== null && _ref !== void 0 ? _ref : false;
			this._hasOwnPendingAsyncValidator = null;
			return shouldHaveEmitted;
		}
		return false;
	}
	setErrors(errors, opts = {}) {
		this.errors = errors;
		this._updateControlsErrors(opts.emitEvent !== false, this, opts.shouldHaveEmitted);
	}
	get(path) {
		let currPath = path;
		if (currPath == null) return null;
		if (!Array.isArray(currPath)) currPath = currPath.split(".");
		if (currPath.length === 0) return null;
		return currPath.reduce((control, name) => control && control._find(name), this);
	}
	getError(errorCode, path) {
		const control = path ? this.get(path) : this;
		return (control === null || control === void 0 ? void 0 : control.errors) ? control.errors[errorCode] : null;
	}
	hasError(errorCode, path) {
		return !!this.getError(errorCode, path);
	}
	get root() {
		let x = this;
		while (x._parent) x = x._parent;
		return x;
	}
	_updateControlsErrors(emitEvent, changedControl, shouldHaveEmitted) {
		this.status = this._calculateStatus();
		if (emitEvent) this.statusChanges.emit(this.status);
		if (emitEvent || shouldHaveEmitted) this._events.next(new StatusChangeEvent(this.status, changedControl));
		if (this._parent) this._parent._updateControlsErrors(emitEvent, changedControl, shouldHaveEmitted);
	}
	_initObservables() {
		this.valueChanges = new EventEmitter();
		this.statusChanges = new EventEmitter();
	}
	_calculateStatus() {
		if (this._allControlsDisabled()) return DISABLED;
		if (this.errors) return INVALID;
		if (this._hasOwnPendingAsyncValidator || this._anyControlsHaveStatus(PENDING)) return PENDING;
		if (this._anyControlsHaveStatus(INVALID)) return INVALID;
		return VALID;
	}
	_anyControlsHaveStatus(status) {
		return this._anyControls((control) => control.status === status);
	}
	_anyControlsDirty() {
		return this._anyControls((control) => control.dirty);
	}
	_anyControlsTouched() {
		return this._anyControls((control) => control.touched);
	}
	_updatePristine(opts, changedControl) {
		const newPristine = !this._anyControlsDirty();
		const changed = this.pristine !== newPristine;
		this.pristine = newPristine;
		if (!opts.onlySelf) {
			var _this$_parent10;
			(_this$_parent10 = this._parent) === null || _this$_parent10 === void 0 || _this$_parent10._updatePristine(opts, changedControl);
		}
		if (changed) this._events.next(new PristineChangeEvent(this.pristine, changedControl));
	}
	_updateTouched(opts = {}, changedControl) {
		this.touched = this._anyControlsTouched();
		this._events.next(new TouchedChangeEvent(this.touched, changedControl));
		if (!opts.onlySelf) {
			var _this$_parent11;
			(_this$_parent11 = this._parent) === null || _this$_parent11 === void 0 || _this$_parent11._updateTouched(opts, changedControl);
		}
	}
	_registerOnCollectionChange(fn) {
		this._onCollectionChange = fn;
	}
	_setUpdateStrategy(opts) {
		if (isOptionsObj(opts) && opts.updateOn != null) this._updateOn = opts.updateOn;
	}
	_parentMarkedDirty(onlySelf) {
		var _this$_parent12;
		return !onlySelf && !!((_this$_parent12 = this._parent) === null || _this$_parent12 === void 0 ? void 0 : _this$_parent12.dirty) && !this._parent._anyControlsDirty();
	}
	_find(name) {
		return null;
	}
	_assignValidators(validators) {
		this._rawValidators = Array.isArray(validators) ? validators.slice() : validators;
		this._composedValidatorFn = coerceToValidator(this._rawValidators);
		this._updateHasRequiredValidator();
	}
	_assignAsyncValidators(validators) {
		this._rawAsyncValidators = Array.isArray(validators) ? validators.slice() : validators;
		this._composedAsyncValidatorFn = coerceToAsyncValidator(this._rawAsyncValidators);
	}
	_updateHasRequiredValidator() {
		untracked(() => this._hasRequired.set(this.hasValidator(Validators.required)));
	}
};
function hasOwnControl(controls, name) {
	return Object.hasOwn(controls, name);
}
function isNativeFormElement(element) {
	return element.tagName === "INPUT" || element.tagName === "SELECT" || element.tagName === "TEXTAREA";
}
function elementAcceptsMinMax(element) {
	if (element.tagName !== "INPUT") return false;
	const type = element.type;
	return type === "number" || type === "range" || type === "date" || type === "month";
}
function isTextualFormElement(element) {
	return element.tagName === "INPUT" || element.tagName === "TEXTAREA";
}
function setNativeDomProperty(renderer, element, name, value) {
	switch (name) {
		case "name":
			renderer.setAttribute(element, name, value);
			break;
		case "disabled":
		case "readonly":
		case "required":
			if (value) renderer.setAttribute(element, name, "");
			else renderer.removeAttribute(element, name);
			break;
		case "max":
		case "min":
		case "minLength":
		case "maxLength":
			if (value !== void 0) renderer.setAttribute(element, name, value.toString());
			else renderer.removeAttribute(element, name);
			break;
	}
}
var ReactiveValidationError = class {
	constructor({ kind, context, control }) {
		_defineProperty(this, "kind", void 0);
		_defineProperty(this, "context", void 0);
		_defineProperty(this, "control", void 0);
		_defineProperty(this, "message", void 0);
		this.kind = kind;
		this.context = context;
		this.control = control;
	}
};
function toInteger(value) {
	return typeof value === "number" ? value : parseInt(value, 10);
}
function toFloat(value) {
	return typeof value === "number" ? value : parseFloat(value);
}
var AbstractValidatorDirective = class {
	constructor() {
		_defineProperty(this, "_validator", nullValidator);
		_defineProperty(this, "_onChange", void 0);
		_defineProperty(this, "_enabled", void 0);
	}
	ngOnChanges(changes) {
		if (this.inputName in changes) {
			var _this$_onChange;
			const input = this.normalizeInput(changes[this.inputName].currentValue);
			this._enabled = this.enabled(input);
			this._validator = this._enabled ? this.createValidator(input) : nullValidator;
			(_this$_onChange = this._onChange) === null || _this$_onChange === void 0 || _this$_onChange.call(this);
		}
	}
	validate(control) {
		return this._validator(control);
	}
	registerOnValidatorChange(fn) {
		this._onChange = fn;
	}
	enabled(input) {
		return input != null;
	}
};
_AbstractValidatorDirective = AbstractValidatorDirective;
_defineProperty(AbstractValidatorDirective, "ɵfac", function AbstractValidatorDirective_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _AbstractValidatorDirective)();
});
_defineProperty(AbstractValidatorDirective, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _AbstractValidatorDirective,
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AbstractValidatorDirective, [{ type: Directive }], null, null);
})();
var MAX_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => MaxValidator),
	multi: true
};
var MaxValidator = class extends AbstractValidatorDirective {
	constructor(..._args2) {
		super(..._args2);
		_defineProperty(this, "max", void 0);
		_defineProperty(this, "inputName", "max");
		_defineProperty(this, "normalizeInput", (input) => toFloat(input));
		_defineProperty(this, "createValidator", (max) => maxValidator(max));
	}
};
_MaxValidator = MaxValidator;
_defineProperty(MaxValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵMaxValidator_BaseFactory;
	return function MaxValidator_Factory(__ngFactoryType__) {
		return (ɵMaxValidator_BaseFactory || (ɵMaxValidator_BaseFactory = ɵɵgetInheritedFactory(_MaxValidator)))(__ngFactoryType__ || _MaxValidator);
	};
})());
_defineProperty(MaxValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _MaxValidator,
	selectors: [
		[
			"input",
			"type",
			"number",
			"max",
			"",
			"formControlName",
			""
		],
		[
			"input",
			"type",
			"number",
			"max",
			"",
			"formControl",
			""
		],
		[
			"input",
			"type",
			"number",
			"max",
			"",
			"ngModel",
			""
		]
	],
	hostVars: 1,
	hostBindings: function MaxValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("max", ctx._enabled ? ctx.max : null);
	},
	inputs: { max: "max" },
	standalone: false,
	features: [ɵɵProvidersFeature([MAX_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MaxValidator, [{
		type: Directive,
		args: [{
			selector: "input[type=number][max][formControlName],input[type=number][max][formControl],input[type=number][max][ngModel]",
			providers: [MAX_VALIDATOR],
			host: { "[attr.max]": "_enabled ? max : null" },
			standalone: false
		}]
	}], null, { max: [{ type: Input }] });
})();
var MIN_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => MinValidator),
	multi: true
};
var MinValidator = class extends AbstractValidatorDirective {
	constructor(..._args3) {
		super(..._args3);
		_defineProperty(this, "min", void 0);
		_defineProperty(this, "inputName", "min");
		_defineProperty(this, "normalizeInput", (input) => toFloat(input));
		_defineProperty(this, "createValidator", (min) => minValidator(min));
	}
};
_MinValidator = MinValidator;
_defineProperty(MinValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵMinValidator_BaseFactory;
	return function MinValidator_Factory(__ngFactoryType__) {
		return (ɵMinValidator_BaseFactory || (ɵMinValidator_BaseFactory = ɵɵgetInheritedFactory(_MinValidator)))(__ngFactoryType__ || _MinValidator);
	};
})());
_defineProperty(MinValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _MinValidator,
	selectors: [
		[
			"input",
			"type",
			"number",
			"min",
			"",
			"formControlName",
			""
		],
		[
			"input",
			"type",
			"number",
			"min",
			"",
			"formControl",
			""
		],
		[
			"input",
			"type",
			"number",
			"min",
			"",
			"ngModel",
			""
		]
	],
	hostVars: 1,
	hostBindings: function MinValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("min", ctx._enabled ? ctx.min : null);
	},
	inputs: { min: "min" },
	standalone: false,
	features: [ɵɵProvidersFeature([MIN_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MinValidator, [{
		type: Directive,
		args: [{
			selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]",
			providers: [MIN_VALIDATOR],
			host: { "[attr.min]": "_enabled ? min : null" },
			standalone: false
		}]
	}], null, { min: [{ type: Input }] });
})();
var REQUIRED_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => RequiredValidator),
	multi: true
};
var CHECKBOX_REQUIRED_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => CheckboxRequiredValidator),
	multi: true
};
var RequiredValidator = class extends AbstractValidatorDirective {
	constructor(..._args4) {
		super(..._args4);
		_defineProperty(this, "required", void 0);
		_defineProperty(this, "inputName", "required");
		_defineProperty(this, "normalizeInput", booleanAttribute);
		_defineProperty(this, "createValidator", (input) => requiredValidator);
	}
	enabled(input) {
		return input;
	}
};
_RequiredValidator = RequiredValidator;
_defineProperty(RequiredValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵRequiredValidator_BaseFactory;
	return function RequiredValidator_Factory(__ngFactoryType__) {
		return (ɵRequiredValidator_BaseFactory || (ɵRequiredValidator_BaseFactory = ɵɵgetInheritedFactory(_RequiredValidator)))(__ngFactoryType__ || _RequiredValidator);
	};
})());
_defineProperty(RequiredValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _RequiredValidator,
	selectors: [
		[
			"",
			"required",
			"",
			"formControlName",
			"",
			3,
			"type",
			"checkbox"
		],
		[
			"",
			"required",
			"",
			"formControl",
			"",
			3,
			"type",
			"checkbox"
		],
		[
			"",
			"required",
			"",
			"ngModel",
			"",
			3,
			"type",
			"checkbox"
		]
	],
	hostVars: 1,
	hostBindings: function RequiredValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("required", ctx._enabled ? "" : null);
	},
	inputs: { required: "required" },
	standalone: false,
	features: [ɵɵProvidersFeature([REQUIRED_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RequiredValidator, [{
		type: Directive,
		args: [{
			selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
			providers: [REQUIRED_VALIDATOR],
			host: { "[attr.required]": "_enabled ? \"\" : null" },
			standalone: false
		}]
	}], null, { required: [{ type: Input }] });
})();
var CheckboxRequiredValidator = class extends RequiredValidator {
	constructor(..._args5) {
		super(..._args5);
		_defineProperty(this, "createValidator", (input) => requiredTrueValidator);
	}
};
_CheckboxRequiredValidator = CheckboxRequiredValidator;
_defineProperty(CheckboxRequiredValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵCheckboxRequiredValidator_BaseFactory;
	return function CheckboxRequiredValidator_Factory(__ngFactoryType__) {
		return (ɵCheckboxRequiredValidator_BaseFactory || (ɵCheckboxRequiredValidator_BaseFactory = ɵɵgetInheritedFactory(_CheckboxRequiredValidator)))(__ngFactoryType__ || _CheckboxRequiredValidator);
	};
})());
_defineProperty(CheckboxRequiredValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _CheckboxRequiredValidator,
	selectors: [
		[
			"input",
			"type",
			"checkbox",
			"required",
			"",
			"formControlName",
			""
		],
		[
			"input",
			"type",
			"checkbox",
			"required",
			"",
			"formControl",
			""
		],
		[
			"input",
			"type",
			"checkbox",
			"required",
			"",
			"ngModel",
			""
		]
	],
	hostVars: 1,
	hostBindings: function CheckboxRequiredValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("required", ctx._enabled ? "" : null);
	},
	standalone: false,
	features: [ɵɵProvidersFeature([CHECKBOX_REQUIRED_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CheckboxRequiredValidator, [{
		type: Directive,
		args: [{
			selector: "input[type=checkbox][required][formControlName],input[type=checkbox][required][formControl],input[type=checkbox][required][ngModel]",
			providers: [CHECKBOX_REQUIRED_VALIDATOR],
			host: { "[attr.required]": "_enabled ? \"\" : null" },
			standalone: false
		}]
	}], null, null);
})();
var EMAIL_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => EmailValidator),
	multi: true
};
var EmailValidator = class extends AbstractValidatorDirective {
	constructor(..._args6) {
		super(..._args6);
		_defineProperty(this, "email", void 0);
		_defineProperty(this, "inputName", "email");
		_defineProperty(this, "normalizeInput", booleanAttribute);
		_defineProperty(this, "createValidator", (input) => emailValidator);
	}
	enabled(input) {
		return input;
	}
};
_EmailValidator = EmailValidator;
_defineProperty(EmailValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵEmailValidator_BaseFactory;
	return function EmailValidator_Factory(__ngFactoryType__) {
		return (ɵEmailValidator_BaseFactory || (ɵEmailValidator_BaseFactory = ɵɵgetInheritedFactory(_EmailValidator)))(__ngFactoryType__ || _EmailValidator);
	};
})());
_defineProperty(EmailValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _EmailValidator,
	selectors: [
		[
			"",
			"email",
			"",
			"formControlName",
			""
		],
		[
			"",
			"email",
			"",
			"formControl",
			""
		],
		[
			"",
			"email",
			"",
			"ngModel",
			""
		]
	],
	inputs: { email: "email" },
	standalone: false,
	features: [ɵɵProvidersFeature([EMAIL_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EmailValidator, [{
		type: Directive,
		args: [{
			selector: "[email][formControlName],[email][formControl],[email][ngModel]",
			providers: [EMAIL_VALIDATOR],
			standalone: false
		}]
	}], null, { email: [{ type: Input }] });
})();
var MIN_LENGTH_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => MinLengthValidator),
	multi: true
};
var MinLengthValidator = class extends AbstractValidatorDirective {
	constructor(..._args7) {
		super(..._args7);
		_defineProperty(this, "minlength", void 0);
		_defineProperty(this, "inputName", "minlength");
		_defineProperty(this, "normalizeInput", (input) => toInteger(input));
		_defineProperty(this, "createValidator", (minlength) => minLengthValidator(minlength));
	}
};
_MinLengthValidator = MinLengthValidator;
_defineProperty(MinLengthValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵMinLengthValidator_BaseFactory;
	return function MinLengthValidator_Factory(__ngFactoryType__) {
		return (ɵMinLengthValidator_BaseFactory || (ɵMinLengthValidator_BaseFactory = ɵɵgetInheritedFactory(_MinLengthValidator)))(__ngFactoryType__ || _MinLengthValidator);
	};
})());
_defineProperty(MinLengthValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _MinLengthValidator,
	selectors: [
		[
			"",
			"minlength",
			"",
			"formControlName",
			""
		],
		[
			"",
			"minlength",
			"",
			"formControl",
			""
		],
		[
			"",
			"minlength",
			"",
			"ngModel",
			""
		]
	],
	hostVars: 1,
	hostBindings: function MinLengthValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("minlength", ctx._enabled ? ctx.minlength : null);
	},
	inputs: { minlength: "minlength" },
	standalone: false,
	features: [ɵɵProvidersFeature([MIN_LENGTH_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MinLengthValidator, [{
		type: Directive,
		args: [{
			selector: "[minlength][formControlName],[minlength][formControl],[minlength][ngModel]",
			providers: [MIN_LENGTH_VALIDATOR],
			host: { "[attr.minlength]": "_enabled ? minlength : null" },
			standalone: false
		}]
	}], null, { minlength: [{ type: Input }] });
})();
var MAX_LENGTH_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => MaxLengthValidator),
	multi: true
};
var MaxLengthValidator = class extends AbstractValidatorDirective {
	constructor(..._args8) {
		super(..._args8);
		_defineProperty(this, "maxlength", void 0);
		_defineProperty(this, "inputName", "maxlength");
		_defineProperty(this, "normalizeInput", (input) => toInteger(input));
		_defineProperty(this, "createValidator", (maxlength) => maxLengthValidator(maxlength));
	}
};
_MaxLengthValidator = MaxLengthValidator;
_defineProperty(MaxLengthValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵMaxLengthValidator_BaseFactory;
	return function MaxLengthValidator_Factory(__ngFactoryType__) {
		return (ɵMaxLengthValidator_BaseFactory || (ɵMaxLengthValidator_BaseFactory = ɵɵgetInheritedFactory(_MaxLengthValidator)))(__ngFactoryType__ || _MaxLengthValidator);
	};
})());
_defineProperty(MaxLengthValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _MaxLengthValidator,
	selectors: [
		[
			"",
			"maxlength",
			"",
			"formControlName",
			""
		],
		[
			"",
			"maxlength",
			"",
			"formControl",
			""
		],
		[
			"",
			"maxlength",
			"",
			"ngModel",
			""
		]
	],
	hostVars: 1,
	hostBindings: function MaxLengthValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("maxlength", ctx._enabled ? ctx.maxlength : null);
	},
	inputs: { maxlength: "maxlength" },
	standalone: false,
	features: [ɵɵProvidersFeature([MAX_LENGTH_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MaxLengthValidator, [{
		type: Directive,
		args: [{
			selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]",
			providers: [MAX_LENGTH_VALIDATOR],
			host: { "[attr.maxlength]": "_enabled ? maxlength : null" },
			standalone: false
		}]
	}], null, { maxlength: [{ type: Input }] });
})();
var PATTERN_VALIDATOR = {
	provide: NG_VALIDATORS,
	useExisting: forwardRef(() => PatternValidator),
	multi: true
};
var PatternValidator = class extends AbstractValidatorDirective {
	constructor(..._args9) {
		super(..._args9);
		_defineProperty(this, "pattern", void 0);
		_defineProperty(this, "inputName", "pattern");
		_defineProperty(this, "normalizeInput", (input) => input);
		_defineProperty(this, "createValidator", (input) => patternValidator(input));
	}
};
_PatternValidator = PatternValidator;
_defineProperty(PatternValidator, "ɵfac", /* @__PURE__ */ (() => {
	let ɵPatternValidator_BaseFactory;
	return function PatternValidator_Factory(__ngFactoryType__) {
		return (ɵPatternValidator_BaseFactory || (ɵPatternValidator_BaseFactory = ɵɵgetInheritedFactory(_PatternValidator)))(__ngFactoryType__ || _PatternValidator);
	};
})());
_defineProperty(PatternValidator, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _PatternValidator,
	selectors: [
		[
			"",
			"pattern",
			"",
			"formControlName",
			""
		],
		[
			"",
			"pattern",
			"",
			"formControl",
			""
		],
		[
			"",
			"pattern",
			"",
			"ngModel",
			""
		]
	],
	hostVars: 1,
	hostBindings: function PatternValidator_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵattribute("pattern", ctx._enabled ? ctx.pattern : null);
	},
	inputs: { pattern: "pattern" },
	standalone: false,
	features: [ɵɵProvidersFeature([PATTERN_VALIDATOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PatternValidator, [{
		type: Directive,
		args: [{
			selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]",
			providers: [PATTERN_VALIDATOR],
			host: { "[attr.pattern]": "_enabled ? pattern : null" },
			standalone: false
		}]
	}], null, { pattern: [{ type: Input }] });
})();
var ɵFORM_CONTROL_INTEGRATION = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "FORM_CONTROL_INTEGRATION" : "");
var CALL_SET_DISABLED_STATE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "CallSetDisabledState" : "", { factory: () => setDisabledStateDefault });
var setDisabledStateDefault = "always";
function controlPath(name, parent) {
	return [...parent.path, name];
}
function setUpControlValueAccessor(control, dir, callSetDisabledState = setDisabledStateDefault) {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		if (!control) _throwError(dir, "Cannot find control with");
		if (!dir.valueAccessor) _throwMissingValueAccessorError(dir);
	}
	setUpValidators(control, dir);
	dir.valueAccessor.writeValue(control.value);
	if (control.disabled || callSetDisabledState === "always") {
		var _dir$valueAccessor$se, _dir$valueAccessor;
		(_dir$valueAccessor$se = (_dir$valueAccessor = dir.valueAccessor).setDisabledState) === null || _dir$valueAccessor$se === void 0 || _dir$valueAccessor$se.call(_dir$valueAccessor, control.disabled);
	}
	setUpViewChangePipeline(control, dir);
	setUpModelChangePipeline(control, dir);
	setUpBlurPipeline(control, dir);
	setUpDisabledChangeHandler(control, dir);
}
function cleanUpControl(control, dir, validateControlPresenceOnChange = true) {
	var _dir$valueAccessor2, _dir$valueAccessor3;
	const noop = () => {
		if (validateControlPresenceOnChange && (typeof ngDevMode === "undefined" || ngDevMode)) _noControlError(dir);
	};
	dir === null || dir === void 0 || (_dir$valueAccessor2 = dir.valueAccessor) === null || _dir$valueAccessor2 === void 0 || _dir$valueAccessor2.registerOnChange(noop);
	dir === null || dir === void 0 || (_dir$valueAccessor3 = dir.valueAccessor) === null || _dir$valueAccessor3 === void 0 || _dir$valueAccessor3.registerOnTouched(noop);
	cleanUpValidators(control, dir);
	if (control) {
		dir._invokeOnDestroyCallbacks();
		control._registerOnCollectionChange(() => {});
	}
}
function registerOnValidatorChange(validators, onChange) {
	validators.forEach((validator) => {
		if (validator.registerOnValidatorChange) validator.registerOnValidatorChange(onChange);
	});
}
function setUpDisabledChangeHandler(control, dir) {
	if (dir.valueAccessor.setDisabledState) {
		const onDisabledChange = (isDisabled) => {
			dir.valueAccessor.setDisabledState(isDisabled);
		};
		control.registerOnDisabledChange(onDisabledChange);
		dir._registerOnDestroy(() => {
			control._unregisterOnDisabledChange(onDisabledChange);
		});
	}
}
function setUpValidators(control, dir) {
	const validators = getControlValidators(control);
	if (dir.validator !== null) control.setValidators(mergeValidators(validators, dir.validator));
	else if (typeof validators === "function") control.setValidators([validators]);
	const asyncValidators = getControlAsyncValidators(control);
	if (dir.asyncValidator !== null) control.setAsyncValidators(mergeValidators(asyncValidators, dir.asyncValidator));
	else if (typeof asyncValidators === "function") control.setAsyncValidators([asyncValidators]);
	const onValidatorChange = () => control.updateValueAndValidity();
	registerOnValidatorChange(dir._rawValidators, onValidatorChange);
	registerOnValidatorChange(dir._rawAsyncValidators, onValidatorChange);
}
function cleanUpValidators(control, dir) {
	let isControlUpdated = false;
	if (control !== null) {
		if (dir.validator !== null) {
			const validators = getControlValidators(control);
			if (Array.isArray(validators) && validators.length > 0) {
				const updatedValidators = validators.filter((validator) => validator !== dir.validator);
				if (updatedValidators.length !== validators.length) {
					isControlUpdated = true;
					control.setValidators(updatedValidators);
				}
			}
		}
		if (dir.asyncValidator !== null) {
			const asyncValidators = getControlAsyncValidators(control);
			if (Array.isArray(asyncValidators) && asyncValidators.length > 0) {
				const updatedAsyncValidators = asyncValidators.filter((asyncValidator) => asyncValidator !== dir.asyncValidator);
				if (updatedAsyncValidators.length !== asyncValidators.length) {
					isControlUpdated = true;
					control.setAsyncValidators(updatedAsyncValidators);
				}
			}
		}
	}
	const noop = () => {};
	registerOnValidatorChange(dir._rawValidators, noop);
	registerOnValidatorChange(dir._rawAsyncValidators, noop);
	return isControlUpdated;
}
function setUpViewChangePipeline(control, dir) {
	dir.valueAccessor.registerOnChange((newValue) => {
		control._pendingValue = newValue;
		control._pendingChange = true;
		control._pendingDirty = true;
		if (control.updateOn === "change") updateControl(control, dir);
	});
}
function setUpBlurPipeline(control, dir) {
	dir.valueAccessor.registerOnTouched(() => {
		control._pendingTouched = true;
		if (control.updateOn === "blur" && control._pendingChange) updateControl(control, dir);
		if (control.updateOn !== "submit") control.markAsTouched();
	});
}
function updateControl(control, dir) {
	if (control._pendingDirty) control.markAsDirty();
	control.setValue(control._pendingValue, { emitModelToViewChange: false });
	dir.viewToModelUpdate(control._pendingValue);
	control._pendingChange = false;
}
function setUpModelChangePipeline(control, dir) {
	const onChange = (newValue, emitModelEvent) => {
		dir.valueAccessor.writeValue(newValue);
		if (emitModelEvent) dir.viewToModelUpdate(newValue);
	};
	control.registerOnChange(onChange);
	dir._registerOnDestroy(() => {
		control._unregisterOnChange(onChange);
	});
}
function setUpFormContainer(control, dir) {
	if (control == null && (typeof ngDevMode === "undefined" || ngDevMode)) _throwError(dir, "Cannot find control with");
	setUpValidators(control, dir);
}
function cleanUpFormContainer(control, dir) {
	return cleanUpValidators(control, dir);
}
function _noControlError(dir) {
	return _throwError(dir, "There is no FormControl instance attached to form control element with");
}
function _throwError(dir, message) {
	const messageEnd = _describeControlLocation(dir);
	throw new Error(`${message} ${messageEnd}`);
}
function _describeControlLocation(dir) {
	const path = dir.path;
	if (path && path.length > 1) return `path: '${path.join(" -> ")}'`;
	if (path === null || path === void 0 ? void 0 : path[0]) return `name: '${path}'`;
	return "unspecified name attribute";
}
function _throwMissingValueAccessorError(dir) {
	throw new RuntimeError(-1203, `No value accessor for form control ${_describeControlLocation(dir)}.`);
}
function _throwInvalidValueAccessorError(dir) {
	throw new RuntimeError(1200, `Value accessor was not provided as an array for form control with ${_describeControlLocation(dir)}. Check that the \`NG_VALUE_ACCESSOR\` token is configured as a \`multi: true\` provider.`);
}
function isPropertyUpdated(changes, viewModel) {
	if (!changes.hasOwnProperty("model")) return false;
	const change = changes["model"];
	if (change.isFirstChange()) return true;
	return !Object.is(viewModel, change.currentValue);
}
function isBuiltInAccessor(valueAccessor) {
	return Object.getPrototypeOf(valueAccessor.constructor) === BuiltInControlValueAccessor;
}
function syncPendingControls(form, directives) {
	form._syncPendingControls();
	directives.forEach((dir) => {
		const control = dir.control;
		if (control.updateOn === "submit" && control._pendingChange) {
			dir.viewToModelUpdate(control._pendingValue);
			control._pendingChange = false;
		}
	});
}
function selectValueAccessor(dir, valueAccessors) {
	if (!valueAccessors) return null;
	if (!Array.isArray(valueAccessors) && (typeof ngDevMode === "undefined" || ngDevMode)) _throwInvalidValueAccessorError(dir);
	let defaultAccessor = void 0;
	let builtinAccessor = void 0;
	let customAccessor = void 0;
	valueAccessors.forEach((v) => {
		if (v.constructor === DefaultValueAccessor) defaultAccessor = v;
		else if (isBuiltInAccessor(v)) {
			if (builtinAccessor && (typeof ngDevMode === "undefined" || ngDevMode)) _throwError(dir, "More than one built-in value accessor matches form control with");
			builtinAccessor = v;
		} else {
			if (customAccessor && (typeof ngDevMode === "undefined" || ngDevMode)) _throwError(dir, "More than one custom value accessor matches form control with");
			customAccessor = v;
		}
	});
	if (customAccessor) return customAccessor;
	if (builtinAccessor) return builtinAccessor;
	if (defaultAccessor) return defaultAccessor;
	if (typeof ngDevMode === "undefined" || ngDevMode) _throwError(dir, "No valid value accessor for form control with");
	return null;
}
function removeListItem$1(list, el) {
	const index = list.indexOf(el);
	if (index > -1) list.splice(index, 1);
}
function _ngModelWarning(name, type, instance, warningConfig) {
	if (warningConfig === "never") return;
	if ((warningConfig === null || warningConfig === "once") && !type._ngModelWarningSentOnce || warningConfig === "always" && !instance._ngModelWarningSent) {
		console.warn(ngModelWarning(name));
		type._ngModelWarningSentOnce = true;
		instance._ngModelWarningSent = true;
	}
}
var NG_CONTROL_INTEGRATION_PROVIDER = {
	provide: ɵFORM_CONTROL_INTEGRATION,
	useFactory: () => {
		const control = inject(NgControl, { self: true });
		return {
			setParseErrors: (source) => {
				control.setParseErrorSource(source);
			},
			set onReset(callback) {
				control.onReset = callback;
			}
		};
	}
};
var NgControl = class extends AbstractControlDirective {
	set onReset(callback) {
		var _this$resetSubscripti;
		this.userOnReset = callback;
		(_this$resetSubscripti = this.resetSubscription) === null || _this$resetSubscripti === void 0 || _this$resetSubscripti.unsubscribe();
		this.resetSubscription = void 0;
		if (this.control) {
			var _this$subscription;
			this.resetSubscription = this.control.events.subscribe((event) => {
				if (event instanceof FormResetEvent && this.control) {
					var _this$userOnReset;
					(_this$userOnReset = this.userOnReset) === null || _this$userOnReset === void 0 || _this$userOnReset.call(this, this.control.value);
				}
			});
			(_this$subscription = this.subscription) === null || _this$subscription === void 0 || _this$subscription.add(this.resetSubscription);
		}
	}
	get selectedValueAccessor() {
		var _this$_selectedValueA;
		return (_this$_selectedValueA = this._selectedValueAccessor) !== null && _this$_selectedValueA !== void 0 ? _this$_selectedValueA : this._selectedValueAccessor = selectValueAccessor(this, this.rawValueAccessors);
	}
	constructor(injector, renderer, rawValueAccessors) {
		var _this$injector;
		super();
		_defineProperty(this, "_parent", null);
		_defineProperty(this, "name", null);
		_defineProperty(this, "valueAccessor", null);
		_defineProperty(this, "isCustomControlBased", false);
		_defineProperty(this, "userOnReset", void 0);
		_defineProperty(this, "resetSubscription", void 0);
		_defineProperty(this, "isNativeFormElement", false);
		_defineProperty(this, "rawValueAccessors", void 0);
		_defineProperty(this, "_selectedValueAccessor", null);
		_defineProperty(this, "parseErrorsValidator", null);
		_defineProperty(this, "renderer", void 0);
		_defineProperty(this, "injector", void 0);
		_defineProperty(this, "requiredValidatorViaDi", void 0);
		_defineProperty(this, "subscription", void 0);
		_defineProperty(this, "customControlBindings", null);
		this.injector = injector;
		this.renderer = renderer;
		this.rawValueAccessors = rawValueAccessors;
		(_this$injector = this.injector) === null || _this$injector === void 0 || (_this$injector = _this$injector.get(DestroyRef)) === null || _this$injector === void 0 || _this$injector.onDestroy(() => {
			var _this$subscription2;
			this.removeParseErrorsValidator(this.control);
			(_this$subscription2 = this.subscription) === null || _this$subscription2 === void 0 || _this$subscription2.unsubscribe();
		});
	}
	setupCustomControl() {
		var _this$subscription3, _this$injector2, _this$resetSubscripti2;
		(_this$subscription3 = this.subscription) === null || _this$subscription3 === void 0 || _this$subscription3.unsubscribe();
		const cdr = (_this$injector2 = this.injector) === null || _this$injector2 === void 0 ? void 0 : _this$injector2.get(ChangeDetectorRef);
		if (!this.control || !cdr) return;
		const markForCheck = cdr.markForCheck.bind(cdr);
		this.subscription = new Subscription();
		this.subscription.add(this.control.valueChanges.subscribe(markForCheck));
		this.subscription.add(this.control.statusChanges.subscribe(markForCheck));
		(_this$resetSubscripti2 = this.resetSubscription) === null || _this$resetSubscripti2 === void 0 || _this$resetSubscripti2.unsubscribe();
		this.resetSubscription = void 0;
		if (this.userOnReset) {
			this.resetSubscription = this.control.events.subscribe((event) => {
				if (event instanceof FormResetEvent && this.control) {
					var _this$userOnReset2;
					(_this$userOnReset2 = this.userOnReset) === null || _this$userOnReset2 === void 0 || _this$userOnReset2.call(this, this.control.value);
				}
			});
			this.subscription.add(this.resetSubscription);
		}
		if (this.parseErrorsValidator) this.control.addValidators(this.parseErrorsValidator);
	}
	ngControlCreate(host) {
		var _host$nativeElement$h, _host$nativeElement;
		if (!((_host$nativeElement$h = (_host$nativeElement = host.nativeElement).hasAttribute) === null || _host$nativeElement$h === void 0 ? void 0 : _host$nativeElement$h.call(_host$nativeElement, "ngNoCva")) && (this.rawValueAccessors && this.rawValueAccessors.length > 0 || this.valueAccessor !== null) || !host.customControl) return;
		this.isCustomControlBased = true;
		host.listenToCustomControlModel((value) => {
			var _this$control2, _this$control3;
			(_this$control2 = this.control) === null || _this$control2 === void 0 || _this$control2.setValue(value, { emitModelToViewChange: false });
			(_this$control3 = this.control) === null || _this$control3 === void 0 || _this$control3.markAsDirty();
			this.viewToModelUpdate(value);
		});
		host.listenToCustomControlOutput("touch", () => {
			var _this$control4;
			(_this$control4 = this.control) === null || _this$control4 === void 0 || _this$control4.markAsTouched();
		});
		this.customControlBindings = {};
		this.isNativeFormElement = isNativeFormElement(host.nativeElement);
		this.requiredValidatorViaDi = this._rawValidators.find((v) => v instanceof RequiredValidator);
	}
	ngControlUpdate(host, bindRequired) {
		if (!this.isCustomControlBased) return;
		const control = this.control;
		const bindings = this.customControlBindings;
		if (!Object.is(bindings.value, control.value)) {
			bindings.value = control.value;
			host.setCustomControlModelInput(control.value);
		}
		this.bindControlProperty(host, bindings, "touched", control.touched);
		this.bindControlProperty(host, bindings, "dirty", control.dirty);
		this.bindControlProperty(host, bindings, "valid", control.valid);
		this.bindControlProperty(host, bindings, "invalid", control.invalid);
		this.bindControlProperty(host, bindings, "pending", control.pending);
		this.bindControlProperty(host, bindings, "disabled", control.disabled);
		if (this.shouldBindRequired) this.bindControlProperty(host, bindings, "required", this.isRequired);
		const errorObject = control.errors;
		if (bindings.errors !== errorObject) {
			bindings.errors = errorObject;
			const errorArray = this._convertErrors(errorObject);
			host.setInputOnDirectives("errors", errorArray);
		}
	}
	get isRequired() {
		var _ref2, _this$requiredValidat, _this$control5;
		return (_ref2 = ((_this$requiredValidat = this.requiredValidatorViaDi) === null || _this$requiredValidat === void 0 ? void 0 : _this$requiredValidat._enabled) || ((_this$control5 = this.control) === null || _this$control5 === void 0 ? void 0 : _this$control5._hasRequired())) !== null && _ref2 !== void 0 ? _ref2 : false;
	}
	get shouldBindRequired() {
		return true;
	}
	bindControlProperty(host, bindings, name, value) {
		if (bindings[name] === value) return;
		bindings[name] = value;
		const wasSet = host.setInputOnDirectives(name, value);
		if (this.isNativeFormElement && !wasSet && (name === "disabled" || name === "required") && this.renderer) setNativeDomProperty(this.renderer, host.nativeElement, name, value);
	}
	_convertErrors(errors) {
		if (errors === null) return [];
		const control = this.control;
		return Object.entries(errors).map(([kind, context]) => {
			return new ReactiveValidationError({
				context,
				kind,
				control
			});
		});
	}
	setParseErrorSource(parseErrors) {
		if (parseErrors === void 0) return;
		let convertedErrors = null;
		const convertedParseErrors = computed(() => {
			const rawErrors = parseErrors();
			if (rawErrors.length === 0) return null;
			return rawErrors.reduce((acc, err) => {
				acc[err.kind] = err;
				return acc;
			}, {});
		}, ...ngDevMode ? [{ debugName: "convertedParseErrors" }] : []);
		this.parseErrorsValidator = (() => convertedErrors).bind(this);
		effect(() => {
			var _this$control6;
			convertedErrors = convertedParseErrors();
			(_this$control6 = this.control) === null || _this$control6 === void 0 || _this$control6.updateValueAndValidity({ emitEvent: false });
		}, { injector: this.injector });
	}
	removeParseErrorsValidator(control) {
		if (this.parseErrorsValidator) {
			control === null || control === void 0 || control.removeValidators(this.parseErrorsValidator);
			control === null || control === void 0 || control.updateValueAndValidity({ emitEvent: false });
		}
	}
};
var AbstractControlStatus = class {
	constructor(cd) {
		_defineProperty(this, "_cd", void 0);
		this._cd = cd;
	}
	get isTouched() {
		var _this$_cd, _this$_cd$_touched, _this$_cd2;
		(_this$_cd = this._cd) === null || _this$_cd === void 0 || (_this$_cd = _this$_cd.control) === null || _this$_cd === void 0 || (_this$_cd$_touched = _this$_cd._touched) === null || _this$_cd$_touched === void 0 || _this$_cd$_touched.call(_this$_cd);
		return !!((_this$_cd2 = this._cd) === null || _this$_cd2 === void 0 || (_this$_cd2 = _this$_cd2.control) === null || _this$_cd2 === void 0 ? void 0 : _this$_cd2.touched);
	}
	get isUntouched() {
		var _this$_cd3;
		return !!((_this$_cd3 = this._cd) === null || _this$_cd3 === void 0 || (_this$_cd3 = _this$_cd3.control) === null || _this$_cd3 === void 0 ? void 0 : _this$_cd3.untouched);
	}
	get isPristine() {
		var _this$_cd4, _this$_cd4$_pristine, _this$_cd5;
		(_this$_cd4 = this._cd) === null || _this$_cd4 === void 0 || (_this$_cd4 = _this$_cd4.control) === null || _this$_cd4 === void 0 || (_this$_cd4$_pristine = _this$_cd4._pristine) === null || _this$_cd4$_pristine === void 0 || _this$_cd4$_pristine.call(_this$_cd4);
		return !!((_this$_cd5 = this._cd) === null || _this$_cd5 === void 0 || (_this$_cd5 = _this$_cd5.control) === null || _this$_cd5 === void 0 ? void 0 : _this$_cd5.pristine);
	}
	get isDirty() {
		var _this$_cd6;
		return !!((_this$_cd6 = this._cd) === null || _this$_cd6 === void 0 || (_this$_cd6 = _this$_cd6.control) === null || _this$_cd6 === void 0 ? void 0 : _this$_cd6.dirty);
	}
	get isValid() {
		var _this$_cd7, _this$_cd7$_status, _this$_cd8;
		(_this$_cd7 = this._cd) === null || _this$_cd7 === void 0 || (_this$_cd7 = _this$_cd7.control) === null || _this$_cd7 === void 0 || (_this$_cd7$_status = _this$_cd7._status) === null || _this$_cd7$_status === void 0 || _this$_cd7$_status.call(_this$_cd7);
		return !!((_this$_cd8 = this._cd) === null || _this$_cd8 === void 0 || (_this$_cd8 = _this$_cd8.control) === null || _this$_cd8 === void 0 ? void 0 : _this$_cd8.valid);
	}
	get isInvalid() {
		var _this$_cd9;
		return !!((_this$_cd9 = this._cd) === null || _this$_cd9 === void 0 || (_this$_cd9 = _this$_cd9.control) === null || _this$_cd9 === void 0 ? void 0 : _this$_cd9.invalid);
	}
	get isPending() {
		var _this$_cd10;
		return !!((_this$_cd10 = this._cd) === null || _this$_cd10 === void 0 || (_this$_cd10 = _this$_cd10.control) === null || _this$_cd10 === void 0 ? void 0 : _this$_cd10.pending);
	}
	get isSubmitted() {
		var _this$_cd11, _this$_cd11$_submitte, _this$_cd12;
		(_this$_cd11 = this._cd) === null || _this$_cd11 === void 0 || (_this$_cd11$_submitte = _this$_cd11._submitted) === null || _this$_cd11$_submitte === void 0 || _this$_cd11$_submitte.call(_this$_cd11);
		return !!((_this$_cd12 = this._cd) === null || _this$_cd12 === void 0 ? void 0 : _this$_cd12.submitted);
	}
};
var ngControlStatusHost = {
	"[class.ng-untouched]": "isUntouched",
	"[class.ng-touched]": "isTouched",
	"[class.ng-pristine]": "isPristine",
	"[class.ng-dirty]": "isDirty",
	"[class.ng-valid]": "isValid",
	"[class.ng-invalid]": "isInvalid",
	"[class.ng-pending]": "isPending"
};
var NgControlStatus = class extends AbstractControlStatus {
	constructor(cd) {
		super(cd);
	}
};
_NgControlStatus = NgControlStatus;
_defineProperty(NgControlStatus, "ɵfac", function NgControlStatus_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgControlStatus)(ɵɵdirectiveInject(NgControl, 2));
});
_defineProperty(NgControlStatus, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgControlStatus,
	selectors: [
		[
			"",
			"formControlName",
			""
		],
		[
			"",
			"ngModel",
			""
		],
		[
			"",
			"formControl",
			""
		]
	],
	hostVars: 14,
	hostBindings: function NgControlStatus_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵclassProp("ng-untouched", ctx.isUntouched)("ng-touched", ctx.isTouched)("ng-pristine", ctx.isPristine)("ng-dirty", ctx.isDirty)("ng-valid", ctx.isValid)("ng-invalid", ctx.isInvalid)("ng-pending", ctx.isPending);
	},
	standalone: false,
	features: [ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgControlStatus, [{
		type: Directive,
		args: [{
			selector: "[formControlName],[ngModel],[formControl]",
			host: ngControlStatusHost,
			standalone: false
		}]
	}], () => [{
		type: NgControl,
		decorators: [{ type: Self }]
	}], null);
})();
var NgControlStatusGroup = class extends AbstractControlStatus {
	constructor(cd) {
		super(cd);
	}
};
_NgControlStatusGroup = NgControlStatusGroup;
_defineProperty(NgControlStatusGroup, "ɵfac", function NgControlStatusGroup_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgControlStatusGroup)(ɵɵdirectiveInject(ControlContainer, 10));
});
_defineProperty(NgControlStatusGroup, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgControlStatusGroup,
	selectors: [
		[
			"",
			"formGroupName",
			""
		],
		[
			"",
			"formArrayName",
			""
		],
		[
			"",
			"ngModelGroup",
			""
		],
		[
			"",
			"formGroup",
			""
		],
		[
			"",
			"formArray",
			""
		],
		[
			"form",
			3,
			"ngNoForm",
			""
		],
		[
			"",
			"ngForm",
			""
		]
	],
	hostVars: 16,
	hostBindings: function NgControlStatusGroup_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵclassProp("ng-untouched", ctx.isUntouched)("ng-touched", ctx.isTouched)("ng-pristine", ctx.isPristine)("ng-dirty", ctx.isDirty)("ng-valid", ctx.isValid)("ng-invalid", ctx.isInvalid)("ng-pending", ctx.isPending)("ng-submitted", ctx.isSubmitted);
	},
	standalone: false,
	features: [ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgControlStatusGroup, [{
		type: Directive,
		args: [{
			selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]",
			host: _objectSpread2(_objectSpread2({}, ngControlStatusHost), {}, { "[class.ng-submitted]": "isSubmitted" }),
			standalone: false
		}]
	}], () => [{
		type: ControlContainer,
		decorators: [{ type: Optional }, { type: Self }]
	}], null);
})();
var FormGroup = class extends AbstractControl {
	constructor(controls, validatorOrOpts, asyncValidator) {
		super(pickValidators(validatorOrOpts), pickAsyncValidators(asyncValidator, validatorOrOpts));
		_defineProperty(this, "controls", void 0);
		(typeof ngDevMode === "undefined" || ngDevMode) && validateFormGroupControls(controls);
		this.controls = controls;
		this._initObservables();
		this._setUpdateStrategy(validatorOrOpts);
		this._setUpControls();
		this.updateValueAndValidity({
			onlySelf: true,
			emitEvent: !!this.asyncValidator
		});
	}
	registerControl(name, control) {
		const existingControl = this._find(name);
		if (existingControl) return existingControl;
		this.controls[name] = control;
		control.setParent(this);
		control._registerOnCollectionChange(this._onCollectionChange);
		return control;
	}
	addControl(name, control, options = {}) {
		this.registerControl(name, control);
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
		this._onCollectionChange();
	}
	removeControl(name, options = {}) {
		const existingControl = this._find(name);
		if (existingControl) existingControl._registerOnCollectionChange(() => {});
		delete this.controls[name];
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
		this._onCollectionChange();
	}
	setControl(name, control, options = {}) {
		const existingControl = this._find(name);
		if (existingControl) existingControl._registerOnCollectionChange(() => {});
		delete this.controls[name];
		if (control) this.registerControl(name, control);
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
		this._onCollectionChange();
	}
	contains(controlName) {
		var _this$_find;
		return ((_this$_find = this._find(controlName)) === null || _this$_find === void 0 ? void 0 : _this$_find.enabled) === true;
	}
	setValue(value, options = {}) {
		untracked(() => {
			assertAllValuesPresent(this, true, value);
			Object.keys(value).forEach((name) => {
				assertControlPresent(this, true, name);
				this.controls[name].setValue(value[name], {
					onlySelf: true,
					emitEvent: options.emitEvent
				});
			});
			this.updateValueAndValidity(options);
		});
	}
	patchValue(value, options = {}) {
		if (value == null) return;
		Object.keys(value).forEach((name) => {
			const existingControl = this._find(name);
			if (existingControl) existingControl.patchValue(value[name], {
				onlySelf: true,
				emitEvent: options.emitEvent
			});
		});
		this.updateValueAndValidity(options);
	}
	reset(value = {}, options = {}) {
		this._forEachChild((control, name) => {
			control.reset(value ? value[name] : null, _objectSpread2(_objectSpread2({}, options), {}, { onlySelf: true }));
		});
		this._updatePristine(options, this);
		this._updateTouched(options, this);
		this.updateValueAndValidity(options);
		if ((options === null || options === void 0 ? void 0 : options.emitEvent) !== false) this._events.next(new FormResetEvent(this));
	}
	getRawValue() {
		return this._reduceChildren({}, (acc, control, name) => {
			acc[name] = control.getRawValue();
			return acc;
		});
	}
	_syncPendingControls() {
		let subtreeUpdated = this._reduceChildren(false, (updated, child) => {
			return child._syncPendingControls() ? true : updated;
		});
		if (subtreeUpdated) this.updateValueAndValidity({ onlySelf: true });
		return subtreeUpdated;
	}
	_forEachChild(cb) {
		Object.keys(this.controls).forEach((key) => {
			const control = this.controls[key];
			control && cb(control, key);
		});
	}
	_setUpControls() {
		this._forEachChild((control) => {
			control.setParent(this);
			control._registerOnCollectionChange(this._onCollectionChange);
		});
	}
	_updateValue() {
		this.value = this._reduceValue();
	}
	_anyControls(condition) {
		for (const [controlName, control] of Object.entries(this.controls)) if (this.contains(controlName) && condition(control)) return true;
		return false;
	}
	_reduceValue() {
		return this._reduceChildren({}, (acc, control, name) => {
			if (control.enabled || this.disabled) acc[name] = control.value;
			return acc;
		});
	}
	_reduceChildren(initValue, fn) {
		let res = initValue;
		this._forEachChild((control, name) => {
			res = fn(res, control, name);
		});
		return res;
	}
	_allControlsDisabled() {
		for (const controlName of Object.keys(this.controls)) if (this.controls[controlName].enabled) return false;
		return Object.keys(this.controls).length > 0 || this.disabled;
	}
	_find(name) {
		return hasOwnControl(this.controls, name) ? this.controls[name] : null;
	}
};
function validateFormGroupControls(controls) {
	const invalidKeys = Object.keys(controls).filter((key) => key.includes("."));
	if (invalidKeys.length > 0) console.warn(`FormGroup keys cannot include \`.\`, please replace the keys for: ${invalidKeys.join(",")}.`);
}
var UntypedFormGroup = FormGroup;
var isFormGroup = (control) => control instanceof FormGroup;
var FormRecord = class extends FormGroup {};
var isFormRecord = (control) => control instanceof FormRecord;
var formDirectiveProvider$2 = {
	provide: ControlContainer,
	useExisting: forwardRef(() => NgForm)
};
var resolvedPromise$1 = (() => Promise.resolve())();
var NgForm = class extends ControlContainer {
	get submitted() {
		return untracked(this.submittedReactive);
	}
	constructor(validators, asyncValidators, callSetDisabledState) {
		super();
		_defineProperty(this, "callSetDisabledState", void 0);
		_defineProperty(this, "_submitted", computed(() => this.submittedReactive(), ...ngDevMode ? [{ debugName: "_submitted" }] : []));
		_defineProperty(this, "submittedReactive", signal(false, ...ngDevMode ? [{ debugName: "submittedReactive" }] : []));
		_defineProperty(this, "_directives", /* @__PURE__ */ new Set());
		_defineProperty(this, "form", void 0);
		_defineProperty(this, "ngSubmit", new EventEmitter());
		_defineProperty(this, "options", void 0);
		this.callSetDisabledState = callSetDisabledState;
		this.form = new FormGroup({}, composeValidators(validators), composeAsyncValidators(asyncValidators));
	}
	ngAfterViewInit() {
		this._setUpdateStrategy();
	}
	get formDirective() {
		return this;
	}
	get control() {
		return this.form;
	}
	get path() {
		return [];
	}
	get controls() {
		return this.form.controls;
	}
	addControl(dir) {
		resolvedPromise$1.then(() => {
			dir.control = this._findContainer(dir.path).registerControl(dir.name, dir.control);
			dir._setupWithForm(this.callSetDisabledState);
			dir.control.updateValueAndValidity({ emitEvent: false });
			this._directives.add(dir);
		});
	}
	getControl(dir) {
		return this.form.get(dir.path);
	}
	removeControl(dir) {
		resolvedPromise$1.then(() => {
			const container = this._findContainer(dir.path);
			container === null || container === void 0 || container.removeControl(dir.name);
			this._directives.delete(dir);
		});
	}
	addFormGroup(dir) {
		resolvedPromise$1.then(() => {
			const container = this._findContainer(dir.path);
			const group = new FormGroup({});
			setUpFormContainer(group, dir);
			container.registerControl(dir.name, group);
			group.updateValueAndValidity({ emitEvent: false });
		});
	}
	removeFormGroup(dir) {
		resolvedPromise$1.then(() => {
			var _container$removeCont;
			const container = this._findContainer(dir.path);
			container === null || container === void 0 || (_container$removeCont = container.removeControl) === null || _container$removeCont === void 0 || _container$removeCont.call(container, dir.name);
		});
	}
	getFormGroup(dir) {
		return this.form.get(dir.path);
	}
	updateModel(dir, value) {
		resolvedPromise$1.then(() => {
			this.form.get(dir.path).setValue(value);
		});
	}
	setValue(value) {
		this.control.setValue(value);
	}
	onSubmit($event) {
		var _$event$target;
		this.submittedReactive.set(true);
		syncPendingControls(this.form, this._directives);
		this.ngSubmit.emit($event);
		this.form._events.next(new FormSubmittedEvent(this.control));
		return ($event === null || $event === void 0 || (_$event$target = $event.target) === null || _$event$target === void 0 ? void 0 : _$event$target.method) === "dialog";
	}
	onReset() {
		this.resetForm();
	}
	resetForm(value = void 0) {
		this.form.reset(value);
		this.submittedReactive.set(false);
	}
	_setUpdateStrategy() {
		if (this.options && this.options.updateOn != null) this.form._updateOn = this.options.updateOn;
	}
	_findContainer(path) {
		path.pop();
		return path.length ? this.form.get(path) : this.form;
	}
};
_NgForm = NgForm;
_defineProperty(NgForm, "ɵfac", function NgForm_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgForm)(ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10), ɵɵdirectiveInject(CALL_SET_DISABLED_STATE, 8));
});
_defineProperty(NgForm, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgForm,
	selectors: [
		[
			"form",
			3,
			"ngNoForm",
			"",
			3,
			"formGroup",
			"",
			3,
			"formArray",
			""
		],
		["ng-form"],
		[
			"",
			"ngForm",
			""
		]
	],
	hostBindings: function NgForm_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("submit", function NgForm_submit_HostBindingHandler($event) {
			return ctx.onSubmit($event);
		})("reset", function NgForm_reset_HostBindingHandler() {
			return ctx.onReset();
		});
	},
	inputs: { options: [
		0,
		"ngFormOptions",
		"options"
	] },
	outputs: { ngSubmit: "ngSubmit" },
	exportAs: ["ngForm"],
	standalone: false,
	features: [ɵɵProvidersFeature([formDirectiveProvider$2]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgForm, [{
		type: Directive,
		args: [{
			selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
			providers: [formDirectiveProvider$2],
			host: {
				"(submit)": "onSubmit($event)",
				"(reset)": "onReset()"
			},
			outputs: ["ngSubmit"],
			exportAs: "ngForm",
			standalone: false
		}]
	}], () => [
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [CALL_SET_DISABLED_STATE]
			}]
		}
	], { options: [{
		type: Input,
		args: ["ngFormOptions"]
	}] });
})();
function removeListItem(list, el) {
	const index = list.indexOf(el);
	if (index > -1) list.splice(index, 1);
}
function isFormControlState(formState) {
	return typeof formState === "object" && formState !== null && Object.keys(formState).length === 2 && "value" in formState && "disabled" in formState;
}
var FormControl = class FormControl extends AbstractControl {
	constructor(formState = null, validatorOrOpts, asyncValidator) {
		super(pickValidators(validatorOrOpts), pickAsyncValidators(asyncValidator, validatorOrOpts));
		_defineProperty(this, "defaultValue", null);
		_defineProperty(this, "_onChange", []);
		_defineProperty(this, "_pendingValue", void 0);
		_defineProperty(this, "_pendingChange", false);
		this._applyFormState(formState);
		this._setUpdateStrategy(validatorOrOpts);
		this._initObservables();
		this.updateValueAndValidity({
			onlySelf: true,
			emitEvent: !!this.asyncValidator
		});
		if (isOptionsObj(validatorOrOpts) && (validatorOrOpts.nonNullable || validatorOrOpts.initialValueIsDefault)) if (isFormControlState(formState)) this.defaultValue = formState.value;
		else this.defaultValue = formState;
	}
	setValue(value, options = {}) {
		untracked(() => {
			this.value = this._pendingValue = value;
			if (this._onChange.length && options.emitModelToViewChange !== false) this._onChange.forEach((changeFn) => changeFn(this.value, options.emitViewToModelChange !== false));
			this.updateValueAndValidity(options);
		});
	}
	patchValue(value, options = {}) {
		this.setValue(value, options);
	}
	reset(formState = this.defaultValue, options = {}) {
		this._applyFormState(formState);
		this.markAsPristine(options);
		this.markAsUntouched(options);
		this.setValue(this.value, options);
		if (options.overwriteDefaultValue) this.defaultValue = this.value;
		this._pendingChange = false;
		if ((options === null || options === void 0 ? void 0 : options.emitEvent) !== false) this._events.next(new FormResetEvent(this));
	}
	_updateValue() {}
	_anyControls(condition) {
		return false;
	}
	_allControlsDisabled() {
		return this.disabled;
	}
	registerOnChange(fn) {
		this._onChange.push(fn);
	}
	_unregisterOnChange(fn) {
		removeListItem(this._onChange, fn);
	}
	registerOnDisabledChange(fn) {
		this._onDisabledChange.push(fn);
	}
	_unregisterOnDisabledChange(fn) {
		removeListItem(this._onDisabledChange, fn);
	}
	_forEachChild(cb) {}
	_syncPendingControls() {
		if (this.updateOn === "submit") {
			if (this._pendingDirty) this.markAsDirty();
			if (this._pendingTouched) this.markAsTouched();
			if (this._pendingChange) {
				this.setValue(this._pendingValue, {
					onlySelf: true,
					emitModelToViewChange: false
				});
				return true;
			}
		}
		return false;
	}
	_applyFormState(formState) {
		if (isFormControlState(formState)) {
			this.value = this._pendingValue = formState.value;
			formState.disabled ? this.disable({
				onlySelf: true,
				emitEvent: false
			}) : this.enable({
				onlySelf: true,
				emitEvent: false
			});
		} else this.value = this._pendingValue = formState;
	}
};
var UntypedFormControl = FormControl;
var isFormControl = (control) => control instanceof FormControl;
var AbstractFormGroupDirective = class extends ControlContainer {
	constructor(..._args10) {
		super(..._args10);
		_defineProperty(this, "_parent", void 0);
	}
	ngOnInit() {
		this._checkParentType();
		this.formDirective.addFormGroup(this);
	}
	ngOnDestroy() {
		var _this$formDirective;
		(_this$formDirective = this.formDirective) === null || _this$formDirective === void 0 || _this$formDirective.removeFormGroup(this);
	}
	get control() {
		return this.formDirective.getFormGroup(this);
	}
	get path() {
		return controlPath(this.name == null ? this.name : this.name.toString(), this._parent);
	}
	get formDirective() {
		return this._parent ? this._parent.formDirective : null;
	}
	_checkParentType() {}
};
_AbstractFormGroupDirective = AbstractFormGroupDirective;
_defineProperty(AbstractFormGroupDirective, "ɵfac", /* @__PURE__ */ (() => {
	let ɵAbstractFormGroupDirective_BaseFactory;
	return function AbstractFormGroupDirective_Factory(__ngFactoryType__) {
		return (ɵAbstractFormGroupDirective_BaseFactory || (ɵAbstractFormGroupDirective_BaseFactory = ɵɵgetInheritedFactory(_AbstractFormGroupDirective)))(__ngFactoryType__ || _AbstractFormGroupDirective);
	};
})());
_defineProperty(AbstractFormGroupDirective, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _AbstractFormGroupDirective,
	standalone: false,
	features: [ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AbstractFormGroupDirective, [{
		type: Directive,
		args: [{ standalone: false }]
	}], null, null);
})();
function modelParentException() {
	return new RuntimeError(1350, `
    ngModel cannot be used to register form controls with a parent formGroup directive.  Try using
    formGroup's partner directive "formControlName" instead.  Example:

    ${formControlNameExample}

    Or, if you'd like to avoid registering this form control, indicate that it's standalone in ngModelOptions:

    Example:

    ${ngModelWithFormGroupExample}`);
}
function formGroupNameException() {
	return new RuntimeError(1351, `
    ngModel cannot be used to register form controls with a parent formGroupName or formArrayName directive.

    Option 1: Use formControlName instead of ngModel (reactive strategy):

    ${formGroupNameExample}

    Option 2:  Update ngModel's parent be ngModelGroup (template-driven strategy):

    ${ngModelGroupExample}`);
}
function missingNameException() {
	return new RuntimeError(1352, `If ngModel is used within a form tag, either the name attribute must be set or the form
    control must be defined as 'standalone' in ngModelOptions.

    Example 1: <input [(ngModel)]="person.firstName" name="first">
    Example 2: <input [(ngModel)]="person.firstName" [ngModelOptions]="{standalone: true}">`);
}
function modelGroupParentException() {
	return new RuntimeError(1353, `
    ngModelGroup cannot be used with a parent formGroup directive.

    Option 1: Use formGroupName instead of ngModelGroup (reactive strategy):

    ${formGroupNameExample}

    Option 2:  Use a regular form tag instead of the formGroup directive (template-driven strategy):

    ${ngModelGroupExample}`);
}
var modelGroupProvider = {
	provide: ControlContainer,
	useExisting: forwardRef(() => NgModelGroup)
};
var NgModelGroup = class NgModelGroup extends AbstractFormGroupDirective {
	constructor(parent, validators, asyncValidators) {
		super();
		_defineProperty(this, "name", "");
		this._parent = parent;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	_checkParentType() {
		if (!(this._parent instanceof NgModelGroup) && !(this._parent instanceof NgForm) && (typeof ngDevMode === "undefined" || ngDevMode)) throw modelGroupParentException();
	}
};
_NgModelGroup = NgModelGroup;
_defineProperty(NgModelGroup, "ɵfac", function NgModelGroup_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgModelGroup)(ɵɵdirectiveInject(ControlContainer, 5), ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10));
});
_defineProperty(NgModelGroup, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgModelGroup,
	selectors: [[
		"",
		"ngModelGroup",
		""
	]],
	inputs: { name: [
		0,
		"ngModelGroup",
		"name"
	] },
	exportAs: ["ngModelGroup"],
	standalone: false,
	features: [ɵɵProvidersFeature([modelGroupProvider]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgModelGroup, [{
		type: Directive,
		args: [{
			selector: "[ngModelGroup]",
			providers: [modelGroupProvider],
			exportAs: "ngModelGroup",
			standalone: false
		}]
	}], () => [
		{
			type: ControlContainer,
			decorators: [{ type: Host }, { type: SkipSelf }]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		}
	], { name: [{
		type: Input,
		args: ["ngModelGroup"]
	}] });
})();
var formControlBinding$1 = {
	provide: NgControl,
	useExisting: forwardRef(() => NgModel)
};
var resolvedPromise = (() => Promise.resolve())();
var NgModel = class extends NgControl {
	constructor(parent, validators, asyncValidators, valueAccessors, _changeDetectorRef, callSetDisabledState, injector, renderer) {
		super(injector, renderer, valueAccessors);
		_defineProperty(this, "_changeDetectorRef", void 0);
		_defineProperty(this, "callSetDisabledState", void 0);
		_defineProperty(this, "control", new FormControl());
		_defineProperty(this, "_registered", false);
		_defineProperty(this, "viewModel", void 0);
		_defineProperty(this, "name", "");
		_defineProperty(this, "isDisabled", void 0);
		_defineProperty(this, "model", void 0);
		_defineProperty(this, "options", void 0);
		_defineProperty(this, "update", new EventEmitter());
		this._changeDetectorRef = _changeDetectorRef;
		this.callSetDisabledState = callSetDisabledState;
		this._parent = parent;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	ngOnChanges(changes) {
		this._checkForErrors();
		if (!this._registered || "name" in changes) {
			if (this._registered) {
				this._checkName();
				if (this.formDirective) {
					const oldName = changes["name"].previousValue;
					this.formDirective.removeControl({
						name: oldName,
						path: this._getPath(oldName)
					});
				}
			}
			this._setUpControl();
		}
		if ("isDisabled" in changes) this._updateDisabled(changes);
		if (isPropertyUpdated(changes, this.viewModel)) {
			this._updateValue(this.model);
			this.viewModel = this.model;
		}
	}
	ngOnDestroy() {
		var _this$formDirective2;
		(_this$formDirective2 = this.formDirective) === null || _this$formDirective2 === void 0 || _this$formDirective2.removeControl(this);
	}
	ɵngControlCreate(host) {
		super.ngControlCreate(host);
	}
	ɵngControlUpdate(host) {
		super.ngControlUpdate(host, false);
	}
	get shouldBindRequired() {
		return false;
	}
	get path() {
		return this._getPath(this.name);
	}
	get formDirective() {
		return this._parent ? this._parent.formDirective : null;
	}
	viewToModelUpdate(newValue) {
		this.viewModel = newValue;
		this.update.emit(newValue);
	}
	_setUpControl() {
		this._setUpdateStrategy();
		this._isStandalone() ? this._setUpStandalone() : this.formDirective.addControl(this);
		this._registered = true;
	}
	_setUpdateStrategy() {
		if (this.options && this.options.updateOn != null) this.control._updateOn = this.options.updateOn;
	}
	_isStandalone() {
		return !this._parent || !!(this.options && this.options.standalone);
	}
	_setUpStandalone() {
		if (!this.isCustomControlBased) {
			var _this$valueAccessor;
			(_this$valueAccessor = this.valueAccessor) !== null && _this$valueAccessor !== void 0 || (this.valueAccessor = this.selectedValueAccessor);
			setUpControlValueAccessor(this.control, this, this.callSetDisabledState);
		} else this.setupCustomControl();
		this.control.updateValueAndValidity({ emitEvent: false });
	}
	_setupWithForm(callSetDisabledState) {
		if (!this.isCustomControlBased) {
			var _this$valueAccessor2;
			(_this$valueAccessor2 = this.valueAccessor) !== null && _this$valueAccessor2 !== void 0 || (this.valueAccessor = this.selectedValueAccessor);
			setUpControlValueAccessor(this.control, this, callSetDisabledState);
		} else this.setupCustomControl();
	}
	_checkForErrors() {
		if ((typeof ngDevMode === "undefined" || ngDevMode) && !this._isStandalone()) checkParentType$1(this._parent);
		this._checkName();
	}
	_checkName() {
		if (this.options && this.options.name) this.name = this.options.name;
		if (!this._isStandalone() && !this.name && (typeof ngDevMode === "undefined" || ngDevMode)) throw missingNameException();
	}
	_updateValue(value) {
		resolvedPromise.then(() => {
			var _this$_changeDetector;
			this.control.setValue(value, { emitViewToModelChange: false });
			(_this$_changeDetector = this._changeDetectorRef) === null || _this$_changeDetector === void 0 || _this$_changeDetector.markForCheck();
		});
	}
	_updateDisabled(changes) {
		const disabledValue = changes["isDisabled"].currentValue;
		const isDisabled = disabledValue !== 0 && booleanAttribute(disabledValue);
		resolvedPromise.then(() => {
			var _this$_changeDetector2;
			if (isDisabled && !this.control.disabled) this.control.disable();
			else if (!isDisabled && this.control.disabled) this.control.enable();
			(_this$_changeDetector2 = this._changeDetectorRef) === null || _this$_changeDetector2 === void 0 || _this$_changeDetector2.markForCheck();
		});
	}
	_getPath(controlName) {
		return this._parent ? controlPath(controlName, this._parent) : [controlName];
	}
};
_NgModel = NgModel;
_defineProperty(NgModel, "ngAcceptInputType_isDisabled", void 0);
_defineProperty(NgModel, "ɵfac", function NgModel_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgModel)(ɵɵdirectiveInject(ControlContainer, 9), ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10), ɵɵdirectiveInject(NG_VALUE_ACCESSOR, 10), ɵɵdirectiveInject(ChangeDetectorRef, 8), ɵɵdirectiveInject(CALL_SET_DISABLED_STATE, 8), ɵɵdirectiveInject(Injector, 8), ɵɵdirectiveInject(Renderer2, 8));
});
_defineProperty(NgModel, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgModel,
	selectors: [[
		"",
		"ngModel",
		"",
		3,
		"formControlName",
		"",
		3,
		"formControl",
		""
	]],
	inputs: {
		name: "name",
		isDisabled: [
			0,
			"disabled",
			"isDisabled"
		],
		model: [
			0,
			"ngModel",
			"model"
		],
		options: [
			0,
			"ngModelOptions",
			"options"
		]
	},
	outputs: { update: "ngModelChange" },
	exportAs: ["ngModel"],
	standalone: false,
	features: [
		ɵɵProvidersFeature([formControlBinding$1, NG_CONTROL_INTEGRATION_PROVIDER]),
		ɵɵInheritDefinitionFeature,
		ɵɵNgOnChangesFeature,
		ɵɵControlFeature(null)
	]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgModel, [{
		type: Directive,
		args: [{
			selector: "[ngModel]:not([formControlName]):not([formControl])",
			providers: [formControlBinding$1, NG_CONTROL_INTEGRATION_PROVIDER],
			exportAs: "ngModel",
			standalone: false
		}]
	}], () => [
		{
			type: ControlContainer,
			decorators: [{ type: Optional }, { type: Host }]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALUE_ACCESSOR]
				}
			]
		},
		{
			type: ChangeDetectorRef,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [ChangeDetectorRef]
			}]
		},
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [CALL_SET_DISABLED_STATE]
			}]
		},
		{
			type: Injector,
			decorators: [{ type: Optional }]
		},
		{
			type: Renderer2,
			decorators: [{ type: Optional }]
		}
	], {
		name: [{ type: Input }],
		isDisabled: [{
			type: Input,
			args: ["disabled"]
		}],
		model: [{
			type: Input,
			args: ["ngModel"]
		}],
		options: [{
			type: Input,
			args: ["ngModelOptions"]
		}],
		update: [{
			type: Output,
			args: ["ngModelChange"]
		}]
	});
})();
function checkParentType$1(parent) {
	if (!(parent instanceof NgModelGroup) && parent instanceof AbstractFormGroupDirective) throw formGroupNameException();
	else if (!(parent instanceof NgModelGroup) && !(parent instanceof NgForm)) throw modelParentException();
}
var ɵNgNoValidate = class {};
_ɵNgNoValidate = ɵNgNoValidate;
_defineProperty(ɵNgNoValidate, "ɵfac", function ɵNgNoValidate_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ɵNgNoValidate)();
});
_defineProperty(ɵNgNoValidate, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _ɵNgNoValidate,
	selectors: [[
		"form",
		3,
		"ngNoForm",
		"",
		3,
		"ngNativeValidate",
		""
	]],
	hostAttrs: ["novalidate", ""],
	standalone: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ɵNgNoValidate, [{
		type: Directive,
		args: [{
			selector: "form:not([ngNoForm]):not([ngNativeValidate])",
			host: { "novalidate": "" },
			standalone: false
		}]
	}], null, null);
})();
var NUMBER_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => NumberValueAccessor),
	multi: true
};
var NumberValueAccessor = class extends BuiltInControlValueAccessor {
	writeValue(value) {
		const normalizedValue = value == null ? "" : value;
		this.setProperty("value", normalizedValue);
	}
	registerOnChange(fn) {
		this.onChange = (value) => {
			fn(value == "" ? null : parseFloat(value));
		};
	}
};
_NumberValueAccessor = NumberValueAccessor;
_defineProperty(NumberValueAccessor, "ɵfac", /* @__PURE__ */ (() => {
	let ɵNumberValueAccessor_BaseFactory;
	return function NumberValueAccessor_Factory(__ngFactoryType__) {
		return (ɵNumberValueAccessor_BaseFactory || (ɵNumberValueAccessor_BaseFactory = ɵɵgetInheritedFactory(_NumberValueAccessor)))(__ngFactoryType__ || _NumberValueAccessor);
	};
})());
_defineProperty(NumberValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NumberValueAccessor,
	selectors: [
		[
			"input",
			"type",
			"number",
			"formControlName",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"number",
			"formControl",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"number",
			"ngModel",
			"",
			3,
			"ngNoCva",
			""
		]
	],
	hostBindings: function NumberValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("input", function NumberValueAccessor_input_HostBindingHandler($event) {
			return ctx.onChange($event.target.value);
		})("blur", function NumberValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		});
	},
	standalone: false,
	features: [ɵɵProvidersFeature([NUMBER_VALUE_ACCESSOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NumberValueAccessor, [{
		type: Directive,
		args: [{
			selector: "input[type=number]:not([ngNoCva])[formControlName],input[type=number]:not([ngNoCva])[formControl],input[type=number]:not([ngNoCva])[ngModel]",
			host: {
				"(input)": "onChange($any($event.target).value)",
				"(blur)": "onTouched()"
			},
			providers: [NUMBER_VALUE_ACCESSOR],
			standalone: false
		}]
	}], null, null);
})();
var RADIO_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => RadioControlValueAccessor),
	multi: true
};
function throwNameError() {
	throw new RuntimeError(1202, `
      If you define both a name and a formControlName attribute on your radio button, their values
      must match. Ex: <input type="radio" formControlName="food" name="food">
    `);
}
var RadioControlRegistry = class {
	constructor() {
		_defineProperty(this, "_accessors", []);
	}
	add(control, accessor) {
		this._accessors.push([control, accessor]);
	}
	remove(accessor) {
		for (let i = this._accessors.length - 1; i >= 0; --i) if (this._accessors[i][1] === accessor) {
			this._accessors.splice(i, 1);
			return;
		}
	}
	select(accessor) {
		this._accessors.forEach((c) => {
			if (this._isSameGroup(c, accessor) && c[1] !== accessor) c[1].fireUncheck(accessor.value);
		});
	}
	_isSameGroup(controlPair, accessor) {
		if (!controlPair[0].control) return false;
		return controlPair[0]._parent === accessor._control._parent && controlPair[1].name === accessor.name;
	}
};
_RadioControlRegistry = RadioControlRegistry;
_defineProperty(RadioControlRegistry, "ɵfac", function RadioControlRegistry_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RadioControlRegistry)();
});
_defineProperty(RadioControlRegistry, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _RadioControlRegistry,
	factory: _RadioControlRegistry.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RadioControlRegistry, [{ type: Service }], null, null);
})();
var RadioControlValueAccessor = class extends BuiltInControlValueAccessor {
	constructor(renderer, elementRef, _registry, _injector) {
		var _inject;
		super(renderer, elementRef);
		_defineProperty(this, "_registry", void 0);
		_defineProperty(this, "_injector", void 0);
		_defineProperty(this, "_state", void 0);
		_defineProperty(this, "_control", void 0);
		_defineProperty(this, "_fn", void 0);
		_defineProperty(this, "setDisabledStateFired", false);
		_defineProperty(this, "onChange", () => {});
		_defineProperty(this, "name", void 0);
		_defineProperty(this, "formControlName", void 0);
		_defineProperty(this, "value", void 0);
		_defineProperty(this, "callSetDisabledState", (_inject = inject(CALL_SET_DISABLED_STATE, { optional: true })) !== null && _inject !== void 0 ? _inject : setDisabledStateDefault);
		this._registry = _registry;
		this._injector = _injector;
	}
	ngOnChanges(changes) {
		var _this$_control;
		const control = (_this$_control = this._control) === null || _this$_control === void 0 ? void 0 : _this$_control.control;
		if (changes["value"] && control) this.writeValue(control.value);
	}
	ngOnInit() {
		this._control = this._injector.get(NgControl);
		this._checkName();
		this._registry.add(this._control, this);
	}
	ngOnDestroy() {
		this._registry.remove(this);
	}
	writeValue(value) {
		this._state = value === this.value;
		this.setProperty("checked", this._state);
	}
	registerOnChange(fn) {
		this._fn = fn;
		this.onChange = () => {
			fn(this.value);
			this._registry.select(this);
		};
	}
	setDisabledState(isDisabled) {
		if (this.setDisabledStateFired || isDisabled || this.callSetDisabledState === "whenDisabledForLegacyCode") this.setProperty("disabled", isDisabled);
		this.setDisabledStateFired = true;
	}
	fireUncheck(value) {
		this.writeValue(value);
	}
	_checkName() {
		if (this.name && this.formControlName && this.name !== this.formControlName && (typeof ngDevMode === "undefined" || ngDevMode)) throwNameError();
		if (!this.name && this.formControlName) this.name = this.formControlName;
	}
};
_RadioControlValueAccessor = RadioControlValueAccessor;
_defineProperty(RadioControlValueAccessor, "ɵfac", function RadioControlValueAccessor_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RadioControlValueAccessor)(ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(RadioControlRegistry), ɵɵdirectiveInject(Injector));
});
_defineProperty(RadioControlValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _RadioControlValueAccessor,
	selectors: [
		[
			"input",
			"type",
			"radio",
			"formControlName",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"radio",
			"formControl",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"radio",
			"ngModel",
			"",
			3,
			"ngNoCva",
			""
		]
	],
	hostBindings: function RadioControlValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("change", function RadioControlValueAccessor_change_HostBindingHandler() {
			return ctx.onChange();
		})("blur", function RadioControlValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		});
	},
	inputs: {
		name: "name",
		formControlName: "formControlName",
		value: "value"
	},
	standalone: false,
	features: [
		ɵɵProvidersFeature([RADIO_VALUE_ACCESSOR]),
		ɵɵInheritDefinitionFeature,
		ɵɵNgOnChangesFeature
	]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RadioControlValueAccessor, [{
		type: Directive,
		args: [{
			selector: "input[type=radio]:not([ngNoCva])[formControlName],input[type=radio]:not([ngNoCva])[formControl],input[type=radio]:not([ngNoCva])[ngModel]",
			host: {
				"(change)": "onChange()",
				"(blur)": "onTouched()"
			},
			providers: [RADIO_VALUE_ACCESSOR],
			standalone: false
		}]
	}], () => [
		{ type: Renderer2 },
		{ type: ElementRef },
		{ type: RadioControlRegistry },
		{ type: Injector }
	], {
		name: [{ type: Input }],
		formControlName: [{ type: Input }],
		value: [{ type: Input }]
	});
})();
var RANGE_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => RangeValueAccessor),
	multi: true
};
var RangeValueAccessor = class extends BuiltInControlValueAccessor {
	writeValue(value) {
		this.setProperty("value", parseFloat(value));
	}
	registerOnChange(fn) {
		this.onChange = (value) => {
			fn(value == "" ? null : parseFloat(value));
		};
	}
};
_RangeValueAccessor = RangeValueAccessor;
_defineProperty(RangeValueAccessor, "ɵfac", /* @__PURE__ */ (() => {
	let ɵRangeValueAccessor_BaseFactory;
	return function RangeValueAccessor_Factory(__ngFactoryType__) {
		return (ɵRangeValueAccessor_BaseFactory || (ɵRangeValueAccessor_BaseFactory = ɵɵgetInheritedFactory(_RangeValueAccessor)))(__ngFactoryType__ || _RangeValueAccessor);
	};
})());
_defineProperty(RangeValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _RangeValueAccessor,
	selectors: [
		[
			"input",
			"type",
			"range",
			"formControlName",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"range",
			"formControl",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"input",
			"type",
			"range",
			"ngModel",
			"",
			3,
			"ngNoCva",
			""
		]
	],
	hostBindings: function RangeValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("change", function RangeValueAccessor_change_HostBindingHandler($event) {
			return ctx.onChange($event.target.value);
		})("input", function RangeValueAccessor_input_HostBindingHandler($event) {
			return ctx.onChange($event.target.value);
		})("blur", function RangeValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		});
	},
	standalone: false,
	features: [ɵɵProvidersFeature([RANGE_VALUE_ACCESSOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RangeValueAccessor, [{
		type: Directive,
		args: [{
			selector: "input[type=range]:not([ngNoCva])[formControlName],input[type=range]:not([ngNoCva])[formControl],input[type=range]:not([ngNoCva])[ngModel]",
			host: {
				"(change)": "onChange($any($event.target).value)",
				"(input)": "onChange($any($event.target).value)",
				"(blur)": "onTouched()"
			},
			providers: [RANGE_VALUE_ACCESSOR],
			standalone: false
		}]
	}], null, null);
})();
var FormArray = class extends AbstractControl {
	constructor(controls, validatorOrOpts, asyncValidator) {
		super(pickValidators(validatorOrOpts), pickAsyncValidators(asyncValidator, validatorOrOpts));
		_defineProperty(this, "controls", void 0);
		this.controls = controls;
		this._initObservables();
		this._setUpdateStrategy(validatorOrOpts);
		this._setUpControls();
		this.updateValueAndValidity({
			onlySelf: true,
			emitEvent: !!this.asyncValidator
		});
	}
	at(index) {
		return this.controls[this._adjustIndex(index)];
	}
	push(control, options = {}) {
		if (Array.isArray(control)) control.forEach((ctrl) => {
			this.controls.push(ctrl);
			this._registerControl(ctrl);
		});
		else {
			this.controls.push(control);
			this._registerControl(control);
		}
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
		this._onCollectionChange();
	}
	insert(index, control, options = {}) {
		this.controls.splice(index, 0, control);
		this._registerControl(control);
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
	}
	removeAt(index, options = {}) {
		let adjustedIndex = this._adjustIndex(index);
		if (adjustedIndex < 0) adjustedIndex = 0;
		if (this.controls[adjustedIndex]) this.controls[adjustedIndex]._registerOnCollectionChange(() => {});
		this.controls.splice(adjustedIndex, 1);
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
	}
	setControl(index, control, options = {}) {
		let adjustedIndex = this._adjustIndex(index);
		if (adjustedIndex < 0) adjustedIndex = 0;
		if (this.controls[adjustedIndex]) this.controls[adjustedIndex]._registerOnCollectionChange(() => {});
		this.controls.splice(adjustedIndex, 1);
		if (control) {
			this.controls.splice(adjustedIndex, 0, control);
			this._registerControl(control);
		}
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
		this._onCollectionChange();
	}
	get length() {
		return this.controls.length;
	}
	setValue(value, options = {}) {
		untracked(() => {
			assertAllValuesPresent(this, false, value);
			value.forEach((newValue, index) => {
				assertControlPresent(this, false, index);
				this.at(index).setValue(newValue, {
					onlySelf: true,
					emitEvent: options.emitEvent
				});
			});
			this.updateValueAndValidity(options);
		});
	}
	patchValue(value, options = {}) {
		if (value == null) return;
		value.forEach((newValue, index) => {
			if (this.at(index)) this.at(index).patchValue(newValue, {
				onlySelf: true,
				emitEvent: options.emitEvent
			});
		});
		this.updateValueAndValidity(options);
	}
	reset(value = [], options = {}) {
		this._forEachChild((control, index) => {
			control.reset(value[index], _objectSpread2(_objectSpread2({}, options), {}, { onlySelf: true }));
		});
		this._updatePristine(options, this);
		this._updateTouched(options, this);
		this.updateValueAndValidity(options);
		if ((options === null || options === void 0 ? void 0 : options.emitEvent) !== false) this._events.next(new FormResetEvent(this));
	}
	getRawValue() {
		return this.controls.map((control) => control.getRawValue());
	}
	clear(options = {}) {
		if (this.controls.length < 1) return;
		this._forEachChild((control) => control._registerOnCollectionChange(() => {}));
		this.controls.splice(0);
		this.updateValueAndValidity({ emitEvent: options.emitEvent });
	}
	_adjustIndex(index) {
		return index < 0 ? index + this.length : index;
	}
	_syncPendingControls() {
		let subtreeUpdated = this.controls.reduce((updated, child) => {
			return child._syncPendingControls() ? true : updated;
		}, false);
		if (subtreeUpdated) this.updateValueAndValidity({ onlySelf: true });
		return subtreeUpdated;
	}
	_forEachChild(cb) {
		this.controls.forEach((control, index) => {
			cb(control, index);
		});
	}
	_updateValue() {
		this.value = this.controls.filter((control) => control.enabled || this.disabled).map((control) => control.value);
	}
	_anyControls(condition) {
		return this.controls.some((control) => control.enabled && condition(control));
	}
	_setUpControls() {
		this._forEachChild((control) => this._registerControl(control));
	}
	_allControlsDisabled() {
		for (const control of this.controls) if (control.enabled) return false;
		return this.controls.length > 0 || this.disabled;
	}
	_registerControl(control) {
		control.setParent(this);
		control._registerOnCollectionChange(this._onCollectionChange);
	}
	_find(name) {
		var _this$at;
		return (_this$at = this.at(name)) !== null && _this$at !== void 0 ? _this$at : null;
	}
};
var UntypedFormArray = FormArray;
var isFormArray = (control) => control instanceof FormArray;
var AbstractFormDirective = class extends ControlContainer {
	get submitted() {
		return untracked(this._submittedReactive);
	}
	set submitted(value) {
		this._submittedReactive.set(value);
	}
	constructor(validators, asyncValidators, callSetDisabledState) {
		super();
		_defineProperty(this, "callSetDisabledState", void 0);
		_defineProperty(this, "_submitted", computed(() => this._submittedReactive(), ...ngDevMode ? [{ debugName: "_submitted" }] : []));
		_defineProperty(this, "_submittedReactive", signal(false, ...ngDevMode ? [{ debugName: "_submittedReactive" }] : []));
		_defineProperty(this, "_oldForm", void 0);
		_defineProperty(this, "_onCollectionChange", () => this._updateDomValue());
		_defineProperty(this, "directives", []);
		this.callSetDisabledState = callSetDisabledState;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	ngOnChanges(changes) {
		this.onChanges(changes);
	}
	ngOnDestroy() {
		this.onDestroy();
	}
	onChanges(changes) {
		this._checkFormPresent();
		if (changes.hasOwnProperty("form")) {
			this._updateValidators();
			this._updateDomValue();
			this._updateRegistrations();
			this._oldForm = this.form;
		}
	}
	onDestroy() {
		if (this.form) {
			cleanUpValidators(this.form, this);
			if (this.form._onCollectionChange === this._onCollectionChange) this.form._registerOnCollectionChange(() => {});
		}
	}
	get formDirective() {
		return this;
	}
	get path() {
		return [];
	}
	addControl(dir) {
		const ctrl = this.form.get(dir.path);
		dir._setupWithForm(ctrl, this.callSetDisabledState);
		ctrl.updateValueAndValidity({ emitEvent: false });
		this.directives.push(dir);
		return ctrl;
	}
	getControl(dir) {
		return this.form.get(dir.path);
	}
	removeControl(dir) {
		cleanUpControl(dir.control || null, dir, false);
		removeListItem$1(this.directives, dir);
	}
	addFormGroup(dir) {
		this._setUpFormContainer(dir);
	}
	removeFormGroup(dir) {
		this._cleanUpFormContainer(dir);
	}
	getFormGroup(dir) {
		return this.form.get(dir.path);
	}
	getFormArray(dir) {
		return this.form.get(dir.path);
	}
	addFormArray(dir) {
		this._setUpFormContainer(dir);
	}
	removeFormArray(dir) {
		this._cleanUpFormContainer(dir);
	}
	updateModel(dir, value) {
		this.form.get(dir.path).setValue(value);
	}
	onReset() {
		this.resetForm();
	}
	resetForm(value = void 0, options = {}) {
		this.form.reset(value, options);
		this._submittedReactive.set(false);
	}
	onSubmit($event) {
		var _$event$target2;
		this.submitted = true;
		syncPendingControls(this.form, this.directives);
		this.ngSubmit.emit($event);
		this.form._events.next(new FormSubmittedEvent(this.control));
		return ($event === null || $event === void 0 || (_$event$target2 = $event.target) === null || _$event$target2 === void 0 ? void 0 : _$event$target2.method) === "dialog";
	}
	_updateDomValue() {
		this.directives.forEach((dir) => {
			const oldCtrl = dir.control;
			const newCtrl = this.form.get(dir.path);
			if (oldCtrl !== newCtrl) {
				cleanUpControl(oldCtrl || null, dir);
				if (isFormControl(newCtrl)) dir._setupWithForm(newCtrl, this.callSetDisabledState);
			}
		});
		this.form._updateTreeValidity({ emitEvent: false });
	}
	_setUpFormContainer(dir) {
		const ctrl = this.form.get(dir.path);
		setUpFormContainer(ctrl, dir);
		ctrl.updateValueAndValidity({ emitEvent: false });
	}
	_cleanUpFormContainer(dir) {
		var _this$form;
		const ctrl = (_this$form = this.form) === null || _this$form === void 0 ? void 0 : _this$form.get(dir.path);
		if (ctrl) {
			if (cleanUpFormContainer(ctrl, dir)) ctrl.updateValueAndValidity({ emitEvent: false });
		}
	}
	_updateRegistrations() {
		var _this$_oldForm;
		this.form._registerOnCollectionChange(this._onCollectionChange);
		(_this$_oldForm = this._oldForm) === null || _this$_oldForm === void 0 || _this$_oldForm._registerOnCollectionChange(() => {});
	}
	_updateValidators() {
		setUpValidators(this.form, this);
		if (this._oldForm) cleanUpValidators(this._oldForm, this);
	}
	_checkFormPresent() {
		if (!this.form && (typeof ngDevMode === "undefined" || ngDevMode)) throw missingFormException();
	}
};
_AbstractFormDirective = AbstractFormDirective;
_defineProperty(AbstractFormDirective, "ɵfac", function AbstractFormDirective_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _AbstractFormDirective)(ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10), ɵɵdirectiveInject(CALL_SET_DISABLED_STATE, 8));
});
_defineProperty(AbstractFormDirective, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _AbstractFormDirective,
	features: [ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AbstractFormDirective, [{ type: Directive }], () => [
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [CALL_SET_DISABLED_STATE]
			}]
		}
	], null);
})();
var formDirectiveProvider$1 = {
	provide: ControlContainer,
	useExisting: forwardRef(() => FormArrayDirective)
};
var FormArrayDirective = class extends AbstractFormDirective {
	constructor(..._args11) {
		super(..._args11);
		_defineProperty(this, "form", null);
		_defineProperty(this, "ngSubmit", new EventEmitter());
	}
	get control() {
		return this.form;
	}
};
_FormArrayDirective = FormArrayDirective;
_defineProperty(FormArrayDirective, "ɵfac", /* @__PURE__ */ (() => {
	let ɵFormArrayDirective_BaseFactory;
	return function FormArrayDirective_Factory(__ngFactoryType__) {
		return (ɵFormArrayDirective_BaseFactory || (ɵFormArrayDirective_BaseFactory = ɵɵgetInheritedFactory(_FormArrayDirective)))(__ngFactoryType__ || _FormArrayDirective);
	};
})());
_defineProperty(FormArrayDirective, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _FormArrayDirective,
	selectors: [[
		"",
		"formArray",
		""
	]],
	hostBindings: function FormArrayDirective_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("submit", function FormArrayDirective_submit_HostBindingHandler($event) {
			return ctx.onSubmit($event);
		})("reset", function FormArrayDirective_reset_HostBindingHandler() {
			return ctx.onReset();
		});
	},
	inputs: { form: [
		0,
		"formArray",
		"form"
	] },
	outputs: { ngSubmit: "ngSubmit" },
	exportAs: ["ngForm"],
	standalone: false,
	features: [ɵɵProvidersFeature([formDirectiveProvider$1]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormArrayDirective, [{
		type: Directive,
		args: [{
			selector: "[formArray]",
			providers: [formDirectiveProvider$1],
			host: {
				"(submit)": "onSubmit($event)",
				"(reset)": "onReset()"
			},
			exportAs: "ngForm",
			standalone: false
		}]
	}], null, {
		form: [{
			type: Input,
			args: ["formArray"]
		}],
		ngSubmit: [{ type: Output }]
	});
})();
var NG_MODEL_WITH_FORM_CONTROL_WARNING = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "NgModelWithFormControlWarning" : "");
var formControlBinding = {
	provide: NgControl,
	useExisting: forwardRef(() => FormControlDirective)
};
var FormControlDirective = class FormControlDirective extends NgControl {
	set isDisabled(isDisabled) {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.warn(disabledAttrWarning);
	}
	constructor(validators, asyncValidators, valueAccessors, _ngModelWarningConfig, callSetDisabledState, renderer, injector) {
		super(injector, renderer, valueAccessors);
		_defineProperty(this, "_ngModelWarningConfig", void 0);
		_defineProperty(this, "callSetDisabledState", void 0);
		_defineProperty(this, "viewModel", void 0);
		_defineProperty(this, "form", void 0);
		_defineProperty(this, "model", void 0);
		_defineProperty(this, "update", new EventEmitter());
		_defineProperty(this, "_ngModelWarningSent", false);
		this._ngModelWarningConfig = _ngModelWarningConfig;
		this.callSetDisabledState = callSetDisabledState;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	ngOnChanges(changes) {
		if (this._isControlChanged(changes)) {
			const previousForm = changes["form"].previousValue;
			if (previousForm) {
				cleanUpControl(previousForm, this, false);
				this.removeParseErrorsValidator(previousForm);
			}
			if (!this.isCustomControlBased) {
				var _this$valueAccessor3;
				(_this$valueAccessor3 = this.valueAccessor) !== null && _this$valueAccessor3 !== void 0 || (this.valueAccessor = this.selectedValueAccessor);
				setUpControlValueAccessor(this.form, this, this.callSetDisabledState);
			} else this.setupCustomControl();
			this.form.updateValueAndValidity({ emitEvent: false });
		}
		if (isPropertyUpdated(changes, this.viewModel)) {
			if (typeof ngDevMode === "undefined" || ngDevMode) _ngModelWarning("formControl", FormControlDirective, this, this._ngModelWarningConfig);
			this.form.setValue(this.model);
			this.viewModel = this.model;
		}
	}
	ngOnDestroy() {
		if (this.form) cleanUpControl(this.form, this, false);
	}
	get path() {
		return [];
	}
	get control() {
		return this.form;
	}
	viewToModelUpdate(newValue) {
		this.viewModel = newValue;
		this.update.emit(newValue);
	}
	_isControlChanged(changes) {
		return changes.hasOwnProperty("form");
	}
	ɵngControlCreate(host) {
		super.ngControlCreate(host);
	}
	ɵngControlUpdate(host) {
		super.ngControlUpdate(host, true);
	}
};
_FormControlDirective = FormControlDirective;
_defineProperty(FormControlDirective, "_ngModelWarningSentOnce", false);
_defineProperty(FormControlDirective, "ɵfac", function FormControlDirective_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FormControlDirective)(ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10), ɵɵdirectiveInject(NG_VALUE_ACCESSOR, 10), ɵɵdirectiveInject(NG_MODEL_WITH_FORM_CONTROL_WARNING, 8), ɵɵdirectiveInject(CALL_SET_DISABLED_STATE, 8), ɵɵdirectiveInject(Renderer2, 8), ɵɵdirectiveInject(Injector, 8));
});
_defineProperty(FormControlDirective, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _FormControlDirective,
	selectors: [[
		"",
		"formControl",
		""
	]],
	inputs: {
		form: [
			0,
			"formControl",
			"form"
		],
		isDisabled: [
			0,
			"disabled",
			"isDisabled"
		],
		model: [
			0,
			"ngModel",
			"model"
		]
	},
	outputs: { update: "ngModelChange" },
	exportAs: ["ngForm"],
	standalone: false,
	features: [
		ɵɵProvidersFeature([formControlBinding, NG_CONTROL_INTEGRATION_PROVIDER]),
		ɵɵInheritDefinitionFeature,
		ɵɵNgOnChangesFeature,
		ɵɵControlFeature(null)
	]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormControlDirective, [{
		type: Directive,
		args: [{
			selector: "[formControl]",
			providers: [formControlBinding, NG_CONTROL_INTEGRATION_PROVIDER],
			exportAs: "ngForm",
			standalone: false
		}]
	}], () => [
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALUE_ACCESSOR]
				}
			]
		},
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [NG_MODEL_WITH_FORM_CONTROL_WARNING]
			}]
		},
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [CALL_SET_DISABLED_STATE]
			}]
		},
		{
			type: Renderer2,
			decorators: [{ type: Optional }]
		},
		{
			type: Injector,
			decorators: [{ type: Optional }]
		}
	], {
		form: [{
			type: Input,
			args: ["formControl"]
		}],
		isDisabled: [{
			type: Input,
			args: ["disabled"]
		}],
		model: [{
			type: Input,
			args: ["ngModel"]
		}],
		update: [{
			type: Output,
			args: ["ngModelChange"]
		}]
	});
})();
var formGroupNameProvider = {
	provide: ControlContainer,
	useExisting: forwardRef(() => FormGroupName)
};
var FormGroupName = class extends AbstractFormGroupDirective {
	constructor(parent, validators, asyncValidators) {
		super();
		_defineProperty(this, "name", null);
		this._parent = parent;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	_checkParentType() {
		if (hasInvalidParent(this._parent) && (typeof ngDevMode === "undefined" || ngDevMode)) throw groupParentException();
	}
};
_FormGroupName = FormGroupName;
_defineProperty(FormGroupName, "ɵfac", function FormGroupName_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FormGroupName)(ɵɵdirectiveInject(ControlContainer, 13), ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10));
});
_defineProperty(FormGroupName, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _FormGroupName,
	selectors: [[
		"",
		"formGroupName",
		""
	]],
	inputs: { name: [
		0,
		"formGroupName",
		"name"
	] },
	standalone: false,
	features: [ɵɵProvidersFeature([formGroupNameProvider]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormGroupName, [{
		type: Directive,
		args: [{
			selector: "[formGroupName]",
			providers: [formGroupNameProvider],
			standalone: false
		}]
	}], () => [
		{
			type: ControlContainer,
			decorators: [
				{ type: Optional },
				{ type: Host },
				{ type: SkipSelf }
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		}
	], { name: [{
		type: Input,
		args: ["formGroupName"]
	}] });
})();
var formArrayNameProvider = {
	provide: ControlContainer,
	useExisting: forwardRef(() => FormArrayName)
};
var FormArrayName = class extends ControlContainer {
	constructor(parent, validators, asyncValidators) {
		super();
		_defineProperty(this, "_parent", void 0);
		_defineProperty(this, "name", null);
		this._parent = parent;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	ngOnInit() {
		if (hasInvalidParent(this._parent) && (typeof ngDevMode === "undefined" || ngDevMode)) throw arrayParentException();
		this.formDirective.addFormArray(this);
	}
	ngOnDestroy() {
		var _this$formDirective3;
		(_this$formDirective3 = this.formDirective) === null || _this$formDirective3 === void 0 || _this$formDirective3.removeFormArray(this);
	}
	get control() {
		return this.formDirective.getFormArray(this);
	}
	get formDirective() {
		return this._parent ? this._parent.formDirective : null;
	}
	get path() {
		return controlPath(this.name == null ? this.name : this.name.toString(), this._parent);
	}
};
_FormArrayName = FormArrayName;
_defineProperty(FormArrayName, "ɵfac", function FormArrayName_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FormArrayName)(ɵɵdirectiveInject(ControlContainer, 13), ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10));
});
_defineProperty(FormArrayName, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _FormArrayName,
	selectors: [[
		"",
		"formArrayName",
		""
	]],
	inputs: { name: [
		0,
		"formArrayName",
		"name"
	] },
	standalone: false,
	features: [ɵɵProvidersFeature([formArrayNameProvider]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormArrayName, [{
		type: Directive,
		args: [{
			selector: "[formArrayName]",
			providers: [formArrayNameProvider],
			standalone: false
		}]
	}], () => [
		{
			type: ControlContainer,
			decorators: [
				{ type: Optional },
				{ type: Host },
				{ type: SkipSelf }
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		}
	], { name: [{
		type: Input,
		args: ["formArrayName"]
	}] });
})();
function hasInvalidParent(parent) {
	return !(parent instanceof FormGroupName) && !(parent instanceof AbstractFormDirective) && !(parent instanceof FormArrayName);
}
var controlNameBinding = {
	provide: NgControl,
	useExisting: forwardRef(() => FormControlName)
};
var FormControlName = class FormControlName extends NgControl {
	set isDisabled(isDisabled) {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.warn(disabledAttrWarning);
	}
	constructor(parent, validators, asyncValidators, valueAccessors, _ngModelWarningConfig, renderer, injector) {
		super(injector, renderer, valueAccessors);
		_defineProperty(this, "_ngModelWarningConfig", void 0);
		_defineProperty(this, "_added", false);
		_defineProperty(this, "viewModel", void 0);
		_defineProperty(this, "control", void 0);
		_defineProperty(this, "name", null);
		_defineProperty(this, "model", void 0);
		_defineProperty(this, "update", new EventEmitter());
		_defineProperty(this, "_ngModelWarningSent", false);
		this._ngModelWarningConfig = _ngModelWarningConfig;
		this._parent = parent;
		this._setValidators(validators);
		this._setAsyncValidators(asyncValidators);
	}
	_setupWithForm(control, callSetDisabledState) {
		this.control = control;
		if (!this.isCustomControlBased) {
			var _this$valueAccessor4;
			(_this$valueAccessor4 = this.valueAccessor) !== null && _this$valueAccessor4 !== void 0 || (this.valueAccessor = this.selectedValueAccessor);
			setUpControlValueAccessor(control, this, callSetDisabledState);
		} else this.setupCustomControl();
	}
	ngOnChanges(changes) {
		if (!this._added) this._setUpControl();
		if (isPropertyUpdated(changes, this.viewModel)) {
			if (typeof ngDevMode === "undefined" || ngDevMode) _ngModelWarning("formControlName", FormControlName, this, this._ngModelWarningConfig);
			this.viewModel = this.model;
			this.formDirective.updateModel(this, this.model);
		}
	}
	ngOnDestroy() {
		var _this$formDirective4;
		(_this$formDirective4 = this.formDirective) === null || _this$formDirective4 === void 0 || _this$formDirective4.removeControl(this);
	}
	viewToModelUpdate(newValue) {
		this.viewModel = newValue;
		this.update.emit(newValue);
	}
	get path() {
		return controlPath(this.name == null ? this.name : this.name.toString(), this._parent);
	}
	get formDirective() {
		return this._parent ? this._parent.formDirective : null;
	}
	_setUpControl() {
		if (typeof ngDevMode === "undefined" || ngDevMode) checkParentType(this._parent, this.name);
		this.control = this.formDirective.addControl(this);
		this._added = true;
	}
	ɵngControlCreate(host) {
		super.ngControlCreate(host);
	}
	ɵngControlUpdate(host) {
		if (!this.isCustomControlBased) return;
		if (!this._added) this._setUpControl();
		super.ngControlUpdate(host, true);
	}
};
_FormControlName = FormControlName;
_defineProperty(FormControlName, "_ngModelWarningSentOnce", false);
_defineProperty(FormControlName, "ɵfac", function FormControlName_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FormControlName)(ɵɵdirectiveInject(ControlContainer, 13), ɵɵdirectiveInject(NG_VALIDATORS, 10), ɵɵdirectiveInject(NG_ASYNC_VALIDATORS, 10), ɵɵdirectiveInject(NG_VALUE_ACCESSOR, 10), ɵɵdirectiveInject(NG_MODEL_WITH_FORM_CONTROL_WARNING, 8), ɵɵdirectiveInject(Renderer2, 8), ɵɵdirectiveInject(Injector, 8));
});
_defineProperty(FormControlName, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _FormControlName,
	selectors: [[
		"",
		"formControlName",
		""
	]],
	inputs: {
		name: [
			0,
			"formControlName",
			"name"
		],
		isDisabled: [
			0,
			"disabled",
			"isDisabled"
		],
		model: [
			0,
			"ngModel",
			"model"
		]
	},
	outputs: { update: "ngModelChange" },
	standalone: false,
	features: [
		ɵɵProvidersFeature([controlNameBinding, NG_CONTROL_INTEGRATION_PROVIDER]),
		ɵɵInheritDefinitionFeature,
		ɵɵNgOnChangesFeature,
		ɵɵControlFeature(null)
	]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormControlName, [{
		type: Directive,
		args: [{
			selector: "[formControlName]",
			providers: [controlNameBinding, NG_CONTROL_INTEGRATION_PROVIDER],
			standalone: false
		}]
	}], () => [
		{
			type: ControlContainer,
			decorators: [
				{ type: Optional },
				{ type: Host },
				{ type: SkipSelf }
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_ASYNC_VALIDATORS]
				}
			]
		},
		{
			type: void 0,
			decorators: [
				{ type: Optional },
				{ type: Self },
				{
					type: Inject,
					args: [NG_VALUE_ACCESSOR]
				}
			]
		},
		{
			type: void 0,
			decorators: [{ type: Optional }, {
				type: Inject,
				args: [NG_MODEL_WITH_FORM_CONTROL_WARNING]
			}]
		},
		{
			type: Renderer2,
			decorators: [{ type: Optional }]
		},
		{
			type: Injector,
			decorators: [{ type: Optional }]
		}
	], {
		name: [{
			type: Input,
			args: ["formControlName"]
		}],
		isDisabled: [{
			type: Input,
			args: ["disabled"]
		}],
		model: [{
			type: Input,
			args: ["ngModel"]
		}],
		update: [{
			type: Output,
			args: ["ngModelChange"]
		}]
	});
})();
function checkParentType(parent, name) {
	if (!(parent instanceof FormGroupName) && parent instanceof AbstractFormGroupDirective) throw ngModelGroupException();
	else if (!(parent instanceof FormGroupName) && !(parent instanceof AbstractFormDirective) && !(parent instanceof FormArrayName)) throw controlParentException(name);
}
var formDirectiveProvider = {
	provide: ControlContainer,
	useExisting: forwardRef(() => FormGroupDirective)
};
var FormGroupDirective = class extends AbstractFormDirective {
	constructor(..._args12) {
		super(..._args12);
		_defineProperty(this, "form", null);
		_defineProperty(this, "ngSubmit", new EventEmitter());
	}
	get control() {
		return this.form;
	}
};
_FormGroupDirective = FormGroupDirective;
_defineProperty(FormGroupDirective, "ɵfac", /* @__PURE__ */ (() => {
	let ɵFormGroupDirective_BaseFactory;
	return function FormGroupDirective_Factory(__ngFactoryType__) {
		return (ɵFormGroupDirective_BaseFactory || (ɵFormGroupDirective_BaseFactory = ɵɵgetInheritedFactory(_FormGroupDirective)))(__ngFactoryType__ || _FormGroupDirective);
	};
})());
_defineProperty(FormGroupDirective, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _FormGroupDirective,
	selectors: [[
		"",
		"formGroup",
		""
	]],
	hostBindings: function FormGroupDirective_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("submit", function FormGroupDirective_submit_HostBindingHandler($event) {
			return ctx.onSubmit($event);
		})("reset", function FormGroupDirective_reset_HostBindingHandler() {
			return ctx.onReset();
		});
	},
	inputs: { form: [
		0,
		"formGroup",
		"form"
	] },
	outputs: { ngSubmit: "ngSubmit" },
	exportAs: ["ngForm"],
	standalone: false,
	features: [ɵɵProvidersFeature([formDirectiveProvider]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormGroupDirective, [{
		type: Directive,
		args: [{
			selector: "[formGroup]",
			providers: [formDirectiveProvider],
			host: {
				"(submit)": "onSubmit($event)",
				"(reset)": "onReset()"
			},
			exportAs: "ngForm",
			standalone: false
		}]
	}], null, {
		form: [{
			type: Input,
			args: ["formGroup"]
		}],
		ngSubmit: [{ type: Output }]
	});
})();
var SELECT_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => SelectControlValueAccessor),
	multi: true
};
function _buildValueString$1(id, value) {
	if (id == null) return `${value}`;
	if (value && typeof value === "object") value = "Object";
	return `${id}: ${value}`.slice(0, 50);
}
function _extractId$1(valueString) {
	return valueString.split(":")[0];
}
var SelectControlValueAccessor = class extends BuiltInControlValueAccessor {
	constructor(..._args13) {
		super(..._args13);
		_defineProperty(this, "value", void 0);
		_defineProperty(this, "_optionMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "_idCounter", 0);
		_defineProperty(this, "_compareWith", Object.is);
		_defineProperty(this, "appRefInjector", inject(ApplicationRef).injector);
		_defineProperty(this, "destroyRef", inject(DestroyRef));
		_defineProperty(this, "cdr", inject(ChangeDetectorRef));
		_defineProperty(this, "_queuedWrite", false);
	}
	set compareWith(fn) {
		if (typeof fn !== "function" && (typeof ngDevMode === "undefined" || ngDevMode)) throw new RuntimeError(1201, `compareWith must be a function, but received ${JSON.stringify(fn)}`);
		this._compareWith = fn;
	}
	_writeValueAfterRender() {
		if (this._queuedWrite || this.appRefInjector.destroyed) return;
		this._queuedWrite = true;
		afterNextRender({ write: () => {
			if (this.destroyRef.destroyed) return;
			this._queuedWrite = false;
			this.writeValue(this.value);
		} }, { injector: this.appRefInjector });
	}
	writeValue(value) {
		this.cdr.markForCheck();
		this.value = value;
		const valueString = _buildValueString$1(this._getOptionId(value), value);
		this.setProperty("value", valueString);
	}
	registerOnChange(fn) {
		this.onChange = (valueString) => {
			this.value = this._getOptionValue(valueString);
			fn(this.value);
		};
	}
	_registerOption() {
		return (this._idCounter++).toString();
	}
	_getOptionId(value) {
		for (const id of this._optionMap.keys()) if (this._compareWith(this._optionMap.get(id), value)) return id;
		return null;
	}
	_getOptionValue(valueString) {
		const id = _extractId$1(valueString);
		return this._optionMap.has(id) ? this._optionMap.get(id) : valueString;
	}
};
_SelectControlValueAccessor = SelectControlValueAccessor;
_defineProperty(SelectControlValueAccessor, "ɵfac", /* @__PURE__ */ (() => {
	let ɵSelectControlValueAccessor_BaseFactory;
	return function SelectControlValueAccessor_Factory(__ngFactoryType__) {
		return (ɵSelectControlValueAccessor_BaseFactory || (ɵSelectControlValueAccessor_BaseFactory = ɵɵgetInheritedFactory(_SelectControlValueAccessor)))(__ngFactoryType__ || _SelectControlValueAccessor);
	};
})());
_defineProperty(SelectControlValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _SelectControlValueAccessor,
	selectors: [
		[
			"select",
			"formControlName",
			"",
			3,
			"multiple",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"select",
			"formControl",
			"",
			3,
			"multiple",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"select",
			"ngModel",
			"",
			3,
			"multiple",
			"",
			3,
			"ngNoCva",
			""
		]
	],
	hostBindings: function SelectControlValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("change", function SelectControlValueAccessor_change_HostBindingHandler($event) {
			return ctx.onChange($event.target.value);
		})("blur", function SelectControlValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		});
	},
	inputs: { compareWith: "compareWith" },
	standalone: false,
	features: [ɵɵProvidersFeature([SELECT_VALUE_ACCESSOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectControlValueAccessor, [{
		type: Directive,
		args: [{
			selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
			host: {
				"(change)": "onChange($any($event.target).value)",
				"(blur)": "onTouched()"
			},
			providers: [SELECT_VALUE_ACCESSOR],
			standalone: false
		}]
	}], null, { compareWith: [{ type: Input }] });
})();
var NgSelectOption = class {
	constructor(_element, _renderer, _select) {
		_defineProperty(this, "_element", void 0);
		_defineProperty(this, "_renderer", void 0);
		_defineProperty(this, "_select", void 0);
		_defineProperty(this, "id", void 0);
		this._element = _element;
		this._renderer = _renderer;
		this._select = _select;
		if (this._select) this.id = this._select._registerOption();
	}
	set ngValue(value) {
		if (this._select == null) return;
		this._select._optionMap.set(this.id, value);
		this._setElementValue(_buildValueString$1(this.id, value));
		this._select._writeValueAfterRender();
	}
	set value(value) {
		var _this$_select;
		this._setElementValue(value);
		(_this$_select = this._select) === null || _this$_select === void 0 || _this$_select._writeValueAfterRender();
	}
	_setElementValue(value) {
		this._renderer.setProperty(this._element.nativeElement, "value", value);
	}
	ngOnDestroy() {
		var _this$_select2, _this$_select3;
		(_this$_select2 = this._select) === null || _this$_select2 === void 0 || _this$_select2._optionMap.delete(this.id);
		(_this$_select3 = this._select) === null || _this$_select3 === void 0 || _this$_select3._writeValueAfterRender();
	}
};
_NgSelectOption = NgSelectOption;
_defineProperty(NgSelectOption, "ɵfac", function NgSelectOption_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgSelectOption)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(SelectControlValueAccessor, 9));
});
_defineProperty(NgSelectOption, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgSelectOption,
	selectors: [["option"]],
	inputs: {
		ngValue: "ngValue",
		value: "value"
	},
	standalone: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgSelectOption, [{
		type: Directive,
		args: [{
			selector: "option",
			standalone: false
		}]
	}], () => [
		{ type: ElementRef },
		{ type: Renderer2 },
		{
			type: SelectControlValueAccessor,
			decorators: [{ type: Optional }, { type: Host }]
		}
	], {
		ngValue: [{
			type: Input,
			args: ["ngValue"]
		}],
		value: [{
			type: Input,
			args: ["value"]
		}]
	});
})();
var SELECT_MULTIPLE_VALUE_ACCESSOR = {
	provide: NG_VALUE_ACCESSOR,
	useExisting: forwardRef(() => SelectMultipleControlValueAccessor),
	multi: true
};
function _buildValueString(id, value) {
	if (id == null) return `${value}`;
	if (typeof value === "string") value = `'${value}'`;
	if (value && typeof value === "object") value = "Object";
	return `${id}: ${value}`.slice(0, 50);
}
function _extractId(valueString) {
	return valueString.split(":")[0];
}
var SelectMultipleControlValueAccessor = class extends BuiltInControlValueAccessor {
	constructor(..._args14) {
		super(..._args14);
		_defineProperty(this, "value", void 0);
		_defineProperty(this, "_optionMap", /* @__PURE__ */ new Map());
		_defineProperty(this, "_idCounter", 0);
		_defineProperty(this, "_compareWith", Object.is);
	}
	set compareWith(fn) {
		if (typeof fn !== "function" && (typeof ngDevMode === "undefined" || ngDevMode)) throw new RuntimeError(1201, `compareWith must be a function, but received ${JSON.stringify(fn)}`);
		this._compareWith = fn;
	}
	writeValue(value) {
		this.value = value;
		let optionSelectedStateSetter;
		if (Array.isArray(value)) {
			const ids = value.map((v) => this._getOptionId(v));
			optionSelectedStateSetter = (opt, id) => {
				opt._setSelected(ids.indexOf(id) > -1);
			};
		} else optionSelectedStateSetter = (opt) => {
			opt._setSelected(false);
		};
		this._optionMap.forEach(optionSelectedStateSetter);
	}
	registerOnChange(fn) {
		this.onChange = (element) => {
			const selected = [];
			const selectedOptions = element.selectedOptions;
			if (selectedOptions !== void 0) {
				const options = selectedOptions;
				for (let i = 0; i < options.length; i++) {
					const opt = options[i];
					const val = this._getOptionValue(opt.value);
					selected.push(val);
				}
			} else {
				const options = element.options;
				for (let i = 0; i < options.length; i++) {
					const opt = options[i];
					if (opt.selected) {
						const val = this._getOptionValue(opt.value);
						selected.push(val);
					}
				}
			}
			this.value = selected;
			fn(selected);
		};
	}
	_registerOption(value) {
		const id = (this._idCounter++).toString();
		this._optionMap.set(id, value);
		return id;
	}
	_getOptionId(value) {
		for (const id of this._optionMap.keys()) if (this._compareWith(this._optionMap.get(id)._value, value)) return id;
		return null;
	}
	_getOptionValue(valueString) {
		const id = _extractId(valueString);
		return this._optionMap.has(id) ? this._optionMap.get(id)._value : valueString;
	}
};
_SelectMultipleControlValueAccessor = SelectMultipleControlValueAccessor;
_defineProperty(SelectMultipleControlValueAccessor, "ɵfac", /* @__PURE__ */ (() => {
	let ɵSelectMultipleControlValueAccessor_BaseFactory;
	return function SelectMultipleControlValueAccessor_Factory(__ngFactoryType__) {
		return (ɵSelectMultipleControlValueAccessor_BaseFactory || (ɵSelectMultipleControlValueAccessor_BaseFactory = ɵɵgetInheritedFactory(_SelectMultipleControlValueAccessor)))(__ngFactoryType__ || _SelectMultipleControlValueAccessor);
	};
})());
_defineProperty(SelectMultipleControlValueAccessor, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _SelectMultipleControlValueAccessor,
	selectors: [
		[
			"select",
			"multiple",
			"",
			"formControlName",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"select",
			"multiple",
			"",
			"formControl",
			"",
			3,
			"ngNoCva",
			""
		],
		[
			"select",
			"multiple",
			"",
			"ngModel",
			"",
			3,
			"ngNoCva",
			""
		]
	],
	hostBindings: function SelectMultipleControlValueAccessor_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("change", function SelectMultipleControlValueAccessor_change_HostBindingHandler($event) {
			return ctx.onChange($event.target);
		})("blur", function SelectMultipleControlValueAccessor_blur_HostBindingHandler() {
			return ctx.onTouched();
		});
	},
	inputs: { compareWith: "compareWith" },
	standalone: false,
	features: [ɵɵProvidersFeature([SELECT_MULTIPLE_VALUE_ACCESSOR]), ɵɵInheritDefinitionFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectMultipleControlValueAccessor, [{
		type: Directive,
		args: [{
			selector: "select[multiple]:not([ngNoCva])[formControlName],select[multiple]:not([ngNoCva])[formControl],select[multiple]:not([ngNoCva])[ngModel]",
			host: {
				"(change)": "onChange($event.target)",
				"(blur)": "onTouched()"
			},
			providers: [SELECT_MULTIPLE_VALUE_ACCESSOR],
			standalone: false
		}]
	}], null, { compareWith: [{ type: Input }] });
})();
var ɵNgSelectMultipleOption = class {
	constructor(_element, _renderer, _select) {
		_defineProperty(this, "_element", void 0);
		_defineProperty(this, "_renderer", void 0);
		_defineProperty(this, "_select", void 0);
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "_value", void 0);
		this._element = _element;
		this._renderer = _renderer;
		this._select = _select;
		if (this._select) this.id = this._select._registerOption(this);
	}
	set ngValue(value) {
		if (this._select == null) return;
		this._value = value;
		this._setElementValue(_buildValueString(this.id, value));
		this._select.writeValue(this._select.value);
	}
	set value(value) {
		if (this._select) {
			this._value = value;
			this._setElementValue(_buildValueString(this.id, value));
			this._select.writeValue(this._select.value);
		} else this._setElementValue(value);
	}
	_setElementValue(value) {
		this._renderer.setProperty(this._element.nativeElement, "value", value);
	}
	_setSelected(selected) {
		this._renderer.setProperty(this._element.nativeElement, "selected", selected);
	}
	ngOnDestroy() {
		if (this._select) {
			this._select._optionMap.delete(this.id);
			this._select.writeValue(this._select.value);
		}
	}
};
_ɵNgSelectMultipleOption = ɵNgSelectMultipleOption;
_defineProperty(ɵNgSelectMultipleOption, "ɵfac", function ɵNgSelectMultipleOption_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ɵNgSelectMultipleOption)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(SelectMultipleControlValueAccessor, 9));
});
_defineProperty(ɵNgSelectMultipleOption, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _ɵNgSelectMultipleOption,
	selectors: [["option"]],
	inputs: {
		ngValue: "ngValue",
		value: "value"
	},
	standalone: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ɵNgSelectMultipleOption, [{
		type: Directive,
		args: [{
			selector: "option",
			standalone: false
		}]
	}], () => [
		{ type: ElementRef },
		{ type: Renderer2 },
		{
			type: SelectMultipleControlValueAccessor,
			decorators: [{ type: Optional }, { type: Host }]
		}
	], {
		ngValue: [{
			type: Input,
			args: ["ngValue"]
		}],
		value: [{
			type: Input,
			args: ["value"]
		}]
	});
})();
var SHARED_FORM_DIRECTIVES = [
	ɵNgNoValidate,
	NgSelectOption,
	ɵNgSelectMultipleOption,
	DefaultValueAccessor,
	NumberValueAccessor,
	RangeValueAccessor,
	CheckboxControlValueAccessor,
	SelectControlValueAccessor,
	SelectMultipleControlValueAccessor,
	RadioControlValueAccessor,
	NgControlStatus,
	NgControlStatusGroup,
	RequiredValidator,
	MinLengthValidator,
	MaxLengthValidator,
	PatternValidator,
	CheckboxRequiredValidator,
	EmailValidator,
	MinValidator,
	MaxValidator
];
var TEMPLATE_DRIVEN_DIRECTIVES = [
	NgModel,
	NgModelGroup,
	NgForm
];
var REACTIVE_DRIVEN_DIRECTIVES = [
	FormControlDirective,
	FormGroupDirective,
	FormArrayDirective,
	FormControlName,
	FormGroupName,
	FormArrayName
];
var ɵInternalFormsSharedModule = class {};
_ɵInternalFormsSharedModule = ɵInternalFormsSharedModule;
_defineProperty(ɵInternalFormsSharedModule, "ɵfac", function ɵInternalFormsSharedModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ɵInternalFormsSharedModule)();
});
_defineProperty(ɵInternalFormsSharedModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({
	type: _ɵInternalFormsSharedModule,
	declarations: [
		ɵNgNoValidate,
		NgSelectOption,
		ɵNgSelectMultipleOption,
		DefaultValueAccessor,
		NumberValueAccessor,
		RangeValueAccessor,
		CheckboxControlValueAccessor,
		SelectControlValueAccessor,
		SelectMultipleControlValueAccessor,
		RadioControlValueAccessor,
		NgControlStatus,
		NgControlStatusGroup,
		RequiredValidator,
		MinLengthValidator,
		MaxLengthValidator,
		PatternValidator,
		CheckboxRequiredValidator,
		EmailValidator,
		MinValidator,
		MaxValidator
	],
	exports: [
		ɵNgNoValidate,
		NgSelectOption,
		ɵNgSelectMultipleOption,
		DefaultValueAccessor,
		NumberValueAccessor,
		RangeValueAccessor,
		CheckboxControlValueAccessor,
		SelectControlValueAccessor,
		SelectMultipleControlValueAccessor,
		RadioControlValueAccessor,
		NgControlStatus,
		NgControlStatusGroup,
		RequiredValidator,
		MinLengthValidator,
		MaxLengthValidator,
		PatternValidator,
		CheckboxRequiredValidator,
		EmailValidator,
		MinValidator,
		MaxValidator
	]
}));
_defineProperty(ɵInternalFormsSharedModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ɵInternalFormsSharedModule, [{
		type: NgModule,
		args: [{
			declarations: SHARED_FORM_DIRECTIVES,
			exports: SHARED_FORM_DIRECTIVES
		}]
	}], null, null);
})();
function isAbstractControlOptions(options) {
	return !!options && (options.asyncValidators !== void 0 || options.validators !== void 0 || options.updateOn !== void 0);
}
var FormBuilder = class FormBuilder {
	constructor() {
		_defineProperty(this, "useNonNullable", false);
	}
	get nonNullable() {
		const nnfb = new FormBuilder();
		nnfb.useNonNullable = true;
		return nnfb;
	}
	group(controls, options = null) {
		const reducedControls = this._reduceControls(controls);
		let newOptions = {};
		if (isAbstractControlOptions(options)) newOptions = options;
		else if (options !== null) {
			newOptions.validators = options.validator;
			newOptions.asyncValidators = options.asyncValidator;
		}
		return new FormGroup(reducedControls, newOptions);
	}
	record(controls, options = null) {
		return new FormRecord(this._reduceControls(controls), options);
	}
	control(formState, validatorOrOpts, asyncValidator) {
		let newOptions = {};
		if (!this.useNonNullable) return new FormControl(formState, validatorOrOpts, asyncValidator);
		if (isAbstractControlOptions(validatorOrOpts)) newOptions = validatorOrOpts;
		else {
			newOptions.validators = validatorOrOpts;
			newOptions.asyncValidators = asyncValidator;
		}
		return new FormControl(formState, _objectSpread2(_objectSpread2({}, newOptions), {}, { nonNullable: true }));
	}
	array(controls, validatorOrOpts, asyncValidator) {
		return new FormArray(controls.map((c) => this._createControl(c)), validatorOrOpts, asyncValidator);
	}
	_reduceControls(controls) {
		const createdControls = {};
		Object.keys(controls).forEach((controlName) => {
			createdControls[controlName] = this._createControl(controls[controlName]);
		});
		return createdControls;
	}
	_createControl(controls) {
		if (controls instanceof FormControl) return controls;
		else if (controls instanceof AbstractControl) return controls;
		else if (Array.isArray(controls)) {
			const value = controls[0];
			const validator = controls.length > 1 ? controls[1] : null;
			const asyncValidator = controls.length > 2 ? controls[2] : null;
			return this.control(value, validator, asyncValidator);
		} else return this.control(controls);
	}
};
_FormBuilder = FormBuilder;
_defineProperty(FormBuilder, "ɵfac", function FormBuilder_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FormBuilder)();
});
_defineProperty(FormBuilder, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _FormBuilder,
	factory: _FormBuilder.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormBuilder, [{ type: Service }], null, null);
})();
var NonNullableFormBuilder = class {};
_NonNullableFormBuilder = NonNullableFormBuilder;
_defineProperty(NonNullableFormBuilder, "ɵfac", function NonNullableFormBuilder_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NonNullableFormBuilder)();
});
_defineProperty(NonNullableFormBuilder, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _NonNullableFormBuilder,
	factory: () => (() => inject(FormBuilder).nonNullable)()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NonNullableFormBuilder, [{
		type: Service,
		args: [{ factory: () => inject(FormBuilder).nonNullable }]
	}], null, null);
})();
var UntypedFormBuilder = class extends FormBuilder {
	group(controlsConfig, options = null) {
		return super.group(controlsConfig, options);
	}
	control(formState, validatorOrOpts, asyncValidator) {
		return super.control(formState, validatorOrOpts, asyncValidator);
	}
	array(controlsConfig, validatorOrOpts, asyncValidator) {
		return super.array(controlsConfig, validatorOrOpts, asyncValidator);
	}
};
_UntypedFormBuilder = UntypedFormBuilder;
_defineProperty(UntypedFormBuilder, "ɵfac", function UntypedFormBuilder_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _UntypedFormBuilder)();
});
_defineProperty(UntypedFormBuilder, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _UntypedFormBuilder,
	factory: _UntypedFormBuilder.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UntypedFormBuilder, [{ type: Service }], null, null);
})();
var FormsModule = class FormsModule {
	static withConfig(opts) {
		var _opts$callSetDisabled;
		return {
			ngModule: FormsModule,
			providers: [{
				provide: CALL_SET_DISABLED_STATE,
				useValue: (_opts$callSetDisabled = opts.callSetDisabledState) !== null && _opts$callSetDisabled !== void 0 ? _opts$callSetDisabled : setDisabledStateDefault
			}]
		};
	}
};
_FormsModule = FormsModule;
_defineProperty(FormsModule, "ɵfac", function FormsModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _FormsModule)();
});
_defineProperty(FormsModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({
	type: _FormsModule,
	declarations: [
		NgModel,
		NgModelGroup,
		NgForm
	],
	exports: [
		ɵInternalFormsSharedModule,
		NgModel,
		NgModelGroup,
		NgForm
	]
}));
_defineProperty(FormsModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({ imports: [ɵInternalFormsSharedModule] }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FormsModule, [{
		type: NgModule,
		args: [{
			declarations: TEMPLATE_DRIVEN_DIRECTIVES,
			exports: [ɵInternalFormsSharedModule, TEMPLATE_DRIVEN_DIRECTIVES]
		}]
	}], null, null);
})();
var ReactiveFormsModule = class ReactiveFormsModule {
	static withConfig(opts) {
		var _opts$warnOnNgModelWi, _opts$callSetDisabled2;
		return {
			ngModule: ReactiveFormsModule,
			providers: [{
				provide: NG_MODEL_WITH_FORM_CONTROL_WARNING,
				useValue: (_opts$warnOnNgModelWi = opts.warnOnNgModelWithFormControl) !== null && _opts$warnOnNgModelWi !== void 0 ? _opts$warnOnNgModelWi : "always"
			}, {
				provide: CALL_SET_DISABLED_STATE,
				useValue: (_opts$callSetDisabled2 = opts.callSetDisabledState) !== null && _opts$callSetDisabled2 !== void 0 ? _opts$callSetDisabled2 : setDisabledStateDefault
			}]
		};
	}
};
_ReactiveFormsModule = ReactiveFormsModule;
_defineProperty(ReactiveFormsModule, "ɵfac", function ReactiveFormsModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ReactiveFormsModule)();
});
_defineProperty(ReactiveFormsModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({
	type: _ReactiveFormsModule,
	declarations: [
		FormControlDirective,
		FormGroupDirective,
		FormArrayDirective,
		FormControlName,
		FormGroupName,
		FormArrayName
	],
	exports: [
		ɵInternalFormsSharedModule,
		FormControlDirective,
		FormGroupDirective,
		FormArrayDirective,
		FormControlName,
		FormGroupName,
		FormArrayName
	]
}));
_defineProperty(ReactiveFormsModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({ imports: [ɵInternalFormsSharedModule] }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReactiveFormsModule, [{
		type: NgModule,
		args: [{
			declarations: [REACTIVE_DRIVEN_DIRECTIVES],
			exports: [ɵInternalFormsSharedModule, REACTIVE_DRIVEN_DIRECTIVES]
		}]
	}], null, null);
})();
//#endregion
export { AbstractControl, AbstractControlDirective, AbstractFormDirective, AbstractFormGroupDirective, COMPOSITION_BUFFER_MODE, CheckboxControlValueAccessor, CheckboxRequiredValidator, ControlContainer, ControlEvent, DefaultValueAccessor, EmailValidator, FormArray, FormArrayDirective, FormArrayName, FormBuilder, FormControl, FormControlDirective, FormControlName, FormGroup, FormGroupDirective, FormGroupName, FormRecord, FormResetEvent, FormSubmittedEvent, FormsModule, MaxLengthValidator, MaxValidator, MinLengthValidator, MinValidator, NG_ASYNC_VALIDATORS, NG_VALIDATORS, NG_VALUE_ACCESSOR, NgControl, NgControlStatus, NgControlStatusGroup, NgForm, NgModel, NgModelGroup, NgSelectOption, NonNullableFormBuilder, NumberValueAccessor, PatternValidator, PristineChangeEvent, RadioControlValueAccessor, RangeValueAccessor, ReactiveFormsModule, RequiredValidator, SelectControlValueAccessor, SelectMultipleControlValueAccessor, StatusChangeEvent, TouchedChangeEvent, UntypedFormArray, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, VERSION, Validators, ValueChangeEvent, isFormArray, isFormControl, isFormGroup, isFormRecord, ɵFORM_CONTROL_INTEGRATION, ɵInternalFormsSharedModule, ɵNgNoValidate, ɵNgSelectMultipleOption, elementAcceptsMinMax as ɵelementAcceptsMinMax, isNativeFormElement as ɵisNativeFormElement, isTextualFormElement as ɵisTextualFormElement, selectValueAccessor as ɵselectValueAccessor, setNativeDomProperty as ɵsetNativeDomProperty };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGFuZ3VsYXJfZm9ybXMuanMiLCJuYW1lcyI6WyJCYXNlQ29udHJvbFZhbHVlQWNjZXNzb3IiLCJpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0IiwiaTAuUmVuZGVyZXIyIiwiaTAuRWxlbWVudFJlZiIsImkwLsm1c2V0Q2xhc3NNZXRhZGF0YSIsImkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5IiwiQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yIiwiaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZSIsIkNoZWNrYm94Q29udHJvbFZhbHVlQWNjZXNzb3IiLCJpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZSIsIl9nZXRET00iLCJEZWZhdWx0VmFsdWVBY2Nlc3NvciIsIl9pc1Byb21pc2UiLCJfaXNTdWJzY3JpYmFibGUiLCJfUnVudGltZUVycm9yIiwiQWJzdHJhY3RWYWxpZGF0b3JEaXJlY3RpdmUiLCJpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlIiwiTWF4VmFsaWRhdG9yIiwiTWluVmFsaWRhdG9yIiwiUmVxdWlyZWRWYWxpZGF0b3IiLCJDaGVja2JveFJlcXVpcmVkVmFsaWRhdG9yIiwiRW1haWxWYWxpZGF0b3IiLCJNaW5MZW5ndGhWYWxpZGF0b3IiLCJNYXhMZW5ndGhWYWxpZGF0b3IiLCJQYXR0ZXJuVmFsaWRhdG9yIiwiTmdDb250cm9sU3RhdHVzIiwiTmdDb250cm9sU3RhdHVzR3JvdXAiLCJOZ0Zvcm0iLCJBYnN0cmFjdEZvcm1Hcm91cERpcmVjdGl2ZSIsIk5nTW9kZWxHcm91cCIsIk5nTW9kZWwiLCJpMC5JbmplY3RvciIsImkwLsm1ybVDb250cm9sRmVhdHVyZSIsImkwLkNoYW5nZURldGVjdG9yUmVmIiwiybVOZ05vVmFsaWRhdGUiLCJOdW1iZXJWYWx1ZUFjY2Vzc29yIiwiUmFkaW9Db250cm9sUmVnaXN0cnkiLCJSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yIiwiUmFuZ2VWYWx1ZUFjY2Vzc29yIiwiQWJzdHJhY3RGb3JtRGlyZWN0aXZlIiwiRm9ybUFycmF5RGlyZWN0aXZlIiwiRm9ybUNvbnRyb2xEaXJlY3RpdmUiLCJGb3JtR3JvdXBOYW1lIiwiRm9ybUFycmF5TmFtZSIsIkZvcm1Db250cm9sTmFtZSIsIkZvcm1Hcm91cERpcmVjdGl2ZSIsIlNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yIiwiTmdTZWxlY3RPcHRpb24iLCJTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yIiwiybVOZ1NlbGVjdE11bHRpcGxlT3B0aW9uIiwiybVJbnRlcm5hbEZvcm1zU2hhcmVkTW9kdWxlIiwiRm9ybUJ1aWxkZXIiLCJOb25OdWxsYWJsZUZvcm1CdWlsZGVyIiwiVW50eXBlZEZvcm1CdWlsZGVyIiwiRm9ybXNNb2R1bGUiLCJSZWFjdGl2ZUZvcm1zTW9kdWxlIl0sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0Bhbmd1bGFyL2Zvcm1zL2Zlc20yMDIyL2Zvcm1zLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjIyLjEuMlxuICogKGMpIDIwMTAtMjAyNiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuZGV2L1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0ICogYXMgaTAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJbmplY3Rpb25Ub2tlbiwgRGlyZWN0aXZlLCBmb3J3YXJkUmVmLCBPcHRpb25hbCwgSW5qZWN0LCDJtWlzUHJvbWlzZSBhcyBfaXNQcm9taXNlLCDJtWlzU3Vic2NyaWJhYmxlIGFzIF9pc1N1YnNjcmliYWJsZSwgybVSdW50aW1lRXJyb3IgYXMgX1J1bnRpbWVFcnJvciwgVmVyc2lvbiwgc2lnbmFsLCB1bnRyYWNrZWQsIGNvbXB1dGVkLCBFdmVudEVtaXR0ZXIsIGJvb2xlYW5BdHRyaWJ1dGUsIElucHV0LCBEZXN0cm95UmVmLCBDaGFuZ2VEZXRlY3RvclJlZiwgZWZmZWN0LCBpbmplY3QsIFNlbGYsIEhvc3QsIFNraXBTZWxmLCBPdXRwdXQsIFNlcnZpY2UsIEFwcGxpY2F0aW9uUmVmLCBhZnRlck5leHRSZW5kZXIsIE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmcm9tLCBmb3JrSm9pbiwgU3ViamVjdCwgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyDJtWdldERPTSBhcyBfZ2V0RE9NIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmNsYXNzIEJhc2VDb250cm9sVmFsdWVBY2Nlc3NvciB7XG4gIF9yZW5kZXJlcjtcbiAgX2VsZW1lbnRSZWY7XG4gIG9uQ2hhbmdlID0gXyA9PiB7fTtcbiAgb25Ub3VjaGVkID0gKCkgPT4ge307XG4gIGNvbnN0cnVjdG9yKF9yZW5kZXJlciwgX2VsZW1lbnRSZWYpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IF9yZW5kZXJlcjtcbiAgICB0aGlzLl9lbGVtZW50UmVmID0gX2VsZW1lbnRSZWY7XG4gIH1cbiAgc2V0UHJvcGVydHkoa2V5LCB2YWx1ZSkge1xuICAgIHRoaXMuX3JlbmRlcmVyLnNldFByb3BlcnR5KHRoaXMuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwga2V5LCB2YWx1ZSk7XG4gIH1cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm4pIHtcbiAgICB0aGlzLm9uVG91Y2hlZCA9IGZuO1xuICB9XG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm4pIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gIH1cbiAgc2V0RGlzYWJsZWRTdGF0ZShpc0Rpc2FibGVkKSB7XG4gICAgdGhpcy5zZXRQcm9wZXJ0eSgnZGlzYWJsZWQnLCBpc0Rpc2FibGVkKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBCYXNlQ29udHJvbFZhbHVlQWNjZXNzb3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBCYXNlQ29udHJvbFZhbHVlQWNjZXNzb3IpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuUmVuZGVyZXIyKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5FbGVtZW50UmVmKSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IEJhc2VDb250cm9sVmFsdWVBY2Nlc3NvclxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEJhc2VDb250cm9sVmFsdWVBY2Nlc3NvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuUmVuZGVyZXIyXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5FbGVtZW50UmVmXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBCdWlsdEluQ29udHJvbFZhbHVlQWNjZXNzb3IgZXh0ZW5kcyBCYXNlQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtUJ1aWx0SW5Db250cm9sVmFsdWVBY2Nlc3Nvcl9CYXNlRmFjdG9yeTtcbiAgICByZXR1cm4gZnVuY3Rpb24gQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVCdWlsdEluQ29udHJvbFZhbHVlQWNjZXNzb3JfQmFzZUZhY3RvcnkgfHwgKMm1QnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5ID0gaTAuybXJtWdldEluaGVyaXRlZEZhY3RvcnkoQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yKSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEJ1aWx0SW5Db250cm9sVmFsdWVBY2Nlc3Nvcik7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShCdWlsdEluQ29udHJvbFZhbHVlQWNjZXNzb3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jb25zdCBOR19WQUxVRV9BQ0NFU1NPUiA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnTmdWYWx1ZUFjY2Vzc29yJyA6ICcnKTtcbmNvbnN0IENIRUNLQk9YX1ZBTFVFX0FDQ0VTU09SID0ge1xuICBwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3NvciksXG4gIG11bHRpOiB0cnVlXG59O1xuY2xhc3MgQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3NvciBleHRlbmRzIEJ1aWx0SW5Db250cm9sVmFsdWVBY2Nlc3NvciB7XG4gIHdyaXRlVmFsdWUodmFsdWUpIHtcbiAgICB0aGlzLnNldFByb3BlcnR5KCdjaGVja2VkJywgdmFsdWUpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IC8qIEBfX1BVUkVfXyAqLygoKSA9PiB7XG4gICAgbGV0IMm1Q2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3Nvcl9CYXNlRmFjdG9yeTtcbiAgICByZXR1cm4gZnVuY3Rpb24gQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3Nvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICByZXR1cm4gKMm1Q2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3Nvcl9CYXNlRmFjdG9yeSB8fCAoybVDaGVja2JveENvbnRyb2xWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5ID0gaTAuybXJtWdldEluaGVyaXRlZEZhY3RvcnkoQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3NvcikpKShfX25nRmFjdG9yeVR5cGVfXyB8fCBDaGVja2JveENvbnRyb2xWYWx1ZUFjY2Vzc29yKTtcbiAgICB9O1xuICB9KSgpO1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBDaGVja2JveENvbnRyb2xWYWx1ZUFjY2Vzc29yLFxuICAgIHNlbGVjdG9yczogW1tcImlucHV0XCIsIFwidHlwZVwiLCBcImNoZWNrYm94XCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXSwgW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwiY2hlY2tib3hcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiLCAzLCBcIm5nTm9DdmFcIiwgXCJcIl0sIFtcImlucHV0XCIsIFwidHlwZVwiLCBcImNoZWNrYm94XCIsIFwibmdNb2RlbFwiLCBcIlwiLCAzLCBcIm5nTm9DdmFcIiwgXCJcIl1dLFxuICAgIGhvc3RCaW5kaW5nczogZnVuY3Rpb24gQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3Nvcl9Ib3N0QmluZGluZ3MocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1bGlzdGVuZXIoXCJjaGFuZ2VcIiwgZnVuY3Rpb24gQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3Nvcl9jaGFuZ2VfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25DaGFuZ2UoJGV2ZW50LnRhcmdldC5jaGVja2VkKTtcbiAgICAgICAgfSkoXCJibHVyXCIsIGZ1bmN0aW9uIENoZWNrYm94Q29udHJvbFZhbHVlQWNjZXNzb3JfYmx1cl9Ib3N0QmluZGluZ0hhbmRsZXIoKSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vblRvdWNoZWQoKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtDSEVDS0JPWF9WQUxVRV9BQ0NFU1NPUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKENoZWNrYm94Q29udHJvbFZhbHVlQWNjZXNzb3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ2lucHV0W3R5cGU9Y2hlY2tib3hdOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sTmFtZV0saW5wdXRbdHlwZT1jaGVja2JveF06bm90KFtuZ05vQ3ZhXSlbZm9ybUNvbnRyb2xdLGlucHV0W3R5cGU9Y2hlY2tib3hdOm5vdChbbmdOb0N2YV0pW25nTW9kZWxdJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJyhjaGFuZ2UpJzogJ29uQ2hhbmdlKCRhbnkoJGV2ZW50LnRhcmdldCkuY2hlY2tlZCknLFxuICAgICAgICAnKGJsdXIpJzogJ29uVG91Y2hlZCgpJ1xuICAgICAgfSxcbiAgICAgIHByb3ZpZGVyczogW0NIRUNLQk9YX1ZBTFVFX0FDQ0VTU09SXSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNvbnN0IERFRkFVTFRfVkFMVUVfQUNDRVNTT1IgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBEZWZhdWx0VmFsdWVBY2Nlc3NvciksXG4gIG11bHRpOiB0cnVlXG59O1xuZnVuY3Rpb24gX2lzQW5kcm9pZCgpIHtcbiAgY29uc3QgdXNlckFnZW50ID0gX2dldERPTSgpID8gX2dldERPTSgpLmdldFVzZXJBZ2VudCgpIDogJyc7XG4gIHJldHVybiAvYW5kcm9pZCAoXFxkKykvLnRlc3QodXNlckFnZW50LnRvTG93ZXJDYXNlKCkpO1xufVxuY29uc3QgQ09NUE9TSVRJT05fQlVGRkVSX01PREUgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ0NvbXBvc2l0aW9uRXZlbnRNb2RlJyA6ICcnKTtcbmNsYXNzIERlZmF1bHRWYWx1ZUFjY2Vzc29yIGV4dGVuZHMgQmFzZUNvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgX2NvbXBvc2l0aW9uTW9kZTtcbiAgX2NvbXBvc2luZyA9IGZhbHNlO1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlciwgZWxlbWVudFJlZiwgX2NvbXBvc2l0aW9uTW9kZSkge1xuICAgIHN1cGVyKHJlbmRlcmVyLCBlbGVtZW50UmVmKTtcbiAgICB0aGlzLl9jb21wb3NpdGlvbk1vZGUgPSBfY29tcG9zaXRpb25Nb2RlO1xuICAgIGlmICh0aGlzLl9jb21wb3NpdGlvbk1vZGUgPT0gbnVsbCkge1xuICAgICAgdGhpcy5fY29tcG9zaXRpb25Nb2RlID0gIV9pc0FuZHJvaWQoKTtcbiAgICB9XG4gIH1cbiAgd3JpdGVWYWx1ZSh2YWx1ZSkge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRWYWx1ZSA9IHZhbHVlID09IG51bGwgPyAnJyA6IHZhbHVlO1xuICAgIHRoaXMuc2V0UHJvcGVydHkoJ3ZhbHVlJywgbm9ybWFsaXplZFZhbHVlKTtcbiAgfVxuICBfaGFuZGxlSW5wdXQodmFsdWUpIHtcbiAgICBpZiAoIXRoaXMuX2NvbXBvc2l0aW9uTW9kZSB8fCB0aGlzLl9jb21wb3NpdGlvbk1vZGUgJiYgIXRoaXMuX2NvbXBvc2luZykge1xuICAgICAgdGhpcy5vbkNoYW5nZSh2YWx1ZSk7XG4gICAgfVxuICB9XG4gIF9jb21wb3NpdGlvblN0YXJ0KCkge1xuICAgIHRoaXMuX2NvbXBvc2luZyA9IHRydWU7XG4gIH1cbiAgX2NvbXBvc2l0aW9uRW5kKHZhbHVlKSB7XG4gICAgdGhpcy5fY29tcG9zaW5nID0gZmFsc2U7XG4gICAgdGhpcy5fY29tcG9zaXRpb25Nb2RlICYmIHRoaXMub25DaGFuZ2UodmFsdWUpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIERlZmF1bHRWYWx1ZUFjY2Vzc29yX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRGVmYXVsdFZhbHVlQWNjZXNzb3IpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuUmVuZGVyZXIyKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5FbGVtZW50UmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChDT01QT1NJVElPTl9CVUZGRVJfTU9ERSwgOCkpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBEZWZhdWx0VmFsdWVBY2Nlc3NvcixcbiAgICBzZWxlY3RvcnM6IFtbXCJpbnB1dFwiLCBcImZvcm1Db250cm9sTmFtZVwiLCBcIlwiLCAzLCBcInR5cGVcIiwgXCJjaGVja2JveFwiLCAzLCBcIm5nTm9DdmFcIiwgXCJcIl0sIFtcInRleHRhcmVhXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXSwgW1wiaW5wdXRcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiLCAzLCBcInR5cGVcIiwgXCJjaGVja2JveFwiLCAzLCBcIm5nTm9DdmFcIiwgXCJcIl0sIFtcInRleHRhcmVhXCIsIFwiZm9ybUNvbnRyb2xcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcIm5nTW9kZWxcIiwgXCJcIiwgMywgXCJ0eXBlXCIsIFwiY2hlY2tib3hcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJ0ZXh0YXJlYVwiLCBcIm5nTW9kZWxcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJcIiwgXCJuZ0RlZmF1bHRDb250cm9sXCIsIFwiXCJdXSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIERlZmF1bHRWYWx1ZUFjY2Vzc29yX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcImlucHV0XCIsIGZ1bmN0aW9uIERlZmF1bHRWYWx1ZUFjY2Vzc29yX2lucHV0X0hvc3RCaW5kaW5nSGFuZGxlcigkZXZlbnQpIHtcbiAgICAgICAgICByZXR1cm4gY3R4Ll9oYW5kbGVJbnB1dCgkZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgfSkoXCJibHVyXCIsIGZ1bmN0aW9uIERlZmF1bHRWYWx1ZUFjY2Vzc29yX2JsdXJfSG9zdEJpbmRpbmdIYW5kbGVyKCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25Ub3VjaGVkKCk7XG4gICAgICAgIH0pKFwiY29tcG9zaXRpb25zdGFydFwiLCBmdW5jdGlvbiBEZWZhdWx0VmFsdWVBY2Nlc3Nvcl9jb21wb3NpdGlvbnN0YXJ0X0hvc3RCaW5kaW5nSGFuZGxlcigpIHtcbiAgICAgICAgICByZXR1cm4gY3R4Ll9jb21wb3NpdGlvblN0YXJ0KCk7XG4gICAgICAgIH0pKFwiY29tcG9zaXRpb25lbmRcIiwgZnVuY3Rpb24gRGVmYXVsdFZhbHVlQWNjZXNzb3JfY29tcG9zaXRpb25lbmRfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHguX2NvbXBvc2l0aW9uRW5kKCRldmVudC50YXJnZXQudmFsdWUpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW0RFRkFVTFRfVkFMVUVfQUNDRVNTT1JdKSwgaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShEZWZhdWx0VmFsdWVBY2Nlc3NvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnaW5wdXQ6bm90KFt0eXBlPWNoZWNrYm94XSk6bm90KFtuZ05vQ3ZhXSlbZm9ybUNvbnRyb2xOYW1lXSx0ZXh0YXJlYTpub3QoW25nTm9DdmFdKVtmb3JtQ29udHJvbE5hbWVdLGlucHV0Om5vdChbdHlwZT1jaGVja2JveF0pOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sXSx0ZXh0YXJlYTpub3QoW25nTm9DdmFdKVtmb3JtQ29udHJvbF0saW5wdXQ6bm90KFt0eXBlPWNoZWNrYm94XSk6bm90KFtuZ05vQ3ZhXSlbbmdNb2RlbF0sdGV4dGFyZWE6bm90KFtuZ05vQ3ZhXSlbbmdNb2RlbF0sW25nRGVmYXVsdENvbnRyb2xdJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJyhpbnB1dCknOiAnX2hhbmRsZUlucHV0KCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpJyxcbiAgICAgICAgJyhibHVyKSc6ICdvblRvdWNoZWQoKScsXG4gICAgICAgICcoY29tcG9zaXRpb25zdGFydCknOiAnX2NvbXBvc2l0aW9uU3RhcnQoKScsXG4gICAgICAgICcoY29tcG9zaXRpb25lbmQpJzogJ19jb21wb3NpdGlvbkVuZCgkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKSdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcnM6IFtERUZBVUxUX1ZBTFVFX0FDQ0VTU09SXSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuUmVuZGVyZXIyXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5FbGVtZW50UmVmXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0NPTVBPU0lUSU9OX0JVRkZFUl9NT0RFXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBpc0VtcHR5SW5wdXRWYWx1ZSh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgPT0gbnVsbCB8fCBsZW5ndGhPclNpemUodmFsdWUpID09PSAwO1xufVxuZnVuY3Rpb24gbGVuZ3RoT3JTaXplKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiB2YWx1ZS5sZW5ndGg7XG4gIH0gZWxzZSBpZiAodmFsdWUgaW5zdGFuY2VvZiBTZXQpIHtcbiAgICByZXR1cm4gdmFsdWUuc2l6ZTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmNvbnN0IE5HX1ZBTElEQVRPUlMgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ05nVmFsaWRhdG9ycycgOiAnJyk7XG5jb25zdCBOR19BU1lOQ19WQUxJREFUT1JTID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdOZ0FzeW5jVmFsaWRhdG9ycycgOiAnJyk7XG5jb25zdCBFTUFJTF9SRUdFWFAgPSAvXig/PS57MSwyNTR9JCkoPz0uezEsNjR9QClbYS16QS1aMC05ISMkJSYnKisvPT9eX2B7fH1+LV0rKD86XFwuW2EtekEtWjAtOSEjJCUmJyorLz0/Xl9ge3x9fi1dKykqQFthLXpBLVowLTldKD86W2EtekEtWjAtOS1dezAsNjF9W2EtekEtWjAtOV0pPyg/OlxcLlthLXpBLVowLTldKD86W2EtekEtWjAtOS1dezAsNjF9W2EtekEtWjAtOV0pPykqJC87XG5jbGFzcyBWYWxpZGF0b3JzIHtcbiAgc3RhdGljIG1pbihtaW4pIHtcbiAgICByZXR1cm4gbWluVmFsaWRhdG9yKG1pbik7XG4gIH1cbiAgc3RhdGljIG1heChtYXgpIHtcbiAgICByZXR1cm4gbWF4VmFsaWRhdG9yKG1heCk7XG4gIH1cbiAgc3RhdGljIHJlcXVpcmVkKGNvbnRyb2wpIHtcbiAgICByZXR1cm4gcmVxdWlyZWRWYWxpZGF0b3IoY29udHJvbCk7XG4gIH1cbiAgc3RhdGljIHJlcXVpcmVkVHJ1ZShjb250cm9sKSB7XG4gICAgcmV0dXJuIHJlcXVpcmVkVHJ1ZVZhbGlkYXRvcihjb250cm9sKTtcbiAgfVxuICBzdGF0aWMgZW1haWwoY29udHJvbCkge1xuICAgIHJldHVybiBlbWFpbFZhbGlkYXRvcihjb250cm9sKTtcbiAgfVxuICBzdGF0aWMgbWluTGVuZ3RoKG1pbkxlbmd0aCkge1xuICAgIHJldHVybiBtaW5MZW5ndGhWYWxpZGF0b3IobWluTGVuZ3RoKTtcbiAgfVxuICBzdGF0aWMgbWF4TGVuZ3RoKG1heExlbmd0aCkge1xuICAgIHJldHVybiBtYXhMZW5ndGhWYWxpZGF0b3IobWF4TGVuZ3RoKTtcbiAgfVxuICBzdGF0aWMgcGF0dGVybihwYXR0ZXJuKSB7XG4gICAgcmV0dXJuIHBhdHRlcm5WYWxpZGF0b3IocGF0dGVybik7XG4gIH1cbiAgc3RhdGljIG51bGxWYWxpZGF0b3IoY29udHJvbCkge1xuICAgIHJldHVybiBudWxsVmFsaWRhdG9yKCk7XG4gIH1cbiAgc3RhdGljIGNvbXBvc2UodmFsaWRhdG9ycykge1xuICAgIHJldHVybiBjb21wb3NlKHZhbGlkYXRvcnMpO1xuICB9XG4gIHN0YXRpYyBjb21wb3NlQXN5bmModmFsaWRhdG9ycykge1xuICAgIHJldHVybiBjb21wb3NlQXN5bmModmFsaWRhdG9ycyk7XG4gIH1cbn1cbmZ1bmN0aW9uIG1pblZhbGlkYXRvcihtaW4pIHtcbiAgcmV0dXJuIGNvbnRyb2wgPT4ge1xuICAgIGlmIChjb250cm9sLnZhbHVlID09IG51bGwgfHwgbWluID09IG51bGwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IHBhcnNlRmxvYXQoY29udHJvbC52YWx1ZSk7XG4gICAgcmV0dXJuICFpc05hTih2YWx1ZSkgJiYgdmFsdWUgPCBtaW4gPyB7XG4gICAgICAnbWluJzoge1xuICAgICAgICAnbWluJzogbWluLFxuICAgICAgICAnYWN0dWFsJzogY29udHJvbC52YWx1ZVxuICAgICAgfVxuICAgIH0gOiBudWxsO1xuICB9O1xufVxuZnVuY3Rpb24gbWF4VmFsaWRhdG9yKG1heCkge1xuICByZXR1cm4gY29udHJvbCA9PiB7XG4gICAgaWYgKGNvbnRyb2wudmFsdWUgPT0gbnVsbCB8fCBtYXggPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlID0gcGFyc2VGbG9hdChjb250cm9sLnZhbHVlKTtcbiAgICByZXR1cm4gIWlzTmFOKHZhbHVlKSAmJiB2YWx1ZSA+IG1heCA/IHtcbiAgICAgICdtYXgnOiB7XG4gICAgICAgICdtYXgnOiBtYXgsXG4gICAgICAgICdhY3R1YWwnOiBjb250cm9sLnZhbHVlXG4gICAgICB9XG4gICAgfSA6IG51bGw7XG4gIH07XG59XG5mdW5jdGlvbiByZXF1aXJlZFZhbGlkYXRvcihjb250cm9sKSB7XG4gIHJldHVybiBpc0VtcHR5SW5wdXRWYWx1ZShjb250cm9sLnZhbHVlKSA/IHtcbiAgICAncmVxdWlyZWQnOiB0cnVlXG4gIH0gOiBudWxsO1xufVxuZnVuY3Rpb24gcmVxdWlyZWRUcnVlVmFsaWRhdG9yKGNvbnRyb2wpIHtcbiAgcmV0dXJuIGNvbnRyb2wudmFsdWUgPT09IHRydWUgPyBudWxsIDoge1xuICAgICdyZXF1aXJlZCc6IHRydWVcbiAgfTtcbn1cbmZ1bmN0aW9uIGVtYWlsVmFsaWRhdG9yKGNvbnRyb2wpIHtcbiAgaWYgKGlzRW1wdHlJbnB1dFZhbHVlKGNvbnRyb2wudmFsdWUpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgcmV0dXJuIEVNQUlMX1JFR0VYUC50ZXN0KGNvbnRyb2wudmFsdWUpID8gbnVsbCA6IHtcbiAgICAnZW1haWwnOiB0cnVlXG4gIH07XG59XG5mdW5jdGlvbiBtaW5MZW5ndGhWYWxpZGF0b3IobWluTGVuZ3RoKSB7XG4gIHJldHVybiBjb250cm9sID0+IHtcbiAgICBjb25zdCBsZW5ndGggPSBjb250cm9sLnZhbHVlPy5sZW5ndGggPz8gbGVuZ3RoT3JTaXplKGNvbnRyb2wudmFsdWUpO1xuICAgIGlmIChsZW5ndGggPT09IG51bGwgfHwgbGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIGxlbmd0aCA8IG1pbkxlbmd0aCA/IHtcbiAgICAgICdtaW5sZW5ndGgnOiB7XG4gICAgICAgICdyZXF1aXJlZExlbmd0aCc6IG1pbkxlbmd0aCxcbiAgICAgICAgJ2FjdHVhbExlbmd0aCc6IGxlbmd0aFxuICAgICAgfVxuICAgIH0gOiBudWxsO1xuICB9O1xufVxuZnVuY3Rpb24gbWF4TGVuZ3RoVmFsaWRhdG9yKG1heExlbmd0aCkge1xuICByZXR1cm4gY29udHJvbCA9PiB7XG4gICAgY29uc3QgbGVuZ3RoID0gY29udHJvbC52YWx1ZT8ubGVuZ3RoID8/IGxlbmd0aE9yU2l6ZShjb250cm9sLnZhbHVlKTtcbiAgICBpZiAobGVuZ3RoICE9PSBudWxsICYmIGxlbmd0aCA+IG1heExlbmd0aCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgJ21heGxlbmd0aCc6IHtcbiAgICAgICAgICAncmVxdWlyZWRMZW5ndGgnOiBtYXhMZW5ndGgsXG4gICAgICAgICAgJ2FjdHVhbExlbmd0aCc6IGxlbmd0aFxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcbn1cbmZ1bmN0aW9uIHBhdHRlcm5WYWxpZGF0b3IocGF0dGVybikge1xuICBpZiAoIXBhdHRlcm4pIHJldHVybiBudWxsVmFsaWRhdG9yO1xuICBsZXQgcmVnZXg7XG4gIGxldCByZWdleFN0cjtcbiAgaWYgKHR5cGVvZiBwYXR0ZXJuID09PSAnc3RyaW5nJykge1xuICAgIHJlZ2V4U3RyID0gJyc7XG4gICAgaWYgKHBhdHRlcm4uY2hhckF0KDApICE9PSAnXicpIHJlZ2V4U3RyICs9ICdeJztcbiAgICByZWdleFN0ciArPSBwYXR0ZXJuO1xuICAgIGlmIChwYXR0ZXJuLmNoYXJBdChwYXR0ZXJuLmxlbmd0aCAtIDEpICE9PSAnJCcpIHJlZ2V4U3RyICs9ICckJztcbiAgICByZWdleCA9IG5ldyBSZWdFeHAocmVnZXhTdHIpO1xuICB9IGVsc2Uge1xuICAgIHJlZ2V4U3RyID0gcGF0dGVybi50b1N0cmluZygpO1xuICAgIHJlZ2V4ID0gcGF0dGVybjtcbiAgfVxuICByZXR1cm4gY29udHJvbCA9PiB7XG4gICAgaWYgKGlzRW1wdHlJbnB1dFZhbHVlKGNvbnRyb2wudmFsdWUpKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgdmFsdWUgPSBjb250cm9sLnZhbHVlO1xuICAgIHJldHVybiByZWdleC50ZXN0KHZhbHVlKSA/IG51bGwgOiB7XG4gICAgICAncGF0dGVybic6IHtcbiAgICAgICAgJ3JlcXVpcmVkUGF0dGVybic6IHJlZ2V4U3RyLFxuICAgICAgICAnYWN0dWFsVmFsdWUnOiB2YWx1ZVxuICAgICAgfVxuICAgIH07XG4gIH07XG59XG5mdW5jdGlvbiBudWxsVmFsaWRhdG9yKGNvbnRyb2wpIHtcbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBpc1ByZXNlbnQobykge1xuICByZXR1cm4gbyAhPSBudWxsO1xufVxuZnVuY3Rpb24gdG9PYnNlcnZhYmxlKHZhbHVlKSB7XG4gIGNvbnN0IG9icyA9IF9pc1Byb21pc2UodmFsdWUpID8gZnJvbSh2YWx1ZSkgOiB2YWx1ZTtcbiAgaWYgKCh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICFfaXNTdWJzY3JpYmFibGUob2JzKSkge1xuICAgIGxldCBlcnJvck1lc3NhZ2UgPSBgRXhwZWN0ZWQgYXN5bmMgdmFsaWRhdG9yIHRvIHJldHVybiBQcm9taXNlIG9yIE9ic2VydmFibGUuYDtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgICAgZXJyb3JNZXNzYWdlICs9ICcgQXJlIHlvdSB1c2luZyBhIHN5bmNocm9ub3VzIHZhbGlkYXRvciB3aGVyZSBhbiBhc3luYyB2YWxpZGF0b3IgaXMgZXhwZWN0ZWQ/JztcbiAgICB9XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoLTExMDEsIGVycm9yTWVzc2FnZSk7XG4gIH1cbiAgcmV0dXJuIG9icztcbn1cbmZ1bmN0aW9uIG1lcmdlRXJyb3JzKGFycmF5T2ZFcnJvcnMpIHtcbiAgbGV0IHJlcyA9IHt9O1xuICBhcnJheU9mRXJyb3JzLmZvckVhY2goZXJyb3JzID0+IHtcbiAgICByZXMgPSBlcnJvcnMgIT0gbnVsbCA/IHtcbiAgICAgIC4uLnJlcyxcbiAgICAgIC4uLmVycm9yc1xuICAgIH0gOiByZXM7XG4gIH0pO1xuICByZXR1cm4gT2JqZWN0LmtleXMocmVzKS5sZW5ndGggPT09IDAgPyBudWxsIDogcmVzO1xufVxuZnVuY3Rpb24gZXhlY3V0ZVZhbGlkYXRvcnMoY29udHJvbCwgdmFsaWRhdG9ycykge1xuICByZXR1cm4gdmFsaWRhdG9ycy5tYXAodmFsaWRhdG9yID0+IHZhbGlkYXRvcihjb250cm9sKSk7XG59XG5mdW5jdGlvbiBpc1ZhbGlkYXRvckZuKHZhbGlkYXRvcikge1xuICByZXR1cm4gIXZhbGlkYXRvci52YWxpZGF0ZTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVZhbGlkYXRvcnModmFsaWRhdG9ycykge1xuICByZXR1cm4gdmFsaWRhdG9ycy5tYXAodmFsaWRhdG9yID0+IHtcbiAgICByZXR1cm4gaXNWYWxpZGF0b3JGbih2YWxpZGF0b3IpID8gdmFsaWRhdG9yIDogYyA9PiB2YWxpZGF0b3IudmFsaWRhdGUoYyk7XG4gIH0pO1xufVxuZnVuY3Rpb24gY29tcG9zZSh2YWxpZGF0b3JzKSB7XG4gIGlmICghdmFsaWRhdG9ycykgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHByZXNlbnRWYWxpZGF0b3JzID0gdmFsaWRhdG9ycy5maWx0ZXIoaXNQcmVzZW50KTtcbiAgaWYgKHByZXNlbnRWYWxpZGF0b3JzLmxlbmd0aCA9PSAwKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGZ1bmN0aW9uIChjb250cm9sKSB7XG4gICAgcmV0dXJuIG1lcmdlRXJyb3JzKGV4ZWN1dGVWYWxpZGF0b3JzKGNvbnRyb2wsIHByZXNlbnRWYWxpZGF0b3JzKSk7XG4gIH07XG59XG5mdW5jdGlvbiBjb21wb3NlVmFsaWRhdG9ycyh2YWxpZGF0b3JzKSB7XG4gIHJldHVybiB2YWxpZGF0b3JzICE9IG51bGwgPyBjb21wb3NlKG5vcm1hbGl6ZVZhbGlkYXRvcnModmFsaWRhdG9ycykpIDogbnVsbDtcbn1cbmZ1bmN0aW9uIGNvbXBvc2VBc3luYyh2YWxpZGF0b3JzKSB7XG4gIGlmICghdmFsaWRhdG9ycykgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHByZXNlbnRWYWxpZGF0b3JzID0gdmFsaWRhdG9ycy5maWx0ZXIoaXNQcmVzZW50KTtcbiAgaWYgKHByZXNlbnRWYWxpZGF0b3JzLmxlbmd0aCA9PSAwKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGZ1bmN0aW9uIChjb250cm9sKSB7XG4gICAgY29uc3Qgb2JzZXJ2YWJsZXMgPSBleGVjdXRlVmFsaWRhdG9ycyhjb250cm9sLCBwcmVzZW50VmFsaWRhdG9ycykubWFwKHRvT2JzZXJ2YWJsZSk7XG4gICAgcmV0dXJuIGZvcmtKb2luKG9ic2VydmFibGVzKS5waXBlKG1hcChtZXJnZUVycm9ycykpO1xuICB9O1xufVxuZnVuY3Rpb24gY29tcG9zZUFzeW5jVmFsaWRhdG9ycyh2YWxpZGF0b3JzKSB7XG4gIHJldHVybiB2YWxpZGF0b3JzICE9IG51bGwgPyBjb21wb3NlQXN5bmMobm9ybWFsaXplVmFsaWRhdG9ycyh2YWxpZGF0b3JzKSkgOiBudWxsO1xufVxuZnVuY3Rpb24gbWVyZ2VWYWxpZGF0b3JzKGNvbnRyb2xWYWxpZGF0b3JzLCBkaXJWYWxpZGF0b3IpIHtcbiAgaWYgKGNvbnRyb2xWYWxpZGF0b3JzID09PSBudWxsKSByZXR1cm4gW2RpclZhbGlkYXRvcl07XG4gIHJldHVybiBBcnJheS5pc0FycmF5KGNvbnRyb2xWYWxpZGF0b3JzKSA/IFsuLi5jb250cm9sVmFsaWRhdG9ycywgZGlyVmFsaWRhdG9yXSA6IFtjb250cm9sVmFsaWRhdG9ycywgZGlyVmFsaWRhdG9yXTtcbn1cbmZ1bmN0aW9uIGdldENvbnRyb2xWYWxpZGF0b3JzKGNvbnRyb2wpIHtcbiAgcmV0dXJuIGNvbnRyb2wuX3Jhd1ZhbGlkYXRvcnM7XG59XG5mdW5jdGlvbiBnZXRDb250cm9sQXN5bmNWYWxpZGF0b3JzKGNvbnRyb2wpIHtcbiAgcmV0dXJuIGNvbnRyb2wuX3Jhd0FzeW5jVmFsaWRhdG9ycztcbn1cbmZ1bmN0aW9uIG1ha2VWYWxpZGF0b3JzQXJyYXkodmFsaWRhdG9ycykge1xuICBpZiAoIXZhbGlkYXRvcnMpIHJldHVybiBbXTtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsaWRhdG9ycykgPyB2YWxpZGF0b3JzIDogW3ZhbGlkYXRvcnNdO1xufVxuZnVuY3Rpb24gaGFzVmFsaWRhdG9yKHZhbGlkYXRvcnMsIHZhbGlkYXRvcikge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWxpZGF0b3JzKSA/IHZhbGlkYXRvcnMuaW5jbHVkZXModmFsaWRhdG9yKSA6IHZhbGlkYXRvcnMgPT09IHZhbGlkYXRvcjtcbn1cbmZ1bmN0aW9uIGFkZFZhbGlkYXRvcnModmFsaWRhdG9ycywgY3VycmVudFZhbGlkYXRvcnMpIHtcbiAgY29uc3QgY3VycmVudCA9IG1ha2VWYWxpZGF0b3JzQXJyYXkoY3VycmVudFZhbGlkYXRvcnMpO1xuICBjb25zdCB2YWxpZGF0b3JzVG9BZGQgPSBtYWtlVmFsaWRhdG9yc0FycmF5KHZhbGlkYXRvcnMpO1xuICB2YWxpZGF0b3JzVG9BZGQuZm9yRWFjaCh2ID0+IHtcbiAgICBpZiAoIWhhc1ZhbGlkYXRvcihjdXJyZW50LCB2KSkge1xuICAgICAgY3VycmVudC5wdXNoKHYpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBjdXJyZW50O1xufVxuZnVuY3Rpb24gcmVtb3ZlVmFsaWRhdG9ycyh2YWxpZGF0b3JzLCBjdXJyZW50VmFsaWRhdG9ycykge1xuICByZXR1cm4gbWFrZVZhbGlkYXRvcnNBcnJheShjdXJyZW50VmFsaWRhdG9ycykuZmlsdGVyKHYgPT4gIWhhc1ZhbGlkYXRvcih2YWxpZGF0b3JzLCB2KSk7XG59XG5jbGFzcyBBYnN0cmFjdENvbnRyb2xEaXJlY3RpdmUge1xuICBnZXQgdmFsdWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbCA/IHRoaXMuY29udHJvbC52YWx1ZSA6IG51bGw7XG4gIH1cbiAgZ2V0IHZhbGlkKCkge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2wgPyB0aGlzLmNvbnRyb2wudmFsaWQgOiBudWxsO1xuICB9XG4gIGdldCBpbnZhbGlkKCkge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2wgPyB0aGlzLmNvbnRyb2wuaW52YWxpZCA6IG51bGw7XG4gIH1cbiAgZ2V0IHBlbmRpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbCA/IHRoaXMuY29udHJvbC5wZW5kaW5nIDogbnVsbDtcbiAgfVxuICBnZXQgZGlzYWJsZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbCA/IHRoaXMuY29udHJvbC5kaXNhYmxlZCA6IG51bGw7XG4gIH1cbiAgZ2V0IGVuYWJsZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbCA/IHRoaXMuY29udHJvbC5lbmFibGVkIDogbnVsbDtcbiAgfVxuICBnZXQgZXJyb3JzKCkge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2wgPyB0aGlzLmNvbnRyb2wuZXJyb3JzIDogbnVsbDtcbiAgfVxuICBnZXQgcHJpc3RpbmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbCA/IHRoaXMuY29udHJvbC5wcmlzdGluZSA6IG51bGw7XG4gIH1cbiAgZ2V0IGRpcnR5KCkge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2wgPyB0aGlzLmNvbnRyb2wuZGlydHkgOiBudWxsO1xuICB9XG4gIGdldCB0b3VjaGVkKCkge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2wgPyB0aGlzLmNvbnRyb2wudG91Y2hlZCA6IG51bGw7XG4gIH1cbiAgZ2V0IHN0YXR1cygpIHtcbiAgICByZXR1cm4gdGhpcy5jb250cm9sID8gdGhpcy5jb250cm9sLnN0YXR1cyA6IG51bGw7XG4gIH1cbiAgZ2V0IHVudG91Y2hlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5jb250cm9sID8gdGhpcy5jb250cm9sLnVudG91Y2hlZCA6IG51bGw7XG4gIH1cbiAgZ2V0IHN0YXR1c0NoYW5nZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbCA/IHRoaXMuY29udHJvbC5zdGF0dXNDaGFuZ2VzIDogbnVsbDtcbiAgfVxuICBnZXQgdmFsdWVDaGFuZ2VzKCkge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2wgPyB0aGlzLmNvbnRyb2wudmFsdWVDaGFuZ2VzIDogbnVsbDtcbiAgfVxuICBnZXQgcGF0aCgpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBfY29tcG9zZWRWYWxpZGF0b3JGbjtcbiAgX2NvbXBvc2VkQXN5bmNWYWxpZGF0b3JGbjtcbiAgX3Jhd1ZhbGlkYXRvcnMgPSBbXTtcbiAgX3Jhd0FzeW5jVmFsaWRhdG9ycyA9IFtdO1xuICBfc2V0VmFsaWRhdG9ycyh2YWxpZGF0b3JzKSB7XG4gICAgdGhpcy5fcmF3VmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMgfHwgW107XG4gICAgdGhpcy5fY29tcG9zZWRWYWxpZGF0b3JGbiA9IGNvbXBvc2VWYWxpZGF0b3JzKHRoaXMuX3Jhd1ZhbGlkYXRvcnMpO1xuICB9XG4gIF9zZXRBc3luY1ZhbGlkYXRvcnModmFsaWRhdG9ycykge1xuICAgIHRoaXMuX3Jhd0FzeW5jVmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMgfHwgW107XG4gICAgdGhpcy5fY29tcG9zZWRBc3luY1ZhbGlkYXRvckZuID0gY29tcG9zZUFzeW5jVmFsaWRhdG9ycyh0aGlzLl9yYXdBc3luY1ZhbGlkYXRvcnMpO1xuICB9XG4gIGdldCB2YWxpZGF0b3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbXBvc2VkVmFsaWRhdG9yRm4gfHwgbnVsbDtcbiAgfVxuICBnZXQgYXN5bmNWYWxpZGF0b3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbXBvc2VkQXN5bmNWYWxpZGF0b3JGbiB8fCBudWxsO1xuICB9XG4gIF9vbkRlc3Ryb3lDYWxsYmFja3MgPSBbXTtcbiAgX3JlZ2lzdGVyT25EZXN0cm95KGZuKSB7XG4gICAgdGhpcy5fb25EZXN0cm95Q2FsbGJhY2tzLnB1c2goZm4pO1xuICB9XG4gIF9pbnZva2VPbkRlc3Ryb3lDYWxsYmFja3MoKSB7XG4gICAgdGhpcy5fb25EZXN0cm95Q2FsbGJhY2tzLmZvckVhY2goZm4gPT4gZm4oKSk7XG4gICAgdGhpcy5fb25EZXN0cm95Q2FsbGJhY2tzID0gW107XG4gIH1cbiAgcmVzZXQodmFsdWUgPSB1bmRlZmluZWQpIHtcbiAgICB0aGlzLmNvbnRyb2w/LnJlc2V0KHZhbHVlKTtcbiAgfVxuICBoYXNFcnJvcihlcnJvckNvZGUsIHBhdGgpIHtcbiAgICByZXR1cm4gdGhpcy5jb250cm9sID8gdGhpcy5jb250cm9sLmhhc0Vycm9yKGVycm9yQ29kZSwgcGF0aCkgOiBmYWxzZTtcbiAgfVxuICBnZXRFcnJvcihlcnJvckNvZGUsIHBhdGgpIHtcbiAgICByZXR1cm4gdGhpcy5jb250cm9sID8gdGhpcy5jb250cm9sLmdldEVycm9yKGVycm9yQ29kZSwgcGF0aCkgOiBudWxsO1xuICB9XG59XG5jbGFzcyBDb250cm9sQ29udGFpbmVyIGV4dGVuZHMgQWJzdHJhY3RDb250cm9sRGlyZWN0aXZlIHtcbiAgbmFtZTtcbiAgZ2V0IGZvcm1EaXJlY3RpdmUoKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgZ2V0IHBhdGgoKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cbmNvbnN0IGZvcm1Db250cm9sTmFtZUV4YW1wbGUgPSBgXG4gIDxkaXYgW2Zvcm1Hcm91cF09XCJteUdyb3VwXCI+XG4gICAgPGlucHV0IGZvcm1Db250cm9sTmFtZT1cImZpcnN0TmFtZVwiPlxuICA8L2Rpdj5cblxuICBJbiB5b3VyIGNsYXNzOlxuXG4gIHRoaXMubXlHcm91cCA9IG5ldyBGb3JtR3JvdXAoe1xuICAgICAgZmlyc3ROYW1lOiBuZXcgRm9ybUNvbnRyb2woKVxuICB9KTtgO1xuY29uc3QgZm9ybUdyb3VwTmFtZUV4YW1wbGUgPSBgXG4gIDxkaXYgW2Zvcm1Hcm91cF09XCJteUdyb3VwXCI+XG4gICAgICA8ZGl2IGZvcm1Hcm91cE5hbWU9XCJwZXJzb25cIj5cbiAgICAgICAgPGlucHV0IGZvcm1Db250cm9sTmFtZT1cImZpcnN0TmFtZVwiPlxuICAgICAgPC9kaXY+XG4gIDwvZGl2PlxuXG4gIEluIHlvdXIgY2xhc3M6XG5cbiAgdGhpcy5teUdyb3VwID0gbmV3IEZvcm1Hcm91cCh7XG4gICAgICBwZXJzb246IG5ldyBGb3JtR3JvdXAoeyBmaXJzdE5hbWU6IG5ldyBGb3JtQ29udHJvbCgpIH0pXG4gIH0pO2A7XG5jb25zdCBmb3JtQXJyYXlOYW1lRXhhbXBsZSA9IGBcbiAgPGRpdiBbZm9ybUdyb3VwXT1cIm15R3JvdXBcIj5cbiAgICA8ZGl2IGZvcm1BcnJheU5hbWU9XCJjaXRpZXNcIj5cbiAgICAgIDxkaXYgKm5nRm9yPVwibGV0IGNpdHkgb2YgY2l0eUFycmF5LmNvbnRyb2xzOyBpbmRleCBhcyBpXCI+XG4gICAgICAgIDxpbnB1dCBbZm9ybUNvbnRyb2xOYW1lXT1cImlcIj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cblxuICBJbiB5b3VyIGNsYXNzOlxuXG4gIHRoaXMuY2l0eUFycmF5ID0gbmV3IEZvcm1BcnJheShbbmV3IEZvcm1Db250cm9sKCdTRicpXSk7XG4gIHRoaXMubXlHcm91cCA9IG5ldyBGb3JtR3JvdXAoe1xuICAgIGNpdGllczogdGhpcy5jaXR5QXJyYXlcbiAgfSk7YDtcbmNvbnN0IG5nTW9kZWxHcm91cEV4YW1wbGUgPSBgXG4gIDxmb3JtPlxuICAgICAgPGRpdiBuZ01vZGVsR3JvdXA9XCJwZXJzb25cIj5cbiAgICAgICAgPGlucHV0IFsobmdNb2RlbCldPVwicGVyc29uLm5hbWVcIiBuYW1lPVwiZmlyc3ROYW1lXCI+XG4gICAgICA8L2Rpdj5cbiAgPC9mb3JtPmA7XG5jb25zdCBuZ01vZGVsV2l0aEZvcm1Hcm91cEV4YW1wbGUgPSBgXG4gIDxkaXYgW2Zvcm1Hcm91cF09XCJteUdyb3VwXCI+XG4gICAgICA8aW5wdXQgZm9ybUNvbnRyb2xOYW1lPVwiZmlyc3ROYW1lXCI+XG4gICAgICA8aW5wdXQgWyhuZ01vZGVsKV09XCJzaG93TW9yZUNvbnRyb2xzXCIgW25nTW9kZWxPcHRpb25zXT1cIntzdGFuZGFsb25lOiB0cnVlfVwiPlxuICA8L2Rpdj5cbmA7XG5jb25zdCBWRVJTSU9OID0gLyogQF9fUFVSRV9fICovbmV3IFZlcnNpb24oJzIyLjEuMicpO1xuZnVuY3Rpb24gY29udHJvbFBhcmVudEV4Y2VwdGlvbihuYW1lT3JJbmRleCkge1xuICByZXR1cm4gbmV3IF9SdW50aW1lRXJyb3IoMTA1MCwgYGZvcm1Db250cm9sTmFtZSBtdXN0IGJlIHVzZWQgd2l0aCBhIHBhcmVudCBmb3JtR3JvdXAgb3IgZm9ybUFycmF5IGRpcmVjdGl2ZS4gWW91J2xsIHdhbnQgdG8gYWRkIGEgZm9ybUdyb3VwL2Zvcm1BcnJheVxuICAgICAgZGlyZWN0aXZlIGFuZCBwYXNzIGl0IGFuIGV4aXN0aW5nIEZvcm1Hcm91cC9Gb3JtQXJyYXkgaW5zdGFuY2UgKHlvdSBjYW4gY3JlYXRlIG9uZSBpbiB5b3VyIGNsYXNzKS5cblxuICAgICAgJHtkZXNjcmliZUZvcm1Db250cm9sKG5hbWVPckluZGV4KX1cblxuICAgIEV4YW1wbGU6XG5cbiAgICAke2Zvcm1Db250cm9sTmFtZUV4YW1wbGV9YCk7XG59XG5mdW5jdGlvbiBkZXNjcmliZUZvcm1Db250cm9sKG5hbWVPckluZGV4KSB7XG4gIGlmIChuYW1lT3JJbmRleCA9PSBudWxsIHx8IG5hbWVPckluZGV4ID09PSAnJykge1xuICAgIHJldHVybiAnJztcbiAgfVxuICBjb25zdCB2YWx1ZVR5cGUgPSB0eXBlb2YgbmFtZU9ySW5kZXggPT09ICdzdHJpbmcnID8gJ25hbWUnIDogJ2luZGV4JztcbiAgcmV0dXJuIGBBZmZlY3RlZCBGb3JtIENvbnRyb2wgJHt2YWx1ZVR5cGV9OiBcIiR7bmFtZU9ySW5kZXh9XCJgO1xufVxuZnVuY3Rpb24gbmdNb2RlbEdyb3VwRXhjZXB0aW9uKCkge1xuICByZXR1cm4gbmV3IF9SdW50aW1lRXJyb3IoMTA1MSwgYGZvcm1Db250cm9sTmFtZSBjYW5ub3QgYmUgdXNlZCB3aXRoIGFuIG5nTW9kZWxHcm91cCBwYXJlbnQuIEl0IGlzIG9ubHkgY29tcGF0aWJsZSB3aXRoIHBhcmVudHNcbiAgICAgIHRoYXQgYWxzbyBoYXZlIGEgXCJmb3JtXCIgcHJlZml4OiBmb3JtR3JvdXBOYW1lLCBmb3JtQXJyYXlOYW1lLCBvciBmb3JtR3JvdXAuXG5cbiAgICAgIE9wdGlvbiAxOiAgVXBkYXRlIHRoZSBwYXJlbnQgdG8gYmUgZm9ybUdyb3VwTmFtZSAocmVhY3RpdmUgZm9ybSBzdHJhdGVneSlcblxuICAgICAgJHtmb3JtR3JvdXBOYW1lRXhhbXBsZX1cblxuICAgICAgT3B0aW9uIDI6IFVzZSBuZ01vZGVsIGluc3RlYWQgb2YgZm9ybUNvbnRyb2xOYW1lICh0ZW1wbGF0ZS1kcml2ZW4gc3RyYXRlZ3kpXG5cbiAgICAgICR7bmdNb2RlbEdyb3VwRXhhbXBsZX1gKTtcbn1cbmZ1bmN0aW9uIG1pc3NpbmdGb3JtRXhjZXB0aW9uKCkge1xuICByZXR1cm4gbmV3IF9SdW50aW1lRXJyb3IoMTA1MiwgYGZvcm1Hcm91cCBleHBlY3RzIGEgRm9ybUdyb3VwIGluc3RhbmNlLiBQbGVhc2UgcGFzcyBvbmUgaW4uXG5cbiAgICAgIEV4YW1wbGU6XG5cbiAgICAgICR7Zm9ybUNvbnRyb2xOYW1lRXhhbXBsZX1gKTtcbn1cbmZ1bmN0aW9uIGdyb3VwUGFyZW50RXhjZXB0aW9uKCkge1xuICByZXR1cm4gbmV3IF9SdW50aW1lRXJyb3IoMTA1MywgYGZvcm1Hcm91cE5hbWUgbXVzdCBiZSB1c2VkIHdpdGggYSBwYXJlbnQgZm9ybUdyb3VwIGRpcmVjdGl2ZS4gIFlvdSdsbCB3YW50IHRvIGFkZCBhIGZvcm1Hcm91cFxuICAgIGRpcmVjdGl2ZSBhbmQgcGFzcyBpdCBhbiBleGlzdGluZyBGb3JtR3JvdXAgaW5zdGFuY2UgKHlvdSBjYW4gY3JlYXRlIG9uZSBpbiB5b3VyIGNsYXNzKS5cblxuICAgIEV4YW1wbGU6XG5cbiAgICAke2Zvcm1Hcm91cE5hbWVFeGFtcGxlfWApO1xufVxuZnVuY3Rpb24gYXJyYXlQYXJlbnRFeGNlcHRpb24oKSB7XG4gIHJldHVybiBuZXcgX1J1bnRpbWVFcnJvcigxMDU0LCBgZm9ybUFycmF5TmFtZSBtdXN0IGJlIHVzZWQgd2l0aCBhIHBhcmVudCBmb3JtR3JvdXAgZGlyZWN0aXZlLiAgWW91J2xsIHdhbnQgdG8gYWRkIGEgZm9ybUdyb3VwXG4gICAgICBkaXJlY3RpdmUgYW5kIHBhc3MgaXQgYW4gZXhpc3RpbmcgRm9ybUdyb3VwIGluc3RhbmNlICh5b3UgY2FuIGNyZWF0ZSBvbmUgaW4geW91ciBjbGFzcykuXG5cbiAgICAgIEV4YW1wbGU6XG5cbiAgICAgICR7Zm9ybUFycmF5TmFtZUV4YW1wbGV9YCk7XG59XG5jb25zdCBkaXNhYmxlZEF0dHJXYXJuaW5nID0gYFxuICBJdCBsb29rcyBsaWtlIHlvdSdyZSB1c2luZyB0aGUgZGlzYWJsZWQgYXR0cmlidXRlIHdpdGggYSByZWFjdGl2ZSBmb3JtIGRpcmVjdGl2ZS4gSWYgeW91IHNldCBkaXNhYmxlZCB0byB0cnVlXG4gIHdoZW4geW91IHNldCB1cCB0aGlzIGNvbnRyb2wgaW4geW91ciBjb21wb25lbnQgY2xhc3MsIHRoZSBkaXNhYmxlZCBhdHRyaWJ1dGUgd2lsbCBhY3R1YWxseSBiZSBzZXQgaW4gdGhlIERPTSBmb3JcbiAgeW91LiBXZSByZWNvbW1lbmQgdXNpbmcgdGhpcyBhcHByb2FjaCB0byBhdm9pZCAnY2hhbmdlZCBhZnRlciBjaGVja2VkJyBlcnJvcnMuXG5cbiAgRXhhbXBsZTpcbiAgLy8gU3BlY2lmeSB0aGUgXFxgZGlzYWJsZWRcXGAgcHJvcGVydHkgYXQgY29udHJvbCBjcmVhdGlvbiB0aW1lOlxuICBmb3JtID0gbmV3IEZvcm1Hcm91cCh7XG4gICAgZmlyc3Q6IG5ldyBGb3JtQ29udHJvbCh7dmFsdWU6ICdOYW5jeScsIGRpc2FibGVkOiB0cnVlfSwgVmFsaWRhdG9ycy5yZXF1aXJlZCksXG4gICAgbGFzdDogbmV3IEZvcm1Db250cm9sKCdEcmV3JywgVmFsaWRhdG9ycy5yZXF1aXJlZClcbiAgfSk7XG5cbiAgLy8gQ29udHJvbHMgY2FuIGFsc28gYmUgZW5hYmxlZC9kaXNhYmxlZCBhZnRlciBjcmVhdGlvbjpcbiAgZm9ybS5nZXQoJ2ZpcnN0Jyk/LmVuYWJsZSgpO1xuICBmb3JtLmdldCgnbGFzdCcpPy5kaXNhYmxlKCk7XG5gO1xuY29uc3QgYXN5bmNWYWxpZGF0b3JzRHJvcHBlZFdpdGhPcHRzV2FybmluZyA9IGBcbiAgSXQgbG9va3MgbGlrZSB5b3UncmUgY29uc3RydWN0aW5nIHVzaW5nIGEgRm9ybUNvbnRyb2wgd2l0aCBib3RoIGFuIG9wdGlvbnMgYXJndW1lbnQgYW5kIGFuXG4gIGFzeW5jIHZhbGlkYXRvcnMgYXJndW1lbnQuIE1peGluZyB0aGVzZSBhcmd1bWVudHMgd2lsbCBjYXVzZSB5b3VyIGFzeW5jIHZhbGlkYXRvcnMgdG8gYmUgZHJvcHBlZC5cbiAgWW91IHNob3VsZCBlaXRoZXIgcHV0IGFsbCB5b3VyIHZhbGlkYXRvcnMgaW4gdGhlIG9wdGlvbnMgb2JqZWN0LCBvciBpbiBzZXBhcmF0ZSB2YWxpZGF0b3JzXG4gIGFyZ3VtZW50cy4gRm9yIGV4YW1wbGU6XG5cbiAgLy8gVXNpbmcgdmFsaWRhdG9ycyBhcmd1bWVudHNcbiAgZmMgPSBuZXcgRm9ybUNvbnRyb2woNDIsIFZhbGlkYXRvcnMucmVxdWlyZWQsIG15QXN5bmNWYWxpZGF0b3IpO1xuXG4gIC8vIFVzaW5nIEFic3RyYWN0Q29udHJvbE9wdGlvbnNcbiAgZmMgPSBuZXcgRm9ybUNvbnRyb2woNDIsIHt2YWxpZGF0b3JzOiBWYWxpZGF0b3JzLnJlcXVpcmVkLCBhc3luY1ZhbGlkYXRvcnM6IG15QVZ9KTtcblxuICAvLyBEbyBOT1QgbWl4IHRoZW06IGFzeW5jIHZhbGlkYXRvcnMgd2lsbCBiZSBkcm9wcGVkIVxuICBmYyA9IG5ldyBGb3JtQ29udHJvbCg0Miwge3ZhbGlkYXRvcnM6IFZhbGlkYXRvcnMucmVxdWlyZWR9LCAvKiBPb3BzISAqLyBteUFzeW5jVmFsaWRhdG9yKTtcbmA7XG5mdW5jdGlvbiBuZ01vZGVsV2FybmluZyhkaXJlY3RpdmVOYW1lKSB7XG4gIGNvbnN0IHZlcnNpb25TdWJEb21haW4gPSBWRVJTSU9OLm1ham9yICE9PSAnMCcgPyBgdiR7VkVSU0lPTi5tYWpvcn0uYCA6ICcnO1xuICByZXR1cm4gYFxuICBJdCBsb29rcyBsaWtlIHlvdSdyZSB1c2luZyBuZ01vZGVsIG9uIHRoZSBzYW1lIGZvcm0gZmllbGQgYXMgJHtkaXJlY3RpdmVOYW1lfS5cbiAgU3VwcG9ydCBmb3IgdXNpbmcgdGhlIG5nTW9kZWwgaW5wdXQgcHJvcGVydHkgYW5kIG5nTW9kZWxDaGFuZ2UgZXZlbnQgd2l0aFxuICByZWFjdGl2ZSBmb3JtIGRpcmVjdGl2ZXMgaGFzIGJlZW4gZGVwcmVjYXRlZCBpbiBBbmd1bGFyIHY2IGFuZCB3aWxsIGJlIHJlbW92ZWRcbiAgaW4gYSBmdXR1cmUgdmVyc2lvbiBvZiBBbmd1bGFyLlxuXG4gIEZvciBtb3JlIGluZm9ybWF0aW9uIG9uIHRoaXMsIHNlZSBvdXIgQVBJIGRvY3MgaGVyZTpcbiAgaHR0cHM6Ly8ke3ZlcnNpb25TdWJEb21haW59YW5ndWxhci5kZXYvYXBpL2Zvcm1zLyR7ZGlyZWN0aXZlTmFtZSA9PT0gJ2Zvcm1Db250cm9sJyA/ICdGb3JtQ29udHJvbERpcmVjdGl2ZScgOiAnRm9ybUNvbnRyb2xOYW1lJ31cbiAgYDtcbn1cbmZ1bmN0aW9uIGRlc2NyaWJlS2V5KGlzRm9ybUdyb3VwLCBrZXkpIHtcbiAgcmV0dXJuIGlzRm9ybUdyb3VwID8gYHdpdGggbmFtZTogJyR7a2V5fSdgIDogYGF0IGluZGV4OiAke2tleX1gO1xufVxuZnVuY3Rpb24gbm9Db250cm9sc0Vycm9yKGlzRm9ybUdyb3VwKSB7XG4gIHJldHVybiBgXG4gICAgVGhlcmUgYXJlIG5vIGZvcm0gY29udHJvbHMgcmVnaXN0ZXJlZCB3aXRoIHRoaXMgJHtpc0Zvcm1Hcm91cCA/ICdncm91cCcgOiAnYXJyYXknfSB5ZXQuIElmIHlvdSdyZSB1c2luZyBuZ01vZGVsLFxuICAgIHlvdSBtYXkgd2FudCB0byBjaGVjayBuZXh0IHRpY2sgKGUuZy4gdXNlIHNldFRpbWVvdXQpLlxuICBgO1xufVxuZnVuY3Rpb24gbWlzc2luZ0NvbnRyb2xFcnJvcihpc0Zvcm1Hcm91cCwga2V5KSB7XG4gIHJldHVybiBgQ2Fubm90IGZpbmQgZm9ybSBjb250cm9sICR7ZGVzY3JpYmVLZXkoaXNGb3JtR3JvdXAsIGtleSl9YDtcbn1cbmZ1bmN0aW9uIG1pc3NpbmdDb250cm9sVmFsdWVFcnJvcihpc0Zvcm1Hcm91cCwga2V5KSB7XG4gIHJldHVybiBgTXVzdCBzdXBwbHkgYSB2YWx1ZSBmb3IgZm9ybSBjb250cm9sICR7ZGVzY3JpYmVLZXkoaXNGb3JtR3JvdXAsIGtleSl9YDtcbn1cbmNvbnN0IFZBTElEID0gJ1ZBTElEJztcbmNvbnN0IElOVkFMSUQgPSAnSU5WQUxJRCc7XG5jb25zdCBQRU5ESU5HID0gJ1BFTkRJTkcnO1xuY29uc3QgRElTQUJMRUQgPSAnRElTQUJMRUQnO1xuY2xhc3MgQ29udHJvbEV2ZW50IHt9XG5jbGFzcyBWYWx1ZUNoYW5nZUV2ZW50IGV4dGVuZHMgQ29udHJvbEV2ZW50IHtcbiAgdmFsdWU7XG4gIHNvdXJjZTtcbiAgY29uc3RydWN0b3IodmFsdWUsIHNvdXJjZSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlO1xuICB9XG59XG5jbGFzcyBQcmlzdGluZUNoYW5nZUV2ZW50IGV4dGVuZHMgQ29udHJvbEV2ZW50IHtcbiAgcHJpc3RpbmU7XG4gIHNvdXJjZTtcbiAgY29uc3RydWN0b3IocHJpc3RpbmUsIHNvdXJjZSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5wcmlzdGluZSA9IHByaXN0aW5lO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlO1xuICB9XG59XG5jbGFzcyBUb3VjaGVkQ2hhbmdlRXZlbnQgZXh0ZW5kcyBDb250cm9sRXZlbnQge1xuICB0b3VjaGVkO1xuICBzb3VyY2U7XG4gIGNvbnN0cnVjdG9yKHRvdWNoZWQsIHNvdXJjZSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy50b3VjaGVkID0gdG91Y2hlZDtcbiAgICB0aGlzLnNvdXJjZSA9IHNvdXJjZTtcbiAgfVxufVxuY2xhc3MgU3RhdHVzQ2hhbmdlRXZlbnQgZXh0ZW5kcyBDb250cm9sRXZlbnQge1xuICBzdGF0dXM7XG4gIHNvdXJjZTtcbiAgY29uc3RydWN0b3Ioc3RhdHVzLCBzb3VyY2UpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuc3RhdHVzID0gc3RhdHVzO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlO1xuICB9XG59XG5jbGFzcyBGb3JtU3VibWl0dGVkRXZlbnQgZXh0ZW5kcyBDb250cm9sRXZlbnQge1xuICBzb3VyY2U7XG4gIGNvbnN0cnVjdG9yKHNvdXJjZSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5zb3VyY2UgPSBzb3VyY2U7XG4gIH1cbn1cbmNsYXNzIEZvcm1SZXNldEV2ZW50IGV4dGVuZHMgQ29udHJvbEV2ZW50IHtcbiAgc291cmNlO1xuICBjb25zdHJ1Y3Rvcihzb3VyY2UpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuc291cmNlID0gc291cmNlO1xuICB9XG59XG5mdW5jdGlvbiBwaWNrVmFsaWRhdG9ycyh2YWxpZGF0b3JPck9wdHMpIHtcbiAgcmV0dXJuIChpc09wdGlvbnNPYmoodmFsaWRhdG9yT3JPcHRzKSA/IHZhbGlkYXRvck9yT3B0cy52YWxpZGF0b3JzIDogdmFsaWRhdG9yT3JPcHRzKSB8fCBudWxsO1xufVxuZnVuY3Rpb24gY29lcmNlVG9WYWxpZGF0b3IodmFsaWRhdG9yKSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHZhbGlkYXRvcikgPyBjb21wb3NlVmFsaWRhdG9ycyh2YWxpZGF0b3IpIDogdmFsaWRhdG9yIHx8IG51bGw7XG59XG5mdW5jdGlvbiBwaWNrQXN5bmNWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9yLCB2YWxpZGF0b3JPck9wdHMpIHtcbiAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgIGlmIChpc09wdGlvbnNPYmoodmFsaWRhdG9yT3JPcHRzKSAmJiBhc3luY1ZhbGlkYXRvcikge1xuICAgICAgY29uc29sZS53YXJuKGFzeW5jVmFsaWRhdG9yc0Ryb3BwZWRXaXRoT3B0c1dhcm5pbmcpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gKGlzT3B0aW9uc09iaih2YWxpZGF0b3JPck9wdHMpID8gdmFsaWRhdG9yT3JPcHRzLmFzeW5jVmFsaWRhdG9ycyA6IGFzeW5jVmFsaWRhdG9yKSB8fCBudWxsO1xufVxuZnVuY3Rpb24gY29lcmNlVG9Bc3luY1ZhbGlkYXRvcihhc3luY1ZhbGlkYXRvcikge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShhc3luY1ZhbGlkYXRvcikgPyBjb21wb3NlQXN5bmNWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9yKSA6IGFzeW5jVmFsaWRhdG9yIHx8IG51bGw7XG59XG5mdW5jdGlvbiBpc09wdGlvbnNPYmoodmFsaWRhdG9yT3JPcHRzKSB7XG4gIHJldHVybiB2YWxpZGF0b3JPck9wdHMgIT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2YWxpZGF0b3JPck9wdHMpICYmIHR5cGVvZiB2YWxpZGF0b3JPck9wdHMgPT09ICdvYmplY3QnO1xufVxuZnVuY3Rpb24gYXNzZXJ0Q29udHJvbFByZXNlbnQocGFyZW50LCBpc0dyb3VwLCBrZXkpIHtcbiAgY29uc3QgY29udHJvbHMgPSBwYXJlbnQuY29udHJvbHM7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSBpc0dyb3VwID8gT2JqZWN0LmtleXMoY29udHJvbHMpIDogY29udHJvbHM7XG4gIGlmICghY29sbGVjdGlvbi5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigxMDAwLCB0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUgPyBub0NvbnRyb2xzRXJyb3IoaXNHcm91cCkgOiAnJyk7XG4gIH1cbiAgaWYgKCFoYXNPd25Db250cm9sKGNvbnRyb2xzLCBrZXkpKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMTAwMSwgdHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gbWlzc2luZ0NvbnRyb2xFcnJvcihpc0dyb3VwLCBrZXkpIDogJycpO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRBbGxWYWx1ZXNQcmVzZW50KGNvbnRyb2wsIGlzR3JvdXAsIHZhbHVlKSB7XG4gIGNvbnRyb2wuX2ZvckVhY2hDaGlsZCgoXywga2V5KSA9PiB7XG4gICAgaWYgKHZhbHVlW2tleV0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoLTEwMDIsIHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IG1pc3NpbmdDb250cm9sVmFsdWVFcnJvcihpc0dyb3VwLCBrZXkpIDogJycpO1xuICAgIH1cbiAgfSk7XG59XG5jbGFzcyBBYnN0cmFjdENvbnRyb2wge1xuICBfcGVuZGluZ0RpcnR5ID0gZmFsc2U7XG4gIF9oYXNPd25QZW5kaW5nQXN5bmNWYWxpZGF0b3IgPSBudWxsO1xuICBfcGVuZGluZ1RvdWNoZWQgPSBmYWxzZTtcbiAgX29uQ29sbGVjdGlvbkNoYW5nZSA9ICgpID0+IHt9O1xuICBfdXBkYXRlT247XG4gIF9oYXNSZXF1aXJlZCA9IHNpZ25hbChmYWxzZSwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgZGVidWdOYW1lOiBcIl9oYXNSZXF1aXJlZFwiXG4gIH1dIDogW10pKTtcbiAgX3BhcmVudCA9IG51bGw7XG4gIF9hc3luY1ZhbGlkYXRpb25TdWJzY3JpcHRpb247XG4gIF9jb21wb3NlZFZhbGlkYXRvckZuO1xuICBfY29tcG9zZWRBc3luY1ZhbGlkYXRvckZuO1xuICBfcmF3VmFsaWRhdG9ycztcbiAgX3Jhd0FzeW5jVmFsaWRhdG9ycztcbiAgdmFsdWU7XG4gIGNvbnN0cnVjdG9yKHZhbGlkYXRvcnMsIGFzeW5jVmFsaWRhdG9ycykge1xuICAgIHRoaXMuX2Fzc2lnblZhbGlkYXRvcnModmFsaWRhdG9ycyk7XG4gICAgdGhpcy5fYXNzaWduQXN5bmNWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9ycyk7XG4gIH1cbiAgZ2V0IHZhbGlkYXRvcigpIHtcbiAgICByZXR1cm4gdGhpcy5fY29tcG9zZWRWYWxpZGF0b3JGbjtcbiAgfVxuICBzZXQgdmFsaWRhdG9yKHZhbGlkYXRvckZuKSB7XG4gICAgdGhpcy5fcmF3VmFsaWRhdG9ycyA9IHRoaXMuX2NvbXBvc2VkVmFsaWRhdG9yRm4gPSB2YWxpZGF0b3JGbjtcbiAgICB0aGlzLl91cGRhdGVIYXNSZXF1aXJlZFZhbGlkYXRvcigpO1xuICB9XG4gIGdldCBhc3luY1ZhbGlkYXRvcigpIHtcbiAgICByZXR1cm4gdGhpcy5fY29tcG9zZWRBc3luY1ZhbGlkYXRvckZuO1xuICB9XG4gIHNldCBhc3luY1ZhbGlkYXRvcihhc3luY1ZhbGlkYXRvckZuKSB7XG4gICAgdGhpcy5fcmF3QXN5bmNWYWxpZGF0b3JzID0gdGhpcy5fY29tcG9zZWRBc3luY1ZhbGlkYXRvckZuID0gYXN5bmNWYWxpZGF0b3JGbjtcbiAgfVxuICBnZXQgcGFyZW50KCkge1xuICAgIHJldHVybiB0aGlzLl9wYXJlbnQ7XG4gIH1cbiAgZ2V0IHN0YXR1cygpIHtcbiAgICByZXR1cm4gdW50cmFja2VkKHRoaXMuc3RhdHVzUmVhY3RpdmUpO1xuICB9XG4gIHNldCBzdGF0dXModikge1xuICAgIHVudHJhY2tlZCgoKSA9PiB0aGlzLnN0YXR1c1JlYWN0aXZlLnNldCh2KSk7XG4gIH1cbiAgX3N0YXR1cyA9IGNvbXB1dGVkKCgpID0+IHRoaXMuc3RhdHVzUmVhY3RpdmUoKSwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgZGVidWdOYW1lOiBcIl9zdGF0dXNcIlxuICB9XSA6IFtdKSk7XG4gIHN0YXR1c1JlYWN0aXZlID0gc2lnbmFsKHVuZGVmaW5lZCwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgZGVidWdOYW1lOiBcInN0YXR1c1JlYWN0aXZlXCJcbiAgfV0gOiBbXSkpO1xuICBnZXQgdmFsaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdHVzID09PSBWQUxJRDtcbiAgfVxuICBnZXQgaW52YWxpZCgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0dXMgPT09IElOVkFMSUQ7XG4gIH1cbiAgZ2V0IHBlbmRpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdHVzID09PSBQRU5ESU5HO1xuICB9XG4gIGdldCBkaXNhYmxlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0dXMgPT09IERJU0FCTEVEO1xuICB9XG4gIGdldCBlbmFibGVkKCkge1xuICAgIHJldHVybiB0aGlzLnN0YXR1cyAhPT0gRElTQUJMRUQ7XG4gIH1cbiAgZXJyb3JzO1xuICBnZXQgcHJpc3RpbmUoKSB7XG4gICAgcmV0dXJuIHVudHJhY2tlZCh0aGlzLnByaXN0aW5lUmVhY3RpdmUpO1xuICB9XG4gIHNldCBwcmlzdGluZSh2KSB7XG4gICAgdW50cmFja2VkKCgpID0+IHRoaXMucHJpc3RpbmVSZWFjdGl2ZS5zZXQodikpO1xuICB9XG4gIF9wcmlzdGluZSA9IGNvbXB1dGVkKCgpID0+IHRoaXMucHJpc3RpbmVSZWFjdGl2ZSgpLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwiX3ByaXN0aW5lXCJcbiAgfV0gOiBbXSkpO1xuICBwcmlzdGluZVJlYWN0aXZlID0gc2lnbmFsKHRydWUsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJwcmlzdGluZVJlYWN0aXZlXCJcbiAgfV0gOiBbXSkpO1xuICBnZXQgZGlydHkoKSB7XG4gICAgcmV0dXJuICF0aGlzLnByaXN0aW5lO1xuICB9XG4gIGdldCB0b3VjaGVkKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy50b3VjaGVkUmVhY3RpdmUpO1xuICB9XG4gIHNldCB0b3VjaGVkKHYpIHtcbiAgICB1bnRyYWNrZWQoKCkgPT4gdGhpcy50b3VjaGVkUmVhY3RpdmUuc2V0KHYpKTtcbiAgfVxuICBfdG91Y2hlZCA9IGNvbXB1dGVkKCgpID0+IHRoaXMudG91Y2hlZFJlYWN0aXZlKCksIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJfdG91Y2hlZFwiXG4gIH1dIDogW10pKTtcbiAgdG91Y2hlZFJlYWN0aXZlID0gc2lnbmFsKGZhbHNlLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwidG91Y2hlZFJlYWN0aXZlXCJcbiAgfV0gOiBbXSkpO1xuICBnZXQgdW50b3VjaGVkKCkge1xuICAgIHJldHVybiAhdGhpcy50b3VjaGVkO1xuICB9XG4gIF9ldmVudHMgPSBuZXcgU3ViamVjdCgpO1xuICBldmVudHMgPSB0aGlzLl9ldmVudHMuYXNPYnNlcnZhYmxlKCk7XG4gIHZhbHVlQ2hhbmdlcztcbiAgc3RhdHVzQ2hhbmdlcztcbiAgZ2V0IHVwZGF0ZU9uKCkge1xuICAgIHJldHVybiB0aGlzLl91cGRhdGVPbiA/IHRoaXMuX3VwZGF0ZU9uIDogdGhpcy5wYXJlbnQgPyB0aGlzLnBhcmVudC51cGRhdGVPbiA6ICdjaGFuZ2UnO1xuICB9XG4gIHNldFZhbGlkYXRvcnModmFsaWRhdG9ycykge1xuICAgIHRoaXMuX2Fzc2lnblZhbGlkYXRvcnModmFsaWRhdG9ycyk7XG4gIH1cbiAgc2V0QXN5bmNWYWxpZGF0b3JzKHZhbGlkYXRvcnMpIHtcbiAgICB0aGlzLl9hc3NpZ25Bc3luY1ZhbGlkYXRvcnModmFsaWRhdG9ycyk7XG4gIH1cbiAgYWRkVmFsaWRhdG9ycyh2YWxpZGF0b3JzKSB7XG4gICAgdGhpcy5zZXRWYWxpZGF0b3JzKGFkZFZhbGlkYXRvcnModmFsaWRhdG9ycywgdGhpcy5fcmF3VmFsaWRhdG9ycykpO1xuICB9XG4gIGFkZEFzeW5jVmFsaWRhdG9ycyh2YWxpZGF0b3JzKSB7XG4gICAgdGhpcy5zZXRBc3luY1ZhbGlkYXRvcnMoYWRkVmFsaWRhdG9ycyh2YWxpZGF0b3JzLCB0aGlzLl9yYXdBc3luY1ZhbGlkYXRvcnMpKTtcbiAgfVxuICByZW1vdmVWYWxpZGF0b3JzKHZhbGlkYXRvcnMpIHtcbiAgICB0aGlzLnNldFZhbGlkYXRvcnMocmVtb3ZlVmFsaWRhdG9ycyh2YWxpZGF0b3JzLCB0aGlzLl9yYXdWYWxpZGF0b3JzKSk7XG4gIH1cbiAgcmVtb3ZlQXN5bmNWYWxpZGF0b3JzKHZhbGlkYXRvcnMpIHtcbiAgICB0aGlzLnNldEFzeW5jVmFsaWRhdG9ycyhyZW1vdmVWYWxpZGF0b3JzKHZhbGlkYXRvcnMsIHRoaXMuX3Jhd0FzeW5jVmFsaWRhdG9ycykpO1xuICB9XG4gIGhhc1ZhbGlkYXRvcih2YWxpZGF0b3IpIHtcbiAgICByZXR1cm4gaGFzVmFsaWRhdG9yKHRoaXMuX3Jhd1ZhbGlkYXRvcnMsIHZhbGlkYXRvcik7XG4gIH1cbiAgaGFzQXN5bmNWYWxpZGF0b3IodmFsaWRhdG9yKSB7XG4gICAgcmV0dXJuIGhhc1ZhbGlkYXRvcih0aGlzLl9yYXdBc3luY1ZhbGlkYXRvcnMsIHZhbGlkYXRvcik7XG4gIH1cbiAgY2xlYXJWYWxpZGF0b3JzKCkge1xuICAgIHRoaXMudmFsaWRhdG9yID0gbnVsbDtcbiAgfVxuICBjbGVhckFzeW5jVmFsaWRhdG9ycygpIHtcbiAgICB0aGlzLmFzeW5jVmFsaWRhdG9yID0gbnVsbDtcbiAgfVxuICBtYXJrQXNUb3VjaGVkKG9wdHMgPSB7fSkge1xuICAgIGNvbnN0IGNoYW5nZWQgPSB0aGlzLnRvdWNoZWQgPT09IGZhbHNlO1xuICAgIHRoaXMudG91Y2hlZCA9IHRydWU7XG4gICAgY29uc3Qgc291cmNlQ29udHJvbCA9IG9wdHMuc291cmNlQ29udHJvbCA/PyB0aGlzO1xuICAgIGlmICghb3B0cy5vbmx5U2VsZikge1xuICAgICAgdGhpcy5fcGFyZW50Py5tYXJrQXNUb3VjaGVkKHtcbiAgICAgICAgLi4ub3B0cyxcbiAgICAgICAgc291cmNlQ29udHJvbFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChjaGFuZ2VkICYmIG9wdHMuZW1pdEV2ZW50ICE9PSBmYWxzZSkge1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFRvdWNoZWRDaGFuZ2VFdmVudCh0cnVlLCBzb3VyY2VDb250cm9sKSk7XG4gICAgfVxuICB9XG4gIG1hcmtBbGxBc0RpcnR5KG9wdHMgPSB7fSkge1xuICAgIHRoaXMubWFya0FzRGlydHkoe1xuICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICBlbWl0RXZlbnQ6IG9wdHMuZW1pdEV2ZW50LFxuICAgICAgc291cmNlQ29udHJvbDogdGhpc1xuICAgIH0pO1xuICAgIHRoaXMuX2ZvckVhY2hDaGlsZChjb250cm9sID0+IGNvbnRyb2wubWFya0FsbEFzRGlydHkob3B0cykpO1xuICB9XG4gIG1hcmtBbGxBc1RvdWNoZWQob3B0cyA9IHt9KSB7XG4gICAgdGhpcy5tYXJrQXNUb3VjaGVkKHtcbiAgICAgIG9ubHlTZWxmOiB0cnVlLFxuICAgICAgZW1pdEV2ZW50OiBvcHRzLmVtaXRFdmVudCxcbiAgICAgIHNvdXJjZUNvbnRyb2w6IHRoaXNcbiAgICB9KTtcbiAgICB0aGlzLl9mb3JFYWNoQ2hpbGQoY29udHJvbCA9PiBjb250cm9sLm1hcmtBbGxBc1RvdWNoZWQob3B0cykpO1xuICB9XG4gIG1hcmtBc1VudG91Y2hlZChvcHRzID0ge30pIHtcbiAgICBjb25zdCBjaGFuZ2VkID0gdGhpcy50b3VjaGVkID09PSB0cnVlO1xuICAgIHRoaXMudG91Y2hlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3BlbmRpbmdUb3VjaGVkID0gZmFsc2U7XG4gICAgY29uc3Qgc291cmNlQ29udHJvbCA9IG9wdHMuc291cmNlQ29udHJvbCA/PyB0aGlzO1xuICAgIHRoaXMuX2ZvckVhY2hDaGlsZChjb250cm9sID0+IHtcbiAgICAgIGNvbnRyb2wubWFya0FzVW50b3VjaGVkKHtcbiAgICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICAgIGVtaXRFdmVudDogb3B0cy5lbWl0RXZlbnQsXG4gICAgICAgIHNvdXJjZUNvbnRyb2xcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGlmICghb3B0cy5vbmx5U2VsZikge1xuICAgICAgdGhpcy5fcGFyZW50Py5fdXBkYXRlVG91Y2hlZChvcHRzLCBzb3VyY2VDb250cm9sKTtcbiAgICB9XG4gICAgaWYgKGNoYW5nZWQgJiYgb3B0cy5lbWl0RXZlbnQgIT09IGZhbHNlKSB7XG4gICAgICB0aGlzLl9ldmVudHMubmV4dChuZXcgVG91Y2hlZENoYW5nZUV2ZW50KGZhbHNlLCBzb3VyY2VDb250cm9sKSk7XG4gICAgfVxuICB9XG4gIG1hcmtBc0RpcnR5KG9wdHMgPSB7fSkge1xuICAgIGNvbnN0IGNoYW5nZWQgPSB0aGlzLnByaXN0aW5lID09PSB0cnVlO1xuICAgIHRoaXMucHJpc3RpbmUgPSBmYWxzZTtcbiAgICBjb25zdCBzb3VyY2VDb250cm9sID0gb3B0cy5zb3VyY2VDb250cm9sID8/IHRoaXM7XG4gICAgaWYgKCFvcHRzLm9ubHlTZWxmKSB7XG4gICAgICB0aGlzLl9wYXJlbnQ/Lm1hcmtBc0RpcnR5KHtcbiAgICAgICAgLi4ub3B0cyxcbiAgICAgICAgc291cmNlQ29udHJvbFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChjaGFuZ2VkICYmIG9wdHMuZW1pdEV2ZW50ICE9PSBmYWxzZSkge1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFByaXN0aW5lQ2hhbmdlRXZlbnQoZmFsc2UsIHNvdXJjZUNvbnRyb2wpKTtcbiAgICB9XG4gIH1cbiAgbWFya0FzUHJpc3RpbmUob3B0cyA9IHt9KSB7XG4gICAgY29uc3QgY2hhbmdlZCA9IHRoaXMucHJpc3RpbmUgPT09IGZhbHNlO1xuICAgIHRoaXMucHJpc3RpbmUgPSB0cnVlO1xuICAgIHRoaXMuX3BlbmRpbmdEaXJ0eSA9IGZhbHNlO1xuICAgIGNvbnN0IHNvdXJjZUNvbnRyb2wgPSBvcHRzLnNvdXJjZUNvbnRyb2wgPz8gdGhpcztcbiAgICB0aGlzLl9mb3JFYWNoQ2hpbGQoY29udHJvbCA9PiB7XG4gICAgICBjb250cm9sLm1hcmtBc1ByaXN0aW5lKHtcbiAgICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICAgIGVtaXRFdmVudDogb3B0cy5lbWl0RXZlbnRcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGlmICghb3B0cy5vbmx5U2VsZikge1xuICAgICAgdGhpcy5fcGFyZW50Py5fdXBkYXRlUHJpc3RpbmUob3B0cywgc291cmNlQ29udHJvbCk7XG4gICAgfVxuICAgIGlmIChjaGFuZ2VkICYmIG9wdHMuZW1pdEV2ZW50ICE9PSBmYWxzZSkge1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFByaXN0aW5lQ2hhbmdlRXZlbnQodHJ1ZSwgc291cmNlQ29udHJvbCkpO1xuICAgIH1cbiAgfVxuICBtYXJrQXNQZW5kaW5nKG9wdHMgPSB7fSkge1xuICAgIHRoaXMuc3RhdHVzID0gUEVORElORztcbiAgICBjb25zdCBzb3VyY2VDb250cm9sID0gb3B0cy5zb3VyY2VDb250cm9sID8/IHRoaXM7XG4gICAgaWYgKG9wdHMuZW1pdEV2ZW50ICE9PSBmYWxzZSkge1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFN0YXR1c0NoYW5nZUV2ZW50KHRoaXMuc3RhdHVzLCBzb3VyY2VDb250cm9sKSk7XG4gICAgICB0aGlzLnN0YXR1c0NoYW5nZXMuZW1pdCh0aGlzLnN0YXR1cyk7XG4gICAgfVxuICAgIGlmICghb3B0cy5vbmx5U2VsZikge1xuICAgICAgdGhpcy5fcGFyZW50Py5tYXJrQXNQZW5kaW5nKHtcbiAgICAgICAgLi4ub3B0cyxcbiAgICAgICAgc291cmNlQ29udHJvbFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGRpc2FibGUob3B0cyA9IHt9KSB7XG4gICAgY29uc3Qgc2tpcFByaXN0aW5lQ2hlY2sgPSB0aGlzLl9wYXJlbnRNYXJrZWREaXJ0eShvcHRzLm9ubHlTZWxmKTtcbiAgICB0aGlzLnN0YXR1cyA9IERJU0FCTEVEO1xuICAgIHRoaXMuZXJyb3JzID0gbnVsbDtcbiAgICB0aGlzLl9mb3JFYWNoQ2hpbGQoY29udHJvbCA9PiB7XG4gICAgICBjb250cm9sLmRpc2FibGUoe1xuICAgICAgICAuLi5vcHRzLFxuICAgICAgICBvbmx5U2VsZjogdHJ1ZVxuICAgICAgfSk7XG4gICAgfSk7XG4gICAgdGhpcy5fdXBkYXRlVmFsdWUoKTtcbiAgICBjb25zdCBzb3VyY2VDb250cm9sID0gb3B0cy5zb3VyY2VDb250cm9sID8/IHRoaXM7XG4gICAgaWYgKG9wdHMuZW1pdEV2ZW50ICE9PSBmYWxzZSkge1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFZhbHVlQ2hhbmdlRXZlbnQodGhpcy52YWx1ZSwgc291cmNlQ29udHJvbCkpO1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFN0YXR1c0NoYW5nZUV2ZW50KHRoaXMuc3RhdHVzLCBzb3VyY2VDb250cm9sKSk7XG4gICAgICB0aGlzLnZhbHVlQ2hhbmdlcy5lbWl0KHRoaXMudmFsdWUpO1xuICAgICAgdGhpcy5zdGF0dXNDaGFuZ2VzLmVtaXQodGhpcy5zdGF0dXMpO1xuICAgIH1cbiAgICB0aGlzLl91cGRhdGVBbmNlc3RvcnMoe1xuICAgICAgLi4ub3B0cyxcbiAgICAgIHNraXBQcmlzdGluZUNoZWNrXG4gICAgfSwgdGhpcyk7XG4gICAgdGhpcy5fb25EaXNhYmxlZENoYW5nZS5mb3JFYWNoKGNoYW5nZUZuID0+IGNoYW5nZUZuKHRydWUpKTtcbiAgfVxuICBlbmFibGUob3B0cyA9IHt9KSB7XG4gICAgY29uc3Qgc2tpcFByaXN0aW5lQ2hlY2sgPSB0aGlzLl9wYXJlbnRNYXJrZWREaXJ0eShvcHRzLm9ubHlTZWxmKTtcbiAgICB0aGlzLnN0YXR1cyA9IFZBTElEO1xuICAgIHRoaXMuX2ZvckVhY2hDaGlsZChjb250cm9sID0+IHtcbiAgICAgIGNvbnRyb2wuZW5hYmxlKHtcbiAgICAgICAgLi4ub3B0cyxcbiAgICAgICAgb25seVNlbGY6IHRydWVcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHRoaXMudXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7XG4gICAgICBvbmx5U2VsZjogdHJ1ZSxcbiAgICAgIGVtaXRFdmVudDogb3B0cy5lbWl0RXZlbnRcbiAgICB9KTtcbiAgICB0aGlzLl91cGRhdGVBbmNlc3RvcnMoe1xuICAgICAgLi4ub3B0cyxcbiAgICAgIHNraXBQcmlzdGluZUNoZWNrXG4gICAgfSwgdGhpcyk7XG4gICAgdGhpcy5fb25EaXNhYmxlZENoYW5nZS5mb3JFYWNoKGNoYW5nZUZuID0+IGNoYW5nZUZuKGZhbHNlKSk7XG4gIH1cbiAgX3VwZGF0ZUFuY2VzdG9ycyhvcHRzLCBzb3VyY2VDb250cm9sKSB7XG4gICAgaWYgKCFvcHRzLm9ubHlTZWxmKSB7XG4gICAgICB0aGlzLl9wYXJlbnQ/LnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkob3B0cyk7XG4gICAgICBpZiAoIW9wdHMuc2tpcFByaXN0aW5lQ2hlY2spIHtcbiAgICAgICAgdGhpcy5fcGFyZW50Py5fdXBkYXRlUHJpc3RpbmUoe30sIHNvdXJjZUNvbnRyb2wpO1xuICAgICAgfVxuICAgICAgdGhpcy5fcGFyZW50Py5fdXBkYXRlVG91Y2hlZCh7fSwgc291cmNlQ29udHJvbCk7XG4gICAgfVxuICB9XG4gIHNldFBhcmVudChwYXJlbnQpIHtcbiAgICB0aGlzLl9wYXJlbnQgPSBwYXJlbnQ7XG4gIH1cbiAgZ2V0UmF3VmFsdWUoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsdWU7XG4gIH1cbiAgdXBkYXRlVmFsdWVBbmRWYWxpZGl0eShvcHRzID0ge30pIHtcbiAgICB0aGlzLl9zZXRJbml0aWFsU3RhdHVzKCk7XG4gICAgdGhpcy5fdXBkYXRlVmFsdWUoKTtcbiAgICBpZiAodGhpcy5lbmFibGVkKSB7XG4gICAgICBjb25zdCBzaG91bGRIYXZlRW1pdHRlZCA9IHRoaXMuX2NhbmNlbEV4aXN0aW5nU3Vic2NyaXB0aW9uKCk7XG4gICAgICB0aGlzLmVycm9ycyA9IHRoaXMuX3J1blZhbGlkYXRvcigpO1xuICAgICAgdGhpcy5zdGF0dXMgPSB0aGlzLl9jYWxjdWxhdGVTdGF0dXMoKTtcbiAgICAgIGlmICh0aGlzLnN0YXR1cyA9PT0gVkFMSUQgfHwgdGhpcy5zdGF0dXMgPT09IFBFTkRJTkcpIHtcbiAgICAgICAgdGhpcy5fcnVuQXN5bmNWYWxpZGF0b3Ioc2hvdWxkSGF2ZUVtaXR0ZWQsIG9wdHMuZW1pdEV2ZW50KTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc291cmNlQ29udHJvbCA9IG9wdHMuc291cmNlQ29udHJvbCA/PyB0aGlzO1xuICAgIGlmIChvcHRzLmVtaXRFdmVudCAhPT0gZmFsc2UpIHtcbiAgICAgIHRoaXMuX2V2ZW50cy5uZXh0KG5ldyBWYWx1ZUNoYW5nZUV2ZW50KHRoaXMudmFsdWUsIHNvdXJjZUNvbnRyb2wpKTtcbiAgICAgIHRoaXMuX2V2ZW50cy5uZXh0KG5ldyBTdGF0dXNDaGFuZ2VFdmVudCh0aGlzLnN0YXR1cywgc291cmNlQ29udHJvbCkpO1xuICAgICAgdGhpcy52YWx1ZUNoYW5nZXMuZW1pdCh0aGlzLnZhbHVlKTtcbiAgICAgIHRoaXMuc3RhdHVzQ2hhbmdlcy5lbWl0KHRoaXMuc3RhdHVzKTtcbiAgICB9XG4gICAgaWYgKCFvcHRzLm9ubHlTZWxmKSB7XG4gICAgICB0aGlzLl9wYXJlbnQ/LnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgICAuLi5vcHRzLFxuICAgICAgICBzb3VyY2VDb250cm9sXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgX3VwZGF0ZVRyZWVWYWxpZGl0eShvcHRzID0ge1xuICAgIGVtaXRFdmVudDogdHJ1ZVxuICB9KSB7XG4gICAgdGhpcy5fZm9yRWFjaENoaWxkKGN0cmwgPT4gY3RybC5fdXBkYXRlVHJlZVZhbGlkaXR5KG9wdHMpKTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICBlbWl0RXZlbnQ6IG9wdHMuZW1pdEV2ZW50XG4gICAgfSk7XG4gIH1cbiAgX3NldEluaXRpYWxTdGF0dXMoKSB7XG4gICAgdGhpcy5zdGF0dXMgPSB0aGlzLl9hbGxDb250cm9sc0Rpc2FibGVkKCkgPyBESVNBQkxFRCA6IFZBTElEO1xuICB9XG4gIF9ydW5WYWxpZGF0b3IoKSB7XG4gICAgcmV0dXJuIHRoaXMudmFsaWRhdG9yID8gdGhpcy52YWxpZGF0b3IodGhpcykgOiBudWxsO1xuICB9XG4gIF9ydW5Bc3luY1ZhbGlkYXRvcihzaG91bGRIYXZlRW1pdHRlZCwgZW1pdEV2ZW50KSB7XG4gICAgaWYgKHRoaXMuYXN5bmNWYWxpZGF0b3IpIHtcbiAgICAgIHRoaXMuc3RhdHVzID0gUEVORElORztcbiAgICAgIHRoaXMuX2hhc093blBlbmRpbmdBc3luY1ZhbGlkYXRvciA9IHtcbiAgICAgICAgZW1pdEV2ZW50OiBlbWl0RXZlbnQgIT09IGZhbHNlLFxuICAgICAgICBzaG91bGRIYXZlRW1pdHRlZDogc2hvdWxkSGF2ZUVtaXR0ZWQgIT09IGZhbHNlXG4gICAgICB9O1xuICAgICAgY29uc3Qgb2JzID0gdG9PYnNlcnZhYmxlKHRoaXMuYXN5bmNWYWxpZGF0b3IodGhpcykpO1xuICAgICAgdGhpcy5fYXN5bmNWYWxpZGF0aW9uU3Vic2NyaXB0aW9uID0gb2JzLnN1YnNjcmliZShlcnJvcnMgPT4ge1xuICAgICAgICB0aGlzLl9oYXNPd25QZW5kaW5nQXN5bmNWYWxpZGF0b3IgPSBudWxsO1xuICAgICAgICB0aGlzLnNldEVycm9ycyhlcnJvcnMsIHtcbiAgICAgICAgICBlbWl0RXZlbnQsXG4gICAgICAgICAgc2hvdWxkSGF2ZUVtaXR0ZWRcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgX2NhbmNlbEV4aXN0aW5nU3Vic2NyaXB0aW9uKCkge1xuICAgIGlmICh0aGlzLl9hc3luY1ZhbGlkYXRpb25TdWJzY3JpcHRpb24pIHtcbiAgICAgIHRoaXMuX2FzeW5jVmFsaWRhdGlvblN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgY29uc3Qgc2hvdWxkSGF2ZUVtaXR0ZWQgPSAodGhpcy5faGFzT3duUGVuZGluZ0FzeW5jVmFsaWRhdG9yPy5lbWl0RXZlbnQgfHwgdGhpcy5faGFzT3duUGVuZGluZ0FzeW5jVmFsaWRhdG9yPy5zaG91bGRIYXZlRW1pdHRlZCkgPz8gZmFsc2U7XG4gICAgICB0aGlzLl9oYXNPd25QZW5kaW5nQXN5bmNWYWxpZGF0b3IgPSBudWxsO1xuICAgICAgcmV0dXJuIHNob3VsZEhhdmVFbWl0dGVkO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgc2V0RXJyb3JzKGVycm9ycywgb3B0cyA9IHt9KSB7XG4gICAgdGhpcy5lcnJvcnMgPSBlcnJvcnM7XG4gICAgdGhpcy5fdXBkYXRlQ29udHJvbHNFcnJvcnMob3B0cy5lbWl0RXZlbnQgIT09IGZhbHNlLCB0aGlzLCBvcHRzLnNob3VsZEhhdmVFbWl0dGVkKTtcbiAgfVxuICBnZXQocGF0aCkge1xuICAgIGxldCBjdXJyUGF0aCA9IHBhdGg7XG4gICAgaWYgKGN1cnJQYXRoID09IG51bGwpIHJldHVybiBudWxsO1xuICAgIGlmICghQXJyYXkuaXNBcnJheShjdXJyUGF0aCkpIGN1cnJQYXRoID0gY3VyclBhdGguc3BsaXQoJy4nKTtcbiAgICBpZiAoY3VyclBhdGgubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gY3VyclBhdGgucmVkdWNlKChjb250cm9sLCBuYW1lKSA9PiBjb250cm9sICYmIGNvbnRyb2wuX2ZpbmQobmFtZSksIHRoaXMpO1xuICB9XG4gIGdldEVycm9yKGVycm9yQ29kZSwgcGF0aCkge1xuICAgIGNvbnN0IGNvbnRyb2wgPSBwYXRoID8gdGhpcy5nZXQocGF0aCkgOiB0aGlzO1xuICAgIHJldHVybiBjb250cm9sPy5lcnJvcnMgPyBjb250cm9sLmVycm9yc1tlcnJvckNvZGVdIDogbnVsbDtcbiAgfVxuICBoYXNFcnJvcihlcnJvckNvZGUsIHBhdGgpIHtcbiAgICByZXR1cm4gISF0aGlzLmdldEVycm9yKGVycm9yQ29kZSwgcGF0aCk7XG4gIH1cbiAgZ2V0IHJvb3QoKSB7XG4gICAgbGV0IHggPSB0aGlzO1xuICAgIHdoaWxlICh4Ll9wYXJlbnQpIHtcbiAgICAgIHggPSB4Ll9wYXJlbnQ7XG4gICAgfVxuICAgIHJldHVybiB4O1xuICB9XG4gIF91cGRhdGVDb250cm9sc0Vycm9ycyhlbWl0RXZlbnQsIGNoYW5nZWRDb250cm9sLCBzaG91bGRIYXZlRW1pdHRlZCkge1xuICAgIHRoaXMuc3RhdHVzID0gdGhpcy5fY2FsY3VsYXRlU3RhdHVzKCk7XG4gICAgaWYgKGVtaXRFdmVudCkge1xuICAgICAgdGhpcy5zdGF0dXNDaGFuZ2VzLmVtaXQodGhpcy5zdGF0dXMpO1xuICAgIH1cbiAgICBpZiAoZW1pdEV2ZW50IHx8IHNob3VsZEhhdmVFbWl0dGVkKSB7XG4gICAgICB0aGlzLl9ldmVudHMubmV4dChuZXcgU3RhdHVzQ2hhbmdlRXZlbnQodGhpcy5zdGF0dXMsIGNoYW5nZWRDb250cm9sKSk7XG4gICAgfVxuICAgIGlmICh0aGlzLl9wYXJlbnQpIHtcbiAgICAgIHRoaXMuX3BhcmVudC5fdXBkYXRlQ29udHJvbHNFcnJvcnMoZW1pdEV2ZW50LCBjaGFuZ2VkQ29udHJvbCwgc2hvdWxkSGF2ZUVtaXR0ZWQpO1xuICAgIH1cbiAgfVxuICBfaW5pdE9ic2VydmFibGVzKCkge1xuICAgIHRoaXMudmFsdWVDaGFuZ2VzID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICAgIHRoaXMuc3RhdHVzQ2hhbmdlcyA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgfVxuICBfY2FsY3VsYXRlU3RhdHVzKCkge1xuICAgIGlmICh0aGlzLl9hbGxDb250cm9sc0Rpc2FibGVkKCkpIHJldHVybiBESVNBQkxFRDtcbiAgICBpZiAodGhpcy5lcnJvcnMpIHJldHVybiBJTlZBTElEO1xuICAgIGlmICh0aGlzLl9oYXNPd25QZW5kaW5nQXN5bmNWYWxpZGF0b3IgfHwgdGhpcy5fYW55Q29udHJvbHNIYXZlU3RhdHVzKFBFTkRJTkcpKSByZXR1cm4gUEVORElORztcbiAgICBpZiAodGhpcy5fYW55Q29udHJvbHNIYXZlU3RhdHVzKElOVkFMSUQpKSByZXR1cm4gSU5WQUxJRDtcbiAgICByZXR1cm4gVkFMSUQ7XG4gIH1cbiAgX2FueUNvbnRyb2xzSGF2ZVN0YXR1cyhzdGF0dXMpIHtcbiAgICByZXR1cm4gdGhpcy5fYW55Q29udHJvbHMoY29udHJvbCA9PiBjb250cm9sLnN0YXR1cyA9PT0gc3RhdHVzKTtcbiAgfVxuICBfYW55Q29udHJvbHNEaXJ0eSgpIHtcbiAgICByZXR1cm4gdGhpcy5fYW55Q29udHJvbHMoY29udHJvbCA9PiBjb250cm9sLmRpcnR5KTtcbiAgfVxuICBfYW55Q29udHJvbHNUb3VjaGVkKCkge1xuICAgIHJldHVybiB0aGlzLl9hbnlDb250cm9scyhjb250cm9sID0+IGNvbnRyb2wudG91Y2hlZCk7XG4gIH1cbiAgX3VwZGF0ZVByaXN0aW5lKG9wdHMsIGNoYW5nZWRDb250cm9sKSB7XG4gICAgY29uc3QgbmV3UHJpc3RpbmUgPSAhdGhpcy5fYW55Q29udHJvbHNEaXJ0eSgpO1xuICAgIGNvbnN0IGNoYW5nZWQgPSB0aGlzLnByaXN0aW5lICE9PSBuZXdQcmlzdGluZTtcbiAgICB0aGlzLnByaXN0aW5lID0gbmV3UHJpc3RpbmU7XG4gICAgaWYgKCFvcHRzLm9ubHlTZWxmKSB7XG4gICAgICB0aGlzLl9wYXJlbnQ/Ll91cGRhdGVQcmlzdGluZShvcHRzLCBjaGFuZ2VkQ29udHJvbCk7XG4gICAgfVxuICAgIGlmIChjaGFuZ2VkKSB7XG4gICAgICB0aGlzLl9ldmVudHMubmV4dChuZXcgUHJpc3RpbmVDaGFuZ2VFdmVudCh0aGlzLnByaXN0aW5lLCBjaGFuZ2VkQ29udHJvbCkpO1xuICAgIH1cbiAgfVxuICBfdXBkYXRlVG91Y2hlZChvcHRzID0ge30sIGNoYW5nZWRDb250cm9sKSB7XG4gICAgdGhpcy50b3VjaGVkID0gdGhpcy5fYW55Q29udHJvbHNUb3VjaGVkKCk7XG4gICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IFRvdWNoZWRDaGFuZ2VFdmVudCh0aGlzLnRvdWNoZWQsIGNoYW5nZWRDb250cm9sKSk7XG4gICAgaWYgKCFvcHRzLm9ubHlTZWxmKSB7XG4gICAgICB0aGlzLl9wYXJlbnQ/Ll91cGRhdGVUb3VjaGVkKG9wdHMsIGNoYW5nZWRDb250cm9sKTtcbiAgICB9XG4gIH1cbiAgX29uRGlzYWJsZWRDaGFuZ2UgPSBbXTtcbiAgX3JlZ2lzdGVyT25Db2xsZWN0aW9uQ2hhbmdlKGZuKSB7XG4gICAgdGhpcy5fb25Db2xsZWN0aW9uQ2hhbmdlID0gZm47XG4gIH1cbiAgX3NldFVwZGF0ZVN0cmF0ZWd5KG9wdHMpIHtcbiAgICBpZiAoaXNPcHRpb25zT2JqKG9wdHMpICYmIG9wdHMudXBkYXRlT24gIT0gbnVsbCkge1xuICAgICAgdGhpcy5fdXBkYXRlT24gPSBvcHRzLnVwZGF0ZU9uO1xuICAgIH1cbiAgfVxuICBfcGFyZW50TWFya2VkRGlydHkob25seVNlbGYpIHtcbiAgICByZXR1cm4gIW9ubHlTZWxmICYmICEhdGhpcy5fcGFyZW50Py5kaXJ0eSAmJiAhdGhpcy5fcGFyZW50Ll9hbnlDb250cm9sc0RpcnR5KCk7XG4gIH1cbiAgX2ZpbmQobmFtZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIF9hc3NpZ25WYWxpZGF0b3JzKHZhbGlkYXRvcnMpIHtcbiAgICB0aGlzLl9yYXdWYWxpZGF0b3JzID0gQXJyYXkuaXNBcnJheSh2YWxpZGF0b3JzKSA/IHZhbGlkYXRvcnMuc2xpY2UoKSA6IHZhbGlkYXRvcnM7XG4gICAgdGhpcy5fY29tcG9zZWRWYWxpZGF0b3JGbiA9IGNvZXJjZVRvVmFsaWRhdG9yKHRoaXMuX3Jhd1ZhbGlkYXRvcnMpO1xuICAgIHRoaXMuX3VwZGF0ZUhhc1JlcXVpcmVkVmFsaWRhdG9yKCk7XG4gIH1cbiAgX2Fzc2lnbkFzeW5jVmFsaWRhdG9ycyh2YWxpZGF0b3JzKSB7XG4gICAgdGhpcy5fcmF3QXN5bmNWYWxpZGF0b3JzID0gQXJyYXkuaXNBcnJheSh2YWxpZGF0b3JzKSA/IHZhbGlkYXRvcnMuc2xpY2UoKSA6IHZhbGlkYXRvcnM7XG4gICAgdGhpcy5fY29tcG9zZWRBc3luY1ZhbGlkYXRvckZuID0gY29lcmNlVG9Bc3luY1ZhbGlkYXRvcih0aGlzLl9yYXdBc3luY1ZhbGlkYXRvcnMpO1xuICB9XG4gIF91cGRhdGVIYXNSZXF1aXJlZFZhbGlkYXRvcigpIHtcbiAgICB1bnRyYWNrZWQoKCkgPT4gdGhpcy5faGFzUmVxdWlyZWQuc2V0KHRoaXMuaGFzVmFsaWRhdG9yKFZhbGlkYXRvcnMucmVxdWlyZWQpKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhc093bkNvbnRyb2woY29udHJvbHMsIG5hbWUpIHtcbiAgcmV0dXJuIE9iamVjdC5oYXNPd24oY29udHJvbHMsIG5hbWUpO1xufVxuZnVuY3Rpb24gaXNOYXRpdmVGb3JtRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50LnRhZ05hbWUgPT09ICdJTlBVVCcgfHwgZWxlbWVudC50YWdOYW1lID09PSAnU0VMRUNUJyB8fCBlbGVtZW50LnRhZ05hbWUgPT09ICdURVhUQVJFQSc7XG59XG5mdW5jdGlvbiBlbGVtZW50QWNjZXB0c01pbk1heChlbGVtZW50KSB7XG4gIGlmIChlbGVtZW50LnRhZ05hbWUgIT09ICdJTlBVVCcpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdHlwZSA9IGVsZW1lbnQudHlwZTtcbiAgcmV0dXJuIHR5cGUgPT09ICdudW1iZXInIHx8IHR5cGUgPT09ICdyYW5nZScgfHwgdHlwZSA9PT0gJ2RhdGUnIHx8IHR5cGUgPT09ICdtb250aCc7XG59XG5mdW5jdGlvbiBpc1RleHR1YWxGb3JtRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50LnRhZ05hbWUgPT09ICdJTlBVVCcgfHwgZWxlbWVudC50YWdOYW1lID09PSAnVEVYVEFSRUEnO1xufVxuZnVuY3Rpb24gc2V0TmF0aXZlRG9tUHJvcGVydHkocmVuZGVyZXIsIGVsZW1lbnQsIG5hbWUsIHZhbHVlKSB7XG4gIHN3aXRjaCAobmFtZSkge1xuICAgIGNhc2UgJ25hbWUnOlxuICAgICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKGVsZW1lbnQsIG5hbWUsIHZhbHVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2Rpc2FibGVkJzpcbiAgICBjYXNlICdyZWFkb25seSc6XG4gICAgY2FzZSAncmVxdWlyZWQnOlxuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIHJlbmRlcmVyLnNldEF0dHJpYnV0ZShlbGVtZW50LCBuYW1lLCAnJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZW5kZXJlci5yZW1vdmVBdHRyaWJ1dGUoZWxlbWVudCwgbmFtZSk7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICBjYXNlICdtYXgnOlxuICAgIGNhc2UgJ21pbic6XG4gICAgY2FzZSAnbWluTGVuZ3RoJzpcbiAgICBjYXNlICdtYXhMZW5ndGgnOlxuICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKGVsZW1lbnQsIG5hbWUsIHZhbHVlLnRvU3RyaW5nKCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVuZGVyZXIucmVtb3ZlQXR0cmlidXRlKGVsZW1lbnQsIG5hbWUpO1xuICAgICAgfVxuICAgICAgYnJlYWs7XG4gIH1cbn1cbmNsYXNzIFJlYWN0aXZlVmFsaWRhdGlvbkVycm9yIHtcbiAga2luZDtcbiAgY29udGV4dDtcbiAgY29udHJvbDtcbiAgbWVzc2FnZTtcbiAgY29uc3RydWN0b3Ioe1xuICAgIGtpbmQsXG4gICAgY29udGV4dCxcbiAgICBjb250cm9sXG4gIH0pIHtcbiAgICB0aGlzLmtpbmQgPSBraW5kO1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgdGhpcy5jb250cm9sID0gY29udHJvbDtcbiAgfVxufVxuZnVuY3Rpb24gdG9JbnRlZ2VyKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInID8gdmFsdWUgOiBwYXJzZUludCh2YWx1ZSwgMTApO1xufVxuZnVuY3Rpb24gdG9GbG9hdCh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJyA/IHZhbHVlIDogcGFyc2VGbG9hdCh2YWx1ZSk7XG59XG5jbGFzcyBBYnN0cmFjdFZhbGlkYXRvckRpcmVjdGl2ZSB7XG4gIF92YWxpZGF0b3IgPSBudWxsVmFsaWRhdG9yO1xuICBfb25DaGFuZ2U7XG4gIF9lbmFibGVkO1xuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzKSB7XG4gICAgaWYgKHRoaXMuaW5wdXROYW1lIGluIGNoYW5nZXMpIHtcbiAgICAgIGNvbnN0IGlucHV0ID0gdGhpcy5ub3JtYWxpemVJbnB1dChjaGFuZ2VzW3RoaXMuaW5wdXROYW1lXS5jdXJyZW50VmFsdWUpO1xuICAgICAgdGhpcy5fZW5hYmxlZCA9IHRoaXMuZW5hYmxlZChpbnB1dCk7XG4gICAgICB0aGlzLl92YWxpZGF0b3IgPSB0aGlzLl9lbmFibGVkID8gdGhpcy5jcmVhdGVWYWxpZGF0b3IoaW5wdXQpIDogbnVsbFZhbGlkYXRvcjtcbiAgICAgIHRoaXMuX29uQ2hhbmdlPy4oKTtcbiAgICB9XG4gIH1cbiAgdmFsaWRhdGUoY29udHJvbCkge1xuICAgIHJldHVybiB0aGlzLl92YWxpZGF0b3IoY29udHJvbCk7XG4gIH1cbiAgcmVnaXN0ZXJPblZhbGlkYXRvckNoYW5nZShmbikge1xuICAgIHRoaXMuX29uQ2hhbmdlID0gZm47XG4gIH1cbiAgZW5hYmxlZChpbnB1dCkge1xuICAgIHJldHVybiBpbnB1dCAhPSBudWxsO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEFic3RyYWN0VmFsaWRhdG9yRGlyZWN0aXZlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBBYnN0cmFjdFZhbGlkYXRvckRpcmVjdGl2ZSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogQWJzdHJhY3RWYWxpZGF0b3JEaXJlY3RpdmUsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEFic3RyYWN0VmFsaWRhdG9yRGlyZWN0aXZlLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY29uc3QgTUFYX1ZBTElEQVRPUiA9IHtcbiAgcHJvdmlkZTogTkdfVkFMSURBVE9SUyxcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gTWF4VmFsaWRhdG9yKSxcbiAgbXVsdGk6IHRydWVcbn07XG5jbGFzcyBNYXhWYWxpZGF0b3IgZXh0ZW5kcyBBYnN0cmFjdFZhbGlkYXRvckRpcmVjdGl2ZSB7XG4gIG1heDtcbiAgaW5wdXROYW1lID0gJ21heCc7XG4gIG5vcm1hbGl6ZUlucHV0ID0gaW5wdXQgPT4gdG9GbG9hdChpbnB1dCk7XG4gIGNyZWF0ZVZhbGlkYXRvciA9IG1heCA9PiBtYXhWYWxpZGF0b3IobWF4KTtcbiAgc3RhdGljIMm1ZmFjID0gLyogQF9fUFVSRV9fICovKCgpID0+IHtcbiAgICBsZXQgybVNYXhWYWxpZGF0b3JfQmFzZUZhY3Rvcnk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIE1heFZhbGlkYXRvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICByZXR1cm4gKMm1TWF4VmFsaWRhdG9yX0Jhc2VGYWN0b3J5IHx8ICjJtU1heFZhbGlkYXRvcl9CYXNlRmFjdG9yeSA9IGkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5KE1heFZhbGlkYXRvcikpKShfX25nRmFjdG9yeVR5cGVfXyB8fCBNYXhWYWxpZGF0b3IpO1xuICAgIH07XG4gIH0pKCk7XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE1heFZhbGlkYXRvcixcbiAgICBzZWxlY3RvcnM6IFtbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJudW1iZXJcIiwgXCJtYXhcIiwgXCJcIiwgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJcIl0sIFtcImlucHV0XCIsIFwidHlwZVwiLCBcIm51bWJlclwiLCBcIm1heFwiLCBcIlwiLCBcImZvcm1Db250cm9sXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJudW1iZXJcIiwgXCJtYXhcIiwgXCJcIiwgXCJuZ01vZGVsXCIsIFwiXCJdXSxcbiAgICBob3N0VmFyczogMSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIE1heFZhbGlkYXRvcl9Ib3N0QmluZGluZ3MocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YXR0cmlidXRlKFwibWF4XCIsIGN0eC5fZW5hYmxlZCA/IGN0eC5tYXggOiBudWxsKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgbWF4OiBcIm1heFwiXG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtNQVhfVkFMSURBVE9SXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTWF4VmFsaWRhdG9yLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdpbnB1dFt0eXBlPW51bWJlcl1bbWF4XVtmb3JtQ29udHJvbE5hbWVdLGlucHV0W3R5cGU9bnVtYmVyXVttYXhdW2Zvcm1Db250cm9sXSxpbnB1dFt0eXBlPW51bWJlcl1bbWF4XVtuZ01vZGVsXScsXG4gICAgICBwcm92aWRlcnM6IFtNQVhfVkFMSURBVE9SXSxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJ1thdHRyLm1heF0nOiAnX2VuYWJsZWQgPyBtYXggOiBudWxsJ1xuICAgICAgfSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICBtYXg6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNvbnN0IE1JTl9WQUxJREFUT1IgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTElEQVRPUlMsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IE1pblZhbGlkYXRvciksXG4gIG11bHRpOiB0cnVlXG59O1xuY2xhc3MgTWluVmFsaWRhdG9yIGV4dGVuZHMgQWJzdHJhY3RWYWxpZGF0b3JEaXJlY3RpdmUge1xuICBtaW47XG4gIGlucHV0TmFtZSA9ICdtaW4nO1xuICBub3JtYWxpemVJbnB1dCA9IGlucHV0ID0+IHRvRmxvYXQoaW5wdXQpO1xuICBjcmVhdGVWYWxpZGF0b3IgPSBtaW4gPT4gbWluVmFsaWRhdG9yKG1pbik7XG4gIHN0YXRpYyDJtWZhYyA9IC8qIEBfX1BVUkVfXyAqLygoKSA9PiB7XG4gICAgbGV0IMm1TWluVmFsaWRhdG9yX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBNaW5WYWxpZGF0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgcmV0dXJuICjJtU1pblZhbGlkYXRvcl9CYXNlRmFjdG9yeSB8fCAoybVNaW5WYWxpZGF0b3JfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShNaW5WYWxpZGF0b3IpKSkoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTWluVmFsaWRhdG9yKTtcbiAgICB9O1xuICB9KSgpO1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBNaW5WYWxpZGF0b3IsXG4gICAgc2VsZWN0b3JzOiBbW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwibnVtYmVyXCIsIFwibWluXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJudW1iZXJcIiwgXCJtaW5cIiwgXCJcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiXSwgW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwibnVtYmVyXCIsIFwibWluXCIsIFwiXCIsIFwibmdNb2RlbFwiLCBcIlwiXV0sXG4gICAgaG9zdFZhcnM6IDEsXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBNaW5WYWxpZGF0b3JfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWF0dHJpYnV0ZShcIm1pblwiLCBjdHguX2VuYWJsZWQgPyBjdHgubWluIDogbnVsbCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG1pbjogXCJtaW5cIlxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbTUlOX1ZBTElEQVRPUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE1pblZhbGlkYXRvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnaW5wdXRbdHlwZT1udW1iZXJdW21pbl1bZm9ybUNvbnRyb2xOYW1lXSxpbnB1dFt0eXBlPW51bWJlcl1bbWluXVtmb3JtQ29udHJvbF0saW5wdXRbdHlwZT1udW1iZXJdW21pbl1bbmdNb2RlbF0nLFxuICAgICAgcHJvdmlkZXJzOiBbTUlOX1ZBTElEQVRPUl0sXG4gICAgICBob3N0OiB7XG4gICAgICAgICdbYXR0ci5taW5dJzogJ19lbmFibGVkID8gbWluIDogbnVsbCdcbiAgICAgIH0sXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCBudWxsLCB7XG4gICAgbWluOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XVxuICB9KTtcbn0pKCk7XG5jb25zdCBSRVFVSVJFRF9WQUxJREFUT1IgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTElEQVRPUlMsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IFJlcXVpcmVkVmFsaWRhdG9yKSxcbiAgbXVsdGk6IHRydWVcbn07XG5jb25zdCBDSEVDS0JPWF9SRVFVSVJFRF9WQUxJREFUT1IgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTElEQVRPUlMsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IpLFxuICBtdWx0aTogdHJ1ZVxufTtcbmNsYXNzIFJlcXVpcmVkVmFsaWRhdG9yIGV4dGVuZHMgQWJzdHJhY3RWYWxpZGF0b3JEaXJlY3RpdmUge1xuICByZXF1aXJlZDtcbiAgaW5wdXROYW1lID0gJ3JlcXVpcmVkJztcbiAgbm9ybWFsaXplSW5wdXQgPSBib29sZWFuQXR0cmlidXRlO1xuICBjcmVhdGVWYWxpZGF0b3IgPSBpbnB1dCA9PiByZXF1aXJlZFZhbGlkYXRvcjtcbiAgZW5hYmxlZChpbnB1dCkge1xuICAgIHJldHVybiBpbnB1dDtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtVJlcXVpcmVkVmFsaWRhdG9yX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBSZXF1aXJlZFZhbGlkYXRvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICByZXR1cm4gKMm1UmVxdWlyZWRWYWxpZGF0b3JfQmFzZUZhY3RvcnkgfHwgKMm1UmVxdWlyZWRWYWxpZGF0b3JfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShSZXF1aXJlZFZhbGlkYXRvcikpKShfX25nRmFjdG9yeVR5cGVfXyB8fCBSZXF1aXJlZFZhbGlkYXRvcik7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogUmVxdWlyZWRWYWxpZGF0b3IsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwicmVxdWlyZWRcIiwgXCJcIiwgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJcIiwgMywgXCJ0eXBlXCIsIFwiY2hlY2tib3hcIl0sIFtcIlwiLCBcInJlcXVpcmVkXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xcIiwgXCJcIiwgMywgXCJ0eXBlXCIsIFwiY2hlY2tib3hcIl0sIFtcIlwiLCBcInJlcXVpcmVkXCIsIFwiXCIsIFwibmdNb2RlbFwiLCBcIlwiLCAzLCBcInR5cGVcIiwgXCJjaGVja2JveFwiXV0sXG4gICAgaG9zdFZhcnM6IDEsXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBSZXF1aXJlZFZhbGlkYXRvcl9Ib3N0QmluZGluZ3MocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YXR0cmlidXRlKFwicmVxdWlyZWRcIiwgY3R4Ll9lbmFibGVkID8gXCJcIiA6IG51bGwpO1xuICAgICAgfVxuICAgIH0sXG4gICAgaW5wdXRzOiB7XG4gICAgICByZXF1aXJlZDogXCJyZXF1aXJlZFwiXG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtSRVFVSVJFRF9WQUxJREFUT1JdKSwgaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShSZXF1aXJlZFZhbGlkYXRvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnOm5vdChbdHlwZT1jaGVja2JveF0pW3JlcXVpcmVkXVtmb3JtQ29udHJvbE5hbWVdLDpub3QoW3R5cGU9Y2hlY2tib3hdKVtyZXF1aXJlZF1bZm9ybUNvbnRyb2xdLDpub3QoW3R5cGU9Y2hlY2tib3hdKVtyZXF1aXJlZF1bbmdNb2RlbF0nLFxuICAgICAgcHJvdmlkZXJzOiBbUkVRVUlSRURfVkFMSURBVE9SXSxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJ1thdHRyLnJlcXVpcmVkXSc6ICdfZW5hYmxlZCA/IFwiXCIgOiBudWxsJ1xuICAgICAgfSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICByZXF1aXJlZDogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY2xhc3MgQ2hlY2tib3hSZXF1aXJlZFZhbGlkYXRvciBleHRlbmRzIFJlcXVpcmVkVmFsaWRhdG9yIHtcbiAgY3JlYXRlVmFsaWRhdG9yID0gaW5wdXQgPT4gcmVxdWlyZWRUcnVlVmFsaWRhdG9yO1xuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtUNoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3JfQmFzZUZhY3Rvcnk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgcmV0dXJuICjJtUNoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3JfQmFzZUZhY3RvcnkgfHwgKMm1Q2hlY2tib3hSZXF1aXJlZFZhbGlkYXRvcl9CYXNlRmFjdG9yeSA9IGkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5KENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IpKSkoX19uZ0ZhY3RvcnlUeXBlX18gfHwgQ2hlY2tib3hSZXF1aXJlZFZhbGlkYXRvcik7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogQ2hlY2tib3hSZXF1aXJlZFZhbGlkYXRvcixcbiAgICBzZWxlY3RvcnM6IFtbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJjaGVja2JveFwiLCBcInJlcXVpcmVkXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJjaGVja2JveFwiLCBcInJlcXVpcmVkXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xcIiwgXCJcIl0sIFtcImlucHV0XCIsIFwidHlwZVwiLCBcImNoZWNrYm94XCIsIFwicmVxdWlyZWRcIiwgXCJcIiwgXCJuZ01vZGVsXCIsIFwiXCJdXSxcbiAgICBob3N0VmFyczogMSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3JfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWF0dHJpYnV0ZShcInJlcXVpcmVkXCIsIGN0eC5fZW5hYmxlZCA/IFwiXCIgOiBudWxsKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW0NIRUNLQk9YX1JFUVVJUkVEX1ZBTElEQVRPUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ2lucHV0W3R5cGU9Y2hlY2tib3hdW3JlcXVpcmVkXVtmb3JtQ29udHJvbE5hbWVdLGlucHV0W3R5cGU9Y2hlY2tib3hdW3JlcXVpcmVkXVtmb3JtQ29udHJvbF0saW5wdXRbdHlwZT1jaGVja2JveF1bcmVxdWlyZWRdW25nTW9kZWxdJyxcbiAgICAgIHByb3ZpZGVyczogW0NIRUNLQk9YX1JFUVVJUkVEX1ZBTElEQVRPUl0sXG4gICAgICBob3N0OiB7XG4gICAgICAgICdbYXR0ci5yZXF1aXJlZF0nOiAnX2VuYWJsZWQgPyBcIlwiIDogbnVsbCdcbiAgICAgIH0sXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jb25zdCBFTUFJTF9WQUxJREFUT1IgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTElEQVRPUlMsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IEVtYWlsVmFsaWRhdG9yKSxcbiAgbXVsdGk6IHRydWVcbn07XG5jbGFzcyBFbWFpbFZhbGlkYXRvciBleHRlbmRzIEFic3RyYWN0VmFsaWRhdG9yRGlyZWN0aXZlIHtcbiAgZW1haWw7XG4gIGlucHV0TmFtZSA9ICdlbWFpbCc7XG4gIG5vcm1hbGl6ZUlucHV0ID0gYm9vbGVhbkF0dHJpYnV0ZTtcbiAgY3JlYXRlVmFsaWRhdG9yID0gaW5wdXQgPT4gZW1haWxWYWxpZGF0b3I7XG4gIGVuYWJsZWQoaW5wdXQpIHtcbiAgICByZXR1cm4gaW5wdXQ7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gLyogQF9fUFVSRV9fICovKCgpID0+IHtcbiAgICBsZXQgybVFbWFpbFZhbGlkYXRvcl9CYXNlRmFjdG9yeTtcbiAgICByZXR1cm4gZnVuY3Rpb24gRW1haWxWYWxpZGF0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgcmV0dXJuICjJtUVtYWlsVmFsaWRhdG9yX0Jhc2VGYWN0b3J5IHx8ICjJtUVtYWlsVmFsaWRhdG9yX0Jhc2VGYWN0b3J5ID0gaTAuybXJtWdldEluaGVyaXRlZEZhY3RvcnkoRW1haWxWYWxpZGF0b3IpKSkoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRW1haWxWYWxpZGF0b3IpO1xuICAgIH07XG4gIH0pKCk7XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IEVtYWlsVmFsaWRhdG9yLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcImVtYWlsXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJcIiwgXCJlbWFpbFwiLCBcIlwiLCBcImZvcm1Db250cm9sXCIsIFwiXCJdLCBbXCJcIiwgXCJlbWFpbFwiLCBcIlwiLCBcIm5nTW9kZWxcIiwgXCJcIl1dLFxuICAgIGlucHV0czoge1xuICAgICAgZW1haWw6IFwiZW1haWxcIlxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbRU1BSUxfVkFMSURBVE9SXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRW1haWxWYWxpZGF0b3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tlbWFpbF1bZm9ybUNvbnRyb2xOYW1lXSxbZW1haWxdW2Zvcm1Db250cm9sXSxbZW1haWxdW25nTW9kZWxdJyxcbiAgICAgIHByb3ZpZGVyczogW0VNQUlMX1ZBTElEQVRPUl0sXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCBudWxsLCB7XG4gICAgZW1haWw6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNvbnN0IE1JTl9MRU5HVEhfVkFMSURBVE9SID0ge1xuICBwcm92aWRlOiBOR19WQUxJREFUT1JTLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBNaW5MZW5ndGhWYWxpZGF0b3IpLFxuICBtdWx0aTogdHJ1ZVxufTtcbmNsYXNzIE1pbkxlbmd0aFZhbGlkYXRvciBleHRlbmRzIEFic3RyYWN0VmFsaWRhdG9yRGlyZWN0aXZlIHtcbiAgbWlubGVuZ3RoO1xuICBpbnB1dE5hbWUgPSAnbWlubGVuZ3RoJztcbiAgbm9ybWFsaXplSW5wdXQgPSBpbnB1dCA9PiB0b0ludGVnZXIoaW5wdXQpO1xuICBjcmVhdGVWYWxpZGF0b3IgPSBtaW5sZW5ndGggPT4gbWluTGVuZ3RoVmFsaWRhdG9yKG1pbmxlbmd0aCk7XG4gIHN0YXRpYyDJtWZhYyA9IC8qIEBfX1BVUkVfXyAqLygoKSA9PiB7XG4gICAgbGV0IMm1TWluTGVuZ3RoVmFsaWRhdG9yX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBNaW5MZW5ndGhWYWxpZGF0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgcmV0dXJuICjJtU1pbkxlbmd0aFZhbGlkYXRvcl9CYXNlRmFjdG9yeSB8fCAoybVNaW5MZW5ndGhWYWxpZGF0b3JfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShNaW5MZW5ndGhWYWxpZGF0b3IpKSkoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTWluTGVuZ3RoVmFsaWRhdG9yKTtcbiAgICB9O1xuICB9KSgpO1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBNaW5MZW5ndGhWYWxpZGF0b3IsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwibWlubGVuZ3RoXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJcIiwgXCJtaW5sZW5ndGhcIiwgXCJcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiXSwgW1wiXCIsIFwibWlubGVuZ3RoXCIsIFwiXCIsIFwibmdNb2RlbFwiLCBcIlwiXV0sXG4gICAgaG9zdFZhcnM6IDEsXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBNaW5MZW5ndGhWYWxpZGF0b3JfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWF0dHJpYnV0ZShcIm1pbmxlbmd0aFwiLCBjdHguX2VuYWJsZWQgPyBjdHgubWlubGVuZ3RoIDogbnVsbCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG1pbmxlbmd0aDogXCJtaW5sZW5ndGhcIlxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbTUlOX0xFTkdUSF9WQUxJREFUT1JdKSwgaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShNaW5MZW5ndGhWYWxpZGF0b3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1ttaW5sZW5ndGhdW2Zvcm1Db250cm9sTmFtZV0sW21pbmxlbmd0aF1bZm9ybUNvbnRyb2xdLFttaW5sZW5ndGhdW25nTW9kZWxdJyxcbiAgICAgIHByb3ZpZGVyczogW01JTl9MRU5HVEhfVkFMSURBVE9SXSxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJ1thdHRyLm1pbmxlbmd0aF0nOiAnX2VuYWJsZWQgPyBtaW5sZW5ndGggOiBudWxsJ1xuICAgICAgfSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICBtaW5sZW5ndGg6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNvbnN0IE1BWF9MRU5HVEhfVkFMSURBVE9SID0ge1xuICBwcm92aWRlOiBOR19WQUxJREFUT1JTLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBNYXhMZW5ndGhWYWxpZGF0b3IpLFxuICBtdWx0aTogdHJ1ZVxufTtcbmNsYXNzIE1heExlbmd0aFZhbGlkYXRvciBleHRlbmRzIEFic3RyYWN0VmFsaWRhdG9yRGlyZWN0aXZlIHtcbiAgbWF4bGVuZ3RoO1xuICBpbnB1dE5hbWUgPSAnbWF4bGVuZ3RoJztcbiAgbm9ybWFsaXplSW5wdXQgPSBpbnB1dCA9PiB0b0ludGVnZXIoaW5wdXQpO1xuICBjcmVhdGVWYWxpZGF0b3IgPSBtYXhsZW5ndGggPT4gbWF4TGVuZ3RoVmFsaWRhdG9yKG1heGxlbmd0aCk7XG4gIHN0YXRpYyDJtWZhYyA9IC8qIEBfX1BVUkVfXyAqLygoKSA9PiB7XG4gICAgbGV0IMm1TWF4TGVuZ3RoVmFsaWRhdG9yX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBNYXhMZW5ndGhWYWxpZGF0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgcmV0dXJuICjJtU1heExlbmd0aFZhbGlkYXRvcl9CYXNlRmFjdG9yeSB8fCAoybVNYXhMZW5ndGhWYWxpZGF0b3JfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShNYXhMZW5ndGhWYWxpZGF0b3IpKSkoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTWF4TGVuZ3RoVmFsaWRhdG9yKTtcbiAgICB9O1xuICB9KSgpO1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBNYXhMZW5ndGhWYWxpZGF0b3IsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwibWF4bGVuZ3RoXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJcIiwgXCJtYXhsZW5ndGhcIiwgXCJcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiXSwgW1wiXCIsIFwibWF4bGVuZ3RoXCIsIFwiXCIsIFwibmdNb2RlbFwiLCBcIlwiXV0sXG4gICAgaG9zdFZhcnM6IDEsXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBNYXhMZW5ndGhWYWxpZGF0b3JfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWF0dHJpYnV0ZShcIm1heGxlbmd0aFwiLCBjdHguX2VuYWJsZWQgPyBjdHgubWF4bGVuZ3RoIDogbnVsbCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG1heGxlbmd0aDogXCJtYXhsZW5ndGhcIlxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbTUFYX0xFTkdUSF9WQUxJREFUT1JdKSwgaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShNYXhMZW5ndGhWYWxpZGF0b3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1ttYXhsZW5ndGhdW2Zvcm1Db250cm9sTmFtZV0sW21heGxlbmd0aF1bZm9ybUNvbnRyb2xdLFttYXhsZW5ndGhdW25nTW9kZWxdJyxcbiAgICAgIHByb3ZpZGVyczogW01BWF9MRU5HVEhfVkFMSURBVE9SXSxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJ1thdHRyLm1heGxlbmd0aF0nOiAnX2VuYWJsZWQgPyBtYXhsZW5ndGggOiBudWxsJ1xuICAgICAgfSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICBtYXhsZW5ndGg6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNvbnN0IFBBVFRFUk5fVkFMSURBVE9SID0ge1xuICBwcm92aWRlOiBOR19WQUxJREFUT1JTLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBQYXR0ZXJuVmFsaWRhdG9yKSxcbiAgbXVsdGk6IHRydWVcbn07XG5jbGFzcyBQYXR0ZXJuVmFsaWRhdG9yIGV4dGVuZHMgQWJzdHJhY3RWYWxpZGF0b3JEaXJlY3RpdmUge1xuICBwYXR0ZXJuO1xuICBpbnB1dE5hbWUgPSAncGF0dGVybic7XG4gIG5vcm1hbGl6ZUlucHV0ID0gaW5wdXQgPT4gaW5wdXQ7XG4gIGNyZWF0ZVZhbGlkYXRvciA9IGlucHV0ID0+IHBhdHRlcm5WYWxpZGF0b3IoaW5wdXQpO1xuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtVBhdHRlcm5WYWxpZGF0b3JfQmFzZUZhY3Rvcnk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIFBhdHRlcm5WYWxpZGF0b3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgICAgcmV0dXJuICjJtVBhdHRlcm5WYWxpZGF0b3JfQmFzZUZhY3RvcnkgfHwgKMm1UGF0dGVyblZhbGlkYXRvcl9CYXNlRmFjdG9yeSA9IGkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5KFBhdHRlcm5WYWxpZGF0b3IpKSkoX19uZ0ZhY3RvcnlUeXBlX18gfHwgUGF0dGVyblZhbGlkYXRvcik7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogUGF0dGVyblZhbGlkYXRvcixcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJwYXR0ZXJuXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJcIiwgXCJwYXR0ZXJuXCIsIFwiXCIsIFwiZm9ybUNvbnRyb2xcIiwgXCJcIl0sIFtcIlwiLCBcInBhdHRlcm5cIiwgXCJcIiwgXCJuZ01vZGVsXCIsIFwiXCJdXSxcbiAgICBob3N0VmFyczogMSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIFBhdHRlcm5WYWxpZGF0b3JfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWF0dHJpYnV0ZShcInBhdHRlcm5cIiwgY3R4Ll9lbmFibGVkID8gY3R4LnBhdHRlcm4gOiBudWxsKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgcGF0dGVybjogXCJwYXR0ZXJuXCJcbiAgICB9LFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW1BBVFRFUk5fVkFMSURBVE9SXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUGF0dGVyblZhbGlkYXRvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW3BhdHRlcm5dW2Zvcm1Db250cm9sTmFtZV0sW3BhdHRlcm5dW2Zvcm1Db250cm9sXSxbcGF0dGVybl1bbmdNb2RlbF0nLFxuICAgICAgcHJvdmlkZXJzOiBbUEFUVEVSTl9WQUxJREFUT1JdLFxuICAgICAgaG9zdDoge1xuICAgICAgICAnW2F0dHIucGF0dGVybl0nOiAnX2VuYWJsZWQgPyBwYXR0ZXJuIDogbnVsbCdcbiAgICAgIH0sXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCBudWxsLCB7XG4gICAgcGF0dGVybjogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY29uc3QgybVGT1JNX0NPTlRST0xfSU5URUdSQVRJT04gPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ0ZPUk1fQ09OVFJPTF9JTlRFR1JBVElPTicgOiAnJyk7XG5jb25zdCBDQUxMX1NFVF9ESVNBQkxFRF9TVEFURSA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUgPyAnQ2FsbFNldERpc2FibGVkU3RhdGUnIDogJycsIHtcbiAgZmFjdG9yeTogKCkgPT4gc2V0RGlzYWJsZWRTdGF0ZURlZmF1bHRcbn0pO1xuY29uc3Qgc2V0RGlzYWJsZWRTdGF0ZURlZmF1bHQgPSAnYWx3YXlzJztcbmZ1bmN0aW9uIGNvbnRyb2xQYXRoKG5hbWUsIHBhcmVudCkge1xuICByZXR1cm4gWy4uLnBhcmVudC5wYXRoLCBuYW1lXTtcbn1cbmZ1bmN0aW9uIHNldFVwQ29udHJvbFZhbHVlQWNjZXNzb3IoY29udHJvbCwgZGlyLCBjYWxsU2V0RGlzYWJsZWRTdGF0ZSA9IHNldERpc2FibGVkU3RhdGVEZWZhdWx0KSB7XG4gIGlmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpIHtcbiAgICBpZiAoIWNvbnRyb2wpIF90aHJvd0Vycm9yKGRpciwgJ0Nhbm5vdCBmaW5kIGNvbnRyb2wgd2l0aCcpO1xuICAgIGlmICghZGlyLnZhbHVlQWNjZXNzb3IpIF90aHJvd01pc3NpbmdWYWx1ZUFjY2Vzc29yRXJyb3IoZGlyKTtcbiAgfVxuICBzZXRVcFZhbGlkYXRvcnMoY29udHJvbCwgZGlyKTtcbiAgZGlyLnZhbHVlQWNjZXNzb3Iud3JpdGVWYWx1ZShjb250cm9sLnZhbHVlKTtcbiAgaWYgKGNvbnRyb2wuZGlzYWJsZWQgfHwgY2FsbFNldERpc2FibGVkU3RhdGUgPT09ICdhbHdheXMnKSB7XG4gICAgZGlyLnZhbHVlQWNjZXNzb3Iuc2V0RGlzYWJsZWRTdGF0ZT8uKGNvbnRyb2wuZGlzYWJsZWQpO1xuICB9XG4gIHNldFVwVmlld0NoYW5nZVBpcGVsaW5lKGNvbnRyb2wsIGRpcik7XG4gIHNldFVwTW9kZWxDaGFuZ2VQaXBlbGluZShjb250cm9sLCBkaXIpO1xuICBzZXRVcEJsdXJQaXBlbGluZShjb250cm9sLCBkaXIpO1xuICBzZXRVcERpc2FibGVkQ2hhbmdlSGFuZGxlcihjb250cm9sLCBkaXIpO1xufVxuZnVuY3Rpb24gY2xlYW5VcENvbnRyb2woY29udHJvbCwgZGlyLCB2YWxpZGF0ZUNvbnRyb2xQcmVzZW5jZU9uQ2hhbmdlID0gdHJ1ZSkge1xuICBjb25zdCBub29wID0gKCkgPT4ge1xuICAgIGlmICh2YWxpZGF0ZUNvbnRyb2xQcmVzZW5jZU9uQ2hhbmdlICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSB7XG4gICAgICBfbm9Db250cm9sRXJyb3IoZGlyKTtcbiAgICB9XG4gIH07XG4gIGRpcj8udmFsdWVBY2Nlc3Nvcj8ucmVnaXN0ZXJPbkNoYW5nZShub29wKTtcbiAgZGlyPy52YWx1ZUFjY2Vzc29yPy5yZWdpc3Rlck9uVG91Y2hlZChub29wKTtcbiAgY2xlYW5VcFZhbGlkYXRvcnMoY29udHJvbCwgZGlyKTtcbiAgaWYgKGNvbnRyb2wpIHtcbiAgICBkaXIuX2ludm9rZU9uRGVzdHJveUNhbGxiYWNrcygpO1xuICAgIGNvbnRyb2wuX3JlZ2lzdGVyT25Db2xsZWN0aW9uQ2hhbmdlKCgpID0+IHt9KTtcbiAgfVxufVxuZnVuY3Rpb24gcmVnaXN0ZXJPblZhbGlkYXRvckNoYW5nZSh2YWxpZGF0b3JzLCBvbkNoYW5nZSkge1xuICB2YWxpZGF0b3JzLmZvckVhY2godmFsaWRhdG9yID0+IHtcbiAgICBpZiAodmFsaWRhdG9yLnJlZ2lzdGVyT25WYWxpZGF0b3JDaGFuZ2UpIHZhbGlkYXRvci5yZWdpc3Rlck9uVmFsaWRhdG9yQ2hhbmdlKG9uQ2hhbmdlKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBzZXRVcERpc2FibGVkQ2hhbmdlSGFuZGxlcihjb250cm9sLCBkaXIpIHtcbiAgaWYgKGRpci52YWx1ZUFjY2Vzc29yLnNldERpc2FibGVkU3RhdGUpIHtcbiAgICBjb25zdCBvbkRpc2FibGVkQ2hhbmdlID0gaXNEaXNhYmxlZCA9PiB7XG4gICAgICBkaXIudmFsdWVBY2Nlc3Nvci5zZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQpO1xuICAgIH07XG4gICAgY29udHJvbC5yZWdpc3Rlck9uRGlzYWJsZWRDaGFuZ2Uob25EaXNhYmxlZENoYW5nZSk7XG4gICAgZGlyLl9yZWdpc3Rlck9uRGVzdHJveSgoKSA9PiB7XG4gICAgICBjb250cm9sLl91bnJlZ2lzdGVyT25EaXNhYmxlZENoYW5nZShvbkRpc2FibGVkQ2hhbmdlKTtcbiAgICB9KTtcbiAgfVxufVxuZnVuY3Rpb24gc2V0VXBWYWxpZGF0b3JzKGNvbnRyb2wsIGRpcikge1xuICBjb25zdCB2YWxpZGF0b3JzID0gZ2V0Q29udHJvbFZhbGlkYXRvcnMoY29udHJvbCk7XG4gIGlmIChkaXIudmFsaWRhdG9yICE9PSBudWxsKSB7XG4gICAgY29udHJvbC5zZXRWYWxpZGF0b3JzKG1lcmdlVmFsaWRhdG9ycyh2YWxpZGF0b3JzLCBkaXIudmFsaWRhdG9yKSk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbGlkYXRvcnMgPT09ICdmdW5jdGlvbicpIHtcbiAgICBjb250cm9sLnNldFZhbGlkYXRvcnMoW3ZhbGlkYXRvcnNdKTtcbiAgfVxuICBjb25zdCBhc3luY1ZhbGlkYXRvcnMgPSBnZXRDb250cm9sQXN5bmNWYWxpZGF0b3JzKGNvbnRyb2wpO1xuICBpZiAoZGlyLmFzeW5jVmFsaWRhdG9yICE9PSBudWxsKSB7XG4gICAgY29udHJvbC5zZXRBc3luY1ZhbGlkYXRvcnMobWVyZ2VWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9ycywgZGlyLmFzeW5jVmFsaWRhdG9yKSk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGFzeW5jVmFsaWRhdG9ycyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGNvbnRyb2wuc2V0QXN5bmNWYWxpZGF0b3JzKFthc3luY1ZhbGlkYXRvcnNdKTtcbiAgfVxuICBjb25zdCBvblZhbGlkYXRvckNoYW5nZSA9ICgpID0+IGNvbnRyb2wudXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xuICByZWdpc3Rlck9uVmFsaWRhdG9yQ2hhbmdlKGRpci5fcmF3VmFsaWRhdG9ycywgb25WYWxpZGF0b3JDaGFuZ2UpO1xuICByZWdpc3Rlck9uVmFsaWRhdG9yQ2hhbmdlKGRpci5fcmF3QXN5bmNWYWxpZGF0b3JzLCBvblZhbGlkYXRvckNoYW5nZSk7XG59XG5mdW5jdGlvbiBjbGVhblVwVmFsaWRhdG9ycyhjb250cm9sLCBkaXIpIHtcbiAgbGV0IGlzQ29udHJvbFVwZGF0ZWQgPSBmYWxzZTtcbiAgaWYgKGNvbnRyb2wgIT09IG51bGwpIHtcbiAgICBpZiAoZGlyLnZhbGlkYXRvciAhPT0gbnVsbCkge1xuICAgICAgY29uc3QgdmFsaWRhdG9ycyA9IGdldENvbnRyb2xWYWxpZGF0b3JzKGNvbnRyb2wpO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsaWRhdG9ycykgJiYgdmFsaWRhdG9ycy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRWYWxpZGF0b3JzID0gdmFsaWRhdG9ycy5maWx0ZXIodmFsaWRhdG9yID0+IHZhbGlkYXRvciAhPT0gZGlyLnZhbGlkYXRvcik7XG4gICAgICAgIGlmICh1cGRhdGVkVmFsaWRhdG9ycy5sZW5ndGggIT09IHZhbGlkYXRvcnMubGVuZ3RoKSB7XG4gICAgICAgICAgaXNDb250cm9sVXBkYXRlZCA9IHRydWU7XG4gICAgICAgICAgY29udHJvbC5zZXRWYWxpZGF0b3JzKHVwZGF0ZWRWYWxpZGF0b3JzKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZGlyLmFzeW5jVmFsaWRhdG9yICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBhc3luY1ZhbGlkYXRvcnMgPSBnZXRDb250cm9sQXN5bmNWYWxpZGF0b3JzKGNvbnRyb2wpO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYXN5bmNWYWxpZGF0b3JzKSAmJiBhc3luY1ZhbGlkYXRvcnMubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCB1cGRhdGVkQXN5bmNWYWxpZGF0b3JzID0gYXN5bmNWYWxpZGF0b3JzLmZpbHRlcihhc3luY1ZhbGlkYXRvciA9PiBhc3luY1ZhbGlkYXRvciAhPT0gZGlyLmFzeW5jVmFsaWRhdG9yKTtcbiAgICAgICAgaWYgKHVwZGF0ZWRBc3luY1ZhbGlkYXRvcnMubGVuZ3RoICE9PSBhc3luY1ZhbGlkYXRvcnMubGVuZ3RoKSB7XG4gICAgICAgICAgaXNDb250cm9sVXBkYXRlZCA9IHRydWU7XG4gICAgICAgICAgY29udHJvbC5zZXRBc3luY1ZhbGlkYXRvcnModXBkYXRlZEFzeW5jVmFsaWRhdG9ycyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgY29uc3Qgbm9vcCA9ICgpID0+IHt9O1xuICByZWdpc3Rlck9uVmFsaWRhdG9yQ2hhbmdlKGRpci5fcmF3VmFsaWRhdG9ycywgbm9vcCk7XG4gIHJlZ2lzdGVyT25WYWxpZGF0b3JDaGFuZ2UoZGlyLl9yYXdBc3luY1ZhbGlkYXRvcnMsIG5vb3ApO1xuICByZXR1cm4gaXNDb250cm9sVXBkYXRlZDtcbn1cbmZ1bmN0aW9uIHNldFVwVmlld0NoYW5nZVBpcGVsaW5lKGNvbnRyb2wsIGRpcikge1xuICBkaXIudmFsdWVBY2Nlc3Nvci5yZWdpc3Rlck9uQ2hhbmdlKG5ld1ZhbHVlID0+IHtcbiAgICBjb250cm9sLl9wZW5kaW5nVmFsdWUgPSBuZXdWYWx1ZTtcbiAgICBjb250cm9sLl9wZW5kaW5nQ2hhbmdlID0gdHJ1ZTtcbiAgICBjb250cm9sLl9wZW5kaW5nRGlydHkgPSB0cnVlO1xuICAgIGlmIChjb250cm9sLnVwZGF0ZU9uID09PSAnY2hhbmdlJykgdXBkYXRlQ29udHJvbChjb250cm9sLCBkaXIpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHNldFVwQmx1clBpcGVsaW5lKGNvbnRyb2wsIGRpcikge1xuICBkaXIudmFsdWVBY2Nlc3Nvci5yZWdpc3Rlck9uVG91Y2hlZCgoKSA9PiB7XG4gICAgY29udHJvbC5fcGVuZGluZ1RvdWNoZWQgPSB0cnVlO1xuICAgIGlmIChjb250cm9sLnVwZGF0ZU9uID09PSAnYmx1cicgJiYgY29udHJvbC5fcGVuZGluZ0NoYW5nZSkgdXBkYXRlQ29udHJvbChjb250cm9sLCBkaXIpO1xuICAgIGlmIChjb250cm9sLnVwZGF0ZU9uICE9PSAnc3VibWl0JykgY29udHJvbC5tYXJrQXNUb3VjaGVkKCk7XG4gIH0pO1xufVxuZnVuY3Rpb24gdXBkYXRlQ29udHJvbChjb250cm9sLCBkaXIpIHtcbiAgaWYgKGNvbnRyb2wuX3BlbmRpbmdEaXJ0eSkgY29udHJvbC5tYXJrQXNEaXJ0eSgpO1xuICBjb250cm9sLnNldFZhbHVlKGNvbnRyb2wuX3BlbmRpbmdWYWx1ZSwge1xuICAgIGVtaXRNb2RlbFRvVmlld0NoYW5nZTogZmFsc2VcbiAgfSk7XG4gIGRpci52aWV3VG9Nb2RlbFVwZGF0ZShjb250cm9sLl9wZW5kaW5nVmFsdWUpO1xuICBjb250cm9sLl9wZW5kaW5nQ2hhbmdlID0gZmFsc2U7XG59XG5mdW5jdGlvbiBzZXRVcE1vZGVsQ2hhbmdlUGlwZWxpbmUoY29udHJvbCwgZGlyKSB7XG4gIGNvbnN0IG9uQ2hhbmdlID0gKG5ld1ZhbHVlLCBlbWl0TW9kZWxFdmVudCkgPT4ge1xuICAgIGRpci52YWx1ZUFjY2Vzc29yLndyaXRlVmFsdWUobmV3VmFsdWUpO1xuICAgIGlmIChlbWl0TW9kZWxFdmVudCkgZGlyLnZpZXdUb01vZGVsVXBkYXRlKG5ld1ZhbHVlKTtcbiAgfTtcbiAgY29udHJvbC5yZWdpc3Rlck9uQ2hhbmdlKG9uQ2hhbmdlKTtcbiAgZGlyLl9yZWdpc3Rlck9uRGVzdHJveSgoKSA9PiB7XG4gICAgY29udHJvbC5fdW5yZWdpc3Rlck9uQ2hhbmdlKG9uQ2hhbmdlKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBzZXRVcEZvcm1Db250YWluZXIoY29udHJvbCwgZGlyKSB7XG4gIGlmIChjb250cm9sID09IG51bGwgJiYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkpIF90aHJvd0Vycm9yKGRpciwgJ0Nhbm5vdCBmaW5kIGNvbnRyb2wgd2l0aCcpO1xuICBzZXRVcFZhbGlkYXRvcnMoY29udHJvbCwgZGlyKTtcbn1cbmZ1bmN0aW9uIGNsZWFuVXBGb3JtQ29udGFpbmVyKGNvbnRyb2wsIGRpcikge1xuICByZXR1cm4gY2xlYW5VcFZhbGlkYXRvcnMoY29udHJvbCwgZGlyKTtcbn1cbmZ1bmN0aW9uIF9ub0NvbnRyb2xFcnJvcihkaXIpIHtcbiAgcmV0dXJuIF90aHJvd0Vycm9yKGRpciwgJ1RoZXJlIGlzIG5vIEZvcm1Db250cm9sIGluc3RhbmNlIGF0dGFjaGVkIHRvIGZvcm0gY29udHJvbCBlbGVtZW50IHdpdGgnKTtcbn1cbmZ1bmN0aW9uIF90aHJvd0Vycm9yKGRpciwgbWVzc2FnZSkge1xuICBjb25zdCBtZXNzYWdlRW5kID0gX2Rlc2NyaWJlQ29udHJvbExvY2F0aW9uKGRpcik7XG4gIHRocm93IG5ldyBFcnJvcihgJHttZXNzYWdlfSAke21lc3NhZ2VFbmR9YCk7XG59XG5mdW5jdGlvbiBfZGVzY3JpYmVDb250cm9sTG9jYXRpb24oZGlyKSB7XG4gIGNvbnN0IHBhdGggPSBkaXIucGF0aDtcbiAgaWYgKHBhdGggJiYgcGF0aC5sZW5ndGggPiAxKSByZXR1cm4gYHBhdGg6ICcke3BhdGguam9pbignIC0+ICcpfSdgO1xuICBpZiAocGF0aD8uWzBdKSByZXR1cm4gYG5hbWU6ICcke3BhdGh9J2A7XG4gIHJldHVybiAndW5zcGVjaWZpZWQgbmFtZSBhdHRyaWJ1dGUnO1xufVxuZnVuY3Rpb24gX3Rocm93TWlzc2luZ1ZhbHVlQWNjZXNzb3JFcnJvcihkaXIpIHtcbiAgY29uc3QgbG9jID0gX2Rlc2NyaWJlQ29udHJvbExvY2F0aW9uKGRpcik7XG4gIHRocm93IG5ldyBfUnVudGltZUVycm9yKC0xMjAzLCBgTm8gdmFsdWUgYWNjZXNzb3IgZm9yIGZvcm0gY29udHJvbCAke2xvY30uYCk7XG59XG5mdW5jdGlvbiBfdGhyb3dJbnZhbGlkVmFsdWVBY2Nlc3NvckVycm9yKGRpcikge1xuICBjb25zdCBsb2MgPSBfZGVzY3JpYmVDb250cm9sTG9jYXRpb24oZGlyKTtcbiAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMTIwMCwgYFZhbHVlIGFjY2Vzc29yIHdhcyBub3QgcHJvdmlkZWQgYXMgYW4gYXJyYXkgZm9yIGZvcm0gY29udHJvbCB3aXRoICR7bG9jfS4gYCArIGBDaGVjayB0aGF0IHRoZSBcXGBOR19WQUxVRV9BQ0NFU1NPUlxcYCB0b2tlbiBpcyBjb25maWd1cmVkIGFzIGEgXFxgbXVsdGk6IHRydWVcXGAgcHJvdmlkZXIuYCk7XG59XG5mdW5jdGlvbiBpc1Byb3BlcnR5VXBkYXRlZChjaGFuZ2VzLCB2aWV3TW9kZWwpIHtcbiAgaWYgKCFjaGFuZ2VzLmhhc093blByb3BlcnR5KCdtb2RlbCcpKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGNoYW5nZSA9IGNoYW5nZXNbJ21vZGVsJ107XG4gIGlmIChjaGFuZ2UuaXNGaXJzdENoYW5nZSgpKSByZXR1cm4gdHJ1ZTtcbiAgcmV0dXJuICFPYmplY3QuaXModmlld01vZGVsLCBjaGFuZ2UuY3VycmVudFZhbHVlKTtcbn1cbmZ1bmN0aW9uIGlzQnVpbHRJbkFjY2Vzc29yKHZhbHVlQWNjZXNzb3IpIHtcbiAgcmV0dXJuIE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWx1ZUFjY2Vzc29yLmNvbnN0cnVjdG9yKSA9PT0gQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yO1xufVxuZnVuY3Rpb24gc3luY1BlbmRpbmdDb250cm9scyhmb3JtLCBkaXJlY3RpdmVzKSB7XG4gIGZvcm0uX3N5bmNQZW5kaW5nQ29udHJvbHMoKTtcbiAgZGlyZWN0aXZlcy5mb3JFYWNoKGRpciA9PiB7XG4gICAgY29uc3QgY29udHJvbCA9IGRpci5jb250cm9sO1xuICAgIGlmIChjb250cm9sLnVwZGF0ZU9uID09PSAnc3VibWl0JyAmJiBjb250cm9sLl9wZW5kaW5nQ2hhbmdlKSB7XG4gICAgICBkaXIudmlld1RvTW9kZWxVcGRhdGUoY29udHJvbC5fcGVuZGluZ1ZhbHVlKTtcbiAgICAgIGNvbnRyb2wuX3BlbmRpbmdDaGFuZ2UgPSBmYWxzZTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gc2VsZWN0VmFsdWVBY2Nlc3NvcihkaXIsIHZhbHVlQWNjZXNzb3JzKSB7XG4gIGlmICghdmFsdWVBY2Nlc3NvcnMpIHJldHVybiBudWxsO1xuICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWVBY2Nlc3NvcnMpICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSBfdGhyb3dJbnZhbGlkVmFsdWVBY2Nlc3NvckVycm9yKGRpcik7XG4gIGxldCBkZWZhdWx0QWNjZXNzb3IgPSB1bmRlZmluZWQ7XG4gIGxldCBidWlsdGluQWNjZXNzb3IgPSB1bmRlZmluZWQ7XG4gIGxldCBjdXN0b21BY2Nlc3NvciA9IHVuZGVmaW5lZDtcbiAgdmFsdWVBY2Nlc3NvcnMuZm9yRWFjaCh2ID0+IHtcbiAgICBpZiAodi5jb25zdHJ1Y3RvciA9PT0gRGVmYXVsdFZhbHVlQWNjZXNzb3IpIHtcbiAgICAgIGRlZmF1bHRBY2Nlc3NvciA9IHY7XG4gICAgfSBlbHNlIGlmIChpc0J1aWx0SW5BY2Nlc3Nvcih2KSkge1xuICAgICAgaWYgKGJ1aWx0aW5BY2Nlc3NvciAmJiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSkgX3Rocm93RXJyb3IoZGlyLCAnTW9yZSB0aGFuIG9uZSBidWlsdC1pbiB2YWx1ZSBhY2Nlc3NvciBtYXRjaGVzIGZvcm0gY29udHJvbCB3aXRoJyk7XG4gICAgICBidWlsdGluQWNjZXNzb3IgPSB2O1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoY3VzdG9tQWNjZXNzb3IgJiYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkpIF90aHJvd0Vycm9yKGRpciwgJ01vcmUgdGhhbiBvbmUgY3VzdG9tIHZhbHVlIGFjY2Vzc29yIG1hdGNoZXMgZm9ybSBjb250cm9sIHdpdGgnKTtcbiAgICAgIGN1c3RvbUFjY2Vzc29yID0gdjtcbiAgICB9XG4gIH0pO1xuICBpZiAoY3VzdG9tQWNjZXNzb3IpIHJldHVybiBjdXN0b21BY2Nlc3NvcjtcbiAgaWYgKGJ1aWx0aW5BY2Nlc3NvcikgcmV0dXJuIGJ1aWx0aW5BY2Nlc3NvcjtcbiAgaWYgKGRlZmF1bHRBY2Nlc3NvcikgcmV0dXJuIGRlZmF1bHRBY2Nlc3NvcjtcbiAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgIF90aHJvd0Vycm9yKGRpciwgJ05vIHZhbGlkIHZhbHVlIGFjY2Vzc29yIGZvciBmb3JtIGNvbnRyb2wgd2l0aCcpO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gcmVtb3ZlTGlzdEl0ZW0kMShsaXN0LCBlbCkge1xuICBjb25zdCBpbmRleCA9IGxpc3QuaW5kZXhPZihlbCk7XG4gIGlmIChpbmRleCA+IC0xKSBsaXN0LnNwbGljZShpbmRleCwgMSk7XG59XG5mdW5jdGlvbiBfbmdNb2RlbFdhcm5pbmcobmFtZSwgdHlwZSwgaW5zdGFuY2UsIHdhcm5pbmdDb25maWcpIHtcbiAgaWYgKHdhcm5pbmdDb25maWcgPT09ICduZXZlcicpIHJldHVybjtcbiAgaWYgKCh3YXJuaW5nQ29uZmlnID09PSBudWxsIHx8IHdhcm5pbmdDb25maWcgPT09ICdvbmNlJykgJiYgIXR5cGUuX25nTW9kZWxXYXJuaW5nU2VudE9uY2UgfHwgd2FybmluZ0NvbmZpZyA9PT0gJ2Fsd2F5cycgJiYgIWluc3RhbmNlLl9uZ01vZGVsV2FybmluZ1NlbnQpIHtcbiAgICBjb25zb2xlLndhcm4obmdNb2RlbFdhcm5pbmcobmFtZSkpO1xuICAgIHR5cGUuX25nTW9kZWxXYXJuaW5nU2VudE9uY2UgPSB0cnVlO1xuICAgIGluc3RhbmNlLl9uZ01vZGVsV2FybmluZ1NlbnQgPSB0cnVlO1xuICB9XG59XG5jb25zdCBOR19DT05UUk9MX0lOVEVHUkFUSU9OX1BST1ZJREVSID0ge1xuICBwcm92aWRlOiDJtUZPUk1fQ09OVFJPTF9JTlRFR1JBVElPTixcbiAgdXNlRmFjdG9yeTogKCkgPT4ge1xuICAgIGNvbnN0IGNvbnRyb2wgPSBpbmplY3QoTmdDb250cm9sLCB7XG4gICAgICBzZWxmOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHNldFBhcnNlRXJyb3JzOiBzb3VyY2UgPT4ge1xuICAgICAgICBjb250cm9sLnNldFBhcnNlRXJyb3JTb3VyY2Uoc291cmNlKTtcbiAgICAgIH0sXG4gICAgICBzZXQgb25SZXNldChjYWxsYmFjaykge1xuICAgICAgICBjb250cm9sLm9uUmVzZXQgPSBjYWxsYmFjaztcbiAgICAgIH1cbiAgICB9O1xuICB9XG59O1xuY2xhc3MgTmdDb250cm9sIGV4dGVuZHMgQWJzdHJhY3RDb250cm9sRGlyZWN0aXZlIHtcbiAgX3BhcmVudCA9IG51bGw7XG4gIG5hbWUgPSBudWxsO1xuICB2YWx1ZUFjY2Vzc29yID0gbnVsbDtcbiAgaXNDdXN0b21Db250cm9sQmFzZWQgPSBmYWxzZTtcbiAgdXNlck9uUmVzZXQ7XG4gIHJlc2V0U3Vic2NyaXB0aW9uO1xuICBzZXQgb25SZXNldChjYWxsYmFjaykge1xuICAgIHRoaXMudXNlck9uUmVzZXQgPSBjYWxsYmFjaztcbiAgICB0aGlzLnJlc2V0U3Vic2NyaXB0aW9uPy51bnN1YnNjcmliZSgpO1xuICAgIHRoaXMucmVzZXRTdWJzY3JpcHRpb24gPSB1bmRlZmluZWQ7XG4gICAgaWYgKHRoaXMuY29udHJvbCkge1xuICAgICAgdGhpcy5yZXNldFN1YnNjcmlwdGlvbiA9IHRoaXMuY29udHJvbC5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcbiAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgRm9ybVJlc2V0RXZlbnQgJiYgdGhpcy5jb250cm9sKSB7XG4gICAgICAgICAgdGhpcy51c2VyT25SZXNldD8uKHRoaXMuY29udHJvbC52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb24/LmFkZCh0aGlzLnJlc2V0U3Vic2NyaXB0aW9uKTtcbiAgICB9XG4gIH1cbiAgaXNOYXRpdmVGb3JtRWxlbWVudCA9IGZhbHNlO1xuICByYXdWYWx1ZUFjY2Vzc29ycztcbiAgX3NlbGVjdGVkVmFsdWVBY2Nlc3NvciA9IG51bGw7XG4gIGdldCBzZWxlY3RlZFZhbHVlQWNjZXNzb3IoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3NlbGVjdGVkVmFsdWVBY2Nlc3NvciA/Pz0gc2VsZWN0VmFsdWVBY2Nlc3Nvcih0aGlzLCB0aGlzLnJhd1ZhbHVlQWNjZXNzb3JzKTtcbiAgfVxuICBwYXJzZUVycm9yc1ZhbGlkYXRvciA9IG51bGw7XG4gIHJlbmRlcmVyO1xuICBpbmplY3RvcjtcbiAgcmVxdWlyZWRWYWxpZGF0b3JWaWFEaTtcbiAgc3Vic2NyaXB0aW9uO1xuICBjdXN0b21Db250cm9sQmluZGluZ3MgPSBudWxsO1xuICBjb25zdHJ1Y3RvcihpbmplY3RvciwgcmVuZGVyZXIsIHJhd1ZhbHVlQWNjZXNzb3JzKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLmluamVjdG9yID0gaW5qZWN0b3I7XG4gICAgdGhpcy5yZW5kZXJlciA9IHJlbmRlcmVyO1xuICAgIHRoaXMucmF3VmFsdWVBY2Nlc3NvcnMgPSByYXdWYWx1ZUFjY2Vzc29ycztcbiAgICB0aGlzLmluamVjdG9yPy5nZXQoRGVzdHJveVJlZik/Lm9uRGVzdHJveSgoKSA9PiB7XG4gICAgICB0aGlzLnJlbW92ZVBhcnNlRXJyb3JzVmFsaWRhdG9yKHRoaXMuY29udHJvbCk7XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbj8udW5zdWJzY3JpYmUoKTtcbiAgICB9KTtcbiAgfVxuICBzZXR1cEN1c3RvbUNvbnRyb2woKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgY29uc3QgY2RyID0gdGhpcy5pbmplY3Rvcj8uZ2V0KENoYW5nZURldGVjdG9yUmVmKTtcbiAgICBpZiAoIXRoaXMuY29udHJvbCB8fCAhY2RyKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG1hcmtGb3JDaGVjayA9IGNkci5tYXJrRm9yQ2hlY2suYmluZChjZHIpO1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uID0gbmV3IFN1YnNjcmlwdGlvbigpO1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uLmFkZCh0aGlzLmNvbnRyb2wudmFsdWVDaGFuZ2VzLnN1YnNjcmliZShtYXJrRm9yQ2hlY2spKTtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbi5hZGQodGhpcy5jb250cm9sLnN0YXR1c0NoYW5nZXMuc3Vic2NyaWJlKG1hcmtGb3JDaGVjaykpO1xuICAgIHRoaXMucmVzZXRTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgdGhpcy5yZXNldFN1YnNjcmlwdGlvbiA9IHVuZGVmaW5lZDtcbiAgICBpZiAodGhpcy51c2VyT25SZXNldCkge1xuICAgICAgdGhpcy5yZXNldFN1YnNjcmlwdGlvbiA9IHRoaXMuY29udHJvbC5ldmVudHMuc3Vic2NyaWJlKGV2ZW50ID0+IHtcbiAgICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgRm9ybVJlc2V0RXZlbnQgJiYgdGhpcy5jb250cm9sKSB7XG4gICAgICAgICAgdGhpcy51c2VyT25SZXNldD8uKHRoaXMuY29udHJvbC52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb24uYWRkKHRoaXMucmVzZXRTdWJzY3JpcHRpb24pO1xuICAgIH1cbiAgICBpZiAodGhpcy5wYXJzZUVycm9yc1ZhbGlkYXRvcikge1xuICAgICAgdGhpcy5jb250cm9sLmFkZFZhbGlkYXRvcnModGhpcy5wYXJzZUVycm9yc1ZhbGlkYXRvcik7XG4gICAgfVxuICB9XG4gIG5nQ29udHJvbENyZWF0ZShob3N0KSB7XG4gICAgY29uc3QgaGFzTmdOb0N2YSA9IGhvc3QubmF0aXZlRWxlbWVudC5oYXNBdHRyaWJ1dGU/LignbmdOb0N2YScpO1xuICAgIGNvbnN0IGhhc0N2YSA9ICFoYXNOZ05vQ3ZhICYmICh0aGlzLnJhd1ZhbHVlQWNjZXNzb3JzICYmIHRoaXMucmF3VmFsdWVBY2Nlc3NvcnMubGVuZ3RoID4gMCB8fCB0aGlzLnZhbHVlQWNjZXNzb3IgIT09IG51bGwpO1xuICAgIGlmIChoYXNDdmEgfHwgIWhvc3QuY3VzdG9tQ29udHJvbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmlzQ3VzdG9tQ29udHJvbEJhc2VkID0gdHJ1ZTtcbiAgICBob3N0Lmxpc3RlblRvQ3VzdG9tQ29udHJvbE1vZGVsKHZhbHVlID0+IHtcbiAgICAgIHRoaXMuY29udHJvbD8uc2V0VmFsdWUodmFsdWUsIHtcbiAgICAgICAgZW1pdE1vZGVsVG9WaWV3Q2hhbmdlOiBmYWxzZVxuICAgICAgfSk7XG4gICAgICB0aGlzLmNvbnRyb2w/Lm1hcmtBc0RpcnR5KCk7XG4gICAgICB0aGlzLnZpZXdUb01vZGVsVXBkYXRlKHZhbHVlKTtcbiAgICB9KTtcbiAgICBob3N0Lmxpc3RlblRvQ3VzdG9tQ29udHJvbE91dHB1dCgndG91Y2gnLCAoKSA9PiB7XG4gICAgICB0aGlzLmNvbnRyb2w/Lm1hcmtBc1RvdWNoZWQoKTtcbiAgICB9KTtcbiAgICB0aGlzLmN1c3RvbUNvbnRyb2xCaW5kaW5ncyA9IHt9O1xuICAgIHRoaXMuaXNOYXRpdmVGb3JtRWxlbWVudCA9IGlzTmF0aXZlRm9ybUVsZW1lbnQoaG9zdC5uYXRpdmVFbGVtZW50KTtcbiAgICB0aGlzLnJlcXVpcmVkVmFsaWRhdG9yVmlhRGkgPSB0aGlzLl9yYXdWYWxpZGF0b3JzLmZpbmQodiA9PiB2IGluc3RhbmNlb2YgUmVxdWlyZWRWYWxpZGF0b3IpO1xuICB9XG4gIG5nQ29udHJvbFVwZGF0ZShob3N0LCBiaW5kUmVxdWlyZWQpIHtcbiAgICBpZiAoIXRoaXMuaXNDdXN0b21Db250cm9sQmFzZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY29udHJvbCA9IHRoaXMuY29udHJvbDtcbiAgICBjb25zdCBiaW5kaW5ncyA9IHRoaXMuY3VzdG9tQ29udHJvbEJpbmRpbmdzO1xuICAgIGlmICghT2JqZWN0LmlzKGJpbmRpbmdzLnZhbHVlLCBjb250cm9sLnZhbHVlKSkge1xuICAgICAgYmluZGluZ3MudmFsdWUgPSBjb250cm9sLnZhbHVlO1xuICAgICAgaG9zdC5zZXRDdXN0b21Db250cm9sTW9kZWxJbnB1dChjb250cm9sLnZhbHVlKTtcbiAgICB9XG4gICAgdGhpcy5iaW5kQ29udHJvbFByb3BlcnR5KGhvc3QsIGJpbmRpbmdzLCAndG91Y2hlZCcsIGNvbnRyb2wudG91Y2hlZCk7XG4gICAgdGhpcy5iaW5kQ29udHJvbFByb3BlcnR5KGhvc3QsIGJpbmRpbmdzLCAnZGlydHknLCBjb250cm9sLmRpcnR5KTtcbiAgICB0aGlzLmJpbmRDb250cm9sUHJvcGVydHkoaG9zdCwgYmluZGluZ3MsICd2YWxpZCcsIGNvbnRyb2wudmFsaWQpO1xuICAgIHRoaXMuYmluZENvbnRyb2xQcm9wZXJ0eShob3N0LCBiaW5kaW5ncywgJ2ludmFsaWQnLCBjb250cm9sLmludmFsaWQpO1xuICAgIHRoaXMuYmluZENvbnRyb2xQcm9wZXJ0eShob3N0LCBiaW5kaW5ncywgJ3BlbmRpbmcnLCBjb250cm9sLnBlbmRpbmcpO1xuICAgIHRoaXMuYmluZENvbnRyb2xQcm9wZXJ0eShob3N0LCBiaW5kaW5ncywgJ2Rpc2FibGVkJywgY29udHJvbC5kaXNhYmxlZCk7XG4gICAgaWYgKHRoaXMuc2hvdWxkQmluZFJlcXVpcmVkKSB7XG4gICAgICB0aGlzLmJpbmRDb250cm9sUHJvcGVydHkoaG9zdCwgYmluZGluZ3MsICdyZXF1aXJlZCcsIHRoaXMuaXNSZXF1aXJlZCk7XG4gICAgfVxuICAgIGNvbnN0IGVycm9yT2JqZWN0ID0gY29udHJvbC5lcnJvcnM7XG4gICAgaWYgKGJpbmRpbmdzLmVycm9ycyAhPT0gZXJyb3JPYmplY3QpIHtcbiAgICAgIGJpbmRpbmdzLmVycm9ycyA9IGVycm9yT2JqZWN0O1xuICAgICAgY29uc3QgZXJyb3JBcnJheSA9IHRoaXMuX2NvbnZlcnRFcnJvcnMoZXJyb3JPYmplY3QpO1xuICAgICAgaG9zdC5zZXRJbnB1dE9uRGlyZWN0aXZlcygnZXJyb3JzJywgZXJyb3JBcnJheSk7XG4gICAgfVxuICB9XG4gIGdldCBpc1JlcXVpcmVkKCkge1xuICAgIHJldHVybiAodGhpcy5yZXF1aXJlZFZhbGlkYXRvclZpYURpPy5fZW5hYmxlZCB8fCB0aGlzLmNvbnRyb2w/Ll9oYXNSZXF1aXJlZCgpKSA/PyBmYWxzZTtcbiAgfVxuICBnZXQgc2hvdWxkQmluZFJlcXVpcmVkKCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGJpbmRDb250cm9sUHJvcGVydHkoaG9zdCwgYmluZGluZ3MsIG5hbWUsIHZhbHVlKSB7XG4gICAgaWYgKGJpbmRpbmdzW25hbWVdID09PSB2YWx1ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBiaW5kaW5nc1tuYW1lXSA9IHZhbHVlO1xuICAgIGNvbnN0IHdhc1NldCA9IGhvc3Quc2V0SW5wdXRPbkRpcmVjdGl2ZXMobmFtZSwgdmFsdWUpO1xuICAgIGlmICh0aGlzLmlzTmF0aXZlRm9ybUVsZW1lbnQgJiYgIXdhc1NldCAmJiAobmFtZSA9PT0gJ2Rpc2FibGVkJyB8fCBuYW1lID09PSAncmVxdWlyZWQnKSAmJiB0aGlzLnJlbmRlcmVyKSB7XG4gICAgICBzZXROYXRpdmVEb21Qcm9wZXJ0eSh0aGlzLnJlbmRlcmVyLCBob3N0Lm5hdGl2ZUVsZW1lbnQsIG5hbWUsIHZhbHVlKTtcbiAgICB9XG4gIH1cbiAgX2NvbnZlcnRFcnJvcnMoZXJyb3JzKSB7XG4gICAgaWYgKGVycm9ycyA9PT0gbnVsbCkge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBjb25zdCBjb250cm9sID0gdGhpcy5jb250cm9sO1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyhlcnJvcnMpLm1hcCgoW2tpbmQsIGNvbnRleHRdKSA9PiB7XG4gICAgICByZXR1cm4gbmV3IFJlYWN0aXZlVmFsaWRhdGlvbkVycm9yKHtcbiAgICAgICAgY29udGV4dCxcbiAgICAgICAga2luZCxcbiAgICAgICAgY29udHJvbFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgc2V0UGFyc2VFcnJvclNvdXJjZShwYXJzZUVycm9ycykge1xuICAgIGlmIChwYXJzZUVycm9ycyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBjb252ZXJ0ZWRFcnJvcnMgPSBudWxsO1xuICAgIGNvbnN0IGNvbnZlcnRlZFBhcnNlRXJyb3JzID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgICAgY29uc3QgcmF3RXJyb3JzID0gcGFyc2VFcnJvcnMoKTtcbiAgICAgIGlmIChyYXdFcnJvcnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJhd0Vycm9ycy5yZWR1Y2UoKGFjYywgZXJyKSA9PiB7XG4gICAgICAgIGFjY1tlcnIua2luZF0gPSBlcnI7XG4gICAgICAgIHJldHVybiBhY2M7XG4gICAgICB9LCB7fSk7XG4gICAgfSwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgICBkZWJ1Z05hbWU6IFwiY29udmVydGVkUGFyc2VFcnJvcnNcIlxuICAgIH1dIDogW10pKTtcbiAgICB0aGlzLnBhcnNlRXJyb3JzVmFsaWRhdG9yID0gKCgpID0+IGNvbnZlcnRlZEVycm9ycykuYmluZCh0aGlzKTtcbiAgICBlZmZlY3QoKCkgPT4ge1xuICAgICAgY29udmVydGVkRXJyb3JzID0gY29udmVydGVkUGFyc2VFcnJvcnMoKTtcbiAgICAgIHRoaXMuY29udHJvbD8udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7XG4gICAgICAgIGVtaXRFdmVudDogZmFsc2VcbiAgICAgIH0pO1xuICAgIH0sIHtcbiAgICAgIGluamVjdG9yOiB0aGlzLmluamVjdG9yXG4gICAgfSk7XG4gIH1cbiAgcmVtb3ZlUGFyc2VFcnJvcnNWYWxpZGF0b3IoY29udHJvbCkge1xuICAgIGlmICh0aGlzLnBhcnNlRXJyb3JzVmFsaWRhdG9yKSB7XG4gICAgICBjb250cm9sPy5yZW1vdmVWYWxpZGF0b3JzKHRoaXMucGFyc2VFcnJvcnNWYWxpZGF0b3IpO1xuICAgICAgY29udHJvbD8udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7XG4gICAgICAgIGVtaXRFdmVudDogZmFsc2VcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuY2xhc3MgQWJzdHJhY3RDb250cm9sU3RhdHVzIHtcbiAgX2NkO1xuICBjb25zdHJ1Y3RvcihjZCkge1xuICAgIHRoaXMuX2NkID0gY2Q7XG4gIH1cbiAgZ2V0IGlzVG91Y2hlZCgpIHtcbiAgICB0aGlzLl9jZD8uY29udHJvbD8uX3RvdWNoZWQ/LigpO1xuICAgIHJldHVybiAhIXRoaXMuX2NkPy5jb250cm9sPy50b3VjaGVkO1xuICB9XG4gIGdldCBpc1VudG91Y2hlZCgpIHtcbiAgICByZXR1cm4gISF0aGlzLl9jZD8uY29udHJvbD8udW50b3VjaGVkO1xuICB9XG4gIGdldCBpc1ByaXN0aW5lKCkge1xuICAgIHRoaXMuX2NkPy5jb250cm9sPy5fcHJpc3RpbmU/LigpO1xuICAgIHJldHVybiAhIXRoaXMuX2NkPy5jb250cm9sPy5wcmlzdGluZTtcbiAgfVxuICBnZXQgaXNEaXJ0eSgpIHtcbiAgICByZXR1cm4gISF0aGlzLl9jZD8uY29udHJvbD8uZGlydHk7XG4gIH1cbiAgZ2V0IGlzVmFsaWQoKSB7XG4gICAgdGhpcy5fY2Q/LmNvbnRyb2w/Ll9zdGF0dXM/LigpO1xuICAgIHJldHVybiAhIXRoaXMuX2NkPy5jb250cm9sPy52YWxpZDtcbiAgfVxuICBnZXQgaXNJbnZhbGlkKCkge1xuICAgIHJldHVybiAhIXRoaXMuX2NkPy5jb250cm9sPy5pbnZhbGlkO1xuICB9XG4gIGdldCBpc1BlbmRpbmcoKSB7XG4gICAgcmV0dXJuICEhdGhpcy5fY2Q/LmNvbnRyb2w/LnBlbmRpbmc7XG4gIH1cbiAgZ2V0IGlzU3VibWl0dGVkKCkge1xuICAgIHRoaXMuX2NkPy5fc3VibWl0dGVkPy4oKTtcbiAgICByZXR1cm4gISF0aGlzLl9jZD8uc3VibWl0dGVkO1xuICB9XG59XG5jb25zdCBuZ0NvbnRyb2xTdGF0dXNIb3N0ID0ge1xuICAnW2NsYXNzLm5nLXVudG91Y2hlZF0nOiAnaXNVbnRvdWNoZWQnLFxuICAnW2NsYXNzLm5nLXRvdWNoZWRdJzogJ2lzVG91Y2hlZCcsXG4gICdbY2xhc3MubmctcHJpc3RpbmVdJzogJ2lzUHJpc3RpbmUnLFxuICAnW2NsYXNzLm5nLWRpcnR5XSc6ICdpc0RpcnR5JyxcbiAgJ1tjbGFzcy5uZy12YWxpZF0nOiAnaXNWYWxpZCcsXG4gICdbY2xhc3MubmctaW52YWxpZF0nOiAnaXNJbnZhbGlkJyxcbiAgJ1tjbGFzcy5uZy1wZW5kaW5nXSc6ICdpc1BlbmRpbmcnXG59O1xuY2xhc3MgTmdDb250cm9sU3RhdHVzIGV4dGVuZHMgQWJzdHJhY3RDb250cm9sU3RhdHVzIHtcbiAgY29uc3RydWN0b3IoY2QpIHtcbiAgICBzdXBlcihjZCk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdDb250cm9sU3RhdHVzX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdDb250cm9sU3RhdHVzKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5nQ29udHJvbCwgMikpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBOZ0NvbnRyb2xTdGF0dXMsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCJdLCBbXCJcIiwgXCJuZ01vZGVsXCIsIFwiXCJdLCBbXCJcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiXV0sXG4gICAgaG9zdFZhcnM6IDE0LFxuICAgIGhvc3RCaW5kaW5nczogZnVuY3Rpb24gTmdDb250cm9sU3RhdHVzX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAyKSB7XG4gICAgICAgIGkwLsm1ybVjbGFzc1Byb3AoXCJuZy11bnRvdWNoZWRcIiwgY3R4LmlzVW50b3VjaGVkKShcIm5nLXRvdWNoZWRcIiwgY3R4LmlzVG91Y2hlZCkoXCJuZy1wcmlzdGluZVwiLCBjdHguaXNQcmlzdGluZSkoXCJuZy1kaXJ0eVwiLCBjdHguaXNEaXJ0eSkoXCJuZy12YWxpZFwiLCBjdHguaXNWYWxpZCkoXCJuZy1pbnZhbGlkXCIsIGN0eC5pc0ludmFsaWQpKFwibmctcGVuZGluZ1wiLCBjdHguaXNQZW5kaW5nKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ0NvbnRyb2xTdGF0dXMsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tmb3JtQ29udHJvbE5hbWVdLFtuZ01vZGVsXSxbZm9ybUNvbnRyb2xdJyxcbiAgICAgIGhvc3Q6IG5nQ29udHJvbFN0YXR1c0hvc3QsXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IE5nQ29udHJvbCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogU2VsZlxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBOZ0NvbnRyb2xTdGF0dXNHcm91cCBleHRlbmRzIEFic3RyYWN0Q29udHJvbFN0YXR1cyB7XG4gIGNvbnN0cnVjdG9yKGNkKSB7XG4gICAgc3VwZXIoY2QpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIE5nQ29udHJvbFN0YXR1c0dyb3VwX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdDb250cm9sU3RhdHVzR3JvdXApKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoQ29udHJvbENvbnRhaW5lciwgMTApKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdDb250cm9sU3RhdHVzR3JvdXAsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwiZm9ybUdyb3VwTmFtZVwiLCBcIlwiXSwgW1wiXCIsIFwiZm9ybUFycmF5TmFtZVwiLCBcIlwiXSwgW1wiXCIsIFwibmdNb2RlbEdyb3VwXCIsIFwiXCJdLCBbXCJcIiwgXCJmb3JtR3JvdXBcIiwgXCJcIl0sIFtcIlwiLCBcImZvcm1BcnJheVwiLCBcIlwiXSwgW1wiZm9ybVwiLCAzLCBcIm5nTm9Gb3JtXCIsIFwiXCJdLCBbXCJcIiwgXCJuZ0Zvcm1cIiwgXCJcIl1dLFxuICAgIGhvc3RWYXJzOiAxNixcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIE5nQ29udHJvbFN0YXR1c0dyb3VwX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAyKSB7XG4gICAgICAgIGkwLsm1ybVjbGFzc1Byb3AoXCJuZy11bnRvdWNoZWRcIiwgY3R4LmlzVW50b3VjaGVkKShcIm5nLXRvdWNoZWRcIiwgY3R4LmlzVG91Y2hlZCkoXCJuZy1wcmlzdGluZVwiLCBjdHguaXNQcmlzdGluZSkoXCJuZy1kaXJ0eVwiLCBjdHguaXNEaXJ0eSkoXCJuZy12YWxpZFwiLCBjdHguaXNWYWxpZCkoXCJuZy1pbnZhbGlkXCIsIGN0eC5pc0ludmFsaWQpKFwibmctcGVuZGluZ1wiLCBjdHguaXNQZW5kaW5nKShcIm5nLXN1Ym1pdHRlZFwiLCBjdHguaXNTdWJtaXR0ZWQpO1xuICAgICAgfVxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nQ29udHJvbFN0YXR1c0dyb3VwLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdbZm9ybUdyb3VwTmFtZV0sW2Zvcm1BcnJheU5hbWVdLFtuZ01vZGVsR3JvdXBdLFtmb3JtR3JvdXBdLFtmb3JtQXJyYXldLGZvcm06bm90KFtuZ05vRm9ybV0pLFtuZ0Zvcm1dJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgLi4ubmdDb250cm9sU3RhdHVzSG9zdCxcbiAgICAgICAgJ1tjbGFzcy5uZy1zdWJtaXR0ZWRdJzogJ2lzU3VibWl0dGVkJ1xuICAgICAgfSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogQ29udHJvbENvbnRhaW5lcixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfV1cbiAgfV0sIG51bGwpO1xufSkoKTtcbmNsYXNzIEZvcm1Hcm91cCBleHRlbmRzIEFic3RyYWN0Q29udHJvbCB7XG4gIGNvbnN0cnVjdG9yKGNvbnRyb2xzLCB2YWxpZGF0b3JPck9wdHMsIGFzeW5jVmFsaWRhdG9yKSB7XG4gICAgc3VwZXIocGlja1ZhbGlkYXRvcnModmFsaWRhdG9yT3JPcHRzKSwgcGlja0FzeW5jVmFsaWRhdG9ycyhhc3luY1ZhbGlkYXRvciwgdmFsaWRhdG9yT3JPcHRzKSk7XG4gICAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgdmFsaWRhdGVGb3JtR3JvdXBDb250cm9scyhjb250cm9scyk7XG4gICAgdGhpcy5jb250cm9scyA9IGNvbnRyb2xzO1xuICAgIHRoaXMuX2luaXRPYnNlcnZhYmxlcygpO1xuICAgIHRoaXMuX3NldFVwZGF0ZVN0cmF0ZWd5KHZhbGlkYXRvck9yT3B0cyk7XG4gICAgdGhpcy5fc2V0VXBDb250cm9scygpO1xuICAgIHRoaXMudXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7XG4gICAgICBvbmx5U2VsZjogdHJ1ZSxcbiAgICAgIGVtaXRFdmVudDogISF0aGlzLmFzeW5jVmFsaWRhdG9yXG4gICAgfSk7XG4gIH1cbiAgY29udHJvbHM7XG4gIHJlZ2lzdGVyQ29udHJvbChuYW1lLCBjb250cm9sKSB7XG4gICAgY29uc3QgZXhpc3RpbmdDb250cm9sID0gdGhpcy5fZmluZChuYW1lKTtcbiAgICBpZiAoZXhpc3RpbmdDb250cm9sKSByZXR1cm4gZXhpc3RpbmdDb250cm9sO1xuICAgIHRoaXMuY29udHJvbHNbbmFtZV0gPSBjb250cm9sO1xuICAgIGNvbnRyb2wuc2V0UGFyZW50KHRoaXMpO1xuICAgIGNvbnRyb2wuX3JlZ2lzdGVyT25Db2xsZWN0aW9uQ2hhbmdlKHRoaXMuX29uQ29sbGVjdGlvbkNoYW5nZSk7XG4gICAgcmV0dXJuIGNvbnRyb2w7XG4gIH1cbiAgYWRkQ29udHJvbChuYW1lLCBjb250cm9sLCBvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLnJlZ2lzdGVyQ29udHJvbChuYW1lLCBjb250cm9sKTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgIH0pO1xuICAgIHRoaXMuX29uQ29sbGVjdGlvbkNoYW5nZSgpO1xuICB9XG4gIHJlbW92ZUNvbnRyb2wobmFtZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgZXhpc3RpbmdDb250cm9sID0gdGhpcy5fZmluZChuYW1lKTtcbiAgICBpZiAoZXhpc3RpbmdDb250cm9sKSBleGlzdGluZ0NvbnRyb2wuX3JlZ2lzdGVyT25Db2xsZWN0aW9uQ2hhbmdlKCgpID0+IHt9KTtcbiAgICBkZWxldGUgdGhpcy5jb250cm9sc1tuYW1lXTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgIH0pO1xuICAgIHRoaXMuX29uQ29sbGVjdGlvbkNoYW5nZSgpO1xuICB9XG4gIHNldENvbnRyb2wobmFtZSwgY29udHJvbCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgZXhpc3RpbmdDb250cm9sID0gdGhpcy5fZmluZChuYW1lKTtcbiAgICBpZiAoZXhpc3RpbmdDb250cm9sKSBleGlzdGluZ0NvbnRyb2wuX3JlZ2lzdGVyT25Db2xsZWN0aW9uQ2hhbmdlKCgpID0+IHt9KTtcbiAgICBkZWxldGUgdGhpcy5jb250cm9sc1tuYW1lXTtcbiAgICBpZiAoY29udHJvbCkgdGhpcy5yZWdpc3RlckNvbnRyb2wobmFtZSwgY29udHJvbCk7XG4gICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgIGVtaXRFdmVudDogb3B0aW9ucy5lbWl0RXZlbnRcbiAgICB9KTtcbiAgICB0aGlzLl9vbkNvbGxlY3Rpb25DaGFuZ2UoKTtcbiAgfVxuICBjb250YWlucyhjb250cm9sTmFtZSkge1xuICAgIHJldHVybiB0aGlzLl9maW5kKGNvbnRyb2xOYW1lKT8uZW5hYmxlZCA9PT0gdHJ1ZTtcbiAgfVxuICBzZXRWYWx1ZSh2YWx1ZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgdW50cmFja2VkKCgpID0+IHtcbiAgICAgIGFzc2VydEFsbFZhbHVlc1ByZXNlbnQodGhpcywgdHJ1ZSwgdmFsdWUpO1xuICAgICAgT2JqZWN0LmtleXModmFsdWUpLmZvckVhY2gobmFtZSA9PiB7XG4gICAgICAgIGFzc2VydENvbnRyb2xQcmVzZW50KHRoaXMsIHRydWUsIG5hbWUpO1xuICAgICAgICB0aGlzLmNvbnRyb2xzW25hbWVdLnNldFZhbHVlKHZhbHVlW25hbWVdLCB7XG4gICAgICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KG9wdGlvbnMpO1xuICAgIH0pO1xuICB9XG4gIHBhdGNoVmFsdWUodmFsdWUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm47XG4gICAgT2JqZWN0LmtleXModmFsdWUpLmZvckVhY2gobmFtZSA9PiB7XG4gICAgICBjb25zdCBleGlzdGluZ0NvbnRyb2wgPSB0aGlzLl9maW5kKG5hbWUpO1xuICAgICAgaWYgKGV4aXN0aW5nQ29udHJvbCkge1xuICAgICAgICBleGlzdGluZ0NvbnRyb2wucGF0Y2hWYWx1ZSh2YWx1ZVtuYW1lXSwge1xuICAgICAgICAgIG9ubHlTZWxmOiB0cnVlLFxuICAgICAgICAgIGVtaXRFdmVudDogb3B0aW9ucy5lbWl0RXZlbnRcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KG9wdGlvbnMpO1xuICB9XG4gIHJlc2V0KHZhbHVlID0ge30sIG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMuX2ZvckVhY2hDaGlsZCgoY29udHJvbCwgbmFtZSkgPT4ge1xuICAgICAgY29udHJvbC5yZXNldCh2YWx1ZSA/IHZhbHVlW25hbWVdIDogbnVsbCwge1xuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICBvbmx5U2VsZjogdHJ1ZVxuICAgICAgfSk7XG4gICAgfSk7XG4gICAgdGhpcy5fdXBkYXRlUHJpc3RpbmUob3B0aW9ucywgdGhpcyk7XG4gICAgdGhpcy5fdXBkYXRlVG91Y2hlZChvcHRpb25zLCB0aGlzKTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkob3B0aW9ucyk7XG4gICAgaWYgKG9wdGlvbnM/LmVtaXRFdmVudCAhPT0gZmFsc2UpIHtcbiAgICAgIHRoaXMuX2V2ZW50cy5uZXh0KG5ldyBGb3JtUmVzZXRFdmVudCh0aGlzKSk7XG4gICAgfVxuICB9XG4gIGdldFJhd1ZhbHVlKCkge1xuICAgIHJldHVybiB0aGlzLl9yZWR1Y2VDaGlsZHJlbih7fSwgKGFjYywgY29udHJvbCwgbmFtZSkgPT4ge1xuICAgICAgYWNjW25hbWVdID0gY29udHJvbC5nZXRSYXdWYWx1ZSgpO1xuICAgICAgcmV0dXJuIGFjYztcbiAgICB9KTtcbiAgfVxuICBfc3luY1BlbmRpbmdDb250cm9scygpIHtcbiAgICBsZXQgc3VidHJlZVVwZGF0ZWQgPSB0aGlzLl9yZWR1Y2VDaGlsZHJlbihmYWxzZSwgKHVwZGF0ZWQsIGNoaWxkKSA9PiB7XG4gICAgICByZXR1cm4gY2hpbGQuX3N5bmNQZW5kaW5nQ29udHJvbHMoKSA/IHRydWUgOiB1cGRhdGVkO1xuICAgIH0pO1xuICAgIGlmIChzdWJ0cmVlVXBkYXRlZCkgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgIG9ubHlTZWxmOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIHN1YnRyZWVVcGRhdGVkO1xuICB9XG4gIF9mb3JFYWNoQ2hpbGQoY2IpIHtcbiAgICBPYmplY3Qua2V5cyh0aGlzLmNvbnRyb2xzKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICBjb25zdCBjb250cm9sID0gdGhpcy5jb250cm9sc1trZXldO1xuICAgICAgY29udHJvbCAmJiBjYihjb250cm9sLCBrZXkpO1xuICAgIH0pO1xuICB9XG4gIF9zZXRVcENvbnRyb2xzKCkge1xuICAgIHRoaXMuX2ZvckVhY2hDaGlsZChjb250cm9sID0+IHtcbiAgICAgIGNvbnRyb2wuc2V0UGFyZW50KHRoaXMpO1xuICAgICAgY29udHJvbC5fcmVnaXN0ZXJPbkNvbGxlY3Rpb25DaGFuZ2UodGhpcy5fb25Db2xsZWN0aW9uQ2hhbmdlKTtcbiAgICB9KTtcbiAgfVxuICBfdXBkYXRlVmFsdWUoKSB7XG4gICAgdGhpcy52YWx1ZSA9IHRoaXMuX3JlZHVjZVZhbHVlKCk7XG4gIH1cbiAgX2FueUNvbnRyb2xzKGNvbmRpdGlvbikge1xuICAgIGZvciAoY29uc3QgW2NvbnRyb2xOYW1lLCBjb250cm9sXSBvZiBPYmplY3QuZW50cmllcyh0aGlzLmNvbnRyb2xzKSkge1xuICAgICAgaWYgKHRoaXMuY29udGFpbnMoY29udHJvbE5hbWUpICYmIGNvbmRpdGlvbihjb250cm9sKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIF9yZWR1Y2VWYWx1ZSgpIHtcbiAgICBsZXQgYWNjID0ge307XG4gICAgcmV0dXJuIHRoaXMuX3JlZHVjZUNoaWxkcmVuKGFjYywgKGFjYywgY29udHJvbCwgbmFtZSkgPT4ge1xuICAgICAgaWYgKGNvbnRyb2wuZW5hYmxlZCB8fCB0aGlzLmRpc2FibGVkKSB7XG4gICAgICAgIGFjY1tuYW1lXSA9IGNvbnRyb2wudmFsdWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gYWNjO1xuICAgIH0pO1xuICB9XG4gIF9yZWR1Y2VDaGlsZHJlbihpbml0VmFsdWUsIGZuKSB7XG4gICAgbGV0IHJlcyA9IGluaXRWYWx1ZTtcbiAgICB0aGlzLl9mb3JFYWNoQ2hpbGQoKGNvbnRyb2wsIG5hbWUpID0+IHtcbiAgICAgIHJlcyA9IGZuKHJlcywgY29udHJvbCwgbmFtZSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuICBfYWxsQ29udHJvbHNEaXNhYmxlZCgpIHtcbiAgICBmb3IgKGNvbnN0IGNvbnRyb2xOYW1lIG9mIE9iamVjdC5rZXlzKHRoaXMuY29udHJvbHMpKSB7XG4gICAgICBpZiAodGhpcy5jb250cm9sc1tjb250cm9sTmFtZV0uZW5hYmxlZCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBPYmplY3Qua2V5cyh0aGlzLmNvbnRyb2xzKS5sZW5ndGggPiAwIHx8IHRoaXMuZGlzYWJsZWQ7XG4gIH1cbiAgX2ZpbmQobmFtZSkge1xuICAgIHJldHVybiBoYXNPd25Db250cm9sKHRoaXMuY29udHJvbHMsIG5hbWUpID8gdGhpcy5jb250cm9sc1tuYW1lXSA6IG51bGw7XG4gIH1cbn1cbmZ1bmN0aW9uIHZhbGlkYXRlRm9ybUdyb3VwQ29udHJvbHMoY29udHJvbHMpIHtcbiAgY29uc3QgaW52YWxpZEtleXMgPSBPYmplY3Qua2V5cyhjb250cm9scykuZmlsdGVyKGtleSA9PiBrZXkuaW5jbHVkZXMoJy4nKSk7XG4gIGlmIChpbnZhbGlkS2V5cy5sZW5ndGggPiAwKSB7XG4gICAgY29uc29sZS53YXJuKGBGb3JtR3JvdXAga2V5cyBjYW5ub3QgaW5jbHVkZSBcXGAuXFxgLCBwbGVhc2UgcmVwbGFjZSB0aGUga2V5cyBmb3I6ICR7aW52YWxpZEtleXMuam9pbignLCcpfS5gKTtcbiAgfVxufVxuY29uc3QgVW50eXBlZEZvcm1Hcm91cCA9IEZvcm1Hcm91cDtcbmNvbnN0IGlzRm9ybUdyb3VwID0gY29udHJvbCA9PiBjb250cm9sIGluc3RhbmNlb2YgRm9ybUdyb3VwO1xuY2xhc3MgRm9ybVJlY29yZCBleHRlbmRzIEZvcm1Hcm91cCB7fVxuY29uc3QgaXNGb3JtUmVjb3JkID0gY29udHJvbCA9PiBjb250cm9sIGluc3RhbmNlb2YgRm9ybVJlY29yZDtcbmNvbnN0IGZvcm1EaXJlY3RpdmVQcm92aWRlciQyID0ge1xuICBwcm92aWRlOiBDb250cm9sQ29udGFpbmVyLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBOZ0Zvcm0pXG59O1xuY29uc3QgcmVzb2x2ZWRQcm9taXNlJDEgPSAoKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkpKCk7XG5jbGFzcyBOZ0Zvcm0gZXh0ZW5kcyBDb250cm9sQ29udGFpbmVyIHtcbiAgY2FsbFNldERpc2FibGVkU3RhdGU7XG4gIGdldCBzdWJtaXR0ZWQoKSB7XG4gICAgcmV0dXJuIHVudHJhY2tlZCh0aGlzLnN1Ym1pdHRlZFJlYWN0aXZlKTtcbiAgfVxuICBfc3VibWl0dGVkID0gY29tcHV0ZWQoKCkgPT4gdGhpcy5zdWJtaXR0ZWRSZWFjdGl2ZSgpLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwiX3N1Ym1pdHRlZFwiXG4gIH1dIDogW10pKTtcbiAgc3VibWl0dGVkUmVhY3RpdmUgPSBzaWduYWwoZmFsc2UsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJzdWJtaXR0ZWRSZWFjdGl2ZVwiXG4gIH1dIDogW10pKTtcbiAgX2RpcmVjdGl2ZXMgPSBuZXcgU2V0KCk7XG4gIGZvcm07XG4gIG5nU3VibWl0ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBvcHRpb25zO1xuICBjb25zdHJ1Y3Rvcih2YWxpZGF0b3JzLCBhc3luY1ZhbGlkYXRvcnMsIGNhbGxTZXREaXNhYmxlZFN0YXRlKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLmNhbGxTZXREaXNhYmxlZFN0YXRlID0gY2FsbFNldERpc2FibGVkU3RhdGU7XG4gICAgdGhpcy5mb3JtID0gbmV3IEZvcm1Hcm91cCh7fSwgY29tcG9zZVZhbGlkYXRvcnModmFsaWRhdG9ycyksIGNvbXBvc2VBc3luY1ZhbGlkYXRvcnMoYXN5bmNWYWxpZGF0b3JzKSk7XG4gIH1cbiAgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMuX3NldFVwZGF0ZVN0cmF0ZWd5KCk7XG4gIH1cbiAgZ2V0IGZvcm1EaXJlY3RpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgZ2V0IGNvbnRyb2woKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybTtcbiAgfVxuICBnZXQgcGF0aCgpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgZ2V0IGNvbnRyb2xzKCkge1xuICAgIHJldHVybiB0aGlzLmZvcm0uY29udHJvbHM7XG4gIH1cbiAgYWRkQ29udHJvbChkaXIpIHtcbiAgICByZXNvbHZlZFByb21pc2UkMS50aGVuKCgpID0+IHtcbiAgICAgIGNvbnN0IGNvbnRhaW5lciA9IHRoaXMuX2ZpbmRDb250YWluZXIoZGlyLnBhdGgpO1xuICAgICAgZGlyLmNvbnRyb2wgPSBjb250YWluZXIucmVnaXN0ZXJDb250cm9sKGRpci5uYW1lLCBkaXIuY29udHJvbCk7XG4gICAgICBkaXIuX3NldHVwV2l0aEZvcm0odGhpcy5jYWxsU2V0RGlzYWJsZWRTdGF0ZSk7XG4gICAgICBkaXIuY29udHJvbC51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgICAgZW1pdEV2ZW50OiBmYWxzZVxuICAgICAgfSk7XG4gICAgICB0aGlzLl9kaXJlY3RpdmVzLmFkZChkaXIpO1xuICAgIH0pO1xuICB9XG4gIGdldENvbnRyb2woZGlyKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybS5nZXQoZGlyLnBhdGgpO1xuICB9XG4gIHJlbW92ZUNvbnRyb2woZGlyKSB7XG4gICAgcmVzb2x2ZWRQcm9taXNlJDEudGhlbigoKSA9PiB7XG4gICAgICBjb25zdCBjb250YWluZXIgPSB0aGlzLl9maW5kQ29udGFpbmVyKGRpci5wYXRoKTtcbiAgICAgIGNvbnRhaW5lcj8ucmVtb3ZlQ29udHJvbChkaXIubmFtZSk7XG4gICAgICB0aGlzLl9kaXJlY3RpdmVzLmRlbGV0ZShkaXIpO1xuICAgIH0pO1xuICB9XG4gIGFkZEZvcm1Hcm91cChkaXIpIHtcbiAgICByZXNvbHZlZFByb21pc2UkMS50aGVuKCgpID0+IHtcbiAgICAgIGNvbnN0IGNvbnRhaW5lciA9IHRoaXMuX2ZpbmRDb250YWluZXIoZGlyLnBhdGgpO1xuICAgICAgY29uc3QgZ3JvdXAgPSBuZXcgRm9ybUdyb3VwKHt9KTtcbiAgICAgIHNldFVwRm9ybUNvbnRhaW5lcihncm91cCwgZGlyKTtcbiAgICAgIGNvbnRhaW5lci5yZWdpc3RlckNvbnRyb2woZGlyLm5hbWUsIGdyb3VwKTtcbiAgICAgIGdyb3VwLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgICBlbWl0RXZlbnQ6IGZhbHNlXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICByZW1vdmVGb3JtR3JvdXAoZGlyKSB7XG4gICAgcmVzb2x2ZWRQcm9taXNlJDEudGhlbigoKSA9PiB7XG4gICAgICBjb25zdCBjb250YWluZXIgPSB0aGlzLl9maW5kQ29udGFpbmVyKGRpci5wYXRoKTtcbiAgICAgIGNvbnRhaW5lcj8ucmVtb3ZlQ29udHJvbD8uKGRpci5uYW1lKTtcbiAgICB9KTtcbiAgfVxuICBnZXRGb3JtR3JvdXAoZGlyKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybS5nZXQoZGlyLnBhdGgpO1xuICB9XG4gIHVwZGF0ZU1vZGVsKGRpciwgdmFsdWUpIHtcbiAgICByZXNvbHZlZFByb21pc2UkMS50aGVuKCgpID0+IHtcbiAgICAgIGNvbnN0IGN0cmwgPSB0aGlzLmZvcm0uZ2V0KGRpci5wYXRoKTtcbiAgICAgIGN0cmwuc2V0VmFsdWUodmFsdWUpO1xuICAgIH0pO1xuICB9XG4gIHNldFZhbHVlKHZhbHVlKSB7XG4gICAgdGhpcy5jb250cm9sLnNldFZhbHVlKHZhbHVlKTtcbiAgfVxuICBvblN1Ym1pdCgkZXZlbnQpIHtcbiAgICB0aGlzLnN1Ym1pdHRlZFJlYWN0aXZlLnNldCh0cnVlKTtcbiAgICBzeW5jUGVuZGluZ0NvbnRyb2xzKHRoaXMuZm9ybSwgdGhpcy5fZGlyZWN0aXZlcyk7XG4gICAgdGhpcy5uZ1N1Ym1pdC5lbWl0KCRldmVudCk7XG4gICAgdGhpcy5mb3JtLl9ldmVudHMubmV4dChuZXcgRm9ybVN1Ym1pdHRlZEV2ZW50KHRoaXMuY29udHJvbCkpO1xuICAgIHJldHVybiAkZXZlbnQ/LnRhcmdldD8ubWV0aG9kID09PSAnZGlhbG9nJztcbiAgfVxuICBvblJlc2V0KCkge1xuICAgIHRoaXMucmVzZXRGb3JtKCk7XG4gIH1cbiAgcmVzZXRGb3JtKHZhbHVlID0gdW5kZWZpbmVkKSB7XG4gICAgdGhpcy5mb3JtLnJlc2V0KHZhbHVlKTtcbiAgICB0aGlzLnN1Ym1pdHRlZFJlYWN0aXZlLnNldChmYWxzZSk7XG4gIH1cbiAgX3NldFVwZGF0ZVN0cmF0ZWd5KCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMgJiYgdGhpcy5vcHRpb25zLnVwZGF0ZU9uICE9IG51bGwpIHtcbiAgICAgIHRoaXMuZm9ybS5fdXBkYXRlT24gPSB0aGlzLm9wdGlvbnMudXBkYXRlT247XG4gICAgfVxuICB9XG4gIF9maW5kQ29udGFpbmVyKHBhdGgpIHtcbiAgICBwYXRoLnBvcCgpO1xuICAgIHJldHVybiBwYXRoLmxlbmd0aCA/IHRoaXMuZm9ybS5nZXQocGF0aCkgOiB0aGlzLmZvcm07XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdGb3JtX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdGb3JtKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5HX1ZBTElEQVRPUlMsIDEwKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19BU1lOQ19WQUxJREFUT1JTLCAxMCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoQ0FMTF9TRVRfRElTQUJMRURfU1RBVEUsIDgpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdGb3JtLFxuICAgIHNlbGVjdG9yczogW1tcImZvcm1cIiwgMywgXCJuZ05vRm9ybVwiLCBcIlwiLCAzLCBcImZvcm1Hcm91cFwiLCBcIlwiLCAzLCBcImZvcm1BcnJheVwiLCBcIlwiXSwgW1wibmctZm9ybVwiXSwgW1wiXCIsIFwibmdGb3JtXCIsIFwiXCJdXSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIE5nRm9ybV9Ib3N0QmluZGluZ3MocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1bGlzdGVuZXIoXCJzdWJtaXRcIiwgZnVuY3Rpb24gTmdGb3JtX3N1Ym1pdF9Ib3N0QmluZGluZ0hhbmRsZXIoJGV2ZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vblN1Ym1pdCgkZXZlbnQpO1xuICAgICAgICB9KShcInJlc2V0XCIsIGZ1bmN0aW9uIE5nRm9ybV9yZXNldF9Ib3N0QmluZGluZ0hhbmRsZXIoKSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vblJlc2V0KCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBvcHRpb25zOiBbMCwgXCJuZ0Zvcm1PcHRpb25zXCIsIFwib3B0aW9uc1wiXVxuICAgIH0sXG4gICAgb3V0cHV0czoge1xuICAgICAgbmdTdWJtaXQ6IFwibmdTdWJtaXRcIlxuICAgIH0sXG4gICAgZXhwb3J0QXM6IFtcIm5nRm9ybVwiXSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtmb3JtRGlyZWN0aXZlUHJvdmlkZXIkMl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nRm9ybSwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnZm9ybTpub3QoW25nTm9Gb3JtXSk6bm90KFtmb3JtR3JvdXBdKTpub3QoW2Zvcm1BcnJheV0pLG5nLWZvcm0sW25nRm9ybV0nLFxuICAgICAgcHJvdmlkZXJzOiBbZm9ybURpcmVjdGl2ZVByb3ZpZGVyJDJdLFxuICAgICAgaG9zdDoge1xuICAgICAgICAnKHN1Ym1pdCknOiAnb25TdWJtaXQoJGV2ZW50KScsXG4gICAgICAgICcocmVzZXQpJzogJ29uUmVzZXQoKSdcbiAgICAgIH0sXG4gICAgICBvdXRwdXRzOiBbJ25nU3VibWl0J10sXG4gICAgICBleHBvcnRBczogJ25nRm9ybScsXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX0FTWU5DX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbQ0FMTF9TRVRfRElTQUJMRURfU1RBVEVdXG4gICAgfV1cbiAgfV0sIHtcbiAgICBvcHRpb25zOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ25nRm9ybU9wdGlvbnMnXVxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmZ1bmN0aW9uIHJlbW92ZUxpc3RJdGVtKGxpc3QsIGVsKSB7XG4gIGNvbnN0IGluZGV4ID0gbGlzdC5pbmRleE9mKGVsKTtcbiAgaWYgKGluZGV4ID4gLTEpIGxpc3Quc3BsaWNlKGluZGV4LCAxKTtcbn1cbmZ1bmN0aW9uIGlzRm9ybUNvbnRyb2xTdGF0ZShmb3JtU3RhdGUpIHtcbiAgcmV0dXJuIHR5cGVvZiBmb3JtU3RhdGUgPT09ICdvYmplY3QnICYmIGZvcm1TdGF0ZSAhPT0gbnVsbCAmJiBPYmplY3Qua2V5cyhmb3JtU3RhdGUpLmxlbmd0aCA9PT0gMiAmJiAndmFsdWUnIGluIGZvcm1TdGF0ZSAmJiAnZGlzYWJsZWQnIGluIGZvcm1TdGF0ZTtcbn1cbmNvbnN0IEZvcm1Db250cm9sID0gY2xhc3MgRm9ybUNvbnRyb2wgZXh0ZW5kcyBBYnN0cmFjdENvbnRyb2wge1xuICBkZWZhdWx0VmFsdWUgPSBudWxsO1xuICBfb25DaGFuZ2UgPSBbXTtcbiAgX3BlbmRpbmdWYWx1ZTtcbiAgX3BlbmRpbmdDaGFuZ2UgPSBmYWxzZTtcbiAgY29uc3RydWN0b3IoZm9ybVN0YXRlID0gbnVsbCwgdmFsaWRhdG9yT3JPcHRzLCBhc3luY1ZhbGlkYXRvcikge1xuICAgIHN1cGVyKHBpY2tWYWxpZGF0b3JzKHZhbGlkYXRvck9yT3B0cyksIHBpY2tBc3luY1ZhbGlkYXRvcnMoYXN5bmNWYWxpZGF0b3IsIHZhbGlkYXRvck9yT3B0cykpO1xuICAgIHRoaXMuX2FwcGx5Rm9ybVN0YXRlKGZvcm1TdGF0ZSk7XG4gICAgdGhpcy5fc2V0VXBkYXRlU3RyYXRlZ3kodmFsaWRhdG9yT3JPcHRzKTtcbiAgICB0aGlzLl9pbml0T2JzZXJ2YWJsZXMoKTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICBlbWl0RXZlbnQ6ICEhdGhpcy5hc3luY1ZhbGlkYXRvclxuICAgIH0pO1xuICAgIGlmIChpc09wdGlvbnNPYmoodmFsaWRhdG9yT3JPcHRzKSAmJiAodmFsaWRhdG9yT3JPcHRzLm5vbk51bGxhYmxlIHx8IHZhbGlkYXRvck9yT3B0cy5pbml0aWFsVmFsdWVJc0RlZmF1bHQpKSB7XG4gICAgICBpZiAoaXNGb3JtQ29udHJvbFN0YXRlKGZvcm1TdGF0ZSkpIHtcbiAgICAgICAgdGhpcy5kZWZhdWx0VmFsdWUgPSBmb3JtU3RhdGUudmFsdWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmRlZmF1bHRWYWx1ZSA9IGZvcm1TdGF0ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc2V0VmFsdWUodmFsdWUsIG9wdGlvbnMgPSB7fSkge1xuICAgIHVudHJhY2tlZCgoKSA9PiB7XG4gICAgICB0aGlzLnZhbHVlID0gdGhpcy5fcGVuZGluZ1ZhbHVlID0gdmFsdWU7XG4gICAgICBpZiAodGhpcy5fb25DaGFuZ2UubGVuZ3RoICYmIG9wdGlvbnMuZW1pdE1vZGVsVG9WaWV3Q2hhbmdlICE9PSBmYWxzZSkge1xuICAgICAgICB0aGlzLl9vbkNoYW5nZS5mb3JFYWNoKGNoYW5nZUZuID0+IGNoYW5nZUZuKHRoaXMudmFsdWUsIG9wdGlvbnMuZW1pdFZpZXdUb01vZGVsQ2hhbmdlICE9PSBmYWxzZSkpO1xuICAgICAgfVxuICAgICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KG9wdGlvbnMpO1xuICAgIH0pO1xuICB9XG4gIHBhdGNoVmFsdWUodmFsdWUsIG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMuc2V0VmFsdWUodmFsdWUsIG9wdGlvbnMpO1xuICB9XG4gIHJlc2V0KGZvcm1TdGF0ZSA9IHRoaXMuZGVmYXVsdFZhbHVlLCBvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLl9hcHBseUZvcm1TdGF0ZShmb3JtU3RhdGUpO1xuICAgIHRoaXMubWFya0FzUHJpc3RpbmUob3B0aW9ucyk7XG4gICAgdGhpcy5tYXJrQXNVbnRvdWNoZWQob3B0aW9ucyk7XG4gICAgdGhpcy5zZXRWYWx1ZSh0aGlzLnZhbHVlLCBvcHRpb25zKTtcbiAgICBpZiAob3B0aW9ucy5vdmVyd3JpdGVEZWZhdWx0VmFsdWUpIHtcbiAgICAgIHRoaXMuZGVmYXVsdFZhbHVlID0gdGhpcy52YWx1ZTtcbiAgICB9XG4gICAgdGhpcy5fcGVuZGluZ0NoYW5nZSA9IGZhbHNlO1xuICAgIGlmIChvcHRpb25zPy5lbWl0RXZlbnQgIT09IGZhbHNlKSB7XG4gICAgICB0aGlzLl9ldmVudHMubmV4dChuZXcgRm9ybVJlc2V0RXZlbnQodGhpcykpO1xuICAgIH1cbiAgfVxuICBfdXBkYXRlVmFsdWUoKSB7fVxuICBfYW55Q29udHJvbHMoY29uZGl0aW9uKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIF9hbGxDb250cm9sc0Rpc2FibGVkKCkge1xuICAgIHJldHVybiB0aGlzLmRpc2FibGVkO1xuICB9XG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm4pIHtcbiAgICB0aGlzLl9vbkNoYW5nZS5wdXNoKGZuKTtcbiAgfVxuICBfdW5yZWdpc3Rlck9uQ2hhbmdlKGZuKSB7XG4gICAgcmVtb3ZlTGlzdEl0ZW0odGhpcy5fb25DaGFuZ2UsIGZuKTtcbiAgfVxuICByZWdpc3Rlck9uRGlzYWJsZWRDaGFuZ2UoZm4pIHtcbiAgICB0aGlzLl9vbkRpc2FibGVkQ2hhbmdlLnB1c2goZm4pO1xuICB9XG4gIF91bnJlZ2lzdGVyT25EaXNhYmxlZENoYW5nZShmbikge1xuICAgIHJlbW92ZUxpc3RJdGVtKHRoaXMuX29uRGlzYWJsZWRDaGFuZ2UsIGZuKTtcbiAgfVxuICBfZm9yRWFjaENoaWxkKGNiKSB7fVxuICBfc3luY1BlbmRpbmdDb250cm9scygpIHtcbiAgICBpZiAodGhpcy51cGRhdGVPbiA9PT0gJ3N1Ym1pdCcpIHtcbiAgICAgIGlmICh0aGlzLl9wZW5kaW5nRGlydHkpIHRoaXMubWFya0FzRGlydHkoKTtcbiAgICAgIGlmICh0aGlzLl9wZW5kaW5nVG91Y2hlZCkgdGhpcy5tYXJrQXNUb3VjaGVkKCk7XG4gICAgICBpZiAodGhpcy5fcGVuZGluZ0NoYW5nZSkge1xuICAgICAgICB0aGlzLnNldFZhbHVlKHRoaXMuX3BlbmRpbmdWYWx1ZSwge1xuICAgICAgICAgIG9ubHlTZWxmOiB0cnVlLFxuICAgICAgICAgIGVtaXRNb2RlbFRvVmlld0NoYW5nZTogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgX2FwcGx5Rm9ybVN0YXRlKGZvcm1TdGF0ZSkge1xuICAgIGlmIChpc0Zvcm1Db250cm9sU3RhdGUoZm9ybVN0YXRlKSkge1xuICAgICAgdGhpcy52YWx1ZSA9IHRoaXMuX3BlbmRpbmdWYWx1ZSA9IGZvcm1TdGF0ZS52YWx1ZTtcbiAgICAgIGZvcm1TdGF0ZS5kaXNhYmxlZCA/IHRoaXMuZGlzYWJsZSh7XG4gICAgICAgIG9ubHlTZWxmOiB0cnVlLFxuICAgICAgICBlbWl0RXZlbnQ6IGZhbHNlXG4gICAgICB9KSA6IHRoaXMuZW5hYmxlKHtcbiAgICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICAgIGVtaXRFdmVudDogZmFsc2VcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnZhbHVlID0gdGhpcy5fcGVuZGluZ1ZhbHVlID0gZm9ybVN0YXRlO1xuICAgIH1cbiAgfVxufTtcbmNvbnN0IFVudHlwZWRGb3JtQ29udHJvbCA9IEZvcm1Db250cm9sO1xuY29uc3QgaXNGb3JtQ29udHJvbCA9IGNvbnRyb2wgPT4gY29udHJvbCBpbnN0YW5jZW9mIEZvcm1Db250cm9sO1xuY2xhc3MgQWJzdHJhY3RGb3JtR3JvdXBEaXJlY3RpdmUgZXh0ZW5kcyBDb250cm9sQ29udGFpbmVyIHtcbiAgX3BhcmVudDtcbiAgbmdPbkluaXQoKSB7XG4gICAgdGhpcy5fY2hlY2tQYXJlbnRUeXBlKCk7XG4gICAgdGhpcy5mb3JtRGlyZWN0aXZlLmFkZEZvcm1Hcm91cCh0aGlzKTtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLmZvcm1EaXJlY3RpdmU/LnJlbW92ZUZvcm1Hcm91cCh0aGlzKTtcbiAgfVxuICBnZXQgY29udHJvbCgpIHtcbiAgICByZXR1cm4gdGhpcy5mb3JtRGlyZWN0aXZlLmdldEZvcm1Hcm91cCh0aGlzKTtcbiAgfVxuICBnZXQgcGF0aCgpIHtcbiAgICByZXR1cm4gY29udHJvbFBhdGgodGhpcy5uYW1lID09IG51bGwgPyB0aGlzLm5hbWUgOiB0aGlzLm5hbWUudG9TdHJpbmcoKSwgdGhpcy5fcGFyZW50KTtcbiAgfVxuICBnZXQgZm9ybURpcmVjdGl2ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGFyZW50ID8gdGhpcy5fcGFyZW50LmZvcm1EaXJlY3RpdmUgOiBudWxsO1xuICB9XG4gIF9jaGVja1BhcmVudFR5cGUoKSB7fVxuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtUFic3RyYWN0Rm9ybUdyb3VwRGlyZWN0aXZlX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBBYnN0cmFjdEZvcm1Hcm91cERpcmVjdGl2ZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICByZXR1cm4gKMm1QWJzdHJhY3RGb3JtR3JvdXBEaXJlY3RpdmVfQmFzZUZhY3RvcnkgfHwgKMm1QWJzdHJhY3RGb3JtR3JvdXBEaXJlY3RpdmVfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShBYnN0cmFjdEZvcm1Hcm91cERpcmVjdGl2ZSkpKShfX25nRmFjdG9yeVR5cGVfXyB8fCBBYnN0cmFjdEZvcm1Hcm91cERpcmVjdGl2ZSk7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogQWJzdHJhY3RGb3JtR3JvdXBEaXJlY3RpdmUsXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEFic3RyYWN0Rm9ybUdyb3VwRGlyZWN0aXZlLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc3RhbmRhbG9uZTogZmFsc2VcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gbW9kZWxQYXJlbnRFeGNlcHRpb24oKSB7XG4gIHJldHVybiBuZXcgX1J1bnRpbWVFcnJvcigxMzUwLCBgXG4gICAgbmdNb2RlbCBjYW5ub3QgYmUgdXNlZCB0byByZWdpc3RlciBmb3JtIGNvbnRyb2xzIHdpdGggYSBwYXJlbnQgZm9ybUdyb3VwIGRpcmVjdGl2ZS4gIFRyeSB1c2luZ1xuICAgIGZvcm1Hcm91cCdzIHBhcnRuZXIgZGlyZWN0aXZlIFwiZm9ybUNvbnRyb2xOYW1lXCIgaW5zdGVhZC4gIEV4YW1wbGU6XG5cbiAgICAke2Zvcm1Db250cm9sTmFtZUV4YW1wbGV9XG5cbiAgICBPciwgaWYgeW91J2QgbGlrZSB0byBhdm9pZCByZWdpc3RlcmluZyB0aGlzIGZvcm0gY29udHJvbCwgaW5kaWNhdGUgdGhhdCBpdCdzIHN0YW5kYWxvbmUgaW4gbmdNb2RlbE9wdGlvbnM6XG5cbiAgICBFeGFtcGxlOlxuXG4gICAgJHtuZ01vZGVsV2l0aEZvcm1Hcm91cEV4YW1wbGV9YCk7XG59XG5mdW5jdGlvbiBmb3JtR3JvdXBOYW1lRXhjZXB0aW9uKCkge1xuICByZXR1cm4gbmV3IF9SdW50aW1lRXJyb3IoMTM1MSwgYFxuICAgIG5nTW9kZWwgY2Fubm90IGJlIHVzZWQgdG8gcmVnaXN0ZXIgZm9ybSBjb250cm9scyB3aXRoIGEgcGFyZW50IGZvcm1Hcm91cE5hbWUgb3IgZm9ybUFycmF5TmFtZSBkaXJlY3RpdmUuXG5cbiAgICBPcHRpb24gMTogVXNlIGZvcm1Db250cm9sTmFtZSBpbnN0ZWFkIG9mIG5nTW9kZWwgKHJlYWN0aXZlIHN0cmF0ZWd5KTpcblxuICAgICR7Zm9ybUdyb3VwTmFtZUV4YW1wbGV9XG5cbiAgICBPcHRpb24gMjogIFVwZGF0ZSBuZ01vZGVsJ3MgcGFyZW50IGJlIG5nTW9kZWxHcm91cCAodGVtcGxhdGUtZHJpdmVuIHN0cmF0ZWd5KTpcblxuICAgICR7bmdNb2RlbEdyb3VwRXhhbXBsZX1gKTtcbn1cbmZ1bmN0aW9uIG1pc3NpbmdOYW1lRXhjZXB0aW9uKCkge1xuICByZXR1cm4gbmV3IF9SdW50aW1lRXJyb3IoMTM1MiwgYElmIG5nTW9kZWwgaXMgdXNlZCB3aXRoaW4gYSBmb3JtIHRhZywgZWl0aGVyIHRoZSBuYW1lIGF0dHJpYnV0ZSBtdXN0IGJlIHNldCBvciB0aGUgZm9ybVxuICAgIGNvbnRyb2wgbXVzdCBiZSBkZWZpbmVkIGFzICdzdGFuZGFsb25lJyBpbiBuZ01vZGVsT3B0aW9ucy5cblxuICAgIEV4YW1wbGUgMTogPGlucHV0IFsobmdNb2RlbCldPVwicGVyc29uLmZpcnN0TmFtZVwiIG5hbWU9XCJmaXJzdFwiPlxuICAgIEV4YW1wbGUgMjogPGlucHV0IFsobmdNb2RlbCldPVwicGVyc29uLmZpcnN0TmFtZVwiIFtuZ01vZGVsT3B0aW9uc109XCJ7c3RhbmRhbG9uZTogdHJ1ZX1cIj5gKTtcbn1cbmZ1bmN0aW9uIG1vZGVsR3JvdXBQYXJlbnRFeGNlcHRpb24oKSB7XG4gIHJldHVybiBuZXcgX1J1bnRpbWVFcnJvcigxMzUzLCBgXG4gICAgbmdNb2RlbEdyb3VwIGNhbm5vdCBiZSB1c2VkIHdpdGggYSBwYXJlbnQgZm9ybUdyb3VwIGRpcmVjdGl2ZS5cblxuICAgIE9wdGlvbiAxOiBVc2UgZm9ybUdyb3VwTmFtZSBpbnN0ZWFkIG9mIG5nTW9kZWxHcm91cCAocmVhY3RpdmUgc3RyYXRlZ3kpOlxuXG4gICAgJHtmb3JtR3JvdXBOYW1lRXhhbXBsZX1cblxuICAgIE9wdGlvbiAyOiAgVXNlIGEgcmVndWxhciBmb3JtIHRhZyBpbnN0ZWFkIG9mIHRoZSBmb3JtR3JvdXAgZGlyZWN0aXZlICh0ZW1wbGF0ZS1kcml2ZW4gc3RyYXRlZ3kpOlxuXG4gICAgJHtuZ01vZGVsR3JvdXBFeGFtcGxlfWApO1xufVxuY29uc3QgbW9kZWxHcm91cFByb3ZpZGVyID0ge1xuICBwcm92aWRlOiBDb250cm9sQ29udGFpbmVyLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBOZ01vZGVsR3JvdXApXG59O1xuY2xhc3MgTmdNb2RlbEdyb3VwIGV4dGVuZHMgQWJzdHJhY3RGb3JtR3JvdXBEaXJlY3RpdmUge1xuICBuYW1lID0gJyc7XG4gIGNvbnN0cnVjdG9yKHBhcmVudCwgdmFsaWRhdG9ycywgYXN5bmNWYWxpZGF0b3JzKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9wYXJlbnQgPSBwYXJlbnQ7XG4gICAgdGhpcy5fc2V0VmFsaWRhdG9ycyh2YWxpZGF0b3JzKTtcbiAgICB0aGlzLl9zZXRBc3luY1ZhbGlkYXRvcnMoYXN5bmNWYWxpZGF0b3JzKTtcbiAgfVxuICBfY2hlY2tQYXJlbnRUeXBlKCkge1xuICAgIGlmICghKHRoaXMuX3BhcmVudCBpbnN0YW5jZW9mIE5nTW9kZWxHcm91cCkgJiYgISh0aGlzLl9wYXJlbnQgaW5zdGFuY2VvZiBOZ0Zvcm0pICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSB7XG4gICAgICB0aHJvdyBtb2RlbEdyb3VwUGFyZW50RXhjZXB0aW9uKCk7XG4gICAgfVxuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIE5nTW9kZWxHcm91cF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IE5nTW9kZWxHcm91cCkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChDb250cm9sQ29udGFpbmVyLCA1KSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19WQUxJREFUT1JTLCAxMCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfQVNZTkNfVkFMSURBVE9SUywgMTApKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdNb2RlbEdyb3VwLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcIm5nTW9kZWxHcm91cFwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuYW1lOiBbMCwgXCJuZ01vZGVsR3JvdXBcIiwgXCJuYW1lXCJdXG4gICAgfSxcbiAgICBleHBvcnRBczogW1wibmdNb2RlbEdyb3VwXCJdLFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW21vZGVsR3JvdXBQcm92aWRlcl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nTW9kZWxHcm91cCwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW25nTW9kZWxHcm91cF0nLFxuICAgICAgcHJvdmlkZXJzOiBbbW9kZWxHcm91cFByb3ZpZGVyXSxcbiAgICAgIGV4cG9ydEFzOiAnbmdNb2RlbEdyb3VwJyxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogQ29udHJvbENvbnRhaW5lcixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSG9zdFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNraXBTZWxmXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX0FTWU5DX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfV0sIHtcbiAgICBuYW1lOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ25nTW9kZWxHcm91cCddXG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY29uc3QgZm9ybUNvbnRyb2xCaW5kaW5nJDEgPSB7XG4gIHByb3ZpZGU6IE5nQ29udHJvbCxcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gTmdNb2RlbClcbn07XG5jb25zdCByZXNvbHZlZFByb21pc2UgPSAoKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkpKCk7XG5jbGFzcyBOZ01vZGVsIGV4dGVuZHMgTmdDb250cm9sIHtcbiAgX2NoYW5nZURldGVjdG9yUmVmO1xuICBjYWxsU2V0RGlzYWJsZWRTdGF0ZTtcbiAgY29udHJvbCA9IG5ldyBGb3JtQ29udHJvbCgpO1xuICBzdGF0aWMgbmdBY2NlcHRJbnB1dFR5cGVfaXNEaXNhYmxlZDtcbiAgX3JlZ2lzdGVyZWQgPSBmYWxzZTtcbiAgdmlld01vZGVsO1xuICBuYW1lID0gJyc7XG4gIGlzRGlzYWJsZWQ7XG4gIG1vZGVsO1xuICBvcHRpb25zO1xuICB1cGRhdGUgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIGNvbnN0cnVjdG9yKHBhcmVudCwgdmFsaWRhdG9ycywgYXN5bmNWYWxpZGF0b3JzLCB2YWx1ZUFjY2Vzc29ycywgX2NoYW5nZURldGVjdG9yUmVmLCBjYWxsU2V0RGlzYWJsZWRTdGF0ZSwgaW5qZWN0b3IsIHJlbmRlcmVyKSB7XG4gICAgc3VwZXIoaW5qZWN0b3IsIHJlbmRlcmVyLCB2YWx1ZUFjY2Vzc29ycyk7XG4gICAgdGhpcy5fY2hhbmdlRGV0ZWN0b3JSZWYgPSBfY2hhbmdlRGV0ZWN0b3JSZWY7XG4gICAgdGhpcy5jYWxsU2V0RGlzYWJsZWRTdGF0ZSA9IGNhbGxTZXREaXNhYmxlZFN0YXRlO1xuICAgIHRoaXMuX3BhcmVudCA9IHBhcmVudDtcbiAgICB0aGlzLl9zZXRWYWxpZGF0b3JzKHZhbGlkYXRvcnMpO1xuICAgIHRoaXMuX3NldEFzeW5jVmFsaWRhdG9ycyhhc3luY1ZhbGlkYXRvcnMpO1xuICB9XG4gIG5nT25DaGFuZ2VzKGNoYW5nZXMpIHtcbiAgICB0aGlzLl9jaGVja0ZvckVycm9ycygpO1xuICAgIGlmICghdGhpcy5fcmVnaXN0ZXJlZCB8fCAnbmFtZScgaW4gY2hhbmdlcykge1xuICAgICAgaWYgKHRoaXMuX3JlZ2lzdGVyZWQpIHtcbiAgICAgICAgdGhpcy5fY2hlY2tOYW1lKCk7XG4gICAgICAgIGlmICh0aGlzLmZvcm1EaXJlY3RpdmUpIHtcbiAgICAgICAgICBjb25zdCBvbGROYW1lID0gY2hhbmdlc1snbmFtZSddLnByZXZpb3VzVmFsdWU7XG4gICAgICAgICAgdGhpcy5mb3JtRGlyZWN0aXZlLnJlbW92ZUNvbnRyb2woe1xuICAgICAgICAgICAgbmFtZTogb2xkTmFtZSxcbiAgICAgICAgICAgIHBhdGg6IHRoaXMuX2dldFBhdGgob2xkTmFtZSlcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5fc2V0VXBDb250cm9sKCk7XG4gICAgfVxuICAgIGlmICgnaXNEaXNhYmxlZCcgaW4gY2hhbmdlcykge1xuICAgICAgdGhpcy5fdXBkYXRlRGlzYWJsZWQoY2hhbmdlcyk7XG4gICAgfVxuICAgIGlmIChpc1Byb3BlcnR5VXBkYXRlZChjaGFuZ2VzLCB0aGlzLnZpZXdNb2RlbCkpIHtcbiAgICAgIHRoaXMuX3VwZGF0ZVZhbHVlKHRoaXMubW9kZWwpO1xuICAgICAgdGhpcy52aWV3TW9kZWwgPSB0aGlzLm1vZGVsO1xuICAgIH1cbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLmZvcm1EaXJlY3RpdmU/LnJlbW92ZUNvbnRyb2wodGhpcyk7XG4gIH1cbiAgybVuZ0NvbnRyb2xDcmVhdGUoaG9zdCkge1xuICAgIHN1cGVyLm5nQ29udHJvbENyZWF0ZShob3N0KTtcbiAgfVxuICDJtW5nQ29udHJvbFVwZGF0ZShob3N0KSB7XG4gICAgc3VwZXIubmdDb250cm9sVXBkYXRlKGhvc3QsIGZhbHNlKTtcbiAgfVxuICBnZXQgc2hvdWxkQmluZFJlcXVpcmVkKCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBnZXQgcGF0aCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZ2V0UGF0aCh0aGlzLm5hbWUpO1xuICB9XG4gIGdldCBmb3JtRGlyZWN0aXZlKCkge1xuICAgIHJldHVybiB0aGlzLl9wYXJlbnQgPyB0aGlzLl9wYXJlbnQuZm9ybURpcmVjdGl2ZSA6IG51bGw7XG4gIH1cbiAgdmlld1RvTW9kZWxVcGRhdGUobmV3VmFsdWUpIHtcbiAgICB0aGlzLnZpZXdNb2RlbCA9IG5ld1ZhbHVlO1xuICAgIHRoaXMudXBkYXRlLmVtaXQobmV3VmFsdWUpO1xuICB9XG4gIF9zZXRVcENvbnRyb2woKSB7XG4gICAgdGhpcy5fc2V0VXBkYXRlU3RyYXRlZ3koKTtcbiAgICB0aGlzLl9pc1N0YW5kYWxvbmUoKSA/IHRoaXMuX3NldFVwU3RhbmRhbG9uZSgpIDogdGhpcy5mb3JtRGlyZWN0aXZlLmFkZENvbnRyb2wodGhpcyk7XG4gICAgdGhpcy5fcmVnaXN0ZXJlZCA9IHRydWU7XG4gIH1cbiAgX3NldFVwZGF0ZVN0cmF0ZWd5KCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMgJiYgdGhpcy5vcHRpb25zLnVwZGF0ZU9uICE9IG51bGwpIHtcbiAgICAgIHRoaXMuY29udHJvbC5fdXBkYXRlT24gPSB0aGlzLm9wdGlvbnMudXBkYXRlT247XG4gICAgfVxuICB9XG4gIF9pc1N0YW5kYWxvbmUoKSB7XG4gICAgcmV0dXJuICF0aGlzLl9wYXJlbnQgfHwgISEodGhpcy5vcHRpb25zICYmIHRoaXMub3B0aW9ucy5zdGFuZGFsb25lKTtcbiAgfVxuICBfc2V0VXBTdGFuZGFsb25lKCkge1xuICAgIGlmICghdGhpcy5pc0N1c3RvbUNvbnRyb2xCYXNlZCkge1xuICAgICAgdGhpcy52YWx1ZUFjY2Vzc29yID8/PSB0aGlzLnNlbGVjdGVkVmFsdWVBY2Nlc3NvcjtcbiAgICAgIHNldFVwQ29udHJvbFZhbHVlQWNjZXNzb3IodGhpcy5jb250cm9sLCB0aGlzLCB0aGlzLmNhbGxTZXREaXNhYmxlZFN0YXRlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zZXR1cEN1c3RvbUNvbnRyb2woKTtcbiAgICB9XG4gICAgdGhpcy5jb250cm9sLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBmYWxzZVxuICAgIH0pO1xuICB9XG4gIF9zZXR1cFdpdGhGb3JtKGNhbGxTZXREaXNhYmxlZFN0YXRlKSB7XG4gICAgaWYgKCF0aGlzLmlzQ3VzdG9tQ29udHJvbEJhc2VkKSB7XG4gICAgICB0aGlzLnZhbHVlQWNjZXNzb3IgPz89IHRoaXMuc2VsZWN0ZWRWYWx1ZUFjY2Vzc29yO1xuICAgICAgc2V0VXBDb250cm9sVmFsdWVBY2Nlc3Nvcih0aGlzLmNvbnRyb2wsIHRoaXMsIGNhbGxTZXREaXNhYmxlZFN0YXRlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zZXR1cEN1c3RvbUNvbnRyb2woKTtcbiAgICB9XG4gIH1cbiAgX2NoZWNrRm9yRXJyb3JzKCkge1xuICAgIGlmICgodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiAhdGhpcy5faXNTdGFuZGFsb25lKCkpIHtcbiAgICAgIGNoZWNrUGFyZW50VHlwZSQxKHRoaXMuX3BhcmVudCk7XG4gICAgfVxuICAgIHRoaXMuX2NoZWNrTmFtZSgpO1xuICB9XG4gIF9jaGVja05hbWUoKSB7XG4gICAgaWYgKHRoaXMub3B0aW9ucyAmJiB0aGlzLm9wdGlvbnMubmFtZSkgdGhpcy5uYW1lID0gdGhpcy5vcHRpb25zLm5hbWU7XG4gICAgaWYgKCF0aGlzLl9pc1N0YW5kYWxvbmUoKSAmJiAhdGhpcy5uYW1lICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSB7XG4gICAgICB0aHJvdyBtaXNzaW5nTmFtZUV4Y2VwdGlvbigpO1xuICAgIH1cbiAgfVxuICBfdXBkYXRlVmFsdWUodmFsdWUpIHtcbiAgICByZXNvbHZlZFByb21pc2UudGhlbigoKSA9PiB7XG4gICAgICB0aGlzLmNvbnRyb2wuc2V0VmFsdWUodmFsdWUsIHtcbiAgICAgICAgZW1pdFZpZXdUb01vZGVsQ2hhbmdlOiBmYWxzZVxuICAgICAgfSk7XG4gICAgICB0aGlzLl9jaGFuZ2VEZXRlY3RvclJlZj8ubWFya0ZvckNoZWNrKCk7XG4gICAgfSk7XG4gIH1cbiAgX3VwZGF0ZURpc2FibGVkKGNoYW5nZXMpIHtcbiAgICBjb25zdCBkaXNhYmxlZFZhbHVlID0gY2hhbmdlc1snaXNEaXNhYmxlZCddLmN1cnJlbnRWYWx1ZTtcbiAgICBjb25zdCBpc0Rpc2FibGVkID0gZGlzYWJsZWRWYWx1ZSAhPT0gMCAmJiBib29sZWFuQXR0cmlidXRlKGRpc2FibGVkVmFsdWUpO1xuICAgIHJlc29sdmVkUHJvbWlzZS50aGVuKCgpID0+IHtcbiAgICAgIGlmIChpc0Rpc2FibGVkICYmICF0aGlzLmNvbnRyb2wuZGlzYWJsZWQpIHtcbiAgICAgICAgdGhpcy5jb250cm9sLmRpc2FibGUoKTtcbiAgICAgIH0gZWxzZSBpZiAoIWlzRGlzYWJsZWQgJiYgdGhpcy5jb250cm9sLmRpc2FibGVkKSB7XG4gICAgICAgIHRoaXMuY29udHJvbC5lbmFibGUoKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuX2NoYW5nZURldGVjdG9yUmVmPy5tYXJrRm9yQ2hlY2soKTtcbiAgICB9KTtcbiAgfVxuICBfZ2V0UGF0aChjb250cm9sTmFtZSkge1xuICAgIHJldHVybiB0aGlzLl9wYXJlbnQgPyBjb250cm9sUGF0aChjb250cm9sTmFtZSwgdGhpcy5fcGFyZW50KSA6IFtjb250cm9sTmFtZV07XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdNb2RlbF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IE5nTW9kZWwpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoQ29udHJvbENvbnRhaW5lciwgOSksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfVkFMSURBVE9SUywgMTApLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5HX0FTWU5DX1ZBTElEQVRPUlMsIDEwKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19WQUxVRV9BQ0NFU1NPUiwgMTApLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KENoYW5nZURldGVjdG9yUmVmLCA4KSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChDQUxMX1NFVF9ESVNBQkxFRF9TVEFURSwgOCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuSW5qZWN0b3IsIDgpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlJlbmRlcmVyMiwgOCkpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBOZ01vZGVsLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcIm5nTW9kZWxcIiwgXCJcIiwgMywgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJcIiwgMywgXCJmb3JtQ29udHJvbFwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuYW1lOiBcIm5hbWVcIixcbiAgICAgIGlzRGlzYWJsZWQ6IFswLCBcImRpc2FibGVkXCIsIFwiaXNEaXNhYmxlZFwiXSxcbiAgICAgIG1vZGVsOiBbMCwgXCJuZ01vZGVsXCIsIFwibW9kZWxcIl0sXG4gICAgICBvcHRpb25zOiBbMCwgXCJuZ01vZGVsT3B0aW9uc1wiLCBcIm9wdGlvbnNcIl1cbiAgICB9LFxuICAgIG91dHB1dHM6IHtcbiAgICAgIHVwZGF0ZTogXCJuZ01vZGVsQ2hhbmdlXCJcbiAgICB9LFxuICAgIGV4cG9ydEFzOiBbXCJuZ01vZGVsXCJdLFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW2Zvcm1Db250cm9sQmluZGluZyQxLCBOR19DT05UUk9MX0lOVEVHUkFUSU9OX1BST1ZJREVSXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmUsIGkwLsm1ybVOZ09uQ2hhbmdlc0ZlYXR1cmUsIGkwLsm1ybVDb250cm9sRmVhdHVyZShudWxsKV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ01vZGVsLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdbbmdNb2RlbF06bm90KFtmb3JtQ29udHJvbE5hbWVdKTpub3QoW2Zvcm1Db250cm9sXSknLFxuICAgICAgcHJvdmlkZXJzOiBbZm9ybUNvbnRyb2xCaW5kaW5nJDEsIE5HX0NPTlRST0xfSU5URUdSQVRJT05fUFJPVklERVJdLFxuICAgICAgZXhwb3J0QXM6ICduZ01vZGVsJyxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogQ29udHJvbENvbnRhaW5lcixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBIb3N0XG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX0FTWU5DX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTFVFX0FDQ0VTU09SXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5DaGFuZ2VEZXRlY3RvclJlZixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbQ2hhbmdlRGV0ZWN0b3JSZWZdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbQ0FMTF9TRVRfRElTQUJMRURfU1RBVEVdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IGkwLkluamVjdG9yLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5SZW5kZXJlcjIsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfV1cbiAgfV0sIHtcbiAgICBuYW1lOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBpc0Rpc2FibGVkOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ2Rpc2FibGVkJ11cbiAgICB9XSxcbiAgICBtb2RlbDogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogWyduZ01vZGVsJ11cbiAgICB9XSxcbiAgICBvcHRpb25zOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ25nTW9kZWxPcHRpb25zJ11cbiAgICB9XSxcbiAgICB1cGRhdGU6IFt7XG4gICAgICB0eXBlOiBPdXRwdXQsXG4gICAgICBhcmdzOiBbJ25nTW9kZWxDaGFuZ2UnXVxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmZ1bmN0aW9uIGNoZWNrUGFyZW50VHlwZSQxKHBhcmVudCkge1xuICBpZiAoIShwYXJlbnQgaW5zdGFuY2VvZiBOZ01vZGVsR3JvdXApICYmIHBhcmVudCBpbnN0YW5jZW9mIEFic3RyYWN0Rm9ybUdyb3VwRGlyZWN0aXZlKSB7XG4gICAgdGhyb3cgZm9ybUdyb3VwTmFtZUV4Y2VwdGlvbigpO1xuICB9IGVsc2UgaWYgKCEocGFyZW50IGluc3RhbmNlb2YgTmdNb2RlbEdyb3VwKSAmJiAhKHBhcmVudCBpbnN0YW5jZW9mIE5nRm9ybSkpIHtcbiAgICB0aHJvdyBtb2RlbFBhcmVudEV4Y2VwdGlvbigpO1xuICB9XG59XG5jbGFzcyDJtU5nTm9WYWxpZGF0ZSB7XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIMm1TmdOb1ZhbGlkYXRlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCDJtU5nTm9WYWxpZGF0ZSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogybVOZ05vVmFsaWRhdGUsXG4gICAgc2VsZWN0b3JzOiBbW1wiZm9ybVwiLCAzLCBcIm5nTm9Gb3JtXCIsIFwiXCIsIDMsIFwibmdOYXRpdmVWYWxpZGF0ZVwiLCBcIlwiXV0sXG4gICAgaG9zdEF0dHJzOiBbXCJub3ZhbGlkYXRlXCIsIFwiXCJdLFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoybVOZ05vVmFsaWRhdGUsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ2Zvcm06bm90KFtuZ05vRm9ybV0pOm5vdChbbmdOYXRpdmVWYWxpZGF0ZV0pJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJ25vdmFsaWRhdGUnOiAnJ1xuICAgICAgfSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNvbnN0IE5VTUJFUl9WQUxVRV9BQ0NFU1NPUiA9IHtcbiAgcHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IE51bWJlclZhbHVlQWNjZXNzb3IpLFxuICBtdWx0aTogdHJ1ZVxufTtcbmNsYXNzIE51bWJlclZhbHVlQWNjZXNzb3IgZXh0ZW5kcyBCdWlsdEluQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuICB3cml0ZVZhbHVlKHZhbHVlKSB7XG4gICAgY29uc3Qgbm9ybWFsaXplZFZhbHVlID0gdmFsdWUgPT0gbnVsbCA/ICcnIDogdmFsdWU7XG4gICAgdGhpcy5zZXRQcm9wZXJ0eSgndmFsdWUnLCBub3JtYWxpemVkVmFsdWUpO1xuICB9XG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm4pIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gdmFsdWUgPT4ge1xuICAgICAgZm4odmFsdWUgPT0gJycgPyBudWxsIDogcGFyc2VGbG9hdCh2YWx1ZSkpO1xuICAgIH07XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gLyogQF9fUFVSRV9fICovKCgpID0+IHtcbiAgICBsZXQgybVOdW1iZXJWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBOdW1iZXJWYWx1ZUFjY2Vzc29yX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVOdW1iZXJWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5IHx8ICjJtU51bWJlclZhbHVlQWNjZXNzb3JfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShOdW1iZXJWYWx1ZUFjY2Vzc29yKSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IE51bWJlclZhbHVlQWNjZXNzb3IpO1xuICAgIH07XG4gIH0pKCk7XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE51bWJlclZhbHVlQWNjZXNzb3IsXG4gICAgc2VsZWN0b3JzOiBbW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwibnVtYmVyXCIsIFwiZm9ybUNvbnRyb2xOYW1lXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXSwgW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwibnVtYmVyXCIsIFwiZm9ybUNvbnRyb2xcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJudW1iZXJcIiwgXCJuZ01vZGVsXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXV0sXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBOdW1iZXJWYWx1ZUFjY2Vzc29yX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcImlucHV0XCIsIGZ1bmN0aW9uIE51bWJlclZhbHVlQWNjZXNzb3JfaW5wdXRfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25DaGFuZ2UoJGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICAgIH0pKFwiYmx1clwiLCBmdW5jdGlvbiBOdW1iZXJWYWx1ZUFjY2Vzc29yX2JsdXJfSG9zdEJpbmRpbmdIYW5kbGVyKCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25Ub3VjaGVkKCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbTlVNQkVSX1ZBTFVFX0FDQ0VTU09SXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTnVtYmVyVmFsdWVBY2Nlc3NvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnaW5wdXRbdHlwZT1udW1iZXJdOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sTmFtZV0saW5wdXRbdHlwZT1udW1iZXJdOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sXSxpbnB1dFt0eXBlPW51bWJlcl06bm90KFtuZ05vQ3ZhXSlbbmdNb2RlbF0nLFxuICAgICAgaG9zdDoge1xuICAgICAgICAnKGlucHV0KSc6ICdvbkNoYW5nZSgkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKScsXG4gICAgICAgICcoYmx1ciknOiAnb25Ub3VjaGVkKCknXG4gICAgICB9LFxuICAgICAgcHJvdmlkZXJzOiBbTlVNQkVSX1ZBTFVFX0FDQ0VTU09SXSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNvbnN0IFJBRElPX1ZBTFVFX0FDQ0VTU09SID0ge1xuICBwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gUmFkaW9Db250cm9sVmFsdWVBY2Nlc3NvciksXG4gIG11bHRpOiB0cnVlXG59O1xuZnVuY3Rpb24gdGhyb3dOYW1lRXJyb3IoKSB7XG4gIHRocm93IG5ldyBfUnVudGltZUVycm9yKDEyMDIsIGBcbiAgICAgIElmIHlvdSBkZWZpbmUgYm90aCBhIG5hbWUgYW5kIGEgZm9ybUNvbnRyb2xOYW1lIGF0dHJpYnV0ZSBvbiB5b3VyIHJhZGlvIGJ1dHRvbiwgdGhlaXIgdmFsdWVzXG4gICAgICBtdXN0IG1hdGNoLiBFeDogPGlucHV0IHR5cGU9XCJyYWRpb1wiIGZvcm1Db250cm9sTmFtZT1cImZvb2RcIiBuYW1lPVwiZm9vZFwiPlxuICAgIGApO1xufVxuY2xhc3MgUmFkaW9Db250cm9sUmVnaXN0cnkge1xuICBfYWNjZXNzb3JzID0gW107XG4gIGFkZChjb250cm9sLCBhY2Nlc3Nvcikge1xuICAgIHRoaXMuX2FjY2Vzc29ycy5wdXNoKFtjb250cm9sLCBhY2Nlc3Nvcl0pO1xuICB9XG4gIHJlbW92ZShhY2Nlc3Nvcikge1xuICAgIGZvciAobGV0IGkgPSB0aGlzLl9hY2Nlc3NvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgIGlmICh0aGlzLl9hY2Nlc3NvcnNbaV1bMV0gPT09IGFjY2Vzc29yKSB7XG4gICAgICAgIHRoaXMuX2FjY2Vzc29ycy5zcGxpY2UoaSwgMSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc2VsZWN0KGFjY2Vzc29yKSB7XG4gICAgdGhpcy5fYWNjZXNzb3JzLmZvckVhY2goYyA9PiB7XG4gICAgICBpZiAodGhpcy5faXNTYW1lR3JvdXAoYywgYWNjZXNzb3IpICYmIGNbMV0gIT09IGFjY2Vzc29yKSB7XG4gICAgICAgIGNbMV0uZmlyZVVuY2hlY2soYWNjZXNzb3IudmFsdWUpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIF9pc1NhbWVHcm91cChjb250cm9sUGFpciwgYWNjZXNzb3IpIHtcbiAgICBpZiAoIWNvbnRyb2xQYWlyWzBdLmNvbnRyb2wpIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gY29udHJvbFBhaXJbMF0uX3BhcmVudCA9PT0gYWNjZXNzb3IuX2NvbnRyb2wuX3BhcmVudCAmJiBjb250cm9sUGFpclsxXS5uYW1lID09PSBhY2Nlc3Nvci5uYW1lO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFJhZGlvQ29udHJvbFJlZ2lzdHJ5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSYWRpb0NvbnRyb2xSZWdpc3RyeSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogUmFkaW9Db250cm9sUmVnaXN0cnksXG4gICAgZmFjdG9yeTogUmFkaW9Db250cm9sUmVnaXN0cnkuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShSYWRpb0NvbnRyb2xSZWdpc3RyeSwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yIGV4dGVuZHMgQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgX3JlZ2lzdHJ5O1xuICBfaW5qZWN0b3I7XG4gIF9zdGF0ZTtcbiAgX2NvbnRyb2w7XG4gIF9mbjtcbiAgc2V0RGlzYWJsZWRTdGF0ZUZpcmVkID0gZmFsc2U7XG4gIG9uQ2hhbmdlID0gKCkgPT4ge307XG4gIG5hbWU7XG4gIGZvcm1Db250cm9sTmFtZTtcbiAgdmFsdWU7XG4gIGNhbGxTZXREaXNhYmxlZFN0YXRlID0gaW5qZWN0KENBTExfU0VUX0RJU0FCTEVEX1NUQVRFLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSkgPz8gc2V0RGlzYWJsZWRTdGF0ZURlZmF1bHQ7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyLCBlbGVtZW50UmVmLCBfcmVnaXN0cnksIF9pbmplY3Rvcikge1xuICAgIHN1cGVyKHJlbmRlcmVyLCBlbGVtZW50UmVmKTtcbiAgICB0aGlzLl9yZWdpc3RyeSA9IF9yZWdpc3RyeTtcbiAgICB0aGlzLl9pbmplY3RvciA9IF9pbmplY3RvcjtcbiAgfVxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzKSB7XG4gICAgY29uc3QgY29udHJvbCA9IHRoaXMuX2NvbnRyb2w/LmNvbnRyb2w7XG4gICAgaWYgKGNoYW5nZXNbJ3ZhbHVlJ10gJiYgY29udHJvbCkge1xuICAgICAgdGhpcy53cml0ZVZhbHVlKGNvbnRyb2wudmFsdWUpO1xuICAgIH1cbiAgfVxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLl9jb250cm9sID0gdGhpcy5faW5qZWN0b3IuZ2V0KE5nQ29udHJvbCk7XG4gICAgdGhpcy5fY2hlY2tOYW1lKCk7XG4gICAgdGhpcy5fcmVnaXN0cnkuYWRkKHRoaXMuX2NvbnRyb2wsIHRoaXMpO1xuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuX3JlZ2lzdHJ5LnJlbW92ZSh0aGlzKTtcbiAgfVxuICB3cml0ZVZhbHVlKHZhbHVlKSB7XG4gICAgdGhpcy5fc3RhdGUgPSB2YWx1ZSA9PT0gdGhpcy52YWx1ZTtcbiAgICB0aGlzLnNldFByb3BlcnR5KCdjaGVja2VkJywgdGhpcy5fc3RhdGUpO1xuICB9XG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm4pIHtcbiAgICB0aGlzLl9mbiA9IGZuO1xuICAgIHRoaXMub25DaGFuZ2UgPSAoKSA9PiB7XG4gICAgICBmbih0aGlzLnZhbHVlKTtcbiAgICAgIHRoaXMuX3JlZ2lzdHJ5LnNlbGVjdCh0aGlzKTtcbiAgICB9O1xuICB9XG4gIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZCkge1xuICAgIGlmICh0aGlzLnNldERpc2FibGVkU3RhdGVGaXJlZCB8fCBpc0Rpc2FibGVkIHx8IHRoaXMuY2FsbFNldERpc2FibGVkU3RhdGUgPT09ICd3aGVuRGlzYWJsZWRGb3JMZWdhY3lDb2RlJykge1xuICAgICAgdGhpcy5zZXRQcm9wZXJ0eSgnZGlzYWJsZWQnLCBpc0Rpc2FibGVkKTtcbiAgICB9XG4gICAgdGhpcy5zZXREaXNhYmxlZFN0YXRlRmlyZWQgPSB0cnVlO1xuICB9XG4gIGZpcmVVbmNoZWNrKHZhbHVlKSB7XG4gICAgdGhpcy53cml0ZVZhbHVlKHZhbHVlKTtcbiAgfVxuICBfY2hlY2tOYW1lKCkge1xuICAgIGlmICh0aGlzLm5hbWUgJiYgdGhpcy5mb3JtQ29udHJvbE5hbWUgJiYgdGhpcy5uYW1lICE9PSB0aGlzLmZvcm1Db250cm9sTmFtZSAmJiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSkge1xuICAgICAgdGhyb3dOYW1lRXJyb3IoKTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLm5hbWUgJiYgdGhpcy5mb3JtQ29udHJvbE5hbWUpIHRoaXMubmFtZSA9IHRoaXMuZm9ybUNvbnRyb2xOYW1lO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFJhZGlvQ29udHJvbFZhbHVlQWNjZXNzb3JfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlJlbmRlcmVyMiksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuRWxlbWVudFJlZiksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoUmFkaW9Db250cm9sUmVnaXN0cnkpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLkluamVjdG9yKSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IFJhZGlvQ29udHJvbFZhbHVlQWNjZXNzb3IsXG4gICAgc2VsZWN0b3JzOiBbW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwicmFkaW9cIiwgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJyYWRpb1wiLCBcImZvcm1Db250cm9sXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXSwgW1wiaW5wdXRcIiwgXCJ0eXBlXCIsIFwicmFkaW9cIiwgXCJuZ01vZGVsXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXV0sXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcImNoYW5nZVwiLCBmdW5jdGlvbiBSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yX2NoYW5nZV9Ib3N0QmluZGluZ0hhbmRsZXIoKSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vbkNoYW5nZSgpO1xuICAgICAgICB9KShcImJsdXJcIiwgZnVuY3Rpb24gUmFkaW9Db250cm9sVmFsdWVBY2Nlc3Nvcl9ibHVyX0hvc3RCaW5kaW5nSGFuZGxlcigpIHtcbiAgICAgICAgICByZXR1cm4gY3R4Lm9uVG91Y2hlZCgpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgbmFtZTogXCJuYW1lXCIsXG4gICAgICBmb3JtQ29udHJvbE5hbWU6IFwiZm9ybUNvbnRyb2xOYW1lXCIsXG4gICAgICB2YWx1ZTogXCJ2YWx1ZVwiXG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtSQURJT19WQUxVRV9BQ0NFU1NPUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlLCBpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJhZGlvQ29udHJvbFZhbHVlQWNjZXNzb3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ2lucHV0W3R5cGU9cmFkaW9dOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sTmFtZV0saW5wdXRbdHlwZT1yYWRpb106bm90KFtuZ05vQ3ZhXSlbZm9ybUNvbnRyb2xdLGlucHV0W3R5cGU9cmFkaW9dOm5vdChbbmdOb0N2YV0pW25nTW9kZWxdJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJyhjaGFuZ2UpJzogJ29uQ2hhbmdlKCknLFxuICAgICAgICAnKGJsdXIpJzogJ29uVG91Y2hlZCgpJ1xuICAgICAgfSxcbiAgICAgIHByb3ZpZGVyczogW1JBRElPX1ZBTFVFX0FDQ0VTU09SXSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuUmVuZGVyZXIyXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5FbGVtZW50UmVmXG4gIH0sIHtcbiAgICB0eXBlOiBSYWRpb0NvbnRyb2xSZWdpc3RyeVxuICB9LCB7XG4gICAgdHlwZTogaTAuSW5qZWN0b3JcbiAgfV0sIHtcbiAgICBuYW1lOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBmb3JtQ29udHJvbE5hbWU6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIHZhbHVlOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XVxuICB9KTtcbn0pKCk7XG5jb25zdCBSQU5HRV9WQUxVRV9BQ0NFU1NPUiA9IHtcbiAgcHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IFJhbmdlVmFsdWVBY2Nlc3NvciksXG4gIG11bHRpOiB0cnVlXG59O1xuY2xhc3MgUmFuZ2VWYWx1ZUFjY2Vzc29yIGV4dGVuZHMgQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgd3JpdGVWYWx1ZSh2YWx1ZSkge1xuICAgIHRoaXMuc2V0UHJvcGVydHkoJ3ZhbHVlJywgcGFyc2VGbG9hdCh2YWx1ZSkpO1xuICB9XG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm4pIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gdmFsdWUgPT4ge1xuICAgICAgZm4odmFsdWUgPT0gJycgPyBudWxsIDogcGFyc2VGbG9hdCh2YWx1ZSkpO1xuICAgIH07XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gLyogQF9fUFVSRV9fICovKCgpID0+IHtcbiAgICBsZXQgybVSYW5nZVZhbHVlQWNjZXNzb3JfQmFzZUZhY3Rvcnk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIFJhbmdlVmFsdWVBY2Nlc3Nvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICByZXR1cm4gKMm1UmFuZ2VWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5IHx8ICjJtVJhbmdlVmFsdWVBY2Nlc3Nvcl9CYXNlRmFjdG9yeSA9IGkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5KFJhbmdlVmFsdWVBY2Nlc3NvcikpKShfX25nRmFjdG9yeVR5cGVfXyB8fCBSYW5nZVZhbHVlQWNjZXNzb3IpO1xuICAgIH07XG4gIH0pKCk7XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IFJhbmdlVmFsdWVBY2Nlc3NvcixcbiAgICBzZWxlY3RvcnM6IFtbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJyYW5nZVwiLCBcImZvcm1Db250cm9sTmFtZVwiLCBcIlwiLCAzLCBcIm5nTm9DdmFcIiwgXCJcIl0sIFtcImlucHV0XCIsIFwidHlwZVwiLCBcInJhbmdlXCIsIFwiZm9ybUNvbnRyb2xcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJpbnB1dFwiLCBcInR5cGVcIiwgXCJyYW5nZVwiLCBcIm5nTW9kZWxcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdXSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIFJhbmdlVmFsdWVBY2Nlc3Nvcl9Ib3N0QmluZGluZ3MocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1bGlzdGVuZXIoXCJjaGFuZ2VcIiwgZnVuY3Rpb24gUmFuZ2VWYWx1ZUFjY2Vzc29yX2NoYW5nZV9Ib3N0QmluZGluZ0hhbmRsZXIoJGV2ZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vbkNoYW5nZSgkZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgfSkoXCJpbnB1dFwiLCBmdW5jdGlvbiBSYW5nZVZhbHVlQWNjZXNzb3JfaW5wdXRfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25DaGFuZ2UoJGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICAgIH0pKFwiYmx1clwiLCBmdW5jdGlvbiBSYW5nZVZhbHVlQWNjZXNzb3JfYmx1cl9Ib3N0QmluZGluZ0hhbmRsZXIoKSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vblRvdWNoZWQoKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtSQU5HRV9WQUxVRV9BQ0NFU1NPUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJhbmdlVmFsdWVBY2Nlc3NvciwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnaW5wdXRbdHlwZT1yYW5nZV06bm90KFtuZ05vQ3ZhXSlbZm9ybUNvbnRyb2xOYW1lXSxpbnB1dFt0eXBlPXJhbmdlXTpub3QoW25nTm9DdmFdKVtmb3JtQ29udHJvbF0saW5wdXRbdHlwZT1yYW5nZV06bm90KFtuZ05vQ3ZhXSlbbmdNb2RlbF0nLFxuICAgICAgaG9zdDoge1xuICAgICAgICAnKGNoYW5nZSknOiAnb25DaGFuZ2UoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSknLFxuICAgICAgICAnKGlucHV0KSc6ICdvbkNoYW5nZSgkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKScsXG4gICAgICAgICcoYmx1ciknOiAnb25Ub3VjaGVkKCknXG4gICAgICB9LFxuICAgICAgcHJvdmlkZXJzOiBbUkFOR0VfVkFMVUVfQUNDRVNTT1JdLFxuICAgICAgc3RhbmRhbG9uZTogZmFsc2VcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY2xhc3MgRm9ybUFycmF5IGV4dGVuZHMgQWJzdHJhY3RDb250cm9sIHtcbiAgY29uc3RydWN0b3IoY29udHJvbHMsIHZhbGlkYXRvck9yT3B0cywgYXN5bmNWYWxpZGF0b3IpIHtcbiAgICBzdXBlcihwaWNrVmFsaWRhdG9ycyh2YWxpZGF0b3JPck9wdHMpLCBwaWNrQXN5bmNWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9yLCB2YWxpZGF0b3JPck9wdHMpKTtcbiAgICB0aGlzLmNvbnRyb2xzID0gY29udHJvbHM7XG4gICAgdGhpcy5faW5pdE9ic2VydmFibGVzKCk7XG4gICAgdGhpcy5fc2V0VXBkYXRlU3RyYXRlZ3kodmFsaWRhdG9yT3JPcHRzKTtcbiAgICB0aGlzLl9zZXRVcENvbnRyb2xzKCk7XG4gICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgIG9ubHlTZWxmOiB0cnVlLFxuICAgICAgZW1pdEV2ZW50OiAhIXRoaXMuYXN5bmNWYWxpZGF0b3JcbiAgICB9KTtcbiAgfVxuICBjb250cm9scztcbiAgYXQoaW5kZXgpIHtcbiAgICByZXR1cm4gdGhpcy5jb250cm9sc1t0aGlzLl9hZGp1c3RJbmRleChpbmRleCldO1xuICB9XG4gIHB1c2goY29udHJvbCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY29udHJvbCkpIHtcbiAgICAgIGNvbnRyb2wuZm9yRWFjaChjdHJsID0+IHtcbiAgICAgICAgdGhpcy5jb250cm9scy5wdXNoKGN0cmwpO1xuICAgICAgICB0aGlzLl9yZWdpc3RlckNvbnRyb2woY3RybCk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb250cm9scy5wdXNoKGNvbnRyb2wpO1xuICAgICAgdGhpcy5fcmVnaXN0ZXJDb250cm9sKGNvbnRyb2wpO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgIH0pO1xuICAgIHRoaXMuX29uQ29sbGVjdGlvbkNoYW5nZSgpO1xuICB9XG4gIGluc2VydChpbmRleCwgY29udHJvbCwgb3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5jb250cm9scy5zcGxpY2UoaW5kZXgsIDAsIGNvbnRyb2wpO1xuICAgIHRoaXMuX3JlZ2lzdGVyQ29udHJvbChjb250cm9sKTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgIH0pO1xuICB9XG4gIHJlbW92ZUF0KGluZGV4LCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgYWRqdXN0ZWRJbmRleCA9IHRoaXMuX2FkanVzdEluZGV4KGluZGV4KTtcbiAgICBpZiAoYWRqdXN0ZWRJbmRleCA8IDApIGFkanVzdGVkSW5kZXggPSAwO1xuICAgIGlmICh0aGlzLmNvbnRyb2xzW2FkanVzdGVkSW5kZXhdKSB0aGlzLmNvbnRyb2xzW2FkanVzdGVkSW5kZXhdLl9yZWdpc3Rlck9uQ29sbGVjdGlvbkNoYW5nZSgoKSA9PiB7fSk7XG4gICAgdGhpcy5jb250cm9scy5zcGxpY2UoYWRqdXN0ZWRJbmRleCwgMSk7XG4gICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgIGVtaXRFdmVudDogb3B0aW9ucy5lbWl0RXZlbnRcbiAgICB9KTtcbiAgfVxuICBzZXRDb250cm9sKGluZGV4LCBjb250cm9sLCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgYWRqdXN0ZWRJbmRleCA9IHRoaXMuX2FkanVzdEluZGV4KGluZGV4KTtcbiAgICBpZiAoYWRqdXN0ZWRJbmRleCA8IDApIGFkanVzdGVkSW5kZXggPSAwO1xuICAgIGlmICh0aGlzLmNvbnRyb2xzW2FkanVzdGVkSW5kZXhdKSB0aGlzLmNvbnRyb2xzW2FkanVzdGVkSW5kZXhdLl9yZWdpc3Rlck9uQ29sbGVjdGlvbkNoYW5nZSgoKSA9PiB7fSk7XG4gICAgdGhpcy5jb250cm9scy5zcGxpY2UoYWRqdXN0ZWRJbmRleCwgMSk7XG4gICAgaWYgKGNvbnRyb2wpIHtcbiAgICAgIHRoaXMuY29udHJvbHMuc3BsaWNlKGFkanVzdGVkSW5kZXgsIDAsIGNvbnRyb2wpO1xuICAgICAgdGhpcy5fcmVnaXN0ZXJDb250cm9sKGNvbnRyb2wpO1xuICAgIH1cbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgIH0pO1xuICAgIHRoaXMuX29uQ29sbGVjdGlvbkNoYW5nZSgpO1xuICB9XG4gIGdldCBsZW5ndGgoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbHMubGVuZ3RoO1xuICB9XG4gIHNldFZhbHVlKHZhbHVlLCBvcHRpb25zID0ge30pIHtcbiAgICB1bnRyYWNrZWQoKCkgPT4ge1xuICAgICAgYXNzZXJ0QWxsVmFsdWVzUHJlc2VudCh0aGlzLCBmYWxzZSwgdmFsdWUpO1xuICAgICAgdmFsdWUuZm9yRWFjaCgobmV3VmFsdWUsIGluZGV4KSA9PiB7XG4gICAgICAgIGFzc2VydENvbnRyb2xQcmVzZW50KHRoaXMsIGZhbHNlLCBpbmRleCk7XG4gICAgICAgIHRoaXMuYXQoaW5kZXgpLnNldFZhbHVlKG5ld1ZhbHVlLCB7XG4gICAgICAgICAgb25seVNlbGY6IHRydWUsXG4gICAgICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KG9wdGlvbnMpO1xuICAgIH0pO1xuICB9XG4gIHBhdGNoVmFsdWUodmFsdWUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm47XG4gICAgdmFsdWUuZm9yRWFjaCgobmV3VmFsdWUsIGluZGV4KSA9PiB7XG4gICAgICBpZiAodGhpcy5hdChpbmRleCkpIHtcbiAgICAgICAgdGhpcy5hdChpbmRleCkucGF0Y2hWYWx1ZShuZXdWYWx1ZSwge1xuICAgICAgICAgIG9ubHlTZWxmOiB0cnVlLFxuICAgICAgICAgIGVtaXRFdmVudDogb3B0aW9ucy5lbWl0RXZlbnRcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KG9wdGlvbnMpO1xuICB9XG4gIHJlc2V0KHZhbHVlID0gW10sIG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMuX2ZvckVhY2hDaGlsZCgoY29udHJvbCwgaW5kZXgpID0+IHtcbiAgICAgIGNvbnRyb2wucmVzZXQodmFsdWVbaW5kZXhdLCB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIG9ubHlTZWxmOiB0cnVlXG4gICAgICB9KTtcbiAgICB9KTtcbiAgICB0aGlzLl91cGRhdGVQcmlzdGluZShvcHRpb25zLCB0aGlzKTtcbiAgICB0aGlzLl91cGRhdGVUb3VjaGVkKG9wdGlvbnMsIHRoaXMpO1xuICAgIHRoaXMudXBkYXRlVmFsdWVBbmRWYWxpZGl0eShvcHRpb25zKTtcbiAgICBpZiAob3B0aW9ucz8uZW1pdEV2ZW50ICE9PSBmYWxzZSkge1xuICAgICAgdGhpcy5fZXZlbnRzLm5leHQobmV3IEZvcm1SZXNldEV2ZW50KHRoaXMpKTtcbiAgICB9XG4gIH1cbiAgZ2V0UmF3VmFsdWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbHMubWFwKGNvbnRyb2wgPT4gY29udHJvbC5nZXRSYXdWYWx1ZSgpKTtcbiAgfVxuICBjbGVhcihvcHRpb25zID0ge30pIHtcbiAgICBpZiAodGhpcy5jb250cm9scy5sZW5ndGggPCAxKSByZXR1cm47XG4gICAgdGhpcy5fZm9yRWFjaENoaWxkKGNvbnRyb2wgPT4gY29udHJvbC5fcmVnaXN0ZXJPbkNvbGxlY3Rpb25DaGFuZ2UoKCkgPT4ge30pKTtcbiAgICB0aGlzLmNvbnRyb2xzLnNwbGljZSgwKTtcbiAgICB0aGlzLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBvcHRpb25zLmVtaXRFdmVudFxuICAgIH0pO1xuICB9XG4gIF9hZGp1c3RJbmRleChpbmRleCkge1xuICAgIHJldHVybiBpbmRleCA8IDAgPyBpbmRleCArIHRoaXMubGVuZ3RoIDogaW5kZXg7XG4gIH1cbiAgX3N5bmNQZW5kaW5nQ29udHJvbHMoKSB7XG4gICAgbGV0IHN1YnRyZWVVcGRhdGVkID0gdGhpcy5jb250cm9scy5yZWR1Y2UoKHVwZGF0ZWQsIGNoaWxkKSA9PiB7XG4gICAgICByZXR1cm4gY2hpbGQuX3N5bmNQZW5kaW5nQ29udHJvbHMoKSA/IHRydWUgOiB1cGRhdGVkO1xuICAgIH0sIGZhbHNlKTtcbiAgICBpZiAoc3VidHJlZVVwZGF0ZWQpIHRoaXMudXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7XG4gICAgICBvbmx5U2VsZjogdHJ1ZVxuICAgIH0pO1xuICAgIHJldHVybiBzdWJ0cmVlVXBkYXRlZDtcbiAgfVxuICBfZm9yRWFjaENoaWxkKGNiKSB7XG4gICAgdGhpcy5jb250cm9scy5mb3JFYWNoKChjb250cm9sLCBpbmRleCkgPT4ge1xuICAgICAgY2IoY29udHJvbCwgaW5kZXgpO1xuICAgIH0pO1xuICB9XG4gIF91cGRhdGVWYWx1ZSgpIHtcbiAgICB0aGlzLnZhbHVlID0gdGhpcy5jb250cm9scy5maWx0ZXIoY29udHJvbCA9PiBjb250cm9sLmVuYWJsZWQgfHwgdGhpcy5kaXNhYmxlZCkubWFwKGNvbnRyb2wgPT4gY29udHJvbC52YWx1ZSk7XG4gIH1cbiAgX2FueUNvbnRyb2xzKGNvbmRpdGlvbikge1xuICAgIHJldHVybiB0aGlzLmNvbnRyb2xzLnNvbWUoY29udHJvbCA9PiBjb250cm9sLmVuYWJsZWQgJiYgY29uZGl0aW9uKGNvbnRyb2wpKTtcbiAgfVxuICBfc2V0VXBDb250cm9scygpIHtcbiAgICB0aGlzLl9mb3JFYWNoQ2hpbGQoY29udHJvbCA9PiB0aGlzLl9yZWdpc3RlckNvbnRyb2woY29udHJvbCkpO1xuICB9XG4gIF9hbGxDb250cm9sc0Rpc2FibGVkKCkge1xuICAgIGZvciAoY29uc3QgY29udHJvbCBvZiB0aGlzLmNvbnRyb2xzKSB7XG4gICAgICBpZiAoY29udHJvbC5lbmFibGVkKSByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmNvbnRyb2xzLmxlbmd0aCA+IDAgfHwgdGhpcy5kaXNhYmxlZDtcbiAgfVxuICBfcmVnaXN0ZXJDb250cm9sKGNvbnRyb2wpIHtcbiAgICBjb250cm9sLnNldFBhcmVudCh0aGlzKTtcbiAgICBjb250cm9sLl9yZWdpc3Rlck9uQ29sbGVjdGlvbkNoYW5nZSh0aGlzLl9vbkNvbGxlY3Rpb25DaGFuZ2UpO1xuICB9XG4gIF9maW5kKG5hbWUpIHtcbiAgICByZXR1cm4gdGhpcy5hdChuYW1lKSA/PyBudWxsO1xuICB9XG59XG5jb25zdCBVbnR5cGVkRm9ybUFycmF5ID0gRm9ybUFycmF5O1xuY29uc3QgaXNGb3JtQXJyYXkgPSBjb250cm9sID0+IGNvbnRyb2wgaW5zdGFuY2VvZiBGb3JtQXJyYXk7XG5jbGFzcyBBYnN0cmFjdEZvcm1EaXJlY3RpdmUgZXh0ZW5kcyBDb250cm9sQ29udGFpbmVyIHtcbiAgY2FsbFNldERpc2FibGVkU3RhdGU7XG4gIGdldCBzdWJtaXR0ZWQoKSB7XG4gICAgcmV0dXJuIHVudHJhY2tlZCh0aGlzLl9zdWJtaXR0ZWRSZWFjdGl2ZSk7XG4gIH1cbiAgc2V0IHN1Ym1pdHRlZCh2YWx1ZSkge1xuICAgIHRoaXMuX3N1Ym1pdHRlZFJlYWN0aXZlLnNldCh2YWx1ZSk7XG4gIH1cbiAgX3N1Ym1pdHRlZCA9IGNvbXB1dGVkKCgpID0+IHRoaXMuX3N1Ym1pdHRlZFJlYWN0aXZlKCksIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJfc3VibWl0dGVkXCJcbiAgfV0gOiBbXSkpO1xuICBfc3VibWl0dGVkUmVhY3RpdmUgPSBzaWduYWwoZmFsc2UsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJfc3VibWl0dGVkUmVhY3RpdmVcIlxuICB9XSA6IFtdKSk7XG4gIF9vbGRGb3JtO1xuICBfb25Db2xsZWN0aW9uQ2hhbmdlID0gKCkgPT4gdGhpcy5fdXBkYXRlRG9tVmFsdWUoKTtcbiAgZGlyZWN0aXZlcyA9IFtdO1xuICBjb25zdHJ1Y3Rvcih2YWxpZGF0b3JzLCBhc3luY1ZhbGlkYXRvcnMsIGNhbGxTZXREaXNhYmxlZFN0YXRlKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLmNhbGxTZXREaXNhYmxlZFN0YXRlID0gY2FsbFNldERpc2FibGVkU3RhdGU7XG4gICAgdGhpcy5fc2V0VmFsaWRhdG9ycyh2YWxpZGF0b3JzKTtcbiAgICB0aGlzLl9zZXRBc3luY1ZhbGlkYXRvcnMoYXN5bmNWYWxpZGF0b3JzKTtcbiAgfVxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzKSB7XG4gICAgdGhpcy5vbkNoYW5nZXMoY2hhbmdlcyk7XG4gIH1cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5vbkRlc3Ryb3koKTtcbiAgfVxuICBvbkNoYW5nZXMoY2hhbmdlcykge1xuICAgIHRoaXMuX2NoZWNrRm9ybVByZXNlbnQoKTtcbiAgICBpZiAoY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZm9ybScpKSB7XG4gICAgICB0aGlzLl91cGRhdGVWYWxpZGF0b3JzKCk7XG4gICAgICB0aGlzLl91cGRhdGVEb21WYWx1ZSgpO1xuICAgICAgdGhpcy5fdXBkYXRlUmVnaXN0cmF0aW9ucygpO1xuICAgICAgdGhpcy5fb2xkRm9ybSA9IHRoaXMuZm9ybTtcbiAgICB9XG4gIH1cbiAgb25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLmZvcm0pIHtcbiAgICAgIGNsZWFuVXBWYWxpZGF0b3JzKHRoaXMuZm9ybSwgdGhpcyk7XG4gICAgICBpZiAodGhpcy5mb3JtLl9vbkNvbGxlY3Rpb25DaGFuZ2UgPT09IHRoaXMuX29uQ29sbGVjdGlvbkNoYW5nZSkge1xuICAgICAgICB0aGlzLmZvcm0uX3JlZ2lzdGVyT25Db2xsZWN0aW9uQ2hhbmdlKCgpID0+IHt9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZ2V0IGZvcm1EaXJlY3RpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgZ2V0IHBhdGgoKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGFkZENvbnRyb2woZGlyKSB7XG4gICAgY29uc3QgY3RybCA9IHRoaXMuZm9ybS5nZXQoZGlyLnBhdGgpO1xuICAgIGRpci5fc2V0dXBXaXRoRm9ybShjdHJsLCB0aGlzLmNhbGxTZXREaXNhYmxlZFN0YXRlKTtcbiAgICBjdHJsLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgZW1pdEV2ZW50OiBmYWxzZVxuICAgIH0pO1xuICAgIHRoaXMuZGlyZWN0aXZlcy5wdXNoKGRpcik7XG4gICAgcmV0dXJuIGN0cmw7XG4gIH1cbiAgZ2V0Q29udHJvbChkaXIpIHtcbiAgICByZXR1cm4gdGhpcy5mb3JtLmdldChkaXIucGF0aCk7XG4gIH1cbiAgcmVtb3ZlQ29udHJvbChkaXIpIHtcbiAgICBjbGVhblVwQ29udHJvbChkaXIuY29udHJvbCB8fCBudWxsLCBkaXIsIGZhbHNlKTtcbiAgICByZW1vdmVMaXN0SXRlbSQxKHRoaXMuZGlyZWN0aXZlcywgZGlyKTtcbiAgfVxuICBhZGRGb3JtR3JvdXAoZGlyKSB7XG4gICAgdGhpcy5fc2V0VXBGb3JtQ29udGFpbmVyKGRpcik7XG4gIH1cbiAgcmVtb3ZlRm9ybUdyb3VwKGRpcikge1xuICAgIHRoaXMuX2NsZWFuVXBGb3JtQ29udGFpbmVyKGRpcik7XG4gIH1cbiAgZ2V0Rm9ybUdyb3VwKGRpcikge1xuICAgIHJldHVybiB0aGlzLmZvcm0uZ2V0KGRpci5wYXRoKTtcbiAgfVxuICBnZXRGb3JtQXJyYXkoZGlyKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybS5nZXQoZGlyLnBhdGgpO1xuICB9XG4gIGFkZEZvcm1BcnJheShkaXIpIHtcbiAgICB0aGlzLl9zZXRVcEZvcm1Db250YWluZXIoZGlyKTtcbiAgfVxuICByZW1vdmVGb3JtQXJyYXkoZGlyKSB7XG4gICAgdGhpcy5fY2xlYW5VcEZvcm1Db250YWluZXIoZGlyKTtcbiAgfVxuICB1cGRhdGVNb2RlbChkaXIsIHZhbHVlKSB7XG4gICAgY29uc3QgY3RybCA9IHRoaXMuZm9ybS5nZXQoZGlyLnBhdGgpO1xuICAgIGN0cmwuc2V0VmFsdWUodmFsdWUpO1xuICB9XG4gIG9uUmVzZXQoKSB7XG4gICAgdGhpcy5yZXNldEZvcm0oKTtcbiAgfVxuICByZXNldEZvcm0odmFsdWUgPSB1bmRlZmluZWQsIG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMuZm9ybS5yZXNldCh2YWx1ZSwgb3B0aW9ucyk7XG4gICAgdGhpcy5fc3VibWl0dGVkUmVhY3RpdmUuc2V0KGZhbHNlKTtcbiAgfVxuICBvblN1Ym1pdCgkZXZlbnQpIHtcbiAgICB0aGlzLnN1Ym1pdHRlZCA9IHRydWU7XG4gICAgc3luY1BlbmRpbmdDb250cm9scyh0aGlzLmZvcm0sIHRoaXMuZGlyZWN0aXZlcyk7XG4gICAgdGhpcy5uZ1N1Ym1pdC5lbWl0KCRldmVudCk7XG4gICAgdGhpcy5mb3JtLl9ldmVudHMubmV4dChuZXcgRm9ybVN1Ym1pdHRlZEV2ZW50KHRoaXMuY29udHJvbCkpO1xuICAgIHJldHVybiAkZXZlbnQ/LnRhcmdldD8ubWV0aG9kID09PSAnZGlhbG9nJztcbiAgfVxuICBfdXBkYXRlRG9tVmFsdWUoKSB7XG4gICAgdGhpcy5kaXJlY3RpdmVzLmZvckVhY2goZGlyID0+IHtcbiAgICAgIGNvbnN0IG9sZEN0cmwgPSBkaXIuY29udHJvbDtcbiAgICAgIGNvbnN0IG5ld0N0cmwgPSB0aGlzLmZvcm0uZ2V0KGRpci5wYXRoKTtcbiAgICAgIGlmIChvbGRDdHJsICE9PSBuZXdDdHJsKSB7XG4gICAgICAgIGNsZWFuVXBDb250cm9sKG9sZEN0cmwgfHwgbnVsbCwgZGlyKTtcbiAgICAgICAgaWYgKGlzRm9ybUNvbnRyb2wobmV3Q3RybCkpIHtcbiAgICAgICAgICBkaXIuX3NldHVwV2l0aEZvcm0obmV3Q3RybCwgdGhpcy5jYWxsU2V0RGlzYWJsZWRTdGF0ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLmZvcm0uX3VwZGF0ZVRyZWVWYWxpZGl0eSh7XG4gICAgICBlbWl0RXZlbnQ6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgX3NldFVwRm9ybUNvbnRhaW5lcihkaXIpIHtcbiAgICBjb25zdCBjdHJsID0gdGhpcy5mb3JtLmdldChkaXIucGF0aCk7XG4gICAgc2V0VXBGb3JtQ29udGFpbmVyKGN0cmwsIGRpcik7XG4gICAgY3RybC51cGRhdGVWYWx1ZUFuZFZhbGlkaXR5KHtcbiAgICAgIGVtaXRFdmVudDogZmFsc2VcbiAgICB9KTtcbiAgfVxuICBfY2xlYW5VcEZvcm1Db250YWluZXIoZGlyKSB7XG4gICAgY29uc3QgY3RybCA9IHRoaXMuZm9ybT8uZ2V0KGRpci5wYXRoKTtcbiAgICBpZiAoY3RybCkge1xuICAgICAgY29uc3QgaXNDb250cm9sVXBkYXRlZCA9IGNsZWFuVXBGb3JtQ29udGFpbmVyKGN0cmwsIGRpcik7XG4gICAgICBpZiAoaXNDb250cm9sVXBkYXRlZCkge1xuICAgICAgICBjdHJsLnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoe1xuICAgICAgICAgIGVtaXRFdmVudDogZmFsc2VcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF91cGRhdGVSZWdpc3RyYXRpb25zKCkge1xuICAgIHRoaXMuZm9ybS5fcmVnaXN0ZXJPbkNvbGxlY3Rpb25DaGFuZ2UodGhpcy5fb25Db2xsZWN0aW9uQ2hhbmdlKTtcbiAgICB0aGlzLl9vbGRGb3JtPy5fcmVnaXN0ZXJPbkNvbGxlY3Rpb25DaGFuZ2UoKCkgPT4ge30pO1xuICB9XG4gIF91cGRhdGVWYWxpZGF0b3JzKCkge1xuICAgIHNldFVwVmFsaWRhdG9ycyh0aGlzLmZvcm0sIHRoaXMpO1xuICAgIGlmICh0aGlzLl9vbGRGb3JtKSB7XG4gICAgICBjbGVhblVwVmFsaWRhdG9ycyh0aGlzLl9vbGRGb3JtLCB0aGlzKTtcbiAgICB9XG4gIH1cbiAgX2NoZWNrRm9ybVByZXNlbnQoKSB7XG4gICAgaWYgKCF0aGlzLmZvcm0gJiYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkpIHtcbiAgICAgIHRocm93IG1pc3NpbmdGb3JtRXhjZXB0aW9uKCk7XG4gICAgfVxuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEFic3RyYWN0Rm9ybURpcmVjdGl2ZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEFic3RyYWN0Rm9ybURpcmVjdGl2ZSkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19WQUxJREFUT1JTLCAxMCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfQVNZTkNfVkFMSURBVE9SUywgMTApLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KENBTExfU0VUX0RJU0FCTEVEX1NUQVRFLCA4KSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IEFic3RyYWN0Rm9ybURpcmVjdGl2ZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmUsIGkwLsm1ybVOZ09uQ2hhbmdlc0ZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoQWJzdHJhY3RGb3JtRGlyZWN0aXZlLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogU2VsZlxuICAgIH0sIHtcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtOR19WQUxJREFUT1JTXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogU2VsZlxuICAgIH0sIHtcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtOR19BU1lOQ19WQUxJREFUT1JTXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0NBTExfU0VUX0RJU0FCTEVEX1NUQVRFXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jb25zdCBmb3JtRGlyZWN0aXZlUHJvdmlkZXIkMSA9IHtcbiAgcHJvdmlkZTogQ29udHJvbENvbnRhaW5lcixcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gRm9ybUFycmF5RGlyZWN0aXZlKVxufTtcbmNsYXNzIEZvcm1BcnJheURpcmVjdGl2ZSBleHRlbmRzIEFic3RyYWN0Rm9ybURpcmVjdGl2ZSB7XG4gIGZvcm0gPSBudWxsO1xuICBuZ1N1Ym1pdCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgZ2V0IGNvbnRyb2woKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtUZvcm1BcnJheURpcmVjdGl2ZV9CYXNlRmFjdG9yeTtcbiAgICByZXR1cm4gZnVuY3Rpb24gRm9ybUFycmF5RGlyZWN0aXZlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVGb3JtQXJyYXlEaXJlY3RpdmVfQmFzZUZhY3RvcnkgfHwgKMm1Rm9ybUFycmF5RGlyZWN0aXZlX0Jhc2VGYWN0b3J5ID0gaTAuybXJtWdldEluaGVyaXRlZEZhY3RvcnkoRm9ybUFycmF5RGlyZWN0aXZlKSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEZvcm1BcnJheURpcmVjdGl2ZSk7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogRm9ybUFycmF5RGlyZWN0aXZlLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcImZvcm1BcnJheVwiLCBcIlwiXV0sXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBGb3JtQXJyYXlEaXJlY3RpdmVfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwic3VibWl0XCIsIGZ1bmN0aW9uIEZvcm1BcnJheURpcmVjdGl2ZV9zdWJtaXRfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25TdWJtaXQoJGV2ZW50KTtcbiAgICAgICAgfSkoXCJyZXNldFwiLCBmdW5jdGlvbiBGb3JtQXJyYXlEaXJlY3RpdmVfcmVzZXRfSG9zdEJpbmRpbmdIYW5kbGVyKCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25SZXNldCgpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgZm9ybTogWzAsIFwiZm9ybUFycmF5XCIsIFwiZm9ybVwiXVxuICAgIH0sXG4gICAgb3V0cHV0czoge1xuICAgICAgbmdTdWJtaXQ6IFwibmdTdWJtaXRcIlxuICAgIH0sXG4gICAgZXhwb3J0QXM6IFtcIm5nRm9ybVwiXSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtmb3JtRGlyZWN0aXZlUHJvdmlkZXIkMV0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEZvcm1BcnJheURpcmVjdGl2ZSwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW2Zvcm1BcnJheV0nLFxuICAgICAgcHJvdmlkZXJzOiBbZm9ybURpcmVjdGl2ZVByb3ZpZGVyJDFdLFxuICAgICAgaG9zdDoge1xuICAgICAgICAnKHN1Ym1pdCknOiAnb25TdWJtaXQoJGV2ZW50KScsXG4gICAgICAgICcocmVzZXQpJzogJ29uUmVzZXQoKSdcbiAgICAgIH0sXG4gICAgICBleHBvcnRBczogJ25nRm9ybScsXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCBudWxsLCB7XG4gICAgZm9ybTogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogWydmb3JtQXJyYXknXVxuICAgIH1dLFxuICAgIG5nU3VibWl0OiBbe1xuICAgICAgdHlwZTogT3V0cHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY29uc3QgTkdfTU9ERUxfV0lUSF9GT1JNX0NPTlRST0xfV0FSTklORyA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnTmdNb2RlbFdpdGhGb3JtQ29udHJvbFdhcm5pbmcnIDogJycpO1xuY29uc3QgZm9ybUNvbnRyb2xCaW5kaW5nID0ge1xuICBwcm92aWRlOiBOZ0NvbnRyb2wsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IEZvcm1Db250cm9sRGlyZWN0aXZlKVxufTtcbmNsYXNzIEZvcm1Db250cm9sRGlyZWN0aXZlIGV4dGVuZHMgTmdDb250cm9sIHtcbiAgX25nTW9kZWxXYXJuaW5nQ29uZmlnO1xuICBjYWxsU2V0RGlzYWJsZWRTdGF0ZTtcbiAgdmlld01vZGVsO1xuICBmb3JtO1xuICBzZXQgaXNEaXNhYmxlZChpc0Rpc2FibGVkKSB7XG4gICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgY29uc29sZS53YXJuKGRpc2FibGVkQXR0cldhcm5pbmcpO1xuICAgIH1cbiAgfVxuICBtb2RlbDtcbiAgdXBkYXRlID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBzdGF0aWMgX25nTW9kZWxXYXJuaW5nU2VudE9uY2UgPSBmYWxzZTtcbiAgX25nTW9kZWxXYXJuaW5nU2VudCA9IGZhbHNlO1xuICBjb25zdHJ1Y3Rvcih2YWxpZGF0b3JzLCBhc3luY1ZhbGlkYXRvcnMsIHZhbHVlQWNjZXNzb3JzLCBfbmdNb2RlbFdhcm5pbmdDb25maWcsIGNhbGxTZXREaXNhYmxlZFN0YXRlLCByZW5kZXJlciwgaW5qZWN0b3IpIHtcbiAgICBzdXBlcihpbmplY3RvciwgcmVuZGVyZXIsIHZhbHVlQWNjZXNzb3JzKTtcbiAgICB0aGlzLl9uZ01vZGVsV2FybmluZ0NvbmZpZyA9IF9uZ01vZGVsV2FybmluZ0NvbmZpZztcbiAgICB0aGlzLmNhbGxTZXREaXNhYmxlZFN0YXRlID0gY2FsbFNldERpc2FibGVkU3RhdGU7XG4gICAgdGhpcy5fc2V0VmFsaWRhdG9ycyh2YWxpZGF0b3JzKTtcbiAgICB0aGlzLl9zZXRBc3luY1ZhbGlkYXRvcnMoYXN5bmNWYWxpZGF0b3JzKTtcbiAgfVxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzKSB7XG4gICAgaWYgKHRoaXMuX2lzQ29udHJvbENoYW5nZWQoY2hhbmdlcykpIHtcbiAgICAgIGNvbnN0IHByZXZpb3VzRm9ybSA9IGNoYW5nZXNbJ2Zvcm0nXS5wcmV2aW91c1ZhbHVlO1xuICAgICAgaWYgKHByZXZpb3VzRm9ybSkge1xuICAgICAgICBjbGVhblVwQ29udHJvbChwcmV2aW91c0Zvcm0sIHRoaXMsIGZhbHNlKTtcbiAgICAgICAgdGhpcy5yZW1vdmVQYXJzZUVycm9yc1ZhbGlkYXRvcihwcmV2aW91c0Zvcm0pO1xuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLmlzQ3VzdG9tQ29udHJvbEJhc2VkKSB7XG4gICAgICAgIHRoaXMudmFsdWVBY2Nlc3NvciA/Pz0gdGhpcy5zZWxlY3RlZFZhbHVlQWNjZXNzb3I7XG4gICAgICAgIHNldFVwQ29udHJvbFZhbHVlQWNjZXNzb3IodGhpcy5mb3JtLCB0aGlzLCB0aGlzLmNhbGxTZXREaXNhYmxlZFN0YXRlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuc2V0dXBDdXN0b21Db250cm9sKCk7XG4gICAgICB9XG4gICAgICB0aGlzLmZvcm0udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSh7XG4gICAgICAgIGVtaXRFdmVudDogZmFsc2VcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoaXNQcm9wZXJ0eVVwZGF0ZWQoY2hhbmdlcywgdGhpcy52aWV3TW9kZWwpKSB7XG4gICAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgICAgIF9uZ01vZGVsV2FybmluZygnZm9ybUNvbnRyb2wnLCBGb3JtQ29udHJvbERpcmVjdGl2ZSwgdGhpcywgdGhpcy5fbmdNb2RlbFdhcm5pbmdDb25maWcpO1xuICAgICAgfVxuICAgICAgdGhpcy5mb3JtLnNldFZhbHVlKHRoaXMubW9kZWwpO1xuICAgICAgdGhpcy52aWV3TW9kZWwgPSB0aGlzLm1vZGVsO1xuICAgIH1cbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5mb3JtKSB7XG4gICAgICBjbGVhblVwQ29udHJvbCh0aGlzLmZvcm0sIHRoaXMsIGZhbHNlKTtcbiAgICB9XG4gIH1cbiAgZ2V0IHBhdGgoKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGdldCBjb250cm9sKCkge1xuICAgIHJldHVybiB0aGlzLmZvcm07XG4gIH1cbiAgdmlld1RvTW9kZWxVcGRhdGUobmV3VmFsdWUpIHtcbiAgICB0aGlzLnZpZXdNb2RlbCA9IG5ld1ZhbHVlO1xuICAgIHRoaXMudXBkYXRlLmVtaXQobmV3VmFsdWUpO1xuICB9XG4gIF9pc0NvbnRyb2xDaGFuZ2VkKGNoYW5nZXMpIHtcbiAgICByZXR1cm4gY2hhbmdlcy5oYXNPd25Qcm9wZXJ0eSgnZm9ybScpO1xuICB9XG4gIMm1bmdDb250cm9sQ3JlYXRlKGhvc3QpIHtcbiAgICBzdXBlci5uZ0NvbnRyb2xDcmVhdGUoaG9zdCk7XG4gIH1cbiAgybVuZ0NvbnRyb2xVcGRhdGUoaG9zdCkge1xuICAgIHN1cGVyLm5nQ29udHJvbFVwZGF0ZShob3N0LCB0cnVlKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBGb3JtQ29udHJvbERpcmVjdGl2ZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEZvcm1Db250cm9sRGlyZWN0aXZlKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5HX1ZBTElEQVRPUlMsIDEwKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19BU1lOQ19WQUxJREFUT1JTLCAxMCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfVkFMVUVfQUNDRVNTT1IsIDEwKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19NT0RFTF9XSVRIX0ZPUk1fQ09OVFJPTF9XQVJOSU5HLCA4KSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChDQUxMX1NFVF9ESVNBQkxFRF9TVEFURSwgOCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuUmVuZGVyZXIyLCA4KSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5JbmplY3RvciwgOCkpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBGb3JtQ29udHJvbERpcmVjdGl2ZSxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJmb3JtQ29udHJvbFwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBmb3JtOiBbMCwgXCJmb3JtQ29udHJvbFwiLCBcImZvcm1cIl0sXG4gICAgICBpc0Rpc2FibGVkOiBbMCwgXCJkaXNhYmxlZFwiLCBcImlzRGlzYWJsZWRcIl0sXG4gICAgICBtb2RlbDogWzAsIFwibmdNb2RlbFwiLCBcIm1vZGVsXCJdXG4gICAgfSxcbiAgICBvdXRwdXRzOiB7XG4gICAgICB1cGRhdGU6IFwibmdNb2RlbENoYW5nZVwiXG4gICAgfSxcbiAgICBleHBvcnRBczogW1wibmdGb3JtXCJdLFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW2Zvcm1Db250cm9sQmluZGluZywgTkdfQ09OVFJPTF9JTlRFR1JBVElPTl9QUk9WSURFUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlLCBpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlLCBpMC7Jtcm1Q29udHJvbEZlYXR1cmUobnVsbCldXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRm9ybUNvbnRyb2xEaXJlY3RpdmUsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tmb3JtQ29udHJvbF0nLFxuICAgICAgcHJvdmlkZXJzOiBbZm9ybUNvbnRyb2xCaW5kaW5nLCBOR19DT05UUk9MX0lOVEVHUkFUSU9OX1BST1ZJREVSXSxcbiAgICAgIGV4cG9ydEFzOiAnbmdGb3JtJyxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNlbGZcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTkdfVkFMSURBVE9SU11cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNlbGZcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTkdfQVNZTkNfVkFMSURBVE9SU11cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNlbGZcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTkdfVkFMVUVfQUNDRVNTT1JdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTkdfTU9ERUxfV0lUSF9GT1JNX0NPTlRST0xfV0FSTklOR11cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtDQUxMX1NFVF9ESVNBQkxFRF9TVEFURV1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogaTAuUmVuZGVyZXIyLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5JbmplY3RvcixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9XVxuICB9XSwge1xuICAgIGZvcm06IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFsnZm9ybUNvbnRyb2wnXVxuICAgIH1dLFxuICAgIGlzRGlzYWJsZWQ6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFsnZGlzYWJsZWQnXVxuICAgIH1dLFxuICAgIG1vZGVsOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ25nTW9kZWwnXVxuICAgIH1dLFxuICAgIHVwZGF0ZTogW3tcbiAgICAgIHR5cGU6IE91dHB1dCxcbiAgICAgIGFyZ3M6IFsnbmdNb2RlbENoYW5nZSddXG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY29uc3QgZm9ybUdyb3VwTmFtZVByb3ZpZGVyID0ge1xuICBwcm92aWRlOiBDb250cm9sQ29udGFpbmVyLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBGb3JtR3JvdXBOYW1lKVxufTtcbmNsYXNzIEZvcm1Hcm91cE5hbWUgZXh0ZW5kcyBBYnN0cmFjdEZvcm1Hcm91cERpcmVjdGl2ZSB7XG4gIG5hbWUgPSBudWxsO1xuICBjb25zdHJ1Y3RvcihwYXJlbnQsIHZhbGlkYXRvcnMsIGFzeW5jVmFsaWRhdG9ycykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fcGFyZW50ID0gcGFyZW50O1xuICAgIHRoaXMuX3NldFZhbGlkYXRvcnModmFsaWRhdG9ycyk7XG4gICAgdGhpcy5fc2V0QXN5bmNWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9ycyk7XG4gIH1cbiAgX2NoZWNrUGFyZW50VHlwZSgpIHtcbiAgICBpZiAoaGFzSW52YWxpZFBhcmVudCh0aGlzLl9wYXJlbnQpICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSB7XG4gICAgICB0aHJvdyBncm91cFBhcmVudEV4Y2VwdGlvbigpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBGb3JtR3JvdXBOYW1lX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRm9ybUdyb3VwTmFtZSkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChDb250cm9sQ29udGFpbmVyLCAxMyksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfVkFMSURBVE9SUywgMTApLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5HX0FTWU5DX1ZBTElEQVRPUlMsIDEwKSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IEZvcm1Hcm91cE5hbWUsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwiZm9ybUdyb3VwTmFtZVwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuYW1lOiBbMCwgXCJmb3JtR3JvdXBOYW1lXCIsIFwibmFtZVwiXVxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbZm9ybUdyb3VwTmFtZVByb3ZpZGVyXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRm9ybUdyb3VwTmFtZSwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW2Zvcm1Hcm91cE5hbWVdJyxcbiAgICAgIHByb3ZpZGVyczogW2Zvcm1Hcm91cE5hbWVQcm92aWRlcl0sXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IENvbnRyb2xDb250YWluZXIsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSG9zdFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNraXBTZWxmXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX0FTWU5DX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfV0sIHtcbiAgICBuYW1lOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ2Zvcm1Hcm91cE5hbWUnXVxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNvbnN0IGZvcm1BcnJheU5hbWVQcm92aWRlciA9IHtcbiAgcHJvdmlkZTogQ29udHJvbENvbnRhaW5lcixcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gRm9ybUFycmF5TmFtZSlcbn07XG5jbGFzcyBGb3JtQXJyYXlOYW1lIGV4dGVuZHMgQ29udHJvbENvbnRhaW5lciB7XG4gIF9wYXJlbnQ7XG4gIG5hbWUgPSBudWxsO1xuICBjb25zdHJ1Y3RvcihwYXJlbnQsIHZhbGlkYXRvcnMsIGFzeW5jVmFsaWRhdG9ycykge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fcGFyZW50ID0gcGFyZW50O1xuICAgIHRoaXMuX3NldFZhbGlkYXRvcnModmFsaWRhdG9ycyk7XG4gICAgdGhpcy5fc2V0QXN5bmNWYWxpZGF0b3JzKGFzeW5jVmFsaWRhdG9ycyk7XG4gIH1cbiAgbmdPbkluaXQoKSB7XG4gICAgaWYgKGhhc0ludmFsaWRQYXJlbnQodGhpcy5fcGFyZW50KSAmJiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSkge1xuICAgICAgdGhyb3cgYXJyYXlQYXJlbnRFeGNlcHRpb24oKTtcbiAgICB9XG4gICAgdGhpcy5mb3JtRGlyZWN0aXZlLmFkZEZvcm1BcnJheSh0aGlzKTtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLmZvcm1EaXJlY3RpdmU/LnJlbW92ZUZvcm1BcnJheSh0aGlzKTtcbiAgfVxuICBnZXQgY29udHJvbCgpIHtcbiAgICByZXR1cm4gdGhpcy5mb3JtRGlyZWN0aXZlLmdldEZvcm1BcnJheSh0aGlzKTtcbiAgfVxuICBnZXQgZm9ybURpcmVjdGl2ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGFyZW50ID8gdGhpcy5fcGFyZW50LmZvcm1EaXJlY3RpdmUgOiBudWxsO1xuICB9XG4gIGdldCBwYXRoKCkge1xuICAgIHJldHVybiBjb250cm9sUGF0aCh0aGlzLm5hbWUgPT0gbnVsbCA/IHRoaXMubmFtZSA6IHRoaXMubmFtZS50b1N0cmluZygpLCB0aGlzLl9wYXJlbnQpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEZvcm1BcnJheU5hbWVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBGb3JtQXJyYXlOYW1lKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KENvbnRyb2xDb250YWluZXIsIDEzKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19WQUxJREFUT1JTLCAxMCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfQVNZTkNfVkFMSURBVE9SUywgMTApKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogRm9ybUFycmF5TmFtZSxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJmb3JtQXJyYXlOYW1lXCIsIFwiXCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG5hbWU6IFswLCBcImZvcm1BcnJheU5hbWVcIiwgXCJuYW1lXCJdXG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtmb3JtQXJyYXlOYW1lUHJvdmlkZXJdKSwgaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShGb3JtQXJyYXlOYW1lLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdbZm9ybUFycmF5TmFtZV0nLFxuICAgICAgcHJvdmlkZXJzOiBbZm9ybUFycmF5TmFtZVByb3ZpZGVyXSxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogQ29udHJvbENvbnRhaW5lcixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBIb3N0XG4gICAgfSwge1xuICAgICAgdHlwZTogU2tpcFNlbGZcbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNlbGZcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTkdfVkFMSURBVE9SU11cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNlbGZcbiAgICB9LCB7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTkdfQVNZTkNfVkFMSURBVE9SU11cbiAgICB9XVxuICB9XSwge1xuICAgIG5hbWU6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFsnZm9ybUFycmF5TmFtZSddXG4gICAgfV1cbiAgfSk7XG59KSgpO1xuZnVuY3Rpb24gaGFzSW52YWxpZFBhcmVudChwYXJlbnQpIHtcbiAgcmV0dXJuICEocGFyZW50IGluc3RhbmNlb2YgRm9ybUdyb3VwTmFtZSkgJiYgIShwYXJlbnQgaW5zdGFuY2VvZiBBYnN0cmFjdEZvcm1EaXJlY3RpdmUpICYmICEocGFyZW50IGluc3RhbmNlb2YgRm9ybUFycmF5TmFtZSk7XG59XG5jb25zdCBjb250cm9sTmFtZUJpbmRpbmcgPSB7XG4gIHByb3ZpZGU6IE5nQ29udHJvbCxcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gRm9ybUNvbnRyb2xOYW1lKVxufTtcbmNsYXNzIEZvcm1Db250cm9sTmFtZSBleHRlbmRzIE5nQ29udHJvbCB7XG4gIF9uZ01vZGVsV2FybmluZ0NvbmZpZztcbiAgX2FkZGVkID0gZmFsc2U7XG4gIHZpZXdNb2RlbDtcbiAgY29udHJvbDtcbiAgbmFtZSA9IG51bGw7XG4gIHNldCBpc0Rpc2FibGVkKGlzRGlzYWJsZWQpIHtcbiAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgICBjb25zb2xlLndhcm4oZGlzYWJsZWRBdHRyV2FybmluZyk7XG4gICAgfVxuICB9XG4gIG1vZGVsO1xuICB1cGRhdGUgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIHN0YXRpYyBfbmdNb2RlbFdhcm5pbmdTZW50T25jZSA9IGZhbHNlO1xuICBfbmdNb2RlbFdhcm5pbmdTZW50ID0gZmFsc2U7XG4gIGNvbnN0cnVjdG9yKHBhcmVudCwgdmFsaWRhdG9ycywgYXN5bmNWYWxpZGF0b3JzLCB2YWx1ZUFjY2Vzc29ycywgX25nTW9kZWxXYXJuaW5nQ29uZmlnLCByZW5kZXJlciwgaW5qZWN0b3IpIHtcbiAgICBzdXBlcihpbmplY3RvciwgcmVuZGVyZXIsIHZhbHVlQWNjZXNzb3JzKTtcbiAgICB0aGlzLl9uZ01vZGVsV2FybmluZ0NvbmZpZyA9IF9uZ01vZGVsV2FybmluZ0NvbmZpZztcbiAgICB0aGlzLl9wYXJlbnQgPSBwYXJlbnQ7XG4gICAgdGhpcy5fc2V0VmFsaWRhdG9ycyh2YWxpZGF0b3JzKTtcbiAgICB0aGlzLl9zZXRBc3luY1ZhbGlkYXRvcnMoYXN5bmNWYWxpZGF0b3JzKTtcbiAgfVxuICBfc2V0dXBXaXRoRm9ybShjb250cm9sLCBjYWxsU2V0RGlzYWJsZWRTdGF0ZSkge1xuICAgIHRoaXMuY29udHJvbCA9IGNvbnRyb2w7XG4gICAgaWYgKCF0aGlzLmlzQ3VzdG9tQ29udHJvbEJhc2VkKSB7XG4gICAgICB0aGlzLnZhbHVlQWNjZXNzb3IgPz89IHRoaXMuc2VsZWN0ZWRWYWx1ZUFjY2Vzc29yO1xuICAgICAgc2V0VXBDb250cm9sVmFsdWVBY2Nlc3Nvcihjb250cm9sLCB0aGlzLCBjYWxsU2V0RGlzYWJsZWRTdGF0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc2V0dXBDdXN0b21Db250cm9sKCk7XG4gICAgfVxuICB9XG4gIG5nT25DaGFuZ2VzKGNoYW5nZXMpIHtcbiAgICBpZiAoIXRoaXMuX2FkZGVkKSB0aGlzLl9zZXRVcENvbnRyb2woKTtcbiAgICBpZiAoaXNQcm9wZXJ0eVVwZGF0ZWQoY2hhbmdlcywgdGhpcy52aWV3TW9kZWwpKSB7XG4gICAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgICAgIF9uZ01vZGVsV2FybmluZygnZm9ybUNvbnRyb2xOYW1lJywgRm9ybUNvbnRyb2xOYW1lLCB0aGlzLCB0aGlzLl9uZ01vZGVsV2FybmluZ0NvbmZpZyk7XG4gICAgICB9XG4gICAgICB0aGlzLnZpZXdNb2RlbCA9IHRoaXMubW9kZWw7XG4gICAgICB0aGlzLmZvcm1EaXJlY3RpdmUudXBkYXRlTW9kZWwodGhpcywgdGhpcy5tb2RlbCk7XG4gICAgfVxuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuZm9ybURpcmVjdGl2ZT8ucmVtb3ZlQ29udHJvbCh0aGlzKTtcbiAgfVxuICB2aWV3VG9Nb2RlbFVwZGF0ZShuZXdWYWx1ZSkge1xuICAgIHRoaXMudmlld01vZGVsID0gbmV3VmFsdWU7XG4gICAgdGhpcy51cGRhdGUuZW1pdChuZXdWYWx1ZSk7XG4gIH1cbiAgZ2V0IHBhdGgoKSB7XG4gICAgcmV0dXJuIGNvbnRyb2xQYXRoKHRoaXMubmFtZSA9PSBudWxsID8gdGhpcy5uYW1lIDogdGhpcy5uYW1lLnRvU3RyaW5nKCksIHRoaXMuX3BhcmVudCk7XG4gIH1cbiAgZ2V0IGZvcm1EaXJlY3RpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BhcmVudCA/IHRoaXMuX3BhcmVudC5mb3JtRGlyZWN0aXZlIDogbnVsbDtcbiAgfVxuICBfc2V0VXBDb250cm9sKCkge1xuICAgIGlmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpIHtcbiAgICAgIGNoZWNrUGFyZW50VHlwZSh0aGlzLl9wYXJlbnQsIHRoaXMubmFtZSk7XG4gICAgfVxuICAgIHRoaXMuY29udHJvbCA9IHRoaXMuZm9ybURpcmVjdGl2ZS5hZGRDb250cm9sKHRoaXMpO1xuICAgIHRoaXMuX2FkZGVkID0gdHJ1ZTtcbiAgfVxuICDJtW5nQ29udHJvbENyZWF0ZShob3N0KSB7XG4gICAgc3VwZXIubmdDb250cm9sQ3JlYXRlKGhvc3QpO1xuICB9XG4gIMm1bmdDb250cm9sVXBkYXRlKGhvc3QpIHtcbiAgICBpZiAoIXRoaXMuaXNDdXN0b21Db250cm9sQmFzZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCF0aGlzLl9hZGRlZCkgdGhpcy5fc2V0VXBDb250cm9sKCk7XG4gICAgc3VwZXIubmdDb250cm9sVXBkYXRlKGhvc3QsIHRydWUpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEZvcm1Db250cm9sTmFtZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEZvcm1Db250cm9sTmFtZSkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChDb250cm9sQ29udGFpbmVyLCAxMyksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTkdfVkFMSURBVE9SUywgMTApLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5HX0FTWU5DX1ZBTElEQVRPUlMsIDEwKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOR19WQUxVRV9BQ0NFU1NPUiwgMTApLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5HX01PREVMX1dJVEhfRk9STV9DT05UUk9MX1dBUk5JTkcsIDgpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlJlbmRlcmVyMiwgOCksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuSW5qZWN0b3IsIDgpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogRm9ybUNvbnRyb2xOYW1lLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcImZvcm1Db250cm9sTmFtZVwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuYW1lOiBbMCwgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJuYW1lXCJdLFxuICAgICAgaXNEaXNhYmxlZDogWzAsIFwiZGlzYWJsZWRcIiwgXCJpc0Rpc2FibGVkXCJdLFxuICAgICAgbW9kZWw6IFswLCBcIm5nTW9kZWxcIiwgXCJtb2RlbFwiXVxuICAgIH0sXG4gICAgb3V0cHV0czoge1xuICAgICAgdXBkYXRlOiBcIm5nTW9kZWxDaGFuZ2VcIlxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbY29udHJvbE5hbWVCaW5kaW5nLCBOR19DT05UUk9MX0lOVEVHUkFUSU9OX1BST1ZJREVSXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmUsIGkwLsm1ybVOZ09uQ2hhbmdlc0ZlYXR1cmUsIGkwLsm1ybVDb250cm9sRmVhdHVyZShudWxsKV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShGb3JtQ29udHJvbE5hbWUsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tmb3JtQ29udHJvbE5hbWVdJyxcbiAgICAgIHByb3ZpZGVyczogW2NvbnRyb2xOYW1lQmluZGluZywgTkdfQ09OVFJPTF9JTlRFR1JBVElPTl9QUk9WSURFUl0sXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IENvbnRyb2xDb250YWluZXIsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSG9zdFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IFNraXBTZWxmXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX0FTWU5DX1ZBTElEQVRPUlNdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBTZWxmXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX1ZBTFVFX0FDQ0VTU09SXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW05HX01PREVMX1dJVEhfRk9STV9DT05UUk9MX1dBUk5JTkddXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IGkwLlJlbmRlcmVyMixcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogaTAuSW5qZWN0b3IsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfV1cbiAgfV0sIHtcbiAgICBuYW1lOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ2Zvcm1Db250cm9sTmFtZSddXG4gICAgfV0sXG4gICAgaXNEaXNhYmxlZDogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogWydkaXNhYmxlZCddXG4gICAgfV0sXG4gICAgbW9kZWw6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFsnbmdNb2RlbCddXG4gICAgfV0sXG4gICAgdXBkYXRlOiBbe1xuICAgICAgdHlwZTogT3V0cHV0LFxuICAgICAgYXJnczogWyduZ01vZGVsQ2hhbmdlJ11cbiAgICB9XVxuICB9KTtcbn0pKCk7XG5mdW5jdGlvbiBjaGVja1BhcmVudFR5cGUocGFyZW50LCBuYW1lKSB7XG4gIGlmICghKHBhcmVudCBpbnN0YW5jZW9mIEZvcm1Hcm91cE5hbWUpICYmIHBhcmVudCBpbnN0YW5jZW9mIEFic3RyYWN0Rm9ybUdyb3VwRGlyZWN0aXZlKSB7XG4gICAgdGhyb3cgbmdNb2RlbEdyb3VwRXhjZXB0aW9uKCk7XG4gIH0gZWxzZSBpZiAoIShwYXJlbnQgaW5zdGFuY2VvZiBGb3JtR3JvdXBOYW1lKSAmJiAhKHBhcmVudCBpbnN0YW5jZW9mIEFic3RyYWN0Rm9ybURpcmVjdGl2ZSkgJiYgIShwYXJlbnQgaW5zdGFuY2VvZiBGb3JtQXJyYXlOYW1lKSkge1xuICAgIHRocm93IGNvbnRyb2xQYXJlbnRFeGNlcHRpb24obmFtZSk7XG4gIH1cbn1cbmNvbnN0IGZvcm1EaXJlY3RpdmVQcm92aWRlciA9IHtcbiAgcHJvdmlkZTogQ29udHJvbENvbnRhaW5lcixcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gRm9ybUdyb3VwRGlyZWN0aXZlKVxufTtcbmNsYXNzIEZvcm1Hcm91cERpcmVjdGl2ZSBleHRlbmRzIEFic3RyYWN0Rm9ybURpcmVjdGl2ZSB7XG4gIGZvcm0gPSBudWxsO1xuICBuZ1N1Ym1pdCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgZ2V0IGNvbnRyb2woKSB7XG4gICAgcmV0dXJuIHRoaXMuZm9ybTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtUZvcm1Hcm91cERpcmVjdGl2ZV9CYXNlRmFjdG9yeTtcbiAgICByZXR1cm4gZnVuY3Rpb24gRm9ybUdyb3VwRGlyZWN0aXZlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVGb3JtR3JvdXBEaXJlY3RpdmVfQmFzZUZhY3RvcnkgfHwgKMm1Rm9ybUdyb3VwRGlyZWN0aXZlX0Jhc2VGYWN0b3J5ID0gaTAuybXJtWdldEluaGVyaXRlZEZhY3RvcnkoRm9ybUdyb3VwRGlyZWN0aXZlKSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEZvcm1Hcm91cERpcmVjdGl2ZSk7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogRm9ybUdyb3VwRGlyZWN0aXZlLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcImZvcm1Hcm91cFwiLCBcIlwiXV0sXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBGb3JtR3JvdXBEaXJlY3RpdmVfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwic3VibWl0XCIsIGZ1bmN0aW9uIEZvcm1Hcm91cERpcmVjdGl2ZV9zdWJtaXRfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25TdWJtaXQoJGV2ZW50KTtcbiAgICAgICAgfSkoXCJyZXNldFwiLCBmdW5jdGlvbiBGb3JtR3JvdXBEaXJlY3RpdmVfcmVzZXRfSG9zdEJpbmRpbmdIYW5kbGVyKCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25SZXNldCgpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgZm9ybTogWzAsIFwiZm9ybUdyb3VwXCIsIFwiZm9ybVwiXVxuICAgIH0sXG4gICAgb3V0cHV0czoge1xuICAgICAgbmdTdWJtaXQ6IFwibmdTdWJtaXRcIlxuICAgIH0sXG4gICAgZXhwb3J0QXM6IFtcIm5nRm9ybVwiXSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVQcm92aWRlcnNGZWF0dXJlKFtmb3JtRGlyZWN0aXZlUHJvdmlkZXJdKSwgaTAuybXJtUluaGVyaXREZWZpbml0aW9uRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShGb3JtR3JvdXBEaXJlY3RpdmUsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tmb3JtR3JvdXBdJyxcbiAgICAgIHByb3ZpZGVyczogW2Zvcm1EaXJlY3RpdmVQcm92aWRlcl0sXG4gICAgICBob3N0OiB7XG4gICAgICAgICcoc3VibWl0KSc6ICdvblN1Ym1pdCgkZXZlbnQpJyxcbiAgICAgICAgJyhyZXNldCknOiAnb25SZXNldCgpJ1xuICAgICAgfSxcbiAgICAgIGV4cG9ydEFzOiAnbmdGb3JtJyxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICBmb3JtOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ2Zvcm1Hcm91cCddXG4gICAgfV0sXG4gICAgbmdTdWJtaXQ6IFt7XG4gICAgICB0eXBlOiBPdXRwdXRcbiAgICB9XVxuICB9KTtcbn0pKCk7XG5jb25zdCBTRUxFQ1RfVkFMVUVfQUNDRVNTT1IgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3NvciksXG4gIG11bHRpOiB0cnVlXG59O1xuZnVuY3Rpb24gX2J1aWxkVmFsdWVTdHJpbmckMShpZCwgdmFsdWUpIHtcbiAgaWYgKGlkID09IG51bGwpIHJldHVybiBgJHt2YWx1ZX1gO1xuICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JykgdmFsdWUgPSAnT2JqZWN0JztcbiAgcmV0dXJuIGAke2lkfTogJHt2YWx1ZX1gLnNsaWNlKDAsIDUwKTtcbn1cbmZ1bmN0aW9uIF9leHRyYWN0SWQkMSh2YWx1ZVN0cmluZykge1xuICByZXR1cm4gdmFsdWVTdHJpbmcuc3BsaXQoJzonKVswXTtcbn1cbmNsYXNzIFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yIGV4dGVuZHMgQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgdmFsdWU7XG4gIF9vcHRpb25NYXAgPSBuZXcgTWFwKCk7XG4gIF9pZENvdW50ZXIgPSAwO1xuICBzZXQgY29tcGFyZVdpdGgoZm4pIHtcbiAgICBpZiAodHlwZW9mIGZuICE9PSAnZnVuY3Rpb24nICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigxMjAxLCBgY29tcGFyZVdpdGggbXVzdCBiZSBhIGZ1bmN0aW9uLCBidXQgcmVjZWl2ZWQgJHtKU09OLnN0cmluZ2lmeShmbil9YCk7XG4gICAgfVxuICAgIHRoaXMuX2NvbXBhcmVXaXRoID0gZm47XG4gIH1cbiAgX2NvbXBhcmVXaXRoID0gT2JqZWN0LmlzO1xuICBhcHBSZWZJbmplY3RvciA9IGluamVjdChBcHBsaWNhdGlvblJlZikuaW5qZWN0b3I7XG4gIGRlc3Ryb3lSZWYgPSBpbmplY3QoRGVzdHJveVJlZik7XG4gIGNkciA9IGluamVjdChDaGFuZ2VEZXRlY3RvclJlZik7XG4gIF9xdWV1ZWRXcml0ZSA9IGZhbHNlO1xuICBfd3JpdGVWYWx1ZUFmdGVyUmVuZGVyKCkge1xuICAgIGlmICh0aGlzLl9xdWV1ZWRXcml0ZSB8fCB0aGlzLmFwcFJlZkluamVjdG9yLmRlc3Ryb3llZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9xdWV1ZWRXcml0ZSA9IHRydWU7XG4gICAgYWZ0ZXJOZXh0UmVuZGVyKHtcbiAgICAgIHdyaXRlOiAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLmRlc3Ryb3lSZWYuZGVzdHJveWVkKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3F1ZXVlZFdyaXRlID0gZmFsc2U7XG4gICAgICAgIHRoaXMud3JpdGVWYWx1ZSh0aGlzLnZhbHVlKTtcbiAgICAgIH1cbiAgICB9LCB7XG4gICAgICBpbmplY3RvcjogdGhpcy5hcHBSZWZJbmplY3RvclxuICAgIH0pO1xuICB9XG4gIHdyaXRlVmFsdWUodmFsdWUpIHtcbiAgICB0aGlzLmNkci5tYXJrRm9yQ2hlY2soKTtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgY29uc3QgaWQgPSB0aGlzLl9nZXRPcHRpb25JZCh2YWx1ZSk7XG4gICAgY29uc3QgdmFsdWVTdHJpbmcgPSBfYnVpbGRWYWx1ZVN0cmluZyQxKGlkLCB2YWx1ZSk7XG4gICAgdGhpcy5zZXRQcm9wZXJ0eSgndmFsdWUnLCB2YWx1ZVN0cmluZyk7XG4gIH1cbiAgcmVnaXN0ZXJPbkNoYW5nZShmbikge1xuICAgIHRoaXMub25DaGFuZ2UgPSB2YWx1ZVN0cmluZyA9PiB7XG4gICAgICB0aGlzLnZhbHVlID0gdGhpcy5fZ2V0T3B0aW9uVmFsdWUodmFsdWVTdHJpbmcpO1xuICAgICAgZm4odGhpcy52YWx1ZSk7XG4gICAgfTtcbiAgfVxuICBfcmVnaXN0ZXJPcHRpb24oKSB7XG4gICAgcmV0dXJuICh0aGlzLl9pZENvdW50ZXIrKykudG9TdHJpbmcoKTtcbiAgfVxuICBfZ2V0T3B0aW9uSWQodmFsdWUpIHtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIHRoaXMuX29wdGlvbk1hcC5rZXlzKCkpIHtcbiAgICAgIGlmICh0aGlzLl9jb21wYXJlV2l0aCh0aGlzLl9vcHRpb25NYXAuZ2V0KGlkKSwgdmFsdWUpKSByZXR1cm4gaWQ7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIF9nZXRPcHRpb25WYWx1ZSh2YWx1ZVN0cmluZykge1xuICAgIGNvbnN0IGlkID0gX2V4dHJhY3RJZCQxKHZhbHVlU3RyaW5nKTtcbiAgICByZXR1cm4gdGhpcy5fb3B0aW9uTWFwLmhhcyhpZCkgPyB0aGlzLl9vcHRpb25NYXAuZ2V0KGlkKSA6IHZhbHVlU3RyaW5nO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IC8qIEBfX1BVUkVfXyAqLygoKSA9PiB7XG4gICAgbGV0IMm1U2VsZWN0Q29udHJvbFZhbHVlQWNjZXNzb3JfQmFzZUZhY3Rvcnk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3Nvcl9CYXNlRmFjdG9yeSB8fCAoybVTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3Nvcl9CYXNlRmFjdG9yeSA9IGkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5KFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yKSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yKTtcbiAgICB9O1xuICB9KSgpO1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3NvcixcbiAgICBzZWxlY3RvcnM6IFtbXCJzZWxlY3RcIiwgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJcIiwgMywgXCJtdWx0aXBsZVwiLCBcIlwiLCAzLCBcIm5nTm9DdmFcIiwgXCJcIl0sIFtcInNlbGVjdFwiLCBcImZvcm1Db250cm9sXCIsIFwiXCIsIDMsIFwibXVsdGlwbGVcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJzZWxlY3RcIiwgXCJuZ01vZGVsXCIsIFwiXCIsIDMsIFwibXVsdGlwbGVcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdXSxcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcImNoYW5nZVwiLCBmdW5jdGlvbiBTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3Nvcl9jaGFuZ2VfSG9zdEJpbmRpbmdIYW5kbGVyKCRldmVudCkge1xuICAgICAgICAgIHJldHVybiBjdHgub25DaGFuZ2UoJGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gICAgICAgIH0pKFwiYmx1clwiLCBmdW5jdGlvbiBTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3Nvcl9ibHVyX0hvc3RCaW5kaW5nSGFuZGxlcigpIHtcbiAgICAgICAgICByZXR1cm4gY3R4Lm9uVG91Y2hlZCgpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgY29tcGFyZVdpdGg6IFwiY29tcGFyZVdpdGhcIlxuICAgIH0sXG4gICAgc3RhbmRhbG9uZTogZmFsc2UsXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1UHJvdmlkZXJzRmVhdHVyZShbU0VMRUNUX1ZBTFVFX0FDQ0VTU09SXSksIGkwLsm1ybVJbmhlcml0RGVmaW5pdGlvbkZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoU2VsZWN0Q29udHJvbFZhbHVlQWNjZXNzb3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ3NlbGVjdDpub3QoW211bHRpcGxlXSk6bm90KFtuZ05vQ3ZhXSlbZm9ybUNvbnRyb2xOYW1lXSxzZWxlY3Q6bm90KFttdWx0aXBsZV0pOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sXSxzZWxlY3Q6bm90KFttdWx0aXBsZV0pOm5vdChbbmdOb0N2YV0pW25nTW9kZWxdJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJyhjaGFuZ2UpJzogJ29uQ2hhbmdlKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpJyxcbiAgICAgICAgJyhibHVyKSc6ICdvblRvdWNoZWQoKSdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcnM6IFtTRUxFQ1RfVkFMVUVfQUNDRVNTT1JdLFxuICAgICAgc3RhbmRhbG9uZTogZmFsc2VcbiAgICB9XVxuICB9XSwgbnVsbCwge1xuICAgIGNvbXBhcmVXaXRoOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XVxuICB9KTtcbn0pKCk7XG5jbGFzcyBOZ1NlbGVjdE9wdGlvbiB7XG4gIF9lbGVtZW50O1xuICBfcmVuZGVyZXI7XG4gIF9zZWxlY3Q7XG4gIGlkO1xuICBjb25zdHJ1Y3RvcihfZWxlbWVudCwgX3JlbmRlcmVyLCBfc2VsZWN0KSB7XG4gICAgdGhpcy5fZWxlbWVudCA9IF9lbGVtZW50O1xuICAgIHRoaXMuX3JlbmRlcmVyID0gX3JlbmRlcmVyO1xuICAgIHRoaXMuX3NlbGVjdCA9IF9zZWxlY3Q7XG4gICAgaWYgKHRoaXMuX3NlbGVjdCkgdGhpcy5pZCA9IHRoaXMuX3NlbGVjdC5fcmVnaXN0ZXJPcHRpb24oKTtcbiAgfVxuICBzZXQgbmdWYWx1ZSh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl9zZWxlY3QgPT0gbnVsbCkgcmV0dXJuO1xuICAgIHRoaXMuX3NlbGVjdC5fb3B0aW9uTWFwLnNldCh0aGlzLmlkLCB2YWx1ZSk7XG4gICAgdGhpcy5fc2V0RWxlbWVudFZhbHVlKF9idWlsZFZhbHVlU3RyaW5nJDEodGhpcy5pZCwgdmFsdWUpKTtcbiAgICB0aGlzLl9zZWxlY3QuX3dyaXRlVmFsdWVBZnRlclJlbmRlcigpO1xuICB9XG4gIHNldCB2YWx1ZSh2YWx1ZSkge1xuICAgIHRoaXMuX3NldEVsZW1lbnRWYWx1ZSh2YWx1ZSk7XG4gICAgdGhpcy5fc2VsZWN0Py5fd3JpdGVWYWx1ZUFmdGVyUmVuZGVyKCk7XG4gIH1cbiAgX3NldEVsZW1lbnRWYWx1ZSh2YWx1ZSkge1xuICAgIHRoaXMuX3JlbmRlcmVyLnNldFByb3BlcnR5KHRoaXMuX2VsZW1lbnQubmF0aXZlRWxlbWVudCwgJ3ZhbHVlJywgdmFsdWUpO1xuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuX3NlbGVjdD8uX29wdGlvbk1hcC5kZWxldGUodGhpcy5pZCk7XG4gICAgdGhpcy5fc2VsZWN0Py5fd3JpdGVWYWx1ZUFmdGVyUmVuZGVyKCk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdTZWxlY3RPcHRpb25fRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ1NlbGVjdE9wdGlvbikoaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5FbGVtZW50UmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5SZW5kZXJlcjIpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yLCA5KSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE5nU2VsZWN0T3B0aW9uLFxuICAgIHNlbGVjdG9yczogW1tcIm9wdGlvblwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuZ1ZhbHVlOiBcIm5nVmFsdWVcIixcbiAgICAgIHZhbHVlOiBcInZhbHVlXCJcbiAgICB9LFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmdTZWxlY3RPcHRpb24sIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ29wdGlvbicsXG4gICAgICBzdGFuZGFsb25lOiBmYWxzZVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IGkwLkVsZW1lbnRSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkwLlJlbmRlcmVyMlxuICB9LCB7XG4gICAgdHlwZTogU2VsZWN0Q29udHJvbFZhbHVlQWNjZXNzb3IsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSG9zdFxuICAgIH1dXG4gIH1dLCB7XG4gICAgbmdWYWx1ZTogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogWyduZ1ZhbHVlJ11cbiAgICB9XSxcbiAgICB2YWx1ZTogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogWyd2YWx1ZSddXG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY29uc3QgU0VMRUNUX01VTFRJUExFX1ZBTFVFX0FDQ0VTU09SID0ge1xuICBwcm92aWRlOiBOR19WQUxVRV9BQ0NFU1NPUixcbiAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gU2VsZWN0TXVsdGlwbGVDb250cm9sVmFsdWVBY2Nlc3NvciksXG4gIG11bHRpOiB0cnVlXG59O1xuZnVuY3Rpb24gX2J1aWxkVmFsdWVTdHJpbmcoaWQsIHZhbHVlKSB7XG4gIGlmIChpZCA9PSBudWxsKSByZXR1cm4gYCR7dmFsdWV9YDtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHZhbHVlID0gYCcke3ZhbHVlfSdgO1xuICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JykgdmFsdWUgPSAnT2JqZWN0JztcbiAgcmV0dXJuIGAke2lkfTogJHt2YWx1ZX1gLnNsaWNlKDAsIDUwKTtcbn1cbmZ1bmN0aW9uIF9leHRyYWN0SWQodmFsdWVTdHJpbmcpIHtcbiAgcmV0dXJuIHZhbHVlU3RyaW5nLnNwbGl0KCc6JylbMF07XG59XG5jbGFzcyBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yIGV4dGVuZHMgQnVpbHRJbkNvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgdmFsdWU7XG4gIF9vcHRpb25NYXAgPSBuZXcgTWFwKCk7XG4gIF9pZENvdW50ZXIgPSAwO1xuICBzZXQgY29tcGFyZVdpdGgoZm4pIHtcbiAgICBpZiAodHlwZW9mIGZuICE9PSAnZnVuY3Rpb24nICYmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigxMjAxLCBgY29tcGFyZVdpdGggbXVzdCBiZSBhIGZ1bmN0aW9uLCBidXQgcmVjZWl2ZWQgJHtKU09OLnN0cmluZ2lmeShmbil9YCk7XG4gICAgfVxuICAgIHRoaXMuX2NvbXBhcmVXaXRoID0gZm47XG4gIH1cbiAgX2NvbXBhcmVXaXRoID0gT2JqZWN0LmlzO1xuICB3cml0ZVZhbHVlKHZhbHVlKSB7XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICAgIGxldCBvcHRpb25TZWxlY3RlZFN0YXRlU2V0dGVyO1xuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgY29uc3QgaWRzID0gdmFsdWUubWFwKHYgPT4gdGhpcy5fZ2V0T3B0aW9uSWQodikpO1xuICAgICAgb3B0aW9uU2VsZWN0ZWRTdGF0ZVNldHRlciA9IChvcHQsIGlkKSA9PiB7XG4gICAgICAgIG9wdC5fc2V0U2VsZWN0ZWQoaWRzLmluZGV4T2YoaWQpID4gLTEpO1xuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3B0aW9uU2VsZWN0ZWRTdGF0ZVNldHRlciA9IG9wdCA9PiB7XG4gICAgICAgIG9wdC5fc2V0U2VsZWN0ZWQoZmFsc2UpO1xuICAgICAgfTtcbiAgICB9XG4gICAgdGhpcy5fb3B0aW9uTWFwLmZvckVhY2gob3B0aW9uU2VsZWN0ZWRTdGF0ZVNldHRlcik7XG4gIH1cbiAgcmVnaXN0ZXJPbkNoYW5nZShmbikge1xuICAgIHRoaXMub25DaGFuZ2UgPSBlbGVtZW50ID0+IHtcbiAgICAgIGNvbnN0IHNlbGVjdGVkID0gW107XG4gICAgICBjb25zdCBzZWxlY3RlZE9wdGlvbnMgPSBlbGVtZW50LnNlbGVjdGVkT3B0aW9ucztcbiAgICAgIGlmIChzZWxlY3RlZE9wdGlvbnMgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gc2VsZWN0ZWRPcHRpb25zO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9wdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBvcHQgPSBvcHRpb25zW2ldO1xuICAgICAgICAgIGNvbnN0IHZhbCA9IHRoaXMuX2dldE9wdGlvblZhbHVlKG9wdC52YWx1ZSk7XG4gICAgICAgICAgc2VsZWN0ZWQucHVzaCh2YWwpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBvcHRpb25zID0gZWxlbWVudC5vcHRpb25zO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9wdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBvcHQgPSBvcHRpb25zW2ldO1xuICAgICAgICAgIGlmIChvcHQuc2VsZWN0ZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbCA9IHRoaXMuX2dldE9wdGlvblZhbHVlKG9wdC52YWx1ZSk7XG4gICAgICAgICAgICBzZWxlY3RlZC5wdXNoKHZhbCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLnZhbHVlID0gc2VsZWN0ZWQ7XG4gICAgICBmbihzZWxlY3RlZCk7XG4gICAgfTtcbiAgfVxuICBfcmVnaXN0ZXJPcHRpb24odmFsdWUpIHtcbiAgICBjb25zdCBpZCA9ICh0aGlzLl9pZENvdW50ZXIrKykudG9TdHJpbmcoKTtcbiAgICB0aGlzLl9vcHRpb25NYXAuc2V0KGlkLCB2YWx1ZSk7XG4gICAgcmV0dXJuIGlkO1xuICB9XG4gIF9nZXRPcHRpb25JZCh2YWx1ZSkge1xuICAgIGZvciAoY29uc3QgaWQgb2YgdGhpcy5fb3B0aW9uTWFwLmtleXMoKSkge1xuICAgICAgaWYgKHRoaXMuX2NvbXBhcmVXaXRoKHRoaXMuX29wdGlvbk1hcC5nZXQoaWQpLl92YWx1ZSwgdmFsdWUpKSByZXR1cm4gaWQ7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIF9nZXRPcHRpb25WYWx1ZSh2YWx1ZVN0cmluZykge1xuICAgIGNvbnN0IGlkID0gX2V4dHJhY3RJZCh2YWx1ZVN0cmluZyk7XG4gICAgcmV0dXJuIHRoaXMuX29wdGlvbk1hcC5oYXMoaWQpID8gdGhpcy5fb3B0aW9uTWFwLmdldChpZCkuX3ZhbHVlIDogdmFsdWVTdHJpbmc7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gLyogQF9fUFVSRV9fICovKCgpID0+IHtcbiAgICBsZXQgybVTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yX0Jhc2VGYWN0b3J5IHx8ICjJtVNlbGVjdE11bHRpcGxlQ29udHJvbFZhbHVlQWNjZXNzb3JfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yKSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFNlbGVjdE11bHRpcGxlQ29udHJvbFZhbHVlQWNjZXNzb3IpO1xuICAgIH07XG4gIH0pKCk7XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IFNlbGVjdE11bHRpcGxlQ29udHJvbFZhbHVlQWNjZXNzb3IsXG4gICAgc2VsZWN0b3JzOiBbW1wic2VsZWN0XCIsIFwibXVsdGlwbGVcIiwgXCJcIiwgXCJmb3JtQ29udHJvbE5hbWVcIiwgXCJcIiwgMywgXCJuZ05vQ3ZhXCIsIFwiXCJdLCBbXCJzZWxlY3RcIiwgXCJtdWx0aXBsZVwiLCBcIlwiLCBcImZvcm1Db250cm9sXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXSwgW1wic2VsZWN0XCIsIFwibXVsdGlwbGVcIiwgXCJcIiwgXCJuZ01vZGVsXCIsIFwiXCIsIDMsIFwibmdOb0N2YVwiLCBcIlwiXV0sXG4gICAgaG9zdEJpbmRpbmdzOiBmdW5jdGlvbiBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yX0hvc3RCaW5kaW5ncyhyZiwgY3R4KSB7XG4gICAgICBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcImNoYW5nZVwiLCBmdW5jdGlvbiBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yX2NoYW5nZV9Ib3N0QmluZGluZ0hhbmRsZXIoJGV2ZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vbkNoYW5nZSgkZXZlbnQudGFyZ2V0KTtcbiAgICAgICAgfSkoXCJibHVyXCIsIGZ1bmN0aW9uIFNlbGVjdE11bHRpcGxlQ29udHJvbFZhbHVlQWNjZXNzb3JfYmx1cl9Ib3N0QmluZGluZ0hhbmRsZXIoKSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vblRvdWNoZWQoKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIGNvbXBhcmVXaXRoOiBcImNvbXBhcmVXaXRoXCJcbiAgICB9LFxuICAgIHN0YW5kYWxvbmU6IGZhbHNlLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtVByb3ZpZGVyc0ZlYXR1cmUoW1NFTEVDVF9NVUxUSVBMRV9WQUxVRV9BQ0NFU1NPUl0pLCBpMC7Jtcm1SW5oZXJpdERlZmluaXRpb25GZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFNlbGVjdE11bHRpcGxlQ29udHJvbFZhbHVlQWNjZXNzb3IsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ3NlbGVjdFttdWx0aXBsZV06bm90KFtuZ05vQ3ZhXSlbZm9ybUNvbnRyb2xOYW1lXSxzZWxlY3RbbXVsdGlwbGVdOm5vdChbbmdOb0N2YV0pW2Zvcm1Db250cm9sXSxzZWxlY3RbbXVsdGlwbGVdOm5vdChbbmdOb0N2YV0pW25nTW9kZWxdJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJyhjaGFuZ2UpJzogJ29uQ2hhbmdlKCRldmVudC50YXJnZXQpJyxcbiAgICAgICAgJyhibHVyKSc6ICdvblRvdWNoZWQoKSdcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcnM6IFtTRUxFQ1RfTVVMVElQTEVfVkFMVUVfQUNDRVNTT1JdLFxuICAgICAgc3RhbmRhbG9uZTogZmFsc2VcbiAgICB9XVxuICB9XSwgbnVsbCwge1xuICAgIGNvbXBhcmVXaXRoOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XVxuICB9KTtcbn0pKCk7XG5jbGFzcyDJtU5nU2VsZWN0TXVsdGlwbGVPcHRpb24ge1xuICBfZWxlbWVudDtcbiAgX3JlbmRlcmVyO1xuICBfc2VsZWN0O1xuICBpZDtcbiAgX3ZhbHVlO1xuICBjb25zdHJ1Y3RvcihfZWxlbWVudCwgX3JlbmRlcmVyLCBfc2VsZWN0KSB7XG4gICAgdGhpcy5fZWxlbWVudCA9IF9lbGVtZW50O1xuICAgIHRoaXMuX3JlbmRlcmVyID0gX3JlbmRlcmVyO1xuICAgIHRoaXMuX3NlbGVjdCA9IF9zZWxlY3Q7XG4gICAgaWYgKHRoaXMuX3NlbGVjdCkge1xuICAgICAgdGhpcy5pZCA9IHRoaXMuX3NlbGVjdC5fcmVnaXN0ZXJPcHRpb24odGhpcyk7XG4gICAgfVxuICB9XG4gIHNldCBuZ1ZhbHVlKHZhbHVlKSB7XG4gICAgaWYgKHRoaXMuX3NlbGVjdCA9PSBudWxsKSByZXR1cm47XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB0aGlzLl9zZXRFbGVtZW50VmFsdWUoX2J1aWxkVmFsdWVTdHJpbmcodGhpcy5pZCwgdmFsdWUpKTtcbiAgICB0aGlzLl9zZWxlY3Qud3JpdGVWYWx1ZSh0aGlzLl9zZWxlY3QudmFsdWUpO1xuICB9XG4gIHNldCB2YWx1ZSh2YWx1ZSkge1xuICAgIGlmICh0aGlzLl9zZWxlY3QpIHtcbiAgICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gICAgICB0aGlzLl9zZXRFbGVtZW50VmFsdWUoX2J1aWxkVmFsdWVTdHJpbmcodGhpcy5pZCwgdmFsdWUpKTtcbiAgICAgIHRoaXMuX3NlbGVjdC53cml0ZVZhbHVlKHRoaXMuX3NlbGVjdC52YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX3NldEVsZW1lbnRWYWx1ZSh2YWx1ZSk7XG4gICAgfVxuICB9XG4gIF9zZXRFbGVtZW50VmFsdWUodmFsdWUpIHtcbiAgICB0aGlzLl9yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLl9lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICd2YWx1ZScsIHZhbHVlKTtcbiAgfVxuICBfc2V0U2VsZWN0ZWQoc2VsZWN0ZWQpIHtcbiAgICB0aGlzLl9yZW5kZXJlci5zZXRQcm9wZXJ0eSh0aGlzLl9lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdzZWxlY3RlZCcsIHNlbGVjdGVkKTtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5fc2VsZWN0KSB7XG4gICAgICB0aGlzLl9zZWxlY3QuX29wdGlvbk1hcC5kZWxldGUodGhpcy5pZCk7XG4gICAgICB0aGlzLl9zZWxlY3Qud3JpdGVWYWx1ZSh0aGlzLl9zZWxlY3QudmFsdWUpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiDJtU5nU2VsZWN0TXVsdGlwbGVPcHRpb25fRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCDJtU5nU2VsZWN0TXVsdGlwbGVPcHRpb24pKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuRWxlbWVudFJlZiksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuUmVuZGVyZXIyKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yLCA5KSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IMm1TmdTZWxlY3RNdWx0aXBsZU9wdGlvbixcbiAgICBzZWxlY3RvcnM6IFtbXCJvcHRpb25cIl1dLFxuICAgIGlucHV0czoge1xuICAgICAgbmdWYWx1ZTogXCJuZ1ZhbHVlXCIsXG4gICAgICB2YWx1ZTogXCJ2YWx1ZVwiXG4gICAgfSxcbiAgICBzdGFuZGFsb25lOiBmYWxzZVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKMm1TmdTZWxlY3RNdWx0aXBsZU9wdGlvbiwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnb3B0aW9uJyxcbiAgICAgIHN0YW5kYWxvbmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuRWxlbWVudFJlZlxuICB9LCB7XG4gICAgdHlwZTogaTAuUmVuZGVyZXIyXG4gIH0sIHtcbiAgICB0eXBlOiBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IEhvc3RcbiAgICB9XVxuICB9XSwge1xuICAgIG5nVmFsdWU6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFsnbmdWYWx1ZSddXG4gICAgfV0sXG4gICAgdmFsdWU6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFsndmFsdWUnXVxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNvbnN0IFNIQVJFRF9GT1JNX0RJUkVDVElWRVMgPSBbybVOZ05vVmFsaWRhdGUsIE5nU2VsZWN0T3B0aW9uLCDJtU5nU2VsZWN0TXVsdGlwbGVPcHRpb24sIERlZmF1bHRWYWx1ZUFjY2Vzc29yLCBOdW1iZXJWYWx1ZUFjY2Vzc29yLCBSYW5nZVZhbHVlQWNjZXNzb3IsIENoZWNrYm94Q29udHJvbFZhbHVlQWNjZXNzb3IsIFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yLCBSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOZ0NvbnRyb2xTdGF0dXMsIE5nQ29udHJvbFN0YXR1c0dyb3VwLCBSZXF1aXJlZFZhbGlkYXRvciwgTWluTGVuZ3RoVmFsaWRhdG9yLCBNYXhMZW5ndGhWYWxpZGF0b3IsIFBhdHRlcm5WYWxpZGF0b3IsIENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IsIEVtYWlsVmFsaWRhdG9yLCBNaW5WYWxpZGF0b3IsIE1heFZhbGlkYXRvcl07XG5jb25zdCBURU1QTEFURV9EUklWRU5fRElSRUNUSVZFUyA9IFtOZ01vZGVsLCBOZ01vZGVsR3JvdXAsIE5nRm9ybV07XG5jb25zdCBSRUFDVElWRV9EUklWRU5fRElSRUNUSVZFUyA9IFtGb3JtQ29udHJvbERpcmVjdGl2ZSwgRm9ybUdyb3VwRGlyZWN0aXZlLCBGb3JtQXJyYXlEaXJlY3RpdmUsIEZvcm1Db250cm9sTmFtZSwgRm9ybUdyb3VwTmFtZSwgRm9ybUFycmF5TmFtZV07XG5jbGFzcyDJtUludGVybmFsRm9ybXNTaGFyZWRNb2R1bGUge1xuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiDJtUludGVybmFsRm9ybXNTaGFyZWRNb2R1bGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IMm1SW50ZXJuYWxGb3Jtc1NoYXJlZE1vZHVsZSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1bW9kID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZU5nTW9kdWxlKHtcbiAgICB0eXBlOiDJtUludGVybmFsRm9ybXNTaGFyZWRNb2R1bGUsXG4gICAgZGVjbGFyYXRpb25zOiBbybVOZ05vVmFsaWRhdGUsIE5nU2VsZWN0T3B0aW9uLCDJtU5nU2VsZWN0TXVsdGlwbGVPcHRpb24sIERlZmF1bHRWYWx1ZUFjY2Vzc29yLCBOdW1iZXJWYWx1ZUFjY2Vzc29yLCBSYW5nZVZhbHVlQWNjZXNzb3IsIENoZWNrYm94Q29udHJvbFZhbHVlQWNjZXNzb3IsIFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yLCBSYWRpb0NvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOZ0NvbnRyb2xTdGF0dXMsIE5nQ29udHJvbFN0YXR1c0dyb3VwLCBSZXF1aXJlZFZhbGlkYXRvciwgTWluTGVuZ3RoVmFsaWRhdG9yLCBNYXhMZW5ndGhWYWxpZGF0b3IsIFBhdHRlcm5WYWxpZGF0b3IsIENoZWNrYm94UmVxdWlyZWRWYWxpZGF0b3IsIEVtYWlsVmFsaWRhdG9yLCBNaW5WYWxpZGF0b3IsIE1heFZhbGlkYXRvcl0sXG4gICAgZXhwb3J0czogW8m1TmdOb1ZhbGlkYXRlLCBOZ1NlbGVjdE9wdGlvbiwgybVOZ1NlbGVjdE11bHRpcGxlT3B0aW9uLCBEZWZhdWx0VmFsdWVBY2Nlc3NvciwgTnVtYmVyVmFsdWVBY2Nlc3NvciwgUmFuZ2VWYWx1ZUFjY2Vzc29yLCBDaGVja2JveENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBTZWxlY3RDb250cm9sVmFsdWVBY2Nlc3NvciwgU2VsZWN0TXVsdGlwbGVDb250cm9sVmFsdWVBY2Nlc3NvciwgUmFkaW9Db250cm9sVmFsdWVBY2Nlc3NvciwgTmdDb250cm9sU3RhdHVzLCBOZ0NvbnRyb2xTdGF0dXNHcm91cCwgUmVxdWlyZWRWYWxpZGF0b3IsIE1pbkxlbmd0aFZhbGlkYXRvciwgTWF4TGVuZ3RoVmFsaWRhdG9yLCBQYXR0ZXJuVmFsaWRhdG9yLCBDaGVja2JveFJlcXVpcmVkVmFsaWRhdG9yLCBFbWFpbFZhbGlkYXRvciwgTWluVmFsaWRhdG9yLCBNYXhWYWxpZGF0b3JdXG4gIH0pO1xuICBzdGF0aWMgybVpbmogPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0b3Ioe30pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoybVJbnRlcm5hbEZvcm1zU2hhcmVkTW9kdWxlLCBbe1xuICAgIHR5cGU6IE5nTW9kdWxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBkZWNsYXJhdGlvbnM6IFNIQVJFRF9GT1JNX0RJUkVDVElWRVMsXG4gICAgICBleHBvcnRzOiBTSEFSRURfRk9STV9ESVJFQ1RJVkVTXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGlzQWJzdHJhY3RDb250cm9sT3B0aW9ucyhvcHRpb25zKSB7XG4gIHJldHVybiAhIW9wdGlvbnMgJiYgKG9wdGlvbnMuYXN5bmNWYWxpZGF0b3JzICE9PSB1bmRlZmluZWQgfHwgb3B0aW9ucy52YWxpZGF0b3JzICE9PSB1bmRlZmluZWQgfHwgb3B0aW9ucy51cGRhdGVPbiAhPT0gdW5kZWZpbmVkKTtcbn1cbmNsYXNzIEZvcm1CdWlsZGVyIHtcbiAgdXNlTm9uTnVsbGFibGUgPSBmYWxzZTtcbiAgZ2V0IG5vbk51bGxhYmxlKCkge1xuICAgIGNvbnN0IG5uZmIgPSBuZXcgRm9ybUJ1aWxkZXIoKTtcbiAgICBubmZiLnVzZU5vbk51bGxhYmxlID0gdHJ1ZTtcbiAgICByZXR1cm4gbm5mYjtcbiAgfVxuICBncm91cChjb250cm9scywgb3B0aW9ucyA9IG51bGwpIHtcbiAgICBjb25zdCByZWR1Y2VkQ29udHJvbHMgPSB0aGlzLl9yZWR1Y2VDb250cm9scyhjb250cm9scyk7XG4gICAgbGV0IG5ld09wdGlvbnMgPSB7fTtcbiAgICBpZiAoaXNBYnN0cmFjdENvbnRyb2xPcHRpb25zKG9wdGlvbnMpKSB7XG4gICAgICBuZXdPcHRpb25zID0gb3B0aW9ucztcbiAgICB9IGVsc2UgaWYgKG9wdGlvbnMgIT09IG51bGwpIHtcbiAgICAgIG5ld09wdGlvbnMudmFsaWRhdG9ycyA9IG9wdGlvbnMudmFsaWRhdG9yO1xuICAgICAgbmV3T3B0aW9ucy5hc3luY1ZhbGlkYXRvcnMgPSBvcHRpb25zLmFzeW5jVmFsaWRhdG9yO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEZvcm1Hcm91cChyZWR1Y2VkQ29udHJvbHMsIG5ld09wdGlvbnMpO1xuICB9XG4gIHJlY29yZChjb250cm9scywgb3B0aW9ucyA9IG51bGwpIHtcbiAgICBjb25zdCByZWR1Y2VkQ29udHJvbHMgPSB0aGlzLl9yZWR1Y2VDb250cm9scyhjb250cm9scyk7XG4gICAgcmV0dXJuIG5ldyBGb3JtUmVjb3JkKHJlZHVjZWRDb250cm9scywgb3B0aW9ucyk7XG4gIH1cbiAgY29udHJvbChmb3JtU3RhdGUsIHZhbGlkYXRvck9yT3B0cywgYXN5bmNWYWxpZGF0b3IpIHtcbiAgICBsZXQgbmV3T3B0aW9ucyA9IHt9O1xuICAgIGlmICghdGhpcy51c2VOb25OdWxsYWJsZSkge1xuICAgICAgcmV0dXJuIG5ldyBGb3JtQ29udHJvbChmb3JtU3RhdGUsIHZhbGlkYXRvck9yT3B0cywgYXN5bmNWYWxpZGF0b3IpO1xuICAgIH1cbiAgICBpZiAoaXNBYnN0cmFjdENvbnRyb2xPcHRpb25zKHZhbGlkYXRvck9yT3B0cykpIHtcbiAgICAgIG5ld09wdGlvbnMgPSB2YWxpZGF0b3JPck9wdHM7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld09wdGlvbnMudmFsaWRhdG9ycyA9IHZhbGlkYXRvck9yT3B0cztcbiAgICAgIG5ld09wdGlvbnMuYXN5bmNWYWxpZGF0b3JzID0gYXN5bmNWYWxpZGF0b3I7XG4gICAgfVxuICAgIHJldHVybiBuZXcgRm9ybUNvbnRyb2woZm9ybVN0YXRlLCB7XG4gICAgICAuLi5uZXdPcHRpb25zLFxuICAgICAgbm9uTnVsbGFibGU6IHRydWVcbiAgICB9KTtcbiAgfVxuICBhcnJheShjb250cm9scywgdmFsaWRhdG9yT3JPcHRzLCBhc3luY1ZhbGlkYXRvcikge1xuICAgIGNvbnN0IGNyZWF0ZWRDb250cm9scyA9IGNvbnRyb2xzLm1hcChjID0+IHRoaXMuX2NyZWF0ZUNvbnRyb2woYykpO1xuICAgIHJldHVybiBuZXcgRm9ybUFycmF5KGNyZWF0ZWRDb250cm9scywgdmFsaWRhdG9yT3JPcHRzLCBhc3luY1ZhbGlkYXRvcik7XG4gIH1cbiAgX3JlZHVjZUNvbnRyb2xzKGNvbnRyb2xzKSB7XG4gICAgY29uc3QgY3JlYXRlZENvbnRyb2xzID0ge307XG4gICAgT2JqZWN0LmtleXMoY29udHJvbHMpLmZvckVhY2goY29udHJvbE5hbWUgPT4ge1xuICAgICAgY3JlYXRlZENvbnRyb2xzW2NvbnRyb2xOYW1lXSA9IHRoaXMuX2NyZWF0ZUNvbnRyb2woY29udHJvbHNbY29udHJvbE5hbWVdKTtcbiAgICB9KTtcbiAgICByZXR1cm4gY3JlYXRlZENvbnRyb2xzO1xuICB9XG4gIF9jcmVhdGVDb250cm9sKGNvbnRyb2xzKSB7XG4gICAgaWYgKGNvbnRyb2xzIGluc3RhbmNlb2YgRm9ybUNvbnRyb2wpIHtcbiAgICAgIHJldHVybiBjb250cm9scztcbiAgICB9IGVsc2UgaWYgKGNvbnRyb2xzIGluc3RhbmNlb2YgQWJzdHJhY3RDb250cm9sKSB7XG4gICAgICByZXR1cm4gY29udHJvbHM7XG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGNvbnRyb2xzKSkge1xuICAgICAgY29uc3QgdmFsdWUgPSBjb250cm9sc1swXTtcbiAgICAgIGNvbnN0IHZhbGlkYXRvciA9IGNvbnRyb2xzLmxlbmd0aCA+IDEgPyBjb250cm9sc1sxXSA6IG51bGw7XG4gICAgICBjb25zdCBhc3luY1ZhbGlkYXRvciA9IGNvbnRyb2xzLmxlbmd0aCA+IDIgPyBjb250cm9sc1syXSA6IG51bGw7XG4gICAgICByZXR1cm4gdGhpcy5jb250cm9sKHZhbHVlLCB2YWxpZGF0b3IsIGFzeW5jVmFsaWRhdG9yKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuY29udHJvbChjb250cm9scyk7XG4gICAgfVxuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEZvcm1CdWlsZGVyX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBGb3JtQnVpbGRlcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogRm9ybUJ1aWxkZXIsXG4gICAgZmFjdG9yeTogRm9ybUJ1aWxkZXIuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShGb3JtQnVpbGRlciwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBOb25OdWxsYWJsZUZvcm1CdWlsZGVyIHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTm9uTnVsbGFibGVGb3JtQnVpbGRlcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTm9uTnVsbGFibGVGb3JtQnVpbGRlcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogTm9uTnVsbGFibGVGb3JtQnVpbGRlcixcbiAgICBmYWN0b3J5OiAoKSA9PiAoKCkgPT4gaW5qZWN0KEZvcm1CdWlsZGVyKS5ub25OdWxsYWJsZSkoKVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5vbk51bGxhYmxlRm9ybUJ1aWxkZXIsIFt7XG4gICAgdHlwZTogU2VydmljZSxcbiAgICBhcmdzOiBbe1xuICAgICAgZmFjdG9yeTogKCkgPT4gaW5qZWN0KEZvcm1CdWlsZGVyKS5ub25OdWxsYWJsZVxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBVbnR5cGVkRm9ybUJ1aWxkZXIgZXh0ZW5kcyBGb3JtQnVpbGRlciB7XG4gIGdyb3VwKGNvbnRyb2xzQ29uZmlnLCBvcHRpb25zID0gbnVsbCkge1xuICAgIHJldHVybiBzdXBlci5ncm91cChjb250cm9sc0NvbmZpZywgb3B0aW9ucyk7XG4gIH1cbiAgY29udHJvbChmb3JtU3RhdGUsIHZhbGlkYXRvck9yT3B0cywgYXN5bmNWYWxpZGF0b3IpIHtcbiAgICByZXR1cm4gc3VwZXIuY29udHJvbChmb3JtU3RhdGUsIHZhbGlkYXRvck9yT3B0cywgYXN5bmNWYWxpZGF0b3IpO1xuICB9XG4gIGFycmF5KGNvbnRyb2xzQ29uZmlnLCB2YWxpZGF0b3JPck9wdHMsIGFzeW5jVmFsaWRhdG9yKSB7XG4gICAgcmV0dXJuIHN1cGVyLmFycmF5KGNvbnRyb2xzQ29uZmlnLCB2YWxpZGF0b3JPck9wdHMsIGFzeW5jVmFsaWRhdG9yKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBVbnR5cGVkRm9ybUJ1aWxkZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFVudHlwZWRGb3JtQnVpbGRlcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogVW50eXBlZEZvcm1CdWlsZGVyLFxuICAgIGZhY3Rvcnk6IFVudHlwZWRGb3JtQnVpbGRlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFVudHlwZWRGb3JtQnVpbGRlciwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBGb3Jtc01vZHVsZSB7XG4gIHN0YXRpYyB3aXRoQ29uZmlnKG9wdHMpIHtcbiAgICByZXR1cm4ge1xuICAgICAgbmdNb2R1bGU6IEZvcm1zTW9kdWxlLFxuICAgICAgcHJvdmlkZXJzOiBbe1xuICAgICAgICBwcm92aWRlOiBDQUxMX1NFVF9ESVNBQkxFRF9TVEFURSxcbiAgICAgICAgdXNlVmFsdWU6IG9wdHMuY2FsbFNldERpc2FibGVkU3RhdGUgPz8gc2V0RGlzYWJsZWRTdGF0ZURlZmF1bHRcbiAgICAgIH1dXG4gICAgfTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBGb3Jtc01vZHVsZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRm9ybXNNb2R1bGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtW1vZCA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVOZ01vZHVsZSh7XG4gICAgdHlwZTogRm9ybXNNb2R1bGUsXG4gICAgZGVjbGFyYXRpb25zOiBbTmdNb2RlbCwgTmdNb2RlbEdyb3VwLCBOZ0Zvcm1dLFxuICAgIGV4cG9ydHM6IFvJtUludGVybmFsRm9ybXNTaGFyZWRNb2R1bGUsIE5nTW9kZWwsIE5nTW9kZWxHcm91cCwgTmdGb3JtXVxuICB9KTtcbiAgc3RhdGljIMm1aW5qID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdG9yKHtcbiAgICBpbXBvcnRzOiBbybVJbnRlcm5hbEZvcm1zU2hhcmVkTW9kdWxlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEZvcm1zTW9kdWxlLCBbe1xuICAgIHR5cGU6IE5nTW9kdWxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBkZWNsYXJhdGlvbnM6IFRFTVBMQVRFX0RSSVZFTl9ESVJFQ1RJVkVTLFxuICAgICAgZXhwb3J0czogW8m1SW50ZXJuYWxGb3Jtc1NoYXJlZE1vZHVsZSwgVEVNUExBVEVfRFJJVkVOX0RJUkVDVElWRVNdXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIFJlYWN0aXZlRm9ybXNNb2R1bGUge1xuICBzdGF0aWMgd2l0aENvbmZpZyhvcHRzKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5nTW9kdWxlOiBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuICAgICAgcHJvdmlkZXJzOiBbe1xuICAgICAgICBwcm92aWRlOiBOR19NT0RFTF9XSVRIX0ZPUk1fQ09OVFJPTF9XQVJOSU5HLFxuICAgICAgICB1c2VWYWx1ZTogb3B0cy53YXJuT25OZ01vZGVsV2l0aEZvcm1Db250cm9sID8/ICdhbHdheXMnXG4gICAgICB9LCB7XG4gICAgICAgIHByb3ZpZGU6IENBTExfU0VUX0RJU0FCTEVEX1NUQVRFLFxuICAgICAgICB1c2VWYWx1ZTogb3B0cy5jYWxsU2V0RGlzYWJsZWRTdGF0ZSA/PyBzZXREaXNhYmxlZFN0YXRlRGVmYXVsdFxuICAgICAgfV1cbiAgICB9O1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFJlYWN0aXZlRm9ybXNNb2R1bGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFJlYWN0aXZlRm9ybXNNb2R1bGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtW1vZCA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVOZ01vZHVsZSh7XG4gICAgdHlwZTogUmVhY3RpdmVGb3Jtc01vZHVsZSxcbiAgICBkZWNsYXJhdGlvbnM6IFtGb3JtQ29udHJvbERpcmVjdGl2ZSwgRm9ybUdyb3VwRGlyZWN0aXZlLCBGb3JtQXJyYXlEaXJlY3RpdmUsIEZvcm1Db250cm9sTmFtZSwgRm9ybUdyb3VwTmFtZSwgRm9ybUFycmF5TmFtZV0sXG4gICAgZXhwb3J0czogW8m1SW50ZXJuYWxGb3Jtc1NoYXJlZE1vZHVsZSwgRm9ybUNvbnRyb2xEaXJlY3RpdmUsIEZvcm1Hcm91cERpcmVjdGl2ZSwgRm9ybUFycmF5RGlyZWN0aXZlLCBGb3JtQ29udHJvbE5hbWUsIEZvcm1Hcm91cE5hbWUsIEZvcm1BcnJheU5hbWVdXG4gIH0pO1xuICBzdGF0aWMgybVpbmogPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0b3Ioe1xuICAgIGltcG9ydHM6IFvJtUludGVybmFsRm9ybXNTaGFyZWRNb2R1bGVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUmVhY3RpdmVGb3Jtc01vZHVsZSwgW3tcbiAgICB0eXBlOiBOZ01vZHVsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgZGVjbGFyYXRpb25zOiBbUkVBQ1RJVkVfRFJJVkVOX0RJUkVDVElWRVNdLFxuICAgICAgZXhwb3J0czogW8m1SW50ZXJuYWxGb3Jtc1NoYXJlZE1vZHVsZSwgUkVBQ1RJVkVfRFJJVkVOX0RJUkVDVElWRVNdXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmV4cG9ydCB7IEFic3RyYWN0Q29udHJvbCwgQWJzdHJhY3RDb250cm9sRGlyZWN0aXZlLCBBYnN0cmFjdEZvcm1EaXJlY3RpdmUsIEFic3RyYWN0Rm9ybUdyb3VwRGlyZWN0aXZlLCBDT01QT1NJVElPTl9CVUZGRVJfTU9ERSwgQ2hlY2tib3hDb250cm9sVmFsdWVBY2Nlc3NvciwgQ2hlY2tib3hSZXF1aXJlZFZhbGlkYXRvciwgQ29udHJvbENvbnRhaW5lciwgQ29udHJvbEV2ZW50LCBEZWZhdWx0VmFsdWVBY2Nlc3NvciwgRW1haWxWYWxpZGF0b3IsIEZvcm1BcnJheSwgRm9ybUFycmF5RGlyZWN0aXZlLCBGb3JtQXJyYXlOYW1lLCBGb3JtQnVpbGRlciwgRm9ybUNvbnRyb2wsIEZvcm1Db250cm9sRGlyZWN0aXZlLCBGb3JtQ29udHJvbE5hbWUsIEZvcm1Hcm91cCwgRm9ybUdyb3VwRGlyZWN0aXZlLCBGb3JtR3JvdXBOYW1lLCBGb3JtUmVjb3JkLCBGb3JtUmVzZXRFdmVudCwgRm9ybVN1Ym1pdHRlZEV2ZW50LCBGb3Jtc01vZHVsZSwgTWF4TGVuZ3RoVmFsaWRhdG9yLCBNYXhWYWxpZGF0b3IsIE1pbkxlbmd0aFZhbGlkYXRvciwgTWluVmFsaWRhdG9yLCBOR19BU1lOQ19WQUxJREFUT1JTLCBOR19WQUxJREFUT1JTLCBOR19WQUxVRV9BQ0NFU1NPUiwgTmdDb250cm9sLCBOZ0NvbnRyb2xTdGF0dXMsIE5nQ29udHJvbFN0YXR1c0dyb3VwLCBOZ0Zvcm0sIE5nTW9kZWwsIE5nTW9kZWxHcm91cCwgTmdTZWxlY3RPcHRpb24sIE5vbk51bGxhYmxlRm9ybUJ1aWxkZXIsIE51bWJlclZhbHVlQWNjZXNzb3IsIFBhdHRlcm5WYWxpZGF0b3IsIFByaXN0aW5lQ2hhbmdlRXZlbnQsIFJhZGlvQ29udHJvbFZhbHVlQWNjZXNzb3IsIFJhbmdlVmFsdWVBY2Nlc3NvciwgUmVhY3RpdmVGb3Jtc01vZHVsZSwgUmVxdWlyZWRWYWxpZGF0b3IsIFNlbGVjdENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBTZWxlY3RNdWx0aXBsZUNvbnRyb2xWYWx1ZUFjY2Vzc29yLCBTdGF0dXNDaGFuZ2VFdmVudCwgVG91Y2hlZENoYW5nZUV2ZW50LCBVbnR5cGVkRm9ybUFycmF5LCBVbnR5cGVkRm9ybUJ1aWxkZXIsIFVudHlwZWRGb3JtQ29udHJvbCwgVW50eXBlZEZvcm1Hcm91cCwgVkVSU0lPTiwgVmFsaWRhdG9ycywgVmFsdWVDaGFuZ2VFdmVudCwgaXNGb3JtQXJyYXksIGlzRm9ybUNvbnRyb2wsIGlzRm9ybUdyb3VwLCBpc0Zvcm1SZWNvcmQsIMm1Rk9STV9DT05UUk9MX0lOVEVHUkFUSU9OLCDJtUludGVybmFsRm9ybXNTaGFyZWRNb2R1bGUsIMm1TmdOb1ZhbGlkYXRlLCDJtU5nU2VsZWN0TXVsdGlwbGVPcHRpb24sIGVsZW1lbnRBY2NlcHRzTWluTWF4IGFzIMm1ZWxlbWVudEFjY2VwdHNNaW5NYXgsIGlzTmF0aXZlRm9ybUVsZW1lbnQgYXMgybVpc05hdGl2ZUZvcm1FbGVtZW50LCBpc1RleHR1YWxGb3JtRWxlbWVudCBhcyDJtWlzVGV4dHVhbEZvcm1FbGVtZW50LCBzZWxlY3RWYWx1ZUFjY2Vzc29yIGFzIMm1c2VsZWN0VmFsdWVBY2Nlc3Nvciwgc2V0TmF0aXZlRG9tUHJvcGVydHkgYXMgybVzZXROYXRpdmVEb21Qcm9wZXJ0eSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Zm9ybXMubWpzLm1hcCJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVdBLElBQU0sMkJBQU4sTUFBK0I7Q0FLN0IsWUFBWSxXQUFXLGFBQWE7d0JBSnBDLGFBQUEsS0FBQSxDQUFBO3dCQUNBLGVBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQVcsTUFBSyxDQUFDLENBQUE7d0JBQ2pCLG1CQUFrQixDQUFDLENBQUE7RUFFakIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztDQUNyQjtDQUNBLFlBQVksS0FBSyxPQUFPO0VBQ3RCLEtBQUssVUFBVSxZQUFZLEtBQUssWUFBWSxlQUFlLEtBQUssS0FBSztDQUN2RTtDQUNBLGtCQUFrQixJQUFJO0VBQ3BCLEtBQUssWUFBWTtDQUNuQjtDQUNBLGlCQUFpQixJQUFJO0VBQ25CLEtBQUssV0FBVztDQUNsQjtDQUNBLGlCQUFpQixZQUFZO0VBQzNCLEtBQUssWUFBWSxZQUFZLFVBQVU7Q0FDekM7QUFRRjs7MENBUFMsUUFBTyxTQUFTLGlDQUFpQyxtQkFBbUI7Q0FFekUsT0FBTyxLQUFLLHFCQUFxQkEsMkJBQTBCQyxrQkFBcUJDLFNBQVksR0FBR0Qsa0JBQXFCRSxVQUFhLENBQUM7QUFDcEksQ0FBQTswQ0FDTyxRQUFzQixrQ0FBcUIsRUFDaEQsTUFBTUgsMEJBQ1IsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNJLGlCQUFxQiwwQkFBMEIsQ0FBQyxFQUNqRyxNQUFNLFVBQ1IsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNRixVQUNSLEdBQUcsRUFDRCxNQUFNQyxXQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSw4QkFBTixjQUEwQyx5QkFBeUIsQ0FXbkU7OzZDQVZTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsb0NBQW9DLG1CQUFtQjtFQUNyRSxRQUFRLDZDQUE2QywyQ0FBMkNFLHNCQUF5QkMsNEJBQTJCLEdBQUEsQ0FBSSxxQkFBcUJBLDRCQUEyQjtDQUMxTTtBQUNGLEVBQUEsQ0FBRyxDQUFBOzZDQUNJLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFVBQVUsQ0FBQ0MsMEJBQTZCO0FBQzFDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsNkJBQTZCLENBQUMsRUFDcEcsTUFBTSxVQUNSLENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxvQkFBb0IsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksb0JBQW9CLEVBQUU7QUFDbkgsSUFBTSwwQkFBMEI7Q0FDOUIsU0FBUztDQUNULGFBQWEsaUJBQWlCLDRCQUE0QjtDQUMxRCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLCtCQUFOLGNBQTJDLDRCQUE0QjtDQUNyRSxXQUFXLE9BQU87RUFDaEIsS0FBSyxZQUFZLFdBQVcsS0FBSztDQUNuQztBQXNCRjs7OENBckJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMscUNBQXFDLG1CQUFtQjtFQUN0RSxRQUFRLDhDQUE4Qyw0Q0FBNENDLHNCQUF5QkcsNkJBQTRCLEdBQUEsQ0FBSSxxQkFBcUJBLDZCQUE0QjtDQUM5TTtBQUNGLEVBQUEsQ0FBRyxDQUFBOzhDQUNJLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVc7RUFBQztHQUFDO0dBQVM7R0FBUTtHQUFZO0dBQW1CO0dBQUk7R0FBRztHQUFXO0VBQUU7RUFBRztHQUFDO0dBQVM7R0FBUTtHQUFZO0dBQWU7R0FBSTtHQUFHO0dBQVc7RUFBRTtFQUFHO0dBQUM7R0FBUztHQUFRO0dBQVk7R0FBVztHQUFJO0dBQUc7R0FBVztFQUFFO0NBQUM7Q0FDdE4sY0FBYyxTQUFTLDBDQUEwQyxJQUFJLEtBQUs7RUFDeEUsSUFBSSxLQUFLLEdBQ1AsV0FBYyxVQUFVLFNBQVMsdURBQXVELFFBQVE7R0FDOUYsT0FBTyxJQUFJLFNBQVMsT0FBTyxPQUFPLE9BQU87RUFDM0MsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLHVEQUF1RDtHQUN6RSxPQUFPLElBQUksVUFBVTtFQUN2QixDQUFDO0NBRUw7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDQyxtQkFBc0IsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDNUYsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQiw4QkFBOEIsQ0FBQztFQUNyRyxNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLE1BQU07SUFDSixZQUFZO0lBQ1osVUFBVTtHQUNaO0dBQ0EsV0FBVyxDQUFDLHVCQUF1QjtHQUNuQyxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSx5QkFBeUI7Q0FDN0IsU0FBUztDQUNULGFBQWEsaUJBQWlCLG9CQUFvQjtDQUNsRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGFBQWE7Q0FDcEIsTUFBTSxZQUFZTSxPQUFRLElBQUlBLE9BQVEsQ0FBQyxDQUFDLGFBQWEsSUFBSTtDQUN6RCxPQUFPLGdCQUFnQixLQUFLLFVBQVUsWUFBWSxDQUFDO0FBQ3JEO0FBQ0EsSUFBTSwwQkFBMEIsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVkseUJBQXlCLEVBQUU7QUFDOUgsSUFBTSx1QkFBTixjQUFtQyx5QkFBeUI7Q0FHMUQsWUFBWSxVQUFVLFlBQVksa0JBQWtCO0VBQ2xELE1BQU0sVUFBVSxVQUFVO3dCQUg1QixvQkFBQSxLQUFBLENBQUE7d0JBQ0EsY0FBYSxLQUFBO0VBR1gsS0FBSyxtQkFBbUI7RUFDeEIsSUFBSSxLQUFLLG9CQUFvQixNQUMzQixLQUFLLG1CQUFtQixDQUFDLFdBQVc7Q0FFeEM7Q0FDQSxXQUFXLE9BQU87RUFDaEIsTUFBTSxrQkFBa0IsU0FBUyxPQUFPLEtBQUs7RUFDN0MsS0FBSyxZQUFZLFNBQVMsZUFBZTtDQUMzQztDQUNBLGFBQWEsT0FBTztFQUNsQixJQUFJLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxvQkFBb0IsQ0FBQyxLQUFLLFlBQzNELEtBQUssU0FBUyxLQUFLO0NBRXZCO0NBQ0Esb0JBQW9CO0VBQ2xCLEtBQUssYUFBYTtDQUNwQjtDQUNBLGdCQUFnQixPQUFPO0VBQ3JCLEtBQUssYUFBYTtFQUNsQixLQUFLLG9CQUFvQixLQUFLLFNBQVMsS0FBSztDQUM5QztBQXdCRjs7c0NBdkJTLFFBQU8sU0FBUyw2QkFBNkIsbUJBQW1CO0NBRXJFLE9BQU8sS0FBSyxxQkFBcUJDLHVCQUFzQlYsa0JBQXFCQyxTQUFZLEdBQUdELGtCQUFxQkUsVUFBYSxHQUFHRixrQkFBcUIseUJBQXlCLENBQUMsQ0FBQztBQUNsTCxDQUFBO3NDQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNVTtDQUNOLFdBQVc7RUFBQztHQUFDO0dBQVM7R0FBbUI7R0FBSTtHQUFHO0dBQVE7R0FBWTtHQUFHO0dBQVc7RUFBRTtFQUFHO0dBQUM7R0FBWTtHQUFtQjtHQUFJO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFTO0dBQWU7R0FBSTtHQUFHO0dBQVE7R0FBWTtHQUFHO0dBQVc7RUFBRTtFQUFHO0dBQUM7R0FBWTtHQUFlO0dBQUk7R0FBRztHQUFXO0VBQUU7RUFBRztHQUFDO0dBQVM7R0FBVztHQUFJO0dBQUc7R0FBUTtHQUFZO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFZO0dBQVc7R0FBSTtHQUFHO0dBQVc7RUFBRTtFQUFHO0dBQUM7R0FBSTtHQUFvQjtFQUFFO0NBQUM7Q0FDdFosY0FBYyxTQUFTLGtDQUFrQyxJQUFJLEtBQUs7RUFDaEUsSUFBSSxLQUFLLEdBQ1AsV0FBYyxTQUFTLFNBQVMsOENBQThDLFFBQVE7R0FDcEYsT0FBTyxJQUFJLGFBQWEsT0FBTyxPQUFPLEtBQUs7RUFDN0MsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLCtDQUErQztHQUNqRSxPQUFPLElBQUksVUFBVTtFQUN2QixDQUFDLENBQUMsQ0FBQyxvQkFBb0IsU0FBUywyREFBMkQ7R0FDekYsT0FBTyxJQUFJLGtCQUFrQjtFQUMvQixDQUFDLENBQUMsQ0FBQyxrQkFBa0IsU0FBUyx1REFBdUQsUUFBUTtHQUMzRixPQUFPLElBQUksZ0JBQWdCLE9BQU8sT0FBTyxLQUFLO0VBQ2hELENBQUM7Q0FFTDtDQUNBLFlBQVk7Q0FDWixVQUFVLENBQUNGLG1CQUFzQixDQUFDLHNCQUFzQixDQUFDLEdBQUdGLDBCQUE2QjtBQUMzRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLHNCQUFzQixDQUFDO0VBQzdGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsTUFBTTtJQUNKLFdBQVc7SUFDWCxVQUFVO0lBQ1Ysc0JBQXNCO0lBQ3RCLG9CQUFvQjtHQUN0QjtHQUNBLFdBQVcsQ0FBQyxzQkFBc0I7R0FDbEMsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVM7RUFBQyxFQUNULE1BQU1GLFVBQ1I7RUFBRyxFQUNELE1BQU1DLFdBQ1I7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixHQUFHO0lBQ0QsTUFBTTtJQUNOLE1BQU0sQ0FBQyx1QkFBdUI7R0FDaEMsQ0FBQztFQUNIO0NBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsU0FBUyxrQkFBa0IsT0FBTztDQUNoQyxPQUFPLFNBQVMsUUFBUSxhQUFhLEtBQUssTUFBTTtBQUNsRDtBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLElBQUksU0FBUyxNQUNYLE9BQU87TUFDRixJQUFJLE1BQU0sUUFBUSxLQUFLLEtBQUssT0FBTyxVQUFVLFVBQ2xELE9BQU8sTUFBTTtNQUNSLElBQUksaUJBQWlCLEtBQzFCLE9BQU8sTUFBTTtDQUVmLE9BQU87QUFDVDtBQUNBLElBQU0sZ0JBQWdCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLGlCQUFpQixFQUFFO0FBQzVHLElBQU0sc0JBQXNCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHNCQUFzQixFQUFFO0FBQ3ZILElBQU0sZUFBZTtBQUNyQixJQUFNLGFBQU4sTUFBaUI7Q0FDZixPQUFPLElBQUksS0FBSztFQUNkLE9BQU8sYUFBYSxHQUFHO0NBQ3pCO0NBQ0EsT0FBTyxJQUFJLEtBQUs7RUFDZCxPQUFPLGFBQWEsR0FBRztDQUN6QjtDQUNBLE9BQU8sU0FBUyxTQUFTO0VBQ3ZCLE9BQU8sa0JBQWtCLE9BQU87Q0FDbEM7Q0FDQSxPQUFPLGFBQWEsU0FBUztFQUMzQixPQUFPLHNCQUFzQixPQUFPO0NBQ3RDO0NBQ0EsT0FBTyxNQUFNLFNBQVM7RUFDcEIsT0FBTyxlQUFlLE9BQU87Q0FDL0I7Q0FDQSxPQUFPLFVBQVUsV0FBVztFQUMxQixPQUFPLG1CQUFtQixTQUFTO0NBQ3JDO0NBQ0EsT0FBTyxVQUFVLFdBQVc7RUFDMUIsT0FBTyxtQkFBbUIsU0FBUztDQUNyQztDQUNBLE9BQU8sUUFBUSxTQUFTO0VBQ3RCLE9BQU8saUJBQWlCLE9BQU87Q0FDakM7Q0FDQSxPQUFPLGNBQWMsU0FBUztFQUM1QixPQUFPLGNBQWM7Q0FDdkI7Q0FDQSxPQUFPLFFBQVEsWUFBWTtFQUN6QixPQUFPLFFBQVEsVUFBVTtDQUMzQjtDQUNBLE9BQU8sYUFBYSxZQUFZO0VBQzlCLE9BQU8sYUFBYSxVQUFVO0NBQ2hDO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsS0FBSztDQUN6QixRQUFPLFlBQVc7RUFDaEIsSUFBSSxRQUFRLFNBQVMsUUFBUSxPQUFPLE1BQ2xDLE9BQU87RUFFVCxNQUFNLFFBQVEsV0FBVyxRQUFRLEtBQUs7RUFDdEMsT0FBTyxDQUFDLE1BQU0sS0FBSyxLQUFLLFFBQVEsTUFBTSxFQUNwQyxPQUFPO0dBQ0wsT0FBTztHQUNQLFVBQVUsUUFBUTtFQUNwQixFQUNGLElBQUk7Q0FDTjtBQUNGO0FBQ0EsU0FBUyxhQUFhLEtBQUs7Q0FDekIsUUFBTyxZQUFXO0VBQ2hCLElBQUksUUFBUSxTQUFTLFFBQVEsT0FBTyxNQUNsQyxPQUFPO0VBRVQsTUFBTSxRQUFRLFdBQVcsUUFBUSxLQUFLO0VBQ3RDLE9BQU8sQ0FBQyxNQUFNLEtBQUssS0FBSyxRQUFRLE1BQU0sRUFDcEMsT0FBTztHQUNMLE9BQU87R0FDUCxVQUFVLFFBQVE7RUFDcEIsRUFDRixJQUFJO0NBQ047QUFDRjtBQUNBLFNBQVMsa0JBQWtCLFNBQVM7Q0FDbEMsT0FBTyxrQkFBa0IsUUFBUSxLQUFLLElBQUksRUFDeEMsWUFBWSxLQUNkLElBQUk7QUFDTjtBQUNBLFNBQVMsc0JBQXNCLFNBQVM7Q0FDdEMsT0FBTyxRQUFRLFVBQVUsT0FBTyxPQUFPLEVBQ3JDLFlBQVksS0FDZDtBQUNGO0FBQ0EsU0FBUyxlQUFlLFNBQVM7Q0FDL0IsSUFBSSxrQkFBa0IsUUFBUSxLQUFLLEdBQ2pDLE9BQU87Q0FFVCxPQUFPLGFBQWEsS0FBSyxRQUFRLEtBQUssSUFBSSxPQUFPLEVBQy9DLFNBQVMsS0FDWDtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsV0FBVztDQUNyQyxRQUFPLFlBQVc7O0VBQ2hCLE1BQU0sVUFBQSx5QkFBQSxpQkFBUyxRQUFRLFdBQUEsUUFBQSxtQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLGVBQU8sWUFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBVSxhQUFhLFFBQVEsS0FBSztFQUNsRSxJQUFJLFdBQVcsUUFBUSxXQUFXLEdBQ2hDLE9BQU87RUFFVCxPQUFPLFNBQVMsWUFBWSxFQUMxQixhQUFhO0dBQ1gsa0JBQWtCO0dBQ2xCLGdCQUFnQjtFQUNsQixFQUNGLElBQUk7Q0FDTjtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsV0FBVztDQUNyQyxRQUFPLFlBQVc7O0VBQ2hCLE1BQU0sVUFBQSwwQkFBQSxrQkFBUyxRQUFRLFdBQUEsUUFBQSxvQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLGdCQUFPLFlBQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEseUJBQVUsYUFBYSxRQUFRLEtBQUs7RUFDbEUsSUFBSSxXQUFXLFFBQVEsU0FBUyxXQUM5QixPQUFPLEVBQ0wsYUFBYTtHQUNYLGtCQUFrQjtHQUNsQixnQkFBZ0I7RUFDbEIsRUFDRjtFQUVGLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxJQUFJLENBQUMsU0FBUyxPQUFPO0NBQ3JCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxPQUFPLFlBQVksVUFBVTtFQUMvQixXQUFXO0VBQ1gsSUFBSSxRQUFRLE9BQU8sQ0FBQyxNQUFNLEtBQUssWUFBWTtFQUMzQyxZQUFZO0VBQ1osSUFBSSxRQUFRLE9BQU8sUUFBUSxTQUFTLENBQUMsTUFBTSxLQUFLLFlBQVk7RUFDNUQsUUFBUSxJQUFJLE9BQU8sUUFBUTtDQUM3QixPQUFPO0VBQ0wsV0FBVyxRQUFRLFNBQVM7RUFDNUIsUUFBUTtDQUNWO0NBQ0EsUUFBTyxZQUFXO0VBQ2hCLElBQUksa0JBQWtCLFFBQVEsS0FBSyxHQUNqQyxPQUFPO0VBRVQsTUFBTSxRQUFRLFFBQVE7RUFDdEIsT0FBTyxNQUFNLEtBQUssS0FBSyxJQUFJLE9BQU8sRUFDaEMsV0FBVztHQUNULG1CQUFtQjtHQUNuQixlQUFlO0VBQ2pCLEVBQ0Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxjQUFjLFNBQVM7Q0FDOUIsT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQUc7Q0FDcEIsT0FBTyxLQUFLO0FBQ2Q7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUMzQixNQUFNLE1BQU1TLFVBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJO0NBQzlDLEtBQUssT0FBTyxjQUFjLGVBQWUsY0FBYyxDQUFDQyxlQUFnQixHQUFHLEdBQUc7RUFDNUUsSUFBSSxlQUFlO0VBQ25CLElBQUksT0FBTyxVQUFVLFVBQ25CLGdCQUFnQjtFQUVsQixNQUFNLElBQUlDLGFBQWMsT0FBTyxZQUFZO0NBQzdDO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLGVBQWU7Q0FDbEMsSUFBSSxNQUFNLENBQUM7Q0FDWCxjQUFjLFNBQVEsV0FBVTtFQUM5QixNQUFNLFVBQVUsT0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNYLEdBQUEsR0FDQSxNQUNMLElBQUk7Q0FDTixDQUFDO0NBQ0QsT0FBTyxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsV0FBVyxJQUFJLE9BQU87QUFDaEQ7QUFDQSxTQUFTLGtCQUFrQixTQUFTLFlBQVk7Q0FDOUMsT0FBTyxXQUFXLEtBQUksY0FBYSxVQUFVLE9BQU8sQ0FBQztBQUN2RDtBQUNBLFNBQVMsY0FBYyxXQUFXO0NBQ2hDLE9BQU8sQ0FBQyxVQUFVO0FBQ3BCO0FBQ0EsU0FBUyxvQkFBb0IsWUFBWTtDQUN2QyxPQUFPLFdBQVcsS0FBSSxjQUFhO0VBQ2pDLE9BQU8sY0FBYyxTQUFTLElBQUksYUFBWSxNQUFLLFVBQVUsU0FBUyxDQUFDO0NBQ3pFLENBQUM7QUFDSDtBQUNBLFNBQVMsUUFBUSxZQUFZO0NBQzNCLElBQUksQ0FBQyxZQUFZLE9BQU87Q0FDeEIsTUFBTSxvQkFBb0IsV0FBVyxPQUFPLFNBQVM7Q0FDckQsSUFBSSxrQkFBa0IsVUFBVSxHQUFHLE9BQU87Q0FDMUMsT0FBTyxTQUFVLFNBQVM7RUFDeEIsT0FBTyxZQUFZLGtCQUFrQixTQUFTLGlCQUFpQixDQUFDO0NBQ2xFO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixZQUFZO0NBQ3JDLE9BQU8sY0FBYyxPQUFPLFFBQVEsb0JBQW9CLFVBQVUsQ0FBQyxJQUFJO0FBQ3pFO0FBQ0EsU0FBUyxhQUFhLFlBQVk7Q0FDaEMsSUFBSSxDQUFDLFlBQVksT0FBTztDQUN4QixNQUFNLG9CQUFvQixXQUFXLE9BQU8sU0FBUztDQUNyRCxJQUFJLGtCQUFrQixVQUFVLEdBQUcsT0FBTztDQUMxQyxPQUFPLFNBQVUsU0FBUztFQUV4QixPQUFPLFNBRGEsa0JBQWtCLFNBQVMsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLFlBQzVDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxXQUFXLENBQUM7Q0FDcEQ7QUFDRjtBQUNBLFNBQVMsdUJBQXVCLFlBQVk7Q0FDMUMsT0FBTyxjQUFjLE9BQU8sYUFBYSxvQkFBb0IsVUFBVSxDQUFDLElBQUk7QUFDOUU7QUFDQSxTQUFTLGdCQUFnQixtQkFBbUIsY0FBYztDQUN4RCxJQUFJLHNCQUFzQixNQUFNLE9BQU8sQ0FBQyxZQUFZO0NBQ3BELE9BQU8sTUFBTSxRQUFRLGlCQUFpQixJQUFJLENBQUMsR0FBRyxtQkFBbUIsWUFBWSxJQUFJLENBQUMsbUJBQW1CLFlBQVk7QUFDbkg7QUFDQSxTQUFTLHFCQUFxQixTQUFTO0NBQ3JDLE9BQU8sUUFBUTtBQUNqQjtBQUNBLFNBQVMsMEJBQTBCLFNBQVM7Q0FDMUMsT0FBTyxRQUFRO0FBQ2pCO0FBQ0EsU0FBUyxvQkFBb0IsWUFBWTtDQUN2QyxJQUFJLENBQUMsWUFBWSxPQUFPLENBQUM7Q0FDekIsT0FBTyxNQUFNLFFBQVEsVUFBVSxJQUFJLGFBQWEsQ0FBQyxVQUFVO0FBQzdEO0FBQ0EsU0FBUyxhQUFhLFlBQVksV0FBVztDQUMzQyxPQUFPLE1BQU0sUUFBUSxVQUFVLElBQUksV0FBVyxTQUFTLFNBQVMsSUFBSSxlQUFlO0FBQ3JGO0FBQ0EsU0FBUyxjQUFjLFlBQVksbUJBQW1CO0NBQ3BELE1BQU0sVUFBVSxvQkFBb0IsaUJBQWlCO0NBRXJELG9CQUQ0QyxVQUM5QixDQUFDLENBQUMsU0FBUSxNQUFLO0VBQzNCLElBQUksQ0FBQyxhQUFhLFNBQVMsQ0FBQyxHQUMxQixRQUFRLEtBQUssQ0FBQztDQUVsQixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsWUFBWSxtQkFBbUI7Q0FDdkQsT0FBTyxvQkFBb0IsaUJBQWlCLENBQUMsQ0FBQyxRQUFPLE1BQUssQ0FBQyxhQUFhLFlBQVksQ0FBQyxDQUFDO0FBQ3hGO0FBQ0EsSUFBTSwyQkFBTixNQUErQjs7d0JBOEM3Qix3QkFBQSxLQUFBLENBQUE7d0JBQ0EsNkJBQUEsS0FBQSxDQUFBO3dCQUNBLGtCQUFpQixDQUFDLENBQUE7d0JBQ2xCLHVCQUFzQixDQUFDLENBQUE7d0JBZXZCLHVCQUFzQixDQUFDLENBQUE7O0NBL0R2QixJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsUUFBUTtDQUM3QztDQUNBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxVQUFVLEtBQUssUUFBUSxRQUFRO0NBQzdDO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLFVBQVU7Q0FDL0M7Q0FDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsVUFBVTtDQUMvQztDQUNBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSyxVQUFVLEtBQUssUUFBUSxXQUFXO0NBQ2hEO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLFVBQVU7Q0FDL0M7Q0FDQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsU0FBUztDQUM5QztDQUNBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSyxVQUFVLEtBQUssUUFBUSxXQUFXO0NBQ2hEO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLFFBQVE7Q0FDN0M7Q0FDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsVUFBVTtDQUMvQztDQUNBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxVQUFVLEtBQUssUUFBUSxTQUFTO0NBQzlDO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLFlBQVk7Q0FDakQ7Q0FDQSxJQUFJLGdCQUFnQjtFQUNsQixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsZ0JBQWdCO0NBQ3JEO0NBQ0EsSUFBSSxlQUFlO0VBQ2pCLE9BQU8sS0FBSyxVQUFVLEtBQUssUUFBUSxlQUFlO0NBQ3BEO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsT0FBTztDQUNUO0NBS0EsZUFBZSxZQUFZO0VBQ3pCLEtBQUssaUJBQWlCLGNBQWMsQ0FBQztFQUNyQyxLQUFLLHVCQUF1QixrQkFBa0IsS0FBSyxjQUFjO0NBQ25FO0NBQ0Esb0JBQW9CLFlBQVk7RUFDOUIsS0FBSyxzQkFBc0IsY0FBYyxDQUFDO0VBQzFDLEtBQUssNEJBQTRCLHVCQUF1QixLQUFLLG1CQUFtQjtDQUNsRjtDQUNBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyx3QkFBd0I7Q0FDdEM7Q0FDQSxJQUFJLGlCQUFpQjtFQUNuQixPQUFPLEtBQUssNkJBQTZCO0NBQzNDO0NBRUEsbUJBQW1CLElBQUk7RUFDckIsS0FBSyxvQkFBb0IsS0FBSyxFQUFFO0NBQ2xDO0NBQ0EsNEJBQTRCO0VBQzFCLEtBQUssb0JBQW9CLFNBQVEsT0FBTSxHQUFHLENBQUM7RUFDM0MsS0FBSyxzQkFBc0IsQ0FBQztDQUM5QjtDQUNBLE1BQU0sUUFBUSxLQUFBLEdBQVc7O0VBQ3ZCLENBQUEsZ0JBQUEsS0FBSyxhQUFBLFFBQUEsa0JBQUEsS0FBQSxLQUFBLGNBQVMsTUFBTSxLQUFLO0NBQzNCO0NBQ0EsU0FBUyxXQUFXLE1BQU07RUFDeEIsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLFNBQVMsV0FBVyxJQUFJLElBQUk7Q0FDakU7Q0FDQSxTQUFTLFdBQVcsTUFBTTtFQUN4QixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsU0FBUyxXQUFXLElBQUksSUFBSTtDQUNqRTtBQUNGO0FBQ0EsSUFBTSxtQkFBTixjQUErQix5QkFBeUI7Ozt3QkFDdEQsUUFBQSxLQUFBLENBQUE7O0NBQ0EsSUFBSSxnQkFBZ0I7RUFDbEIsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsT0FBTztDQUNUO0FBQ0Y7QUFDQSxJQUFNLHlCQUF5Qjs7Ozs7Ozs7OztBQVUvQixJQUFNLHVCQUF1Qjs7Ozs7Ozs7Ozs7O0FBWTdCLElBQU0sdUJBQXVCOzs7Ozs7Ozs7Ozs7Ozs7QUFlN0IsSUFBTSxzQkFBc0I7Ozs7OztBQU01QixJQUFNLDhCQUE4Qjs7Ozs7O0FBTXBDLElBQU0sMEJBQXlCLElBQUksUUFBUSxRQUFRO0FBQ25ELFNBQVMsdUJBQXVCLGFBQWE7Q0FDM0MsT0FBTyxJQUFJQSxhQUFjLE1BQU07OztRQUd6QixvQkFBb0IsV0FBVyxFQUFFOzs7O01BSW5DLHdCQUF3QjtBQUM5QjtBQUNBLFNBQVMsb0JBQW9CLGFBQWE7Q0FDeEMsSUFBSSxlQUFlLFFBQVEsZ0JBQWdCLElBQ3pDLE9BQU87Q0FHVCxPQUFPLHlCQURXLE9BQU8sZ0JBQWdCLFdBQVcsU0FBUyxRQUNuQixLQUFLLFlBQVk7QUFDN0Q7QUFDQSxTQUFTLHdCQUF3QjtDQUMvQixPQUFPLElBQUlBLGFBQWMsTUFBTTs7Ozs7UUFLekIscUJBQXFCOzs7O1FBSXJCLHFCQUFxQjtBQUM3QjtBQUNBLFNBQVMsdUJBQXVCO0NBQzlCLE9BQU8sSUFBSUEsYUFBYyxNQUFNOzs7O1FBSXpCLHdCQUF3QjtBQUNoQztBQUNBLFNBQVMsdUJBQXVCO0NBQzlCLE9BQU8sSUFBSUEsYUFBYyxNQUFNOzs7OztNQUszQixzQkFBc0I7QUFDNUI7QUFDQSxTQUFTLHVCQUF1QjtDQUM5QixPQUFPLElBQUlBLGFBQWMsTUFBTTs7Ozs7UUFLekIsc0JBQXNCO0FBQzlCO0FBQ0EsSUFBTSxzQkFBc0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQjVCLElBQU0sd0NBQXdDOzs7Ozs7Ozs7Ozs7Ozs7QUFlOUMsU0FBUyxlQUFlLGVBQWU7Q0FFckMsT0FBTztpRUFDd0QsY0FBYzs7Ozs7O1lBRnBELFFBQVEsVUFBVSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssR0FRN0Msd0JBQXdCLGtCQUFrQixnQkFBZ0IseUJBQXlCLGtCQUFrQjs7QUFFbEk7QUFDQSxTQUFTLFlBQVksYUFBYSxLQUFLO0NBQ3JDLE9BQU8sY0FBYyxlQUFlLElBQUksS0FBSyxhQUFhO0FBQzVEO0FBQ0EsU0FBUyxnQkFBZ0IsYUFBYTtDQUNwQyxPQUFPO3NEQUM2QyxjQUFjLFVBQVUsUUFBUTs7O0FBR3RGO0FBQ0EsU0FBUyxvQkFBb0IsYUFBYSxLQUFLO0NBQzdDLE9BQU8sNEJBQTRCLFlBQVksYUFBYSxHQUFHO0FBQ2pFO0FBQ0EsU0FBUyx5QkFBeUIsYUFBYSxLQUFLO0NBQ2xELE9BQU8sd0NBQXdDLFlBQVksYUFBYSxHQUFHO0FBQzdFO0FBQ0EsSUFBTSxRQUFRO0FBQ2QsSUFBTSxVQUFVO0FBQ2hCLElBQU0sVUFBVTtBQUNoQixJQUFNLFdBQVc7QUFDakIsSUFBTSxlQUFOLE1BQW1CLENBQUM7QUFDcEIsSUFBTSxtQkFBTixjQUErQixhQUFhO0NBRzFDLFlBQVksT0FBTyxRQUFRO0VBQ3pCLE1BQU07d0JBSFIsU0FBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7RUFHRSxLQUFLLFFBQVE7RUFDYixLQUFLLFNBQVM7Q0FDaEI7QUFDRjtBQUNBLElBQU0sc0JBQU4sY0FBa0MsYUFBYTtDQUc3QyxZQUFZLFVBQVUsUUFBUTtFQUM1QixNQUFNO3dCQUhSLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUztDQUNoQjtBQUNGO0FBQ0EsSUFBTSxxQkFBTixjQUFpQyxhQUFhO0NBRzVDLFlBQVksU0FBUyxRQUFRO0VBQzNCLE1BQU07d0JBSFIsV0FBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7RUFHRSxLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVM7Q0FDaEI7QUFDRjtBQUNBLElBQU0sb0JBQU4sY0FBZ0MsYUFBYTtDQUczQyxZQUFZLFFBQVEsUUFBUTtFQUMxQixNQUFNO3dCQUhSLFVBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxTQUFTO0VBQ2QsS0FBSyxTQUFTO0NBQ2hCO0FBQ0Y7QUFDQSxJQUFNLHFCQUFOLGNBQWlDLGFBQWE7Q0FFNUMsWUFBWSxRQUFRO0VBQ2xCLE1BQU07d0JBRlIsVUFBQSxLQUFBLENBQUE7RUFHRSxLQUFLLFNBQVM7Q0FDaEI7QUFDRjtBQUNBLElBQU0saUJBQU4sY0FBNkIsYUFBYTtDQUV4QyxZQUFZLFFBQVE7RUFDbEIsTUFBTTt3QkFGUixVQUFBLEtBQUEsQ0FBQTtFQUdFLEtBQUssU0FBUztDQUNoQjtBQUNGO0FBQ0EsU0FBUyxlQUFlLGlCQUFpQjtDQUN2QyxRQUFRLGFBQWEsZUFBZSxJQUFJLGdCQUFnQixhQUFhLG9CQUFvQjtBQUMzRjtBQUNBLFNBQVMsa0JBQWtCLFdBQVc7Q0FDcEMsT0FBTyxNQUFNLFFBQVEsU0FBUyxJQUFJLGtCQUFrQixTQUFTLElBQUksYUFBYTtBQUNoRjtBQUNBLFNBQVMsb0JBQW9CLGdCQUFnQixpQkFBaUI7Q0FDNUQsSUFBSSxPQUFPLGNBQWMsZUFBZTtNQUNsQyxhQUFhLGVBQWUsS0FBSyxnQkFDbkMsUUFBUSxLQUFLLHFDQUFxQztDQUFBO0NBR3RELFFBQVEsYUFBYSxlQUFlLElBQUksZ0JBQWdCLGtCQUFrQixtQkFBbUI7QUFDL0Y7QUFDQSxTQUFTLHVCQUF1QixnQkFBZ0I7Q0FDOUMsT0FBTyxNQUFNLFFBQVEsY0FBYyxJQUFJLHVCQUF1QixjQUFjLElBQUksa0JBQWtCO0FBQ3BHO0FBQ0EsU0FBUyxhQUFhLGlCQUFpQjtDQUNyQyxPQUFPLG1CQUFtQixRQUFRLENBQUMsTUFBTSxRQUFRLGVBQWUsS0FBSyxPQUFPLG9CQUFvQjtBQUNsRztBQUNBLFNBQVMscUJBQXFCLFFBQVEsU0FBUyxLQUFLO0NBQ2xELE1BQU0sV0FBVyxPQUFPO0NBRXhCLElBQUksRUFEZSxVQUFVLE9BQU8sS0FBSyxRQUFRLElBQUksU0FBQSxDQUNyQyxRQUNkLE1BQU0sSUFBSUEsYUFBYyxLQUFNLE9BQU8sY0FBYyxlQUFlLFlBQVksZ0JBQWdCLE9BQU8sSUFBSSxFQUFFO0NBRTdHLElBQUksQ0FBQyxjQUFjLFVBQVUsR0FBRyxHQUM5QixNQUFNLElBQUlBLGFBQWMsTUFBTSxPQUFPLGNBQWMsZUFBZSxZQUFZLG9CQUFvQixTQUFTLEdBQUcsSUFBSSxFQUFFO0FBRXhIO0FBQ0EsU0FBUyx1QkFBdUIsU0FBUyxTQUFTLE9BQU87Q0FDdkQsUUFBUSxlQUFlLEdBQUcsUUFBUTtFQUNoQyxJQUFJLE1BQU0sU0FBUyxLQUFBLEdBQ2pCLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLFlBQVkseUJBQXlCLFNBQVMsR0FBRyxJQUFJLEVBQUU7Q0FFOUgsQ0FBQztBQUNIO0FBQ0EsSUFBTSxrQkFBTixNQUFzQjtDQWdCcEIsWUFBWSxZQUFZLGlCQUFpQjt3QkFmekMsaUJBQWdCLEtBQUE7d0JBQ2hCLGdDQUErQixJQUFBO3dCQUMvQixtQkFBa0IsS0FBQTt3QkFDbEIsNkJBQTRCLENBQUMsQ0FBQTt3QkFDN0IsYUFBQSxLQUFBLENBQUE7d0JBQ0EsZ0JBQWUsT0FBTyxPQUFPLEdBQUksWUFBWSxDQUFDLEVBQzVDLFdBQVcsZUFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1IsV0FBVSxJQUFBO3dCQUNWLGdDQUFBLEtBQUEsQ0FBQTt3QkFDQSx3QkFBQSxLQUFBLENBQUE7d0JBQ0EsNkJBQUEsS0FBQSxDQUFBO3dCQUNBLGtCQUFBLEtBQUEsQ0FBQTt3QkFDQSx1QkFBQSxLQUFBLENBQUE7d0JBQ0EsU0FBQSxLQUFBLENBQUE7d0JBMkJBLFdBQVUsZUFBZSxLQUFLLGVBQWUsR0FBRyxHQUFJLFlBQVksQ0FBQyxFQUMvRCxXQUFXLFVBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQUNSLGtCQUFpQixPQUFPLEtBQUEsR0FBVyxHQUFJLFlBQVksQ0FBQyxFQUNsRCxXQUFXLGlCQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFnQlIsVUFBQSxLQUFBLENBQUE7d0JBT0EsYUFBWSxlQUFlLEtBQUssaUJBQWlCLEdBQUcsR0FBSSxZQUFZLENBQUMsRUFDbkUsV0FBVyxZQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFDUixvQkFBbUIsT0FBTyxNQUFNLEdBQUksWUFBWSxDQUFDLEVBQy9DLFdBQVcsbUJBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQVVSLFlBQVcsZUFBZSxLQUFLLGdCQUFnQixHQUFHLEdBQUksWUFBWSxDQUFDLEVBQ2pFLFdBQVcsV0FDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1IsbUJBQWtCLE9BQU8sT0FBTyxHQUFJLFlBQVksQ0FBQyxFQUMvQyxXQUFXLGtCQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFJUixXQUFVLElBQUksUUFBUSxDQUFBO3dCQUN0QixVQUFTLEtBQUssUUFBUSxhQUFhLENBQUE7d0JBQ25DLGdCQUFBLEtBQUEsQ0FBQTt3QkFDQSxpQkFBQSxLQUFBLENBQUE7d0JBd1VBLHFCQUFvQixDQUFDLENBQUE7RUF4Wm5CLEtBQUssa0JBQWtCLFVBQVU7RUFDakMsS0FBSyx1QkFBdUIsZUFBZTtDQUM3QztDQUNBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxVQUFVLGFBQWE7RUFDekIsS0FBSyxpQkFBaUIsS0FBSyx1QkFBdUI7RUFDbEQsS0FBSyw0QkFBNEI7Q0FDbkM7Q0FDQSxJQUFJLGlCQUFpQjtFQUNuQixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksZUFBZSxrQkFBa0I7RUFDbkMsS0FBSyxzQkFBc0IsS0FBSyw0QkFBNEI7Q0FDOUQ7Q0FDQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksU0FBUztFQUNYLE9BQU8sVUFBVSxLQUFLLGNBQWM7Q0FDdEM7Q0FDQSxJQUFJLE9BQU8sR0FBRztFQUNaLGdCQUFnQixLQUFLLGVBQWUsSUFBSSxDQUFDLENBQUM7Q0FDNUM7Q0FPQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssV0FBVztDQUN6QjtDQUNBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxXQUFXO0NBQ3pCO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLLFdBQVc7Q0FDekI7Q0FDQSxJQUFJLFdBQVc7RUFDYixPQUFPLEtBQUssV0FBVztDQUN6QjtDQUNBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxXQUFXO0NBQ3pCO0NBRUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyxVQUFVLEtBQUssZ0JBQWdCO0NBQ3hDO0NBQ0EsSUFBSSxTQUFTLEdBQUc7RUFDZCxnQkFBZ0IsS0FBSyxpQkFBaUIsSUFBSSxDQUFDLENBQUM7Q0FDOUM7Q0FPQSxJQUFJLFFBQVE7RUFDVixPQUFPLENBQUMsS0FBSztDQUNmO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxVQUFVLEtBQUssZUFBZTtDQUN2QztDQUNBLElBQUksUUFBUSxHQUFHO0VBQ2IsZ0JBQWdCLEtBQUssZ0JBQWdCLElBQUksQ0FBQyxDQUFDO0NBQzdDO0NBT0EsSUFBSSxZQUFZO0VBQ2QsT0FBTyxDQUFDLEtBQUs7Q0FDZjtDQUtBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSyxZQUFZLEtBQUssWUFBWSxLQUFLLFNBQVMsS0FBSyxPQUFPLFdBQVc7Q0FDaEY7Q0FDQSxjQUFjLFlBQVk7RUFDeEIsS0FBSyxrQkFBa0IsVUFBVTtDQUNuQztDQUNBLG1CQUFtQixZQUFZO0VBQzdCLEtBQUssdUJBQXVCLFVBQVU7Q0FDeEM7Q0FDQSxjQUFjLFlBQVk7RUFDeEIsS0FBSyxjQUFjLGNBQWMsWUFBWSxLQUFLLGNBQWMsQ0FBQztDQUNuRTtDQUNBLG1CQUFtQixZQUFZO0VBQzdCLEtBQUssbUJBQW1CLGNBQWMsWUFBWSxLQUFLLG1CQUFtQixDQUFDO0NBQzdFO0NBQ0EsaUJBQWlCLFlBQVk7RUFDM0IsS0FBSyxjQUFjLGlCQUFpQixZQUFZLEtBQUssY0FBYyxDQUFDO0NBQ3RFO0NBQ0Esc0JBQXNCLFlBQVk7RUFDaEMsS0FBSyxtQkFBbUIsaUJBQWlCLFlBQVksS0FBSyxtQkFBbUIsQ0FBQztDQUNoRjtDQUNBLGFBQWEsV0FBVztFQUN0QixPQUFPLGFBQWEsS0FBSyxnQkFBZ0IsU0FBUztDQUNwRDtDQUNBLGtCQUFrQixXQUFXO0VBQzNCLE9BQU8sYUFBYSxLQUFLLHFCQUFxQixTQUFTO0NBQ3pEO0NBQ0Esa0JBQWtCO0VBQ2hCLEtBQUssWUFBWTtDQUNuQjtDQUNBLHVCQUF1QjtFQUNyQixLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLGNBQWMsT0FBTyxDQUFDLEdBQUc7O0VBQ3ZCLE1BQU0sVUFBVSxLQUFLLFlBQVk7RUFDakMsS0FBSyxVQUFVO0VBQ2YsTUFBTSxpQkFBQSxzQkFBZ0IsS0FBSyxtQkFBQSxRQUFBLHdCQUFBLEtBQUEsSUFBQSxzQkFBaUI7RUFDNUMsSUFBSSxDQUFDLEtBQUssVUFBVTs7R0FDbEIsQ0FBQSxnQkFBQSxLQUFLLGFBQUEsUUFBQSxrQkFBQSxLQUFBLEtBQUEsY0FBUyxjQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ1QsSUFBQSxHQUFBLENBQUEsR0FBQSxFQUNILGNBQUEsQ0FDRixDQUFDO0VBQ0g7RUFDQSxJQUFJLFdBQVcsS0FBSyxjQUFjLE9BQ2hDLEtBQUssUUFBUSxLQUFLLElBQUksbUJBQW1CLE1BQU0sYUFBYSxDQUFDO0NBRWpFO0NBQ0EsZUFBZSxPQUFPLENBQUMsR0FBRztFQUN4QixLQUFLLFlBQVk7R0FDZixVQUFVO0dBQ1YsV0FBVyxLQUFLO0dBQ2hCLGVBQWU7RUFDakIsQ0FBQztFQUNELEtBQUssZUFBYyxZQUFXLFFBQVEsZUFBZSxJQUFJLENBQUM7Q0FDNUQ7Q0FDQSxpQkFBaUIsT0FBTyxDQUFDLEdBQUc7RUFDMUIsS0FBSyxjQUFjO0dBQ2pCLFVBQVU7R0FDVixXQUFXLEtBQUs7R0FDaEIsZUFBZTtFQUNqQixDQUFDO0VBQ0QsS0FBSyxlQUFjLFlBQVcsUUFBUSxpQkFBaUIsSUFBSSxDQUFDO0NBQzlEO0NBQ0EsZ0JBQWdCLE9BQU8sQ0FBQyxHQUFHOztFQUN6QixNQUFNLFVBQVUsS0FBSyxZQUFZO0VBQ2pDLEtBQUssVUFBVTtFQUNmLEtBQUssa0JBQWtCO0VBQ3ZCLE1BQU0saUJBQUEsdUJBQWdCLEtBQUssbUJBQUEsUUFBQSx5QkFBQSxLQUFBLElBQUEsdUJBQWlCO0VBQzVDLEtBQUssZUFBYyxZQUFXO0dBQzVCLFFBQVEsZ0JBQWdCO0lBQ3RCLFVBQVU7SUFDVixXQUFXLEtBQUs7SUFDaEI7R0FDRixDQUFDO0VBQ0gsQ0FBQztFQUNELElBQUksQ0FBQyxLQUFLLFVBQVU7O0dBQ2xCLENBQUEsaUJBQUEsS0FBSyxhQUFBLFFBQUEsbUJBQUEsS0FBQSxLQUFBLGVBQVMsZUFBZSxNQUFNLGFBQWE7RUFDbEQ7RUFDQSxJQUFJLFdBQVcsS0FBSyxjQUFjLE9BQ2hDLEtBQUssUUFBUSxLQUFLLElBQUksbUJBQW1CLE9BQU8sYUFBYSxDQUFDO0NBRWxFO0NBQ0EsWUFBWSxPQUFPLENBQUMsR0FBRzs7RUFDckIsTUFBTSxVQUFVLEtBQUssYUFBYTtFQUNsQyxLQUFLLFdBQVc7RUFDaEIsTUFBTSxpQkFBQSx1QkFBZ0IsS0FBSyxtQkFBQSxRQUFBLHlCQUFBLEtBQUEsSUFBQSx1QkFBaUI7RUFDNUMsSUFBSSxDQUFDLEtBQUssVUFBVTs7R0FDbEIsQ0FBQSxpQkFBQSxLQUFLLGFBQUEsUUFBQSxtQkFBQSxLQUFBLEtBQUEsZUFBUyxZQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ1QsSUFBQSxHQUFBLENBQUEsR0FBQSxFQUNILGNBQUEsQ0FDRixDQUFDO0VBQ0g7RUFDQSxJQUFJLFdBQVcsS0FBSyxjQUFjLE9BQ2hDLEtBQUssUUFBUSxLQUFLLElBQUksb0JBQW9CLE9BQU8sYUFBYSxDQUFDO0NBRW5FO0NBQ0EsZUFBZSxPQUFPLENBQUMsR0FBRzs7RUFDeEIsTUFBTSxVQUFVLEtBQUssYUFBYTtFQUNsQyxLQUFLLFdBQVc7RUFDaEIsS0FBSyxnQkFBZ0I7RUFDckIsTUFBTSxpQkFBQSx1QkFBZ0IsS0FBSyxtQkFBQSxRQUFBLHlCQUFBLEtBQUEsSUFBQSx1QkFBaUI7RUFDNUMsS0FBSyxlQUFjLFlBQVc7R0FDNUIsUUFBUSxlQUFlO0lBQ3JCLFVBQVU7SUFDVixXQUFXLEtBQUs7R0FDbEIsQ0FBQztFQUNILENBQUM7RUFDRCxJQUFJLENBQUMsS0FBSyxVQUFVOztHQUNsQixDQUFBLGlCQUFBLEtBQUssYUFBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFTLGdCQUFnQixNQUFNLGFBQWE7RUFDbkQ7RUFDQSxJQUFJLFdBQVcsS0FBSyxjQUFjLE9BQ2hDLEtBQUssUUFBUSxLQUFLLElBQUksb0JBQW9CLE1BQU0sYUFBYSxDQUFDO0NBRWxFO0NBQ0EsY0FBYyxPQUFPLENBQUMsR0FBRzs7RUFDdkIsS0FBSyxTQUFTO0VBQ2QsTUFBTSxpQkFBQSx1QkFBZ0IsS0FBSyxtQkFBQSxRQUFBLHlCQUFBLEtBQUEsSUFBQSx1QkFBaUI7RUFDNUMsSUFBSSxLQUFLLGNBQWMsT0FBTztHQUM1QixLQUFLLFFBQVEsS0FBSyxJQUFJLGtCQUFrQixLQUFLLFFBQVEsYUFBYSxDQUFDO0dBQ25FLEtBQUssY0FBYyxLQUFLLEtBQUssTUFBTTtFQUNyQztFQUNBLElBQUksQ0FBQyxLQUFLLFVBQVU7O0dBQ2xCLENBQUEsaUJBQUEsS0FBSyxhQUFBLFFBQUEsbUJBQUEsS0FBQSxLQUFBLGVBQVMsY0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNULElBQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCxjQUFBLENBQ0YsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxRQUFRLE9BQU8sQ0FBQyxHQUFHOztFQUNqQixNQUFNLG9CQUFvQixLQUFLLG1CQUFtQixLQUFLLFFBQVE7RUFDL0QsS0FBSyxTQUFTO0VBQ2QsS0FBSyxTQUFTO0VBQ2QsS0FBSyxlQUFjLFlBQVc7R0FDNUIsUUFBUSxRQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0gsSUFBQSxHQUFBLENBQUEsR0FBQSxFQUNILFVBQVUsS0FBQSxDQUNaLENBQUM7RUFDSCxDQUFDO0VBQ0QsS0FBSyxhQUFhO0VBQ2xCLE1BQU0saUJBQUEsdUJBQWdCLEtBQUssbUJBQUEsUUFBQSx5QkFBQSxLQUFBLElBQUEsdUJBQWlCO0VBQzVDLElBQUksS0FBSyxjQUFjLE9BQU87R0FDNUIsS0FBSyxRQUFRLEtBQUssSUFBSSxpQkFBaUIsS0FBSyxPQUFPLGFBQWEsQ0FBQztHQUNqRSxLQUFLLFFBQVEsS0FBSyxJQUFJLGtCQUFrQixLQUFLLFFBQVEsYUFBYSxDQUFDO0dBQ25FLEtBQUssYUFBYSxLQUFLLEtBQUssS0FBSztHQUNqQyxLQUFLLGNBQWMsS0FBSyxLQUFLLE1BQU07RUFDckM7RUFDQSxLQUFLLGlCQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0EsSUFBQSxHQUFBLENBQUEsR0FBQSxFQUNILGtCQUFBLENBQ0YsR0FBRyxJQUFJO0VBQ1AsS0FBSyxrQkFBa0IsU0FBUSxhQUFZLFNBQVMsSUFBSSxDQUFDO0NBQzNEO0NBQ0EsT0FBTyxPQUFPLENBQUMsR0FBRztFQUNoQixNQUFNLG9CQUFvQixLQUFLLG1CQUFtQixLQUFLLFFBQVE7RUFDL0QsS0FBSyxTQUFTO0VBQ2QsS0FBSyxlQUFjLFlBQVc7R0FDNUIsUUFBUSxPQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0gsSUFBQSxHQUFBLENBQUEsR0FBQSxFQUNILFVBQVUsS0FBQSxDQUNaLENBQUM7RUFDSCxDQUFDO0VBQ0QsS0FBSyx1QkFBdUI7R0FDMUIsVUFBVTtHQUNWLFdBQVcsS0FBSztFQUNsQixDQUFDO0VBQ0QsS0FBSyxpQkFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNBLElBQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCxrQkFBQSxDQUNGLEdBQUcsSUFBSTtFQUNQLEtBQUssa0JBQWtCLFNBQVEsYUFBWSxTQUFTLEtBQUssQ0FBQztDQUM1RDtDQUNBLGlCQUFpQixNQUFNLGVBQWU7RUFDcEMsSUFBSSxDQUFDLEtBQUssVUFBVTs7R0FDbEIsQ0FBQSxpQkFBQSxLQUFLLGFBQUEsUUFBQSxtQkFBQSxLQUFBLEtBQUEsZUFBUyx1QkFBdUIsSUFBSTtHQUN6QyxJQUFJLENBQUMsS0FBSyxtQkFBbUI7O0lBQzNCLENBQUEsaUJBQUEsS0FBSyxhQUFBLFFBQUEsbUJBQUEsS0FBQSxLQUFBLGVBQVMsZ0JBQWdCLENBQUMsR0FBRyxhQUFhO0dBQ2pEO0dBQ0EsQ0FBQSxpQkFBQSxLQUFLLGFBQUEsUUFBQSxtQkFBQSxLQUFBLEtBQUEsZUFBUyxlQUFlLENBQUMsR0FBRyxhQUFhO0VBQ2hEO0NBQ0Y7Q0FDQSxVQUFVLFFBQVE7RUFDaEIsS0FBSyxVQUFVO0NBQ2pCO0NBQ0EsY0FBYztFQUNaLE9BQU8sS0FBSztDQUNkO0NBQ0EsdUJBQXVCLE9BQU8sQ0FBQyxHQUFHOztFQUNoQyxLQUFLLGtCQUFrQjtFQUN2QixLQUFLLGFBQWE7RUFDbEIsSUFBSSxLQUFLLFNBQVM7R0FDaEIsTUFBTSxvQkFBb0IsS0FBSyw0QkFBNEI7R0FDM0QsS0FBSyxTQUFTLEtBQUssY0FBYztHQUNqQyxLQUFLLFNBQVMsS0FBSyxpQkFBaUI7R0FDcEMsSUFBSSxLQUFLLFdBQVcsU0FBUyxLQUFLLFdBQVcsU0FDM0MsS0FBSyxtQkFBbUIsbUJBQW1CLEtBQUssU0FBUztFQUU3RDtFQUNBLE1BQU0saUJBQUEsdUJBQWdCLEtBQUssbUJBQUEsUUFBQSx5QkFBQSxLQUFBLElBQUEsdUJBQWlCO0VBQzVDLElBQUksS0FBSyxjQUFjLE9BQU87R0FDNUIsS0FBSyxRQUFRLEtBQUssSUFBSSxpQkFBaUIsS0FBSyxPQUFPLGFBQWEsQ0FBQztHQUNqRSxLQUFLLFFBQVEsS0FBSyxJQUFJLGtCQUFrQixLQUFLLFFBQVEsYUFBYSxDQUFDO0dBQ25FLEtBQUssYUFBYSxLQUFLLEtBQUssS0FBSztHQUNqQyxLQUFLLGNBQWMsS0FBSyxLQUFLLE1BQU07RUFDckM7RUFDQSxJQUFJLENBQUMsS0FBSyxVQUFVOztHQUNsQixDQUFBLGlCQUFBLEtBQUssYUFBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFTLHVCQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ1QsSUFBQSxHQUFBLENBQUEsR0FBQSxFQUNILGNBQUEsQ0FDRixDQUFDO0VBQ0g7Q0FDRjtDQUNBLG9CQUFvQixPQUFPLEVBQ3pCLFdBQVcsS0FDYixHQUFHO0VBQ0QsS0FBSyxlQUFjLFNBQVEsS0FBSyxvQkFBb0IsSUFBSSxDQUFDO0VBQ3pELEtBQUssdUJBQXVCO0dBQzFCLFVBQVU7R0FDVixXQUFXLEtBQUs7RUFDbEIsQ0FBQztDQUNIO0NBQ0Esb0JBQW9CO0VBQ2xCLEtBQUssU0FBUyxLQUFLLHFCQUFxQixJQUFJLFdBQVc7Q0FDekQ7Q0FDQSxnQkFBZ0I7RUFDZCxPQUFPLEtBQUssWUFBWSxLQUFLLFVBQVUsSUFBSSxJQUFJO0NBQ2pEO0NBQ0EsbUJBQW1CLG1CQUFtQixXQUFXO0VBQy9DLElBQUksS0FBSyxnQkFBZ0I7R0FDdkIsS0FBSyxTQUFTO0dBQ2QsS0FBSywrQkFBK0I7SUFDbEMsV0FBVyxjQUFjO0lBQ3pCLG1CQUFtQixzQkFBc0I7R0FDM0M7R0FDQSxNQUFNLE1BQU0sYUFBYSxLQUFLLGVBQWUsSUFBSSxDQUFDO0dBQ2xELEtBQUssK0JBQStCLElBQUksV0FBVSxXQUFVO0lBQzFELEtBQUssK0JBQStCO0lBQ3BDLEtBQUssVUFBVSxRQUFRO0tBQ3JCO0tBQ0E7SUFDRixDQUFDO0dBQ0gsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSw4QkFBOEI7RUFDNUIsSUFBSSxLQUFLLDhCQUE4Qjs7R0FDckMsS0FBSyw2QkFBNkIsWUFBWTtHQUM5QyxNQUFNLHFCQUFBLFNBQUEsd0JBQXFCLEtBQUssa0NBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUE4QixnQkFBQSx5QkFBYSxLQUFLLGtDQUFBLFFBQUEsMkJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSx1QkFBOEIsd0JBQUEsUUFBQSxTQUFBLEtBQUEsSUFBQSxPQUFzQjtHQUNwSSxLQUFLLCtCQUErQjtHQUNwQyxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxVQUFVLFFBQVEsT0FBTyxDQUFDLEdBQUc7RUFDM0IsS0FBSyxTQUFTO0VBQ2QsS0FBSyxzQkFBc0IsS0FBSyxjQUFjLE9BQU8sTUFBTSxLQUFLLGlCQUFpQjtDQUNuRjtDQUNBLElBQUksTUFBTTtFQUNSLElBQUksV0FBVztFQUNmLElBQUksWUFBWSxNQUFNLE9BQU87RUFDN0IsSUFBSSxDQUFDLE1BQU0sUUFBUSxRQUFRLEdBQUcsV0FBVyxTQUFTLE1BQU0sR0FBRztFQUMzRCxJQUFJLFNBQVMsV0FBVyxHQUFHLE9BQU87RUFDbEMsT0FBTyxTQUFTLFFBQVEsU0FBUyxTQUFTLFdBQVcsUUFBUSxNQUFNLElBQUksR0FBRyxJQUFJO0NBQ2hGO0NBQ0EsU0FBUyxXQUFXLE1BQU07RUFDeEIsTUFBTSxVQUFVLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSTtFQUN4QyxRQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxLQUFBLElBQU8sUUFBUyxVQUFTLFFBQVEsT0FBTyxhQUFhO0NBQ3ZEO0NBQ0EsU0FBUyxXQUFXLE1BQU07RUFDeEIsT0FBTyxDQUFDLENBQUMsS0FBSyxTQUFTLFdBQVcsSUFBSTtDQUN4QztDQUNBLElBQUksT0FBTztFQUNULElBQUksSUFBSTtFQUNSLE9BQU8sRUFBRSxTQUNQLElBQUksRUFBRTtFQUVSLE9BQU87Q0FDVDtDQUNBLHNCQUFzQixXQUFXLGdCQUFnQixtQkFBbUI7RUFDbEUsS0FBSyxTQUFTLEtBQUssaUJBQWlCO0VBQ3BDLElBQUksV0FDRixLQUFLLGNBQWMsS0FBSyxLQUFLLE1BQU07RUFFckMsSUFBSSxhQUFhLG1CQUNmLEtBQUssUUFBUSxLQUFLLElBQUksa0JBQWtCLEtBQUssUUFBUSxjQUFjLENBQUM7RUFFdEUsSUFBSSxLQUFLLFNBQ1AsS0FBSyxRQUFRLHNCQUFzQixXQUFXLGdCQUFnQixpQkFBaUI7Q0FFbkY7Q0FDQSxtQkFBbUI7RUFDakIsS0FBSyxlQUFlLElBQUksYUFBYTtFQUNyQyxLQUFLLGdCQUFnQixJQUFJLGFBQWE7Q0FDeEM7Q0FDQSxtQkFBbUI7RUFDakIsSUFBSSxLQUFLLHFCQUFxQixHQUFHLE9BQU87RUFDeEMsSUFBSSxLQUFLLFFBQVEsT0FBTztFQUN4QixJQUFJLEtBQUssZ0NBQWdDLEtBQUssdUJBQXVCLE9BQU8sR0FBRyxPQUFPO0VBQ3RGLElBQUksS0FBSyx1QkFBdUIsT0FBTyxHQUFHLE9BQU87RUFDakQsT0FBTztDQUNUO0NBQ0EsdUJBQXVCLFFBQVE7RUFDN0IsT0FBTyxLQUFLLGNBQWEsWUFBVyxRQUFRLFdBQVcsTUFBTTtDQUMvRDtDQUNBLG9CQUFvQjtFQUNsQixPQUFPLEtBQUssY0FBYSxZQUFXLFFBQVEsS0FBSztDQUNuRDtDQUNBLHNCQUFzQjtFQUNwQixPQUFPLEtBQUssY0FBYSxZQUFXLFFBQVEsT0FBTztDQUNyRDtDQUNBLGdCQUFnQixNQUFNLGdCQUFnQjtFQUNwQyxNQUFNLGNBQWMsQ0FBQyxLQUFLLGtCQUFrQjtFQUM1QyxNQUFNLFVBQVUsS0FBSyxhQUFhO0VBQ2xDLEtBQUssV0FBVztFQUNoQixJQUFJLENBQUMsS0FBSyxVQUFVOztHQUNsQixDQUFBLGtCQUFBLEtBQUssYUFBQSxRQUFBLG9CQUFBLEtBQUEsS0FBQSxnQkFBUyxnQkFBZ0IsTUFBTSxjQUFjO0VBQ3BEO0VBQ0EsSUFBSSxTQUNGLEtBQUssUUFBUSxLQUFLLElBQUksb0JBQW9CLEtBQUssVUFBVSxjQUFjLENBQUM7Q0FFNUU7Q0FDQSxlQUFlLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQjtFQUN4QyxLQUFLLFVBQVUsS0FBSyxvQkFBb0I7RUFDeEMsS0FBSyxRQUFRLEtBQUssSUFBSSxtQkFBbUIsS0FBSyxTQUFTLGNBQWMsQ0FBQztFQUN0RSxJQUFJLENBQUMsS0FBSyxVQUFVOztHQUNsQixDQUFBLGtCQUFBLEtBQUssYUFBQSxRQUFBLG9CQUFBLEtBQUEsS0FBQSxnQkFBUyxlQUFlLE1BQU0sY0FBYztFQUNuRDtDQUNGO0NBRUEsNEJBQTRCLElBQUk7RUFDOUIsS0FBSyxzQkFBc0I7Q0FDN0I7Q0FDQSxtQkFBbUIsTUFBTTtFQUN2QixJQUFJLGFBQWEsSUFBSSxLQUFLLEtBQUssWUFBWSxNQUN6QyxLQUFLLFlBQVksS0FBSztDQUUxQjtDQUNBLG1CQUFtQixVQUFVOztFQUMzQixPQUFPLENBQUMsWUFBWSxDQUFDLEdBQUEsa0JBQUMsS0FBSyxhQUFBLFFBQUEsb0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxnQkFBUyxVQUFTLENBQUMsS0FBSyxRQUFRLGtCQUFrQjtDQUMvRTtDQUNBLE1BQU0sTUFBTTtFQUNWLE9BQU87Q0FDVDtDQUNBLGtCQUFrQixZQUFZO0VBQzVCLEtBQUssaUJBQWlCLE1BQU0sUUFBUSxVQUFVLElBQUksV0FBVyxNQUFNLElBQUk7RUFDdkUsS0FBSyx1QkFBdUIsa0JBQWtCLEtBQUssY0FBYztFQUNqRSxLQUFLLDRCQUE0QjtDQUNuQztDQUNBLHVCQUF1QixZQUFZO0VBQ2pDLEtBQUssc0JBQXNCLE1BQU0sUUFBUSxVQUFVLElBQUksV0FBVyxNQUFNLElBQUk7RUFDNUUsS0FBSyw0QkFBNEIsdUJBQXVCLEtBQUssbUJBQW1CO0NBQ2xGO0NBQ0EsOEJBQThCO0VBQzVCLGdCQUFnQixLQUFLLGFBQWEsSUFBSSxLQUFLLGFBQWEsV0FBVyxRQUFRLENBQUMsQ0FBQztDQUMvRTtBQUNGO0FBQ0EsU0FBUyxjQUFjLFVBQVUsTUFBTTtDQUNyQyxPQUFPLE9BQU8sT0FBTyxVQUFVLElBQUk7QUFDckM7QUFDQSxTQUFTLG9CQUFvQixTQUFTO0NBQ3BDLE9BQU8sUUFBUSxZQUFZLFdBQVcsUUFBUSxZQUFZLFlBQVksUUFBUSxZQUFZO0FBQzVGO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxJQUFJLFFBQVEsWUFBWSxTQUN0QixPQUFPO0NBRVQsTUFBTSxPQUFPLFFBQVE7Q0FDckIsT0FBTyxTQUFTLFlBQVksU0FBUyxXQUFXLFNBQVMsVUFBVSxTQUFTO0FBQzlFO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxPQUFPLFFBQVEsWUFBWSxXQUFXLFFBQVEsWUFBWTtBQUM1RDtBQUNBLFNBQVMscUJBQXFCLFVBQVUsU0FBUyxNQUFNLE9BQU87Q0FDNUQsUUFBUSxNQUFSO0VBQ0UsS0FBSztHQUNILFNBQVMsYUFBYSxTQUFTLE1BQU0sS0FBSztHQUMxQztFQUNGLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztHQUNILElBQUksT0FDRixTQUFTLGFBQWEsU0FBUyxNQUFNLEVBQUU7UUFFdkMsU0FBUyxnQkFBZ0IsU0FBUyxJQUFJO0dBRXhDO0VBQ0YsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztHQUNILElBQUksVUFBVSxLQUFBLEdBQ1osU0FBUyxhQUFhLFNBQVMsTUFBTSxNQUFNLFNBQVMsQ0FBQztRQUVyRCxTQUFTLGdCQUFnQixTQUFTLElBQUk7R0FFeEM7Q0FDSjtBQUNGO0FBQ0EsSUFBTSwwQkFBTixNQUE4QjtDQUs1QixZQUFZLEVBQ1YsTUFDQSxTQUNBLFdBQ0M7d0JBUkgsUUFBQSxLQUFBLENBQUE7d0JBQ0EsV0FBQSxLQUFBLENBQUE7d0JBQ0EsV0FBQSxLQUFBLENBQUE7d0JBQ0EsV0FBQSxLQUFBLENBQUE7RUFNRSxLQUFLLE9BQU87RUFDWixLQUFLLFVBQVU7RUFDZixLQUFLLFVBQVU7Q0FDakI7QUFDRjtBQUNBLFNBQVMsVUFBVSxPQUFPO0NBQ3hCLE9BQU8sT0FBTyxVQUFVLFdBQVcsUUFBUSxTQUFTLE9BQU8sRUFBRTtBQUMvRDtBQUNBLFNBQVMsUUFBUSxPQUFPO0NBQ3RCLE9BQU8sT0FBTyxVQUFVLFdBQVcsUUFBUSxXQUFXLEtBQUs7QUFDN0Q7QUFDQSxJQUFNLDZCQUFOLE1BQWlDOzt3QkFDL0IsY0FBYSxhQUFBO3dCQUNiLGFBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBOztDQUNBLFlBQVksU0FBUztFQUNuQixJQUFJLEtBQUssYUFBYSxTQUFTOztHQUM3QixNQUFNLFFBQVEsS0FBSyxlQUFlLFFBQVEsS0FBSyxVQUFVLENBQUMsWUFBWTtHQUN0RSxLQUFLLFdBQVcsS0FBSyxRQUFRLEtBQUs7R0FDbEMsS0FBSyxhQUFhLEtBQUssV0FBVyxLQUFLLGdCQUFnQixLQUFLLElBQUk7R0FDaEUsQ0FBQSxrQkFBQSxLQUFLLGVBQUEsUUFBQSxvQkFBQSxLQUFBLEtBQUEsZ0JBQUEsS0FBQSxJQUFZO0VBQ25CO0NBQ0Y7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsT0FBTyxLQUFLLFdBQVcsT0FBTztDQUNoQztDQUNBLDBCQUEwQixJQUFJO0VBQzVCLEtBQUssWUFBWTtDQUNuQjtDQUNBLFFBQVEsT0FBTztFQUNiLE9BQU8sU0FBUztDQUNsQjtBQVFGOzs0Q0FQUyxRQUFPLFNBQVMsbUNBQW1DLG1CQUFtQjtDQUMzRSxPQUFPLEtBQUsscUJBQXFCQyw2QkFBNEI7QUFDL0QsQ0FBQTs0Q0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixVQUFVLENBQUNDLG9CQUF1QjtBQUNwQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1osaUJBQXFCLDRCQUE0QixDQUFDLEVBQ25HLE1BQU0sVUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sZ0JBQWdCO0NBQ3BCLFNBQVM7Q0FDVCxhQUFhLGlCQUFpQixZQUFZO0NBQzFDLE9BQU87QUFDVDtBQUNBLElBQU0sZUFBTixjQUEyQiwyQkFBMkI7Ozt3QkFDcEQsT0FBQSxLQUFBLENBQUE7d0JBQ0EsYUFBWSxLQUFBO3dCQUNaLG1CQUFpQixVQUFTLFFBQVEsS0FBSyxDQUFBO3dCQUN2QyxvQkFBa0IsUUFBTyxhQUFhLEdBQUcsQ0FBQTs7QUFzQjNDOzs4QkFyQlMsUUFBc0IsdUJBQU87Q0FDbEMsSUFBSTtDQUNKLE9BQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0VBQ3RELFFBQVEsOEJBQThCLDRCQUE0QkMsc0JBQXlCWSxhQUFZLEdBQUEsQ0FBSSxxQkFBcUJBLGFBQVk7Q0FDOUk7QUFDRixFQUFBLENBQUcsQ0FBQTs4QkFDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFTO0dBQVE7R0FBVTtHQUFPO0dBQUk7R0FBbUI7RUFBRTtFQUFHO0dBQUM7R0FBUztHQUFRO0dBQVU7R0FBTztHQUFJO0dBQWU7RUFBRTtFQUFHO0dBQUM7R0FBUztHQUFRO0dBQVU7R0FBTztHQUFJO0dBQVc7RUFBRTtDQUFDO0NBQzNMLFVBQVU7Q0FDVixjQUFjLFNBQVMsMEJBQTBCLElBQUksS0FBSztFQUN4RCxJQUFJLEtBQUssR0FDUCxZQUFlLE9BQU8sSUFBSSxXQUFXLElBQUksTUFBTSxJQUFJO0NBRXZEO0NBQ0EsUUFBUSxFQUNOLEtBQUssTUFDUDtDQUNBLFlBQVk7Q0FDWixVQUFVLENBQUNSLG1CQUFzQixDQUFDLGFBQWEsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDbEYsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUMsYUFBYTtHQUN6QixNQUFNLEVBQ0osY0FBYyx3QkFDaEI7R0FDQSxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLEVBQ1IsS0FBSyxDQUFDLEVBQ0osTUFBTSxNQUNSLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSxnQkFBZ0I7Q0FDcEIsU0FBUztDQUNULGFBQWEsaUJBQWlCLFlBQVk7Q0FDMUMsT0FBTztBQUNUO0FBQ0EsSUFBTSxlQUFOLGNBQTJCLDJCQUEyQjs7O3dCQUNwRCxPQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFZLEtBQUE7d0JBQ1osbUJBQWlCLFVBQVMsUUFBUSxLQUFLLENBQUE7d0JBQ3ZDLG9CQUFrQixRQUFPLGFBQWEsR0FBRyxDQUFBOztBQXNCM0M7OzhCQXJCUyxRQUFzQix1QkFBTztDQUNsQyxJQUFJO0NBQ0osT0FBTyxTQUFTLHFCQUFxQixtQkFBbUI7RUFDdEQsUUFBUSw4QkFBOEIsNEJBQTRCQyxzQkFBeUJhLGFBQVksR0FBQSxDQUFJLHFCQUFxQkEsYUFBWTtDQUM5STtBQUNGLEVBQUEsQ0FBRyxDQUFBOzhCQUNJLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVc7RUFBQztHQUFDO0dBQVM7R0FBUTtHQUFVO0dBQU87R0FBSTtHQUFtQjtFQUFFO0VBQUc7R0FBQztHQUFTO0dBQVE7R0FBVTtHQUFPO0dBQUk7R0FBZTtFQUFFO0VBQUc7R0FBQztHQUFTO0dBQVE7R0FBVTtHQUFPO0dBQUk7R0FBVztFQUFFO0NBQUM7Q0FDM0wsVUFBVTtDQUNWLGNBQWMsU0FBUywwQkFBMEIsSUFBSSxLQUFLO0VBQ3hELElBQUksS0FBSyxHQUNQLFlBQWUsT0FBTyxJQUFJLFdBQVcsSUFBSSxNQUFNLElBQUk7Q0FFdkQ7Q0FDQSxRQUFRLEVBQ04sS0FBSyxNQUNQO0NBQ0EsWUFBWTtDQUNaLFVBQVUsQ0FBQ1QsbUJBQXNCLENBQUMsYUFBYSxDQUFDLEdBQUdGLDBCQUE2QjtBQUNsRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLGNBQWMsQ0FBQztFQUNyRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLFdBQVcsQ0FBQyxhQUFhO0dBQ3pCLE1BQU0sRUFDSixjQUFjLHdCQUNoQjtHQUNBLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sRUFDUixLQUFLLENBQUMsRUFDSixNQUFNLE1BQ1IsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLHFCQUFxQjtDQUN6QixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsaUJBQWlCO0NBQy9DLE9BQU87QUFDVDtBQUNBLElBQU0sOEJBQThCO0NBQ2xDLFNBQVM7Q0FDVCxhQUFhLGlCQUFpQix5QkFBeUI7Q0FDdkQsT0FBTztBQUNUO0FBQ0EsSUFBTSxvQkFBTixjQUFnQywyQkFBMkI7Ozt3QkFDekQsWUFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBWSxVQUFBO3dCQUNaLGtCQUFpQixnQkFBQTt3QkFDakIsb0JBQWtCLFVBQVMsaUJBQUE7O0NBQzNCLFFBQVEsT0FBTztFQUNiLE9BQU87Q0FDVDtBQXNCRjs7bUNBckJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsMEJBQTBCLG1CQUFtQjtFQUMzRCxRQUFRLG1DQUFtQyxpQ0FBaUNDLHNCQUF5QmMsa0JBQWlCLEdBQUEsQ0FBSSxxQkFBcUJBLGtCQUFpQjtDQUNsSztBQUNGLEVBQUEsQ0FBRyxDQUFBO21DQUNJLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVc7RUFBQztHQUFDO0dBQUk7R0FBWTtHQUFJO0dBQW1CO0dBQUk7R0FBRztHQUFRO0VBQVU7RUFBRztHQUFDO0dBQUk7R0FBWTtHQUFJO0dBQWU7R0FBSTtHQUFHO0dBQVE7RUFBVTtFQUFHO0dBQUM7R0FBSTtHQUFZO0dBQUk7R0FBVztHQUFJO0dBQUc7R0FBUTtFQUFVO0NBQUM7Q0FDMU0sVUFBVTtDQUNWLGNBQWMsU0FBUywrQkFBK0IsSUFBSSxLQUFLO0VBQzdELElBQUksS0FBSyxHQUNQLFlBQWUsWUFBWSxJQUFJLFdBQVcsS0FBSyxJQUFJO0NBRXZEO0NBQ0EsUUFBUSxFQUNOLFVBQVUsV0FDWjtDQUNBLFlBQVk7Q0FDWixVQUFVLENBQUNWLG1CQUFzQixDQUFDLGtCQUFrQixDQUFDLEdBQUdGLDBCQUE2QjtBQUN2RixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLG1CQUFtQixDQUFDO0VBQzFGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLGtCQUFrQjtHQUM5QixNQUFNLEVBQ0osbUJBQW1CLHlCQUNyQjtHQUNBLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sRUFDUixVQUFVLENBQUMsRUFDVCxNQUFNLE1BQ1IsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLDRCQUFOLGNBQXdDLGtCQUFrQjs7O3dCQUN4RCxvQkFBa0IsVUFBUyxxQkFBQTs7QUFtQjdCOzsyQ0FsQlMsUUFBc0IsdUJBQU87Q0FDbEMsSUFBSTtDQUNKLE9BQU8sU0FBUyxrQ0FBa0MsbUJBQW1CO0VBQ25FLFFBQVEsMkNBQTJDLHlDQUF5Q0Msc0JBQXlCZSwwQkFBeUIsR0FBQSxDQUFJLHFCQUFxQkEsMEJBQXlCO0NBQ2xNO0FBQ0YsRUFBQSxDQUFHLENBQUE7MkNBQ0ksUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1BO0NBQ04sV0FBVztFQUFDO0dBQUM7R0FBUztHQUFRO0dBQVk7R0FBWTtHQUFJO0dBQW1CO0VBQUU7RUFBRztHQUFDO0dBQVM7R0FBUTtHQUFZO0dBQVk7R0FBSTtHQUFlO0VBQUU7RUFBRztHQUFDO0dBQVM7R0FBUTtHQUFZO0dBQVk7R0FBSTtHQUFXO0VBQUU7Q0FBQztDQUNoTixVQUFVO0NBQ1YsY0FBYyxTQUFTLHVDQUF1QyxJQUFJLEtBQUs7RUFDckUsSUFBSSxLQUFLLEdBQ1AsWUFBZSxZQUFZLElBQUksV0FBVyxLQUFLLElBQUk7Q0FFdkQ7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDWCxtQkFBc0IsQ0FBQywyQkFBMkIsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDaEcsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQiwyQkFBMkIsQ0FBQztFQUNsRyxNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLFdBQVcsQ0FBQywyQkFBMkI7R0FDdkMsTUFBTSxFQUNKLG1CQUFtQix5QkFDckI7R0FDQSxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxrQkFBa0I7Q0FDdEIsU0FBUztDQUNULGFBQWEsaUJBQWlCLGNBQWM7Q0FDNUMsT0FBTztBQUNUO0FBQ0EsSUFBTSxpQkFBTixjQUE2QiwyQkFBMkI7Ozt3QkFDdEQsU0FBQSxLQUFBLENBQUE7d0JBQ0EsYUFBWSxPQUFBO3dCQUNaLGtCQUFpQixnQkFBQTt3QkFDakIsb0JBQWtCLFVBQVMsY0FBQTs7Q0FDM0IsUUFBUSxPQUFPO0VBQ2IsT0FBTztDQUNUO0FBZ0JGOztnQ0FmUyxRQUFzQix1QkFBTztDQUNsQyxJQUFJO0NBQ0osT0FBTyxTQUFTLHVCQUF1QixtQkFBbUI7RUFDeEQsUUFBUSxnQ0FBZ0MsOEJBQThCQyxzQkFBeUJnQixlQUFjLEdBQUEsQ0FBSSxxQkFBcUJBLGVBQWM7Q0FDdEo7QUFDRixFQUFBLENBQUcsQ0FBQTtnQ0FDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFJO0dBQVM7R0FBSTtHQUFtQjtFQUFFO0VBQUc7R0FBQztHQUFJO0dBQVM7R0FBSTtHQUFlO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBUztHQUFJO0dBQVc7RUFBRTtDQUFDO0NBQzVILFFBQVEsRUFDTixPQUFPLFFBQ1Q7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDWixtQkFBc0IsQ0FBQyxlQUFlLENBQUMsR0FBR0YsMEJBQTZCO0FBQ3BGLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsZ0JBQWdCLENBQUM7RUFDdkYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUMsZUFBZTtHQUMzQixZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLEVBQ1IsT0FBTyxDQUFDLEVBQ04sTUFBTSxNQUNSLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSx1QkFBdUI7Q0FDM0IsU0FBUztDQUNULGFBQWEsaUJBQWlCLGtCQUFrQjtDQUNoRCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLHFCQUFOLGNBQWlDLDJCQUEyQjs7O3dCQUMxRCxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFZLFdBQUE7d0JBQ1osbUJBQWlCLFVBQVMsVUFBVSxLQUFLLENBQUE7d0JBQ3pDLG9CQUFrQixjQUFhLG1CQUFtQixTQUFTLENBQUE7O0FBc0I3RDs7b0NBckJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsMkJBQTJCLG1CQUFtQjtFQUM1RCxRQUFRLG9DQUFvQyxrQ0FBa0NDLHNCQUF5QmlCLG1CQUFrQixHQUFBLENBQUkscUJBQXFCQSxtQkFBa0I7Q0FDdEs7QUFDRixFQUFBLENBQUcsQ0FBQTtvQ0FDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFJO0dBQWE7R0FBSTtHQUFtQjtFQUFFO0VBQUc7R0FBQztHQUFJO0dBQWE7R0FBSTtHQUFlO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBYTtHQUFJO0dBQVc7RUFBRTtDQUFDO0NBQ3hJLFVBQVU7Q0FDVixjQUFjLFNBQVMsZ0NBQWdDLElBQUksS0FBSztFQUM5RCxJQUFJLEtBQUssR0FDUCxZQUFlLGFBQWEsSUFBSSxXQUFXLElBQUksWUFBWSxJQUFJO0NBRW5FO0NBQ0EsUUFBUSxFQUNOLFdBQVcsWUFDYjtDQUNBLFlBQVk7Q0FDWixVQUFVLENBQUNiLG1CQUFzQixDQUFDLG9CQUFvQixDQUFDLEdBQUdGLDBCQUE2QjtBQUN6RixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLG9CQUFvQixDQUFDO0VBQzNGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLG9CQUFvQjtHQUNoQyxNQUFNLEVBQ0osb0JBQW9CLDhCQUN0QjtHQUNBLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sRUFDUixXQUFXLENBQUMsRUFDVixNQUFNLE1BQ1IsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLHVCQUF1QjtDQUMzQixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsa0JBQWtCO0NBQ2hELE9BQU87QUFDVDtBQUNBLElBQU0scUJBQU4sY0FBaUMsMkJBQTJCOzs7d0JBQzFELGFBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQVksV0FBQTt3QkFDWixtQkFBaUIsVUFBUyxVQUFVLEtBQUssQ0FBQTt3QkFDekMsb0JBQWtCLGNBQWEsbUJBQW1CLFNBQVMsQ0FBQTs7QUFzQjdEOztvQ0FyQlMsUUFBc0IsdUJBQU87Q0FDbEMsSUFBSTtDQUNKLE9BQU8sU0FBUywyQkFBMkIsbUJBQW1CO0VBQzVELFFBQVEsb0NBQW9DLGtDQUFrQ0Msc0JBQXlCa0IsbUJBQWtCLEdBQUEsQ0FBSSxxQkFBcUJBLG1CQUFrQjtDQUN0SztBQUNGLEVBQUEsQ0FBRyxDQUFBO29DQUNJLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVc7RUFBQztHQUFDO0dBQUk7R0FBYTtHQUFJO0dBQW1CO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBYTtHQUFJO0dBQWU7RUFBRTtFQUFHO0dBQUM7R0FBSTtHQUFhO0dBQUk7R0FBVztFQUFFO0NBQUM7Q0FDeEksVUFBVTtDQUNWLGNBQWMsU0FBUyxnQ0FBZ0MsSUFBSSxLQUFLO0VBQzlELElBQUksS0FBSyxHQUNQLFlBQWUsYUFBYSxJQUFJLFdBQVcsSUFBSSxZQUFZLElBQUk7Q0FFbkU7Q0FDQSxRQUFRLEVBQ04sV0FBVyxZQUNiO0NBQ0EsWUFBWTtDQUNaLFVBQVUsQ0FBQ2QsbUJBQXNCLENBQUMsb0JBQW9CLENBQUMsR0FBR0YsMEJBQTZCO0FBQ3pGLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsb0JBQW9CLENBQUM7RUFDM0YsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUMsb0JBQW9CO0dBQ2hDLE1BQU0sRUFDSixvQkFBb0IsOEJBQ3RCO0dBQ0EsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxFQUNSLFdBQVcsQ0FBQyxFQUNWLE1BQU0sTUFDUixDQUFDLEVBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILElBQU0sb0JBQW9CO0NBQ3hCLFNBQVM7Q0FDVCxhQUFhLGlCQUFpQixnQkFBZ0I7Q0FDOUMsT0FBTztBQUNUO0FBQ0EsSUFBTSxtQkFBTixjQUErQiwyQkFBMkI7Ozt3QkFDeEQsV0FBQSxLQUFBLENBQUE7d0JBQ0EsYUFBWSxTQUFBO3dCQUNaLG1CQUFpQixVQUFTLEtBQUE7d0JBQzFCLG9CQUFrQixVQUFTLGlCQUFpQixLQUFLLENBQUE7O0FBc0JuRDs7a0NBckJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMseUJBQXlCLG1CQUFtQjtFQUMxRCxRQUFRLGtDQUFrQyxnQ0FBZ0NDLHNCQUF5Qm1CLGlCQUFnQixHQUFBLENBQUkscUJBQXFCQSxpQkFBZ0I7Q0FDOUo7QUFDRixFQUFBLENBQUcsQ0FBQTtrQ0FDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFJO0dBQVc7R0FBSTtHQUFtQjtFQUFFO0VBQUc7R0FBQztHQUFJO0dBQVc7R0FBSTtHQUFlO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBVztHQUFJO0dBQVc7RUFBRTtDQUFDO0NBQ2xJLFVBQVU7Q0FDVixjQUFjLFNBQVMsOEJBQThCLElBQUksS0FBSztFQUM1RCxJQUFJLEtBQUssR0FDUCxZQUFlLFdBQVcsSUFBSSxXQUFXLElBQUksVUFBVSxJQUFJO0NBRS9EO0NBQ0EsUUFBUSxFQUNOLFNBQVMsVUFDWDtDQUNBLFlBQVk7Q0FDWixVQUFVLENBQUNmLG1CQUFzQixDQUFDLGlCQUFpQixDQUFDLEdBQUdGLDBCQUE2QjtBQUN0RixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLGtCQUFrQixDQUFDO0VBQ3pGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLGlCQUFpQjtHQUM3QixNQUFNLEVBQ0osa0JBQWtCLDRCQUNwQjtHQUNBLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sRUFDUixTQUFTLENBQUMsRUFDUixNQUFNLE1BQ1IsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLDRCQUE0QixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSw2QkFBNkIsRUFBRTtBQUNwSSxJQUFNLDBCQUEwQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSx5QkFBeUIsSUFBSSxFQUM5SCxlQUFlLHdCQUNqQixDQUFDO0FBQ0QsSUFBTSwwQkFBMEI7QUFDaEMsU0FBUyxZQUFZLE1BQU0sUUFBUTtDQUNqQyxPQUFPLENBQUMsR0FBRyxPQUFPLE1BQU0sSUFBSTtBQUM5QjtBQUNBLFNBQVMsMEJBQTBCLFNBQVMsS0FBSyx1QkFBdUIseUJBQXlCO0NBQy9GLElBQUksT0FBTyxjQUFjLGVBQWUsV0FBVztFQUNqRCxJQUFJLENBQUMsU0FBUyxZQUFZLEtBQUssMEJBQTBCO0VBQ3pELElBQUksQ0FBQyxJQUFJLGVBQWUsZ0NBQWdDLEdBQUc7Q0FDN0Q7Q0FDQSxnQkFBZ0IsU0FBUyxHQUFHO0NBQzVCLElBQUksY0FBYyxXQUFXLFFBQVEsS0FBSztDQUMxQyxJQUFJLFFBQVEsWUFBWSx5QkFBeUIsVUFBVTs7RUFDekQsQ0FBQSx5QkFBQSxxQkFBQSxJQUFJLGNBQUEsQ0FBYyxzQkFBQSxRQUFBLDBCQUFBLEtBQUEsS0FBQSxzQkFBQSxLQUFBLG9CQUFtQixRQUFRLFFBQVE7Q0FDdkQ7Q0FDQSx3QkFBd0IsU0FBUyxHQUFHO0NBQ3BDLHlCQUF5QixTQUFTLEdBQUc7Q0FDckMsa0JBQWtCLFNBQVMsR0FBRztDQUM5QiwyQkFBMkIsU0FBUyxHQUFHO0FBQ3pDO0FBQ0EsU0FBUyxlQUFlLFNBQVMsS0FBSyxrQ0FBa0MsTUFBTTs7Q0FDNUUsTUFBTSxhQUFhO0VBQ2pCLElBQUksb0NBQW9DLE9BQU8sY0FBYyxlQUFlLFlBQzFFLGdCQUFnQixHQUFHO0NBRXZCO0NBQ0EsUUFBQSxRQUFBLFFBQUEsS0FBQSxNQUFBLHNCQUFBLElBQUssbUJBQUEsUUFBQSx3QkFBQSxLQUFBLEtBQUEsb0JBQWUsaUJBQWlCLElBQUk7Q0FDekMsUUFBQSxRQUFBLFFBQUEsS0FBQSxNQUFBLHNCQUFBLElBQUssbUJBQUEsUUFBQSx3QkFBQSxLQUFBLEtBQUEsb0JBQWUsa0JBQWtCLElBQUk7Q0FDMUMsa0JBQWtCLFNBQVMsR0FBRztDQUM5QixJQUFJLFNBQVM7RUFDWCxJQUFJLDBCQUEwQjtFQUM5QixRQUFRLGtDQUFrQyxDQUFDLENBQUM7Q0FDOUM7QUFDRjtBQUNBLFNBQVMsMEJBQTBCLFlBQVksVUFBVTtDQUN2RCxXQUFXLFNBQVEsY0FBYTtFQUM5QixJQUFJLFVBQVUsMkJBQTJCLFVBQVUsMEJBQTBCLFFBQVE7Q0FDdkYsQ0FBQztBQUNIO0FBQ0EsU0FBUywyQkFBMkIsU0FBUyxLQUFLO0NBQ2hELElBQUksSUFBSSxjQUFjLGtCQUFrQjtFQUN0QyxNQUFNLG9CQUFtQixlQUFjO0dBQ3JDLElBQUksY0FBYyxpQkFBaUIsVUFBVTtFQUMvQztFQUNBLFFBQVEseUJBQXlCLGdCQUFnQjtFQUNqRCxJQUFJLHlCQUF5QjtHQUMzQixRQUFRLDRCQUE0QixnQkFBZ0I7RUFDdEQsQ0FBQztDQUNIO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixTQUFTLEtBQUs7Q0FDckMsTUFBTSxhQUFhLHFCQUFxQixPQUFPO0NBQy9DLElBQUksSUFBSSxjQUFjLE1BQ3BCLFFBQVEsY0FBYyxnQkFBZ0IsWUFBWSxJQUFJLFNBQVMsQ0FBQztNQUMzRCxJQUFJLE9BQU8sZUFBZSxZQUMvQixRQUFRLGNBQWMsQ0FBQyxVQUFVLENBQUM7Q0FFcEMsTUFBTSxrQkFBa0IsMEJBQTBCLE9BQU87Q0FDekQsSUFBSSxJQUFJLG1CQUFtQixNQUN6QixRQUFRLG1CQUFtQixnQkFBZ0IsaUJBQWlCLElBQUksY0FBYyxDQUFDO01BQzFFLElBQUksT0FBTyxvQkFBb0IsWUFDcEMsUUFBUSxtQkFBbUIsQ0FBQyxlQUFlLENBQUM7Q0FFOUMsTUFBTSwwQkFBMEIsUUFBUSx1QkFBdUI7Q0FDL0QsMEJBQTBCLElBQUksZ0JBQWdCLGlCQUFpQjtDQUMvRCwwQkFBMEIsSUFBSSxxQkFBcUIsaUJBQWlCO0FBQ3RFO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUyxLQUFLO0NBQ3ZDLElBQUksbUJBQW1CO0NBQ3ZCLElBQUksWUFBWSxNQUFNO0VBQ3BCLElBQUksSUFBSSxjQUFjLE1BQU07R0FDMUIsTUFBTSxhQUFhLHFCQUFxQixPQUFPO0dBQy9DLElBQUksTUFBTSxRQUFRLFVBQVUsS0FBSyxXQUFXLFNBQVMsR0FBRztJQUN0RCxNQUFNLG9CQUFvQixXQUFXLFFBQU8sY0FBYSxjQUFjLElBQUksU0FBUztJQUNwRixJQUFJLGtCQUFrQixXQUFXLFdBQVcsUUFBUTtLQUNsRCxtQkFBbUI7S0FDbkIsUUFBUSxjQUFjLGlCQUFpQjtJQUN6QztHQUNGO0VBQ0Y7RUFDQSxJQUFJLElBQUksbUJBQW1CLE1BQU07R0FDL0IsTUFBTSxrQkFBa0IsMEJBQTBCLE9BQU87R0FDekQsSUFBSSxNQUFNLFFBQVEsZUFBZSxLQUFLLGdCQUFnQixTQUFTLEdBQUc7SUFDaEUsTUFBTSx5QkFBeUIsZ0JBQWdCLFFBQU8sbUJBQWtCLG1CQUFtQixJQUFJLGNBQWM7SUFDN0csSUFBSSx1QkFBdUIsV0FBVyxnQkFBZ0IsUUFBUTtLQUM1RCxtQkFBbUI7S0FDbkIsUUFBUSxtQkFBbUIsc0JBQXNCO0lBQ25EO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTSxhQUFhLENBQUM7Q0FDcEIsMEJBQTBCLElBQUksZ0JBQWdCLElBQUk7Q0FDbEQsMEJBQTBCLElBQUkscUJBQXFCLElBQUk7Q0FDdkQsT0FBTztBQUNUO0FBQ0EsU0FBUyx3QkFBd0IsU0FBUyxLQUFLO0NBQzdDLElBQUksY0FBYyxrQkFBaUIsYUFBWTtFQUM3QyxRQUFRLGdCQUFnQjtFQUN4QixRQUFRLGlCQUFpQjtFQUN6QixRQUFRLGdCQUFnQjtFQUN4QixJQUFJLFFBQVEsYUFBYSxVQUFVLGNBQWMsU0FBUyxHQUFHO0NBQy9ELENBQUM7QUFDSDtBQUNBLFNBQVMsa0JBQWtCLFNBQVMsS0FBSztDQUN2QyxJQUFJLGNBQWMsd0JBQXdCO0VBQ3hDLFFBQVEsa0JBQWtCO0VBQzFCLElBQUksUUFBUSxhQUFhLFVBQVUsUUFBUSxnQkFBZ0IsY0FBYyxTQUFTLEdBQUc7RUFDckYsSUFBSSxRQUFRLGFBQWEsVUFBVSxRQUFRLGNBQWM7Q0FDM0QsQ0FBQztBQUNIO0FBQ0EsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUNuQyxJQUFJLFFBQVEsZUFBZSxRQUFRLFlBQVk7Q0FDL0MsUUFBUSxTQUFTLFFBQVEsZUFBZSxFQUN0Qyx1QkFBdUIsTUFDekIsQ0FBQztDQUNELElBQUksa0JBQWtCLFFBQVEsYUFBYTtDQUMzQyxRQUFRLGlCQUFpQjtBQUMzQjtBQUNBLFNBQVMseUJBQXlCLFNBQVMsS0FBSztDQUM5QyxNQUFNLFlBQVksVUFBVSxtQkFBbUI7RUFDN0MsSUFBSSxjQUFjLFdBQVcsUUFBUTtFQUNyQyxJQUFJLGdCQUFnQixJQUFJLGtCQUFrQixRQUFRO0NBQ3BEO0NBQ0EsUUFBUSxpQkFBaUIsUUFBUTtDQUNqQyxJQUFJLHlCQUF5QjtFQUMzQixRQUFRLG9CQUFvQixRQUFRO0NBQ3RDLENBQUM7QUFDSDtBQUNBLFNBQVMsbUJBQW1CLFNBQVMsS0FBSztDQUN4QyxJQUFJLFdBQVcsU0FBUyxPQUFPLGNBQWMsZUFBZSxZQUFZLFlBQVksS0FBSywwQkFBMEI7Q0FDbkgsZ0JBQWdCLFNBQVMsR0FBRztBQUM5QjtBQUNBLFNBQVMscUJBQXFCLFNBQVMsS0FBSztDQUMxQyxPQUFPLGtCQUFrQixTQUFTLEdBQUc7QUFDdkM7QUFDQSxTQUFTLGdCQUFnQixLQUFLO0NBQzVCLE9BQU8sWUFBWSxLQUFLLHdFQUF3RTtBQUNsRztBQUNBLFNBQVMsWUFBWSxLQUFLLFNBQVM7Q0FDakMsTUFBTSxhQUFhLHlCQUF5QixHQUFHO0NBQy9DLE1BQU0sSUFBSSxNQUFNLEdBQUcsUUFBUSxHQUFHLFlBQVk7QUFDNUM7QUFDQSxTQUFTLHlCQUF5QixLQUFLO0NBQ3JDLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLElBQUksUUFBUSxLQUFLLFNBQVMsR0FBRyxPQUFPLFVBQVUsS0FBSyxLQUFLLE1BQU0sRUFBRTtDQUNoRSxJQUFBLFNBQUEsUUFBQSxTQUFBLEtBQUEsSUFBQSxLQUFBLElBQUksS0FBTyxJQUFJLE9BQU8sVUFBVSxLQUFLO0NBQ3JDLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0NBQWdDLEtBQUs7Q0FFNUMsTUFBTSxJQUFJVSxhQUFjLE9BQU8sc0NBRG5CLHlCQUF5QixHQUNrQyxFQUFFLEVBQUU7QUFDN0U7QUFDQSxTQUFTLGdDQUFnQyxLQUFLO0NBRTVDLE1BQU0sSUFBSUEsYUFBYyxNQUFNLHFFQURsQix5QkFBeUIsR0FDZ0UsRUFBRSwwRkFBK0Y7QUFDeE07QUFDQSxTQUFTLGtCQUFrQixTQUFTLFdBQVc7Q0FDN0MsSUFBSSxDQUFDLFFBQVEsZUFBZSxPQUFPLEdBQUcsT0FBTztDQUM3QyxNQUFNLFNBQVMsUUFBUTtDQUN2QixJQUFJLE9BQU8sY0FBYyxHQUFHLE9BQU87Q0FDbkMsT0FBTyxDQUFDLE9BQU8sR0FBRyxXQUFXLE9BQU8sWUFBWTtBQUNsRDtBQUNBLFNBQVMsa0JBQWtCLGVBQWU7Q0FDeEMsT0FBTyxPQUFPLGVBQWUsY0FBYyxXQUFXLE1BQU07QUFDOUQ7QUFDQSxTQUFTLG9CQUFvQixNQUFNLFlBQVk7Q0FDN0MsS0FBSyxxQkFBcUI7Q0FDMUIsV0FBVyxTQUFRLFFBQU87RUFDeEIsTUFBTSxVQUFVLElBQUk7RUFDcEIsSUFBSSxRQUFRLGFBQWEsWUFBWSxRQUFRLGdCQUFnQjtHQUMzRCxJQUFJLGtCQUFrQixRQUFRLGFBQWE7R0FDM0MsUUFBUSxpQkFBaUI7RUFDM0I7Q0FDRixDQUFDO0FBQ0g7QUFDQSxTQUFTLG9CQUFvQixLQUFLLGdCQUFnQjtDQUNoRCxJQUFJLENBQUMsZ0JBQWdCLE9BQU87Q0FDNUIsSUFBSSxDQUFDLE1BQU0sUUFBUSxjQUFjLE1BQU0sT0FBTyxjQUFjLGVBQWUsWUFBWSxnQ0FBZ0MsR0FBRztDQUMxSCxJQUFJLGtCQUFrQixLQUFBO0NBQ3RCLElBQUksa0JBQWtCLEtBQUE7Q0FDdEIsSUFBSSxpQkFBaUIsS0FBQTtDQUNyQixlQUFlLFNBQVEsTUFBSztFQUMxQixJQUFJLEVBQUUsZ0JBQWdCLHNCQUNwQixrQkFBa0I7T0FDYixJQUFJLGtCQUFrQixDQUFDLEdBQUc7R0FDL0IsSUFBSSxvQkFBb0IsT0FBTyxjQUFjLGVBQWUsWUFBWSxZQUFZLEtBQUssaUVBQWlFO0dBQzFKLGtCQUFrQjtFQUNwQixPQUFPO0dBQ0wsSUFBSSxtQkFBbUIsT0FBTyxjQUFjLGVBQWUsWUFBWSxZQUFZLEtBQUssK0RBQStEO0dBQ3ZKLGlCQUFpQjtFQUNuQjtDQUNGLENBQUM7Q0FDRCxJQUFJLGdCQUFnQixPQUFPO0NBQzNCLElBQUksaUJBQWlCLE9BQU87Q0FDNUIsSUFBSSxpQkFBaUIsT0FBTztDQUM1QixJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLFlBQVksS0FBSywrQ0FBK0M7Q0FFbEUsT0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTSxJQUFJO0NBQ2xDLE1BQU0sUUFBUSxLQUFLLFFBQVEsRUFBRTtDQUM3QixJQUFJLFFBQVEsSUFBSSxLQUFLLE9BQU8sT0FBTyxDQUFDO0FBQ3RDO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxNQUFNLFVBQVUsZUFBZTtDQUM1RCxJQUFJLGtCQUFrQixTQUFTO0NBQy9CLEtBQUssa0JBQWtCLFFBQVEsa0JBQWtCLFdBQVcsQ0FBQyxLQUFLLDJCQUEyQixrQkFBa0IsWUFBWSxDQUFDLFNBQVMscUJBQXFCO0VBQ3hKLFFBQVEsS0FBSyxlQUFlLElBQUksQ0FBQztFQUNqQyxLQUFLLDBCQUEwQjtFQUMvQixTQUFTLHNCQUFzQjtDQUNqQztBQUNGO0FBQ0EsSUFBTSxrQ0FBa0M7Q0FDdEMsU0FBUztDQUNULGtCQUFrQjtFQUNoQixNQUFNLFVBQVUsT0FBTyxXQUFXLEVBQ2hDLE1BQU0sS0FDUixDQUFDO0VBQ0QsT0FBTztHQUNMLGlCQUFnQixXQUFVO0lBQ3hCLFFBQVEsb0JBQW9CLE1BQU07R0FDcEM7R0FDQSxJQUFJLFFBQVEsVUFBVTtJQUNwQixRQUFRLFVBQVU7R0FDcEI7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxJQUFNLFlBQU4sY0FBd0IseUJBQXlCO0NBTy9DLElBQUksUUFBUSxVQUFVOztFQUNwQixLQUFLLGNBQWM7RUFDbkIsQ0FBQSx3QkFBQSxLQUFLLHVCQUFBLFFBQUEsMEJBQUEsS0FBQSxLQUFBLHNCQUFtQixZQUFZO0VBQ3BDLEtBQUssb0JBQW9CLEtBQUE7RUFDekIsSUFBSSxLQUFLLFNBQVM7O0dBQ2hCLEtBQUssb0JBQW9CLEtBQUssUUFBUSxPQUFPLFdBQVUsVUFBUztJQUM5RCxJQUFJLGlCQUFpQixrQkFBa0IsS0FBSyxTQUFTOztLQUNuRCxDQUFBLG9CQUFBLEtBQUssaUJBQUEsUUFBQSxzQkFBQSxLQUFBLEtBQUEsa0JBQUEsS0FBQSxNQUFjLEtBQUssUUFBUSxLQUFLO0lBQ3ZDO0dBQ0YsQ0FBQztHQUNELENBQUEscUJBQUEsS0FBSyxrQkFBQSxRQUFBLHVCQUFBLEtBQUEsS0FBQSxtQkFBYyxJQUFJLEtBQUssaUJBQWlCO0VBQy9DO0NBQ0Y7Q0FJQSxJQUFJLHdCQUF3Qjs7RUFDMUIsUUFBQSx3QkFBTyxLQUFLLDRCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFMLEtBQUsseUJBQTJCLG9CQUFvQixNQUFNLEtBQUssaUJBQWlCO0NBQ3pGO0NBT0EsWUFBWSxVQUFVLFVBQVUsbUJBQW1COztFQUNqRCxNQUFNO3dCQWhDUixXQUFVLElBQUE7d0JBQ1YsUUFBTyxJQUFBO3dCQUNQLGlCQUFnQixJQUFBO3dCQUNoQix3QkFBdUIsS0FBQTt3QkFDdkIsZUFBQSxLQUFBLENBQUE7d0JBQ0EscUJBQUEsS0FBQSxDQUFBO3dCQWNBLHVCQUFzQixLQUFBO3dCQUN0QixxQkFBQSxLQUFBLENBQUE7d0JBQ0EsMEJBQXlCLElBQUE7d0JBSXpCLHdCQUF1QixJQUFBO3dCQUN2QixZQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTt3QkFDQSwwQkFBQSxLQUFBLENBQUE7d0JBQ0EsZ0JBQUEsS0FBQSxDQUFBO3dCQUNBLHlCQUF3QixJQUFBO0VBR3RCLEtBQUssV0FBVztFQUNoQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxvQkFBb0I7RUFDekIsQ0FBQSxpQkFBQSxLQUFLLGNBQUEsUUFBQSxtQkFBQSxLQUFBLE1BQUEsaUJBQUEsZUFBVSxJQUFJLFVBQVUsT0FBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFHLGdCQUFnQjs7R0FDOUMsS0FBSywyQkFBMkIsS0FBSyxPQUFPO0dBQzVDLENBQUEsc0JBQUEsS0FBSyxrQkFBQSxRQUFBLHdCQUFBLEtBQUEsS0FBQSxvQkFBYyxZQUFZO0VBQ2pDLENBQUM7Q0FDSDtDQUNBLHFCQUFxQjs7RUFDbkIsQ0FBQSxzQkFBQSxLQUFLLGtCQUFBLFFBQUEsd0JBQUEsS0FBQSxLQUFBLG9CQUFjLFlBQVk7RUFDL0IsTUFBTSxPQUFBLGtCQUFNLEtBQUssY0FBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsZ0JBQVUsSUFBSSxpQkFBaUI7RUFDaEQsSUFBSSxDQUFDLEtBQUssV0FBVyxDQUFDLEtBQ3BCO0VBRUYsTUFBTSxlQUFlLElBQUksYUFBYSxLQUFLLEdBQUc7RUFDOUMsS0FBSyxlQUFlLElBQUksYUFBYTtFQUNyQyxLQUFLLGFBQWEsSUFBSSxLQUFLLFFBQVEsYUFBYSxVQUFVLFlBQVksQ0FBQztFQUN2RSxLQUFLLGFBQWEsSUFBSSxLQUFLLFFBQVEsY0FBYyxVQUFVLFlBQVksQ0FBQztFQUN4RSxDQUFBLHlCQUFBLEtBQUssdUJBQUEsUUFBQSwyQkFBQSxLQUFBLEtBQUEsdUJBQW1CLFlBQVk7RUFDcEMsS0FBSyxvQkFBb0IsS0FBQTtFQUN6QixJQUFJLEtBQUssYUFBYTtHQUNwQixLQUFLLG9CQUFvQixLQUFLLFFBQVEsT0FBTyxXQUFVLFVBQVM7SUFDOUQsSUFBSSxpQkFBaUIsa0JBQWtCLEtBQUssU0FBUzs7S0FDbkQsQ0FBQSxxQkFBQSxLQUFLLGlCQUFBLFFBQUEsdUJBQUEsS0FBQSxLQUFBLG1CQUFBLEtBQUEsTUFBYyxLQUFLLFFBQVEsS0FBSztJQUN2QztHQUNGLENBQUM7R0FDRCxLQUFLLGFBQWEsSUFBSSxLQUFLLGlCQUFpQjtFQUM5QztFQUNBLElBQUksS0FBSyxzQkFDUCxLQUFLLFFBQVEsY0FBYyxLQUFLLG9CQUFvQjtDQUV4RDtDQUNBLGdCQUFnQixNQUFNOztFQUdwQixJQURlLEdBQUEseUJBQUEsc0JBREksS0FBSyxjQUFBLENBQWMsa0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFBLEtBQUEscUJBQWUsU0FBUyxPQUMvQixLQUFLLHFCQUFxQixLQUFLLGtCQUFrQixTQUFTLEtBQUssS0FBSyxrQkFBa0IsU0FDdkcsQ0FBQyxLQUFLLGVBQ2xCO0VBRUYsS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyw0QkFBMkIsVUFBUzs7R0FDdkMsQ0FBQSxpQkFBQSxLQUFLLGFBQUEsUUFBQSxtQkFBQSxLQUFBLEtBQUEsZUFBUyxTQUFTLE9BQU8sRUFDNUIsdUJBQXVCLE1BQ3pCLENBQUM7R0FDRCxDQUFBLGlCQUFBLEtBQUssYUFBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFTLFlBQVk7R0FDMUIsS0FBSyxrQkFBa0IsS0FBSztFQUM5QixDQUFDO0VBQ0QsS0FBSyw0QkFBNEIsZUFBZTs7R0FDOUMsQ0FBQSxpQkFBQSxLQUFLLGFBQUEsUUFBQSxtQkFBQSxLQUFBLEtBQUEsZUFBUyxjQUFjO0VBQzlCLENBQUM7RUFDRCxLQUFLLHdCQUF3QixDQUFDO0VBQzlCLEtBQUssc0JBQXNCLG9CQUFvQixLQUFLLGFBQWE7RUFDakUsS0FBSyx5QkFBeUIsS0FBSyxlQUFlLE1BQUssTUFBSyxhQUFhLGlCQUFpQjtDQUM1RjtDQUNBLGdCQUFnQixNQUFNLGNBQWM7RUFDbEMsSUFBSSxDQUFDLEtBQUssc0JBQ1I7RUFFRixNQUFNLFVBQVUsS0FBSztFQUNyQixNQUFNLFdBQVcsS0FBSztFQUN0QixJQUFJLENBQUMsT0FBTyxHQUFHLFNBQVMsT0FBTyxRQUFRLEtBQUssR0FBRztHQUM3QyxTQUFTLFFBQVEsUUFBUTtHQUN6QixLQUFLLDJCQUEyQixRQUFRLEtBQUs7RUFDL0M7RUFDQSxLQUFLLG9CQUFvQixNQUFNLFVBQVUsV0FBVyxRQUFRLE9BQU87RUFDbkUsS0FBSyxvQkFBb0IsTUFBTSxVQUFVLFNBQVMsUUFBUSxLQUFLO0VBQy9ELEtBQUssb0JBQW9CLE1BQU0sVUFBVSxTQUFTLFFBQVEsS0FBSztFQUMvRCxLQUFLLG9CQUFvQixNQUFNLFVBQVUsV0FBVyxRQUFRLE9BQU87RUFDbkUsS0FBSyxvQkFBb0IsTUFBTSxVQUFVLFdBQVcsUUFBUSxPQUFPO0VBQ25FLEtBQUssb0JBQW9CLE1BQU0sVUFBVSxZQUFZLFFBQVEsUUFBUTtFQUNyRSxJQUFJLEtBQUssb0JBQ1AsS0FBSyxvQkFBb0IsTUFBTSxVQUFVLFlBQVksS0FBSyxVQUFVO0VBRXRFLE1BQU0sY0FBYyxRQUFRO0VBQzVCLElBQUksU0FBUyxXQUFXLGFBQWE7R0FDbkMsU0FBUyxTQUFTO0dBQ2xCLE1BQU0sYUFBYSxLQUFLLGVBQWUsV0FBVztHQUNsRCxLQUFLLHFCQUFxQixVQUFVLFVBQVU7RUFDaEQ7Q0FDRjtDQUNBLElBQUksYUFBYTs7RUFDZixRQUFBLFVBQUEsd0JBQVEsS0FBSyw0QkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQXdCLGVBQUEsaUJBQVksS0FBSyxhQUFBLFFBQUEsbUJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxlQUFTLGFBQWEsUUFBQSxRQUFBLFVBQUEsS0FBQSxJQUFBLFFBQU07Q0FDcEY7Q0FDQSxJQUFJLHFCQUFxQjtFQUN2QixPQUFPO0NBQ1Q7Q0FDQSxvQkFBb0IsTUFBTSxVQUFVLE1BQU0sT0FBTztFQUMvQyxJQUFJLFNBQVMsVUFBVSxPQUNyQjtFQUVGLFNBQVMsUUFBUTtFQUNqQixNQUFNLFNBQVMsS0FBSyxxQkFBcUIsTUFBTSxLQUFLO0VBQ3BELElBQUksS0FBSyx1QkFBdUIsQ0FBQyxXQUFXLFNBQVMsY0FBYyxTQUFTLGVBQWUsS0FBSyxVQUM5RixxQkFBcUIsS0FBSyxVQUFVLEtBQUssZUFBZSxNQUFNLEtBQUs7Q0FFdkU7Q0FDQSxlQUFlLFFBQVE7RUFDckIsSUFBSSxXQUFXLE1BQ2IsT0FBTyxDQUFDO0VBRVYsTUFBTSxVQUFVLEtBQUs7RUFDckIsT0FBTyxPQUFPLFFBQVEsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sYUFBYTtHQUNyRCxPQUFPLElBQUksd0JBQXdCO0lBQ2pDO0lBQ0E7SUFDQTtHQUNGLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxvQkFBb0IsYUFBYTtFQUMvQixJQUFJLGdCQUFnQixLQUFBLEdBQ2xCO0VBRUYsSUFBSSxrQkFBa0I7RUFDdEIsTUFBTSx1QkFBdUIsZUFBZTtHQUMxQyxNQUFNLFlBQVksWUFBWTtHQUM5QixJQUFJLFVBQVUsV0FBVyxHQUN2QixPQUFPO0dBRVQsT0FBTyxVQUFVLFFBQVEsS0FBSyxRQUFRO0lBQ3BDLElBQUksSUFBSSxRQUFRO0lBQ2hCLE9BQU87R0FDVCxHQUFHLENBQUMsQ0FBQztFQUNQLEdBQUcsR0FBSSxZQUFZLENBQUMsRUFDbEIsV0FBVyx1QkFDYixDQUFDLElBQUksQ0FBQyxDQUFFO0VBQ1IsS0FBSyw4QkFBOEIsZ0JBQUEsQ0FBaUIsS0FBSyxJQUFJO0VBQzdELGFBQWE7O0dBQ1gsa0JBQWtCLHFCQUFxQjtHQUN2QyxDQUFBLGlCQUFBLEtBQUssYUFBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFTLHVCQUF1QixFQUNuQyxXQUFXLE1BQ2IsQ0FBQztFQUNILEdBQUcsRUFDRCxVQUFVLEtBQUssU0FDakIsQ0FBQztDQUNIO0NBQ0EsMkJBQTJCLFNBQVM7RUFDbEMsSUFBSSxLQUFLLHNCQUFzQjtHQUM3QixZQUFBLFFBQUEsWUFBQSxLQUFBLEtBQUEsUUFBUyxpQkFBaUIsS0FBSyxvQkFBb0I7R0FDbkQsWUFBQSxRQUFBLFlBQUEsS0FBQSxLQUFBLFFBQVMsdUJBQXVCLEVBQzlCLFdBQVcsTUFDYixDQUFDO0VBQ0g7Q0FDRjtBQUNGO0FBQ0EsSUFBTSx3QkFBTixNQUE0QjtDQUUxQixZQUFZLElBQUk7d0JBRGhCLE9BQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxNQUFNO0NBQ2I7Q0FDQSxJQUFJLFlBQVk7O0VBQ2QsQ0FBQSxZQUFBLEtBQUssU0FBQSxRQUFBLGNBQUEsS0FBQSxNQUFBLFlBQUEsVUFBSyxhQUFBLFFBQUEsY0FBQSxLQUFBLE1BQUEscUJBQUEsVUFBUyxjQUFBLFFBQUEsdUJBQUEsS0FBQSxLQUFBLG1CQUFBLEtBQUEsU0FBVztFQUM5QixPQUFPLENBQUMsR0FBQSxhQUFDLEtBQUssU0FBQSxRQUFBLGVBQUEsS0FBQSxNQUFBLGFBQUEsV0FBSyxhQUFBLFFBQUEsZUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFdBQVM7Q0FDOUI7Q0FDQSxJQUFJLGNBQWM7O0VBQ2hCLE9BQU8sQ0FBQyxHQUFBLGFBQUMsS0FBSyxTQUFBLFFBQUEsZUFBQSxLQUFBLE1BQUEsYUFBQSxXQUFLLGFBQUEsUUFBQSxlQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsV0FBUztDQUM5QjtDQUNBLElBQUksYUFBYTs7RUFDZixDQUFBLGFBQUEsS0FBSyxTQUFBLFFBQUEsZUFBQSxLQUFBLE1BQUEsYUFBQSxXQUFLLGFBQUEsUUFBQSxlQUFBLEtBQUEsTUFBQSx1QkFBQSxXQUFTLGVBQUEsUUFBQSx5QkFBQSxLQUFBLEtBQUEscUJBQUEsS0FBQSxVQUFZO0VBQy9CLE9BQU8sQ0FBQyxHQUFBLGFBQUMsS0FBSyxTQUFBLFFBQUEsZUFBQSxLQUFBLE1BQUEsYUFBQSxXQUFLLGFBQUEsUUFBQSxlQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsV0FBUztDQUM5QjtDQUNBLElBQUksVUFBVTs7RUFDWixPQUFPLENBQUMsR0FBQSxhQUFDLEtBQUssU0FBQSxRQUFBLGVBQUEsS0FBQSxNQUFBLGFBQUEsV0FBSyxhQUFBLFFBQUEsZUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFdBQVM7Q0FDOUI7Q0FDQSxJQUFJLFVBQVU7O0VBQ1osQ0FBQSxhQUFBLEtBQUssU0FBQSxRQUFBLGVBQUEsS0FBQSxNQUFBLGFBQUEsV0FBSyxhQUFBLFFBQUEsZUFBQSxLQUFBLE1BQUEscUJBQUEsV0FBUyxhQUFBLFFBQUEsdUJBQUEsS0FBQSxLQUFBLG1CQUFBLEtBQUEsVUFBVTtFQUM3QixPQUFPLENBQUMsR0FBQSxhQUFDLEtBQUssU0FBQSxRQUFBLGVBQUEsS0FBQSxNQUFBLGFBQUEsV0FBSyxhQUFBLFFBQUEsZUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFdBQVM7Q0FDOUI7Q0FDQSxJQUFJLFlBQVk7O0VBQ2QsT0FBTyxDQUFDLEdBQUEsYUFBQyxLQUFLLFNBQUEsUUFBQSxlQUFBLEtBQUEsTUFBQSxhQUFBLFdBQUssYUFBQSxRQUFBLGVBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxXQUFTO0NBQzlCO0NBQ0EsSUFBSSxZQUFZOztFQUNkLE9BQU8sQ0FBQyxHQUFBLGNBQUMsS0FBSyxTQUFBLFFBQUEsZ0JBQUEsS0FBQSxNQUFBLGNBQUEsWUFBSyxhQUFBLFFBQUEsZ0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxZQUFTO0NBQzlCO0NBQ0EsSUFBSSxjQUFjOztFQUNoQixDQUFBLGNBQUEsS0FBSyxTQUFBLFFBQUEsZ0JBQUEsS0FBQSxNQUFBLHdCQUFBLFlBQUssZ0JBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQUEsS0FBQSxXQUFhO0VBQ3ZCLE9BQU8sQ0FBQyxHQUFBLGNBQUMsS0FBSyxTQUFBLFFBQUEsZ0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxZQUFLO0NBQ3JCO0FBQ0Y7QUFDQSxJQUFNLHNCQUFzQjtDQUMxQix3QkFBd0I7Q0FDeEIsc0JBQXNCO0NBQ3RCLHVCQUF1QjtDQUN2QixvQkFBb0I7Q0FDcEIsb0JBQW9CO0NBQ3BCLHNCQUFzQjtDQUN0QixzQkFBc0I7QUFDeEI7QUFDQSxJQUFNLGtCQUFOLGNBQThCLHNCQUFzQjtDQUNsRCxZQUFZLElBQUk7RUFDZCxNQUFNLEVBQUU7Q0FDVjtBQWlCRjs7aUNBaEJTLFFBQU8sU0FBUyx3QkFBd0IsbUJBQW1CO0NBRWhFLE9BQU8sS0FBSyxxQkFBcUJXLGtCQUFpQnhCLGtCQUFxQixXQUFXLENBQUMsQ0FBQztBQUN0RixDQUFBO2lDQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNd0I7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFJO0dBQW1CO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFJO0dBQWU7RUFBRTtDQUFDO0NBQ3JGLFVBQVU7Q0FDVixjQUFjLFNBQVMsNkJBQTZCLElBQUksS0FBSztFQUMzRCxJQUFJLEtBQUssR0FDUCxZQUFlLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQyxlQUFlLElBQUksVUFBVSxDQUFDLENBQUMsWUFBWSxJQUFJLE9BQU8sQ0FBQyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUMsY0FBYyxJQUFJLFNBQVM7Q0FFMU47Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDbEIsMEJBQTZCO0FBQzFDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsaUJBQWlCLENBQUM7RUFDeEYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixNQUFNO0dBQ04sWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQztFQUNULE1BQU07RUFDTixZQUFZLENBQUMsRUFDWCxNQUFNLEtBQ1IsQ0FBQztDQUNILENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSx1QkFBTixjQUFtQyxzQkFBc0I7Q0FDdkQsWUFBWSxJQUFJO0VBQ2QsTUFBTSxFQUFFO0NBQ1Y7QUFpQkY7O3NDQWhCUyxRQUFPLFNBQVMsNkJBQTZCLG1CQUFtQjtDQUVyRSxPQUFPLEtBQUsscUJBQXFCc0IsdUJBQXNCekIsa0JBQXFCLGtCQUFrQixFQUFFLENBQUM7QUFDbkcsQ0FBQTtzQ0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTXlCO0NBQ04sV0FBVztFQUFDO0dBQUM7R0FBSTtHQUFpQjtFQUFFO0VBQUc7R0FBQztHQUFJO0dBQWlCO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBZ0I7RUFBRTtFQUFHO0dBQUM7R0FBSTtHQUFhO0VBQUU7RUFBRztHQUFDO0dBQUk7R0FBYTtFQUFFO0VBQUc7R0FBQztHQUFRO0dBQUc7R0FBWTtFQUFFO0VBQUc7R0FBQztHQUFJO0dBQVU7RUFBRTtDQUFDO0NBQ3pMLFVBQVU7Q0FDVixjQUFjLFNBQVMsa0NBQWtDLElBQUksS0FBSztFQUNoRSxJQUFJLEtBQUssR0FDUCxZQUFlLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQyxlQUFlLElBQUksVUFBVSxDQUFDLENBQUMsWUFBWSxJQUFJLE9BQU8sQ0FBQyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUMsY0FBYyxJQUFJLFNBQVMsQ0FBQyxDQUFDLGdCQUFnQixJQUFJLFdBQVc7Q0FFM1A7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDbkIsMEJBQTZCO0FBQzFDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsc0JBQXNCLENBQUM7RUFDN0YsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixNQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0ssbUJBQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCx3QkFBd0IsY0FBQSxDQUMxQjtHQUNBLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUM7RUFDVCxNQUFNO0VBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUcsRUFDRCxNQUFNLEtBQ1IsQ0FBQztDQUNILENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxZQUFOLGNBQXdCLGdCQUFnQjtDQUN0QyxZQUFZLFVBQVUsaUJBQWlCLGdCQUFnQjtFQUNyRCxNQUFNLGVBQWUsZUFBZSxHQUFHLG9CQUFvQixnQkFBZ0IsZUFBZSxDQUFDO3dCQVc3RixZQUFBLEtBQUEsQ0FBQTtFQVZFLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYywwQkFBMEIsUUFBUTtFQUNyRixLQUFLLFdBQVc7RUFDaEIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxtQkFBbUIsZUFBZTtFQUN2QyxLQUFLLGVBQWU7RUFDcEIsS0FBSyx1QkFBdUI7R0FDMUIsVUFBVTtHQUNWLFdBQVcsQ0FBQyxDQUFDLEtBQUs7RUFDcEIsQ0FBQztDQUNIO0NBRUEsZ0JBQWdCLE1BQU0sU0FBUztFQUM3QixNQUFNLGtCQUFrQixLQUFLLE1BQU0sSUFBSTtFQUN2QyxJQUFJLGlCQUFpQixPQUFPO0VBQzVCLEtBQUssU0FBUyxRQUFRO0VBQ3RCLFFBQVEsVUFBVSxJQUFJO0VBQ3RCLFFBQVEsNEJBQTRCLEtBQUssbUJBQW1CO0VBQzVELE9BQU87Q0FDVDtDQUNBLFdBQVcsTUFBTSxTQUFTLFVBQVUsQ0FBQyxHQUFHO0VBQ3RDLEtBQUssZ0JBQWdCLE1BQU0sT0FBTztFQUNsQyxLQUFLLHVCQUF1QixFQUMxQixXQUFXLFFBQVEsVUFDckIsQ0FBQztFQUNELEtBQUssb0JBQW9CO0NBQzNCO0NBQ0EsY0FBYyxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQ2hDLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxJQUFJO0VBQ3ZDLElBQUksaUJBQWlCLGdCQUFnQixrQ0FBa0MsQ0FBQyxDQUFDO0VBQ3pFLE9BQU8sS0FBSyxTQUFTO0VBQ3JCLEtBQUssdUJBQXVCLEVBQzFCLFdBQVcsUUFBUSxVQUNyQixDQUFDO0VBQ0QsS0FBSyxvQkFBb0I7Q0FDM0I7Q0FDQSxXQUFXLE1BQU0sU0FBUyxVQUFVLENBQUMsR0FBRztFQUN0QyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sSUFBSTtFQUN2QyxJQUFJLGlCQUFpQixnQkFBZ0Isa0NBQWtDLENBQUMsQ0FBQztFQUN6RSxPQUFPLEtBQUssU0FBUztFQUNyQixJQUFJLFNBQVMsS0FBSyxnQkFBZ0IsTUFBTSxPQUFPO0VBQy9DLEtBQUssdUJBQXVCLEVBQzFCLFdBQVcsUUFBUSxVQUNyQixDQUFDO0VBQ0QsS0FBSyxvQkFBb0I7Q0FDM0I7Q0FDQSxTQUFTLGFBQWE7O0VBQ3BCLFNBQUEsY0FBTyxLQUFLLE1BQU0sV0FBVyxPQUFBLFFBQUEsZ0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxZQUFHLGFBQVk7Q0FDOUM7Q0FDQSxTQUFTLE9BQU8sVUFBVSxDQUFDLEdBQUc7RUFDNUIsZ0JBQWdCO0dBQ2QsdUJBQXVCLE1BQU0sTUFBTSxLQUFLO0dBQ3hDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxTQUFRLFNBQVE7SUFDakMscUJBQXFCLE1BQU0sTUFBTSxJQUFJO0lBQ3JDLEtBQUssU0FBUyxLQUFLLENBQUMsU0FBUyxNQUFNLE9BQU87S0FDeEMsVUFBVTtLQUNWLFdBQVcsUUFBUTtJQUNyQixDQUFDO0dBQ0gsQ0FBQztHQUNELEtBQUssdUJBQXVCLE9BQU87RUFDckMsQ0FBQztDQUNIO0NBQ0EsV0FBVyxPQUFPLFVBQVUsQ0FBQyxHQUFHO0VBQzlCLElBQUksU0FBUyxNQUFNO0VBQ25CLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxTQUFRLFNBQVE7R0FDakMsTUFBTSxrQkFBa0IsS0FBSyxNQUFNLElBQUk7R0FDdkMsSUFBSSxpQkFDRixnQkFBZ0IsV0FBVyxNQUFNLE9BQU87SUFDdEMsVUFBVTtJQUNWLFdBQVcsUUFBUTtHQUNyQixDQUFDO0VBRUwsQ0FBQztFQUNELEtBQUssdUJBQXVCLE9BQU87Q0FDckM7Q0FDQSxNQUFNLFFBQVEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHO0VBQzlCLEtBQUssZUFBZSxTQUFTLFNBQVM7R0FDcEMsUUFBUSxNQUFNLFFBQVEsTUFBTSxRQUFRLE1BQUEsZUFBQSxlQUFBLENBQUEsR0FDL0IsT0FBQSxHQUFBLENBQUEsR0FBQSxFQUNILFVBQVUsS0FBQSxDQUNaLENBQUM7RUFDSCxDQUFDO0VBQ0QsS0FBSyxnQkFBZ0IsU0FBUyxJQUFJO0VBQ2xDLEtBQUssZUFBZSxTQUFTLElBQUk7RUFDakMsS0FBSyx1QkFBdUIsT0FBTztFQUNuQyxLQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxLQUFBLElBQUksUUFBUyxlQUFjLE9BQ3pCLEtBQUssUUFBUSxLQUFLLElBQUksZUFBZSxJQUFJLENBQUM7Q0FFOUM7Q0FDQSxjQUFjO0VBQ1osT0FBTyxLQUFLLGdCQUFnQixDQUFDLElBQUksS0FBSyxTQUFTLFNBQVM7R0FDdEQsSUFBSSxRQUFRLFFBQVEsWUFBWTtHQUNoQyxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsdUJBQXVCO0VBQ3JCLElBQUksaUJBQWlCLEtBQUssZ0JBQWdCLFFBQVEsU0FBUyxVQUFVO0dBQ25FLE9BQU8sTUFBTSxxQkFBcUIsSUFBSSxPQUFPO0VBQy9DLENBQUM7RUFDRCxJQUFJLGdCQUFnQixLQUFLLHVCQUF1QixFQUM5QyxVQUFVLEtBQ1osQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLGNBQWMsSUFBSTtFQUNoQixPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFRLFFBQU87R0FDeEMsTUFBTSxVQUFVLEtBQUssU0FBUztHQUM5QixXQUFXLEdBQUcsU0FBUyxHQUFHO0VBQzVCLENBQUM7Q0FDSDtDQUNBLGlCQUFpQjtFQUNmLEtBQUssZUFBYyxZQUFXO0dBQzVCLFFBQVEsVUFBVSxJQUFJO0dBQ3RCLFFBQVEsNEJBQTRCLEtBQUssbUJBQW1CO0VBQzlELENBQUM7Q0FDSDtDQUNBLGVBQWU7RUFDYixLQUFLLFFBQVEsS0FBSyxhQUFhO0NBQ2pDO0NBQ0EsYUFBYSxXQUFXO0VBQ3RCLEtBQUssTUFBTSxDQUFDLGFBQWEsWUFBWSxPQUFPLFFBQVEsS0FBSyxRQUFRLEdBQy9ELElBQUksS0FBSyxTQUFTLFdBQVcsS0FBSyxVQUFVLE9BQU8sR0FDakQsT0FBTztFQUdYLE9BQU87Q0FDVDtDQUNBLGVBQWU7RUFFYixPQUFPLEtBQUssZ0JBQWdCLENBQUUsSUFBSSxLQUFLLFNBQVMsU0FBUztHQUN2RCxJQUFJLFFBQVEsV0FBVyxLQUFLLFVBQzFCLElBQUksUUFBUSxRQUFRO0dBRXRCLE9BQU87RUFDVCxDQUFDO0NBQ0g7Q0FDQSxnQkFBZ0IsV0FBVyxJQUFJO0VBQzdCLElBQUksTUFBTTtFQUNWLEtBQUssZUFBZSxTQUFTLFNBQVM7R0FDcEMsTUFBTSxHQUFHLEtBQUssU0FBUyxJQUFJO0VBQzdCLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSx1QkFBdUI7RUFDckIsS0FBSyxNQUFNLGVBQWUsT0FBTyxLQUFLLEtBQUssUUFBUSxHQUNqRCxJQUFJLEtBQUssU0FBUyxZQUFZLENBQUMsU0FDN0IsT0FBTztFQUdYLE9BQU8sT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUMsU0FBUyxLQUFLLEtBQUs7Q0FDdkQ7Q0FDQSxNQUFNLE1BQU07RUFDVixPQUFPLGNBQWMsS0FBSyxVQUFVLElBQUksSUFBSSxLQUFLLFNBQVMsUUFBUTtDQUNwRTtBQUNGO0FBQ0EsU0FBUywwQkFBMEIsVUFBVTtDQUMzQyxNQUFNLGNBQWMsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFFBQU8sUUFBTyxJQUFJLFNBQVMsR0FBRyxDQUFDO0NBQ3pFLElBQUksWUFBWSxTQUFTLEdBQ3ZCLFFBQVEsS0FBSyxxRUFBcUUsWUFBWSxLQUFLLEdBQUcsRUFBRSxFQUFFO0FBRTlHO0FBQ0EsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxlQUFjLFlBQVcsbUJBQW1CO0FBQ2xELElBQU0sYUFBTixjQUF5QixVQUFVLENBQUM7QUFDcEMsSUFBTSxnQkFBZSxZQUFXLG1CQUFtQjtBQUNuRCxJQUFNLDBCQUEwQjtDQUM5QixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsTUFBTTtBQUN0QztBQUNBLElBQU0sMkJBQTJCLFFBQVEsUUFBUSxFQUFBLENBQUc7QUFDcEQsSUFBTSxTQUFOLGNBQXFCLGlCQUFpQjtDQUVwQyxJQUFJLFlBQVk7RUFDZCxPQUFPLFVBQVUsS0FBSyxpQkFBaUI7Q0FDekM7Q0FXQSxZQUFZLFlBQVksaUJBQWlCLHNCQUFzQjtFQUM3RCxNQUFNO3dCQWZSLHdCQUFBLEtBQUEsQ0FBQTt3QkFJQSxjQUFhLGVBQWUsS0FBSyxrQkFBa0IsR0FBRyxHQUFJLFlBQVksQ0FBQyxFQUNyRSxXQUFXLGFBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQUNSLHFCQUFvQixPQUFPLE9BQU8sR0FBSSxZQUFZLENBQUMsRUFDakQsV0FBVyxvQkFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1IsK0JBQWMsSUFBSSxJQUFJLENBQUE7d0JBQ3RCLFFBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQVcsSUFBSSxhQUFhLENBQUE7d0JBQzVCLFdBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyxPQUFPLElBQUksVUFBVSxDQUFDLEdBQUcsa0JBQWtCLFVBQVUsR0FBRyx1QkFBdUIsZUFBZSxDQUFDO0NBQ3RHO0NBQ0Esa0JBQWtCO0VBQ2hCLEtBQUssbUJBQW1CO0NBQzFCO0NBQ0EsSUFBSSxnQkFBZ0I7RUFDbEIsT0FBTztDQUNUO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLENBQUM7Q0FDVjtDQUNBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSyxLQUFLO0NBQ25CO0NBQ0EsV0FBVyxLQUFLO0VBQ2Qsa0JBQWtCLFdBQVc7R0FFM0IsSUFBSSxVQURjLEtBQUssZUFBZSxJQUFJLElBQ3BCLENBQUMsQ0FBQyxnQkFBZ0IsSUFBSSxNQUFNLElBQUksT0FBTztHQUM3RCxJQUFJLGVBQWUsS0FBSyxvQkFBb0I7R0FDNUMsSUFBSSxRQUFRLHVCQUF1QixFQUNqQyxXQUFXLE1BQ2IsQ0FBQztHQUNELEtBQUssWUFBWSxJQUFJLEdBQUc7RUFDMUIsQ0FBQztDQUNIO0NBQ0EsV0FBVyxLQUFLO0VBQ2QsT0FBTyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUk7Q0FDL0I7Q0FDQSxjQUFjLEtBQUs7RUFDakIsa0JBQWtCLFdBQVc7R0FDM0IsTUFBTSxZQUFZLEtBQUssZUFBZSxJQUFJLElBQUk7R0FDOUMsY0FBQSxRQUFBLGNBQUEsS0FBQSxLQUFBLFVBQVcsY0FBYyxJQUFJLElBQUk7R0FDakMsS0FBSyxZQUFZLE9BQU8sR0FBRztFQUM3QixDQUFDO0NBQ0g7Q0FDQSxhQUFhLEtBQUs7RUFDaEIsa0JBQWtCLFdBQVc7R0FDM0IsTUFBTSxZQUFZLEtBQUssZUFBZSxJQUFJLElBQUk7R0FDOUMsTUFBTSxRQUFRLElBQUksVUFBVSxDQUFDLENBQUM7R0FDOUIsbUJBQW1CLE9BQU8sR0FBRztHQUM3QixVQUFVLGdCQUFnQixJQUFJLE1BQU0sS0FBSztHQUN6QyxNQUFNLHVCQUF1QixFQUMzQixXQUFXLE1BQ2IsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLGdCQUFnQixLQUFLO0VBQ25CLGtCQUFrQixXQUFXOztHQUMzQixNQUFNLFlBQVksS0FBSyxlQUFlLElBQUksSUFBSTtHQUM5QyxjQUFBLFFBQUEsY0FBQSxLQUFBLE1BQUEsd0JBQUEsVUFBVyxtQkFBQSxRQUFBLDBCQUFBLEtBQUEsS0FBQSxzQkFBQSxLQUFBLFdBQWdCLElBQUksSUFBSTtFQUNyQyxDQUFDO0NBQ0g7Q0FDQSxhQUFhLEtBQUs7RUFDaEIsT0FBTyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUk7Q0FDL0I7Q0FDQSxZQUFZLEtBQUssT0FBTztFQUN0QixrQkFBa0IsV0FBVztHQUUzQixLQURrQixLQUFLLElBQUksSUFBSSxJQUM1QixDQUFDLENBQUMsU0FBUyxLQUFLO0VBQ3JCLENBQUM7Q0FDSDtDQUNBLFNBQVMsT0FBTztFQUNkLEtBQUssUUFBUSxTQUFTLEtBQUs7Q0FDN0I7Q0FDQSxTQUFTLFFBQVE7O0VBQ2YsS0FBSyxrQkFBa0IsSUFBSSxJQUFJO0VBQy9CLG9CQUFvQixLQUFLLE1BQU0sS0FBSyxXQUFXO0VBQy9DLEtBQUssU0FBUyxLQUFLLE1BQU07RUFDekIsS0FBSyxLQUFLLFFBQVEsS0FBSyxJQUFJLG1CQUFtQixLQUFLLE9BQU8sQ0FBQztFQUMzRCxRQUFBLFdBQUEsUUFBQSxXQUFBLEtBQUEsTUFBQSxpQkFBTyxPQUFRLFlBQUEsUUFBQSxtQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLGVBQVEsWUFBVztDQUNwQztDQUNBLFVBQVU7RUFDUixLQUFLLFVBQVU7Q0FDakI7Q0FDQSxVQUFVLFFBQVEsS0FBQSxHQUFXO0VBQzNCLEtBQUssS0FBSyxNQUFNLEtBQUs7RUFDckIsS0FBSyxrQkFBa0IsSUFBSSxLQUFLO0NBQ2xDO0NBQ0EscUJBQXFCO0VBQ25CLElBQUksS0FBSyxXQUFXLEtBQUssUUFBUSxZQUFZLE1BQzNDLEtBQUssS0FBSyxZQUFZLEtBQUssUUFBUTtDQUV2QztDQUNBLGVBQWUsTUFBTTtFQUNuQixLQUFLLElBQUk7RUFDVCxPQUFPLEtBQUssU0FBUyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSztDQUNsRDtBQTJCRjs7d0JBMUJTLFFBQU8sU0FBUyxlQUFlLG1CQUFtQjtDQUV2RCxPQUFPLEtBQUsscUJBQXFCdUIsU0FBUTFCLGtCQUFxQixlQUFlLEVBQUUsR0FBR0Esa0JBQXFCLHFCQUFxQixFQUFFLEdBQUdBLGtCQUFxQix5QkFBeUIsQ0FBQyxDQUFDO0FBQ25MLENBQUE7d0JBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU0wQjtDQUNOLFdBQVc7RUFBQztHQUFDO0dBQVE7R0FBRztHQUFZO0dBQUk7R0FBRztHQUFhO0dBQUk7R0FBRztHQUFhO0VBQUU7RUFBRyxDQUFDLFNBQVM7RUFBRztHQUFDO0dBQUk7R0FBVTtFQUFFO0NBQUM7Q0FDaEgsY0FBYyxTQUFTLG9CQUFvQixJQUFJLEtBQUs7RUFDbEQsSUFBSSxLQUFLLEdBQ1AsV0FBYyxVQUFVLFNBQVMsaUNBQWlDLFFBQVE7R0FDeEUsT0FBTyxJQUFJLFNBQVMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxTQUFTLFNBQVMsa0NBQWtDO0dBQ3JELE9BQU8sSUFBSSxRQUFRO0VBQ3JCLENBQUM7Q0FFTDtDQUNBLFFBQVEsRUFDTixTQUFTO0VBQUM7RUFBRztFQUFpQjtDQUFTLEVBQ3pDO0NBQ0EsU0FBUyxFQUNQLFVBQVUsV0FDWjtDQUNBLFVBQVUsQ0FBQyxRQUFRO0NBQ25CLFlBQVk7Q0FDWixVQUFVLENBQUNsQixtQkFBc0IsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDNUYsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQixRQUFRLENBQUM7RUFDL0UsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUMsdUJBQXVCO0dBQ25DLE1BQU07SUFDSixZQUFZO0lBQ1osV0FBVztHQUNiO0dBQ0EsU0FBUyxDQUFDLFVBQVU7R0FDcEIsVUFBVTtHQUNWLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTO0VBQUM7R0FDVCxNQUFNLEtBQUE7R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHO0tBQ0QsTUFBTTtLQUNOLE1BQU0sQ0FBQyxhQUFhO0lBQ3RCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsbUJBQW1CO0lBQzVCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUc7SUFDRCxNQUFNO0lBQ04sTUFBTSxDQUFDLHVCQUF1QjtHQUNoQyxDQUFDO0VBQ0g7Q0FBQyxHQUFHLEVBQ0YsU0FBUyxDQUFDO0VBQ1IsTUFBTTtFQUNOLE1BQU0sQ0FBQyxlQUFlO0NBQ3hCLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsU0FBUyxlQUFlLE1BQU0sSUFBSTtDQUNoQyxNQUFNLFFBQVEsS0FBSyxRQUFRLEVBQUU7Q0FDN0IsSUFBSSxRQUFRLElBQUksS0FBSyxPQUFPLE9BQU8sQ0FBQztBQUN0QztBQUNBLFNBQVMsbUJBQW1CLFdBQVc7Q0FDckMsT0FBTyxPQUFPLGNBQWMsWUFBWSxjQUFjLFFBQVEsT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFdBQVcsS0FBSyxXQUFXLGFBQWEsY0FBYztBQUM3STtBQUNBLElBQU0sY0FBYyxNQUFNLG9CQUFvQixnQkFBZ0I7Q0FLNUQsWUFBWSxZQUFZLE1BQU0saUJBQWlCLGdCQUFnQjtFQUM3RCxNQUFNLGVBQWUsZUFBZSxHQUFHLG9CQUFvQixnQkFBZ0IsZUFBZSxDQUFDO3dCQUw3RixnQkFBZSxJQUFBO3dCQUNmLGFBQVksQ0FBQyxDQUFBO3dCQUNiLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBaUIsS0FBQTtFQUdmLEtBQUssZ0JBQWdCLFNBQVM7RUFDOUIsS0FBSyxtQkFBbUIsZUFBZTtFQUN2QyxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLHVCQUF1QjtHQUMxQixVQUFVO0dBQ1YsV0FBVyxDQUFDLENBQUMsS0FBSztFQUNwQixDQUFDO0VBQ0QsSUFBSSxhQUFhLGVBQWUsTUFBTSxnQkFBZ0IsZUFBZSxnQkFBZ0Isd0JBQ25GLElBQUksbUJBQW1CLFNBQVMsR0FDOUIsS0FBSyxlQUFlLFVBQVU7T0FFOUIsS0FBSyxlQUFlO0NBRzFCO0NBQ0EsU0FBUyxPQUFPLFVBQVUsQ0FBQyxHQUFHO0VBQzVCLGdCQUFnQjtHQUNkLEtBQUssUUFBUSxLQUFLLGdCQUFnQjtHQUNsQyxJQUFJLEtBQUssVUFBVSxVQUFVLFFBQVEsMEJBQTBCLE9BQzdELEtBQUssVUFBVSxTQUFRLGFBQVksU0FBUyxLQUFLLE9BQU8sUUFBUSwwQkFBMEIsS0FBSyxDQUFDO0dBRWxHLEtBQUssdUJBQXVCLE9BQU87RUFDckMsQ0FBQztDQUNIO0NBQ0EsV0FBVyxPQUFPLFVBQVUsQ0FBQyxHQUFHO0VBQzlCLEtBQUssU0FBUyxPQUFPLE9BQU87Q0FDOUI7Q0FDQSxNQUFNLFlBQVksS0FBSyxjQUFjLFVBQVUsQ0FBQyxHQUFHO0VBQ2pELEtBQUssZ0JBQWdCLFNBQVM7RUFDOUIsS0FBSyxlQUFlLE9BQU87RUFDM0IsS0FBSyxnQkFBZ0IsT0FBTztFQUM1QixLQUFLLFNBQVMsS0FBSyxPQUFPLE9BQU87RUFDakMsSUFBSSxRQUFRLHVCQUNWLEtBQUssZUFBZSxLQUFLO0VBRTNCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUEsWUFBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLEtBQUEsSUFBSSxRQUFTLGVBQWMsT0FDekIsS0FBSyxRQUFRLEtBQUssSUFBSSxlQUFlLElBQUksQ0FBQztDQUU5QztDQUNBLGVBQWUsQ0FBQztDQUNoQixhQUFhLFdBQVc7RUFDdEIsT0FBTztDQUNUO0NBQ0EsdUJBQXVCO0VBQ3JCLE9BQU8sS0FBSztDQUNkO0NBQ0EsaUJBQWlCLElBQUk7RUFDbkIsS0FBSyxVQUFVLEtBQUssRUFBRTtDQUN4QjtDQUNBLG9CQUFvQixJQUFJO0VBQ3RCLGVBQWUsS0FBSyxXQUFXLEVBQUU7Q0FDbkM7Q0FDQSx5QkFBeUIsSUFBSTtFQUMzQixLQUFLLGtCQUFrQixLQUFLLEVBQUU7Q0FDaEM7Q0FDQSw0QkFBNEIsSUFBSTtFQUM5QixlQUFlLEtBQUssbUJBQW1CLEVBQUU7Q0FDM0M7Q0FDQSxjQUFjLElBQUksQ0FBQztDQUNuQix1QkFBdUI7RUFDckIsSUFBSSxLQUFLLGFBQWEsVUFBVTtHQUM5QixJQUFJLEtBQUssZUFBZSxLQUFLLFlBQVk7R0FDekMsSUFBSSxLQUFLLGlCQUFpQixLQUFLLGNBQWM7R0FDN0MsSUFBSSxLQUFLLGdCQUFnQjtJQUN2QixLQUFLLFNBQVMsS0FBSyxlQUFlO0tBQ2hDLFVBQVU7S0FDVix1QkFBdUI7SUFDekIsQ0FBQztJQUNELE9BQU87R0FDVDtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLFdBQVc7RUFDekIsSUFBSSxtQkFBbUIsU0FBUyxHQUFHO0dBQ2pDLEtBQUssUUFBUSxLQUFLLGdCQUFnQixVQUFVO0dBQzVDLFVBQVUsV0FBVyxLQUFLLFFBQVE7SUFDaEMsVUFBVTtJQUNWLFdBQVc7R0FDYixDQUFDLElBQUksS0FBSyxPQUFPO0lBQ2YsVUFBVTtJQUNWLFdBQVc7R0FDYixDQUFDO0VBQ0gsT0FDRSxLQUFLLFFBQVEsS0FBSyxnQkFBZ0I7Q0FFdEM7QUFDRjtBQUNBLElBQU0scUJBQXFCO0FBQzNCLElBQU0saUJBQWdCLFlBQVcsbUJBQW1CO0FBQ3BELElBQU0sNkJBQU4sY0FBeUMsaUJBQWlCOzs7d0JBQ3hELFdBQUEsS0FBQSxDQUFBOztDQUNBLFdBQVc7RUFDVCxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGNBQWMsYUFBYSxJQUFJO0NBQ3RDO0NBQ0EsY0FBYzs7RUFDWixDQUFBLHNCQUFBLEtBQUssbUJBQUEsUUFBQSx3QkFBQSxLQUFBLEtBQUEsb0JBQWUsZ0JBQWdCLElBQUk7Q0FDMUM7Q0FDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssY0FBYyxhQUFhLElBQUk7Q0FDN0M7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLFlBQVksS0FBSyxRQUFRLE9BQU8sS0FBSyxPQUFPLEtBQUssS0FBSyxTQUFTLEdBQUcsS0FBSyxPQUFPO0NBQ3ZGO0NBQ0EsSUFBSSxnQkFBZ0I7RUFDbEIsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLGdCQUFnQjtDQUNyRDtDQUNBLG1CQUFtQixDQUFDO0FBWXRCOzs0Q0FYUyxRQUFzQix1QkFBTztDQUNsQyxJQUFJO0NBQ0osT0FBTyxTQUFTLG1DQUFtQyxtQkFBbUI7RUFDcEUsUUFBUSw0Q0FBNEMsMENBQTBDQyxzQkFBeUJ1QiwyQkFBMEIsR0FBQSxDQUFJLHFCQUFxQkEsMkJBQTBCO0NBQ3RNO0FBQ0YsRUFBQSxDQUFHLENBQUE7NENBQ0ksUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1BO0NBQ04sWUFBWTtDQUNaLFVBQVUsQ0FBQ3JCLDBCQUE2QjtBQUMxQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLDRCQUE0QixDQUFDO0VBQ25HLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxZQUFZLE1BQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyx1QkFBdUI7Q0FDOUIsT0FBTyxJQUFJVSxhQUFjLE1BQU07Ozs7TUFJM0IsdUJBQXVCOzs7Ozs7TUFNdkIsNkJBQTZCO0FBQ25DO0FBQ0EsU0FBUyx5QkFBeUI7Q0FDaEMsT0FBTyxJQUFJQSxhQUFjLE1BQU07Ozs7O01BSzNCLHFCQUFxQjs7OztNQUlyQixxQkFBcUI7QUFDM0I7QUFDQSxTQUFTLHVCQUF1QjtDQUM5QixPQUFPLElBQUlBLGFBQWMsTUFBTTs7Ozs0RkFJMkQ7QUFDNUY7QUFDQSxTQUFTLDRCQUE0QjtDQUNuQyxPQUFPLElBQUlBLGFBQWMsTUFBTTs7Ozs7TUFLM0IscUJBQXFCOzs7O01BSXJCLHFCQUFxQjtBQUMzQjtBQUNBLElBQU0scUJBQXFCO0NBQ3pCLFNBQVM7Q0FDVCxhQUFhLGlCQUFpQixZQUFZO0FBQzVDO0FBQ0EsSUFBTSxlQUFOLE1BQU0scUJBQXFCLDJCQUEyQjtDQUVwRCxZQUFZLFFBQVEsWUFBWSxpQkFBaUI7RUFDL0MsTUFBTTt3QkFGUixRQUFPLEVBQUE7RUFHTCxLQUFLLFVBQVU7RUFDZixLQUFLLGVBQWUsVUFBVTtFQUM5QixLQUFLLG9CQUFvQixlQUFlO0NBQzFDO0NBQ0EsbUJBQW1CO0VBQ2pCLElBQUksRUFBRSxLQUFLLG1CQUFtQixpQkFBaUIsRUFBRSxLQUFLLG1CQUFtQixZQUFZLE9BQU8sY0FBYyxlQUFlLFlBQ3ZILE1BQU0sMEJBQTBCO0NBRXBDO0FBZUY7OzhCQWRTLFFBQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0NBRTdELE9BQU8sS0FBSyxxQkFBcUJlLGVBQWM1QixrQkFBcUIsa0JBQWtCLENBQUMsR0FBR0Esa0JBQXFCLGVBQWUsRUFBRSxHQUFHQSxrQkFBcUIscUJBQXFCLEVBQUUsQ0FBQztBQUNsTCxDQUFBOzhCQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNNEI7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFJO0VBQWdCO0NBQUUsQ0FBQztDQUNwQyxRQUFRLEVBQ04sTUFBTTtFQUFDO0VBQUc7RUFBZ0I7Q0FBTSxFQUNsQztDQUNBLFVBQVUsQ0FBQyxjQUFjO0NBQ3pCLFlBQVk7Q0FDWixVQUFVLENBQUNwQixtQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDdkYsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUMsa0JBQWtCO0dBQzlCLFVBQVU7R0FDVixZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsU0FBUztFQUFDO0dBQ1QsTUFBTTtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sS0FDUixHQUFHLEVBQ0QsTUFBTSxTQUNSLENBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsYUFBYTtJQUN0QjtHQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVk7SUFBQyxFQUNYLE1BQU0sU0FDUjtJQUFHLEVBQ0QsTUFBTSxLQUNSO0lBQUc7S0FDRCxNQUFNO0tBQ04sTUFBTSxDQUFDLG1CQUFtQjtJQUM1QjtHQUFDO0VBQ0g7Q0FBQyxHQUFHLEVBQ0YsTUFBTSxDQUFDO0VBQ0wsTUFBTTtFQUNOLE1BQU0sQ0FBQyxjQUFjO0NBQ3ZCLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSx1QkFBdUI7Q0FDM0IsU0FBUztDQUNULGFBQWEsaUJBQWlCLE9BQU87QUFDdkM7QUFDQSxJQUFNLHlCQUF5QixRQUFRLFFBQVEsRUFBQSxDQUFHO0FBQ2xELElBQU0sVUFBTixjQUFzQixVQUFVO0NBWTlCLFlBQVksUUFBUSxZQUFZLGlCQUFpQixnQkFBZ0Isb0JBQW9CLHNCQUFzQixVQUFVLFVBQVU7RUFDN0gsTUFBTSxVQUFVLFVBQVUsY0FBYzt3QkFaMUMsc0JBQUEsS0FBQSxDQUFBO3dCQUNBLHdCQUFBLEtBQUEsQ0FBQTt3QkFDQSxXQUFVLElBQUksWUFBWSxDQUFBO3dCQUUxQixlQUFjLEtBQUE7d0JBQ2QsYUFBQSxLQUFBLENBQUE7d0JBQ0EsUUFBTyxFQUFBO3dCQUNQLGNBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQVMsSUFBSSxhQUFhLENBQUE7RUFHeEIsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxlQUFlLFVBQVU7RUFDOUIsS0FBSyxvQkFBb0IsZUFBZTtDQUMxQztDQUNBLFlBQVksU0FBUztFQUNuQixLQUFLLGdCQUFnQjtFQUNyQixJQUFJLENBQUMsS0FBSyxlQUFlLFVBQVUsU0FBUztHQUMxQyxJQUFJLEtBQUssYUFBYTtJQUNwQixLQUFLLFdBQVc7SUFDaEIsSUFBSSxLQUFLLGVBQWU7S0FDdEIsTUFBTSxVQUFVLFFBQVEsT0FBTyxDQUFDO0tBQ2hDLEtBQUssY0FBYyxjQUFjO01BQy9CLE1BQU07TUFDTixNQUFNLEtBQUssU0FBUyxPQUFPO0tBQzdCLENBQUM7SUFDSDtHQUNGO0dBQ0EsS0FBSyxjQUFjO0VBQ3JCO0VBQ0EsSUFBSSxnQkFBZ0IsU0FDbEIsS0FBSyxnQkFBZ0IsT0FBTztFQUU5QixJQUFJLGtCQUFrQixTQUFTLEtBQUssU0FBUyxHQUFHO0dBQzlDLEtBQUssYUFBYSxLQUFLLEtBQUs7R0FDNUIsS0FBSyxZQUFZLEtBQUs7RUFDeEI7Q0FDRjtDQUNBLGNBQWM7O0VBQ1osQ0FBQSx1QkFBQSxLQUFLLG1CQUFBLFFBQUEseUJBQUEsS0FBQSxLQUFBLHFCQUFlLGNBQWMsSUFBSTtDQUN4QztDQUNBLGlCQUFpQixNQUFNO0VBQ3JCLE1BQU0sZ0JBQWdCLElBQUk7Q0FDNUI7Q0FDQSxpQkFBaUIsTUFBTTtFQUNyQixNQUFNLGdCQUFnQixNQUFNLEtBQUs7Q0FDbkM7Q0FDQSxJQUFJLHFCQUFxQjtFQUN2QixPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssU0FBUyxLQUFLLElBQUk7Q0FDaEM7Q0FDQSxJQUFJLGdCQUFnQjtFQUNsQixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsZ0JBQWdCO0NBQ3JEO0NBQ0Esa0JBQWtCLFVBQVU7RUFDMUIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssT0FBTyxLQUFLLFFBQVE7Q0FDM0I7Q0FDQSxnQkFBZ0I7RUFDZCxLQUFLLG1CQUFtQjtFQUN4QixLQUFLLGNBQWMsSUFBSSxLQUFLLGlCQUFpQixJQUFJLEtBQUssY0FBYyxXQUFXLElBQUk7RUFDbkYsS0FBSyxjQUFjO0NBQ3JCO0NBQ0EscUJBQXFCO0VBQ25CLElBQUksS0FBSyxXQUFXLEtBQUssUUFBUSxZQUFZLE1BQzNDLEtBQUssUUFBUSxZQUFZLEtBQUssUUFBUTtDQUUxQztDQUNBLGdCQUFnQjtFQUNkLE9BQU8sQ0FBQyxLQUFLLFdBQVcsQ0FBQyxFQUFFLEtBQUssV0FBVyxLQUFLLFFBQVE7Q0FDMUQ7Q0FDQSxtQkFBbUI7RUFDakIsSUFBSSxDQUFDLEtBQUssc0JBQXNCOztHQUM5QixDQUFBLHNCQUFBLEtBQUssbUJBQUEsUUFBQSx3QkFBQSxLQUFBLE1BQUwsS0FBSyxnQkFBa0IsS0FBSztHQUM1QiwwQkFBMEIsS0FBSyxTQUFTLE1BQU0sS0FBSyxvQkFBb0I7RUFDekUsT0FDRSxLQUFLLG1CQUFtQjtFQUUxQixLQUFLLFFBQVEsdUJBQXVCLEVBQ2xDLFdBQVcsTUFDYixDQUFDO0NBQ0g7Q0FDQSxlQUFlLHNCQUFzQjtFQUNuQyxJQUFJLENBQUMsS0FBSyxzQkFBc0I7O0dBQzlCLENBQUEsdUJBQUEsS0FBSyxtQkFBQSxRQUFBLHlCQUFBLEtBQUEsTUFBTCxLQUFLLGdCQUFrQixLQUFLO0dBQzVCLDBCQUEwQixLQUFLLFNBQVMsTUFBTSxvQkFBb0I7RUFDcEUsT0FDRSxLQUFLLG1CQUFtQjtDQUU1QjtDQUNBLGtCQUFrQjtFQUNoQixLQUFLLE9BQU8sY0FBYyxlQUFlLGNBQWMsQ0FBQyxLQUFLLGNBQWMsR0FDekUsa0JBQWtCLEtBQUssT0FBTztFQUVoQyxLQUFLLFdBQVc7Q0FDbEI7Q0FDQSxhQUFhO0VBQ1gsSUFBSSxLQUFLLFdBQVcsS0FBSyxRQUFRLE1BQU0sS0FBSyxPQUFPLEtBQUssUUFBUTtFQUNoRSxJQUFJLENBQUMsS0FBSyxjQUFjLEtBQUssQ0FBQyxLQUFLLFNBQVMsT0FBTyxjQUFjLGVBQWUsWUFDOUUsTUFBTSxxQkFBcUI7Q0FFL0I7Q0FDQSxhQUFhLE9BQU87RUFDbEIsZ0JBQWdCLFdBQVc7O0dBQ3pCLEtBQUssUUFBUSxTQUFTLE9BQU8sRUFDM0IsdUJBQXVCLE1BQ3pCLENBQUM7R0FDRCxDQUFBLHdCQUFBLEtBQUssd0JBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQW9CLGFBQWE7RUFDeEMsQ0FBQztDQUNIO0NBQ0EsZ0JBQWdCLFNBQVM7RUFDdkIsTUFBTSxnQkFBZ0IsUUFBUSxhQUFhLENBQUM7RUFDNUMsTUFBTSxhQUFhLGtCQUFrQixLQUFLLGlCQUFpQixhQUFhO0VBQ3hFLGdCQUFnQixXQUFXOztHQUN6QixJQUFJLGNBQWMsQ0FBQyxLQUFLLFFBQVEsVUFDOUIsS0FBSyxRQUFRLFFBQVE7UUFDaEIsSUFBSSxDQUFDLGNBQWMsS0FBSyxRQUFRLFVBQ3JDLEtBQUssUUFBUSxPQUFPO0dBRXRCLENBQUEseUJBQUEsS0FBSyx3QkFBQSxRQUFBLDJCQUFBLEtBQUEsS0FBQSx1QkFBb0IsYUFBYTtFQUN4QyxDQUFDO0NBQ0g7Q0FDQSxTQUFTLGFBQWE7RUFDcEIsT0FBTyxLQUFLLFVBQVUsWUFBWSxhQUFhLEtBQUssT0FBTyxJQUFJLENBQUMsV0FBVztDQUM3RTtBQXFCRjs7eUJBcEpTLGdDQUFBLEtBQUEsQ0FBQTt5QkFnSUEsUUFBTyxTQUFTLGdCQUFnQixtQkFBbUI7Q0FFeEQsT0FBTyxLQUFLLHFCQUFxQjBCLFVBQVM3QixrQkFBcUIsa0JBQWtCLENBQUMsR0FBR0Esa0JBQXFCLGVBQWUsRUFBRSxHQUFHQSxrQkFBcUIscUJBQXFCLEVBQUUsR0FBR0Esa0JBQXFCLG1CQUFtQixFQUFFLEdBQUdBLGtCQUFxQixtQkFBbUIsQ0FBQyxHQUFHQSxrQkFBcUIseUJBQXlCLENBQUMsR0FBR0Esa0JBQXFCOEIsVUFBYSxDQUFDLEdBQUc5QixrQkFBcUJDLFdBQWMsQ0FBQyxDQUFDO0FBQ3JZLENBQUE7eUJBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU00QjtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQUk7RUFBVztFQUFJO0VBQUc7RUFBbUI7RUFBSTtFQUFHO0VBQWU7Q0FBRSxDQUFDO0NBQy9FLFFBQVE7RUFDTixNQUFNO0VBQ04sWUFBWTtHQUFDO0dBQUc7R0FBWTtFQUFZO0VBQ3hDLE9BQU87R0FBQztHQUFHO0dBQVc7RUFBTztFQUM3QixTQUFTO0dBQUM7R0FBRztHQUFrQjtFQUFTO0NBQzFDO0NBQ0EsU0FBUyxFQUNQLFFBQVEsZ0JBQ1Y7Q0FDQSxVQUFVLENBQUMsU0FBUztDQUNwQixZQUFZO0NBQ1osVUFBVTtFQUFDckIsbUJBQXNCLENBQUMsc0JBQXNCLCtCQUErQixDQUFDO0VBQUdGO0VBQStCUztFQUF5QmdCLGlCQUFvQixJQUFJO0NBQUM7QUFDOUssQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWM1QixpQkFBcUIsU0FBUyxDQUFDO0VBQ2hGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLHNCQUFzQiwrQkFBK0I7R0FDakUsVUFBVTtHQUNWLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTO0VBQUM7R0FDVCxNQUFNO0dBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUcsRUFDRCxNQUFNLEtBQ1IsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHO0tBQ0QsTUFBTTtLQUNOLE1BQU0sQ0FBQyxhQUFhO0lBQ3RCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsbUJBQW1CO0lBQzVCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsaUJBQWlCO0lBQzFCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTTZCO0dBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUc7SUFDRCxNQUFNO0lBQ04sTUFBTSxDQUFDLGlCQUFpQjtHQUMxQixDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixHQUFHO0lBQ0QsTUFBTTtJQUNOLE1BQU0sQ0FBQyx1QkFBdUI7R0FDaEMsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNRjtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU03QjtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHO0VBQ0YsTUFBTSxDQUFDLEVBQ0wsTUFBTSxNQUNSLENBQUM7RUFDRCxZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLFVBQVU7RUFDbkIsQ0FBQztFQUNELE9BQU8sQ0FBQztHQUNOLE1BQU07R0FDTixNQUFNLENBQUMsU0FBUztFQUNsQixDQUFDO0VBQ0QsU0FBUyxDQUFDO0dBQ1IsTUFBTTtHQUNOLE1BQU0sQ0FBQyxnQkFBZ0I7RUFDekIsQ0FBQztFQUNELFFBQVEsQ0FBQztHQUNQLE1BQU07R0FDTixNQUFNLENBQUMsZUFBZTtFQUN4QixDQUFDO0NBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILFNBQVMsa0JBQWtCLFFBQVE7Q0FDakMsSUFBSSxFQUFFLGtCQUFrQixpQkFBaUIsa0JBQWtCLDRCQUN6RCxNQUFNLHVCQUF1QjtNQUN4QixJQUFJLEVBQUUsa0JBQWtCLGlCQUFpQixFQUFFLGtCQUFrQixTQUNsRSxNQUFNLHFCQUFxQjtBQUUvQjtBQUNBLElBQU0sZ0JBQU4sTUFBb0IsQ0FVcEI7OytCQVRTLFFBQU8sU0FBUyxzQkFBc0IsbUJBQW1CO0NBQzlELE9BQU8sS0FBSyxxQkFBcUJnQyxnQkFBZTtBQUNsRCxDQUFBOytCQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQVE7RUFBRztFQUFZO0VBQUk7RUFBRztFQUFvQjtDQUFFLENBQUM7Q0FDbEUsV0FBVyxDQUFDLGNBQWMsRUFBRTtDQUM1QixZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWM5QixpQkFBcUIsZUFBZSxDQUFDO0VBQ3RGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsTUFBTSxFQUNKLGNBQWMsR0FDaEI7R0FDQSxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSx3QkFBd0I7Q0FDNUIsU0FBUztDQUNULGFBQWEsaUJBQWlCLG1CQUFtQjtDQUNqRCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLHNCQUFOLGNBQWtDLDRCQUE0QjtDQUM1RCxXQUFXLE9BQU87RUFDaEIsTUFBTSxrQkFBa0IsU0FBUyxPQUFPLEtBQUs7RUFDN0MsS0FBSyxZQUFZLFNBQVMsZUFBZTtDQUMzQztDQUNBLGlCQUFpQixJQUFJO0VBQ25CLEtBQUssWUFBVyxVQUFTO0dBQ3ZCLEdBQUcsU0FBUyxLQUFLLE9BQU8sV0FBVyxLQUFLLENBQUM7RUFDM0M7Q0FDRjtBQXNCRjs7cUNBckJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsNEJBQTRCLG1CQUFtQjtFQUM3RCxRQUFRLHFDQUFxQyxtQ0FBbUNDLHNCQUF5QjhCLG9CQUFtQixHQUFBLENBQUkscUJBQXFCQSxvQkFBbUI7Q0FDMUs7QUFDRixFQUFBLENBQUcsQ0FBQTtxQ0FDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFTO0dBQVE7R0FBVTtHQUFtQjtHQUFJO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFTO0dBQVE7R0FBVTtHQUFlO0dBQUk7R0FBRztHQUFXO0VBQUU7RUFBRztHQUFDO0dBQVM7R0FBUTtHQUFVO0dBQVc7R0FBSTtHQUFHO0dBQVc7RUFBRTtDQUFDO0NBQ2hOLGNBQWMsU0FBUyxpQ0FBaUMsSUFBSSxLQUFLO0VBQy9ELElBQUksS0FBSyxHQUNQLFdBQWMsU0FBUyxTQUFTLDZDQUE2QyxRQUFRO0dBQ25GLE9BQU8sSUFBSSxTQUFTLE9BQU8sT0FBTyxLQUFLO0VBQ3pDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyw4Q0FBOEM7R0FDaEUsT0FBTyxJQUFJLFVBQVU7RUFDdkIsQ0FBQztDQUVMO0NBQ0EsWUFBWTtDQUNaLFVBQVUsQ0FBQzFCLG1CQUFzQixDQUFDLHFCQUFxQixDQUFDLEdBQUdGLDBCQUE2QjtBQUMxRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLHFCQUFxQixDQUFDO0VBQzVGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsTUFBTTtJQUNKLFdBQVc7SUFDWCxVQUFVO0dBQ1o7R0FDQSxXQUFXLENBQUMscUJBQXFCO0dBQ2pDLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLHVCQUF1QjtDQUMzQixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIseUJBQXlCO0NBQ3ZELE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCO0NBQ3hCLE1BQU0sSUFBSVUsYUFBYyxNQUFNOzs7S0FHM0I7QUFDTDtBQUNBLElBQU0sdUJBQU4sTUFBMkI7O3dCQUN6QixjQUFhLENBQUMsQ0FBQTs7Q0FDZCxJQUFJLFNBQVMsVUFBVTtFQUNyQixLQUFLLFdBQVcsS0FBSyxDQUFDLFNBQVMsUUFBUSxDQUFDO0NBQzFDO0NBQ0EsT0FBTyxVQUFVO0VBQ2YsS0FBSyxJQUFJLElBQUksS0FBSyxXQUFXLFNBQVMsR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUNqRCxJQUFJLEtBQUssV0FBVyxFQUFFLENBQUMsT0FBTyxVQUFVO0dBQ3RDLEtBQUssV0FBVyxPQUFPLEdBQUcsQ0FBQztHQUMzQjtFQUNGO0NBRUo7Q0FDQSxPQUFPLFVBQVU7RUFDZixLQUFLLFdBQVcsU0FBUSxNQUFLO0dBQzNCLElBQUksS0FBSyxhQUFhLEdBQUcsUUFBUSxLQUFLLEVBQUUsT0FBTyxVQUM3QyxFQUFFLEVBQUUsQ0FBQyxZQUFZLFNBQVMsS0FBSztFQUVuQyxDQUFDO0NBQ0g7Q0FDQSxhQUFhLGFBQWEsVUFBVTtFQUNsQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsU0FBUyxPQUFPO0VBQ3BDLE9BQU8sWUFBWSxFQUFFLENBQUMsWUFBWSxTQUFTLFNBQVMsV0FBVyxZQUFZLEVBQUUsQ0FBQyxTQUFTLFNBQVM7Q0FDbEc7QUFRRjs7c0NBUFMsUUFBTyxTQUFTLDZCQUE2QixtQkFBbUI7Q0FDckUsT0FBTyxLQUFLLHFCQUFxQnNCLHVCQUFzQjtBQUN6RCxDQUFBO3NDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLHNCQUFxQjtBQUNoQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2hDLGlCQUFxQixzQkFBc0IsQ0FBQyxFQUM3RixNQUFNLFFBQ1IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLDRCQUFOLGNBQXdDLDRCQUE0QjtDQWNsRSxZQUFZLFVBQVUsWUFBWSxXQUFXLFdBQVc7O0VBQ3RELE1BQU0sVUFBVSxVQUFVO3dCQWQ1QixhQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxPQUFBLEtBQUEsQ0FBQTt3QkFDQSx5QkFBd0IsS0FBQTt3QkFDeEIsa0JBQWlCLENBQUMsQ0FBQTt3QkFDbEIsUUFBQSxLQUFBLENBQUE7d0JBQ0EsbUJBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLHlCQUFBLFVBQXVCLE9BQU8seUJBQXlCLEVBQ3JELFVBQVUsS0FDWixDQUFDLE9BQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxVQUFLLHVCQUFBO0VBR0osS0FBSyxZQUFZO0VBQ2pCLEtBQUssWUFBWTtDQUNuQjtDQUNBLFlBQVksU0FBUzs7RUFDbkIsTUFBTSxXQUFBLGlCQUFVLEtBQUssY0FBQSxRQUFBLG1CQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsZUFBVTtFQUMvQixJQUFJLFFBQVEsWUFBWSxTQUN0QixLQUFLLFdBQVcsUUFBUSxLQUFLO0NBRWpDO0NBQ0EsV0FBVztFQUNULEtBQUssV0FBVyxLQUFLLFVBQVUsSUFBSSxTQUFTO0VBQzVDLEtBQUssV0FBVztFQUNoQixLQUFLLFVBQVUsSUFBSSxLQUFLLFVBQVUsSUFBSTtDQUN4QztDQUNBLGNBQWM7RUFDWixLQUFLLFVBQVUsT0FBTyxJQUFJO0NBQzVCO0NBQ0EsV0FBVyxPQUFPO0VBQ2hCLEtBQUssU0FBUyxVQUFVLEtBQUs7RUFDN0IsS0FBSyxZQUFZLFdBQVcsS0FBSyxNQUFNO0NBQ3pDO0NBQ0EsaUJBQWlCLElBQUk7RUFDbkIsS0FBSyxNQUFNO0VBQ1gsS0FBSyxpQkFBaUI7R0FDcEIsR0FBRyxLQUFLLEtBQUs7R0FDYixLQUFLLFVBQVUsT0FBTyxJQUFJO0VBQzVCO0NBQ0Y7Q0FDQSxpQkFBaUIsWUFBWTtFQUMzQixJQUFJLEtBQUsseUJBQXlCLGNBQWMsS0FBSyx5QkFBeUIsNkJBQzVFLEtBQUssWUFBWSxZQUFZLFVBQVU7RUFFekMsS0FBSyx3QkFBd0I7Q0FDL0I7Q0FDQSxZQUFZLE9BQU87RUFDakIsS0FBSyxXQUFXLEtBQUs7Q0FDdkI7Q0FDQSxhQUFhO0VBQ1gsSUFBSSxLQUFLLFFBQVEsS0FBSyxtQkFBbUIsS0FBSyxTQUFTLEtBQUssb0JBQW9CLE9BQU8sY0FBYyxlQUFlLFlBQ2xILGVBQWU7RUFFakIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLGlCQUFpQixLQUFLLE9BQU8sS0FBSztDQUMzRDtBQXlCRjs7MkNBeEJTLFFBQU8sU0FBUyxrQ0FBa0MsbUJBQW1CO0NBRTFFLE9BQU8sS0FBSyxxQkFBcUJpQyw0QkFBMkJwQyxrQkFBcUJDLFNBQVksR0FBR0Qsa0JBQXFCRSxVQUFhLEdBQUdGLGtCQUFxQixvQkFBb0IsR0FBR0Esa0JBQXFCOEIsUUFBVyxDQUFDO0FBQ3BOLENBQUE7MkNBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1NO0NBQ04sV0FBVztFQUFDO0dBQUM7R0FBUztHQUFRO0dBQVM7R0FBbUI7R0FBSTtHQUFHO0dBQVc7RUFBRTtFQUFHO0dBQUM7R0FBUztHQUFRO0dBQVM7R0FBZTtHQUFJO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFTO0dBQVE7R0FBUztHQUFXO0dBQUk7R0FBRztHQUFXO0VBQUU7Q0FBQztDQUM3TSxjQUFjLFNBQVMsdUNBQXVDLElBQUksS0FBSztFQUNyRSxJQUFJLEtBQUssR0FDUCxXQUFjLFVBQVUsU0FBUyxzREFBc0Q7R0FDckYsT0FBTyxJQUFJLFNBQVM7RUFDdEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLG9EQUFvRDtHQUN0RSxPQUFPLElBQUksVUFBVTtFQUN2QixDQUFDO0NBRUw7Q0FDQSxRQUFRO0VBQ04sTUFBTTtFQUNOLGlCQUFpQjtFQUNqQixPQUFPO0NBQ1Q7Q0FDQSxZQUFZO0NBQ1osVUFBVTtFQUFDNUIsbUJBQXNCLENBQUMsb0JBQW9CLENBQUM7RUFBR0Y7RUFBK0JTO0NBQXVCO0FBQ2xILENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjWixpQkFBcUIsMkJBQTJCLENBQUM7RUFDbEcsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixNQUFNO0lBQ0osWUFBWTtJQUNaLFVBQVU7R0FDWjtHQUNBLFdBQVcsQ0FBQyxvQkFBb0I7R0FDaEMsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVM7RUFBQyxFQUNULE1BQU1GLFVBQ1I7RUFBRyxFQUNELE1BQU1DLFdBQ1I7RUFBRyxFQUNELE1BQU0scUJBQ1I7RUFBRyxFQUNELE1BQU00QixTQUNSO0NBQUMsR0FBRztFQUNGLE1BQU0sQ0FBQyxFQUNMLE1BQU0sTUFDUixDQUFDO0VBQ0QsaUJBQWlCLENBQUMsRUFDaEIsTUFBTSxNQUNSLENBQUM7RUFDRCxPQUFPLENBQUMsRUFDTixNQUFNLE1BQ1IsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLHVCQUF1QjtDQUMzQixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsa0JBQWtCO0NBQ2hELE9BQU87QUFDVDtBQUNBLElBQU0scUJBQU4sY0FBaUMsNEJBQTRCO0NBQzNELFdBQVcsT0FBTztFQUNoQixLQUFLLFlBQVksU0FBUyxXQUFXLEtBQUssQ0FBQztDQUM3QztDQUNBLGlCQUFpQixJQUFJO0VBQ25CLEtBQUssWUFBVyxVQUFTO0dBQ3ZCLEdBQUcsU0FBUyxLQUFLLE9BQU8sV0FBVyxLQUFLLENBQUM7RUFDM0M7Q0FDRjtBQXdCRjs7b0NBdkJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsMkJBQTJCLG1CQUFtQjtFQUM1RCxRQUFRLG9DQUFvQyxrQ0FBa0MxQixzQkFBeUJpQyxtQkFBa0IsR0FBQSxDQUFJLHFCQUFxQkEsbUJBQWtCO0NBQ3RLO0FBQ0YsRUFBQSxDQUFHLENBQUE7b0NBQ0ksUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1BO0NBQ04sV0FBVztFQUFDO0dBQUM7R0FBUztHQUFRO0dBQVM7R0FBbUI7R0FBSTtHQUFHO0dBQVc7RUFBRTtFQUFHO0dBQUM7R0FBUztHQUFRO0dBQVM7R0FBZTtHQUFJO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFTO0dBQVE7R0FBUztHQUFXO0dBQUk7R0FBRztHQUFXO0VBQUU7Q0FBQztDQUM3TSxjQUFjLFNBQVMsZ0NBQWdDLElBQUksS0FBSztFQUM5RCxJQUFJLEtBQUssR0FDUCxXQUFjLFVBQVUsU0FBUyw2Q0FBNkMsUUFBUTtHQUNwRixPQUFPLElBQUksU0FBUyxPQUFPLE9BQU8sS0FBSztFQUN6QyxDQUFDLENBQUMsQ0FBQyxTQUFTLFNBQVMsNENBQTRDLFFBQVE7R0FDdkUsT0FBTyxJQUFJLFNBQVMsT0FBTyxPQUFPLEtBQUs7RUFDekMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLDZDQUE2QztHQUMvRCxPQUFPLElBQUksVUFBVTtFQUN2QixDQUFDO0NBRUw7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDN0IsbUJBQXNCLENBQUMsb0JBQW9CLENBQUMsR0FBR0YsMEJBQTZCO0FBQ3pGLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsb0JBQW9CLENBQUM7RUFDM0YsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixNQUFNO0lBQ0osWUFBWTtJQUNaLFdBQVc7SUFDWCxVQUFVO0dBQ1o7R0FDQSxXQUFXLENBQUMsb0JBQW9CO0dBQ2hDLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLFlBQU4sY0FBd0IsZ0JBQWdCO0NBQ3RDLFlBQVksVUFBVSxpQkFBaUIsZ0JBQWdCO0VBQ3JELE1BQU0sZUFBZSxlQUFlLEdBQUcsb0JBQW9CLGdCQUFnQixlQUFlLENBQUM7d0JBVTdGLFlBQUEsS0FBQSxDQUFBO0VBVEUsS0FBSyxXQUFXO0VBQ2hCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssbUJBQW1CLGVBQWU7RUFDdkMsS0FBSyxlQUFlO0VBQ3BCLEtBQUssdUJBQXVCO0dBQzFCLFVBQVU7R0FDVixXQUFXLENBQUMsQ0FBQyxLQUFLO0VBQ3BCLENBQUM7Q0FDSDtDQUVBLEdBQUcsT0FBTztFQUNSLE9BQU8sS0FBSyxTQUFTLEtBQUssYUFBYSxLQUFLO0NBQzlDO0NBQ0EsS0FBSyxTQUFTLFVBQVUsQ0FBQyxHQUFHO0VBQzFCLElBQUksTUFBTSxRQUFRLE9BQU8sR0FDdkIsUUFBUSxTQUFRLFNBQVE7R0FDdEIsS0FBSyxTQUFTLEtBQUssSUFBSTtHQUN2QixLQUFLLGlCQUFpQixJQUFJO0VBQzVCLENBQUM7T0FDSTtHQUNMLEtBQUssU0FBUyxLQUFLLE9BQU87R0FDMUIsS0FBSyxpQkFBaUIsT0FBTztFQUMvQjtFQUNBLEtBQUssdUJBQXVCLEVBQzFCLFdBQVcsUUFBUSxVQUNyQixDQUFDO0VBQ0QsS0FBSyxvQkFBb0I7Q0FDM0I7Q0FDQSxPQUFPLE9BQU8sU0FBUyxVQUFVLENBQUMsR0FBRztFQUNuQyxLQUFLLFNBQVMsT0FBTyxPQUFPLEdBQUcsT0FBTztFQUN0QyxLQUFLLGlCQUFpQixPQUFPO0VBQzdCLEtBQUssdUJBQXVCLEVBQzFCLFdBQVcsUUFBUSxVQUNyQixDQUFDO0NBQ0g7Q0FDQSxTQUFTLE9BQU8sVUFBVSxDQUFDLEdBQUc7RUFDNUIsSUFBSSxnQkFBZ0IsS0FBSyxhQUFhLEtBQUs7RUFDM0MsSUFBSSxnQkFBZ0IsR0FBRyxnQkFBZ0I7RUFDdkMsSUFBSSxLQUFLLFNBQVMsZ0JBQWdCLEtBQUssU0FBUyxjQUFjLENBQUMsa0NBQWtDLENBQUMsQ0FBQztFQUNuRyxLQUFLLFNBQVMsT0FBTyxlQUFlLENBQUM7RUFDckMsS0FBSyx1QkFBdUIsRUFDMUIsV0FBVyxRQUFRLFVBQ3JCLENBQUM7Q0FDSDtDQUNBLFdBQVcsT0FBTyxTQUFTLFVBQVUsQ0FBQyxHQUFHO0VBQ3ZDLElBQUksZ0JBQWdCLEtBQUssYUFBYSxLQUFLO0VBQzNDLElBQUksZ0JBQWdCLEdBQUcsZ0JBQWdCO0VBQ3ZDLElBQUksS0FBSyxTQUFTLGdCQUFnQixLQUFLLFNBQVMsY0FBYyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7RUFDbkcsS0FBSyxTQUFTLE9BQU8sZUFBZSxDQUFDO0VBQ3JDLElBQUksU0FBUztHQUNYLEtBQUssU0FBUyxPQUFPLGVBQWUsR0FBRyxPQUFPO0dBQzlDLEtBQUssaUJBQWlCLE9BQU87RUFDL0I7RUFDQSxLQUFLLHVCQUF1QixFQUMxQixXQUFXLFFBQVEsVUFDckIsQ0FBQztFQUNELEtBQUssb0JBQW9CO0NBQzNCO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLFNBQVM7Q0FDdkI7Q0FDQSxTQUFTLE9BQU8sVUFBVSxDQUFDLEdBQUc7RUFDNUIsZ0JBQWdCO0dBQ2QsdUJBQXVCLE1BQU0sT0FBTyxLQUFLO0dBQ3pDLE1BQU0sU0FBUyxVQUFVLFVBQVU7SUFDakMscUJBQXFCLE1BQU0sT0FBTyxLQUFLO0lBQ3ZDLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxTQUFTLFVBQVU7S0FDaEMsVUFBVTtLQUNWLFdBQVcsUUFBUTtJQUNyQixDQUFDO0dBQ0gsQ0FBQztHQUNELEtBQUssdUJBQXVCLE9BQU87RUFDckMsQ0FBQztDQUNIO0NBQ0EsV0FBVyxPQUFPLFVBQVUsQ0FBQyxHQUFHO0VBQzlCLElBQUksU0FBUyxNQUFNO0VBQ25CLE1BQU0sU0FBUyxVQUFVLFVBQVU7R0FDakMsSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUNmLEtBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxXQUFXLFVBQVU7SUFDbEMsVUFBVTtJQUNWLFdBQVcsUUFBUTtHQUNyQixDQUFDO0VBRUwsQ0FBQztFQUNELEtBQUssdUJBQXVCLE9BQU87Q0FDckM7Q0FDQSxNQUFNLFFBQVEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHO0VBQzlCLEtBQUssZUFBZSxTQUFTLFVBQVU7R0FDckMsUUFBUSxNQUFNLE1BQU0sUUFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNmLE9BQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCxVQUFVLEtBQUEsQ0FDWixDQUFDO0VBQ0gsQ0FBQztFQUNELEtBQUssZ0JBQWdCLFNBQVMsSUFBSTtFQUNsQyxLQUFLLGVBQWUsU0FBUyxJQUFJO0VBQ2pDLEtBQUssdUJBQXVCLE9BQU87RUFDbkMsS0FBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFJLFFBQVMsZUFBYyxPQUN6QixLQUFLLFFBQVEsS0FBSyxJQUFJLGVBQWUsSUFBSSxDQUFDO0NBRTlDO0NBQ0EsY0FBYztFQUNaLE9BQU8sS0FBSyxTQUFTLEtBQUksWUFBVyxRQUFRLFlBQVksQ0FBQztDQUMzRDtDQUNBLE1BQU0sVUFBVSxDQUFDLEdBQUc7RUFDbEIsSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHO0VBQzlCLEtBQUssZUFBYyxZQUFXLFFBQVEsa0NBQWtDLENBQUMsQ0FBQyxDQUFDO0VBQzNFLEtBQUssU0FBUyxPQUFPLENBQUM7RUFDdEIsS0FBSyx1QkFBdUIsRUFDMUIsV0FBVyxRQUFRLFVBQ3JCLENBQUM7Q0FDSDtDQUNBLGFBQWEsT0FBTztFQUNsQixPQUFPLFFBQVEsSUFBSSxRQUFRLEtBQUssU0FBUztDQUMzQztDQUNBLHVCQUF1QjtFQUNyQixJQUFJLGlCQUFpQixLQUFLLFNBQVMsUUFBUSxTQUFTLFVBQVU7R0FDNUQsT0FBTyxNQUFNLHFCQUFxQixJQUFJLE9BQU87RUFDL0MsR0FBRyxLQUFLO0VBQ1IsSUFBSSxnQkFBZ0IsS0FBSyx1QkFBdUIsRUFDOUMsVUFBVSxLQUNaLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxjQUFjLElBQUk7RUFDaEIsS0FBSyxTQUFTLFNBQVMsU0FBUyxVQUFVO0dBQ3hDLEdBQUcsU0FBUyxLQUFLO0VBQ25CLENBQUM7Q0FDSDtDQUNBLGVBQWU7RUFDYixLQUFLLFFBQVEsS0FBSyxTQUFTLFFBQU8sWUFBVyxRQUFRLFdBQVcsS0FBSyxRQUFRLENBQUMsQ0FBQyxLQUFJLFlBQVcsUUFBUSxLQUFLO0NBQzdHO0NBQ0EsYUFBYSxXQUFXO0VBQ3RCLE9BQU8sS0FBSyxTQUFTLE1BQUssWUFBVyxRQUFRLFdBQVcsVUFBVSxPQUFPLENBQUM7Q0FDNUU7Q0FDQSxpQkFBaUI7RUFDZixLQUFLLGVBQWMsWUFBVyxLQUFLLGlCQUFpQixPQUFPLENBQUM7Q0FDOUQ7Q0FDQSx1QkFBdUI7RUFDckIsS0FBSyxNQUFNLFdBQVcsS0FBSyxVQUN6QixJQUFJLFFBQVEsU0FBUyxPQUFPO0VBRTlCLE9BQU8sS0FBSyxTQUFTLFNBQVMsS0FBSyxLQUFLO0NBQzFDO0NBQ0EsaUJBQWlCLFNBQVM7RUFDeEIsUUFBUSxVQUFVLElBQUk7RUFDdEIsUUFBUSw0QkFBNEIsS0FBSyxtQkFBbUI7Q0FDOUQ7Q0FDQSxNQUFNLE1BQU07O0VBQ1YsUUFBQSxXQUFPLEtBQUssR0FBRyxJQUFJLE9BQUEsUUFBQSxhQUFBLEtBQUEsSUFBQSxXQUFLO0NBQzFCO0FBQ0Y7QUFDQSxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGVBQWMsWUFBVyxtQkFBbUI7QUFDbEQsSUFBTSx3QkFBTixjQUFvQyxpQkFBaUI7Q0FFbkQsSUFBSSxZQUFZO0VBQ2QsT0FBTyxVQUFVLEtBQUssa0JBQWtCO0NBQzFDO0NBQ0EsSUFBSSxVQUFVLE9BQU87RUFDbkIsS0FBSyxtQkFBbUIsSUFBSSxLQUFLO0NBQ25DO0NBVUEsWUFBWSxZQUFZLGlCQUFpQixzQkFBc0I7RUFDN0QsTUFBTTt3QkFqQlIsd0JBQUEsS0FBQSxDQUFBO3dCQU9BLGNBQWEsZUFBZSxLQUFLLG1CQUFtQixHQUFHLEdBQUksWUFBWSxDQUFDLEVBQ3RFLFdBQVcsYUFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1Isc0JBQXFCLE9BQU8sT0FBTyxHQUFJLFlBQVksQ0FBQyxFQUNsRCxXQUFXLHFCQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFDUixZQUFBLEtBQUEsQ0FBQTt3QkFDQSw2QkFBNEIsS0FBSyxnQkFBZ0IsQ0FBQTt3QkFDakQsY0FBYSxDQUFDLENBQUE7RUFHWixLQUFLLHVCQUF1QjtFQUM1QixLQUFLLGVBQWUsVUFBVTtFQUM5QixLQUFLLG9CQUFvQixlQUFlO0NBQzFDO0NBQ0EsWUFBWSxTQUFTO0VBQ25CLEtBQUssVUFBVSxPQUFPO0NBQ3hCO0NBQ0EsY0FBYztFQUNaLEtBQUssVUFBVTtDQUNqQjtDQUNBLFVBQVUsU0FBUztFQUNqQixLQUFLLGtCQUFrQjtFQUN2QixJQUFJLFFBQVEsZUFBZSxNQUFNLEdBQUc7R0FDbEMsS0FBSyxrQkFBa0I7R0FDdkIsS0FBSyxnQkFBZ0I7R0FDckIsS0FBSyxxQkFBcUI7R0FDMUIsS0FBSyxXQUFXLEtBQUs7RUFDdkI7Q0FDRjtDQUNBLFlBQVk7RUFDVixJQUFJLEtBQUssTUFBTTtHQUNiLGtCQUFrQixLQUFLLE1BQU0sSUFBSTtHQUNqQyxJQUFJLEtBQUssS0FBSyx3QkFBd0IsS0FBSyxxQkFDekMsS0FBSyxLQUFLLGtDQUFrQyxDQUFDLENBQUM7RUFFbEQ7Q0FDRjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sQ0FBQztDQUNWO0NBQ0EsV0FBVyxLQUFLO0VBQ2QsTUFBTSxPQUFPLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSTtFQUNuQyxJQUFJLGVBQWUsTUFBTSxLQUFLLG9CQUFvQjtFQUNsRCxLQUFLLHVCQUF1QixFQUMxQixXQUFXLE1BQ2IsQ0FBQztFQUNELEtBQUssV0FBVyxLQUFLLEdBQUc7RUFDeEIsT0FBTztDQUNUO0NBQ0EsV0FBVyxLQUFLO0VBQ2QsT0FBTyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUk7Q0FDL0I7Q0FDQSxjQUFjLEtBQUs7RUFDakIsZUFBZSxJQUFJLFdBQVcsTUFBTSxLQUFLLEtBQUs7RUFDOUMsaUJBQWlCLEtBQUssWUFBWSxHQUFHO0NBQ3ZDO0NBQ0EsYUFBYSxLQUFLO0VBQ2hCLEtBQUssb0JBQW9CLEdBQUc7Q0FDOUI7Q0FDQSxnQkFBZ0IsS0FBSztFQUNuQixLQUFLLHNCQUFzQixHQUFHO0NBQ2hDO0NBQ0EsYUFBYSxLQUFLO0VBQ2hCLE9BQU8sS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJO0NBQy9CO0NBQ0EsYUFBYSxLQUFLO0VBQ2hCLE9BQU8sS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJO0NBQy9CO0NBQ0EsYUFBYSxLQUFLO0VBQ2hCLEtBQUssb0JBQW9CLEdBQUc7Q0FDOUI7Q0FDQSxnQkFBZ0IsS0FBSztFQUNuQixLQUFLLHNCQUFzQixHQUFHO0NBQ2hDO0NBQ0EsWUFBWSxLQUFLLE9BQU87RUFFdEIsS0FEa0IsS0FBSyxJQUFJLElBQUksSUFDNUIsQ0FBQyxDQUFDLFNBQVMsS0FBSztDQUNyQjtDQUNBLFVBQVU7RUFDUixLQUFLLFVBQVU7Q0FDakI7Q0FDQSxVQUFVLFFBQVEsS0FBQSxHQUFXLFVBQVUsQ0FBQyxHQUFHO0VBQ3pDLEtBQUssS0FBSyxNQUFNLE9BQU8sT0FBTztFQUM5QixLQUFLLG1CQUFtQixJQUFJLEtBQUs7Q0FDbkM7Q0FDQSxTQUFTLFFBQVE7O0VBQ2YsS0FBSyxZQUFZO0VBQ2pCLG9CQUFvQixLQUFLLE1BQU0sS0FBSyxVQUFVO0VBQzlDLEtBQUssU0FBUyxLQUFLLE1BQU07RUFDekIsS0FBSyxLQUFLLFFBQVEsS0FBSyxJQUFJLG1CQUFtQixLQUFLLE9BQU8sQ0FBQztFQUMzRCxRQUFBLFdBQUEsUUFBQSxXQUFBLEtBQUEsTUFBQSxrQkFBTyxPQUFRLFlBQUEsUUFBQSxvQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLGdCQUFRLFlBQVc7Q0FDcEM7Q0FDQSxrQkFBa0I7RUFDaEIsS0FBSyxXQUFXLFNBQVEsUUFBTztHQUM3QixNQUFNLFVBQVUsSUFBSTtHQUNwQixNQUFNLFVBQVUsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJO0dBQ3RDLElBQUksWUFBWSxTQUFTO0lBQ3ZCLGVBQWUsV0FBVyxNQUFNLEdBQUc7SUFDbkMsSUFBSSxjQUFjLE9BQU8sR0FDdkIsSUFBSSxlQUFlLFNBQVMsS0FBSyxvQkFBb0I7R0FFekQ7RUFDRixDQUFDO0VBQ0QsS0FBSyxLQUFLLG9CQUFvQixFQUM1QixXQUFXLE1BQ2IsQ0FBQztDQUNIO0NBQ0Esb0JBQW9CLEtBQUs7RUFDdkIsTUFBTSxPQUFPLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSTtFQUNuQyxtQkFBbUIsTUFBTSxHQUFHO0VBQzVCLEtBQUssdUJBQXVCLEVBQzFCLFdBQVcsTUFDYixDQUFDO0NBQ0g7Q0FDQSxzQkFBc0IsS0FBSzs7RUFDekIsTUFBTSxRQUFBLGFBQU8sS0FBSyxVQUFBLFFBQUEsZUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFdBQU0sSUFBSSxJQUFJLElBQUk7RUFDcEMsSUFBSTtPQUN1QixxQkFBcUIsTUFBTSxHQUNqQyxHQUNqQixLQUFLLHVCQUF1QixFQUMxQixXQUFXLE1BQ2IsQ0FBQztFQUFBO0NBR1A7Q0FDQSx1QkFBdUI7O0VBQ3JCLEtBQUssS0FBSyw0QkFBNEIsS0FBSyxtQkFBbUI7RUFDOUQsQ0FBQSxpQkFBQSxLQUFLLGNBQUEsUUFBQSxtQkFBQSxLQUFBLEtBQUEsZUFBVSxrQ0FBa0MsQ0FBQyxDQUFDO0NBQ3JEO0NBQ0Esb0JBQW9CO0VBQ2xCLGdCQUFnQixLQUFLLE1BQU0sSUFBSTtFQUMvQixJQUFJLEtBQUssVUFDUCxrQkFBa0IsS0FBSyxVQUFVLElBQUk7Q0FFekM7Q0FDQSxvQkFBb0I7RUFDbEIsSUFBSSxDQUFDLEtBQUssU0FBUyxPQUFPLGNBQWMsZUFBZSxZQUNyRCxNQUFNLHFCQUFxQjtDQUUvQjtBQVNGOzt1Q0FSUyxRQUFPLFNBQVMsOEJBQThCLG1CQUFtQjtDQUV0RSxPQUFPLEtBQUsscUJBQXFCbUMsd0JBQXVCdEMsa0JBQXFCLGVBQWUsRUFBRSxHQUFHQSxrQkFBcUIscUJBQXFCLEVBQUUsR0FBR0Esa0JBQXFCLHlCQUF5QixDQUFDLENBQUM7QUFDbE0sQ0FBQTt1Q0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTXNDO0NBQ04sVUFBVSxDQUFDaEMsNEJBQStCUyxvQkFBdUI7QUFDbkUsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNaLGlCQUFxQix1QkFBdUIsQ0FBQyxFQUM5RixNQUFNLFVBQ1IsQ0FBQyxTQUFTO0VBQUM7R0FDVCxNQUFNLEtBQUE7R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHO0tBQ0QsTUFBTTtLQUNOLE1BQU0sQ0FBQyxhQUFhO0lBQ3RCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsbUJBQW1CO0lBQzVCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUc7SUFDRCxNQUFNO0lBQ04sTUFBTSxDQUFDLHVCQUF1QjtHQUNoQyxDQUFDO0VBQ0g7Q0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLDBCQUEwQjtDQUM5QixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsa0JBQWtCO0FBQ2xEO0FBQ0EsSUFBTSxxQkFBTixjQUFpQyxzQkFBc0I7Ozt3QkFDckQsUUFBTyxJQUFBO3dCQUNQLFlBQVcsSUFBSSxhQUFhLENBQUE7O0NBQzVCLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSztDQUNkO0FBNkJGOztvQ0E1QlMsUUFBc0IsdUJBQU87Q0FDbEMsSUFBSTtDQUNKLE9BQU8sU0FBUywyQkFBMkIsbUJBQW1CO0VBQzVELFFBQVEsb0NBQW9DLGtDQUFrQ0Msc0JBQXlCbUMsbUJBQWtCLEdBQUEsQ0FBSSxxQkFBcUJBLG1CQUFrQjtDQUN0SztBQUNGLEVBQUEsQ0FBRyxDQUFBO29DQUNJLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQUk7RUFBYTtDQUFFLENBQUM7Q0FDakMsY0FBYyxTQUFTLGdDQUFnQyxJQUFJLEtBQUs7RUFDOUQsSUFBSSxLQUFLLEdBQ1AsV0FBYyxVQUFVLFNBQVMsNkNBQTZDLFFBQVE7R0FDcEYsT0FBTyxJQUFJLFNBQVMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxTQUFTLFNBQVMsOENBQThDO0dBQ2pFLE9BQU8sSUFBSSxRQUFRO0VBQ3JCLENBQUM7Q0FFTDtDQUNBLFFBQVEsRUFDTixNQUFNO0VBQUM7RUFBRztFQUFhO0NBQU0sRUFDL0I7Q0FDQSxTQUFTLEVBQ1AsVUFBVSxXQUNaO0NBQ0EsVUFBVSxDQUFDLFFBQVE7Q0FDbkIsWUFBWTtDQUNaLFVBQVUsQ0FBQy9CLG1CQUFzQixDQUFDLHVCQUF1QixDQUFDLEdBQUdGLDBCQUE2QjtBQUM1RixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLG9CQUFvQixDQUFDO0VBQzNGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLHVCQUF1QjtHQUNuQyxNQUFNO0lBQ0osWUFBWTtJQUNaLFdBQVc7R0FDYjtHQUNBLFVBQVU7R0FDVixZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNO0VBQ1IsTUFBTSxDQUFDO0dBQ0wsTUFBTTtHQUNOLE1BQU0sQ0FBQyxXQUFXO0VBQ3BCLENBQUM7RUFDRCxVQUFVLENBQUMsRUFDVCxNQUFNLE9BQ1IsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLHFDQUFxQyxJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxrQ0FBa0MsRUFBRTtBQUNsSixJQUFNLHFCQUFxQjtDQUN6QixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsb0JBQW9CO0FBQ3BEO0FBQ0EsSUFBTSx1QkFBTixNQUFNLDZCQUE2QixVQUFVO0NBSzNDLElBQUksV0FBVyxZQUFZO0VBQ3pCLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsUUFBUSxLQUFLLG1CQUFtQjtDQUVwQztDQUtBLFlBQVksWUFBWSxpQkFBaUIsZ0JBQWdCLHVCQUF1QixzQkFBc0IsVUFBVSxVQUFVO0VBQ3hILE1BQU0sVUFBVSxVQUFVLGNBQWM7d0JBZDFDLHlCQUFBLEtBQUEsQ0FBQTt3QkFDQSx3QkFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7d0JBQ0EsUUFBQSxLQUFBLENBQUE7d0JBTUEsU0FBQSxLQUFBLENBQUE7d0JBQ0EsVUFBUyxJQUFJLGFBQWEsQ0FBQTt3QkFFMUIsdUJBQXNCLEtBQUE7RUFHcEIsS0FBSyx3QkFBd0I7RUFDN0IsS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyxlQUFlLFVBQVU7RUFDOUIsS0FBSyxvQkFBb0IsZUFBZTtDQUMxQztDQUNBLFlBQVksU0FBUztFQUNuQixJQUFJLEtBQUssa0JBQWtCLE9BQU8sR0FBRztHQUNuQyxNQUFNLGVBQWUsUUFBUSxPQUFPLENBQUM7R0FDckMsSUFBSSxjQUFjO0lBQ2hCLGVBQWUsY0FBYyxNQUFNLEtBQUs7SUFDeEMsS0FBSywyQkFBMkIsWUFBWTtHQUM5QztHQUNBLElBQUksQ0FBQyxLQUFLLHNCQUFzQjs7SUFDOUIsQ0FBQSx1QkFBQSxLQUFLLG1CQUFBLFFBQUEseUJBQUEsS0FBQSxNQUFMLEtBQUssZ0JBQWtCLEtBQUs7SUFDNUIsMEJBQTBCLEtBQUssTUFBTSxNQUFNLEtBQUssb0JBQW9CO0dBQ3RFLE9BQ0UsS0FBSyxtQkFBbUI7R0FFMUIsS0FBSyxLQUFLLHVCQUF1QixFQUMvQixXQUFXLE1BQ2IsQ0FBQztFQUNIO0VBQ0EsSUFBSSxrQkFBa0IsU0FBUyxLQUFLLFNBQVMsR0FBRztHQUM5QyxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLGdCQUFnQixlQUFlLHNCQUFzQixNQUFNLEtBQUsscUJBQXFCO0dBRXZGLEtBQUssS0FBSyxTQUFTLEtBQUssS0FBSztHQUM3QixLQUFLLFlBQVksS0FBSztFQUN4QjtDQUNGO0NBQ0EsY0FBYztFQUNaLElBQUksS0FBSyxNQUNQLGVBQWUsS0FBSyxNQUFNLE1BQU0sS0FBSztDQUV6QztDQUNBLElBQUksT0FBTztFQUNULE9BQU8sQ0FBQztDQUNWO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxrQkFBa0IsVUFBVTtFQUMxQixLQUFLLFlBQVk7RUFDakIsS0FBSyxPQUFPLEtBQUssUUFBUTtDQUMzQjtDQUNBLGtCQUFrQixTQUFTO0VBQ3pCLE9BQU8sUUFBUSxlQUFlLE1BQU07Q0FDdEM7Q0FDQSxpQkFBaUIsTUFBTTtFQUNyQixNQUFNLGdCQUFnQixJQUFJO0NBQzVCO0NBQ0EsaUJBQWlCLE1BQU07RUFDckIsTUFBTSxnQkFBZ0IsTUFBTSxJQUFJO0NBQ2xDO0FBb0JGOztzQ0E3RVMsMkJBQTBCLEtBQUE7c0NBMEQxQixRQUFPLFNBQVMsNkJBQTZCLG1CQUFtQjtDQUVyRSxPQUFPLEtBQUsscUJBQXFCcUMsdUJBQXNCeEMsa0JBQXFCLGVBQWUsRUFBRSxHQUFHQSxrQkFBcUIscUJBQXFCLEVBQUUsR0FBR0Esa0JBQXFCLG1CQUFtQixFQUFFLEdBQUdBLGtCQUFxQixvQ0FBb0MsQ0FBQyxHQUFHQSxrQkFBcUIseUJBQXlCLENBQUMsR0FBR0Esa0JBQXFCQyxXQUFjLENBQUMsR0FBR0Qsa0JBQXFCOEIsVUFBYSxDQUFDLENBQUM7QUFDeFgsQ0FBQTtzQ0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTVU7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFJO0VBQWU7Q0FBRSxDQUFDO0NBQ25DLFFBQVE7RUFDTixNQUFNO0dBQUM7R0FBRztHQUFlO0VBQU07RUFDL0IsWUFBWTtHQUFDO0dBQUc7R0FBWTtFQUFZO0VBQ3hDLE9BQU87R0FBQztHQUFHO0dBQVc7RUFBTztDQUMvQjtDQUNBLFNBQVMsRUFDUCxRQUFRLGdCQUNWO0NBQ0EsVUFBVSxDQUFDLFFBQVE7Q0FDbkIsWUFBWTtDQUNaLFVBQVU7RUFBQ2hDLG1CQUFzQixDQUFDLG9CQUFvQiwrQkFBK0IsQ0FBQztFQUFHRjtFQUErQlM7RUFBeUJnQixpQkFBb0IsSUFBSTtDQUFDO0FBQzVLLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjNUIsaUJBQXFCLHNCQUFzQixDQUFDO0VBQzdGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLG9CQUFvQiwrQkFBK0I7R0FDL0QsVUFBVTtHQUNWLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTO0VBQUM7R0FDVCxNQUFNLEtBQUE7R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHO0tBQ0QsTUFBTTtLQUNOLE1BQU0sQ0FBQyxhQUFhO0lBQ3RCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsbUJBQW1CO0lBQzVCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsaUJBQWlCO0lBQzFCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUc7SUFDRCxNQUFNO0lBQ04sTUFBTSxDQUFDLGtDQUFrQztHQUMzQyxDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixHQUFHO0lBQ0QsTUFBTTtJQUNOLE1BQU0sQ0FBQyx1QkFBdUI7R0FDaEMsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNRjtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU02QjtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHO0VBQ0YsTUFBTSxDQUFDO0dBQ0wsTUFBTTtHQUNOLE1BQU0sQ0FBQyxhQUFhO0VBQ3RCLENBQUM7RUFDRCxZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLFVBQVU7RUFDbkIsQ0FBQztFQUNELE9BQU8sQ0FBQztHQUNOLE1BQU07R0FDTixNQUFNLENBQUMsU0FBUztFQUNsQixDQUFDO0VBQ0QsUUFBUSxDQUFDO0dBQ1AsTUFBTTtHQUNOLE1BQU0sQ0FBQyxlQUFlO0VBQ3hCLENBQUM7Q0FDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSx3QkFBd0I7Q0FDNUIsU0FBUztDQUNULGFBQWEsaUJBQWlCLGFBQWE7QUFDN0M7QUFDQSxJQUFNLGdCQUFOLGNBQTRCLDJCQUEyQjtDQUVyRCxZQUFZLFFBQVEsWUFBWSxpQkFBaUI7RUFDL0MsTUFBTTt3QkFGUixRQUFPLElBQUE7RUFHTCxLQUFLLFVBQVU7RUFDZixLQUFLLGVBQWUsVUFBVTtFQUM5QixLQUFLLG9CQUFvQixlQUFlO0NBQzFDO0NBQ0EsbUJBQW1CO0VBQ2pCLElBQUksaUJBQWlCLEtBQUssT0FBTyxNQUFNLE9BQU8sY0FBYyxlQUFlLFlBQ3pFLE1BQU0scUJBQXFCO0NBRS9CO0FBY0Y7OytCQWJTLFFBQU8sU0FBUyxzQkFBc0IsbUJBQW1CO0NBRTlELE9BQU8sS0FBSyxxQkFBcUJXLGdCQUFlekMsa0JBQXFCLGtCQUFrQixFQUFFLEdBQUdBLGtCQUFxQixlQUFlLEVBQUUsR0FBR0Esa0JBQXFCLHFCQUFxQixFQUFFLENBQUM7QUFDcEwsQ0FBQTsrQkFDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTXlDO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFpQjtDQUFFLENBQUM7Q0FDckMsUUFBUSxFQUNOLE1BQU07RUFBQztFQUFHO0VBQWlCO0NBQU0sRUFDbkM7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDakMsbUJBQXNCLENBQUMscUJBQXFCLENBQUMsR0FBR0YsMEJBQTZCO0FBQzFGLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsZUFBZSxDQUFDO0VBQ3RGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLHFCQUFxQjtHQUNqQyxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsU0FBUztFQUFDO0dBQ1QsTUFBTTtHQUNOLFlBQVk7SUFBQyxFQUNYLE1BQU0sU0FDUjtJQUFHLEVBQ0QsTUFBTSxLQUNSO0lBQUcsRUFDRCxNQUFNLFNBQ1I7R0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHO0tBQ0QsTUFBTTtLQUNOLE1BQU0sQ0FBQyxhQUFhO0lBQ3RCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsbUJBQW1CO0lBQzVCO0dBQUM7RUFDSDtDQUFDLEdBQUcsRUFDRixNQUFNLENBQUM7RUFDTCxNQUFNO0VBQ04sTUFBTSxDQUFDLGVBQWU7Q0FDeEIsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLHdCQUF3QjtDQUM1QixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsYUFBYTtBQUM3QztBQUNBLElBQU0sZ0JBQU4sY0FBNEIsaUJBQWlCO0NBRzNDLFlBQVksUUFBUSxZQUFZLGlCQUFpQjtFQUMvQyxNQUFNO3dCQUhSLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQU8sSUFBQTtFQUdMLEtBQUssVUFBVTtFQUNmLEtBQUssZUFBZSxVQUFVO0VBQzlCLEtBQUssb0JBQW9CLGVBQWU7Q0FDMUM7Q0FDQSxXQUFXO0VBQ1QsSUFBSSxpQkFBaUIsS0FBSyxPQUFPLE1BQU0sT0FBTyxjQUFjLGVBQWUsWUFDekUsTUFBTSxxQkFBcUI7RUFFN0IsS0FBSyxjQUFjLGFBQWEsSUFBSTtDQUN0QztDQUNBLGNBQWM7O0VBQ1osQ0FBQSx1QkFBQSxLQUFLLG1CQUFBLFFBQUEseUJBQUEsS0FBQSxLQUFBLHFCQUFlLGdCQUFnQixJQUFJO0NBQzFDO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLLGNBQWMsYUFBYSxJQUFJO0NBQzdDO0NBQ0EsSUFBSSxnQkFBZ0I7RUFDbEIsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLGdCQUFnQjtDQUNyRDtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sWUFBWSxLQUFLLFFBQVEsT0FBTyxLQUFLLE9BQU8sS0FBSyxLQUFLLFNBQVMsR0FBRyxLQUFLLE9BQU87Q0FDdkY7QUFjRjs7K0JBYlMsUUFBTyxTQUFTLHNCQUFzQixtQkFBbUI7Q0FFOUQsT0FBTyxLQUFLLHFCQUFxQnVDLGdCQUFlMUMsa0JBQXFCLGtCQUFrQixFQUFFLEdBQUdBLGtCQUFxQixlQUFlLEVBQUUsR0FBR0Esa0JBQXFCLHFCQUFxQixFQUFFLENBQUM7QUFDcEwsQ0FBQTsrQkFDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTTBDO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFpQjtDQUFFLENBQUM7Q0FDckMsUUFBUSxFQUNOLE1BQU07RUFBQztFQUFHO0VBQWlCO0NBQU0sRUFDbkM7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDbEMsbUJBQXNCLENBQUMscUJBQXFCLENBQUMsR0FBR0YsMEJBQTZCO0FBQzFGLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsZUFBZSxDQUFDO0VBQ3RGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLHFCQUFxQjtHQUNqQyxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsU0FBUztFQUFDO0dBQ1QsTUFBTTtHQUNOLFlBQVk7SUFBQyxFQUNYLE1BQU0sU0FDUjtJQUFHLEVBQ0QsTUFBTSxLQUNSO0lBQUcsRUFDRCxNQUFNLFNBQ1I7R0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHO0tBQ0QsTUFBTTtLQUNOLE1BQU0sQ0FBQyxhQUFhO0lBQ3RCO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsbUJBQW1CO0lBQzVCO0dBQUM7RUFDSDtDQUFDLEdBQUcsRUFDRixNQUFNLENBQUM7RUFDTCxNQUFNO0VBQ04sTUFBTSxDQUFDLGVBQWU7Q0FDeEIsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxTQUFTLGlCQUFpQixRQUFRO0NBQ2hDLE9BQU8sRUFBRSxrQkFBa0Isa0JBQWtCLEVBQUUsa0JBQWtCLDBCQUEwQixFQUFFLGtCQUFrQjtBQUNqSDtBQUNBLElBQU0scUJBQXFCO0NBQ3pCLFNBQVM7Q0FDVCxhQUFhLGlCQUFpQixlQUFlO0FBQy9DO0FBQ0EsSUFBTSxrQkFBTixNQUFNLHdCQUF3QixVQUFVO0NBTXRDLElBQUksV0FBVyxZQUFZO0VBQ3pCLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsUUFBUSxLQUFLLG1CQUFtQjtDQUVwQztDQUtBLFlBQVksUUFBUSxZQUFZLGlCQUFpQixnQkFBZ0IsdUJBQXVCLFVBQVUsVUFBVTtFQUMxRyxNQUFNLFVBQVUsVUFBVSxjQUFjO3dCQWYxQyx5QkFBQSxLQUFBLENBQUE7d0JBQ0EsVUFBUyxLQUFBO3dCQUNULGFBQUEsS0FBQSxDQUFBO3dCQUNBLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQU8sSUFBQTt3QkFNUCxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFTLElBQUksYUFBYSxDQUFBO3dCQUUxQix1QkFBc0IsS0FBQTtFQUdwQixLQUFLLHdCQUF3QjtFQUM3QixLQUFLLFVBQVU7RUFDZixLQUFLLGVBQWUsVUFBVTtFQUM5QixLQUFLLG9CQUFvQixlQUFlO0NBQzFDO0NBQ0EsZUFBZSxTQUFTLHNCQUFzQjtFQUM1QyxLQUFLLFVBQVU7RUFDZixJQUFJLENBQUMsS0FBSyxzQkFBc0I7O0dBQzlCLENBQUEsdUJBQUEsS0FBSyxtQkFBQSxRQUFBLHlCQUFBLEtBQUEsTUFBTCxLQUFLLGdCQUFrQixLQUFLO0dBQzVCLDBCQUEwQixTQUFTLE1BQU0sb0JBQW9CO0VBQy9ELE9BQ0UsS0FBSyxtQkFBbUI7Q0FFNUI7Q0FDQSxZQUFZLFNBQVM7RUFDbkIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLGNBQWM7RUFDckMsSUFBSSxrQkFBa0IsU0FBUyxLQUFLLFNBQVMsR0FBRztHQUM5QyxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLGdCQUFnQixtQkFBbUIsaUJBQWlCLE1BQU0sS0FBSyxxQkFBcUI7R0FFdEYsS0FBSyxZQUFZLEtBQUs7R0FDdEIsS0FBSyxjQUFjLFlBQVksTUFBTSxLQUFLLEtBQUs7RUFDakQ7Q0FDRjtDQUNBLGNBQWM7O0VBQ1osQ0FBQSx1QkFBQSxLQUFLLG1CQUFBLFFBQUEseUJBQUEsS0FBQSxLQUFBLHFCQUFlLGNBQWMsSUFBSTtDQUN4QztDQUNBLGtCQUFrQixVQUFVO0VBQzFCLEtBQUssWUFBWTtFQUNqQixLQUFLLE9BQU8sS0FBSyxRQUFRO0NBQzNCO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsT0FBTyxZQUFZLEtBQUssUUFBUSxPQUFPLEtBQUssT0FBTyxLQUFLLEtBQUssU0FBUyxHQUFHLEtBQUssT0FBTztDQUN2RjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU8sS0FBSyxVQUFVLEtBQUssUUFBUSxnQkFBZ0I7Q0FDckQ7Q0FDQSxnQkFBZ0I7RUFDZCxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLGdCQUFnQixLQUFLLFNBQVMsS0FBSyxJQUFJO0VBRXpDLEtBQUssVUFBVSxLQUFLLGNBQWMsV0FBVyxJQUFJO0VBQ2pELEtBQUssU0FBUztDQUNoQjtDQUNBLGlCQUFpQixNQUFNO0VBQ3JCLE1BQU0sZ0JBQWdCLElBQUk7Q0FDNUI7Q0FDQSxpQkFBaUIsTUFBTTtFQUNyQixJQUFJLENBQUMsS0FBSyxzQkFDUjtFQUVGLElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxjQUFjO0VBQ3JDLE1BQU0sZ0JBQWdCLE1BQU0sSUFBSTtDQUNsQztBQW1CRjs7aUNBNUVTLDJCQUEwQixLQUFBO2lDQTBEMUIsUUFBTyxTQUFTLHdCQUF3QixtQkFBbUI7Q0FFaEUsT0FBTyxLQUFLLHFCQUFxQndDLGtCQUFpQjNDLGtCQUFxQixrQkFBa0IsRUFBRSxHQUFHQSxrQkFBcUIsZUFBZSxFQUFFLEdBQUdBLGtCQUFxQixxQkFBcUIsRUFBRSxHQUFHQSxrQkFBcUIsbUJBQW1CLEVBQUUsR0FBR0Esa0JBQXFCLG9DQUFvQyxDQUFDLEdBQUdBLGtCQUFxQkMsV0FBYyxDQUFDLEdBQUdELGtCQUFxQjhCLFVBQWEsQ0FBQyxDQUFDO0FBQzdXLENBQUE7aUNBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1hO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFtQjtDQUFFLENBQUM7Q0FDdkMsUUFBUTtFQUNOLE1BQU07R0FBQztHQUFHO0dBQW1CO0VBQU07RUFDbkMsWUFBWTtHQUFDO0dBQUc7R0FBWTtFQUFZO0VBQ3hDLE9BQU87R0FBQztHQUFHO0dBQVc7RUFBTztDQUMvQjtDQUNBLFNBQVMsRUFDUCxRQUFRLGdCQUNWO0NBQ0EsWUFBWTtDQUNaLFVBQVU7RUFBQ25DLG1CQUFzQixDQUFDLG9CQUFvQiwrQkFBK0IsQ0FBQztFQUFHRjtFQUErQlM7RUFBeUJnQixpQkFBb0IsSUFBSTtDQUFDO0FBQzVLLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjNUIsaUJBQXFCLGlCQUFpQixDQUFDO0VBQ3hGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLG9CQUFvQiwrQkFBK0I7R0FDL0QsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVM7RUFBQztHQUNULE1BQU07R0FDTixZQUFZO0lBQUMsRUFDWCxNQUFNLFNBQ1I7SUFBRyxFQUNELE1BQU0sS0FDUjtJQUFHLEVBQ0QsTUFBTSxTQUNSO0dBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWTtJQUFDLEVBQ1gsTUFBTSxTQUNSO0lBQUcsRUFDRCxNQUFNLEtBQ1I7SUFBRztLQUNELE1BQU07S0FDTixNQUFNLENBQUMsYUFBYTtJQUN0QjtHQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVk7SUFBQyxFQUNYLE1BQU0sU0FDUjtJQUFHLEVBQ0QsTUFBTSxLQUNSO0lBQUc7S0FDRCxNQUFNO0tBQ04sTUFBTSxDQUFDLG1CQUFtQjtJQUM1QjtHQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVk7SUFBQyxFQUNYLE1BQU0sU0FDUjtJQUFHLEVBQ0QsTUFBTSxLQUNSO0lBQUc7S0FDRCxNQUFNO0tBQ04sTUFBTSxDQUFDLGlCQUFpQjtJQUMxQjtHQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixHQUFHO0lBQ0QsTUFBTTtJQUNOLE1BQU0sQ0FBQyxrQ0FBa0M7R0FDM0MsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNRjtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU02QjtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHO0VBQ0YsTUFBTSxDQUFDO0dBQ0wsTUFBTTtHQUNOLE1BQU0sQ0FBQyxpQkFBaUI7RUFDMUIsQ0FBQztFQUNELFlBQVksQ0FBQztHQUNYLE1BQU07R0FDTixNQUFNLENBQUMsVUFBVTtFQUNuQixDQUFDO0VBQ0QsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLE1BQU0sQ0FBQyxTQUFTO0VBQ2xCLENBQUM7RUFDRCxRQUFRLENBQUM7R0FDUCxNQUFNO0dBQ04sTUFBTSxDQUFDLGVBQWU7RUFDeEIsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxTQUFTLGdCQUFnQixRQUFRLE1BQU07Q0FDckMsSUFBSSxFQUFFLGtCQUFrQixrQkFBa0Isa0JBQWtCLDRCQUMxRCxNQUFNLHNCQUFzQjtNQUN2QixJQUFJLEVBQUUsa0JBQWtCLGtCQUFrQixFQUFFLGtCQUFrQiwwQkFBMEIsRUFBRSxrQkFBa0IsZ0JBQ2pILE1BQU0sdUJBQXVCLElBQUk7QUFFckM7QUFDQSxJQUFNLHdCQUF3QjtDQUM1QixTQUFTO0NBQ1QsYUFBYSxpQkFBaUIsa0JBQWtCO0FBQ2xEO0FBQ0EsSUFBTSxxQkFBTixjQUFpQyxzQkFBc0I7Ozt3QkFDckQsUUFBTyxJQUFBO3dCQUNQLFlBQVcsSUFBSSxhQUFhLENBQUE7O0NBQzVCLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSztDQUNkO0FBNkJGOztvQ0E1QlMsUUFBc0IsdUJBQU87Q0FDbEMsSUFBSTtDQUNKLE9BQU8sU0FBUywyQkFBMkIsbUJBQW1CO0VBQzVELFFBQVEsb0NBQW9DLGtDQUFrQzFCLHNCQUF5QndDLG1CQUFrQixHQUFBLENBQUkscUJBQXFCQSxtQkFBa0I7Q0FDdEs7QUFDRixFQUFBLENBQUcsQ0FBQTtvQ0FDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFJO0VBQWE7Q0FBRSxDQUFDO0NBQ2pDLGNBQWMsU0FBUyxnQ0FBZ0MsSUFBSSxLQUFLO0VBQzlELElBQUksS0FBSyxHQUNQLFdBQWMsVUFBVSxTQUFTLDZDQUE2QyxRQUFRO0dBQ3BGLE9BQU8sSUFBSSxTQUFTLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsU0FBUyxTQUFTLDhDQUE4QztHQUNqRSxPQUFPLElBQUksUUFBUTtFQUNyQixDQUFDO0NBRUw7Q0FDQSxRQUFRLEVBQ04sTUFBTTtFQUFDO0VBQUc7RUFBYTtDQUFNLEVBQy9CO0NBQ0EsU0FBUyxFQUNQLFVBQVUsV0FDWjtDQUNBLFVBQVUsQ0FBQyxRQUFRO0NBQ25CLFlBQVk7Q0FDWixVQUFVLENBQUNwQyxtQkFBc0IsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDMUYsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQixvQkFBb0IsQ0FBQztFQUMzRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLFdBQVcsQ0FBQyxxQkFBcUI7R0FDakMsTUFBTTtJQUNKLFlBQVk7SUFDWixXQUFXO0dBQ2I7R0FDQSxVQUFVO0dBQ1YsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTTtFQUNSLE1BQU0sQ0FBQztHQUNMLE1BQU07R0FDTixNQUFNLENBQUMsV0FBVztFQUNwQixDQUFDO0VBQ0QsVUFBVSxDQUFDLEVBQ1QsTUFBTSxPQUNSLENBQUM7Q0FDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSx3QkFBd0I7Q0FDNUIsU0FBUztDQUNULGFBQWEsaUJBQWlCLDBCQUEwQjtDQUN4RCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixJQUFJLE9BQU87Q0FDdEMsSUFBSSxNQUFNLE1BQU0sT0FBTyxHQUFHO0NBQzFCLElBQUksU0FBUyxPQUFPLFVBQVUsVUFBVSxRQUFRO0NBQ2hELE9BQU8sR0FBRyxHQUFHLElBQUksUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUN0QztBQUNBLFNBQVMsYUFBYSxhQUFhO0NBQ2pDLE9BQU8sWUFBWSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQ2hDO0FBQ0EsSUFBTSw2QkFBTixjQUF5Qyw0QkFBNEI7Ozt3QkFDbkUsU0FBQSxLQUFBLENBQUE7d0JBQ0EsOEJBQWEsSUFBSSxJQUFJLENBQUE7d0JBQ3JCLGNBQWEsQ0FBQTt3QkFPYixnQkFBZSxPQUFPLEVBQUE7d0JBQ3RCLGtCQUFpQixPQUFPLGNBQWMsQ0FBQyxDQUFDLFFBQUE7d0JBQ3hDLGNBQWEsT0FBTyxVQUFVLENBQUE7d0JBQzlCLE9BQU0sT0FBTyxpQkFBaUIsQ0FBQTt3QkFDOUIsZ0JBQWUsS0FBQTs7Q0FWZixJQUFJLFlBQVksSUFBSTtFQUNsQixJQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQ25FLE1BQU0sSUFBSVUsYUFBYyxNQUFNLGdEQUFnRCxLQUFLLFVBQVUsRUFBRSxHQUFHO0VBRXBHLEtBQUssZUFBZTtDQUN0QjtDQU1BLHlCQUF5QjtFQUN2QixJQUFJLEtBQUssZ0JBQWdCLEtBQUssZUFBZSxXQUMzQztFQUVGLEtBQUssZUFBZTtFQUNwQixnQkFBZ0IsRUFDZCxhQUFhO0dBQ1gsSUFBSSxLQUFLLFdBQVcsV0FDbEI7R0FFRixLQUFLLGVBQWU7R0FDcEIsS0FBSyxXQUFXLEtBQUssS0FBSztFQUM1QixFQUNGLEdBQUcsRUFDRCxVQUFVLEtBQUssZUFDakIsQ0FBQztDQUNIO0NBQ0EsV0FBVyxPQUFPO0VBQ2hCLEtBQUssSUFBSSxhQUFhO0VBQ3RCLEtBQUssUUFBUTtFQUViLE1BQU0sY0FBYyxvQkFEVCxLQUFLLGFBQWEsS0FDWSxHQUFHLEtBQUs7RUFDakQsS0FBSyxZQUFZLFNBQVMsV0FBVztDQUN2QztDQUNBLGlCQUFpQixJQUFJO0VBQ25CLEtBQUssWUFBVyxnQkFBZTtHQUM3QixLQUFLLFFBQVEsS0FBSyxnQkFBZ0IsV0FBVztHQUM3QyxHQUFHLEtBQUssS0FBSztFQUNmO0NBQ0Y7Q0FDQSxrQkFBa0I7RUFDaEIsUUFBUSxLQUFLLGFBQUEsQ0FBYyxTQUFTO0NBQ3RDO0NBQ0EsYUFBYSxPQUFPO0VBQ2xCLEtBQUssTUFBTSxNQUFNLEtBQUssV0FBVyxLQUFLLEdBQ3BDLElBQUksS0FBSyxhQUFhLEtBQUssV0FBVyxJQUFJLEVBQUUsR0FBRyxLQUFLLEdBQUcsT0FBTztFQUVoRSxPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsYUFBYTtFQUMzQixNQUFNLEtBQUssYUFBYSxXQUFXO0VBQ25DLE9BQU8sS0FBSyxXQUFXLElBQUksRUFBRSxJQUFJLEtBQUssV0FBVyxJQUFJLEVBQUUsSUFBSTtDQUM3RDtBQXlCRjs7NENBeEJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsbUNBQW1DLG1CQUFtQjtFQUNwRSxRQUFRLDRDQUE0QywwQ0FBMENULHNCQUF5QnlDLDJCQUEwQixHQUFBLENBQUkscUJBQXFCQSwyQkFBMEI7Q0FDdE07QUFDRixFQUFBLENBQUcsQ0FBQTs0Q0FDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFVO0dBQW1CO0dBQUk7R0FBRztHQUFZO0dBQUk7R0FBRztHQUFXO0VBQUU7RUFBRztHQUFDO0dBQVU7R0FBZTtHQUFJO0dBQUc7R0FBWTtHQUFJO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFVO0dBQVc7R0FBSTtHQUFHO0dBQVk7R0FBSTtHQUFHO0dBQVc7RUFBRTtDQUFDO0NBQ3ROLGNBQWMsU0FBUyx3Q0FBd0MsSUFBSSxLQUFLO0VBQ3RFLElBQUksS0FBSyxHQUNQLFdBQWMsVUFBVSxTQUFTLHFEQUFxRCxRQUFRO0dBQzVGLE9BQU8sSUFBSSxTQUFTLE9BQU8sT0FBTyxLQUFLO0VBQ3pDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxxREFBcUQ7R0FDdkUsT0FBTyxJQUFJLFVBQVU7RUFDdkIsQ0FBQztDQUVMO0NBQ0EsUUFBUSxFQUNOLGFBQWEsY0FDZjtDQUNBLFlBQVk7Q0FDWixVQUFVLENBQUNyQyxtQkFBc0IsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHRiwwQkFBNkI7QUFDMUYsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQiw0QkFBNEIsQ0FBQztFQUNuRyxNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLE1BQU07SUFDSixZQUFZO0lBQ1osVUFBVTtHQUNaO0dBQ0EsV0FBVyxDQUFDLHFCQUFxQjtHQUNqQyxZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLEVBQ1IsYUFBYSxDQUFDLEVBQ1osTUFBTSxNQUNSLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSxpQkFBTixNQUFxQjtDQUtuQixZQUFZLFVBQVUsV0FBVyxTQUFTO3dCQUoxQyxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxXQUFBLEtBQUEsQ0FBQTt3QkFDQSxNQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssV0FBVztFQUNoQixLQUFLLFlBQVk7RUFDakIsS0FBSyxVQUFVO0VBQ2YsSUFBSSxLQUFLLFNBQVMsS0FBSyxLQUFLLEtBQUssUUFBUSxnQkFBZ0I7Q0FDM0Q7Q0FDQSxJQUFJLFFBQVEsT0FBTztFQUNqQixJQUFJLEtBQUssV0FBVyxNQUFNO0VBQzFCLEtBQUssUUFBUSxXQUFXLElBQUksS0FBSyxJQUFJLEtBQUs7RUFDMUMsS0FBSyxpQkFBaUIsb0JBQW9CLEtBQUssSUFBSSxLQUFLLENBQUM7RUFDekQsS0FBSyxRQUFRLHVCQUF1QjtDQUN0QztDQUNBLElBQUksTUFBTSxPQUFPOztFQUNmLEtBQUssaUJBQWlCLEtBQUs7RUFDM0IsQ0FBQSxnQkFBQSxLQUFLLGFBQUEsUUFBQSxrQkFBQSxLQUFBLEtBQUEsY0FBUyx1QkFBdUI7Q0FDdkM7Q0FDQSxpQkFBaUIsT0FBTztFQUN0QixLQUFLLFVBQVUsWUFBWSxLQUFLLFNBQVMsZUFBZSxTQUFTLEtBQUs7Q0FDeEU7Q0FDQSxjQUFjOztFQUNaLENBQUEsaUJBQUEsS0FBSyxhQUFBLFFBQUEsbUJBQUEsS0FBQSxLQUFBLGVBQVMsV0FBVyxPQUFPLEtBQUssRUFBRTtFQUN2QyxDQUFBLGlCQUFBLEtBQUssYUFBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFTLHVCQUF1QjtDQUN2QztBQWNGOztnQ0FiUyxRQUFPLFNBQVMsdUJBQXVCLG1CQUFtQjtDQUUvRCxPQUFPLEtBQUsscUJBQXFCMkMsaUJBQWdCOUMsa0JBQXFCRSxVQUFhLEdBQUdGLGtCQUFxQkMsU0FBWSxHQUFHRCxrQkFBcUIsNEJBQTRCLENBQUMsQ0FBQztBQUMvSyxDQUFBO2dDQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNOEM7Q0FDTixXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUM7Q0FDdEIsUUFBUTtFQUNOLFNBQVM7RUFDVCxPQUFPO0NBQ1Q7Q0FDQSxZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWMzQyxpQkFBcUIsZ0JBQWdCLENBQUM7RUFDdkYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixZQUFZO0VBQ2QsQ0FBQztDQUNILENBQUMsU0FBUztFQUFDLEVBQ1QsTUFBTUQsV0FDUjtFQUFHLEVBQ0QsTUFBTUQsVUFDUjtFQUFHO0dBQ0QsTUFBTTtHQUNOLFlBQVksQ0FBQyxFQUNYLE1BQU0sU0FDUixHQUFHLEVBQ0QsTUFBTSxLQUNSLENBQUM7RUFDSDtDQUFDLEdBQUc7RUFDRixTQUFTLENBQUM7R0FDUixNQUFNO0dBQ04sTUFBTSxDQUFDLFNBQVM7RUFDbEIsQ0FBQztFQUNELE9BQU8sQ0FBQztHQUNOLE1BQU07R0FDTixNQUFNLENBQUMsT0FBTztFQUNoQixDQUFDO0NBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILElBQU0saUNBQWlDO0NBQ3JDLFNBQVM7Q0FDVCxhQUFhLGlCQUFpQixrQ0FBa0M7Q0FDaEUsT0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsSUFBSSxPQUFPO0NBQ3BDLElBQUksTUFBTSxNQUFNLE9BQU8sR0FBRztDQUMxQixJQUFJLE9BQU8sVUFBVSxVQUFVLFFBQVEsSUFBSSxNQUFNO0NBQ2pELElBQUksU0FBUyxPQUFPLFVBQVUsVUFBVSxRQUFRO0NBQ2hELE9BQU8sR0FBRyxHQUFHLElBQUksUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUN0QztBQUNBLFNBQVMsV0FBVyxhQUFhO0NBQy9CLE9BQU8sWUFBWSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQ2hDO0FBQ0EsSUFBTSxxQ0FBTixjQUFpRCw0QkFBNEI7Ozt3QkFDM0UsU0FBQSxLQUFBLENBQUE7d0JBQ0EsOEJBQWEsSUFBSSxJQUFJLENBQUE7d0JBQ3JCLGNBQWEsQ0FBQTt3QkFPYixnQkFBZSxPQUFPLEVBQUE7O0NBTnRCLElBQUksWUFBWSxJQUFJO0VBQ2xCLElBQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFDbkUsTUFBTSxJQUFJWSxhQUFjLE1BQU0sZ0RBQWdELEtBQUssVUFBVSxFQUFFLEdBQUc7RUFFcEcsS0FBSyxlQUFlO0NBQ3RCO0NBRUEsV0FBVyxPQUFPO0VBQ2hCLEtBQUssUUFBUTtFQUNiLElBQUk7RUFDSixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7R0FDeEIsTUFBTSxNQUFNLE1BQU0sS0FBSSxNQUFLLEtBQUssYUFBYSxDQUFDLENBQUM7R0FDL0MsNkJBQTZCLEtBQUssT0FBTztJQUN2QyxJQUFJLGFBQWEsSUFBSSxRQUFRLEVBQUUsSUFBSSxFQUFFO0dBQ3ZDO0VBQ0YsT0FDRSw2QkFBNEIsUUFBTztHQUNqQyxJQUFJLGFBQWEsS0FBSztFQUN4QjtFQUVGLEtBQUssV0FBVyxRQUFRLHlCQUF5QjtDQUNuRDtDQUNBLGlCQUFpQixJQUFJO0VBQ25CLEtBQUssWUFBVyxZQUFXO0dBQ3pCLE1BQU0sV0FBVyxDQUFDO0dBQ2xCLE1BQU0sa0JBQWtCLFFBQVE7R0FDaEMsSUFBSSxvQkFBb0IsS0FBQSxHQUFXO0lBQ2pDLE1BQU0sVUFBVTtJQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7S0FDdkMsTUFBTSxNQUFNLFFBQVE7S0FDcEIsTUFBTSxNQUFNLEtBQUssZ0JBQWdCLElBQUksS0FBSztLQUMxQyxTQUFTLEtBQUssR0FBRztJQUNuQjtHQUNGLE9BQU87SUFDTCxNQUFNLFVBQVUsUUFBUTtJQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7S0FDdkMsTUFBTSxNQUFNLFFBQVE7S0FDcEIsSUFBSSxJQUFJLFVBQVU7TUFDaEIsTUFBTSxNQUFNLEtBQUssZ0JBQWdCLElBQUksS0FBSztNQUMxQyxTQUFTLEtBQUssR0FBRztLQUNuQjtJQUNGO0dBQ0Y7R0FDQSxLQUFLLFFBQVE7R0FDYixHQUFHLFFBQVE7RUFDYjtDQUNGO0NBQ0EsZ0JBQWdCLE9BQU87RUFDckIsTUFBTSxNQUFNLEtBQUssYUFBQSxDQUFjLFNBQVM7RUFDeEMsS0FBSyxXQUFXLElBQUksSUFBSSxLQUFLO0VBQzdCLE9BQU87Q0FDVDtDQUNBLGFBQWEsT0FBTztFQUNsQixLQUFLLE1BQU0sTUFBTSxLQUFLLFdBQVcsS0FBSyxHQUNwQyxJQUFJLEtBQUssYUFBYSxLQUFLLFdBQVcsSUFBSSxFQUFFLENBQUMsQ0FBQyxRQUFRLEtBQUssR0FBRyxPQUFPO0VBRXZFLE9BQU87Q0FDVDtDQUNBLGdCQUFnQixhQUFhO0VBQzNCLE1BQU0sS0FBSyxXQUFXLFdBQVc7RUFDakMsT0FBTyxLQUFLLFdBQVcsSUFBSSxFQUFFLElBQUksS0FBSyxXQUFXLElBQUksRUFBRSxDQUFDLENBQUMsU0FBUztDQUNwRTtBQXlCRjs7b0RBeEJTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsMkNBQTJDLG1CQUFtQjtFQUM1RSxRQUFRLG9EQUFvRCxrREFBa0RULHNCQUF5QjJDLG1DQUFrQyxHQUFBLENBQUkscUJBQXFCQSxtQ0FBa0M7Q0FDdE87QUFDRixFQUFBLENBQUcsQ0FBQTtvREFDSSxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXO0VBQUM7R0FBQztHQUFVO0dBQVk7R0FBSTtHQUFtQjtHQUFJO0dBQUc7R0FBVztFQUFFO0VBQUc7R0FBQztHQUFVO0dBQVk7R0FBSTtHQUFlO0dBQUk7R0FBRztHQUFXO0VBQUU7RUFBRztHQUFDO0dBQVU7R0FBWTtHQUFJO0dBQVc7R0FBSTtHQUFHO0dBQVc7RUFBRTtDQUFDO0NBQzdNLGNBQWMsU0FBUyxnREFBZ0QsSUFBSSxLQUFLO0VBQzlFLElBQUksS0FBSyxHQUNQLFdBQWMsVUFBVSxTQUFTLDZEQUE2RCxRQUFRO0dBQ3BHLE9BQU8sSUFBSSxTQUFTLE9BQU8sTUFBTTtFQUNuQyxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsNkRBQTZEO0dBQy9FLE9BQU8sSUFBSSxVQUFVO0VBQ3ZCLENBQUM7Q0FFTDtDQUNBLFFBQVEsRUFDTixhQUFhLGNBQ2Y7Q0FDQSxZQUFZO0NBQ1osVUFBVSxDQUFDdkMsbUJBQXNCLENBQUMsOEJBQThCLENBQUMsR0FBR0YsMEJBQTZCO0FBQ25HLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjSCxpQkFBcUIsb0NBQW9DLENBQUM7RUFDM0csTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixNQUFNO0lBQ0osWUFBWTtJQUNaLFVBQVU7R0FDWjtHQUNBLFdBQVcsQ0FBQyw4QkFBOEI7R0FDMUMsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxFQUNSLGFBQWEsQ0FBQyxFQUNaLE1BQU0sTUFDUixDQUFDLEVBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILElBQU0sMEJBQU4sTUFBOEI7Q0FNNUIsWUFBWSxVQUFVLFdBQVcsU0FBUzt3QkFMMUMsWUFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7d0JBQ0EsV0FBQSxLQUFBLENBQUE7d0JBQ0EsTUFBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLFdBQVc7RUFDaEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssVUFBVTtFQUNmLElBQUksS0FBSyxTQUNQLEtBQUssS0FBSyxLQUFLLFFBQVEsZ0JBQWdCLElBQUk7Q0FFL0M7Q0FDQSxJQUFJLFFBQVEsT0FBTztFQUNqQixJQUFJLEtBQUssV0FBVyxNQUFNO0VBQzFCLEtBQUssU0FBUztFQUNkLEtBQUssaUJBQWlCLGtCQUFrQixLQUFLLElBQUksS0FBSyxDQUFDO0VBQ3ZELEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxLQUFLO0NBQzVDO0NBQ0EsSUFBSSxNQUFNLE9BQU87RUFDZixJQUFJLEtBQUssU0FBUztHQUNoQixLQUFLLFNBQVM7R0FDZCxLQUFLLGlCQUFpQixrQkFBa0IsS0FBSyxJQUFJLEtBQUssQ0FBQztHQUN2RCxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsS0FBSztFQUM1QyxPQUNFLEtBQUssaUJBQWlCLEtBQUs7Q0FFL0I7Q0FDQSxpQkFBaUIsT0FBTztFQUN0QixLQUFLLFVBQVUsWUFBWSxLQUFLLFNBQVMsZUFBZSxTQUFTLEtBQUs7Q0FDeEU7Q0FDQSxhQUFhLFVBQVU7RUFDckIsS0FBSyxVQUFVLFlBQVksS0FBSyxTQUFTLGVBQWUsWUFBWSxRQUFRO0NBQzlFO0NBQ0EsY0FBYztFQUNaLElBQUksS0FBSyxTQUFTO0dBQ2hCLEtBQUssUUFBUSxXQUFXLE9BQU8sS0FBSyxFQUFFO0dBQ3RDLEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxLQUFLO0VBQzVDO0NBQ0Y7QUFjRjs7eUNBYlMsUUFBTyxTQUFTLGdDQUFnQyxtQkFBbUI7Q0FFeEUsT0FBTyxLQUFLLHFCQUFxQjZDLDBCQUF5QmhELGtCQUFxQkUsVUFBYSxHQUFHRixrQkFBcUJDLFNBQVksR0FBR0Qsa0JBQXFCLG9DQUFvQyxDQUFDLENBQUM7QUFDaE0sQ0FBQTt5Q0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTWdEO0NBQ04sV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDO0NBQ3RCLFFBQVE7RUFDTixTQUFTO0VBQ1QsT0FBTztDQUNUO0NBQ0EsWUFBWTtBQUNkLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjN0MsaUJBQXFCLHlCQUF5QixDQUFDO0VBQ2hHLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsWUFBWTtFQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVM7RUFBQyxFQUNULE1BQU1ELFdBQ1I7RUFBRyxFQUNELE1BQU1ELFVBQ1I7RUFBRztHQUNELE1BQU07R0FDTixZQUFZLENBQUMsRUFDWCxNQUFNLFNBQ1IsR0FBRyxFQUNELE1BQU0sS0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHO0VBQ0YsU0FBUyxDQUFDO0dBQ1IsTUFBTTtHQUNOLE1BQU0sQ0FBQyxTQUFTO0VBQ2xCLENBQUM7RUFDRCxPQUFPLENBQUM7R0FDTixNQUFNO0dBQ04sTUFBTSxDQUFDLE9BQU87RUFDaEIsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLHlCQUF5QjtDQUFDO0NBQWU7Q0FBZ0I7Q0FBeUI7Q0FBc0I7Q0FBcUI7Q0FBb0I7Q0FBOEI7Q0FBNEI7Q0FBb0M7Q0FBMkI7Q0FBaUI7Q0FBc0I7Q0FBbUI7Q0FBb0I7Q0FBb0I7Q0FBa0I7Q0FBMkI7Q0FBZ0I7Q0FBYztBQUFZO0FBQ3pjLElBQU0sNkJBQTZCO0NBQUM7Q0FBUztDQUFjO0FBQU07QUFDakUsSUFBTSw2QkFBNkI7Q0FBQztDQUFzQjtDQUFvQjtDQUFvQjtDQUFpQjtDQUFlO0FBQWE7QUFDL0ksSUFBTSw2QkFBTixNQUFpQyxDQVVqQzs7NENBVFMsUUFBTyxTQUFTLG1DQUFtQyxtQkFBbUI7Q0FDM0UsT0FBTyxLQUFLLHFCQUFxQmdELDZCQUE0QjtBQUMvRCxDQUFBOzRDQUNPLFFBQXNCLGlDQUFvQjtDQUMvQyxNQUFNQTtDQUNOLGNBQWM7RUFBQztFQUFlO0VBQWdCO0VBQXlCO0VBQXNCO0VBQXFCO0VBQW9CO0VBQThCO0VBQTRCO0VBQW9DO0VBQTJCO0VBQWlCO0VBQXNCO0VBQW1CO0VBQW9CO0VBQW9CO0VBQWtCO0VBQTJCO0VBQWdCO0VBQWM7Q0FBWTtDQUN4YixTQUFTO0VBQUM7RUFBZTtFQUFnQjtFQUF5QjtFQUFzQjtFQUFxQjtFQUFvQjtFQUE4QjtFQUE0QjtFQUFvQztFQUEyQjtFQUFpQjtFQUFzQjtFQUFtQjtFQUFvQjtFQUFvQjtFQUFrQjtFQUEyQjtFQUFnQjtFQUFjO0NBQVk7QUFDcmIsQ0FBQyxDQUFBOzRDQUNNLFFBQXNCLGlDQUFvQixDQUFDLENBQUMsQ0FBQTtPQUU5QztDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYzlDLGlCQUFxQiw0QkFBNEIsQ0FBQztFQUNuRyxNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsY0FBYztHQUNkLFNBQVM7RUFDWCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxTQUFTLHlCQUF5QixTQUFTO0NBQ3pDLE9BQU8sQ0FBQyxDQUFDLFlBQVksUUFBUSxvQkFBb0IsS0FBQSxLQUFhLFFBQVEsZUFBZSxLQUFBLEtBQWEsUUFBUSxhQUFhLEtBQUE7QUFDekg7QUFDQSxJQUFNLGNBQU4sTUFBTSxZQUFZOzt3QkFDaEIsa0JBQWlCLEtBQUE7O0NBQ2pCLElBQUksY0FBYztFQUNoQixNQUFNLE9BQU8sSUFBSSxZQUFZO0VBQzdCLEtBQUssaUJBQWlCO0VBQ3RCLE9BQU87Q0FDVDtDQUNBLE1BQU0sVUFBVSxVQUFVLE1BQU07RUFDOUIsTUFBTSxrQkFBa0IsS0FBSyxnQkFBZ0IsUUFBUTtFQUNyRCxJQUFJLGFBQWEsQ0FBQztFQUNsQixJQUFJLHlCQUF5QixPQUFPLEdBQ2xDLGFBQWE7T0FDUixJQUFJLFlBQVksTUFBTTtHQUMzQixXQUFXLGFBQWEsUUFBUTtHQUNoQyxXQUFXLGtCQUFrQixRQUFRO0VBQ3ZDO0VBQ0EsT0FBTyxJQUFJLFVBQVUsaUJBQWlCLFVBQVU7Q0FDbEQ7Q0FDQSxPQUFPLFVBQVUsVUFBVSxNQUFNO0VBRS9CLE9BQU8sSUFBSSxXQURhLEtBQUssZ0JBQWdCLFFBQ3ZCLEdBQWlCLE9BQU87Q0FDaEQ7Q0FDQSxRQUFRLFdBQVcsaUJBQWlCLGdCQUFnQjtFQUNsRCxJQUFJLGFBQWEsQ0FBQztFQUNsQixJQUFJLENBQUMsS0FBSyxnQkFDUixPQUFPLElBQUksWUFBWSxXQUFXLGlCQUFpQixjQUFjO0VBRW5FLElBQUkseUJBQXlCLGVBQWUsR0FDMUMsYUFBYTtPQUNSO0dBQ0wsV0FBVyxhQUFhO0dBQ3hCLFdBQVcsa0JBQWtCO0VBQy9CO0VBQ0EsT0FBTyxJQUFJLFlBQVksV0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNsQixVQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ0gsYUFBYSxLQUFBLENBQ2YsQ0FBQztDQUNIO0NBQ0EsTUFBTSxVQUFVLGlCQUFpQixnQkFBZ0I7RUFFL0MsT0FBTyxJQUFJLFVBRGEsU0FBUyxLQUFJLE1BQUssS0FBSyxlQUFlLENBQUMsQ0FDMUMsR0FBaUIsaUJBQWlCLGNBQWM7Q0FDdkU7Q0FDQSxnQkFBZ0IsVUFBVTtFQUN4QixNQUFNLGtCQUFrQixDQUFDO0VBQ3pCLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFRLGdCQUFlO0dBQzNDLGdCQUFnQixlQUFlLEtBQUssZUFBZSxTQUFTLFlBQVk7RUFDMUUsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLGVBQWUsVUFBVTtFQUN2QixJQUFJLG9CQUFvQixhQUN0QixPQUFPO09BQ0YsSUFBSSxvQkFBb0IsaUJBQzdCLE9BQU87T0FDRixJQUFJLE1BQU0sUUFBUSxRQUFRLEdBQUc7R0FDbEMsTUFBTSxRQUFRLFNBQVM7R0FDdkIsTUFBTSxZQUFZLFNBQVMsU0FBUyxJQUFJLFNBQVMsS0FBSztHQUN0RCxNQUFNLGlCQUFpQixTQUFTLFNBQVMsSUFBSSxTQUFTLEtBQUs7R0FDM0QsT0FBTyxLQUFLLFFBQVEsT0FBTyxXQUFXLGNBQWM7RUFDdEQsT0FDRSxPQUFPLEtBQUssUUFBUSxRQUFRO0NBRWhDO0FBUUY7OzZCQVBTLFFBQU8sU0FBUyxvQkFBb0IsbUJBQW1CO0NBQzVELE9BQU8sS0FBSyxxQkFBcUIrQyxjQUFhO0FBQ2hELENBQUE7NkJBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0EsYUFBWTtBQUN2QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYy9DLGlCQUFxQixhQUFhLENBQUMsRUFDcEYsTUFBTSxRQUNSLENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSx5QkFBTixNQUE2QixDQVE3Qjs7d0NBUFMsUUFBTyxTQUFTLCtCQUErQixtQkFBbUI7Q0FDdkUsT0FBTyxLQUFLLHFCQUFxQmdELHlCQUF3QjtBQUMzRCxDQUFBO3dDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLHNCQUFzQixPQUFPLFdBQVcsQ0FBQyxDQUFDLFlBQUEsQ0FBYTtBQUN6RCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2hELGlCQUFxQix3QkFBd0IsQ0FBQztFQUMvRixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsZUFBZSxPQUFPLFdBQVcsQ0FBQyxDQUFDLFlBQ3JDLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0scUJBQU4sY0FBaUMsWUFBWTtDQUMzQyxNQUFNLGdCQUFnQixVQUFVLE1BQU07RUFDcEMsT0FBTyxNQUFNLE1BQU0sZ0JBQWdCLE9BQU87Q0FDNUM7Q0FDQSxRQUFRLFdBQVcsaUJBQWlCLGdCQUFnQjtFQUNsRCxPQUFPLE1BQU0sUUFBUSxXQUFXLGlCQUFpQixjQUFjO0NBQ2pFO0NBQ0EsTUFBTSxnQkFBZ0IsaUJBQWlCLGdCQUFnQjtFQUNyRCxPQUFPLE1BQU0sTUFBTSxnQkFBZ0IsaUJBQWlCLGNBQWM7Q0FDcEU7QUFRRjs7b0NBUFMsUUFBTyxTQUFTLDJCQUEyQixtQkFBbUI7Q0FDbkUsT0FBTyxLQUFLLHFCQUFxQmlELHFCQUFvQjtBQUN2RCxDQUFBO29DQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLG9CQUFtQjtBQUM5QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2pELGlCQUFxQixvQkFBb0IsQ0FBQyxFQUMzRixNQUFNLFFBQ1IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLGNBQU4sTUFBTSxZQUFZO0NBQ2hCLE9BQU8sV0FBVyxNQUFNOztFQUN0QixPQUFPO0dBQ0wsVUFBVTtHQUNWLFdBQVcsQ0FBQztJQUNWLFNBQVM7SUFDVCxXQUFBLHdCQUFVLEtBQUssMEJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQXdCO0dBQ3pDLENBQUM7RUFDSDtDQUNGO0FBWUY7OzZCQVhTLFFBQU8sU0FBUyxvQkFBb0IsbUJBQW1CO0NBQzVELE9BQU8sS0FBSyxxQkFBcUJrRCxjQUFhO0FBQ2hELENBQUE7NkJBQ08sUUFBc0IsaUNBQW9CO0NBQy9DLE1BQU1BO0NBQ04sY0FBYztFQUFDO0VBQVM7RUFBYztDQUFNO0NBQzVDLFNBQVM7RUFBQztFQUE0QjtFQUFTO0VBQWM7Q0FBTTtBQUNyRSxDQUFDLENBQUE7NkJBQ00sUUFBc0IsaUNBQW9CLEVBQy9DLFNBQVMsQ0FBQywwQkFBMEIsRUFDdEMsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNsRCxpQkFBcUIsYUFBYSxDQUFDO0VBQ3BGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxjQUFjO0dBQ2QsU0FBUyxDQUFDLDRCQUE0QiwwQkFBMEI7RUFDbEUsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxzQkFBTixNQUFNLG9CQUFvQjtDQUN4QixPQUFPLFdBQVcsTUFBTTs7RUFDdEIsT0FBTztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUM7SUFDVixTQUFTO0lBQ1QsV0FBQSx3QkFBVSxLQUFLLGtDQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFnQztHQUNqRCxHQUFHO0lBQ0QsU0FBUztJQUNULFdBQUEseUJBQVUsS0FBSywwQkFBQSxRQUFBLDJCQUFBLEtBQUEsSUFBQSx5QkFBd0I7R0FDekMsQ0FBQztFQUNIO0NBQ0Y7QUFZRjs7cUNBWFMsUUFBTyxTQUFTLDRCQUE0QixtQkFBbUI7Q0FDcEUsT0FBTyxLQUFLLHFCQUFxQm1ELHNCQUFxQjtBQUN4RCxDQUFBO3FDQUNPLFFBQXNCLGlDQUFvQjtDQUMvQyxNQUFNQTtDQUNOLGNBQWM7RUFBQztFQUFzQjtFQUFvQjtFQUFvQjtFQUFpQjtFQUFlO0NBQWE7Q0FDMUgsU0FBUztFQUFDO0VBQTRCO0VBQXNCO0VBQW9CO0VBQW9CO0VBQWlCO0VBQWU7Q0FBYTtBQUNuSixDQUFDLENBQUE7cUNBQ00sUUFBc0IsaUNBQW9CLEVBQy9DLFNBQVMsQ0FBQywwQkFBMEIsRUFDdEMsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNuRCxpQkFBcUIscUJBQXFCLENBQUM7RUFDNUYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLGNBQWMsQ0FBQywwQkFBMEI7R0FDekMsU0FBUyxDQUFDLDRCQUE0QiwwQkFBMEI7RUFDbEUsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHIn0=