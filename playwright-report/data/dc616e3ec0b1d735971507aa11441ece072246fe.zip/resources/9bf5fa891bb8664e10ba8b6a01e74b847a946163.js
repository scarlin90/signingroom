import { t as _defineProperty } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/defineProperty-wQpB4Zl9.js?v=cf17c1b4";
import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
import { Bn as LOCALE_ID, Dn as Host, Do as ɵɵgetInheritedFactory, Ec as Injector, El as ɵɵdefineInjector, En as ElementRef, Er as ViewContainerRef, Fn as Injectable, Hc as RuntimeError, In as Input, Io as ɵɵinjectAttribute, Jr as createNgModule, Kc as Version, Ni as registerLocaleData$1, O as booleanAttribute, Pc as NgZone, Pn as Inject, Qi as unwrapSafeValue, Qn as Optional, Qr as findLocaleData, Rs as ɵɵstyleProp, Sl as stringify, Tc as InjectionToken, Ti as performanceMarkFeature, Tl as ɵɵdefineInjectable, Ui as setClassMetadata, Vn as LocaleDataIndex, Zn as NgModuleRef$1, ao as ɵɵdirectiveInject, bc as IMAGE_CONFIG, ca as ɵɵNgOnChangesFeature, di as getLocalePluralCase$1, dr as Service, er as Pipe, io as ɵɵdefineService, ir as Renderer2, kl as ɵɵinject, ll as isSignal, m as KeyValueDiffers, mc as DestroyRef, mn as DEFAULT_CURRENCY_CODE, nn as Attribute, no as ɵɵdefineNgModule, ol as inject, or as RendererStyleFlags2, p as IterableDiffers, pc as DOCUMENT, qn as NgModule, qt as untracked, r as ChangeDetectorRef, ro as ɵɵdefinePipe, rt as numberAttribute, tl as formatRuntimeError, tn as ApplicationRef, to as ɵɵdefineDirective, ui as getLocaleCurrencyCode$1, vi as isPromise, vr as TemplateRef, wc as INTERNAL_APPLICATION_ERROR_HANDLER, wn as Directive, xc as IMAGE_CONFIG_DEFAULTS, yi as isSubscribable } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/core-BV_jmGG7.js?v=cf17c1b4";
import { Wn as Subject } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zipWith-DkrnN79P.js?v=cf17c1b4";
import { t as _asyncToGenerator } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/asyncToGenerator-B0cJ8fiL.js?v=cf17c1b4";
import { o as PlatformLocation } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/_xhr-chunk-CYugLJIp.js?v=cf17c1b4";
//#region node_modules/@angular/common/fesm2022/_location-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _LocationStrategy;
var _PathLocationStrategy;
var _NoTrailingSlashPathLocationStrategy;
var _TrailingSlashPathLocationStrategy;
var _Location;
function joinWithSlash(start, end) {
	if (!start) return end;
	if (!end) return start;
	if (start.endsWith("/")) return end.startsWith("/") ? start + end.slice(1) : start + end;
	return end.startsWith("/") ? start + end : `${start}/${end}`;
}
function stripTrailingSlash(url) {
	const pathEndIdx = url.search(/#|\?|$/);
	return url[pathEndIdx - 1] === "/" ? url.slice(0, pathEndIdx - 1) + url.slice(pathEndIdx) : url;
}
function normalizeQueryParams(params) {
	return params && params[0] !== "?" ? `?${params}` : params;
}
var LocationStrategy = class {
	historyGo(relativePosition) {
		throw new Error(ngDevMode ? "Not implemented" : "");
	}
};
_LocationStrategy = LocationStrategy;
_defineProperty(LocationStrategy, "ɵfac", function LocationStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _LocationStrategy)();
});
_defineProperty(LocationStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _LocationStrategy,
	factory: () => (() => inject(PathLocationStrategy))(),
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocationStrategy, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useFactory: () => inject(PathLocationStrategy)
		}]
	}], null, null);
})();
var APP_BASE_HREF = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "appBaseHref" : "");
var PathLocationStrategy = class extends LocationStrategy {
	constructor(_platformLocation, href) {
		var _ref, _ref2, _inject$location;
		super();
		_defineProperty(this, "_platformLocation", void 0);
		_defineProperty(this, "_baseHref", void 0);
		_defineProperty(this, "_removeListenerFns", []);
		this._platformLocation = _platformLocation;
		this._baseHref = (_ref = (_ref2 = href !== null && href !== void 0 ? href : this._platformLocation.getBaseHrefFromDOM()) !== null && _ref2 !== void 0 ? _ref2 : (_inject$location = inject(DOCUMENT).location) === null || _inject$location === void 0 ? void 0 : _inject$location.origin) !== null && _ref !== void 0 ? _ref : "";
	}
	ngOnDestroy() {
		while (this._removeListenerFns.length) this._removeListenerFns.pop()();
	}
	onPopState(fn) {
		this._removeListenerFns.push(this._platformLocation.onPopState(fn), this._platformLocation.onHashChange(fn));
	}
	getBaseHref() {
		return this._baseHref;
	}
	prepareExternalUrl(internal) {
		return joinWithSlash(this._baseHref, internal);
	}
	path(includeHash = false) {
		const pathname = this._platformLocation.pathname + normalizeQueryParams(this._platformLocation.search);
		const hash = this._platformLocation.hash;
		return hash && includeHash ? `${pathname}${hash}` : pathname;
	}
	pushState(state, title, url, queryParams) {
		const externalUrl = this.prepareExternalUrl(url + normalizeQueryParams(queryParams));
		this._platformLocation.pushState(state, title, externalUrl);
	}
	replaceState(state, title, url, queryParams) {
		const externalUrl = this.prepareExternalUrl(url + normalizeQueryParams(queryParams));
		this._platformLocation.replaceState(state, title, externalUrl);
	}
	forward() {
		this._platformLocation.forward();
	}
	back() {
		this._platformLocation.back();
	}
	getState() {
		return this._platformLocation.getState();
	}
	historyGo(relativePosition = 0) {
		var _this$_platformLocati, _this$_platformLocati2;
		(_this$_platformLocati = (_this$_platformLocati2 = this._platformLocation).historyGo) === null || _this$_platformLocati === void 0 || _this$_platformLocati.call(_this$_platformLocati2, relativePosition);
	}
};
_PathLocationStrategy = PathLocationStrategy;
_defineProperty(PathLocationStrategy, "ɵfac", function PathLocationStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _PathLocationStrategy)(ɵɵinject(PlatformLocation), ɵɵinject(APP_BASE_HREF, 8));
});
_defineProperty(PathLocationStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _PathLocationStrategy,
	factory: _PathLocationStrategy.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PathLocationStrategy, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: PlatformLocation }, {
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [APP_BASE_HREF]
		}]
	}], null);
})();
var NoTrailingSlashPathLocationStrategy = class extends PathLocationStrategy {
	prepareExternalUrl(internal) {
		const path = extractUrlPath(internal);
		if (path.endsWith("/") && path.length > 1) internal = path.slice(0, -1) + internal.slice(path.length);
		return super.prepareExternalUrl(internal);
	}
};
_NoTrailingSlashPathLocationStrategy = NoTrailingSlashPathLocationStrategy;
_defineProperty(NoTrailingSlashPathLocationStrategy, "ɵfac", /* @__PURE__ */ (() => {
	let ɵNoTrailingSlashPathLocationStrategy_BaseFactory;
	return function NoTrailingSlashPathLocationStrategy_Factory(__ngFactoryType__) {
		return (ɵNoTrailingSlashPathLocationStrategy_BaseFactory || (ɵNoTrailingSlashPathLocationStrategy_BaseFactory = ɵɵgetInheritedFactory(_NoTrailingSlashPathLocationStrategy)))(__ngFactoryType__ || _NoTrailingSlashPathLocationStrategy);
	};
})());
_defineProperty(NoTrailingSlashPathLocationStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _NoTrailingSlashPathLocationStrategy,
	factory: _NoTrailingSlashPathLocationStrategy.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NoTrailingSlashPathLocationStrategy, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
var TrailingSlashPathLocationStrategy = class extends PathLocationStrategy {
	prepareExternalUrl(internal) {
		const path = extractUrlPath(internal);
		if (!path.endsWith("/")) internal = path + "/" + internal.slice(path.length);
		return super.prepareExternalUrl(internal);
	}
};
_TrailingSlashPathLocationStrategy = TrailingSlashPathLocationStrategy;
_defineProperty(TrailingSlashPathLocationStrategy, "ɵfac", /* @__PURE__ */ (() => {
	let ɵTrailingSlashPathLocationStrategy_BaseFactory;
	return function TrailingSlashPathLocationStrategy_Factory(__ngFactoryType__) {
		return (ɵTrailingSlashPathLocationStrategy_BaseFactory || (ɵTrailingSlashPathLocationStrategy_BaseFactory = ɵɵgetInheritedFactory(_TrailingSlashPathLocationStrategy)))(__ngFactoryType__ || _TrailingSlashPathLocationStrategy);
	};
})());
_defineProperty(TrailingSlashPathLocationStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _TrailingSlashPathLocationStrategy,
	factory: _TrailingSlashPathLocationStrategy.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TrailingSlashPathLocationStrategy, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], null, null);
})();
function extractUrlPath(url) {
	const questionMarkOrHashIndex = url.search(/[?#]/);
	const pathEnd = questionMarkOrHashIndex > -1 ? questionMarkOrHashIndex : url.length;
	return url.slice(0, pathEnd);
}
var Location = class Location {
	constructor(locationStrategy) {
		_defineProperty(this, "_subject", new Subject());
		_defineProperty(this, "_basePath", void 0);
		_defineProperty(this, "_locationStrategy", void 0);
		_defineProperty(this, "_urlChangeListeners", []);
		_defineProperty(this, "_urlChangeSubscription", null);
		this._locationStrategy = locationStrategy;
		const baseHref = this._locationStrategy.getBaseHref();
		this._basePath = _stripOrigin(stripTrailingSlash(_stripIndexHtml(baseHref)));
		this._locationStrategy.onPopState((ev) => {
			this._subject.next({
				"url": this.path(true),
				"pop": true,
				"state": ev.state,
				"type": ev.type
			});
		});
	}
	ngOnDestroy() {
		var _this$_urlChangeSubsc;
		(_this$_urlChangeSubsc = this._urlChangeSubscription) === null || _this$_urlChangeSubsc === void 0 || _this$_urlChangeSubsc.unsubscribe();
		this._urlChangeListeners = [];
	}
	path(includeHash = false) {
		return this.normalize(this._locationStrategy.path(includeHash));
	}
	getState() {
		return this._locationStrategy.getState();
	}
	isCurrentPathEqualTo(path, query = "") {
		return this.path() == this.normalize(path + normalizeQueryParams(query));
	}
	normalize(url) {
		return Location.stripTrailingSlash(_stripBasePath(this._basePath, _stripIndexHtml(url)));
	}
	prepareExternalUrl(url) {
		if (url && url[0] !== "/") url = "/" + url;
		return this._locationStrategy.prepareExternalUrl(url);
	}
	go(path, query = "", state = null) {
		this._locationStrategy.pushState(state, "", path, query);
		this._notifyUrlChangeListeners(this.prepareExternalUrl(path + normalizeQueryParams(query)), state);
	}
	replaceState(path, query = "", state = null) {
		this._locationStrategy.replaceState(state, "", path, query);
		this._notifyUrlChangeListeners(this.prepareExternalUrl(path + normalizeQueryParams(query)), state);
	}
	forward() {
		this._locationStrategy.forward();
	}
	back() {
		this._locationStrategy.back();
	}
	historyGo(relativePosition = 0) {
		var _this$_locationStrate, _this$_locationStrate2;
		(_this$_locationStrate = (_this$_locationStrate2 = this._locationStrategy).historyGo) === null || _this$_locationStrate === void 0 || _this$_locationStrate.call(_this$_locationStrate2, relativePosition);
	}
	onUrlChange(fn) {
		var _this$_urlChangeSubsc2;
		this._urlChangeListeners.push(fn);
		(_this$_urlChangeSubsc2 = this._urlChangeSubscription) !== null && _this$_urlChangeSubsc2 !== void 0 || (this._urlChangeSubscription = this.subscribe((v) => {
			this._notifyUrlChangeListeners(v.url, v.state);
		}));
		return () => {
			const fnIndex = this._urlChangeListeners.indexOf(fn);
			this._urlChangeListeners.splice(fnIndex, 1);
			if (this._urlChangeListeners.length === 0) {
				var _this$_urlChangeSubsc3;
				(_this$_urlChangeSubsc3 = this._urlChangeSubscription) === null || _this$_urlChangeSubsc3 === void 0 || _this$_urlChangeSubsc3.unsubscribe();
				this._urlChangeSubscription = null;
			}
		};
	}
	_notifyUrlChangeListeners(url = "", state) {
		this._urlChangeListeners.forEach((fn) => fn(url, state));
	}
	subscribe(onNext, onThrow, onReturn) {
		return this._subject.subscribe({
			next: onNext,
			error: onThrow !== null && onThrow !== void 0 ? onThrow : void 0,
			complete: onReturn !== null && onReturn !== void 0 ? onReturn : void 0
		});
	}
};
_Location = Location;
_defineProperty(Location, "normalizeQueryParams", normalizeQueryParams);
_defineProperty(Location, "joinWithSlash", joinWithSlash);
_defineProperty(Location, "stripTrailingSlash", stripTrailingSlash);
_defineProperty(Location, "ɵfac", function Location_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _Location)(ɵɵinject(LocationStrategy));
});
_defineProperty(Location, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _Location,
	factory: () => createLocation(),
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Location, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useFactory: createLocation
		}]
	}], () => [{ type: LocationStrategy }], null);
})();
function createLocation() {
	return new Location(ɵɵinject(LocationStrategy));
}
function _stripBasePath(basePath, url) {
	if (!basePath || !url.startsWith(basePath)) return url;
	const strippedUrl = url.substring(basePath.length);
	if (strippedUrl === "" || [
		"/",
		";",
		"?",
		"#"
	].includes(strippedUrl[0])) return strippedUrl;
	return url;
}
function _stripIndexHtml(url) {
	return url.replace(/\/index\.html$/, "");
}
function _stripOrigin(baseHref) {
	if ((/* @__PURE__ */ new RegExp("^(https?:)?//")).test(baseHref)) {
		const [, pathname] = baseHref.split(/\/\/[^\/]+/);
		return pathname;
	}
	return baseHref;
}
//#endregion
//#region node_modules/@angular/common/fesm2022/_common_module-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _HashLocationStrategy;
var _NgLocalization;
var _NgLocaleLocalization;
var _NgClass;
var _NgComponentOutlet;
var _NgForOf;
var _NgIf;
var _NgSwitch;
var _NgSwitchCase;
var _NgSwitchDefault;
var _NgPlural;
var _NgPluralCase;
var _NgStyle;
var _NgTemplateOutlet;
var _AsyncPipe;
var _LowerCasePipe;
var _TitleCasePipe;
var _UpperCasePipe;
var _DatePipe;
var _I18nPluralPipe;
var _I18nSelectPipe;
var _JsonPipe;
var _KeyValuePipe;
var _DecimalPipe;
var _PercentPipe;
var _CurrencyPipe;
var _SlicePipe;
var _CommonModule;
var HashLocationStrategy = class extends LocationStrategy {
	constructor(_platformLocation, _baseHref) {
		super();
		_defineProperty(this, "_platformLocation", void 0);
		_defineProperty(this, "_baseHref", "");
		_defineProperty(this, "_removeListenerFns", []);
		this._platformLocation = _platformLocation;
		if (_baseHref != null) this._baseHref = _baseHref;
	}
	ngOnDestroy() {
		while (this._removeListenerFns.length) this._removeListenerFns.pop()();
	}
	onPopState(fn) {
		this._removeListenerFns.push(this._platformLocation.onPopState(fn), this._platformLocation.onHashChange(fn));
	}
	getBaseHref() {
		return this._baseHref;
	}
	path(includeHash = false) {
		var _this$_platformLocati;
		const path = (_this$_platformLocati = this._platformLocation.hash) !== null && _this$_platformLocati !== void 0 ? _this$_platformLocati : "#";
		return path.length > 0 ? path.substring(1) : path;
	}
	prepareExternalUrl(internal) {
		const url = joinWithSlash(this._baseHref, internal);
		return url.length > 0 ? "#" + url : url;
	}
	pushState(state, title, path, queryParams) {
		const url = this.prepareExternalUrl(path + normalizeQueryParams(queryParams)) || this._platformLocation.pathname;
		this._platformLocation.pushState(state, title, url);
	}
	replaceState(state, title, path, queryParams) {
		const url = this.prepareExternalUrl(path + normalizeQueryParams(queryParams)) || this._platformLocation.pathname;
		this._platformLocation.replaceState(state, title, url);
	}
	forward() {
		this._platformLocation.forward();
	}
	back() {
		this._platformLocation.back();
	}
	getState() {
		return this._platformLocation.getState();
	}
	historyGo(relativePosition = 0) {
		var _this$_platformLocati2, _this$_platformLocati3;
		(_this$_platformLocati2 = (_this$_platformLocati3 = this._platformLocation).historyGo) === null || _this$_platformLocati2 === void 0 || _this$_platformLocati2.call(_this$_platformLocati3, relativePosition);
	}
};
_HashLocationStrategy = HashLocationStrategy;
_defineProperty(HashLocationStrategy, "ɵfac", function HashLocationStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HashLocationStrategy)(ɵɵinject(PlatformLocation), ɵɵinject(APP_BASE_HREF, 8));
});
_defineProperty(HashLocationStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _HashLocationStrategy,
	factory: _HashLocationStrategy.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HashLocationStrategy, [{ type: Injectable }], () => [{ type: PlatformLocation }, {
		type: void 0,
		decorators: [{ type: Optional }, {
			type: Inject,
			args: [APP_BASE_HREF]
		}]
	}], null);
})();
var CURRENCIES_EN = {
	"ADP": [
		void 0,
		void 0,
		0
	],
	"AFN": [
		void 0,
		"؋",
		0
	],
	"ALL": [
		void 0,
		void 0,
		0
	],
	"AMD": [
		void 0,
		"֏",
		2
	],
	"AOA": [void 0, "Kz"],
	"ARS": [void 0, "$"],
	"AUD": ["A$", "$"],
	"AZN": [void 0, "₼"],
	"BAM": [void 0, "KM"],
	"BBD": [void 0, "$"],
	"BDT": [void 0, "৳"],
	"BHD": [
		void 0,
		void 0,
		3
	],
	"BIF": [
		void 0,
		void 0,
		0
	],
	"BMD": [void 0, "$"],
	"BND": [void 0, "$"],
	"BOB": [void 0, "Bs"],
	"BRL": ["R$"],
	"BSD": [void 0, "$"],
	"BWP": [void 0, "P"],
	"BYN": [
		void 0,
		void 0,
		2
	],
	"BYR": [
		void 0,
		void 0,
		0
	],
	"BZD": [void 0, "$"],
	"CAD": [
		"CA$",
		"$",
		2
	],
	"CHF": [
		void 0,
		void 0,
		2
	],
	"CLF": [
		void 0,
		void 0,
		4
	],
	"CLP": [
		void 0,
		"$",
		0
	],
	"CNY": ["CN¥", "¥"],
	"COP": [
		void 0,
		"$",
		2
	],
	"CRC": [
		void 0,
		"₡",
		2
	],
	"CUC": [void 0, "$"],
	"CUP": [void 0, "$"],
	"CZK": [
		void 0,
		"Kč",
		2
	],
	"DJF": [
		void 0,
		void 0,
		0
	],
	"DKK": [
		void 0,
		"kr",
		2
	],
	"DOP": [void 0, "$"],
	"EGP": [void 0, "E£"],
	"ESP": [
		void 0,
		"₧",
		0
	],
	"EUR": ["€"],
	"FJD": [void 0, "$"],
	"FKP": [void 0, "£"],
	"GBP": ["£"],
	"GEL": [void 0, "₾"],
	"GHS": [void 0, "GH₵"],
	"GIP": [void 0, "£"],
	"GNF": [
		void 0,
		"FG",
		0
	],
	"GTQ": [void 0, "Q"],
	"GYD": [
		void 0,
		"$",
		2
	],
	"HKD": ["HK$", "$"],
	"HNL": [void 0, "L"],
	"HRK": [void 0, "kn"],
	"HUF": [
		void 0,
		"Ft",
		2
	],
	"IDR": [
		void 0,
		"Rp",
		2
	],
	"ILS": ["₪"],
	"INR": ["₹"],
	"IQD": [
		void 0,
		void 0,
		0
	],
	"IRR": [
		void 0,
		void 0,
		0
	],
	"ISK": [
		void 0,
		"kr",
		0
	],
	"ITL": [
		void 0,
		void 0,
		0
	],
	"JMD": [void 0, "$"],
	"JOD": [
		void 0,
		void 0,
		3
	],
	"JPY": [
		"¥",
		void 0,
		0
	],
	"KGS": [void 0, "⃀"],
	"KHR": [void 0, "៛"],
	"KMF": [
		void 0,
		"CF",
		0
	],
	"KPW": [
		void 0,
		"₩",
		0
	],
	"KRW": [
		"₩",
		void 0,
		0
	],
	"KWD": [
		void 0,
		void 0,
		3
	],
	"KYD": [void 0, "$"],
	"KZT": [void 0, "₸"],
	"LAK": [
		void 0,
		"₭",
		0
	],
	"LBP": [
		void 0,
		"L£",
		0
	],
	"LKR": [void 0, "Rs"],
	"LRD": [void 0, "$"],
	"LTL": [void 0, "Lt"],
	"LUF": [
		void 0,
		void 0,
		0
	],
	"LVL": [void 0, "Ls"],
	"LYD": [
		void 0,
		void 0,
		3
	],
	"MGA": [
		void 0,
		"Ar",
		0
	],
	"MGF": [
		void 0,
		void 0,
		0
	],
	"MMK": [
		void 0,
		"K",
		0
	],
	"MNT": [
		void 0,
		"₮",
		2
	],
	"MRO": [
		void 0,
		void 0,
		0
	],
	"MUR": [
		void 0,
		"Rs",
		2
	],
	"MXN": ["MX$", "$"],
	"MYR": [void 0, "RM"],
	"NAD": [void 0, "$"],
	"NGN": [void 0, "₦"],
	"NIO": [void 0, "C$"],
	"NOK": [
		void 0,
		"kr",
		2
	],
	"NPR": [void 0, "Rs"],
	"NZD": ["NZ$", "$"],
	"OMR": [
		void 0,
		void 0,
		3
	],
	"PHP": ["₱"],
	"PKR": [
		void 0,
		"Rs",
		2
	],
	"PLN": [void 0, "zł"],
	"PYG": [
		void 0,
		"₲",
		0
	],
	"RON": [void 0, "lei"],
	"RSD": [
		void 0,
		void 0,
		0
	],
	"RUB": [void 0, "₽"],
	"RWF": [
		void 0,
		"RF",
		0
	],
	"SBD": [void 0, "$"],
	"SEK": [
		void 0,
		"kr",
		2
	],
	"SGD": [void 0, "$"],
	"SHP": [void 0, "£"],
	"SLE": [
		void 0,
		void 0,
		2
	],
	"SLL": [
		void 0,
		void 0,
		0
	],
	"SOS": [
		void 0,
		void 0,
		0
	],
	"SRD": [void 0, "$"],
	"SSP": [void 0, "£"],
	"STD": [
		void 0,
		void 0,
		0
	],
	"STN": [void 0, "Db"],
	"SYP": [
		void 0,
		"£",
		0
	],
	"THB": [void 0, "฿"],
	"TMM": [
		void 0,
		void 0,
		0
	],
	"TND": [
		void 0,
		void 0,
		3
	],
	"TOP": [void 0, "T$"],
	"TRL": [
		void 0,
		void 0,
		0
	],
	"TRY": [void 0, "₺"],
	"TTD": [void 0, "$"],
	"TWD": [
		"NT$",
		"$",
		2
	],
	"TZS": [
		void 0,
		void 0,
		2
	],
	"UAH": [void 0, "₴"],
	"UGX": [
		void 0,
		void 0,
		0
	],
	"USD": ["$"],
	"UYI": [
		void 0,
		void 0,
		0
	],
	"UYU": [void 0, "$"],
	"UYW": [
		void 0,
		void 0,
		4
	],
	"UZS": [
		void 0,
		void 0,
		2
	],
	"VEF": [
		void 0,
		"Bs",
		2
	],
	"VND": [
		"₫",
		void 0,
		0
	],
	"VUV": [
		void 0,
		void 0,
		0
	],
	"XAF": [
		"FCFA",
		void 0,
		0
	],
	"XCD": ["EC$", "$"],
	"XCG": ["Cg."],
	"XOF": [
		"F CFA",
		void 0,
		0
	],
	"XPF": [
		"CFPF",
		void 0,
		0
	],
	"XXX": ["¤"],
	"YER": [
		void 0,
		void 0,
		0
	],
	"ZAR": [void 0, "R"],
	"ZMK": [
		void 0,
		void 0,
		0
	],
	"ZMW": [void 0, "ZK"],
	"ZWD": [
		void 0,
		void 0,
		0
	]
};
var NumberFormatStyle;
(function(NumberFormatStyle) {
	NumberFormatStyle[NumberFormatStyle["Decimal"] = 0] = "Decimal";
	NumberFormatStyle[NumberFormatStyle["Percent"] = 1] = "Percent";
	NumberFormatStyle[NumberFormatStyle["Currency"] = 2] = "Currency";
	NumberFormatStyle[NumberFormatStyle["Scientific"] = 3] = "Scientific";
})(NumberFormatStyle || (NumberFormatStyle = {}));
var Plural;
(function(Plural) {
	Plural[Plural["Zero"] = 0] = "Zero";
	Plural[Plural["One"] = 1] = "One";
	Plural[Plural["Two"] = 2] = "Two";
	Plural[Plural["Few"] = 3] = "Few";
	Plural[Plural["Many"] = 4] = "Many";
	Plural[Plural["Other"] = 5] = "Other";
})(Plural || (Plural = {}));
var FormStyle;
(function(FormStyle) {
	FormStyle[FormStyle["Format"] = 0] = "Format";
	FormStyle[FormStyle["Standalone"] = 1] = "Standalone";
})(FormStyle || (FormStyle = {}));
var TranslationWidth;
(function(TranslationWidth) {
	TranslationWidth[TranslationWidth["Narrow"] = 0] = "Narrow";
	TranslationWidth[TranslationWidth["Abbreviated"] = 1] = "Abbreviated";
	TranslationWidth[TranslationWidth["Wide"] = 2] = "Wide";
	TranslationWidth[TranslationWidth["Short"] = 3] = "Short";
})(TranslationWidth || (TranslationWidth = {}));
var FormatWidth;
(function(FormatWidth) {
	FormatWidth[FormatWidth["Short"] = 0] = "Short";
	FormatWidth[FormatWidth["Medium"] = 1] = "Medium";
	FormatWidth[FormatWidth["Long"] = 2] = "Long";
	FormatWidth[FormatWidth["Full"] = 3] = "Full";
})(FormatWidth || (FormatWidth = {}));
var NumberSymbol = {
	Decimal: 0,
	Group: 1,
	List: 2,
	PercentSign: 3,
	PlusSign: 4,
	MinusSign: 5,
	Exponential: 6,
	SuperscriptingExponent: 7,
	PerMille: 8,
	Infinity: 9,
	NaN: 10,
	TimeSeparator: 11,
	CurrencyDecimal: 12,
	CurrencyGroup: 13
};
var WeekDay;
(function(WeekDay) {
	WeekDay[WeekDay["Sunday"] = 0] = "Sunday";
	WeekDay[WeekDay["Monday"] = 1] = "Monday";
	WeekDay[WeekDay["Tuesday"] = 2] = "Tuesday";
	WeekDay[WeekDay["Wednesday"] = 3] = "Wednesday";
	WeekDay[WeekDay["Thursday"] = 4] = "Thursday";
	WeekDay[WeekDay["Friday"] = 5] = "Friday";
	WeekDay[WeekDay["Saturday"] = 6] = "Saturday";
})(WeekDay || (WeekDay = {}));
function getLocaleId(locale) {
	return findLocaleData(locale)[LocaleDataIndex.LocaleId];
}
function getLocaleDayPeriods(locale, formStyle, width) {
	const data = findLocaleData(locale);
	return getLastDefinedValue(getLastDefinedValue([data[LocaleDataIndex.DayPeriodsFormat], data[LocaleDataIndex.DayPeriodsStandalone]], formStyle), width);
}
function getLocaleDayNames(locale, formStyle, width) {
	const data = findLocaleData(locale);
	return getLastDefinedValue(getLastDefinedValue([data[LocaleDataIndex.DaysFormat], data[LocaleDataIndex.DaysStandalone]], formStyle), width);
}
function getLocaleMonthNames(locale, formStyle, width) {
	const data = findLocaleData(locale);
	return getLastDefinedValue(getLastDefinedValue([data[LocaleDataIndex.MonthsFormat], data[LocaleDataIndex.MonthsStandalone]], formStyle), width);
}
function getLocaleEraNames(locale, width) {
	const erasData = findLocaleData(locale)[LocaleDataIndex.Eras];
	return getLastDefinedValue(erasData, width);
}
function getLocaleFirstDayOfWeek(locale) {
	return findLocaleData(locale)[LocaleDataIndex.FirstDayOfWeek];
}
function getLocaleWeekEndRange(locale) {
	return findLocaleData(locale)[LocaleDataIndex.WeekendRange];
}
function getLocaleDateFormat(locale, width) {
	return getLastDefinedValue(findLocaleData(locale)[LocaleDataIndex.DateFormat], width);
}
function getLocaleTimeFormat(locale, width) {
	return getLastDefinedValue(findLocaleData(locale)[LocaleDataIndex.TimeFormat], width);
}
function getLocaleDateTimeFormat(locale, width) {
	const dateTimeFormatData = findLocaleData(locale)[LocaleDataIndex.DateTimeFormat];
	return getLastDefinedValue(dateTimeFormatData, width);
}
function getLocaleNumberSymbol(locale, symbol) {
	const data = findLocaleData(locale);
	const res = data[LocaleDataIndex.NumberSymbols][symbol];
	if (typeof res === "undefined") {
		if (symbol === NumberSymbol.CurrencyDecimal) return data[LocaleDataIndex.NumberSymbols][NumberSymbol.Decimal];
		else if (symbol === NumberSymbol.CurrencyGroup) return data[LocaleDataIndex.NumberSymbols][NumberSymbol.Group];
	}
	return res;
}
function getLocaleNumberFormat(locale, type) {
	return findLocaleData(locale)[LocaleDataIndex.NumberFormats][type];
}
function getLocaleCurrencySymbol(locale) {
	return findLocaleData(locale)[LocaleDataIndex.CurrencySymbol] || null;
}
function getLocaleCurrencyName(locale) {
	return findLocaleData(locale)[LocaleDataIndex.CurrencyName] || null;
}
function getLocaleCurrencyCode(locale) {
	return getLocaleCurrencyCode$1(locale);
}
function getLocaleCurrencies(locale) {
	return findLocaleData(locale)[LocaleDataIndex.Currencies];
}
var getLocalePluralCase = getLocalePluralCase$1;
function checkFullData(data) {
	if (!data[LocaleDataIndex.ExtraData]) throw new RuntimeError(2303, ngDevMode && `Missing extra locale data for the locale "${data[LocaleDataIndex.LocaleId]}". Use "registerLocaleData" to load new data. See the "I18n guide" on angular.io to know more.`);
}
function getLocaleExtraDayPeriodRules(locale) {
	const data = findLocaleData(locale);
	checkFullData(data);
	return (data[LocaleDataIndex.ExtraData][2] || []).map((rule) => {
		if (typeof rule === "string") return extractTime(rule);
		return [extractTime(rule[0]), extractTime(rule[1])];
	});
}
function getLocaleExtraDayPeriods(locale, formStyle, width) {
	const data = findLocaleData(locale);
	checkFullData(data);
	return getLastDefinedValue(getLastDefinedValue([data[LocaleDataIndex.ExtraData][0], data[LocaleDataIndex.ExtraData][1]], formStyle) || [], width) || [];
}
function getLocaleDirection(locale) {
	return findLocaleData(locale)[LocaleDataIndex.Directionality];
}
function getLastDefinedValue(data, index) {
	for (let i = index; i > -1; i--) if (typeof data[i] !== "undefined") return data[i];
	throw new RuntimeError(2304, ngDevMode && "Locale data API: locale data undefined");
}
function extractTime(time) {
	const [h, m] = time.split(":");
	return {
		hours: +h,
		minutes: +m
	};
}
function getCurrencySymbol(code, format, locale = "en") {
	const currency = getLocaleCurrencies(locale)[code] || CURRENCIES_EN[code] || [];
	const symbolNarrow = currency[1];
	if (format === "narrow" && typeof symbolNarrow === "string") return symbolNarrow;
	return currency[0] || code;
}
var DEFAULT_NB_OF_CURRENCY_DIGITS = 2;
function getNumberOfCurrencyDigits(code) {
	let digits;
	const currency = CURRENCIES_EN[code];
	if (currency) digits = currency[2];
	return typeof digits === "number" ? digits : DEFAULT_NB_OF_CURRENCY_DIGITS;
}
var ISO8601_DATE_REGEX = /^(\d{4,})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/;
var NAMED_FORMATS = Object.create(null);
var DATE_FORMATS_SPLIT = /((?:[^BEGHLMOSWYZabcdhmswyz']+)|(?:'(?:[^']|'')*')|(?:G{1,5}|y{1,4}|Y{1,4}|M{1,5}|L{1,5}|w{1,2}|W{1}|d{1,2}|E{1,6}|c{1,6}|a{1,5}|b{1,5}|B{1,5}|h{1,2}|H{1,2}|m{1,2}|s{1,2}|S{1,3}|z{1,4}|Z{1,5}|O{1,4}))([\s\S]*)/;
var MAX_DATE_FORMAT_LENGTH = 256;
function formatDate(value, format, locale, timezone) {
	let date = toDate(value);
	assertValidDateFormatLength(format);
	format = getNamedFormat(locale, format) || format;
	let parts = [];
	let match;
	while (format) {
		match = DATE_FORMATS_SPLIT.exec(format);
		if (match) {
			parts = parts.concat(match.slice(1));
			const part = parts.pop();
			if (!part) break;
			format = part;
		} else {
			parts.push(format);
			break;
		}
	}
	if (typeof ngDevMode === "undefined" || ngDevMode) assertValidDateFormat(parts);
	let dateTimezoneOffset = date.getTimezoneOffset();
	if (timezone) {
		dateTimezoneOffset = timezoneToOffset(timezone, dateTimezoneOffset);
		date = convertTimezoneToLocal(date, timezone);
	}
	let text = "";
	parts.forEach((value) => {
		const dateFormatter = getDateFormatter(value);
		text += dateFormatter ? dateFormatter(date, locale, dateTimezoneOffset) : value === "''" ? "'" : value.replace(/(^'|'$)/g, "").replace(/''/g, "'");
	});
	return text;
}
function assertValidDateFormatLength(format) {
	if (format.length > MAX_DATE_FORMAT_LENGTH) throw new RuntimeError(2300, ngDevMode && `Date format is too long. Exceeded maximum length of ${MAX_DATE_FORMAT_LENGTH} characters.`);
}
function assertValidDateFormat(parts) {
	if (parts.some((part) => /^Y+$/.test(part)) && !parts.some((part) => /^w+$/.test(part))) {
		const message = `Suspicious use of week-based year "Y" in date pattern "${parts.join("")}". Did you mean to use calendar year "y" instead?`;
		if (parts.length === 1) console.error(formatRuntimeError(2300, message));
		else throw new RuntimeError(2300, message);
	}
}
function createDate(year, month, date) {
	const newDate = /* @__PURE__ */ new Date(0);
	newDate.setFullYear(year, month, date);
	newDate.setHours(0, 0, 0);
	return newDate;
}
function getNamedFormat(locale, format) {
	var _NAMED_FORMATS$locale;
	const localeId = getLocaleId(locale);
	(_NAMED_FORMATS$locale = NAMED_FORMATS[localeId]) !== null && _NAMED_FORMATS$locale !== void 0 || (NAMED_FORMATS[localeId] = Object.create(null));
	if (NAMED_FORMATS[localeId][format]) return NAMED_FORMATS[localeId][format];
	let formatValue = "";
	switch (format) {
		case "shortDate":
			formatValue = getLocaleDateFormat(locale, FormatWidth.Short);
			break;
		case "mediumDate":
			formatValue = getLocaleDateFormat(locale, FormatWidth.Medium);
			break;
		case "longDate":
			formatValue = getLocaleDateFormat(locale, FormatWidth.Long);
			break;
		case "fullDate":
			formatValue = getLocaleDateFormat(locale, FormatWidth.Full);
			break;
		case "shortTime":
			formatValue = getLocaleTimeFormat(locale, FormatWidth.Short);
			break;
		case "mediumTime":
			formatValue = getLocaleTimeFormat(locale, FormatWidth.Medium);
			break;
		case "longTime":
			formatValue = getLocaleTimeFormat(locale, FormatWidth.Long);
			break;
		case "fullTime":
			formatValue = getLocaleTimeFormat(locale, FormatWidth.Full);
			break;
		case "short":
			const shortTime = getNamedFormat(locale, "shortTime");
			const shortDate = getNamedFormat(locale, "shortDate");
			formatValue = formatDateTime(getLocaleDateTimeFormat(locale, FormatWidth.Short), [shortTime, shortDate]);
			break;
		case "medium":
			const mediumTime = getNamedFormat(locale, "mediumTime");
			const mediumDate = getNamedFormat(locale, "mediumDate");
			formatValue = formatDateTime(getLocaleDateTimeFormat(locale, FormatWidth.Medium), [mediumTime, mediumDate]);
			break;
		case "long":
			const longTime = getNamedFormat(locale, "longTime");
			const longDate = getNamedFormat(locale, "longDate");
			formatValue = formatDateTime(getLocaleDateTimeFormat(locale, FormatWidth.Long), [longTime, longDate]);
			break;
		case "full":
			const fullTime = getNamedFormat(locale, "fullTime");
			const fullDate = getNamedFormat(locale, "fullDate");
			formatValue = formatDateTime(getLocaleDateTimeFormat(locale, FormatWidth.Full), [fullTime, fullDate]);
			break;
	}
	if (formatValue) NAMED_FORMATS[localeId][format] = formatValue;
	return formatValue;
}
function formatDateTime(str, opt_values) {
	if (opt_values) str = str.replace(/\{([^}]+)}/g, function(match, key) {
		return Object.hasOwn(opt_values, key) ? opt_values[key] : match;
	});
	return str;
}
function padNumber(num, digits, minusSign = "-", trim, negWrap) {
	let neg = "";
	if (num < 0 || negWrap && num <= 0) if (negWrap) num = -num + 1;
	else {
		num = -num;
		neg = minusSign;
	}
	let strNum = String(num);
	while (strNum.length < digits) strNum = "0" + strNum;
	if (trim) strNum = strNum.slice(strNum.length - digits);
	return neg + strNum;
}
function formatFractionalSeconds(milliseconds, digits) {
	return padNumber(milliseconds, 3).substring(0, digits);
}
function dateGetter(name, size, offset = 0, trim = false, negWrap = false) {
	return function(date, locale) {
		let part = getDatePart(name, date);
		if (offset > 0 || part > -offset) part += offset;
		if (name === 3) {
			if (part === 0 && offset === -12) part = 12;
		} else if (name === 6) return formatFractionalSeconds(part, size);
		const localeMinus = getLocaleNumberSymbol(locale, NumberSymbol.MinusSign);
		return padNumber(part, size, localeMinus, trim, negWrap);
	};
}
function getDatePart(part, date) {
	switch (part) {
		case 0: return date.getFullYear();
		case 1: return date.getMonth();
		case 2: return date.getDate();
		case 3: return date.getHours();
		case 4: return date.getMinutes();
		case 5: return date.getSeconds();
		case 6: return date.getMilliseconds();
		case 7: return date.getDay();
		default: throw new RuntimeError(2301, ngDevMode && `Unknown DateType value "${part}".`);
	}
}
function dateStrGetter(name, width, form = FormStyle.Format, extended = false) {
	return function(date, locale) {
		return getDateTranslation(date, locale, name, width, form, extended);
	};
}
function getDateTranslation(date, locale, name, width, form, extended) {
	switch (name) {
		case 2: return getLocaleMonthNames(locale, form, width)[date.getMonth()];
		case 1: return getLocaleDayNames(locale, form, width)[date.getDay()];
		case 0:
			const currentHours = date.getHours();
			const currentMinutes = date.getMinutes();
			if (extended) {
				const rules = getLocaleExtraDayPeriodRules(locale);
				const dayPeriods = getLocaleExtraDayPeriods(locale, form, width);
				const index = rules.findIndex((rule) => {
					if (Array.isArray(rule)) {
						const [from, to] = rule;
						const afterFrom = currentHours >= from.hours && currentMinutes >= from.minutes;
						const beforeTo = currentHours < to.hours || currentHours === to.hours && currentMinutes < to.minutes;
						if (from.hours < to.hours) {
							if (afterFrom && beforeTo) return true;
						} else if (afterFrom || beforeTo) return true;
					} else if (rule.hours === currentHours && rule.minutes === currentMinutes) return true;
					return false;
				});
				if (index !== -1) return dayPeriods[index];
			}
			return getLocaleDayPeriods(locale, form, width)[currentHours < 12 ? 0 : 1];
		case 3: return getLocaleEraNames(locale, width)[date.getFullYear() <= 0 ? 0 : 1];
		default:
			const unexpected = name;
			throw new RuntimeError(2302, ngDevMode && `unexpected translation type ${unexpected}`);
	}
}
function timeZoneGetter(width) {
	return function(date, locale, offset) {
		const zone = -1 * offset;
		const minusSign = getLocaleNumberSymbol(locale, NumberSymbol.MinusSign);
		const hours = zone > 0 ? Math.floor(zone / 60) : Math.ceil(zone / 60);
		switch (width) {
			case 0: return (zone >= 0 ? "+" : "") + padNumber(hours, 2, minusSign) + padNumber(Math.abs(zone % 60), 2, minusSign);
			case 1: return "GMT" + (zone >= 0 ? "+" : "") + padNumber(hours, 1, minusSign);
			case 2: return "GMT" + (zone >= 0 ? "+" : "") + padNumber(hours, 2, minusSign) + ":" + padNumber(Math.abs(zone % 60), 2, minusSign);
			case 3: if (offset === 0) return "Z";
			else return (zone >= 0 ? "+" : "") + padNumber(hours, 2, minusSign) + ":" + padNumber(Math.abs(zone % 60), 2, minusSign);
			default: throw new RuntimeError(2310, ngDevMode && `Unknown zone width "${width}"`);
		}
	};
}
var JANUARY = 0;
var THURSDAY = 4;
function getFirstThursdayOfYear(year) {
	const firstDayOfYear = createDate(year, JANUARY, 1).getDay();
	return createDate(year, 0, 1 + (firstDayOfYear <= THURSDAY ? THURSDAY : 11) - firstDayOfYear);
}
function getThursdayThisIsoWeek(datetime) {
	const currentDay = datetime.getDay();
	const deltaToThursday = currentDay === 0 ? -3 : THURSDAY - currentDay;
	return createDate(datetime.getFullYear(), datetime.getMonth(), datetime.getDate() + deltaToThursday);
}
function weekGetter(size, monthBased = false) {
	return function(date, locale) {
		let result;
		if (monthBased) {
			const nbDaysBefore1stDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1).getDay() - 1;
			const today = date.getDate();
			result = 1 + Math.floor((today + nbDaysBefore1stDayOfMonth) / 7);
		} else {
			const thisThurs = getThursdayThisIsoWeek(date);
			const firstThurs = getFirstThursdayOfYear(thisThurs.getFullYear());
			const diff = thisThurs.getTime() - firstThurs.getTime();
			result = 1 + Math.round(diff / 6048e5);
		}
		return padNumber(result, size, getLocaleNumberSymbol(locale, NumberSymbol.MinusSign));
	};
}
function weekNumberingYearGetter(size, trim = false) {
	return function(date, locale) {
		return padNumber(getThursdayThisIsoWeek(date).getFullYear(), size, getLocaleNumberSymbol(locale, NumberSymbol.MinusSign), trim);
	};
}
var DATE_FORMATS = Object.create(null);
function getDateFormatter(format) {
	if (DATE_FORMATS[format]) return DATE_FORMATS[format];
	let formatter;
	switch (format) {
		case "G":
		case "GG":
		case "GGG":
			formatter = dateStrGetter(3, TranslationWidth.Abbreviated);
			break;
		case "GGGG":
			formatter = dateStrGetter(3, TranslationWidth.Wide);
			break;
		case "GGGGG":
			formatter = dateStrGetter(3, TranslationWidth.Narrow);
			break;
		case "y":
			formatter = dateGetter(0, 1, 0, false, true);
			break;
		case "yy":
			formatter = dateGetter(0, 2, 0, true, true);
			break;
		case "yyy":
			formatter = dateGetter(0, 3, 0, false, true);
			break;
		case "yyyy":
			formatter = dateGetter(0, 4, 0, false, true);
			break;
		case "Y":
			formatter = weekNumberingYearGetter(1);
			break;
		case "YY":
			formatter = weekNumberingYearGetter(2, true);
			break;
		case "YYY":
			formatter = weekNumberingYearGetter(3);
			break;
		case "YYYY":
			formatter = weekNumberingYearGetter(4);
			break;
		case "M":
		case "L":
			formatter = dateGetter(1, 1, 1);
			break;
		case "MM":
		case "LL":
			formatter = dateGetter(1, 2, 1);
			break;
		case "MMM":
			formatter = dateStrGetter(2, TranslationWidth.Abbreviated);
			break;
		case "MMMM":
			formatter = dateStrGetter(2, TranslationWidth.Wide);
			break;
		case "MMMMM":
			formatter = dateStrGetter(2, TranslationWidth.Narrow);
			break;
		case "LLL":
			formatter = dateStrGetter(2, TranslationWidth.Abbreviated, FormStyle.Standalone);
			break;
		case "LLLL":
			formatter = dateStrGetter(2, TranslationWidth.Wide, FormStyle.Standalone);
			break;
		case "LLLLL":
			formatter = dateStrGetter(2, TranslationWidth.Narrow, FormStyle.Standalone);
			break;
		case "w":
			formatter = weekGetter(1);
			break;
		case "ww":
			formatter = weekGetter(2);
			break;
		case "W":
			formatter = weekGetter(1, true);
			break;
		case "d":
			formatter = dateGetter(2, 1);
			break;
		case "dd":
			formatter = dateGetter(2, 2);
			break;
		case "c":
		case "cc":
			formatter = dateGetter(7, 1);
			break;
		case "ccc":
			formatter = dateStrGetter(1, TranslationWidth.Abbreviated, FormStyle.Standalone);
			break;
		case "cccc":
			formatter = dateStrGetter(1, TranslationWidth.Wide, FormStyle.Standalone);
			break;
		case "ccccc":
			formatter = dateStrGetter(1, TranslationWidth.Narrow, FormStyle.Standalone);
			break;
		case "cccccc":
			formatter = dateStrGetter(1, TranslationWidth.Short, FormStyle.Standalone);
			break;
		case "E":
		case "EE":
		case "EEE":
			formatter = dateStrGetter(1, TranslationWidth.Abbreviated);
			break;
		case "EEEE":
			formatter = dateStrGetter(1, TranslationWidth.Wide);
			break;
		case "EEEEE":
			formatter = dateStrGetter(1, TranslationWidth.Narrow);
			break;
		case "EEEEEE":
			formatter = dateStrGetter(1, TranslationWidth.Short);
			break;
		case "a":
		case "aa":
		case "aaa":
			formatter = dateStrGetter(0, TranslationWidth.Abbreviated);
			break;
		case "aaaa":
			formatter = dateStrGetter(0, TranslationWidth.Wide);
			break;
		case "aaaaa":
			formatter = dateStrGetter(0, TranslationWidth.Narrow);
			break;
		case "b":
		case "bb":
		case "bbb":
			formatter = dateStrGetter(0, TranslationWidth.Abbreviated, FormStyle.Standalone, true);
			break;
		case "bbbb":
			formatter = dateStrGetter(0, TranslationWidth.Wide, FormStyle.Standalone, true);
			break;
		case "bbbbb":
			formatter = dateStrGetter(0, TranslationWidth.Narrow, FormStyle.Standalone, true);
			break;
		case "B":
		case "BB":
		case "BBB":
			formatter = dateStrGetter(0, TranslationWidth.Abbreviated, FormStyle.Format, true);
			break;
		case "BBBB":
			formatter = dateStrGetter(0, TranslationWidth.Wide, FormStyle.Format, true);
			break;
		case "BBBBB":
			formatter = dateStrGetter(0, TranslationWidth.Narrow, FormStyle.Format, true);
			break;
		case "h":
			formatter = dateGetter(3, 1, -12);
			break;
		case "hh":
			formatter = dateGetter(3, 2, -12);
			break;
		case "H":
			formatter = dateGetter(3, 1);
			break;
		case "HH":
			formatter = dateGetter(3, 2);
			break;
		case "m":
			formatter = dateGetter(4, 1);
			break;
		case "mm":
			formatter = dateGetter(4, 2);
			break;
		case "s":
			formatter = dateGetter(5, 1);
			break;
		case "ss":
			formatter = dateGetter(5, 2);
			break;
		case "S":
			formatter = dateGetter(6, 1);
			break;
		case "SS":
			formatter = dateGetter(6, 2);
			break;
		case "SSS":
			formatter = dateGetter(6, 3);
			break;
		case "Z":
		case "ZZ":
		case "ZZZ":
			formatter = timeZoneGetter(0);
			break;
		case "ZZZZZ":
			formatter = timeZoneGetter(3);
			break;
		case "O":
		case "OO":
		case "OOO":
		case "z":
		case "zz":
		case "zzz":
			formatter = timeZoneGetter(1);
			break;
		case "OOOO":
		case "ZZZZ":
		case "zzzz":
			formatter = timeZoneGetter(2);
			break;
		default: return null;
	}
	DATE_FORMATS[format] = formatter;
	return formatter;
}
function timezoneToOffset(timezone, fallback) {
	timezone = timezone.replace(/:/g, "");
	const requestedTimezoneOffset = Date.parse("Jan 01, 1970 00:00:00 " + timezone) / 6e4;
	return isNaN(requestedTimezoneOffset) ? fallback : requestedTimezoneOffset;
}
function addDateMinutes(date, minutes) {
	date = new Date(date.getTime());
	date.setMinutes(date.getMinutes() + minutes);
	return date;
}
function convertTimezoneToLocal(date, timezone, reverse) {
	const reverseValue = -1;
	const dateTimezoneOffset = date.getTimezoneOffset();
	return addDateMinutes(date, reverseValue * (timezoneToOffset(timezone, dateTimezoneOffset) - dateTimezoneOffset));
}
function toDate(value) {
	if (isDate(value)) return value;
	if (typeof value === "number" && !isNaN(value)) return new Date(value);
	if (typeof value === "string") {
		value = value.trim();
		if (/^(\d{4}(-\d{1,2}(-\d{1,2})?)?)$/.test(value)) {
			const [y, m = 1, d = 1] = value.split("-").map((val) => +val);
			return createDate(y, m - 1, d);
		}
		const parsedNb = parseFloat(value);
		if (!isNaN(value - parsedNb)) return new Date(parsedNb);
		let match;
		if (match = value.match(ISO8601_DATE_REGEX)) return isoStringToDate(match);
	}
	const date = new Date(value);
	if (!isDate(date)) throw new RuntimeError(2311, ngDevMode && `Unable to convert "${value}" into a date`);
	return date;
}
function isoStringToDate(match) {
	const date = /* @__PURE__ */ new Date(0);
	let tzHour = 0;
	let tzMin = 0;
	const dateSetter = match[8] ? date.setUTCFullYear : date.setFullYear;
	const timeSetter = match[8] ? date.setUTCHours : date.setHours;
	if (match[9]) {
		tzHour = Number(match[9] + match[10]);
		tzMin = Number(match[9] + match[11]);
	}
	dateSetter.call(date, Number(match[1]), Number(match[2]) - 1, Number(match[3]));
	const h = Number(match[4] || 0) - tzHour;
	const m = Number(match[5] || 0) - tzMin;
	const s = Number(match[6] || 0);
	const ms = Math.floor(parseFloat("0." + (match[7] || 0)) * 1e3);
	timeSetter.call(date, h, m, s, ms);
	return date;
}
function isDate(value) {
	return value instanceof Date && !isNaN(value.valueOf());
}
var NUMBER_FORMAT_REGEXP = /^(\d+)?\.((\d+)(-(\d+))?)?$/;
var MAX_DIGITS = 22;
var DECIMAL_SEP = ".";
var ZERO_CHAR = "0";
var PATTERN_SEP = ";";
var GROUP_SEP = ",";
var DIGIT_CHAR = "#";
var CURRENCY_CHAR = "¤";
var PERCENT_CHAR = "%";
function formatNumberToLocaleString(value, pattern, locale, groupSymbol, decimalSymbol, digitsInfo, isPercent = false) {
	let formattedText = "";
	let isZero = false;
	if (!isFinite(value)) formattedText = getLocaleNumberSymbol(locale, NumberSymbol.Infinity);
	else {
		let parsedNumber = parseNumber(value);
		if (isPercent) parsedNumber = toPercent(parsedNumber);
		let minInt = pattern.minInt;
		let minFraction = pattern.minFrac;
		let maxFraction = pattern.maxFrac;
		if (digitsInfo) {
			const parts = digitsInfo.match(NUMBER_FORMAT_REGEXP);
			if (parts === null) throw new RuntimeError(2306, ngDevMode && `${digitsInfo} is not a valid digit info`);
			const minIntPart = parts[1];
			const minFractionPart = parts[3];
			const maxFractionPart = parts[5];
			if (minIntPart != null) minInt = parseIntAutoRadix(minIntPart);
			if (minFractionPart != null) minFraction = parseIntAutoRadix(minFractionPart);
			if (maxFractionPart != null) maxFraction = parseIntAutoRadix(maxFractionPart);
			else if (minFractionPart != null && minFraction > maxFraction) maxFraction = minFraction;
			const MAX_ALLOWED_DIGITS = 100;
			if (minInt > MAX_ALLOWED_DIGITS || minFraction > MAX_ALLOWED_DIGITS || maxFraction > MAX_ALLOWED_DIGITS) throw new RuntimeError(2306, ngDevMode && `${digitsInfo} is not a valid digit info. Exceeded maximum limits of ${MAX_ALLOWED_DIGITS} digits.`);
		}
		roundNumber(parsedNumber, minFraction, maxFraction);
		let digits = parsedNumber.digits;
		let integerLen = parsedNumber.integerLen;
		const exponent = parsedNumber.exponent;
		let decimals = [];
		isZero = digits.every((d) => !d);
		for (; integerLen < minInt; integerLen++) digits.unshift(0);
		for (; integerLen < 0; integerLen++) digits.unshift(0);
		if (integerLen > 0) decimals = digits.splice(integerLen, digits.length);
		else {
			decimals = digits;
			digits = [0];
		}
		const groups = [];
		if (digits.length >= pattern.lgSize) groups.unshift(digits.splice(-pattern.lgSize, digits.length).join(""));
		while (digits.length > pattern.gSize) groups.unshift(digits.splice(-pattern.gSize, digits.length).join(""));
		if (digits.length) groups.unshift(digits.join(""));
		formattedText = groups.join(getLocaleNumberSymbol(locale, groupSymbol));
		if (decimals.length) formattedText += getLocaleNumberSymbol(locale, decimalSymbol) + decimals.join("");
		if (exponent) formattedText += getLocaleNumberSymbol(locale, NumberSymbol.Exponential) + "+" + exponent;
	}
	if (value < 0 && !isZero) formattedText = pattern.negPre + formattedText + pattern.negSuf;
	else formattedText = pattern.posPre + formattedText + pattern.posSuf;
	return formattedText;
}
function formatCurrency(value, locale, currency, currencyCode, digitsInfo) {
	const pattern = parseNumberFormat(getLocaleNumberFormat(locale, NumberFormatStyle.Currency), getLocaleNumberSymbol(locale, NumberSymbol.MinusSign));
	pattern.minFrac = getNumberOfCurrencyDigits(currencyCode);
	pattern.maxFrac = pattern.minFrac;
	return formatNumberToLocaleString(value, pattern, locale, NumberSymbol.CurrencyGroup, NumberSymbol.CurrencyDecimal, digitsInfo).replace(CURRENCY_CHAR, currency).replace(CURRENCY_CHAR, "").trim();
}
function formatPercent(value, locale, digitsInfo) {
	return formatNumberToLocaleString(value, parseNumberFormat(getLocaleNumberFormat(locale, NumberFormatStyle.Percent), getLocaleNumberSymbol(locale, NumberSymbol.MinusSign)), locale, NumberSymbol.Group, NumberSymbol.Decimal, digitsInfo, true).replace(new RegExp(PERCENT_CHAR, "g"), getLocaleNumberSymbol(locale, NumberSymbol.PercentSign));
}
function formatNumber(value, locale, digitsInfo) {
	return formatNumberToLocaleString(value, parseNumberFormat(getLocaleNumberFormat(locale, NumberFormatStyle.Decimal), getLocaleNumberSymbol(locale, NumberSymbol.MinusSign)), locale, NumberSymbol.Group, NumberSymbol.Decimal, digitsInfo);
}
function parseNumberFormat(format, minusSign = "-") {
	const p = {
		minInt: 1,
		minFrac: 0,
		maxFrac: 0,
		posPre: "",
		posSuf: "",
		negPre: "",
		negSuf: "",
		gSize: 0,
		lgSize: 0
	};
	const patternParts = format.split(PATTERN_SEP);
	const positive = patternParts[0];
	const negative = patternParts[1];
	const positiveParts = positive.indexOf(DECIMAL_SEP) !== -1 ? positive.split(DECIMAL_SEP) : [positive.substring(0, positive.lastIndexOf(ZERO_CHAR) + 1), positive.substring(positive.lastIndexOf(ZERO_CHAR) + 1)], integer = positiveParts[0], fraction = positiveParts[1] || "";
	p.posPre = integer.substring(0, integer.indexOf(DIGIT_CHAR));
	for (let i = 0; i < fraction.length; i++) {
		const ch = fraction.charAt(i);
		if (ch === ZERO_CHAR) p.minFrac = p.maxFrac = i + 1;
		else if (ch === DIGIT_CHAR) p.maxFrac = i + 1;
		else p.posSuf += ch;
	}
	const groups = integer.split(GROUP_SEP);
	p.gSize = groups[1] ? groups[1].length : 0;
	p.lgSize = groups[2] || groups[1] ? (groups[2] || groups[1]).length : 0;
	if (negative) {
		const trunkLen = positive.length - p.posPre.length - p.posSuf.length, pos = negative.indexOf(DIGIT_CHAR);
		p.negPre = negative.substring(0, pos).replace(/'/g, "");
		p.negSuf = negative.slice(pos + trunkLen).replace(/'/g, "");
	} else {
		p.negPre = minusSign + p.posPre;
		p.negSuf = p.posSuf;
	}
	return p;
}
function toPercent(parsedNumber) {
	if (parsedNumber.digits[0] === 0) return parsedNumber;
	const fractionLen = parsedNumber.digits.length - parsedNumber.integerLen;
	if (parsedNumber.exponent) parsedNumber.exponent += 2;
	else {
		if (fractionLen === 0) parsedNumber.digits.push(0, 0);
		else if (fractionLen === 1) parsedNumber.digits.push(0);
		parsedNumber.integerLen += 2;
	}
	return parsedNumber;
}
function parseNumber(num) {
	let numStr = Math.abs(num) + "";
	let exponent = 0, digits, integerLen;
	let i, j, zeros;
	if ((integerLen = numStr.indexOf(DECIMAL_SEP)) > -1) numStr = numStr.replace(DECIMAL_SEP, "");
	if ((i = numStr.search(/e/i)) > 0) {
		if (integerLen < 0) integerLen = i;
		integerLen += +numStr.slice(i + 1);
		numStr = numStr.substring(0, i);
	} else if (integerLen < 0) integerLen = numStr.length;
	for (i = 0; numStr.charAt(i) === ZERO_CHAR; i++);
	if (i === (zeros = numStr.length)) {
		digits = [0];
		integerLen = 1;
	} else {
		zeros--;
		while (numStr.charAt(zeros) === ZERO_CHAR) zeros--;
		integerLen -= i;
		digits = [];
		for (j = 0; i <= zeros; i++, j++) digits[j] = Number(numStr.charAt(i));
	}
	if (integerLen > MAX_DIGITS) {
		digits = digits.splice(0, MAX_DIGITS - 1);
		exponent = integerLen - 1;
		integerLen = 1;
	}
	return {
		digits,
		exponent,
		integerLen
	};
}
function roundNumber(parsedNumber, minFrac, maxFrac) {
	if (minFrac > maxFrac) throw new RuntimeError(2307, ngDevMode && `The minimum number of digits after fraction (${minFrac}) is higher than the maximum (${maxFrac}).`);
	let digits = parsedNumber.digits;
	let fractionLen = digits.length - parsedNumber.integerLen;
	const fractionSize = Math.min(Math.max(minFrac, fractionLen), maxFrac);
	let roundAt = fractionSize + parsedNumber.integerLen;
	let digit = digits[roundAt];
	if (roundAt > 0) {
		digits.splice(Math.max(parsedNumber.integerLen, roundAt));
		for (let j = roundAt; j < digits.length; j++) digits[j] = 0;
	} else {
		fractionLen = Math.max(0, fractionLen);
		parsedNumber.integerLen = 1;
		digits.length = Math.max(1, roundAt = fractionSize + 1);
		digits[0] = 0;
		for (let i = 1; i < roundAt; i++) digits[i] = 0;
	}
	if (digit >= 5) if (roundAt - 1 < 0) {
		for (let k = 0; k > roundAt; k--) {
			digits.unshift(0);
			parsedNumber.integerLen++;
		}
		digits.unshift(1);
		parsedNumber.integerLen++;
	} else digits[roundAt - 1]++;
	for (; fractionLen < Math.max(0, fractionSize); fractionLen++) digits.push(0);
	let dropTrailingZeros = fractionSize !== 0;
	const minLen = minFrac + parsedNumber.integerLen;
	const carry = digits.reduceRight(function(carry, d, i, digits) {
		d = d + carry;
		digits[i] = d < 10 ? d : d - 10;
		if (dropTrailingZeros) if (digits[i] === 0 && i >= minLen) digits.pop();
		else dropTrailingZeros = false;
		return d >= 10 ? 1 : 0;
	}, 0);
	if (carry) {
		digits.unshift(carry);
		parsedNumber.integerLen++;
	}
}
function parseIntAutoRadix(text) {
	const result = parseInt(text);
	if (isNaN(result)) throw new RuntimeError(2305, ngDevMode && "Invalid integer literal when parsing " + text);
	return result;
}
var NgLocalization = class {};
_NgLocalization = NgLocalization;
_defineProperty(NgLocalization, "ɵfac", function NgLocalization_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgLocalization)();
});
_defineProperty(NgLocalization, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _NgLocalization,
	factory: () => (() => new NgLocaleLocalization(inject(LOCALE_ID)))()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgLocalization, [{
		type: Service,
		args: [{ factory: () => new NgLocaleLocalization(inject(LOCALE_ID)) }]
	}], null, null);
})();
function getPluralCategory(value, cases, ngLocalization, locale) {
	let key = `=${value}`;
	if (cases.indexOf(key) > -1) return key;
	key = ngLocalization.getPluralCategory(value, locale);
	if (cases.indexOf(key) > -1) return key;
	if (cases.indexOf("other") > -1) return "other";
	throw new RuntimeError(2308, ngDevMode && `No plural message found for value "${value}"`);
}
var NgLocaleLocalization = class extends NgLocalization {
	constructor(locale) {
		super();
		_defineProperty(this, "locale", void 0);
		this.locale = locale;
	}
	getPluralCategory(value, locale) {
		switch (getLocalePluralCase(locale || this.locale)(value)) {
			case Plural.Zero: return "zero";
			case Plural.One: return "one";
			case Plural.Two: return "two";
			case Plural.Few: return "few";
			case Plural.Many: return "many";
			default: return "other";
		}
	}
};
_NgLocaleLocalization = NgLocaleLocalization;
_defineProperty(NgLocaleLocalization, "ɵfac", function NgLocaleLocalization_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgLocaleLocalization)(ɵɵinject(LOCALE_ID));
});
_defineProperty(NgLocaleLocalization, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _NgLocaleLocalization,
	factory: _NgLocaleLocalization.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgLocaleLocalization, [{ type: Injectable }], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [LOCALE_ID]
		}]
	}], null);
})();
var WS_REGEXP = /\s+/;
var EMPTY_ARRAY = [];
var NgClass = class {
	constructor(_ngEl, _renderer) {
		_defineProperty(this, "_ngEl", void 0);
		_defineProperty(this, "_renderer", void 0);
		_defineProperty(this, "initialClasses", EMPTY_ARRAY);
		_defineProperty(this, "rawClass", void 0);
		_defineProperty(this, "stateMap", /* @__PURE__ */ new Map());
		this._ngEl = _ngEl;
		this._renderer = _renderer;
	}
	set klass(value) {
		this.initialClasses = value != null ? value.trim().split(WS_REGEXP) : EMPTY_ARRAY;
	}
	set ngClass(value) {
		this.rawClass = typeof value === "string" ? value.trim().split(WS_REGEXP) : value;
	}
	ngDoCheck() {
		for (const klass of this.initialClasses) this._updateState(klass, true);
		const rawClass = this.rawClass;
		if (Array.isArray(rawClass) || rawClass instanceof Set) for (const klass of rawClass) this._updateState(klass, true);
		else if (rawClass != null) for (const klass of Object.keys(rawClass)) this._updateState(klass, Boolean(rawClass[klass]));
		this._applyStateDiff();
	}
	_updateState(klass, nextEnabled) {
		const state = this.stateMap.get(klass);
		if (state !== void 0) {
			if (state.enabled !== nextEnabled) {
				state.changed = true;
				state.enabled = nextEnabled;
			}
			state.touched = true;
		} else this.stateMap.set(klass, {
			enabled: nextEnabled,
			changed: true,
			touched: true
		});
	}
	_applyStateDiff() {
		for (const stateEntry of this.stateMap) {
			const klass = stateEntry[0];
			const state = stateEntry[1];
			if (state.changed) {
				this._toggleClass(klass, state.enabled);
				state.changed = false;
			} else if (!state.touched) {
				if (state.enabled) this._toggleClass(klass, false);
				this.stateMap.delete(klass);
			}
			state.touched = false;
		}
	}
	_toggleClass(klass, enabled) {
		if (ngDevMode) {
			if (typeof klass !== "string") throw new Error(`NgClass can only toggle CSS classes expressed as strings, got ${stringify(klass)}`);
		}
		klass = klass.trim();
		if (klass.length > 0) klass.split(WS_REGEXP).forEach((klass) => {
			if (enabled) this._renderer.addClass(this._ngEl.nativeElement, klass);
			else this._renderer.removeClass(this._ngEl.nativeElement, klass);
		});
	}
};
_NgClass = NgClass;
_defineProperty(NgClass, "ɵfac", function NgClass_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgClass)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2));
});
_defineProperty(NgClass, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgClass,
	selectors: [[
		"",
		"ngClass",
		""
	]],
	inputs: {
		klass: [
			0,
			"class",
			"klass"
		],
		ngClass: "ngClass"
	}
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgClass, [{
		type: Directive,
		args: [{ selector: "[ngClass]" }]
	}], () => [{ type: ElementRef }, { type: Renderer2 }], {
		klass: [{
			type: Input,
			args: ["class"]
		}],
		ngClass: [{
			type: Input,
			args: ["ngClass"]
		}]
	});
})();
var NgComponentOutlet = class {
	get componentInstance() {
		var _this$_componentRef$i, _this$_componentRef;
		return (_this$_componentRef$i = (_this$_componentRef = this._componentRef) === null || _this$_componentRef === void 0 ? void 0 : _this$_componentRef.instance) !== null && _this$_componentRef$i !== void 0 ? _this$_componentRef$i : null;
	}
	constructor(_viewContainerRef) {
		_defineProperty(this, "_viewContainerRef", void 0);
		_defineProperty(this, "ngComponentOutlet", null);
		_defineProperty(this, "ngComponentOutletInputs", void 0);
		_defineProperty(this, "ngComponentOutletInjector", void 0);
		_defineProperty(this, "ngComponentOutletEnvironmentInjector", void 0);
		_defineProperty(this, "ngComponentOutletContent", void 0);
		_defineProperty(this, "ngComponentOutletNgModule", void 0);
		_defineProperty(this, "_componentRef", void 0);
		_defineProperty(this, "_moduleRef", void 0);
		_defineProperty(this, "_inputsUsed", /* @__PURE__ */ new Map());
		this._viewContainerRef = _viewContainerRef;
	}
	_needToReCreateNgModuleInstance(changes) {
		return changes["ngComponentOutletNgModule"] !== void 0;
	}
	_needToReCreateComponentInstance(changes) {
		return changes["ngComponentOutlet"] !== void 0 || changes["ngComponentOutletContent"] !== void 0 || changes["ngComponentOutletInjector"] !== void 0 || changes["ngComponentOutletEnvironmentInjector"] !== void 0 || this._needToReCreateNgModuleInstance(changes);
	}
	ngOnChanges(changes) {
		if (this._needToReCreateComponentInstance(changes)) {
			this._viewContainerRef.clear();
			this._inputsUsed.clear();
			this._componentRef = void 0;
			if (this.ngComponentOutlet) {
				const injector = this.ngComponentOutletInjector || this._viewContainerRef.parentInjector;
				if (this._needToReCreateNgModuleInstance(changes)) {
					var _this$_moduleRef;
					(_this$_moduleRef = this._moduleRef) === null || _this$_moduleRef === void 0 || _this$_moduleRef.destroy();
					if (this.ngComponentOutletNgModule) this._moduleRef = createNgModule(this.ngComponentOutletNgModule, getParentInjector(injector));
					else this._moduleRef = void 0;
				}
				this._componentRef = this._viewContainerRef.createComponent(this.ngComponentOutlet, {
					injector,
					ngModuleRef: this._moduleRef,
					projectableNodes: this.ngComponentOutletContent,
					environmentInjector: this.ngComponentOutletEnvironmentInjector
				});
			}
		}
	}
	ngDoCheck() {
		if (this._componentRef) {
			if (this.ngComponentOutletInputs) for (const inputName of Object.keys(this.ngComponentOutletInputs)) this._inputsUsed.set(inputName, true);
			this._applyInputStateDiff(this._componentRef);
		}
	}
	ngOnDestroy() {
		var _this$_moduleRef2;
		(_this$_moduleRef2 = this._moduleRef) === null || _this$_moduleRef2 === void 0 || _this$_moduleRef2.destroy();
	}
	_applyInputStateDiff(componentRef) {
		for (const [inputName, touched] of this._inputsUsed) if (!touched) {
			componentRef.setInput(inputName, void 0);
			this._inputsUsed.delete(inputName);
		} else {
			componentRef.setInput(inputName, this.ngComponentOutletInputs[inputName]);
			this._inputsUsed.set(inputName, false);
		}
	}
};
_NgComponentOutlet = NgComponentOutlet;
_defineProperty(NgComponentOutlet, "ɵfac", function NgComponentOutlet_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgComponentOutlet)(ɵɵdirectiveInject(ViewContainerRef));
});
_defineProperty(NgComponentOutlet, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgComponentOutlet,
	selectors: [[
		"",
		"ngComponentOutlet",
		""
	]],
	inputs: {
		ngComponentOutlet: "ngComponentOutlet",
		ngComponentOutletInputs: "ngComponentOutletInputs",
		ngComponentOutletInjector: "ngComponentOutletInjector",
		ngComponentOutletEnvironmentInjector: "ngComponentOutletEnvironmentInjector",
		ngComponentOutletContent: "ngComponentOutletContent",
		ngComponentOutletNgModule: "ngComponentOutletNgModule"
	},
	exportAs: ["ngComponentOutlet"],
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgComponentOutlet, [{
		type: Directive,
		args: [{
			selector: "[ngComponentOutlet]",
			exportAs: "ngComponentOutlet"
		}]
	}], () => [{ type: ViewContainerRef }], {
		ngComponentOutlet: [{ type: Input }],
		ngComponentOutletInputs: [{ type: Input }],
		ngComponentOutletInjector: [{ type: Input }],
		ngComponentOutletEnvironmentInjector: [{ type: Input }],
		ngComponentOutletContent: [{ type: Input }],
		ngComponentOutletNgModule: [{ type: Input }]
	});
})();
function getParentInjector(injector) {
	return injector.get(NgModuleRef$1).injector;
}
var NgForOfContext = class {
	constructor($implicit, ngForOf, index, count) {
		_defineProperty(this, "$implicit", void 0);
		_defineProperty(this, "ngForOf", void 0);
		_defineProperty(this, "index", void 0);
		_defineProperty(this, "count", void 0);
		this.$implicit = $implicit;
		this.ngForOf = ngForOf;
		this.index = index;
		this.count = count;
	}
	get first() {
		return this.index === 0;
	}
	get last() {
		return this.index === this.count - 1;
	}
	get even() {
		return this.index % 2 === 0;
	}
	get odd() {
		return !this.even;
	}
};
var NgForOf = class {
	set ngForOf(ngForOf) {
		this._ngForOf = ngForOf;
		this._ngForOfDirty = true;
	}
	set ngForTrackBy(fn) {
		if ((typeof ngDevMode === "undefined" || ngDevMode) && fn != null && typeof fn !== "function") console.warn(`trackBy must be a function, but received ${JSON.stringify(fn)}. See https://angular.dev/api/common/NgForOf#change-propagation for more information.`);
		this._trackByFn = fn;
	}
	get ngForTrackBy() {
		return this._trackByFn;
	}
	constructor(_viewContainer, _template, _differs) {
		_defineProperty(this, "_viewContainer", void 0);
		_defineProperty(this, "_template", void 0);
		_defineProperty(this, "_differs", void 0);
		_defineProperty(this, "_ngForOf", null);
		_defineProperty(this, "_ngForOfDirty", true);
		_defineProperty(this, "_differ", null);
		_defineProperty(this, "_trackByFn", void 0);
		this._viewContainer = _viewContainer;
		this._template = _template;
		this._differs = _differs;
	}
	set ngForTemplate(value) {
		if (value) this._template = value;
	}
	ngDoCheck() {
		if (this._ngForOfDirty) {
			this._ngForOfDirty = false;
			const value = this._ngForOf;
			if (!this._differ && value) if (typeof ngDevMode === "undefined" || ngDevMode) try {
				this._differ = this._differs.find(value).create(this.ngForTrackBy);
			} catch (_unused) {
				let errorMessage = `Cannot find a differ supporting object '${value}' of type '${getTypeName(value)}'. NgFor only supports binding to Iterables, such as Arrays.`;
				if (typeof value === "object") errorMessage += " Did you mean to use the keyvalue pipe?";
				throw new RuntimeError(-2200, errorMessage);
			}
			else this._differ = this._differs.find(value).create(this.ngForTrackBy);
		}
		if (this._differ) {
			const changes = this._differ.diff(this._ngForOf);
			if (changes) this._applyChanges(changes);
		}
	}
	_applyChanges(changes) {
		const viewContainer = this._viewContainer;
		changes.forEachOperation((item, adjustedPreviousIndex, currentIndex) => {
			if (item.previousIndex == null) viewContainer.createEmbeddedView(this._template, new NgForOfContext(item.item, this._ngForOf, -1, -1), currentIndex === null ? void 0 : currentIndex);
			else if (currentIndex == null) viewContainer.remove(adjustedPreviousIndex === null ? void 0 : adjustedPreviousIndex);
			else if (adjustedPreviousIndex !== null) {
				const view = viewContainer.get(adjustedPreviousIndex);
				viewContainer.move(view, currentIndex);
				applyViewChange(view, item);
			}
		});
		for (let i = 0, ilen = viewContainer.length; i < ilen; i++) {
			const context = viewContainer.get(i).context;
			context.index = i;
			context.count = ilen;
			context.ngForOf = this._ngForOf;
		}
		changes.forEachIdentityChange((record) => {
			applyViewChange(viewContainer.get(record.currentIndex), record);
		});
	}
	static ngTemplateContextGuard(dir, ctx) {
		return true;
	}
};
_NgForOf = NgForOf;
_defineProperty(NgForOf, "ɵfac", function NgForOf_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgForOf)(ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(TemplateRef), ɵɵdirectiveInject(IterableDiffers));
});
_defineProperty(NgForOf, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgForOf,
	selectors: [[
		"",
		"ngFor",
		"",
		"ngForOf",
		""
	]],
	inputs: {
		ngForOf: "ngForOf",
		ngForTrackBy: "ngForTrackBy",
		ngForTemplate: "ngForTemplate"
	}
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgForOf, [{
		type: Directive,
		args: [{ selector: "[ngFor][ngForOf]" }]
	}], () => [
		{ type: ViewContainerRef },
		{ type: TemplateRef },
		{ type: IterableDiffers }
	], {
		ngForOf: [{ type: Input }],
		ngForTrackBy: [{ type: Input }],
		ngForTemplate: [{ type: Input }]
	});
})();
function applyViewChange(view, record) {
	view.context.$implicit = record.item;
}
function getTypeName(type) {
	return type["name"] || typeof type;
}
var NgIf = class {
	constructor(_viewContainer, templateRef) {
		_defineProperty(this, "_viewContainer", void 0);
		_defineProperty(this, "_context", new NgIfContext());
		_defineProperty(this, "_thenTemplateRef", null);
		_defineProperty(this, "_elseTemplateRef", null);
		_defineProperty(this, "_thenViewRef", null);
		_defineProperty(this, "_elseViewRef", null);
		this._viewContainer = _viewContainer;
		this._thenTemplateRef = templateRef;
	}
	set ngIf(condition) {
		this._context.$implicit = this._context.ngIf = condition;
		this._updateView();
	}
	set ngIfThen(templateRef) {
		assertTemplate(templateRef, (typeof ngDevMode === "undefined" || ngDevMode) && "ngIfThen");
		this._thenTemplateRef = templateRef;
		this._thenViewRef = null;
		this._updateView();
	}
	set ngIfElse(templateRef) {
		assertTemplate(templateRef, (typeof ngDevMode === "undefined" || ngDevMode) && "ngIfElse");
		this._elseTemplateRef = templateRef;
		this._elseViewRef = null;
		this._updateView();
	}
	_updateView() {
		if (this._context.$implicit) {
			if (!this._thenViewRef) {
				this._viewContainer.clear();
				this._elseViewRef = null;
				if (this._thenTemplateRef) this._thenViewRef = this._viewContainer.createEmbeddedView(this._thenTemplateRef, this._context);
			}
		} else if (!this._elseViewRef) {
			this._viewContainer.clear();
			this._thenViewRef = null;
			if (this._elseTemplateRef) this._elseViewRef = this._viewContainer.createEmbeddedView(this._elseTemplateRef, this._context);
		}
	}
	static ngTemplateContextGuard(dir, ctx) {
		return true;
	}
};
_NgIf = NgIf;
_defineProperty(NgIf, "ngIfUseIfTypeGuard", void 0);
_defineProperty(NgIf, "ngTemplateGuard_ngIf", void 0);
_defineProperty(NgIf, "ɵfac", function NgIf_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgIf)(ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(TemplateRef));
});
_defineProperty(NgIf, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgIf,
	selectors: [[
		"",
		"ngIf",
		""
	]],
	inputs: {
		ngIf: "ngIf",
		ngIfThen: "ngIfThen",
		ngIfElse: "ngIfElse"
	}
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgIf, [{
		type: Directive,
		args: [{ selector: "[ngIf]" }]
	}], () => [{ type: ViewContainerRef }, { type: TemplateRef }], {
		ngIf: [{ type: Input }],
		ngIfThen: [{ type: Input }],
		ngIfElse: [{ type: Input }]
	});
})();
var NgIfContext = class {
	constructor() {
		_defineProperty(this, "$implicit", null);
		_defineProperty(this, "ngIf", null);
	}
};
function assertTemplate(templateRef, property) {
	if (templateRef && !templateRef.createEmbeddedView) throw new RuntimeError(2020, (typeof ngDevMode === "undefined" || ngDevMode) && `${property} must be a TemplateRef, but received '${stringify(templateRef)}'.`);
}
var SwitchView = class {
	constructor(_viewContainerRef, _templateRef) {
		_defineProperty(this, "_viewContainerRef", void 0);
		_defineProperty(this, "_templateRef", void 0);
		_defineProperty(this, "_created", false);
		this._viewContainerRef = _viewContainerRef;
		this._templateRef = _templateRef;
	}
	create() {
		this._created = true;
		this._viewContainerRef.createEmbeddedView(this._templateRef);
	}
	destroy() {
		this._created = false;
		this._viewContainerRef.clear();
	}
	enforceState(created) {
		if (created && !this._created) this.create();
		else if (!created && this._created) this.destroy();
	}
};
var NgSwitch = class {
	constructor() {
		_defineProperty(this, "_defaultViews", []);
		_defineProperty(this, "_defaultUsed", false);
		_defineProperty(this, "_caseCount", 0);
		_defineProperty(this, "_lastCaseCheckIndex", 0);
		_defineProperty(this, "_lastCasesMatched", false);
		_defineProperty(this, "_ngSwitch", void 0);
	}
	set ngSwitch(newValue) {
		this._ngSwitch = newValue;
		if (this._caseCount === 0) this._updateDefaultCases(true);
	}
	_addCase() {
		return this._caseCount++;
	}
	_addDefault(view) {
		this._defaultViews.push(view);
	}
	_matchCase(value) {
		const matched = value === this._ngSwitch;
		this._lastCasesMatched || (this._lastCasesMatched = matched);
		this._lastCaseCheckIndex++;
		if (this._lastCaseCheckIndex === this._caseCount) {
			this._updateDefaultCases(!this._lastCasesMatched);
			this._lastCaseCheckIndex = 0;
			this._lastCasesMatched = false;
		}
		return matched;
	}
	_updateDefaultCases(useDefault) {
		if (this._defaultViews.length > 0 && useDefault !== this._defaultUsed) {
			this._defaultUsed = useDefault;
			for (const defaultView of this._defaultViews) defaultView.enforceState(useDefault);
		}
	}
};
_NgSwitch = NgSwitch;
_defineProperty(NgSwitch, "ɵfac", function NgSwitch_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgSwitch)();
});
_defineProperty(NgSwitch, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgSwitch,
	selectors: [[
		"",
		"ngSwitch",
		""
	]],
	inputs: { ngSwitch: "ngSwitch" }
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgSwitch, [{
		type: Directive,
		args: [{ selector: "[ngSwitch]" }]
	}], null, { ngSwitch: [{ type: Input }] });
})();
var NgSwitchCase = class {
	constructor(viewContainer, templateRef, ngSwitch) {
		_defineProperty(this, "ngSwitch", void 0);
		_defineProperty(this, "_view", void 0);
		_defineProperty(this, "ngSwitchCase", void 0);
		this.ngSwitch = ngSwitch;
		if ((typeof ngDevMode === "undefined" || ngDevMode) && !ngSwitch) throwNgSwitchProviderNotFoundError("ngSwitchCase", "NgSwitchCase");
		ngSwitch._addCase();
		this._view = new SwitchView(viewContainer, templateRef);
	}
	ngDoCheck() {
		this._view.enforceState(this.ngSwitch._matchCase(this.ngSwitchCase));
	}
};
_NgSwitchCase = NgSwitchCase;
_defineProperty(NgSwitchCase, "ɵfac", function NgSwitchCase_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgSwitchCase)(ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(TemplateRef), ɵɵdirectiveInject(NgSwitch, 9));
});
_defineProperty(NgSwitchCase, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgSwitchCase,
	selectors: [[
		"",
		"ngSwitchCase",
		""
	]],
	inputs: { ngSwitchCase: "ngSwitchCase" }
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgSwitchCase, [{
		type: Directive,
		args: [{ selector: "[ngSwitchCase]" }]
	}], () => [
		{ type: ViewContainerRef },
		{ type: TemplateRef },
		{
			type: NgSwitch,
			decorators: [{ type: Optional }, { type: Host }]
		}
	], { ngSwitchCase: [{ type: Input }] });
})();
var NgSwitchDefault = class {
	constructor(viewContainer, templateRef, ngSwitch) {
		if ((typeof ngDevMode === "undefined" || ngDevMode) && !ngSwitch) throwNgSwitchProviderNotFoundError("ngSwitchDefault", "NgSwitchDefault");
		ngSwitch._addDefault(new SwitchView(viewContainer, templateRef));
	}
};
_NgSwitchDefault = NgSwitchDefault;
_defineProperty(NgSwitchDefault, "ɵfac", function NgSwitchDefault_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgSwitchDefault)(ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(TemplateRef), ɵɵdirectiveInject(NgSwitch, 9));
});
_defineProperty(NgSwitchDefault, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgSwitchDefault,
	selectors: [[
		"",
		"ngSwitchDefault",
		""
	]]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgSwitchDefault, [{
		type: Directive,
		args: [{ selector: "[ngSwitchDefault]" }]
	}], () => [
		{ type: ViewContainerRef },
		{ type: TemplateRef },
		{
			type: NgSwitch,
			decorators: [{ type: Optional }, { type: Host }]
		}
	], null);
})();
function throwNgSwitchProviderNotFoundError(attrName, directiveName) {
	throw new RuntimeError(2e3, `An element with the "${attrName}" attribute (matching the "${directiveName}" directive) must be located inside an element with the "ngSwitch" attribute (matching "NgSwitch" directive)`);
}
var NgPlural = class {
	constructor(_localization) {
		_defineProperty(this, "_localization", void 0);
		_defineProperty(this, "_activeView", void 0);
		_defineProperty(this, "_caseViews", {});
		this._localization = _localization;
	}
	set ngPlural(value) {
		this._updateView(value);
	}
	addCase(value, switchView) {
		this._caseViews[value] = switchView;
	}
	_updateView(switchValue) {
		this._clearViews();
		const key = getPluralCategory(switchValue, Object.keys(this._caseViews), this._localization);
		this._activateView(this._caseViews[key]);
	}
	_clearViews() {
		if (this._activeView) this._activeView.destroy();
	}
	_activateView(view) {
		if (view) {
			this._activeView = view;
			this._activeView.create();
		}
	}
};
_NgPlural = NgPlural;
_defineProperty(NgPlural, "ɵfac", function NgPlural_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgPlural)(ɵɵdirectiveInject(NgLocalization));
});
_defineProperty(NgPlural, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgPlural,
	selectors: [[
		"",
		"ngPlural",
		""
	]],
	inputs: { ngPlural: "ngPlural" }
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgPlural, [{
		type: Directive,
		args: [{ selector: "[ngPlural]" }]
	}], () => [{ type: NgLocalization }], { ngPlural: [{ type: Input }] });
})();
var NgPluralCase = class {
	constructor(value, template, viewContainer, ngPlural) {
		_defineProperty(this, "value", void 0);
		this.value = value;
		const isANumber = !isNaN(Number(value));
		ngPlural.addCase(isANumber ? `=${value}` : value, new SwitchView(viewContainer, template));
	}
};
_NgPluralCase = NgPluralCase;
_defineProperty(NgPluralCase, "ɵfac", function NgPluralCase_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgPluralCase)(ɵɵinjectAttribute("ngPluralCase"), ɵɵdirectiveInject(TemplateRef), ɵɵdirectiveInject(ViewContainerRef), ɵɵdirectiveInject(NgPlural, 1));
});
_defineProperty(NgPluralCase, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgPluralCase,
	selectors: [[
		"",
		"ngPluralCase",
		""
	]]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgPluralCase, [{
		type: Directive,
		args: [{ selector: "[ngPluralCase]" }]
	}], () => [
		{
			type: void 0,
			decorators: [{
				type: Attribute,
				args: ["ngPluralCase"]
			}]
		},
		{ type: TemplateRef },
		{ type: ViewContainerRef },
		{
			type: NgPlural,
			decorators: [{ type: Host }]
		}
	], null);
})();
var NgStyle = class {
	constructor(_ngEl, _differs, _renderer) {
		_defineProperty(this, "_ngEl", void 0);
		_defineProperty(this, "_differs", void 0);
		_defineProperty(this, "_renderer", void 0);
		_defineProperty(this, "_ngStyle", null);
		_defineProperty(this, "_differ", null);
		this._ngEl = _ngEl;
		this._differs = _differs;
		this._renderer = _renderer;
	}
	set ngStyle(values) {
		this._ngStyle = values;
		if (!this._differ && values) this._differ = this._differs.find(values).create();
	}
	ngDoCheck() {
		if (this._differ) {
			const changes = this._differ.diff(this._ngStyle);
			if (changes) this._applyChanges(changes);
		}
	}
	_setStyle(nameAndUnit, value) {
		const [name, unit] = nameAndUnit.split(".");
		const flags = name.indexOf("-") === -1 ? void 0 : RendererStyleFlags2.DashCase;
		if (value != null) this._renderer.setStyle(this._ngEl.nativeElement, name, unit ? `${value}${unit}` : value, flags);
		else this._renderer.removeStyle(this._ngEl.nativeElement, name, flags);
	}
	_applyChanges(changes) {
		changes.forEachRemovedItem((record) => this._setStyle(record.key, null));
		changes.forEachAddedItem((record) => this._setStyle(record.key, record.currentValue));
		changes.forEachChangedItem((record) => this._setStyle(record.key, record.currentValue));
	}
};
_NgStyle = NgStyle;
_defineProperty(NgStyle, "ɵfac", function NgStyle_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgStyle)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(KeyValueDiffers), ɵɵdirectiveInject(Renderer2));
});
_defineProperty(NgStyle, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgStyle,
	selectors: [[
		"",
		"ngStyle",
		""
	]],
	inputs: { ngStyle: "ngStyle" }
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgStyle, [{
		type: Directive,
		args: [{ selector: "[ngStyle]" }]
	}], () => [
		{ type: ElementRef },
		{ type: KeyValueDiffers },
		{ type: Renderer2 }
	], { ngStyle: [{
		type: Input,
		args: ["ngStyle"]
	}] });
})();
var NgTemplateOutlet = class {
	constructor(_viewContainerRef) {
		_defineProperty(this, "_viewContainerRef", void 0);
		_defineProperty(this, "_viewRef", null);
		_defineProperty(this, "ngTemplateOutletContext", null);
		_defineProperty(this, "ngTemplateOutlet", null);
		_defineProperty(this, "ngTemplateOutletInjector", null);
		_defineProperty(this, "injector", inject(Injector));
		this._viewContainerRef = _viewContainerRef;
	}
	ngOnChanges(changes) {
		if (this._shouldRecreateView(changes)) {
			const viewContainerRef = this._viewContainerRef;
			if (this._viewRef) viewContainerRef.remove(viewContainerRef.indexOf(this._viewRef));
			if (!this.ngTemplateOutlet) {
				this._viewRef = null;
				return;
			}
			const viewContext = this._createContextForwardProxy();
			this._viewRef = viewContainerRef.createEmbeddedView(this.ngTemplateOutlet, viewContext, { injector: this._getInjector() });
		}
	}
	_getInjector() {
		var _this$ngTemplateOutle;
		if (this.ngTemplateOutletInjector === "outlet") return this.injector;
		return (_this$ngTemplateOutle = this.ngTemplateOutletInjector) !== null && _this$ngTemplateOutle !== void 0 ? _this$ngTemplateOutle : void 0;
	}
	_shouldRecreateView(changes) {
		return !!changes["ngTemplateOutlet"] || !!changes["ngTemplateOutletInjector"];
	}
	_createContextForwardProxy() {
		return new Proxy({}, {
			set: (_target, prop, newValue) => {
				if (!this.ngTemplateOutletContext) return false;
				return Reflect.set(this.ngTemplateOutletContext, prop, newValue);
			},
			get: (_target, prop, receiver) => {
				if (!this.ngTemplateOutletContext) return;
				return Reflect.get(this.ngTemplateOutletContext, prop, receiver);
			}
		});
	}
};
_NgTemplateOutlet = NgTemplateOutlet;
_defineProperty(NgTemplateOutlet, "ɵfac", function NgTemplateOutlet_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgTemplateOutlet)(ɵɵdirectiveInject(ViewContainerRef));
});
_defineProperty(NgTemplateOutlet, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgTemplateOutlet,
	selectors: [[
		"",
		"ngTemplateOutlet",
		""
	]],
	inputs: {
		ngTemplateOutletContext: "ngTemplateOutletContext",
		ngTemplateOutlet: "ngTemplateOutlet",
		ngTemplateOutletInjector: "ngTemplateOutletInjector"
	},
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgTemplateOutlet, [{
		type: Directive,
		args: [{ selector: "[ngTemplateOutlet]" }]
	}], () => [{ type: ViewContainerRef }], {
		ngTemplateOutletContext: [{ type: Input }],
		ngTemplateOutlet: [{ type: Input }],
		ngTemplateOutletInjector: [{ type: Input }]
	});
})();
var COMMON_DIRECTIVES = [
	NgClass,
	NgComponentOutlet,
	NgForOf,
	NgIf,
	NgTemplateOutlet,
	NgStyle,
	NgSwitch,
	NgSwitchCase,
	NgSwitchDefault,
	NgPlural,
	NgPluralCase
];
function invalidPipeArgumentError(type, value) {
	return new RuntimeError(2100, ngDevMode && `InvalidPipeArgument: '${value}' for pipe '${stringify(type)}'`);
}
function warnIfSignal(pipeName, value) {
	if (isSignal(value)) console.warn(`The ${pipeName} does not unwrap signals. Received a signal with value:`, value());
}
var SubscribableStrategy = class {
	createSubscription(async, updateLatestValue, onError) {
		return untracked(() => async.subscribe({
			next: updateLatestValue,
			error: onError
		}));
	}
	dispose(subscription) {
		untracked(() => subscription.unsubscribe());
	}
};
var PromiseStrategy = class {
	createSubscription(async, updateLatestValue, onError) {
		async.then((v) => updateLatestValue === null || updateLatestValue === void 0 ? void 0 : updateLatestValue(v), (e) => onError === null || onError === void 0 ? void 0 : onError(e));
		return { unsubscribe: () => {
			updateLatestValue = null;
			onError = null;
		} };
	}
	dispose(subscription) {
		subscription.unsubscribe();
	}
};
var _promiseStrategy = new PromiseStrategy();
var _subscribableStrategy = new SubscribableStrategy();
var AsyncPipe = class AsyncPipe {
	constructor(ref) {
		_defineProperty(this, "_ref", void 0);
		_defineProperty(this, "_latestValue", null);
		_defineProperty(this, "markForCheckOnValueUpdate", true);
		_defineProperty(this, "_subscription", null);
		_defineProperty(this, "_obj", null);
		_defineProperty(this, "_strategy", null);
		_defineProperty(this, "applicationErrorHandler", inject(INTERNAL_APPLICATION_ERROR_HANDLER));
		this._ref = ref;
	}
	ngOnDestroy() {
		if (this._subscription) this._dispose();
		this._ref = null;
	}
	transform(obj) {
		if (!this._obj) {
			if (obj) try {
				this.markForCheckOnValueUpdate = false;
				this._subscribe(obj);
			} finally {
				this.markForCheckOnValueUpdate = true;
			}
			return this._latestValue;
		}
		if (obj !== this._obj) {
			this._dispose();
			return this.transform(obj);
		}
		return this._latestValue;
	}
	_subscribe(obj) {
		this._obj = obj;
		this._strategy = this._selectStrategy(obj);
		this._subscription = this._strategy.createSubscription(obj, (value) => this._updateLatestValue(obj, value), (e) => this.applicationErrorHandler(e));
	}
	_selectStrategy(obj) {
		if (isPromise(obj)) return _promiseStrategy;
		if (isSubscribable(obj)) return _subscribableStrategy;
		throw invalidPipeArgumentError(AsyncPipe, obj);
	}
	_dispose() {
		this._strategy.dispose(this._subscription);
		this._latestValue = null;
		this._subscription = null;
		this._obj = null;
	}
	_updateLatestValue(async, value) {
		if (async === this._obj) {
			this._latestValue = value;
			if (this.markForCheckOnValueUpdate) {
				var _this$_ref;
				(_this$_ref = this._ref) === null || _this$_ref === void 0 || _this$_ref.markForCheck();
			}
		}
	}
};
_AsyncPipe = AsyncPipe;
_defineProperty(AsyncPipe, "ɵfac", function AsyncPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _AsyncPipe)(ɵɵdirectiveInject(ChangeDetectorRef, 16));
});
_defineProperty(AsyncPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "async",
	type: _AsyncPipe,
	pure: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AsyncPipe, [{
		type: Pipe,
		args: [{
			name: "async",
			pure: false
		}]
	}], () => [{ type: ChangeDetectorRef }], null);
})();
var LowerCasePipe = class LowerCasePipe {
	transform(value) {
		if (value == null) return null;
		assertPipeArgument(LowerCasePipe, value);
		return value.toLowerCase();
	}
};
_LowerCasePipe = LowerCasePipe;
_defineProperty(LowerCasePipe, "ɵfac", function LowerCasePipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _LowerCasePipe)();
});
_defineProperty(LowerCasePipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "lowercase",
	type: _LowerCasePipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LowerCasePipe, [{
		type: Pipe,
		args: [{ name: "lowercase" }]
	}], null, null);
})();
var unicodeWordMatch = /(?:[0-9A-Za-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDEE0-\uDEF2\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE7F\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD50-\uDD52\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E]|\uD838[\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF38\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A])\S*/g;
var TitleCasePipe = class TitleCasePipe {
	transform(value) {
		if (value == null) return null;
		assertPipeArgument(TitleCasePipe, value);
		return value.replace(unicodeWordMatch, (txt) => txt[0].toUpperCase() + txt.slice(1).toLowerCase());
	}
};
_TitleCasePipe = TitleCasePipe;
_defineProperty(TitleCasePipe, "ɵfac", function TitleCasePipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _TitleCasePipe)();
});
_defineProperty(TitleCasePipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "titlecase",
	type: _TitleCasePipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TitleCasePipe, [{
		type: Pipe,
		args: [{ name: "titlecase" }]
	}], null, null);
})();
var UpperCasePipe = class UpperCasePipe {
	transform(value) {
		if (value == null) return null;
		assertPipeArgument(UpperCasePipe, value);
		return value.toUpperCase();
	}
};
_UpperCasePipe = UpperCasePipe;
_defineProperty(UpperCasePipe, "ɵfac", function UpperCasePipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _UpperCasePipe)();
});
_defineProperty(UpperCasePipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "uppercase",
	type: _UpperCasePipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UpperCasePipe, [{
		type: Pipe,
		args: [{ name: "uppercase" }]
	}], null, null);
})();
function assertPipeArgument(pipe, value) {
	if (typeof value !== "string") throw invalidPipeArgumentError(pipe, value);
}
var DEFAULT_DATE_FORMAT = "mediumDate";
var DATE_PIPE_DEFAULT_TIMEZONE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DATE_PIPE_DEFAULT_TIMEZONE" : "");
var DATE_PIPE_DEFAULT_OPTIONS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "DATE_PIPE_DEFAULT_OPTIONS" : "");
var DatePipe = class DatePipe {
	constructor(locale, defaultTimezone, defaultOptions) {
		_defineProperty(this, "locale", void 0);
		_defineProperty(this, "defaultTimezone", void 0);
		_defineProperty(this, "defaultOptions", void 0);
		this.locale = locale;
		this.defaultTimezone = defaultTimezone;
		this.defaultOptions = defaultOptions;
	}
	transform(value, format, timezone, locale) {
		if (value == null || value === "" || value !== value) return null;
		try {
			var _ref, _this$defaultOptions, _ref2, _ref3, _this$defaultOptions2;
			const _format = (_ref = format !== null && format !== void 0 ? format : (_this$defaultOptions = this.defaultOptions) === null || _this$defaultOptions === void 0 ? void 0 : _this$defaultOptions.dateFormat) !== null && _ref !== void 0 ? _ref : DEFAULT_DATE_FORMAT;
			const _timezone = (_ref2 = (_ref3 = timezone !== null && timezone !== void 0 ? timezone : (_this$defaultOptions2 = this.defaultOptions) === null || _this$defaultOptions2 === void 0 ? void 0 : _this$defaultOptions2.timezone) !== null && _ref3 !== void 0 ? _ref3 : this.defaultTimezone) !== null && _ref2 !== void 0 ? _ref2 : void 0;
			return formatDate(value, _format, locale || this.locale, _timezone);
		} catch (error) {
			throw invalidPipeArgumentError(DatePipe, error.message);
		}
	}
};
_DatePipe = DatePipe;
_defineProperty(DatePipe, "ɵfac", function DatePipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DatePipe)(ɵɵdirectiveInject(LOCALE_ID, 16), ɵɵdirectiveInject(DATE_PIPE_DEFAULT_TIMEZONE, 24), ɵɵdirectiveInject(DATE_PIPE_DEFAULT_OPTIONS, 24));
});
_defineProperty(DatePipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "date",
	type: _DatePipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DatePipe, [{
		type: Pipe,
		args: [{ name: "date" }]
	}], () => [
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [LOCALE_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DATE_PIPE_DEFAULT_TIMEZONE]
			}, { type: Optional }]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [DATE_PIPE_DEFAULT_OPTIONS]
			}, { type: Optional }]
		}
	], null);
})();
var _INTERPOLATION_REGEXP = /#/g;
var I18nPluralPipe = class I18nPluralPipe {
	constructor(_localization) {
		_defineProperty(this, "_localization", void 0);
		this._localization = _localization;
	}
	transform(value, pluralMap, locale) {
		if (value == null) return "";
		if (typeof pluralMap !== "object" || pluralMap === null) throw invalidPipeArgumentError(I18nPluralPipe, pluralMap);
		return pluralMap[getPluralCategory(value, Object.keys(pluralMap), this._localization, locale)].replace(_INTERPOLATION_REGEXP, value.toString());
	}
};
_I18nPluralPipe = I18nPluralPipe;
_defineProperty(I18nPluralPipe, "ɵfac", function I18nPluralPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _I18nPluralPipe)(ɵɵdirectiveInject(NgLocalization, 16));
});
_defineProperty(I18nPluralPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "i18nPlural",
	type: _I18nPluralPipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(I18nPluralPipe, [{
		type: Pipe,
		args: [{ name: "i18nPlural" }]
	}], () => [{ type: NgLocalization }], null);
})();
var I18nSelectPipe = class I18nSelectPipe {
	transform(value, mapping) {
		if (value == null) return "";
		if (typeof mapping !== "object" || typeof value !== "string") throw invalidPipeArgumentError(I18nSelectPipe, mapping);
		if (Object.hasOwn(mapping, value)) return mapping[value];
		if (Object.hasOwn(mapping, "other")) return mapping["other"];
		return "";
	}
};
_I18nSelectPipe = I18nSelectPipe;
_defineProperty(I18nSelectPipe, "ɵfac", function I18nSelectPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _I18nSelectPipe)();
});
_defineProperty(I18nSelectPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "i18nSelect",
	type: _I18nSelectPipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(I18nSelectPipe, [{
		type: Pipe,
		args: [{ name: "i18nSelect" }]
	}], null, null);
})();
var JsonPipe = class {
	transform(value) {
		ngDevMode && warnIfSignal("JsonPipe", value);
		return JSON.stringify(value, null, 2);
	}
};
_JsonPipe = JsonPipe;
_defineProperty(JsonPipe, "ɵfac", function JsonPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _JsonPipe)();
});
_defineProperty(JsonPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "json",
	type: _JsonPipe,
	pure: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(JsonPipe, [{
		type: Pipe,
		args: [{
			name: "json",
			pure: false
		}]
	}], null, null);
})();
function makeKeyValuePair(key, value) {
	return {
		key,
		value
	};
}
var KeyValuePipe = class {
	constructor(differs) {
		_defineProperty(this, "differs", void 0);
		_defineProperty(this, "differ", void 0);
		_defineProperty(this, "keyValues", []);
		_defineProperty(this, "compareFn", defaultComparator);
		this.differs = differs;
	}
	transform(input, compareFn = defaultComparator) {
		var _this$differ;
		ngDevMode && warnIfSignal("KeyValuePipe", input);
		if (!input || !(input instanceof Map) && typeof input !== "object") return null;
		(_this$differ = this.differ) !== null && _this$differ !== void 0 || (this.differ = this.differs.find(input).create());
		const differChanges = this.differ.diff(input);
		const compareFnChanged = compareFn !== this.compareFn;
		if (differChanges) {
			this.keyValues = [];
			differChanges.forEachItem((r) => {
				this.keyValues.push(makeKeyValuePair(r.key, r.currentValue));
			});
		}
		if (differChanges || compareFnChanged) {
			if (compareFn) this.keyValues.sort(compareFn);
			this.compareFn = compareFn;
		}
		return this.keyValues;
	}
};
_KeyValuePipe = KeyValuePipe;
_defineProperty(KeyValuePipe, "ɵfac", function KeyValuePipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _KeyValuePipe)(ɵɵdirectiveInject(KeyValueDiffers, 16));
});
_defineProperty(KeyValuePipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "keyvalue",
	type: _KeyValuePipe,
	pure: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(KeyValuePipe, [{
		type: Pipe,
		args: [{
			name: "keyvalue",
			pure: false
		}]
	}], () => [{ type: KeyValueDiffers }], null);
})();
function defaultComparator(keyValueA, keyValueB) {
	const a = keyValueA.key;
	const b = keyValueB.key;
	if (a === b) return 0;
	if (a == null) return 1;
	if (b == null) return -1;
	if (typeof a == "string" && typeof b == "string") return a < b ? -1 : 1;
	if (typeof a == "number" && typeof b == "number") return a - b;
	if (typeof a == "boolean" && typeof b == "boolean") return a < b ? -1 : 1;
	const aString = String(a);
	const bString = String(b);
	return aString == bString ? 0 : aString < bString ? -1 : 1;
}
var DecimalPipe = class DecimalPipe {
	constructor(_locale) {
		_defineProperty(this, "_locale", void 0);
		this._locale = _locale;
	}
	transform(value, digitsInfo, locale) {
		if (!isValue(value)) return null;
		locale || (locale = this._locale);
		try {
			return formatNumber(strToNumber(value), locale, digitsInfo);
		} catch (error) {
			throw invalidPipeArgumentError(DecimalPipe, error.message);
		}
	}
};
_DecimalPipe = DecimalPipe;
_defineProperty(DecimalPipe, "ɵfac", function DecimalPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DecimalPipe)(ɵɵdirectiveInject(LOCALE_ID, 16));
});
_defineProperty(DecimalPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "number",
	type: _DecimalPipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DecimalPipe, [{
		type: Pipe,
		args: [{ name: "number" }]
	}], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [LOCALE_ID]
		}]
	}], null);
})();
var PercentPipe = class PercentPipe {
	constructor(_locale) {
		_defineProperty(this, "_locale", void 0);
		this._locale = _locale;
	}
	transform(value, digitsInfo, locale) {
		if (!isValue(value)) return null;
		locale || (locale = this._locale);
		try {
			return formatPercent(strToNumber(value), locale, digitsInfo);
		} catch (error) {
			throw invalidPipeArgumentError(PercentPipe, error.message);
		}
	}
};
_PercentPipe = PercentPipe;
_defineProperty(PercentPipe, "ɵfac", function PercentPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _PercentPipe)(ɵɵdirectiveInject(LOCALE_ID, 16));
});
_defineProperty(PercentPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "percent",
	type: _PercentPipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PercentPipe, [{
		type: Pipe,
		args: [{ name: "percent" }]
	}], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [LOCALE_ID]
		}]
	}], null);
})();
var CurrencyPipe = class CurrencyPipe {
	constructor(_locale, _defaultCurrencyCode = "USD") {
		_defineProperty(this, "_locale", void 0);
		_defineProperty(this, "_defaultCurrencyCode", void 0);
		this._locale = _locale;
		this._defaultCurrencyCode = _defaultCurrencyCode;
	}
	transform(value, currencyCode = this._defaultCurrencyCode, display = "symbol", digitsInfo, locale) {
		if (!isValue(value)) return null;
		locale || (locale = this._locale);
		if (typeof display === "boolean") {
			if (typeof ngDevMode === "undefined" || ngDevMode) console.warn(`Warning: the currency pipe has been changed in Angular v5. The symbolDisplay option (third parameter) is now a string instead of a boolean. The accepted values are "code", "symbol" or "symbol-narrow".`);
			display = display ? "symbol" : "code";
		}
		let currency = currencyCode || this._defaultCurrencyCode;
		if (display !== "code") if (display === "symbol" || display === "symbol-narrow") currency = getCurrencySymbol(currency, display === "symbol" ? "wide" : "narrow", locale);
		else currency = display;
		try {
			return formatCurrency(strToNumber(value), locale, currency, currencyCode, digitsInfo);
		} catch (error) {
			throw invalidPipeArgumentError(CurrencyPipe, error.message);
		}
	}
};
_CurrencyPipe = CurrencyPipe;
_defineProperty(CurrencyPipe, "ɵfac", function CurrencyPipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _CurrencyPipe)(ɵɵdirectiveInject(LOCALE_ID, 16), ɵɵdirectiveInject(DEFAULT_CURRENCY_CODE, 16));
});
_defineProperty(CurrencyPipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "currency",
	type: _CurrencyPipe,
	pure: true
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CurrencyPipe, [{
		type: Pipe,
		args: [{ name: "currency" }]
	}], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [LOCALE_ID]
		}]
	}, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [DEFAULT_CURRENCY_CODE]
		}]
	}], null);
})();
function isValue(value) {
	return !(value == null || value === "" || value !== value);
}
function strToNumber(value) {
	if (typeof value === "string" && !isNaN(Number(value) - parseFloat(value))) return Number(value);
	if (typeof value !== "number") throw new RuntimeError(2309, ngDevMode && `${value} is not a number`);
	return value;
}
var SlicePipe = class SlicePipe {
	transform(value, start, end) {
		if (value == null) return null;
		if (!(typeof value === "string" || Array.isArray(value))) throw invalidPipeArgumentError(SlicePipe, value);
		return value.slice(start, end);
	}
};
_SlicePipe = SlicePipe;
_defineProperty(SlicePipe, "ɵfac", function SlicePipe_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _SlicePipe)();
});
_defineProperty(SlicePipe, "ɵpipe", /* @__PURE__ */ ɵɵdefinePipe({
	name: "slice",
	type: _SlicePipe,
	pure: false
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SlicePipe, [{
		type: Pipe,
		args: [{
			name: "slice",
			pure: false
		}]
	}], null, null);
})();
var COMMON_PIPES = [
	AsyncPipe,
	UpperCasePipe,
	LowerCasePipe,
	JsonPipe,
	SlicePipe,
	DecimalPipe,
	PercentPipe,
	TitleCasePipe,
	CurrencyPipe,
	DatePipe,
	I18nPluralPipe,
	I18nSelectPipe,
	KeyValuePipe
];
var CommonModule = class {};
_CommonModule = CommonModule;
_defineProperty(CommonModule, "ɵfac", function CommonModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _CommonModule)();
});
_defineProperty(CommonModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({
	type: _CommonModule,
	imports: [
		NgClass,
		NgComponentOutlet,
		NgForOf,
		NgIf,
		NgTemplateOutlet,
		NgStyle,
		NgSwitch,
		NgSwitchCase,
		NgSwitchDefault,
		NgPlural,
		NgPluralCase,
		AsyncPipe,
		UpperCasePipe,
		LowerCasePipe,
		JsonPipe,
		SlicePipe,
		DecimalPipe,
		PercentPipe,
		TitleCasePipe,
		CurrencyPipe,
		DatePipe,
		I18nPluralPipe,
		I18nSelectPipe,
		KeyValuePipe
	],
	exports: [
		NgClass,
		NgComponentOutlet,
		NgForOf,
		NgIf,
		NgTemplateOutlet,
		NgStyle,
		NgSwitch,
		NgSwitchCase,
		NgSwitchDefault,
		NgPlural,
		NgPluralCase,
		AsyncPipe,
		UpperCasePipe,
		LowerCasePipe,
		JsonPipe,
		SlicePipe,
		DecimalPipe,
		PercentPipe,
		TitleCasePipe,
		CurrencyPipe,
		DatePipe,
		I18nPluralPipe,
		I18nSelectPipe,
		KeyValuePipe
	]
}));
_defineProperty(CommonModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CommonModule, [{
		type: NgModule,
		args: [{
			imports: [COMMON_DIRECTIVES, COMMON_PIPES],
			exports: [COMMON_DIRECTIVES, COMMON_PIPES]
		}]
	}], null, null);
})();
//#endregion
//#region node_modules/@angular/common/fesm2022/_platform_navigation-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _PlatformNavigation;
var PRECOMMIT_HANDLER_SUPPORTED = new InjectionToken("", { factory: () => {
	return typeof window !== "undefined" && typeof window.NavigationPrecommitController !== "undefined";
} });
var PlatformNavigation = class {};
_PlatformNavigation = PlatformNavigation;
_defineProperty(PlatformNavigation, "ɵfac", function PlatformNavigation_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _PlatformNavigation)();
});
_defineProperty(PlatformNavigation, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _PlatformNavigation,
	factory: () => (() => window.navigation)(),
	providedIn: "platform"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PlatformNavigation, [{
		type: Injectable,
		args: [{
			providedIn: "platform",
			useFactory: () => window.navigation
		}]
	}], null, null);
})();
//#endregion
//#region node_modules/@angular/common/fesm2022/common.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _NavigationAdapterForLocation;
var _ViewportScroller;
var _LCPImageObserver;
var _PreconnectLinkChecker;
var _PreloadLinkCreator;
var _NgOptimizedImage;
var NavigationAdapterForLocation = class extends Location {
	constructor() {
		super(inject(LocationStrategy));
		_defineProperty(this, "navigation", inject(PlatformNavigation));
		_defineProperty(this, "destroyRef", inject(DestroyRef));
		this.registerNavigationListeners();
	}
	registerNavigationListeners() {
		const currentEntryChangeListener = () => {
			this._notifyUrlChangeListeners(this.path(true), this.getState());
		};
		this.navigation.addEventListener("currententrychange", currentEntryChangeListener);
		this.destroyRef.onDestroy(() => {
			this.navigation.removeEventListener("currententrychange", currentEntryChangeListener);
		});
	}
	getState() {
		var _this$navigation$curr;
		return (_this$navigation$curr = this.navigation.currentEntry) === null || _this$navigation$curr === void 0 ? void 0 : _this$navigation$curr.getState();
	}
	replaceState(path, query = "", state = null) {
		const url = this.prepareExternalUrl(path + normalizeQueryParams(query));
		this.navigation.navigate(url, {
			state,
			history: "replace"
		});
	}
	go(path, query = "", state = null) {
		const url = this.prepareExternalUrl(path + normalizeQueryParams(query));
		this.navigation.navigate(url, {
			state,
			history: "push"
		});
	}
	back() {
		this.navigation.back();
	}
	forward() {
		this.navigation.forward();
	}
	onUrlChange(fn) {
		this._urlChangeListeners.push(fn);
		return () => {
			const fnIndex = this._urlChangeListeners.indexOf(fn);
			this._urlChangeListeners.splice(fnIndex, 1);
		};
	}
};
_NavigationAdapterForLocation = NavigationAdapterForLocation;
_defineProperty(NavigationAdapterForLocation, "ɵfac", function NavigationAdapterForLocation_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NavigationAdapterForLocation)();
});
_defineProperty(NavigationAdapterForLocation, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _NavigationAdapterForLocation,
	factory: _NavigationAdapterForLocation.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NavigationAdapterForLocation, [{ type: Injectable }], () => [], null);
})();
function registerLocaleData(data, localeId, extraData) {
	return registerLocaleData$1(data, localeId, extraData);
}
var PLATFORM_BROWSER_ID = "browser";
var PLATFORM_SERVER_ID = "server";
function isPlatformBrowser(platformId) {
	return platformId === PLATFORM_BROWSER_ID;
}
function isPlatformServer(platformId) {
	return platformId === PLATFORM_SERVER_ID;
}
var VERSION = /* @__PURE__ */ new Version("22.1.2");
var ViewportScroller = class {};
_ViewportScroller = ViewportScroller;
_defineProperty(ViewportScroller, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _ViewportScroller,
	providedIn: "root",
	factory: () => new BrowserViewportScroller(inject(DOCUMENT), window)
}));
var BrowserViewportScroller = class {
	constructor(document, window) {
		_defineProperty(this, "document", void 0);
		_defineProperty(this, "window", void 0);
		_defineProperty(this, "offset", () => [0, 0]);
		this.document = document;
		this.window = window;
	}
	setOffset(offset) {
		if (Array.isArray(offset)) this.offset = () => offset;
		else this.offset = offset;
	}
	getScrollPosition() {
		return [this.window.scrollX, this.window.scrollY];
	}
	scrollToPosition(position, options) {
		this.window.scrollTo(_objectSpread2(_objectSpread2({}, options), {}, {
			left: position[0],
			top: position[1]
		}));
	}
	scrollToAnchor(target, options) {
		const elSelected = findAnchorFromDocument(this.document, target);
		if (elSelected) {
			this.scrollToElement(elSelected, options);
			elSelected.focus({ preventScroll: true });
		}
	}
	setHistoryScrollRestoration(scrollRestoration) {
		try {
			this.window.history.scrollRestoration = scrollRestoration;
		} catch (_unused) {
			console.warn(formatRuntimeError(2400, ngDevMode && "Failed to set `window.history.scrollRestoration`. This may occur when:\n• The script is running inside a sandboxed iframe\n• The window is partially navigated or inactive\n• The script is executed in an untrusted or special context (e.g., test runners, browser extensions, or content previews)\nScroll position may not be preserved across navigation."));
		}
	}
	scrollToElement(el, options) {
		const rect = el.getBoundingClientRect();
		const left = rect.left + this.window.pageXOffset;
		const top = rect.top + this.window.pageYOffset;
		const offset = this.offset();
		this.window.scrollTo(_objectSpread2(_objectSpread2({}, options), {}, {
			left: left - offset[0],
			top: top - offset[1]
		}));
	}
};
function findAnchorFromDocument(document, target) {
	const documentResult = document.getElementById(target) || document.getElementsByName(target)[0];
	if (documentResult) return documentResult;
	if (typeof document.createTreeWalker === "function" && document.body && typeof document.body.attachShadow === "function") {
		const treeWalker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
		let currentNode = treeWalker.currentNode;
		while (currentNode) {
			const shadowRoot = currentNode.shadowRoot;
			if (shadowRoot) {
				const result = shadowRoot.getElementById(target) || shadowRoot.querySelector(`[name="${CSS.escape(target)}"]`);
				if (result) return result;
			}
			currentNode = treeWalker.nextNode();
		}
	}
	return null;
}
var NullViewportScroller = class {
	setOffset(offset) {}
	getScrollPosition() {
		return [0, 0];
	}
	scrollToPosition(position) {}
	scrollToAnchor(anchor, options) {}
	setHistoryScrollRestoration(scrollRestoration) {}
};
var PLACEHOLDER_QUALITY = "20";
function getUrl(src, win) {
	return isAbsoluteUrl(src) ? new URL(src) : new URL(src, win.location.href);
}
function isAbsoluteUrl(src) {
	return /^https?:\/\//.test(src);
}
function extractHostname(url) {
	return isAbsoluteUrl(url) ? new URL(url).hostname : url;
}
function isValidPath(path) {
	if (!(typeof path === "string") || path.trim() === "") return false;
	try {
		new URL(path);
		return true;
	} catch (_unused2) {
		return false;
	}
}
function normalizePath(path) {
	return path.endsWith("/") ? path.slice(0, -1) : path;
}
function normalizeSrc(src) {
	return src.startsWith("/") ? src.slice(1) : src;
}
function escapeCssUrl(input) {
	return input.replace(/\\/g, "\\\\").replace(/[\n\r\f\0]/g, "").replace(/"/g, "\\\"");
}
var noopImageLoader = (config) => config.src;
var IMAGE_LOADER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ImageLoader" : "", { factory: () => noopImageLoader });
function createImageLoader(buildUrlFn, exampleUrls) {
	return function provideImageLoader(path) {
		if (!isValidPath(path)) throwInvalidPathError(path, exampleUrls || []);
		path = normalizePath(path);
		const loaderFn = (config) => {
			if (isAbsoluteUrl(config.src)) throwUnexpectedAbsoluteUrlError(path, config.src);
			return buildUrlFn(path, _objectSpread2(_objectSpread2({}, config), {}, { src: normalizeSrc(config.src) }));
		};
		return [{
			provide: IMAGE_LOADER,
			useValue: loaderFn
		}];
	};
}
function throwInvalidPathError(path, exampleUrls) {
	throw new RuntimeError(2959, ngDevMode && `Image loader has detected an invalid path (\`${path}\`). To fix this, supply a path using one of the following formats: ${exampleUrls.join(" or ")}`);
}
function throwUnexpectedAbsoluteUrlError(path, url) {
	throw new RuntimeError(2959, ngDevMode && `Image loader has detected a \`<img>\` tag with an invalid \`ngSrc\` attribute: ${url}. This image loader expects \`ngSrc\` to be a relative URL - however the provided value is an absolute URL. To fix this, provide \`ngSrc\` as a path relative to the base URL configured for this loader (\`${path}\`).`);
}
function normalizeLoaderTransform(transform, separator) {
	if (typeof transform === "string") return transform;
	return Object.entries(transform).map(([key, value]) => `${key}${separator}${value}`).join(",");
}
var provideCloudflareLoader = createImageLoader(createCloudflareUrl, ngDevMode ? ["https://<ZONE>/cdn-cgi/image/<OPTIONS>/<SOURCE-IMAGE>"] : void 0);
function createCloudflareUrl(path, config) {
	var _config$loaderParams;
	let params = `format=auto`;
	if (config.width) params += `,width=${config.width}`;
	if (config.height) params += `,height=${config.height}`;
	if (config.isPlaceholder) params += `,quality=${PLACEHOLDER_QUALITY}`;
	if ((_config$loaderParams = config.loaderParams) === null || _config$loaderParams === void 0 ? void 0 : _config$loaderParams["transform"]) {
		const transformStr = normalizeLoaderTransform(config.loaderParams["transform"], "=");
		params += `,${transformStr}`;
	}
	return `${path}/cdn-cgi/image/${params}/${config.src}`;
}
var cloudinaryLoaderInfo = {
	name: "Cloudinary",
	testUrl: isCloudinaryUrl
};
var CLOUDINARY_LOADER_REGEX = /https?\:\/\/[^\/]+\.cloudinary\.com\/.+/;
function isCloudinaryUrl(url) {
	return CLOUDINARY_LOADER_REGEX.test(url);
}
var provideCloudinaryLoader = createImageLoader(createCloudinaryUrl, ngDevMode ? [
	"https://res.cloudinary.com/mysite",
	"https://mysite.cloudinary.com",
	"https://subdomain.mysite.com"
] : void 0);
function createCloudinaryUrl(path, config) {
	var _config$loaderParams2, _config$loaderParams3;
	let params = `f_auto,${config.isPlaceholder ? "q_auto:low" : "q_auto"}`;
	if (config.width) params += `,w_${config.width}`;
	if (config.height) params += `,h_${config.height}`;
	if ((_config$loaderParams2 = config.loaderParams) === null || _config$loaderParams2 === void 0 ? void 0 : _config$loaderParams2["rounded"]) params += `,r_max`;
	if ((_config$loaderParams3 = config.loaderParams) === null || _config$loaderParams3 === void 0 ? void 0 : _config$loaderParams3["transform"]) {
		const transformStr = normalizeLoaderTransform(config.loaderParams["transform"], "_");
		params += `,${transformStr}`;
	}
	return `${path}/image/upload/${params}/${config.src}`;
}
var imageKitLoaderInfo = {
	name: "ImageKit",
	testUrl: isImageKitUrl
};
var IMAGE_KIT_LOADER_REGEX = /https?\:\/\/[^\/]+\.imagekit\.io\/.+/;
function isImageKitUrl(url) {
	return IMAGE_KIT_LOADER_REGEX.test(url);
}
var provideImageKitLoader = createImageLoader(createImagekitUrl, ngDevMode ? ["https://ik.imagekit.io/mysite", "https://subdomain.mysite.com"] : void 0);
function createImagekitUrl(path, config) {
	var _config$loaderParams4;
	const { src, width } = config;
	const params = [];
	if (width) params.push(`w-${width}`);
	if (config.height) params.push(`h-${config.height}`);
	if (config.isPlaceholder) params.push(`q-${PLACEHOLDER_QUALITY}`);
	if ((_config$loaderParams4 = config.loaderParams) === null || _config$loaderParams4 === void 0 ? void 0 : _config$loaderParams4["transform"]) {
		const transformStr = normalizeLoaderTransform(config.loaderParams["transform"], "-");
		params.push(transformStr);
	}
	const urlSegments = params.length ? [
		path,
		`tr:${params.join(",")}`,
		src
	] : [path, src];
	return new URL(urlSegments.join("/")).href;
}
var imgixLoaderInfo = {
	name: "Imgix",
	testUrl: isImgixUrl
};
var IMGIX_LOADER_REGEX = /https?\:\/\/[^\/]+\.imgix\.net\/.+/;
function isImgixUrl(url) {
	return IMGIX_LOADER_REGEX.test(url);
}
var provideImgixLoader = createImageLoader(createImgixUrl, ngDevMode ? ["https://somepath.imgix.net/"] : void 0);
function createImgixUrl(path, config) {
	var _config$loaderParams5;
	const params = [];
	params.push("auto=format");
	if (config.width) params.push(`w=${config.width}`);
	if (config.height) params.push(`h=${config.height}`);
	if (config.isPlaceholder) params.push(`q=${PLACEHOLDER_QUALITY}`);
	if ((_config$loaderParams5 = config.loaderParams) === null || _config$loaderParams5 === void 0 ? void 0 : _config$loaderParams5["transform"]) {
		const transform = normalizeLoaderTransform(config.loaderParams["transform"], "=").split(",");
		params.push(...transform);
	}
	const url = new URL(`${path}/${config.src}`);
	url.search = params.join("&");
	return url.href;
}
var netlifyLoaderInfo = {
	name: "Netlify",
	testUrl: isNetlifyUrl
};
var NETLIFY_LOADER_REGEX = /https?\:\/\/[^\/]+\.netlify\.app\/.+/;
function isNetlifyUrl(url) {
	return NETLIFY_LOADER_REGEX.test(url);
}
function provideNetlifyLoader(path) {
	if (path && !isValidPath(path)) throw new RuntimeError(2959, ngDevMode && `Image loader has detected an invalid path (\`${path}\`). To fix this, supply either the full URL to the Netlify site, or leave it empty to use the current site.`);
	if (path) path = new URL(path).origin;
	const loaderFn = (config) => {
		return createNetlifyUrl(config, path);
	};
	return [{
		provide: IMAGE_LOADER,
		useValue: loaderFn
	}];
}
var validParams = /* @__PURE__ */ new Map([
	["height", "h"],
	["fit", "fit"],
	["quality", "q"],
	["q", "q"],
	["position", "position"]
]);
function createNetlifyUrl(config, path) {
	var _config$loaderParams$, _config$loaderParams6, _config$loaderParams7, _config$loaderParams8;
	const url = new URL(path !== null && path !== void 0 ? path : "https://a/");
	url.pathname = "/.netlify/images";
	if (!isAbsoluteUrl(config.src) && !config.src.startsWith("/")) config.src = "/" + config.src;
	url.searchParams.set("url", config.src);
	if (config.width) url.searchParams.set("w", config.width.toString());
	if (config.height) url.searchParams.set("h", config.height.toString());
	const configQuality = (_config$loaderParams$ = (_config$loaderParams6 = config.loaderParams) === null || _config$loaderParams6 === void 0 ? void 0 : _config$loaderParams6["quality"]) !== null && _config$loaderParams$ !== void 0 ? _config$loaderParams$ : (_config$loaderParams7 = config.loaderParams) === null || _config$loaderParams7 === void 0 ? void 0 : _config$loaderParams7["q"];
	if (config.isPlaceholder && !configQuality) url.searchParams.set("q", PLACEHOLDER_QUALITY);
	for (const [param, value] of Object.entries((_config$loaderParams8 = config.loaderParams) !== null && _config$loaderParams8 !== void 0 ? _config$loaderParams8 : {})) if (validParams.has(param)) url.searchParams.set(validParams.get(param), value.toString());
	else if (ngDevMode) console.warn(formatRuntimeError(2959, `The Netlify image loader has detected an \`<img>\` tag with the unsupported attribute "\`${param}\`".`));
	return url.hostname === "a" ? url.href.replace(url.origin, "") : url.href;
}
function imgDirectiveDetails(ngSrc, includeNgSrc = true) {
	return `The NgOptimizedImage directive ${includeNgSrc ? `(activated on an <img> element with the \`ngSrc="${ngSrc}"\`) ` : ""}has detected that`;
}
function assertDevMode(checkName) {
	if (!ngDevMode) throw new RuntimeError(2958, `Unexpected invocation of the ${checkName} in the prod mode. Please make sure that the prod mode is enabled for production builds.`);
}
var LCPImageObserver = class {
	constructor() {
		_defineProperty(this, "images", /* @__PURE__ */ new Map());
		_defineProperty(this, "window", inject(DOCUMENT).defaultView);
		_defineProperty(this, "observer", null);
		assertDevMode("LCP checker");
		if (typeof PerformanceObserver !== "undefined") this.observer = this.initPerformanceObserver();
	}
	initPerformanceObserver() {
		const observer = new PerformanceObserver((entryList) => {
			var _lcpElement$element$s, _lcpElement$element;
			const entries = entryList.getEntries();
			if (entries.length === 0) return;
			const imgSrc = (_lcpElement$element$s = (_lcpElement$element = entries[entries.length - 1].element) === null || _lcpElement$element === void 0 ? void 0 : _lcpElement$element.src) !== null && _lcpElement$element$s !== void 0 ? _lcpElement$element$s : "";
			if (imgSrc.startsWith("data:") || imgSrc.startsWith("blob:")) return;
			const img = this.images.get(imgSrc);
			if (!img) return;
			if (!img.priority && !img.alreadyWarnedPriority) {
				img.alreadyWarnedPriority = true;
				logMissingPriorityError(imgSrc);
			}
			if (img.modified && !img.alreadyWarnedModified) {
				img.alreadyWarnedModified = true;
				logModifiedWarning(imgSrc);
			}
		});
		observer.observe({
			type: "largest-contentful-paint",
			buffered: true
		});
		return observer;
	}
	registerImage(rewrittenSrc, isPriority) {
		if (!this.observer) return;
		const url = getUrl(rewrittenSrc, this.window).href;
		const existingState = this.images.get(url);
		if (existingState) {
			existingState.priority = existingState.priority || isPriority;
			existingState.count++;
		} else {
			const newObservedImageState = {
				priority: isPriority,
				modified: false,
				alreadyWarnedModified: false,
				alreadyWarnedPriority: false,
				count: 1
			};
			this.images.set(url, newObservedImageState);
		}
	}
	unregisterImage(rewrittenSrc) {
		if (!this.observer) return;
		const url = getUrl(rewrittenSrc, this.window).href;
		const existingState = this.images.get(url);
		if (existingState) {
			existingState.count--;
			if (existingState.count <= 0) this.images.delete(url);
		}
	}
	updateImage(originalSrc, newSrc) {
		if (!this.observer) return;
		const originalUrl = getUrl(originalSrc, this.window).href;
		const newUrl = getUrl(newSrc, this.window).href;
		if (originalUrl === newUrl) return;
		const originalState = this.images.get(originalUrl);
		if (!originalState) return;
		originalState.count--;
		if (originalState.count <= 0) this.images.delete(originalUrl);
		const newState = this.images.get(newUrl);
		if (newState) {
			newState.priority = newState.priority || originalState.priority;
			newState.modified = true;
			newState.alreadyWarnedPriority = newState.alreadyWarnedPriority || originalState.alreadyWarnedPriority;
			newState.alreadyWarnedModified = newState.alreadyWarnedModified || originalState.alreadyWarnedModified;
			newState.count++;
		} else this.images.set(newUrl, {
			priority: originalState.priority,
			modified: true,
			alreadyWarnedModified: originalState.alreadyWarnedModified,
			alreadyWarnedPriority: originalState.alreadyWarnedPriority,
			count: 1
		});
	}
	ngOnDestroy() {
		if (!this.observer) return;
		this.observer.disconnect();
		this.images.clear();
	}
};
_LCPImageObserver = LCPImageObserver;
_defineProperty(LCPImageObserver, "ɵfac", function LCPImageObserver_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _LCPImageObserver)();
});
_defineProperty(LCPImageObserver, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _LCPImageObserver,
	factory: _LCPImageObserver.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LCPImageObserver, [{ type: Service }], () => [], null);
})();
function logMissingPriorityError(ngSrc) {
	const directiveDetails = imgDirectiveDetails(ngSrc);
	console.error(formatRuntimeError(2955, `${directiveDetails} this image is the Largest Contentful Paint (LCP) element but was not marked "priority". This image should be marked "priority" in order to prioritize its loading. To fix this, add the "priority" attribute.`));
}
function logModifiedWarning(ngSrc) {
	const directiveDetails = imgDirectiveDetails(ngSrc);
	console.warn(formatRuntimeError(2964, `${directiveDetails} this image is the Largest Contentful Paint (LCP) element and has had its "ngSrc" attribute modified. This can cause slower loading performance. It is recommended not to modify the "ngSrc" property on any image which could be the LCP element.`));
}
var INTERNAL_PRECONNECT_CHECK_BLOCKLIST = /* @__PURE__ */ new Set([
	"localhost",
	"127.0.0.1",
	"0.0.0.0",
	"[::1]"
]);
var PRECONNECT_CHECK_BLOCKLIST = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "PRECONNECT_CHECK_BLOCKLIST" : "");
var PreconnectLinkChecker = class {
	constructor() {
		_defineProperty(this, "document", inject(DOCUMENT));
		_defineProperty(this, "preconnectLinks", null);
		_defineProperty(this, "alreadySeen", /* @__PURE__ */ new Set());
		_defineProperty(this, "window", this.document.defaultView);
		_defineProperty(this, "blocklist", new Set(INTERNAL_PRECONNECT_CHECK_BLOCKLIST));
		assertDevMode("preconnect link checker");
		const blocklist = inject(PRECONNECT_CHECK_BLOCKLIST, { optional: true });
		if (blocklist) this.populateBlocklist(blocklist);
	}
	populateBlocklist(origins) {
		if (Array.isArray(origins)) deepForEach(origins, (origin) => {
			this.blocklist.add(extractHostname(origin));
		});
		else this.blocklist.add(extractHostname(origins));
	}
	assertPreconnect(rewrittenSrc, originalNgSrc) {
		var _this$preconnectLinks;
		const imgUrl = getUrl(rewrittenSrc, this.window);
		if (this.blocklist.has(imgUrl.hostname) || this.alreadySeen.has(imgUrl.origin)) return;
		this.alreadySeen.add(imgUrl.origin);
		(_this$preconnectLinks = this.preconnectLinks) !== null && _this$preconnectLinks !== void 0 || (this.preconnectLinks = this.queryPreconnectLinks());
		if (!this.preconnectLinks.has(imgUrl.origin)) console.warn(formatRuntimeError(2956, `${imgDirectiveDetails(originalNgSrc)} there is no preconnect tag present for this image. Preconnecting to the origin(s) that serve priority images ensures that these images are delivered as soon as possible. To fix this, please add the following element into the <head> of the document:\n  <link rel="preconnect" href="${imgUrl.origin}">`));
	}
	queryPreconnectLinks() {
		const preconnectUrls = /* @__PURE__ */ new Set();
		const links = this.document.querySelectorAll("link[rel=preconnect]");
		for (const link of links) {
			const url = getUrl(link.href, this.window);
			preconnectUrls.add(url.origin);
		}
		return preconnectUrls;
	}
	ngOnDestroy() {
		var _this$preconnectLinks2;
		(_this$preconnectLinks2 = this.preconnectLinks) === null || _this$preconnectLinks2 === void 0 || _this$preconnectLinks2.clear();
		this.alreadySeen.clear();
	}
};
_PreconnectLinkChecker = PreconnectLinkChecker;
_defineProperty(PreconnectLinkChecker, "ɵfac", function PreconnectLinkChecker_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _PreconnectLinkChecker)();
});
_defineProperty(PreconnectLinkChecker, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _PreconnectLinkChecker,
	factory: _PreconnectLinkChecker.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PreconnectLinkChecker, [{ type: Service }], () => [], null);
})();
function deepForEach(input, fn) {
	for (let value of input) Array.isArray(value) ? deepForEach(value, fn) : fn(value);
}
var DEFAULT_PRELOADED_IMAGES_LIMIT = 5;
var PRELOADED_IMAGES = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "NG_OPTIMIZED_PRELOADED_IMAGES" : "", { factory: () => /* @__PURE__ */ new Set() });
var PreloadLinkCreator = class {
	constructor() {
		_defineProperty(this, "preloadedImages", inject(PRELOADED_IMAGES));
		_defineProperty(this, "document", inject(DOCUMENT));
		_defineProperty(this, "errorShown", false);
	}
	createPreloadLinkTag(renderer, src, srcset, sizes, crossOrigin) {
		const preloadKey = `${src}:${getCrossOriginMode(crossOrigin)}`;
		if (ngDevMode && !this.errorShown && this.preloadedImages.size >= DEFAULT_PRELOADED_IMAGES_LIMIT) {
			this.errorShown = true;
			console.warn(formatRuntimeError(2961, `The \`NgOptimizedImage\` directive has detected that more than ${DEFAULT_PRELOADED_IMAGES_LIMIT} images were marked as priority. This might negatively affect an overall performance of the page. To fix this, remove the "priority" attribute from images with less priority.`));
		}
		if (this.preloadedImages.has(preloadKey)) return;
		this.preloadedImages.add(preloadKey);
		const preload = renderer.createElement("link");
		renderer.setAttribute(preload, "as", "image");
		renderer.setAttribute(preload, "href", src);
		renderer.setAttribute(preload, "rel", "preload");
		renderer.setAttribute(preload, "fetchpriority", "high");
		if (crossOrigin != null) renderer.setAttribute(preload, "crossorigin", crossOrigin);
		if (sizes) renderer.setAttribute(preload, "imageSizes", sizes);
		if (srcset) renderer.setAttribute(preload, "imageSrcset", srcset);
		renderer.appendChild(this.document.head, preload);
	}
};
_PreloadLinkCreator = PreloadLinkCreator;
_defineProperty(PreloadLinkCreator, "ɵfac", function PreloadLinkCreator_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _PreloadLinkCreator)();
});
_defineProperty(PreloadLinkCreator, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _PreloadLinkCreator,
	factory: _PreloadLinkCreator.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PreloadLinkCreator, [{ type: Service }], null, null);
})();
function getCrossOriginMode(crossOrigin) {
	if (crossOrigin == null) return null;
	return crossOrigin.toLowerCase() === "use-credentials" ? "use-credentials" : "anonymous";
}
var BASE64_IMG_MAX_LENGTH_IN_ERROR = 50;
var VALID_WIDTH_DESCRIPTOR_SRCSET = /^((\s*\d+w\s*(,|$)){1,})$/;
var VALID_DENSITY_DESCRIPTOR_SRCSET = /^((\s*\d+(\.\d+)?x\s*(,|$)){1,})$/;
var ABSOLUTE_SRCSET_DENSITY_CAP = 3;
var RECOMMENDED_SRCSET_DENSITY_CAP = 2;
var DENSITY_SRCSET_MULTIPLIERS = [1, 2];
var VIEWPORT_BREAKPOINT_CUTOFF = 640;
var ASPECT_RATIO_TOLERANCE = .1;
var OVERSIZED_IMAGE_TOLERANCE = 1e3;
var FIXED_SRCSET_WIDTH_LIMIT = 1920;
var FIXED_SRCSET_HEIGHT_LIMIT = 1080;
var PLACEHOLDER_DIMENSION_LIMIT = 1e3;
var DATA_URL_WARN_LIMIT = 4e3;
var DATA_URL_ERROR_LIMIT = 1e4;
var BUILT_IN_LOADERS = [
	imgixLoaderInfo,
	imageKitLoaderInfo,
	cloudinaryLoaderInfo,
	netlifyLoaderInfo
];
var PRIORITY_COUNT_THRESHOLD = 10;
var IMGS_WITH_PRIORITY_ATTR_COUNT = 0;
var NgOptimizedImage = class {
	constructor() {
		_defineProperty(this, "imageLoader", inject(IMAGE_LOADER));
		_defineProperty(this, "config", processConfig(inject(IMAGE_CONFIG)));
		_defineProperty(this, "renderer", inject(Renderer2));
		_defineProperty(this, "imgElement", inject(ElementRef).nativeElement);
		_defineProperty(this, "injector", inject(Injector));
		_defineProperty(this, "destroyRef", inject(DestroyRef));
		_defineProperty(this, "lcpObserver", void 0);
		_defineProperty(this, "_renderedSrc", null);
		_defineProperty(this, "ngSrc", void 0);
		_defineProperty(this, "ngSrcset", void 0);
		_defineProperty(this, "sizes", void 0);
		_defineProperty(this, "width", void 0);
		_defineProperty(this, "height", void 0);
		_defineProperty(this, "decoding", void 0);
		_defineProperty(this, "loading", void 0);
		_defineProperty(this, "priority", false);
		_defineProperty(this, "loaderParams", void 0);
		_defineProperty(this, "disableOptimizedSrcset", false);
		_defineProperty(this, "fill", false);
		_defineProperty(this, "placeholder", void 0);
		_defineProperty(this, "placeholderConfig", void 0);
		_defineProperty(this, "src", void 0);
		_defineProperty(this, "srcset", void 0);
		if (ngDevMode) {
			this.lcpObserver = this.injector.get(LCPImageObserver);
			this.destroyRef.onDestroy(() => {
				if (!this.priority && this._renderedSrc !== null) this.lcpObserver.unregisterImage(this._renderedSrc);
			});
		}
		this.destroyRef.onDestroy(() => {
			this.renderer.removeAttribute(this.imgElement, "loading");
		});
	}
	ngOnInit() {
		performanceMarkFeature("NgOptimizedImage");
		if (ngDevMode) {
			const ngZone = this.injector.get(NgZone);
			assertNonEmptyInput(this, "ngSrc", this.ngSrc);
			assertValidNgSrcset(this, this.ngSrcset);
			assertNoConflictingSrc(this);
			if (this.ngSrcset) assertNoConflictingSrcset(this);
			assertNotBase64Image(this);
			assertNotBlobUrl(this);
			if (this.fill) {
				assertEmptyWidthAndHeight(this);
				ngZone.runOutsideAngular(() => assertNonZeroRenderedHeight(this, this.imgElement, this.renderer, this.destroyRef));
			} else {
				assertNonEmptyWidthAndHeight(this);
				if (this.height !== void 0) assertGreaterThanZero(this, this.height, "height");
				if (this.width !== void 0) assertGreaterThanZero(this, this.width, "width");
				ngZone.runOutsideAngular(() => assertNoImageDistortion(this, this.imgElement, this.renderer, this.destroyRef));
			}
			assertValidLoadingInput(this);
			assertValidDecodingInput(this);
			if (!this.ngSrcset) assertNoComplexSizes(this);
			assertValidPlaceholder(this, this.imageLoader);
			assertNotMissingBuiltInLoader(this.ngSrc, this.imageLoader);
			assertNoNgSrcsetWithoutLoader(this, this.imageLoader);
			assertNoLoaderParamsWithoutLoader(this, this.imageLoader);
			ngZone.runOutsideAngular(() => {
				this.lcpObserver.registerImage(this.getRewrittenSrc(), this.priority);
			});
			if (this.priority) {
				this.injector.get(PreconnectLinkChecker).assertPreconnect(this.getRewrittenSrc(), this.ngSrc);
				assetPriorityCountBelowThreshold(this.injector.get(ApplicationRef));
			}
		}
		if (this.placeholder) this.removePlaceholderOnLoad(this.imgElement);
		this.setHostAttributes();
	}
	setHostAttributes() {
		if (this.fill) this.sizes || (this.sizes = "100vw");
		else {
			this.setHostAttribute("width", this.width.toString());
			this.setHostAttribute("height", this.height.toString());
		}
		this.setHostAttribute("loading", this.getLoadingBehavior());
		this.setHostAttribute("fetchpriority", this.getFetchPriority());
		this.setHostAttribute("decoding", this.getDecoding());
		this.setHostAttribute("ng-img", "true");
		this.updateSrcAndSrcset();
		if (this.sizes) if (this.getLoadingBehavior() === "lazy") this.setHostAttribute("sizes", "auto, " + this.sizes);
		else this.setHostAttribute("sizes", this.sizes);
		else if (this.ngSrcset && VALID_WIDTH_DESCRIPTOR_SRCSET.test(this.ngSrcset) && this.getLoadingBehavior() === "lazy") this.setHostAttribute("sizes", "auto, 100vw");
	}
	ngOnChanges(changes) {
		var _changes$placeholder;
		if (ngDevMode) assertNoPostInitInputChange(this, changes, [
			"ngSrcset",
			"width",
			"height",
			"priority",
			"fill",
			"loading",
			"sizes",
			"loaderParams",
			"disableOptimizedSrcset"
		]);
		if (changes["ngSrc"] && !changes["ngSrc"].isFirstChange()) {
			const oldSrc = this._renderedSrc;
			this.updateSrcAndSrcset(true);
			if (ngDevMode) {
				const newSrc = this._renderedSrc;
				if (oldSrc && newSrc && oldSrc !== newSrc) this.injector.get(NgZone).runOutsideAngular(() => {
					this.lcpObserver.updateImage(oldSrc, newSrc);
				});
			}
		}
		if (ngDevMode && ((_changes$placeholder = changes["placeholder"]) === null || _changes$placeholder === void 0 ? void 0 : _changes$placeholder.currentValue) && true) assertPlaceholderDimensions(this, this.imgElement);
	}
	getAspectRatio() {
		if (this.width && this.height && this.height !== 0) return this.width / this.height;
		return null;
	}
	callImageLoader(configWithoutCustomParams) {
		let augmentedConfig = configWithoutCustomParams;
		if (this.loaderParams) augmentedConfig.loaderParams = this.loaderParams;
		const ratio = this.getAspectRatio();
		if (ratio !== null && augmentedConfig.width) augmentedConfig.height = Math.round(augmentedConfig.width / ratio);
		return this.imageLoader(augmentedConfig);
	}
	getLoadingBehavior() {
		if (!this.priority && this.loading !== void 0) return this.loading;
		return this.priority ? "eager" : "lazy";
	}
	getFetchPriority() {
		return this.priority ? "high" : "auto";
	}
	getDecoding() {
		var _this$decoding;
		if (this.priority) return "sync";
		return (_this$decoding = this.decoding) !== null && _this$decoding !== void 0 ? _this$decoding : "auto";
	}
	getRewrittenSrc() {
		if (!this._renderedSrc) {
			const imgConfig = { src: this.ngSrc };
			this._renderedSrc = this.callImageLoader(imgConfig);
		}
		return this._renderedSrc;
	}
	getRewrittenSrcset() {
		const widthSrcSet = VALID_WIDTH_DESCRIPTOR_SRCSET.test(this.ngSrcset);
		return this.ngSrcset.split(",").filter((src) => src !== "").map((srcStr) => {
			srcStr = srcStr.trim();
			const width = widthSrcSet ? parseFloat(srcStr) : parseFloat(srcStr) * this.width;
			return `${this.callImageLoader({
				src: this.ngSrc,
				width
			})} ${srcStr}`;
		}).join(", ");
	}
	getAutomaticSrcset() {
		if (this.sizes) return this.getResponsiveSrcset();
		else return this.getFixedSrcset();
	}
	getResponsiveSrcset() {
		var _this$sizes;
		const { breakpoints } = this.config;
		let filteredBreakpoints = breakpoints;
		if (((_this$sizes = this.sizes) === null || _this$sizes === void 0 ? void 0 : _this$sizes.trim()) === "100vw") filteredBreakpoints = breakpoints.filter((bp) => bp >= VIEWPORT_BREAKPOINT_CUTOFF);
		return filteredBreakpoints.map((bp) => `${this.callImageLoader({
			src: this.ngSrc,
			width: bp
		})} ${bp}w`).join(", ");
	}
	updateSrcAndSrcset(forceSrcRecalc = false) {
		if (forceSrcRecalc) this._renderedSrc = null;
		const rewrittenSrc = this.getRewrittenSrc();
		this.setHostAttribute("src", rewrittenSrc);
		let rewrittenSrcset = void 0;
		if (this.ngSrcset) rewrittenSrcset = this.getRewrittenSrcset();
		else if (this.shouldGenerateAutomaticSrcset()) rewrittenSrcset = this.getAutomaticSrcset();
		if (rewrittenSrcset) this.setHostAttribute("srcset", rewrittenSrcset);
		return rewrittenSrcset;
	}
	getFixedSrcset() {
		return DENSITY_SRCSET_MULTIPLIERS.map((multiplier) => `${this.callImageLoader({
			src: this.ngSrc,
			width: this.width * multiplier
		})} ${multiplier}x`).join(", ");
	}
	shouldGenerateAutomaticSrcset() {
		let oversizedImage = false;
		if (!this.sizes) oversizedImage = this.width > FIXED_SRCSET_WIDTH_LIMIT || this.height > FIXED_SRCSET_HEIGHT_LIMIT;
		return !this.disableOptimizedSrcset && !this.srcset && this.imageLoader !== noopImageLoader && !oversizedImage;
	}
	generatePlaceholder(placeholderInput) {
		const { placeholderResolution } = this.config;
		if (placeholderInput === true) return `url("${escapeCssUrl(this.callImageLoader({
			src: this.ngSrc,
			width: placeholderResolution,
			isPlaceholder: true
		}))}")`;
		else if (typeof placeholderInput === "string") return `url("${escapeCssUrl(placeholderInput)}")`;
		return null;
	}
	shouldBlurPlaceholder(placeholderConfig) {
		if (!placeholderConfig || !placeholderConfig.hasOwnProperty("blur")) return true;
		return Boolean(placeholderConfig.blur);
	}
	removePlaceholderOnLoad(img) {
		const callback = () => {
			const changeDetectorRef = this.injector.get(ChangeDetectorRef);
			removeLoadListenerFn();
			removeErrorListenerFn();
			this.placeholder = false;
			changeDetectorRef.markForCheck();
		};
		const removeLoadListenerFn = this.renderer.listen(img, "load", callback);
		const removeErrorListenerFn = this.renderer.listen(img, "error", callback);
		this.destroyRef.onDestroy(() => {
			removeLoadListenerFn();
			removeErrorListenerFn();
		});
		callOnLoadIfImageIsLoaded(img, callback);
	}
	setHostAttribute(name, value) {
		this.renderer.setAttribute(this.imgElement, name, value);
	}
};
_NgOptimizedImage = NgOptimizedImage;
_defineProperty(NgOptimizedImage, "ɵfac", function NgOptimizedImage_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NgOptimizedImage)();
});
_defineProperty(NgOptimizedImage, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _NgOptimizedImage,
	selectors: [[
		"img",
		"ngSrc",
		""
	]],
	hostVars: 18,
	hostBindings: function NgOptimizedImage_HostBindings(rf, ctx) {
		if (rf & 2) ɵɵstyleProp("position", ctx.fill ? "absolute" : null)("width", ctx.fill ? "100%" : null)("height", ctx.fill ? "100%" : null)("inset", ctx.fill ? "0" : null)("background-size", ctx.placeholder ? "cover" : null)("background-position", ctx.placeholder ? "50% 50%" : null)("background-repeat", ctx.placeholder ? "no-repeat" : null)("background-image", ctx.placeholder ? ctx.generatePlaceholder(ctx.placeholder) : null)("filter", ctx.placeholder && ctx.shouldBlurPlaceholder(ctx.placeholderConfig) ? "blur(15px)" : null);
	},
	inputs: {
		ngSrc: [
			2,
			"ngSrc",
			"ngSrc",
			unwrapSafeUrl
		],
		ngSrcset: "ngSrcset",
		sizes: "sizes",
		width: [
			2,
			"width",
			"width",
			numberAttribute
		],
		height: [
			2,
			"height",
			"height",
			numberAttribute
		],
		decoding: "decoding",
		loading: "loading",
		priority: [
			2,
			"priority",
			"priority",
			booleanAttribute
		],
		loaderParams: "loaderParams",
		disableOptimizedSrcset: [
			2,
			"disableOptimizedSrcset",
			"disableOptimizedSrcset",
			booleanAttribute
		],
		fill: [
			2,
			"fill",
			"fill",
			booleanAttribute
		],
		placeholder: [
			2,
			"placeholder",
			"placeholder",
			booleanOrUrlAttribute
		],
		placeholderConfig: "placeholderConfig",
		src: "src",
		srcset: "srcset"
	},
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgOptimizedImage, [{
		type: Directive,
		args: [{
			selector: "img[ngSrc]",
			host: {
				"[style.position]": "fill ? \"absolute\" : null",
				"[style.width]": "fill ? \"100%\" : null",
				"[style.height]": "fill ? \"100%\" : null",
				"[style.inset]": "fill ? \"0\" : null",
				"[style.background-size]": "placeholder ? \"cover\" : null",
				"[style.background-position]": "placeholder ? \"50% 50%\" : null",
				"[style.background-repeat]": "placeholder ? \"no-repeat\" : null",
				"[style.background-image]": "placeholder ? generatePlaceholder(placeholder) : null",
				"[style.filter]": "placeholder && shouldBlurPlaceholder(placeholderConfig) ? \"blur(15px)\" : null"
			}
		}]
	}], () => [], {
		ngSrc: [{
			type: Input,
			args: [{
				required: true,
				transform: unwrapSafeUrl
			}]
		}],
		ngSrcset: [{ type: Input }],
		sizes: [{ type: Input }],
		width: [{
			type: Input,
			args: [{ transform: numberAttribute }]
		}],
		height: [{
			type: Input,
			args: [{ transform: numberAttribute }]
		}],
		decoding: [{ type: Input }],
		loading: [{ type: Input }],
		priority: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		loaderParams: [{ type: Input }],
		disableOptimizedSrcset: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		fill: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		placeholder: [{
			type: Input,
			args: [{ transform: booleanOrUrlAttribute }]
		}],
		placeholderConfig: [{ type: Input }],
		src: [{ type: Input }],
		srcset: [{ type: Input }]
	});
})();
function processConfig(config) {
	let sortedBreakpoints = {};
	if (config.breakpoints) sortedBreakpoints.breakpoints = config.breakpoints.sort((a, b) => a - b);
	return Object.assign({}, IMAGE_CONFIG_DEFAULTS, config, sortedBreakpoints);
}
function assertNoConflictingSrc(dir) {
	if (dir.src) throw new RuntimeError(2950, `${imgDirectiveDetails(dir.ngSrc)} both \`src\` and \`ngSrc\` have been set. Supplying both of these attributes breaks lazy loading. The NgOptimizedImage directive sets \`src\` itself based on the value of \`ngSrc\`. To fix this, please remove the \`src\` attribute.`);
}
function assertNoConflictingSrcset(dir) {
	if (dir.srcset) throw new RuntimeError(2951, `${imgDirectiveDetails(dir.ngSrc)} both \`srcset\` and \`ngSrcset\` have been set. Supplying both of these attributes breaks lazy loading. The NgOptimizedImage directive sets \`srcset\` itself based on the value of \`ngSrcset\`. To fix this, please remove the \`srcset\` attribute.`);
}
function assertNotBase64Image(dir) {
	let ngSrc = dir.ngSrc.trim();
	if (ngSrc.startsWith("data:")) {
		if (ngSrc.length > BASE64_IMG_MAX_LENGTH_IN_ERROR) ngSrc = ngSrc.substring(0, BASE64_IMG_MAX_LENGTH_IN_ERROR) + "...";
		throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc, false)} \`ngSrc\` is a Base64-encoded string (${ngSrc}). NgOptimizedImage does not support Base64-encoded strings. To fix this, disable the NgOptimizedImage directive for this element by removing \`ngSrc\` and using a standard \`src\` attribute instead.`);
	}
}
function assertNoComplexSizes(dir) {
	let sizes = dir.sizes;
	if (sizes === null || sizes === void 0 ? void 0 : sizes.match(/((\)|,)\s|^)\d+px/)) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc, false)} \`sizes\` was set to a string including pixel values. For automatic \`srcset\` generation, \`sizes\` must only include responsive values, such as \`sizes="50vw"\` or \`sizes="(min-width: 768px) 50vw, 100vw"\`. To fix this, modify the \`sizes\` attribute, or provide your own \`ngSrcset\` value directly.`);
}
function assertValidPlaceholder(dir, imageLoader) {
	assertNoPlaceholderConfigWithoutPlaceholder(dir);
	assertNoRelativePlaceholderWithoutLoader(dir, imageLoader);
	assertNoOversizedDataUrl(dir);
}
function assertNoPlaceholderConfigWithoutPlaceholder(dir) {
	if (dir.placeholderConfig && !dir.placeholder) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc, false)} \`placeholderConfig\` options were provided for an image that does not use the \`placeholder\` attribute, and will have no effect.`);
}
function assertNoRelativePlaceholderWithoutLoader(dir, imageLoader) {
	if (dir.placeholder === true && imageLoader === noopImageLoader) throw new RuntimeError(2963, `${imgDirectiveDetails(dir.ngSrc)} the \`placeholder\` attribute is set to true but no image loader is configured (i.e. the default one is being used), which would result in the same image being used for the primary image and its placeholder. To fix this, provide a loader or remove the \`placeholder\` attribute from the image.`);
}
function assertNoOversizedDataUrl(dir) {
	if (dir.placeholder && typeof dir.placeholder === "string" && dir.placeholder.startsWith("data:")) {
		if (dir.placeholder.length > DATA_URL_ERROR_LIMIT) throw new RuntimeError(2965, `${imgDirectiveDetails(dir.ngSrc)} the \`placeholder\` attribute is set to a data URL which is longer than ${DATA_URL_ERROR_LIMIT} characters. This is strongly discouraged, as large inline placeholders directly increase the bundle size of Angular and hurt page load performance. To fix this, generate a smaller data URL placeholder.`);
		if (dir.placeholder.length > DATA_URL_WARN_LIMIT) console.warn(formatRuntimeError(2965, `${imgDirectiveDetails(dir.ngSrc)} the \`placeholder\` attribute is set to a data URL which is longer than ${DATA_URL_WARN_LIMIT} characters. This is discouraged, as large inline placeholders directly increase the bundle size of Angular and hurt page load performance. For better loading performance, generate a smaller data URL placeholder.`));
	}
}
function assertNotBlobUrl(dir) {
	const ngSrc = dir.ngSrc.trim();
	if (ngSrc.startsWith("blob:")) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} \`ngSrc\` was set to a blob URL (${ngSrc}). Blob URLs are not supported by the NgOptimizedImage directive. To fix this, disable the NgOptimizedImage directive for this element by removing \`ngSrc\` and using a regular \`src\` attribute instead.`);
}
function assertNonEmptyInput(dir, name, value) {
	const isString = typeof value === "string";
	const isEmptyString = isString && value.trim() === "";
	if (!isString || isEmptyString) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} \`${name}\` has an invalid value (\`${value}\`). To fix this, change the value to a non-empty string.`);
}
function assertValidNgSrcset(dir, value) {
	if (value == null) return;
	assertNonEmptyInput(dir, "ngSrcset", value);
	const stringVal = value;
	const isValidWidthDescriptor = VALID_WIDTH_DESCRIPTOR_SRCSET.test(stringVal);
	const isValidDensityDescriptor = VALID_DENSITY_DESCRIPTOR_SRCSET.test(stringVal);
	if (isValidDensityDescriptor) assertUnderDensityCap(dir, stringVal);
	if (!(isValidWidthDescriptor || isValidDensityDescriptor)) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} \`ngSrcset\` has an invalid value (\`${value}\`). To fix this, supply \`ngSrcset\` using a comma-separated list of one or more width descriptors (e.g. "100w, 200w") or density descriptors (e.g. "1x, 2x").`);
}
function assertUnderDensityCap(dir, value) {
	if (!value.split(",").every((num) => num === "" || parseFloat(num) <= ABSOLUTE_SRCSET_DENSITY_CAP)) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the \`ngSrcset\` contains an unsupported image density:\`${value}\`. NgOptimizedImage generally recommends a max image density of ${RECOMMENDED_SRCSET_DENSITY_CAP}x but supports image densities up to ${ABSOLUTE_SRCSET_DENSITY_CAP}x. The human eye cannot distinguish between image densities greater than ${RECOMMENDED_SRCSET_DENSITY_CAP}x - which makes them unnecessary for most use cases. Images that will be pinch-zoomed are typically the primary use case for ${ABSOLUTE_SRCSET_DENSITY_CAP}x images. Please remove the high density descriptor and try again.`);
}
function postInitInputChangeError(dir, inputName) {
	let reason;
	if (inputName === "width" || inputName === "height") reason = `Changing \`${inputName}\` may result in different attribute value applied to the underlying image element and cause layout shifts on a page.`;
	else reason = `Changing the \`${inputName}\` would have no effect on the underlying image element, because the resource loading has already occurred.`;
	return new RuntimeError(2953, `${imgDirectiveDetails(dir.ngSrc)} \`${inputName}\` was updated after initialization. The NgOptimizedImage directive will not react to this input change. ${reason} To fix this, either switch \`${inputName}\` to a static value or wrap the image element in an @if that is gated on the necessary value.`);
}
function assertNoPostInitInputChange(dir, changes, inputs) {
	inputs.forEach((input) => {
		if (changes.hasOwnProperty(input) && !changes[input].isFirstChange()) {
			if (input === "ngSrc") dir = { ngSrc: changes[input].previousValue };
			throw postInitInputChangeError(dir, input);
		}
	});
}
function assertGreaterThanZero(dir, inputValue, inputName) {
	const validNumber = typeof inputValue === "number" && inputValue > 0;
	const validString = typeof inputValue === "string" && /^\d+$/.test(inputValue.trim()) && parseInt(inputValue) > 0;
	if (!validNumber && !validString) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} \`${inputName}\` has an invalid value. To fix this, provide \`${inputName}\` as a number greater than 0.`);
}
function assertNoImageDistortion(dir, img, renderer, destroyRef) {
	const callback = () => {
		removeLoadListenerFn();
		removeErrorListenerFn();
		const computedStyle = window.getComputedStyle(img);
		let renderedWidth = parseFloat(computedStyle.getPropertyValue("width"));
		let renderedHeight = parseFloat(computedStyle.getPropertyValue("height"));
		if (computedStyle.getPropertyValue("box-sizing") === "border-box") {
			const paddingTop = computedStyle.getPropertyValue("padding-top");
			const paddingRight = computedStyle.getPropertyValue("padding-right");
			const paddingBottom = computedStyle.getPropertyValue("padding-bottom");
			const paddingLeft = computedStyle.getPropertyValue("padding-left");
			renderedWidth -= parseFloat(paddingRight) + parseFloat(paddingLeft);
			renderedHeight -= parseFloat(paddingTop) + parseFloat(paddingBottom);
		}
		const renderedAspectRatio = renderedWidth / renderedHeight;
		const nonZeroRenderedDimensions = renderedWidth !== 0 && renderedHeight !== 0;
		const intrinsicWidth = img.naturalWidth;
		const intrinsicHeight = img.naturalHeight;
		const intrinsicAspectRatio = intrinsicWidth / intrinsicHeight;
		const suppliedWidth = dir.width;
		const suppliedHeight = dir.height;
		const suppliedAspectRatio = suppliedWidth / suppliedHeight;
		const inaccurateDimensions = Math.abs(suppliedAspectRatio - intrinsicAspectRatio) > ASPECT_RATIO_TOLERANCE;
		const stylingDistortion = nonZeroRenderedDimensions && Math.abs(intrinsicAspectRatio - renderedAspectRatio) > ASPECT_RATIO_TOLERANCE;
		if (inaccurateDimensions) console.warn(formatRuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the aspect ratio of the image does not match the aspect ratio indicated by the width and height attributes. \nIntrinsic image size: ${intrinsicWidth}w x ${intrinsicHeight}h (aspect-ratio: ${round(intrinsicAspectRatio)}). \nSupplied width and height attributes: ${suppliedWidth}w x ${suppliedHeight}h (aspect-ratio: ${round(suppliedAspectRatio)}). \nTo fix this, update the width and height attributes.`));
		else if (stylingDistortion) console.warn(formatRuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the aspect ratio of the rendered image does not match the image's intrinsic aspect ratio. \nIntrinsic image size: ${intrinsicWidth}w x ${intrinsicHeight}h (aspect-ratio: ${round(intrinsicAspectRatio)}). \nRendered image size: ${renderedWidth}w x ${renderedHeight}h (aspect-ratio: ${round(renderedAspectRatio)}). \nThis issue can occur if "width" and "height" attributes are added to an image without updating the corresponding image styling. To fix this, adjust image styling. In most cases, adding "height: auto" or "width: auto" to the image styling will fix this issue.`));
		else if (!dir.ngSrcset && nonZeroRenderedDimensions) {
			const recommendedWidth = RECOMMENDED_SRCSET_DENSITY_CAP * renderedWidth;
			const recommendedHeight = RECOMMENDED_SRCSET_DENSITY_CAP * renderedHeight;
			const oversizedWidth = intrinsicWidth - recommendedWidth >= OVERSIZED_IMAGE_TOLERANCE;
			const oversizedHeight = intrinsicHeight - recommendedHeight >= OVERSIZED_IMAGE_TOLERANCE;
			if (oversizedWidth || oversizedHeight) console.warn(formatRuntimeError(2960, `${imgDirectiveDetails(dir.ngSrc)} the intrinsic image is significantly larger than necessary. \nRendered image size: ${renderedWidth}w x ${renderedHeight}h. \nIntrinsic image size: ${intrinsicWidth}w x ${intrinsicHeight}h. \nRecommended intrinsic image size: ${recommendedWidth}w x ${recommendedHeight}h. \nNote: Recommended intrinsic image size is calculated assuming a maximum DPR of ${RECOMMENDED_SRCSET_DENSITY_CAP}. To improve loading time, resize the image or consider using the "ngSrcset" and "sizes" attributes.`));
		}
	};
	const removeLoadListenerFn = renderer.listen(img, "load", callback);
	const removeErrorListenerFn = renderer.listen(img, "error", () => {
		removeLoadListenerFn();
		removeErrorListenerFn();
	});
	destroyRef.onDestroy(() => {
		removeLoadListenerFn();
		removeErrorListenerFn();
	});
	callOnLoadIfImageIsLoaded(img, callback);
}
function assertNonEmptyWidthAndHeight(dir) {
	let missingAttributes = [];
	if (dir.width === void 0) missingAttributes.push("width");
	if (dir.height === void 0) missingAttributes.push("height");
	if (missingAttributes.length > 0) throw new RuntimeError(2954, `${imgDirectiveDetails(dir.ngSrc)} these required attributes are missing: ${missingAttributes.map((attr) => `"${attr}"`).join(", ")}. Including "width" and "height" attributes will prevent image-related layout shifts. To fix this, include "width" and "height" attributes on the image tag or turn on "fill" mode with the \`fill\` attribute.`);
}
function assertEmptyWidthAndHeight(dir) {
	if (dir.width || dir.height) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the attributes \`height\` and/or \`width\` are present along with the \`fill\` attribute. Because \`fill\` mode causes an image to fill its containing element, the size attributes have no effect and should be removed.`);
}
function assertNonZeroRenderedHeight(dir, img, renderer, destroyRef) {
	const callback = () => {
		removeLoadListenerFn();
		removeErrorListenerFn();
		const renderedHeight = img.clientHeight;
		if (dir.fill && renderedHeight === 0) console.warn(formatRuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the height of the fill-mode image is zero. This is likely because the containing element does not have the CSS 'position' property set to one of the following: "relative", "fixed", or "absolute". To fix this problem, make sure the container element has the CSS 'position' property defined and the height of the element is not zero.`));
	};
	const removeLoadListenerFn = renderer.listen(img, "load", callback);
	const removeErrorListenerFn = renderer.listen(img, "error", () => {
		removeLoadListenerFn();
		removeErrorListenerFn();
	});
	destroyRef.onDestroy(() => {
		removeLoadListenerFn();
		removeErrorListenerFn();
	});
	callOnLoadIfImageIsLoaded(img, callback);
}
function assertValidLoadingInput(dir) {
	if (dir.loading && dir.priority) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the \`loading\` attribute was used on an image that was marked "priority". Setting \`loading\` on priority images is not allowed because these images will always be eagerly loaded. To fix this, remove the “loading” attribute from the priority image.`);
	if (typeof dir.loading === "string" && ![
		"auto",
		"eager",
		"lazy"
	].includes(dir.loading)) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the \`loading\` attribute has an invalid value (\`${dir.loading}\`). To fix this, provide a valid value ("lazy", "eager", or "auto").`);
}
function assertValidDecodingInput(dir) {
	if (typeof dir.decoding === "string" && ![
		"sync",
		"async",
		"auto"
	].includes(dir.decoding)) throw new RuntimeError(2952, `${imgDirectiveDetails(dir.ngSrc)} the \`decoding\` attribute has an invalid value (\`${dir.decoding}\`). To fix this, provide a valid value ("sync", "async", or "auto").`);
}
function assertNotMissingBuiltInLoader(ngSrc, imageLoader) {
	if (imageLoader === noopImageLoader) {
		let builtInLoaderName = "";
		for (const loader of BUILT_IN_LOADERS) if (loader.testUrl(ngSrc)) {
			builtInLoaderName = loader.name;
			break;
		}
		if (builtInLoaderName) console.warn(formatRuntimeError(2962, `NgOptimizedImage: It looks like your images may be hosted on the ${builtInLoaderName} CDN, but your app is not using Angular's built-in loader for that CDN. We recommend switching to use the built-in by calling \`provide${builtInLoaderName}Loader()\` in your \`providers\` and passing it your instance's base URL. If you don't want to use the built-in loader, define a custom loader function using IMAGE_LOADER to silence this warning.`));
	}
}
function assertNoNgSrcsetWithoutLoader(dir, imageLoader) {
	if (dir.ngSrcset && imageLoader === noopImageLoader) console.warn(formatRuntimeError(2963, `${imgDirectiveDetails(dir.ngSrc)} the \`ngSrcset\` attribute is present but no image loader is configured (i.e. the default one is being used), which would result in the same image being used for all configured sizes. To fix this, provide a loader or remove the \`ngSrcset\` attribute from the image.`));
}
function assertNoLoaderParamsWithoutLoader(dir, imageLoader) {
	if (dir.loaderParams && imageLoader === noopImageLoader) console.warn(formatRuntimeError(2963, `${imgDirectiveDetails(dir.ngSrc)} the \`loaderParams\` attribute is present but no image loader is configured (i.e. the default one is being used), which means that the loaderParams data will not be consumed and will not affect the URL. To fix this, provide a custom loader or remove the \`loaderParams\` attribute from the image.`));
}
function assetPriorityCountBelowThreshold(_x) {
	return _assetPriorityCountBelowThreshold.apply(this, arguments);
}
function _assetPriorityCountBelowThreshold() {
	_assetPriorityCountBelowThreshold = _asyncToGenerator(function* (appRef) {
		if (IMGS_WITH_PRIORITY_ATTR_COUNT === 0) {
			IMGS_WITH_PRIORITY_ATTR_COUNT++;
			yield appRef.whenStable();
			if (IMGS_WITH_PRIORITY_ATTR_COUNT > PRIORITY_COUNT_THRESHOLD) console.warn(formatRuntimeError(2966, `NgOptimizedImage: The "priority" attribute is set to true more than ${PRIORITY_COUNT_THRESHOLD} times (${IMGS_WITH_PRIORITY_ATTR_COUNT} times). Marking too many images as "high" priority can hurt your application's LCP (https://web.dev/lcp). "Priority" should only be set on the image expected to be the page's LCP element.`));
		} else IMGS_WITH_PRIORITY_ATTR_COUNT++;
	});
	return _assetPriorityCountBelowThreshold.apply(this, arguments);
}
function assertPlaceholderDimensions(dir, imgElement) {
	const computedStyle = window.getComputedStyle(imgElement);
	let renderedWidth = parseFloat(computedStyle.getPropertyValue("width"));
	let renderedHeight = parseFloat(computedStyle.getPropertyValue("height"));
	if (renderedWidth > PLACEHOLDER_DIMENSION_LIMIT || renderedHeight > PLACEHOLDER_DIMENSION_LIMIT) console.warn(formatRuntimeError(2967, `${imgDirectiveDetails(dir.ngSrc)} it uses a placeholder image, but at least one of the dimensions attribute (height or width) exceeds the limit of ${PLACEHOLDER_DIMENSION_LIMIT}px. To fix this, use a smaller image as a placeholder.`));
}
function callOnLoadIfImageIsLoaded(img, callback) {
	if (img.complete && img.naturalWidth) callback();
}
function round(input) {
	return Number.isInteger(input) ? input : input.toFixed(2);
}
function unwrapSafeUrl(value) {
	if (typeof value === "string") return value;
	return unwrapSafeValue(value);
}
function booleanOrUrlAttribute(value) {
	if (typeof value === "string" && value !== "true" && value !== "false" && value !== "") return value;
	return booleanAttribute(value);
}
//#endregion
export { Plural as $, I18nPluralPipe as A, APP_BASE_HREF as At, NgIfContext as B, DATE_PIPE_DEFAULT_OPTIONS as C, getLocaleMonthNames as Ct, FormStyle as D, getLocaleTimeFormat as Dt, DecimalPipe as E, getLocalePluralCase as Et, NgClass as F, TrailingSlashPathLocationStrategy as Ft, NgStyle as G, NgLocalization as H, NgComponentOutlet as I, normalizeQueryParams as It, NgSwitchDefault as J, NgSwitch as K, NgForOf as L, JsonPipe as M, LocationStrategy as Mt, KeyValuePipe as N, NoTrailingSlashPathLocationStrategy as Nt, FormatWidth as O, getLocaleWeekEndRange as Ot, LowerCasePipe as P, PathLocationStrategy as Pt, PercentPipe as Q, NgForOfContext as R, CurrencyPipe as S, getLocaleId as St, DatePipe as T, getLocaleNumberSymbol as Tt, NgPlural as U, NgLocaleLocalization as V, NgPluralCase as W, NumberFormatStyle as X, NgTemplateOutlet as Y, NumberSymbol as Z, registerLocaleData as _, getLocaleDirection as _t, PLATFORM_BROWSER_ID as a, formatCurrency as at, AsyncPipe as b, getLocaleExtraDayPeriods as bt, VERSION as c, formatPercent as ct, isPlatformServer as d, getLocaleCurrencyName as dt, SlicePipe as et, provideCloudflareLoader as f, getLocaleCurrencySymbol as ft, provideNetlifyLoader as g, getLocaleDayPeriods as gt, provideImgixLoader as h, getLocaleDayNames as ht, NullViewportScroller as i, WeekDay as it, I18nSelectPipe as j, Location as jt, HashLocationStrategy as k, getNumberOfCurrencyDigits as kt, ViewportScroller as l, getCurrencySymbol as lt, provideImageKitLoader as m, getLocaleDateTimeFormat as mt, NavigationAdapterForLocation as n, TranslationWidth as nt, PLATFORM_SERVER_ID as o, formatDate as ot, provideCloudinaryLoader as p, getLocaleDateFormat as pt, NgSwitchCase as q, NgOptimizedImage as r, UpperCasePipe as rt, PRECONNECT_CHECK_BLOCKLIST as s, formatNumber as st, IMAGE_LOADER as t, TitleCasePipe as tt, isPlatformBrowser as u, getLocaleCurrencyCode as ut, PRECOMMIT_HANDLER_SUPPORTED as v, getLocaleEraNames as vt, DATE_PIPE_DEFAULT_TIMEZONE as w, getLocaleNumberFormat as wt, CommonModule as x, getLocaleFirstDayOfWeek as xt, PlatformNavigation as y, getLocaleExtraDayPeriodRules as yt, NgIf as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLVdZNGpTQy1rLmpzIiwibmFtZXMiOlsiTG9jYXRpb25TdHJhdGVneSIsImkwLsm1c2V0Q2xhc3NNZXRhZGF0YSIsIlBhdGhMb2NhdGlvblN0cmF0ZWd5IiwiaTAuybXJtWluamVjdCIsImkwLsm1ybVnZXRJbmhlcml0ZWRGYWN0b3J5IiwiTm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3kiLCJUcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3kiLCJMb2NhdGlvbiIsIl9faW5qZWN0IiwiSGFzaExvY2F0aW9uU3RyYXRlZ3kiLCJpMC7Jtcm1aW5qZWN0IiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiX2ZpbmRMb2NhbGVEYXRhIiwiX0xvY2FsZURhdGFJbmRleCIsIl9nZXRMb2NhbGVDdXJyZW5jeUNvZGUiLCJfZ2V0TG9jYWxlUGx1cmFsQ2FzZSIsIl9SdW50aW1lRXJyb3IiLCJfZm9ybWF0UnVudGltZUVycm9yIiwiTmdMb2NhbGl6YXRpb24iLCJOZ0xvY2FsZUxvY2FsaXphdGlvbiIsIl9zdHJpbmdpZnkiLCJOZ0NsYXNzIiwiaTAuybXJtWRpcmVjdGl2ZUluamVjdCIsImkwLkVsZW1lbnRSZWYiLCJpMC5SZW5kZXJlcjIiLCJOZ0NvbXBvbmVudE91dGxldCIsImkwLlZpZXdDb250YWluZXJSZWYiLCJpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlIiwiTmdNb2R1bGVSZWYiLCJOZ0Zvck9mIiwiaTAuVGVtcGxhdGVSZWYiLCJpMC5JdGVyYWJsZURpZmZlcnMiLCJOZ0lmIiwiTmdTd2l0Y2giLCJOZ1N3aXRjaENhc2UiLCJOZ1N3aXRjaERlZmF1bHQiLCJOZ1BsdXJhbCIsIk5nUGx1cmFsQ2FzZSIsImkwLsm1ybVpbmplY3RBdHRyaWJ1dGUiLCJOZ1N0eWxlIiwiaTAuS2V5VmFsdWVEaWZmZXJzIiwiTmdUZW1wbGF0ZU91dGxldCIsIl9JTlRFUk5BTF9BUFBMSUNBVElPTl9FUlJPUl9IQU5ETEVSIiwiX2lzUHJvbWlzZSIsIl9pc1N1YnNjcmliYWJsZSIsIkFzeW5jUGlwZSIsImkwLkNoYW5nZURldGVjdG9yUmVmIiwiTG93ZXJDYXNlUGlwZSIsIlRpdGxlQ2FzZVBpcGUiLCJVcHBlckNhc2VQaXBlIiwiRGF0ZVBpcGUiLCJJMThuUGx1cmFsUGlwZSIsIkkxOG5TZWxlY3RQaXBlIiwiSnNvblBpcGUiLCJLZXlWYWx1ZVBpcGUiLCJEZWNpbWFsUGlwZSIsIlBlcmNlbnRQaXBlIiwiQ3VycmVuY3lQaXBlIiwiU2xpY2VQaXBlIiwiQ29tbW9uTW9kdWxlIiwiUGxhdGZvcm1OYXZpZ2F0aW9uIiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiTmF2aWdhdGlvbkFkYXB0ZXJGb3JMb2NhdGlvbiIsImkwLsm1c2V0Q2xhc3NNZXRhZGF0YSIsIl9yZWdpc3RlckxvY2FsZURhdGEiLCJWaWV3cG9ydFNjcm9sbGVyIiwiX2Zvcm1hdFJ1bnRpbWVFcnJvciIsIl9SdW50aW1lRXJyb3IiLCJMQ1BJbWFnZU9ic2VydmVyIiwiUHJlY29ubmVjdExpbmtDaGVja2VyIiwiUHJlbG9hZExpbmtDcmVhdG9yIiwiX0lNQUdFX0NPTkZJRyIsIk5nT3B0aW1pemVkSW1hZ2UiLCJpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlIiwiX0lNQUdFX0NPTkZJR19ERUZBVUxUUyIsIl91bndyYXBTYWZlVmFsdWUiXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvY29tbW9uL2Zlc20yMDIyL19sb2NhdGlvbi1jaHVuay5tanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvY29tbW9uL2Zlc20yMDIyL19jb21tb25fbW9kdWxlLWNodW5rLm1qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AYW5ndWxhci9jb21tb24vZmVzbTIwMjIvX3BsYXRmb3JtX25hdmlnYXRpb24tY2h1bmsubWpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0Bhbmd1bGFyL2NvbW1vbi9mZXNtMjAyMi9jb21tb24ubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2UgQW5ndWxhciB2MjIuMS4yXG4gKiAoYykgMjAxMC0yMDI2IEdvb2dsZSBMTEMuIGh0dHBzOi8vYW5ndWxhci5kZXYvXG4gKiBMaWNlbnNlOiBNSVRcbiAqL1xuXG5pbXBvcnQgKiBhcyBpMCBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEluamVjdGlvblRva2VuLCBpbmplY3QsIERPQ1VNRU5ULCBJbmplY3RhYmxlLCBPcHRpb25hbCwgSW5qZWN0LCDJtcm1aW5qZWN0IGFzIF9faW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBQbGF0Zm9ybUxvY2F0aW9uIH0gZnJvbSAnLi9fcGxhdGZvcm1fbG9jYXRpb24tY2h1bmsubWpzJztcbmZ1bmN0aW9uIGpvaW5XaXRoU2xhc2goc3RhcnQsIGVuZCkge1xuICBpZiAoIXN0YXJ0KSByZXR1cm4gZW5kO1xuICBpZiAoIWVuZCkgcmV0dXJuIHN0YXJ0O1xuICBpZiAoc3RhcnQuZW5kc1dpdGgoJy8nKSkge1xuICAgIHJldHVybiBlbmQuc3RhcnRzV2l0aCgnLycpID8gc3RhcnQgKyBlbmQuc2xpY2UoMSkgOiBzdGFydCArIGVuZDtcbiAgfVxuICByZXR1cm4gZW5kLnN0YXJ0c1dpdGgoJy8nKSA/IHN0YXJ0ICsgZW5kIDogYCR7c3RhcnR9LyR7ZW5kfWA7XG59XG5mdW5jdGlvbiBzdHJpcFRyYWlsaW5nU2xhc2godXJsKSB7XG4gIGNvbnN0IHBhdGhFbmRJZHggPSB1cmwuc2VhcmNoKC8jfFxcP3wkLyk7XG4gIHJldHVybiB1cmxbcGF0aEVuZElkeCAtIDFdID09PSAnLycgPyB1cmwuc2xpY2UoMCwgcGF0aEVuZElkeCAtIDEpICsgdXJsLnNsaWNlKHBhdGhFbmRJZHgpIDogdXJsO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplUXVlcnlQYXJhbXMocGFyYW1zKSB7XG4gIHJldHVybiBwYXJhbXMgJiYgcGFyYW1zWzBdICE9PSAnPycgPyBgPyR7cGFyYW1zfWAgOiBwYXJhbXM7XG59XG5jbGFzcyBMb2NhdGlvblN0cmF0ZWd5IHtcbiAgaGlzdG9yeUdvKHJlbGF0aXZlUG9zaXRpb24pIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IobmdEZXZNb2RlID8gJ05vdCBpbXBsZW1lbnRlZCcgOiAnJyk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTG9jYXRpb25TdHJhdGVneV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTG9jYXRpb25TdHJhdGVneSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogTG9jYXRpb25TdHJhdGVneSxcbiAgICBmYWN0b3J5OiAoKSA9PiAoKCkgPT4gaW5qZWN0KFBhdGhMb2NhdGlvblN0cmF0ZWd5KSkoKSxcbiAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShMb2NhdGlvblN0cmF0ZWd5LCBbe1xuICAgIHR5cGU6IEluamVjdGFibGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVkSW46ICdyb290JyxcbiAgICAgIHVzZUZhY3Rvcnk6ICgpID0+IGluamVjdChQYXRoTG9jYXRpb25TdHJhdGVneSlcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY29uc3QgQVBQX0JBU0VfSFJFRiA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnYXBwQmFzZUhyZWYnIDogJycpO1xuY2xhc3MgUGF0aExvY2F0aW9uU3RyYXRlZ3kgZXh0ZW5kcyBMb2NhdGlvblN0cmF0ZWd5IHtcbiAgX3BsYXRmb3JtTG9jYXRpb247XG4gIF9iYXNlSHJlZjtcbiAgX3JlbW92ZUxpc3RlbmVyRm5zID0gW107XG4gIGNvbnN0cnVjdG9yKF9wbGF0Zm9ybUxvY2F0aW9uLCBocmVmKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uID0gX3BsYXRmb3JtTG9jYXRpb247XG4gICAgdGhpcy5fYmFzZUhyZWYgPSBocmVmID8/IHRoaXMuX3BsYXRmb3JtTG9jYXRpb24uZ2V0QmFzZUhyZWZGcm9tRE9NKCkgPz8gaW5qZWN0KERPQ1VNRU5UKS5sb2NhdGlvbj8ub3JpZ2luID8/ICcnO1xuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIHdoaWxlICh0aGlzLl9yZW1vdmVMaXN0ZW5lckZucy5sZW5ndGgpIHtcbiAgICAgIHRoaXMuX3JlbW92ZUxpc3RlbmVyRm5zLnBvcCgpKCk7XG4gICAgfVxuICB9XG4gIG9uUG9wU3RhdGUoZm4pIHtcbiAgICB0aGlzLl9yZW1vdmVMaXN0ZW5lckZucy5wdXNoKHRoaXMuX3BsYXRmb3JtTG9jYXRpb24ub25Qb3BTdGF0ZShmbiksIHRoaXMuX3BsYXRmb3JtTG9jYXRpb24ub25IYXNoQ2hhbmdlKGZuKSk7XG4gIH1cbiAgZ2V0QmFzZUhyZWYoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Jhc2VIcmVmO1xuICB9XG4gIHByZXBhcmVFeHRlcm5hbFVybChpbnRlcm5hbCkge1xuICAgIHJldHVybiBqb2luV2l0aFNsYXNoKHRoaXMuX2Jhc2VIcmVmLCBpbnRlcm5hbCk7XG4gIH1cbiAgcGF0aChpbmNsdWRlSGFzaCA9IGZhbHNlKSB7XG4gICAgY29uc3QgcGF0aG5hbWUgPSB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLnBhdGhuYW1lICsgbm9ybWFsaXplUXVlcnlQYXJhbXModGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5zZWFyY2gpO1xuICAgIGNvbnN0IGhhc2ggPSB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLmhhc2g7XG4gICAgcmV0dXJuIGhhc2ggJiYgaW5jbHVkZUhhc2ggPyBgJHtwYXRobmFtZX0ke2hhc2h9YCA6IHBhdGhuYW1lO1xuICB9XG4gIHB1c2hTdGF0ZShzdGF0ZSwgdGl0bGUsIHVybCwgcXVlcnlQYXJhbXMpIHtcbiAgICBjb25zdCBleHRlcm5hbFVybCA9IHRoaXMucHJlcGFyZUV4dGVybmFsVXJsKHVybCArIG5vcm1hbGl6ZVF1ZXJ5UGFyYW1zKHF1ZXJ5UGFyYW1zKSk7XG4gICAgdGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5wdXNoU3RhdGUoc3RhdGUsIHRpdGxlLCBleHRlcm5hbFVybCk7XG4gIH1cbiAgcmVwbGFjZVN0YXRlKHN0YXRlLCB0aXRsZSwgdXJsLCBxdWVyeVBhcmFtcykge1xuICAgIGNvbnN0IGV4dGVybmFsVXJsID0gdGhpcy5wcmVwYXJlRXh0ZXJuYWxVcmwodXJsICsgbm9ybWFsaXplUXVlcnlQYXJhbXMocXVlcnlQYXJhbXMpKTtcbiAgICB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLnJlcGxhY2VTdGF0ZShzdGF0ZSwgdGl0bGUsIGV4dGVybmFsVXJsKTtcbiAgfVxuICBmb3J3YXJkKCkge1xuICAgIHRoaXMuX3BsYXRmb3JtTG9jYXRpb24uZm9yd2FyZCgpO1xuICB9XG4gIGJhY2soKSB7XG4gICAgdGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5iYWNrKCk7XG4gIH1cbiAgZ2V0U3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BsYXRmb3JtTG9jYXRpb24uZ2V0U3RhdGUoKTtcbiAgfVxuICBoaXN0b3J5R28ocmVsYXRpdmVQb3NpdGlvbiA9IDApIHtcbiAgICB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLmhpc3RvcnlHbz8uKHJlbGF0aXZlUG9zaXRpb24pO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFBhdGhMb2NhdGlvblN0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgUGF0aExvY2F0aW9uU3RyYXRlZ3kpKGkwLsm1ybVpbmplY3QoUGxhdGZvcm1Mb2NhdGlvbiksIGkwLsm1ybVpbmplY3QoQVBQX0JBU0VfSFJFRiwgOCkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBQYXRoTG9jYXRpb25TdHJhdGVneSxcbiAgICBmYWN0b3J5OiBQYXRoTG9jYXRpb25TdHJhdGVneS7JtWZhYyxcbiAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShQYXRoTG9jYXRpb25TdHJhdGVneSwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBQbGF0Zm9ybUxvY2F0aW9uXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0FQUF9CQVNFX0hSRUZdXG4gICAgfV1cbiAgfV0sIG51bGwpO1xufSkoKTtcbmNsYXNzIE5vVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5IGV4dGVuZHMgUGF0aExvY2F0aW9uU3RyYXRlZ3kge1xuICBwcmVwYXJlRXh0ZXJuYWxVcmwoaW50ZXJuYWwpIHtcbiAgICBjb25zdCBwYXRoID0gZXh0cmFjdFVybFBhdGgoaW50ZXJuYWwpO1xuICAgIGlmIChwYXRoLmVuZHNXaXRoKCcvJykgJiYgcGF0aC5sZW5ndGggPiAxKSB7XG4gICAgICBpbnRlcm5hbCA9IHBhdGguc2xpY2UoMCwgLTEpICsgaW50ZXJuYWwuc2xpY2UocGF0aC5sZW5ndGgpO1xuICAgIH1cbiAgICByZXR1cm4gc3VwZXIucHJlcGFyZUV4dGVybmFsVXJsKGludGVybmFsKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtU5vVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5X0Jhc2VGYWN0b3J5O1xuICAgIHJldHVybiBmdW5jdGlvbiBOb1RyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICByZXR1cm4gKMm1Tm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3lfQmFzZUZhY3RvcnkgfHwgKMm1Tm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3lfQmFzZUZhY3RvcnkgPSBpMC7Jtcm1Z2V0SW5oZXJpdGVkRmFjdG9yeShOb1RyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneSkpKShfX25nRmFjdG9yeVR5cGVfXyB8fCBOb1RyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneSk7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogTm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3ksXG4gICAgZmFjdG9yeTogTm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3kuybVmYWMsXG4gICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3ksIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIFRyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneSBleHRlbmRzIFBhdGhMb2NhdGlvblN0cmF0ZWd5IHtcbiAgcHJlcGFyZUV4dGVybmFsVXJsKGludGVybmFsKSB7XG4gICAgY29uc3QgcGF0aCA9IGV4dHJhY3RVcmxQYXRoKGludGVybmFsKTtcbiAgICBpZiAoIXBhdGguZW5kc1dpdGgoJy8nKSkge1xuICAgICAgaW50ZXJuYWwgPSBwYXRoICsgJy8nICsgaW50ZXJuYWwuc2xpY2UocGF0aC5sZW5ndGgpO1xuICAgIH1cbiAgICByZXR1cm4gc3VwZXIucHJlcGFyZUV4dGVybmFsVXJsKGludGVybmFsKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSAvKiBAX19QVVJFX18gKi8oKCkgPT4ge1xuICAgIGxldCDJtVRyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneV9CYXNlRmFjdG9yeTtcbiAgICByZXR1cm4gZnVuY3Rpb24gVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIHJldHVybiAoybVUcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3lfQmFzZUZhY3RvcnkgfHwgKMm1VHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5X0Jhc2VGYWN0b3J5ID0gaTAuybXJtWdldEluaGVyaXRlZEZhY3RvcnkoVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5KSkpKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFRyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneSk7XG4gICAgfTtcbiAgfSkoKTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5LFxuICAgIGZhY3Rvcnk6IFRyYWlsaW5nU2xhc2hQYXRoTG9jYXRpb25TdHJhdGVneS7JtWZhYyxcbiAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShUcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3ksIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGV4dHJhY3RVcmxQYXRoKHVybCkge1xuICBjb25zdCBxdWVzdGlvbk1hcmtPckhhc2hJbmRleCA9IHVybC5zZWFyY2goL1s/I10vKTtcbiAgY29uc3QgcGF0aEVuZCA9IHF1ZXN0aW9uTWFya09ySGFzaEluZGV4ID4gLTEgPyBxdWVzdGlvbk1hcmtPckhhc2hJbmRleCA6IHVybC5sZW5ndGg7XG4gIHJldHVybiB1cmwuc2xpY2UoMCwgcGF0aEVuZCk7XG59XG5jbGFzcyBMb2NhdGlvbiB7XG4gIF9zdWJqZWN0ID0gbmV3IFN1YmplY3QoKTtcbiAgX2Jhc2VQYXRoO1xuICBfbG9jYXRpb25TdHJhdGVneTtcbiAgX3VybENoYW5nZUxpc3RlbmVycyA9IFtdO1xuICBfdXJsQ2hhbmdlU3Vic2NyaXB0aW9uID0gbnVsbDtcbiAgY29uc3RydWN0b3IobG9jYXRpb25TdHJhdGVneSkge1xuICAgIHRoaXMuX2xvY2F0aW9uU3RyYXRlZ3kgPSBsb2NhdGlvblN0cmF0ZWd5O1xuICAgIGNvbnN0IGJhc2VIcmVmID0gdGhpcy5fbG9jYXRpb25TdHJhdGVneS5nZXRCYXNlSHJlZigpO1xuICAgIHRoaXMuX2Jhc2VQYXRoID0gX3N0cmlwT3JpZ2luKHN0cmlwVHJhaWxpbmdTbGFzaChfc3RyaXBJbmRleEh0bWwoYmFzZUhyZWYpKSk7XG4gICAgdGhpcy5fbG9jYXRpb25TdHJhdGVneS5vblBvcFN0YXRlKGV2ID0+IHtcbiAgICAgIHRoaXMuX3N1YmplY3QubmV4dCh7XG4gICAgICAgICd1cmwnOiB0aGlzLnBhdGgodHJ1ZSksXG4gICAgICAgICdwb3AnOiB0cnVlLFxuICAgICAgICAnc3RhdGUnOiBldi5zdGF0ZSxcbiAgICAgICAgJ3R5cGUnOiBldi50eXBlXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLl91cmxDaGFuZ2VTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgdGhpcy5fdXJsQ2hhbmdlTGlzdGVuZXJzID0gW107XG4gIH1cbiAgcGF0aChpbmNsdWRlSGFzaCA9IGZhbHNlKSB7XG4gICAgcmV0dXJuIHRoaXMubm9ybWFsaXplKHRoaXMuX2xvY2F0aW9uU3RyYXRlZ3kucGF0aChpbmNsdWRlSGFzaCkpO1xuICB9XG4gIGdldFN0YXRlKCkge1xuICAgIHJldHVybiB0aGlzLl9sb2NhdGlvblN0cmF0ZWd5LmdldFN0YXRlKCk7XG4gIH1cbiAgaXNDdXJyZW50UGF0aEVxdWFsVG8ocGF0aCwgcXVlcnkgPSAnJykge1xuICAgIHJldHVybiB0aGlzLnBhdGgoKSA9PSB0aGlzLm5vcm1hbGl6ZShwYXRoICsgbm9ybWFsaXplUXVlcnlQYXJhbXMocXVlcnkpKTtcbiAgfVxuICBub3JtYWxpemUodXJsKSB7XG4gICAgcmV0dXJuIExvY2F0aW9uLnN0cmlwVHJhaWxpbmdTbGFzaChfc3RyaXBCYXNlUGF0aCh0aGlzLl9iYXNlUGF0aCwgX3N0cmlwSW5kZXhIdG1sKHVybCkpKTtcbiAgfVxuICBwcmVwYXJlRXh0ZXJuYWxVcmwodXJsKSB7XG4gICAgaWYgKHVybCAmJiB1cmxbMF0gIT09ICcvJykge1xuICAgICAgdXJsID0gJy8nICsgdXJsO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fbG9jYXRpb25TdHJhdGVneS5wcmVwYXJlRXh0ZXJuYWxVcmwodXJsKTtcbiAgfVxuICBnbyhwYXRoLCBxdWVyeSA9ICcnLCBzdGF0ZSA9IG51bGwpIHtcbiAgICB0aGlzLl9sb2NhdGlvblN0cmF0ZWd5LnB1c2hTdGF0ZShzdGF0ZSwgJycsIHBhdGgsIHF1ZXJ5KTtcbiAgICB0aGlzLl9ub3RpZnlVcmxDaGFuZ2VMaXN0ZW5lcnModGhpcy5wcmVwYXJlRXh0ZXJuYWxVcmwocGF0aCArIG5vcm1hbGl6ZVF1ZXJ5UGFyYW1zKHF1ZXJ5KSksIHN0YXRlKTtcbiAgfVxuICByZXBsYWNlU3RhdGUocGF0aCwgcXVlcnkgPSAnJywgc3RhdGUgPSBudWxsKSB7XG4gICAgdGhpcy5fbG9jYXRpb25TdHJhdGVneS5yZXBsYWNlU3RhdGUoc3RhdGUsICcnLCBwYXRoLCBxdWVyeSk7XG4gICAgdGhpcy5fbm90aWZ5VXJsQ2hhbmdlTGlzdGVuZXJzKHRoaXMucHJlcGFyZUV4dGVybmFsVXJsKHBhdGggKyBub3JtYWxpemVRdWVyeVBhcmFtcyhxdWVyeSkpLCBzdGF0ZSk7XG4gIH1cbiAgZm9yd2FyZCgpIHtcbiAgICB0aGlzLl9sb2NhdGlvblN0cmF0ZWd5LmZvcndhcmQoKTtcbiAgfVxuICBiYWNrKCkge1xuICAgIHRoaXMuX2xvY2F0aW9uU3RyYXRlZ3kuYmFjaygpO1xuICB9XG4gIGhpc3RvcnlHbyhyZWxhdGl2ZVBvc2l0aW9uID0gMCkge1xuICAgIHRoaXMuX2xvY2F0aW9uU3RyYXRlZ3kuaGlzdG9yeUdvPy4ocmVsYXRpdmVQb3NpdGlvbik7XG4gIH1cbiAgb25VcmxDaGFuZ2UoZm4pIHtcbiAgICB0aGlzLl91cmxDaGFuZ2VMaXN0ZW5lcnMucHVzaChmbik7XG4gICAgdGhpcy5fdXJsQ2hhbmdlU3Vic2NyaXB0aW9uID8/PSB0aGlzLnN1YnNjcmliZSh2ID0+IHtcbiAgICAgIHRoaXMuX25vdGlmeVVybENoYW5nZUxpc3RlbmVycyh2LnVybCwgdi5zdGF0ZSk7XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNvbnN0IGZuSW5kZXggPSB0aGlzLl91cmxDaGFuZ2VMaXN0ZW5lcnMuaW5kZXhPZihmbik7XG4gICAgICB0aGlzLl91cmxDaGFuZ2VMaXN0ZW5lcnMuc3BsaWNlKGZuSW5kZXgsIDEpO1xuICAgICAgaWYgKHRoaXMuX3VybENoYW5nZUxpc3RlbmVycy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhpcy5fdXJsQ2hhbmdlU3Vic2NyaXB0aW9uPy51bnN1YnNjcmliZSgpO1xuICAgICAgICB0aGlzLl91cmxDaGFuZ2VTdWJzY3JpcHRpb24gPSBudWxsO1xuICAgICAgfVxuICAgIH07XG4gIH1cbiAgX25vdGlmeVVybENoYW5nZUxpc3RlbmVycyh1cmwgPSAnJywgc3RhdGUpIHtcbiAgICB0aGlzLl91cmxDaGFuZ2VMaXN0ZW5lcnMuZm9yRWFjaChmbiA9PiBmbih1cmwsIHN0YXRlKSk7XG4gIH1cbiAgc3Vic2NyaWJlKG9uTmV4dCwgb25UaHJvdywgb25SZXR1cm4pIHtcbiAgICByZXR1cm4gdGhpcy5fc3ViamVjdC5zdWJzY3JpYmUoe1xuICAgICAgbmV4dDogb25OZXh0LFxuICAgICAgZXJyb3I6IG9uVGhyb3cgPz8gdW5kZWZpbmVkLFxuICAgICAgY29tcGxldGU6IG9uUmV0dXJuID8/IHVuZGVmaW5lZFxuICAgIH0pO1xuICB9XG4gIHN0YXRpYyBub3JtYWxpemVRdWVyeVBhcmFtcyA9IG5vcm1hbGl6ZVF1ZXJ5UGFyYW1zO1xuICBzdGF0aWMgam9pbldpdGhTbGFzaCA9IGpvaW5XaXRoU2xhc2g7XG4gIHN0YXRpYyBzdHJpcFRyYWlsaW5nU2xhc2ggPSBzdHJpcFRyYWlsaW5nU2xhc2g7XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIExvY2F0aW9uX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTG9jYXRpb24pKGkwLsm1ybVpbmplY3QoTG9jYXRpb25TdHJhdGVneSkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBMb2NhdGlvbixcbiAgICBmYWN0b3J5OiAoKSA9PiBjcmVhdGVMb2NhdGlvbigpLFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKExvY2F0aW9uLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVkSW46ICdyb290JyxcbiAgICAgIHVzZUZhY3Rvcnk6IGNyZWF0ZUxvY2F0aW9uXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogTG9jYXRpb25TdHJhdGVneVxuICB9XSwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gY3JlYXRlTG9jYXRpb24oKSB7XG4gIHJldHVybiBuZXcgTG9jYXRpb24oX19pbmplY3QoTG9jYXRpb25TdHJhdGVneSkpO1xufVxuZnVuY3Rpb24gX3N0cmlwQmFzZVBhdGgoYmFzZVBhdGgsIHVybCkge1xuICBpZiAoIWJhc2VQYXRoIHx8ICF1cmwuc3RhcnRzV2l0aChiYXNlUGF0aCkpIHtcbiAgICByZXR1cm4gdXJsO1xuICB9XG4gIGNvbnN0IHN0cmlwcGVkVXJsID0gdXJsLnN1YnN0cmluZyhiYXNlUGF0aC5sZW5ndGgpO1xuICBpZiAoc3RyaXBwZWRVcmwgPT09ICcnIHx8IFsnLycsICc7JywgJz8nLCAnIyddLmluY2x1ZGVzKHN0cmlwcGVkVXJsWzBdKSkge1xuICAgIHJldHVybiBzdHJpcHBlZFVybDtcbiAgfVxuICByZXR1cm4gdXJsO1xufVxuZnVuY3Rpb24gX3N0cmlwSW5kZXhIdG1sKHVybCkge1xuICByZXR1cm4gdXJsLnJlcGxhY2UoL1xcL2luZGV4XFwuaHRtbCQvLCAnJyk7XG59XG5mdW5jdGlvbiBfc3RyaXBPcmlnaW4oYmFzZUhyZWYpIHtcbiAgY29uc3QgaXNBYnNvbHV0ZVVybCA9IG5ldyBSZWdFeHAoJ14oaHR0cHM/Oik/Ly8nKS50ZXN0KGJhc2VIcmVmKTtcbiAgaWYgKGlzQWJzb2x1dGVVcmwpIHtcbiAgICBjb25zdCBbLCBwYXRobmFtZV0gPSBiYXNlSHJlZi5zcGxpdCgvXFwvXFwvW15cXC9dKy8pO1xuICAgIHJldHVybiBwYXRobmFtZTtcbiAgfVxuICByZXR1cm4gYmFzZUhyZWY7XG59XG5leHBvcnQgeyBBUFBfQkFTRV9IUkVGLCBMb2NhdGlvbiwgTG9jYXRpb25TdHJhdGVneSwgTm9UcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3ksIFBhdGhMb2NhdGlvblN0cmF0ZWd5LCBUcmFpbGluZ1NsYXNoUGF0aExvY2F0aW9uU3RyYXRlZ3ksIGpvaW5XaXRoU2xhc2gsIG5vcm1hbGl6ZVF1ZXJ5UGFyYW1zIH07XG4iLCIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjIyLjEuMlxuICogKGMpIDIwMTAtMjAyNiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuZGV2L1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0ICogYXMgaTAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPcHRpb25hbCwgSW5qZWN0LCBJbmplY3RhYmxlLCDJtWdldExvY2FsZVBsdXJhbENhc2UgYXMgX2dldExvY2FsZVBsdXJhbENhc2UsIMm1Z2V0TG9jYWxlQ3VycmVuY3lDb2RlIGFzIF9nZXRMb2NhbGVDdXJyZW5jeUNvZGUsIMm1ZmluZExvY2FsZURhdGEgYXMgX2ZpbmRMb2NhbGVEYXRhLCDJtUxvY2FsZURhdGFJbmRleCBhcyBfTG9jYWxlRGF0YUluZGV4LCDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCDJtWZvcm1hdFJ1bnRpbWVFcnJvciBhcyBfZm9ybWF0UnVudGltZUVycm9yLCBMT0NBTEVfSUQsIGluamVjdCwgU2VydmljZSwgybVzdHJpbmdpZnkgYXMgX3N0cmluZ2lmeSwgSW5wdXQsIERpcmVjdGl2ZSwgY3JlYXRlTmdNb2R1bGUsIE5nTW9kdWxlUmVmLCBIb3N0LCBBdHRyaWJ1dGUsIFJlbmRlcmVyU3R5bGVGbGFnczIsIEluamVjdG9yLCBpc1NpZ25hbCwgybVJTlRFUk5BTF9BUFBMSUNBVElPTl9FUlJPUl9IQU5ETEVSIGFzIF9JTlRFUk5BTF9BUFBMSUNBVElPTl9FUlJPUl9IQU5ETEVSLCDJtWlzUHJvbWlzZSBhcyBfaXNQcm9taXNlLCDJtWlzU3Vic2NyaWJhYmxlIGFzIF9pc1N1YnNjcmliYWJsZSwgdW50cmFja2VkLCBQaXBlLCBJbmplY3Rpb25Ub2tlbiwgREVGQVVMVF9DVVJSRU5DWV9DT0RFLCBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTG9jYXRpb25TdHJhdGVneSwgam9pbldpdGhTbGFzaCwgbm9ybWFsaXplUXVlcnlQYXJhbXMsIEFQUF9CQVNFX0hSRUYgfSBmcm9tICcuL19sb2NhdGlvbi1jaHVuay5tanMnO1xuaW1wb3J0IHsgUGxhdGZvcm1Mb2NhdGlvbiB9IGZyb20gJy4vX3BsYXRmb3JtX2xvY2F0aW9uLWNodW5rLm1qcyc7XG5jbGFzcyBIYXNoTG9jYXRpb25TdHJhdGVneSBleHRlbmRzIExvY2F0aW9uU3RyYXRlZ3kge1xuICBfcGxhdGZvcm1Mb2NhdGlvbjtcbiAgX2Jhc2VIcmVmID0gJyc7XG4gIF9yZW1vdmVMaXN0ZW5lckZucyA9IFtdO1xuICBjb25zdHJ1Y3RvcihfcGxhdGZvcm1Mb2NhdGlvbiwgX2Jhc2VIcmVmKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uID0gX3BsYXRmb3JtTG9jYXRpb247XG4gICAgaWYgKF9iYXNlSHJlZiAhPSBudWxsKSB7XG4gICAgICB0aGlzLl9iYXNlSHJlZiA9IF9iYXNlSHJlZjtcbiAgICB9XG4gIH1cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgd2hpbGUgKHRoaXMuX3JlbW92ZUxpc3RlbmVyRm5zLmxlbmd0aCkge1xuICAgICAgdGhpcy5fcmVtb3ZlTGlzdGVuZXJGbnMucG9wKCkoKTtcbiAgICB9XG4gIH1cbiAgb25Qb3BTdGF0ZShmbikge1xuICAgIHRoaXMuX3JlbW92ZUxpc3RlbmVyRm5zLnB1c2godGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5vblBvcFN0YXRlKGZuKSwgdGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5vbkhhc2hDaGFuZ2UoZm4pKTtcbiAgfVxuICBnZXRCYXNlSHJlZigpIHtcbiAgICByZXR1cm4gdGhpcy5fYmFzZUhyZWY7XG4gIH1cbiAgcGF0aChpbmNsdWRlSGFzaCA9IGZhbHNlKSB7XG4gICAgY29uc3QgcGF0aCA9IHRoaXMuX3BsYXRmb3JtTG9jYXRpb24uaGFzaCA/PyAnIyc7XG4gICAgcmV0dXJuIHBhdGgubGVuZ3RoID4gMCA/IHBhdGguc3Vic3RyaW5nKDEpIDogcGF0aDtcbiAgfVxuICBwcmVwYXJlRXh0ZXJuYWxVcmwoaW50ZXJuYWwpIHtcbiAgICBjb25zdCB1cmwgPSBqb2luV2l0aFNsYXNoKHRoaXMuX2Jhc2VIcmVmLCBpbnRlcm5hbCk7XG4gICAgcmV0dXJuIHVybC5sZW5ndGggPiAwID8gJyMnICsgdXJsIDogdXJsO1xuICB9XG4gIHB1c2hTdGF0ZShzdGF0ZSwgdGl0bGUsIHBhdGgsIHF1ZXJ5UGFyYW1zKSB7XG4gICAgY29uc3QgdXJsID0gdGhpcy5wcmVwYXJlRXh0ZXJuYWxVcmwocGF0aCArIG5vcm1hbGl6ZVF1ZXJ5UGFyYW1zKHF1ZXJ5UGFyYW1zKSkgfHwgdGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5wYXRobmFtZTtcbiAgICB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLnB1c2hTdGF0ZShzdGF0ZSwgdGl0bGUsIHVybCk7XG4gIH1cbiAgcmVwbGFjZVN0YXRlKHN0YXRlLCB0aXRsZSwgcGF0aCwgcXVlcnlQYXJhbXMpIHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLnByZXBhcmVFeHRlcm5hbFVybChwYXRoICsgbm9ybWFsaXplUXVlcnlQYXJhbXMocXVlcnlQYXJhbXMpKSB8fCB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLnBhdGhuYW1lO1xuICAgIHRoaXMuX3BsYXRmb3JtTG9jYXRpb24ucmVwbGFjZVN0YXRlKHN0YXRlLCB0aXRsZSwgdXJsKTtcbiAgfVxuICBmb3J3YXJkKCkge1xuICAgIHRoaXMuX3BsYXRmb3JtTG9jYXRpb24uZm9yd2FyZCgpO1xuICB9XG4gIGJhY2soKSB7XG4gICAgdGhpcy5fcGxhdGZvcm1Mb2NhdGlvbi5iYWNrKCk7XG4gIH1cbiAgZ2V0U3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3BsYXRmb3JtTG9jYXRpb24uZ2V0U3RhdGUoKTtcbiAgfVxuICBoaXN0b3J5R28ocmVsYXRpdmVQb3NpdGlvbiA9IDApIHtcbiAgICB0aGlzLl9wbGF0Zm9ybUxvY2F0aW9uLmhpc3RvcnlHbz8uKHJlbGF0aXZlUG9zaXRpb24pO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEhhc2hMb2NhdGlvblN0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgSGFzaExvY2F0aW9uU3RyYXRlZ3kpKGkwLsm1ybVpbmplY3QoUGxhdGZvcm1Mb2NhdGlvbiksIGkwLsm1ybVpbmplY3QoQVBQX0JBU0VfSFJFRiwgOCkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBIYXNoTG9jYXRpb25TdHJhdGVneSxcbiAgICBmYWN0b3J5OiBIYXNoTG9jYXRpb25TdHJhdGVneS7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEhhc2hMb2NhdGlvblN0cmF0ZWd5LCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogUGxhdGZvcm1Mb2NhdGlvblxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH0sIHtcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtBUFBfQkFTRV9IUkVGXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jb25zdCBDVVJSRU5DSUVTX0VOID0ge1xuICBcIkFEUFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIkFGTlwiOiBbdW5kZWZpbmVkLCBcItiLXCIsIDBdLFxuICBcIkFMTFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIkFNRFwiOiBbdW5kZWZpbmVkLCBcItaPXCIsIDJdLFxuICBcIkFPQVwiOiBbdW5kZWZpbmVkLCBcIkt6XCJdLFxuICBcIkFSU1wiOiBbdW5kZWZpbmVkLCBcIiRcIl0sXG4gIFwiQVVEXCI6IFtcIkEkXCIsIFwiJFwiXSxcbiAgXCJBWk5cIjogW3VuZGVmaW5lZCwgXCLigrxcIl0sXG4gIFwiQkFNXCI6IFt1bmRlZmluZWQsIFwiS01cIl0sXG4gIFwiQkJEXCI6IFt1bmRlZmluZWQsIFwiJFwiXSxcbiAgXCJCRFRcIjogW3VuZGVmaW5lZCwgXCLgp7NcIl0sXG4gIFwiQkhEXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgM10sXG4gIFwiQklGXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiQk1EXCI6IFt1bmRlZmluZWQsIFwiJFwiXSxcbiAgXCJCTkRcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIkJPQlwiOiBbdW5kZWZpbmVkLCBcIkJzXCJdLFxuICBcIkJSTFwiOiBbXCJSJFwiXSxcbiAgXCJCU0RcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIkJXUFwiOiBbdW5kZWZpbmVkLCBcIlBcIl0sXG4gIFwiQllOXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMl0sXG4gIFwiQllSXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiQlpEXCI6IFt1bmRlZmluZWQsIFwiJFwiXSxcbiAgXCJDQURcIjogW1wiQ0EkXCIsIFwiJFwiLCAyXSxcbiAgXCJDSEZcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAyXSxcbiAgXCJDTEZcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCA0XSxcbiAgXCJDTFBcIjogW3VuZGVmaW5lZCwgXCIkXCIsIDBdLFxuICBcIkNOWVwiOiBbXCJDTsKlXCIsIFwiwqVcIl0sXG4gIFwiQ09QXCI6IFt1bmRlZmluZWQsIFwiJFwiLCAyXSxcbiAgXCJDUkNcIjogW3VuZGVmaW5lZCwgXCLigqFcIiwgMl0sXG4gIFwiQ1VDXCI6IFt1bmRlZmluZWQsIFwiJFwiXSxcbiAgXCJDVVBcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIkNaS1wiOiBbdW5kZWZpbmVkLCBcIkvEjVwiLCAyXSxcbiAgXCJESkZcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAwXSxcbiAgXCJES0tcIjogW3VuZGVmaW5lZCwgXCJrclwiLCAyXSxcbiAgXCJET1BcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIkVHUFwiOiBbdW5kZWZpbmVkLCBcIkXCo1wiXSxcbiAgXCJFU1BcIjogW3VuZGVmaW5lZCwgXCLigqdcIiwgMF0sXG4gIFwiRVVSXCI6IFtcIuKCrFwiXSxcbiAgXCJGSkRcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIkZLUFwiOiBbdW5kZWZpbmVkLCBcIsKjXCJdLFxuICBcIkdCUFwiOiBbXCLCo1wiXSxcbiAgXCJHRUxcIjogW3VuZGVmaW5lZCwgXCLigr5cIl0sXG4gIFwiR0hTXCI6IFt1bmRlZmluZWQsIFwiR0jigrVcIl0sXG4gIFwiR0lQXCI6IFt1bmRlZmluZWQsIFwiwqNcIl0sXG4gIFwiR05GXCI6IFt1bmRlZmluZWQsIFwiRkdcIiwgMF0sXG4gIFwiR1RRXCI6IFt1bmRlZmluZWQsIFwiUVwiXSxcbiAgXCJHWURcIjogW3VuZGVmaW5lZCwgXCIkXCIsIDJdLFxuICBcIkhLRFwiOiBbXCJISyRcIiwgXCIkXCJdLFxuICBcIkhOTFwiOiBbdW5kZWZpbmVkLCBcIkxcIl0sXG4gIFwiSFJLXCI6IFt1bmRlZmluZWQsIFwia25cIl0sXG4gIFwiSFVGXCI6IFt1bmRlZmluZWQsIFwiRnRcIiwgMl0sXG4gIFwiSURSXCI6IFt1bmRlZmluZWQsIFwiUnBcIiwgMl0sXG4gIFwiSUxTXCI6IFtcIuKCqlwiXSxcbiAgXCJJTlJcIjogW1wi4oK5XCJdLFxuICBcIklRRFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIklSUlwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIklTS1wiOiBbdW5kZWZpbmVkLCBcImtyXCIsIDBdLFxuICBcIklUTFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIkpNRFwiOiBbdW5kZWZpbmVkLCBcIiRcIl0sXG4gIFwiSk9EXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgM10sXG4gIFwiSlBZXCI6IFtcIsKlXCIsIHVuZGVmaW5lZCwgMF0sXG4gIFwiS0dTXCI6IFt1bmRlZmluZWQsIFwi4oOAXCJdLFxuICBcIktIUlwiOiBbdW5kZWZpbmVkLCBcIuGfm1wiXSxcbiAgXCJLTUZcIjogW3VuZGVmaW5lZCwgXCJDRlwiLCAwXSxcbiAgXCJLUFdcIjogW3VuZGVmaW5lZCwgXCLigqlcIiwgMF0sXG4gIFwiS1JXXCI6IFtcIuKCqVwiLCB1bmRlZmluZWQsIDBdLFxuICBcIktXRFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDNdLFxuICBcIktZRFwiOiBbdW5kZWZpbmVkLCBcIiRcIl0sXG4gIFwiS1pUXCI6IFt1bmRlZmluZWQsIFwi4oK4XCJdLFxuICBcIkxBS1wiOiBbdW5kZWZpbmVkLCBcIuKCrVwiLCAwXSxcbiAgXCJMQlBcIjogW3VuZGVmaW5lZCwgXCJMwqNcIiwgMF0sXG4gIFwiTEtSXCI6IFt1bmRlZmluZWQsIFwiUnNcIl0sXG4gIFwiTFJEXCI6IFt1bmRlZmluZWQsIFwiJFwiXSxcbiAgXCJMVExcIjogW3VuZGVmaW5lZCwgXCJMdFwiXSxcbiAgXCJMVUZcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAwXSxcbiAgXCJMVkxcIjogW3VuZGVmaW5lZCwgXCJMc1wiXSxcbiAgXCJMWURcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAzXSxcbiAgXCJNR0FcIjogW3VuZGVmaW5lZCwgXCJBclwiLCAwXSxcbiAgXCJNR0ZcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAwXSxcbiAgXCJNTUtcIjogW3VuZGVmaW5lZCwgXCJLXCIsIDBdLFxuICBcIk1OVFwiOiBbdW5kZWZpbmVkLCBcIuKCrlwiLCAyXSxcbiAgXCJNUk9cIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAwXSxcbiAgXCJNVVJcIjogW3VuZGVmaW5lZCwgXCJSc1wiLCAyXSxcbiAgXCJNWE5cIjogW1wiTVgkXCIsIFwiJFwiXSxcbiAgXCJNWVJcIjogW3VuZGVmaW5lZCwgXCJSTVwiXSxcbiAgXCJOQURcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIk5HTlwiOiBbdW5kZWZpbmVkLCBcIuKCplwiXSxcbiAgXCJOSU9cIjogW3VuZGVmaW5lZCwgXCJDJFwiXSxcbiAgXCJOT0tcIjogW3VuZGVmaW5lZCwgXCJrclwiLCAyXSxcbiAgXCJOUFJcIjogW3VuZGVmaW5lZCwgXCJSc1wiXSxcbiAgXCJOWkRcIjogW1wiTlokXCIsIFwiJFwiXSxcbiAgXCJPTVJcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAzXSxcbiAgXCJQSFBcIjogW1wi4oKxXCJdLFxuICBcIlBLUlwiOiBbdW5kZWZpbmVkLCBcIlJzXCIsIDJdLFxuICBcIlBMTlwiOiBbdW5kZWZpbmVkLCBcInrFglwiXSxcbiAgXCJQWUdcIjogW3VuZGVmaW5lZCwgXCLigrJcIiwgMF0sXG4gIFwiUk9OXCI6IFt1bmRlZmluZWQsIFwibGVpXCJdLFxuICBcIlJTRFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIlJVQlwiOiBbdW5kZWZpbmVkLCBcIuKCvVwiXSxcbiAgXCJSV0ZcIjogW3VuZGVmaW5lZCwgXCJSRlwiLCAwXSxcbiAgXCJTQkRcIjogW3VuZGVmaW5lZCwgXCIkXCJdLFxuICBcIlNFS1wiOiBbdW5kZWZpbmVkLCBcImtyXCIsIDJdLFxuICBcIlNHRFwiOiBbdW5kZWZpbmVkLCBcIiRcIl0sXG4gIFwiU0hQXCI6IFt1bmRlZmluZWQsIFwiwqNcIl0sXG4gIFwiU0xFXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMl0sXG4gIFwiU0xMXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiU09TXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiU1JEXCI6IFt1bmRlZmluZWQsIFwiJFwiXSxcbiAgXCJTU1BcIjogW3VuZGVmaW5lZCwgXCLCo1wiXSxcbiAgXCJTVERcIjogW3VuZGVmaW5lZCwgdW5kZWZpbmVkLCAwXSxcbiAgXCJTVE5cIjogW3VuZGVmaW5lZCwgXCJEYlwiXSxcbiAgXCJTWVBcIjogW3VuZGVmaW5lZCwgXCLCo1wiLCAwXSxcbiAgXCJUSEJcIjogW3VuZGVmaW5lZCwgXCLguL9cIl0sXG4gIFwiVE1NXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiVE5EXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgM10sXG4gIFwiVE9QXCI6IFt1bmRlZmluZWQsIFwiVCRcIl0sXG4gIFwiVFJMXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiVFJZXCI6IFt1bmRlZmluZWQsIFwi4oK6XCJdLFxuICBcIlRURFwiOiBbdW5kZWZpbmVkLCBcIiRcIl0sXG4gIFwiVFdEXCI6IFtcIk5UJFwiLCBcIiRcIiwgMl0sXG4gIFwiVFpTXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMl0sXG4gIFwiVUFIXCI6IFt1bmRlZmluZWQsIFwi4oK0XCJdLFxuICBcIlVHWFwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIlVTRFwiOiBbXCIkXCJdLFxuICBcIlVZSVwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIlVZVVwiOiBbdW5kZWZpbmVkLCBcIiRcIl0sXG4gIFwiVVlXXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgNF0sXG4gIFwiVVpTXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMl0sXG4gIFwiVkVGXCI6IFt1bmRlZmluZWQsIFwiQnNcIiwgMl0sXG4gIFwiVk5EXCI6IFtcIuKCq1wiLCB1bmRlZmluZWQsIDBdLFxuICBcIlZVVlwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIlhBRlwiOiBbXCJGQ0ZBXCIsIHVuZGVmaW5lZCwgMF0sXG4gIFwiWENEXCI6IFtcIkVDJFwiLCBcIiRcIl0sXG4gIFwiWENHXCI6IFtcIkNnLlwiXSxcbiAgXCJYT0ZcIjogW1wiRuKAr0NGQVwiLCB1bmRlZmluZWQsIDBdLFxuICBcIlhQRlwiOiBbXCJDRlBGXCIsIHVuZGVmaW5lZCwgMF0sXG4gIFwiWFhYXCI6IFtcIsKkXCJdLFxuICBcIllFUlwiOiBbdW5kZWZpbmVkLCB1bmRlZmluZWQsIDBdLFxuICBcIlpBUlwiOiBbdW5kZWZpbmVkLCBcIlJcIl0sXG4gIFwiWk1LXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF0sXG4gIFwiWk1XXCI6IFt1bmRlZmluZWQsIFwiWktcIl0sXG4gIFwiWldEXCI6IFt1bmRlZmluZWQsIHVuZGVmaW5lZCwgMF1cbn07XG52YXIgTnVtYmVyRm9ybWF0U3R5bGU7XG4oZnVuY3Rpb24gKE51bWJlckZvcm1hdFN0eWxlKSB7XG4gIE51bWJlckZvcm1hdFN0eWxlW051bWJlckZvcm1hdFN0eWxlW1wiRGVjaW1hbFwiXSA9IDBdID0gXCJEZWNpbWFsXCI7XG4gIE51bWJlckZvcm1hdFN0eWxlW051bWJlckZvcm1hdFN0eWxlW1wiUGVyY2VudFwiXSA9IDFdID0gXCJQZXJjZW50XCI7XG4gIE51bWJlckZvcm1hdFN0eWxlW051bWJlckZvcm1hdFN0eWxlW1wiQ3VycmVuY3lcIl0gPSAyXSA9IFwiQ3VycmVuY3lcIjtcbiAgTnVtYmVyRm9ybWF0U3R5bGVbTnVtYmVyRm9ybWF0U3R5bGVbXCJTY2llbnRpZmljXCJdID0gM10gPSBcIlNjaWVudGlmaWNcIjtcbn0pKE51bWJlckZvcm1hdFN0eWxlIHx8IChOdW1iZXJGb3JtYXRTdHlsZSA9IHt9KSk7XG52YXIgUGx1cmFsO1xuKGZ1bmN0aW9uIChQbHVyYWwpIHtcbiAgUGx1cmFsW1BsdXJhbFtcIlplcm9cIl0gPSAwXSA9IFwiWmVyb1wiO1xuICBQbHVyYWxbUGx1cmFsW1wiT25lXCJdID0gMV0gPSBcIk9uZVwiO1xuICBQbHVyYWxbUGx1cmFsW1wiVHdvXCJdID0gMl0gPSBcIlR3b1wiO1xuICBQbHVyYWxbUGx1cmFsW1wiRmV3XCJdID0gM10gPSBcIkZld1wiO1xuICBQbHVyYWxbUGx1cmFsW1wiTWFueVwiXSA9IDRdID0gXCJNYW55XCI7XG4gIFBsdXJhbFtQbHVyYWxbXCJPdGhlclwiXSA9IDVdID0gXCJPdGhlclwiO1xufSkoUGx1cmFsIHx8IChQbHVyYWwgPSB7fSkpO1xudmFyIEZvcm1TdHlsZTtcbihmdW5jdGlvbiAoRm9ybVN0eWxlKSB7XG4gIEZvcm1TdHlsZVtGb3JtU3R5bGVbXCJGb3JtYXRcIl0gPSAwXSA9IFwiRm9ybWF0XCI7XG4gIEZvcm1TdHlsZVtGb3JtU3R5bGVbXCJTdGFuZGFsb25lXCJdID0gMV0gPSBcIlN0YW5kYWxvbmVcIjtcbn0pKEZvcm1TdHlsZSB8fCAoRm9ybVN0eWxlID0ge30pKTtcbnZhciBUcmFuc2xhdGlvbldpZHRoO1xuKGZ1bmN0aW9uIChUcmFuc2xhdGlvbldpZHRoKSB7XG4gIFRyYW5zbGF0aW9uV2lkdGhbVHJhbnNsYXRpb25XaWR0aFtcIk5hcnJvd1wiXSA9IDBdID0gXCJOYXJyb3dcIjtcbiAgVHJhbnNsYXRpb25XaWR0aFtUcmFuc2xhdGlvbldpZHRoW1wiQWJicmV2aWF0ZWRcIl0gPSAxXSA9IFwiQWJicmV2aWF0ZWRcIjtcbiAgVHJhbnNsYXRpb25XaWR0aFtUcmFuc2xhdGlvbldpZHRoW1wiV2lkZVwiXSA9IDJdID0gXCJXaWRlXCI7XG4gIFRyYW5zbGF0aW9uV2lkdGhbVHJhbnNsYXRpb25XaWR0aFtcIlNob3J0XCJdID0gM10gPSBcIlNob3J0XCI7XG59KShUcmFuc2xhdGlvbldpZHRoIHx8IChUcmFuc2xhdGlvbldpZHRoID0ge30pKTtcbnZhciBGb3JtYXRXaWR0aDtcbihmdW5jdGlvbiAoRm9ybWF0V2lkdGgpIHtcbiAgRm9ybWF0V2lkdGhbRm9ybWF0V2lkdGhbXCJTaG9ydFwiXSA9IDBdID0gXCJTaG9ydFwiO1xuICBGb3JtYXRXaWR0aFtGb3JtYXRXaWR0aFtcIk1lZGl1bVwiXSA9IDFdID0gXCJNZWRpdW1cIjtcbiAgRm9ybWF0V2lkdGhbRm9ybWF0V2lkdGhbXCJMb25nXCJdID0gMl0gPSBcIkxvbmdcIjtcbiAgRm9ybWF0V2lkdGhbRm9ybWF0V2lkdGhbXCJGdWxsXCJdID0gM10gPSBcIkZ1bGxcIjtcbn0pKEZvcm1hdFdpZHRoIHx8IChGb3JtYXRXaWR0aCA9IHt9KSk7XG5jb25zdCBOdW1iZXJTeW1ib2wgPSB7XG4gIERlY2ltYWw6IDAsXG4gIEdyb3VwOiAxLFxuICBMaXN0OiAyLFxuICBQZXJjZW50U2lnbjogMyxcbiAgUGx1c1NpZ246IDQsXG4gIE1pbnVzU2lnbjogNSxcbiAgRXhwb25lbnRpYWw6IDYsXG4gIFN1cGVyc2NyaXB0aW5nRXhwb25lbnQ6IDcsXG4gIFBlck1pbGxlOiA4LFxuICBJbmZpbml0eTogOSxcbiAgTmFOOiAxMCxcbiAgVGltZVNlcGFyYXRvcjogMTEsXG4gIEN1cnJlbmN5RGVjaW1hbDogMTIsXG4gIEN1cnJlbmN5R3JvdXA6IDEzXG59O1xudmFyIFdlZWtEYXk7XG4oZnVuY3Rpb24gKFdlZWtEYXkpIHtcbiAgV2Vla0RheVtXZWVrRGF5W1wiU3VuZGF5XCJdID0gMF0gPSBcIlN1bmRheVwiO1xuICBXZWVrRGF5W1dlZWtEYXlbXCJNb25kYXlcIl0gPSAxXSA9IFwiTW9uZGF5XCI7XG4gIFdlZWtEYXlbV2Vla0RheVtcIlR1ZXNkYXlcIl0gPSAyXSA9IFwiVHVlc2RheVwiO1xuICBXZWVrRGF5W1dlZWtEYXlbXCJXZWRuZXNkYXlcIl0gPSAzXSA9IFwiV2VkbmVzZGF5XCI7XG4gIFdlZWtEYXlbV2Vla0RheVtcIlRodXJzZGF5XCJdID0gNF0gPSBcIlRodXJzZGF5XCI7XG4gIFdlZWtEYXlbV2Vla0RheVtcIkZyaWRheVwiXSA9IDVdID0gXCJGcmlkYXlcIjtcbiAgV2Vla0RheVtXZWVrRGF5W1wiU2F0dXJkYXlcIl0gPSA2XSA9IFwiU2F0dXJkYXlcIjtcbn0pKFdlZWtEYXkgfHwgKFdlZWtEYXkgPSB7fSkpO1xuZnVuY3Rpb24gZ2V0TG9jYWxlSWQobG9jYWxlKSB7XG4gIHJldHVybiBfZmluZExvY2FsZURhdGEobG9jYWxlKVtfTG9jYWxlRGF0YUluZGV4LkxvY2FsZUlkXTtcbn1cbmZ1bmN0aW9uIGdldExvY2FsZURheVBlcmlvZHMobG9jYWxlLCBmb3JtU3R5bGUsIHdpZHRoKSB7XG4gIGNvbnN0IGRhdGEgPSBfZmluZExvY2FsZURhdGEobG9jYWxlKTtcbiAgY29uc3QgYW1QbURhdGEgPSBbZGF0YVtfTG9jYWxlRGF0YUluZGV4LkRheVBlcmlvZHNGb3JtYXRdLCBkYXRhW19Mb2NhbGVEYXRhSW5kZXguRGF5UGVyaW9kc1N0YW5kYWxvbmVdXTtcbiAgY29uc3QgYW1QbSA9IGdldExhc3REZWZpbmVkVmFsdWUoYW1QbURhdGEsIGZvcm1TdHlsZSk7XG4gIHJldHVybiBnZXRMYXN0RGVmaW5lZFZhbHVlKGFtUG0sIHdpZHRoKTtcbn1cbmZ1bmN0aW9uIGdldExvY2FsZURheU5hbWVzKGxvY2FsZSwgZm9ybVN0eWxlLCB3aWR0aCkge1xuICBjb25zdCBkYXRhID0gX2ZpbmRMb2NhbGVEYXRhKGxvY2FsZSk7XG4gIGNvbnN0IGRheXNEYXRhID0gW2RhdGFbX0xvY2FsZURhdGFJbmRleC5EYXlzRm9ybWF0XSwgZGF0YVtfTG9jYWxlRGF0YUluZGV4LkRheXNTdGFuZGFsb25lXV07XG4gIGNvbnN0IGRheXMgPSBnZXRMYXN0RGVmaW5lZFZhbHVlKGRheXNEYXRhLCBmb3JtU3R5bGUpO1xuICByZXR1cm4gZ2V0TGFzdERlZmluZWRWYWx1ZShkYXlzLCB3aWR0aCk7XG59XG5mdW5jdGlvbiBnZXRMb2NhbGVNb250aE5hbWVzKGxvY2FsZSwgZm9ybVN0eWxlLCB3aWR0aCkge1xuICBjb25zdCBkYXRhID0gX2ZpbmRMb2NhbGVEYXRhKGxvY2FsZSk7XG4gIGNvbnN0IG1vbnRoc0RhdGEgPSBbZGF0YVtfTG9jYWxlRGF0YUluZGV4Lk1vbnRoc0Zvcm1hdF0sIGRhdGFbX0xvY2FsZURhdGFJbmRleC5Nb250aHNTdGFuZGFsb25lXV07XG4gIGNvbnN0IG1vbnRocyA9IGdldExhc3REZWZpbmVkVmFsdWUobW9udGhzRGF0YSwgZm9ybVN0eWxlKTtcbiAgcmV0dXJuIGdldExhc3REZWZpbmVkVmFsdWUobW9udGhzLCB3aWR0aCk7XG59XG5mdW5jdGlvbiBnZXRMb2NhbGVFcmFOYW1lcyhsb2NhbGUsIHdpZHRoKSB7XG4gIGNvbnN0IGRhdGEgPSBfZmluZExvY2FsZURhdGEobG9jYWxlKTtcbiAgY29uc3QgZXJhc0RhdGEgPSBkYXRhW19Mb2NhbGVEYXRhSW5kZXguRXJhc107XG4gIHJldHVybiBnZXRMYXN0RGVmaW5lZFZhbHVlKGVyYXNEYXRhLCB3aWR0aCk7XG59XG5mdW5jdGlvbiBnZXRMb2NhbGVGaXJzdERheU9mV2Vlayhsb2NhbGUpIHtcbiAgY29uc3QgZGF0YSA9IF9maW5kTG9jYWxlRGF0YShsb2NhbGUpO1xuICByZXR1cm4gZGF0YVtfTG9jYWxlRGF0YUluZGV4LkZpcnN0RGF5T2ZXZWVrXTtcbn1cbmZ1bmN0aW9uIGdldExvY2FsZVdlZWtFbmRSYW5nZShsb2NhbGUpIHtcbiAgY29uc3QgZGF0YSA9IF9maW5kTG9jYWxlRGF0YShsb2NhbGUpO1xuICByZXR1cm4gZGF0YVtfTG9jYWxlRGF0YUluZGV4LldlZWtlbmRSYW5nZV07XG59XG5mdW5jdGlvbiBnZXRMb2NhbGVEYXRlRm9ybWF0KGxvY2FsZSwgd2lkdGgpIHtcbiAgY29uc3QgZGF0YSA9IF9maW5kTG9jYWxlRGF0YShsb2NhbGUpO1xuICByZXR1cm4gZ2V0TGFzdERlZmluZWRWYWx1ZShkYXRhW19Mb2NhbGVEYXRhSW5kZXguRGF0ZUZvcm1hdF0sIHdpZHRoKTtcbn1cbmZ1bmN0aW9uIGdldExvY2FsZVRpbWVGb3JtYXQobG9jYWxlLCB3aWR0aCkge1xuICBjb25zdCBkYXRhID0gX2ZpbmRMb2NhbGVEYXRhKGxvY2FsZSk7XG4gIHJldHVybiBnZXRMYXN0RGVmaW5lZFZhbHVlKGRhdGFbX0xvY2FsZURhdGFJbmRleC5UaW1lRm9ybWF0XSwgd2lkdGgpO1xufVxuZnVuY3Rpb24gZ2V0TG9jYWxlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCB3aWR0aCkge1xuICBjb25zdCBkYXRhID0gX2ZpbmRMb2NhbGVEYXRhKGxvY2FsZSk7XG4gIGNvbnN0IGRhdGVUaW1lRm9ybWF0RGF0YSA9IGRhdGFbX0xvY2FsZURhdGFJbmRleC5EYXRlVGltZUZvcm1hdF07XG4gIHJldHVybiBnZXRMYXN0RGVmaW5lZFZhbHVlKGRhdGVUaW1lRm9ybWF0RGF0YSwgd2lkdGgpO1xufVxuZnVuY3Rpb24gZ2V0TG9jYWxlTnVtYmVyU3ltYm9sKGxvY2FsZSwgc3ltYm9sKSB7XG4gIGNvbnN0IGRhdGEgPSBfZmluZExvY2FsZURhdGEobG9jYWxlKTtcbiAgY29uc3QgcmVzID0gZGF0YVtfTG9jYWxlRGF0YUluZGV4Lk51bWJlclN5bWJvbHNdW3N5bWJvbF07XG4gIGlmICh0eXBlb2YgcmVzID09PSAndW5kZWZpbmVkJykge1xuICAgIGlmIChzeW1ib2wgPT09IE51bWJlclN5bWJvbC5DdXJyZW5jeURlY2ltYWwpIHtcbiAgICAgIHJldHVybiBkYXRhW19Mb2NhbGVEYXRhSW5kZXguTnVtYmVyU3ltYm9sc11bTnVtYmVyU3ltYm9sLkRlY2ltYWxdO1xuICAgIH0gZWxzZSBpZiAoc3ltYm9sID09PSBOdW1iZXJTeW1ib2wuQ3VycmVuY3lHcm91cCkge1xuICAgICAgcmV0dXJuIGRhdGFbX0xvY2FsZURhdGFJbmRleC5OdW1iZXJTeW1ib2xzXVtOdW1iZXJTeW1ib2wuR3JvdXBdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzO1xufVxuZnVuY3Rpb24gZ2V0TG9jYWxlTnVtYmVyRm9ybWF0KGxvY2FsZSwgdHlwZSkge1xuICBjb25zdCBkYXRhID0gX2ZpbmRMb2NhbGVEYXRhKGxvY2FsZSk7XG4gIHJldHVybiBkYXRhW19Mb2NhbGVEYXRhSW5kZXguTnVtYmVyRm9ybWF0c11bdHlwZV07XG59XG5mdW5jdGlvbiBnZXRMb2NhbGVDdXJyZW5jeVN5bWJvbChsb2NhbGUpIHtcbiAgY29uc3QgZGF0YSA9IF9maW5kTG9jYWxlRGF0YShsb2NhbGUpO1xuICByZXR1cm4gZGF0YVtfTG9jYWxlRGF0YUluZGV4LkN1cnJlbmN5U3ltYm9sXSB8fCBudWxsO1xufVxuZnVuY3Rpb24gZ2V0TG9jYWxlQ3VycmVuY3lOYW1lKGxvY2FsZSkge1xuICBjb25zdCBkYXRhID0gX2ZpbmRMb2NhbGVEYXRhKGxvY2FsZSk7XG4gIHJldHVybiBkYXRhW19Mb2NhbGVEYXRhSW5kZXguQ3VycmVuY3lOYW1lXSB8fCBudWxsO1xufVxuZnVuY3Rpb24gZ2V0TG9jYWxlQ3VycmVuY3lDb2RlKGxvY2FsZSkge1xuICByZXR1cm4gX2dldExvY2FsZUN1cnJlbmN5Q29kZShsb2NhbGUpO1xufVxuZnVuY3Rpb24gZ2V0TG9jYWxlQ3VycmVuY2llcyhsb2NhbGUpIHtcbiAgY29uc3QgZGF0YSA9IF9maW5kTG9jYWxlRGF0YShsb2NhbGUpO1xuICByZXR1cm4gZGF0YVtfTG9jYWxlRGF0YUluZGV4LkN1cnJlbmNpZXNdO1xufVxuY29uc3QgZ2V0TG9jYWxlUGx1cmFsQ2FzZSA9IF9nZXRMb2NhbGVQbHVyYWxDYXNlO1xuZnVuY3Rpb24gY2hlY2tGdWxsRGF0YShkYXRhKSB7XG4gIGlmICghZGF0YVtfTG9jYWxlRGF0YUluZGV4LkV4dHJhRGF0YV0pIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyMzAzLCBuZ0Rldk1vZGUgJiYgYE1pc3NpbmcgZXh0cmEgbG9jYWxlIGRhdGEgZm9yIHRoZSBsb2NhbGUgXCIke2RhdGFbX0xvY2FsZURhdGFJbmRleC5Mb2NhbGVJZF19XCIuIFVzZSBcInJlZ2lzdGVyTG9jYWxlRGF0YVwiIHRvIGxvYWQgbmV3IGRhdGEuIFNlZSB0aGUgXCJJMThuIGd1aWRlXCIgb24gYW5ndWxhci5pbyB0byBrbm93IG1vcmUuYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldExvY2FsZUV4dHJhRGF5UGVyaW9kUnVsZXMobG9jYWxlKSB7XG4gIGNvbnN0IGRhdGEgPSBfZmluZExvY2FsZURhdGEobG9jYWxlKTtcbiAgY2hlY2tGdWxsRGF0YShkYXRhKTtcbiAgY29uc3QgcnVsZXMgPSBkYXRhW19Mb2NhbGVEYXRhSW5kZXguRXh0cmFEYXRhXVsyXSB8fCBbXTtcbiAgcmV0dXJuIHJ1bGVzLm1hcChydWxlID0+IHtcbiAgICBpZiAodHlwZW9mIHJ1bGUgPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gZXh0cmFjdFRpbWUocnVsZSk7XG4gICAgfVxuICAgIHJldHVybiBbZXh0cmFjdFRpbWUocnVsZVswXSksIGV4dHJhY3RUaW1lKHJ1bGVbMV0pXTtcbiAgfSk7XG59XG5mdW5jdGlvbiBnZXRMb2NhbGVFeHRyYURheVBlcmlvZHMobG9jYWxlLCBmb3JtU3R5bGUsIHdpZHRoKSB7XG4gIGNvbnN0IGRhdGEgPSBfZmluZExvY2FsZURhdGEobG9jYWxlKTtcbiAgY2hlY2tGdWxsRGF0YShkYXRhKTtcbiAgY29uc3QgZGF5UGVyaW9kc0RhdGEgPSBbZGF0YVtfTG9jYWxlRGF0YUluZGV4LkV4dHJhRGF0YV1bMF0sIGRhdGFbX0xvY2FsZURhdGFJbmRleC5FeHRyYURhdGFdWzFdXTtcbiAgY29uc3QgZGF5UGVyaW9kcyA9IGdldExhc3REZWZpbmVkVmFsdWUoZGF5UGVyaW9kc0RhdGEsIGZvcm1TdHlsZSkgfHwgW107XG4gIHJldHVybiBnZXRMYXN0RGVmaW5lZFZhbHVlKGRheVBlcmlvZHMsIHdpZHRoKSB8fCBbXTtcbn1cbmZ1bmN0aW9uIGdldExvY2FsZURpcmVjdGlvbihsb2NhbGUpIHtcbiAgY29uc3QgZGF0YSA9IF9maW5kTG9jYWxlRGF0YShsb2NhbGUpO1xuICByZXR1cm4gZGF0YVtfTG9jYWxlRGF0YUluZGV4LkRpcmVjdGlvbmFsaXR5XTtcbn1cbmZ1bmN0aW9uIGdldExhc3REZWZpbmVkVmFsdWUoZGF0YSwgaW5kZXgpIHtcbiAgZm9yIChsZXQgaSA9IGluZGV4OyBpID4gLTE7IGktLSkge1xuICAgIGlmICh0eXBlb2YgZGF0YVtpXSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJldHVybiBkYXRhW2ldO1xuICAgIH1cbiAgfVxuICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyMzA0LCBuZ0Rldk1vZGUgJiYgJ0xvY2FsZSBkYXRhIEFQSTogbG9jYWxlIGRhdGEgdW5kZWZpbmVkJyk7XG59XG5mdW5jdGlvbiBleHRyYWN0VGltZSh0aW1lKSB7XG4gIGNvbnN0IFtoLCBtXSA9IHRpbWUuc3BsaXQoJzonKTtcbiAgcmV0dXJuIHtcbiAgICBob3VyczogK2gsXG4gICAgbWludXRlczogK21cbiAgfTtcbn1cbmZ1bmN0aW9uIGdldEN1cnJlbmN5U3ltYm9sKGNvZGUsIGZvcm1hdCwgbG9jYWxlID0gJ2VuJykge1xuICBjb25zdCBjdXJyZW5jeSA9IGdldExvY2FsZUN1cnJlbmNpZXMobG9jYWxlKVtjb2RlXSB8fCBDVVJSRU5DSUVTX0VOW2NvZGVdIHx8IFtdO1xuICBjb25zdCBzeW1ib2xOYXJyb3cgPSBjdXJyZW5jeVsxXTtcbiAgaWYgKGZvcm1hdCA9PT0gJ25hcnJvdycgJiYgdHlwZW9mIHN5bWJvbE5hcnJvdyA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gc3ltYm9sTmFycm93O1xuICB9XG4gIHJldHVybiBjdXJyZW5jeVswXSB8fCBjb2RlO1xufVxuY29uc3QgREVGQVVMVF9OQl9PRl9DVVJSRU5DWV9ESUdJVFMgPSAyO1xuZnVuY3Rpb24gZ2V0TnVtYmVyT2ZDdXJyZW5jeURpZ2l0cyhjb2RlKSB7XG4gIGxldCBkaWdpdHM7XG4gIGNvbnN0IGN1cnJlbmN5ID0gQ1VSUkVOQ0lFU19FTltjb2RlXTtcbiAgaWYgKGN1cnJlbmN5KSB7XG4gICAgZGlnaXRzID0gY3VycmVuY3lbMl07XG4gIH1cbiAgcmV0dXJuIHR5cGVvZiBkaWdpdHMgPT09ICdudW1iZXInID8gZGlnaXRzIDogREVGQVVMVF9OQl9PRl9DVVJSRU5DWV9ESUdJVFM7XG59XG5jb25zdCBJU084NjAxX0RBVEVfUkVHRVggPSAvXihcXGR7NCx9KS0/KFxcZFxcZCktPyhcXGRcXGQpKD86VChcXGRcXGQpKD86Oj8oXFxkXFxkKSg/Ojo/KFxcZFxcZCkoPzpcXC4oXFxkKykpPyk/KT8oWnwoWystXSkoXFxkXFxkKTo/KFxcZFxcZCkpPyk/JC87XG5jb25zdCBOQU1FRF9GT1JNQVRTID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbmNvbnN0IERBVEVfRk9STUFUU19TUExJVCA9IC8oKD86W15CRUdITE1PU1dZWmFiY2RobXN3eXonXSspfCg/OicoPzpbXiddfCcnKSonKXwoPzpHezEsNX18eXsxLDR9fFl7MSw0fXxNezEsNX18THsxLDV9fHd7MSwyfXxXezF9fGR7MSwyfXxFezEsNn18Y3sxLDZ9fGF7MSw1fXxiezEsNX18QnsxLDV9fGh7MSwyfXxIezEsMn18bXsxLDJ9fHN7MSwyfXxTezEsM318ensxLDR9fFp7MSw1fXxPezEsNH0pKShbXFxzXFxTXSopLztcbmNvbnN0IE1BWF9EQVRFX0ZPUk1BVF9MRU5HVEggPSAyNTY7XG5mdW5jdGlvbiBmb3JtYXREYXRlKHZhbHVlLCBmb3JtYXQsIGxvY2FsZSwgdGltZXpvbmUpIHtcbiAgbGV0IGRhdGUgPSB0b0RhdGUodmFsdWUpO1xuICBhc3NlcnRWYWxpZERhdGVGb3JtYXRMZW5ndGgoZm9ybWF0KTtcbiAgY29uc3QgbmFtZWRGb3JtYXQgPSBnZXROYW1lZEZvcm1hdChsb2NhbGUsIGZvcm1hdCk7XG4gIGZvcm1hdCA9IG5hbWVkRm9ybWF0IHx8IGZvcm1hdDtcbiAgbGV0IHBhcnRzID0gW107XG4gIGxldCBtYXRjaDtcbiAgd2hpbGUgKGZvcm1hdCkge1xuICAgIG1hdGNoID0gREFURV9GT1JNQVRTX1NQTElULmV4ZWMoZm9ybWF0KTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgIHBhcnRzID0gcGFydHMuY29uY2F0KG1hdGNoLnNsaWNlKDEpKTtcbiAgICAgIGNvbnN0IHBhcnQgPSBwYXJ0cy5wb3AoKTtcbiAgICAgIGlmICghcGFydCkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGZvcm1hdCA9IHBhcnQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhcnRzLnB1c2goZm9ybWF0KTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgYXNzZXJ0VmFsaWREYXRlRm9ybWF0KHBhcnRzKTtcbiAgfVxuICBsZXQgZGF0ZVRpbWV6b25lT2Zmc2V0ID0gZGF0ZS5nZXRUaW1lem9uZU9mZnNldCgpO1xuICBpZiAodGltZXpvbmUpIHtcbiAgICBkYXRlVGltZXpvbmVPZmZzZXQgPSB0aW1lem9uZVRvT2Zmc2V0KHRpbWV6b25lLCBkYXRlVGltZXpvbmVPZmZzZXQpO1xuICAgIGRhdGUgPSBjb252ZXJ0VGltZXpvbmVUb0xvY2FsKGRhdGUsIHRpbWV6b25lKTtcbiAgfVxuICBsZXQgdGV4dCA9ICcnO1xuICBwYXJ0cy5mb3JFYWNoKHZhbHVlID0+IHtcbiAgICBjb25zdCBkYXRlRm9ybWF0dGVyID0gZ2V0RGF0ZUZvcm1hdHRlcih2YWx1ZSk7XG4gICAgdGV4dCArPSBkYXRlRm9ybWF0dGVyID8gZGF0ZUZvcm1hdHRlcihkYXRlLCBsb2NhbGUsIGRhdGVUaW1lem9uZU9mZnNldCkgOiB2YWx1ZSA9PT0gXCInJ1wiID8gXCInXCIgOiB2YWx1ZS5yZXBsYWNlKC8oXid8JyQpL2csICcnKS5yZXBsYWNlKC8nJy9nLCBcIidcIik7XG4gIH0pO1xuICByZXR1cm4gdGV4dDtcbn1cbmZ1bmN0aW9uIGFzc2VydFZhbGlkRGF0ZUZvcm1hdExlbmd0aChmb3JtYXQpIHtcbiAgaWYgKGZvcm1hdC5sZW5ndGggPiBNQVhfREFURV9GT1JNQVRfTEVOR1RIKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMwMCwgbmdEZXZNb2RlICYmIGBEYXRlIGZvcm1hdCBpcyB0b28gbG9uZy4gRXhjZWVkZWQgbWF4aW11bSBsZW5ndGggb2YgJHtNQVhfREFURV9GT1JNQVRfTEVOR1RIfSBjaGFyYWN0ZXJzLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRWYWxpZERhdGVGb3JtYXQocGFydHMpIHtcbiAgaWYgKHBhcnRzLnNvbWUocGFydCA9PiAvXlkrJC8udGVzdChwYXJ0KSkgJiYgIXBhcnRzLnNvbWUocGFydCA9PiAvXncrJC8udGVzdChwYXJ0KSkpIHtcbiAgICBjb25zdCBtZXNzYWdlID0gYFN1c3BpY2lvdXMgdXNlIG9mIHdlZWstYmFzZWQgeWVhciBcIllcIiBpbiBkYXRlIHBhdHRlcm4gXCIke3BhcnRzLmpvaW4oJycpfVwiLiBEaWQgeW91IG1lYW4gdG8gdXNlIGNhbGVuZGFyIHllYXIgXCJ5XCIgaW5zdGVhZD9gO1xuICAgIGlmIChwYXJ0cy5sZW5ndGggPT09IDEpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoX2Zvcm1hdFJ1bnRpbWVFcnJvcigyMzAwLCBtZXNzYWdlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDIzMDAsIG1lc3NhZ2UpO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gY3JlYXRlRGF0ZSh5ZWFyLCBtb250aCwgZGF0ZSkge1xuICBjb25zdCBuZXdEYXRlID0gbmV3IERhdGUoMCk7XG4gIG5ld0RhdGUuc2V0RnVsbFllYXIoeWVhciwgbW9udGgsIGRhdGUpO1xuICBuZXdEYXRlLnNldEhvdXJzKDAsIDAsIDApO1xuICByZXR1cm4gbmV3RGF0ZTtcbn1cbmZ1bmN0aW9uIGdldE5hbWVkRm9ybWF0KGxvY2FsZSwgZm9ybWF0KSB7XG4gIGNvbnN0IGxvY2FsZUlkID0gZ2V0TG9jYWxlSWQobG9jYWxlKTtcbiAgTkFNRURfRk9STUFUU1tsb2NhbGVJZF0gPz89IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGlmIChOQU1FRF9GT1JNQVRTW2xvY2FsZUlkXVtmb3JtYXRdKSB7XG4gICAgcmV0dXJuIE5BTUVEX0ZPUk1BVFNbbG9jYWxlSWRdW2Zvcm1hdF07XG4gIH1cbiAgbGV0IGZvcm1hdFZhbHVlID0gJyc7XG4gIHN3aXRjaCAoZm9ybWF0KSB7XG4gICAgY2FzZSAnc2hvcnREYXRlJzpcbiAgICAgIGZvcm1hdFZhbHVlID0gZ2V0TG9jYWxlRGF0ZUZvcm1hdChsb2NhbGUsIEZvcm1hdFdpZHRoLlNob3J0KTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ21lZGl1bURhdGUnOlxuICAgICAgZm9ybWF0VmFsdWUgPSBnZXRMb2NhbGVEYXRlRm9ybWF0KGxvY2FsZSwgRm9ybWF0V2lkdGguTWVkaXVtKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2xvbmdEYXRlJzpcbiAgICAgIGZvcm1hdFZhbHVlID0gZ2V0TG9jYWxlRGF0ZUZvcm1hdChsb2NhbGUsIEZvcm1hdFdpZHRoLkxvbmcpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnZnVsbERhdGUnOlxuICAgICAgZm9ybWF0VmFsdWUgPSBnZXRMb2NhbGVEYXRlRm9ybWF0KGxvY2FsZSwgRm9ybWF0V2lkdGguRnVsbCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdzaG9ydFRpbWUnOlxuICAgICAgZm9ybWF0VmFsdWUgPSBnZXRMb2NhbGVUaW1lRm9ybWF0KGxvY2FsZSwgRm9ybWF0V2lkdGguU2hvcnQpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbWVkaXVtVGltZSc6XG4gICAgICBmb3JtYXRWYWx1ZSA9IGdldExvY2FsZVRpbWVGb3JtYXQobG9jYWxlLCBGb3JtYXRXaWR0aC5NZWRpdW0pO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbG9uZ1RpbWUnOlxuICAgICAgZm9ybWF0VmFsdWUgPSBnZXRMb2NhbGVUaW1lRm9ybWF0KGxvY2FsZSwgRm9ybWF0V2lkdGguTG9uZyk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdmdWxsVGltZSc6XG4gICAgICBmb3JtYXRWYWx1ZSA9IGdldExvY2FsZVRpbWVGb3JtYXQobG9jYWxlLCBGb3JtYXRXaWR0aC5GdWxsKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3Nob3J0JzpcbiAgICAgIGNvbnN0IHNob3J0VGltZSA9IGdldE5hbWVkRm9ybWF0KGxvY2FsZSwgJ3Nob3J0VGltZScpO1xuICAgICAgY29uc3Qgc2hvcnREYXRlID0gZ2V0TmFtZWRGb3JtYXQobG9jYWxlLCAnc2hvcnREYXRlJyk7XG4gICAgICBmb3JtYXRWYWx1ZSA9IGZvcm1hdERhdGVUaW1lKGdldExvY2FsZURhdGVUaW1lRm9ybWF0KGxvY2FsZSwgRm9ybWF0V2lkdGguU2hvcnQpLCBbc2hvcnRUaW1lLCBzaG9ydERhdGVdKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ21lZGl1bSc6XG4gICAgICBjb25zdCBtZWRpdW1UaW1lID0gZ2V0TmFtZWRGb3JtYXQobG9jYWxlLCAnbWVkaXVtVGltZScpO1xuICAgICAgY29uc3QgbWVkaXVtRGF0ZSA9IGdldE5hbWVkRm9ybWF0KGxvY2FsZSwgJ21lZGl1bURhdGUnKTtcbiAgICAgIGZvcm1hdFZhbHVlID0gZm9ybWF0RGF0ZVRpbWUoZ2V0TG9jYWxlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBGb3JtYXRXaWR0aC5NZWRpdW0pLCBbbWVkaXVtVGltZSwgbWVkaXVtRGF0ZV0pO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbG9uZyc6XG4gICAgICBjb25zdCBsb25nVGltZSA9IGdldE5hbWVkRm9ybWF0KGxvY2FsZSwgJ2xvbmdUaW1lJyk7XG4gICAgICBjb25zdCBsb25nRGF0ZSA9IGdldE5hbWVkRm9ybWF0KGxvY2FsZSwgJ2xvbmdEYXRlJyk7XG4gICAgICBmb3JtYXRWYWx1ZSA9IGZvcm1hdERhdGVUaW1lKGdldExvY2FsZURhdGVUaW1lRm9ybWF0KGxvY2FsZSwgRm9ybWF0V2lkdGguTG9uZyksIFtsb25nVGltZSwgbG9uZ0RhdGVdKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2Z1bGwnOlxuICAgICAgY29uc3QgZnVsbFRpbWUgPSBnZXROYW1lZEZvcm1hdChsb2NhbGUsICdmdWxsVGltZScpO1xuICAgICAgY29uc3QgZnVsbERhdGUgPSBnZXROYW1lZEZvcm1hdChsb2NhbGUsICdmdWxsRGF0ZScpO1xuICAgICAgZm9ybWF0VmFsdWUgPSBmb3JtYXREYXRlVGltZShnZXRMb2NhbGVEYXRlVGltZUZvcm1hdChsb2NhbGUsIEZvcm1hdFdpZHRoLkZ1bGwpLCBbZnVsbFRpbWUsIGZ1bGxEYXRlXSk7XG4gICAgICBicmVhaztcbiAgfVxuICBpZiAoZm9ybWF0VmFsdWUpIHtcbiAgICBOQU1FRF9GT1JNQVRTW2xvY2FsZUlkXVtmb3JtYXRdID0gZm9ybWF0VmFsdWU7XG4gIH1cbiAgcmV0dXJuIGZvcm1hdFZhbHVlO1xufVxuZnVuY3Rpb24gZm9ybWF0RGF0ZVRpbWUoc3RyLCBvcHRfdmFsdWVzKSB7XG4gIGlmIChvcHRfdmFsdWVzKSB7XG4gICAgc3RyID0gc3RyLnJlcGxhY2UoL1xceyhbXn1dKyl9L2csIGZ1bmN0aW9uIChtYXRjaCwga2V5KSB7XG4gICAgICByZXR1cm4gT2JqZWN0Lmhhc093bihvcHRfdmFsdWVzLCBrZXkpID8gb3B0X3ZhbHVlc1trZXldIDogbWF0Y2g7XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHN0cjtcbn1cbmZ1bmN0aW9uIHBhZE51bWJlcihudW0sIGRpZ2l0cywgbWludXNTaWduID0gJy0nLCB0cmltLCBuZWdXcmFwKSB7XG4gIGxldCBuZWcgPSAnJztcbiAgaWYgKG51bSA8IDAgfHwgbmVnV3JhcCAmJiBudW0gPD0gMCkge1xuICAgIGlmIChuZWdXcmFwKSB7XG4gICAgICBudW0gPSAtbnVtICsgMTtcbiAgICB9IGVsc2Uge1xuICAgICAgbnVtID0gLW51bTtcbiAgICAgIG5lZyA9IG1pbnVzU2lnbjtcbiAgICB9XG4gIH1cbiAgbGV0IHN0ck51bSA9IFN0cmluZyhudW0pO1xuICB3aGlsZSAoc3RyTnVtLmxlbmd0aCA8IGRpZ2l0cykge1xuICAgIHN0ck51bSA9ICcwJyArIHN0ck51bTtcbiAgfVxuICBpZiAodHJpbSkge1xuICAgIHN0ck51bSA9IHN0ck51bS5zbGljZShzdHJOdW0ubGVuZ3RoIC0gZGlnaXRzKTtcbiAgfVxuICByZXR1cm4gbmVnICsgc3RyTnVtO1xufVxuZnVuY3Rpb24gZm9ybWF0RnJhY3Rpb25hbFNlY29uZHMobWlsbGlzZWNvbmRzLCBkaWdpdHMpIHtcbiAgY29uc3Qgc3RyTXMgPSBwYWROdW1iZXIobWlsbGlzZWNvbmRzLCAzKTtcbiAgcmV0dXJuIHN0ck1zLnN1YnN0cmluZygwLCBkaWdpdHMpO1xufVxuZnVuY3Rpb24gZGF0ZUdldHRlcihuYW1lLCBzaXplLCBvZmZzZXQgPSAwLCB0cmltID0gZmFsc2UsIG5lZ1dyYXAgPSBmYWxzZSkge1xuICByZXR1cm4gZnVuY3Rpb24gKGRhdGUsIGxvY2FsZSkge1xuICAgIGxldCBwYXJ0ID0gZ2V0RGF0ZVBhcnQobmFtZSwgZGF0ZSk7XG4gICAgaWYgKG9mZnNldCA+IDAgfHwgcGFydCA+IC1vZmZzZXQpIHtcbiAgICAgIHBhcnQgKz0gb2Zmc2V0O1xuICAgIH1cbiAgICBpZiAobmFtZSA9PT0gMykge1xuICAgICAgaWYgKHBhcnQgPT09IDAgJiYgb2Zmc2V0ID09PSAtMTIpIHtcbiAgICAgICAgcGFydCA9IDEyO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gNikge1xuICAgICAgcmV0dXJuIGZvcm1hdEZyYWN0aW9uYWxTZWNvbmRzKHBhcnQsIHNpemUpO1xuICAgIH1cbiAgICBjb25zdCBsb2NhbGVNaW51cyA9IGdldExvY2FsZU51bWJlclN5bWJvbChsb2NhbGUsIE51bWJlclN5bWJvbC5NaW51c1NpZ24pO1xuICAgIHJldHVybiBwYWROdW1iZXIocGFydCwgc2l6ZSwgbG9jYWxlTWludXMsIHRyaW0sIG5lZ1dyYXApO1xuICB9O1xufVxuZnVuY3Rpb24gZ2V0RGF0ZVBhcnQocGFydCwgZGF0ZSkge1xuICBzd2l0Y2ggKHBhcnQpIHtcbiAgICBjYXNlIDA6XG4gICAgICByZXR1cm4gZGF0ZS5nZXRGdWxsWWVhcigpO1xuICAgIGNhc2UgMTpcbiAgICAgIHJldHVybiBkYXRlLmdldE1vbnRoKCk7XG4gICAgY2FzZSAyOlxuICAgICAgcmV0dXJuIGRhdGUuZ2V0RGF0ZSgpO1xuICAgIGNhc2UgMzpcbiAgICAgIHJldHVybiBkYXRlLmdldEhvdXJzKCk7XG4gICAgY2FzZSA0OlxuICAgICAgcmV0dXJuIGRhdGUuZ2V0TWludXRlcygpO1xuICAgIGNhc2UgNTpcbiAgICAgIHJldHVybiBkYXRlLmdldFNlY29uZHMoKTtcbiAgICBjYXNlIDY6XG4gICAgICByZXR1cm4gZGF0ZS5nZXRNaWxsaXNlY29uZHMoKTtcbiAgICBjYXNlIDc6XG4gICAgICByZXR1cm4gZGF0ZS5nZXREYXkoKTtcbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMwMSwgbmdEZXZNb2RlICYmIGBVbmtub3duIERhdGVUeXBlIHZhbHVlIFwiJHtwYXJ0fVwiLmApO1xuICB9XG59XG5mdW5jdGlvbiBkYXRlU3RyR2V0dGVyKG5hbWUsIHdpZHRoLCBmb3JtID0gRm9ybVN0eWxlLkZvcm1hdCwgZXh0ZW5kZWQgPSBmYWxzZSkge1xuICByZXR1cm4gZnVuY3Rpb24gKGRhdGUsIGxvY2FsZSkge1xuICAgIHJldHVybiBnZXREYXRlVHJhbnNsYXRpb24oZGF0ZSwgbG9jYWxlLCBuYW1lLCB3aWR0aCwgZm9ybSwgZXh0ZW5kZWQpO1xuICB9O1xufVxuZnVuY3Rpb24gZ2V0RGF0ZVRyYW5zbGF0aW9uKGRhdGUsIGxvY2FsZSwgbmFtZSwgd2lkdGgsIGZvcm0sIGV4dGVuZGVkKSB7XG4gIHN3aXRjaCAobmFtZSkge1xuICAgIGNhc2UgMjpcbiAgICAgIHJldHVybiBnZXRMb2NhbGVNb250aE5hbWVzKGxvY2FsZSwgZm9ybSwgd2lkdGgpW2RhdGUuZ2V0TW9udGgoKV07XG4gICAgY2FzZSAxOlxuICAgICAgcmV0dXJuIGdldExvY2FsZURheU5hbWVzKGxvY2FsZSwgZm9ybSwgd2lkdGgpW2RhdGUuZ2V0RGF5KCldO1xuICAgIGNhc2UgMDpcbiAgICAgIGNvbnN0IGN1cnJlbnRIb3VycyA9IGRhdGUuZ2V0SG91cnMoKTtcbiAgICAgIGNvbnN0IGN1cnJlbnRNaW51dGVzID0gZGF0ZS5nZXRNaW51dGVzKCk7XG4gICAgICBpZiAoZXh0ZW5kZWQpIHtcbiAgICAgICAgY29uc3QgcnVsZXMgPSBnZXRMb2NhbGVFeHRyYURheVBlcmlvZFJ1bGVzKGxvY2FsZSk7XG4gICAgICAgIGNvbnN0IGRheVBlcmlvZHMgPSBnZXRMb2NhbGVFeHRyYURheVBlcmlvZHMobG9jYWxlLCBmb3JtLCB3aWR0aCk7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gcnVsZXMuZmluZEluZGV4KHJ1bGUgPT4ge1xuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHJ1bGUpKSB7XG4gICAgICAgICAgICBjb25zdCBbZnJvbSwgdG9dID0gcnVsZTtcbiAgICAgICAgICAgIGNvbnN0IGFmdGVyRnJvbSA9IGN1cnJlbnRIb3VycyA+PSBmcm9tLmhvdXJzICYmIGN1cnJlbnRNaW51dGVzID49IGZyb20ubWludXRlcztcbiAgICAgICAgICAgIGNvbnN0IGJlZm9yZVRvID0gY3VycmVudEhvdXJzIDwgdG8uaG91cnMgfHwgY3VycmVudEhvdXJzID09PSB0by5ob3VycyAmJiBjdXJyZW50TWludXRlcyA8IHRvLm1pbnV0ZXM7XG4gICAgICAgICAgICBpZiAoZnJvbS5ob3VycyA8IHRvLmhvdXJzKSB7XG4gICAgICAgICAgICAgIGlmIChhZnRlckZyb20gJiYgYmVmb3JlVG8pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChhZnRlckZyb20gfHwgYmVmb3JlVG8pIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmIChydWxlLmhvdXJzID09PSBjdXJyZW50SG91cnMgJiYgcnVsZS5taW51dGVzID09PSBjdXJyZW50TWludXRlcykge1xuICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgICAgIHJldHVybiBkYXlQZXJpb2RzW2luZGV4XTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGdldExvY2FsZURheVBlcmlvZHMobG9jYWxlLCBmb3JtLCB3aWR0aClbY3VycmVudEhvdXJzIDwgMTIgPyAwIDogMV07XG4gICAgY2FzZSAzOlxuICAgICAgcmV0dXJuIGdldExvY2FsZUVyYU5hbWVzKGxvY2FsZSwgd2lkdGgpW2RhdGUuZ2V0RnVsbFllYXIoKSA8PSAwID8gMCA6IDFdO1xuICAgIGRlZmF1bHQ6XG4gICAgICBjb25zdCB1bmV4cGVjdGVkID0gbmFtZTtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDIzMDIsIG5nRGV2TW9kZSAmJiBgdW5leHBlY3RlZCB0cmFuc2xhdGlvbiB0eXBlICR7dW5leHBlY3RlZH1gKTtcbiAgfVxufVxuZnVuY3Rpb24gdGltZVpvbmVHZXR0ZXIod2lkdGgpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIChkYXRlLCBsb2NhbGUsIG9mZnNldCkge1xuICAgIGNvbnN0IHpvbmUgPSAtMSAqIG9mZnNldDtcbiAgICBjb25zdCBtaW51c1NpZ24gPSBnZXRMb2NhbGVOdW1iZXJTeW1ib2wobG9jYWxlLCBOdW1iZXJTeW1ib2wuTWludXNTaWduKTtcbiAgICBjb25zdCBob3VycyA9IHpvbmUgPiAwID8gTWF0aC5mbG9vcih6b25lIC8gNjApIDogTWF0aC5jZWlsKHpvbmUgLyA2MCk7XG4gICAgc3dpdGNoICh3aWR0aCkge1xuICAgICAgY2FzZSAwOlxuICAgICAgICByZXR1cm4gKHpvbmUgPj0gMCA/ICcrJyA6ICcnKSArIHBhZE51bWJlcihob3VycywgMiwgbWludXNTaWduKSArIHBhZE51bWJlcihNYXRoLmFicyh6b25lICUgNjApLCAyLCBtaW51c1NpZ24pO1xuICAgICAgY2FzZSAxOlxuICAgICAgICByZXR1cm4gJ0dNVCcgKyAoem9uZSA+PSAwID8gJysnIDogJycpICsgcGFkTnVtYmVyKGhvdXJzLCAxLCBtaW51c1NpZ24pO1xuICAgICAgY2FzZSAyOlxuICAgICAgICByZXR1cm4gJ0dNVCcgKyAoem9uZSA+PSAwID8gJysnIDogJycpICsgcGFkTnVtYmVyKGhvdXJzLCAyLCBtaW51c1NpZ24pICsgJzonICsgcGFkTnVtYmVyKE1hdGguYWJzKHpvbmUgJSA2MCksIDIsIG1pbnVzU2lnbik7XG4gICAgICBjYXNlIDM6XG4gICAgICAgIGlmIChvZmZzZXQgPT09IDApIHtcbiAgICAgICAgICByZXR1cm4gJ1onO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiAoem9uZSA+PSAwID8gJysnIDogJycpICsgcGFkTnVtYmVyKGhvdXJzLCAyLCBtaW51c1NpZ24pICsgJzonICsgcGFkTnVtYmVyKE1hdGguYWJzKHpvbmUgJSA2MCksIDIsIG1pbnVzU2lnbik7XG4gICAgICAgIH1cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDIzMTAsIG5nRGV2TW9kZSAmJiBgVW5rbm93biB6b25lIHdpZHRoIFwiJHt3aWR0aH1cImApO1xuICAgIH1cbiAgfTtcbn1cbmNvbnN0IEpBTlVBUlkgPSAwO1xuY29uc3QgVEhVUlNEQVkgPSA0O1xuZnVuY3Rpb24gZ2V0Rmlyc3RUaHVyc2RheU9mWWVhcih5ZWFyKSB7XG4gIGNvbnN0IGZpcnN0RGF5T2ZZZWFyID0gY3JlYXRlRGF0ZSh5ZWFyLCBKQU5VQVJZLCAxKS5nZXREYXkoKTtcbiAgcmV0dXJuIGNyZWF0ZURhdGUoeWVhciwgMCwgMSArIChmaXJzdERheU9mWWVhciA8PSBUSFVSU0RBWSA/IFRIVVJTREFZIDogVEhVUlNEQVkgKyA3KSAtIGZpcnN0RGF5T2ZZZWFyKTtcbn1cbmZ1bmN0aW9uIGdldFRodXJzZGF5VGhpc0lzb1dlZWsoZGF0ZXRpbWUpIHtcbiAgY29uc3QgY3VycmVudERheSA9IGRhdGV0aW1lLmdldERheSgpO1xuICBjb25zdCBkZWx0YVRvVGh1cnNkYXkgPSBjdXJyZW50RGF5ID09PSAwID8gLTMgOiBUSFVSU0RBWSAtIGN1cnJlbnREYXk7XG4gIHJldHVybiBjcmVhdGVEYXRlKGRhdGV0aW1lLmdldEZ1bGxZZWFyKCksIGRhdGV0aW1lLmdldE1vbnRoKCksIGRhdGV0aW1lLmdldERhdGUoKSArIGRlbHRhVG9UaHVyc2RheSk7XG59XG5mdW5jdGlvbiB3ZWVrR2V0dGVyKHNpemUsIG1vbnRoQmFzZWQgPSBmYWxzZSkge1xuICByZXR1cm4gZnVuY3Rpb24gKGRhdGUsIGxvY2FsZSkge1xuICAgIGxldCByZXN1bHQ7XG4gICAgaWYgKG1vbnRoQmFzZWQpIHtcbiAgICAgIGNvbnN0IG5iRGF5c0JlZm9yZTFzdERheU9mTW9udGggPSBuZXcgRGF0ZShkYXRlLmdldEZ1bGxZZWFyKCksIGRhdGUuZ2V0TW9udGgoKSwgMSkuZ2V0RGF5KCkgLSAxO1xuICAgICAgY29uc3QgdG9kYXkgPSBkYXRlLmdldERhdGUoKTtcbiAgICAgIHJlc3VsdCA9IDEgKyBNYXRoLmZsb29yKCh0b2RheSArIG5iRGF5c0JlZm9yZTFzdERheU9mTW9udGgpIC8gNyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHRoaXNUaHVycyA9IGdldFRodXJzZGF5VGhpc0lzb1dlZWsoZGF0ZSk7XG4gICAgICBjb25zdCBmaXJzdFRodXJzID0gZ2V0Rmlyc3RUaHVyc2RheU9mWWVhcih0aGlzVGh1cnMuZ2V0RnVsbFllYXIoKSk7XG4gICAgICBjb25zdCBkaWZmID0gdGhpc1RodXJzLmdldFRpbWUoKSAtIGZpcnN0VGh1cnMuZ2V0VGltZSgpO1xuICAgICAgcmVzdWx0ID0gMSArIE1hdGgucm91bmQoZGlmZiAvIDYuMDQ4ZTgpO1xuICAgIH1cbiAgICByZXR1cm4gcGFkTnVtYmVyKHJlc3VsdCwgc2l6ZSwgZ2V0TG9jYWxlTnVtYmVyU3ltYm9sKGxvY2FsZSwgTnVtYmVyU3ltYm9sLk1pbnVzU2lnbikpO1xuICB9O1xufVxuZnVuY3Rpb24gd2Vla051bWJlcmluZ1llYXJHZXR0ZXIoc2l6ZSwgdHJpbSA9IGZhbHNlKSB7XG4gIHJldHVybiBmdW5jdGlvbiAoZGF0ZSwgbG9jYWxlKSB7XG4gICAgY29uc3QgdGhpc1RodXJzID0gZ2V0VGh1cnNkYXlUaGlzSXNvV2VlayhkYXRlKTtcbiAgICBjb25zdCB3ZWVrTnVtYmVyaW5nWWVhciA9IHRoaXNUaHVycy5nZXRGdWxsWWVhcigpO1xuICAgIHJldHVybiBwYWROdW1iZXIod2Vla051bWJlcmluZ1llYXIsIHNpemUsIGdldExvY2FsZU51bWJlclN5bWJvbChsb2NhbGUsIE51bWJlclN5bWJvbC5NaW51c1NpZ24pLCB0cmltKTtcbiAgfTtcbn1cbmNvbnN0IERBVEVfRk9STUFUUyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5mdW5jdGlvbiBnZXREYXRlRm9ybWF0dGVyKGZvcm1hdCkge1xuICBpZiAoREFURV9GT1JNQVRTW2Zvcm1hdF0pIHtcbiAgICByZXR1cm4gREFURV9GT1JNQVRTW2Zvcm1hdF07XG4gIH1cbiAgbGV0IGZvcm1hdHRlcjtcbiAgc3dpdGNoIChmb3JtYXQpIHtcbiAgICBjYXNlICdHJzpcbiAgICBjYXNlICdHRyc6XG4gICAgY2FzZSAnR0dHJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMywgVHJhbnNsYXRpb25XaWR0aC5BYmJyZXZpYXRlZCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdHR0dHJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMywgVHJhbnNsYXRpb25XaWR0aC5XaWRlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ0dHR0dHJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMywgVHJhbnNsYXRpb25XaWR0aC5OYXJyb3cpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAneSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDAsIDEsIDAsIGZhbHNlLCB0cnVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3l5JzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoMCwgMiwgMCwgdHJ1ZSwgdHJ1ZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICd5eXknOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZUdldHRlcigwLCAzLCAwLCBmYWxzZSwgdHJ1ZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICd5eXl5JzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoMCwgNCwgMCwgZmFsc2UsIHRydWUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnWSc6XG4gICAgICBmb3JtYXR0ZXIgPSB3ZWVrTnVtYmVyaW5nWWVhckdldHRlcigxKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ1lZJzpcbiAgICAgIGZvcm1hdHRlciA9IHdlZWtOdW1iZXJpbmdZZWFyR2V0dGVyKDIsIHRydWUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnWVlZJzpcbiAgICAgIGZvcm1hdHRlciA9IHdlZWtOdW1iZXJpbmdZZWFyR2V0dGVyKDMpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnWVlZWSc6XG4gICAgICBmb3JtYXR0ZXIgPSB3ZWVrTnVtYmVyaW5nWWVhckdldHRlcig0KTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ00nOlxuICAgIGNhc2UgJ0wnOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZUdldHRlcigxLCAxLCAxKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ01NJzpcbiAgICBjYXNlICdMTCc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDEsIDIsIDEpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnTU1NJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMiwgVHJhbnNsYXRpb25XaWR0aC5BYmJyZXZpYXRlZCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdNTU1NJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMiwgVHJhbnNsYXRpb25XaWR0aC5XaWRlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ01NTU1NJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMiwgVHJhbnNsYXRpb25XaWR0aC5OYXJyb3cpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnTExMJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMiwgVHJhbnNsYXRpb25XaWR0aC5BYmJyZXZpYXRlZCwgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnTExMTCc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDIsIFRyYW5zbGF0aW9uV2lkdGguV2lkZSwgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnTExMTEwnOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZVN0ckdldHRlcigyLCBUcmFuc2xhdGlvbldpZHRoLk5hcnJvdywgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAndyc6XG4gICAgICBmb3JtYXR0ZXIgPSB3ZWVrR2V0dGVyKDEpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnd3cnOlxuICAgICAgZm9ybWF0dGVyID0gd2Vla0dldHRlcigyKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ1cnOlxuICAgICAgZm9ybWF0dGVyID0gd2Vla0dldHRlcigxLCB0cnVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2QnOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZUdldHRlcigyLCAxKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2RkJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoMiwgMik7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdjJzpcbiAgICBjYXNlICdjYyc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDcsIDEpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2NjJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMSwgVHJhbnNsYXRpb25XaWR0aC5BYmJyZXZpYXRlZCwgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2NjYyc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDEsIFRyYW5zbGF0aW9uV2lkdGguV2lkZSwgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2NjY2MnOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZVN0ckdldHRlcigxLCBUcmFuc2xhdGlvbldpZHRoLk5hcnJvdywgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnY2NjY2NjJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMSwgVHJhbnNsYXRpb25XaWR0aC5TaG9ydCwgRm9ybVN0eWxlLlN0YW5kYWxvbmUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnRSc6XG4gICAgY2FzZSAnRUUnOlxuICAgIGNhc2UgJ0VFRSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDEsIFRyYW5zbGF0aW9uV2lkdGguQWJicmV2aWF0ZWQpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnRUVFRSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDEsIFRyYW5zbGF0aW9uV2lkdGguV2lkZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdFRUVFRSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDEsIFRyYW5zbGF0aW9uV2lkdGguTmFycm93KTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ0VFRUVFRSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDEsIFRyYW5zbGF0aW9uV2lkdGguU2hvcnQpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnYSc6XG4gICAgY2FzZSAnYWEnOlxuICAgIGNhc2UgJ2FhYSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDAsIFRyYW5zbGF0aW9uV2lkdGguQWJicmV2aWF0ZWQpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnYWFhYSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDAsIFRyYW5zbGF0aW9uV2lkdGguV2lkZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdhYWFhYSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDAsIFRyYW5zbGF0aW9uV2lkdGguTmFycm93KTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2InOlxuICAgIGNhc2UgJ2JiJzpcbiAgICBjYXNlICdiYmInOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZVN0ckdldHRlcigwLCBUcmFuc2xhdGlvbldpZHRoLkFiYnJldmlhdGVkLCBGb3JtU3R5bGUuU3RhbmRhbG9uZSwgdHJ1ZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdiYmJiJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMCwgVHJhbnNsYXRpb25XaWR0aC5XaWRlLCBGb3JtU3R5bGUuU3RhbmRhbG9uZSwgdHJ1ZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdiYmJiYic6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlU3RyR2V0dGVyKDAsIFRyYW5zbGF0aW9uV2lkdGguTmFycm93LCBGb3JtU3R5bGUuU3RhbmRhbG9uZSwgdHJ1ZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdCJzpcbiAgICBjYXNlICdCQic6XG4gICAgY2FzZSAnQkJCJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMCwgVHJhbnNsYXRpb25XaWR0aC5BYmJyZXZpYXRlZCwgRm9ybVN0eWxlLkZvcm1hdCwgdHJ1ZSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdCQkJCJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMCwgVHJhbnNsYXRpb25XaWR0aC5XaWRlLCBGb3JtU3R5bGUuRm9ybWF0LCB0cnVlKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ0JCQkJCJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVTdHJHZXR0ZXIoMCwgVHJhbnNsYXRpb25XaWR0aC5OYXJyb3csIEZvcm1TdHlsZS5Gb3JtYXQsIHRydWUpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnaCc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDMsIDEsIC0xMik7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdoaCc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDMsIDIsIC0xMik7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdIJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoMywgMSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdISCc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDMsIDIpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbSc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDQsIDEpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnbW0nOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZUdldHRlcig0LCAyKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3MnOlxuICAgICAgZm9ybWF0dGVyID0gZGF0ZUdldHRlcig1LCAxKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ3NzJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoNSwgMik7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdTJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoNiwgMSk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdTUyc6XG4gICAgICBmb3JtYXR0ZXIgPSBkYXRlR2V0dGVyKDYsIDIpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnU1NTJzpcbiAgICAgIGZvcm1hdHRlciA9IGRhdGVHZXR0ZXIoNiwgMyk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdaJzpcbiAgICBjYXNlICdaWic6XG4gICAgY2FzZSAnWlpaJzpcbiAgICAgIGZvcm1hdHRlciA9IHRpbWVab25lR2V0dGVyKDApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnWlpaWlonOlxuICAgICAgZm9ybWF0dGVyID0gdGltZVpvbmVHZXR0ZXIoMyk7XG4gICAgICBicmVhaztcbiAgICBjYXNlICdPJzpcbiAgICBjYXNlICdPTyc6XG4gICAgY2FzZSAnT09PJzpcbiAgICBjYXNlICd6JzpcbiAgICBjYXNlICd6eic6XG4gICAgY2FzZSAnenp6JzpcbiAgICAgIGZvcm1hdHRlciA9IHRpbWVab25lR2V0dGVyKDEpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnT09PTyc6XG4gICAgY2FzZSAnWlpaWic6XG4gICAgY2FzZSAnenp6eic6XG4gICAgICBmb3JtYXR0ZXIgPSB0aW1lWm9uZUdldHRlcigyKTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBEQVRFX0ZPUk1BVFNbZm9ybWF0XSA9IGZvcm1hdHRlcjtcbiAgcmV0dXJuIGZvcm1hdHRlcjtcbn1cbmZ1bmN0aW9uIHRpbWV6b25lVG9PZmZzZXQodGltZXpvbmUsIGZhbGxiYWNrKSB7XG4gIHRpbWV6b25lID0gdGltZXpvbmUucmVwbGFjZSgvOi9nLCAnJyk7XG4gIGNvbnN0IHJlcXVlc3RlZFRpbWV6b25lT2Zmc2V0ID0gRGF0ZS5wYXJzZSgnSmFuIDAxLCAxOTcwIDAwOjAwOjAwICcgKyB0aW1lem9uZSkgLyA2MDAwMDtcbiAgcmV0dXJuIGlzTmFOKHJlcXVlc3RlZFRpbWV6b25lT2Zmc2V0KSA/IGZhbGxiYWNrIDogcmVxdWVzdGVkVGltZXpvbmVPZmZzZXQ7XG59XG5mdW5jdGlvbiBhZGREYXRlTWludXRlcyhkYXRlLCBtaW51dGVzKSB7XG4gIGRhdGUgPSBuZXcgRGF0ZShkYXRlLmdldFRpbWUoKSk7XG4gIGRhdGUuc2V0TWludXRlcyhkYXRlLmdldE1pbnV0ZXMoKSArIG1pbnV0ZXMpO1xuICByZXR1cm4gZGF0ZTtcbn1cbmZ1bmN0aW9uIGNvbnZlcnRUaW1lem9uZVRvTG9jYWwoZGF0ZSwgdGltZXpvbmUsIHJldmVyc2UpIHtcbiAgY29uc3QgcmV2ZXJzZVZhbHVlID0gLTE7XG4gIGNvbnN0IGRhdGVUaW1lem9uZU9mZnNldCA9IGRhdGUuZ2V0VGltZXpvbmVPZmZzZXQoKTtcbiAgY29uc3QgdGltZXpvbmVPZmZzZXQgPSB0aW1lem9uZVRvT2Zmc2V0KHRpbWV6b25lLCBkYXRlVGltZXpvbmVPZmZzZXQpO1xuICByZXR1cm4gYWRkRGF0ZU1pbnV0ZXMoZGF0ZSwgcmV2ZXJzZVZhbHVlICogKHRpbWV6b25lT2Zmc2V0IC0gZGF0ZVRpbWV6b25lT2Zmc2V0KSk7XG59XG5mdW5jdGlvbiB0b0RhdGUodmFsdWUpIHtcbiAgaWYgKGlzRGF0ZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgJiYgIWlzTmFOKHZhbHVlKSkge1xuICAgIHJldHVybiBuZXcgRGF0ZSh2YWx1ZSk7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICB2YWx1ZSA9IHZhbHVlLnRyaW0oKTtcbiAgICBpZiAoL14oXFxkezR9KC1cXGR7MSwyfSgtXFxkezEsMn0pPyk/KSQvLnRlc3QodmFsdWUpKSB7XG4gICAgICBjb25zdCBbeSwgbSA9IDEsIGQgPSAxXSA9IHZhbHVlLnNwbGl0KCctJykubWFwKHZhbCA9PiArdmFsKTtcbiAgICAgIHJldHVybiBjcmVhdGVEYXRlKHksIG0gLSAxLCBkKTtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkTmIgPSBwYXJzZUZsb2F0KHZhbHVlKTtcbiAgICBpZiAoIWlzTmFOKHZhbHVlIC0gcGFyc2VkTmIpKSB7XG4gICAgICByZXR1cm4gbmV3IERhdGUocGFyc2VkTmIpO1xuICAgIH1cbiAgICBsZXQgbWF0Y2g7XG4gICAgaWYgKG1hdGNoID0gdmFsdWUubWF0Y2goSVNPODYwMV9EQVRFX1JFR0VYKSkge1xuICAgICAgcmV0dXJuIGlzb1N0cmluZ1RvRGF0ZShtYXRjaCk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh2YWx1ZSk7XG4gIGlmICghaXNEYXRlKGRhdGUpKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMxMSwgbmdEZXZNb2RlICYmIGBVbmFibGUgdG8gY29udmVydCBcIiR7dmFsdWV9XCIgaW50byBhIGRhdGVgKTtcbiAgfVxuICByZXR1cm4gZGF0ZTtcbn1cbmZ1bmN0aW9uIGlzb1N0cmluZ1RvRGF0ZShtYXRjaCkge1xuICBjb25zdCBkYXRlID0gbmV3IERhdGUoMCk7XG4gIGxldCB0ekhvdXIgPSAwO1xuICBsZXQgdHpNaW4gPSAwO1xuICBjb25zdCBkYXRlU2V0dGVyID0gbWF0Y2hbOF0gPyBkYXRlLnNldFVUQ0Z1bGxZZWFyIDogZGF0ZS5zZXRGdWxsWWVhcjtcbiAgY29uc3QgdGltZVNldHRlciA9IG1hdGNoWzhdID8gZGF0ZS5zZXRVVENIb3VycyA6IGRhdGUuc2V0SG91cnM7XG4gIGlmIChtYXRjaFs5XSkge1xuICAgIHR6SG91ciA9IE51bWJlcihtYXRjaFs5XSArIG1hdGNoWzEwXSk7XG4gICAgdHpNaW4gPSBOdW1iZXIobWF0Y2hbOV0gKyBtYXRjaFsxMV0pO1xuICB9XG4gIGRhdGVTZXR0ZXIuY2FsbChkYXRlLCBOdW1iZXIobWF0Y2hbMV0pLCBOdW1iZXIobWF0Y2hbMl0pIC0gMSwgTnVtYmVyKG1hdGNoWzNdKSk7XG4gIGNvbnN0IGggPSBOdW1iZXIobWF0Y2hbNF0gfHwgMCkgLSB0ekhvdXI7XG4gIGNvbnN0IG0gPSBOdW1iZXIobWF0Y2hbNV0gfHwgMCkgLSB0ek1pbjtcbiAgY29uc3QgcyA9IE51bWJlcihtYXRjaFs2XSB8fCAwKTtcbiAgY29uc3QgbXMgPSBNYXRoLmZsb29yKHBhcnNlRmxvYXQoJzAuJyArIChtYXRjaFs3XSB8fCAwKSkgKiAxMDAwKTtcbiAgdGltZVNldHRlci5jYWxsKGRhdGUsIGgsIG0sIHMsIG1zKTtcbiAgcmV0dXJuIGRhdGU7XG59XG5mdW5jdGlvbiBpc0RhdGUodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRGF0ZSAmJiAhaXNOYU4odmFsdWUudmFsdWVPZigpKTtcbn1cbmNvbnN0IE5VTUJFUl9GT1JNQVRfUkVHRVhQID0gL14oXFxkKyk/XFwuKChcXGQrKSgtKFxcZCspKT8pPyQvO1xuY29uc3QgTUFYX0RJR0lUUyA9IDIyO1xuY29uc3QgREVDSU1BTF9TRVAgPSAnLic7XG5jb25zdCBaRVJPX0NIQVIgPSAnMCc7XG5jb25zdCBQQVRURVJOX1NFUCA9ICc7JztcbmNvbnN0IEdST1VQX1NFUCA9ICcsJztcbmNvbnN0IERJR0lUX0NIQVIgPSAnIyc7XG5jb25zdCBDVVJSRU5DWV9DSEFSID0gJ8KkJztcbmNvbnN0IFBFUkNFTlRfQ0hBUiA9ICclJztcbmZ1bmN0aW9uIGZvcm1hdE51bWJlclRvTG9jYWxlU3RyaW5nKHZhbHVlLCBwYXR0ZXJuLCBsb2NhbGUsIGdyb3VwU3ltYm9sLCBkZWNpbWFsU3ltYm9sLCBkaWdpdHNJbmZvLCBpc1BlcmNlbnQgPSBmYWxzZSkge1xuICBsZXQgZm9ybWF0dGVkVGV4dCA9ICcnO1xuICBsZXQgaXNaZXJvID0gZmFsc2U7XG4gIGlmICghaXNGaW5pdGUodmFsdWUpKSB7XG4gICAgZm9ybWF0dGVkVGV4dCA9IGdldExvY2FsZU51bWJlclN5bWJvbChsb2NhbGUsIE51bWJlclN5bWJvbC5JbmZpbml0eSk7XG4gIH0gZWxzZSB7XG4gICAgbGV0IHBhcnNlZE51bWJlciA9IHBhcnNlTnVtYmVyKHZhbHVlKTtcbiAgICBpZiAoaXNQZXJjZW50KSB7XG4gICAgICBwYXJzZWROdW1iZXIgPSB0b1BlcmNlbnQocGFyc2VkTnVtYmVyKTtcbiAgICB9XG4gICAgbGV0IG1pbkludCA9IHBhdHRlcm4ubWluSW50O1xuICAgIGxldCBtaW5GcmFjdGlvbiA9IHBhdHRlcm4ubWluRnJhYztcbiAgICBsZXQgbWF4RnJhY3Rpb24gPSBwYXR0ZXJuLm1heEZyYWM7XG4gICAgaWYgKGRpZ2l0c0luZm8pIHtcbiAgICAgIGNvbnN0IHBhcnRzID0gZGlnaXRzSW5mby5tYXRjaChOVU1CRVJfRk9STUFUX1JFR0VYUCk7XG4gICAgICBpZiAocGFydHMgPT09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMwNiwgbmdEZXZNb2RlICYmIGAke2RpZ2l0c0luZm99IGlzIG5vdCBhIHZhbGlkIGRpZ2l0IGluZm9gKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1pbkludFBhcnQgPSBwYXJ0c1sxXTtcbiAgICAgIGNvbnN0IG1pbkZyYWN0aW9uUGFydCA9IHBhcnRzWzNdO1xuICAgICAgY29uc3QgbWF4RnJhY3Rpb25QYXJ0ID0gcGFydHNbNV07XG4gICAgICBpZiAobWluSW50UGFydCAhPSBudWxsKSB7XG4gICAgICAgIG1pbkludCA9IHBhcnNlSW50QXV0b1JhZGl4KG1pbkludFBhcnQpO1xuICAgICAgfVxuICAgICAgaWYgKG1pbkZyYWN0aW9uUGFydCAhPSBudWxsKSB7XG4gICAgICAgIG1pbkZyYWN0aW9uID0gcGFyc2VJbnRBdXRvUmFkaXgobWluRnJhY3Rpb25QYXJ0KTtcbiAgICAgIH1cbiAgICAgIGlmIChtYXhGcmFjdGlvblBhcnQgIT0gbnVsbCkge1xuICAgICAgICBtYXhGcmFjdGlvbiA9IHBhcnNlSW50QXV0b1JhZGl4KG1heEZyYWN0aW9uUGFydCk7XG4gICAgICB9IGVsc2UgaWYgKG1pbkZyYWN0aW9uUGFydCAhPSBudWxsICYmIG1pbkZyYWN0aW9uID4gbWF4RnJhY3Rpb24pIHtcbiAgICAgICAgbWF4RnJhY3Rpb24gPSBtaW5GcmFjdGlvbjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IE1BWF9BTExPV0VEX0RJR0lUUyA9IDEwMDtcbiAgICAgIGlmIChtaW5JbnQgPiBNQVhfQUxMT1dFRF9ESUdJVFMgfHwgbWluRnJhY3Rpb24gPiBNQVhfQUxMT1dFRF9ESUdJVFMgfHwgbWF4RnJhY3Rpb24gPiBNQVhfQUxMT1dFRF9ESUdJVFMpIHtcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMwNiwgbmdEZXZNb2RlICYmIGAke2RpZ2l0c0luZm99IGlzIG5vdCBhIHZhbGlkIGRpZ2l0IGluZm8uIEV4Y2VlZGVkIG1heGltdW0gbGltaXRzIG9mICR7TUFYX0FMTE9XRURfRElHSVRTfSBkaWdpdHMuYCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJvdW5kTnVtYmVyKHBhcnNlZE51bWJlciwgbWluRnJhY3Rpb24sIG1heEZyYWN0aW9uKTtcbiAgICBsZXQgZGlnaXRzID0gcGFyc2VkTnVtYmVyLmRpZ2l0cztcbiAgICBsZXQgaW50ZWdlckxlbiA9IHBhcnNlZE51bWJlci5pbnRlZ2VyTGVuO1xuICAgIGNvbnN0IGV4cG9uZW50ID0gcGFyc2VkTnVtYmVyLmV4cG9uZW50O1xuICAgIGxldCBkZWNpbWFscyA9IFtdO1xuICAgIGlzWmVybyA9IGRpZ2l0cy5ldmVyeShkID0+ICFkKTtcbiAgICBmb3IgKDsgaW50ZWdlckxlbiA8IG1pbkludDsgaW50ZWdlckxlbisrKSB7XG4gICAgICBkaWdpdHMudW5zaGlmdCgwKTtcbiAgICB9XG4gICAgZm9yICg7IGludGVnZXJMZW4gPCAwOyBpbnRlZ2VyTGVuKyspIHtcbiAgICAgIGRpZ2l0cy51bnNoaWZ0KDApO1xuICAgIH1cbiAgICBpZiAoaW50ZWdlckxlbiA+IDApIHtcbiAgICAgIGRlY2ltYWxzID0gZGlnaXRzLnNwbGljZShpbnRlZ2VyTGVuLCBkaWdpdHMubGVuZ3RoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZGVjaW1hbHMgPSBkaWdpdHM7XG4gICAgICBkaWdpdHMgPSBbMF07XG4gICAgfVxuICAgIGNvbnN0IGdyb3VwcyA9IFtdO1xuICAgIGlmIChkaWdpdHMubGVuZ3RoID49IHBhdHRlcm4ubGdTaXplKSB7XG4gICAgICBncm91cHMudW5zaGlmdChkaWdpdHMuc3BsaWNlKC1wYXR0ZXJuLmxnU2l6ZSwgZGlnaXRzLmxlbmd0aCkuam9pbignJykpO1xuICAgIH1cbiAgICB3aGlsZSAoZGlnaXRzLmxlbmd0aCA+IHBhdHRlcm4uZ1NpemUpIHtcbiAgICAgIGdyb3Vwcy51bnNoaWZ0KGRpZ2l0cy5zcGxpY2UoLXBhdHRlcm4uZ1NpemUsIGRpZ2l0cy5sZW5ndGgpLmpvaW4oJycpKTtcbiAgICB9XG4gICAgaWYgKGRpZ2l0cy5sZW5ndGgpIHtcbiAgICAgIGdyb3Vwcy51bnNoaWZ0KGRpZ2l0cy5qb2luKCcnKSk7XG4gICAgfVxuICAgIGZvcm1hdHRlZFRleHQgPSBncm91cHMuam9pbihnZXRMb2NhbGVOdW1iZXJTeW1ib2wobG9jYWxlLCBncm91cFN5bWJvbCkpO1xuICAgIGlmIChkZWNpbWFscy5sZW5ndGgpIHtcbiAgICAgIGZvcm1hdHRlZFRleHQgKz0gZ2V0TG9jYWxlTnVtYmVyU3ltYm9sKGxvY2FsZSwgZGVjaW1hbFN5bWJvbCkgKyBkZWNpbWFscy5qb2luKCcnKTtcbiAgICB9XG4gICAgaWYgKGV4cG9uZW50KSB7XG4gICAgICBmb3JtYXR0ZWRUZXh0ICs9IGdldExvY2FsZU51bWJlclN5bWJvbChsb2NhbGUsIE51bWJlclN5bWJvbC5FeHBvbmVudGlhbCkgKyAnKycgKyBleHBvbmVudDtcbiAgICB9XG4gIH1cbiAgaWYgKHZhbHVlIDwgMCAmJiAhaXNaZXJvKSB7XG4gICAgZm9ybWF0dGVkVGV4dCA9IHBhdHRlcm4ubmVnUHJlICsgZm9ybWF0dGVkVGV4dCArIHBhdHRlcm4ubmVnU3VmO1xuICB9IGVsc2Uge1xuICAgIGZvcm1hdHRlZFRleHQgPSBwYXR0ZXJuLnBvc1ByZSArIGZvcm1hdHRlZFRleHQgKyBwYXR0ZXJuLnBvc1N1ZjtcbiAgfVxuICByZXR1cm4gZm9ybWF0dGVkVGV4dDtcbn1cbmZ1bmN0aW9uIGZvcm1hdEN1cnJlbmN5KHZhbHVlLCBsb2NhbGUsIGN1cnJlbmN5LCBjdXJyZW5jeUNvZGUsIGRpZ2l0c0luZm8pIHtcbiAgY29uc3QgZm9ybWF0ID0gZ2V0TG9jYWxlTnVtYmVyRm9ybWF0KGxvY2FsZSwgTnVtYmVyRm9ybWF0U3R5bGUuQ3VycmVuY3kpO1xuICBjb25zdCBwYXR0ZXJuID0gcGFyc2VOdW1iZXJGb3JtYXQoZm9ybWF0LCBnZXRMb2NhbGVOdW1iZXJTeW1ib2wobG9jYWxlLCBOdW1iZXJTeW1ib2wuTWludXNTaWduKSk7XG4gIHBhdHRlcm4ubWluRnJhYyA9IGdldE51bWJlck9mQ3VycmVuY3lEaWdpdHMoY3VycmVuY3lDb2RlKTtcbiAgcGF0dGVybi5tYXhGcmFjID0gcGF0dGVybi5taW5GcmFjO1xuICBjb25zdCByZXMgPSBmb3JtYXROdW1iZXJUb0xvY2FsZVN0cmluZyh2YWx1ZSwgcGF0dGVybiwgbG9jYWxlLCBOdW1iZXJTeW1ib2wuQ3VycmVuY3lHcm91cCwgTnVtYmVyU3ltYm9sLkN1cnJlbmN5RGVjaW1hbCwgZGlnaXRzSW5mbyk7XG4gIHJldHVybiByZXMucmVwbGFjZShDVVJSRU5DWV9DSEFSLCBjdXJyZW5jeSkucmVwbGFjZShDVVJSRU5DWV9DSEFSLCAnJykudHJpbSgpO1xufVxuZnVuY3Rpb24gZm9ybWF0UGVyY2VudCh2YWx1ZSwgbG9jYWxlLCBkaWdpdHNJbmZvKSB7XG4gIGNvbnN0IGZvcm1hdCA9IGdldExvY2FsZU51bWJlckZvcm1hdChsb2NhbGUsIE51bWJlckZvcm1hdFN0eWxlLlBlcmNlbnQpO1xuICBjb25zdCBwYXR0ZXJuID0gcGFyc2VOdW1iZXJGb3JtYXQoZm9ybWF0LCBnZXRMb2NhbGVOdW1iZXJTeW1ib2wobG9jYWxlLCBOdW1iZXJTeW1ib2wuTWludXNTaWduKSk7XG4gIGNvbnN0IHJlcyA9IGZvcm1hdE51bWJlclRvTG9jYWxlU3RyaW5nKHZhbHVlLCBwYXR0ZXJuLCBsb2NhbGUsIE51bWJlclN5bWJvbC5Hcm91cCwgTnVtYmVyU3ltYm9sLkRlY2ltYWwsIGRpZ2l0c0luZm8sIHRydWUpO1xuICByZXR1cm4gcmVzLnJlcGxhY2UobmV3IFJlZ0V4cChQRVJDRU5UX0NIQVIsICdnJyksIGdldExvY2FsZU51bWJlclN5bWJvbChsb2NhbGUsIE51bWJlclN5bWJvbC5QZXJjZW50U2lnbikpO1xufVxuZnVuY3Rpb24gZm9ybWF0TnVtYmVyKHZhbHVlLCBsb2NhbGUsIGRpZ2l0c0luZm8pIHtcbiAgY29uc3QgZm9ybWF0ID0gZ2V0TG9jYWxlTnVtYmVyRm9ybWF0KGxvY2FsZSwgTnVtYmVyRm9ybWF0U3R5bGUuRGVjaW1hbCk7XG4gIGNvbnN0IHBhdHRlcm4gPSBwYXJzZU51bWJlckZvcm1hdChmb3JtYXQsIGdldExvY2FsZU51bWJlclN5bWJvbChsb2NhbGUsIE51bWJlclN5bWJvbC5NaW51c1NpZ24pKTtcbiAgcmV0dXJuIGZvcm1hdE51bWJlclRvTG9jYWxlU3RyaW5nKHZhbHVlLCBwYXR0ZXJuLCBsb2NhbGUsIE51bWJlclN5bWJvbC5Hcm91cCwgTnVtYmVyU3ltYm9sLkRlY2ltYWwsIGRpZ2l0c0luZm8pO1xufVxuZnVuY3Rpb24gcGFyc2VOdW1iZXJGb3JtYXQoZm9ybWF0LCBtaW51c1NpZ24gPSAnLScpIHtcbiAgY29uc3QgcCA9IHtcbiAgICBtaW5JbnQ6IDEsXG4gICAgbWluRnJhYzogMCxcbiAgICBtYXhGcmFjOiAwLFxuICAgIHBvc1ByZTogJycsXG4gICAgcG9zU3VmOiAnJyxcbiAgICBuZWdQcmU6ICcnLFxuICAgIG5lZ1N1ZjogJycsXG4gICAgZ1NpemU6IDAsXG4gICAgbGdTaXplOiAwXG4gIH07XG4gIGNvbnN0IHBhdHRlcm5QYXJ0cyA9IGZvcm1hdC5zcGxpdChQQVRURVJOX1NFUCk7XG4gIGNvbnN0IHBvc2l0aXZlID0gcGF0dGVyblBhcnRzWzBdO1xuICBjb25zdCBuZWdhdGl2ZSA9IHBhdHRlcm5QYXJ0c1sxXTtcbiAgY29uc3QgcG9zaXRpdmVQYXJ0cyA9IHBvc2l0aXZlLmluZGV4T2YoREVDSU1BTF9TRVApICE9PSAtMSA/IHBvc2l0aXZlLnNwbGl0KERFQ0lNQUxfU0VQKSA6IFtwb3NpdGl2ZS5zdWJzdHJpbmcoMCwgcG9zaXRpdmUubGFzdEluZGV4T2YoWkVST19DSEFSKSArIDEpLCBwb3NpdGl2ZS5zdWJzdHJpbmcocG9zaXRpdmUubGFzdEluZGV4T2YoWkVST19DSEFSKSArIDEpXSxcbiAgICBpbnRlZ2VyID0gcG9zaXRpdmVQYXJ0c1swXSxcbiAgICBmcmFjdGlvbiA9IHBvc2l0aXZlUGFydHNbMV0gfHwgJyc7XG4gIHAucG9zUHJlID0gaW50ZWdlci5zdWJzdHJpbmcoMCwgaW50ZWdlci5pbmRleE9mKERJR0lUX0NIQVIpKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBmcmFjdGlvbi5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoID0gZnJhY3Rpb24uY2hhckF0KGkpO1xuICAgIGlmIChjaCA9PT0gWkVST19DSEFSKSB7XG4gICAgICBwLm1pbkZyYWMgPSBwLm1heEZyYWMgPSBpICsgMTtcbiAgICB9IGVsc2UgaWYgKGNoID09PSBESUdJVF9DSEFSKSB7XG4gICAgICBwLm1heEZyYWMgPSBpICsgMTtcbiAgICB9IGVsc2Uge1xuICAgICAgcC5wb3NTdWYgKz0gY2g7XG4gICAgfVxuICB9XG4gIGNvbnN0IGdyb3VwcyA9IGludGVnZXIuc3BsaXQoR1JPVVBfU0VQKTtcbiAgcC5nU2l6ZSA9IGdyb3Vwc1sxXSA/IGdyb3Vwc1sxXS5sZW5ndGggOiAwO1xuICBwLmxnU2l6ZSA9IGdyb3Vwc1syXSB8fCBncm91cHNbMV0gPyAoZ3JvdXBzWzJdIHx8IGdyb3Vwc1sxXSkubGVuZ3RoIDogMDtcbiAgaWYgKG5lZ2F0aXZlKSB7XG4gICAgY29uc3QgdHJ1bmtMZW4gPSBwb3NpdGl2ZS5sZW5ndGggLSBwLnBvc1ByZS5sZW5ndGggLSBwLnBvc1N1Zi5sZW5ndGgsXG4gICAgICBwb3MgPSBuZWdhdGl2ZS5pbmRleE9mKERJR0lUX0NIQVIpO1xuICAgIHAubmVnUHJlID0gbmVnYXRpdmUuc3Vic3RyaW5nKDAsIHBvcykucmVwbGFjZSgvJy9nLCAnJyk7XG4gICAgcC5uZWdTdWYgPSBuZWdhdGl2ZS5zbGljZShwb3MgKyB0cnVua0xlbikucmVwbGFjZSgvJy9nLCAnJyk7XG4gIH0gZWxzZSB7XG4gICAgcC5uZWdQcmUgPSBtaW51c1NpZ24gKyBwLnBvc1ByZTtcbiAgICBwLm5lZ1N1ZiA9IHAucG9zU3VmO1xuICB9XG4gIHJldHVybiBwO1xufVxuZnVuY3Rpb24gdG9QZXJjZW50KHBhcnNlZE51bWJlcikge1xuICBpZiAocGFyc2VkTnVtYmVyLmRpZ2l0c1swXSA9PT0gMCkge1xuICAgIHJldHVybiBwYXJzZWROdW1iZXI7XG4gIH1cbiAgY29uc3QgZnJhY3Rpb25MZW4gPSBwYXJzZWROdW1iZXIuZGlnaXRzLmxlbmd0aCAtIHBhcnNlZE51bWJlci5pbnRlZ2VyTGVuO1xuICBpZiAocGFyc2VkTnVtYmVyLmV4cG9uZW50KSB7XG4gICAgcGFyc2VkTnVtYmVyLmV4cG9uZW50ICs9IDI7XG4gIH0gZWxzZSB7XG4gICAgaWYgKGZyYWN0aW9uTGVuID09PSAwKSB7XG4gICAgICBwYXJzZWROdW1iZXIuZGlnaXRzLnB1c2goMCwgMCk7XG4gICAgfSBlbHNlIGlmIChmcmFjdGlvbkxlbiA9PT0gMSkge1xuICAgICAgcGFyc2VkTnVtYmVyLmRpZ2l0cy5wdXNoKDApO1xuICAgIH1cbiAgICBwYXJzZWROdW1iZXIuaW50ZWdlckxlbiArPSAyO1xuICB9XG4gIHJldHVybiBwYXJzZWROdW1iZXI7XG59XG5mdW5jdGlvbiBwYXJzZU51bWJlcihudW0pIHtcbiAgbGV0IG51bVN0ciA9IE1hdGguYWJzKG51bSkgKyAnJztcbiAgbGV0IGV4cG9uZW50ID0gMCxcbiAgICBkaWdpdHMsXG4gICAgaW50ZWdlckxlbjtcbiAgbGV0IGksIGosIHplcm9zO1xuICBpZiAoKGludGVnZXJMZW4gPSBudW1TdHIuaW5kZXhPZihERUNJTUFMX1NFUCkpID4gLTEpIHtcbiAgICBudW1TdHIgPSBudW1TdHIucmVwbGFjZShERUNJTUFMX1NFUCwgJycpO1xuICB9XG4gIGlmICgoaSA9IG51bVN0ci5zZWFyY2goL2UvaSkpID4gMCkge1xuICAgIGlmIChpbnRlZ2VyTGVuIDwgMCkgaW50ZWdlckxlbiA9IGk7XG4gICAgaW50ZWdlckxlbiArPSArbnVtU3RyLnNsaWNlKGkgKyAxKTtcbiAgICBudW1TdHIgPSBudW1TdHIuc3Vic3RyaW5nKDAsIGkpO1xuICB9IGVsc2UgaWYgKGludGVnZXJMZW4gPCAwKSB7XG4gICAgaW50ZWdlckxlbiA9IG51bVN0ci5sZW5ndGg7XG4gIH1cbiAgZm9yIChpID0gMDsgbnVtU3RyLmNoYXJBdChpKSA9PT0gWkVST19DSEFSOyBpKyspIHt9XG4gIGlmIChpID09PSAoemVyb3MgPSBudW1TdHIubGVuZ3RoKSkge1xuICAgIGRpZ2l0cyA9IFswXTtcbiAgICBpbnRlZ2VyTGVuID0gMTtcbiAgfSBlbHNlIHtcbiAgICB6ZXJvcy0tO1xuICAgIHdoaWxlIChudW1TdHIuY2hhckF0KHplcm9zKSA9PT0gWkVST19DSEFSKSB6ZXJvcy0tO1xuICAgIGludGVnZXJMZW4gLT0gaTtcbiAgICBkaWdpdHMgPSBbXTtcbiAgICBmb3IgKGogPSAwOyBpIDw9IHplcm9zOyBpKyssIGorKykge1xuICAgICAgZGlnaXRzW2pdID0gTnVtYmVyKG51bVN0ci5jaGFyQXQoaSkpO1xuICAgIH1cbiAgfVxuICBpZiAoaW50ZWdlckxlbiA+IE1BWF9ESUdJVFMpIHtcbiAgICBkaWdpdHMgPSBkaWdpdHMuc3BsaWNlKDAsIE1BWF9ESUdJVFMgLSAxKTtcbiAgICBleHBvbmVudCA9IGludGVnZXJMZW4gLSAxO1xuICAgIGludGVnZXJMZW4gPSAxO1xuICB9XG4gIHJldHVybiB7XG4gICAgZGlnaXRzLFxuICAgIGV4cG9uZW50LFxuICAgIGludGVnZXJMZW5cbiAgfTtcbn1cbmZ1bmN0aW9uIHJvdW5kTnVtYmVyKHBhcnNlZE51bWJlciwgbWluRnJhYywgbWF4RnJhYykge1xuICBpZiAobWluRnJhYyA+IG1heEZyYWMpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyMzA3LCBuZ0Rldk1vZGUgJiYgYFRoZSBtaW5pbXVtIG51bWJlciBvZiBkaWdpdHMgYWZ0ZXIgZnJhY3Rpb24gKCR7bWluRnJhY30pIGlzIGhpZ2hlciB0aGFuIHRoZSBtYXhpbXVtICgke21heEZyYWN9KS5gKTtcbiAgfVxuICBsZXQgZGlnaXRzID0gcGFyc2VkTnVtYmVyLmRpZ2l0cztcbiAgbGV0IGZyYWN0aW9uTGVuID0gZGlnaXRzLmxlbmd0aCAtIHBhcnNlZE51bWJlci5pbnRlZ2VyTGVuO1xuICBjb25zdCBmcmFjdGlvblNpemUgPSBNYXRoLm1pbihNYXRoLm1heChtaW5GcmFjLCBmcmFjdGlvbkxlbiksIG1heEZyYWMpO1xuICBsZXQgcm91bmRBdCA9IGZyYWN0aW9uU2l6ZSArIHBhcnNlZE51bWJlci5pbnRlZ2VyTGVuO1xuICBsZXQgZGlnaXQgPSBkaWdpdHNbcm91bmRBdF07XG4gIGlmIChyb3VuZEF0ID4gMCkge1xuICAgIGRpZ2l0cy5zcGxpY2UoTWF0aC5tYXgocGFyc2VkTnVtYmVyLmludGVnZXJMZW4sIHJvdW5kQXQpKTtcbiAgICBmb3IgKGxldCBqID0gcm91bmRBdDsgaiA8IGRpZ2l0cy5sZW5ndGg7IGorKykge1xuICAgICAgZGlnaXRzW2pdID0gMDtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZnJhY3Rpb25MZW4gPSBNYXRoLm1heCgwLCBmcmFjdGlvbkxlbik7XG4gICAgcGFyc2VkTnVtYmVyLmludGVnZXJMZW4gPSAxO1xuICAgIGRpZ2l0cy5sZW5ndGggPSBNYXRoLm1heCgxLCByb3VuZEF0ID0gZnJhY3Rpb25TaXplICsgMSk7XG4gICAgZGlnaXRzWzBdID0gMDtcbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IHJvdW5kQXQ7IGkrKykgZGlnaXRzW2ldID0gMDtcbiAgfVxuICBpZiAoZGlnaXQgPj0gNSkge1xuICAgIGlmIChyb3VuZEF0IC0gMSA8IDApIHtcbiAgICAgIGZvciAobGV0IGsgPSAwOyBrID4gcm91bmRBdDsgay0tKSB7XG4gICAgICAgIGRpZ2l0cy51bnNoaWZ0KDApO1xuICAgICAgICBwYXJzZWROdW1iZXIuaW50ZWdlckxlbisrO1xuICAgICAgfVxuICAgICAgZGlnaXRzLnVuc2hpZnQoMSk7XG4gICAgICBwYXJzZWROdW1iZXIuaW50ZWdlckxlbisrO1xuICAgIH0gZWxzZSB7XG4gICAgICBkaWdpdHNbcm91bmRBdCAtIDFdKys7XG4gICAgfVxuICB9XG4gIGZvciAoOyBmcmFjdGlvbkxlbiA8IE1hdGgubWF4KDAsIGZyYWN0aW9uU2l6ZSk7IGZyYWN0aW9uTGVuKyspIGRpZ2l0cy5wdXNoKDApO1xuICBsZXQgZHJvcFRyYWlsaW5nWmVyb3MgPSBmcmFjdGlvblNpemUgIT09IDA7XG4gIGNvbnN0IG1pbkxlbiA9IG1pbkZyYWMgKyBwYXJzZWROdW1iZXIuaW50ZWdlckxlbjtcbiAgY29uc3QgY2FycnkgPSBkaWdpdHMucmVkdWNlUmlnaHQoZnVuY3Rpb24gKGNhcnJ5LCBkLCBpLCBkaWdpdHMpIHtcbiAgICBkID0gZCArIGNhcnJ5O1xuICAgIGRpZ2l0c1tpXSA9IGQgPCAxMCA/IGQgOiBkIC0gMTA7XG4gICAgaWYgKGRyb3BUcmFpbGluZ1plcm9zKSB7XG4gICAgICBpZiAoZGlnaXRzW2ldID09PSAwICYmIGkgPj0gbWluTGVuKSB7XG4gICAgICAgIGRpZ2l0cy5wb3AoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRyb3BUcmFpbGluZ1plcm9zID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkID49IDEwID8gMSA6IDA7XG4gIH0sIDApO1xuICBpZiAoY2FycnkpIHtcbiAgICBkaWdpdHMudW5zaGlmdChjYXJyeSk7XG4gICAgcGFyc2VkTnVtYmVyLmludGVnZXJMZW4rKztcbiAgfVxufVxuZnVuY3Rpb24gcGFyc2VJbnRBdXRvUmFkaXgodGV4dCkge1xuICBjb25zdCByZXN1bHQgPSBwYXJzZUludCh0ZXh0KTtcbiAgaWYgKGlzTmFOKHJlc3VsdCkpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyMzA1LCBuZ0Rldk1vZGUgJiYgJ0ludmFsaWQgaW50ZWdlciBsaXRlcmFsIHdoZW4gcGFyc2luZyAnICsgdGV4dCk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmNsYXNzIE5nTG9jYWxpemF0aW9uIHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdMb2NhbGl6YXRpb25fRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IE5nTG9jYWxpemF0aW9uKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBOZ0xvY2FsaXphdGlvbixcbiAgICBmYWN0b3J5OiAoKSA9PiAoKCkgPT4gbmV3IE5nTG9jYWxlTG9jYWxpemF0aW9uKGluamVjdChMT0NBTEVfSUQpKSkoKVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nTG9jYWxpemF0aW9uLCBbe1xuICAgIHR5cGU6IFNlcnZpY2UsXG4gICAgYXJnczogW3tcbiAgICAgIGZhY3Rvcnk6ICgpID0+IG5ldyBOZ0xvY2FsZUxvY2FsaXphdGlvbihpbmplY3QoTE9DQUxFX0lEKSlcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gZ2V0UGx1cmFsQ2F0ZWdvcnkodmFsdWUsIGNhc2VzLCBuZ0xvY2FsaXphdGlvbiwgbG9jYWxlKSB7XG4gIGxldCBrZXkgPSBgPSR7dmFsdWV9YDtcbiAgaWYgKGNhc2VzLmluZGV4T2Yoa2V5KSA+IC0xKSB7XG4gICAgcmV0dXJuIGtleTtcbiAgfVxuICBrZXkgPSBuZ0xvY2FsaXphdGlvbi5nZXRQbHVyYWxDYXRlZ29yeSh2YWx1ZSwgbG9jYWxlKTtcbiAgaWYgKGNhc2VzLmluZGV4T2Yoa2V5KSA+IC0xKSB7XG4gICAgcmV0dXJuIGtleTtcbiAgfVxuICBpZiAoY2FzZXMuaW5kZXhPZignb3RoZXInKSA+IC0xKSB7XG4gICAgcmV0dXJuICdvdGhlcic7XG4gIH1cbiAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMwOCwgbmdEZXZNb2RlICYmIGBObyBwbHVyYWwgbWVzc2FnZSBmb3VuZCBmb3IgdmFsdWUgXCIke3ZhbHVlfVwiYCk7XG59XG5jbGFzcyBOZ0xvY2FsZUxvY2FsaXphdGlvbiBleHRlbmRzIE5nTG9jYWxpemF0aW9uIHtcbiAgbG9jYWxlO1xuICBjb25zdHJ1Y3Rvcihsb2NhbGUpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMubG9jYWxlID0gbG9jYWxlO1xuICB9XG4gIGdldFBsdXJhbENhdGVnb3J5KHZhbHVlLCBsb2NhbGUpIHtcbiAgICBjb25zdCBwbHVyYWwgPSBnZXRMb2NhbGVQbHVyYWxDYXNlKGxvY2FsZSB8fCB0aGlzLmxvY2FsZSkodmFsdWUpO1xuICAgIHN3aXRjaCAocGx1cmFsKSB7XG4gICAgICBjYXNlIFBsdXJhbC5aZXJvOlxuICAgICAgICByZXR1cm4gJ3plcm8nO1xuICAgICAgY2FzZSBQbHVyYWwuT25lOlxuICAgICAgICByZXR1cm4gJ29uZSc7XG4gICAgICBjYXNlIFBsdXJhbC5Ud286XG4gICAgICAgIHJldHVybiAndHdvJztcbiAgICAgIGNhc2UgUGx1cmFsLkZldzpcbiAgICAgICAgcmV0dXJuICdmZXcnO1xuICAgICAgY2FzZSBQbHVyYWwuTWFueTpcbiAgICAgICAgcmV0dXJuICdtYW55JztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAnb3RoZXInO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOZ0xvY2FsZUxvY2FsaXphdGlvbl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IE5nTG9jYWxlTG9jYWxpemF0aW9uKShpMC7Jtcm1aW5qZWN0KExPQ0FMRV9JRCkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBOZ0xvY2FsZUxvY2FsaXphdGlvbixcbiAgICBmYWN0b3J5OiBOZ0xvY2FsZUxvY2FsaXphdGlvbi7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nTG9jYWxlTG9jYWxpemF0aW9uLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTE9DQUxFX0lEXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jb25zdCBXU19SRUdFWFAgPSAvXFxzKy87XG5jb25zdCBFTVBUWV9BUlJBWSA9IFtdO1xuY2xhc3MgTmdDbGFzcyB7XG4gIF9uZ0VsO1xuICBfcmVuZGVyZXI7XG4gIGluaXRpYWxDbGFzc2VzID0gRU1QVFlfQVJSQVk7XG4gIHJhd0NsYXNzO1xuICBzdGF0ZU1hcCA9IG5ldyBNYXAoKTtcbiAgY29uc3RydWN0b3IoX25nRWwsIF9yZW5kZXJlcikge1xuICAgIHRoaXMuX25nRWwgPSBfbmdFbDtcbiAgICB0aGlzLl9yZW5kZXJlciA9IF9yZW5kZXJlcjtcbiAgfVxuICBzZXQga2xhc3ModmFsdWUpIHtcbiAgICB0aGlzLmluaXRpYWxDbGFzc2VzID0gdmFsdWUgIT0gbnVsbCA/IHZhbHVlLnRyaW0oKS5zcGxpdChXU19SRUdFWFApIDogRU1QVFlfQVJSQVk7XG4gIH1cbiAgc2V0IG5nQ2xhc3ModmFsdWUpIHtcbiAgICB0aGlzLnJhd0NsYXNzID0gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IHZhbHVlLnRyaW0oKS5zcGxpdChXU19SRUdFWFApIDogdmFsdWU7XG4gIH1cbiAgbmdEb0NoZWNrKCkge1xuICAgIGZvciAoY29uc3Qga2xhc3Mgb2YgdGhpcy5pbml0aWFsQ2xhc3Nlcykge1xuICAgICAgdGhpcy5fdXBkYXRlU3RhdGUoa2xhc3MsIHRydWUpO1xuICAgIH1cbiAgICBjb25zdCByYXdDbGFzcyA9IHRoaXMucmF3Q2xhc3M7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocmF3Q2xhc3MpIHx8IHJhd0NsYXNzIGluc3RhbmNlb2YgU2V0KSB7XG4gICAgICBmb3IgKGNvbnN0IGtsYXNzIG9mIHJhd0NsYXNzKSB7XG4gICAgICAgIHRoaXMuX3VwZGF0ZVN0YXRlKGtsYXNzLCB0cnVlKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHJhd0NsYXNzICE9IG51bGwpIHtcbiAgICAgIGZvciAoY29uc3Qga2xhc3Mgb2YgT2JqZWN0LmtleXMocmF3Q2xhc3MpKSB7XG4gICAgICAgIHRoaXMuX3VwZGF0ZVN0YXRlKGtsYXNzLCBCb29sZWFuKHJhd0NsYXNzW2tsYXNzXSkpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLl9hcHBseVN0YXRlRGlmZigpO1xuICB9XG4gIF91cGRhdGVTdGF0ZShrbGFzcywgbmV4dEVuYWJsZWQpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuc3RhdGVNYXAuZ2V0KGtsYXNzKTtcbiAgICBpZiAoc3RhdGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHN0YXRlLmVuYWJsZWQgIT09IG5leHRFbmFibGVkKSB7XG4gICAgICAgIHN0YXRlLmNoYW5nZWQgPSB0cnVlO1xuICAgICAgICBzdGF0ZS5lbmFibGVkID0gbmV4dEVuYWJsZWQ7XG4gICAgICB9XG4gICAgICBzdGF0ZS50b3VjaGVkID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdGF0ZU1hcC5zZXQoa2xhc3MsIHtcbiAgICAgICAgZW5hYmxlZDogbmV4dEVuYWJsZWQsXG4gICAgICAgIGNoYW5nZWQ6IHRydWUsXG4gICAgICAgIHRvdWNoZWQ6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBfYXBwbHlTdGF0ZURpZmYoKSB7XG4gICAgZm9yIChjb25zdCBzdGF0ZUVudHJ5IG9mIHRoaXMuc3RhdGVNYXApIHtcbiAgICAgIGNvbnN0IGtsYXNzID0gc3RhdGVFbnRyeVswXTtcbiAgICAgIGNvbnN0IHN0YXRlID0gc3RhdGVFbnRyeVsxXTtcbiAgICAgIGlmIChzdGF0ZS5jaGFuZ2VkKSB7XG4gICAgICAgIHRoaXMuX3RvZ2dsZUNsYXNzKGtsYXNzLCBzdGF0ZS5lbmFibGVkKTtcbiAgICAgICAgc3RhdGUuY2hhbmdlZCA9IGZhbHNlO1xuICAgICAgfSBlbHNlIGlmICghc3RhdGUudG91Y2hlZCkge1xuICAgICAgICBpZiAoc3RhdGUuZW5hYmxlZCkge1xuICAgICAgICAgIHRoaXMuX3RvZ2dsZUNsYXNzKGtsYXNzLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zdGF0ZU1hcC5kZWxldGUoa2xhc3MpO1xuICAgICAgfVxuICAgICAgc3RhdGUudG91Y2hlZCA9IGZhbHNlO1xuICAgIH1cbiAgfVxuICBfdG9nZ2xlQ2xhc3Moa2xhc3MsIGVuYWJsZWQpIHtcbiAgICBpZiAobmdEZXZNb2RlKSB7XG4gICAgICBpZiAodHlwZW9mIGtsYXNzICE9PSAnc3RyaW5nJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE5nQ2xhc3MgY2FuIG9ubHkgdG9nZ2xlIENTUyBjbGFzc2VzIGV4cHJlc3NlZCBhcyBzdHJpbmdzLCBnb3QgJHtfc3RyaW5naWZ5KGtsYXNzKX1gKTtcbiAgICAgIH1cbiAgICB9XG4gICAga2xhc3MgPSBrbGFzcy50cmltKCk7XG4gICAgaWYgKGtsYXNzLmxlbmd0aCA+IDApIHtcbiAgICAgIGtsYXNzLnNwbGl0KFdTX1JFR0VYUCkuZm9yRWFjaChrbGFzcyA9PiB7XG4gICAgICAgIGlmIChlbmFibGVkKSB7XG4gICAgICAgICAgdGhpcy5fcmVuZGVyZXIuYWRkQ2xhc3ModGhpcy5fbmdFbC5uYXRpdmVFbGVtZW50LCBrbGFzcyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5fcmVuZGVyZXIucmVtb3ZlQ2xhc3ModGhpcy5fbmdFbC5uYXRpdmVFbGVtZW50LCBrbGFzcyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOZ0NsYXNzX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdDbGFzcykoaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5FbGVtZW50UmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5SZW5kZXJlcjIpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdDbGFzcyxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJuZ0NsYXNzXCIsIFwiXCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIGtsYXNzOiBbMCwgXCJjbGFzc1wiLCBcImtsYXNzXCJdLFxuICAgICAgbmdDbGFzczogXCJuZ0NsYXNzXCJcbiAgICB9XG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmdDbGFzcywgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW25nQ2xhc3NdJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IGkwLkVsZW1lbnRSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkwLlJlbmRlcmVyMlxuICB9XSwge1xuICAgIGtsYXNzOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ2NsYXNzJ11cbiAgICB9XSxcbiAgICBuZ0NsYXNzOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbJ25nQ2xhc3MnXVxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNsYXNzIE5nQ29tcG9uZW50T3V0bGV0IHtcbiAgX3ZpZXdDb250YWluZXJSZWY7XG4gIG5nQ29tcG9uZW50T3V0bGV0ID0gbnVsbDtcbiAgbmdDb21wb25lbnRPdXRsZXRJbnB1dHM7XG4gIG5nQ29tcG9uZW50T3V0bGV0SW5qZWN0b3I7XG4gIG5nQ29tcG9uZW50T3V0bGV0RW52aXJvbm1lbnRJbmplY3RvcjtcbiAgbmdDb21wb25lbnRPdXRsZXRDb250ZW50O1xuICBuZ0NvbXBvbmVudE91dGxldE5nTW9kdWxlO1xuICBfY29tcG9uZW50UmVmO1xuICBfbW9kdWxlUmVmO1xuICBfaW5wdXRzVXNlZCA9IG5ldyBNYXAoKTtcbiAgZ2V0IGNvbXBvbmVudEluc3RhbmNlKCkge1xuICAgIHJldHVybiB0aGlzLl9jb21wb25lbnRSZWY/Lmluc3RhbmNlID8/IG51bGw7XG4gIH1cbiAgY29uc3RydWN0b3IoX3ZpZXdDb250YWluZXJSZWYpIHtcbiAgICB0aGlzLl92aWV3Q29udGFpbmVyUmVmID0gX3ZpZXdDb250YWluZXJSZWY7XG4gIH1cbiAgX25lZWRUb1JlQ3JlYXRlTmdNb2R1bGVJbnN0YW5jZShjaGFuZ2VzKSB7XG4gICAgcmV0dXJuIGNoYW5nZXNbJ25nQ29tcG9uZW50T3V0bGV0TmdNb2R1bGUnXSAhPT0gdW5kZWZpbmVkO1xuICB9XG4gIF9uZWVkVG9SZUNyZWF0ZUNvbXBvbmVudEluc3RhbmNlKGNoYW5nZXMpIHtcbiAgICByZXR1cm4gY2hhbmdlc1snbmdDb21wb25lbnRPdXRsZXQnXSAhPT0gdW5kZWZpbmVkIHx8IGNoYW5nZXNbJ25nQ29tcG9uZW50T3V0bGV0Q29udGVudCddICE9PSB1bmRlZmluZWQgfHwgY2hhbmdlc1snbmdDb21wb25lbnRPdXRsZXRJbmplY3RvciddICE9PSB1bmRlZmluZWQgfHwgY2hhbmdlc1snbmdDb21wb25lbnRPdXRsZXRFbnZpcm9ubWVudEluamVjdG9yJ10gIT09IHVuZGVmaW5lZCB8fCB0aGlzLl9uZWVkVG9SZUNyZWF0ZU5nTW9kdWxlSW5zdGFuY2UoY2hhbmdlcyk7XG4gIH1cbiAgbmdPbkNoYW5nZXMoY2hhbmdlcykge1xuICAgIGlmICh0aGlzLl9uZWVkVG9SZUNyZWF0ZUNvbXBvbmVudEluc3RhbmNlKGNoYW5nZXMpKSB7XG4gICAgICB0aGlzLl92aWV3Q29udGFpbmVyUmVmLmNsZWFyKCk7XG4gICAgICB0aGlzLl9pbnB1dHNVc2VkLmNsZWFyKCk7XG4gICAgICB0aGlzLl9jb21wb25lbnRSZWYgPSB1bmRlZmluZWQ7XG4gICAgICBpZiAodGhpcy5uZ0NvbXBvbmVudE91dGxldCkge1xuICAgICAgICBjb25zdCBpbmplY3RvciA9IHRoaXMubmdDb21wb25lbnRPdXRsZXRJbmplY3RvciB8fCB0aGlzLl92aWV3Q29udGFpbmVyUmVmLnBhcmVudEluamVjdG9yO1xuICAgICAgICBpZiAodGhpcy5fbmVlZFRvUmVDcmVhdGVOZ01vZHVsZUluc3RhbmNlKGNoYW5nZXMpKSB7XG4gICAgICAgICAgdGhpcy5fbW9kdWxlUmVmPy5kZXN0cm95KCk7XG4gICAgICAgICAgaWYgKHRoaXMubmdDb21wb25lbnRPdXRsZXROZ01vZHVsZSkge1xuICAgICAgICAgICAgdGhpcy5fbW9kdWxlUmVmID0gY3JlYXRlTmdNb2R1bGUodGhpcy5uZ0NvbXBvbmVudE91dGxldE5nTW9kdWxlLCBnZXRQYXJlbnRJbmplY3RvcihpbmplY3RvcikpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9tb2R1bGVSZWYgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2NvbXBvbmVudFJlZiA9IHRoaXMuX3ZpZXdDb250YWluZXJSZWYuY3JlYXRlQ29tcG9uZW50KHRoaXMubmdDb21wb25lbnRPdXRsZXQsIHtcbiAgICAgICAgICBpbmplY3RvcixcbiAgICAgICAgICBuZ01vZHVsZVJlZjogdGhpcy5fbW9kdWxlUmVmLFxuICAgICAgICAgIHByb2plY3RhYmxlTm9kZXM6IHRoaXMubmdDb21wb25lbnRPdXRsZXRDb250ZW50LFxuICAgICAgICAgIGVudmlyb25tZW50SW5qZWN0b3I6IHRoaXMubmdDb21wb25lbnRPdXRsZXRFbnZpcm9ubWVudEluamVjdG9yXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBuZ0RvQ2hlY2soKSB7XG4gICAgaWYgKHRoaXMuX2NvbXBvbmVudFJlZikge1xuICAgICAgaWYgKHRoaXMubmdDb21wb25lbnRPdXRsZXRJbnB1dHMpIHtcbiAgICAgICAgZm9yIChjb25zdCBpbnB1dE5hbWUgb2YgT2JqZWN0LmtleXModGhpcy5uZ0NvbXBvbmVudE91dGxldElucHV0cykpIHtcbiAgICAgICAgICB0aGlzLl9pbnB1dHNVc2VkLnNldChpbnB1dE5hbWUsIHRydWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLl9hcHBseUlucHV0U3RhdGVEaWZmKHRoaXMuX2NvbXBvbmVudFJlZik7XG4gICAgfVxuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuX21vZHVsZVJlZj8uZGVzdHJveSgpO1xuICB9XG4gIF9hcHBseUlucHV0U3RhdGVEaWZmKGNvbXBvbmVudFJlZikge1xuICAgIGZvciAoY29uc3QgW2lucHV0TmFtZSwgdG91Y2hlZF0gb2YgdGhpcy5faW5wdXRzVXNlZCkge1xuICAgICAgaWYgKCF0b3VjaGVkKSB7XG4gICAgICAgIGNvbXBvbmVudFJlZi5zZXRJbnB1dChpbnB1dE5hbWUsIHVuZGVmaW5lZCk7XG4gICAgICAgIHRoaXMuX2lucHV0c1VzZWQuZGVsZXRlKGlucHV0TmFtZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb21wb25lbnRSZWYuc2V0SW5wdXQoaW5wdXROYW1lLCB0aGlzLm5nQ29tcG9uZW50T3V0bGV0SW5wdXRzW2lucHV0TmFtZV0pO1xuICAgICAgICB0aGlzLl9pbnB1dHNVc2VkLnNldChpbnB1dE5hbWUsIGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdDb21wb25lbnRPdXRsZXRfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ0NvbXBvbmVudE91dGxldCkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5WaWV3Q29udGFpbmVyUmVmKSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE5nQ29tcG9uZW50T3V0bGV0LFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcIm5nQ29tcG9uZW50T3V0bGV0XCIsIFwiXCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG5nQ29tcG9uZW50T3V0bGV0OiBcIm5nQ29tcG9uZW50T3V0bGV0XCIsXG4gICAgICBuZ0NvbXBvbmVudE91dGxldElucHV0czogXCJuZ0NvbXBvbmVudE91dGxldElucHV0c1wiLFxuICAgICAgbmdDb21wb25lbnRPdXRsZXRJbmplY3RvcjogXCJuZ0NvbXBvbmVudE91dGxldEluamVjdG9yXCIsXG4gICAgICBuZ0NvbXBvbmVudE91dGxldEVudmlyb25tZW50SW5qZWN0b3I6IFwibmdDb21wb25lbnRPdXRsZXRFbnZpcm9ubWVudEluamVjdG9yXCIsXG4gICAgICBuZ0NvbXBvbmVudE91dGxldENvbnRlbnQ6IFwibmdDb21wb25lbnRPdXRsZXRDb250ZW50XCIsXG4gICAgICBuZ0NvbXBvbmVudE91dGxldE5nTW9kdWxlOiBcIm5nQ29tcG9uZW50T3V0bGV0TmdNb2R1bGVcIlxuICAgIH0sXG4gICAgZXhwb3J0QXM6IFtcIm5nQ29tcG9uZW50T3V0bGV0XCJdLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtU5nT25DaGFuZ2VzRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ0NvbXBvbmVudE91dGxldCwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW25nQ29tcG9uZW50T3V0bGV0XScsXG4gICAgICBleHBvcnRBczogJ25nQ29tcG9uZW50T3V0bGV0J1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IGkwLlZpZXdDb250YWluZXJSZWZcbiAgfV0sIHtcbiAgICBuZ0NvbXBvbmVudE91dGxldDogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV0sXG4gICAgbmdDb21wb25lbnRPdXRsZXRJbnB1dHM6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG5nQ29tcG9uZW50T3V0bGV0SW5qZWN0b3I6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG5nQ29tcG9uZW50T3V0bGV0RW52aXJvbm1lbnRJbmplY3RvcjogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV0sXG4gICAgbmdDb21wb25lbnRPdXRsZXRDb250ZW50OiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBuZ0NvbXBvbmVudE91dGxldE5nTW9kdWxlOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XVxuICB9KTtcbn0pKCk7XG5mdW5jdGlvbiBnZXRQYXJlbnRJbmplY3RvcihpbmplY3Rvcikge1xuICBjb25zdCBwYXJlbnROZ01vZHVsZSA9IGluamVjdG9yLmdldChOZ01vZHVsZVJlZik7XG4gIHJldHVybiBwYXJlbnROZ01vZHVsZS5pbmplY3Rvcjtcbn1cbmNsYXNzIE5nRm9yT2ZDb250ZXh0IHtcbiAgJGltcGxpY2l0O1xuICBuZ0Zvck9mO1xuICBpbmRleDtcbiAgY291bnQ7XG4gIGNvbnN0cnVjdG9yKCRpbXBsaWNpdCwgbmdGb3JPZiwgaW5kZXgsIGNvdW50KSB7XG4gICAgdGhpcy4kaW1wbGljaXQgPSAkaW1wbGljaXQ7XG4gICAgdGhpcy5uZ0Zvck9mID0gbmdGb3JPZjtcbiAgICB0aGlzLmluZGV4ID0gaW5kZXg7XG4gICAgdGhpcy5jb3VudCA9IGNvdW50O1xuICB9XG4gIGdldCBmaXJzdCgpIHtcbiAgICByZXR1cm4gdGhpcy5pbmRleCA9PT0gMDtcbiAgfVxuICBnZXQgbGFzdCgpIHtcbiAgICByZXR1cm4gdGhpcy5pbmRleCA9PT0gdGhpcy5jb3VudCAtIDE7XG4gIH1cbiAgZ2V0IGV2ZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5kZXggJSAyID09PSAwO1xuICB9XG4gIGdldCBvZGQoKSB7XG4gICAgcmV0dXJuICF0aGlzLmV2ZW47XG4gIH1cbn1cbmNsYXNzIE5nRm9yT2Yge1xuICBfdmlld0NvbnRhaW5lcjtcbiAgX3RlbXBsYXRlO1xuICBfZGlmZmVycztcbiAgc2V0IG5nRm9yT2YobmdGb3JPZikge1xuICAgIHRoaXMuX25nRm9yT2YgPSBuZ0Zvck9mO1xuICAgIHRoaXMuX25nRm9yT2ZEaXJ0eSA9IHRydWU7XG4gIH1cbiAgc2V0IG5nRm9yVHJhY2tCeShmbikge1xuICAgIGlmICgodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBmbiAhPSBudWxsICYmIHR5cGVvZiBmbiAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY29uc29sZS53YXJuKGB0cmFja0J5IG11c3QgYmUgYSBmdW5jdGlvbiwgYnV0IHJlY2VpdmVkICR7SlNPTi5zdHJpbmdpZnkoZm4pfS4gYCArIGBTZWUgaHR0cHM6Ly9hbmd1bGFyLmRldi9hcGkvY29tbW9uL05nRm9yT2YjY2hhbmdlLXByb3BhZ2F0aW9uIGZvciBtb3JlIGluZm9ybWF0aW9uLmApO1xuICAgIH1cbiAgICB0aGlzLl90cmFja0J5Rm4gPSBmbjtcbiAgfVxuICBnZXQgbmdGb3JUcmFja0J5KCkge1xuICAgIHJldHVybiB0aGlzLl90cmFja0J5Rm47XG4gIH1cbiAgX25nRm9yT2YgPSBudWxsO1xuICBfbmdGb3JPZkRpcnR5ID0gdHJ1ZTtcbiAgX2RpZmZlciA9IG51bGw7XG4gIF90cmFja0J5Rm47XG4gIGNvbnN0cnVjdG9yKF92aWV3Q29udGFpbmVyLCBfdGVtcGxhdGUsIF9kaWZmZXJzKSB7XG4gICAgdGhpcy5fdmlld0NvbnRhaW5lciA9IF92aWV3Q29udGFpbmVyO1xuICAgIHRoaXMuX3RlbXBsYXRlID0gX3RlbXBsYXRlO1xuICAgIHRoaXMuX2RpZmZlcnMgPSBfZGlmZmVycztcbiAgfVxuICBzZXQgbmdGb3JUZW1wbGF0ZSh2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSkge1xuICAgICAgdGhpcy5fdGVtcGxhdGUgPSB2YWx1ZTtcbiAgICB9XG4gIH1cbiAgbmdEb0NoZWNrKCkge1xuICAgIGlmICh0aGlzLl9uZ0Zvck9mRGlydHkpIHtcbiAgICAgIHRoaXMuX25nRm9yT2ZEaXJ0eSA9IGZhbHNlO1xuICAgICAgY29uc3QgdmFsdWUgPSB0aGlzLl9uZ0Zvck9mO1xuICAgICAgaWYgKCF0aGlzLl9kaWZmZXIgJiYgdmFsdWUpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLl9kaWZmZXIgPSB0aGlzLl9kaWZmZXJzLmZpbmQodmFsdWUpLmNyZWF0ZSh0aGlzLm5nRm9yVHJhY2tCeSk7XG4gICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICBsZXQgZXJyb3JNZXNzYWdlID0gYENhbm5vdCBmaW5kIGEgZGlmZmVyIHN1cHBvcnRpbmcgb2JqZWN0ICcke3ZhbHVlfScgb2YgdHlwZSAnYCArIGAke2dldFR5cGVOYW1lKHZhbHVlKX0nLiBOZ0ZvciBvbmx5IHN1cHBvcnRzIGJpbmRpbmcgdG8gSXRlcmFibGVzLCBzdWNoIGFzIEFycmF5cy5gO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgICAgICAgZXJyb3JNZXNzYWdlICs9ICcgRGlkIHlvdSBtZWFuIHRvIHVzZSB0aGUga2V5dmFsdWUgcGlwZT8nO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoLTIyMDAsIGVycm9yTWVzc2FnZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuX2RpZmZlciA9IHRoaXMuX2RpZmZlcnMuZmluZCh2YWx1ZSkuY3JlYXRlKHRoaXMubmdGb3JUcmFja0J5KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5fZGlmZmVyKSB7XG4gICAgICBjb25zdCBjaGFuZ2VzID0gdGhpcy5fZGlmZmVyLmRpZmYodGhpcy5fbmdGb3JPZik7XG4gICAgICBpZiAoY2hhbmdlcykgdGhpcy5fYXBwbHlDaGFuZ2VzKGNoYW5nZXMpO1xuICAgIH1cbiAgfVxuICBfYXBwbHlDaGFuZ2VzKGNoYW5nZXMpIHtcbiAgICBjb25zdCB2aWV3Q29udGFpbmVyID0gdGhpcy5fdmlld0NvbnRhaW5lcjtcbiAgICBjaGFuZ2VzLmZvckVhY2hPcGVyYXRpb24oKGl0ZW0sIGFkanVzdGVkUHJldmlvdXNJbmRleCwgY3VycmVudEluZGV4KSA9PiB7XG4gICAgICBpZiAoaXRlbS5wcmV2aW91c0luZGV4ID09IG51bGwpIHtcbiAgICAgICAgdmlld0NvbnRhaW5lci5jcmVhdGVFbWJlZGRlZFZpZXcodGhpcy5fdGVtcGxhdGUsIG5ldyBOZ0Zvck9mQ29udGV4dChpdGVtLml0ZW0sIHRoaXMuX25nRm9yT2YsIC0xLCAtMSksIGN1cnJlbnRJbmRleCA9PT0gbnVsbCA/IHVuZGVmaW5lZCA6IGN1cnJlbnRJbmRleCk7XG4gICAgICB9IGVsc2UgaWYgKGN1cnJlbnRJbmRleCA9PSBudWxsKSB7XG4gICAgICAgIHZpZXdDb250YWluZXIucmVtb3ZlKGFkanVzdGVkUHJldmlvdXNJbmRleCA9PT0gbnVsbCA/IHVuZGVmaW5lZCA6IGFkanVzdGVkUHJldmlvdXNJbmRleCk7XG4gICAgICB9IGVsc2UgaWYgKGFkanVzdGVkUHJldmlvdXNJbmRleCAhPT0gbnVsbCkge1xuICAgICAgICBjb25zdCB2aWV3ID0gdmlld0NvbnRhaW5lci5nZXQoYWRqdXN0ZWRQcmV2aW91c0luZGV4KTtcbiAgICAgICAgdmlld0NvbnRhaW5lci5tb3ZlKHZpZXcsIGN1cnJlbnRJbmRleCk7XG4gICAgICAgIGFwcGx5Vmlld0NoYW5nZSh2aWV3LCBpdGVtKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBmb3IgKGxldCBpID0gMCwgaWxlbiA9IHZpZXdDb250YWluZXIubGVuZ3RoOyBpIDwgaWxlbjsgaSsrKSB7XG4gICAgICBjb25zdCB2aWV3UmVmID0gdmlld0NvbnRhaW5lci5nZXQoaSk7XG4gICAgICBjb25zdCBjb250ZXh0ID0gdmlld1JlZi5jb250ZXh0O1xuICAgICAgY29udGV4dC5pbmRleCA9IGk7XG4gICAgICBjb250ZXh0LmNvdW50ID0gaWxlbjtcbiAgICAgIGNvbnRleHQubmdGb3JPZiA9IHRoaXMuX25nRm9yT2Y7XG4gICAgfVxuICAgIGNoYW5nZXMuZm9yRWFjaElkZW50aXR5Q2hhbmdlKHJlY29yZCA9PiB7XG4gICAgICBjb25zdCB2aWV3UmVmID0gdmlld0NvbnRhaW5lci5nZXQocmVjb3JkLmN1cnJlbnRJbmRleCk7XG4gICAgICBhcHBseVZpZXdDaGFuZ2Uodmlld1JlZiwgcmVjb3JkKTtcbiAgICB9KTtcbiAgfVxuICBzdGF0aWMgbmdUZW1wbGF0ZUNvbnRleHRHdWFyZChkaXIsIGN0eCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIE5nRm9yT2ZfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ0Zvck9mKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlZpZXdDb250YWluZXJSZWYpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlRlbXBsYXRlUmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5JdGVyYWJsZURpZmZlcnMpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdGb3JPZixcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJuZ0ZvclwiLCBcIlwiLCBcIm5nRm9yT2ZcIiwgXCJcIl1dLFxuICAgIGlucHV0czoge1xuICAgICAgbmdGb3JPZjogXCJuZ0Zvck9mXCIsXG4gICAgICBuZ0ZvclRyYWNrQnk6IFwibmdGb3JUcmFja0J5XCIsXG4gICAgICBuZ0ZvclRlbXBsYXRlOiBcIm5nRm9yVGVtcGxhdGVcIlxuICAgIH1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ0Zvck9mLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdbbmdGb3JdW25nRm9yT2ZdJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IGkwLlZpZXdDb250YWluZXJSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkwLlRlbXBsYXRlUmVmXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5JdGVyYWJsZURpZmZlcnNcbiAgfV0sIHtcbiAgICBuZ0Zvck9mOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBuZ0ZvclRyYWNrQnk6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG5nRm9yVGVtcGxhdGU6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmZ1bmN0aW9uIGFwcGx5Vmlld0NoYW5nZSh2aWV3LCByZWNvcmQpIHtcbiAgdmlldy5jb250ZXh0LiRpbXBsaWNpdCA9IHJlY29yZC5pdGVtO1xufVxuZnVuY3Rpb24gZ2V0VHlwZU5hbWUodHlwZSkge1xuICByZXR1cm4gdHlwZVsnbmFtZSddIHx8IHR5cGVvZiB0eXBlO1xufVxuY2xhc3MgTmdJZiB7XG4gIF92aWV3Q29udGFpbmVyO1xuICBfY29udGV4dCA9IG5ldyBOZ0lmQ29udGV4dCgpO1xuICBfdGhlblRlbXBsYXRlUmVmID0gbnVsbDtcbiAgX2Vsc2VUZW1wbGF0ZVJlZiA9IG51bGw7XG4gIF90aGVuVmlld1JlZiA9IG51bGw7XG4gIF9lbHNlVmlld1JlZiA9IG51bGw7XG4gIGNvbnN0cnVjdG9yKF92aWV3Q29udGFpbmVyLCB0ZW1wbGF0ZVJlZikge1xuICAgIHRoaXMuX3ZpZXdDb250YWluZXIgPSBfdmlld0NvbnRhaW5lcjtcbiAgICB0aGlzLl90aGVuVGVtcGxhdGVSZWYgPSB0ZW1wbGF0ZVJlZjtcbiAgfVxuICBzZXQgbmdJZihjb25kaXRpb24pIHtcbiAgICB0aGlzLl9jb250ZXh0LiRpbXBsaWNpdCA9IHRoaXMuX2NvbnRleHQubmdJZiA9IGNvbmRpdGlvbjtcbiAgICB0aGlzLl91cGRhdGVWaWV3KCk7XG4gIH1cbiAgc2V0IG5nSWZUaGVuKHRlbXBsYXRlUmVmKSB7XG4gICAgYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGVSZWYsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICduZ0lmVGhlbicpO1xuICAgIHRoaXMuX3RoZW5UZW1wbGF0ZVJlZiA9IHRlbXBsYXRlUmVmO1xuICAgIHRoaXMuX3RoZW5WaWV3UmVmID0gbnVsbDtcbiAgICB0aGlzLl91cGRhdGVWaWV3KCk7XG4gIH1cbiAgc2V0IG5nSWZFbHNlKHRlbXBsYXRlUmVmKSB7XG4gICAgYXNzZXJ0VGVtcGxhdGUodGVtcGxhdGVSZWYsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICduZ0lmRWxzZScpO1xuICAgIHRoaXMuX2Vsc2VUZW1wbGF0ZVJlZiA9IHRlbXBsYXRlUmVmO1xuICAgIHRoaXMuX2Vsc2VWaWV3UmVmID0gbnVsbDtcbiAgICB0aGlzLl91cGRhdGVWaWV3KCk7XG4gIH1cbiAgX3VwZGF0ZVZpZXcoKSB7XG4gICAgaWYgKHRoaXMuX2NvbnRleHQuJGltcGxpY2l0KSB7XG4gICAgICBpZiAoIXRoaXMuX3RoZW5WaWV3UmVmKSB7XG4gICAgICAgIHRoaXMuX3ZpZXdDb250YWluZXIuY2xlYXIoKTtcbiAgICAgICAgdGhpcy5fZWxzZVZpZXdSZWYgPSBudWxsO1xuICAgICAgICBpZiAodGhpcy5fdGhlblRlbXBsYXRlUmVmKSB7XG4gICAgICAgICAgdGhpcy5fdGhlblZpZXdSZWYgPSB0aGlzLl92aWV3Q29udGFpbmVyLmNyZWF0ZUVtYmVkZGVkVmlldyh0aGlzLl90aGVuVGVtcGxhdGVSZWYsIHRoaXMuX2NvbnRleHQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghdGhpcy5fZWxzZVZpZXdSZWYpIHtcbiAgICAgICAgdGhpcy5fdmlld0NvbnRhaW5lci5jbGVhcigpO1xuICAgICAgICB0aGlzLl90aGVuVmlld1JlZiA9IG51bGw7XG4gICAgICAgIGlmICh0aGlzLl9lbHNlVGVtcGxhdGVSZWYpIHtcbiAgICAgICAgICB0aGlzLl9lbHNlVmlld1JlZiA9IHRoaXMuX3ZpZXdDb250YWluZXIuY3JlYXRlRW1iZWRkZWRWaWV3KHRoaXMuX2Vsc2VUZW1wbGF0ZVJlZiwgdGhpcy5fY29udGV4dCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc3RhdGljIG5nSWZVc2VJZlR5cGVHdWFyZDtcbiAgc3RhdGljIG5nVGVtcGxhdGVHdWFyZF9uZ0lmO1xuICBzdGF0aWMgbmdUZW1wbGF0ZUNvbnRleHRHdWFyZChkaXIsIGN0eCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIE5nSWZfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ0lmKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlZpZXdDb250YWluZXJSZWYpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlRlbXBsYXRlUmVmKSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE5nSWYsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwibmdJZlwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuZ0lmOiBcIm5nSWZcIixcbiAgICAgIG5nSWZUaGVuOiBcIm5nSWZUaGVuXCIsXG4gICAgICBuZ0lmRWxzZTogXCJuZ0lmRWxzZVwiXG4gICAgfVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nSWYsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tuZ0lmXSdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBpMC5WaWV3Q29udGFpbmVyUmVmXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5UZW1wbGF0ZVJlZlxuICB9XSwge1xuICAgIG5nSWY6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG5nSWZUaGVuOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBuZ0lmRWxzZTogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY2xhc3MgTmdJZkNvbnRleHQge1xuICAkaW1wbGljaXQgPSBudWxsO1xuICBuZ0lmID0gbnVsbDtcbn1cbmZ1bmN0aW9uIGFzc2VydFRlbXBsYXRlKHRlbXBsYXRlUmVmLCBwcm9wZXJ0eSkge1xuICBpZiAodGVtcGxhdGVSZWYgJiYgIXRlbXBsYXRlUmVmLmNyZWF0ZUVtYmVkZGVkVmlldykge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDIwMjAsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGAke3Byb3BlcnR5fSBtdXN0IGJlIGEgVGVtcGxhdGVSZWYsIGJ1dCByZWNlaXZlZCAnJHtfc3RyaW5naWZ5KHRlbXBsYXRlUmVmKX0nLmApO1xuICB9XG59XG5jbGFzcyBTd2l0Y2hWaWV3IHtcbiAgX3ZpZXdDb250YWluZXJSZWY7XG4gIF90ZW1wbGF0ZVJlZjtcbiAgX2NyZWF0ZWQgPSBmYWxzZTtcbiAgY29uc3RydWN0b3IoX3ZpZXdDb250YWluZXJSZWYsIF90ZW1wbGF0ZVJlZikge1xuICAgIHRoaXMuX3ZpZXdDb250YWluZXJSZWYgPSBfdmlld0NvbnRhaW5lclJlZjtcbiAgICB0aGlzLl90ZW1wbGF0ZVJlZiA9IF90ZW1wbGF0ZVJlZjtcbiAgfVxuICBjcmVhdGUoKSB7XG4gICAgdGhpcy5fY3JlYXRlZCA9IHRydWU7XG4gICAgdGhpcy5fdmlld0NvbnRhaW5lclJlZi5jcmVhdGVFbWJlZGRlZFZpZXcodGhpcy5fdGVtcGxhdGVSZWYpO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fY3JlYXRlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3ZpZXdDb250YWluZXJSZWYuY2xlYXIoKTtcbiAgfVxuICBlbmZvcmNlU3RhdGUoY3JlYXRlZCkge1xuICAgIGlmIChjcmVhdGVkICYmICF0aGlzLl9jcmVhdGVkKSB7XG4gICAgICB0aGlzLmNyZWF0ZSgpO1xuICAgIH0gZWxzZSBpZiAoIWNyZWF0ZWQgJiYgdGhpcy5fY3JlYXRlZCkge1xuICAgICAgdGhpcy5kZXN0cm95KCk7XG4gICAgfVxuICB9XG59XG5jbGFzcyBOZ1N3aXRjaCB7XG4gIF9kZWZhdWx0Vmlld3MgPSBbXTtcbiAgX2RlZmF1bHRVc2VkID0gZmFsc2U7XG4gIF9jYXNlQ291bnQgPSAwO1xuICBfbGFzdENhc2VDaGVja0luZGV4ID0gMDtcbiAgX2xhc3RDYXNlc01hdGNoZWQgPSBmYWxzZTtcbiAgX25nU3dpdGNoO1xuICBzZXQgbmdTd2l0Y2gobmV3VmFsdWUpIHtcbiAgICB0aGlzLl9uZ1N3aXRjaCA9IG5ld1ZhbHVlO1xuICAgIGlmICh0aGlzLl9jYXNlQ291bnQgPT09IDApIHtcbiAgICAgIHRoaXMuX3VwZGF0ZURlZmF1bHRDYXNlcyh0cnVlKTtcbiAgICB9XG4gIH1cbiAgX2FkZENhc2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Nhc2VDb3VudCsrO1xuICB9XG4gIF9hZGREZWZhdWx0KHZpZXcpIHtcbiAgICB0aGlzLl9kZWZhdWx0Vmlld3MucHVzaCh2aWV3KTtcbiAgfVxuICBfbWF0Y2hDYXNlKHZhbHVlKSB7XG4gICAgY29uc3QgbWF0Y2hlZCA9IHZhbHVlID09PSB0aGlzLl9uZ1N3aXRjaDtcbiAgICB0aGlzLl9sYXN0Q2FzZXNNYXRjaGVkIHx8PSBtYXRjaGVkO1xuICAgIHRoaXMuX2xhc3RDYXNlQ2hlY2tJbmRleCsrO1xuICAgIGlmICh0aGlzLl9sYXN0Q2FzZUNoZWNrSW5kZXggPT09IHRoaXMuX2Nhc2VDb3VudCkge1xuICAgICAgdGhpcy5fdXBkYXRlRGVmYXVsdENhc2VzKCF0aGlzLl9sYXN0Q2FzZXNNYXRjaGVkKTtcbiAgICAgIHRoaXMuX2xhc3RDYXNlQ2hlY2tJbmRleCA9IDA7XG4gICAgICB0aGlzLl9sYXN0Q2FzZXNNYXRjaGVkID0gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBtYXRjaGVkO1xuICB9XG4gIF91cGRhdGVEZWZhdWx0Q2FzZXModXNlRGVmYXVsdCkge1xuICAgIGlmICh0aGlzLl9kZWZhdWx0Vmlld3MubGVuZ3RoID4gMCAmJiB1c2VEZWZhdWx0ICE9PSB0aGlzLl9kZWZhdWx0VXNlZCkge1xuICAgICAgdGhpcy5fZGVmYXVsdFVzZWQgPSB1c2VEZWZhdWx0O1xuICAgICAgZm9yIChjb25zdCBkZWZhdWx0VmlldyBvZiB0aGlzLl9kZWZhdWx0Vmlld3MpIHtcbiAgICAgICAgZGVmYXVsdFZpZXcuZW5mb3JjZVN0YXRlKHVzZURlZmF1bHQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOZ1N3aXRjaF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdTd2l0Y2gpKCk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE5nU3dpdGNoLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcIm5nU3dpdGNoXCIsIFwiXCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG5nU3dpdGNoOiBcIm5nU3dpdGNoXCJcbiAgICB9XG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmdTd2l0Y2gsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tuZ1N3aXRjaF0nXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICBuZ1N3aXRjaDogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY2xhc3MgTmdTd2l0Y2hDYXNlIHtcbiAgbmdTd2l0Y2g7XG4gIF92aWV3O1xuICBuZ1N3aXRjaENhc2U7XG4gIGNvbnN0cnVjdG9yKHZpZXdDb250YWluZXIsIHRlbXBsYXRlUmVmLCBuZ1N3aXRjaCkge1xuICAgIHRoaXMubmdTd2l0Y2ggPSBuZ1N3aXRjaDtcbiAgICBpZiAoKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgIW5nU3dpdGNoKSB7XG4gICAgICB0aHJvd05nU3dpdGNoUHJvdmlkZXJOb3RGb3VuZEVycm9yKCduZ1N3aXRjaENhc2UnLCAnTmdTd2l0Y2hDYXNlJyk7XG4gICAgfVxuICAgIG5nU3dpdGNoLl9hZGRDYXNlKCk7XG4gICAgdGhpcy5fdmlldyA9IG5ldyBTd2l0Y2hWaWV3KHZpZXdDb250YWluZXIsIHRlbXBsYXRlUmVmKTtcbiAgfVxuICBuZ0RvQ2hlY2soKSB7XG4gICAgdGhpcy5fdmlldy5lbmZvcmNlU3RhdGUodGhpcy5uZ1N3aXRjaC5fbWF0Y2hDYXNlKHRoaXMubmdTd2l0Y2hDYXNlKSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdTd2l0Y2hDYXNlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdTd2l0Y2hDYXNlKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlZpZXdDb250YWluZXJSZWYpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlRlbXBsYXRlUmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChOZ1N3aXRjaCwgOSkpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBOZ1N3aXRjaENhc2UsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwibmdTd2l0Y2hDYXNlXCIsIFwiXCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG5nU3dpdGNoQ2FzZTogXCJuZ1N3aXRjaENhc2VcIlxuICAgIH1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ1N3aXRjaENhc2UsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tuZ1N3aXRjaENhc2VdJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IGkwLlZpZXdDb250YWluZXJSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkwLlRlbXBsYXRlUmVmXG4gIH0sIHtcbiAgICB0eXBlOiBOZ1N3aXRjaCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9LCB7XG4gICAgICB0eXBlOiBIb3N0XG4gICAgfV1cbiAgfV0sIHtcbiAgICBuZ1N3aXRjaENhc2U6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNsYXNzIE5nU3dpdGNoRGVmYXVsdCB7XG4gIGNvbnN0cnVjdG9yKHZpZXdDb250YWluZXIsIHRlbXBsYXRlUmVmLCBuZ1N3aXRjaCkge1xuICAgIGlmICgodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiAhbmdTd2l0Y2gpIHtcbiAgICAgIHRocm93TmdTd2l0Y2hQcm92aWRlck5vdEZvdW5kRXJyb3IoJ25nU3dpdGNoRGVmYXVsdCcsICdOZ1N3aXRjaERlZmF1bHQnKTtcbiAgICB9XG4gICAgbmdTd2l0Y2guX2FkZERlZmF1bHQobmV3IFN3aXRjaFZpZXcodmlld0NvbnRhaW5lciwgdGVtcGxhdGVSZWYpKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOZ1N3aXRjaERlZmF1bHRfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ1N3aXRjaERlZmF1bHQpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuVmlld0NvbnRhaW5lclJlZiksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuVGVtcGxhdGVSZWYpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5nU3dpdGNoLCA5KSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IE5nU3dpdGNoRGVmYXVsdCxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJuZ1N3aXRjaERlZmF1bHRcIiwgXCJcIl1dXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmdTd2l0Y2hEZWZhdWx0LCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdbbmdTd2l0Y2hEZWZhdWx0XSdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBpMC5WaWV3Q29udGFpbmVyUmVmXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5UZW1wbGF0ZVJlZlxuICB9LCB7XG4gICAgdHlwZTogTmdTd2l0Y2gsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IE9wdGlvbmFsXG4gICAgfSwge1xuICAgICAgdHlwZTogSG9zdFxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiB0aHJvd05nU3dpdGNoUHJvdmlkZXJOb3RGb3VuZEVycm9yKGF0dHJOYW1lLCBkaXJlY3RpdmVOYW1lKSB7XG4gIHRocm93IG5ldyBfUnVudGltZUVycm9yKDIwMDAsIGBBbiBlbGVtZW50IHdpdGggdGhlIFwiJHthdHRyTmFtZX1cIiBhdHRyaWJ1dGUgYCArIGAobWF0Y2hpbmcgdGhlIFwiJHtkaXJlY3RpdmVOYW1lfVwiIGRpcmVjdGl2ZSkgbXVzdCBiZSBsb2NhdGVkIGluc2lkZSBhbiBlbGVtZW50IHdpdGggdGhlIFwibmdTd2l0Y2hcIiBhdHRyaWJ1dGUgYCArIGAobWF0Y2hpbmcgXCJOZ1N3aXRjaFwiIGRpcmVjdGl2ZSlgKTtcbn1cbmNsYXNzIE5nUGx1cmFsIHtcbiAgX2xvY2FsaXphdGlvbjtcbiAgX2FjdGl2ZVZpZXc7XG4gIF9jYXNlVmlld3MgPSB7fTtcbiAgY29uc3RydWN0b3IoX2xvY2FsaXphdGlvbikge1xuICAgIHRoaXMuX2xvY2FsaXphdGlvbiA9IF9sb2NhbGl6YXRpb247XG4gIH1cbiAgc2V0IG5nUGx1cmFsKHZhbHVlKSB7XG4gICAgdGhpcy5fdXBkYXRlVmlldyh2YWx1ZSk7XG4gIH1cbiAgYWRkQ2FzZSh2YWx1ZSwgc3dpdGNoVmlldykge1xuICAgIHRoaXMuX2Nhc2VWaWV3c1t2YWx1ZV0gPSBzd2l0Y2hWaWV3O1xuICB9XG4gIF91cGRhdGVWaWV3KHN3aXRjaFZhbHVlKSB7XG4gICAgdGhpcy5fY2xlYXJWaWV3cygpO1xuICAgIGNvbnN0IGNhc2VzID0gT2JqZWN0LmtleXModGhpcy5fY2FzZVZpZXdzKTtcbiAgICBjb25zdCBrZXkgPSBnZXRQbHVyYWxDYXRlZ29yeShzd2l0Y2hWYWx1ZSwgY2FzZXMsIHRoaXMuX2xvY2FsaXphdGlvbik7XG4gICAgdGhpcy5fYWN0aXZhdGVWaWV3KHRoaXMuX2Nhc2VWaWV3c1trZXldKTtcbiAgfVxuICBfY2xlYXJWaWV3cygpIHtcbiAgICBpZiAodGhpcy5fYWN0aXZlVmlldykgdGhpcy5fYWN0aXZlVmlldy5kZXN0cm95KCk7XG4gIH1cbiAgX2FjdGl2YXRlVmlldyh2aWV3KSB7XG4gICAgaWYgKHZpZXcpIHtcbiAgICAgIHRoaXMuX2FjdGl2ZVZpZXcgPSB2aWV3O1xuICAgICAgdGhpcy5fYWN0aXZlVmlldy5jcmVhdGUoKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdQbHVyYWxfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ1BsdXJhbCkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChOZ0xvY2FsaXphdGlvbikpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBOZ1BsdXJhbCxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJuZ1BsdXJhbFwiLCBcIlwiXV0sXG4gICAgaW5wdXRzOiB7XG4gICAgICBuZ1BsdXJhbDogXCJuZ1BsdXJhbFwiXG4gICAgfVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nUGx1cmFsLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdbbmdQbHVyYWxdJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IE5nTG9jYWxpemF0aW9uXG4gIH1dLCB7XG4gICAgbmdQbHVyYWw6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNsYXNzIE5nUGx1cmFsQ2FzZSB7XG4gIHZhbHVlO1xuICBjb25zdHJ1Y3Rvcih2YWx1ZSwgdGVtcGxhdGUsIHZpZXdDb250YWluZXIsIG5nUGx1cmFsKSB7XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICAgIGNvbnN0IGlzQU51bWJlciA9ICFpc05hTihOdW1iZXIodmFsdWUpKTtcbiAgICBuZ1BsdXJhbC5hZGRDYXNlKGlzQU51bWJlciA/IGA9JHt2YWx1ZX1gIDogdmFsdWUsIG5ldyBTd2l0Y2hWaWV3KHZpZXdDb250YWluZXIsIHRlbXBsYXRlKSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdQbHVyYWxDYXNlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdQbHVyYWxDYXNlKShpMC7Jtcm1aW5qZWN0QXR0cmlidXRlKCduZ1BsdXJhbENhc2UnKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5UZW1wbGF0ZVJlZiksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuVmlld0NvbnRhaW5lclJlZiksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoTmdQbHVyYWwsIDEpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdQbHVyYWxDYXNlLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcIm5nUGx1cmFsQ2FzZVwiLCBcIlwiXV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ1BsdXJhbENhc2UsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tuZ1BsdXJhbENhc2VdJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogQXR0cmlidXRlLFxuICAgICAgYXJnczogWyduZ1BsdXJhbENhc2UnXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5UZW1wbGF0ZVJlZlxuICB9LCB7XG4gICAgdHlwZTogaTAuVmlld0NvbnRhaW5lclJlZlxuICB9LCB7XG4gICAgdHlwZTogTmdQbHVyYWwsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEhvc3RcbiAgICB9XVxuICB9XSwgbnVsbCk7XG59KSgpO1xuY2xhc3MgTmdTdHlsZSB7XG4gIF9uZ0VsO1xuICBfZGlmZmVycztcbiAgX3JlbmRlcmVyO1xuICBfbmdTdHlsZSA9IG51bGw7XG4gIF9kaWZmZXIgPSBudWxsO1xuICBjb25zdHJ1Y3RvcihfbmdFbCwgX2RpZmZlcnMsIF9yZW5kZXJlcikge1xuICAgIHRoaXMuX25nRWwgPSBfbmdFbDtcbiAgICB0aGlzLl9kaWZmZXJzID0gX2RpZmZlcnM7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBfcmVuZGVyZXI7XG4gIH1cbiAgc2V0IG5nU3R5bGUodmFsdWVzKSB7XG4gICAgdGhpcy5fbmdTdHlsZSA9IHZhbHVlcztcbiAgICBpZiAoIXRoaXMuX2RpZmZlciAmJiB2YWx1ZXMpIHtcbiAgICAgIHRoaXMuX2RpZmZlciA9IHRoaXMuX2RpZmZlcnMuZmluZCh2YWx1ZXMpLmNyZWF0ZSgpO1xuICAgIH1cbiAgfVxuICBuZ0RvQ2hlY2soKSB7XG4gICAgaWYgKHRoaXMuX2RpZmZlcikge1xuICAgICAgY29uc3QgY2hhbmdlcyA9IHRoaXMuX2RpZmZlci5kaWZmKHRoaXMuX25nU3R5bGUpO1xuICAgICAgaWYgKGNoYW5nZXMpIHtcbiAgICAgICAgdGhpcy5fYXBwbHlDaGFuZ2VzKGNoYW5nZXMpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBfc2V0U3R5bGUobmFtZUFuZFVuaXQsIHZhbHVlKSB7XG4gICAgY29uc3QgW25hbWUsIHVuaXRdID0gbmFtZUFuZFVuaXQuc3BsaXQoJy4nKTtcbiAgICBjb25zdCBmbGFncyA9IG5hbWUuaW5kZXhPZignLScpID09PSAtMSA/IHVuZGVmaW5lZCA6IFJlbmRlcmVyU3R5bGVGbGFnczIuRGFzaENhc2U7XG4gICAgaWYgKHZhbHVlICE9IG51bGwpIHtcbiAgICAgIHRoaXMuX3JlbmRlcmVyLnNldFN0eWxlKHRoaXMuX25nRWwubmF0aXZlRWxlbWVudCwgbmFtZSwgdW5pdCA/IGAke3ZhbHVlfSR7dW5pdH1gIDogdmFsdWUsIGZsYWdzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fcmVuZGVyZXIucmVtb3ZlU3R5bGUodGhpcy5fbmdFbC5uYXRpdmVFbGVtZW50LCBuYW1lLCBmbGFncyk7XG4gICAgfVxuICB9XG4gIF9hcHBseUNoYW5nZXMoY2hhbmdlcykge1xuICAgIGNoYW5nZXMuZm9yRWFjaFJlbW92ZWRJdGVtKHJlY29yZCA9PiB0aGlzLl9zZXRTdHlsZShyZWNvcmQua2V5LCBudWxsKSk7XG4gICAgY2hhbmdlcy5mb3JFYWNoQWRkZWRJdGVtKHJlY29yZCA9PiB0aGlzLl9zZXRTdHlsZShyZWNvcmQua2V5LCByZWNvcmQuY3VycmVudFZhbHVlKSk7XG4gICAgY2hhbmdlcy5mb3JFYWNoQ2hhbmdlZEl0ZW0ocmVjb3JkID0+IHRoaXMuX3NldFN0eWxlKHJlY29yZC5rZXksIHJlY29yZC5jdXJyZW50VmFsdWUpKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOZ1N0eWxlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdTdHlsZSkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5FbGVtZW50UmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5LZXlWYWx1ZURpZmZlcnMpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlJlbmRlcmVyMikpO1xuICB9O1xuICBzdGF0aWMgybVkaXIgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lRGlyZWN0aXZlKHtcbiAgICB0eXBlOiBOZ1N0eWxlLFxuICAgIHNlbGVjdG9yczogW1tcIlwiLCBcIm5nU3R5bGVcIiwgXCJcIl1dLFxuICAgIGlucHV0czoge1xuICAgICAgbmdTdHlsZTogXCJuZ1N0eWxlXCJcbiAgICB9XG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmdTdHlsZSwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW25nU3R5bGVdJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IGkwLkVsZW1lbnRSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkwLktleVZhbHVlRGlmZmVyc1xuICB9LCB7XG4gICAgdHlwZTogaTAuUmVuZGVyZXIyXG4gIH1dLCB7XG4gICAgbmdTdHlsZTogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogWyduZ1N0eWxlJ11cbiAgICB9XVxuICB9KTtcbn0pKCk7XG5jbGFzcyBOZ1RlbXBsYXRlT3V0bGV0IHtcbiAgX3ZpZXdDb250YWluZXJSZWY7XG4gIF92aWV3UmVmID0gbnVsbDtcbiAgbmdUZW1wbGF0ZU91dGxldENvbnRleHQgPSBudWxsO1xuICBuZ1RlbXBsYXRlT3V0bGV0ID0gbnVsbDtcbiAgbmdUZW1wbGF0ZU91dGxldEluamVjdG9yID0gbnVsbDtcbiAgaW5qZWN0b3IgPSBpbmplY3QoSW5qZWN0b3IpO1xuICBjb25zdHJ1Y3Rvcihfdmlld0NvbnRhaW5lclJlZikge1xuICAgIHRoaXMuX3ZpZXdDb250YWluZXJSZWYgPSBfdmlld0NvbnRhaW5lclJlZjtcbiAgfVxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzKSB7XG4gICAgaWYgKHRoaXMuX3Nob3VsZFJlY3JlYXRlVmlldyhjaGFuZ2VzKSkge1xuICAgICAgY29uc3Qgdmlld0NvbnRhaW5lclJlZiA9IHRoaXMuX3ZpZXdDb250YWluZXJSZWY7XG4gICAgICBpZiAodGhpcy5fdmlld1JlZikge1xuICAgICAgICB2aWV3Q29udGFpbmVyUmVmLnJlbW92ZSh2aWV3Q29udGFpbmVyUmVmLmluZGV4T2YodGhpcy5fdmlld1JlZikpO1xuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLm5nVGVtcGxhdGVPdXRsZXQpIHtcbiAgICAgICAgdGhpcy5fdmlld1JlZiA9IG51bGw7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHZpZXdDb250ZXh0ID0gdGhpcy5fY3JlYXRlQ29udGV4dEZvcndhcmRQcm94eSgpO1xuICAgICAgdGhpcy5fdmlld1JlZiA9IHZpZXdDb250YWluZXJSZWYuY3JlYXRlRW1iZWRkZWRWaWV3KHRoaXMubmdUZW1wbGF0ZU91dGxldCwgdmlld0NvbnRleHQsIHtcbiAgICAgICAgaW5qZWN0b3I6IHRoaXMuX2dldEluamVjdG9yKClcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBfZ2V0SW5qZWN0b3IoKSB7XG4gICAgaWYgKHRoaXMubmdUZW1wbGF0ZU91dGxldEluamVjdG9yID09PSAnb3V0bGV0Jykge1xuICAgICAgcmV0dXJuIHRoaXMuaW5qZWN0b3I7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5nVGVtcGxhdGVPdXRsZXRJbmplY3RvciA/PyB1bmRlZmluZWQ7XG4gIH1cbiAgX3Nob3VsZFJlY3JlYXRlVmlldyhjaGFuZ2VzKSB7XG4gICAgcmV0dXJuICEhY2hhbmdlc1snbmdUZW1wbGF0ZU91dGxldCddIHx8ICEhY2hhbmdlc1snbmdUZW1wbGF0ZU91dGxldEluamVjdG9yJ107XG4gIH1cbiAgX2NyZWF0ZUNvbnRleHRGb3J3YXJkUHJveHkoKSB7XG4gICAgcmV0dXJuIG5ldyBQcm94eSh7fSwge1xuICAgICAgc2V0OiAoX3RhcmdldCwgcHJvcCwgbmV3VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLm5nVGVtcGxhdGVPdXRsZXRDb250ZXh0KSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBSZWZsZWN0LnNldCh0aGlzLm5nVGVtcGxhdGVPdXRsZXRDb250ZXh0LCBwcm9wLCBuZXdWYWx1ZSk7XG4gICAgICB9LFxuICAgICAgZ2V0OiAoX3RhcmdldCwgcHJvcCwgcmVjZWl2ZXIpID0+IHtcbiAgICAgICAgaWYgKCF0aGlzLm5nVGVtcGxhdGVPdXRsZXRDb250ZXh0KSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUmVmbGVjdC5nZXQodGhpcy5uZ1RlbXBsYXRlT3V0bGV0Q29udGV4dCwgcHJvcCwgcmVjZWl2ZXIpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIE5nVGVtcGxhdGVPdXRsZXRfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOZ1RlbXBsYXRlT3V0bGV0KShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLlZpZXdDb250YWluZXJSZWYpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdUZW1wbGF0ZU91dGxldCxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJuZ1RlbXBsYXRlT3V0bGV0XCIsIFwiXCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG5nVGVtcGxhdGVPdXRsZXRDb250ZXh0OiBcIm5nVGVtcGxhdGVPdXRsZXRDb250ZXh0XCIsXG4gICAgICBuZ1RlbXBsYXRlT3V0bGV0OiBcIm5nVGVtcGxhdGVPdXRsZXRcIixcbiAgICAgIG5nVGVtcGxhdGVPdXRsZXRJbmplY3RvcjogXCJuZ1RlbXBsYXRlT3V0bGV0SW5qZWN0b3JcIlxuICAgIH0sXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5nVGVtcGxhdGVPdXRsZXQsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tuZ1RlbXBsYXRlT3V0bGV0XSdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBpMC5WaWV3Q29udGFpbmVyUmVmXG4gIH1dLCB7XG4gICAgbmdUZW1wbGF0ZU91dGxldENvbnRleHQ6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG5nVGVtcGxhdGVPdXRsZXQ6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG5nVGVtcGxhdGVPdXRsZXRJbmplY3RvcjogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY29uc3QgQ09NTU9OX0RJUkVDVElWRVMgPSBbTmdDbGFzcywgTmdDb21wb25lbnRPdXRsZXQsIE5nRm9yT2YsIE5nSWYsIE5nVGVtcGxhdGVPdXRsZXQsIE5nU3R5bGUsIE5nU3dpdGNoLCBOZ1N3aXRjaENhc2UsIE5nU3dpdGNoRGVmYXVsdCwgTmdQbHVyYWwsIE5nUGx1cmFsQ2FzZV07XG5mdW5jdGlvbiBpbnZhbGlkUGlwZUFyZ3VtZW50RXJyb3IodHlwZSwgdmFsdWUpIHtcbiAgcmV0dXJuIG5ldyBfUnVudGltZUVycm9yKDIxMDAsIG5nRGV2TW9kZSAmJiBgSW52YWxpZFBpcGVBcmd1bWVudDogJyR7dmFsdWV9JyBmb3IgcGlwZSAnJHtfc3RyaW5naWZ5KHR5cGUpfSdgKTtcbn1cbmZ1bmN0aW9uIHdhcm5JZlNpZ25hbChwaXBlTmFtZSwgdmFsdWUpIHtcbiAgaWYgKGlzU2lnbmFsKHZhbHVlKSkge1xuICAgIGNvbnNvbGUud2FybihgVGhlICR7cGlwZU5hbWV9IGRvZXMgbm90IHVud3JhcCBzaWduYWxzLiBSZWNlaXZlZCBhIHNpZ25hbCB3aXRoIHZhbHVlOmAsIHZhbHVlKCkpO1xuICB9XG59XG5jbGFzcyBTdWJzY3JpYmFibGVTdHJhdGVneSB7XG4gIGNyZWF0ZVN1YnNjcmlwdGlvbihhc3luYywgdXBkYXRlTGF0ZXN0VmFsdWUsIG9uRXJyb3IpIHtcbiAgICByZXR1cm4gdW50cmFja2VkKCgpID0+IGFzeW5jLnN1YnNjcmliZSh7XG4gICAgICBuZXh0OiB1cGRhdGVMYXRlc3RWYWx1ZSxcbiAgICAgIGVycm9yOiBvbkVycm9yXG4gICAgfSkpO1xuICB9XG4gIGRpc3Bvc2Uoc3Vic2NyaXB0aW9uKSB7XG4gICAgdW50cmFja2VkKCgpID0+IHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpKTtcbiAgfVxufVxuY2xhc3MgUHJvbWlzZVN0cmF0ZWd5IHtcbiAgY3JlYXRlU3Vic2NyaXB0aW9uKGFzeW5jLCB1cGRhdGVMYXRlc3RWYWx1ZSwgb25FcnJvcikge1xuICAgIGFzeW5jLnRoZW4odiA9PiB1cGRhdGVMYXRlc3RWYWx1ZT8uKHYpLCBlID0+IG9uRXJyb3I/LihlKSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHVuc3Vic2NyaWJlOiAoKSA9PiB7XG4gICAgICAgIHVwZGF0ZUxhdGVzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgb25FcnJvciA9IG51bGw7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuICBkaXNwb3NlKHN1YnNjcmlwdGlvbikge1xuICAgIHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICB9XG59XG5jb25zdCBfcHJvbWlzZVN0cmF0ZWd5ID0gbmV3IFByb21pc2VTdHJhdGVneSgpO1xuY29uc3QgX3N1YnNjcmliYWJsZVN0cmF0ZWd5ID0gbmV3IFN1YnNjcmliYWJsZVN0cmF0ZWd5KCk7XG5jbGFzcyBBc3luY1BpcGUge1xuICBfcmVmO1xuICBfbGF0ZXN0VmFsdWUgPSBudWxsO1xuICBtYXJrRm9yQ2hlY2tPblZhbHVlVXBkYXRlID0gdHJ1ZTtcbiAgX3N1YnNjcmlwdGlvbiA9IG51bGw7XG4gIF9vYmogPSBudWxsO1xuICBfc3RyYXRlZ3kgPSBudWxsO1xuICBhcHBsaWNhdGlvbkVycm9ySGFuZGxlciA9IGluamVjdChfSU5URVJOQUxfQVBQTElDQVRJT05fRVJST1JfSEFORExFUik7XG4gIGNvbnN0cnVjdG9yKHJlZikge1xuICAgIHRoaXMuX3JlZiA9IHJlZjtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5fc3Vic2NyaXB0aW9uKSB7XG4gICAgICB0aGlzLl9kaXNwb3NlKCk7XG4gICAgfVxuICAgIHRoaXMuX3JlZiA9IG51bGw7XG4gIH1cbiAgdHJhbnNmb3JtKG9iaikge1xuICAgIGlmICghdGhpcy5fb2JqKSB7XG4gICAgICBpZiAob2JqKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgdGhpcy5tYXJrRm9yQ2hlY2tPblZhbHVlVXBkYXRlID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5fc3Vic2NyaWJlKG9iaik7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgdGhpcy5tYXJrRm9yQ2hlY2tPblZhbHVlVXBkYXRlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuX2xhdGVzdFZhbHVlO1xuICAgIH1cbiAgICBpZiAob2JqICE9PSB0aGlzLl9vYmopIHtcbiAgICAgIHRoaXMuX2Rpc3Bvc2UoKTtcbiAgICAgIHJldHVybiB0aGlzLnRyYW5zZm9ybShvYmopO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fbGF0ZXN0VmFsdWU7XG4gIH1cbiAgX3N1YnNjcmliZShvYmopIHtcbiAgICB0aGlzLl9vYmogPSBvYmo7XG4gICAgdGhpcy5fc3RyYXRlZ3kgPSB0aGlzLl9zZWxlY3RTdHJhdGVneShvYmopO1xuICAgIHRoaXMuX3N1YnNjcmlwdGlvbiA9IHRoaXMuX3N0cmF0ZWd5LmNyZWF0ZVN1YnNjcmlwdGlvbihvYmosIHZhbHVlID0+IHRoaXMuX3VwZGF0ZUxhdGVzdFZhbHVlKG9iaiwgdmFsdWUpLCBlID0+IHRoaXMuYXBwbGljYXRpb25FcnJvckhhbmRsZXIoZSkpO1xuICB9XG4gIF9zZWxlY3RTdHJhdGVneShvYmopIHtcbiAgICBpZiAoX2lzUHJvbWlzZShvYmopKSB7XG4gICAgICByZXR1cm4gX3Byb21pc2VTdHJhdGVneTtcbiAgICB9XG4gICAgaWYgKF9pc1N1YnNjcmliYWJsZShvYmopKSB7XG4gICAgICByZXR1cm4gX3N1YnNjcmliYWJsZVN0cmF0ZWd5O1xuICAgIH1cbiAgICB0aHJvdyBpbnZhbGlkUGlwZUFyZ3VtZW50RXJyb3IoQXN5bmNQaXBlLCBvYmopO1xuICB9XG4gIF9kaXNwb3NlKCkge1xuICAgIHRoaXMuX3N0cmF0ZWd5LmRpc3Bvc2UodGhpcy5fc3Vic2NyaXB0aW9uKTtcbiAgICB0aGlzLl9sYXRlc3RWYWx1ZSA9IG51bGw7XG4gICAgdGhpcy5fc3Vic2NyaXB0aW9uID0gbnVsbDtcbiAgICB0aGlzLl9vYmogPSBudWxsO1xuICB9XG4gIF91cGRhdGVMYXRlc3RWYWx1ZShhc3luYywgdmFsdWUpIHtcbiAgICBpZiAoYXN5bmMgPT09IHRoaXMuX29iaikge1xuICAgICAgdGhpcy5fbGF0ZXN0VmFsdWUgPSB2YWx1ZTtcbiAgICAgIGlmICh0aGlzLm1hcmtGb3JDaGVja09uVmFsdWVVcGRhdGUpIHtcbiAgICAgICAgdGhpcy5fcmVmPy5tYXJrRm9yQ2hlY2soKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gQXN5bmNQaXBlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgQXN5bmNQaXBlKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLkNoYW5nZURldGVjdG9yUmVmLCAxNikpO1xuICB9O1xuICBzdGF0aWMgybVwaXBlID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVBpcGUoe1xuICAgIG5hbWU6IFwiYXN5bmNcIixcbiAgICB0eXBlOiBBc3luY1BpcGUsXG4gICAgcHVyZTogZmFsc2VcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShBc3luY1BpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ2FzeW5jJyxcbiAgICAgIHB1cmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuQ2hhbmdlRGV0ZWN0b3JSZWZcbiAgfV0sIG51bGwpO1xufSkoKTtcbmNsYXNzIExvd2VyQ2FzZVBpcGUge1xuICB0cmFuc2Zvcm0odmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gICAgYXNzZXJ0UGlwZUFyZ3VtZW50KExvd2VyQ2FzZVBpcGUsIHZhbHVlKTtcbiAgICByZXR1cm4gdmFsdWUudG9Mb3dlckNhc2UoKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBMb3dlckNhc2VQaXBlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBMb3dlckNhc2VQaXBlKSgpO1xuICB9O1xuICBzdGF0aWMgybVwaXBlID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVBpcGUoe1xuICAgIG5hbWU6IFwibG93ZXJjYXNlXCIsXG4gICAgdHlwZTogTG93ZXJDYXNlUGlwZSxcbiAgICBwdXJlOiB0cnVlXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTG93ZXJDYXNlUGlwZSwgW3tcbiAgICB0eXBlOiBQaXBlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBuYW1lOiAnbG93ZXJjYXNlJ1xuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jb25zdCB1bmljb2RlV29yZE1hdGNoID0gLyg/OlswLTlBLVphLXpcXHhBQVxceEI1XFx4QkFcXHhDMC1cXHhENlxceEQ4LVxceEY2XFx4RjgtXFx1MDJDMVxcdTAyQzYtXFx1MDJEMVxcdTAyRTAtXFx1MDJFNFxcdTAyRUNcXHUwMkVFXFx1MDM3MC1cXHUwMzc0XFx1MDM3NlxcdTAzNzdcXHUwMzdBLVxcdTAzN0RcXHUwMzdGXFx1MDM4NlxcdTAzODgtXFx1MDM4QVxcdTAzOENcXHUwMzhFLVxcdTAzQTFcXHUwM0EzLVxcdTAzRjVcXHUwM0Y3LVxcdTA0ODFcXHUwNDhBLVxcdTA1MkZcXHUwNTMxLVxcdTA1NTZcXHUwNTU5XFx1MDU2MC1cXHUwNTg4XFx1MDVEMC1cXHUwNUVBXFx1MDVFRi1cXHUwNUYyXFx1MDYyMC1cXHUwNjRBXFx1MDY2RVxcdTA2NkZcXHUwNjcxLVxcdTA2RDNcXHUwNkQ1XFx1MDZFNVxcdTA2RTZcXHUwNkVFXFx1MDZFRlxcdTA2RkEtXFx1MDZGQ1xcdTA2RkZcXHUwNzEwXFx1MDcxMi1cXHUwNzJGXFx1MDc0RC1cXHUwN0E1XFx1MDdCMVxcdTA3Q0EtXFx1MDdFQVxcdTA3RjRcXHUwN0Y1XFx1MDdGQVxcdTA4MDAtXFx1MDgxNVxcdTA4MUFcXHUwODI0XFx1MDgyOFxcdTA4NDAtXFx1MDg1OFxcdTA4NjAtXFx1MDg2QVxcdTA4NzAtXFx1MDg4N1xcdTA4ODktXFx1MDg4RVxcdTA4QTAtXFx1MDhDOVxcdTA5MDQtXFx1MDkzOVxcdTA5M0RcXHUwOTUwXFx1MDk1OC1cXHUwOTYxXFx1MDk3MS1cXHUwOTgwXFx1MDk4NS1cXHUwOThDXFx1MDk4RlxcdTA5OTBcXHUwOTkzLVxcdTA5QThcXHUwOUFBLVxcdTA5QjBcXHUwOUIyXFx1MDlCNi1cXHUwOUI5XFx1MDlCRFxcdTA5Q0VcXHUwOURDXFx1MDlERFxcdTA5REYtXFx1MDlFMVxcdTA5RjBcXHUwOUYxXFx1MDlGQ1xcdTBBMDUtXFx1MEEwQVxcdTBBMEZcXHUwQTEwXFx1MEExMy1cXHUwQTI4XFx1MEEyQS1cXHUwQTMwXFx1MEEzMlxcdTBBMzNcXHUwQTM1XFx1MEEzNlxcdTBBMzhcXHUwQTM5XFx1MEE1OS1cXHUwQTVDXFx1MEE1RVxcdTBBNzItXFx1MEE3NFxcdTBBODUtXFx1MEE4RFxcdTBBOEYtXFx1MEE5MVxcdTBBOTMtXFx1MEFBOFxcdTBBQUEtXFx1MEFCMFxcdTBBQjJcXHUwQUIzXFx1MEFCNS1cXHUwQUI5XFx1MEFCRFxcdTBBRDBcXHUwQUUwXFx1MEFFMVxcdTBBRjlcXHUwQjA1LVxcdTBCMENcXHUwQjBGXFx1MEIxMFxcdTBCMTMtXFx1MEIyOFxcdTBCMkEtXFx1MEIzMFxcdTBCMzJcXHUwQjMzXFx1MEIzNS1cXHUwQjM5XFx1MEIzRFxcdTBCNUNcXHUwQjVEXFx1MEI1Ri1cXHUwQjYxXFx1MEI3MVxcdTBCODNcXHUwQjg1LVxcdTBCOEFcXHUwQjhFLVxcdTBCOTBcXHUwQjkyLVxcdTBCOTVcXHUwQjk5XFx1MEI5QVxcdTBCOUNcXHUwQjlFXFx1MEI5RlxcdTBCQTNcXHUwQkE0XFx1MEJBOC1cXHUwQkFBXFx1MEJBRS1cXHUwQkI5XFx1MEJEMFxcdTBDMDUtXFx1MEMwQ1xcdTBDMEUtXFx1MEMxMFxcdTBDMTItXFx1MEMyOFxcdTBDMkEtXFx1MEMzOVxcdTBDM0RcXHUwQzU4LVxcdTBDNUFcXHUwQzVEXFx1MEM2MFxcdTBDNjFcXHUwQzgwXFx1MEM4NS1cXHUwQzhDXFx1MEM4RS1cXHUwQzkwXFx1MEM5Mi1cXHUwQ0E4XFx1MENBQS1cXHUwQ0IzXFx1MENCNS1cXHUwQ0I5XFx1MENCRFxcdTBDRERcXHUwQ0RFXFx1MENFMFxcdTBDRTFcXHUwQ0YxXFx1MENGMlxcdTBEMDQtXFx1MEQwQ1xcdTBEMEUtXFx1MEQxMFxcdTBEMTItXFx1MEQzQVxcdTBEM0RcXHUwRDRFXFx1MEQ1NC1cXHUwRDU2XFx1MEQ1Ri1cXHUwRDYxXFx1MEQ3QS1cXHUwRDdGXFx1MEQ4NS1cXHUwRDk2XFx1MEQ5QS1cXHUwREIxXFx1MERCMy1cXHUwREJCXFx1MERCRFxcdTBEQzAtXFx1MERDNlxcdTBFMDEtXFx1MEUzMFxcdTBFMzJcXHUwRTMzXFx1MEU0MC1cXHUwRTQ2XFx1MEU4MVxcdTBFODJcXHUwRTg0XFx1MEU4Ni1cXHUwRThBXFx1MEU4Qy1cXHUwRUEzXFx1MEVBNVxcdTBFQTctXFx1MEVCMFxcdTBFQjJcXHUwRUIzXFx1MEVCRFxcdTBFQzAtXFx1MEVDNFxcdTBFQzZcXHUwRURDLVxcdTBFREZcXHUwRjAwXFx1MEY0MC1cXHUwRjQ3XFx1MEY0OS1cXHUwRjZDXFx1MEY4OC1cXHUwRjhDXFx1MTAwMC1cXHUxMDJBXFx1MTAzRlxcdTEwNTAtXFx1MTA1NVxcdTEwNUEtXFx1MTA1RFxcdTEwNjFcXHUxMDY1XFx1MTA2NlxcdTEwNkUtXFx1MTA3MFxcdTEwNzUtXFx1MTA4MVxcdTEwOEVcXHUxMEEwLVxcdTEwQzVcXHUxMEM3XFx1MTBDRFxcdTEwRDAtXFx1MTBGQVxcdTEwRkMtXFx1MTI0OFxcdTEyNEEtXFx1MTI0RFxcdTEyNTAtXFx1MTI1NlxcdTEyNThcXHUxMjVBLVxcdTEyNURcXHUxMjYwLVxcdTEyODhcXHUxMjhBLVxcdTEyOERcXHUxMjkwLVxcdTEyQjBcXHUxMkIyLVxcdTEyQjVcXHUxMkI4LVxcdTEyQkVcXHUxMkMwXFx1MTJDMi1cXHUxMkM1XFx1MTJDOC1cXHUxMkQ2XFx1MTJEOC1cXHUxMzEwXFx1MTMxMi1cXHUxMzE1XFx1MTMxOC1cXHUxMzVBXFx1MTM4MC1cXHUxMzhGXFx1MTNBMC1cXHUxM0Y1XFx1MTNGOC1cXHUxM0ZEXFx1MTQwMS1cXHUxNjZDXFx1MTY2Ri1cXHUxNjdGXFx1MTY4MS1cXHUxNjlBXFx1MTZBMC1cXHUxNkVBXFx1MTZGMS1cXHUxNkY4XFx1MTcwMC1cXHUxNzExXFx1MTcxRi1cXHUxNzMxXFx1MTc0MC1cXHUxNzUxXFx1MTc2MC1cXHUxNzZDXFx1MTc2RS1cXHUxNzcwXFx1MTc4MC1cXHUxN0IzXFx1MTdEN1xcdTE3RENcXHUxODIwLVxcdTE4NzhcXHUxODgwLVxcdTE4ODRcXHUxODg3LVxcdTE4QThcXHUxOEFBXFx1MThCMC1cXHUxOEY1XFx1MTkwMC1cXHUxOTFFXFx1MTk1MC1cXHUxOTZEXFx1MTk3MC1cXHUxOTc0XFx1MTk4MC1cXHUxOUFCXFx1MTlCMC1cXHUxOUM5XFx1MUEwMC1cXHUxQTE2XFx1MUEyMC1cXHUxQTU0XFx1MUFBN1xcdTFCMDUtXFx1MUIzM1xcdTFCNDUtXFx1MUI0Q1xcdTFCODMtXFx1MUJBMFxcdTFCQUVcXHUxQkFGXFx1MUJCQS1cXHUxQkU1XFx1MUMwMC1cXHUxQzIzXFx1MUM0RC1cXHUxQzRGXFx1MUM1QS1cXHUxQzdEXFx1MUM4MC1cXHUxQzg4XFx1MUM5MC1cXHUxQ0JBXFx1MUNCRC1cXHUxQ0JGXFx1MUNFOS1cXHUxQ0VDXFx1MUNFRS1cXHUxQ0YzXFx1MUNGNVxcdTFDRjZcXHUxQ0ZBXFx1MUQwMC1cXHUxREJGXFx1MUUwMC1cXHUxRjE1XFx1MUYxOC1cXHUxRjFEXFx1MUYyMC1cXHUxRjQ1XFx1MUY0OC1cXHUxRjREXFx1MUY1MC1cXHUxRjU3XFx1MUY1OVxcdTFGNUJcXHUxRjVEXFx1MUY1Ri1cXHUxRjdEXFx1MUY4MC1cXHUxRkI0XFx1MUZCNi1cXHUxRkJDXFx1MUZCRVxcdTFGQzItXFx1MUZDNFxcdTFGQzYtXFx1MUZDQ1xcdTFGRDAtXFx1MUZEM1xcdTFGRDYtXFx1MUZEQlxcdTFGRTAtXFx1MUZFQ1xcdTFGRjItXFx1MUZGNFxcdTFGRjYtXFx1MUZGQ1xcdTIwNzFcXHUyMDdGXFx1MjA5MC1cXHUyMDlDXFx1MjEwMlxcdTIxMDdcXHUyMTBBLVxcdTIxMTNcXHUyMTE1XFx1MjExOS1cXHUyMTFEXFx1MjEyNFxcdTIxMjZcXHUyMTI4XFx1MjEyQS1cXHUyMTJEXFx1MjEyRi1cXHUyMTM5XFx1MjEzQy1cXHUyMTNGXFx1MjE0NS1cXHUyMTQ5XFx1MjE0RVxcdTIxODNcXHUyMTg0XFx1MkMwMC1cXHUyQ0U0XFx1MkNFQi1cXHUyQ0VFXFx1MkNGMlxcdTJDRjNcXHUyRDAwLVxcdTJEMjVcXHUyRDI3XFx1MkQyRFxcdTJEMzAtXFx1MkQ2N1xcdTJENkZcXHUyRDgwLVxcdTJEOTZcXHUyREEwLVxcdTJEQTZcXHUyREE4LVxcdTJEQUVcXHUyREIwLVxcdTJEQjZcXHUyREI4LVxcdTJEQkVcXHUyREMwLVxcdTJEQzZcXHUyREM4LVxcdTJEQ0VcXHUyREQwLVxcdTJERDZcXHUyREQ4LVxcdTJEREVcXHUyRTJGXFx1MzAwNVxcdTMwMDZcXHUzMDMxLVxcdTMwMzVcXHUzMDNCXFx1MzAzQ1xcdTMwNDEtXFx1MzA5NlxcdTMwOUQtXFx1MzA5RlxcdTMwQTEtXFx1MzBGQVxcdTMwRkMtXFx1MzBGRlxcdTMxMDUtXFx1MzEyRlxcdTMxMzEtXFx1MzE4RVxcdTMxQTAtXFx1MzFCRlxcdTMxRjAtXFx1MzFGRlxcdTM0MDAtXFx1NERCRlxcdTRFMDAtXFx1QTQ4Q1xcdUE0RDAtXFx1QTRGRFxcdUE1MDAtXFx1QTYwQ1xcdUE2MTAtXFx1QTYxRlxcdUE2MkFcXHVBNjJCXFx1QTY0MC1cXHVBNjZFXFx1QTY3Ri1cXHVBNjlEXFx1QTZBMC1cXHVBNkU1XFx1QTcxNy1cXHVBNzFGXFx1QTcyMi1cXHVBNzg4XFx1QTc4Qi1cXHVBN0NBXFx1QTdEMFxcdUE3RDFcXHVBN0QzXFx1QTdENS1cXHVBN0Q5XFx1QTdGMi1cXHVBODAxXFx1QTgwMy1cXHVBODA1XFx1QTgwNy1cXHVBODBBXFx1QTgwQy1cXHVBODIyXFx1QTg0MC1cXHVBODczXFx1QTg4Mi1cXHVBOEIzXFx1QThGMi1cXHVBOEY3XFx1QThGQlxcdUE4RkRcXHVBOEZFXFx1QTkwQS1cXHVBOTI1XFx1QTkzMC1cXHVBOTQ2XFx1QTk2MC1cXHVBOTdDXFx1QTk4NC1cXHVBOUIyXFx1QTlDRlxcdUE5RTAtXFx1QTlFNFxcdUE5RTYtXFx1QTlFRlxcdUE5RkEtXFx1QTlGRVxcdUFBMDAtXFx1QUEyOFxcdUFBNDAtXFx1QUE0MlxcdUFBNDQtXFx1QUE0QlxcdUFBNjAtXFx1QUE3NlxcdUFBN0FcXHVBQTdFLVxcdUFBQUZcXHVBQUIxXFx1QUFCNVxcdUFBQjZcXHVBQUI5LVxcdUFBQkRcXHVBQUMwXFx1QUFDMlxcdUFBREItXFx1QUFERFxcdUFBRTAtXFx1QUFFQVxcdUFBRjItXFx1QUFGNFxcdUFCMDEtXFx1QUIwNlxcdUFCMDktXFx1QUIwRVxcdUFCMTEtXFx1QUIxNlxcdUFCMjAtXFx1QUIyNlxcdUFCMjgtXFx1QUIyRVxcdUFCMzAtXFx1QUI1QVxcdUFCNUMtXFx1QUI2OVxcdUFCNzAtXFx1QUJFMlxcdUFDMDAtXFx1RDdBM1xcdUQ3QjAtXFx1RDdDNlxcdUQ3Q0ItXFx1RDdGQlxcdUY5MDAtXFx1RkE2RFxcdUZBNzAtXFx1RkFEOVxcdUZCMDAtXFx1RkIwNlxcdUZCMTMtXFx1RkIxN1xcdUZCMURcXHVGQjFGLVxcdUZCMjhcXHVGQjJBLVxcdUZCMzZcXHVGQjM4LVxcdUZCM0NcXHVGQjNFXFx1RkI0MFxcdUZCNDFcXHVGQjQzXFx1RkI0NFxcdUZCNDYtXFx1RkJCMVxcdUZCRDMtXFx1RkQzRFxcdUZENTAtXFx1RkQ4RlxcdUZEOTItXFx1RkRDN1xcdUZERjAtXFx1RkRGQlxcdUZFNzAtXFx1RkU3NFxcdUZFNzYtXFx1RkVGQ1xcdUZGMjEtXFx1RkYzQVxcdUZGNDEtXFx1RkY1QVxcdUZGNjYtXFx1RkZCRVxcdUZGQzItXFx1RkZDN1xcdUZGQ0EtXFx1RkZDRlxcdUZGRDItXFx1RkZEN1xcdUZGREEtXFx1RkZEQ118XFx1RDgwMFtcXHVEQzAwLVxcdURDMEJcXHVEQzBELVxcdURDMjZcXHVEQzI4LVxcdURDM0FcXHVEQzNDXFx1REMzRFxcdURDM0YtXFx1REM0RFxcdURDNTAtXFx1REM1RFxcdURDODAtXFx1RENGQVxcdURFODAtXFx1REU5Q1xcdURFQTAtXFx1REVEMFxcdURGMDAtXFx1REYxRlxcdURGMkQtXFx1REY0MFxcdURGNDItXFx1REY0OVxcdURGNTAtXFx1REY3NVxcdURGODAtXFx1REY5RFxcdURGQTAtXFx1REZDM1xcdURGQzgtXFx1REZDRl18XFx1RDgwMVtcXHVEQzAwLVxcdURDOURcXHVEQ0IwLVxcdURDRDNcXHVEQ0Q4LVxcdURDRkJcXHVERDAwLVxcdUREMjdcXHVERDMwLVxcdURENjNcXHVERDcwLVxcdUREN0FcXHVERDdDLVxcdUREOEFcXHVERDhDLVxcdUREOTJcXHVERDk0XFx1REQ5NVxcdUREOTctXFx1RERBMVxcdUREQTMtXFx1RERCMVxcdUREQjMtXFx1RERCOVxcdUREQkJcXHVEREJDXFx1REUwMC1cXHVERjM2XFx1REY0MC1cXHVERjU1XFx1REY2MC1cXHVERjY3XFx1REY4MC1cXHVERjg1XFx1REY4Ny1cXHVERkIwXFx1REZCMi1cXHVERkJBXXxcXHVEODAyW1xcdURDMDAtXFx1REMwNVxcdURDMDhcXHVEQzBBLVxcdURDMzVcXHVEQzM3XFx1REMzOFxcdURDM0NcXHVEQzNGLVxcdURDNTVcXHVEQzYwLVxcdURDNzZcXHVEQzgwLVxcdURDOUVcXHVEQ0UwLVxcdURDRjJcXHVEQ0Y0XFx1RENGNVxcdUREMDAtXFx1REQxNVxcdUREMjAtXFx1REQzOVxcdUREODAtXFx1RERCN1xcdUREQkVcXHVEREJGXFx1REUwMFxcdURFMTAtXFx1REUxM1xcdURFMTUtXFx1REUxN1xcdURFMTktXFx1REUzNVxcdURFNjAtXFx1REU3Q1xcdURFODAtXFx1REU5Q1xcdURFQzAtXFx1REVDN1xcdURFQzktXFx1REVFNFxcdURGMDAtXFx1REYzNVxcdURGNDAtXFx1REY1NVxcdURGNjAtXFx1REY3MlxcdURGODAtXFx1REY5MV18XFx1RDgwM1tcXHVEQzAwLVxcdURDNDhcXHVEQzgwLVxcdURDQjJcXHVEQ0MwLVxcdURDRjJcXHVERDAwLVxcdUREMjNcXHVERTgwLVxcdURFQTlcXHVERUIwXFx1REVCMVxcdURGMDAtXFx1REYxQ1xcdURGMjdcXHVERjMwLVxcdURGNDVcXHVERjcwLVxcdURGODFcXHVERkIwLVxcdURGQzRcXHVERkUwLVxcdURGRjZdfFxcdUQ4MDRbXFx1REMwMy1cXHVEQzM3XFx1REM3MVxcdURDNzJcXHVEQzc1XFx1REM4My1cXHVEQ0FGXFx1RENEMC1cXHVEQ0U4XFx1REQwMy1cXHVERDI2XFx1REQ0NFxcdURENDdcXHVERDUwLVxcdURENzJcXHVERDc2XFx1REQ4My1cXHVEREIyXFx1RERDMS1cXHVEREM0XFx1REREQVxcdURERENcXHVERTAwLVxcdURFMTFcXHVERTEzLVxcdURFMkJcXHVERTgwLVxcdURFODZcXHVERTg4XFx1REU4QS1cXHVERThEXFx1REU4Ri1cXHVERTlEXFx1REU5Ri1cXHVERUE4XFx1REVCMC1cXHVERURFXFx1REYwNS1cXHVERjBDXFx1REYwRlxcdURGMTBcXHVERjEzLVxcdURGMjhcXHVERjJBLVxcdURGMzBcXHVERjMyXFx1REYzM1xcdURGMzUtXFx1REYzOVxcdURGM0RcXHVERjUwXFx1REY1RC1cXHVERjYxXXxcXHVEODA1W1xcdURDMDAtXFx1REMzNFxcdURDNDctXFx1REM0QVxcdURDNUYtXFx1REM2MVxcdURDODAtXFx1RENBRlxcdURDQzRcXHVEQ0M1XFx1RENDN1xcdUREODAtXFx1RERBRVxcdURERDgtXFx1REREQlxcdURFMDAtXFx1REUyRlxcdURFNDRcXHVERTgwLVxcdURFQUFcXHVERUI4XFx1REYwMC1cXHVERjFBXFx1REY0MC1cXHVERjQ2XXxcXHVEODA2W1xcdURDMDAtXFx1REMyQlxcdURDQTAtXFx1RENERlxcdURDRkYtXFx1REQwNlxcdUREMDlcXHVERDBDLVxcdUREMTNcXHVERDE1XFx1REQxNlxcdUREMTgtXFx1REQyRlxcdUREM0ZcXHVERDQxXFx1RERBMC1cXHVEREE3XFx1RERBQS1cXHVEREQwXFx1RERFMVxcdURERTNcXHVERTAwXFx1REUwQi1cXHVERTMyXFx1REUzQVxcdURFNTBcXHVERTVDLVxcdURFODlcXHVERTlEXFx1REVCMC1cXHVERUY4XXxcXHVEODA3W1xcdURDMDAtXFx1REMwOFxcdURDMEEtXFx1REMyRVxcdURDNDBcXHVEQzcyLVxcdURDOEZcXHVERDAwLVxcdUREMDZcXHVERDA4XFx1REQwOVxcdUREMEItXFx1REQzMFxcdURENDZcXHVERDYwLVxcdURENjVcXHVERDY3XFx1REQ2OFxcdURENkEtXFx1REQ4OVxcdUREOThcXHVERUUwLVxcdURFRjJcXHVERkIwXXxcXHVEODA4W1xcdURDMDAtXFx1REY5OV18XFx1RDgwOVtcXHVEQzgwLVxcdURENDNdfFxcdUQ4MEJbXFx1REY5MC1cXHVERkYwXXxbXFx1RDgwQ1xcdUQ4MUMtXFx1RDgyMFxcdUQ4MjJcXHVEODQwLVxcdUQ4NjhcXHVEODZBLVxcdUQ4NkNcXHVEODZGLVxcdUQ4NzJcXHVEODc0LVxcdUQ4NzlcXHVEODgwLVxcdUQ4ODNdW1xcdURDMDAtXFx1REZGRl18XFx1RDgwRFtcXHVEQzAwLVxcdURDMkVdfFxcdUQ4MTFbXFx1REMwMC1cXHVERTQ2XXxcXHVEODFBW1xcdURDMDAtXFx1REUzOFxcdURFNDAtXFx1REU1RVxcdURFNzAtXFx1REVCRVxcdURFRDAtXFx1REVFRFxcdURGMDAtXFx1REYyRlxcdURGNDAtXFx1REY0M1xcdURGNjMtXFx1REY3N1xcdURGN0QtXFx1REY4Rl18XFx1RDgxQltcXHVERTQwLVxcdURFN0ZcXHVERjAwLVxcdURGNEFcXHVERjUwXFx1REY5My1cXHVERjlGXFx1REZFMFxcdURGRTFcXHVERkUzXXxcXHVEODIxW1xcdURDMDAtXFx1REZGN118XFx1RDgyM1tcXHVEQzAwLVxcdURDRDVcXHVERDAwLVxcdUREMDhdfFxcdUQ4MkJbXFx1REZGMC1cXHVERkYzXFx1REZGNS1cXHVERkZCXFx1REZGRFxcdURGRkVdfFxcdUQ4MkNbXFx1REMwMC1cXHVERDIyXFx1REQ1MC1cXHVERDUyXFx1REQ2NC1cXHVERDY3XFx1REQ3MC1cXHVERUZCXXxcXHVEODJGW1xcdURDMDAtXFx1REM2QVxcdURDNzAtXFx1REM3Q1xcdURDODAtXFx1REM4OFxcdURDOTAtXFx1REM5OV18XFx1RDgzNVtcXHVEQzAwLVxcdURDNTRcXHVEQzU2LVxcdURDOUNcXHVEQzlFXFx1REM5RlxcdURDQTJcXHVEQ0E1XFx1RENBNlxcdURDQTktXFx1RENBQ1xcdURDQUUtXFx1RENCOVxcdURDQkJcXHVEQ0JELVxcdURDQzNcXHVEQ0M1LVxcdUREMDVcXHVERDA3LVxcdUREMEFcXHVERDBELVxcdUREMTRcXHVERDE2LVxcdUREMUNcXHVERDFFLVxcdUREMzlcXHVERDNCLVxcdUREM0VcXHVERDQwLVxcdURENDRcXHVERDQ2XFx1REQ0QS1cXHVERDUwXFx1REQ1Mi1cXHVERUE1XFx1REVBOC1cXHVERUMwXFx1REVDMi1cXHVERURBXFx1REVEQy1cXHVERUZBXFx1REVGQy1cXHVERjE0XFx1REYxNi1cXHVERjM0XFx1REYzNi1cXHVERjRFXFx1REY1MC1cXHVERjZFXFx1REY3MC1cXHVERjg4XFx1REY4QS1cXHVERkE4XFx1REZBQS1cXHVERkMyXFx1REZDNC1cXHVERkNCXXxcXHVEODM3W1xcdURGMDAtXFx1REYxRV18XFx1RDgzOFtcXHVERDAwLVxcdUREMkNcXHVERDM3LVxcdUREM0RcXHVERDRFXFx1REU5MC1cXHVERUFEXFx1REVDMC1cXHVERUVCXXxcXHVEODM5W1xcdURGRTAtXFx1REZFNlxcdURGRTgtXFx1REZFQlxcdURGRURcXHVERkVFXFx1REZGMC1cXHVERkZFXXxcXHVEODNBW1xcdURDMDAtXFx1RENDNFxcdUREMDAtXFx1REQ0M1xcdURENEJdfFxcdUQ4M0JbXFx1REUwMC1cXHVERTAzXFx1REUwNS1cXHVERTFGXFx1REUyMVxcdURFMjJcXHVERTI0XFx1REUyN1xcdURFMjktXFx1REUzMlxcdURFMzQtXFx1REUzN1xcdURFMzlcXHVERTNCXFx1REU0MlxcdURFNDdcXHVERTQ5XFx1REU0QlxcdURFNEQtXFx1REU0RlxcdURFNTFcXHVERTUyXFx1REU1NFxcdURFNTdcXHVERTU5XFx1REU1QlxcdURFNURcXHVERTVGXFx1REU2MVxcdURFNjJcXHVERTY0XFx1REU2Ny1cXHVERTZBXFx1REU2Qy1cXHVERTcyXFx1REU3NC1cXHVERTc3XFx1REU3OS1cXHVERTdDXFx1REU3RVxcdURFODAtXFx1REU4OVxcdURFOEItXFx1REU5QlxcdURFQTEtXFx1REVBM1xcdURFQTUtXFx1REVBOVxcdURFQUItXFx1REVCQl18XFx1RDg2OVtcXHVEQzAwLVxcdURFREZcXHVERjAwLVxcdURGRkZdfFxcdUQ4NkRbXFx1REMwMC1cXHVERjM4XFx1REY0MC1cXHVERkZGXXxcXHVEODZFW1xcdURDMDAtXFx1REMxRFxcdURDMjAtXFx1REZGRl18XFx1RDg3M1tcXHVEQzAwLVxcdURFQTFcXHVERUIwLVxcdURGRkZdfFxcdUQ4N0FbXFx1REMwMC1cXHVERkUwXXxcXHVEODdFW1xcdURDMDAtXFx1REUxRF18XFx1RDg4NFtcXHVEQzAwLVxcdURGNEFdKVxcUyovZztcbmNsYXNzIFRpdGxlQ2FzZVBpcGUge1xuICB0cmFuc2Zvcm0odmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gICAgYXNzZXJ0UGlwZUFyZ3VtZW50KFRpdGxlQ2FzZVBpcGUsIHZhbHVlKTtcbiAgICByZXR1cm4gdmFsdWUucmVwbGFjZSh1bmljb2RlV29yZE1hdGNoLCB0eHQgPT4gdHh0WzBdLnRvVXBwZXJDYXNlKCkgKyB0eHQuc2xpY2UoMSkudG9Mb3dlckNhc2UoKSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gVGl0bGVDYXNlUGlwZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgVGl0bGVDYXNlUGlwZSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1cGlwZSA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVQaXBlKHtcbiAgICBuYW1lOiBcInRpdGxlY2FzZVwiLFxuICAgIHR5cGU6IFRpdGxlQ2FzZVBpcGUsXG4gICAgcHVyZTogdHJ1ZVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFRpdGxlQ2FzZVBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ3RpdGxlY2FzZSdcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY2xhc3MgVXBwZXJDYXNlUGlwZSB7XG4gIHRyYW5zZm9ybSh2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgICBhc3NlcnRQaXBlQXJndW1lbnQoVXBwZXJDYXNlUGlwZSwgdmFsdWUpO1xuICAgIHJldHVybiB2YWx1ZS50b1VwcGVyQ2FzZSgpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFVwcGVyQ2FzZVBpcGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFVwcGVyQ2FzZVBpcGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXBpcGUgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lUGlwZSh7XG4gICAgbmFtZTogXCJ1cHBlcmNhc2VcIixcbiAgICB0eXBlOiBVcHBlckNhc2VQaXBlLFxuICAgIHB1cmU6IHRydWVcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShVcHBlckNhc2VQaXBlLCBbe1xuICAgIHR5cGU6IFBpcGUsXG4gICAgYXJnczogW3tcbiAgICAgIG5hbWU6ICd1cHBlcmNhc2UnXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGFzc2VydFBpcGVBcmd1bWVudChwaXBlLCB2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IGludmFsaWRQaXBlQXJndW1lbnRFcnJvcihwaXBlLCB2YWx1ZSk7XG4gIH1cbn1cbmNvbnN0IERFRkFVTFRfREFURV9GT1JNQVQgPSAnbWVkaXVtRGF0ZSc7XG5jb25zdCBEQVRFX1BJUEVfREVGQVVMVF9USU1FWk9ORSA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnREFURV9QSVBFX0RFRkFVTFRfVElNRVpPTkUnIDogJycpO1xuY29uc3QgREFURV9QSVBFX0RFRkFVTFRfT1BUSU9OUyA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnREFURV9QSVBFX0RFRkFVTFRfT1BUSU9OUycgOiAnJyk7XG5jbGFzcyBEYXRlUGlwZSB7XG4gIGxvY2FsZTtcbiAgZGVmYXVsdFRpbWV6b25lO1xuICBkZWZhdWx0T3B0aW9ucztcbiAgY29uc3RydWN0b3IobG9jYWxlLCBkZWZhdWx0VGltZXpvbmUsIGRlZmF1bHRPcHRpb25zKSB7XG4gICAgdGhpcy5sb2NhbGUgPSBsb2NhbGU7XG4gICAgdGhpcy5kZWZhdWx0VGltZXpvbmUgPSBkZWZhdWx0VGltZXpvbmU7XG4gICAgdGhpcy5kZWZhdWx0T3B0aW9ucyA9IGRlZmF1bHRPcHRpb25zO1xuICB9XG4gIHRyYW5zZm9ybSh2YWx1ZSwgZm9ybWF0LCB0aW1lem9uZSwgbG9jYWxlKSB7XG4gICAgaWYgKHZhbHVlID09IG51bGwgfHwgdmFsdWUgPT09ICcnIHx8IHZhbHVlICE9PSB2YWx1ZSkgcmV0dXJuIG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IF9mb3JtYXQgPSBmb3JtYXQgPz8gdGhpcy5kZWZhdWx0T3B0aW9ucz8uZGF0ZUZvcm1hdCA/PyBERUZBVUxUX0RBVEVfRk9STUFUO1xuICAgICAgY29uc3QgX3RpbWV6b25lID0gdGltZXpvbmUgPz8gdGhpcy5kZWZhdWx0T3B0aW9ucz8udGltZXpvbmUgPz8gdGhpcy5kZWZhdWx0VGltZXpvbmUgPz8gdW5kZWZpbmVkO1xuICAgICAgcmV0dXJuIGZvcm1hdERhdGUodmFsdWUsIF9mb3JtYXQsIGxvY2FsZSB8fCB0aGlzLmxvY2FsZSwgX3RpbWV6b25lKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgaW52YWxpZFBpcGVBcmd1bWVudEVycm9yKERhdGVQaXBlLCBlcnJvci5tZXNzYWdlKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gRGF0ZVBpcGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBEYXRlUGlwZSkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChMT0NBTEVfSUQsIDE2KSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChEQVRFX1BJUEVfREVGQVVMVF9USU1FWk9ORSwgMjQpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KERBVEVfUElQRV9ERUZBVUxUX09QVElPTlMsIDI0KSk7XG4gIH07XG4gIHN0YXRpYyDJtXBpcGUgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lUGlwZSh7XG4gICAgbmFtZTogXCJkYXRlXCIsXG4gICAgdHlwZTogRGF0ZVBpcGUsXG4gICAgcHVyZTogdHJ1ZVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKERhdGVQaXBlLCBbe1xuICAgIHR5cGU6IFBpcGUsXG4gICAgYXJnczogW3tcbiAgICAgIG5hbWU6ICdkYXRlJ1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0xPQ0FMRV9JRF1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbREFURV9QSVBFX0RFRkFVTFRfVElNRVpPTkVdXG4gICAgfSwge1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbREFURV9QSVBFX0RFRkFVTFRfT1BUSU9OU11cbiAgICB9LCB7XG4gICAgICB0eXBlOiBPcHRpb25hbFxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jb25zdCBfSU5URVJQT0xBVElPTl9SRUdFWFAgPSAvIy9nO1xuY2xhc3MgSTE4blBsdXJhbFBpcGUge1xuICBfbG9jYWxpemF0aW9uO1xuICBjb25zdHJ1Y3RvcihfbG9jYWxpemF0aW9uKSB7XG4gICAgdGhpcy5fbG9jYWxpemF0aW9uID0gX2xvY2FsaXphdGlvbjtcbiAgfVxuICB0cmFuc2Zvcm0odmFsdWUsIHBsdXJhbE1hcCwgbG9jYWxlKSB7XG4gICAgaWYgKHZhbHVlID09IG51bGwpIHJldHVybiAnJztcbiAgICBpZiAodHlwZW9mIHBsdXJhbE1hcCAhPT0gJ29iamVjdCcgfHwgcGx1cmFsTWFwID09PSBudWxsKSB7XG4gICAgICB0aHJvdyBpbnZhbGlkUGlwZUFyZ3VtZW50RXJyb3IoSTE4blBsdXJhbFBpcGUsIHBsdXJhbE1hcCk7XG4gICAgfVxuICAgIGNvbnN0IGtleSA9IGdldFBsdXJhbENhdGVnb3J5KHZhbHVlLCBPYmplY3Qua2V5cyhwbHVyYWxNYXApLCB0aGlzLl9sb2NhbGl6YXRpb24sIGxvY2FsZSk7XG4gICAgcmV0dXJuIHBsdXJhbE1hcFtrZXldLnJlcGxhY2UoX0lOVEVSUE9MQVRJT05fUkVHRVhQLCB2YWx1ZS50b1N0cmluZygpKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBJMThuUGx1cmFsUGlwZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEkxOG5QbHVyYWxQaXBlKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KE5nTG9jYWxpemF0aW9uLCAxNikpO1xuICB9O1xuICBzdGF0aWMgybVwaXBlID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVBpcGUoe1xuICAgIG5hbWU6IFwiaTE4blBsdXJhbFwiLFxuICAgIHR5cGU6IEkxOG5QbHVyYWxQaXBlLFxuICAgIHB1cmU6IHRydWVcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShJMThuUGx1cmFsUGlwZSwgW3tcbiAgICB0eXBlOiBQaXBlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBuYW1lOiAnaTE4blBsdXJhbCdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBOZ0xvY2FsaXphdGlvblxuICB9XSwgbnVsbCk7XG59KSgpO1xuY2xhc3MgSTE4blNlbGVjdFBpcGUge1xuICB0cmFuc2Zvcm0odmFsdWUsIG1hcHBpbmcpIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuICcnO1xuICAgIGlmICh0eXBlb2YgbWFwcGluZyAhPT0gJ29iamVjdCcgfHwgdHlwZW9mIHZhbHVlICE9PSAnc3RyaW5nJykge1xuICAgICAgdGhyb3cgaW52YWxpZFBpcGVBcmd1bWVudEVycm9yKEkxOG5TZWxlY3RQaXBlLCBtYXBwaW5nKTtcbiAgICB9XG4gICAgaWYgKE9iamVjdC5oYXNPd24obWFwcGluZywgdmFsdWUpKSB7XG4gICAgICByZXR1cm4gbWFwcGluZ1t2YWx1ZV07XG4gICAgfVxuICAgIGlmIChPYmplY3QuaGFzT3duKG1hcHBpbmcsICdvdGhlcicpKSB7XG4gICAgICByZXR1cm4gbWFwcGluZ1snb3RoZXInXTtcbiAgICB9XG4gICAgcmV0dXJuICcnO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEkxOG5TZWxlY3RQaXBlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBJMThuU2VsZWN0UGlwZSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1cGlwZSA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVQaXBlKHtcbiAgICBuYW1lOiBcImkxOG5TZWxlY3RcIixcbiAgICB0eXBlOiBJMThuU2VsZWN0UGlwZSxcbiAgICBwdXJlOiB0cnVlXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoSTE4blNlbGVjdFBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ2kxOG5TZWxlY3QnXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIEpzb25QaXBlIHtcbiAgdHJhbnNmb3JtKHZhbHVlKSB7XG4gICAgbmdEZXZNb2RlICYmIHdhcm5JZlNpZ25hbCgnSnNvblBpcGUnLCB2YWx1ZSk7XG4gICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbHVlLCBudWxsLCAyKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBKc29uUGlwZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgSnNvblBpcGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXBpcGUgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lUGlwZSh7XG4gICAgbmFtZTogXCJqc29uXCIsXG4gICAgdHlwZTogSnNvblBpcGUsXG4gICAgcHVyZTogZmFsc2VcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShKc29uUGlwZSwgW3tcbiAgICB0eXBlOiBQaXBlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBuYW1lOiAnanNvbicsXG4gICAgICBwdXJlOiBmYWxzZVxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBtYWtlS2V5VmFsdWVQYWlyKGtleSwgdmFsdWUpIHtcbiAgcmV0dXJuIHtcbiAgICBrZXk6IGtleSxcbiAgICB2YWx1ZTogdmFsdWVcbiAgfTtcbn1cbmNsYXNzIEtleVZhbHVlUGlwZSB7XG4gIGRpZmZlcnM7XG4gIGNvbnN0cnVjdG9yKGRpZmZlcnMpIHtcbiAgICB0aGlzLmRpZmZlcnMgPSBkaWZmZXJzO1xuICB9XG4gIGRpZmZlcjtcbiAga2V5VmFsdWVzID0gW107XG4gIGNvbXBhcmVGbiA9IGRlZmF1bHRDb21wYXJhdG9yO1xuICB0cmFuc2Zvcm0oaW5wdXQsIGNvbXBhcmVGbiA9IGRlZmF1bHRDb21wYXJhdG9yKSB7XG4gICAgbmdEZXZNb2RlICYmIHdhcm5JZlNpZ25hbCgnS2V5VmFsdWVQaXBlJywgaW5wdXQpO1xuICAgIGlmICghaW5wdXQgfHwgIShpbnB1dCBpbnN0YW5jZW9mIE1hcCkgJiYgdHlwZW9mIGlucHV0ICE9PSAnb2JqZWN0Jykge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHRoaXMuZGlmZmVyID8/PSB0aGlzLmRpZmZlcnMuZmluZChpbnB1dCkuY3JlYXRlKCk7XG4gICAgY29uc3QgZGlmZmVyQ2hhbmdlcyA9IHRoaXMuZGlmZmVyLmRpZmYoaW5wdXQpO1xuICAgIGNvbnN0IGNvbXBhcmVGbkNoYW5nZWQgPSBjb21wYXJlRm4gIT09IHRoaXMuY29tcGFyZUZuO1xuICAgIGlmIChkaWZmZXJDaGFuZ2VzKSB7XG4gICAgICB0aGlzLmtleVZhbHVlcyA9IFtdO1xuICAgICAgZGlmZmVyQ2hhbmdlcy5mb3JFYWNoSXRlbShyID0+IHtcbiAgICAgICAgdGhpcy5rZXlWYWx1ZXMucHVzaChtYWtlS2V5VmFsdWVQYWlyKHIua2V5LCByLmN1cnJlbnRWYWx1ZSkpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChkaWZmZXJDaGFuZ2VzIHx8IGNvbXBhcmVGbkNoYW5nZWQpIHtcbiAgICAgIGlmIChjb21wYXJlRm4pIHtcbiAgICAgICAgdGhpcy5rZXlWYWx1ZXMuc29ydChjb21wYXJlRm4pO1xuICAgICAgfVxuICAgICAgdGhpcy5jb21wYXJlRm4gPSBjb21wYXJlRm47XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmtleVZhbHVlcztcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBLZXlWYWx1ZVBpcGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBLZXlWYWx1ZVBpcGUpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTAuS2V5VmFsdWVEaWZmZXJzLCAxNikpO1xuICB9O1xuICBzdGF0aWMgybVwaXBlID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVBpcGUoe1xuICAgIG5hbWU6IFwia2V5dmFsdWVcIixcbiAgICB0eXBlOiBLZXlWYWx1ZVBpcGUsXG4gICAgcHVyZTogZmFsc2VcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShLZXlWYWx1ZVBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ2tleXZhbHVlJyxcbiAgICAgIHB1cmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuS2V5VmFsdWVEaWZmZXJzXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBkZWZhdWx0Q29tcGFyYXRvcihrZXlWYWx1ZUEsIGtleVZhbHVlQikge1xuICBjb25zdCBhID0ga2V5VmFsdWVBLmtleTtcbiAgY29uc3QgYiA9IGtleVZhbHVlQi5rZXk7XG4gIGlmIChhID09PSBiKSByZXR1cm4gMDtcbiAgaWYgKGEgPT0gbnVsbCkgcmV0dXJuIDE7XG4gIGlmIChiID09IG51bGwpIHJldHVybiAtMTtcbiAgaWYgKHR5cGVvZiBhID09ICdzdHJpbmcnICYmIHR5cGVvZiBiID09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIGEgPCBiID8gLTEgOiAxO1xuICB9XG4gIGlmICh0eXBlb2YgYSA9PSAnbnVtYmVyJyAmJiB0eXBlb2YgYiA9PSAnbnVtYmVyJykge1xuICAgIHJldHVybiBhIC0gYjtcbiAgfVxuICBpZiAodHlwZW9mIGEgPT0gJ2Jvb2xlYW4nICYmIHR5cGVvZiBiID09ICdib29sZWFuJykge1xuICAgIHJldHVybiBhIDwgYiA/IC0xIDogMTtcbiAgfVxuICBjb25zdCBhU3RyaW5nID0gU3RyaW5nKGEpO1xuICBjb25zdCBiU3RyaW5nID0gU3RyaW5nKGIpO1xuICByZXR1cm4gYVN0cmluZyA9PSBiU3RyaW5nID8gMCA6IGFTdHJpbmcgPCBiU3RyaW5nID8gLTEgOiAxO1xufVxuY2xhc3MgRGVjaW1hbFBpcGUge1xuICBfbG9jYWxlO1xuICBjb25zdHJ1Y3RvcihfbG9jYWxlKSB7XG4gICAgdGhpcy5fbG9jYWxlID0gX2xvY2FsZTtcbiAgfVxuICB0cmFuc2Zvcm0odmFsdWUsIGRpZ2l0c0luZm8sIGxvY2FsZSkge1xuICAgIGlmICghaXNWYWx1ZSh2YWx1ZSkpIHJldHVybiBudWxsO1xuICAgIGxvY2FsZSB8fD0gdGhpcy5fbG9jYWxlO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBudW0gPSBzdHJUb051bWJlcih2YWx1ZSk7XG4gICAgICByZXR1cm4gZm9ybWF0TnVtYmVyKG51bSwgbG9jYWxlLCBkaWdpdHNJbmZvKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhyb3cgaW52YWxpZFBpcGVBcmd1bWVudEVycm9yKERlY2ltYWxQaXBlLCBlcnJvci5tZXNzYWdlKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gRGVjaW1hbFBpcGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBEZWNpbWFsUGlwZSkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChMT0NBTEVfSUQsIDE2KSk7XG4gIH07XG4gIHN0YXRpYyDJtXBpcGUgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lUGlwZSh7XG4gICAgbmFtZTogXCJudW1iZXJcIixcbiAgICB0eXBlOiBEZWNpbWFsUGlwZSxcbiAgICBwdXJlOiB0cnVlXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRGVjaW1hbFBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ251bWJlcidcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtMT0NBTEVfSURdXG4gICAgfV1cbiAgfV0sIG51bGwpO1xufSkoKTtcbmNsYXNzIFBlcmNlbnRQaXBlIHtcbiAgX2xvY2FsZTtcbiAgY29uc3RydWN0b3IoX2xvY2FsZSkge1xuICAgIHRoaXMuX2xvY2FsZSA9IF9sb2NhbGU7XG4gIH1cbiAgdHJhbnNmb3JtKHZhbHVlLCBkaWdpdHNJbmZvLCBsb2NhbGUpIHtcbiAgICBpZiAoIWlzVmFsdWUodmFsdWUpKSByZXR1cm4gbnVsbDtcbiAgICBsb2NhbGUgfHw9IHRoaXMuX2xvY2FsZTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgbnVtID0gc3RyVG9OdW1iZXIodmFsdWUpO1xuICAgICAgcmV0dXJuIGZvcm1hdFBlcmNlbnQobnVtLCBsb2NhbGUsIGRpZ2l0c0luZm8pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBpbnZhbGlkUGlwZUFyZ3VtZW50RXJyb3IoUGVyY2VudFBpcGUsIGVycm9yLm1lc3NhZ2UpO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBQZXJjZW50UGlwZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFBlcmNlbnRQaXBlKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KExPQ0FMRV9JRCwgMTYpKTtcbiAgfTtcbiAgc3RhdGljIMm1cGlwZSA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVQaXBlKHtcbiAgICBuYW1lOiBcInBlcmNlbnRcIixcbiAgICB0eXBlOiBQZXJjZW50UGlwZSxcbiAgICBwdXJlOiB0cnVlXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUGVyY2VudFBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ3BlcmNlbnQnXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbTE9DQUxFX0lEXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBDdXJyZW5jeVBpcGUge1xuICBfbG9jYWxlO1xuICBfZGVmYXVsdEN1cnJlbmN5Q29kZTtcbiAgY29uc3RydWN0b3IoX2xvY2FsZSwgX2RlZmF1bHRDdXJyZW5jeUNvZGUgPSAnVVNEJykge1xuICAgIHRoaXMuX2xvY2FsZSA9IF9sb2NhbGU7XG4gICAgdGhpcy5fZGVmYXVsdEN1cnJlbmN5Q29kZSA9IF9kZWZhdWx0Q3VycmVuY3lDb2RlO1xuICB9XG4gIHRyYW5zZm9ybSh2YWx1ZSwgY3VycmVuY3lDb2RlID0gdGhpcy5fZGVmYXVsdEN1cnJlbmN5Q29kZSwgZGlzcGxheSA9ICdzeW1ib2wnLCBkaWdpdHNJbmZvLCBsb2NhbGUpIHtcbiAgICBpZiAoIWlzVmFsdWUodmFsdWUpKSByZXR1cm4gbnVsbDtcbiAgICBsb2NhbGUgfHw9IHRoaXMuX2xvY2FsZTtcbiAgICBpZiAodHlwZW9mIGRpc3BsYXkgPT09ICdib29sZWFuJykge1xuICAgICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgICBjb25zb2xlLndhcm4oYFdhcm5pbmc6IHRoZSBjdXJyZW5jeSBwaXBlIGhhcyBiZWVuIGNoYW5nZWQgaW4gQW5ndWxhciB2NS4gVGhlIHN5bWJvbERpc3BsYXkgb3B0aW9uICh0aGlyZCBwYXJhbWV0ZXIpIGlzIG5vdyBhIHN0cmluZyBpbnN0ZWFkIG9mIGEgYm9vbGVhbi4gVGhlIGFjY2VwdGVkIHZhbHVlcyBhcmUgXCJjb2RlXCIsIFwic3ltYm9sXCIgb3IgXCJzeW1ib2wtbmFycm93XCIuYCk7XG4gICAgICB9XG4gICAgICBkaXNwbGF5ID0gZGlzcGxheSA/ICdzeW1ib2wnIDogJ2NvZGUnO1xuICAgIH1cbiAgICBsZXQgY3VycmVuY3kgPSBjdXJyZW5jeUNvZGUgfHwgdGhpcy5fZGVmYXVsdEN1cnJlbmN5Q29kZTtcbiAgICBpZiAoZGlzcGxheSAhPT0gJ2NvZGUnKSB7XG4gICAgICBpZiAoZGlzcGxheSA9PT0gJ3N5bWJvbCcgfHwgZGlzcGxheSA9PT0gJ3N5bWJvbC1uYXJyb3cnKSB7XG4gICAgICAgIGN1cnJlbmN5ID0gZ2V0Q3VycmVuY3lTeW1ib2woY3VycmVuY3ksIGRpc3BsYXkgPT09ICdzeW1ib2wnID8gJ3dpZGUnIDogJ25hcnJvdycsIGxvY2FsZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjdXJyZW5jeSA9IGRpc3BsYXk7XG4gICAgICB9XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCBudW0gPSBzdHJUb051bWJlcih2YWx1ZSk7XG4gICAgICByZXR1cm4gZm9ybWF0Q3VycmVuY3kobnVtLCBsb2NhbGUsIGN1cnJlbmN5LCBjdXJyZW5jeUNvZGUsIGRpZ2l0c0luZm8pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICB0aHJvdyBpbnZhbGlkUGlwZUFyZ3VtZW50RXJyb3IoQ3VycmVuY3lQaXBlLCBlcnJvci5tZXNzYWdlKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gQ3VycmVuY3lQaXBlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgQ3VycmVuY3lQaXBlKShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KExPQ0FMRV9JRCwgMTYpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KERFRkFVTFRfQ1VSUkVOQ1lfQ09ERSwgMTYpKTtcbiAgfTtcbiAgc3RhdGljIMm1cGlwZSA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVQaXBlKHtcbiAgICBuYW1lOiBcImN1cnJlbmN5XCIsXG4gICAgdHlwZTogQ3VycmVuY3lQaXBlLFxuICAgIHB1cmU6IHRydWVcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShDdXJyZW5jeVBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ2N1cnJlbmN5J1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0xPQ0FMRV9JRF1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbREVGQVVMVF9DVVJSRU5DWV9DT0RFXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBpc1ZhbHVlKHZhbHVlKSB7XG4gIHJldHVybiAhKHZhbHVlID09IG51bGwgfHwgdmFsdWUgPT09ICcnIHx8IHZhbHVlICE9PSB2YWx1ZSk7XG59XG5mdW5jdGlvbiBzdHJUb051bWJlcih2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyAmJiAhaXNOYU4oTnVtYmVyKHZhbHVlKSAtIHBhcnNlRmxvYXQodmFsdWUpKSkge1xuICAgIHJldHVybiBOdW1iZXIodmFsdWUpO1xuICB9XG4gIGlmICh0eXBlb2YgdmFsdWUgIT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjMwOSwgbmdEZXZNb2RlICYmIGAke3ZhbHVlfSBpcyBub3QgYSBudW1iZXJgKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5jbGFzcyBTbGljZVBpcGUge1xuICB0cmFuc2Zvcm0odmFsdWUsIHN0YXJ0LCBlbmQpIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3Qgc3VwcG9ydHMgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8IEFycmF5LmlzQXJyYXkodmFsdWUpO1xuICAgIGlmICghc3VwcG9ydHMpIHtcbiAgICAgIHRocm93IGludmFsaWRQaXBlQXJndW1lbnRFcnJvcihTbGljZVBpcGUsIHZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlLnNsaWNlKHN0YXJ0LCBlbmQpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFNsaWNlUGlwZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgU2xpY2VQaXBlKSgpO1xuICB9O1xuICBzdGF0aWMgybVwaXBlID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVBpcGUoe1xuICAgIG5hbWU6IFwic2xpY2VcIixcbiAgICB0eXBlOiBTbGljZVBpcGUsXG4gICAgcHVyZTogZmFsc2VcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShTbGljZVBpcGUsIFt7XG4gICAgdHlwZTogUGlwZSxcbiAgICBhcmdzOiBbe1xuICAgICAgbmFtZTogJ3NsaWNlJyxcbiAgICAgIHB1cmU6IGZhbHNlXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNvbnN0IENPTU1PTl9QSVBFUyA9IFtBc3luY1BpcGUsIFVwcGVyQ2FzZVBpcGUsIExvd2VyQ2FzZVBpcGUsIEpzb25QaXBlLCBTbGljZVBpcGUsIERlY2ltYWxQaXBlLCBQZXJjZW50UGlwZSwgVGl0bGVDYXNlUGlwZSwgQ3VycmVuY3lQaXBlLCBEYXRlUGlwZSwgSTE4blBsdXJhbFBpcGUsIEkxOG5TZWxlY3RQaXBlLCBLZXlWYWx1ZVBpcGVdO1xuY2xhc3MgQ29tbW9uTW9kdWxlIHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gQ29tbW9uTW9kdWxlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBDb21tb25Nb2R1bGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtW1vZCA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVOZ01vZHVsZSh7XG4gICAgdHlwZTogQ29tbW9uTW9kdWxlLFxuICAgIGltcG9ydHM6IFtOZ0NsYXNzLCBOZ0NvbXBvbmVudE91dGxldCwgTmdGb3JPZiwgTmdJZiwgTmdUZW1wbGF0ZU91dGxldCwgTmdTdHlsZSwgTmdTd2l0Y2gsIE5nU3dpdGNoQ2FzZSwgTmdTd2l0Y2hEZWZhdWx0LCBOZ1BsdXJhbCwgTmdQbHVyYWxDYXNlLCBBc3luY1BpcGUsIFVwcGVyQ2FzZVBpcGUsIExvd2VyQ2FzZVBpcGUsIEpzb25QaXBlLCBTbGljZVBpcGUsIERlY2ltYWxQaXBlLCBQZXJjZW50UGlwZSwgVGl0bGVDYXNlUGlwZSwgQ3VycmVuY3lQaXBlLCBEYXRlUGlwZSwgSTE4blBsdXJhbFBpcGUsIEkxOG5TZWxlY3RQaXBlLCBLZXlWYWx1ZVBpcGVdLFxuICAgIGV4cG9ydHM6IFtOZ0NsYXNzLCBOZ0NvbXBvbmVudE91dGxldCwgTmdGb3JPZiwgTmdJZiwgTmdUZW1wbGF0ZU91dGxldCwgTmdTdHlsZSwgTmdTd2l0Y2gsIE5nU3dpdGNoQ2FzZSwgTmdTd2l0Y2hEZWZhdWx0LCBOZ1BsdXJhbCwgTmdQbHVyYWxDYXNlLCBBc3luY1BpcGUsIFVwcGVyQ2FzZVBpcGUsIExvd2VyQ2FzZVBpcGUsIEpzb25QaXBlLCBTbGljZVBpcGUsIERlY2ltYWxQaXBlLCBQZXJjZW50UGlwZSwgVGl0bGVDYXNlUGlwZSwgQ3VycmVuY3lQaXBlLCBEYXRlUGlwZSwgSTE4blBsdXJhbFBpcGUsIEkxOG5TZWxlY3RQaXBlLCBLZXlWYWx1ZVBpcGVdXG4gIH0pO1xuICBzdGF0aWMgybVpbmogPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0b3Ioe30pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoQ29tbW9uTW9kdWxlLCBbe1xuICAgIHR5cGU6IE5nTW9kdWxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBpbXBvcnRzOiBbQ09NTU9OX0RJUkVDVElWRVMsIENPTU1PTl9QSVBFU10sXG4gICAgICBleHBvcnRzOiBbQ09NTU9OX0RJUkVDVElWRVMsIENPTU1PTl9QSVBFU11cbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuZXhwb3J0IHsgQXN5bmNQaXBlLCBDb21tb25Nb2R1bGUsIEN1cnJlbmN5UGlwZSwgREFURV9QSVBFX0RFRkFVTFRfT1BUSU9OUywgREFURV9QSVBFX0RFRkFVTFRfVElNRVpPTkUsIERhdGVQaXBlLCBEZWNpbWFsUGlwZSwgRm9ybVN0eWxlLCBGb3JtYXRXaWR0aCwgSGFzaExvY2F0aW9uU3RyYXRlZ3ksIEkxOG5QbHVyYWxQaXBlLCBJMThuU2VsZWN0UGlwZSwgSnNvblBpcGUsIEtleVZhbHVlUGlwZSwgTG93ZXJDYXNlUGlwZSwgTmdDbGFzcywgTmdDb21wb25lbnRPdXRsZXQsIE5nRm9yT2YsIE5nRm9yT2ZDb250ZXh0LCBOZ0lmLCBOZ0lmQ29udGV4dCwgTmdMb2NhbGVMb2NhbGl6YXRpb24sIE5nTG9jYWxpemF0aW9uLCBOZ1BsdXJhbCwgTmdQbHVyYWxDYXNlLCBOZ1N0eWxlLCBOZ1N3aXRjaCwgTmdTd2l0Y2hDYXNlLCBOZ1N3aXRjaERlZmF1bHQsIE5nVGVtcGxhdGVPdXRsZXQsIE51bWJlckZvcm1hdFN0eWxlLCBOdW1iZXJTeW1ib2wsIFBlcmNlbnRQaXBlLCBQbHVyYWwsIFNsaWNlUGlwZSwgVGl0bGVDYXNlUGlwZSwgVHJhbnNsYXRpb25XaWR0aCwgVXBwZXJDYXNlUGlwZSwgV2Vla0RheSwgZm9ybWF0Q3VycmVuY3ksIGZvcm1hdERhdGUsIGZvcm1hdE51bWJlciwgZm9ybWF0UGVyY2VudCwgZ2V0Q3VycmVuY3lTeW1ib2wsIGdldExvY2FsZUN1cnJlbmN5Q29kZSwgZ2V0TG9jYWxlQ3VycmVuY3lOYW1lLCBnZXRMb2NhbGVDdXJyZW5jeVN5bWJvbCwgZ2V0TG9jYWxlRGF0ZUZvcm1hdCwgZ2V0TG9jYWxlRGF0ZVRpbWVGb3JtYXQsIGdldExvY2FsZURheU5hbWVzLCBnZXRMb2NhbGVEYXlQZXJpb2RzLCBnZXRMb2NhbGVEaXJlY3Rpb24sIGdldExvY2FsZUVyYU5hbWVzLCBnZXRMb2NhbGVFeHRyYURheVBlcmlvZFJ1bGVzLCBnZXRMb2NhbGVFeHRyYURheVBlcmlvZHMsIGdldExvY2FsZUZpcnN0RGF5T2ZXZWVrLCBnZXRMb2NhbGVJZCwgZ2V0TG9jYWxlTW9udGhOYW1lcywgZ2V0TG9jYWxlTnVtYmVyRm9ybWF0LCBnZXRMb2NhbGVOdW1iZXJTeW1ib2wsIGdldExvY2FsZVBsdXJhbENhc2UsIGdldExvY2FsZVRpbWVGb3JtYXQsIGdldExvY2FsZVdlZWtFbmRSYW5nZSwgZ2V0TnVtYmVyT2ZDdXJyZW5jeURpZ2l0cyB9O1xuIiwiLyoqXG4gKiBAbGljZW5zZSBBbmd1bGFyIHYyMi4xLjJcbiAqIChjKSAyMDEwLTIwMjYgR29vZ2xlIExMQy4gaHR0cHM6Ly9hbmd1bGFyLmRldi9cbiAqIExpY2Vuc2U6IE1JVFxuICovXG5cbmltcG9ydCAqIGFzIGkwIGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSW5qZWN0aW9uVG9rZW4sIEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmNvbnN0IFBSRUNPTU1JVF9IQU5ETEVSX1NVUFBPUlRFRCA9IG5ldyBJbmplY3Rpb25Ub2tlbignJywge1xuICBmYWN0b3J5OiAoKSA9PiB7XG4gICAgcmV0dXJuIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiB3aW5kb3cuTmF2aWdhdGlvblByZWNvbW1pdENvbnRyb2xsZXIgIT09ICd1bmRlZmluZWQnO1xuICB9XG59KTtcbmNsYXNzIFBsYXRmb3JtTmF2aWdhdGlvbiB7XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFBsYXRmb3JtTmF2aWdhdGlvbl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgUGxhdGZvcm1OYXZpZ2F0aW9uKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBQbGF0Zm9ybU5hdmlnYXRpb24sXG4gICAgZmFjdG9yeTogKCkgPT4gKCgpID0+IHdpbmRvdy5uYXZpZ2F0aW9uKSgpLFxuICAgIHByb3ZpZGVkSW46ICdwbGF0Zm9ybSdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShQbGF0Zm9ybU5hdmlnYXRpb24sIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZWRJbjogJ3BsYXRmb3JtJyxcbiAgICAgIHVzZUZhY3Rvcnk6ICgpID0+IHdpbmRvdy5uYXZpZ2F0aW9uXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmV4cG9ydCB7IFBSRUNPTU1JVF9IQU5ETEVSX1NVUFBPUlRFRCwgUGxhdGZvcm1OYXZpZ2F0aW9uIH07XG4iLCIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjIyLjEuMlxuICogKGMpIDIwMTAtMjAyNiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuZGV2L1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0IHsgTG9jYXRpb24sIExvY2F0aW9uU3RyYXRlZ3ksIG5vcm1hbGl6ZVF1ZXJ5UGFyYW1zIH0gZnJvbSAnLi9fbG9jYXRpb24tY2h1bmsubWpzJztcbmV4cG9ydCB7IEFQUF9CQVNFX0hSRUYsIE5vVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5LCBQYXRoTG9jYXRpb25TdHJhdGVneSwgVHJhaWxpbmdTbGFzaFBhdGhMb2NhdGlvblN0cmF0ZWd5IH0gZnJvbSAnLi9fbG9jYXRpb24tY2h1bmsubWpzJztcbmV4cG9ydCB7IEFzeW5jUGlwZSwgQ29tbW9uTW9kdWxlLCBDdXJyZW5jeVBpcGUsIERBVEVfUElQRV9ERUZBVUxUX09QVElPTlMsIERBVEVfUElQRV9ERUZBVUxUX1RJTUVaT05FLCBEYXRlUGlwZSwgRGVjaW1hbFBpcGUsIEZvcm1TdHlsZSwgRm9ybWF0V2lkdGgsIEhhc2hMb2NhdGlvblN0cmF0ZWd5LCBJMThuUGx1cmFsUGlwZSwgSTE4blNlbGVjdFBpcGUsIEpzb25QaXBlLCBLZXlWYWx1ZVBpcGUsIExvd2VyQ2FzZVBpcGUsIE5nQ2xhc3MsIE5nQ29tcG9uZW50T3V0bGV0LCBOZ0Zvck9mIGFzIE5nRm9yLCBOZ0Zvck9mLCBOZ0Zvck9mQ29udGV4dCwgTmdJZiwgTmdJZkNvbnRleHQsIE5nTG9jYWxlTG9jYWxpemF0aW9uLCBOZ0xvY2FsaXphdGlvbiwgTmdQbHVyYWwsIE5nUGx1cmFsQ2FzZSwgTmdTdHlsZSwgTmdTd2l0Y2gsIE5nU3dpdGNoQ2FzZSwgTmdTd2l0Y2hEZWZhdWx0LCBOZ1RlbXBsYXRlT3V0bGV0LCBOdW1iZXJGb3JtYXRTdHlsZSwgTnVtYmVyU3ltYm9sLCBQZXJjZW50UGlwZSwgUGx1cmFsLCBTbGljZVBpcGUsIFRpdGxlQ2FzZVBpcGUsIFRyYW5zbGF0aW9uV2lkdGgsIFVwcGVyQ2FzZVBpcGUsIFdlZWtEYXksIGZvcm1hdEN1cnJlbmN5LCBmb3JtYXREYXRlLCBmb3JtYXROdW1iZXIsIGZvcm1hdFBlcmNlbnQsIGdldEN1cnJlbmN5U3ltYm9sLCBnZXRMb2NhbGVDdXJyZW5jeUNvZGUsIGdldExvY2FsZUN1cnJlbmN5TmFtZSwgZ2V0TG9jYWxlQ3VycmVuY3lTeW1ib2wsIGdldExvY2FsZURhdGVGb3JtYXQsIGdldExvY2FsZURhdGVUaW1lRm9ybWF0LCBnZXRMb2NhbGVEYXlOYW1lcywgZ2V0TG9jYWxlRGF5UGVyaW9kcywgZ2V0TG9jYWxlRGlyZWN0aW9uLCBnZXRMb2NhbGVFcmFOYW1lcywgZ2V0TG9jYWxlRXh0cmFEYXlQZXJpb2RSdWxlcywgZ2V0TG9jYWxlRXh0cmFEYXlQZXJpb2RzLCBnZXRMb2NhbGVGaXJzdERheU9mV2VlaywgZ2V0TG9jYWxlSWQsIGdldExvY2FsZU1vbnRoTmFtZXMsIGdldExvY2FsZU51bWJlckZvcm1hdCwgZ2V0TG9jYWxlTnVtYmVyU3ltYm9sLCBnZXRMb2NhbGVQbHVyYWxDYXNlLCBnZXRMb2NhbGVUaW1lRm9ybWF0LCBnZXRMb2NhbGVXZWVrRW5kUmFuZ2UsIGdldE51bWJlck9mQ3VycmVuY3lEaWdpdHMgfSBmcm9tICcuL19jb21tb25fbW9kdWxlLWNodW5rLm1qcyc7XG5leHBvcnQgeyBCcm93c2VyUGxhdGZvcm1Mb2NhdGlvbiwgTE9DQVRJT05fSU5JVElBTElaRUQsIFBsYXRmb3JtTG9jYXRpb24sIERvbUFkYXB0ZXIgYXMgybVEb21BZGFwdGVyLCBnZXRET00gYXMgybVnZXRET00sIHNldFJvb3REb21BZGFwdGVyIGFzIMm1c2V0Um9vdERvbUFkYXB0ZXIgfSBmcm9tICcuL19wbGF0Zm9ybV9sb2NhdGlvbi1jaHVuay5tanMnO1xuaW1wb3J0ICogYXMgaTAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBpbmplY3QsIERlc3Ryb3lSZWYsIEluamVjdGFibGUsIMm1cmVnaXN0ZXJMb2NhbGVEYXRhIGFzIF9yZWdpc3RlckxvY2FsZURhdGEsIFZlcnNpb24sIMm1ybVkZWZpbmVJbmplY3RhYmxlIGFzIF9fZGVmaW5lSW5qZWN0YWJsZSwgRE9DVU1FTlQsIMm1Zm9ybWF0UnVudGltZUVycm9yIGFzIF9mb3JtYXRSdW50aW1lRXJyb3IsIEluamVjdGlvblRva2VuLCDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCBTZXJ2aWNlLCDJtUlNQUdFX0NPTkZJRyBhcyBfSU1BR0VfQ09ORklHLCBSZW5kZXJlcjIsIEVsZW1lbnRSZWYsIEluamVjdG9yLCDJtXBlcmZvcm1hbmNlTWFya0ZlYXR1cmUgYXMgX3BlcmZvcm1hbmNlTWFya0ZlYXR1cmUsIE5nWm9uZSwgQXBwbGljYXRpb25SZWYsIGJvb2xlYW5BdHRyaWJ1dGUsIG51bWJlckF0dHJpYnV0ZSwgQ2hhbmdlRGV0ZWN0b3JSZWYsIMm1SU1BR0VfQ09ORklHX0RFRkFVTFRTIGFzIF9JTUFHRV9DT05GSUdfREVGQVVMVFMsIMm1dW53cmFwU2FmZVZhbHVlIGFzIF91bndyYXBTYWZlVmFsdWUsIElucHV0LCBEaXJlY3RpdmUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmV4cG9ydCB7IERPQ1VNRU5ULCDJtUlNQUdFX0NPTkZJRyBhcyBJTUFHRV9DT05GSUcgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFBsYXRmb3JtTmF2aWdhdGlvbiB9IGZyb20gJy4vX3BsYXRmb3JtX25hdmlnYXRpb24tY2h1bmsubWpzJztcbmV4cG9ydCB7IFBSRUNPTU1JVF9IQU5ETEVSX1NVUFBPUlRFRCBhcyDJtVBSRUNPTU1JVF9IQU5ETEVSX1NVUFBPUlRFRCB9IGZyb20gJy4vX3BsYXRmb3JtX25hdmlnYXRpb24tY2h1bmsubWpzJztcbmV4cG9ydCB7IFhockZhY3RvcnksIHBhcnNlQ29va2llVmFsdWUgYXMgybVwYXJzZUNvb2tpZVZhbHVlIH0gZnJvbSAnLi9feGhyLWNodW5rLm1qcyc7XG5pbXBvcnQgJ3J4anMnO1xuY2xhc3MgTmF2aWdhdGlvbkFkYXB0ZXJGb3JMb2NhdGlvbiBleHRlbmRzIExvY2F0aW9uIHtcbiAgbmF2aWdhdGlvbiA9IGluamVjdChQbGF0Zm9ybU5hdmlnYXRpb24pO1xuICBkZXN0cm95UmVmID0gaW5qZWN0KERlc3Ryb3lSZWYpO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihpbmplY3QoTG9jYXRpb25TdHJhdGVneSkpO1xuICAgIHRoaXMucmVnaXN0ZXJOYXZpZ2F0aW9uTGlzdGVuZXJzKCk7XG4gIH1cbiAgcmVnaXN0ZXJOYXZpZ2F0aW9uTGlzdGVuZXJzKCkge1xuICAgIGNvbnN0IGN1cnJlbnRFbnRyeUNoYW5nZUxpc3RlbmVyID0gKCkgPT4ge1xuICAgICAgdGhpcy5fbm90aWZ5VXJsQ2hhbmdlTGlzdGVuZXJzKHRoaXMucGF0aCh0cnVlKSwgdGhpcy5nZXRTdGF0ZSgpKTtcbiAgICB9O1xuICAgIHRoaXMubmF2aWdhdGlvbi5hZGRFdmVudExpc3RlbmVyKCdjdXJyZW50ZW50cnljaGFuZ2UnLCBjdXJyZW50RW50cnlDaGFuZ2VMaXN0ZW5lcik7XG4gICAgdGhpcy5kZXN0cm95UmVmLm9uRGVzdHJveSgoKSA9PiB7XG4gICAgICB0aGlzLm5hdmlnYXRpb24ucmVtb3ZlRXZlbnRMaXN0ZW5lcignY3VycmVudGVudHJ5Y2hhbmdlJywgY3VycmVudEVudHJ5Q2hhbmdlTGlzdGVuZXIpO1xuICAgIH0pO1xuICB9XG4gIGdldFN0YXRlKCkge1xuICAgIHJldHVybiB0aGlzLm5hdmlnYXRpb24uY3VycmVudEVudHJ5Py5nZXRTdGF0ZSgpO1xuICB9XG4gIHJlcGxhY2VTdGF0ZShwYXRoLCBxdWVyeSA9ICcnLCBzdGF0ZSA9IG51bGwpIHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLnByZXBhcmVFeHRlcm5hbFVybChwYXRoICsgbm9ybWFsaXplUXVlcnlQYXJhbXMocXVlcnkpKTtcbiAgICB0aGlzLm5hdmlnYXRpb24ubmF2aWdhdGUodXJsLCB7XG4gICAgICBzdGF0ZSxcbiAgICAgIGhpc3Rvcnk6ICdyZXBsYWNlJ1xuICAgIH0pO1xuICB9XG4gIGdvKHBhdGgsIHF1ZXJ5ID0gJycsIHN0YXRlID0gbnVsbCkge1xuICAgIGNvbnN0IHVybCA9IHRoaXMucHJlcGFyZUV4dGVybmFsVXJsKHBhdGggKyBub3JtYWxpemVRdWVyeVBhcmFtcyhxdWVyeSkpO1xuICAgIHRoaXMubmF2aWdhdGlvbi5uYXZpZ2F0ZSh1cmwsIHtcbiAgICAgIHN0YXRlLFxuICAgICAgaGlzdG9yeTogJ3B1c2gnXG4gICAgfSk7XG4gIH1cbiAgYmFjaygpIHtcbiAgICB0aGlzLm5hdmlnYXRpb24uYmFjaygpO1xuICB9XG4gIGZvcndhcmQoKSB7XG4gICAgdGhpcy5uYXZpZ2F0aW9uLmZvcndhcmQoKTtcbiAgfVxuICBvblVybENoYW5nZShmbikge1xuICAgIHRoaXMuX3VybENoYW5nZUxpc3RlbmVycy5wdXNoKGZuKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgY29uc3QgZm5JbmRleCA9IHRoaXMuX3VybENoYW5nZUxpc3RlbmVycy5pbmRleE9mKGZuKTtcbiAgICAgIHRoaXMuX3VybENoYW5nZUxpc3RlbmVycy5zcGxpY2UoZm5JbmRleCwgMSk7XG4gICAgfTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBOYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBOYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uLFxuICAgIGZhY3Rvcnk6IE5hdmlnYXRpb25BZGFwdGVyRm9yTG9jYXRpb24uybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFtdLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiByZWdpc3RlckxvY2FsZURhdGEoZGF0YSwgbG9jYWxlSWQsIGV4dHJhRGF0YSkge1xuICByZXR1cm4gX3JlZ2lzdGVyTG9jYWxlRGF0YShkYXRhLCBsb2NhbGVJZCwgZXh0cmFEYXRhKTtcbn1cbmNvbnN0IFBMQVRGT1JNX0JST1dTRVJfSUQgPSAnYnJvd3Nlcic7XG5jb25zdCBQTEFURk9STV9TRVJWRVJfSUQgPSAnc2VydmVyJztcbmZ1bmN0aW9uIGlzUGxhdGZvcm1Ccm93c2VyKHBsYXRmb3JtSWQpIHtcbiAgcmV0dXJuIHBsYXRmb3JtSWQgPT09IFBMQVRGT1JNX0JST1dTRVJfSUQ7XG59XG5mdW5jdGlvbiBpc1BsYXRmb3JtU2VydmVyKHBsYXRmb3JtSWQpIHtcbiAgcmV0dXJuIHBsYXRmb3JtSWQgPT09IFBMQVRGT1JNX1NFUlZFUl9JRDtcbn1cbmNvbnN0IFZFUlNJT04gPSAvKiBAX19QVVJFX18gKi9uZXcgVmVyc2lvbignMjIuMS4yJyk7XG5jbGFzcyBWaWV3cG9ydFNjcm9sbGVyIHtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL1xuICBfX2RlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBWaWV3cG9ydFNjcm9sbGVyLFxuICAgIHByb3ZpZGVkSW46ICdyb290JyxcbiAgICBmYWN0b3J5OiAoKSA9PiB0eXBlb2YgbmdTZXJ2ZXJNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ1NlcnZlck1vZGUgPyBuZXcgTnVsbFZpZXdwb3J0U2Nyb2xsZXIoKSA6IG5ldyBCcm93c2VyVmlld3BvcnRTY3JvbGxlcihpbmplY3QoRE9DVU1FTlQpLCB3aW5kb3cpXG4gIH0pO1xufVxuY2xhc3MgQnJvd3NlclZpZXdwb3J0U2Nyb2xsZXIge1xuICBkb2N1bWVudDtcbiAgd2luZG93O1xuICBvZmZzZXQgPSAoKSA9PiBbMCwgMF07XG4gIGNvbnN0cnVjdG9yKGRvY3VtZW50LCB3aW5kb3cpIHtcbiAgICB0aGlzLmRvY3VtZW50ID0gZG9jdW1lbnQ7XG4gICAgdGhpcy53aW5kb3cgPSB3aW5kb3c7XG4gIH1cbiAgc2V0T2Zmc2V0KG9mZnNldCkge1xuICAgIGlmIChBcnJheS5pc0FycmF5KG9mZnNldCkpIHtcbiAgICAgIHRoaXMub2Zmc2V0ID0gKCkgPT4gb2Zmc2V0O1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm9mZnNldCA9IG9mZnNldDtcbiAgICB9XG4gIH1cbiAgZ2V0U2Nyb2xsUG9zaXRpb24oKSB7XG4gICAgcmV0dXJuIFt0aGlzLndpbmRvdy5zY3JvbGxYLCB0aGlzLndpbmRvdy5zY3JvbGxZXTtcbiAgfVxuICBzY3JvbGxUb1Bvc2l0aW9uKHBvc2l0aW9uLCBvcHRpb25zKSB7XG4gICAgdGhpcy53aW5kb3cuc2Nyb2xsVG8oe1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIGxlZnQ6IHBvc2l0aW9uWzBdLFxuICAgICAgdG9wOiBwb3NpdGlvblsxXVxuICAgIH0pO1xuICB9XG4gIHNjcm9sbFRvQW5jaG9yKHRhcmdldCwgb3B0aW9ucykge1xuICAgIGNvbnN0IGVsU2VsZWN0ZWQgPSBmaW5kQW5jaG9yRnJvbURvY3VtZW50KHRoaXMuZG9jdW1lbnQsIHRhcmdldCk7XG4gICAgaWYgKGVsU2VsZWN0ZWQpIHtcbiAgICAgIHRoaXMuc2Nyb2xsVG9FbGVtZW50KGVsU2VsZWN0ZWQsIG9wdGlvbnMpO1xuICAgICAgZWxTZWxlY3RlZC5mb2N1cyh7XG4gICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBzZXRIaXN0b3J5U2Nyb2xsUmVzdG9yYXRpb24oc2Nyb2xsUmVzdG9yYXRpb24pIHtcbiAgICB0cnkge1xuICAgICAgdGhpcy53aW5kb3cuaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IHNjcm9sbFJlc3RvcmF0aW9uO1xuICAgIH0gY2F0Y2gge1xuICAgICAgY29uc29sZS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjQwMCwgbmdEZXZNb2RlICYmICdGYWlsZWQgdG8gc2V0IGB3aW5kb3cuaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbmAuICcgKyAnVGhpcyBtYXkgb2NjdXIgd2hlbjpcXG4nICsgJ+KAoiBUaGUgc2NyaXB0IGlzIHJ1bm5pbmcgaW5zaWRlIGEgc2FuZGJveGVkIGlmcmFtZVxcbicgKyAn4oCiIFRoZSB3aW5kb3cgaXMgcGFydGlhbGx5IG5hdmlnYXRlZCBvciBpbmFjdGl2ZVxcbicgKyAn4oCiIFRoZSBzY3JpcHQgaXMgZXhlY3V0ZWQgaW4gYW4gdW50cnVzdGVkIG9yIHNwZWNpYWwgY29udGV4dCAoZS5nLiwgdGVzdCBydW5uZXJzLCBicm93c2VyIGV4dGVuc2lvbnMsIG9yIGNvbnRlbnQgcHJldmlld3MpXFxuJyArICdTY3JvbGwgcG9zaXRpb24gbWF5IG5vdCBiZSBwcmVzZXJ2ZWQgYWNyb3NzIG5hdmlnYXRpb24uJykpO1xuICAgIH1cbiAgfVxuICBzY3JvbGxUb0VsZW1lbnQoZWwsIG9wdGlvbnMpIHtcbiAgICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3QgbGVmdCA9IHJlY3QubGVmdCArIHRoaXMud2luZG93LnBhZ2VYT2Zmc2V0O1xuICAgIGNvbnN0IHRvcCA9IHJlY3QudG9wICsgdGhpcy53aW5kb3cucGFnZVlPZmZzZXQ7XG4gICAgY29uc3Qgb2Zmc2V0ID0gdGhpcy5vZmZzZXQoKTtcbiAgICB0aGlzLndpbmRvdy5zY3JvbGxUbyh7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgbGVmdDogbGVmdCAtIG9mZnNldFswXSxcbiAgICAgIHRvcDogdG9wIC0gb2Zmc2V0WzFdXG4gICAgfSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGZpbmRBbmNob3JGcm9tRG9jdW1lbnQoZG9jdW1lbnQsIHRhcmdldCkge1xuICBjb25zdCBkb2N1bWVudFJlc3VsdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHRhcmdldCkgfHwgZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUodGFyZ2V0KVswXTtcbiAgaWYgKGRvY3VtZW50UmVzdWx0KSB7XG4gICAgcmV0dXJuIGRvY3VtZW50UmVzdWx0O1xuICB9XG4gIGlmICh0eXBlb2YgZG9jdW1lbnQuY3JlYXRlVHJlZVdhbGtlciA9PT0gJ2Z1bmN0aW9uJyAmJiBkb2N1bWVudC5ib2R5ICYmIHR5cGVvZiBkb2N1bWVudC5ib2R5LmF0dGFjaFNoYWRvdyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIGNvbnN0IHRyZWVXYWxrZXIgPSBkb2N1bWVudC5jcmVhdGVUcmVlV2Fsa2VyKGRvY3VtZW50LmJvZHksIE5vZGVGaWx0ZXIuU0hPV19FTEVNRU5UKTtcbiAgICBsZXQgY3VycmVudE5vZGUgPSB0cmVlV2Fsa2VyLmN1cnJlbnROb2RlO1xuICAgIHdoaWxlIChjdXJyZW50Tm9kZSkge1xuICAgICAgY29uc3Qgc2hhZG93Um9vdCA9IGN1cnJlbnROb2RlLnNoYWRvd1Jvb3Q7XG4gICAgICBpZiAoc2hhZG93Um9vdCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBzaGFkb3dSb290LmdldEVsZW1lbnRCeUlkKHRhcmdldCkgfHwgc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKGBbbmFtZT1cIiR7Q1NTLmVzY2FwZSh0YXJnZXQpfVwiXWApO1xuICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY3VycmVudE5vZGUgPSB0cmVlV2Fsa2VyLm5leHROb2RlKCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuY2xhc3MgTnVsbFZpZXdwb3J0U2Nyb2xsZXIge1xuICBzZXRPZmZzZXQob2Zmc2V0KSB7fVxuICBnZXRTY3JvbGxQb3NpdGlvbigpIHtcbiAgICByZXR1cm4gWzAsIDBdO1xuICB9XG4gIHNjcm9sbFRvUG9zaXRpb24ocG9zaXRpb24pIHt9XG4gIHNjcm9sbFRvQW5jaG9yKGFuY2hvciwgb3B0aW9ucykge31cbiAgc2V0SGlzdG9yeVNjcm9sbFJlc3RvcmF0aW9uKHNjcm9sbFJlc3RvcmF0aW9uKSB7fVxufVxuY29uc3QgUExBQ0VIT0xERVJfUVVBTElUWSA9ICcyMCc7XG5mdW5jdGlvbiBnZXRVcmwoc3JjLCB3aW4pIHtcbiAgcmV0dXJuIGlzQWJzb2x1dGVVcmwoc3JjKSA/IG5ldyBVUkwoc3JjKSA6IG5ldyBVUkwoc3JjLCB3aW4ubG9jYXRpb24uaHJlZik7XG59XG5mdW5jdGlvbiBpc0Fic29sdXRlVXJsKHNyYykge1xuICByZXR1cm4gL15odHRwcz86XFwvXFwvLy50ZXN0KHNyYyk7XG59XG5mdW5jdGlvbiBleHRyYWN0SG9zdG5hbWUodXJsKSB7XG4gIHJldHVybiBpc0Fic29sdXRlVXJsKHVybCkgPyBuZXcgVVJMKHVybCkuaG9zdG5hbWUgOiB1cmw7XG59XG5mdW5jdGlvbiBpc1ZhbGlkUGF0aChwYXRoKSB7XG4gIGNvbnN0IGlzU3RyaW5nID0gdHlwZW9mIHBhdGggPT09ICdzdHJpbmcnO1xuICBpZiAoIWlzU3RyaW5nIHx8IHBhdGgudHJpbSgpID09PSAnJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocGF0aCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuZnVuY3Rpb24gbm9ybWFsaXplUGF0aChwYXRoKSB7XG4gIHJldHVybiBwYXRoLmVuZHNXaXRoKCcvJykgPyBwYXRoLnNsaWNlKDAsIC0xKSA6IHBhdGg7XG59XG5mdW5jdGlvbiBub3JtYWxpemVTcmMoc3JjKSB7XG4gIHJldHVybiBzcmMuc3RhcnRzV2l0aCgnLycpID8gc3JjLnNsaWNlKDEpIDogc3JjO1xufVxuZnVuY3Rpb24gZXNjYXBlQ3NzVXJsKGlucHV0KSB7XG4gIHJldHVybiBpbnB1dC5yZXBsYWNlKC9cXFxcL2csICdcXFxcXFxcXCcpLnJlcGxhY2UoL1tcXG5cXHJcXGZcXDBdL2csICcnKS5yZXBsYWNlKC9cIi9nLCAnXFxcXFwiJyk7XG59XG5jb25zdCBub29wSW1hZ2VMb2FkZXIgPSBjb25maWcgPT4gY29uZmlnLnNyYztcbmNvbnN0IElNQUdFX0xPQURFUiA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnSW1hZ2VMb2FkZXInIDogJycsIHtcbiAgZmFjdG9yeTogKCkgPT4gbm9vcEltYWdlTG9hZGVyXG59KTtcbmZ1bmN0aW9uIGNyZWF0ZUltYWdlTG9hZGVyKGJ1aWxkVXJsRm4sIGV4YW1wbGVVcmxzKSB7XG4gIHJldHVybiBmdW5jdGlvbiBwcm92aWRlSW1hZ2VMb2FkZXIocGF0aCkge1xuICAgIGlmICghaXNWYWxpZFBhdGgocGF0aCkpIHtcbiAgICAgIHRocm93SW52YWxpZFBhdGhFcnJvcihwYXRoLCBleGFtcGxlVXJscyB8fCBbXSk7XG4gICAgfVxuICAgIHBhdGggPSBub3JtYWxpemVQYXRoKHBhdGgpO1xuICAgIGNvbnN0IGxvYWRlckZuID0gY29uZmlnID0+IHtcbiAgICAgIGlmIChpc0Fic29sdXRlVXJsKGNvbmZpZy5zcmMpKSB7XG4gICAgICAgIHRocm93VW5leHBlY3RlZEFic29sdXRlVXJsRXJyb3IocGF0aCwgY29uZmlnLnNyYyk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYnVpbGRVcmxGbihwYXRoLCB7XG4gICAgICAgIC4uLmNvbmZpZyxcbiAgICAgICAgc3JjOiBub3JtYWxpemVTcmMoY29uZmlnLnNyYylcbiAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICAgIHByb3ZpZGU6IElNQUdFX0xPQURFUixcbiAgICAgIHVzZVZhbHVlOiBsb2FkZXJGblxuICAgIH1dO1xuICAgIHJldHVybiBwcm92aWRlcnM7XG4gIH07XG59XG5mdW5jdGlvbiB0aHJvd0ludmFsaWRQYXRoRXJyb3IocGF0aCwgZXhhbXBsZVVybHMpIHtcbiAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1OSwgbmdEZXZNb2RlICYmIGBJbWFnZSBsb2FkZXIgaGFzIGRldGVjdGVkIGFuIGludmFsaWQgcGF0aCAoXFxgJHtwYXRofVxcYCkuIGAgKyBgVG8gZml4IHRoaXMsIHN1cHBseSBhIHBhdGggdXNpbmcgb25lIG9mIHRoZSBmb2xsb3dpbmcgZm9ybWF0czogJHtleGFtcGxlVXJscy5qb2luKCcgb3IgJyl9YCk7XG59XG5mdW5jdGlvbiB0aHJvd1VuZXhwZWN0ZWRBYnNvbHV0ZVVybEVycm9yKHBhdGgsIHVybCkge1xuICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyOTU5LCBuZ0Rldk1vZGUgJiYgYEltYWdlIGxvYWRlciBoYXMgZGV0ZWN0ZWQgYSBcXGA8aW1nPlxcYCB0YWcgd2l0aCBhbiBpbnZhbGlkIFxcYG5nU3JjXFxgIGF0dHJpYnV0ZTogJHt1cmx9LiBgICsgYFRoaXMgaW1hZ2UgbG9hZGVyIGV4cGVjdHMgXFxgbmdTcmNcXGAgdG8gYmUgYSByZWxhdGl2ZSBVUkwgLSBgICsgYGhvd2V2ZXIgdGhlIHByb3ZpZGVkIHZhbHVlIGlzIGFuIGFic29sdXRlIFVSTC4gYCArIGBUbyBmaXggdGhpcywgcHJvdmlkZSBcXGBuZ1NyY1xcYCBhcyBhIHBhdGggcmVsYXRpdmUgdG8gdGhlIGJhc2UgVVJMIGAgKyBgY29uZmlndXJlZCBmb3IgdGhpcyBsb2FkZXIgKFxcYCR7cGF0aH1cXGApLmApO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplTG9hZGVyVHJhbnNmb3JtKHRyYW5zZm9ybSwgc2VwYXJhdG9yKSB7XG4gIGlmICh0eXBlb2YgdHJhbnNmb3JtID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiB0cmFuc2Zvcm07XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHRyYW5zZm9ybSkubWFwKChba2V5LCB2YWx1ZV0pID0+IGAke2tleX0ke3NlcGFyYXRvcn0ke3ZhbHVlfWApLmpvaW4oJywnKTtcbn1cbmNvbnN0IHByb3ZpZGVDbG91ZGZsYXJlTG9hZGVyID0gY3JlYXRlSW1hZ2VMb2FkZXIoY3JlYXRlQ2xvdWRmbGFyZVVybCwgbmdEZXZNb2RlID8gWydodHRwczovLzxaT05FPi9jZG4tY2dpL2ltYWdlLzxPUFRJT05TPi88U09VUkNFLUlNQUdFPiddIDogdW5kZWZpbmVkKTtcbmZ1bmN0aW9uIGNyZWF0ZUNsb3VkZmxhcmVVcmwocGF0aCwgY29uZmlnKSB7XG4gIGxldCBwYXJhbXMgPSBgZm9ybWF0PWF1dG9gO1xuICBpZiAoY29uZmlnLndpZHRoKSB7XG4gICAgcGFyYW1zICs9IGAsd2lkdGg9JHtjb25maWcud2lkdGh9YDtcbiAgfVxuICBpZiAoY29uZmlnLmhlaWdodCkge1xuICAgIHBhcmFtcyArPSBgLGhlaWdodD0ke2NvbmZpZy5oZWlnaHR9YDtcbiAgfVxuICBpZiAoY29uZmlnLmlzUGxhY2Vob2xkZXIpIHtcbiAgICBwYXJhbXMgKz0gYCxxdWFsaXR5PSR7UExBQ0VIT0xERVJfUVVBTElUWX1gO1xuICB9XG4gIGlmIChjb25maWcubG9hZGVyUGFyYW1zPy5bJ3RyYW5zZm9ybSddKSB7XG4gICAgY29uc3QgdHJhbnNmb3JtU3RyID0gbm9ybWFsaXplTG9hZGVyVHJhbnNmb3JtKGNvbmZpZy5sb2FkZXJQYXJhbXNbJ3RyYW5zZm9ybSddLCAnPScpO1xuICAgIHBhcmFtcyArPSBgLCR7dHJhbnNmb3JtU3RyfWA7XG4gIH1cbiAgcmV0dXJuIGAke3BhdGh9L2Nkbi1jZ2kvaW1hZ2UvJHtwYXJhbXN9LyR7Y29uZmlnLnNyY31gO1xufVxuY29uc3QgY2xvdWRpbmFyeUxvYWRlckluZm8gPSB7XG4gIG5hbWU6ICdDbG91ZGluYXJ5JyxcbiAgdGVzdFVybDogaXNDbG91ZGluYXJ5VXJsXG59O1xuY29uc3QgQ0xPVURJTkFSWV9MT0FERVJfUkVHRVggPSAvaHR0cHM/XFw6XFwvXFwvW15cXC9dK1xcLmNsb3VkaW5hcnlcXC5jb21cXC8uKy87XG5mdW5jdGlvbiBpc0Nsb3VkaW5hcnlVcmwodXJsKSB7XG4gIHJldHVybiBDTE9VRElOQVJZX0xPQURFUl9SRUdFWC50ZXN0KHVybCk7XG59XG5jb25zdCBwcm92aWRlQ2xvdWRpbmFyeUxvYWRlciA9IGNyZWF0ZUltYWdlTG9hZGVyKGNyZWF0ZUNsb3VkaW5hcnlVcmwsIG5nRGV2TW9kZSA/IFsnaHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vbXlzaXRlJywgJ2h0dHBzOi8vbXlzaXRlLmNsb3VkaW5hcnkuY29tJywgJ2h0dHBzOi8vc3ViZG9tYWluLm15c2l0ZS5jb20nXSA6IHVuZGVmaW5lZCk7XG5mdW5jdGlvbiBjcmVhdGVDbG91ZGluYXJ5VXJsKHBhdGgsIGNvbmZpZykge1xuICBjb25zdCBxdWFsaXR5ID0gY29uZmlnLmlzUGxhY2Vob2xkZXIgPyAncV9hdXRvOmxvdycgOiAncV9hdXRvJztcbiAgbGV0IHBhcmFtcyA9IGBmX2F1dG8sJHtxdWFsaXR5fWA7XG4gIGlmIChjb25maWcud2lkdGgpIHtcbiAgICBwYXJhbXMgKz0gYCx3XyR7Y29uZmlnLndpZHRofWA7XG4gIH1cbiAgaWYgKGNvbmZpZy5oZWlnaHQpIHtcbiAgICBwYXJhbXMgKz0gYCxoXyR7Y29uZmlnLmhlaWdodH1gO1xuICB9XG4gIGlmIChjb25maWcubG9hZGVyUGFyYW1zPy5bJ3JvdW5kZWQnXSkge1xuICAgIHBhcmFtcyArPSBgLHJfbWF4YDtcbiAgfVxuICBpZiAoY29uZmlnLmxvYWRlclBhcmFtcz8uWyd0cmFuc2Zvcm0nXSkge1xuICAgIGNvbnN0IHRyYW5zZm9ybVN0ciA9IG5vcm1hbGl6ZUxvYWRlclRyYW5zZm9ybShjb25maWcubG9hZGVyUGFyYW1zWyd0cmFuc2Zvcm0nXSwgJ18nKTtcbiAgICBwYXJhbXMgKz0gYCwke3RyYW5zZm9ybVN0cn1gO1xuICB9XG4gIHJldHVybiBgJHtwYXRofS9pbWFnZS91cGxvYWQvJHtwYXJhbXN9LyR7Y29uZmlnLnNyY31gO1xufVxuY29uc3QgaW1hZ2VLaXRMb2FkZXJJbmZvID0ge1xuICBuYW1lOiAnSW1hZ2VLaXQnLFxuICB0ZXN0VXJsOiBpc0ltYWdlS2l0VXJsXG59O1xuY29uc3QgSU1BR0VfS0lUX0xPQURFUl9SRUdFWCA9IC9odHRwcz9cXDpcXC9cXC9bXlxcL10rXFwuaW1hZ2VraXRcXC5pb1xcLy4rLztcbmZ1bmN0aW9uIGlzSW1hZ2VLaXRVcmwodXJsKSB7XG4gIHJldHVybiBJTUFHRV9LSVRfTE9BREVSX1JFR0VYLnRlc3QodXJsKTtcbn1cbmNvbnN0IHByb3ZpZGVJbWFnZUtpdExvYWRlciA9IGNyZWF0ZUltYWdlTG9hZGVyKGNyZWF0ZUltYWdla2l0VXJsLCBuZ0Rldk1vZGUgPyBbJ2h0dHBzOi8vaWsuaW1hZ2VraXQuaW8vbXlzaXRlJywgJ2h0dHBzOi8vc3ViZG9tYWluLm15c2l0ZS5jb20nXSA6IHVuZGVmaW5lZCk7XG5mdW5jdGlvbiBjcmVhdGVJbWFnZWtpdFVybChwYXRoLCBjb25maWcpIHtcbiAgY29uc3Qge1xuICAgIHNyYyxcbiAgICB3aWR0aFxuICB9ID0gY29uZmlnO1xuICBjb25zdCBwYXJhbXMgPSBbXTtcbiAgaWYgKHdpZHRoKSB7XG4gICAgcGFyYW1zLnB1c2goYHctJHt3aWR0aH1gKTtcbiAgfVxuICBpZiAoY29uZmlnLmhlaWdodCkge1xuICAgIHBhcmFtcy5wdXNoKGBoLSR7Y29uZmlnLmhlaWdodH1gKTtcbiAgfVxuICBpZiAoY29uZmlnLmlzUGxhY2Vob2xkZXIpIHtcbiAgICBwYXJhbXMucHVzaChgcS0ke1BMQUNFSE9MREVSX1FVQUxJVFl9YCk7XG4gIH1cbiAgaWYgKGNvbmZpZy5sb2FkZXJQYXJhbXM/LlsndHJhbnNmb3JtJ10pIHtcbiAgICBjb25zdCB0cmFuc2Zvcm1TdHIgPSBub3JtYWxpemVMb2FkZXJUcmFuc2Zvcm0oY29uZmlnLmxvYWRlclBhcmFtc1sndHJhbnNmb3JtJ10sICctJyk7XG4gICAgcGFyYW1zLnB1c2godHJhbnNmb3JtU3RyKTtcbiAgfVxuICBjb25zdCB1cmxTZWdtZW50cyA9IHBhcmFtcy5sZW5ndGggPyBbcGF0aCwgYHRyOiR7cGFyYW1zLmpvaW4oJywnKX1gLCBzcmNdIDogW3BhdGgsIHNyY107XG4gIGNvbnN0IHVybCA9IG5ldyBVUkwodXJsU2VnbWVudHMuam9pbignLycpKTtcbiAgcmV0dXJuIHVybC5ocmVmO1xufVxuY29uc3QgaW1naXhMb2FkZXJJbmZvID0ge1xuICBuYW1lOiAnSW1naXgnLFxuICB0ZXN0VXJsOiBpc0ltZ2l4VXJsXG59O1xuY29uc3QgSU1HSVhfTE9BREVSX1JFR0VYID0gL2h0dHBzP1xcOlxcL1xcL1teXFwvXStcXC5pbWdpeFxcLm5ldFxcLy4rLztcbmZ1bmN0aW9uIGlzSW1naXhVcmwodXJsKSB7XG4gIHJldHVybiBJTUdJWF9MT0FERVJfUkVHRVgudGVzdCh1cmwpO1xufVxuY29uc3QgcHJvdmlkZUltZ2l4TG9hZGVyID0gY3JlYXRlSW1hZ2VMb2FkZXIoY3JlYXRlSW1naXhVcmwsIG5nRGV2TW9kZSA/IFsnaHR0cHM6Ly9zb21lcGF0aC5pbWdpeC5uZXQvJ10gOiB1bmRlZmluZWQpO1xuZnVuY3Rpb24gY3JlYXRlSW1naXhVcmwocGF0aCwgY29uZmlnKSB7XG4gIGNvbnN0IHBhcmFtcyA9IFtdO1xuICBwYXJhbXMucHVzaCgnYXV0bz1mb3JtYXQnKTtcbiAgaWYgKGNvbmZpZy53aWR0aCkge1xuICAgIHBhcmFtcy5wdXNoKGB3PSR7Y29uZmlnLndpZHRofWApO1xuICB9XG4gIGlmIChjb25maWcuaGVpZ2h0KSB7XG4gICAgcGFyYW1zLnB1c2goYGg9JHtjb25maWcuaGVpZ2h0fWApO1xuICB9XG4gIGlmIChjb25maWcuaXNQbGFjZWhvbGRlcikge1xuICAgIHBhcmFtcy5wdXNoKGBxPSR7UExBQ0VIT0xERVJfUVVBTElUWX1gKTtcbiAgfVxuICBpZiAoY29uZmlnLmxvYWRlclBhcmFtcz8uWyd0cmFuc2Zvcm0nXSkge1xuICAgIGNvbnN0IHRyYW5zZm9ybSA9IG5vcm1hbGl6ZUxvYWRlclRyYW5zZm9ybShjb25maWcubG9hZGVyUGFyYW1zWyd0cmFuc2Zvcm0nXSwgJz0nKS5zcGxpdCgnLCcpO1xuICAgIHBhcmFtcy5wdXNoKC4uLnRyYW5zZm9ybSk7XG4gIH1cbiAgY29uc3QgdXJsID0gbmV3IFVSTChgJHtwYXRofS8ke2NvbmZpZy5zcmN9YCk7XG4gIHVybC5zZWFyY2ggPSBwYXJhbXMuam9pbignJicpO1xuICByZXR1cm4gdXJsLmhyZWY7XG59XG5jb25zdCBuZXRsaWZ5TG9hZGVySW5mbyA9IHtcbiAgbmFtZTogJ05ldGxpZnknLFxuICB0ZXN0VXJsOiBpc05ldGxpZnlVcmxcbn07XG5jb25zdCBORVRMSUZZX0xPQURFUl9SRUdFWCA9IC9odHRwcz9cXDpcXC9cXC9bXlxcL10rXFwubmV0bGlmeVxcLmFwcFxcLy4rLztcbmZ1bmN0aW9uIGlzTmV0bGlmeVVybCh1cmwpIHtcbiAgcmV0dXJuIE5FVExJRllfTE9BREVSX1JFR0VYLnRlc3QodXJsKTtcbn1cbmZ1bmN0aW9uIHByb3ZpZGVOZXRsaWZ5TG9hZGVyKHBhdGgpIHtcbiAgaWYgKHBhdGggJiYgIWlzVmFsaWRQYXRoKHBhdGgpKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1OSwgbmdEZXZNb2RlICYmIGBJbWFnZSBsb2FkZXIgaGFzIGRldGVjdGVkIGFuIGludmFsaWQgcGF0aCAoXFxgJHtwYXRofVxcYCkuIGAgKyBgVG8gZml4IHRoaXMsIHN1cHBseSBlaXRoZXIgdGhlIGZ1bGwgVVJMIHRvIHRoZSBOZXRsaWZ5IHNpdGUsIG9yIGxlYXZlIGl0IGVtcHR5IHRvIHVzZSB0aGUgY3VycmVudCBzaXRlLmApO1xuICB9XG4gIGlmIChwYXRoKSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChwYXRoKTtcbiAgICBwYXRoID0gdXJsLm9yaWdpbjtcbiAgfVxuICBjb25zdCBsb2FkZXJGbiA9IGNvbmZpZyA9PiB7XG4gICAgcmV0dXJuIGNyZWF0ZU5ldGxpZnlVcmwoY29uZmlnLCBwYXRoKTtcbiAgfTtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICBwcm92aWRlOiBJTUFHRV9MT0FERVIsXG4gICAgdXNlVmFsdWU6IGxvYWRlckZuXG4gIH1dO1xuICByZXR1cm4gcHJvdmlkZXJzO1xufVxuY29uc3QgdmFsaWRQYXJhbXMgPSBuZXcgTWFwKFtbJ2hlaWdodCcsICdoJ10sIFsnZml0JywgJ2ZpdCddLCBbJ3F1YWxpdHknLCAncSddLCBbJ3EnLCAncSddLCBbJ3Bvc2l0aW9uJywgJ3Bvc2l0aW9uJ11dKTtcbmZ1bmN0aW9uIGNyZWF0ZU5ldGxpZnlVcmwoY29uZmlnLCBwYXRoKSB7XG4gIGNvbnN0IHVybCA9IG5ldyBVUkwocGF0aCA/PyAnaHR0cHM6Ly9hLycpO1xuICB1cmwucGF0aG5hbWUgPSAnLy5uZXRsaWZ5L2ltYWdlcyc7XG4gIGlmICghaXNBYnNvbHV0ZVVybChjb25maWcuc3JjKSAmJiAhY29uZmlnLnNyYy5zdGFydHNXaXRoKCcvJykpIHtcbiAgICBjb25maWcuc3JjID0gJy8nICsgY29uZmlnLnNyYztcbiAgfVxuICB1cmwuc2VhcmNoUGFyYW1zLnNldCgndXJsJywgY29uZmlnLnNyYyk7XG4gIGlmIChjb25maWcud2lkdGgpIHtcbiAgICB1cmwuc2VhcmNoUGFyYW1zLnNldCgndycsIGNvbmZpZy53aWR0aC50b1N0cmluZygpKTtcbiAgfVxuICBpZiAoY29uZmlnLmhlaWdodCkge1xuICAgIHVybC5zZWFyY2hQYXJhbXMuc2V0KCdoJywgY29uZmlnLmhlaWdodC50b1N0cmluZygpKTtcbiAgfVxuICBjb25zdCBjb25maWdRdWFsaXR5ID0gY29uZmlnLmxvYWRlclBhcmFtcz8uWydxdWFsaXR5J10gPz8gY29uZmlnLmxvYWRlclBhcmFtcz8uWydxJ107XG4gIGlmIChjb25maWcuaXNQbGFjZWhvbGRlciAmJiAhY29uZmlnUXVhbGl0eSkge1xuICAgIHVybC5zZWFyY2hQYXJhbXMuc2V0KCdxJywgUExBQ0VIT0xERVJfUVVBTElUWSk7XG4gIH1cbiAgZm9yIChjb25zdCBbcGFyYW0sIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhjb25maWcubG9hZGVyUGFyYW1zID8/IHt9KSkge1xuICAgIGlmICh2YWxpZFBhcmFtcy5oYXMocGFyYW0pKSB7XG4gICAgICB1cmwuc2VhcmNoUGFyYW1zLnNldCh2YWxpZFBhcmFtcy5nZXQocGFyYW0pLCB2YWx1ZS50b1N0cmluZygpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKG5nRGV2TW9kZSkge1xuICAgICAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyOTU5LCBgVGhlIE5ldGxpZnkgaW1hZ2UgbG9hZGVyIGhhcyBkZXRlY3RlZCBhbiBcXGA8aW1nPlxcYCB0YWcgd2l0aCB0aGUgdW5zdXBwb3J0ZWQgYXR0cmlidXRlIFwiXFxgJHtwYXJhbX1cXGBcIi5gKSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiB1cmwuaG9zdG5hbWUgPT09ICdhJyA/IHVybC5ocmVmLnJlcGxhY2UodXJsLm9yaWdpbiwgJycpIDogdXJsLmhyZWY7XG59XG5mdW5jdGlvbiBpbWdEaXJlY3RpdmVEZXRhaWxzKG5nU3JjLCBpbmNsdWRlTmdTcmMgPSB0cnVlKSB7XG4gIGNvbnN0IG5nU3JjSW5mbyA9IGluY2x1ZGVOZ1NyYyA/IGAoYWN0aXZhdGVkIG9uIGFuIDxpbWc+IGVsZW1lbnQgd2l0aCB0aGUgXFxgbmdTcmM9XCIke25nU3JjfVwiXFxgKSBgIDogJyc7XG4gIHJldHVybiBgVGhlIE5nT3B0aW1pemVkSW1hZ2UgZGlyZWN0aXZlICR7bmdTcmNJbmZvfWhhcyBkZXRlY3RlZCB0aGF0YDtcbn1cbmZ1bmN0aW9uIGFzc2VydERldk1vZGUoY2hlY2tOYW1lKSB7XG4gIGlmICghbmdEZXZNb2RlKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1OCwgYFVuZXhwZWN0ZWQgaW52b2NhdGlvbiBvZiB0aGUgJHtjaGVja05hbWV9IGluIHRoZSBwcm9kIG1vZGUuIGAgKyBgUGxlYXNlIG1ha2Ugc3VyZSB0aGF0IHRoZSBwcm9kIG1vZGUgaXMgZW5hYmxlZCBmb3IgcHJvZHVjdGlvbiBidWlsZHMuYCk7XG4gIH1cbn1cbmNsYXNzIExDUEltYWdlT2JzZXJ2ZXIge1xuICBpbWFnZXMgPSBuZXcgTWFwKCk7XG4gIHdpbmRvdyA9IGluamVjdChET0NVTUVOVCkuZGVmYXVsdFZpZXc7XG4gIG9ic2VydmVyID0gbnVsbDtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgYXNzZXJ0RGV2TW9kZSgnTENQIGNoZWNrZXInKTtcbiAgICBpZiAoKHR5cGVvZiBuZ1NlcnZlck1vZGUgPT09ICd1bmRlZmluZWQnIHx8ICFuZ1NlcnZlck1vZGUpICYmIHR5cGVvZiBQZXJmb3JtYW5jZU9ic2VydmVyICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgdGhpcy5vYnNlcnZlciA9IHRoaXMuaW5pdFBlcmZvcm1hbmNlT2JzZXJ2ZXIoKTtcbiAgICB9XG4gIH1cbiAgaW5pdFBlcmZvcm1hbmNlT2JzZXJ2ZXIoKSB7XG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgUGVyZm9ybWFuY2VPYnNlcnZlcihlbnRyeUxpc3QgPT4ge1xuICAgICAgY29uc3QgZW50cmllcyA9IGVudHJ5TGlzdC5nZXRFbnRyaWVzKCk7XG4gICAgICBpZiAoZW50cmllcy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgICAgIGNvbnN0IGxjcEVsZW1lbnQgPSBlbnRyaWVzW2VudHJpZXMubGVuZ3RoIC0gMV07XG4gICAgICBjb25zdCBpbWdTcmMgPSBsY3BFbGVtZW50LmVsZW1lbnQ/LnNyYyA/PyAnJztcbiAgICAgIGlmIChpbWdTcmMuc3RhcnRzV2l0aCgnZGF0YTonKSB8fCBpbWdTcmMuc3RhcnRzV2l0aCgnYmxvYjonKSkgcmV0dXJuO1xuICAgICAgY29uc3QgaW1nID0gdGhpcy5pbWFnZXMuZ2V0KGltZ1NyYyk7XG4gICAgICBpZiAoIWltZykgcmV0dXJuO1xuICAgICAgaWYgKCFpbWcucHJpb3JpdHkgJiYgIWltZy5hbHJlYWR5V2FybmVkUHJpb3JpdHkpIHtcbiAgICAgICAgaW1nLmFscmVhZHlXYXJuZWRQcmlvcml0eSA9IHRydWU7XG4gICAgICAgIGxvZ01pc3NpbmdQcmlvcml0eUVycm9yKGltZ1NyYyk7XG4gICAgICB9XG4gICAgICBpZiAoaW1nLm1vZGlmaWVkICYmICFpbWcuYWxyZWFkeVdhcm5lZE1vZGlmaWVkKSB7XG4gICAgICAgIGltZy5hbHJlYWR5V2FybmVkTW9kaWZpZWQgPSB0cnVlO1xuICAgICAgICBsb2dNb2RpZmllZFdhcm5pbmcoaW1nU3JjKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKHtcbiAgICAgIHR5cGU6ICdsYXJnZXN0LWNvbnRlbnRmdWwtcGFpbnQnLFxuICAgICAgYnVmZmVyZWQ6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gb2JzZXJ2ZXI7XG4gIH1cbiAgcmVnaXN0ZXJJbWFnZShyZXdyaXR0ZW5TcmMsIGlzUHJpb3JpdHkpIHtcbiAgICBpZiAoIXRoaXMub2JzZXJ2ZXIpIHJldHVybjtcbiAgICBjb25zdCB1cmwgPSBnZXRVcmwocmV3cml0dGVuU3JjLCB0aGlzLndpbmRvdykuaHJlZjtcbiAgICBjb25zdCBleGlzdGluZ1N0YXRlID0gdGhpcy5pbWFnZXMuZ2V0KHVybCk7XG4gICAgaWYgKGV4aXN0aW5nU3RhdGUpIHtcbiAgICAgIGV4aXN0aW5nU3RhdGUucHJpb3JpdHkgPSBleGlzdGluZ1N0YXRlLnByaW9yaXR5IHx8IGlzUHJpb3JpdHk7XG4gICAgICBleGlzdGluZ1N0YXRlLmNvdW50Kys7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG5ld09ic2VydmVkSW1hZ2VTdGF0ZSA9IHtcbiAgICAgICAgcHJpb3JpdHk6IGlzUHJpb3JpdHksXG4gICAgICAgIG1vZGlmaWVkOiBmYWxzZSxcbiAgICAgICAgYWxyZWFkeVdhcm5lZE1vZGlmaWVkOiBmYWxzZSxcbiAgICAgICAgYWxyZWFkeVdhcm5lZFByaW9yaXR5OiBmYWxzZSxcbiAgICAgICAgY291bnQ6IDFcbiAgICAgIH07XG4gICAgICB0aGlzLmltYWdlcy5zZXQodXJsLCBuZXdPYnNlcnZlZEltYWdlU3RhdGUpO1xuICAgIH1cbiAgfVxuICB1bnJlZ2lzdGVySW1hZ2UocmV3cml0dGVuU3JjKSB7XG4gICAgaWYgKCF0aGlzLm9ic2VydmVyKSByZXR1cm47XG4gICAgY29uc3QgdXJsID0gZ2V0VXJsKHJld3JpdHRlblNyYywgdGhpcy53aW5kb3cpLmhyZWY7XG4gICAgY29uc3QgZXhpc3RpbmdTdGF0ZSA9IHRoaXMuaW1hZ2VzLmdldCh1cmwpO1xuICAgIGlmIChleGlzdGluZ1N0YXRlKSB7XG4gICAgICBleGlzdGluZ1N0YXRlLmNvdW50LS07XG4gICAgICBpZiAoZXhpc3RpbmdTdGF0ZS5jb3VudCA8PSAwKSB7XG4gICAgICAgIHRoaXMuaW1hZ2VzLmRlbGV0ZSh1cmwpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICB1cGRhdGVJbWFnZShvcmlnaW5hbFNyYywgbmV3U3JjKSB7XG4gICAgaWYgKCF0aGlzLm9ic2VydmVyKSByZXR1cm47XG4gICAgY29uc3Qgb3JpZ2luYWxVcmwgPSBnZXRVcmwob3JpZ2luYWxTcmMsIHRoaXMud2luZG93KS5ocmVmO1xuICAgIGNvbnN0IG5ld1VybCA9IGdldFVybChuZXdTcmMsIHRoaXMud2luZG93KS5ocmVmO1xuICAgIGlmIChvcmlnaW5hbFVybCA9PT0gbmV3VXJsKSByZXR1cm47XG4gICAgY29uc3Qgb3JpZ2luYWxTdGF0ZSA9IHRoaXMuaW1hZ2VzLmdldChvcmlnaW5hbFVybCk7XG4gICAgaWYgKCFvcmlnaW5hbFN0YXRlKSByZXR1cm47XG4gICAgb3JpZ2luYWxTdGF0ZS5jb3VudC0tO1xuICAgIGlmIChvcmlnaW5hbFN0YXRlLmNvdW50IDw9IDApIHtcbiAgICAgIHRoaXMuaW1hZ2VzLmRlbGV0ZShvcmlnaW5hbFVybCk7XG4gICAgfVxuICAgIGNvbnN0IG5ld1N0YXRlID0gdGhpcy5pbWFnZXMuZ2V0KG5ld1VybCk7XG4gICAgaWYgKG5ld1N0YXRlKSB7XG4gICAgICBuZXdTdGF0ZS5wcmlvcml0eSA9IG5ld1N0YXRlLnByaW9yaXR5IHx8IG9yaWdpbmFsU3RhdGUucHJpb3JpdHk7XG4gICAgICBuZXdTdGF0ZS5tb2RpZmllZCA9IHRydWU7XG4gICAgICBuZXdTdGF0ZS5hbHJlYWR5V2FybmVkUHJpb3JpdHkgPSBuZXdTdGF0ZS5hbHJlYWR5V2FybmVkUHJpb3JpdHkgfHwgb3JpZ2luYWxTdGF0ZS5hbHJlYWR5V2FybmVkUHJpb3JpdHk7XG4gICAgICBuZXdTdGF0ZS5hbHJlYWR5V2FybmVkTW9kaWZpZWQgPSBuZXdTdGF0ZS5hbHJlYWR5V2FybmVkTW9kaWZpZWQgfHwgb3JpZ2luYWxTdGF0ZS5hbHJlYWR5V2FybmVkTW9kaWZpZWQ7XG4gICAgICBuZXdTdGF0ZS5jb3VudCsrO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmltYWdlcy5zZXQobmV3VXJsLCB7XG4gICAgICAgIHByaW9yaXR5OiBvcmlnaW5hbFN0YXRlLnByaW9yaXR5LFxuICAgICAgICBtb2RpZmllZDogdHJ1ZSxcbiAgICAgICAgYWxyZWFkeVdhcm5lZE1vZGlmaWVkOiBvcmlnaW5hbFN0YXRlLmFscmVhZHlXYXJuZWRNb2RpZmllZCxcbiAgICAgICAgYWxyZWFkeVdhcm5lZFByaW9yaXR5OiBvcmlnaW5hbFN0YXRlLmFscmVhZHlXYXJuZWRQcmlvcml0eSxcbiAgICAgICAgY291bnQ6IDFcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICBpZiAoIXRoaXMub2JzZXJ2ZXIpIHJldHVybjtcbiAgICB0aGlzLm9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICB0aGlzLmltYWdlcy5jbGVhcigpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIExDUEltYWdlT2JzZXJ2ZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IExDUEltYWdlT2JzZXJ2ZXIpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lU2VydmljZSh7XG4gICAgdG9rZW46IExDUEltYWdlT2JzZXJ2ZXIsXG4gICAgZmFjdG9yeTogTENQSW1hZ2VPYnNlcnZlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKExDUEltYWdlT2JzZXJ2ZXIsIFt7XG4gICAgdHlwZTogU2VydmljZVxuICB9XSwgKCkgPT4gW10sIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGxvZ01pc3NpbmdQcmlvcml0eUVycm9yKG5nU3JjKSB7XG4gIGNvbnN0IGRpcmVjdGl2ZURldGFpbHMgPSBpbWdEaXJlY3RpdmVEZXRhaWxzKG5nU3JjKTtcbiAgY29uc29sZS5lcnJvcihfZm9ybWF0UnVudGltZUVycm9yKDI5NTUsIGAke2RpcmVjdGl2ZURldGFpbHN9IHRoaXMgaW1hZ2UgaXMgdGhlIExhcmdlc3QgQ29udGVudGZ1bCBQYWludCAoTENQKSBgICsgYGVsZW1lbnQgYnV0IHdhcyBub3QgbWFya2VkIFwicHJpb3JpdHlcIi4gVGhpcyBpbWFnZSBzaG91bGQgYmUgbWFya2VkIGAgKyBgXCJwcmlvcml0eVwiIGluIG9yZGVyIHRvIHByaW9yaXRpemUgaXRzIGxvYWRpbmcuIGAgKyBgVG8gZml4IHRoaXMsIGFkZCB0aGUgXCJwcmlvcml0eVwiIGF0dHJpYnV0ZS5gKSk7XG59XG5mdW5jdGlvbiBsb2dNb2RpZmllZFdhcm5pbmcobmdTcmMpIHtcbiAgY29uc3QgZGlyZWN0aXZlRGV0YWlscyA9IGltZ0RpcmVjdGl2ZURldGFpbHMobmdTcmMpO1xuICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyOTY0LCBgJHtkaXJlY3RpdmVEZXRhaWxzfSB0aGlzIGltYWdlIGlzIHRoZSBMYXJnZXN0IENvbnRlbnRmdWwgUGFpbnQgKExDUCkgYCArIGBlbGVtZW50IGFuZCBoYXMgaGFkIGl0cyBcIm5nU3JjXCIgYXR0cmlidXRlIG1vZGlmaWVkLiBUaGlzIGNhbiBjYXVzZSBgICsgYHNsb3dlciBsb2FkaW5nIHBlcmZvcm1hbmNlLiBJdCBpcyByZWNvbW1lbmRlZCBub3QgdG8gbW9kaWZ5IHRoZSBcIm5nU3JjXCIgYCArIGBwcm9wZXJ0eSBvbiBhbnkgaW1hZ2Ugd2hpY2ggY291bGQgYmUgdGhlIExDUCBlbGVtZW50LmApKTtcbn1cbmNvbnN0IElOVEVSTkFMX1BSRUNPTk5FQ1RfQ0hFQ0tfQkxPQ0tMSVNUID0gbmV3IFNldChbJ2xvY2FsaG9zdCcsICcxMjcuMC4wLjEnLCAnMC4wLjAuMCcsICdbOjoxXSddKTtcbmNvbnN0IFBSRUNPTk5FQ1RfQ0hFQ0tfQkxPQ0tMSVNUID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdQUkVDT05ORUNUX0NIRUNLX0JMT0NLTElTVCcgOiAnJyk7XG5jbGFzcyBQcmVjb25uZWN0TGlua0NoZWNrZXIge1xuICBkb2N1bWVudCA9IGluamVjdChET0NVTUVOVCk7XG4gIHByZWNvbm5lY3RMaW5rcyA9IG51bGw7XG4gIGFscmVhZHlTZWVuID0gbmV3IFNldCgpO1xuICB3aW5kb3cgPSB0aGlzLmRvY3VtZW50LmRlZmF1bHRWaWV3O1xuICBibG9ja2xpc3QgPSBuZXcgU2V0KElOVEVSTkFMX1BSRUNPTk5FQ1RfQ0hFQ0tfQkxPQ0tMSVNUKTtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgYXNzZXJ0RGV2TW9kZSgncHJlY29ubmVjdCBsaW5rIGNoZWNrZXInKTtcbiAgICBjb25zdCBibG9ja2xpc3QgPSBpbmplY3QoUFJFQ09OTkVDVF9DSEVDS19CTE9DS0xJU1QsIHtcbiAgICAgIG9wdGlvbmFsOiB0cnVlXG4gICAgfSk7XG4gICAgaWYgKGJsb2NrbGlzdCkge1xuICAgICAgdGhpcy5wb3B1bGF0ZUJsb2NrbGlzdChibG9ja2xpc3QpO1xuICAgIH1cbiAgfVxuICBwb3B1bGF0ZUJsb2NrbGlzdChvcmlnaW5zKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkob3JpZ2lucykpIHtcbiAgICAgIGRlZXBGb3JFYWNoKG9yaWdpbnMsIG9yaWdpbiA9PiB7XG4gICAgICAgIHRoaXMuYmxvY2tsaXN0LmFkZChleHRyYWN0SG9zdG5hbWUob3JpZ2luKSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5ibG9ja2xpc3QuYWRkKGV4dHJhY3RIb3N0bmFtZShvcmlnaW5zKSk7XG4gICAgfVxuICB9XG4gIGFzc2VydFByZWNvbm5lY3QocmV3cml0dGVuU3JjLCBvcmlnaW5hbE5nU3JjKSB7XG4gICAgaWYgKHR5cGVvZiBuZ1NlcnZlck1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nU2VydmVyTW9kZSkgcmV0dXJuO1xuICAgIGNvbnN0IGltZ1VybCA9IGdldFVybChyZXdyaXR0ZW5TcmMsIHRoaXMud2luZG93KTtcbiAgICBpZiAodGhpcy5ibG9ja2xpc3QuaGFzKGltZ1VybC5ob3N0bmFtZSkgfHwgdGhpcy5hbHJlYWR5U2Vlbi5oYXMoaW1nVXJsLm9yaWdpbikpIHJldHVybjtcbiAgICB0aGlzLmFscmVhZHlTZWVuLmFkZChpbWdVcmwub3JpZ2luKTtcbiAgICB0aGlzLnByZWNvbm5lY3RMaW5rcyA/Pz0gdGhpcy5xdWVyeVByZWNvbm5lY3RMaW5rcygpO1xuICAgIGlmICghdGhpcy5wcmVjb25uZWN0TGlua3MuaGFzKGltZ1VybC5vcmlnaW4pKSB7XG4gICAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyOTU2LCBgJHtpbWdEaXJlY3RpdmVEZXRhaWxzKG9yaWdpbmFsTmdTcmMpfSB0aGVyZSBpcyBubyBwcmVjb25uZWN0IHRhZyBwcmVzZW50IGZvciB0aGlzIGAgKyBgaW1hZ2UuIFByZWNvbm5lY3RpbmcgdG8gdGhlIG9yaWdpbihzKSB0aGF0IHNlcnZlIHByaW9yaXR5IGltYWdlcyBlbnN1cmVzIHRoYXQgdGhlc2UgYCArIGBpbWFnZXMgYXJlIGRlbGl2ZXJlZCBhcyBzb29uIGFzIHBvc3NpYmxlLiBUbyBmaXggdGhpcywgcGxlYXNlIGFkZCB0aGUgZm9sbG93aW5nIGAgKyBgZWxlbWVudCBpbnRvIHRoZSA8aGVhZD4gb2YgdGhlIGRvY3VtZW50OlxcbmAgKyBgICA8bGluayByZWw9XCJwcmVjb25uZWN0XCIgaHJlZj1cIiR7aW1nVXJsLm9yaWdpbn1cIj5gKSk7XG4gICAgfVxuICB9XG4gIHF1ZXJ5UHJlY29ubmVjdExpbmtzKCkge1xuICAgIGNvbnN0IHByZWNvbm5lY3RVcmxzID0gbmV3IFNldCgpO1xuICAgIGNvbnN0IGxpbmtzID0gdGhpcy5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdsaW5rW3JlbD1wcmVjb25uZWN0XScpO1xuICAgIGZvciAoY29uc3QgbGluayBvZiBsaW5rcykge1xuICAgICAgY29uc3QgdXJsID0gZ2V0VXJsKGxpbmsuaHJlZiwgdGhpcy53aW5kb3cpO1xuICAgICAgcHJlY29ubmVjdFVybHMuYWRkKHVybC5vcmlnaW4pO1xuICAgIH1cbiAgICByZXR1cm4gcHJlY29ubmVjdFVybHM7XG4gIH1cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5wcmVjb25uZWN0TGlua3M/LmNsZWFyKCk7XG4gICAgdGhpcy5hbHJlYWR5U2Vlbi5jbGVhcigpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFByZWNvbm5lY3RMaW5rQ2hlY2tlcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgUHJlY29ubmVjdExpbmtDaGVja2VyKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBQcmVjb25uZWN0TGlua0NoZWNrZXIsXG4gICAgZmFjdG9yeTogUHJlY29ubmVjdExpbmtDaGVja2VyLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUHJlY29ubmVjdExpbmtDaGVja2VyLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sICgpID0+IFtdLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBkZWVwRm9yRWFjaChpbnB1dCwgZm4pIHtcbiAgZm9yIChsZXQgdmFsdWUgb2YgaW5wdXQpIHtcbiAgICBBcnJheS5pc0FycmF5KHZhbHVlKSA/IGRlZXBGb3JFYWNoKHZhbHVlLCBmbikgOiBmbih2YWx1ZSk7XG4gIH1cbn1cbmNvbnN0IERFRkFVTFRfUFJFTE9BREVEX0lNQUdFU19MSU1JVCA9IDU7XG5jb25zdCBQUkVMT0FERURfSU1BR0VTID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/ICdOR19PUFRJTUlaRURfUFJFTE9BREVEX0lNQUdFUycgOiAnJywge1xuICBmYWN0b3J5OiAoKSA9PiBuZXcgU2V0KClcbn0pO1xuY2xhc3MgUHJlbG9hZExpbmtDcmVhdG9yIHtcbiAgcHJlbG9hZGVkSW1hZ2VzID0gaW5qZWN0KFBSRUxPQURFRF9JTUFHRVMpO1xuICBkb2N1bWVudCA9IGluamVjdChET0NVTUVOVCk7XG4gIGVycm9yU2hvd24gPSBmYWxzZTtcbiAgY3JlYXRlUHJlbG9hZExpbmtUYWcocmVuZGVyZXIsIHNyYywgc3Jjc2V0LCBzaXplcywgY3Jvc3NPcmlnaW4pIHtcbiAgICBjb25zdCBwcmVsb2FkS2V5ID0gYCR7c3JjfToke2dldENyb3NzT3JpZ2luTW9kZShjcm9zc09yaWdpbil9YDtcbiAgICBpZiAobmdEZXZNb2RlICYmICF0aGlzLmVycm9yU2hvd24gJiYgdGhpcy5wcmVsb2FkZWRJbWFnZXMuc2l6ZSA+PSBERUZBVUxUX1BSRUxPQURFRF9JTUFHRVNfTElNSVQpIHtcbiAgICAgIHRoaXMuZXJyb3JTaG93biA9IHRydWU7XG4gICAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyOTYxLCBgVGhlIFxcYE5nT3B0aW1pemVkSW1hZ2VcXGAgZGlyZWN0aXZlIGhhcyBkZXRlY3RlZCB0aGF0IG1vcmUgdGhhbiBgICsgYCR7REVGQVVMVF9QUkVMT0FERURfSU1BR0VTX0xJTUlUfSBpbWFnZXMgd2VyZSBtYXJrZWQgYXMgcHJpb3JpdHkuIGAgKyBgVGhpcyBtaWdodCBuZWdhdGl2ZWx5IGFmZmVjdCBhbiBvdmVyYWxsIHBlcmZvcm1hbmNlIG9mIHRoZSBwYWdlLiBgICsgYFRvIGZpeCB0aGlzLCByZW1vdmUgdGhlIFwicHJpb3JpdHlcIiBhdHRyaWJ1dGUgZnJvbSBpbWFnZXMgd2l0aCBsZXNzIHByaW9yaXR5LmApKTtcbiAgICB9XG4gICAgaWYgKHRoaXMucHJlbG9hZGVkSW1hZ2VzLmhhcyhwcmVsb2FkS2V5KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnByZWxvYWRlZEltYWdlcy5hZGQocHJlbG9hZEtleSk7XG4gICAgY29uc3QgcHJlbG9hZCA9IHJlbmRlcmVyLmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKTtcbiAgICByZW5kZXJlci5zZXRBdHRyaWJ1dGUocHJlbG9hZCwgJ2FzJywgJ2ltYWdlJyk7XG4gICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKHByZWxvYWQsICdocmVmJywgc3JjKTtcbiAgICByZW5kZXJlci5zZXRBdHRyaWJ1dGUocHJlbG9hZCwgJ3JlbCcsICdwcmVsb2FkJyk7XG4gICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKHByZWxvYWQsICdmZXRjaHByaW9yaXR5JywgJ2hpZ2gnKTtcbiAgICBpZiAoY3Jvc3NPcmlnaW4gIT0gbnVsbCkge1xuICAgICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKHByZWxvYWQsICdjcm9zc29yaWdpbicsIGNyb3NzT3JpZ2luKTtcbiAgICB9XG4gICAgaWYgKHNpemVzKSB7XG4gICAgICByZW5kZXJlci5zZXRBdHRyaWJ1dGUocHJlbG9hZCwgJ2ltYWdlU2l6ZXMnLCBzaXplcyk7XG4gICAgfVxuICAgIGlmIChzcmNzZXQpIHtcbiAgICAgIHJlbmRlcmVyLnNldEF0dHJpYnV0ZShwcmVsb2FkLCAnaW1hZ2VTcmNzZXQnLCBzcmNzZXQpO1xuICAgIH1cbiAgICByZW5kZXJlci5hcHBlbmRDaGlsZCh0aGlzLmRvY3VtZW50LmhlYWQsIHByZWxvYWQpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFByZWxvYWRMaW5rQ3JlYXRvcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgUHJlbG9hZExpbmtDcmVhdG9yKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBQcmVsb2FkTGlua0NyZWF0b3IsXG4gICAgZmFjdG9yeTogUHJlbG9hZExpbmtDcmVhdG9yLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUHJlbG9hZExpbmtDcmVhdG9yLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGdldENyb3NzT3JpZ2luTW9kZShjcm9zc09yaWdpbikge1xuICBpZiAoY3Jvc3NPcmlnaW4gPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiBjcm9zc09yaWdpbi50b0xvd2VyQ2FzZSgpID09PSAndXNlLWNyZWRlbnRpYWxzJyA/ICd1c2UtY3JlZGVudGlhbHMnIDogJ2Fub255bW91cyc7XG59XG5jb25zdCBCQVNFNjRfSU1HX01BWF9MRU5HVEhfSU5fRVJST1IgPSA1MDtcbmNvbnN0IFZBTElEX1dJRFRIX0RFU0NSSVBUT1JfU1JDU0VUID0gL14oKFxccypcXGQrd1xccyooLHwkKSl7MSx9KSQvO1xuY29uc3QgVkFMSURfREVOU0lUWV9ERVNDUklQVE9SX1NSQ1NFVCA9IC9eKChcXHMqXFxkKyhcXC5cXGQrKT94XFxzKigsfCQpKXsxLH0pJC87XG5jb25zdCBBQlNPTFVURV9TUkNTRVRfREVOU0lUWV9DQVAgPSAzO1xuY29uc3QgUkVDT01NRU5ERURfU1JDU0VUX0RFTlNJVFlfQ0FQID0gMjtcbmNvbnN0IERFTlNJVFlfU1JDU0VUX01VTFRJUExJRVJTID0gWzEsIDJdO1xuY29uc3QgVklFV1BPUlRfQlJFQUtQT0lOVF9DVVRPRkYgPSA2NDA7XG5jb25zdCBBU1BFQ1RfUkFUSU9fVE9MRVJBTkNFID0gMC4xO1xuY29uc3QgT1ZFUlNJWkVEX0lNQUdFX1RPTEVSQU5DRSA9IDEwMDA7XG5jb25zdCBGSVhFRF9TUkNTRVRfV0lEVEhfTElNSVQgPSAxOTIwO1xuY29uc3QgRklYRURfU1JDU0VUX0hFSUdIVF9MSU1JVCA9IDEwODA7XG5jb25zdCBQTEFDRUhPTERFUl9ESU1FTlNJT05fTElNSVQgPSAxMDAwO1xuY29uc3QgREFUQV9VUkxfV0FSTl9MSU1JVCA9IDQwMDA7XG5jb25zdCBEQVRBX1VSTF9FUlJPUl9MSU1JVCA9IDEwMDAwO1xuY29uc3QgQlVJTFRfSU5fTE9BREVSUyA9IFtpbWdpeExvYWRlckluZm8sIGltYWdlS2l0TG9hZGVySW5mbywgY2xvdWRpbmFyeUxvYWRlckluZm8sIG5ldGxpZnlMb2FkZXJJbmZvXTtcbmNvbnN0IFBSSU9SSVRZX0NPVU5UX1RIUkVTSE9MRCA9IDEwO1xubGV0IElNR1NfV0lUSF9QUklPUklUWV9BVFRSX0NPVU5UID0gMDtcbmNsYXNzIE5nT3B0aW1pemVkSW1hZ2Uge1xuICBpbWFnZUxvYWRlciA9IGluamVjdChJTUFHRV9MT0FERVIpO1xuICBjb25maWcgPSBwcm9jZXNzQ29uZmlnKGluamVjdChfSU1BR0VfQ09ORklHKSk7XG4gIHJlbmRlcmVyID0gaW5qZWN0KFJlbmRlcmVyMik7XG4gIGltZ0VsZW1lbnQgPSBpbmplY3QoRWxlbWVudFJlZikubmF0aXZlRWxlbWVudDtcbiAgaW5qZWN0b3IgPSBpbmplY3QoSW5qZWN0b3IpO1xuICBkZXN0cm95UmVmID0gaW5qZWN0KERlc3Ryb3lSZWYpO1xuICBsY3BPYnNlcnZlcjtcbiAgX3JlbmRlcmVkU3JjID0gbnVsbDtcbiAgbmdTcmM7XG4gIG5nU3Jjc2V0O1xuICBzaXplcztcbiAgd2lkdGg7XG4gIGhlaWdodDtcbiAgZGVjb2Rpbmc7XG4gIGxvYWRpbmc7XG4gIHByaW9yaXR5ID0gZmFsc2U7XG4gIGxvYWRlclBhcmFtcztcbiAgZGlzYWJsZU9wdGltaXplZFNyY3NldCA9IGZhbHNlO1xuICBmaWxsID0gZmFsc2U7XG4gIHBsYWNlaG9sZGVyO1xuICBwbGFjZWhvbGRlckNvbmZpZztcbiAgc3JjO1xuICBzcmNzZXQ7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIGlmIChuZ0Rldk1vZGUpIHtcbiAgICAgIHRoaXMubGNwT2JzZXJ2ZXIgPSB0aGlzLmluamVjdG9yLmdldChMQ1BJbWFnZU9ic2VydmVyKTtcbiAgICAgIHRoaXMuZGVzdHJveVJlZi5vbkRlc3Ryb3koKCkgPT4ge1xuICAgICAgICBpZiAoIXRoaXMucHJpb3JpdHkgJiYgdGhpcy5fcmVuZGVyZWRTcmMgIT09IG51bGwpIHtcbiAgICAgICAgICB0aGlzLmxjcE9ic2VydmVyLnVucmVnaXN0ZXJJbWFnZSh0aGlzLl9yZW5kZXJlZFNyYyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aGlzLmRlc3Ryb3lSZWYub25EZXN0cm95KCgpID0+IHtcbiAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQXR0cmlidXRlKHRoaXMuaW1nRWxlbWVudCwgJ2xvYWRpbmcnKTtcbiAgICB9KTtcbiAgfVxuICBuZ09uSW5pdCgpIHtcbiAgICBfcGVyZm9ybWFuY2VNYXJrRmVhdHVyZSgnTmdPcHRpbWl6ZWRJbWFnZScpO1xuICAgIGlmIChuZ0Rldk1vZGUpIHtcbiAgICAgIGNvbnN0IG5nWm9uZSA9IHRoaXMuaW5qZWN0b3IuZ2V0KE5nWm9uZSk7XG4gICAgICBhc3NlcnROb25FbXB0eUlucHV0KHRoaXMsICduZ1NyYycsIHRoaXMubmdTcmMpO1xuICAgICAgYXNzZXJ0VmFsaWROZ1NyY3NldCh0aGlzLCB0aGlzLm5nU3Jjc2V0KTtcbiAgICAgIGFzc2VydE5vQ29uZmxpY3RpbmdTcmModGhpcyk7XG4gICAgICBpZiAodGhpcy5uZ1NyY3NldCkge1xuICAgICAgICBhc3NlcnROb0NvbmZsaWN0aW5nU3Jjc2V0KHRoaXMpO1xuICAgICAgfVxuICAgICAgYXNzZXJ0Tm90QmFzZTY0SW1hZ2UodGhpcyk7XG4gICAgICBhc3NlcnROb3RCbG9iVXJsKHRoaXMpO1xuICAgICAgaWYgKHRoaXMuZmlsbCkge1xuICAgICAgICBhc3NlcnRFbXB0eVdpZHRoQW5kSGVpZ2h0KHRoaXMpO1xuICAgICAgICBuZ1pvbmUucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4gYXNzZXJ0Tm9uWmVyb1JlbmRlcmVkSGVpZ2h0KHRoaXMsIHRoaXMuaW1nRWxlbWVudCwgdGhpcy5yZW5kZXJlciwgdGhpcy5kZXN0cm95UmVmKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhc3NlcnROb25FbXB0eVdpZHRoQW5kSGVpZ2h0KHRoaXMpO1xuICAgICAgICBpZiAodGhpcy5oZWlnaHQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGFzc2VydEdyZWF0ZXJUaGFuWmVybyh0aGlzLCB0aGlzLmhlaWdodCwgJ2hlaWdodCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLndpZHRoICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBhc3NlcnRHcmVhdGVyVGhhblplcm8odGhpcywgdGhpcy53aWR0aCwgJ3dpZHRoJyk7XG4gICAgICAgIH1cbiAgICAgICAgbmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IGFzc2VydE5vSW1hZ2VEaXN0b3J0aW9uKHRoaXMsIHRoaXMuaW1nRWxlbWVudCwgdGhpcy5yZW5kZXJlciwgdGhpcy5kZXN0cm95UmVmKSk7XG4gICAgICB9XG4gICAgICBhc3NlcnRWYWxpZExvYWRpbmdJbnB1dCh0aGlzKTtcbiAgICAgIGFzc2VydFZhbGlkRGVjb2RpbmdJbnB1dCh0aGlzKTtcbiAgICAgIGlmICghdGhpcy5uZ1NyY3NldCkge1xuICAgICAgICBhc3NlcnROb0NvbXBsZXhTaXplcyh0aGlzKTtcbiAgICAgIH1cbiAgICAgIGFzc2VydFZhbGlkUGxhY2Vob2xkZXIodGhpcywgdGhpcy5pbWFnZUxvYWRlcik7XG4gICAgICBhc3NlcnROb3RNaXNzaW5nQnVpbHRJbkxvYWRlcih0aGlzLm5nU3JjLCB0aGlzLmltYWdlTG9hZGVyKTtcbiAgICAgIGFzc2VydE5vTmdTcmNzZXRXaXRob3V0TG9hZGVyKHRoaXMsIHRoaXMuaW1hZ2VMb2FkZXIpO1xuICAgICAgYXNzZXJ0Tm9Mb2FkZXJQYXJhbXNXaXRob3V0TG9hZGVyKHRoaXMsIHRoaXMuaW1hZ2VMb2FkZXIpO1xuICAgICAgbmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgICAgdGhpcy5sY3BPYnNlcnZlci5yZWdpc3RlckltYWdlKHRoaXMuZ2V0UmV3cml0dGVuU3JjKCksIHRoaXMucHJpb3JpdHkpO1xuICAgICAgfSk7XG4gICAgICBpZiAodGhpcy5wcmlvcml0eSkge1xuICAgICAgICBjb25zdCBjaGVja2VyID0gdGhpcy5pbmplY3Rvci5nZXQoUHJlY29ubmVjdExpbmtDaGVja2VyKTtcbiAgICAgICAgY2hlY2tlci5hc3NlcnRQcmVjb25uZWN0KHRoaXMuZ2V0UmV3cml0dGVuU3JjKCksIHRoaXMubmdTcmMpO1xuICAgICAgICBpZiAodHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgIW5nU2VydmVyTW9kZSkge1xuICAgICAgICAgIGNvbnN0IGFwcGxpY2F0aW9uUmVmID0gdGhpcy5pbmplY3Rvci5nZXQoQXBwbGljYXRpb25SZWYpO1xuICAgICAgICAgIGFzc2V0UHJpb3JpdHlDb3VudEJlbG93VGhyZXNob2xkKGFwcGxpY2F0aW9uUmVmKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5wbGFjZWhvbGRlcikge1xuICAgICAgdGhpcy5yZW1vdmVQbGFjZWhvbGRlck9uTG9hZCh0aGlzLmltZ0VsZW1lbnQpO1xuICAgIH1cbiAgICB0aGlzLnNldEhvc3RBdHRyaWJ1dGVzKCk7XG4gIH1cbiAgc2V0SG9zdEF0dHJpYnV0ZXMoKSB7XG4gICAgaWYgKHRoaXMuZmlsbCkge1xuICAgICAgdGhpcy5zaXplcyB8fD0gJzEwMHZ3JztcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zZXRIb3N0QXR0cmlidXRlKCd3aWR0aCcsIHRoaXMud2lkdGgudG9TdHJpbmcoKSk7XG4gICAgICB0aGlzLnNldEhvc3RBdHRyaWJ1dGUoJ2hlaWdodCcsIHRoaXMuaGVpZ2h0LnRvU3RyaW5nKCkpO1xuICAgIH1cbiAgICB0aGlzLnNldEhvc3RBdHRyaWJ1dGUoJ2xvYWRpbmcnLCB0aGlzLmdldExvYWRpbmdCZWhhdmlvcigpKTtcbiAgICB0aGlzLnNldEhvc3RBdHRyaWJ1dGUoJ2ZldGNocHJpb3JpdHknLCB0aGlzLmdldEZldGNoUHJpb3JpdHkoKSk7XG4gICAgdGhpcy5zZXRIb3N0QXR0cmlidXRlKCdkZWNvZGluZycsIHRoaXMuZ2V0RGVjb2RpbmcoKSk7XG4gICAgdGhpcy5zZXRIb3N0QXR0cmlidXRlKCduZy1pbWcnLCAndHJ1ZScpO1xuICAgIGNvbnN0IHJld3JpdHRlblNyY3NldCA9IHRoaXMudXBkYXRlU3JjQW5kU3Jjc2V0KCk7XG4gICAgaWYgKHRoaXMuc2l6ZXMpIHtcbiAgICAgIGlmICh0aGlzLmdldExvYWRpbmdCZWhhdmlvcigpID09PSAnbGF6eScpIHtcbiAgICAgICAgdGhpcy5zZXRIb3N0QXR0cmlidXRlKCdzaXplcycsICdhdXRvLCAnICsgdGhpcy5zaXplcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnNldEhvc3RBdHRyaWJ1dGUoJ3NpemVzJywgdGhpcy5zaXplcyk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh0aGlzLm5nU3Jjc2V0ICYmIFZBTElEX1dJRFRIX0RFU0NSSVBUT1JfU1JDU0VULnRlc3QodGhpcy5uZ1NyY3NldCkgJiYgdGhpcy5nZXRMb2FkaW5nQmVoYXZpb3IoKSA9PT0gJ2xhenknKSB7XG4gICAgICAgIHRoaXMuc2V0SG9zdEF0dHJpYnV0ZSgnc2l6ZXMnLCAnYXV0bywgMTAwdncnKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHR5cGVvZiBuZ1NlcnZlck1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nU2VydmVyTW9kZSAmJiB0aGlzLnByaW9yaXR5KSB7XG4gICAgICBjb25zdCBwcmVsb2FkTGlua0NyZWF0b3IgPSB0aGlzLmluamVjdG9yLmdldChQcmVsb2FkTGlua0NyZWF0b3IpO1xuICAgICAgcHJlbG9hZExpbmtDcmVhdG9yLmNyZWF0ZVByZWxvYWRMaW5rVGFnKHRoaXMucmVuZGVyZXIsIHRoaXMuZ2V0UmV3cml0dGVuU3JjKCksIHJld3JpdHRlblNyY3NldCwgdGhpcy5zaXplcywgdGhpcy5pbWdFbGVtZW50LmdldEF0dHJpYnV0ZSgnY3Jvc3NvcmlnaW4nKSk7XG4gICAgfVxuICB9XG4gIG5nT25DaGFuZ2VzKGNoYW5nZXMpIHtcbiAgICBpZiAobmdEZXZNb2RlKSB7XG4gICAgICBhc3NlcnROb1Bvc3RJbml0SW5wdXRDaGFuZ2UodGhpcywgY2hhbmdlcywgWyduZ1NyY3NldCcsICd3aWR0aCcsICdoZWlnaHQnLCAncHJpb3JpdHknLCAnZmlsbCcsICdsb2FkaW5nJywgJ3NpemVzJywgJ2xvYWRlclBhcmFtcycsICdkaXNhYmxlT3B0aW1pemVkU3Jjc2V0J10pO1xuICAgIH1cbiAgICBpZiAoY2hhbmdlc1snbmdTcmMnXSAmJiAhY2hhbmdlc1snbmdTcmMnXS5pc0ZpcnN0Q2hhbmdlKCkpIHtcbiAgICAgIGNvbnN0IG9sZFNyYyA9IHRoaXMuX3JlbmRlcmVkU3JjO1xuICAgICAgdGhpcy51cGRhdGVTcmNBbmRTcmNzZXQodHJ1ZSk7XG4gICAgICBpZiAobmdEZXZNb2RlKSB7XG4gICAgICAgIGNvbnN0IG5ld1NyYyA9IHRoaXMuX3JlbmRlcmVkU3JjO1xuICAgICAgICBpZiAob2xkU3JjICYmIG5ld1NyYyAmJiBvbGRTcmMgIT09IG5ld1NyYykge1xuICAgICAgICAgIGNvbnN0IG5nWm9uZSA9IHRoaXMuaW5qZWN0b3IuZ2V0KE5nWm9uZSk7XG4gICAgICAgICAgbmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMubGNwT2JzZXJ2ZXIudXBkYXRlSW1hZ2Uob2xkU3JjLCBuZXdTcmMpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChuZ0Rldk1vZGUgJiYgY2hhbmdlc1sncGxhY2Vob2xkZXInXT8uY3VycmVudFZhbHVlICYmIHR5cGVvZiBuZ1NlcnZlck1vZGUgIT09ICd1bmRlZmluZWQnICYmICFuZ1NlcnZlck1vZGUpIHtcbiAgICAgIGFzc2VydFBsYWNlaG9sZGVyRGltZW5zaW9ucyh0aGlzLCB0aGlzLmltZ0VsZW1lbnQpO1xuICAgIH1cbiAgfVxuICBnZXRBc3BlY3RSYXRpbygpIHtcbiAgICBpZiAodGhpcy53aWR0aCAmJiB0aGlzLmhlaWdodCAmJiB0aGlzLmhlaWdodCAhPT0gMCkge1xuICAgICAgcmV0dXJuIHRoaXMud2lkdGggLyB0aGlzLmhlaWdodDtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY2FsbEltYWdlTG9hZGVyKGNvbmZpZ1dpdGhvdXRDdXN0b21QYXJhbXMpIHtcbiAgICBsZXQgYXVnbWVudGVkQ29uZmlnID0gY29uZmlnV2l0aG91dEN1c3RvbVBhcmFtcztcbiAgICBpZiAodGhpcy5sb2FkZXJQYXJhbXMpIHtcbiAgICAgIGF1Z21lbnRlZENvbmZpZy5sb2FkZXJQYXJhbXMgPSB0aGlzLmxvYWRlclBhcmFtcztcbiAgICB9XG4gICAgY29uc3QgcmF0aW8gPSB0aGlzLmdldEFzcGVjdFJhdGlvKCk7XG4gICAgaWYgKHJhdGlvICE9PSBudWxsICYmIGF1Z21lbnRlZENvbmZpZy53aWR0aCkge1xuICAgICAgYXVnbWVudGVkQ29uZmlnLmhlaWdodCA9IE1hdGgucm91bmQoYXVnbWVudGVkQ29uZmlnLndpZHRoIC8gcmF0aW8pO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5pbWFnZUxvYWRlcihhdWdtZW50ZWRDb25maWcpO1xuICB9XG4gIGdldExvYWRpbmdCZWhhdmlvcigpIHtcbiAgICBpZiAoIXRoaXMucHJpb3JpdHkgJiYgdGhpcy5sb2FkaW5nICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB0aGlzLmxvYWRpbmc7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnByaW9yaXR5ID8gJ2VhZ2VyJyA6ICdsYXp5JztcbiAgfVxuICBnZXRGZXRjaFByaW9yaXR5KCkge1xuICAgIHJldHVybiB0aGlzLnByaW9yaXR5ID8gJ2hpZ2gnIDogJ2F1dG8nO1xuICB9XG4gIGdldERlY29kaW5nKCkge1xuICAgIGlmICh0aGlzLnByaW9yaXR5KSB7XG4gICAgICByZXR1cm4gJ3N5bmMnO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5kZWNvZGluZyA/PyAnYXV0byc7XG4gIH1cbiAgZ2V0UmV3cml0dGVuU3JjKCkge1xuICAgIGlmICghdGhpcy5fcmVuZGVyZWRTcmMpIHtcbiAgICAgIGNvbnN0IGltZ0NvbmZpZyA9IHtcbiAgICAgICAgc3JjOiB0aGlzLm5nU3JjXG4gICAgICB9O1xuICAgICAgdGhpcy5fcmVuZGVyZWRTcmMgPSB0aGlzLmNhbGxJbWFnZUxvYWRlcihpbWdDb25maWcpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fcmVuZGVyZWRTcmM7XG4gIH1cbiAgZ2V0UmV3cml0dGVuU3Jjc2V0KCkge1xuICAgIGNvbnN0IHdpZHRoU3JjU2V0ID0gVkFMSURfV0lEVEhfREVTQ1JJUFRPUl9TUkNTRVQudGVzdCh0aGlzLm5nU3Jjc2V0KTtcbiAgICBjb25zdCBmaW5hbFNyY3MgPSB0aGlzLm5nU3Jjc2V0LnNwbGl0KCcsJykuZmlsdGVyKHNyYyA9PiBzcmMgIT09ICcnKS5tYXAoc3JjU3RyID0+IHtcbiAgICAgIHNyY1N0ciA9IHNyY1N0ci50cmltKCk7XG4gICAgICBjb25zdCB3aWR0aCA9IHdpZHRoU3JjU2V0ID8gcGFyc2VGbG9hdChzcmNTdHIpIDogcGFyc2VGbG9hdChzcmNTdHIpICogdGhpcy53aWR0aDtcbiAgICAgIHJldHVybiBgJHt0aGlzLmNhbGxJbWFnZUxvYWRlcih7XG4gICAgICAgIHNyYzogdGhpcy5uZ1NyYyxcbiAgICAgICAgd2lkdGhcbiAgICAgIH0pfSAke3NyY1N0cn1gO1xuICAgIH0pO1xuICAgIHJldHVybiBmaW5hbFNyY3Muam9pbignLCAnKTtcbiAgfVxuICBnZXRBdXRvbWF0aWNTcmNzZXQoKSB7XG4gICAgaWYgKHRoaXMuc2l6ZXMpIHtcbiAgICAgIHJldHVybiB0aGlzLmdldFJlc3BvbnNpdmVTcmNzZXQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMuZ2V0Rml4ZWRTcmNzZXQoKTtcbiAgICB9XG4gIH1cbiAgZ2V0UmVzcG9uc2l2ZVNyY3NldCgpIHtcbiAgICBjb25zdCB7XG4gICAgICBicmVha3BvaW50c1xuICAgIH0gPSB0aGlzLmNvbmZpZztcbiAgICBsZXQgZmlsdGVyZWRCcmVha3BvaW50cyA9IGJyZWFrcG9pbnRzO1xuICAgIGlmICh0aGlzLnNpemVzPy50cmltKCkgPT09ICcxMDB2dycpIHtcbiAgICAgIGZpbHRlcmVkQnJlYWtwb2ludHMgPSBicmVha3BvaW50cy5maWx0ZXIoYnAgPT4gYnAgPj0gVklFV1BPUlRfQlJFQUtQT0lOVF9DVVRPRkYpO1xuICAgIH1cbiAgICBjb25zdCBmaW5hbFNyY3MgPSBmaWx0ZXJlZEJyZWFrcG9pbnRzLm1hcChicCA9PiBgJHt0aGlzLmNhbGxJbWFnZUxvYWRlcih7XG4gICAgICBzcmM6IHRoaXMubmdTcmMsXG4gICAgICB3aWR0aDogYnBcbiAgICB9KX0gJHticH13YCk7XG4gICAgcmV0dXJuIGZpbmFsU3Jjcy5qb2luKCcsICcpO1xuICB9XG4gIHVwZGF0ZVNyY0FuZFNyY3NldChmb3JjZVNyY1JlY2FsYyA9IGZhbHNlKSB7XG4gICAgaWYgKGZvcmNlU3JjUmVjYWxjKSB7XG4gICAgICB0aGlzLl9yZW5kZXJlZFNyYyA9IG51bGw7XG4gICAgfVxuICAgIGNvbnN0IHJld3JpdHRlblNyYyA9IHRoaXMuZ2V0UmV3cml0dGVuU3JjKCk7XG4gICAgdGhpcy5zZXRIb3N0QXR0cmlidXRlKCdzcmMnLCByZXdyaXR0ZW5TcmMpO1xuICAgIGxldCByZXdyaXR0ZW5TcmNzZXQgPSB1bmRlZmluZWQ7XG4gICAgaWYgKHRoaXMubmdTcmNzZXQpIHtcbiAgICAgIHJld3JpdHRlblNyY3NldCA9IHRoaXMuZ2V0UmV3cml0dGVuU3Jjc2V0KCk7XG4gICAgfSBlbHNlIGlmICh0aGlzLnNob3VsZEdlbmVyYXRlQXV0b21hdGljU3Jjc2V0KCkpIHtcbiAgICAgIHJld3JpdHRlblNyY3NldCA9IHRoaXMuZ2V0QXV0b21hdGljU3Jjc2V0KCk7XG4gICAgfVxuICAgIGlmIChyZXdyaXR0ZW5TcmNzZXQpIHtcbiAgICAgIHRoaXMuc2V0SG9zdEF0dHJpYnV0ZSgnc3Jjc2V0JywgcmV3cml0dGVuU3Jjc2V0KTtcbiAgICB9XG4gICAgcmV0dXJuIHJld3JpdHRlblNyY3NldDtcbiAgfVxuICBnZXRGaXhlZFNyY3NldCgpIHtcbiAgICBjb25zdCBmaW5hbFNyY3MgPSBERU5TSVRZX1NSQ1NFVF9NVUxUSVBMSUVSUy5tYXAobXVsdGlwbGllciA9PiBgJHt0aGlzLmNhbGxJbWFnZUxvYWRlcih7XG4gICAgICBzcmM6IHRoaXMubmdTcmMsXG4gICAgICB3aWR0aDogdGhpcy53aWR0aCAqIG11bHRpcGxpZXJcbiAgICB9KX0gJHttdWx0aXBsaWVyfXhgKTtcbiAgICByZXR1cm4gZmluYWxTcmNzLmpvaW4oJywgJyk7XG4gIH1cbiAgc2hvdWxkR2VuZXJhdGVBdXRvbWF0aWNTcmNzZXQoKSB7XG4gICAgbGV0IG92ZXJzaXplZEltYWdlID0gZmFsc2U7XG4gICAgaWYgKCF0aGlzLnNpemVzKSB7XG4gICAgICBvdmVyc2l6ZWRJbWFnZSA9IHRoaXMud2lkdGggPiBGSVhFRF9TUkNTRVRfV0lEVEhfTElNSVQgfHwgdGhpcy5oZWlnaHQgPiBGSVhFRF9TUkNTRVRfSEVJR0hUX0xJTUlUO1xuICAgIH1cbiAgICByZXR1cm4gIXRoaXMuZGlzYWJsZU9wdGltaXplZFNyY3NldCAmJiAhdGhpcy5zcmNzZXQgJiYgdGhpcy5pbWFnZUxvYWRlciAhPT0gbm9vcEltYWdlTG9hZGVyICYmICFvdmVyc2l6ZWRJbWFnZTtcbiAgfVxuICBnZW5lcmF0ZVBsYWNlaG9sZGVyKHBsYWNlaG9sZGVySW5wdXQpIHtcbiAgICBjb25zdCB7XG4gICAgICBwbGFjZWhvbGRlclJlc29sdXRpb25cbiAgICB9ID0gdGhpcy5jb25maWc7XG4gICAgaWYgKHBsYWNlaG9sZGVySW5wdXQgPT09IHRydWUpIHtcbiAgICAgIHJldHVybiBgdXJsKFwiJHtlc2NhcGVDc3NVcmwodGhpcy5jYWxsSW1hZ2VMb2FkZXIoe1xuICAgICAgICBzcmM6IHRoaXMubmdTcmMsXG4gICAgICAgIHdpZHRoOiBwbGFjZWhvbGRlclJlc29sdXRpb24sXG4gICAgICAgIGlzUGxhY2Vob2xkZXI6IHRydWVcbiAgICAgIH0pKX1cIilgO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHBsYWNlaG9sZGVySW5wdXQgPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gYHVybChcIiR7ZXNjYXBlQ3NzVXJsKHBsYWNlaG9sZGVySW5wdXQpfVwiKWA7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHNob3VsZEJsdXJQbGFjZWhvbGRlcihwbGFjZWhvbGRlckNvbmZpZykge1xuICAgIGlmICghcGxhY2Vob2xkZXJDb25maWcgfHwgIXBsYWNlaG9sZGVyQ29uZmlnLmhhc093blByb3BlcnR5KCdibHVyJykpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gQm9vbGVhbihwbGFjZWhvbGRlckNvbmZpZy5ibHVyKTtcbiAgfVxuICByZW1vdmVQbGFjZWhvbGRlck9uTG9hZChpbWcpIHtcbiAgICBjb25zdCBjYWxsYmFjayA9ICgpID0+IHtcbiAgICAgIGNvbnN0IGNoYW5nZURldGVjdG9yUmVmID0gdGhpcy5pbmplY3Rvci5nZXQoQ2hhbmdlRGV0ZWN0b3JSZWYpO1xuICAgICAgcmVtb3ZlTG9hZExpc3RlbmVyRm4oKTtcbiAgICAgIHJlbW92ZUVycm9yTGlzdGVuZXJGbigpO1xuICAgICAgdGhpcy5wbGFjZWhvbGRlciA9IGZhbHNlO1xuICAgICAgY2hhbmdlRGV0ZWN0b3JSZWYubWFya0ZvckNoZWNrKCk7XG4gICAgfTtcbiAgICBjb25zdCByZW1vdmVMb2FkTGlzdGVuZXJGbiA9IHRoaXMucmVuZGVyZXIubGlzdGVuKGltZywgJ2xvYWQnLCBjYWxsYmFjayk7XG4gICAgY29uc3QgcmVtb3ZlRXJyb3JMaXN0ZW5lckZuID0gdGhpcy5yZW5kZXJlci5saXN0ZW4oaW1nLCAnZXJyb3InLCBjYWxsYmFjayk7XG4gICAgdGhpcy5kZXN0cm95UmVmLm9uRGVzdHJveSgoKSA9PiB7XG4gICAgICByZW1vdmVMb2FkTGlzdGVuZXJGbigpO1xuICAgICAgcmVtb3ZlRXJyb3JMaXN0ZW5lckZuKCk7XG4gICAgfSk7XG4gICAgY2FsbE9uTG9hZElmSW1hZ2VJc0xvYWRlZChpbWcsIGNhbGxiYWNrKTtcbiAgfVxuICBzZXRIb3N0QXR0cmlidXRlKG5hbWUsIHZhbHVlKSB7XG4gICAgdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUodGhpcy5pbWdFbGVtZW50LCBuYW1lLCB2YWx1ZSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmdPcHRpbWl6ZWRJbWFnZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmdPcHRpbWl6ZWRJbWFnZSkoKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogTmdPcHRpbWl6ZWRJbWFnZSxcbiAgICBzZWxlY3RvcnM6IFtbXCJpbWdcIiwgXCJuZ1NyY1wiLCBcIlwiXV0sXG4gICAgaG9zdFZhcnM6IDE4LFxuICAgIGhvc3RCaW5kaW5nczogZnVuY3Rpb24gTmdPcHRpbWl6ZWRJbWFnZV9Ib3N0QmluZGluZ3MocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1c3R5bGVQcm9wKFwicG9zaXRpb25cIiwgY3R4LmZpbGwgPyBcImFic29sdXRlXCIgOiBudWxsKShcIndpZHRoXCIsIGN0eC5maWxsID8gXCIxMDAlXCIgOiBudWxsKShcImhlaWdodFwiLCBjdHguZmlsbCA/IFwiMTAwJVwiIDogbnVsbCkoXCJpbnNldFwiLCBjdHguZmlsbCA/IFwiMFwiIDogbnVsbCkoXCJiYWNrZ3JvdW5kLXNpemVcIiwgY3R4LnBsYWNlaG9sZGVyID8gXCJjb3ZlclwiIDogbnVsbCkoXCJiYWNrZ3JvdW5kLXBvc2l0aW9uXCIsIGN0eC5wbGFjZWhvbGRlciA/IFwiNTAlIDUwJVwiIDogbnVsbCkoXCJiYWNrZ3JvdW5kLXJlcGVhdFwiLCBjdHgucGxhY2Vob2xkZXIgPyBcIm5vLXJlcGVhdFwiIDogbnVsbCkoXCJiYWNrZ3JvdW5kLWltYWdlXCIsIGN0eC5wbGFjZWhvbGRlciA/IGN0eC5nZW5lcmF0ZVBsYWNlaG9sZGVyKGN0eC5wbGFjZWhvbGRlcikgOiBudWxsKShcImZpbHRlclwiLCBjdHgucGxhY2Vob2xkZXIgJiYgY3R4LnNob3VsZEJsdXJQbGFjZWhvbGRlcihjdHgucGxhY2Vob2xkZXJDb25maWcpID8gXCJibHVyKDE1cHgpXCIgOiBudWxsKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgbmdTcmM6IFsyLCBcIm5nU3JjXCIsIFwibmdTcmNcIiwgdW53cmFwU2FmZVVybF0sXG4gICAgICBuZ1NyY3NldDogXCJuZ1NyY3NldFwiLFxuICAgICAgc2l6ZXM6IFwic2l6ZXNcIixcbiAgICAgIHdpZHRoOiBbMiwgXCJ3aWR0aFwiLCBcIndpZHRoXCIsIG51bWJlckF0dHJpYnV0ZV0sXG4gICAgICBoZWlnaHQ6IFsyLCBcImhlaWdodFwiLCBcImhlaWdodFwiLCBudW1iZXJBdHRyaWJ1dGVdLFxuICAgICAgZGVjb2Rpbmc6IFwiZGVjb2RpbmdcIixcbiAgICAgIGxvYWRpbmc6IFwibG9hZGluZ1wiLFxuICAgICAgcHJpb3JpdHk6IFsyLCBcInByaW9yaXR5XCIsIFwicHJpb3JpdHlcIiwgYm9vbGVhbkF0dHJpYnV0ZV0sXG4gICAgICBsb2FkZXJQYXJhbXM6IFwibG9hZGVyUGFyYW1zXCIsXG4gICAgICBkaXNhYmxlT3B0aW1pemVkU3Jjc2V0OiBbMiwgXCJkaXNhYmxlT3B0aW1pemVkU3Jjc2V0XCIsIFwiZGlzYWJsZU9wdGltaXplZFNyY3NldFwiLCBib29sZWFuQXR0cmlidXRlXSxcbiAgICAgIGZpbGw6IFsyLCBcImZpbGxcIiwgXCJmaWxsXCIsIGJvb2xlYW5BdHRyaWJ1dGVdLFxuICAgICAgcGxhY2Vob2xkZXI6IFsyLCBcInBsYWNlaG9sZGVyXCIsIFwicGxhY2Vob2xkZXJcIiwgYm9vbGVhbk9yVXJsQXR0cmlidXRlXSxcbiAgICAgIHBsYWNlaG9sZGVyQ29uZmlnOiBcInBsYWNlaG9sZGVyQ29uZmlnXCIsXG4gICAgICBzcmM6IFwic3JjXCIsXG4gICAgICBzcmNzZXQ6IFwic3Jjc2V0XCJcbiAgICB9LFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtU5nT25DaGFuZ2VzRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShOZ09wdGltaXplZEltYWdlLCBbe1xuICAgIHR5cGU6IERpcmVjdGl2ZSxcbiAgICBhcmdzOiBbe1xuICAgICAgc2VsZWN0b3I6ICdpbWdbbmdTcmNdJyxcbiAgICAgIGhvc3Q6IHtcbiAgICAgICAgJ1tzdHlsZS5wb3NpdGlvbl0nOiAnZmlsbCA/IFwiYWJzb2x1dGVcIiA6IG51bGwnLFxuICAgICAgICAnW3N0eWxlLndpZHRoXSc6ICdmaWxsID8gXCIxMDAlXCIgOiBudWxsJyxcbiAgICAgICAgJ1tzdHlsZS5oZWlnaHRdJzogJ2ZpbGwgPyBcIjEwMCVcIiA6IG51bGwnLFxuICAgICAgICAnW3N0eWxlLmluc2V0XSc6ICdmaWxsID8gXCIwXCIgOiBudWxsJyxcbiAgICAgICAgJ1tzdHlsZS5iYWNrZ3JvdW5kLXNpemVdJzogJ3BsYWNlaG9sZGVyID8gXCJjb3ZlclwiIDogbnVsbCcsXG4gICAgICAgICdbc3R5bGUuYmFja2dyb3VuZC1wb3NpdGlvbl0nOiAncGxhY2Vob2xkZXIgPyBcIjUwJSA1MCVcIiA6IG51bGwnLFxuICAgICAgICAnW3N0eWxlLmJhY2tncm91bmQtcmVwZWF0XSc6ICdwbGFjZWhvbGRlciA/IFwibm8tcmVwZWF0XCIgOiBudWxsJyxcbiAgICAgICAgJ1tzdHlsZS5iYWNrZ3JvdW5kLWltYWdlXSc6ICdwbGFjZWhvbGRlciA/IGdlbmVyYXRlUGxhY2Vob2xkZXIocGxhY2Vob2xkZXIpIDogbnVsbCcsXG4gICAgICAgICdbc3R5bGUuZmlsdGVyXSc6ICdwbGFjZWhvbGRlciAmJiBzaG91bGRCbHVyUGxhY2Vob2xkZXIocGxhY2Vob2xkZXJDb25maWcpID8gXCJibHVyKDE1cHgpXCIgOiBudWxsJ1xuICAgICAgfVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbXSwge1xuICAgIG5nU3JjOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbe1xuICAgICAgICByZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgdHJhbnNmb3JtOiB1bndyYXBTYWZlVXJsXG4gICAgICB9XVxuICAgIH1dLFxuICAgIG5nU3Jjc2V0OiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBzaXplczogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV0sXG4gICAgd2lkdGg6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFt7XG4gICAgICAgIHRyYW5zZm9ybTogbnVtYmVyQXR0cmlidXRlXG4gICAgICB9XVxuICAgIH1dLFxuICAgIGhlaWdodDogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogW3tcbiAgICAgICAgdHJhbnNmb3JtOiBudW1iZXJBdHRyaWJ1dGVcbiAgICAgIH1dXG4gICAgfV0sXG4gICAgZGVjb2Rpbmc6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIGxvYWRpbmc6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIHByaW9yaXR5OiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbe1xuICAgICAgICB0cmFuc2Zvcm06IGJvb2xlYW5BdHRyaWJ1dGVcbiAgICAgIH1dXG4gICAgfV0sXG4gICAgbG9hZGVyUGFyYW1zOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBkaXNhYmxlT3B0aW1pemVkU3Jjc2V0OiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbe1xuICAgICAgICB0cmFuc2Zvcm06IGJvb2xlYW5BdHRyaWJ1dGVcbiAgICAgIH1dXG4gICAgfV0sXG4gICAgZmlsbDogW3tcbiAgICAgIHR5cGU6IElucHV0LFxuICAgICAgYXJnczogW3tcbiAgICAgICAgdHJhbnNmb3JtOiBib29sZWFuQXR0cmlidXRlXG4gICAgICB9XVxuICAgIH1dLFxuICAgIHBsYWNlaG9sZGVyOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbe1xuICAgICAgICB0cmFuc2Zvcm06IGJvb2xlYW5PclVybEF0dHJpYnV0ZVxuICAgICAgfV1cbiAgICB9XSxcbiAgICBwbGFjZWhvbGRlckNvbmZpZzogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV0sXG4gICAgc3JjOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBzcmNzZXQ6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmZ1bmN0aW9uIHByb2Nlc3NDb25maWcoY29uZmlnKSB7XG4gIGxldCBzb3J0ZWRCcmVha3BvaW50cyA9IHt9O1xuICBpZiAoY29uZmlnLmJyZWFrcG9pbnRzKSB7XG4gICAgc29ydGVkQnJlYWtwb2ludHMuYnJlYWtwb2ludHMgPSBjb25maWcuYnJlYWtwb2ludHMuc29ydCgoYSwgYikgPT4gYSAtIGIpO1xuICB9XG4gIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBfSU1BR0VfQ09ORklHX0RFRkFVTFRTLCBjb25maWcsIHNvcnRlZEJyZWFrcG9pbnRzKTtcbn1cbmZ1bmN0aW9uIGFzc2VydE5vQ29uZmxpY3RpbmdTcmMoZGlyKSB7XG4gIGlmIChkaXIuc3JjKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MCwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSBib3RoIFxcYHNyY1xcYCBhbmQgXFxgbmdTcmNcXGAgaGF2ZSBiZWVuIHNldC4gYCArIGBTdXBwbHlpbmcgYm90aCBvZiB0aGVzZSBhdHRyaWJ1dGVzIGJyZWFrcyBsYXp5IGxvYWRpbmcuIGAgKyBgVGhlIE5nT3B0aW1pemVkSW1hZ2UgZGlyZWN0aXZlIHNldHMgXFxgc3JjXFxgIGl0c2VsZiBiYXNlZCBvbiB0aGUgdmFsdWUgb2YgXFxgbmdTcmNcXGAuIGAgKyBgVG8gZml4IHRoaXMsIHBsZWFzZSByZW1vdmUgdGhlIFxcYHNyY1xcYCBhdHRyaWJ1dGUuYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGFzc2VydE5vQ29uZmxpY3RpbmdTcmNzZXQoZGlyKSB7XG4gIGlmIChkaXIuc3Jjc2V0KSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MSwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSBib3RoIFxcYHNyY3NldFxcYCBhbmQgXFxgbmdTcmNzZXRcXGAgaGF2ZSBiZWVuIHNldC4gYCArIGBTdXBwbHlpbmcgYm90aCBvZiB0aGVzZSBhdHRyaWJ1dGVzIGJyZWFrcyBsYXp5IGxvYWRpbmcuIGAgKyBgVGhlIE5nT3B0aW1pemVkSW1hZ2UgZGlyZWN0aXZlIHNldHMgXFxgc3Jjc2V0XFxgIGl0c2VsZiBiYXNlZCBvbiB0aGUgdmFsdWUgb2YgYCArIGBcXGBuZ1NyY3NldFxcYC4gVG8gZml4IHRoaXMsIHBsZWFzZSByZW1vdmUgdGhlIFxcYHNyY3NldFxcYCBhdHRyaWJ1dGUuYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGFzc2VydE5vdEJhc2U2NEltYWdlKGRpcikge1xuICBsZXQgbmdTcmMgPSBkaXIubmdTcmMudHJpbSgpO1xuICBpZiAobmdTcmMuc3RhcnRzV2l0aCgnZGF0YTonKSkge1xuICAgIGlmIChuZ1NyYy5sZW5ndGggPiBCQVNFNjRfSU1HX01BWF9MRU5HVEhfSU5fRVJST1IpIHtcbiAgICAgIG5nU3JjID0gbmdTcmMuc3Vic3RyaW5nKDAsIEJBU0U2NF9JTUdfTUFYX0xFTkdUSF9JTl9FUlJPUikgKyAnLi4uJztcbiAgICB9XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMsIGZhbHNlKX0gXFxgbmdTcmNcXGAgaXMgYSBCYXNlNjQtZW5jb2RlZCBzdHJpbmcgYCArIGAoJHtuZ1NyY30pLiBOZ09wdGltaXplZEltYWdlIGRvZXMgbm90IHN1cHBvcnQgQmFzZTY0LWVuY29kZWQgc3RyaW5ncy4gYCArIGBUbyBmaXggdGhpcywgZGlzYWJsZSB0aGUgTmdPcHRpbWl6ZWRJbWFnZSBkaXJlY3RpdmUgZm9yIHRoaXMgZWxlbWVudCBgICsgYGJ5IHJlbW92aW5nIFxcYG5nU3JjXFxgIGFuZCB1c2luZyBhIHN0YW5kYXJkIFxcYHNyY1xcYCBhdHRyaWJ1dGUgaW5zdGVhZC5gKTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0Tm9Db21wbGV4U2l6ZXMoZGlyKSB7XG4gIGxldCBzaXplcyA9IGRpci5zaXplcztcbiAgaWYgKHNpemVzPy5tYXRjaCgvKChcXCl8LClcXHN8XilcXGQrcHgvKSkge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NTIsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjLCBmYWxzZSl9IFxcYHNpemVzXFxgIHdhcyBzZXQgdG8gYSBzdHJpbmcgaW5jbHVkaW5nIGAgKyBgcGl4ZWwgdmFsdWVzLiBGb3IgYXV0b21hdGljIFxcYHNyY3NldFxcYCBnZW5lcmF0aW9uLCBcXGBzaXplc1xcYCBtdXN0IG9ubHkgaW5jbHVkZSByZXNwb25zaXZlIGAgKyBgdmFsdWVzLCBzdWNoIGFzIFxcYHNpemVzPVwiNTB2d1wiXFxgIG9yIFxcYHNpemVzPVwiKG1pbi13aWR0aDogNzY4cHgpIDUwdncsIDEwMHZ3XCJcXGAuIGAgKyBgVG8gZml4IHRoaXMsIG1vZGlmeSB0aGUgXFxgc2l6ZXNcXGAgYXR0cmlidXRlLCBvciBwcm92aWRlIHlvdXIgb3duIFxcYG5nU3Jjc2V0XFxgIHZhbHVlIGRpcmVjdGx5LmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRWYWxpZFBsYWNlaG9sZGVyKGRpciwgaW1hZ2VMb2FkZXIpIHtcbiAgYXNzZXJ0Tm9QbGFjZWhvbGRlckNvbmZpZ1dpdGhvdXRQbGFjZWhvbGRlcihkaXIpO1xuICBhc3NlcnROb1JlbGF0aXZlUGxhY2Vob2xkZXJXaXRob3V0TG9hZGVyKGRpciwgaW1hZ2VMb2FkZXIpO1xuICBhc3NlcnROb092ZXJzaXplZERhdGFVcmwoZGlyKTtcbn1cbmZ1bmN0aW9uIGFzc2VydE5vUGxhY2Vob2xkZXJDb25maWdXaXRob3V0UGxhY2Vob2xkZXIoZGlyKSB7XG4gIGlmIChkaXIucGxhY2Vob2xkZXJDb25maWcgJiYgIWRpci5wbGFjZWhvbGRlcikge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NTIsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjLCBmYWxzZSl9IFxcYHBsYWNlaG9sZGVyQ29uZmlnXFxgIG9wdGlvbnMgd2VyZSBwcm92aWRlZCBmb3IgYW4gYCArIGBpbWFnZSB0aGF0IGRvZXMgbm90IHVzZSB0aGUgXFxgcGxhY2Vob2xkZXJcXGAgYXR0cmlidXRlLCBhbmQgd2lsbCBoYXZlIG5vIGVmZmVjdC5gKTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0Tm9SZWxhdGl2ZVBsYWNlaG9sZGVyV2l0aG91dExvYWRlcihkaXIsIGltYWdlTG9hZGVyKSB7XG4gIGlmIChkaXIucGxhY2Vob2xkZXIgPT09IHRydWUgJiYgaW1hZ2VMb2FkZXIgPT09IG5vb3BJbWFnZUxvYWRlcikge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NjMsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gdGhlIFxcYHBsYWNlaG9sZGVyXFxgIGF0dHJpYnV0ZSBpcyBzZXQgdG8gdHJ1ZSBidXQgYCArIGBubyBpbWFnZSBsb2FkZXIgaXMgY29uZmlndXJlZCAoaS5lLiB0aGUgZGVmYXVsdCBvbmUgaXMgYmVpbmcgdXNlZCksIGAgKyBgd2hpY2ggd291bGQgcmVzdWx0IGluIHRoZSBzYW1lIGltYWdlIGJlaW5nIHVzZWQgZm9yIHRoZSBwcmltYXJ5IGltYWdlIGFuZCBpdHMgcGxhY2Vob2xkZXIuIGAgKyBgVG8gZml4IHRoaXMsIHByb3ZpZGUgYSBsb2FkZXIgb3IgcmVtb3ZlIHRoZSBcXGBwbGFjZWhvbGRlclxcYCBhdHRyaWJ1dGUgZnJvbSB0aGUgaW1hZ2UuYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGFzc2VydE5vT3ZlcnNpemVkRGF0YVVybChkaXIpIHtcbiAgaWYgKGRpci5wbGFjZWhvbGRlciAmJiB0eXBlb2YgZGlyLnBsYWNlaG9sZGVyID09PSAnc3RyaW5nJyAmJiBkaXIucGxhY2Vob2xkZXIuc3RhcnRzV2l0aCgnZGF0YTonKSkge1xuICAgIGlmIChkaXIucGxhY2Vob2xkZXIubGVuZ3RoID4gREFUQV9VUkxfRVJST1JfTElNSVQpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NjUsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gdGhlIFxcYHBsYWNlaG9sZGVyXFxgIGF0dHJpYnV0ZSBpcyBzZXQgdG8gYSBkYXRhIFVSTCB3aGljaCBpcyBsb25nZXIgYCArIGB0aGFuICR7REFUQV9VUkxfRVJST1JfTElNSVR9IGNoYXJhY3RlcnMuIFRoaXMgaXMgc3Ryb25nbHkgZGlzY291cmFnZWQsIGFzIGxhcmdlIGlubGluZSBwbGFjZWhvbGRlcnMgYCArIGBkaXJlY3RseSBpbmNyZWFzZSB0aGUgYnVuZGxlIHNpemUgb2YgQW5ndWxhciBhbmQgaHVydCBwYWdlIGxvYWQgcGVyZm9ybWFuY2UuIFRvIGZpeCB0aGlzLCBnZW5lcmF0ZSBgICsgYGEgc21hbGxlciBkYXRhIFVSTCBwbGFjZWhvbGRlci5gKTtcbiAgICB9XG4gICAgaWYgKGRpci5wbGFjZWhvbGRlci5sZW5ndGggPiBEQVRBX1VSTF9XQVJOX0xJTUlUKSB7XG4gICAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyOTY1LCBgJHtpbWdEaXJlY3RpdmVEZXRhaWxzKGRpci5uZ1NyYyl9IHRoZSBcXGBwbGFjZWhvbGRlclxcYCBhdHRyaWJ1dGUgaXMgc2V0IHRvIGEgZGF0YSBVUkwgd2hpY2ggaXMgbG9uZ2VyIGAgKyBgdGhhbiAke0RBVEFfVVJMX1dBUk5fTElNSVR9IGNoYXJhY3RlcnMuIFRoaXMgaXMgZGlzY291cmFnZWQsIGFzIGxhcmdlIGlubGluZSBwbGFjZWhvbGRlcnMgYCArIGBkaXJlY3RseSBpbmNyZWFzZSB0aGUgYnVuZGxlIHNpemUgb2YgQW5ndWxhciBhbmQgaHVydCBwYWdlIGxvYWQgcGVyZm9ybWFuY2UuIEZvciBiZXR0ZXIgbG9hZGluZyBwZXJmb3JtYW5jZSwgYCArIGBnZW5lcmF0ZSBhIHNtYWxsZXIgZGF0YSBVUkwgcGxhY2Vob2xkZXIuYCkpO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0Tm90QmxvYlVybChkaXIpIHtcbiAgY29uc3QgbmdTcmMgPSBkaXIubmdTcmMudHJpbSgpO1xuICBpZiAobmdTcmMuc3RhcnRzV2l0aCgnYmxvYjonKSkge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NTIsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gXFxgbmdTcmNcXGAgd2FzIHNldCB0byBhIGJsb2IgVVJMICgke25nU3JjfSkuIGAgKyBgQmxvYiBVUkxzIGFyZSBub3Qgc3VwcG9ydGVkIGJ5IHRoZSBOZ09wdGltaXplZEltYWdlIGRpcmVjdGl2ZS4gYCArIGBUbyBmaXggdGhpcywgZGlzYWJsZSB0aGUgTmdPcHRpbWl6ZWRJbWFnZSBkaXJlY3RpdmUgZm9yIHRoaXMgZWxlbWVudCBgICsgYGJ5IHJlbW92aW5nIFxcYG5nU3JjXFxgIGFuZCB1c2luZyBhIHJlZ3VsYXIgXFxgc3JjXFxgIGF0dHJpYnV0ZSBpbnN0ZWFkLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnROb25FbXB0eUlucHV0KGRpciwgbmFtZSwgdmFsdWUpIHtcbiAgY29uc3QgaXNTdHJpbmcgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnO1xuICBjb25zdCBpc0VtcHR5U3RyaW5nID0gaXNTdHJpbmcgJiYgdmFsdWUudHJpbSgpID09PSAnJztcbiAgaWYgKCFpc1N0cmluZyB8fCBpc0VtcHR5U3RyaW5nKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSBcXGAke25hbWV9XFxgIGhhcyBhbiBpbnZhbGlkIHZhbHVlIGAgKyBgKFxcYCR7dmFsdWV9XFxgKS4gVG8gZml4IHRoaXMsIGNoYW5nZSB0aGUgdmFsdWUgdG8gYSBub24tZW1wdHkgc3RyaW5nLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRWYWxpZE5nU3Jjc2V0KGRpciwgdmFsdWUpIHtcbiAgaWYgKHZhbHVlID09IG51bGwpIHJldHVybjtcbiAgYXNzZXJ0Tm9uRW1wdHlJbnB1dChkaXIsICduZ1NyY3NldCcsIHZhbHVlKTtcbiAgY29uc3Qgc3RyaW5nVmFsID0gdmFsdWU7XG4gIGNvbnN0IGlzVmFsaWRXaWR0aERlc2NyaXB0b3IgPSBWQUxJRF9XSURUSF9ERVNDUklQVE9SX1NSQ1NFVC50ZXN0KHN0cmluZ1ZhbCk7XG4gIGNvbnN0IGlzVmFsaWREZW5zaXR5RGVzY3JpcHRvciA9IFZBTElEX0RFTlNJVFlfREVTQ1JJUFRPUl9TUkNTRVQudGVzdChzdHJpbmdWYWwpO1xuICBpZiAoaXNWYWxpZERlbnNpdHlEZXNjcmlwdG9yKSB7XG4gICAgYXNzZXJ0VW5kZXJEZW5zaXR5Q2FwKGRpciwgc3RyaW5nVmFsKTtcbiAgfVxuICBjb25zdCBpc1ZhbGlkU3Jjc2V0ID0gaXNWYWxpZFdpZHRoRGVzY3JpcHRvciB8fCBpc1ZhbGlkRGVuc2l0eURlc2NyaXB0b3I7XG4gIGlmICghaXNWYWxpZFNyY3NldCkge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NTIsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gXFxgbmdTcmNzZXRcXGAgaGFzIGFuIGludmFsaWQgdmFsdWUgKFxcYCR7dmFsdWV9XFxgKS4gYCArIGBUbyBmaXggdGhpcywgc3VwcGx5IFxcYG5nU3Jjc2V0XFxgIHVzaW5nIGEgY29tbWEtc2VwYXJhdGVkIGxpc3Qgb2Ygb25lIG9yIG1vcmUgd2lkdGggYCArIGBkZXNjcmlwdG9ycyAoZS5nLiBcIjEwMHcsIDIwMHdcIikgb3IgZGVuc2l0eSBkZXNjcmlwdG9ycyAoZS5nLiBcIjF4LCAyeFwiKS5gKTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0VW5kZXJEZW5zaXR5Q2FwKGRpciwgdmFsdWUpIHtcbiAgY29uc3QgdW5kZXJEZW5zaXR5Q2FwID0gdmFsdWUuc3BsaXQoJywnKS5ldmVyeShudW0gPT4gbnVtID09PSAnJyB8fCBwYXJzZUZsb2F0KG51bSkgPD0gQUJTT0xVVEVfU1JDU0VUX0RFTlNJVFlfQ0FQKTtcbiAgaWYgKCF1bmRlckRlbnNpdHlDYXApIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyOTUyLCBgJHtpbWdEaXJlY3RpdmVEZXRhaWxzKGRpci5uZ1NyYyl9IHRoZSBcXGBuZ1NyY3NldFxcYCBjb250YWlucyBhbiB1bnN1cHBvcnRlZCBpbWFnZSBkZW5zaXR5OmAgKyBgXFxgJHt2YWx1ZX1cXGAuIE5nT3B0aW1pemVkSW1hZ2UgZ2VuZXJhbGx5IHJlY29tbWVuZHMgYSBtYXggaW1hZ2UgZGVuc2l0eSBvZiBgICsgYCR7UkVDT01NRU5ERURfU1JDU0VUX0RFTlNJVFlfQ0FQfXggYnV0IHN1cHBvcnRzIGltYWdlIGRlbnNpdGllcyB1cCB0byBgICsgYCR7QUJTT0xVVEVfU1JDU0VUX0RFTlNJVFlfQ0FQfXguIFRoZSBodW1hbiBleWUgY2Fubm90IGRpc3Rpbmd1aXNoIGJldHdlZW4gaW1hZ2UgZGVuc2l0aWVzIGAgKyBgZ3JlYXRlciB0aGFuICR7UkVDT01NRU5ERURfU1JDU0VUX0RFTlNJVFlfQ0FQfXggLSB3aGljaCBtYWtlcyB0aGVtIHVubmVjZXNzYXJ5IGZvciBgICsgYG1vc3QgdXNlIGNhc2VzLiBJbWFnZXMgdGhhdCB3aWxsIGJlIHBpbmNoLXpvb21lZCBhcmUgdHlwaWNhbGx5IHRoZSBwcmltYXJ5IHVzZSBjYXNlIGZvciBgICsgYCR7QUJTT0xVVEVfU1JDU0VUX0RFTlNJVFlfQ0FQfXggaW1hZ2VzLiBQbGVhc2UgcmVtb3ZlIHRoZSBoaWdoIGRlbnNpdHkgZGVzY3JpcHRvciBhbmQgdHJ5IGFnYWluLmApO1xuICB9XG59XG5mdW5jdGlvbiBwb3N0SW5pdElucHV0Q2hhbmdlRXJyb3IoZGlyLCBpbnB1dE5hbWUpIHtcbiAgbGV0IHJlYXNvbjtcbiAgaWYgKGlucHV0TmFtZSA9PT0gJ3dpZHRoJyB8fCBpbnB1dE5hbWUgPT09ICdoZWlnaHQnKSB7XG4gICAgcmVhc29uID0gYENoYW5naW5nIFxcYCR7aW5wdXROYW1lfVxcYCBtYXkgcmVzdWx0IGluIGRpZmZlcmVudCBhdHRyaWJ1dGUgdmFsdWUgYCArIGBhcHBsaWVkIHRvIHRoZSB1bmRlcmx5aW5nIGltYWdlIGVsZW1lbnQgYW5kIGNhdXNlIGxheW91dCBzaGlmdHMgb24gYSBwYWdlLmA7XG4gIH0gZWxzZSB7XG4gICAgcmVhc29uID0gYENoYW5naW5nIHRoZSBcXGAke2lucHV0TmFtZX1cXGAgd291bGQgaGF2ZSBubyBlZmZlY3Qgb24gdGhlIHVuZGVybHlpbmcgYCArIGBpbWFnZSBlbGVtZW50LCBiZWNhdXNlIHRoZSByZXNvdXJjZSBsb2FkaW5nIGhhcyBhbHJlYWR5IG9jY3VycmVkLmA7XG4gIH1cbiAgcmV0dXJuIG5ldyBfUnVudGltZUVycm9yKDI5NTMsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gXFxgJHtpbnB1dE5hbWV9XFxgIHdhcyB1cGRhdGVkIGFmdGVyIGluaXRpYWxpemF0aW9uLiBgICsgYFRoZSBOZ09wdGltaXplZEltYWdlIGRpcmVjdGl2ZSB3aWxsIG5vdCByZWFjdCB0byB0aGlzIGlucHV0IGNoYW5nZS4gJHtyZWFzb259IGAgKyBgVG8gZml4IHRoaXMsIGVpdGhlciBzd2l0Y2ggXFxgJHtpbnB1dE5hbWV9XFxgIHRvIGEgc3RhdGljIHZhbHVlIGAgKyBgb3Igd3JhcCB0aGUgaW1hZ2UgZWxlbWVudCBpbiBhbiBAaWYgdGhhdCBpcyBnYXRlZCBvbiB0aGUgbmVjZXNzYXJ5IHZhbHVlLmApO1xufVxuZnVuY3Rpb24gYXNzZXJ0Tm9Qb3N0SW5pdElucHV0Q2hhbmdlKGRpciwgY2hhbmdlcywgaW5wdXRzKSB7XG4gIGlucHV0cy5mb3JFYWNoKGlucHV0ID0+IHtcbiAgICBjb25zdCBpc1VwZGF0ZWQgPSBjaGFuZ2VzLmhhc093blByb3BlcnR5KGlucHV0KTtcbiAgICBpZiAoaXNVcGRhdGVkICYmICFjaGFuZ2VzW2lucHV0XS5pc0ZpcnN0Q2hhbmdlKCkpIHtcbiAgICAgIGlmIChpbnB1dCA9PT0gJ25nU3JjJykge1xuICAgICAgICBkaXIgPSB7XG4gICAgICAgICAgbmdTcmM6IGNoYW5nZXNbaW5wdXRdLnByZXZpb3VzVmFsdWVcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHRocm93IHBvc3RJbml0SW5wdXRDaGFuZ2VFcnJvcihkaXIsIGlucHV0KTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gYXNzZXJ0R3JlYXRlclRoYW5aZXJvKGRpciwgaW5wdXRWYWx1ZSwgaW5wdXROYW1lKSB7XG4gIGNvbnN0IHZhbGlkTnVtYmVyID0gdHlwZW9mIGlucHV0VmFsdWUgPT09ICdudW1iZXInICYmIGlucHV0VmFsdWUgPiAwO1xuICBjb25zdCB2YWxpZFN0cmluZyA9IHR5cGVvZiBpbnB1dFZhbHVlID09PSAnc3RyaW5nJyAmJiAvXlxcZCskLy50ZXN0KGlucHV0VmFsdWUudHJpbSgpKSAmJiBwYXJzZUludChpbnB1dFZhbHVlKSA+IDA7XG4gIGlmICghdmFsaWROdW1iZXIgJiYgIXZhbGlkU3RyaW5nKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSBcXGAke2lucHV0TmFtZX1cXGAgaGFzIGFuIGludmFsaWQgdmFsdWUuIGAgKyBgVG8gZml4IHRoaXMsIHByb3ZpZGUgXFxgJHtpbnB1dE5hbWV9XFxgIGFzIGEgbnVtYmVyIGdyZWF0ZXIgdGhhbiAwLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnROb0ltYWdlRGlzdG9ydGlvbihkaXIsIGltZywgcmVuZGVyZXIsIGRlc3Ryb3lSZWYpIHtcbiAgY29uc3QgY2FsbGJhY2sgPSAoKSA9PiB7XG4gICAgcmVtb3ZlTG9hZExpc3RlbmVyRm4oKTtcbiAgICByZW1vdmVFcnJvckxpc3RlbmVyRm4oKTtcbiAgICBjb25zdCBjb21wdXRlZFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoaW1nKTtcbiAgICBsZXQgcmVuZGVyZWRXaWR0aCA9IHBhcnNlRmxvYXQoY29tcHV0ZWRTdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKCd3aWR0aCcpKTtcbiAgICBsZXQgcmVuZGVyZWRIZWlnaHQgPSBwYXJzZUZsb2F0KGNvbXB1dGVkU3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgnaGVpZ2h0JykpO1xuICAgIGNvbnN0IGJveFNpemluZyA9IGNvbXB1dGVkU3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgnYm94LXNpemluZycpO1xuICAgIGlmIChib3hTaXppbmcgPT09ICdib3JkZXItYm94Jykge1xuICAgICAgY29uc3QgcGFkZGluZ1RvcCA9IGNvbXB1dGVkU3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgncGFkZGluZy10b3AnKTtcbiAgICAgIGNvbnN0IHBhZGRpbmdSaWdodCA9IGNvbXB1dGVkU3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgncGFkZGluZy1yaWdodCcpO1xuICAgICAgY29uc3QgcGFkZGluZ0JvdHRvbSA9IGNvbXB1dGVkU3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgncGFkZGluZy1ib3R0b20nKTtcbiAgICAgIGNvbnN0IHBhZGRpbmdMZWZ0ID0gY29tcHV0ZWRTdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKCdwYWRkaW5nLWxlZnQnKTtcbiAgICAgIHJlbmRlcmVkV2lkdGggLT0gcGFyc2VGbG9hdChwYWRkaW5nUmlnaHQpICsgcGFyc2VGbG9hdChwYWRkaW5nTGVmdCk7XG4gICAgICByZW5kZXJlZEhlaWdodCAtPSBwYXJzZUZsb2F0KHBhZGRpbmdUb3ApICsgcGFyc2VGbG9hdChwYWRkaW5nQm90dG9tKTtcbiAgICB9XG4gICAgY29uc3QgcmVuZGVyZWRBc3BlY3RSYXRpbyA9IHJlbmRlcmVkV2lkdGggLyByZW5kZXJlZEhlaWdodDtcbiAgICBjb25zdCBub25aZXJvUmVuZGVyZWREaW1lbnNpb25zID0gcmVuZGVyZWRXaWR0aCAhPT0gMCAmJiByZW5kZXJlZEhlaWdodCAhPT0gMDtcbiAgICBjb25zdCBpbnRyaW5zaWNXaWR0aCA9IGltZy5uYXR1cmFsV2lkdGg7XG4gICAgY29uc3QgaW50cmluc2ljSGVpZ2h0ID0gaW1nLm5hdHVyYWxIZWlnaHQ7XG4gICAgY29uc3QgaW50cmluc2ljQXNwZWN0UmF0aW8gPSBpbnRyaW5zaWNXaWR0aCAvIGludHJpbnNpY0hlaWdodDtcbiAgICBjb25zdCBzdXBwbGllZFdpZHRoID0gZGlyLndpZHRoO1xuICAgIGNvbnN0IHN1cHBsaWVkSGVpZ2h0ID0gZGlyLmhlaWdodDtcbiAgICBjb25zdCBzdXBwbGllZEFzcGVjdFJhdGlvID0gc3VwcGxpZWRXaWR0aCAvIHN1cHBsaWVkSGVpZ2h0O1xuICAgIGNvbnN0IGluYWNjdXJhdGVEaW1lbnNpb25zID0gTWF0aC5hYnMoc3VwcGxpZWRBc3BlY3RSYXRpbyAtIGludHJpbnNpY0FzcGVjdFJhdGlvKSA+IEFTUEVDVF9SQVRJT19UT0xFUkFOQ0U7XG4gICAgY29uc3Qgc3R5bGluZ0Rpc3RvcnRpb24gPSBub25aZXJvUmVuZGVyZWREaW1lbnNpb25zICYmIE1hdGguYWJzKGludHJpbnNpY0FzcGVjdFJhdGlvIC0gcmVuZGVyZWRBc3BlY3RSYXRpbykgPiBBU1BFQ1RfUkFUSU9fVE9MRVJBTkNFO1xuICAgIGlmIChpbmFjY3VyYXRlRGltZW5zaW9ucykge1xuICAgICAgY29uc29sZS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSB0aGUgYXNwZWN0IHJhdGlvIG9mIHRoZSBpbWFnZSBkb2VzIG5vdCBtYXRjaCBgICsgYHRoZSBhc3BlY3QgcmF0aW8gaW5kaWNhdGVkIGJ5IHRoZSB3aWR0aCBhbmQgaGVpZ2h0IGF0dHJpYnV0ZXMuIGAgKyBgXFxuSW50cmluc2ljIGltYWdlIHNpemU6ICR7aW50cmluc2ljV2lkdGh9dyB4ICR7aW50cmluc2ljSGVpZ2h0fWggYCArIGAoYXNwZWN0LXJhdGlvOiAke3JvdW5kKGludHJpbnNpY0FzcGVjdFJhdGlvKX0pLiBcXG5TdXBwbGllZCB3aWR0aCBhbmQgaGVpZ2h0IGF0dHJpYnV0ZXM6IGAgKyBgJHtzdXBwbGllZFdpZHRofXcgeCAke3N1cHBsaWVkSGVpZ2h0fWggKGFzcGVjdC1yYXRpbzogJHtyb3VuZChzdXBwbGllZEFzcGVjdFJhdGlvKX0pLiBgICsgYFxcblRvIGZpeCB0aGlzLCB1cGRhdGUgdGhlIHdpZHRoIGFuZCBoZWlnaHQgYXR0cmlidXRlcy5gKSk7XG4gICAgfSBlbHNlIGlmIChzdHlsaW5nRGlzdG9ydGlvbikge1xuICAgICAgY29uc29sZS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSB0aGUgYXNwZWN0IHJhdGlvIG9mIHRoZSByZW5kZXJlZCBpbWFnZSBgICsgYGRvZXMgbm90IG1hdGNoIHRoZSBpbWFnZSdzIGludHJpbnNpYyBhc3BlY3QgcmF0aW8uIGAgKyBgXFxuSW50cmluc2ljIGltYWdlIHNpemU6ICR7aW50cmluc2ljV2lkdGh9dyB4ICR7aW50cmluc2ljSGVpZ2h0fWggYCArIGAoYXNwZWN0LXJhdGlvOiAke3JvdW5kKGludHJpbnNpY0FzcGVjdFJhdGlvKX0pLiBcXG5SZW5kZXJlZCBpbWFnZSBzaXplOiBgICsgYCR7cmVuZGVyZWRXaWR0aH13IHggJHtyZW5kZXJlZEhlaWdodH1oIChhc3BlY3QtcmF0aW86IGAgKyBgJHtyb3VuZChyZW5kZXJlZEFzcGVjdFJhdGlvKX0pLiBcXG5UaGlzIGlzc3VlIGNhbiBvY2N1ciBpZiBcIndpZHRoXCIgYW5kIFwiaGVpZ2h0XCIgYCArIGBhdHRyaWJ1dGVzIGFyZSBhZGRlZCB0byBhbiBpbWFnZSB3aXRob3V0IHVwZGF0aW5nIHRoZSBjb3JyZXNwb25kaW5nIGAgKyBgaW1hZ2Ugc3R5bGluZy4gVG8gZml4IHRoaXMsIGFkanVzdCBpbWFnZSBzdHlsaW5nLiBJbiBtb3N0IGNhc2VzLCBgICsgYGFkZGluZyBcImhlaWdodDogYXV0b1wiIG9yIFwid2lkdGg6IGF1dG9cIiB0byB0aGUgaW1hZ2Ugc3R5bGluZyB3aWxsIGZpeCBgICsgYHRoaXMgaXNzdWUuYCkpO1xuICAgIH0gZWxzZSBpZiAoIWRpci5uZ1NyY3NldCAmJiBub25aZXJvUmVuZGVyZWREaW1lbnNpb25zKSB7XG4gICAgICBjb25zdCByZWNvbW1lbmRlZFdpZHRoID0gUkVDT01NRU5ERURfU1JDU0VUX0RFTlNJVFlfQ0FQICogcmVuZGVyZWRXaWR0aDtcbiAgICAgIGNvbnN0IHJlY29tbWVuZGVkSGVpZ2h0ID0gUkVDT01NRU5ERURfU1JDU0VUX0RFTlNJVFlfQ0FQICogcmVuZGVyZWRIZWlnaHQ7XG4gICAgICBjb25zdCBvdmVyc2l6ZWRXaWR0aCA9IGludHJpbnNpY1dpZHRoIC0gcmVjb21tZW5kZWRXaWR0aCA+PSBPVkVSU0laRURfSU1BR0VfVE9MRVJBTkNFO1xuICAgICAgY29uc3Qgb3ZlcnNpemVkSGVpZ2h0ID0gaW50cmluc2ljSGVpZ2h0IC0gcmVjb21tZW5kZWRIZWlnaHQgPj0gT1ZFUlNJWkVEX0lNQUdFX1RPTEVSQU5DRTtcbiAgICAgIGlmIChvdmVyc2l6ZWRXaWR0aCB8fCBvdmVyc2l6ZWRIZWlnaHQpIHtcbiAgICAgICAgY29uc29sZS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjk2MCwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSB0aGUgaW50cmluc2ljIGltYWdlIGlzIHNpZ25pZmljYW50bHkgYCArIGBsYXJnZXIgdGhhbiBuZWNlc3NhcnkuIGAgKyBgXFxuUmVuZGVyZWQgaW1hZ2Ugc2l6ZTogJHtyZW5kZXJlZFdpZHRofXcgeCAke3JlbmRlcmVkSGVpZ2h0fWguIGAgKyBgXFxuSW50cmluc2ljIGltYWdlIHNpemU6ICR7aW50cmluc2ljV2lkdGh9dyB4ICR7aW50cmluc2ljSGVpZ2h0fWguIGAgKyBgXFxuUmVjb21tZW5kZWQgaW50cmluc2ljIGltYWdlIHNpemU6ICR7cmVjb21tZW5kZWRXaWR0aH13IHggJHtyZWNvbW1lbmRlZEhlaWdodH1oLiBgICsgYFxcbk5vdGU6IFJlY29tbWVuZGVkIGludHJpbnNpYyBpbWFnZSBzaXplIGlzIGNhbGN1bGF0ZWQgYXNzdW1pbmcgYSBtYXhpbXVtIERQUiBvZiBgICsgYCR7UkVDT01NRU5ERURfU1JDU0VUX0RFTlNJVFlfQ0FQfS4gVG8gaW1wcm92ZSBsb2FkaW5nIHRpbWUsIHJlc2l6ZSB0aGUgaW1hZ2UgYCArIGBvciBjb25zaWRlciB1c2luZyB0aGUgXCJuZ1NyY3NldFwiIGFuZCBcInNpemVzXCIgYXR0cmlidXRlcy5gKSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCByZW1vdmVMb2FkTGlzdGVuZXJGbiA9IHJlbmRlcmVyLmxpc3RlbihpbWcsICdsb2FkJywgY2FsbGJhY2spO1xuICBjb25zdCByZW1vdmVFcnJvckxpc3RlbmVyRm4gPSByZW5kZXJlci5saXN0ZW4oaW1nLCAnZXJyb3InLCAoKSA9PiB7XG4gICAgcmVtb3ZlTG9hZExpc3RlbmVyRm4oKTtcbiAgICByZW1vdmVFcnJvckxpc3RlbmVyRm4oKTtcbiAgfSk7XG4gIGRlc3Ryb3lSZWYub25EZXN0cm95KCgpID0+IHtcbiAgICByZW1vdmVMb2FkTGlzdGVuZXJGbigpO1xuICAgIHJlbW92ZUVycm9yTGlzdGVuZXJGbigpO1xuICB9KTtcbiAgY2FsbE9uTG9hZElmSW1hZ2VJc0xvYWRlZChpbWcsIGNhbGxiYWNrKTtcbn1cbmZ1bmN0aW9uIGFzc2VydE5vbkVtcHR5V2lkdGhBbmRIZWlnaHQoZGlyKSB7XG4gIGxldCBtaXNzaW5nQXR0cmlidXRlcyA9IFtdO1xuICBpZiAoZGlyLndpZHRoID09PSB1bmRlZmluZWQpIG1pc3NpbmdBdHRyaWJ1dGVzLnB1c2goJ3dpZHRoJyk7XG4gIGlmIChkaXIuaGVpZ2h0ID09PSB1bmRlZmluZWQpIG1pc3NpbmdBdHRyaWJ1dGVzLnB1c2goJ2hlaWdodCcpO1xuICBpZiAobWlzc2luZ0F0dHJpYnV0ZXMubGVuZ3RoID4gMCkge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NTQsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gdGhlc2UgcmVxdWlyZWQgYXR0cmlidXRlcyBgICsgYGFyZSBtaXNzaW5nOiAke21pc3NpbmdBdHRyaWJ1dGVzLm1hcChhdHRyID0+IGBcIiR7YXR0cn1cImApLmpvaW4oJywgJyl9LiBgICsgYEluY2x1ZGluZyBcIndpZHRoXCIgYW5kIFwiaGVpZ2h0XCIgYXR0cmlidXRlcyB3aWxsIHByZXZlbnQgaW1hZ2UtcmVsYXRlZCBsYXlvdXQgc2hpZnRzLiBgICsgYFRvIGZpeCB0aGlzLCBpbmNsdWRlIFwid2lkdGhcIiBhbmQgXCJoZWlnaHRcIiBhdHRyaWJ1dGVzIG9uIHRoZSBpbWFnZSB0YWcgb3IgdHVybiBvbiBgICsgYFwiZmlsbFwiIG1vZGUgd2l0aCB0aGUgXFxgZmlsbFxcYCBhdHRyaWJ1dGUuYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGFzc2VydEVtcHR5V2lkdGhBbmRIZWlnaHQoZGlyKSB7XG4gIGlmIChkaXIud2lkdGggfHwgZGlyLmhlaWdodCkge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDI5NTIsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gdGhlIGF0dHJpYnV0ZXMgXFxgaGVpZ2h0XFxgIGFuZC9vciBcXGB3aWR0aFxcYCBhcmUgcHJlc2VudCBgICsgYGFsb25nIHdpdGggdGhlIFxcYGZpbGxcXGAgYXR0cmlidXRlLiBCZWNhdXNlIFxcYGZpbGxcXGAgbW9kZSBjYXVzZXMgYW4gaW1hZ2UgdG8gZmlsbCBpdHMgY29udGFpbmluZyBgICsgYGVsZW1lbnQsIHRoZSBzaXplIGF0dHJpYnV0ZXMgaGF2ZSBubyBlZmZlY3QgYW5kIHNob3VsZCBiZSByZW1vdmVkLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnROb25aZXJvUmVuZGVyZWRIZWlnaHQoZGlyLCBpbWcsIHJlbmRlcmVyLCBkZXN0cm95UmVmKSB7XG4gIGNvbnN0IGNhbGxiYWNrID0gKCkgPT4ge1xuICAgIHJlbW92ZUxvYWRMaXN0ZW5lckZuKCk7XG4gICAgcmVtb3ZlRXJyb3JMaXN0ZW5lckZuKCk7XG4gICAgY29uc3QgcmVuZGVyZWRIZWlnaHQgPSBpbWcuY2xpZW50SGVpZ2h0O1xuICAgIGlmIChkaXIuZmlsbCAmJiByZW5kZXJlZEhlaWdodCA9PT0gMCkge1xuICAgICAgY29uc29sZS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSB0aGUgaGVpZ2h0IG9mIHRoZSBmaWxsLW1vZGUgaW1hZ2UgaXMgemVyby4gYCArIGBUaGlzIGlzIGxpa2VseSBiZWNhdXNlIHRoZSBjb250YWluaW5nIGVsZW1lbnQgZG9lcyBub3QgaGF2ZSB0aGUgQ1NTICdwb3NpdGlvbicgYCArIGBwcm9wZXJ0eSBzZXQgdG8gb25lIG9mIHRoZSBmb2xsb3dpbmc6IFwicmVsYXRpdmVcIiwgXCJmaXhlZFwiLCBvciBcImFic29sdXRlXCIuIGAgKyBgVG8gZml4IHRoaXMgcHJvYmxlbSwgbWFrZSBzdXJlIHRoZSBjb250YWluZXIgZWxlbWVudCBoYXMgdGhlIENTUyAncG9zaXRpb24nIGAgKyBgcHJvcGVydHkgZGVmaW5lZCBhbmQgdGhlIGhlaWdodCBvZiB0aGUgZWxlbWVudCBpcyBub3QgemVyby5gKSk7XG4gICAgfVxuICB9O1xuICBjb25zdCByZW1vdmVMb2FkTGlzdGVuZXJGbiA9IHJlbmRlcmVyLmxpc3RlbihpbWcsICdsb2FkJywgY2FsbGJhY2spO1xuICBjb25zdCByZW1vdmVFcnJvckxpc3RlbmVyRm4gPSByZW5kZXJlci5saXN0ZW4oaW1nLCAnZXJyb3InLCAoKSA9PiB7XG4gICAgcmVtb3ZlTG9hZExpc3RlbmVyRm4oKTtcbiAgICByZW1vdmVFcnJvckxpc3RlbmVyRm4oKTtcbiAgfSk7XG4gIGRlc3Ryb3lSZWYub25EZXN0cm95KCgpID0+IHtcbiAgICByZW1vdmVMb2FkTGlzdGVuZXJGbigpO1xuICAgIHJlbW92ZUVycm9yTGlzdGVuZXJGbigpO1xuICB9KTtcbiAgY2FsbE9uTG9hZElmSW1hZ2VJc0xvYWRlZChpbWcsIGNhbGxiYWNrKTtcbn1cbmZ1bmN0aW9uIGFzc2VydFZhbGlkTG9hZGluZ0lucHV0KGRpcikge1xuICBpZiAoZGlyLmxvYWRpbmcgJiYgZGlyLnByaW9yaXR5KSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSB0aGUgXFxgbG9hZGluZ1xcYCBhdHRyaWJ1dGUgYCArIGB3YXMgdXNlZCBvbiBhbiBpbWFnZSB0aGF0IHdhcyBtYXJrZWQgXCJwcmlvcml0eVwiLiBgICsgYFNldHRpbmcgXFxgbG9hZGluZ1xcYCBvbiBwcmlvcml0eSBpbWFnZXMgaXMgbm90IGFsbG93ZWQgYCArIGBiZWNhdXNlIHRoZXNlIGltYWdlcyB3aWxsIGFsd2F5cyBiZSBlYWdlcmx5IGxvYWRlZC4gYCArIGBUbyBmaXggdGhpcywgcmVtb3ZlIHRoZSDigJxsb2FkaW5n4oCdIGF0dHJpYnV0ZSBmcm9tIHRoZSBwcmlvcml0eSBpbWFnZS5gKTtcbiAgfVxuICBjb25zdCB2YWxpZElucHV0cyA9IFsnYXV0bycsICdlYWdlcicsICdsYXp5J107XG4gIGlmICh0eXBlb2YgZGlyLmxvYWRpbmcgPT09ICdzdHJpbmcnICYmICF2YWxpZElucHV0cy5pbmNsdWRlcyhkaXIubG9hZGluZykpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigyOTUyLCBgJHtpbWdEaXJlY3RpdmVEZXRhaWxzKGRpci5uZ1NyYyl9IHRoZSBcXGBsb2FkaW5nXFxgIGF0dHJpYnV0ZSBgICsgYGhhcyBhbiBpbnZhbGlkIHZhbHVlIChcXGAke2Rpci5sb2FkaW5nfVxcYCkuIGAgKyBgVG8gZml4IHRoaXMsIHByb3ZpZGUgYSB2YWxpZCB2YWx1ZSAoXCJsYXp5XCIsIFwiZWFnZXJcIiwgb3IgXCJhdXRvXCIpLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRWYWxpZERlY29kaW5nSW5wdXQoZGlyKSB7XG4gIGNvbnN0IHZhbGlkSW5wdXRzID0gWydzeW5jJywgJ2FzeW5jJywgJ2F1dG8nXTtcbiAgaWYgKHR5cGVvZiBkaXIuZGVjb2RpbmcgPT09ICdzdHJpbmcnICYmICF2YWxpZElucHV0cy5pbmNsdWRlcyhkaXIuZGVjb2RpbmcpKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoMjk1MiwgYCR7aW1nRGlyZWN0aXZlRGV0YWlscyhkaXIubmdTcmMpfSB0aGUgXFxgZGVjb2RpbmdcXGAgYXR0cmlidXRlIGAgKyBgaGFzIGFuIGludmFsaWQgdmFsdWUgKFxcYCR7ZGlyLmRlY29kaW5nfVxcYCkuIGAgKyBgVG8gZml4IHRoaXMsIHByb3ZpZGUgYSB2YWxpZCB2YWx1ZSAoXCJzeW5jXCIsIFwiYXN5bmNcIiwgb3IgXCJhdXRvXCIpLmApO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnROb3RNaXNzaW5nQnVpbHRJbkxvYWRlcihuZ1NyYywgaW1hZ2VMb2FkZXIpIHtcbiAgaWYgKGltYWdlTG9hZGVyID09PSBub29wSW1hZ2VMb2FkZXIpIHtcbiAgICBsZXQgYnVpbHRJbkxvYWRlck5hbWUgPSAnJztcbiAgICBmb3IgKGNvbnN0IGxvYWRlciBvZiBCVUlMVF9JTl9MT0FERVJTKSB7XG4gICAgICBpZiAobG9hZGVyLnRlc3RVcmwobmdTcmMpKSB7XG4gICAgICAgIGJ1aWx0SW5Mb2FkZXJOYW1lID0gbG9hZGVyLm5hbWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoYnVpbHRJbkxvYWRlck5hbWUpIHtcbiAgICAgIGNvbnNvbGUud2FybihfZm9ybWF0UnVudGltZUVycm9yKDI5NjIsIGBOZ09wdGltaXplZEltYWdlOiBJdCBsb29rcyBsaWtlIHlvdXIgaW1hZ2VzIG1heSBiZSBob3N0ZWQgb24gdGhlIGAgKyBgJHtidWlsdEluTG9hZGVyTmFtZX0gQ0ROLCBidXQgeW91ciBhcHAgaXMgbm90IHVzaW5nIEFuZ3VsYXIncyBgICsgYGJ1aWx0LWluIGxvYWRlciBmb3IgdGhhdCBDRE4uIFdlIHJlY29tbWVuZCBzd2l0Y2hpbmcgdG8gdXNlIGAgKyBgdGhlIGJ1aWx0LWluIGJ5IGNhbGxpbmcgXFxgcHJvdmlkZSR7YnVpbHRJbkxvYWRlck5hbWV9TG9hZGVyKClcXGAgYCArIGBpbiB5b3VyIFxcYHByb3ZpZGVyc1xcYCBhbmQgcGFzc2luZyBpdCB5b3VyIGluc3RhbmNlJ3MgYmFzZSBVUkwuIGAgKyBgSWYgeW91IGRvbid0IHdhbnQgdG8gdXNlIHRoZSBidWlsdC1pbiBsb2FkZXIsIGRlZmluZSBhIGN1c3RvbSBgICsgYGxvYWRlciBmdW5jdGlvbiB1c2luZyBJTUFHRV9MT0FERVIgdG8gc2lsZW5jZSB0aGlzIHdhcm5pbmcuYCkpO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0Tm9OZ1NyY3NldFdpdGhvdXRMb2FkZXIoZGlyLCBpbWFnZUxvYWRlcikge1xuICBpZiAoZGlyLm5nU3Jjc2V0ICYmIGltYWdlTG9hZGVyID09PSBub29wSW1hZ2VMb2FkZXIpIHtcbiAgICBjb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcigyOTYzLCBgJHtpbWdEaXJlY3RpdmVEZXRhaWxzKGRpci5uZ1NyYyl9IHRoZSBcXGBuZ1NyY3NldFxcYCBhdHRyaWJ1dGUgaXMgcHJlc2VudCBidXQgYCArIGBubyBpbWFnZSBsb2FkZXIgaXMgY29uZmlndXJlZCAoaS5lLiB0aGUgZGVmYXVsdCBvbmUgaXMgYmVpbmcgdXNlZCksIGAgKyBgd2hpY2ggd291bGQgcmVzdWx0IGluIHRoZSBzYW1lIGltYWdlIGJlaW5nIHVzZWQgZm9yIGFsbCBjb25maWd1cmVkIHNpemVzLiBgICsgYFRvIGZpeCB0aGlzLCBwcm92aWRlIGEgbG9hZGVyIG9yIHJlbW92ZSB0aGUgXFxgbmdTcmNzZXRcXGAgYXR0cmlidXRlIGZyb20gdGhlIGltYWdlLmApKTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0Tm9Mb2FkZXJQYXJhbXNXaXRob3V0TG9hZGVyKGRpciwgaW1hZ2VMb2FkZXIpIHtcbiAgaWYgKGRpci5sb2FkZXJQYXJhbXMgJiYgaW1hZ2VMb2FkZXIgPT09IG5vb3BJbWFnZUxvYWRlcikge1xuICAgIGNvbnNvbGUud2FybihfZm9ybWF0UnVudGltZUVycm9yKDI5NjMsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gdGhlIFxcYGxvYWRlclBhcmFtc1xcYCBhdHRyaWJ1dGUgaXMgcHJlc2VudCBidXQgYCArIGBubyBpbWFnZSBsb2FkZXIgaXMgY29uZmlndXJlZCAoaS5lLiB0aGUgZGVmYXVsdCBvbmUgaXMgYmVpbmcgdXNlZCksIGAgKyBgd2hpY2ggbWVhbnMgdGhhdCB0aGUgbG9hZGVyUGFyYW1zIGRhdGEgd2lsbCBub3QgYmUgY29uc3VtZWQgYW5kIHdpbGwgbm90IGFmZmVjdCB0aGUgVVJMLiBgICsgYFRvIGZpeCB0aGlzLCBwcm92aWRlIGEgY3VzdG9tIGxvYWRlciBvciByZW1vdmUgdGhlIFxcYGxvYWRlclBhcmFtc1xcYCBhdHRyaWJ1dGUgZnJvbSB0aGUgaW1hZ2UuYCkpO1xuICB9XG59XG5hc3luYyBmdW5jdGlvbiBhc3NldFByaW9yaXR5Q291bnRCZWxvd1RocmVzaG9sZChhcHBSZWYpIHtcbiAgaWYgKElNR1NfV0lUSF9QUklPUklUWV9BVFRSX0NPVU5UID09PSAwKSB7XG4gICAgSU1HU19XSVRIX1BSSU9SSVRZX0FUVFJfQ09VTlQrKztcbiAgICBhd2FpdCBhcHBSZWYud2hlblN0YWJsZSgpO1xuICAgIGlmIChJTUdTX1dJVEhfUFJJT1JJVFlfQVRUUl9DT1VOVCA+IFBSSU9SSVRZX0NPVU5UX1RIUkVTSE9MRCkge1xuICAgICAgY29uc29sZS53YXJuKF9mb3JtYXRSdW50aW1lRXJyb3IoMjk2NiwgYE5nT3B0aW1pemVkSW1hZ2U6IFRoZSBcInByaW9yaXR5XCIgYXR0cmlidXRlIGlzIHNldCB0byB0cnVlIG1vcmUgdGhhbiAke1BSSU9SSVRZX0NPVU5UX1RIUkVTSE9MRH0gdGltZXMgKCR7SU1HU19XSVRIX1BSSU9SSVRZX0FUVFJfQ09VTlR9IHRpbWVzKS4gYCArIGBNYXJraW5nIHRvbyBtYW55IGltYWdlcyBhcyBcImhpZ2hcIiBwcmlvcml0eSBjYW4gaHVydCB5b3VyIGFwcGxpY2F0aW9uJ3MgTENQIChodHRwczovL3dlYi5kZXYvbGNwKS4gYCArIGBcIlByaW9yaXR5XCIgc2hvdWxkIG9ubHkgYmUgc2V0IG9uIHRoZSBpbWFnZSBleHBlY3RlZCB0byBiZSB0aGUgcGFnZSdzIExDUCBlbGVtZW50LmApKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgSU1HU19XSVRIX1BSSU9SSVRZX0FUVFJfQ09VTlQrKztcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0UGxhY2Vob2xkZXJEaW1lbnNpb25zKGRpciwgaW1nRWxlbWVudCkge1xuICBjb25zdCBjb21wdXRlZFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoaW1nRWxlbWVudCk7XG4gIGxldCByZW5kZXJlZFdpZHRoID0gcGFyc2VGbG9hdChjb21wdXRlZFN0eWxlLmdldFByb3BlcnR5VmFsdWUoJ3dpZHRoJykpO1xuICBsZXQgcmVuZGVyZWRIZWlnaHQgPSBwYXJzZUZsb2F0KGNvbXB1dGVkU3R5bGUuZ2V0UHJvcGVydHlWYWx1ZSgnaGVpZ2h0JykpO1xuICBpZiAocmVuZGVyZWRXaWR0aCA+IFBMQUNFSE9MREVSX0RJTUVOU0lPTl9MSU1JVCB8fCByZW5kZXJlZEhlaWdodCA+IFBMQUNFSE9MREVSX0RJTUVOU0lPTl9MSU1JVCkge1xuICAgIGNvbnNvbGUud2FybihfZm9ybWF0UnVudGltZUVycm9yKDI5NjcsIGAke2ltZ0RpcmVjdGl2ZURldGFpbHMoZGlyLm5nU3JjKX0gaXQgdXNlcyBhIHBsYWNlaG9sZGVyIGltYWdlLCBidXQgYXQgbGVhc3Qgb25lIGAgKyBgb2YgdGhlIGRpbWVuc2lvbnMgYXR0cmlidXRlIChoZWlnaHQgb3Igd2lkdGgpIGV4Y2VlZHMgdGhlIGxpbWl0IG9mICR7UExBQ0VIT0xERVJfRElNRU5TSU9OX0xJTUlUfXB4LiBgICsgYFRvIGZpeCB0aGlzLCB1c2UgYSBzbWFsbGVyIGltYWdlIGFzIGEgcGxhY2Vob2xkZXIuYCkpO1xuICB9XG59XG5mdW5jdGlvbiBjYWxsT25Mb2FkSWZJbWFnZUlzTG9hZGVkKGltZywgY2FsbGJhY2spIHtcbiAgaWYgKGltZy5jb21wbGV0ZSAmJiBpbWcubmF0dXJhbFdpZHRoKSB7XG4gICAgY2FsbGJhY2soKTtcbiAgfVxufVxuZnVuY3Rpb24gcm91bmQoaW5wdXQpIHtcbiAgcmV0dXJuIE51bWJlci5pc0ludGVnZXIoaW5wdXQpID8gaW5wdXQgOiBpbnB1dC50b0ZpeGVkKDIpO1xufVxuZnVuY3Rpb24gdW53cmFwU2FmZVVybCh2YWx1ZSkge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICByZXR1cm4gX3Vud3JhcFNhZmVWYWx1ZSh2YWx1ZSk7XG59XG5mdW5jdGlvbiBib29sZWFuT3JVcmxBdHRyaWJ1dGUodmFsdWUpIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgJiYgdmFsdWUgIT09ICd0cnVlJyAmJiB2YWx1ZSAhPT0gJ2ZhbHNlJyAmJiB2YWx1ZSAhPT0gJycpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgcmV0dXJuIGJvb2xlYW5BdHRyaWJ1dGUodmFsdWUpO1xufVxuZXhwb3J0IHsgSU1BR0VfTE9BREVSLCBMb2NhdGlvbiwgTG9jYXRpb25TdHJhdGVneSwgTmdPcHRpbWl6ZWRJbWFnZSwgUFJFQ09OTkVDVF9DSEVDS19CTE9DS0xJU1QsIFBsYXRmb3JtTmF2aWdhdGlvbiwgVkVSU0lPTiwgVmlld3BvcnRTY3JvbGxlciwgaXNQbGF0Zm9ybUJyb3dzZXIsIGlzUGxhdGZvcm1TZXJ2ZXIsIHByb3ZpZGVDbG91ZGZsYXJlTG9hZGVyLCBwcm92aWRlQ2xvdWRpbmFyeUxvYWRlciwgcHJvdmlkZUltYWdlS2l0TG9hZGVyLCBwcm92aWRlSW1naXhMb2FkZXIsIHByb3ZpZGVOZXRsaWZ5TG9hZGVyLCByZWdpc3RlckxvY2FsZURhdGEsIE5hdmlnYXRpb25BZGFwdGVyRm9yTG9jYXRpb24gYXMgybVOYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uLCBOdWxsVmlld3BvcnRTY3JvbGxlciBhcyDJtU51bGxWaWV3cG9ydFNjcm9sbGVyLCBQTEFURk9STV9CUk9XU0VSX0lEIGFzIMm1UExBVEZPUk1fQlJPV1NFUl9JRCwgUExBVEZPUk1fU0VSVkVSX0lEIGFzIMm1UExBVEZPUk1fU0VSVkVSX0lELCBub3JtYWxpemVRdWVyeVBhcmFtcyBhcyDJtW5vcm1hbGl6ZVF1ZXJ5UGFyYW1zIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDNdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFVQSxTQUFTLGNBQWMsT0FBTyxLQUFLO0NBQ2pDLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsSUFBSSxDQUFDLEtBQUssT0FBTztDQUNqQixJQUFJLE1BQU0sU0FBUyxHQUFHLEdBQ3BCLE9BQU8sSUFBSSxXQUFXLEdBQUcsSUFBSSxRQUFRLElBQUksTUFBTSxDQUFDLElBQUksUUFBUTtDQUU5RCxPQUFPLElBQUksV0FBVyxHQUFHLElBQUksUUFBUSxNQUFNLEdBQUcsTUFBTSxHQUFHO0FBQ3pEO0FBQ0EsU0FBUyxtQkFBbUIsS0FBSztDQUMvQixNQUFNLGFBQWEsSUFBSSxPQUFPLFFBQVE7Q0FDdEMsT0FBTyxJQUFJLGFBQWEsT0FBTyxNQUFNLElBQUksTUFBTSxHQUFHLGFBQWEsQ0FBQyxJQUFJLElBQUksTUFBTSxVQUFVLElBQUk7QUFDOUY7QUFDQSxTQUFTLHFCQUFxQixRQUFRO0NBQ3BDLE9BQU8sVUFBVSxPQUFPLE9BQU8sTUFBTSxJQUFJLFdBQVc7QUFDdEQ7QUFDQSxJQUFNLG1CQUFOLE1BQXVCO0NBQ3JCLFVBQVUsa0JBQWtCO0VBQzFCLE1BQU0sSUFBSSxNQUFNLFlBQVksb0JBQW9CLEVBQUU7Q0FDcEQ7QUFTRjs7a0NBUlMsUUFBTyxTQUFTLHlCQUF5QixtQkFBbUI7Q0FDakUsT0FBTyxLQUFLLHFCQUFxQkEsbUJBQWtCO0FBQ3JELENBQUE7a0NBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9BO0NBQ1Asc0JBQXNCLE9BQU8sb0JBQW9CLEVBQUEsQ0FBRztDQUNwRCxZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNDLGlCQUFxQixrQkFBa0IsQ0FBQztFQUN6RixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsWUFBWTtHQUNaLGtCQUFrQixPQUFPLG9CQUFvQjtFQUMvQyxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLGdCQUFnQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxnQkFBZ0IsRUFBRTtBQUMzRyxJQUFNLHVCQUFOLGNBQW1DLGlCQUFpQjtDQUlsRCxZQUFZLG1CQUFtQixNQUFNOztFQUNuQyxNQUFNO3dCQUpSLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxzQkFBcUIsQ0FBQyxDQUFBO0VBR3BCLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssYUFBQSxRQUFBLFFBQVksU0FBQSxRQUFBLFNBQUEsS0FBQSxJQUFBLE9BQVEsS0FBSyxrQkFBa0IsbUJBQW1CLE9BQUEsUUFBQSxVQUFBLEtBQUEsSUFBQSxTQUFBLG1CQUFLLE9BQU8sUUFBUSxDQUFDLENBQUMsY0FBQSxRQUFBLHFCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsaUJBQVUsWUFBQSxRQUFBLFNBQUEsS0FBQSxJQUFBLE9BQVU7Q0FDL0c7Q0FDQSxjQUFjO0VBQ1osT0FBTyxLQUFLLG1CQUFtQixRQUM3QixLQUFLLG1CQUFtQixJQUFJLENBQUMsQ0FBQztDQUVsQztDQUNBLFdBQVcsSUFBSTtFQUNiLEtBQUssbUJBQW1CLEtBQUssS0FBSyxrQkFBa0IsV0FBVyxFQUFFLEdBQUcsS0FBSyxrQkFBa0IsYUFBYSxFQUFFLENBQUM7Q0FDN0c7Q0FDQSxjQUFjO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxtQkFBbUIsVUFBVTtFQUMzQixPQUFPLGNBQWMsS0FBSyxXQUFXLFFBQVE7Q0FDL0M7Q0FDQSxLQUFLLGNBQWMsT0FBTztFQUN4QixNQUFNLFdBQVcsS0FBSyxrQkFBa0IsV0FBVyxxQkFBcUIsS0FBSyxrQkFBa0IsTUFBTTtFQUNyRyxNQUFNLE9BQU8sS0FBSyxrQkFBa0I7RUFDcEMsT0FBTyxRQUFRLGNBQWMsR0FBRyxXQUFXLFNBQVM7Q0FDdEQ7Q0FDQSxVQUFVLE9BQU8sT0FBTyxLQUFLLGFBQWE7RUFDeEMsTUFBTSxjQUFjLEtBQUssbUJBQW1CLE1BQU0scUJBQXFCLFdBQVcsQ0FBQztFQUNuRixLQUFLLGtCQUFrQixVQUFVLE9BQU8sT0FBTyxXQUFXO0NBQzVEO0NBQ0EsYUFBYSxPQUFPLE9BQU8sS0FBSyxhQUFhO0VBQzNDLE1BQU0sY0FBYyxLQUFLLG1CQUFtQixNQUFNLHFCQUFxQixXQUFXLENBQUM7RUFDbkYsS0FBSyxrQkFBa0IsYUFBYSxPQUFPLE9BQU8sV0FBVztDQUMvRDtDQUNBLFVBQVU7RUFDUixLQUFLLGtCQUFrQixRQUFRO0NBQ2pDO0NBQ0EsT0FBTztFQUNMLEtBQUssa0JBQWtCLEtBQUs7Q0FDOUI7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLLGtCQUFrQixTQUFTO0NBQ3pDO0NBQ0EsVUFBVSxtQkFBbUIsR0FBRzs7RUFDOUIsQ0FBQSx5QkFBQSx5QkFBQSxLQUFLLGtCQUFBLENBQWtCLGVBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQUEsS0FBQSx3QkFBWSxnQkFBZ0I7Q0FDckQ7QUFVRjs7c0NBVFMsUUFBTyxTQUFTLDZCQUE2QixtQkFBbUI7Q0FFckUsT0FBTyxLQUFLLHFCQUFxQkMsdUJBQXNCQyxTQUFZLGdCQUFnQixHQUFHQSxTQUFZLGVBQWUsQ0FBQyxDQUFDO0FBQ3JILENBQUE7c0NBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9EO0NBQ1AsU0FBU0Esc0JBQXFCO0NBQzlCLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0QsaUJBQXFCLHNCQUFzQixDQUFDO0VBQzdGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxZQUFZLE9BQ2QsQ0FBQztDQUNILENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTSxpQkFDUixHQUFHO0VBQ0QsTUFBTSxLQUFBO0VBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxTQUNSLEdBQUc7R0FDRCxNQUFNO0dBQ04sTUFBTSxDQUFDLGFBQWE7RUFDdEIsQ0FBQztDQUNILENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxzQ0FBTixjQUFrRCxxQkFBcUI7Q0FDckUsbUJBQW1CLFVBQVU7RUFDM0IsTUFBTSxPQUFPLGVBQWUsUUFBUTtFQUNwQyxJQUFJLEtBQUssU0FBUyxHQUFHLEtBQUssS0FBSyxTQUFTLEdBQ3RDLFdBQVcsS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLFNBQVMsTUFBTSxLQUFLLE1BQU07RUFFM0QsT0FBTyxNQUFNLG1CQUFtQixRQUFRO0NBQzFDO0FBWUY7O3FEQVhTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsNENBQTRDLG1CQUFtQjtFQUM3RSxRQUFRLHFEQUFxRCxtREFBbURHLHNCQUF5QkMsb0NBQW1DLEdBQUEsQ0FBSSxxQkFBcUJBLG9DQUFtQztDQUMxTztBQUNGLEVBQUEsQ0FBRyxDQUFBO3FEQUNJLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPQTtDQUNQLFNBQVNBLHFDQUFvQztDQUM3QyxZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNKLGlCQUFxQixxQ0FBcUMsQ0FBQztFQUM1RyxNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsWUFBWSxPQUNkLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sb0NBQU4sY0FBZ0QscUJBQXFCO0NBQ25FLG1CQUFtQixVQUFVO0VBQzNCLE1BQU0sT0FBTyxlQUFlLFFBQVE7RUFDcEMsSUFBSSxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQ3BCLFdBQVcsT0FBTyxNQUFNLFNBQVMsTUFBTSxLQUFLLE1BQU07RUFFcEQsT0FBTyxNQUFNLG1CQUFtQixRQUFRO0NBQzFDO0FBWUY7O21EQVhTLFFBQXNCLHVCQUFPO0NBQ2xDLElBQUk7Q0FDSixPQUFPLFNBQVMsMENBQTBDLG1CQUFtQjtFQUMzRSxRQUFRLG1EQUFtRCxpREFBaURHLHNCQUF5QkUsa0NBQWlDLEdBQUEsQ0FBSSxxQkFBcUJBLGtDQUFpQztDQUNsTztBQUNGLEVBQUEsQ0FBRyxDQUFBO21EQUNJLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPQTtDQUNQLFNBQVNBLG1DQUFrQztDQUMzQyxZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNMLGlCQUFxQixtQ0FBbUMsQ0FBQztFQUMxRyxNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsWUFBWSxPQUNkLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILFNBQVMsZUFBZSxLQUFLO0NBQzNCLE1BQU0sMEJBQTBCLElBQUksT0FBTyxNQUFNO0NBQ2pELE1BQU0sVUFBVSwwQkFBMEIsS0FBSywwQkFBMEIsSUFBSTtDQUM3RSxPQUFPLElBQUksTUFBTSxHQUFHLE9BQU87QUFDN0I7QUFDQSxJQUFNLFdBQU4sTUFBTSxTQUFTO0NBTWIsWUFBWSxrQkFBa0I7d0JBTDlCLFlBQVcsSUFBSSxRQUFRLENBQUE7d0JBQ3ZCLGFBQUEsS0FBQSxDQUFBO3dCQUNBLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSx1QkFBc0IsQ0FBQyxDQUFBO3dCQUN2QiwwQkFBeUIsSUFBQTtFQUV2QixLQUFLLG9CQUFvQjtFQUN6QixNQUFNLFdBQVcsS0FBSyxrQkFBa0IsWUFBWTtFQUNwRCxLQUFLLFlBQVksYUFBYSxtQkFBbUIsZ0JBQWdCLFFBQVEsQ0FBQyxDQUFDO0VBQzNFLEtBQUssa0JBQWtCLFlBQVcsT0FBTTtHQUN0QyxLQUFLLFNBQVMsS0FBSztJQUNqQixPQUFPLEtBQUssS0FBSyxJQUFJO0lBQ3JCLE9BQU87SUFDUCxTQUFTLEdBQUc7SUFDWixRQUFRLEdBQUc7R0FDYixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsY0FBYzs7RUFDWixDQUFBLHdCQUFBLEtBQUssNEJBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQXdCLFlBQVk7RUFDekMsS0FBSyxzQkFBc0IsQ0FBQztDQUM5QjtDQUNBLEtBQUssY0FBYyxPQUFPO0VBQ3hCLE9BQU8sS0FBSyxVQUFVLEtBQUssa0JBQWtCLEtBQUssV0FBVyxDQUFDO0NBQ2hFO0NBQ0EsV0FBVztFQUNULE9BQU8sS0FBSyxrQkFBa0IsU0FBUztDQUN6QztDQUNBLHFCQUFxQixNQUFNLFFBQVEsSUFBSTtFQUNyQyxPQUFPLEtBQUssS0FBSyxLQUFLLEtBQUssVUFBVSxPQUFPLHFCQUFxQixLQUFLLENBQUM7Q0FDekU7Q0FDQSxVQUFVLEtBQUs7RUFDYixPQUFPLFNBQVMsbUJBQW1CLGVBQWUsS0FBSyxXQUFXLGdCQUFnQixHQUFHLENBQUMsQ0FBQztDQUN6RjtDQUNBLG1CQUFtQixLQUFLO0VBQ3RCLElBQUksT0FBTyxJQUFJLE9BQU8sS0FDcEIsTUFBTSxNQUFNO0VBRWQsT0FBTyxLQUFLLGtCQUFrQixtQkFBbUIsR0FBRztDQUN0RDtDQUNBLEdBQUcsTUFBTSxRQUFRLElBQUksUUFBUSxNQUFNO0VBQ2pDLEtBQUssa0JBQWtCLFVBQVUsT0FBTyxJQUFJLE1BQU0sS0FBSztFQUN2RCxLQUFLLDBCQUEwQixLQUFLLG1CQUFtQixPQUFPLHFCQUFxQixLQUFLLENBQUMsR0FBRyxLQUFLO0NBQ25HO0NBQ0EsYUFBYSxNQUFNLFFBQVEsSUFBSSxRQUFRLE1BQU07RUFDM0MsS0FBSyxrQkFBa0IsYUFBYSxPQUFPLElBQUksTUFBTSxLQUFLO0VBQzFELEtBQUssMEJBQTBCLEtBQUssbUJBQW1CLE9BQU8scUJBQXFCLEtBQUssQ0FBQyxHQUFHLEtBQUs7Q0FDbkc7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxrQkFBa0IsUUFBUTtDQUNqQztDQUNBLE9BQU87RUFDTCxLQUFLLGtCQUFrQixLQUFLO0NBQzlCO0NBQ0EsVUFBVSxtQkFBbUIsR0FBRzs7RUFDOUIsQ0FBQSx5QkFBQSx5QkFBQSxLQUFLLGtCQUFBLENBQWtCLGVBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQUEsS0FBQSx3QkFBWSxnQkFBZ0I7Q0FDckQ7Q0FDQSxZQUFZLElBQUk7O0VBQ2QsS0FBSyxvQkFBb0IsS0FBSyxFQUFFO0VBQ2hDLENBQUEseUJBQUEsS0FBSyw0QkFBQSxRQUFBLDJCQUFBLEtBQUEsTUFBTCxLQUFLLHlCQUEyQixLQUFLLFdBQVUsTUFBSztHQUNsRCxLQUFLLDBCQUEwQixFQUFFLEtBQUssRUFBRSxLQUFLO0VBQy9DLENBQUM7RUFDRCxhQUFhO0dBQ1gsTUFBTSxVQUFVLEtBQUssb0JBQW9CLFFBQVEsRUFBRTtHQUNuRCxLQUFLLG9CQUFvQixPQUFPLFNBQVMsQ0FBQztHQUMxQyxJQUFJLEtBQUssb0JBQW9CLFdBQVcsR0FBRzs7SUFDekMsQ0FBQSx5QkFBQSxLQUFLLDRCQUFBLFFBQUEsMkJBQUEsS0FBQSxLQUFBLHVCQUF3QixZQUFZO0lBQ3pDLEtBQUsseUJBQXlCO0dBQ2hDO0VBQ0Y7Q0FDRjtDQUNBLDBCQUEwQixNQUFNLElBQUksT0FBTztFQUN6QyxLQUFLLG9CQUFvQixTQUFRLE9BQU0sR0FBRyxLQUFLLEtBQUssQ0FBQztDQUN2RDtDQUNBLFVBQVUsUUFBUSxTQUFTLFVBQVU7RUFDbkMsT0FBTyxLQUFLLFNBQVMsVUFBVTtHQUM3QixNQUFNO0dBQ04sT0FBTyxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsVUFBVyxLQUFBO0dBQ2xCLFVBQVUsYUFBQSxRQUFBLGFBQUEsS0FBQSxJQUFBLFdBQVksS0FBQTtFQUN4QixDQUFDO0NBQ0g7QUFhRjs7MEJBWlMsd0JBQXVCLG9CQUFBOzBCQUN2QixpQkFBZ0IsYUFBQTswQkFDaEIsc0JBQXFCLGtCQUFBOzBCQUNyQixRQUFPLFNBQVMsaUJBQWlCLG1CQUFtQjtDQUV6RCxPQUFPLEtBQUsscUJBQXFCTSxXQUFVSixTQUFZLGdCQUFnQixDQUFDO0FBQzFFLENBQUE7MEJBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9JO0NBQ1AsZUFBZSxlQUFlO0NBQzlCLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY04saUJBQXFCLFVBQVUsQ0FBQztFQUNqRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsWUFBWTtHQUNaLFlBQVk7RUFDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNLGlCQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsU0FBUyxpQkFBaUI7Q0FDeEIsT0FBTyxJQUFJLFNBQVNPLFNBQVMsZ0JBQWdCLENBQUM7QUFDaEQ7QUFDQSxTQUFTLGVBQWUsVUFBVSxLQUFLO0NBQ3JDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxXQUFXLFFBQVEsR0FDdkMsT0FBTztDQUVULE1BQU0sY0FBYyxJQUFJLFVBQVUsU0FBUyxNQUFNO0NBQ2pELElBQUksZ0JBQWdCLE1BQU07RUFBQztFQUFLO0VBQUs7RUFBSztDQUFHLENBQUMsQ0FBQyxTQUFTLFlBQVksRUFBRSxHQUNwRSxPQUFPO0NBRVQsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsS0FBSztDQUM1QixPQUFPLElBQUksUUFBUSxrQkFBa0IsRUFBRTtBQUN6QztBQUNBLFNBQVMsYUFBYSxVQUFVO0NBRTlCLHFCQURzQixJQUFJLE9BQU8sZUFBZSxFQUFBLENBQUUsS0FBSyxRQUN2QyxHQUFHO0VBQ2pCLE1BQU0sR0FBRyxZQUFZLFNBQVMsTUFBTSxZQUFZO0VBQ2hELE9BQU87Q0FDVDtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaFRBLElBQU0sdUJBQU4sY0FBbUMsaUJBQWlCO0NBSWxELFlBQVksbUJBQW1CLFdBQVc7RUFDeEMsTUFBTTt3QkFKUixxQkFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBWSxFQUFBO3dCQUNaLHNCQUFxQixDQUFDLENBQUE7RUFHcEIsS0FBSyxvQkFBb0I7RUFDekIsSUFBSSxhQUFhLE1BQ2YsS0FBSyxZQUFZO0NBRXJCO0NBQ0EsY0FBYztFQUNaLE9BQU8sS0FBSyxtQkFBbUIsUUFDN0IsS0FBSyxtQkFBbUIsSUFBSSxDQUFDLENBQUM7Q0FFbEM7Q0FDQSxXQUFXLElBQUk7RUFDYixLQUFLLG1CQUFtQixLQUFLLEtBQUssa0JBQWtCLFdBQVcsRUFBRSxHQUFHLEtBQUssa0JBQWtCLGFBQWEsRUFBRSxDQUFDO0NBQzdHO0NBQ0EsY0FBYztFQUNaLE9BQU8sS0FBSztDQUNkO0NBQ0EsS0FBSyxjQUFjLE9BQU87O0VBQ3hCLE1BQU0sUUFBQSx3QkFBTyxLQUFLLGtCQUFrQixVQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFRO0VBQzVDLE9BQU8sS0FBSyxTQUFTLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSTtDQUMvQztDQUNBLG1CQUFtQixVQUFVO0VBQzNCLE1BQU0sTUFBTSxjQUFjLEtBQUssV0FBVyxRQUFRO0VBQ2xELE9BQU8sSUFBSSxTQUFTLElBQUksTUFBTSxNQUFNO0NBQ3RDO0NBQ0EsVUFBVSxPQUFPLE9BQU8sTUFBTSxhQUFhO0VBQ3pDLE1BQU0sTUFBTSxLQUFLLG1CQUFtQixPQUFPLHFCQUFxQixXQUFXLENBQUMsS0FBSyxLQUFLLGtCQUFrQjtFQUN4RyxLQUFLLGtCQUFrQixVQUFVLE9BQU8sT0FBTyxHQUFHO0NBQ3BEO0NBQ0EsYUFBYSxPQUFPLE9BQU8sTUFBTSxhQUFhO0VBQzVDLE1BQU0sTUFBTSxLQUFLLG1CQUFtQixPQUFPLHFCQUFxQixXQUFXLENBQUMsS0FBSyxLQUFLLGtCQUFrQjtFQUN4RyxLQUFLLGtCQUFrQixhQUFhLE9BQU8sT0FBTyxHQUFHO0NBQ3ZEO0NBQ0EsVUFBVTtFQUNSLEtBQUssa0JBQWtCLFFBQVE7Q0FDakM7Q0FDQSxPQUFPO0VBQ0wsS0FBSyxrQkFBa0IsS0FBSztDQUM5QjtDQUNBLFdBQVc7RUFDVCxPQUFPLEtBQUssa0JBQWtCLFNBQVM7Q0FDekM7Q0FDQSxVQUFVLG1CQUFtQixHQUFHOztFQUM5QixDQUFBLDBCQUFBLHlCQUFBLEtBQUssa0JBQUEsQ0FBa0IsZUFBQSxRQUFBLDJCQUFBLEtBQUEsS0FBQSx1QkFBQSxLQUFBLHdCQUFZLGdCQUFnQjtDQUNyRDtBQVNGOztzQ0FSUyxRQUFPLFNBQVMsNkJBQTZCLG1CQUFtQjtDQUVyRSxPQUFPLEtBQUsscUJBQXFCQyx1QkFBc0JDLFNBQVksZ0JBQWdCLEdBQUdBLFNBQVksZUFBZSxDQUFDLENBQUM7QUFDckgsQ0FBQTtzQ0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0Q7Q0FDUCxTQUFTQSxzQkFBcUI7QUFDaEMsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNFLGlCQUFxQixzQkFBc0IsQ0FBQyxFQUM3RixNQUFNLFdBQ1IsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNLGlCQUNSLEdBQUc7RUFDRCxNQUFNLEtBQUE7RUFDTixZQUFZLENBQUMsRUFDWCxNQUFNLFNBQ1IsR0FBRztHQUNELE1BQU07R0FDTixNQUFNLENBQUMsYUFBYTtFQUN0QixDQUFDO0NBQ0gsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLGdCQUFnQjtDQUNwQixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBSztDQUFDO0NBQ3pCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFLO0NBQUM7Q0FDekIsT0FBTyxDQUFDLEtBQUEsR0FBVyxJQUFJO0NBQ3ZCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsTUFBTSxHQUFHO0NBQ2pCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTyxDQUFDLElBQUk7Q0FDWixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTztFQUFDO0VBQU87RUFBSztDQUFDO0NBQ3JCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQUs7Q0FBQztDQUN6QixPQUFPLENBQUMsT0FBTyxHQUFHO0NBQ2xCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBSztDQUFDO0NBQ3pCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBSztDQUFDO0NBQ3pCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFNO0NBQUM7Q0FDMUIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQU07Q0FBQztDQUMxQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxJQUFJO0NBQ3ZCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBSztDQUFDO0NBQ3pCLE9BQU8sQ0FBQyxHQUFHO0NBQ1gsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsR0FBRztDQUNYLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLEtBQUs7Q0FDeEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBTTtDQUFDO0NBQzFCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQUs7Q0FBQztDQUN6QixPQUFPLENBQUMsT0FBTyxHQUFHO0NBQ2xCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFNO0NBQUM7Q0FDMUIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFNO0NBQUM7Q0FDMUIsT0FBTyxDQUFDLEdBQUc7Q0FDWCxPQUFPLENBQUMsR0FBRztDQUNYLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQU07Q0FBQztDQUMxQixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU87RUFBQztFQUFLLEtBQUE7RUFBVztDQUFDO0NBQ3pCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFNO0NBQUM7Q0FDMUIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFLO0NBQUM7Q0FDekIsT0FBTztFQUFDO0VBQUssS0FBQTtFQUFXO0NBQUM7Q0FDekIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBSztDQUFDO0NBQ3pCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBTTtDQUFDO0NBQzFCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsSUFBSTtDQUN2QixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxJQUFJO0NBQ3ZCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTyxDQUFDLEtBQUEsR0FBVyxJQUFJO0NBQ3ZCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFNO0NBQUM7Q0FDMUIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQUs7Q0FBQztDQUN6QixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQUs7Q0FBQztDQUN6QixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBTTtDQUFDO0NBQzFCLE9BQU8sQ0FBQyxPQUFPLEdBQUc7Q0FDbEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxJQUFJO0NBQ3ZCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxJQUFJO0NBQ3ZCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBTTtDQUFDO0NBQzFCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsSUFBSTtDQUN2QixPQUFPLENBQUMsT0FBTyxHQUFHO0NBQ2xCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTyxDQUFDLEdBQUc7Q0FDWCxPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQU07Q0FBQztDQUMxQixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFLO0NBQUM7Q0FDekIsT0FBTyxDQUFDLEtBQUEsR0FBVyxLQUFLO0NBQ3hCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBTTtDQUFDO0NBQzFCLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPO0VBQUMsS0FBQTtFQUFXO0VBQU07Q0FBQztDQUMxQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTztFQUFDLEtBQUE7RUFBVztFQUFLO0NBQUM7Q0FDekIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTyxDQUFDLEtBQUEsR0FBVyxHQUFHO0NBQ3RCLE9BQU87RUFBQztFQUFPO0VBQUs7Q0FBQztDQUNyQixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU8sQ0FBQyxLQUFBLEdBQVcsR0FBRztDQUN0QixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU8sQ0FBQyxHQUFHO0NBQ1gsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPO0VBQUMsS0FBQTtFQUFXLEtBQUE7RUFBVztDQUFDO0NBQy9CLE9BQU87RUFBQyxLQUFBO0VBQVc7RUFBTTtDQUFDO0NBQzFCLE9BQU87RUFBQztFQUFLLEtBQUE7RUFBVztDQUFDO0NBQ3pCLE9BQU87RUFBQyxLQUFBO0VBQVcsS0FBQTtFQUFXO0NBQUM7Q0FDL0IsT0FBTztFQUFDO0VBQVEsS0FBQTtFQUFXO0NBQUM7Q0FDNUIsT0FBTyxDQUFDLE9BQU8sR0FBRztDQUNsQixPQUFPLENBQUMsS0FBSztDQUNiLE9BQU87RUFBQztFQUFTLEtBQUE7RUFBVztDQUFDO0NBQzdCLE9BQU87RUFBQztFQUFRLEtBQUE7RUFBVztDQUFDO0NBQzVCLE9BQU8sQ0FBQyxHQUFHO0NBQ1gsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLEdBQUc7Q0FDdEIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztDQUMvQixPQUFPLENBQUMsS0FBQSxHQUFXLElBQUk7Q0FDdkIsT0FBTztFQUFDLEtBQUE7RUFBVyxLQUFBO0VBQVc7Q0FBQztBQUNqQztBQUNBLElBQUk7Q0FDSCxTQUFVLG1CQUFtQjtDQUM1QixrQkFBa0Isa0JBQWtCLGFBQWEsS0FBSztDQUN0RCxrQkFBa0Isa0JBQWtCLGFBQWEsS0FBSztDQUN0RCxrQkFBa0Isa0JBQWtCLGNBQWMsS0FBSztDQUN2RCxrQkFBa0Isa0JBQWtCLGdCQUFnQixLQUFLO0FBQzNELEVBQUEsQ0FBRyxzQkFBc0Isb0JBQW9CLENBQUMsRUFBRTtBQUNoRCxJQUFJO0NBQ0gsU0FBVSxRQUFRO0NBQ2pCLE9BQU8sT0FBTyxVQUFVLEtBQUs7Q0FDN0IsT0FBTyxPQUFPLFNBQVMsS0FBSztDQUM1QixPQUFPLE9BQU8sU0FBUyxLQUFLO0NBQzVCLE9BQU8sT0FBTyxTQUFTLEtBQUs7Q0FDNUIsT0FBTyxPQUFPLFVBQVUsS0FBSztDQUM3QixPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ2hDLEVBQUEsQ0FBRyxXQUFXLFNBQVMsQ0FBQyxFQUFFO0FBQzFCLElBQUk7Q0FDSCxTQUFVLFdBQVc7Q0FDcEIsVUFBVSxVQUFVLFlBQVksS0FBSztDQUNyQyxVQUFVLFVBQVUsZ0JBQWdCLEtBQUs7QUFDM0MsRUFBQSxDQUFHLGNBQWMsWUFBWSxDQUFDLEVBQUU7QUFDaEMsSUFBSTtDQUNILFNBQVUsa0JBQWtCO0NBQzNCLGlCQUFpQixpQkFBaUIsWUFBWSxLQUFLO0NBQ25ELGlCQUFpQixpQkFBaUIsaUJBQWlCLEtBQUs7Q0FDeEQsaUJBQWlCLGlCQUFpQixVQUFVLEtBQUs7Q0FDakQsaUJBQWlCLGlCQUFpQixXQUFXLEtBQUs7QUFDcEQsRUFBQSxDQUFHLHFCQUFxQixtQkFBbUIsQ0FBQyxFQUFFO0FBQzlDLElBQUk7Q0FDSCxTQUFVLGFBQWE7Q0FDdEIsWUFBWSxZQUFZLFdBQVcsS0FBSztDQUN4QyxZQUFZLFlBQVksWUFBWSxLQUFLO0NBQ3pDLFlBQVksWUFBWSxVQUFVLEtBQUs7Q0FDdkMsWUFBWSxZQUFZLFVBQVUsS0FBSztBQUN6QyxFQUFBLENBQUcsZ0JBQWdCLGNBQWMsQ0FBQyxFQUFFO0FBQ3BDLElBQU0sZUFBZTtDQUNuQixTQUFTO0NBQ1QsT0FBTztDQUNQLE1BQU07Q0FDTixhQUFhO0NBQ2IsVUFBVTtDQUNWLFdBQVc7Q0FDWCxhQUFhO0NBQ2Isd0JBQXdCO0NBQ3hCLFVBQVU7Q0FDVixVQUFVO0NBQ1YsS0FBSztDQUNMLGVBQWU7Q0FDZixpQkFBaUI7Q0FDakIsZUFBZTtBQUNqQjtBQUNBLElBQUk7Q0FDSCxTQUFVLFNBQVM7Q0FDbEIsUUFBUSxRQUFRLFlBQVksS0FBSztDQUNqQyxRQUFRLFFBQVEsWUFBWSxLQUFLO0NBQ2pDLFFBQVEsUUFBUSxhQUFhLEtBQUs7Q0FDbEMsUUFBUSxRQUFRLGVBQWUsS0FBSztDQUNwQyxRQUFRLFFBQVEsY0FBYyxLQUFLO0NBQ25DLFFBQVEsUUFBUSxZQUFZLEtBQUs7Q0FDakMsUUFBUSxRQUFRLGNBQWMsS0FBSztBQUNyQyxFQUFBLENBQUcsWUFBWSxVQUFVLENBQUMsRUFBRTtBQUM1QixTQUFTLFlBQVksUUFBUTtDQUMzQixPQUFPQyxlQUFnQixNQUFNLENBQUMsQ0FBQ0MsZ0JBQWlCO0FBQ2xEO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxXQUFXLE9BQU87Q0FDckQsTUFBTSxPQUFPRCxlQUFnQixNQUFNO0NBR25DLE9BQU8sb0JBRE0sb0JBQW9CLENBRGYsS0FBS0MsZ0JBQWlCLG1CQUFtQixLQUFLQSxnQkFBaUIscUJBQ3pDLEdBQUcsU0FDYixHQUFHLEtBQUs7QUFDeEM7QUFDQSxTQUFTLGtCQUFrQixRQUFRLFdBQVcsT0FBTztDQUNuRCxNQUFNLE9BQU9ELGVBQWdCLE1BQU07Q0FHbkMsT0FBTyxvQkFETSxvQkFBb0IsQ0FEZixLQUFLQyxnQkFBaUIsYUFBYSxLQUFLQSxnQkFBaUIsZUFDbkMsR0FBRyxTQUNiLEdBQUcsS0FBSztBQUN4QztBQUNBLFNBQVMsb0JBQW9CLFFBQVEsV0FBVyxPQUFPO0NBQ3JELE1BQU0sT0FBT0QsZUFBZ0IsTUFBTTtDQUduQyxPQUFPLG9CQURRLG9CQUFvQixDQURmLEtBQUtDLGdCQUFpQixlQUFlLEtBQUtBLGdCQUFpQixpQkFDbkMsR0FBRyxTQUNmLEdBQUcsS0FBSztBQUMxQztBQUNBLFNBQVMsa0JBQWtCLFFBQVEsT0FBTztDQUV4QyxNQUFNLFdBRE9ELGVBQWdCLE1BQ1QsQ0FBQyxDQUFDQyxnQkFBaUI7Q0FDdkMsT0FBTyxvQkFBb0IsVUFBVSxLQUFLO0FBQzVDO0FBQ0EsU0FBUyx3QkFBd0IsUUFBUTtDQUV2QyxPQURhRCxlQUFnQixNQUNuQixDQUFDLENBQUNDLGdCQUFpQjtBQUMvQjtBQUNBLFNBQVMsc0JBQXNCLFFBQVE7Q0FFckMsT0FEYUQsZUFBZ0IsTUFDbkIsQ0FBQyxDQUFDQyxnQkFBaUI7QUFDL0I7QUFDQSxTQUFTLG9CQUFvQixRQUFRLE9BQU87Q0FFMUMsT0FBTyxvQkFETUQsZUFBZ0IsTUFDQyxDQUFDLENBQUNDLGdCQUFpQixhQUFhLEtBQUs7QUFDckU7QUFDQSxTQUFTLG9CQUFvQixRQUFRLE9BQU87Q0FFMUMsT0FBTyxvQkFETUQsZUFBZ0IsTUFDQyxDQUFDLENBQUNDLGdCQUFpQixhQUFhLEtBQUs7QUFDckU7QUFDQSxTQUFTLHdCQUF3QixRQUFRLE9BQU87Q0FFOUMsTUFBTSxxQkFET0QsZUFBZ0IsTUFDQyxDQUFDLENBQUNDLGdCQUFpQjtDQUNqRCxPQUFPLG9CQUFvQixvQkFBb0IsS0FBSztBQUN0RDtBQUNBLFNBQVMsc0JBQXNCLFFBQVEsUUFBUTtDQUM3QyxNQUFNLE9BQU9ELGVBQWdCLE1BQU07Q0FDbkMsTUFBTSxNQUFNLEtBQUtDLGdCQUFpQixjQUFjLENBQUM7Q0FDakQsSUFBSSxPQUFPLFFBQVE7TUFDYixXQUFXLGFBQWEsaUJBQzFCLE9BQU8sS0FBS0EsZ0JBQWlCLGNBQWMsQ0FBQyxhQUFhO09BQ3BELElBQUksV0FBVyxhQUFhLGVBQ2pDLE9BQU8sS0FBS0EsZ0JBQWlCLGNBQWMsQ0FBQyxhQUFhO0NBQUE7Q0FHN0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxzQkFBc0IsUUFBUSxNQUFNO0NBRTNDLE9BRGFELGVBQWdCLE1BQ25CLENBQUMsQ0FBQ0MsZ0JBQWlCLGNBQWMsQ0FBQztBQUM5QztBQUNBLFNBQVMsd0JBQXdCLFFBQVE7Q0FFdkMsT0FEYUQsZUFBZ0IsTUFDbkIsQ0FBQyxDQUFDQyxnQkFBaUIsbUJBQW1CO0FBQ2xEO0FBQ0EsU0FBUyxzQkFBc0IsUUFBUTtDQUVyQyxPQURhRCxlQUFnQixNQUNuQixDQUFDLENBQUNDLGdCQUFpQixpQkFBaUI7QUFDaEQ7QUFDQSxTQUFTLHNCQUFzQixRQUFRO0NBQ3JDLE9BQU9DLHdCQUF1QixNQUFNO0FBQ3RDO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUTtDQUVuQyxPQURhRixlQUFnQixNQUNuQixDQUFDLENBQUNDLGdCQUFpQjtBQUMvQjtBQUNBLElBQU0sc0JBQXNCRTtBQUM1QixTQUFTLGNBQWMsTUFBTTtDQUMzQixJQUFJLENBQUMsS0FBS0YsZ0JBQWlCLFlBQ3pCLE1BQU0sSUFBSUcsYUFBYyxNQUFNLGFBQWEsNkNBQTZDLEtBQUtILGdCQUFpQixVQUFVLCtGQUErRjtBQUUzTjtBQUNBLFNBQVMsNkJBQTZCLFFBQVE7Q0FDNUMsTUFBTSxPQUFPRCxlQUFnQixNQUFNO0NBQ25DLGNBQWMsSUFBSTtDQUVsQixRQURjLEtBQUtDLGdCQUFpQixVQUFVLENBQUMsTUFBTSxDQUFDLEVBQUEsQ0FDekMsS0FBSSxTQUFRO0VBQ3ZCLElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU8sWUFBWSxJQUFJO0VBRXpCLE9BQU8sQ0FBQyxZQUFZLEtBQUssRUFBRSxHQUFHLFlBQVksS0FBSyxFQUFFLENBQUM7Q0FDcEQsQ0FBQztBQUNIO0FBQ0EsU0FBUyx5QkFBeUIsUUFBUSxXQUFXLE9BQU87Q0FDMUQsTUFBTSxPQUFPRCxlQUFnQixNQUFNO0NBQ25DLGNBQWMsSUFBSTtDQUdsQixPQUFPLG9CQURZLG9CQUFvQixDQURmLEtBQUtDLGdCQUFpQixVQUFVLENBQUMsSUFBSSxLQUFLQSxnQkFBaUIsVUFBVSxDQUFDLEVBQzFDLEdBQUcsU0FBUyxLQUFLLENBQUMsR0FDL0IsS0FBSyxLQUFLLENBQUM7QUFDcEQ7QUFDQSxTQUFTLG1CQUFtQixRQUFRO0NBRWxDLE9BRGFELGVBQWdCLE1BQ25CLENBQUMsQ0FBQ0MsZ0JBQWlCO0FBQy9CO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxPQUFPO0NBQ3hDLEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSSxJQUFJLEtBQzFCLElBQUksT0FBTyxLQUFLLE9BQU8sYUFDckIsT0FBTyxLQUFLO0NBR2hCLE1BQU0sSUFBSUcsYUFBYyxNQUFNLGFBQWEsd0NBQXdDO0FBQ3JGO0FBQ0EsU0FBUyxZQUFZLE1BQU07Q0FDekIsTUFBTSxDQUFDLEdBQUcsS0FBSyxLQUFLLE1BQU0sR0FBRztDQUM3QixPQUFPO0VBQ0wsT0FBTyxDQUFDO0VBQ1IsU0FBUyxDQUFDO0NBQ1o7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLE1BQU0sUUFBUSxTQUFTLE1BQU07Q0FDdEQsTUFBTSxXQUFXLG9CQUFvQixNQUFNLENBQUMsQ0FBQyxTQUFTLGNBQWMsU0FBUyxDQUFDO0NBQzlFLE1BQU0sZUFBZSxTQUFTO0NBQzlCLElBQUksV0FBVyxZQUFZLE9BQU8saUJBQWlCLFVBQ2pELE9BQU87Q0FFVCxPQUFPLFNBQVMsTUFBTTtBQUN4QjtBQUNBLElBQU0sZ0NBQWdDO0FBQ3RDLFNBQVMsMEJBQTBCLE1BQU07Q0FDdkMsSUFBSTtDQUNKLE1BQU0sV0FBVyxjQUFjO0NBQy9CLElBQUksVUFDRixTQUFTLFNBQVM7Q0FFcEIsT0FBTyxPQUFPLFdBQVcsV0FBVyxTQUFTO0FBQy9DO0FBQ0EsSUFBTSxxQkFBcUI7QUFDM0IsSUFBTSxnQkFBZ0IsT0FBTyxPQUFPLElBQUk7QUFDeEMsSUFBTSxxQkFBcUI7QUFDM0IsSUFBTSx5QkFBeUI7QUFDL0IsU0FBUyxXQUFXLE9BQU8sUUFBUSxRQUFRLFVBQVU7Q0FDbkQsSUFBSSxPQUFPLE9BQU8sS0FBSztDQUN2Qiw0QkFBNEIsTUFBTTtDQUVsQyxTQURvQixlQUFlLFFBQVEsTUFDeEIsS0FBSztDQUN4QixJQUFJLFFBQVEsQ0FBQztDQUNiLElBQUk7Q0FDSixPQUFPLFFBQVE7RUFDYixRQUFRLG1CQUFtQixLQUFLLE1BQU07RUFDdEMsSUFBSSxPQUFPO0dBQ1QsUUFBUSxNQUFNLE9BQU8sTUFBTSxNQUFNLENBQUMsQ0FBQztHQUNuQyxNQUFNLE9BQU8sTUFBTSxJQUFJO0dBQ3ZCLElBQUksQ0FBQyxNQUNIO0dBRUYsU0FBUztFQUNYLE9BQU87R0FDTCxNQUFNLEtBQUssTUFBTTtHQUNqQjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLHNCQUFzQixLQUFLO0NBRTdCLElBQUkscUJBQXFCLEtBQUssa0JBQWtCO0NBQ2hELElBQUksVUFBVTtFQUNaLHFCQUFxQixpQkFBaUIsVUFBVSxrQkFBa0I7RUFDbEUsT0FBTyx1QkFBdUIsTUFBTSxRQUFRO0NBQzlDO0NBQ0EsSUFBSSxPQUFPO0NBQ1gsTUFBTSxTQUFRLFVBQVM7RUFDckIsTUFBTSxnQkFBZ0IsaUJBQWlCLEtBQUs7RUFDNUMsUUFBUSxnQkFBZ0IsY0FBYyxNQUFNLFFBQVEsa0JBQWtCLElBQUksVUFBVSxPQUFPLE1BQU0sTUFBTSxRQUFRLFlBQVksRUFBRSxDQUFDLENBQUMsUUFBUSxPQUFPLEdBQUc7Q0FDbkosQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLFNBQVMsNEJBQTRCLFFBQVE7Q0FDM0MsSUFBSSxPQUFPLFNBQVMsd0JBQ2xCLE1BQU0sSUFBSUEsYUFBYyxNQUFNLGFBQWEsdURBQXVELHVCQUF1QixhQUFhO0FBRTFJO0FBQ0EsU0FBUyxzQkFBc0IsT0FBTztDQUNwQyxJQUFJLE1BQU0sTUFBSyxTQUFRLE9BQU8sS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sTUFBSyxTQUFRLE9BQU8sS0FBSyxJQUFJLENBQUMsR0FBRztFQUNuRixNQUFNLFVBQVUsMERBQTBELE1BQU0sS0FBSyxFQUFFLEVBQUU7RUFDekYsSUFBSSxNQUFNLFdBQVcsR0FDbkIsUUFBUSxNQUFNQyxtQkFBb0IsTUFBTSxPQUFPLENBQUM7T0FFaEQsTUFBTSxJQUFJRCxhQUFjLE1BQU0sT0FBTztDQUV6QztBQUNGO0FBQ0EsU0FBUyxXQUFXLE1BQU0sT0FBTyxNQUFNO0NBQ3JDLE1BQU0sMEJBQVUsSUFBSSxLQUFLLENBQUM7Q0FDMUIsUUFBUSxZQUFZLE1BQU0sT0FBTyxJQUFJO0NBQ3JDLFFBQVEsU0FBUyxHQUFHLEdBQUcsQ0FBQztDQUN4QixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsUUFBUSxRQUFROztDQUN0QyxNQUFNLFdBQVcsWUFBWSxNQUFNO0NBQ25DLENBQUEsd0JBQUEsY0FBYyxlQUFBLFFBQUEsMEJBQUEsS0FBQSxNQUFkLGNBQWMsWUFBYyxPQUFPLE9BQU8sSUFBSTtDQUM5QyxJQUFJLGNBQWMsU0FBUyxDQUFDLFNBQzFCLE9BQU8sY0FBYyxTQUFTLENBQUM7Q0FFakMsSUFBSSxjQUFjO0NBQ2xCLFFBQVEsUUFBUjtFQUNFLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksS0FBSztHQUMzRDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksTUFBTTtHQUM1RDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksSUFBSTtHQUMxRDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksSUFBSTtHQUMxRDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksS0FBSztHQUMzRDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksTUFBTTtHQUM1RDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksSUFBSTtHQUMxRDtFQUNGLEtBQUs7R0FDSCxjQUFjLG9CQUFvQixRQUFRLFlBQVksSUFBSTtHQUMxRDtFQUNGLEtBQUs7R0FDSCxNQUFNLFlBQVksZUFBZSxRQUFRLFdBQVc7R0FDcEQsTUFBTSxZQUFZLGVBQWUsUUFBUSxXQUFXO0dBQ3BELGNBQWMsZUFBZSx3QkFBd0IsUUFBUSxZQUFZLEtBQUssR0FBRyxDQUFDLFdBQVcsU0FBUyxDQUFDO0dBQ3ZHO0VBQ0YsS0FBSztHQUNILE1BQU0sYUFBYSxlQUFlLFFBQVEsWUFBWTtHQUN0RCxNQUFNLGFBQWEsZUFBZSxRQUFRLFlBQVk7R0FDdEQsY0FBYyxlQUFlLHdCQUF3QixRQUFRLFlBQVksTUFBTSxHQUFHLENBQUMsWUFBWSxVQUFVLENBQUM7R0FDMUc7RUFDRixLQUFLO0dBQ0gsTUFBTSxXQUFXLGVBQWUsUUFBUSxVQUFVO0dBQ2xELE1BQU0sV0FBVyxlQUFlLFFBQVEsVUFBVTtHQUNsRCxjQUFjLGVBQWUsd0JBQXdCLFFBQVEsWUFBWSxJQUFJLEdBQUcsQ0FBQyxVQUFVLFFBQVEsQ0FBQztHQUNwRztFQUNGLEtBQUs7R0FDSCxNQUFNLFdBQVcsZUFBZSxRQUFRLFVBQVU7R0FDbEQsTUFBTSxXQUFXLGVBQWUsUUFBUSxVQUFVO0dBQ2xELGNBQWMsZUFBZSx3QkFBd0IsUUFBUSxZQUFZLElBQUksR0FBRyxDQUFDLFVBQVUsUUFBUSxDQUFDO0dBQ3BHO0NBQ0o7Q0FDQSxJQUFJLGFBQ0YsY0FBYyxTQUFTLENBQUMsVUFBVTtDQUVwQyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsS0FBSyxZQUFZO0NBQ3ZDLElBQUksWUFDRixNQUFNLElBQUksUUFBUSxlQUFlLFNBQVUsT0FBTyxLQUFLO0VBQ3JELE9BQU8sT0FBTyxPQUFPLFlBQVksR0FBRyxJQUFJLFdBQVcsT0FBTztDQUM1RCxDQUFDO0NBRUgsT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEtBQUssUUFBUSxZQUFZLEtBQUssTUFBTSxTQUFTO0NBQzlELElBQUksTUFBTTtDQUNWLElBQUksTUFBTSxLQUFLLFdBQVcsT0FBTyxHQUMvQixJQUFJLFNBQ0YsTUFBTSxDQUFDLE1BQU07TUFDUjtFQUNMLE1BQU0sQ0FBQztFQUNQLE1BQU07Q0FDUjtDQUVGLElBQUksU0FBUyxPQUFPLEdBQUc7Q0FDdkIsT0FBTyxPQUFPLFNBQVMsUUFDckIsU0FBUyxNQUFNO0NBRWpCLElBQUksTUFDRixTQUFTLE9BQU8sTUFBTSxPQUFPLFNBQVMsTUFBTTtDQUU5QyxPQUFPLE1BQU07QUFDZjtBQUNBLFNBQVMsd0JBQXdCLGNBQWMsUUFBUTtDQUVyRCxPQURjLFVBQVUsY0FBYyxDQUMzQixDQUFDLENBQUMsVUFBVSxHQUFHLE1BQU07QUFDbEM7QUFDQSxTQUFTLFdBQVcsTUFBTSxNQUFNLFNBQVMsR0FBRyxPQUFPLE9BQU8sVUFBVSxPQUFPO0NBQ3pFLE9BQU8sU0FBVSxNQUFNLFFBQVE7RUFDN0IsSUFBSSxPQUFPLFlBQVksTUFBTSxJQUFJO0VBQ2pDLElBQUksU0FBUyxLQUFLLE9BQU8sQ0FBQyxRQUN4QixRQUFRO0VBRVYsSUFBSSxTQUFTO09BQ1AsU0FBUyxLQUFLLFdBQVcsS0FDM0IsT0FBTztFQUFBLE9BRUosSUFBSSxTQUFTLEdBQ2xCLE9BQU8sd0JBQXdCLE1BQU0sSUFBSTtFQUUzQyxNQUFNLGNBQWMsc0JBQXNCLFFBQVEsYUFBYSxTQUFTO0VBQ3hFLE9BQU8sVUFBVSxNQUFNLE1BQU0sYUFBYSxNQUFNLE9BQU87Q0FDekQ7QUFDRjtBQUNBLFNBQVMsWUFBWSxNQUFNLE1BQU07Q0FDL0IsUUFBUSxNQUFSO0VBQ0UsS0FBSyxHQUNILE9BQU8sS0FBSyxZQUFZO0VBQzFCLEtBQUssR0FDSCxPQUFPLEtBQUssU0FBUztFQUN2QixLQUFLLEdBQ0gsT0FBTyxLQUFLLFFBQVE7RUFDdEIsS0FBSyxHQUNILE9BQU8sS0FBSyxTQUFTO0VBQ3ZCLEtBQUssR0FDSCxPQUFPLEtBQUssV0FBVztFQUN6QixLQUFLLEdBQ0gsT0FBTyxLQUFLLFdBQVc7RUFDekIsS0FBSyxHQUNILE9BQU8sS0FBSyxnQkFBZ0I7RUFDOUIsS0FBSyxHQUNILE9BQU8sS0FBSyxPQUFPO0VBQ3JCLFNBQ0UsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSwyQkFBMkIsS0FBSyxHQUFHO0NBQ2xGO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsTUFBTSxPQUFPLE9BQU8sVUFBVSxRQUFRLFdBQVcsT0FBTztDQUM3RSxPQUFPLFNBQVUsTUFBTSxRQUFRO0VBQzdCLE9BQU8sbUJBQW1CLE1BQU0sUUFBUSxNQUFNLE9BQU8sTUFBTSxRQUFRO0NBQ3JFO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixNQUFNLFFBQVEsTUFBTSxPQUFPLE1BQU0sVUFBVTtDQUNyRSxRQUFRLE1BQVI7RUFDRSxLQUFLLEdBQ0gsT0FBTyxvQkFBb0IsUUFBUSxNQUFNLEtBQUssQ0FBQyxDQUFDLEtBQUssU0FBUztFQUNoRSxLQUFLLEdBQ0gsT0FBTyxrQkFBa0IsUUFBUSxNQUFNLEtBQUssQ0FBQyxDQUFDLEtBQUssT0FBTztFQUM1RCxLQUFLO0dBQ0gsTUFBTSxlQUFlLEtBQUssU0FBUztHQUNuQyxNQUFNLGlCQUFpQixLQUFLLFdBQVc7R0FDdkMsSUFBSSxVQUFVO0lBQ1osTUFBTSxRQUFRLDZCQUE2QixNQUFNO0lBQ2pELE1BQU0sYUFBYSx5QkFBeUIsUUFBUSxNQUFNLEtBQUs7SUFDL0QsTUFBTSxRQUFRLE1BQU0sV0FBVSxTQUFRO0tBQ3BDLElBQUksTUFBTSxRQUFRLElBQUksR0FBRztNQUN2QixNQUFNLENBQUMsTUFBTSxNQUFNO01BQ25CLE1BQU0sWUFBWSxnQkFBZ0IsS0FBSyxTQUFTLGtCQUFrQixLQUFLO01BQ3ZFLE1BQU0sV0FBVyxlQUFlLEdBQUcsU0FBUyxpQkFBaUIsR0FBRyxTQUFTLGlCQUFpQixHQUFHO01BQzdGLElBQUksS0FBSyxRQUFRLEdBQUc7V0FDZCxhQUFhLFVBQ2YsT0FBTztNQUFBLE9BRUosSUFBSSxhQUFhLFVBQ3RCLE9BQU87S0FFWCxPQUNFLElBQUksS0FBSyxVQUFVLGdCQUFnQixLQUFLLFlBQVksZ0JBQ2xELE9BQU87S0FHWCxPQUFPO0lBQ1QsQ0FBQztJQUNELElBQUksVUFBVSxJQUNaLE9BQU8sV0FBVztHQUV0QjtHQUNBLE9BQU8sb0JBQW9CLFFBQVEsTUFBTSxLQUFLLENBQUMsQ0FBQyxlQUFlLEtBQUssSUFBSTtFQUMxRSxLQUFLLEdBQ0gsT0FBTyxrQkFBa0IsUUFBUSxLQUFLLENBQUMsQ0FBQyxLQUFLLFlBQVksS0FBSyxJQUFJLElBQUk7RUFDeEU7R0FDRSxNQUFNLGFBQWE7R0FDbkIsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSwrQkFBK0IsWUFBWTtDQUMxRjtBQUNGO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxTQUFVLE1BQU0sUUFBUSxRQUFRO0VBQ3JDLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLE1BQU0sWUFBWSxzQkFBc0IsUUFBUSxhQUFhLFNBQVM7RUFDdEUsTUFBTSxRQUFRLE9BQU8sSUFBSSxLQUFLLE1BQU0sT0FBTyxFQUFFLElBQUksS0FBSyxLQUFLLE9BQU8sRUFBRTtFQUNwRSxRQUFRLE9BQVI7R0FDRSxLQUFLLEdBQ0gsUUFBUSxRQUFRLElBQUksTUFBTSxNQUFNLFVBQVUsT0FBTyxHQUFHLFNBQVMsSUFBSSxVQUFVLEtBQUssSUFBSSxPQUFPLEVBQUUsR0FBRyxHQUFHLFNBQVM7R0FDOUcsS0FBSyxHQUNILE9BQU8sU0FBUyxRQUFRLElBQUksTUFBTSxNQUFNLFVBQVUsT0FBTyxHQUFHLFNBQVM7R0FDdkUsS0FBSyxHQUNILE9BQU8sU0FBUyxRQUFRLElBQUksTUFBTSxNQUFNLFVBQVUsT0FBTyxHQUFHLFNBQVMsSUFBSSxNQUFNLFVBQVUsS0FBSyxJQUFJLE9BQU8sRUFBRSxHQUFHLEdBQUcsU0FBUztHQUM1SCxLQUFLLEdBQ0gsSUFBSSxXQUFXLEdBQ2IsT0FBTztRQUVQLFFBQVEsUUFBUSxJQUFJLE1BQU0sTUFBTSxVQUFVLE9BQU8sR0FBRyxTQUFTLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxPQUFPLEVBQUUsR0FBRyxHQUFHLFNBQVM7R0FFdEgsU0FDRSxNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLHVCQUF1QixNQUFNLEVBQUU7RUFDOUU7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxVQUFVO0FBQ2hCLElBQU0sV0FBVztBQUNqQixTQUFTLHVCQUF1QixNQUFNO0NBQ3BDLE1BQU0saUJBQWlCLFdBQVcsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU87Q0FDM0QsT0FBTyxXQUFXLE1BQU0sR0FBRyxLQUFLLGtCQUFrQixXQUFXLFdBQVcsTUFBZ0IsY0FBYztBQUN4RztBQUNBLFNBQVMsdUJBQXVCLFVBQVU7Q0FDeEMsTUFBTSxhQUFhLFNBQVMsT0FBTztDQUNuQyxNQUFNLGtCQUFrQixlQUFlLElBQUksS0FBSyxXQUFXO0NBQzNELE9BQU8sV0FBVyxTQUFTLFlBQVksR0FBRyxTQUFTLFNBQVMsR0FBRyxTQUFTLFFBQVEsSUFBSSxlQUFlO0FBQ3JHO0FBQ0EsU0FBUyxXQUFXLE1BQU0sYUFBYSxPQUFPO0NBQzVDLE9BQU8sU0FBVSxNQUFNLFFBQVE7RUFDN0IsSUFBSTtFQUNKLElBQUksWUFBWTtHQUNkLE1BQU0sNEJBQTRCLElBQUksS0FBSyxLQUFLLFlBQVksR0FBRyxLQUFLLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUk7R0FDOUYsTUFBTSxRQUFRLEtBQUssUUFBUTtHQUMzQixTQUFTLElBQUksS0FBSyxPQUFPLFFBQVEsNkJBQTZCLENBQUM7RUFDakUsT0FBTztHQUNMLE1BQU0sWUFBWSx1QkFBdUIsSUFBSTtHQUM3QyxNQUFNLGFBQWEsdUJBQXVCLFVBQVUsWUFBWSxDQUFDO0dBQ2pFLE1BQU0sT0FBTyxVQUFVLFFBQVEsSUFBSSxXQUFXLFFBQVE7R0FDdEQsU0FBUyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU87RUFDeEM7RUFDQSxPQUFPLFVBQVUsUUFBUSxNQUFNLHNCQUFzQixRQUFRLGFBQWEsU0FBUyxDQUFDO0NBQ3RGO0FBQ0Y7QUFDQSxTQUFTLHdCQUF3QixNQUFNLE9BQU8sT0FBTztDQUNuRCxPQUFPLFNBQVUsTUFBTSxRQUFRO0VBRzdCLE9BQU8sVUFGVyx1QkFBdUIsSUFDUCxDQUFDLENBQUMsWUFDSCxHQUFHLE1BQU0sc0JBQXNCLFFBQVEsYUFBYSxTQUFTLEdBQUcsSUFBSTtDQUN2RztBQUNGO0FBQ0EsSUFBTSxlQUFlLE9BQU8sT0FBTyxJQUFJO0FBQ3ZDLFNBQVMsaUJBQWlCLFFBQVE7Q0FDaEMsSUFBSSxhQUFhLFNBQ2YsT0FBTyxhQUFhO0NBRXRCLElBQUk7Q0FDSixRQUFRLFFBQVI7RUFDRSxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsV0FBVztHQUN6RDtFQUNGLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsSUFBSTtHQUNsRDtFQUNGLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsTUFBTTtHQUNwRDtFQUNGLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxHQUFHLEdBQUcsT0FBTyxJQUFJO0dBQzNDO0VBQ0YsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLEdBQUcsR0FBRyxNQUFNLElBQUk7R0FDMUM7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsR0FBRyxHQUFHLE9BQU8sSUFBSTtHQUMzQztFQUNGLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxHQUFHLEdBQUcsT0FBTyxJQUFJO0dBQzNDO0VBQ0YsS0FBSztHQUNILFlBQVksd0JBQXdCLENBQUM7R0FDckM7RUFDRixLQUFLO0dBQ0gsWUFBWSx3QkFBd0IsR0FBRyxJQUFJO0dBQzNDO0VBQ0YsS0FBSztHQUNILFlBQVksd0JBQXdCLENBQUM7R0FDckM7RUFDRixLQUFLO0dBQ0gsWUFBWSx3QkFBd0IsQ0FBQztHQUNyQztFQUNGLEtBQUs7RUFDTCxLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsR0FBRyxDQUFDO0dBQzlCO0VBQ0YsS0FBSztFQUNMLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxHQUFHLENBQUM7R0FDOUI7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLFdBQVc7R0FDekQ7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLElBQUk7R0FDbEQ7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLE1BQU07R0FDcEQ7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLGFBQWEsVUFBVSxVQUFVO0dBQy9FO0VBQ0YsS0FBSztHQUNILFlBQVksY0FBYyxHQUFHLGlCQUFpQixNQUFNLFVBQVUsVUFBVTtHQUN4RTtFQUNGLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsUUFBUSxVQUFVLFVBQVU7R0FDMUU7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLENBQUM7R0FDeEI7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLENBQUM7R0FDeEI7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsSUFBSTtHQUM5QjtFQUNGLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxDQUFDO0dBQzNCO0VBQ0YsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLENBQUM7R0FDM0I7RUFDRixLQUFLO0VBQ0wsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLENBQUM7R0FDM0I7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLGFBQWEsVUFBVSxVQUFVO0dBQy9FO0VBQ0YsS0FBSztHQUNILFlBQVksY0FBYyxHQUFHLGlCQUFpQixNQUFNLFVBQVUsVUFBVTtHQUN4RTtFQUNGLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsUUFBUSxVQUFVLFVBQVU7R0FDMUU7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLE9BQU8sVUFBVSxVQUFVO0dBQ3pFO0VBQ0YsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLFdBQVc7R0FDekQ7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLElBQUk7R0FDbEQ7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLE1BQU07R0FDcEQ7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLEtBQUs7R0FDbkQ7RUFDRixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsV0FBVztHQUN6RDtFQUNGLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsSUFBSTtHQUNsRDtFQUNGLEtBQUs7R0FDSCxZQUFZLGNBQWMsR0FBRyxpQkFBaUIsTUFBTTtHQUNwRDtFQUNGLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztHQUNILFlBQVksY0FBYyxHQUFHLGlCQUFpQixhQUFhLFVBQVUsWUFBWSxJQUFJO0dBQ3JGO0VBQ0YsS0FBSztHQUNILFlBQVksY0FBYyxHQUFHLGlCQUFpQixNQUFNLFVBQVUsWUFBWSxJQUFJO0dBQzlFO0VBQ0YsS0FBSztHQUNILFlBQVksY0FBYyxHQUFHLGlCQUFpQixRQUFRLFVBQVUsWUFBWSxJQUFJO0dBQ2hGO0VBQ0YsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLGFBQWEsVUFBVSxRQUFRLElBQUk7R0FDakY7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLE1BQU0sVUFBVSxRQUFRLElBQUk7R0FDMUU7RUFDRixLQUFLO0dBQ0gsWUFBWSxjQUFjLEdBQUcsaUJBQWlCLFFBQVEsVUFBVSxRQUFRLElBQUk7R0FDNUU7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsR0FBRyxHQUFHO0dBQ2hDO0VBQ0YsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLEdBQUcsR0FBRztHQUNoQztFQUNGLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxDQUFDO0dBQzNCO0VBQ0YsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLENBQUM7R0FDM0I7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsQ0FBQztHQUMzQjtFQUNGLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxDQUFDO0dBQzNCO0VBQ0YsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLENBQUM7R0FDM0I7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsQ0FBQztHQUMzQjtFQUNGLEtBQUs7R0FDSCxZQUFZLFdBQVcsR0FBRyxDQUFDO0dBQzNCO0VBQ0YsS0FBSztHQUNILFlBQVksV0FBVyxHQUFHLENBQUM7R0FDM0I7RUFDRixLQUFLO0dBQ0gsWUFBWSxXQUFXLEdBQUcsQ0FBQztHQUMzQjtFQUNGLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztHQUNILFlBQVksZUFBZSxDQUFDO0dBQzVCO0VBQ0YsS0FBSztHQUNILFlBQVksZUFBZSxDQUFDO0dBQzVCO0VBQ0YsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0dBQ0gsWUFBWSxlQUFlLENBQUM7R0FDNUI7RUFDRixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7R0FDSCxZQUFZLGVBQWUsQ0FBQztHQUM1QjtFQUNGLFNBQ0UsT0FBTztDQUNYO0NBQ0EsYUFBYSxVQUFVO0NBQ3ZCLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsVUFBVTtDQUM1QyxXQUFXLFNBQVMsUUFBUSxNQUFNLEVBQUU7Q0FDcEMsTUFBTSwwQkFBMEIsS0FBSyxNQUFNLDJCQUEyQixRQUFRLElBQUk7Q0FDbEYsT0FBTyxNQUFNLHVCQUF1QixJQUFJLFdBQVc7QUFDckQ7QUFDQSxTQUFTLGVBQWUsTUFBTSxTQUFTO0NBQ3JDLE9BQU8sSUFBSSxLQUFLLEtBQUssUUFBUSxDQUFDO0NBQzlCLEtBQUssV0FBVyxLQUFLLFdBQVcsSUFBSSxPQUFPO0NBQzNDLE9BQU87QUFDVDtBQUNBLFNBQVMsdUJBQXVCLE1BQU0sVUFBVSxTQUFTO0NBQ3ZELE1BQU0sZUFBZTtDQUNyQixNQUFNLHFCQUFxQixLQUFLLGtCQUFrQjtDQUVsRCxPQUFPLGVBQWUsTUFBTSxnQkFETCxpQkFBaUIsVUFBVSxrQkFDTyxJQUFJLG1CQUFtQjtBQUNsRjtBQUNBLFNBQVMsT0FBTyxPQUFPO0NBQ3JCLElBQUksT0FBTyxLQUFLLEdBQ2QsT0FBTztDQUVULElBQUksT0FBTyxVQUFVLFlBQVksQ0FBQyxNQUFNLEtBQUssR0FDM0MsT0FBTyxJQUFJLEtBQUssS0FBSztDQUV2QixJQUFJLE9BQU8sVUFBVSxVQUFVO0VBQzdCLFFBQVEsTUFBTSxLQUFLO0VBQ25CLElBQUksa0NBQWtDLEtBQUssS0FBSyxHQUFHO0dBQ2pELE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUksUUFBTyxDQUFDLEdBQUc7R0FDMUQsT0FBTyxXQUFXLEdBQUcsSUFBSSxHQUFHLENBQUM7RUFDL0I7RUFDQSxNQUFNLFdBQVcsV0FBVyxLQUFLO0VBQ2pDLElBQUksQ0FBQyxNQUFNLFFBQVEsUUFBUSxHQUN6QixPQUFPLElBQUksS0FBSyxRQUFRO0VBRTFCLElBQUk7RUFDSixJQUFJLFFBQVEsTUFBTSxNQUFNLGtCQUFrQixHQUN4QyxPQUFPLGdCQUFnQixLQUFLO0NBRWhDO0NBQ0EsTUFBTSxPQUFPLElBQUksS0FBSyxLQUFLO0NBQzNCLElBQUksQ0FBQyxPQUFPLElBQUksR0FDZCxNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLHNCQUFzQixNQUFNLGNBQWM7Q0FFdkYsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixNQUFNLHVCQUFPLElBQUksS0FBSyxDQUFDO0NBQ3ZCLElBQUksU0FBUztDQUNiLElBQUksUUFBUTtDQUNaLE1BQU0sYUFBYSxNQUFNLEtBQUssS0FBSyxpQkFBaUIsS0FBSztDQUN6RCxNQUFNLGFBQWEsTUFBTSxLQUFLLEtBQUssY0FBYyxLQUFLO0NBQ3RELElBQUksTUFBTSxJQUFJO0VBQ1osU0FBUyxPQUFPLE1BQU0sS0FBSyxNQUFNLEdBQUc7RUFDcEMsUUFBUSxPQUFPLE1BQU0sS0FBSyxNQUFNLEdBQUc7Q0FDckM7Q0FDQSxXQUFXLEtBQUssTUFBTSxPQUFPLE1BQU0sRUFBRSxHQUFHLE9BQU8sTUFBTSxFQUFFLElBQUksR0FBRyxPQUFPLE1BQU0sRUFBRSxDQUFDO0NBQzlFLE1BQU0sSUFBSSxPQUFPLE1BQU0sTUFBTSxDQUFDLElBQUk7Q0FDbEMsTUFBTSxJQUFJLE9BQU8sTUFBTSxNQUFNLENBQUMsSUFBSTtDQUNsQyxNQUFNLElBQUksT0FBTyxNQUFNLE1BQU0sQ0FBQztDQUM5QixNQUFNLEtBQUssS0FBSyxNQUFNLFdBQVcsUUFBUSxNQUFNLE1BQU0sRUFBRSxJQUFJLEdBQUk7Q0FDL0QsV0FBVyxLQUFLLE1BQU0sR0FBRyxHQUFHLEdBQUcsRUFBRTtDQUNqQyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLE9BQU8sT0FBTztDQUNyQixPQUFPLGlCQUFpQixRQUFRLENBQUMsTUFBTSxNQUFNLFFBQVEsQ0FBQztBQUN4RDtBQUNBLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sYUFBYTtBQUNuQixJQUFNLGNBQWM7QUFDcEIsSUFBTSxZQUFZO0FBQ2xCLElBQU0sY0FBYztBQUNwQixJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sZUFBZTtBQUNyQixTQUFTLDJCQUEyQixPQUFPLFNBQVMsUUFBUSxhQUFhLGVBQWUsWUFBWSxZQUFZLE9BQU87Q0FDckgsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxTQUFTO0NBQ2IsSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUNqQixnQkFBZ0Isc0JBQXNCLFFBQVEsYUFBYSxRQUFRO01BQzlEO0VBQ0wsSUFBSSxlQUFlLFlBQVksS0FBSztFQUNwQyxJQUFJLFdBQ0YsZUFBZSxVQUFVLFlBQVk7RUFFdkMsSUFBSSxTQUFTLFFBQVE7RUFDckIsSUFBSSxjQUFjLFFBQVE7RUFDMUIsSUFBSSxjQUFjLFFBQVE7RUFDMUIsSUFBSSxZQUFZO0dBQ2QsTUFBTSxRQUFRLFdBQVcsTUFBTSxvQkFBb0I7R0FDbkQsSUFBSSxVQUFVLE1BQ1osTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSxHQUFHLFdBQVcsMkJBQTJCO0dBRXRGLE1BQU0sYUFBYSxNQUFNO0dBQ3pCLE1BQU0sa0JBQWtCLE1BQU07R0FDOUIsTUFBTSxrQkFBa0IsTUFBTTtHQUM5QixJQUFJLGNBQWMsTUFDaEIsU0FBUyxrQkFBa0IsVUFBVTtHQUV2QyxJQUFJLG1CQUFtQixNQUNyQixjQUFjLGtCQUFrQixlQUFlO0dBRWpELElBQUksbUJBQW1CLE1BQ3JCLGNBQWMsa0JBQWtCLGVBQWU7UUFDMUMsSUFBSSxtQkFBbUIsUUFBUSxjQUFjLGFBQ2xELGNBQWM7R0FFaEIsTUFBTSxxQkFBcUI7R0FDM0IsSUFBSSxTQUFTLHNCQUFzQixjQUFjLHNCQUFzQixjQUFjLG9CQUNuRixNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLEdBQUcsV0FBVyx5REFBeUQsbUJBQW1CLFNBQVM7RUFFbEo7RUFDQSxZQUFZLGNBQWMsYUFBYSxXQUFXO0VBQ2xELElBQUksU0FBUyxhQUFhO0VBQzFCLElBQUksYUFBYSxhQUFhO0VBQzlCLE1BQU0sV0FBVyxhQUFhO0VBQzlCLElBQUksV0FBVyxDQUFDO0VBQ2hCLFNBQVMsT0FBTyxPQUFNLE1BQUssQ0FBQyxDQUFDO0VBQzdCLE9BQU8sYUFBYSxRQUFRLGNBQzFCLE9BQU8sUUFBUSxDQUFDO0VBRWxCLE9BQU8sYUFBYSxHQUFHLGNBQ3JCLE9BQU8sUUFBUSxDQUFDO0VBRWxCLElBQUksYUFBYSxHQUNmLFdBQVcsT0FBTyxPQUFPLFlBQVksT0FBTyxNQUFNO09BQzdDO0dBQ0wsV0FBVztHQUNYLFNBQVMsQ0FBQyxDQUFDO0VBQ2I7RUFDQSxNQUFNLFNBQVMsQ0FBQztFQUNoQixJQUFJLE9BQU8sVUFBVSxRQUFRLFFBQzNCLE9BQU8sUUFBUSxPQUFPLE9BQU8sQ0FBQyxRQUFRLFFBQVEsT0FBTyxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztFQUV2RSxPQUFPLE9BQU8sU0FBUyxRQUFRLE9BQzdCLE9BQU8sUUFBUSxPQUFPLE9BQU8sQ0FBQyxRQUFRLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztFQUV0RSxJQUFJLE9BQU8sUUFDVCxPQUFPLFFBQVEsT0FBTyxLQUFLLEVBQUUsQ0FBQztFQUVoQyxnQkFBZ0IsT0FBTyxLQUFLLHNCQUFzQixRQUFRLFdBQVcsQ0FBQztFQUN0RSxJQUFJLFNBQVMsUUFDWCxpQkFBaUIsc0JBQXNCLFFBQVEsYUFBYSxJQUFJLFNBQVMsS0FBSyxFQUFFO0VBRWxGLElBQUksVUFDRixpQkFBaUIsc0JBQXNCLFFBQVEsYUFBYSxXQUFXLElBQUksTUFBTTtDQUVyRjtDQUNBLElBQUksUUFBUSxLQUFLLENBQUMsUUFDaEIsZ0JBQWdCLFFBQVEsU0FBUyxnQkFBZ0IsUUFBUTtNQUV6RCxnQkFBZ0IsUUFBUSxTQUFTLGdCQUFnQixRQUFRO0NBRTNELE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxPQUFPLFFBQVEsVUFBVSxjQUFjLFlBQVk7Q0FFekUsTUFBTSxVQUFVLGtCQURELHNCQUFzQixRQUFRLGtCQUFrQixRQUN4QixHQUFHLHNCQUFzQixRQUFRLGFBQWEsU0FBUyxDQUFDO0NBQy9GLFFBQVEsVUFBVSwwQkFBMEIsWUFBWTtDQUN4RCxRQUFRLFVBQVUsUUFBUTtDQUUxQixPQURZLDJCQUEyQixPQUFPLFNBQVMsUUFBUSxhQUFhLGVBQWUsYUFBYSxpQkFBaUIsVUFDaEgsQ0FBQyxDQUFDLFFBQVEsZUFBZSxRQUFRLENBQUMsQ0FBQyxRQUFRLGVBQWUsRUFBRSxDQUFDLENBQUMsS0FBSztBQUM5RTtBQUNBLFNBQVMsY0FBYyxPQUFPLFFBQVEsWUFBWTtDQUloRCxPQURZLDJCQUEyQixPQUR2QixrQkFERCxzQkFBc0IsUUFBUSxrQkFBa0IsT0FDeEIsR0FBRyxzQkFBc0IsUUFBUSxhQUFhLFNBQVMsQ0FDMUMsR0FBRyxRQUFRLGFBQWEsT0FBTyxhQUFhLFNBQVMsWUFBWSxJQUM1RyxDQUFDLENBQUMsUUFBUSxJQUFJLE9BQU8sY0FBYyxHQUFHLEdBQUcsc0JBQXNCLFFBQVEsYUFBYSxXQUFXLENBQUM7QUFDM0c7QUFDQSxTQUFTLGFBQWEsT0FBTyxRQUFRLFlBQVk7Q0FHL0MsT0FBTywyQkFBMkIsT0FEbEIsa0JBREQsc0JBQXNCLFFBQVEsa0JBQWtCLE9BQ3hCLEdBQUcsc0JBQXNCLFFBQVEsYUFBYSxTQUFTLENBQy9DLEdBQUcsUUFBUSxhQUFhLE9BQU8sYUFBYSxTQUFTLFVBQVU7QUFDaEg7QUFDQSxTQUFTLGtCQUFrQixRQUFRLFlBQVksS0FBSztDQUNsRCxNQUFNLElBQUk7RUFDUixRQUFRO0VBQ1IsU0FBUztFQUNULFNBQVM7RUFDVCxRQUFRO0VBQ1IsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0VBQ1IsT0FBTztFQUNQLFFBQVE7Q0FDVjtDQUNBLE1BQU0sZUFBZSxPQUFPLE1BQU0sV0FBVztDQUM3QyxNQUFNLFdBQVcsYUFBYTtDQUM5QixNQUFNLFdBQVcsYUFBYTtDQUM5QixNQUFNLGdCQUFnQixTQUFTLFFBQVEsV0FBVyxNQUFNLEtBQUssU0FBUyxNQUFNLFdBQVcsSUFBSSxDQUFDLFNBQVMsVUFBVSxHQUFHLFNBQVMsWUFBWSxTQUFTLElBQUksQ0FBQyxHQUFHLFNBQVMsVUFBVSxTQUFTLFlBQVksU0FBUyxJQUFJLENBQUMsQ0FBQyxHQUM3TSxVQUFVLGNBQWMsSUFDeEIsV0FBVyxjQUFjLE1BQU07Q0FDakMsRUFBRSxTQUFTLFFBQVEsVUFBVSxHQUFHLFFBQVEsUUFBUSxVQUFVLENBQUM7Q0FDM0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sS0FBSyxTQUFTLE9BQU8sQ0FBQztFQUM1QixJQUFJLE9BQU8sV0FDVCxFQUFFLFVBQVUsRUFBRSxVQUFVLElBQUk7T0FDdkIsSUFBSSxPQUFPLFlBQ2hCLEVBQUUsVUFBVSxJQUFJO09BRWhCLEVBQUUsVUFBVTtDQUVoQjtDQUNBLE1BQU0sU0FBUyxRQUFRLE1BQU0sU0FBUztDQUN0QyxFQUFFLFFBQVEsT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDLFNBQVM7Q0FDekMsRUFBRSxTQUFTLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU8sR0FBQSxDQUFJLFNBQVM7Q0FDdEUsSUFBSSxVQUFVO0VBQ1osTUFBTSxXQUFXLFNBQVMsU0FBUyxFQUFFLE9BQU8sU0FBUyxFQUFFLE9BQU8sUUFDNUQsTUFBTSxTQUFTLFFBQVEsVUFBVTtFQUNuQyxFQUFFLFNBQVMsU0FBUyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUMsUUFBUSxNQUFNLEVBQUU7RUFDdEQsRUFBRSxTQUFTLFNBQVMsTUFBTSxNQUFNLFFBQVEsQ0FBQyxDQUFDLFFBQVEsTUFBTSxFQUFFO0NBQzVELE9BQU87RUFDTCxFQUFFLFNBQVMsWUFBWSxFQUFFO0VBQ3pCLEVBQUUsU0FBUyxFQUFFO0NBQ2Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsY0FBYztDQUMvQixJQUFJLGFBQWEsT0FBTyxPQUFPLEdBQzdCLE9BQU87Q0FFVCxNQUFNLGNBQWMsYUFBYSxPQUFPLFNBQVMsYUFBYTtDQUM5RCxJQUFJLGFBQWEsVUFDZixhQUFhLFlBQVk7TUFDcEI7RUFDTCxJQUFJLGdCQUFnQixHQUNsQixhQUFhLE9BQU8sS0FBSyxHQUFHLENBQUM7T0FDeEIsSUFBSSxnQkFBZ0IsR0FDekIsYUFBYSxPQUFPLEtBQUssQ0FBQztFQUU1QixhQUFhLGNBQWM7Q0FDN0I7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFlBQVksS0FBSztDQUN4QixJQUFJLFNBQVMsS0FBSyxJQUFJLEdBQUcsSUFBSTtDQUM3QixJQUFJLFdBQVcsR0FDYixRQUNBO0NBQ0YsSUFBSSxHQUFHLEdBQUc7Q0FDVixLQUFLLGFBQWEsT0FBTyxRQUFRLFdBQVcsS0FBSyxJQUMvQyxTQUFTLE9BQU8sUUFBUSxhQUFhLEVBQUU7Q0FFekMsS0FBSyxJQUFJLE9BQU8sT0FBTyxJQUFJLEtBQUssR0FBRztFQUNqQyxJQUFJLGFBQWEsR0FBRyxhQUFhO0VBQ2pDLGNBQWMsQ0FBQyxPQUFPLE1BQU0sSUFBSSxDQUFDO0VBQ2pDLFNBQVMsT0FBTyxVQUFVLEdBQUcsQ0FBQztDQUNoQyxPQUFPLElBQUksYUFBYSxHQUN0QixhQUFhLE9BQU87Q0FFdEIsS0FBSyxJQUFJLEdBQUcsT0FBTyxPQUFPLENBQUMsTUFBTSxXQUFXO0NBQzVDLElBQUksT0FBTyxRQUFRLE9BQU8sU0FBUztFQUNqQyxTQUFTLENBQUMsQ0FBQztFQUNYLGFBQWE7Q0FDZixPQUFPO0VBQ0w7RUFDQSxPQUFPLE9BQU8sT0FBTyxLQUFLLE1BQU0sV0FBVztFQUMzQyxjQUFjO0VBQ2QsU0FBUyxDQUFDO0VBQ1YsS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssS0FDM0IsT0FBTyxLQUFLLE9BQU8sT0FBTyxPQUFPLENBQUMsQ0FBQztDQUV2QztDQUNBLElBQUksYUFBYSxZQUFZO0VBQzNCLFNBQVMsT0FBTyxPQUFPLEdBQUcsYUFBYSxDQUFDO0VBQ3hDLFdBQVcsYUFBYTtFQUN4QixhQUFhO0NBQ2Y7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsWUFBWSxjQUFjLFNBQVMsU0FBUztDQUNuRCxJQUFJLFVBQVUsU0FDWixNQUFNLElBQUlBLGFBQWMsTUFBTSxhQUFhLGdEQUFnRCxRQUFRLGdDQUFnQyxRQUFRLEdBQUc7Q0FFaEosSUFBSSxTQUFTLGFBQWE7Q0FDMUIsSUFBSSxjQUFjLE9BQU8sU0FBUyxhQUFhO0NBQy9DLE1BQU0sZUFBZSxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsV0FBVyxHQUFHLE9BQU87Q0FDckUsSUFBSSxVQUFVLGVBQWUsYUFBYTtDQUMxQyxJQUFJLFFBQVEsT0FBTztDQUNuQixJQUFJLFVBQVUsR0FBRztFQUNmLE9BQU8sT0FBTyxLQUFLLElBQUksYUFBYSxZQUFZLE9BQU8sQ0FBQztFQUN4RCxLQUFLLElBQUksSUFBSSxTQUFTLElBQUksT0FBTyxRQUFRLEtBQ3ZDLE9BQU8sS0FBSztDQUVoQixPQUFPO0VBQ0wsY0FBYyxLQUFLLElBQUksR0FBRyxXQUFXO0VBQ3JDLGFBQWEsYUFBYTtFQUMxQixPQUFPLFNBQVMsS0FBSyxJQUFJLEdBQUcsVUFBVSxlQUFlLENBQUM7RUFDdEQsT0FBTyxLQUFLO0VBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsS0FBSyxPQUFPLEtBQUs7Q0FDaEQ7Q0FDQSxJQUFJLFNBQVMsR0FDWCxJQUFJLFVBQVUsSUFBSSxHQUFHO0VBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLEtBQUs7R0FDaEMsT0FBTyxRQUFRLENBQUM7R0FDaEIsYUFBYTtFQUNmO0VBQ0EsT0FBTyxRQUFRLENBQUM7RUFDaEIsYUFBYTtDQUNmLE9BQ0UsT0FBTyxVQUFVLEVBQUU7Q0FHdkIsT0FBTyxjQUFjLEtBQUssSUFBSSxHQUFHLFlBQVksR0FBRyxlQUFlLE9BQU8sS0FBSyxDQUFDO0NBQzVFLElBQUksb0JBQW9CLGlCQUFpQjtDQUN6QyxNQUFNLFNBQVMsVUFBVSxhQUFhO0NBQ3RDLE1BQU0sUUFBUSxPQUFPLFlBQVksU0FBVSxPQUFPLEdBQUcsR0FBRyxRQUFRO0VBQzlELElBQUksSUFBSTtFQUNSLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJO0VBQzdCLElBQUksbUJBQ0YsSUFBSSxPQUFPLE9BQU8sS0FBSyxLQUFLLFFBQzFCLE9BQU8sSUFBSTtPQUVYLG9CQUFvQjtFQUd4QixPQUFPLEtBQUssS0FBSyxJQUFJO0NBQ3ZCLEdBQUcsQ0FBQztDQUNKLElBQUksT0FBTztFQUNULE9BQU8sUUFBUSxLQUFLO0VBQ3BCLGFBQWE7Q0FDZjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUMvQixNQUFNLFNBQVMsU0FBUyxJQUFJO0NBQzVCLElBQUksTUFBTSxNQUFNLEdBQ2QsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSwwQ0FBMEMsSUFBSTtDQUUzRixPQUFPO0FBQ1Q7QUFDQSxJQUFNLGlCQUFOLE1BQXFCLENBUXJCOztnQ0FQUyxRQUFPLFNBQVMsdUJBQXVCLG1CQUFtQjtDQUMvRCxPQUFPLEtBQUsscUJBQXFCRSxpQkFBZ0I7QUFDbkQsQ0FBQTtnQ0FDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxzQkFBc0IsSUFBSSxxQkFBcUIsT0FBTyxTQUFTLENBQUMsRUFBQSxDQUFHO0FBQ3JFLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjUCxpQkFBcUIsZ0JBQWdCLENBQUM7RUFDdkYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLGVBQWUsSUFBSSxxQkFBcUIsT0FBTyxTQUFTLENBQUMsRUFDM0QsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyxrQkFBa0IsT0FBTyxPQUFPLGdCQUFnQixRQUFRO0NBQy9ELElBQUksTUFBTSxJQUFJO0NBQ2QsSUFBSSxNQUFNLFFBQVEsR0FBRyxJQUFJLElBQ3ZCLE9BQU87Q0FFVCxNQUFNLGVBQWUsa0JBQWtCLE9BQU8sTUFBTTtDQUNwRCxJQUFJLE1BQU0sUUFBUSxHQUFHLElBQUksSUFDdkIsT0FBTztDQUVULElBQUksTUFBTSxRQUFRLE9BQU8sSUFBSSxJQUMzQixPQUFPO0NBRVQsTUFBTSxJQUFJSyxhQUFjLE1BQU0sYUFBYSxzQ0FBc0MsTUFBTSxFQUFFO0FBQzNGO0FBQ0EsSUFBTSx1QkFBTixjQUFtQyxlQUFlO0NBRWhELFlBQVksUUFBUTtFQUNsQixNQUFNO3dCQUZSLFVBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxTQUFTO0NBQ2hCO0NBQ0Esa0JBQWtCLE9BQU8sUUFBUTtFQUUvQixRQURlLG9CQUFvQixVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsS0FDN0MsR0FBYjtHQUNFLEtBQUssT0FBTyxNQUNWLE9BQU87R0FDVCxLQUFLLE9BQU8sS0FDVixPQUFPO0dBQ1QsS0FBSyxPQUFPLEtBQ1YsT0FBTztHQUNULEtBQUssT0FBTyxLQUNWLE9BQU87R0FDVCxLQUFLLE9BQU8sTUFDVixPQUFPO0dBQ1QsU0FDRSxPQUFPO0VBQ1g7Q0FDRjtBQVNGOztzQ0FSUyxRQUFPLFNBQVMsNkJBQTZCLG1CQUFtQjtDQUVyRSxPQUFPLEtBQUsscUJBQXFCRyx1QkFBc0JULFNBQVksU0FBUyxDQUFDO0FBQy9FLENBQUE7c0NBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9TO0NBQ1AsU0FBU0Esc0JBQXFCO0FBQ2hDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjUixpQkFBcUIsc0JBQXNCLENBQUMsRUFDN0YsTUFBTSxXQUNSLENBQUMsU0FBUyxDQUFDO0VBQ1QsTUFBTSxLQUFBO0VBQ04sWUFBWSxDQUFDO0dBQ1gsTUFBTTtHQUNOLE1BQU0sQ0FBQyxTQUFTO0VBQ2xCLENBQUM7Q0FDSCxDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sWUFBWTtBQUNsQixJQUFNLGNBQWMsQ0FBQztBQUNyQixJQUFNLFVBQU4sTUFBYztDQU1aLFlBQVksT0FBTyxXQUFXO3dCQUw5QixTQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBaUIsV0FBQTt3QkFDakIsWUFBQSxLQUFBLENBQUE7d0JBQ0EsNEJBQVcsSUFBSSxJQUFJLENBQUE7RUFFakIsS0FBSyxRQUFRO0VBQ2IsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsSUFBSSxNQUFNLE9BQU87RUFDZixLQUFLLGlCQUFpQixTQUFTLE9BQU8sTUFBTSxLQUFLLENBQUMsQ0FBQyxNQUFNLFNBQVMsSUFBSTtDQUN4RTtDQUNBLElBQUksUUFBUSxPQUFPO0VBQ2pCLEtBQUssV0FBVyxPQUFPLFVBQVUsV0FBVyxNQUFNLEtBQUssQ0FBQyxDQUFDLE1BQU0sU0FBUyxJQUFJO0NBQzlFO0NBQ0EsWUFBWTtFQUNWLEtBQUssTUFBTSxTQUFTLEtBQUssZ0JBQ3ZCLEtBQUssYUFBYSxPQUFPLElBQUk7RUFFL0IsTUFBTSxXQUFXLEtBQUs7RUFDdEIsSUFBSSxNQUFNLFFBQVEsUUFBUSxLQUFLLG9CQUFvQixLQUNqRCxLQUFLLE1BQU0sU0FBUyxVQUNsQixLQUFLLGFBQWEsT0FBTyxJQUFJO09BRTFCLElBQUksWUFBWSxNQUNyQixLQUFLLE1BQU0sU0FBUyxPQUFPLEtBQUssUUFBUSxHQUN0QyxLQUFLLGFBQWEsT0FBTyxRQUFRLFNBQVMsTUFBTSxDQUFDO0VBR3JELEtBQUssZ0JBQWdCO0NBQ3ZCO0NBQ0EsYUFBYSxPQUFPLGFBQWE7RUFDL0IsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUs7RUFDckMsSUFBSSxVQUFVLEtBQUEsR0FBVztHQUN2QixJQUFJLE1BQU0sWUFBWSxhQUFhO0lBQ2pDLE1BQU0sVUFBVTtJQUNoQixNQUFNLFVBQVU7R0FDbEI7R0FDQSxNQUFNLFVBQVU7RUFDbEIsT0FDRSxLQUFLLFNBQVMsSUFBSSxPQUFPO0dBQ3ZCLFNBQVM7R0FDVCxTQUFTO0dBQ1QsU0FBUztFQUNYLENBQUM7Q0FFTDtDQUNBLGtCQUFrQjtFQUNoQixLQUFLLE1BQU0sY0FBYyxLQUFLLFVBQVU7R0FDdEMsTUFBTSxRQUFRLFdBQVc7R0FDekIsTUFBTSxRQUFRLFdBQVc7R0FDekIsSUFBSSxNQUFNLFNBQVM7SUFDakIsS0FBSyxhQUFhLE9BQU8sTUFBTSxPQUFPO0lBQ3RDLE1BQU0sVUFBVTtHQUNsQixPQUFPLElBQUksQ0FBQyxNQUFNLFNBQVM7SUFDekIsSUFBSSxNQUFNLFNBQ1IsS0FBSyxhQUFhLE9BQU8sS0FBSztJQUVoQyxLQUFLLFNBQVMsT0FBTyxLQUFLO0dBQzVCO0dBQ0EsTUFBTSxVQUFVO0VBQ2xCO0NBQ0Y7Q0FDQSxhQUFhLE9BQU8sU0FBUztFQUMzQixJQUFJO09BQ0UsT0FBTyxVQUFVLFVBQ25CLE1BQU0sSUFBSSxNQUFNLGlFQUFpRVMsVUFBVyxLQUFLLEdBQUc7RUFBQTtFQUd4RyxRQUFRLE1BQU0sS0FBSztFQUNuQixJQUFJLE1BQU0sU0FBUyxHQUNqQixNQUFNLE1BQU0sU0FBUyxDQUFDLENBQUMsU0FBUSxVQUFTO0dBQ3RDLElBQUksU0FDRixLQUFLLFVBQVUsU0FBUyxLQUFLLE1BQU0sZUFBZSxLQUFLO1FBRXZELEtBQUssVUFBVSxZQUFZLEtBQUssTUFBTSxlQUFlLEtBQUs7RUFFOUQsQ0FBQztDQUVMO0FBYUY7O3lCQVpTLFFBQU8sU0FBUyxnQkFBZ0IsbUJBQW1CO0NBRXhELE9BQU8sS0FBSyxxQkFBcUJDLFVBQVNDLGtCQUFxQkMsVUFBYSxHQUFHRCxrQkFBcUJFLFNBQVksQ0FBQztBQUNuSCxDQUFBO3lCQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNSDtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQUk7RUFBVztDQUFFLENBQUM7Q0FDL0IsUUFBUTtFQUNOLE9BQU87R0FBQztHQUFHO0dBQVM7RUFBTztFQUMzQixTQUFTO0NBQ1g7QUFDRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1YsaUJBQXFCLFNBQVMsQ0FBQztFQUNoRixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsVUFBVSxZQUNaLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU1ZLFdBQ1IsR0FBRyxFQUNELE1BQU1DLFVBQ1IsQ0FBQyxHQUFHO0VBQ0YsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLE1BQU0sQ0FBQyxPQUFPO0VBQ2hCLENBQUM7RUFDRCxTQUFTLENBQUM7R0FDUixNQUFNO0dBQ04sTUFBTSxDQUFDLFNBQVM7RUFDbEIsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLG9CQUFOLE1BQXdCO0NBV3RCLElBQUksb0JBQW9COztFQUN0QixRQUFBLHlCQUFBLHNCQUFPLEtBQUssbUJBQUEsUUFBQSx3QkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLG9CQUFlLGNBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQVk7Q0FDekM7Q0FDQSxZQUFZLG1CQUFtQjt3QkFiL0IscUJBQUEsS0FBQSxDQUFBO3dCQUNBLHFCQUFvQixJQUFBO3dCQUNwQiwyQkFBQSxLQUFBLENBQUE7d0JBQ0EsNkJBQUEsS0FBQSxDQUFBO3dCQUNBLHdDQUFBLEtBQUEsQ0FBQTt3QkFDQSw0QkFBQSxLQUFBLENBQUE7d0JBQ0EsNkJBQUEsS0FBQSxDQUFBO3dCQUNBLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxjQUFBLEtBQUEsQ0FBQTt3QkFDQSwrQkFBYyxJQUFJLElBQUksQ0FBQTtFQUtwQixLQUFLLG9CQUFvQjtDQUMzQjtDQUNBLGdDQUFnQyxTQUFTO0VBQ3ZDLE9BQU8sUUFBUSxpQ0FBaUMsS0FBQTtDQUNsRDtDQUNBLGlDQUFpQyxTQUFTO0VBQ3hDLE9BQU8sUUFBUSx5QkFBeUIsS0FBQSxLQUFhLFFBQVEsZ0NBQWdDLEtBQUEsS0FBYSxRQUFRLGlDQUFpQyxLQUFBLEtBQWEsUUFBUSw0Q0FBNEMsS0FBQSxLQUFhLEtBQUssZ0NBQWdDLE9BQU87Q0FDL1E7Q0FDQSxZQUFZLFNBQVM7RUFDbkIsSUFBSSxLQUFLLGlDQUFpQyxPQUFPLEdBQUc7R0FDbEQsS0FBSyxrQkFBa0IsTUFBTTtHQUM3QixLQUFLLFlBQVksTUFBTTtHQUN2QixLQUFLLGdCQUFnQixLQUFBO0dBQ3JCLElBQUksS0FBSyxtQkFBbUI7SUFDMUIsTUFBTSxXQUFXLEtBQUssNkJBQTZCLEtBQUssa0JBQWtCO0lBQzFFLElBQUksS0FBSyxnQ0FBZ0MsT0FBTyxHQUFHOztLQUNqRCxDQUFBLG1CQUFBLEtBQUssZ0JBQUEsUUFBQSxxQkFBQSxLQUFBLEtBQUEsaUJBQVksUUFBUTtLQUN6QixJQUFJLEtBQUssMkJBQ1AsS0FBSyxhQUFhLGVBQWUsS0FBSywyQkFBMkIsa0JBQWtCLFFBQVEsQ0FBQztVQUU1RixLQUFLLGFBQWEsS0FBQTtJQUV0QjtJQUNBLEtBQUssZ0JBQWdCLEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLG1CQUFtQjtLQUNsRjtLQUNBLGFBQWEsS0FBSztLQUNsQixrQkFBa0IsS0FBSztLQUN2QixxQkFBcUIsS0FBSztJQUM1QixDQUFDO0dBQ0g7RUFDRjtDQUNGO0NBQ0EsWUFBWTtFQUNWLElBQUksS0FBSyxlQUFlO0dBQ3RCLElBQUksS0FBSyx5QkFDUCxLQUFLLE1BQU0sYUFBYSxPQUFPLEtBQUssS0FBSyx1QkFBdUIsR0FDOUQsS0FBSyxZQUFZLElBQUksV0FBVyxJQUFJO0dBR3hDLEtBQUsscUJBQXFCLEtBQUssYUFBYTtFQUM5QztDQUNGO0NBQ0EsY0FBYzs7RUFDWixDQUFBLG9CQUFBLEtBQUssZ0JBQUEsUUFBQSxzQkFBQSxLQUFBLEtBQUEsa0JBQVksUUFBUTtDQUMzQjtDQUNBLHFCQUFxQixjQUFjO0VBQ2pDLEtBQUssTUFBTSxDQUFDLFdBQVcsWUFBWSxLQUFLLGFBQ3RDLElBQUksQ0FBQyxTQUFTO0dBQ1osYUFBYSxTQUFTLFdBQVcsS0FBQSxDQUFTO0dBQzFDLEtBQUssWUFBWSxPQUFPLFNBQVM7RUFDbkMsT0FBTztHQUNMLGFBQWEsU0FBUyxXQUFXLEtBQUssd0JBQXdCLFVBQVU7R0FDeEUsS0FBSyxZQUFZLElBQUksV0FBVyxLQUFLO0VBQ3ZDO0NBRUo7QUFtQkY7O21DQWxCUyxRQUFPLFNBQVMsMEJBQTBCLG1CQUFtQjtDQUVsRSxPQUFPLEtBQUsscUJBQXFCQyxvQkFBbUJILGtCQUFxQkksZ0JBQW1CLENBQUM7QUFDL0YsQ0FBQTttQ0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUQ7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFJO0VBQXFCO0NBQUUsQ0FBQztDQUN6QyxRQUFRO0VBQ04sbUJBQW1CO0VBQ25CLHlCQUF5QjtFQUN6QiwyQkFBMkI7RUFDM0Isc0NBQXNDO0VBQ3RDLDBCQUEwQjtFQUMxQiwyQkFBMkI7Q0FDN0I7Q0FDQSxVQUFVLENBQUMsbUJBQW1CO0NBQzlCLFVBQVUsQ0FBQ0Usb0JBQXVCO0FBQ3BDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjaEIsaUJBQXFCLG1CQUFtQixDQUFDO0VBQzFGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsVUFBVTtFQUNaLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU1lLGlCQUNSLENBQUMsR0FBRztFQUNGLG1CQUFtQixDQUFDLEVBQ2xCLE1BQU0sTUFDUixDQUFDO0VBQ0QseUJBQXlCLENBQUMsRUFDeEIsTUFBTSxNQUNSLENBQUM7RUFDRCwyQkFBMkIsQ0FBQyxFQUMxQixNQUFNLE1BQ1IsQ0FBQztFQUNELHNDQUFzQyxDQUFDLEVBQ3JDLE1BQU0sTUFDUixDQUFDO0VBQ0QsMEJBQTBCLENBQUMsRUFDekIsTUFBTSxNQUNSLENBQUM7RUFDRCwyQkFBMkIsQ0FBQyxFQUMxQixNQUFNLE1BQ1IsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxTQUFTLGtCQUFrQixVQUFVO0NBRW5DLE9BRHVCLFNBQVMsSUFBSUUsYUFDaEIsQ0FBQyxDQUFDO0FBQ3hCO0FBQ0EsSUFBTSxpQkFBTixNQUFxQjtDQUtuQixZQUFZLFdBQVcsU0FBUyxPQUFPLE9BQU87d0JBSjlDLGFBQUEsS0FBQSxDQUFBO3dCQUNBLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxZQUFZO0VBQ2pCLEtBQUssVUFBVTtFQUNmLEtBQUssUUFBUTtFQUNiLEtBQUssUUFBUTtDQUNmO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFVBQVU7Q0FDeEI7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVE7Q0FDckM7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssUUFBUSxNQUFNO0NBQzVCO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsT0FBTyxDQUFDLEtBQUs7Q0FDZjtBQUNGO0FBQ0EsSUFBTSxVQUFOLE1BQWM7Q0FJWixJQUFJLFFBQVEsU0FBUztFQUNuQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxnQkFBZ0I7Q0FDdkI7Q0FDQSxJQUFJLGFBQWEsSUFBSTtFQUNuQixLQUFLLE9BQU8sY0FBYyxlQUFlLGNBQWMsTUFBTSxRQUFRLE9BQU8sT0FBTyxZQUNqRixRQUFRLEtBQUssNENBQTRDLEtBQUssVUFBVSxFQUFFLEVBQUUsc0ZBQTJGO0VBRXpLLEtBQUssYUFBYTtDQUNwQjtDQUNBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUs7Q0FDZDtDQUtBLFlBQVksZ0JBQWdCLFdBQVcsVUFBVTt3QkFwQmpELGtCQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTt3QkFjQSxZQUFXLElBQUE7d0JBQ1gsaUJBQWdCLElBQUE7d0JBQ2hCLFdBQVUsSUFBQTt3QkFDVixjQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssWUFBWTtFQUNqQixLQUFLLFdBQVc7Q0FDbEI7Q0FDQSxJQUFJLGNBQWMsT0FBTztFQUN2QixJQUFJLE9BQ0YsS0FBSyxZQUFZO0NBRXJCO0NBQ0EsWUFBWTtFQUNWLElBQUksS0FBSyxlQUFlO0dBQ3RCLEtBQUssZ0JBQWdCO0dBQ3JCLE1BQU0sUUFBUSxLQUFLO0dBQ25CLElBQUksQ0FBQyxLQUFLLFdBQVcsT0FDbkIsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUN0QyxJQUFJO0lBQ0YsS0FBSyxVQUFVLEtBQUssU0FBUyxLQUFLLEtBQUssQ0FBQyxDQUFDLE9BQU8sS0FBSyxZQUFZO0dBQ25FLFNBQUEsU0FBUTtJQUNOLElBQUksZUFBZSwyQ0FBMkMsTUFBTSxhQUFrQixZQUFZLEtBQUssRUFBRTtJQUN6RyxJQUFJLE9BQU8sVUFBVSxVQUNuQixnQkFBZ0I7SUFFbEIsTUFBTSxJQUFJWixhQUFjLE9BQU8sWUFBWTtHQUM3QztRQUVBLEtBQUssVUFBVSxLQUFLLFNBQVMsS0FBSyxLQUFLLENBQUMsQ0FBQyxPQUFPLEtBQUssWUFBWTtFQUd2RTtFQUNBLElBQUksS0FBSyxTQUFTO0dBQ2hCLE1BQU0sVUFBVSxLQUFLLFFBQVEsS0FBSyxLQUFLLFFBQVE7R0FDL0MsSUFBSSxTQUFTLEtBQUssY0FBYyxPQUFPO0VBQ3pDO0NBQ0Y7Q0FDQSxjQUFjLFNBQVM7RUFDckIsTUFBTSxnQkFBZ0IsS0FBSztFQUMzQixRQUFRLGtCQUFrQixNQUFNLHVCQUF1QixpQkFBaUI7R0FDdEUsSUFBSSxLQUFLLGlCQUFpQixNQUN4QixjQUFjLG1CQUFtQixLQUFLLFdBQVcsSUFBSSxlQUFlLEtBQUssTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLEdBQUcsaUJBQWlCLE9BQU8sS0FBQSxJQUFZLFlBQVk7UUFDbEosSUFBSSxnQkFBZ0IsTUFDekIsY0FBYyxPQUFPLDBCQUEwQixPQUFPLEtBQUEsSUFBWSxxQkFBcUI7UUFDbEYsSUFBSSwwQkFBMEIsTUFBTTtJQUN6QyxNQUFNLE9BQU8sY0FBYyxJQUFJLHFCQUFxQjtJQUNwRCxjQUFjLEtBQUssTUFBTSxZQUFZO0lBQ3JDLGdCQUFnQixNQUFNLElBQUk7R0FDNUI7RUFDRixDQUFDO0VBQ0QsS0FBSyxJQUFJLElBQUksR0FBRyxPQUFPLGNBQWMsUUFBUSxJQUFJLE1BQU0sS0FBSztHQUUxRCxNQUFNLFVBRFUsY0FBYyxJQUFJLENBQ1osQ0FBQyxDQUFDO0dBQ3hCLFFBQVEsUUFBUTtHQUNoQixRQUFRLFFBQVE7R0FDaEIsUUFBUSxVQUFVLEtBQUs7RUFDekI7RUFDQSxRQUFRLHVCQUFzQixXQUFVO0dBRXRDLGdCQURnQixjQUFjLElBQUksT0FBTyxZQUNuQixHQUFHLE1BQU07RUFDakMsQ0FBQztDQUNIO0NBQ0EsT0FBTyx1QkFBdUIsS0FBSyxLQUFLO0VBQ3RDLE9BQU87Q0FDVDtBQWNGOzt5QkFiUyxRQUFPLFNBQVMsZ0JBQWdCLG1CQUFtQjtDQUV4RCxPQUFPLEtBQUsscUJBQXFCYSxVQUFTUCxrQkFBcUJJLGdCQUFtQixHQUFHSixrQkFBcUJRLFdBQWMsR0FBR1Isa0JBQXFCUyxlQUFrQixDQUFDO0FBQ3JLLENBQUE7eUJBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1GO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFTO0VBQUk7RUFBVztDQUFFLENBQUM7Q0FDNUMsUUFBUTtFQUNOLFNBQVM7RUFDVCxjQUFjO0VBQ2QsZUFBZTtDQUNqQjtBQUNGLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjbEIsaUJBQXFCLFNBQVMsQ0FBQztFQUNoRixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsVUFBVSxtQkFDWixDQUFDO0NBQ0gsQ0FBQyxTQUFTO0VBQUMsRUFDVCxNQUFNZSxpQkFDUjtFQUFHLEVBQ0QsTUFBTUksWUFDUjtFQUFHLEVBQ0QsTUFBTUMsZ0JBQ1I7Q0FBQyxHQUFHO0VBQ0YsU0FBUyxDQUFDLEVBQ1IsTUFBTSxNQUNSLENBQUM7RUFDRCxjQUFjLENBQUMsRUFDYixNQUFNLE1BQ1IsQ0FBQztFQUNELGVBQWUsQ0FBQyxFQUNkLE1BQU0sTUFDUixDQUFDO0NBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILFNBQVMsZ0JBQWdCLE1BQU0sUUFBUTtDQUNyQyxLQUFLLFFBQVEsWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsU0FBUyxZQUFZLE1BQU07Q0FDekIsT0FBTyxLQUFLLFdBQVcsT0FBTztBQUNoQztBQUNBLElBQU0sT0FBTixNQUFXO0NBT1QsWUFBWSxnQkFBZ0IsYUFBYTt3QkFOekMsa0JBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQVcsSUFBSSxZQUFZLENBQUE7d0JBQzNCLG9CQUFtQixJQUFBO3dCQUNuQixvQkFBbUIsSUFBQTt3QkFDbkIsZ0JBQWUsSUFBQTt3QkFDZixnQkFBZSxJQUFBO0VBRWIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxtQkFBbUI7Q0FDMUI7Q0FDQSxJQUFJLEtBQUssV0FBVztFQUNsQixLQUFLLFNBQVMsWUFBWSxLQUFLLFNBQVMsT0FBTztFQUMvQyxLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxJQUFJLFNBQVMsYUFBYTtFQUN4QixlQUFlLGNBQWMsT0FBTyxjQUFjLGVBQWUsY0FBYyxVQUFVO0VBQ3pGLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssZUFBZTtFQUNwQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxJQUFJLFNBQVMsYUFBYTtFQUN4QixlQUFlLGNBQWMsT0FBTyxjQUFjLGVBQWUsY0FBYyxVQUFVO0VBQ3pGLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssZUFBZTtFQUNwQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxjQUFjO0VBQ1osSUFBSSxLQUFLLFNBQVM7T0FDWixDQUFDLEtBQUssY0FBYztJQUN0QixLQUFLLGVBQWUsTUFBTTtJQUMxQixLQUFLLGVBQWU7SUFDcEIsSUFBSSxLQUFLLGtCQUNQLEtBQUssZUFBZSxLQUFLLGVBQWUsbUJBQW1CLEtBQUssa0JBQWtCLEtBQUssUUFBUTtHQUVuRztTQUVBLElBQUksQ0FBQyxLQUFLLGNBQWM7R0FDdEIsS0FBSyxlQUFlLE1BQU07R0FDMUIsS0FBSyxlQUFlO0dBQ3BCLElBQUksS0FBSyxrQkFDUCxLQUFLLGVBQWUsS0FBSyxlQUFlLG1CQUFtQixLQUFLLGtCQUFrQixLQUFLLFFBQVE7RUFFbkc7Q0FFSjtDQUdBLE9BQU8sdUJBQXVCLEtBQUssS0FBSztFQUN0QyxPQUFPO0NBQ1Q7QUFjRjs7c0JBbEJTLHNCQUFBLEtBQUEsQ0FBQTtzQkFDQSx3QkFBQSxLQUFBLENBQUE7c0JBSUEsUUFBTyxTQUFTLGFBQWEsbUJBQW1CO0NBRXJELE9BQU8sS0FBSyxxQkFBcUJDLE9BQU1WLGtCQUFxQkksZ0JBQW1CLEdBQUdKLGtCQUFxQlEsV0FBYyxDQUFDO0FBQ3hILENBQUE7c0JBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1FO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFRO0NBQUUsQ0FBQztDQUM1QixRQUFRO0VBQ04sTUFBTTtFQUNOLFVBQVU7RUFDVixVQUFVO0NBQ1o7QUFDRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY3JCLGlCQUFxQixNQUFNLENBQUM7RUFDN0UsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFVBQVUsU0FDWixDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNZSxpQkFDUixHQUFHLEVBQ0QsTUFBTUksWUFDUixDQUFDLEdBQUc7RUFDRixNQUFNLENBQUMsRUFDTCxNQUFNLE1BQ1IsQ0FBQztFQUNELFVBQVUsQ0FBQyxFQUNULE1BQU0sTUFDUixDQUFDO0VBQ0QsVUFBVSxDQUFDLEVBQ1QsTUFBTSxNQUNSLENBQUM7Q0FDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSxjQUFOLE1BQWtCOzt3QkFDaEIsYUFBWSxJQUFBO3dCQUNaLFFBQU8sSUFBQTs7QUFDVDtBQUNBLFNBQVMsZUFBZSxhQUFhLFVBQVU7Q0FDN0MsSUFBSSxlQUFlLENBQUMsWUFBWSxvQkFDOUIsTUFBTSxJQUFJZCxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyxHQUFHLFNBQVMsd0NBQXdDSSxVQUFXLFdBQVcsRUFBRSxHQUFHO0FBRXBLO0FBQ0EsSUFBTSxhQUFOLE1BQWlCO0NBSWYsWUFBWSxtQkFBbUIsY0FBYzt3QkFIN0MscUJBQUEsS0FBQSxDQUFBO3dCQUNBLGdCQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFXLEtBQUE7RUFFVCxLQUFLLG9CQUFvQjtFQUN6QixLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxTQUFTO0VBQ1AsS0FBSyxXQUFXO0VBQ2hCLEtBQUssa0JBQWtCLG1CQUFtQixLQUFLLFlBQVk7Q0FDN0Q7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxXQUFXO0VBQ2hCLEtBQUssa0JBQWtCLE1BQU07Q0FDL0I7Q0FDQSxhQUFhLFNBQVM7RUFDcEIsSUFBSSxXQUFXLENBQUMsS0FBSyxVQUNuQixLQUFLLE9BQU87T0FDUCxJQUFJLENBQUMsV0FBVyxLQUFLLFVBQzFCLEtBQUssUUFBUTtDQUVqQjtBQUNGO0FBQ0EsSUFBTSxXQUFOLE1BQWU7O3dCQUNiLGlCQUFnQixDQUFDLENBQUE7d0JBQ2pCLGdCQUFlLEtBQUE7d0JBQ2YsY0FBYSxDQUFBO3dCQUNiLHVCQUFzQixDQUFBO3dCQUN0QixxQkFBb0IsS0FBQTt3QkFDcEIsYUFBQSxLQUFBLENBQUE7O0NBQ0EsSUFBSSxTQUFTLFVBQVU7RUFDckIsS0FBSyxZQUFZO0VBQ2pCLElBQUksS0FBSyxlQUFlLEdBQ3RCLEtBQUssb0JBQW9CLElBQUk7Q0FFakM7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxZQUFZLE1BQU07RUFDaEIsS0FBSyxjQUFjLEtBQUssSUFBSTtDQUM5QjtDQUNBLFdBQVcsT0FBTztFQUNoQixNQUFNLFVBQVUsVUFBVSxLQUFLO0VBQy9CLEtBQUssc0JBQUwsS0FBSyxvQkFBc0I7RUFDM0IsS0FBSztFQUNMLElBQUksS0FBSyx3QkFBd0IsS0FBSyxZQUFZO0dBQ2hELEtBQUssb0JBQW9CLENBQUMsS0FBSyxpQkFBaUI7R0FDaEQsS0FBSyxzQkFBc0I7R0FDM0IsS0FBSyxvQkFBb0I7RUFDM0I7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxvQkFBb0IsWUFBWTtFQUM5QixJQUFJLEtBQUssY0FBYyxTQUFTLEtBQUssZUFBZSxLQUFLLGNBQWM7R0FDckUsS0FBSyxlQUFlO0dBQ3BCLEtBQUssTUFBTSxlQUFlLEtBQUssZUFDN0IsWUFBWSxhQUFhLFVBQVU7RUFFdkM7Q0FDRjtBQVdGOzswQkFWUyxRQUFPLFNBQVMsaUJBQWlCLG1CQUFtQjtDQUN6RCxPQUFPLEtBQUsscUJBQXFCYSxXQUFVO0FBQzdDLENBQUE7MEJBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1BO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFZO0NBQUUsQ0FBQztDQUNoQyxRQUFRLEVBQ04sVUFBVSxXQUNaO0FBQ0YsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWN0QixpQkFBcUIsVUFBVSxDQUFDO0VBQ2pGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxVQUFVLGFBQ1osQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLEVBQ1IsVUFBVSxDQUFDLEVBQ1QsTUFBTSxNQUNSLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSxlQUFOLE1BQW1CO0NBSWpCLFlBQVksZUFBZSxhQUFhLFVBQVU7d0JBSGxELFlBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLGdCQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssV0FBVztFQUNoQixLQUFLLE9BQU8sY0FBYyxlQUFlLGNBQWMsQ0FBQyxVQUN0RCxtQ0FBbUMsZ0JBQWdCLGNBQWM7RUFFbkUsU0FBUyxTQUFTO0VBQ2xCLEtBQUssUUFBUSxJQUFJLFdBQVcsZUFBZSxXQUFXO0NBQ3hEO0NBQ0EsWUFBWTtFQUNWLEtBQUssTUFBTSxhQUFhLEtBQUssU0FBUyxXQUFXLEtBQUssWUFBWSxDQUFDO0NBQ3JFO0FBWUY7OzhCQVhTLFFBQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0NBRTdELE9BQU8sS0FBSyxxQkFBcUJ1QixlQUFjWixrQkFBcUJJLGdCQUFtQixHQUFHSixrQkFBcUJRLFdBQWMsR0FBR1Isa0JBQXFCLFVBQVUsQ0FBQyxDQUFDO0FBQ25LLENBQUE7OEJBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1ZO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFnQjtDQUFFLENBQUM7Q0FDcEMsUUFBUSxFQUNOLGNBQWMsZUFDaEI7QUFDRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY3ZCLGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFVBQVUsaUJBQ1osQ0FBQztDQUNILENBQUMsU0FBUztFQUFDLEVBQ1QsTUFBTWUsaUJBQ1I7RUFBRyxFQUNELE1BQU1JLFlBQ1I7RUFBRztHQUNELE1BQU07R0FDTixZQUFZLENBQUMsRUFDWCxNQUFNLFNBQ1IsR0FBRyxFQUNELE1BQU0sS0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHLEVBQ0YsY0FBYyxDQUFDLEVBQ2IsTUFBTSxNQUNSLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSxrQkFBTixNQUFzQjtDQUNwQixZQUFZLGVBQWUsYUFBYSxVQUFVO0VBQ2hELEtBQUssT0FBTyxjQUFjLGVBQWUsY0FBYyxDQUFDLFVBQ3RELG1DQUFtQyxtQkFBbUIsaUJBQWlCO0VBRXpFLFNBQVMsWUFBWSxJQUFJLFdBQVcsZUFBZSxXQUFXLENBQUM7Q0FDakU7QUFTRjs7aUNBUlMsUUFBTyxTQUFTLHdCQUF3QixtQkFBbUI7Q0FFaEUsT0FBTyxLQUFLLHFCQUFxQkssa0JBQWlCYixrQkFBcUJJLGdCQUFtQixHQUFHSixrQkFBcUJRLFdBQWMsR0FBR1Isa0JBQXFCLFVBQVUsQ0FBQyxDQUFDO0FBQ3RLLENBQUE7aUNBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1hO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFtQjtDQUFFLENBQUM7QUFDekMsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWN4QixpQkFBcUIsaUJBQWlCLENBQUM7RUFDeEYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFVBQVUsb0JBQ1osQ0FBQztDQUNILENBQUMsU0FBUztFQUFDLEVBQ1QsTUFBTWUsaUJBQ1I7RUFBRyxFQUNELE1BQU1JLFlBQ1I7RUFBRztHQUNELE1BQU07R0FDTixZQUFZLENBQUMsRUFDWCxNQUFNLFNBQ1IsR0FBRyxFQUNELE1BQU0sS0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxTQUFTLG1DQUFtQyxVQUFVLGVBQWU7Q0FDbkUsTUFBTSxJQUFJZCxhQUFjLEtBQU0sd0JBQXdCLFNBQVMsNkJBQWtDLGNBQWMsNkdBQWtIO0FBQ25PO0FBQ0EsSUFBTSxXQUFOLE1BQWU7Q0FJYixZQUFZLGVBQWU7d0JBSDNCLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxlQUFBLEtBQUEsQ0FBQTt3QkFDQSxjQUFhLENBQUMsQ0FBQTtFQUVaLEtBQUssZ0JBQWdCO0NBQ3ZCO0NBQ0EsSUFBSSxTQUFTLE9BQU87RUFDbEIsS0FBSyxZQUFZLEtBQUs7Q0FDeEI7Q0FDQSxRQUFRLE9BQU8sWUFBWTtFQUN6QixLQUFLLFdBQVcsU0FBUztDQUMzQjtDQUNBLFlBQVksYUFBYTtFQUN2QixLQUFLLFlBQVk7RUFFakIsTUFBTSxNQUFNLGtCQUFrQixhQURoQixPQUFPLEtBQUssS0FBSyxVQUNnQixHQUFHLEtBQUssYUFBYTtFQUNwRSxLQUFLLGNBQWMsS0FBSyxXQUFXLElBQUk7Q0FDekM7Q0FDQSxjQUFjO0VBQ1osSUFBSSxLQUFLLGFBQWEsS0FBSyxZQUFZLFFBQVE7Q0FDakQ7Q0FDQSxjQUFjLE1BQU07RUFDbEIsSUFBSSxNQUFNO0dBQ1IsS0FBSyxjQUFjO0dBQ25CLEtBQUssWUFBWSxPQUFPO0VBQzFCO0NBQ0Y7QUFZRjs7MEJBWFMsUUFBTyxTQUFTLGlCQUFpQixtQkFBbUI7Q0FFekQsT0FBTyxLQUFLLHFCQUFxQm9CLFdBQVVkLGtCQUFxQixjQUFjLENBQUM7QUFDakYsQ0FBQTswQkFDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTWM7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFJO0VBQVk7Q0FBRSxDQUFDO0NBQ2hDLFFBQVEsRUFDTixVQUFVLFdBQ1o7QUFDRixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY3pCLGlCQUFxQixVQUFVLENBQUM7RUFDakYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFVBQVUsYUFDWixDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNLGVBQ1IsQ0FBQyxHQUFHLEVBQ0YsVUFBVSxDQUFDLEVBQ1QsTUFBTSxNQUNSLENBQUMsRUFDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsSUFBTSxlQUFOLE1BQW1CO0NBRWpCLFlBQVksT0FBTyxVQUFVLGVBQWUsVUFBVTt3QkFEdEQsU0FBQSxLQUFBLENBQUE7RUFFRSxLQUFLLFFBQVE7RUFDYixNQUFNLFlBQVksQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDO0VBQ3RDLFNBQVMsUUFBUSxZQUFZLElBQUksVUFBVSxPQUFPLElBQUksV0FBVyxlQUFlLFFBQVEsQ0FBQztDQUMzRjtBQVNGOzs4QkFSUyxRQUFPLFNBQVMscUJBQXFCLG1CQUFtQjtDQUU3RCxPQUFPLEtBQUsscUJBQXFCMEIsZUFBY0Msa0JBQXFCLGNBQWMsR0FBR2hCLGtCQUFxQlEsV0FBYyxHQUFHUixrQkFBcUJJLGdCQUFtQixHQUFHSixrQkFBcUIsVUFBVSxDQUFDLENBQUM7QUFDek0sQ0FBQTs4QkFDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTWU7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFJO0VBQWdCO0NBQUUsQ0FBQztBQUN0QyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYzFCLGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFVBQVUsaUJBQ1osQ0FBQztDQUNILENBQUMsU0FBUztFQUFDO0dBQ1QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyxjQUFjO0dBQ3ZCLENBQUM7RUFDSDtFQUFHLEVBQ0QsTUFBTW1CLFlBQ1I7RUFBRyxFQUNELE1BQU1KLGlCQUNSO0VBQUc7R0FDRCxNQUFNO0dBQ04sWUFBWSxDQUFDLEVBQ1gsTUFBTSxLQUNSLENBQUM7RUFDSDtDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sVUFBTixNQUFjO0NBTVosWUFBWSxPQUFPLFVBQVUsV0FBVzt3QkFMeEMsU0FBQSxLQUFBLENBQUE7d0JBQ0EsWUFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7d0JBQ0EsWUFBVyxJQUFBO3dCQUNYLFdBQVUsSUFBQTtFQUVSLEtBQUssUUFBUTtFQUNiLEtBQUssV0FBVztFQUNoQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxJQUFJLFFBQVEsUUFBUTtFQUNsQixLQUFLLFdBQVc7RUFDaEIsSUFBSSxDQUFDLEtBQUssV0FBVyxRQUNuQixLQUFLLFVBQVUsS0FBSyxTQUFTLEtBQUssTUFBTSxDQUFDLENBQUMsT0FBTztDQUVyRDtDQUNBLFlBQVk7RUFDVixJQUFJLEtBQUssU0FBUztHQUNoQixNQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUssS0FBSyxRQUFRO0dBQy9DLElBQUksU0FDRixLQUFLLGNBQWMsT0FBTztFQUU5QjtDQUNGO0NBQ0EsVUFBVSxhQUFhLE9BQU87RUFDNUIsTUFBTSxDQUFDLE1BQU0sUUFBUSxZQUFZLE1BQU0sR0FBRztFQUMxQyxNQUFNLFFBQVEsS0FBSyxRQUFRLEdBQUcsTUFBTSxLQUFLLEtBQUEsSUFBWSxvQkFBb0I7RUFDekUsSUFBSSxTQUFTLE1BQ1gsS0FBSyxVQUFVLFNBQVMsS0FBSyxNQUFNLGVBQWUsTUFBTSxPQUFPLEdBQUcsUUFBUSxTQUFTLE9BQU8sS0FBSztPQUUvRixLQUFLLFVBQVUsWUFBWSxLQUFLLE1BQU0sZUFBZSxNQUFNLEtBQUs7Q0FFcEU7Q0FDQSxjQUFjLFNBQVM7RUFDckIsUUFBUSxvQkFBbUIsV0FBVSxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUksQ0FBQztFQUNyRSxRQUFRLGtCQUFpQixXQUFVLEtBQUssVUFBVSxPQUFPLEtBQUssT0FBTyxZQUFZLENBQUM7RUFDbEYsUUFBUSxvQkFBbUIsV0FBVSxLQUFLLFVBQVUsT0FBTyxLQUFLLE9BQU8sWUFBWSxDQUFDO0NBQ3RGO0FBWUY7O3lCQVhTLFFBQU8sU0FBUyxnQkFBZ0IsbUJBQW1CO0NBRXhELE9BQU8sS0FBSyxxQkFBcUJhLFVBQVNqQixrQkFBcUJDLFVBQWEsR0FBR0Qsa0JBQXFCa0IsZUFBa0IsR0FBR2xCLGtCQUFxQkUsU0FBWSxDQUFDO0FBQzdKLENBQUE7eUJBQ08sUUFBc0Isa0NBQXFCO0NBQ2hELE1BQU1lO0NBQ04sV0FBVyxDQUFDO0VBQUM7RUFBSTtFQUFXO0NBQUUsQ0FBQztDQUMvQixRQUFRLEVBQ04sU0FBUyxVQUNYO0FBQ0YsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWM1QixpQkFBcUIsU0FBUyxDQUFDO0VBQ2hGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxVQUFVLFlBQ1osQ0FBQztDQUNILENBQUMsU0FBUztFQUFDLEVBQ1QsTUFBTVksV0FDUjtFQUFHLEVBQ0QsTUFBTWlCLGdCQUNSO0VBQUcsRUFDRCxNQUFNaEIsVUFDUjtDQUFDLEdBQUcsRUFDRixTQUFTLENBQUM7RUFDUixNQUFNO0VBQ04sTUFBTSxDQUFDLFNBQVM7Q0FDbEIsQ0FBQyxFQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLG1CQUFOLE1BQXVCO0NBT3JCLFlBQVksbUJBQW1CO3dCQU4vQixxQkFBQSxLQUFBLENBQUE7d0JBQ0EsWUFBVyxJQUFBO3dCQUNYLDJCQUEwQixJQUFBO3dCQUMxQixvQkFBbUIsSUFBQTt3QkFDbkIsNEJBQTJCLElBQUE7d0JBQzNCLFlBQVcsT0FBTyxRQUFRLENBQUE7RUFFeEIsS0FBSyxvQkFBb0I7Q0FDM0I7Q0FDQSxZQUFZLFNBQVM7RUFDbkIsSUFBSSxLQUFLLG9CQUFvQixPQUFPLEdBQUc7R0FDckMsTUFBTSxtQkFBbUIsS0FBSztHQUM5QixJQUFJLEtBQUssVUFDUCxpQkFBaUIsT0FBTyxpQkFBaUIsUUFBUSxLQUFLLFFBQVEsQ0FBQztHQUVqRSxJQUFJLENBQUMsS0FBSyxrQkFBa0I7SUFDMUIsS0FBSyxXQUFXO0lBQ2hCO0dBQ0Y7R0FDQSxNQUFNLGNBQWMsS0FBSywyQkFBMkI7R0FDcEQsS0FBSyxXQUFXLGlCQUFpQixtQkFBbUIsS0FBSyxrQkFBa0IsYUFBYSxFQUN0RixVQUFVLEtBQUssYUFBYSxFQUM5QixDQUFDO0VBQ0g7Q0FDRjtDQUNBLGVBQWU7O0VBQ2IsSUFBSSxLQUFLLDZCQUE2QixVQUNwQyxPQUFPLEtBQUs7RUFFZCxRQUFBLHdCQUFPLEtBQUssOEJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQTRCLEtBQUE7Q0FDMUM7Q0FDQSxvQkFBb0IsU0FBUztFQUMzQixPQUFPLENBQUMsQ0FBQyxRQUFRLHVCQUF1QixDQUFDLENBQUMsUUFBUTtDQUNwRDtDQUNBLDZCQUE2QjtFQUMzQixPQUFPLElBQUksTUFBTSxDQUFDLEdBQUc7R0FDbkIsTUFBTSxTQUFTLE1BQU0sYUFBYTtJQUNoQyxJQUFJLENBQUMsS0FBSyx5QkFDUixPQUFPO0lBRVQsT0FBTyxRQUFRLElBQUksS0FBSyx5QkFBeUIsTUFBTSxRQUFRO0dBQ2pFO0dBQ0EsTUFBTSxTQUFTLE1BQU0sYUFBYTtJQUNoQyxJQUFJLENBQUMsS0FBSyx5QkFDUjtJQUVGLE9BQU8sUUFBUSxJQUFJLEtBQUsseUJBQXlCLE1BQU0sUUFBUTtHQUNqRTtFQUNGLENBQUM7Q0FDSDtBQWVGOztrQ0FkUyxRQUFPLFNBQVMseUJBQXlCLG1CQUFtQjtDQUVqRSxPQUFPLEtBQUsscUJBQXFCaUIsbUJBQWtCbkIsa0JBQXFCSSxnQkFBbUIsQ0FBQztBQUM5RixDQUFBO2tDQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNZTtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQUk7RUFBb0I7Q0FBRSxDQUFDO0NBQ3hDLFFBQVE7RUFDTix5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLDBCQUEwQjtDQUM1QjtDQUNBLFVBQVUsQ0FBQ2Qsb0JBQXVCO0FBQ3BDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjaEIsaUJBQXFCLGtCQUFrQixDQUFDO0VBQ3pGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxVQUFVLHFCQUNaLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU1lLGlCQUNSLENBQUMsR0FBRztFQUNGLHlCQUF5QixDQUFDLEVBQ3hCLE1BQU0sTUFDUixDQUFDO0VBQ0Qsa0JBQWtCLENBQUMsRUFDakIsTUFBTSxNQUNSLENBQUM7RUFDRCwwQkFBMEIsQ0FBQyxFQUN6QixNQUFNLE1BQ1IsQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLG9CQUFvQjtDQUFDO0NBQVM7Q0FBbUI7Q0FBUztDQUFNO0NBQWtCO0NBQVM7Q0FBVTtDQUFjO0NBQWlCO0NBQVU7QUFBWTtBQUNoSyxTQUFTLHlCQUF5QixNQUFNLE9BQU87Q0FDN0MsT0FBTyxJQUFJVixhQUFjLE1BQU0sYUFBYSx5QkFBeUIsTUFBTSxjQUFjSSxVQUFXLElBQUksRUFBRSxFQUFFO0FBQzlHO0FBQ0EsU0FBUyxhQUFhLFVBQVUsT0FBTztDQUNyQyxJQUFJLFNBQVMsS0FBSyxHQUNoQixRQUFRLEtBQUssT0FBTyxTQUFTLDBEQUEwRCxNQUFNLENBQUM7QUFFbEc7QUFDQSxJQUFNLHVCQUFOLE1BQTJCO0NBQ3pCLG1CQUFtQixPQUFPLG1CQUFtQixTQUFTO0VBQ3BELE9BQU8sZ0JBQWdCLE1BQU0sVUFBVTtHQUNyQyxNQUFNO0dBQ04sT0FBTztFQUNULENBQUMsQ0FBQztDQUNKO0NBQ0EsUUFBUSxjQUFjO0VBQ3BCLGdCQUFnQixhQUFhLFlBQVksQ0FBQztDQUM1QztBQUNGO0FBQ0EsSUFBTSxrQkFBTixNQUFzQjtDQUNwQixtQkFBbUIsT0FBTyxtQkFBbUIsU0FBUztFQUNwRCxNQUFNLE1BQUssTUFBQSxzQkFBQSxRQUFBLHNCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUssa0JBQW9CLENBQUMsSUFBRyxNQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxLQUFBLElBQUssUUFBVSxDQUFDLENBQUM7RUFDekQsT0FBTyxFQUNMLG1CQUFtQjtHQUNqQixvQkFBb0I7R0FDcEIsVUFBVTtFQUNaLEVBQ0Y7Q0FDRjtDQUNBLFFBQVEsY0FBYztFQUNwQixhQUFhLFlBQVk7Q0FDM0I7QUFDRjtBQUNBLElBQU0sbUJBQW1CLElBQUksZ0JBQWdCO0FBQzdDLElBQU0sd0JBQXdCLElBQUkscUJBQXFCO0FBQ3ZELElBQU0sWUFBTixNQUFNLFVBQVU7Q0FRZCxZQUFZLEtBQUs7d0JBUGpCLFFBQUEsS0FBQSxDQUFBO3dCQUNBLGdCQUFlLElBQUE7d0JBQ2YsNkJBQTRCLElBQUE7d0JBQzVCLGlCQUFnQixJQUFBO3dCQUNoQixRQUFPLElBQUE7d0JBQ1AsYUFBWSxJQUFBO3dCQUNaLDJCQUEwQixPQUFPc0Isa0NBQW1DLENBQUE7RUFFbEUsS0FBSyxPQUFPO0NBQ2Q7Q0FDQSxjQUFjO0VBQ1osSUFBSSxLQUFLLGVBQ1AsS0FBSyxTQUFTO0VBRWhCLEtBQUssT0FBTztDQUNkO0NBQ0EsVUFBVSxLQUFLO0VBQ2IsSUFBSSxDQUFDLEtBQUssTUFBTTtHQUNkLElBQUksS0FDRixJQUFJO0lBQ0YsS0FBSyw0QkFBNEI7SUFDakMsS0FBSyxXQUFXLEdBQUc7R0FDckIsVUFBVTtJQUNSLEtBQUssNEJBQTRCO0dBQ25DO0dBRUYsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxJQUFJLFFBQVEsS0FBSyxNQUFNO0dBQ3JCLEtBQUssU0FBUztHQUNkLE9BQU8sS0FBSyxVQUFVLEdBQUc7RUFDM0I7RUFDQSxPQUFPLEtBQUs7Q0FDZDtDQUNBLFdBQVcsS0FBSztFQUNkLEtBQUssT0FBTztFQUNaLEtBQUssWUFBWSxLQUFLLGdCQUFnQixHQUFHO0VBQ3pDLEtBQUssZ0JBQWdCLEtBQUssVUFBVSxtQkFBbUIsTUFBSyxVQUFTLEtBQUssbUJBQW1CLEtBQUssS0FBSyxJQUFHLE1BQUssS0FBSyx3QkFBd0IsQ0FBQyxDQUFDO0NBQ2hKO0NBQ0EsZ0JBQWdCLEtBQUs7RUFDbkIsSUFBSUMsVUFBVyxHQUFHLEdBQ2hCLE9BQU87RUFFVCxJQUFJQyxlQUFnQixHQUFHLEdBQ3JCLE9BQU87RUFFVCxNQUFNLHlCQUF5QixXQUFXLEdBQUc7Q0FDL0M7Q0FDQSxXQUFXO0VBQ1QsS0FBSyxVQUFVLFFBQVEsS0FBSyxhQUFhO0VBQ3pDLEtBQUssZUFBZTtFQUNwQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLE9BQU87Q0FDZDtDQUNBLG1CQUFtQixPQUFPLE9BQU87RUFDL0IsSUFBSSxVQUFVLEtBQUssTUFBTTtHQUN2QixLQUFLLGVBQWU7R0FDcEIsSUFBSSxLQUFLLDJCQUEyQjs7SUFDbEMsQ0FBQSxhQUFBLEtBQUssVUFBQSxRQUFBLGVBQUEsS0FBQSxLQUFBLFdBQU0sYUFBYTtHQUMxQjtFQUNGO0NBQ0Y7QUFVRjs7MkJBVFMsUUFBTyxTQUFTLGtCQUFrQixtQkFBbUI7Q0FFMUQsT0FBTyxLQUFLLHFCQUFxQkMsWUFBV3ZCLGtCQUFxQndCLG1CQUFzQixFQUFFLENBQUM7QUFDNUYsQ0FBQTsyQkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1EO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjbEMsaUJBQXFCLFdBQVcsQ0FBQztFQUNsRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsTUFBTTtHQUNOLE1BQU07RUFDUixDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNbUMsa0JBQ1IsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLGdCQUFOLE1BQU0sY0FBYztDQUNsQixVQUFVLE9BQU87RUFDZixJQUFJLFNBQVMsTUFBTSxPQUFPO0VBQzFCLG1CQUFtQixlQUFlLEtBQUs7RUFDdkMsT0FBTyxNQUFNLFlBQVk7Q0FDM0I7QUFTRjs7K0JBUlMsUUFBTyxTQUFTLHNCQUFzQixtQkFBbUI7Q0FDOUQsT0FBTyxLQUFLLHFCQUFxQkMsZ0JBQWU7QUFDbEQsQ0FBQTsrQkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1BO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjcEMsaUJBQXFCLGVBQWUsQ0FBQztFQUN0RixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsTUFBTSxZQUNSLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sZ0JBQU4sTUFBTSxjQUFjO0NBQ2xCLFVBQVUsT0FBTztFQUNmLElBQUksU0FBUyxNQUFNLE9BQU87RUFDMUIsbUJBQW1CLGVBQWUsS0FBSztFQUN2QyxPQUFPLE1BQU0sUUFBUSxtQkFBa0IsUUFBTyxJQUFJLEVBQUUsQ0FBQyxZQUFZLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztDQUNqRztBQVNGOzsrQkFSUyxRQUFPLFNBQVMsc0JBQXNCLG1CQUFtQjtDQUM5RCxPQUFPLEtBQUsscUJBQXFCcUMsZ0JBQWU7QUFDbEQsQ0FBQTsrQkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1BO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjckMsaUJBQXFCLGVBQWUsQ0FBQztFQUN0RixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsTUFBTSxZQUNSLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sZ0JBQU4sTUFBTSxjQUFjO0NBQ2xCLFVBQVUsT0FBTztFQUNmLElBQUksU0FBUyxNQUFNLE9BQU87RUFDMUIsbUJBQW1CLGVBQWUsS0FBSztFQUN2QyxPQUFPLE1BQU0sWUFBWTtDQUMzQjtBQVNGOzsrQkFSUyxRQUFPLFNBQVMsc0JBQXNCLG1CQUFtQjtDQUM5RCxPQUFPLEtBQUsscUJBQXFCc0MsZ0JBQWU7QUFDbEQsQ0FBQTsrQkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1BO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjdEMsaUJBQXFCLGVBQWUsQ0FBQztFQUN0RixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsTUFBTSxZQUNSLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILFNBQVMsbUJBQW1CLE1BQU0sT0FBTztDQUN2QyxJQUFJLE9BQU8sVUFBVSxVQUNuQixNQUFNLHlCQUF5QixNQUFNLEtBQUs7QUFFOUM7QUFDQSxJQUFNLHNCQUFzQjtBQUM1QixJQUFNLDZCQUE2QixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSwrQkFBK0IsRUFBRTtBQUN2SSxJQUFNLDRCQUE0QixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSw4QkFBOEIsRUFBRTtBQUNySSxJQUFNLFdBQU4sTUFBTSxTQUFTO0NBSWIsWUFBWSxRQUFRLGlCQUFpQixnQkFBZ0I7d0JBSHJELFVBQUEsS0FBQSxDQUFBO3dCQUNBLG1CQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLFNBQVM7RUFDZCxLQUFLLGtCQUFrQjtFQUN2QixLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLFVBQVUsT0FBTyxRQUFRLFVBQVUsUUFBUTtFQUN6QyxJQUFJLFNBQVMsUUFBUSxVQUFVLE1BQU0sVUFBVSxPQUFPLE9BQU87RUFDN0QsSUFBSTs7R0FDRixNQUFNLFdBQUEsT0FBVSxXQUFBLFFBQUEsV0FBQSxLQUFBLElBQUEsVUFBQSx1QkFBVSxLQUFLLG9CQUFBLFFBQUEseUJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxxQkFBZ0IsZ0JBQUEsUUFBQSxTQUFBLEtBQUEsSUFBQSxPQUFjO0dBQzdELE1BQU0sYUFBQSxTQUFBLFFBQVksYUFBQSxRQUFBLGFBQUEsS0FBQSxJQUFBLFlBQUEsd0JBQVksS0FBSyxvQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQWdCLGNBQUEsUUFBQSxVQUFBLEtBQUEsSUFBQSxRQUFZLEtBQUsscUJBQUEsUUFBQSxVQUFBLEtBQUEsSUFBQSxRQUFtQixLQUFBO0dBQ3ZGLE9BQU8sV0FBVyxPQUFPLFNBQVMsVUFBVSxLQUFLLFFBQVEsU0FBUztFQUNwRSxTQUFTLE9BQU87R0FDZCxNQUFNLHlCQUF5QixVQUFVLE1BQU0sT0FBTztFQUN4RDtDQUNGO0FBVUY7OzBCQVRTLFFBQU8sU0FBUyxpQkFBaUIsbUJBQW1CO0NBRXpELE9BQU8sS0FBSyxxQkFBcUJ1QyxXQUFVNUIsa0JBQXFCLFdBQVcsRUFBRSxHQUFHQSxrQkFBcUIsNEJBQTRCLEVBQUUsR0FBR0Esa0JBQXFCLDJCQUEyQixFQUFFLENBQUM7QUFDM0wsQ0FBQTswQkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU00QjtDQUNOLE1BQU07QUFDUixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY3ZDLGlCQUFxQixVQUFVLENBQUM7RUFDakYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLE1BQU0sT0FDUixDQUFDO0NBQ0gsQ0FBQyxTQUFTO0VBQUM7R0FDVCxNQUFNLEtBQUE7R0FDTixZQUFZLENBQUM7SUFDWCxNQUFNO0lBQ04sTUFBTSxDQUFDLFNBQVM7R0FDbEIsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZLENBQUM7SUFDWCxNQUFNO0lBQ04sTUFBTSxDQUFDLDBCQUEwQjtHQUNuQyxHQUFHLEVBQ0QsTUFBTSxTQUNSLENBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyx5QkFBeUI7R0FDbEMsR0FBRyxFQUNELE1BQU0sU0FDUixDQUFDO0VBQ0g7Q0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLHdCQUF3QjtBQUM5QixJQUFNLGlCQUFOLE1BQU0sZUFBZTtDQUVuQixZQUFZLGVBQWU7d0JBRDNCLGlCQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssZ0JBQWdCO0NBQ3ZCO0NBQ0EsVUFBVSxPQUFPLFdBQVcsUUFBUTtFQUNsQyxJQUFJLFNBQVMsTUFBTSxPQUFPO0VBQzFCLElBQUksT0FBTyxjQUFjLFlBQVksY0FBYyxNQUNqRCxNQUFNLHlCQUF5QixnQkFBZ0IsU0FBUztFQUcxRCxPQUFPLFVBREssa0JBQWtCLE9BQU8sT0FBTyxLQUFLLFNBQVMsR0FBRyxLQUFLLGVBQWUsTUFDOUQsRUFBRSxDQUFDLFFBQVEsdUJBQXVCLE1BQU0sU0FBUyxDQUFDO0NBQ3ZFO0FBVUY7O2dDQVRTLFFBQU8sU0FBUyx1QkFBdUIsbUJBQW1CO0NBRS9ELE9BQU8sS0FBSyxxQkFBcUJ3QyxpQkFBZ0I3QixrQkFBcUIsZ0JBQWdCLEVBQUUsQ0FBQztBQUMzRixDQUFBO2dDQUNPLFNBQXVCLDZCQUFnQjtDQUM1QyxNQUFNO0NBQ04sTUFBTTZCO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjeEMsaUJBQXFCLGdCQUFnQixDQUFDO0VBQ3ZGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxNQUFNLGFBQ1IsQ0FBQztDQUNILENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTSxlQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxpQkFBTixNQUFNLGVBQWU7Q0FDbkIsVUFBVSxPQUFPLFNBQVM7RUFDeEIsSUFBSSxTQUFTLE1BQU0sT0FBTztFQUMxQixJQUFJLE9BQU8sWUFBWSxZQUFZLE9BQU8sVUFBVSxVQUNsRCxNQUFNLHlCQUF5QixnQkFBZ0IsT0FBTztFQUV4RCxJQUFJLE9BQU8sT0FBTyxTQUFTLEtBQUssR0FDOUIsT0FBTyxRQUFRO0VBRWpCLElBQUksT0FBTyxPQUFPLFNBQVMsT0FBTyxHQUNoQyxPQUFPLFFBQVE7RUFFakIsT0FBTztDQUNUO0FBU0Y7O2dDQVJTLFFBQU8sU0FBUyx1QkFBdUIsbUJBQW1CO0NBQy9ELE9BQU8sS0FBSyxxQkFBcUJ5QyxpQkFBZ0I7QUFDbkQsQ0FBQTtnQ0FDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1BO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjekMsaUJBQXFCLGdCQUFnQixDQUFDO0VBQ3ZGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxNQUFNLGFBQ1IsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxXQUFOLE1BQWU7Q0FDYixVQUFVLE9BQU87RUFDZixhQUFhLGFBQWEsWUFBWSxLQUFLO0VBQzNDLE9BQU8sS0FBSyxVQUFVLE9BQU8sTUFBTSxDQUFDO0NBQ3RDO0FBU0Y7OzBCQVJTLFFBQU8sU0FBUyxpQkFBaUIsbUJBQW1CO0NBQ3pELE9BQU8sS0FBSyxxQkFBcUIwQyxXQUFVO0FBQzdDLENBQUE7MEJBQ08sU0FBdUIsNkJBQWdCO0NBQzVDLE1BQU07Q0FDTixNQUFNQTtDQUNOLE1BQU07QUFDUixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYzFDLGlCQUFxQixVQUFVLENBQUM7RUFDakYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLE1BQU07R0FDTixNQUFNO0VBQ1IsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyxpQkFBaUIsS0FBSyxPQUFPO0NBQ3BDLE9BQU87RUFDQTtFQUNFO0NBQ1Q7QUFDRjtBQUNBLElBQU0sZUFBTixNQUFtQjtDQUVqQixZQUFZLFNBQVM7d0JBRHJCLFdBQUEsS0FBQSxDQUFBO3dCQUlBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQVksQ0FBQyxDQUFBO3dCQUNiLGFBQVksaUJBQUE7RUFKVixLQUFLLFVBQVU7Q0FDakI7Q0FJQSxVQUFVLE9BQU8sWUFBWSxtQkFBbUI7O0VBQzlDLGFBQWEsYUFBYSxnQkFBZ0IsS0FBSztFQUMvQyxJQUFJLENBQUMsU0FBUyxFQUFFLGlCQUFpQixRQUFRLE9BQU8sVUFBVSxVQUN4RCxPQUFPO0VBRVQsQ0FBQSxlQUFBLEtBQUssWUFBQSxRQUFBLGlCQUFBLEtBQUEsTUFBTCxLQUFLLFNBQVcsS0FBSyxRQUFRLEtBQUssS0FBSyxDQUFDLENBQUMsT0FBTztFQUNoRCxNQUFNLGdCQUFnQixLQUFLLE9BQU8sS0FBSyxLQUFLO0VBQzVDLE1BQU0sbUJBQW1CLGNBQWMsS0FBSztFQUM1QyxJQUFJLGVBQWU7R0FDakIsS0FBSyxZQUFZLENBQUM7R0FDbEIsY0FBYyxhQUFZLE1BQUs7SUFDN0IsS0FBSyxVQUFVLEtBQUssaUJBQWlCLEVBQUUsS0FBSyxFQUFFLFlBQVksQ0FBQztHQUM3RCxDQUFDO0VBQ0g7RUFDQSxJQUFJLGlCQUFpQixrQkFBa0I7R0FDckMsSUFBSSxXQUNGLEtBQUssVUFBVSxLQUFLLFNBQVM7R0FFL0IsS0FBSyxZQUFZO0VBQ25CO0VBQ0EsT0FBTyxLQUFLO0NBQ2Q7QUFVRjs7OEJBVFMsUUFBTyxTQUFTLHFCQUFxQixtQkFBbUI7Q0FFN0QsT0FBTyxLQUFLLHFCQUFxQjJDLGVBQWNoQyxrQkFBcUJrQixpQkFBb0IsRUFBRSxDQUFDO0FBQzdGLENBQUE7OEJBQ08sU0FBdUIsNkJBQWdCO0NBQzVDLE1BQU07Q0FDTixNQUFNYztDQUNOLE1BQU07QUFDUixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYzNDLGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLE1BQU07R0FDTixNQUFNO0VBQ1IsQ0FBQztDQUNILENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTTZCLGdCQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsU0FBUyxrQkFBa0IsV0FBVyxXQUFXO0NBQy9DLE1BQU0sSUFBSSxVQUFVO0NBQ3BCLE1BQU0sSUFBSSxVQUFVO0NBQ3BCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxLQUFLLE1BQU0sT0FBTztDQUN0QixJQUFJLEtBQUssTUFBTSxPQUFPO0NBQ3RCLElBQUksT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLFVBQ3RDLE9BQU8sSUFBSSxJQUFJLEtBQUs7Q0FFdEIsSUFBSSxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssVUFDdEMsT0FBTyxJQUFJO0NBRWIsSUFBSSxPQUFPLEtBQUssYUFBYSxPQUFPLEtBQUssV0FDdkMsT0FBTyxJQUFJLElBQUksS0FBSztDQUV0QixNQUFNLFVBQVUsT0FBTyxDQUFDO0NBQ3hCLE1BQU0sVUFBVSxPQUFPLENBQUM7Q0FDeEIsT0FBTyxXQUFXLFVBQVUsSUFBSSxVQUFVLFVBQVUsS0FBSztBQUMzRDtBQUNBLElBQU0sY0FBTixNQUFNLFlBQVk7Q0FFaEIsWUFBWSxTQUFTO3dCQURyQixXQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssVUFBVTtDQUNqQjtDQUNBLFVBQVUsT0FBTyxZQUFZLFFBQVE7RUFDbkMsSUFBSSxDQUFDLFFBQVEsS0FBSyxHQUFHLE9BQU87RUFDNUIsV0FBQSxTQUFXLEtBQUs7RUFDaEIsSUFBSTtHQUVGLE9BQU8sYUFESyxZQUFZLEtBQ0YsR0FBRyxRQUFRLFVBQVU7RUFDN0MsU0FBUyxPQUFPO0dBQ2QsTUFBTSx5QkFBeUIsYUFBYSxNQUFNLE9BQU87RUFDM0Q7Q0FDRjtBQVVGOzs2QkFUUyxRQUFPLFNBQVMsb0JBQW9CLG1CQUFtQjtDQUU1RCxPQUFPLEtBQUsscUJBQXFCZSxjQUFhakMsa0JBQXFCLFdBQVcsRUFBRSxDQUFDO0FBQ25GLENBQUE7NkJBQ08sU0FBdUIsNkJBQWdCO0NBQzVDLE1BQU07Q0FDTixNQUFNaUM7Q0FDTixNQUFNO0FBQ1IsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWM1QyxpQkFBcUIsYUFBYSxDQUFDO0VBQ3BGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxNQUFNLFNBQ1IsQ0FBQztDQUNILENBQUMsU0FBUyxDQUFDO0VBQ1QsTUFBTSxLQUFBO0VBQ04sWUFBWSxDQUFDO0dBQ1gsTUFBTTtHQUNOLE1BQU0sQ0FBQyxTQUFTO0VBQ2xCLENBQUM7Q0FDSCxDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sY0FBTixNQUFNLFlBQVk7Q0FFaEIsWUFBWSxTQUFTO3dCQURyQixXQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssVUFBVTtDQUNqQjtDQUNBLFVBQVUsT0FBTyxZQUFZLFFBQVE7RUFDbkMsSUFBSSxDQUFDLFFBQVEsS0FBSyxHQUFHLE9BQU87RUFDNUIsV0FBQSxTQUFXLEtBQUs7RUFDaEIsSUFBSTtHQUVGLE9BQU8sY0FESyxZQUFZLEtBQ0QsR0FBRyxRQUFRLFVBQVU7RUFDOUMsU0FBUyxPQUFPO0dBQ2QsTUFBTSx5QkFBeUIsYUFBYSxNQUFNLE9BQU87RUFDM0Q7Q0FDRjtBQVVGOzs2QkFUUyxRQUFPLFNBQVMsb0JBQW9CLG1CQUFtQjtDQUU1RCxPQUFPLEtBQUsscUJBQXFCNkMsY0FBYWxDLGtCQUFxQixXQUFXLEVBQUUsQ0FBQztBQUNuRixDQUFBOzZCQUNPLFNBQXVCLDZCQUFnQjtDQUM1QyxNQUFNO0NBQ04sTUFBTWtDO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjN0MsaUJBQXFCLGFBQWEsQ0FBQztFQUNwRixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsTUFBTSxVQUNSLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQztFQUNULE1BQU0sS0FBQTtFQUNOLFlBQVksQ0FBQztHQUNYLE1BQU07R0FDTixNQUFNLENBQUMsU0FBUztFQUNsQixDQUFDO0NBQ0gsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLGVBQU4sTUFBTSxhQUFhO0NBR2pCLFlBQVksU0FBUyx1QkFBdUIsT0FBTzt3QkFGbkQsV0FBQSxLQUFBLENBQUE7d0JBQ0Esd0JBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxVQUFVO0VBQ2YsS0FBSyx1QkFBdUI7Q0FDOUI7Q0FDQSxVQUFVLE9BQU8sZUFBZSxLQUFLLHNCQUFzQixVQUFVLFVBQVUsWUFBWSxRQUFRO0VBQ2pHLElBQUksQ0FBQyxRQUFRLEtBQUssR0FBRyxPQUFPO0VBQzVCLFdBQUEsU0FBVyxLQUFLO0VBQ2hCLElBQUksT0FBTyxZQUFZLFdBQVc7R0FDaEMsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUN0QyxRQUFRLEtBQUssME1BQTBNO0dBRXpOLFVBQVUsVUFBVSxXQUFXO0VBQ2pDO0VBQ0EsSUFBSSxXQUFXLGdCQUFnQixLQUFLO0VBQ3BDLElBQUksWUFBWSxRQUNkLElBQUksWUFBWSxZQUFZLFlBQVksaUJBQ3RDLFdBQVcsa0JBQWtCLFVBQVUsWUFBWSxXQUFXLFNBQVMsVUFBVSxNQUFNO09BRXZGLFdBQVc7RUFHZixJQUFJO0dBRUYsT0FBTyxlQURLLFlBQVksS0FDQSxHQUFHLFFBQVEsVUFBVSxjQUFjLFVBQVU7RUFDdkUsU0FBUyxPQUFPO0dBQ2QsTUFBTSx5QkFBeUIsY0FBYyxNQUFNLE9BQU87RUFDNUQ7Q0FDRjtBQVVGOzs4QkFUUyxRQUFPLFNBQVMscUJBQXFCLG1CQUFtQjtDQUU3RCxPQUFPLEtBQUsscUJBQXFCOEMsZUFBY25DLGtCQUFxQixXQUFXLEVBQUUsR0FBR0Esa0JBQXFCLHVCQUF1QixFQUFFLENBQUM7QUFDckksQ0FBQTs4QkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1tQztDQUNOLE1BQU07QUFDUixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYzlDLGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLE1BQU0sV0FDUixDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUM7RUFDVCxNQUFNLEtBQUE7RUFDTixZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLFNBQVM7RUFDbEIsQ0FBQztDQUNILEdBQUc7RUFDRCxNQUFNLEtBQUE7RUFDTixZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLHFCQUFxQjtFQUM5QixDQUFDO0NBQ0gsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxTQUFTLFFBQVEsT0FBTztDQUN0QixPQUFPLEVBQUUsU0FBUyxRQUFRLFVBQVUsTUFBTSxVQUFVO0FBQ3REO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsSUFBSSxPQUFPLFVBQVUsWUFBWSxDQUFDLE1BQU0sT0FBTyxLQUFLLElBQUksV0FBVyxLQUFLLENBQUMsR0FDdkUsT0FBTyxPQUFPLEtBQUs7Q0FFckIsSUFBSSxPQUFPLFVBQVUsVUFDbkIsTUFBTSxJQUFJSyxhQUFjLE1BQU0sYUFBYSxHQUFHLE1BQU0saUJBQWlCO0NBRXZFLE9BQU87QUFDVDtBQUNBLElBQU0sWUFBTixNQUFNLFVBQVU7Q0FDZCxVQUFVLE9BQU8sT0FBTyxLQUFLO0VBQzNCLElBQUksU0FBUyxNQUFNLE9BQU87RUFFMUIsSUFBSSxFQURhLE9BQU8sVUFBVSxZQUFZLE1BQU0sUUFBUSxLQUFLLElBRS9ELE1BQU0seUJBQXlCLFdBQVcsS0FBSztFQUVqRCxPQUFPLE1BQU0sTUFBTSxPQUFPLEdBQUc7Q0FDL0I7QUFTRjs7MkJBUlMsUUFBTyxTQUFTLGtCQUFrQixtQkFBbUI7Q0FDMUQsT0FBTyxLQUFLLHFCQUFxQjBDLFlBQVc7QUFDOUMsQ0FBQTsyQkFDTyxTQUF1Qiw2QkFBZ0I7Q0FDNUMsTUFBTTtDQUNOLE1BQU1BO0NBQ04sTUFBTTtBQUNSLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjL0MsaUJBQXFCLFdBQVcsQ0FBQztFQUNsRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsTUFBTTtHQUNOLE1BQU07RUFDUixDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLGVBQWU7Q0FBQztDQUFXO0NBQWU7Q0FBZTtDQUFVO0NBQVc7Q0FBYTtDQUFhO0NBQWU7Q0FBYztDQUFVO0NBQWdCO0NBQWdCO0FBQVk7QUFDak0sSUFBTSxlQUFOLE1BQW1CLENBVW5COzs4QkFUUyxRQUFPLFNBQVMscUJBQXFCLG1CQUFtQjtDQUM3RCxPQUFPLEtBQUsscUJBQXFCZ0QsZUFBYztBQUNqRCxDQUFBOzhCQUNPLFFBQXNCLGlDQUFvQjtDQUMvQyxNQUFNQTtDQUNOLFNBQVM7RUFBQztFQUFTO0VBQW1CO0VBQVM7RUFBTTtFQUFrQjtFQUFTO0VBQVU7RUFBYztFQUFpQjtFQUFVO0VBQWM7RUFBVztFQUFlO0VBQWU7RUFBVTtFQUFXO0VBQWE7RUFBYTtFQUFlO0VBQWM7RUFBVTtFQUFnQjtFQUFnQjtDQUFZO0NBQzVULFNBQVM7RUFBQztFQUFTO0VBQW1CO0VBQVM7RUFBTTtFQUFrQjtFQUFTO0VBQVU7RUFBYztFQUFpQjtFQUFVO0VBQWM7RUFBVztFQUFlO0VBQWU7RUFBVTtFQUFXO0VBQWE7RUFBYTtFQUFlO0VBQWM7RUFBVTtFQUFnQjtFQUFnQjtDQUFZO0FBQzlULENBQUMsQ0FBQTs4QkFDTSxRQUFzQixpQ0FBb0IsQ0FBQyxDQUFDLENBQUE7T0FFOUM7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNoRCxpQkFBcUIsY0FBYyxDQUFDO0VBQ3JGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxTQUFTLENBQUMsbUJBQW1CLFlBQVk7R0FDekMsU0FBUyxDQUFDLG1CQUFtQixZQUFZO0VBQzNDLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRzs7Ozs7Ozs7O0FDeHlGSCxJQUFNLDhCQUE4QixJQUFJLGVBQWUsSUFBSSxFQUN6RCxlQUFlO0NBQ2IsT0FBTyxPQUFPLFdBQVcsZUFBZSxPQUFPLE9BQU8sa0NBQWtDO0FBQzFGLEVBQ0YsQ0FBQztBQUNELElBQU0scUJBQU4sTUFBeUIsQ0FTekI7O29DQVJTLFFBQU8sU0FBUywyQkFBMkIsbUJBQW1CO0NBQ25FLE9BQU8sS0FBSyxxQkFBcUJpRCxxQkFBb0I7QUFDdkQsQ0FBQTtvQ0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0E7Q0FDUCxzQkFBc0IsT0FBTyxXQUFBLENBQVk7Q0FDekMsWUFBWTtBQUNkLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjQyxpQkFBcUIsb0JBQW9CLENBQUM7RUFDM0YsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFlBQVk7R0FDWixrQkFBa0IsT0FBTztFQUMzQixDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7Ozs7Ozs7Ozs7Ozs7O0FDZEgsSUFBTSwrQkFBTixjQUEyQyxTQUFTO0NBR2xELGNBQWM7RUFDWixNQUFNLE9BQU8sZ0JBQWdCLENBQUM7d0JBSGhDLGNBQWEsT0FBTyxrQkFBa0IsQ0FBQTt3QkFDdEMsY0FBYSxPQUFPLFVBQVUsQ0FBQTtFQUc1QixLQUFLLDRCQUE0QjtDQUNuQztDQUNBLDhCQUE4QjtFQUM1QixNQUFNLG1DQUFtQztHQUN2QyxLQUFLLDBCQUEwQixLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssU0FBUyxDQUFDO0VBQ2pFO0VBQ0EsS0FBSyxXQUFXLGlCQUFpQixzQkFBc0IsMEJBQTBCO0VBQ2pGLEtBQUssV0FBVyxnQkFBZ0I7R0FDOUIsS0FBSyxXQUFXLG9CQUFvQixzQkFBc0IsMEJBQTBCO0VBQ3RGLENBQUM7Q0FDSDtDQUNBLFdBQVc7O0VBQ1QsUUFBQSx3QkFBTyxLQUFLLFdBQVcsa0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFjLFNBQVM7Q0FDaEQ7Q0FDQSxhQUFhLE1BQU0sUUFBUSxJQUFJLFFBQVEsTUFBTTtFQUMzQyxNQUFNLE1BQU0sS0FBSyxtQkFBbUIsT0FBTyxxQkFBcUIsS0FBSyxDQUFDO0VBQ3RFLEtBQUssV0FBVyxTQUFTLEtBQUs7R0FDNUI7R0FDQSxTQUFTO0VBQ1gsQ0FBQztDQUNIO0NBQ0EsR0FBRyxNQUFNLFFBQVEsSUFBSSxRQUFRLE1BQU07RUFDakMsTUFBTSxNQUFNLEtBQUssbUJBQW1CLE9BQU8scUJBQXFCLEtBQUssQ0FBQztFQUN0RSxLQUFLLFdBQVcsU0FBUyxLQUFLO0dBQzVCO0dBQ0EsU0FBUztFQUNYLENBQUM7Q0FDSDtDQUNBLE9BQU87RUFDTCxLQUFLLFdBQVcsS0FBSztDQUN2QjtDQUNBLFVBQVU7RUFDUixLQUFLLFdBQVcsUUFBUTtDQUMxQjtDQUNBLFlBQVksSUFBSTtFQUNkLEtBQUssb0JBQW9CLEtBQUssRUFBRTtFQUNoQyxhQUFhO0dBQ1gsTUFBTSxVQUFVLEtBQUssb0JBQW9CLFFBQVEsRUFBRTtHQUNuRCxLQUFLLG9CQUFvQixPQUFPLFNBQVMsQ0FBQztFQUM1QztDQUNGO0FBUUY7OzhDQVBTLFFBQU8sU0FBUyxxQ0FBcUMsbUJBQW1CO0NBQzdFLE9BQU8sS0FBSyxxQkFBcUJDLCtCQUE4QjtBQUNqRSxDQUFBOzhDQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPQTtDQUNQLFNBQVNBLDhCQUE2QjtBQUN4QyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0MsaUJBQXFCLDhCQUE4QixDQUFDLEVBQ3JHLE1BQU0sV0FDUixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFDcEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyxtQkFBbUIsTUFBTSxVQUFVLFdBQVc7Q0FDckQsT0FBT0MscUJBQW9CLE1BQU0sVUFBVSxTQUFTO0FBQ3REO0FBQ0EsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxxQkFBcUI7QUFDM0IsU0FBUyxrQkFBa0IsWUFBWTtDQUNyQyxPQUFPLGVBQWU7QUFDeEI7QUFDQSxTQUFTLGlCQUFpQixZQUFZO0NBQ3BDLE9BQU8sZUFBZTtBQUN4QjtBQUNBLElBQU0sMEJBQXlCLElBQUksUUFBUSxRQUFRO0FBQ25ELElBQU0sbUJBQU4sTUFBdUIsQ0FPdkI7O2tDQU5TLFNBQ1AsbUNBQW1CO0NBQ2pCLE9BQU9DO0NBQ1AsWUFBWTtDQUNaLGVBQWtHLElBQUksd0JBQXdCLE9BQU8sUUFBUSxHQUFHLE1BQU07QUFDeEosQ0FBQyxDQUFBO0FBRUgsSUFBTSwwQkFBTixNQUE4QjtDQUk1QixZQUFZLFVBQVUsUUFBUTt3QkFIOUIsWUFBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7d0JBQ0EsZ0JBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQTtFQUVsQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxTQUFTO0NBQ2hCO0NBQ0EsVUFBVSxRQUFRO0VBQ2hCLElBQUksTUFBTSxRQUFRLE1BQU0sR0FDdEIsS0FBSyxlQUFlO09BRXBCLEtBQUssU0FBUztDQUVsQjtDQUNBLG9CQUFvQjtFQUNsQixPQUFPLENBQUMsS0FBSyxPQUFPLFNBQVMsS0FBSyxPQUFPLE9BQU87Q0FDbEQ7Q0FDQSxpQkFBaUIsVUFBVSxTQUFTO0VBQ2xDLEtBQUssT0FBTyxTQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ1AsT0FBQSxHQUFBLENBQUEsR0FBQTtHQUNILE1BQU0sU0FBUztHQUNmLEtBQUssU0FBUztHQUNoQixDQUFDO0NBQ0g7Q0FDQSxlQUFlLFFBQVEsU0FBUztFQUM5QixNQUFNLGFBQWEsdUJBQXVCLEtBQUssVUFBVSxNQUFNO0VBQy9ELElBQUksWUFBWTtHQUNkLEtBQUssZ0JBQWdCLFlBQVksT0FBTztHQUN4QyxXQUFXLE1BQU0sRUFDZixlQUFlLEtBQ2pCLENBQUM7RUFDSDtDQUNGO0NBQ0EsNEJBQTRCLG1CQUFtQjtFQUM3QyxJQUFJO0dBQ0YsS0FBSyxPQUFPLFFBQVEsb0JBQW9CO0VBQzFDLFNBQUEsU0FBUTtHQUNOLFFBQVEsS0FBS0MsbUJBQW9CLE1BQU0sYUFBYSxnV0FBeVgsQ0FBQztFQUNoYjtDQUNGO0NBQ0EsZ0JBQWdCLElBQUksU0FBUztFQUMzQixNQUFNLE9BQU8sR0FBRyxzQkFBc0I7RUFDdEMsTUFBTSxPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU87RUFDckMsTUFBTSxNQUFNLEtBQUssTUFBTSxLQUFLLE9BQU87RUFDbkMsTUFBTSxTQUFTLEtBQUssT0FBTztFQUMzQixLQUFLLE9BQU8sU0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNQLE9BQUEsR0FBQSxDQUFBLEdBQUE7R0FDSCxNQUFNLE9BQU8sT0FBTztHQUNwQixLQUFLLE1BQU0sT0FBTztHQUNwQixDQUFDO0NBQ0g7QUFDRjtBQUNBLFNBQVMsdUJBQXVCLFVBQVUsUUFBUTtDQUNoRCxNQUFNLGlCQUFpQixTQUFTLGVBQWUsTUFBTSxLQUFLLFNBQVMsa0JBQWtCLE1BQU0sQ0FBQyxDQUFDO0NBQzdGLElBQUksZ0JBQ0YsT0FBTztDQUVULElBQUksT0FBTyxTQUFTLHFCQUFxQixjQUFjLFNBQVMsUUFBUSxPQUFPLFNBQVMsS0FBSyxpQkFBaUIsWUFBWTtFQUN4SCxNQUFNLGFBQWEsU0FBUyxpQkFBaUIsU0FBUyxNQUFNLFdBQVcsWUFBWTtFQUNuRixJQUFJLGNBQWMsV0FBVztFQUM3QixPQUFPLGFBQWE7R0FDbEIsTUFBTSxhQUFhLFlBQVk7R0FDL0IsSUFBSSxZQUFZO0lBQ2QsTUFBTSxTQUFTLFdBQVcsZUFBZSxNQUFNLEtBQUssV0FBVyxjQUFjLFVBQVUsSUFBSSxPQUFPLE1BQU0sRUFBRSxHQUFHO0lBQzdHLElBQUksUUFDRixPQUFPO0dBRVg7R0FDQSxjQUFjLFdBQVcsU0FBUztFQUNwQztDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSx1QkFBTixNQUEyQjtDQUN6QixVQUFVLFFBQVEsQ0FBQztDQUNuQixvQkFBb0I7RUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQztDQUNkO0NBQ0EsaUJBQWlCLFVBQVUsQ0FBQztDQUM1QixlQUFlLFFBQVEsU0FBUyxDQUFDO0NBQ2pDLDRCQUE0QixtQkFBbUIsQ0FBQztBQUNsRDtBQUNBLElBQU0sc0JBQXNCO0FBQzVCLFNBQVMsT0FBTyxLQUFLLEtBQUs7Q0FDeEIsT0FBTyxjQUFjLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJO0FBQzNFO0FBQ0EsU0FBUyxjQUFjLEtBQUs7Q0FDMUIsT0FBTyxlQUFlLEtBQUssR0FBRztBQUNoQztBQUNBLFNBQVMsZ0JBQWdCLEtBQUs7Q0FDNUIsT0FBTyxjQUFjLEdBQUcsSUFBSSxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsV0FBVztBQUN0RDtBQUNBLFNBQVMsWUFBWSxNQUFNO0NBRXpCLElBQUksRUFEYSxPQUFPLFNBQVMsYUFDaEIsS0FBSyxLQUFLLE1BQU0sSUFDL0IsT0FBTztDQUVULElBQUk7RUFDVSxJQUFJLElBQUksSUFBSTtFQUN4QixPQUFPO0NBQ1QsU0FBQSxVQUFRO0VBQ04sT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsTUFBTTtDQUMzQixPQUFPLEtBQUssU0FBUyxHQUFHLElBQUksS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQ2xEO0FBQ0EsU0FBUyxhQUFhLEtBQUs7Q0FDekIsT0FBTyxJQUFJLFdBQVcsR0FBRyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUk7QUFDOUM7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUMzQixPQUFPLE1BQU0sUUFBUSxPQUFPLE1BQU0sQ0FBQyxDQUFDLFFBQVEsZUFBZSxFQUFFLENBQUMsQ0FBQyxRQUFRLE1BQU0sTUFBSztBQUNwRjtBQUNBLElBQU0sbUJBQWtCLFdBQVUsT0FBTztBQUN6QyxJQUFNLGVBQWUsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksZ0JBQWdCLElBQUksRUFDMUcsZUFBZSxnQkFDakIsQ0FBQztBQUNELFNBQVMsa0JBQWtCLFlBQVksYUFBYTtDQUNsRCxPQUFPLFNBQVMsbUJBQW1CLE1BQU07RUFDdkMsSUFBSSxDQUFDLFlBQVksSUFBSSxHQUNuQixzQkFBc0IsTUFBTSxlQUFlLENBQUMsQ0FBQztFQUUvQyxPQUFPLGNBQWMsSUFBSTtFQUN6QixNQUFNLFlBQVcsV0FBVTtHQUN6QixJQUFJLGNBQWMsT0FBTyxHQUFHLEdBQzFCLGdDQUFnQyxNQUFNLE9BQU8sR0FBRztHQUVsRCxPQUFPLFdBQVcsTUFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNiLE1BQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCxLQUFLLGFBQWEsT0FBTyxHQUFHLEVBQUEsQ0FDOUIsQ0FBQztFQUNIO0VBS0EsT0FBTyxDQUpZO0dBQ2pCLFNBQVM7R0FDVCxVQUFVO0VBQ1osQ0FDZTtDQUNqQjtBQUNGO0FBQ0EsU0FBUyxzQkFBc0IsTUFBTSxhQUFhO0NBQ2hELE1BQU0sSUFBSUMsYUFBYyxNQUFNLGFBQWEsZ0RBQWdELEtBQUssc0VBQTJFLFlBQVksS0FBSyxNQUFNLEdBQUc7QUFDdk07QUFDQSxTQUFTLGdDQUFnQyxNQUFNLEtBQUs7Q0FDbEQsTUFBTSxJQUFJQSxhQUFjLE1BQU0sYUFBYSxrRkFBa0YsSUFBSSw4TUFBa08sS0FBSyxLQUFLO0FBQy9XO0FBQ0EsU0FBUyx5QkFBeUIsV0FBVyxXQUFXO0NBQ3RELElBQUksT0FBTyxjQUFjLFVBQ3ZCLE9BQU87Q0FFVCxPQUFPLE9BQU8sUUFBUSxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXLEdBQUcsTUFBTSxZQUFZLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRztBQUMvRjtBQUNBLElBQU0sMEJBQTBCLGtCQUFrQixxQkFBcUIsWUFBWSxDQUFDLHVEQUF1RCxJQUFJLEtBQUEsQ0FBUztBQUN4SixTQUFTLG9CQUFvQixNQUFNLFFBQVE7O0NBQ3pDLElBQUksU0FBUztDQUNiLElBQUksT0FBTyxPQUNULFVBQVUsVUFBVSxPQUFPO0NBRTdCLElBQUksT0FBTyxRQUNULFVBQVUsV0FBVyxPQUFPO0NBRTlCLElBQUksT0FBTyxlQUNULFVBQVUsWUFBWTtDQUV4QixLQUFBLHVCQUFJLE9BQU8sa0JBQUEsUUFBQSx5QkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHFCQUFlLGNBQWM7RUFDdEMsTUFBTSxlQUFlLHlCQUF5QixPQUFPLGFBQWEsY0FBYyxHQUFHO0VBQ25GLFVBQVUsSUFBSTtDQUNoQjtDQUNBLE9BQU8sR0FBRyxLQUFLLGlCQUFpQixPQUFPLEdBQUcsT0FBTztBQUNuRDtBQUNBLElBQU0sdUJBQXVCO0NBQzNCLE1BQU07Q0FDTixTQUFTO0FBQ1g7QUFDQSxJQUFNLDBCQUEwQjtBQUNoQyxTQUFTLGdCQUFnQixLQUFLO0NBQzVCLE9BQU8sd0JBQXdCLEtBQUssR0FBRztBQUN6QztBQUNBLElBQU0sMEJBQTBCLGtCQUFrQixxQkFBcUIsWUFBWTtDQUFDO0NBQXFDO0NBQWlDO0FBQThCLElBQUksS0FBQSxDQUFTO0FBQ3JNLFNBQVMsb0JBQW9CLE1BQU0sUUFBUTs7Q0FFekMsSUFBSSxTQUFTLFVBREcsT0FBTyxnQkFBZ0IsZUFBZTtDQUV0RCxJQUFJLE9BQU8sT0FDVCxVQUFVLE1BQU0sT0FBTztDQUV6QixJQUFJLE9BQU8sUUFDVCxVQUFVLE1BQU0sT0FBTztDQUV6QixLQUFBLHdCQUFJLE9BQU8sa0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFlLFlBQ3hCLFVBQVU7Q0FFWixLQUFBLHdCQUFJLE9BQU8sa0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFlLGNBQWM7RUFDdEMsTUFBTSxlQUFlLHlCQUF5QixPQUFPLGFBQWEsY0FBYyxHQUFHO0VBQ25GLFVBQVUsSUFBSTtDQUNoQjtDQUNBLE9BQU8sR0FBRyxLQUFLLGdCQUFnQixPQUFPLEdBQUcsT0FBTztBQUNsRDtBQUNBLElBQU0scUJBQXFCO0NBQ3pCLE1BQU07Q0FDTixTQUFTO0FBQ1g7QUFDQSxJQUFNLHlCQUF5QjtBQUMvQixTQUFTLGNBQWMsS0FBSztDQUMxQixPQUFPLHVCQUF1QixLQUFLLEdBQUc7QUFDeEM7QUFDQSxJQUFNLHdCQUF3QixrQkFBa0IsbUJBQW1CLFlBQVksQ0FBQyxpQ0FBaUMsOEJBQThCLElBQUksS0FBQSxDQUFTO0FBQzVKLFNBQVMsa0JBQWtCLE1BQU0sUUFBUTs7Q0FDdkMsTUFBTSxFQUNKLEtBQ0EsVUFDRTtDQUNKLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLElBQUksT0FDRixPQUFPLEtBQUssS0FBSyxPQUFPO0NBRTFCLElBQUksT0FBTyxRQUNULE9BQU8sS0FBSyxLQUFLLE9BQU8sUUFBUTtDQUVsQyxJQUFJLE9BQU8sZUFDVCxPQUFPLEtBQUssS0FBSyxxQkFBcUI7Q0FFeEMsS0FBQSx3QkFBSSxPQUFPLGtCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxzQkFBZSxjQUFjO0VBQ3RDLE1BQU0sZUFBZSx5QkFBeUIsT0FBTyxhQUFhLGNBQWMsR0FBRztFQUNuRixPQUFPLEtBQUssWUFBWTtDQUMxQjtDQUNBLE1BQU0sY0FBYyxPQUFPLFNBQVM7RUFBQztFQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7RUFBSztDQUFHLElBQUksQ0FBQyxNQUFNLEdBQUc7Q0FFdEYsT0FBTyxJQURTLElBQUksWUFBWSxLQUFLLEdBQUcsQ0FDL0IsQ0FBQyxDQUFDO0FBQ2I7QUFDQSxJQUFNLGtCQUFrQjtDQUN0QixNQUFNO0NBQ04sU0FBUztBQUNYO0FBQ0EsSUFBTSxxQkFBcUI7QUFDM0IsU0FBUyxXQUFXLEtBQUs7Q0FDdkIsT0FBTyxtQkFBbUIsS0FBSyxHQUFHO0FBQ3BDO0FBQ0EsSUFBTSxxQkFBcUIsa0JBQWtCLGdCQUFnQixZQUFZLENBQUMsNkJBQTZCLElBQUksS0FBQSxDQUFTO0FBQ3BILFNBQVMsZUFBZSxNQUFNLFFBQVE7O0NBQ3BDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE9BQU8sS0FBSyxhQUFhO0NBQ3pCLElBQUksT0FBTyxPQUNULE9BQU8sS0FBSyxLQUFLLE9BQU8sT0FBTztDQUVqQyxJQUFJLE9BQU8sUUFDVCxPQUFPLEtBQUssS0FBSyxPQUFPLFFBQVE7Q0FFbEMsSUFBSSxPQUFPLGVBQ1QsT0FBTyxLQUFLLEtBQUsscUJBQXFCO0NBRXhDLEtBQUEsd0JBQUksT0FBTyxrQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQWUsY0FBYztFQUN0QyxNQUFNLFlBQVkseUJBQXlCLE9BQU8sYUFBYSxjQUFjLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRztFQUMzRixPQUFPLEtBQUssR0FBRyxTQUFTO0NBQzFCO0NBQ0EsTUFBTSxNQUFNLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRyxPQUFPLEtBQUs7Q0FDM0MsSUFBSSxTQUFTLE9BQU8sS0FBSyxHQUFHO0NBQzVCLE9BQU8sSUFBSTtBQUNiO0FBQ0EsSUFBTSxvQkFBb0I7Q0FDeEIsTUFBTTtDQUNOLFNBQVM7QUFDWDtBQUNBLElBQU0sdUJBQXVCO0FBQzdCLFNBQVMsYUFBYSxLQUFLO0NBQ3pCLE9BQU8scUJBQXFCLEtBQUssR0FBRztBQUN0QztBQUNBLFNBQVMscUJBQXFCLE1BQU07Q0FDbEMsSUFBSSxRQUFRLENBQUMsWUFBWSxJQUFJLEdBQzNCLE1BQU0sSUFBSUEsYUFBYyxNQUFNLGFBQWEsZ0RBQWdELEtBQUssNkdBQWtIO0NBRXBOLElBQUksTUFFRixPQUFPLElBRFMsSUFBSSxJQUNYLENBQUMsQ0FBQztDQUViLE1BQU0sWUFBVyxXQUFVO0VBQ3pCLE9BQU8saUJBQWlCLFFBQVEsSUFBSTtDQUN0QztDQUtBLE9BQU8sQ0FKWTtFQUNqQixTQUFTO0VBQ1QsVUFBVTtDQUNaLENBQ2U7QUFDakI7QUFDQSxJQUFNLDhCQUFjLElBQUksSUFBSTtDQUFDLENBQUMsVUFBVSxHQUFHO0NBQUcsQ0FBQyxPQUFPLEtBQUs7Q0FBRyxDQUFDLFdBQVcsR0FBRztDQUFHLENBQUMsS0FBSyxHQUFHO0NBQUcsQ0FBQyxZQUFZLFVBQVU7QUFBQyxDQUFDO0FBQ3JILFNBQVMsaUJBQWlCLFFBQVEsTUFBTTs7Q0FDdEMsTUFBTSxNQUFNLElBQUksSUFBSSxTQUFBLFFBQUEsU0FBQSxLQUFBLElBQUEsT0FBUSxZQUFZO0NBQ3hDLElBQUksV0FBVztDQUNmLElBQUksQ0FBQyxjQUFjLE9BQU8sR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLFdBQVcsR0FBRyxHQUMxRCxPQUFPLE1BQU0sTUFBTSxPQUFPO0NBRTVCLElBQUksYUFBYSxJQUFJLE9BQU8sT0FBTyxHQUFHO0NBQ3RDLElBQUksT0FBTyxPQUNULElBQUksYUFBYSxJQUFJLEtBQUssT0FBTyxNQUFNLFNBQVMsQ0FBQztDQUVuRCxJQUFJLE9BQU8sUUFDVCxJQUFJLGFBQWEsSUFBSSxLQUFLLE9BQU8sT0FBTyxTQUFTLENBQUM7Q0FFcEQsTUFBTSxpQkFBQSx5QkFBQSx3QkFBZ0IsT0FBTyxrQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQWUsZ0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEseUJBQUEsd0JBQWMsT0FBTyxrQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQWU7Q0FDaEYsSUFBSSxPQUFPLGlCQUFpQixDQUFDLGVBQzNCLElBQUksYUFBYSxJQUFJLEtBQUssbUJBQW1CO0NBRS9DLEtBQUssTUFBTSxDQUFDLE9BQU8sVUFBVSxPQUFPLFNBQUEsd0JBQVEsT0FBTyxrQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBZ0IsQ0FBQyxDQUFDLEdBQ25FLElBQUksWUFBWSxJQUFJLEtBQUssR0FDdkIsSUFBSSxhQUFhLElBQUksWUFBWSxJQUFJLEtBQUssR0FBRyxNQUFNLFNBQVMsQ0FBQztNQUU3RCxJQUFJLFdBQ0YsUUFBUSxLQUFLRCxtQkFBb0IsTUFBTSw0RkFBNEYsTUFBTSxLQUFLLENBQUM7Q0FJckosT0FBTyxJQUFJLGFBQWEsTUFBTSxJQUFJLEtBQUssUUFBUSxJQUFJLFFBQVEsRUFBRSxJQUFJLElBQUk7QUFDdkU7QUFDQSxTQUFTLG9CQUFvQixPQUFPLGVBQWUsTUFBTTtDQUV2RCxPQUFPLGtDQURXLGVBQWUsb0RBQW9ELE1BQU0sU0FBUyxHQUNqRDtBQUNyRDtBQUNBLFNBQVMsY0FBYyxXQUFXO0NBQ2hDLElBQUksQ0FBQyxXQUNILE1BQU0sSUFBSUMsYUFBYyxNQUFNLGdDQUFnQyxVQUFVLHlGQUE4RjtBQUUxSztBQUNBLElBQU0sbUJBQU4sTUFBdUI7Q0FJckIsY0FBYzt3QkFIZCwwQkFBUyxJQUFJLElBQUksQ0FBQTt3QkFDakIsVUFBUyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFdBQUE7d0JBQzFCLFlBQVcsSUFBQTtFQUVULGNBQWMsYUFBYTtFQUMzQixJQUE4RCxPQUFPLHdCQUF3QixhQUMzRixLQUFLLFdBQVcsS0FBSyx3QkFBd0I7Q0FFakQ7Q0FDQSwwQkFBMEI7RUFDeEIsTUFBTSxXQUFXLElBQUkscUJBQW9CLGNBQWE7O0dBQ3BELE1BQU0sVUFBVSxVQUFVLFdBQVc7R0FDckMsSUFBSSxRQUFRLFdBQVcsR0FBRztHQUUxQixNQUFNLFVBQUEseUJBQUEsc0JBRGEsUUFBUSxRQUFRLFNBQVMsRUFDbkIsQ0FBQyxhQUFBLFFBQUEsd0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxvQkFBUyxTQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFPO0dBQzFDLElBQUksT0FBTyxXQUFXLE9BQU8sS0FBSyxPQUFPLFdBQVcsT0FBTyxHQUFHO0dBQzlELE1BQU0sTUFBTSxLQUFLLE9BQU8sSUFBSSxNQUFNO0dBQ2xDLElBQUksQ0FBQyxLQUFLO0dBQ1YsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLElBQUksdUJBQXVCO0lBQy9DLElBQUksd0JBQXdCO0lBQzVCLHdCQUF3QixNQUFNO0dBQ2hDO0dBQ0EsSUFBSSxJQUFJLFlBQVksQ0FBQyxJQUFJLHVCQUF1QjtJQUM5QyxJQUFJLHdCQUF3QjtJQUM1QixtQkFBbUIsTUFBTTtHQUMzQjtFQUNGLENBQUM7RUFDRCxTQUFTLFFBQVE7R0FDZixNQUFNO0dBQ04sVUFBVTtFQUNaLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxjQUFjLGNBQWMsWUFBWTtFQUN0QyxJQUFJLENBQUMsS0FBSyxVQUFVO0VBQ3BCLE1BQU0sTUFBTSxPQUFPLGNBQWMsS0FBSyxNQUFNLENBQUMsQ0FBQztFQUM5QyxNQUFNLGdCQUFnQixLQUFLLE9BQU8sSUFBSSxHQUFHO0VBQ3pDLElBQUksZUFBZTtHQUNqQixjQUFjLFdBQVcsY0FBYyxZQUFZO0dBQ25ELGNBQWM7RUFDaEIsT0FBTztHQUNMLE1BQU0sd0JBQXdCO0lBQzVCLFVBQVU7SUFDVixVQUFVO0lBQ1YsdUJBQXVCO0lBQ3ZCLHVCQUF1QjtJQUN2QixPQUFPO0dBQ1Q7R0FDQSxLQUFLLE9BQU8sSUFBSSxLQUFLLHFCQUFxQjtFQUM1QztDQUNGO0NBQ0EsZ0JBQWdCLGNBQWM7RUFDNUIsSUFBSSxDQUFDLEtBQUssVUFBVTtFQUNwQixNQUFNLE1BQU0sT0FBTyxjQUFjLEtBQUssTUFBTSxDQUFDLENBQUM7RUFDOUMsTUFBTSxnQkFBZ0IsS0FBSyxPQUFPLElBQUksR0FBRztFQUN6QyxJQUFJLGVBQWU7R0FDakIsY0FBYztHQUNkLElBQUksY0FBYyxTQUFTLEdBQ3pCLEtBQUssT0FBTyxPQUFPLEdBQUc7RUFFMUI7Q0FDRjtDQUNBLFlBQVksYUFBYSxRQUFRO0VBQy9CLElBQUksQ0FBQyxLQUFLLFVBQVU7RUFDcEIsTUFBTSxjQUFjLE9BQU8sYUFBYSxLQUFLLE1BQU0sQ0FBQyxDQUFDO0VBQ3JELE1BQU0sU0FBUyxPQUFPLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQztFQUMzQyxJQUFJLGdCQUFnQixRQUFRO0VBQzVCLE1BQU0sZ0JBQWdCLEtBQUssT0FBTyxJQUFJLFdBQVc7RUFDakQsSUFBSSxDQUFDLGVBQWU7RUFDcEIsY0FBYztFQUNkLElBQUksY0FBYyxTQUFTLEdBQ3pCLEtBQUssT0FBTyxPQUFPLFdBQVc7RUFFaEMsTUFBTSxXQUFXLEtBQUssT0FBTyxJQUFJLE1BQU07RUFDdkMsSUFBSSxVQUFVO0dBQ1osU0FBUyxXQUFXLFNBQVMsWUFBWSxjQUFjO0dBQ3ZELFNBQVMsV0FBVztHQUNwQixTQUFTLHdCQUF3QixTQUFTLHlCQUF5QixjQUFjO0dBQ2pGLFNBQVMsd0JBQXdCLFNBQVMseUJBQXlCLGNBQWM7R0FDakYsU0FBUztFQUNYLE9BQ0UsS0FBSyxPQUFPLElBQUksUUFBUTtHQUN0QixVQUFVLGNBQWM7R0FDeEIsVUFBVTtHQUNWLHVCQUF1QixjQUFjO0dBQ3JDLHVCQUF1QixjQUFjO0dBQ3JDLE9BQU87RUFDVCxDQUFDO0NBRUw7Q0FDQSxjQUFjO0VBQ1osSUFBSSxDQUFDLEtBQUssVUFBVTtFQUNwQixLQUFLLFNBQVMsV0FBVztFQUN6QixLQUFLLE9BQU8sTUFBTTtDQUNwQjtBQVFGOztrQ0FQUyxRQUFPLFNBQVMseUJBQXlCLG1CQUFtQjtDQUNqRSxPQUFPLEtBQUsscUJBQXFCQyxtQkFBa0I7QUFDckQsQ0FBQTtrQ0FDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxTQUFTQSxrQkFBaUI7QUFDNUIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNMLGlCQUFxQixrQkFBa0IsQ0FBQyxFQUN6RixNQUFNLFFBQ1IsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJO0FBQ3BCLEVBQUEsQ0FBRztBQUNILFNBQVMsd0JBQXdCLE9BQU87Q0FDdEMsTUFBTSxtQkFBbUIsb0JBQW9CLEtBQUs7Q0FDbEQsUUFBUSxNQUFNRyxtQkFBb0IsTUFBTSxHQUFHLGlCQUFpQiwrTUFBOE4sQ0FBQztBQUM3UjtBQUNBLFNBQVMsbUJBQW1CLE9BQU87Q0FDakMsTUFBTSxtQkFBbUIsb0JBQW9CLEtBQUs7Q0FDbEQsUUFBUSxLQUFLQSxtQkFBb0IsTUFBTSxHQUFHLGlCQUFpQixtUEFBa1EsQ0FBQztBQUNoVTtBQUNBLElBQU0sc0RBQXNDLElBQUksSUFBSTtDQUFDO0NBQWE7Q0FBYTtDQUFXO0FBQU8sQ0FBQztBQUNsRyxJQUFNLDZCQUE2QixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSwrQkFBK0IsRUFBRTtBQUN2SSxJQUFNLHdCQUFOLE1BQTRCO0NBTTFCLGNBQWM7d0JBTGQsWUFBVyxPQUFPLFFBQVEsQ0FBQTt3QkFDMUIsbUJBQWtCLElBQUE7d0JBQ2xCLCtCQUFjLElBQUksSUFBSSxDQUFBO3dCQUN0QixVQUFTLEtBQUssU0FBUyxXQUFBO3dCQUN2QixhQUFZLElBQUksSUFBSSxtQ0FBbUMsQ0FBQTtFQUVyRCxjQUFjLHlCQUF5QjtFQUN2QyxNQUFNLFlBQVksT0FBTyw0QkFBNEIsRUFDbkQsVUFBVSxLQUNaLENBQUM7RUFDRCxJQUFJLFdBQ0YsS0FBSyxrQkFBa0IsU0FBUztDQUVwQztDQUNBLGtCQUFrQixTQUFTO0VBQ3pCLElBQUksTUFBTSxRQUFRLE9BQU8sR0FDdkIsWUFBWSxVQUFTLFdBQVU7R0FDN0IsS0FBSyxVQUFVLElBQUksZ0JBQWdCLE1BQU0sQ0FBQztFQUM1QyxDQUFDO09BRUQsS0FBSyxVQUFVLElBQUksZ0JBQWdCLE9BQU8sQ0FBQztDQUUvQztDQUNBLGlCQUFpQixjQUFjLGVBQWU7O0VBRTVDLE1BQU0sU0FBUyxPQUFPLGNBQWMsS0FBSyxNQUFNO0VBQy9DLElBQUksS0FBSyxVQUFVLElBQUksT0FBTyxRQUFRLEtBQUssS0FBSyxZQUFZLElBQUksT0FBTyxNQUFNLEdBQUc7RUFDaEYsS0FBSyxZQUFZLElBQUksT0FBTyxNQUFNO0VBQ2xDLENBQUEsd0JBQUEsS0FBSyxxQkFBQSxRQUFBLDBCQUFBLEtBQUEsTUFBTCxLQUFLLGtCQUFvQixLQUFLLHFCQUFxQjtFQUNuRCxJQUFJLENBQUMsS0FBSyxnQkFBZ0IsSUFBSSxPQUFPLE1BQU0sR0FDekMsUUFBUSxLQUFLQSxtQkFBb0IsTUFBTSxHQUFHLG9CQUFvQixhQUFhLEVBQUUsNFJBQWdULE9BQU8sT0FBTyxHQUFHLENBQUM7Q0FFblo7Q0FDQSx1QkFBdUI7RUFDckIsTUFBTSxpQ0FBaUIsSUFBSSxJQUFJO0VBQy9CLE1BQU0sUUFBUSxLQUFLLFNBQVMsaUJBQWlCLHNCQUFzQjtFQUNuRSxLQUFLLE1BQU0sUUFBUSxPQUFPO0dBQ3hCLE1BQU0sTUFBTSxPQUFPLEtBQUssTUFBTSxLQUFLLE1BQU07R0FDekMsZUFBZSxJQUFJLElBQUksTUFBTTtFQUMvQjtFQUNBLE9BQU87Q0FDVDtDQUNBLGNBQWM7O0VBQ1osQ0FBQSx5QkFBQSxLQUFLLHFCQUFBLFFBQUEsMkJBQUEsS0FBQSxLQUFBLHVCQUFpQixNQUFNO0VBQzVCLEtBQUssWUFBWSxNQUFNO0NBQ3pCO0FBUUY7O3VDQVBTLFFBQU8sU0FBUyw4QkFBOEIsbUJBQW1CO0NBQ3RFLE9BQU8sS0FBSyxxQkFBcUJHLHdCQUF1QjtBQUMxRCxDQUFBO3VDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLHVCQUFzQjtBQUNqQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY04saUJBQXFCLHVCQUF1QixDQUFDLEVBQzlGLE1BQU0sUUFDUixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFDcEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyxZQUFZLE9BQU8sSUFBSTtDQUM5QixLQUFLLElBQUksU0FBUyxPQUNoQixNQUFNLFFBQVEsS0FBSyxJQUFJLFlBQVksT0FBTyxFQUFFLElBQUksR0FBRyxLQUFLO0FBRTVEO0FBQ0EsSUFBTSxpQ0FBaUM7QUFDdkMsSUFBTSxtQkFBbUIsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksa0NBQWtDLElBQUksRUFDaEksK0JBQWUsSUFBSSxJQUFJLEVBQ3pCLENBQUM7QUFDRCxJQUFNLHFCQUFOLE1BQXlCOzt3QkFDdkIsbUJBQWtCLE9BQU8sZ0JBQWdCLENBQUE7d0JBQ3pDLFlBQVcsT0FBTyxRQUFRLENBQUE7d0JBQzFCLGNBQWEsS0FBQTs7Q0FDYixxQkFBcUIsVUFBVSxLQUFLLFFBQVEsT0FBTyxhQUFhO0VBQzlELE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxtQkFBbUIsV0FBVztFQUMzRCxJQUFJLGFBQWEsQ0FBQyxLQUFLLGNBQWMsS0FBSyxnQkFBZ0IsUUFBUSxnQ0FBZ0M7R0FDaEcsS0FBSyxhQUFhO0dBQ2xCLFFBQVEsS0FBS0csbUJBQW9CLE1BQU0sa0VBQXVFLCtCQUErQiwrS0FBeUwsQ0FBQztFQUN6VTtFQUNBLElBQUksS0FBSyxnQkFBZ0IsSUFBSSxVQUFVLEdBQ3JDO0VBRUYsS0FBSyxnQkFBZ0IsSUFBSSxVQUFVO0VBQ25DLE1BQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtFQUM3QyxTQUFTLGFBQWEsU0FBUyxNQUFNLE9BQU87RUFDNUMsU0FBUyxhQUFhLFNBQVMsUUFBUSxHQUFHO0VBQzFDLFNBQVMsYUFBYSxTQUFTLE9BQU8sU0FBUztFQUMvQyxTQUFTLGFBQWEsU0FBUyxpQkFBaUIsTUFBTTtFQUN0RCxJQUFJLGVBQWUsTUFDakIsU0FBUyxhQUFhLFNBQVMsZUFBZSxXQUFXO0VBRTNELElBQUksT0FDRixTQUFTLGFBQWEsU0FBUyxjQUFjLEtBQUs7RUFFcEQsSUFBSSxRQUNGLFNBQVMsYUFBYSxTQUFTLGVBQWUsTUFBTTtFQUV0RCxTQUFTLFlBQVksS0FBSyxTQUFTLE1BQU0sT0FBTztDQUNsRDtBQVFGOztvQ0FQUyxRQUFPLFNBQVMsMkJBQTJCLG1CQUFtQjtDQUNuRSxPQUFPLEtBQUsscUJBQXFCSSxxQkFBb0I7QUFDdkQsQ0FBQTtvQ0FDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxTQUFTQSxvQkFBbUI7QUFDOUIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNQLGlCQUFxQixvQkFBb0IsQ0FBQyxFQUMzRixNQUFNLFFBQ1IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxTQUFTLG1CQUFtQixhQUFhO0NBQ3ZDLElBQUksZUFBZSxNQUNqQixPQUFPO0NBRVQsT0FBTyxZQUFZLFlBQVksTUFBTSxvQkFBb0Isb0JBQW9CO0FBQy9FO0FBQ0EsSUFBTSxpQ0FBaUM7QUFDdkMsSUFBTSxnQ0FBZ0M7QUFDdEMsSUFBTSxrQ0FBa0M7QUFDeEMsSUFBTSw4QkFBOEI7QUFDcEMsSUFBTSxpQ0FBaUM7QUFDdkMsSUFBTSw2QkFBNkIsQ0FBQyxHQUFHLENBQUM7QUFDeEMsSUFBTSw2QkFBNkI7QUFDbkMsSUFBTSx5QkFBeUI7QUFDL0IsSUFBTSw0QkFBNEI7QUFDbEMsSUFBTSwyQkFBMkI7QUFDakMsSUFBTSw0QkFBNEI7QUFDbEMsSUFBTSw4QkFBOEI7QUFDcEMsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxtQkFBbUI7Q0FBQztDQUFpQjtDQUFvQjtDQUFzQjtBQUFpQjtBQUN0RyxJQUFNLDJCQUEyQjtBQUNqQyxJQUFJLGdDQUFnQztBQUNwQyxJQUFNLG1CQUFOLE1BQXVCO0NBd0JyQixjQUFjO3dCQXZCZCxlQUFjLE9BQU8sWUFBWSxDQUFBO3dCQUNqQyxVQUFTLGNBQWMsT0FBT1EsWUFBYSxDQUFDLENBQUE7d0JBQzVDLFlBQVcsT0FBTyxTQUFTLENBQUE7d0JBQzNCLGNBQWEsT0FBTyxVQUFVLENBQUMsQ0FBQyxhQUFBO3dCQUNoQyxZQUFXLE9BQU8sUUFBUSxDQUFBO3dCQUMxQixjQUFhLE9BQU8sVUFBVSxDQUFBO3dCQUM5QixlQUFBLEtBQUEsQ0FBQTt3QkFDQSxnQkFBZSxJQUFBO3dCQUNmLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFdBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQVcsS0FBQTt3QkFDWCxnQkFBQSxLQUFBLENBQUE7d0JBQ0EsMEJBQXlCLEtBQUE7d0JBQ3pCLFFBQU8sS0FBQTt3QkFDUCxlQUFBLEtBQUEsQ0FBQTt3QkFDQSxxQkFBQSxLQUFBLENBQUE7d0JBQ0EsT0FBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7RUFFRSxJQUFJLFdBQVc7R0FDYixLQUFLLGNBQWMsS0FBSyxTQUFTLElBQUksZ0JBQWdCO0dBQ3JELEtBQUssV0FBVyxnQkFBZ0I7SUFDOUIsSUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLGlCQUFpQixNQUMxQyxLQUFLLFlBQVksZ0JBQWdCLEtBQUssWUFBWTtHQUV0RCxDQUFDO0VBQ0g7RUFDQSxLQUFLLFdBQVcsZ0JBQWdCO0dBQzlCLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxZQUFZLFNBQVM7RUFDMUQsQ0FBQztDQUNIO0NBQ0EsV0FBVztFQUNULHVCQUF3QixrQkFBa0I7RUFDMUMsSUFBSSxXQUFXO0dBQ2IsTUFBTSxTQUFTLEtBQUssU0FBUyxJQUFJLE1BQU07R0FDdkMsb0JBQW9CLE1BQU0sU0FBUyxLQUFLLEtBQUs7R0FDN0Msb0JBQW9CLE1BQU0sS0FBSyxRQUFRO0dBQ3ZDLHVCQUF1QixJQUFJO0dBQzNCLElBQUksS0FBSyxVQUNQLDBCQUEwQixJQUFJO0dBRWhDLHFCQUFxQixJQUFJO0dBQ3pCLGlCQUFpQixJQUFJO0dBQ3JCLElBQUksS0FBSyxNQUFNO0lBQ2IsMEJBQTBCLElBQUk7SUFDOUIsT0FBTyx3QkFBd0IsNEJBQTRCLE1BQU0sS0FBSyxZQUFZLEtBQUssVUFBVSxLQUFLLFVBQVUsQ0FBQztHQUNuSCxPQUFPO0lBQ0wsNkJBQTZCLElBQUk7SUFDakMsSUFBSSxLQUFLLFdBQVcsS0FBQSxHQUNsQixzQkFBc0IsTUFBTSxLQUFLLFFBQVEsUUFBUTtJQUVuRCxJQUFJLEtBQUssVUFBVSxLQUFBLEdBQ2pCLHNCQUFzQixNQUFNLEtBQUssT0FBTyxPQUFPO0lBRWpELE9BQU8sd0JBQXdCLHdCQUF3QixNQUFNLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxVQUFVLENBQUM7R0FDL0c7R0FDQSx3QkFBd0IsSUFBSTtHQUM1Qix5QkFBeUIsSUFBSTtHQUM3QixJQUFJLENBQUMsS0FBSyxVQUNSLHFCQUFxQixJQUFJO0dBRTNCLHVCQUF1QixNQUFNLEtBQUssV0FBVztHQUM3Qyw4QkFBOEIsS0FBSyxPQUFPLEtBQUssV0FBVztHQUMxRCw4QkFBOEIsTUFBTSxLQUFLLFdBQVc7R0FDcEQsa0NBQWtDLE1BQU0sS0FBSyxXQUFXO0dBQ3hELE9BQU8sd0JBQXdCO0lBQzdCLEtBQUssWUFBWSxjQUFjLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxRQUFRO0dBQ3RFLENBQUM7R0FDRCxJQUFJLEtBQUssVUFBVTtJQUVqQixLQURxQixTQUFTLElBQUkscUJBQzVCLENBQUMsQ0FBQyxpQkFBaUIsS0FBSyxnQkFBZ0IsR0FBRyxLQUFLLEtBQUs7SUFHekQsaUNBRHVCLEtBQUssU0FBUyxJQUFJLGNBQ0ssQ0FBQztHQUVuRDtFQUNGO0VBQ0EsSUFBSSxLQUFLLGFBQ1AsS0FBSyx3QkFBd0IsS0FBSyxVQUFVO0VBRTlDLEtBQUssa0JBQWtCO0NBQ3pCO0NBQ0Esb0JBQW9CO0VBQ2xCLElBQUksS0FBSyxNQUNQLEtBQUssVUFBTCxLQUFLLFFBQVU7T0FDVjtHQUNMLEtBQUssaUJBQWlCLFNBQVMsS0FBSyxNQUFNLFNBQVMsQ0FBQztHQUNwRCxLQUFLLGlCQUFpQixVQUFVLEtBQUssT0FBTyxTQUFTLENBQUM7RUFDeEQ7RUFDQSxLQUFLLGlCQUFpQixXQUFXLEtBQUssbUJBQW1CLENBQUM7RUFDMUQsS0FBSyxpQkFBaUIsaUJBQWlCLEtBQUssaUJBQWlCLENBQUM7RUFDOUQsS0FBSyxpQkFBaUIsWUFBWSxLQUFLLFlBQVksQ0FBQztFQUNwRCxLQUFLLGlCQUFpQixVQUFVLE1BQU07RUFDZCxLQUFLLG1CQUFtQjtFQUNoRCxJQUFJLEtBQUssT0FDUCxJQUFJLEtBQUssbUJBQW1CLE1BQU0sUUFDaEMsS0FBSyxpQkFBaUIsU0FBUyxXQUFXLEtBQUssS0FBSztPQUVwRCxLQUFLLGlCQUFpQixTQUFTLEtBQUssS0FBSztPQUczQyxJQUFJLEtBQUssWUFBWSw4QkFBOEIsS0FBSyxLQUFLLFFBQVEsS0FBSyxLQUFLLG1CQUFtQixNQUFNLFFBQ3RHLEtBQUssaUJBQWlCLFNBQVMsYUFBYTtDQU9sRDtDQUNBLFlBQVksU0FBUzs7RUFDbkIsSUFBSSxXQUNGLDRCQUE0QixNQUFNLFNBQVM7R0FBQztHQUFZO0dBQVM7R0FBVTtHQUFZO0dBQVE7R0FBVztHQUFTO0dBQWdCO0VBQXdCLENBQUM7RUFFOUosSUFBSSxRQUFRLFlBQVksQ0FBQyxRQUFRLFFBQVEsQ0FBQyxjQUFjLEdBQUc7R0FDekQsTUFBTSxTQUFTLEtBQUs7R0FDcEIsS0FBSyxtQkFBbUIsSUFBSTtHQUM1QixJQUFJLFdBQVc7SUFDYixNQUFNLFNBQVMsS0FBSztJQUNwQixJQUFJLFVBQVUsVUFBVSxXQUFXLFFBRWpDLEtBRG9CLFNBQVMsSUFBSSxNQUM1QixDQUFDLENBQUMsd0JBQXdCO0tBQzdCLEtBQUssWUFBWSxZQUFZLFFBQVEsTUFBTTtJQUM3QyxDQUFDO0dBRUw7RUFDRjtFQUNBLElBQUksZUFBQSx1QkFBYSxRQUFRLG9CQUFBLFFBQUEseUJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxxQkFBZ0IsaUJBQXVELE1BQzlGLDRCQUE0QixNQUFNLEtBQUssVUFBVTtDQUVyRDtDQUNBLGlCQUFpQjtFQUNmLElBQUksS0FBSyxTQUFTLEtBQUssVUFBVSxLQUFLLFdBQVcsR0FDL0MsT0FBTyxLQUFLLFFBQVEsS0FBSztFQUUzQixPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsMkJBQTJCO0VBQ3pDLElBQUksa0JBQWtCO0VBQ3RCLElBQUksS0FBSyxjQUNQLGdCQUFnQixlQUFlLEtBQUs7RUFFdEMsTUFBTSxRQUFRLEtBQUssZUFBZTtFQUNsQyxJQUFJLFVBQVUsUUFBUSxnQkFBZ0IsT0FDcEMsZ0JBQWdCLFNBQVMsS0FBSyxNQUFNLGdCQUFnQixRQUFRLEtBQUs7RUFFbkUsT0FBTyxLQUFLLFlBQVksZUFBZTtDQUN6QztDQUNBLHFCQUFxQjtFQUNuQixJQUFJLENBQUMsS0FBSyxZQUFZLEtBQUssWUFBWSxLQUFBLEdBQ3JDLE9BQU8sS0FBSztFQUVkLE9BQU8sS0FBSyxXQUFXLFVBQVU7Q0FDbkM7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxLQUFLLFdBQVcsU0FBUztDQUNsQztDQUNBLGNBQWM7O0VBQ1osSUFBSSxLQUFLLFVBQ1AsT0FBTztFQUVULFFBQUEsaUJBQU8sS0FBSyxjQUFBLFFBQUEsbUJBQUEsS0FBQSxJQUFBLGlCQUFZO0NBQzFCO0NBQ0Esa0JBQWtCO0VBQ2hCLElBQUksQ0FBQyxLQUFLLGNBQWM7R0FDdEIsTUFBTSxZQUFZLEVBQ2hCLEtBQUssS0FBSyxNQUNaO0dBQ0EsS0FBSyxlQUFlLEtBQUssZ0JBQWdCLFNBQVM7RUFDcEQ7RUFDQSxPQUFPLEtBQUs7Q0FDZDtDQUNBLHFCQUFxQjtFQUNuQixNQUFNLGNBQWMsOEJBQThCLEtBQUssS0FBSyxRQUFRO0VBU3BFLE9BUmtCLEtBQUssU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQU8sUUFBTyxRQUFRLEVBQUUsQ0FBQyxDQUFDLEtBQUksV0FBVTtHQUNqRixTQUFTLE9BQU8sS0FBSztHQUNyQixNQUFNLFFBQVEsY0FBYyxXQUFXLE1BQU0sSUFBSSxXQUFXLE1BQU0sSUFBSSxLQUFLO0dBQzNFLE9BQU8sR0FBRyxLQUFLLGdCQUFnQjtJQUM3QixLQUFLLEtBQUs7SUFDVjtHQUNGLENBQUMsRUFBRSxHQUFHO0VBQ1IsQ0FDZSxDQUFDLENBQUMsS0FBSyxJQUFJO0NBQzVCO0NBQ0EscUJBQXFCO0VBQ25CLElBQUksS0FBSyxPQUNQLE9BQU8sS0FBSyxvQkFBb0I7T0FFaEMsT0FBTyxLQUFLLGVBQWU7Q0FFL0I7Q0FDQSxzQkFBc0I7O0VBQ3BCLE1BQU0sRUFDSixnQkFDRSxLQUFLO0VBQ1QsSUFBSSxzQkFBc0I7RUFDMUIsTUFBQSxjQUFJLEtBQUssV0FBQSxRQUFBLGdCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsWUFBTyxLQUFLLE9BQU0sU0FDekIsc0JBQXNCLFlBQVksUUFBTyxPQUFNLE1BQU0sMEJBQTBCO0VBTWpGLE9BSmtCLG9CQUFvQixLQUFJLE9BQU0sR0FBRyxLQUFLLGdCQUFnQjtHQUN0RSxLQUFLLEtBQUs7R0FDVixPQUFPO0VBQ1QsQ0FBQyxFQUFFLEdBQUcsR0FBRyxFQUNNLENBQUMsQ0FBQyxLQUFLLElBQUk7Q0FDNUI7Q0FDQSxtQkFBbUIsaUJBQWlCLE9BQU87RUFDekMsSUFBSSxnQkFDRixLQUFLLGVBQWU7RUFFdEIsTUFBTSxlQUFlLEtBQUssZ0JBQWdCO0VBQzFDLEtBQUssaUJBQWlCLE9BQU8sWUFBWTtFQUN6QyxJQUFJLGtCQUFrQixLQUFBO0VBQ3RCLElBQUksS0FBSyxVQUNQLGtCQUFrQixLQUFLLG1CQUFtQjtPQUNyQyxJQUFJLEtBQUssOEJBQThCLEdBQzVDLGtCQUFrQixLQUFLLG1CQUFtQjtFQUU1QyxJQUFJLGlCQUNGLEtBQUssaUJBQWlCLFVBQVUsZUFBZTtFQUVqRCxPQUFPO0NBQ1Q7Q0FDQSxpQkFBaUI7RUFLZixPQUprQiwyQkFBMkIsS0FBSSxlQUFjLEdBQUcsS0FBSyxnQkFBZ0I7R0FDckYsS0FBSyxLQUFLO0dBQ1YsT0FBTyxLQUFLLFFBQVE7RUFDdEIsQ0FBQyxFQUFFLEdBQUcsV0FBVyxFQUNGLENBQUMsQ0FBQyxLQUFLLElBQUk7Q0FDNUI7Q0FDQSxnQ0FBZ0M7RUFDOUIsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxDQUFDLEtBQUssT0FDUixpQkFBaUIsS0FBSyxRQUFRLDRCQUE0QixLQUFLLFNBQVM7RUFFMUUsT0FBTyxDQUFDLEtBQUssMEJBQTBCLENBQUMsS0FBSyxVQUFVLEtBQUssZ0JBQWdCLG1CQUFtQixDQUFDO0NBQ2xHO0NBQ0Esb0JBQW9CLGtCQUFrQjtFQUNwQyxNQUFNLEVBQ0osMEJBQ0UsS0FBSztFQUNULElBQUkscUJBQXFCLE1BQ3ZCLE9BQU8sUUFBUSxhQUFhLEtBQUssZ0JBQWdCO0dBQy9DLEtBQUssS0FBSztHQUNWLE9BQU87R0FDUCxlQUFlO0VBQ2pCLENBQUMsQ0FBQyxFQUFFO09BQ0MsSUFBSSxPQUFPLHFCQUFxQixVQUNyQyxPQUFPLFFBQVEsYUFBYSxnQkFBZ0IsRUFBRTtFQUVoRCxPQUFPO0NBQ1Q7Q0FDQSxzQkFBc0IsbUJBQW1CO0VBQ3ZDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsZUFBZSxNQUFNLEdBQ2hFLE9BQU87RUFFVCxPQUFPLFFBQVEsa0JBQWtCLElBQUk7Q0FDdkM7Q0FDQSx3QkFBd0IsS0FBSztFQUMzQixNQUFNLGlCQUFpQjtHQUNyQixNQUFNLG9CQUFvQixLQUFLLFNBQVMsSUFBSSxpQkFBaUI7R0FDN0QscUJBQXFCO0dBQ3JCLHNCQUFzQjtHQUN0QixLQUFLLGNBQWM7R0FDbkIsa0JBQWtCLGFBQWE7RUFDakM7RUFDQSxNQUFNLHVCQUF1QixLQUFLLFNBQVMsT0FBTyxLQUFLLFFBQVEsUUFBUTtFQUN2RSxNQUFNLHdCQUF3QixLQUFLLFNBQVMsT0FBTyxLQUFLLFNBQVMsUUFBUTtFQUN6RSxLQUFLLFdBQVcsZ0JBQWdCO0dBQzlCLHFCQUFxQjtHQUNyQixzQkFBc0I7RUFDeEIsQ0FBQztFQUNELDBCQUEwQixLQUFLLFFBQVE7Q0FDekM7Q0FDQSxpQkFBaUIsTUFBTSxPQUFPO0VBQzVCLEtBQUssU0FBUyxhQUFhLEtBQUssWUFBWSxNQUFNLEtBQUs7Q0FDekQ7QUFnQ0Y7O2tDQS9CUyxRQUFPLFNBQVMseUJBQXlCLG1CQUFtQjtDQUNqRSxPQUFPLEtBQUsscUJBQXFCQyxtQkFBa0I7QUFDckQsQ0FBQTtrQ0FDTyxRQUFzQixrQ0FBcUI7Q0FDaEQsTUFBTUE7Q0FDTixXQUFXLENBQUM7RUFBQztFQUFPO0VBQVM7Q0FBRSxDQUFDO0NBQ2hDLFVBQVU7Q0FDVixjQUFjLFNBQVMsOEJBQThCLElBQUksS0FBSztFQUM1RCxJQUFJLEtBQUssR0FDUCxZQUFlLFlBQVksSUFBSSxPQUFPLGFBQWEsSUFBSSxDQUFDLENBQUMsU0FBUyxJQUFJLE9BQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxVQUFVLElBQUksT0FBTyxTQUFTLElBQUksQ0FBQyxDQUFDLFNBQVMsSUFBSSxPQUFPLE1BQU0sSUFBSSxDQUFDLENBQUMsbUJBQW1CLElBQUksY0FBYyxVQUFVLElBQUksQ0FBQyxDQUFDLHVCQUF1QixJQUFJLGNBQWMsWUFBWSxJQUFJLENBQUMsQ0FBQyxxQkFBcUIsSUFBSSxjQUFjLGNBQWMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLElBQUksY0FBYyxJQUFJLG9CQUFvQixJQUFJLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQyxVQUFVLElBQUksZUFBZSxJQUFJLHNCQUFzQixJQUFJLGlCQUFpQixJQUFJLGVBQWUsSUFBSTtDQUV6Z0I7Q0FDQSxRQUFRO0VBQ04sT0FBTztHQUFDO0dBQUc7R0FBUztHQUFTO0VBQWE7RUFDMUMsVUFBVTtFQUNWLE9BQU87RUFDUCxPQUFPO0dBQUM7R0FBRztHQUFTO0dBQVM7RUFBZTtFQUM1QyxRQUFRO0dBQUM7R0FBRztHQUFVO0dBQVU7RUFBZTtFQUMvQyxVQUFVO0VBQ1YsU0FBUztFQUNULFVBQVU7R0FBQztHQUFHO0dBQVk7R0FBWTtFQUFnQjtFQUN0RCxjQUFjO0VBQ2Qsd0JBQXdCO0dBQUM7R0FBRztHQUEwQjtHQUEwQjtFQUFnQjtFQUNoRyxNQUFNO0dBQUM7R0FBRztHQUFRO0dBQVE7RUFBZ0I7RUFDMUMsYUFBYTtHQUFDO0dBQUc7R0FBZTtHQUFlO0VBQXFCO0VBQ3BFLG1CQUFtQjtFQUNuQixLQUFLO0VBQ0wsUUFBUTtDQUNWO0NBQ0EsVUFBVSxDQUFDQyxvQkFBdUI7QUFDcEMsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNWLGlCQUFxQixrQkFBa0IsQ0FBQztFQUN6RixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLE1BQU07SUFDSixvQkFBb0I7SUFDcEIsaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsMkJBQTJCO0lBQzNCLCtCQUErQjtJQUMvQiw2QkFBNkI7SUFDN0IsNEJBQTRCO0lBQzVCLGtCQUFrQjtHQUNwQjtFQUNGLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxHQUFHO0VBQ1osT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLE1BQU0sQ0FBQztJQUNMLFVBQVU7SUFDVixXQUFXO0dBQ2IsQ0FBQztFQUNILENBQUM7RUFDRCxVQUFVLENBQUMsRUFDVCxNQUFNLE1BQ1IsQ0FBQztFQUNELE9BQU8sQ0FBQyxFQUNOLE1BQU0sTUFDUixDQUFDO0VBQ0QsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLE1BQU0sQ0FBQyxFQUNMLFdBQVcsZ0JBQ2IsQ0FBQztFQUNILENBQUM7RUFDRCxRQUFRLENBQUM7R0FDUCxNQUFNO0dBQ04sTUFBTSxDQUFDLEVBQ0wsV0FBVyxnQkFDYixDQUFDO0VBQ0gsQ0FBQztFQUNELFVBQVUsQ0FBQyxFQUNULE1BQU0sTUFDUixDQUFDO0VBQ0QsU0FBUyxDQUFDLEVBQ1IsTUFBTSxNQUNSLENBQUM7RUFDRCxVQUFVLENBQUM7R0FDVCxNQUFNO0dBQ04sTUFBTSxDQUFDLEVBQ0wsV0FBVyxpQkFDYixDQUFDO0VBQ0gsQ0FBQztFQUNELGNBQWMsQ0FBQyxFQUNiLE1BQU0sTUFDUixDQUFDO0VBQ0Qsd0JBQXdCLENBQUM7R0FDdkIsTUFBTTtHQUNOLE1BQU0sQ0FBQyxFQUNMLFdBQVcsaUJBQ2IsQ0FBQztFQUNILENBQUM7RUFDRCxNQUFNLENBQUM7R0FDTCxNQUFNO0dBQ04sTUFBTSxDQUFDLEVBQ0wsV0FBVyxpQkFDYixDQUFDO0VBQ0gsQ0FBQztFQUNELGFBQWEsQ0FBQztHQUNaLE1BQU07R0FDTixNQUFNLENBQUMsRUFDTCxXQUFXLHNCQUNiLENBQUM7RUFDSCxDQUFDO0VBQ0QsbUJBQW1CLENBQUMsRUFDbEIsTUFBTSxNQUNSLENBQUM7RUFDRCxLQUFLLENBQUMsRUFDSixNQUFNLE1BQ1IsQ0FBQztFQUNELFFBQVEsQ0FBQyxFQUNQLE1BQU0sTUFDUixDQUFDO0NBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILFNBQVMsY0FBYyxRQUFRO0NBQzdCLElBQUksb0JBQW9CLENBQUM7Q0FDekIsSUFBSSxPQUFPLGFBQ1Qsa0JBQWtCLGNBQWMsT0FBTyxZQUFZLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQztDQUV6RSxPQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUdXLHVCQUF3QixRQUFRLGlCQUFpQjtBQUM1RTtBQUNBLFNBQVMsdUJBQXVCLEtBQUs7Q0FDbkMsSUFBSSxJQUFJLEtBQ04sTUFBTSxJQUFJUCxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUseU9BQXdQO0FBRTVUO0FBQ0EsU0FBUywwQkFBMEIsS0FBSztDQUN0QyxJQUFJLElBQUksUUFDTixNQUFNLElBQUlBLGFBQWMsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSx3UEFBdVE7QUFFM1U7QUFDQSxTQUFTLHFCQUFxQixLQUFLO0NBQ2pDLElBQUksUUFBUSxJQUFJLE1BQU0sS0FBSztDQUMzQixJQUFJLE1BQU0sV0FBVyxPQUFPLEdBQUc7RUFDN0IsSUFBSSxNQUFNLFNBQVMsZ0NBQ2pCLFFBQVEsTUFBTSxVQUFVLEdBQUcsOEJBQThCLElBQUk7RUFFL0QsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxPQUFPLEtBQUssRUFBRSx5Q0FBOEMsTUFBTSx3TUFBa047Q0FDL1U7QUFDRjtBQUNBLFNBQVMscUJBQXFCLEtBQUs7Q0FDakMsSUFBSSxRQUFRLElBQUk7Q0FDaEIsSUFBQSxVQUFBLFFBQUEsVUFBQSxLQUFBLElBQUEsS0FBQSxJQUFJLE1BQU8sTUFBTSxtQkFBbUIsR0FDbEMsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxPQUFPLEtBQUssRUFBRSxpVEFBZ1U7QUFFM1k7QUFDQSxTQUFTLHVCQUF1QixLQUFLLGFBQWE7Q0FDaEQsNENBQTRDLEdBQUc7Q0FDL0MseUNBQXlDLEtBQUssV0FBVztDQUN6RCx5QkFBeUIsR0FBRztBQUM5QjtBQUNBLFNBQVMsNENBQTRDLEtBQUs7Q0FDeEQsSUFBSSxJQUFJLHFCQUFxQixDQUFDLElBQUksYUFDaEMsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxPQUFPLEtBQUssRUFBRSxvSUFBeUk7QUFFcE47QUFDQSxTQUFTLHlDQUF5QyxLQUFLLGFBQWE7Q0FDbEUsSUFBSSxJQUFJLGdCQUFnQixRQUFRLGdCQUFnQixpQkFDOUMsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsdVNBQXNUO0FBRTFYO0FBQ0EsU0FBUyx5QkFBeUIsS0FBSztDQUNyQyxJQUFJLElBQUksZUFBZSxPQUFPLElBQUksZ0JBQWdCLFlBQVksSUFBSSxZQUFZLFdBQVcsT0FBTyxHQUFHO0VBQ2pHLElBQUksSUFBSSxZQUFZLFNBQVMsc0JBQzNCLE1BQU0sSUFBSUEsYUFBYyxNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLDJFQUFnRixxQkFBcUIsMk1BQXFOO0VBRTVYLElBQUksSUFBSSxZQUFZLFNBQVMscUJBQzNCLFFBQVEsS0FBS0QsbUJBQW9CLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsMkVBQWdGLG9CQUFvQixxTkFBK04sQ0FBQztDQUVqWjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsS0FBSztDQUM3QixNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUs7Q0FDN0IsSUFBSSxNQUFNLFdBQVcsT0FBTyxHQUMxQixNQUFNLElBQUlDLGFBQWMsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSxvQ0FBb0MsTUFBTSw0TUFBMk47QUFFelU7QUFDQSxTQUFTLG9CQUFvQixLQUFLLE1BQU0sT0FBTztDQUM3QyxNQUFNLFdBQVcsT0FBTyxVQUFVO0NBQ2xDLE1BQU0sZ0JBQWdCLFlBQVksTUFBTSxLQUFLLE1BQU07Q0FDbkQsSUFBSSxDQUFDLFlBQVksZUFDZixNQUFNLElBQUlBLGFBQWMsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSxLQUFLLEtBQUssNkJBQWtDLE1BQU0sMERBQTBEO0FBRWhMO0FBQ0EsU0FBUyxvQkFBb0IsS0FBSyxPQUFPO0NBQ3ZDLElBQUksU0FBUyxNQUFNO0NBQ25CLG9CQUFvQixLQUFLLFlBQVksS0FBSztDQUMxQyxNQUFNLFlBQVk7Q0FDbEIsTUFBTSx5QkFBeUIsOEJBQThCLEtBQUssU0FBUztDQUMzRSxNQUFNLDJCQUEyQixnQ0FBZ0MsS0FBSyxTQUFTO0NBQy9FLElBQUksMEJBQ0Ysc0JBQXNCLEtBQUssU0FBUztDQUd0QyxJQUFJLEVBRGtCLDBCQUEwQiwyQkFFOUMsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsd0NBQXdDLE1BQU0sZ0tBQTBLO0FBRTVSO0FBQ0EsU0FBUyxzQkFBc0IsS0FBSyxPQUFPO0NBRXpDLElBQUksQ0FEb0IsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU0sUUFBTyxRQUFRLE1BQU0sV0FBVyxHQUFHLEtBQUssMkJBQ3BFLEdBQ2pCLE1BQU0sSUFBSUEsYUFBYyxNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLDREQUFpRSxNQUFNLG1FQUF3RSwrQkFBK0IsdUNBQTRDLDRCQUE0QiwyRUFBZ0YsK0JBQStCLCtIQUF5SSw0QkFBNEIsbUVBQW1FO0FBRWpwQjtBQUNBLFNBQVMseUJBQXlCLEtBQUssV0FBVztDQUNoRCxJQUFJO0NBQ0osSUFBSSxjQUFjLFdBQVcsY0FBYyxVQUN6QyxTQUFTLGNBQWMsVUFBVTtNQUVqQyxTQUFTLGtCQUFrQixVQUFVO0NBRXZDLE9BQU8sSUFBSUEsYUFBYyxNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLEtBQUssVUFBVSwyR0FBZ0gsT0FBTyxnQ0FBcUMsVUFBVSwrRkFBb0c7QUFDNVY7QUFDQSxTQUFTLDRCQUE0QixLQUFLLFNBQVMsUUFBUTtDQUN6RCxPQUFPLFNBQVEsVUFBUztFQUV0QixJQURrQixRQUFRLGVBQWUsS0FDN0IsS0FBSyxDQUFDLFFBQVEsTUFBTSxDQUFDLGNBQWMsR0FBRztHQUNoRCxJQUFJLFVBQVUsU0FDWixNQUFNLEVBQ0osT0FBTyxRQUFRLE1BQU0sQ0FBQyxjQUN4QjtHQUVGLE1BQU0seUJBQXlCLEtBQUssS0FBSztFQUMzQztDQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsc0JBQXNCLEtBQUssWUFBWSxXQUFXO0NBQ3pELE1BQU0sY0FBYyxPQUFPLGVBQWUsWUFBWSxhQUFhO0NBQ25FLE1BQU0sY0FBYyxPQUFPLGVBQWUsWUFBWSxRQUFRLEtBQUssV0FBVyxLQUFLLENBQUMsS0FBSyxTQUFTLFVBQVUsSUFBSTtDQUNoSCxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQ25CLE1BQU0sSUFBSUEsYUFBYyxNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLEtBQUssVUFBVSxrREFBdUQsVUFBVSwrQkFBK0I7QUFFbkw7QUFDQSxTQUFTLHdCQUF3QixLQUFLLEtBQUssVUFBVSxZQUFZO0NBQy9ELE1BQU0saUJBQWlCO0VBQ3JCLHFCQUFxQjtFQUNyQixzQkFBc0I7RUFDdEIsTUFBTSxnQkFBZ0IsT0FBTyxpQkFBaUIsR0FBRztFQUNqRCxJQUFJLGdCQUFnQixXQUFXLGNBQWMsaUJBQWlCLE9BQU8sQ0FBQztFQUN0RSxJQUFJLGlCQUFpQixXQUFXLGNBQWMsaUJBQWlCLFFBQVEsQ0FBQztFQUV4RSxJQURrQixjQUFjLGlCQUFpQixZQUNyQyxNQUFNLGNBQWM7R0FDOUIsTUFBTSxhQUFhLGNBQWMsaUJBQWlCLGFBQWE7R0FDL0QsTUFBTSxlQUFlLGNBQWMsaUJBQWlCLGVBQWU7R0FDbkUsTUFBTSxnQkFBZ0IsY0FBYyxpQkFBaUIsZ0JBQWdCO0dBQ3JFLE1BQU0sY0FBYyxjQUFjLGlCQUFpQixjQUFjO0dBQ2pFLGlCQUFpQixXQUFXLFlBQVksSUFBSSxXQUFXLFdBQVc7R0FDbEUsa0JBQWtCLFdBQVcsVUFBVSxJQUFJLFdBQVcsYUFBYTtFQUNyRTtFQUNBLE1BQU0sc0JBQXNCLGdCQUFnQjtFQUM1QyxNQUFNLDRCQUE0QixrQkFBa0IsS0FBSyxtQkFBbUI7RUFDNUUsTUFBTSxpQkFBaUIsSUFBSTtFQUMzQixNQUFNLGtCQUFrQixJQUFJO0VBQzVCLE1BQU0sdUJBQXVCLGlCQUFpQjtFQUM5QyxNQUFNLGdCQUFnQixJQUFJO0VBQzFCLE1BQU0saUJBQWlCLElBQUk7RUFDM0IsTUFBTSxzQkFBc0IsZ0JBQWdCO0VBQzVDLE1BQU0sdUJBQXVCLEtBQUssSUFBSSxzQkFBc0Isb0JBQW9CLElBQUk7RUFDcEYsTUFBTSxvQkFBb0IsNkJBQTZCLEtBQUssSUFBSSx1QkFBdUIsbUJBQW1CLElBQUk7RUFDOUcsSUFBSSxzQkFDRixRQUFRLEtBQUtELG1CQUFvQixNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLHVJQUFpSixlQUFlLE1BQU0sZ0JBQWdCLG1CQUF3QixNQUFNLG9CQUFvQixFQUFFLDZDQUFrRCxjQUFjLE1BQU0sZUFBZSxtQkFBbUIsTUFBTSxtQkFBbUIsRUFBRSwwREFBK0QsQ0FBQztPQUNqZixJQUFJLG1CQUNULFFBQVEsS0FBS0EsbUJBQW9CLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUscUhBQStILGVBQWUsTUFBTSxnQkFBZ0IsbUJBQXdCLE1BQU0sb0JBQW9CLEVBQUUsNEJBQWlDLGNBQWMsTUFBTSxlQUFlLG1CQUF3QixNQUFNLG1CQUFtQixFQUFFLHdRQUE0UixDQUFDO09BQ2hyQixJQUFJLENBQUMsSUFBSSxZQUFZLDJCQUEyQjtHQUNyRCxNQUFNLG1CQUFtQixpQ0FBaUM7R0FDMUQsTUFBTSxvQkFBb0IsaUNBQWlDO0dBQzNELE1BQU0saUJBQWlCLGlCQUFpQixvQkFBb0I7R0FDNUQsTUFBTSxrQkFBa0Isa0JBQWtCLHFCQUFxQjtHQUMvRCxJQUFJLGtCQUFrQixpQkFDcEIsUUFBUSxLQUFLQSxtQkFBb0IsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSxzRkFBZ0csY0FBYyxNQUFNLGVBQWUsNkJBQWtDLGVBQWUsTUFBTSxnQkFBZ0IseUNBQThDLGlCQUFpQixNQUFNLGtCQUFrQixzRkFBZ0csK0JBQStCLHFHQUEwRyxDQUFDO0VBRXhsQjtDQUNGO0NBQ0EsTUFBTSx1QkFBdUIsU0FBUyxPQUFPLEtBQUssUUFBUSxRQUFRO0NBQ2xFLE1BQU0sd0JBQXdCLFNBQVMsT0FBTyxLQUFLLGVBQWU7RUFDaEUscUJBQXFCO0VBQ3JCLHNCQUFzQjtDQUN4QixDQUFDO0NBQ0QsV0FBVyxnQkFBZ0I7RUFDekIscUJBQXFCO0VBQ3JCLHNCQUFzQjtDQUN4QixDQUFDO0NBQ0QsMEJBQTBCLEtBQUssUUFBUTtBQUN6QztBQUNBLFNBQVMsNkJBQTZCLEtBQUs7Q0FDekMsSUFBSSxvQkFBb0IsQ0FBQztDQUN6QixJQUFJLElBQUksVUFBVSxLQUFBLEdBQVcsa0JBQWtCLEtBQUssT0FBTztDQUMzRCxJQUFJLElBQUksV0FBVyxLQUFBLEdBQVcsa0JBQWtCLEtBQUssUUFBUTtDQUM3RCxJQUFJLGtCQUFrQixTQUFTLEdBQzdCLE1BQU0sSUFBSUMsYUFBYyxNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLDBDQUErQyxrQkFBa0IsS0FBSSxTQUFRLElBQUksS0FBSyxFQUFFLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxnTkFBK047QUFFeFk7QUFDQSxTQUFTLDBCQUEwQixLQUFLO0NBQ3RDLElBQUksSUFBSSxTQUFTLElBQUksUUFDbkIsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsMk5BQXFPO0FBRXpTO0FBQ0EsU0FBUyw0QkFBNEIsS0FBSyxLQUFLLFVBQVUsWUFBWTtDQUNuRSxNQUFNLGlCQUFpQjtFQUNyQixxQkFBcUI7RUFDckIsc0JBQXNCO0VBQ3RCLE1BQU0saUJBQWlCLElBQUk7RUFDM0IsSUFBSSxJQUFJLFFBQVEsbUJBQW1CLEdBQ2pDLFFBQVEsS0FBS0QsbUJBQW9CLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsNlVBQWlXLENBQUM7Q0FFL2E7Q0FDQSxNQUFNLHVCQUF1QixTQUFTLE9BQU8sS0FBSyxRQUFRLFFBQVE7Q0FDbEUsTUFBTSx3QkFBd0IsU0FBUyxPQUFPLEtBQUssZUFBZTtFQUNoRSxxQkFBcUI7RUFDckIsc0JBQXNCO0NBQ3hCLENBQUM7Q0FDRCxXQUFXLGdCQUFnQjtFQUN6QixxQkFBcUI7RUFDckIsc0JBQXNCO0NBQ3hCLENBQUM7Q0FDRCwwQkFBMEIsS0FBSyxRQUFRO0FBQ3pDO0FBQ0EsU0FBUyx3QkFBd0IsS0FBSztDQUNwQyxJQUFJLElBQUksV0FBVyxJQUFJLFVBQ3JCLE1BQU0sSUFBSUMsYUFBYyxNQUFNLEdBQUcsb0JBQW9CLElBQUksS0FBSyxFQUFFLDJQQUErUTtDQUdqVixJQUFJLE9BQU8sSUFBSSxZQUFZLFlBQVksQ0FBQztFQURuQjtFQUFRO0VBQVM7Q0FDWSxDQUFDLENBQUMsU0FBUyxJQUFJLE9BQU8sR0FDdEUsTUFBTSxJQUFJQSxhQUFjLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUscURBQTBELElBQUksUUFBUSxzRUFBMkU7QUFFck47QUFDQSxTQUFTLHlCQUF5QixLQUFLO0NBRXJDLElBQUksT0FBTyxJQUFJLGFBQWEsWUFBWSxDQUFDO0VBRHBCO0VBQVE7RUFBUztDQUNhLENBQUMsQ0FBQyxTQUFTLElBQUksUUFBUSxHQUN4RSxNQUFNLElBQUlBLGFBQWMsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSxzREFBMkQsSUFBSSxTQUFTLHNFQUEyRTtBQUV2TjtBQUNBLFNBQVMsOEJBQThCLE9BQU8sYUFBYTtDQUN6RCxJQUFJLGdCQUFnQixpQkFBaUI7RUFDbkMsSUFBSSxvQkFBb0I7RUFDeEIsS0FBSyxNQUFNLFVBQVUsa0JBQ25CLElBQUksT0FBTyxRQUFRLEtBQUssR0FBRztHQUN6QixvQkFBb0IsT0FBTztHQUMzQjtFQUNGO0VBRUYsSUFBSSxtQkFDRixRQUFRLEtBQUtELG1CQUFvQixNQUFNLG9FQUF5RSxrQkFBa0IseUlBQW1KLGtCQUFrQixvTUFBbU4sQ0FBQztDQUUvZjtBQUNGO0FBQ0EsU0FBUyw4QkFBOEIsS0FBSyxhQUFhO0NBQ3ZELElBQUksSUFBSSxZQUFZLGdCQUFnQixpQkFDbEMsUUFBUSxLQUFLQSxtQkFBb0IsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSw0UUFBMlIsQ0FBQztBQUV6VztBQUNBLFNBQVMsa0NBQWtDLEtBQUssYUFBYTtDQUMzRCxJQUFJLElBQUksZ0JBQWdCLGdCQUFnQixpQkFDdEMsUUFBUSxLQUFLQSxtQkFBb0IsTUFBTSxHQUFHLG9CQUFvQixJQUFJLEtBQUssRUFBRSwwU0FBeVQsQ0FBQztBQUV2WTtBQUNBLFNBQWUsaUNBQWlDLElBQUE7Ozs7MEVBQVE7RUFDdEQsSUFBSSxrQ0FBa0MsR0FBRztHQUN2QztHQUNBLE1BQU0sT0FBTyxXQUFXO0dBQ3hCLElBQUksZ0NBQWdDLDBCQUNsQyxRQUFRLEtBQUtBLG1CQUFvQixNQUFNLHVFQUF1RSx5QkFBeUIsVUFBVSw4QkFBOEIsNkxBQXVNLENBQUM7RUFFM1gsT0FDRTtDQUVKLENBQUE7OztBQUNBLFNBQVMsNEJBQTRCLEtBQUssWUFBWTtDQUNwRCxNQUFNLGdCQUFnQixPQUFPLGlCQUFpQixVQUFVO0NBQ3hELElBQUksZ0JBQWdCLFdBQVcsY0FBYyxpQkFBaUIsT0FBTyxDQUFDO0NBQ3RFLElBQUksaUJBQWlCLFdBQVcsY0FBYyxpQkFBaUIsUUFBUSxDQUFDO0NBQ3hFLElBQUksZ0JBQWdCLCtCQUErQixpQkFBaUIsNkJBQ2xFLFFBQVEsS0FBS0EsbUJBQW9CLE1BQU0sR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsb0hBQXlILDRCQUE0Qix1REFBNEQsQ0FBQztBQUUvUjtBQUNBLFNBQVMsMEJBQTBCLEtBQUssVUFBVTtDQUNoRCxJQUFJLElBQUksWUFBWSxJQUFJLGNBQ3RCLFNBQVM7QUFFYjtBQUNBLFNBQVMsTUFBTSxPQUFPO0NBQ3BCLE9BQU8sT0FBTyxVQUFVLEtBQUssSUFBSSxRQUFRLE1BQU0sUUFBUSxDQUFDO0FBQzFEO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsSUFBSSxPQUFPLFVBQVUsVUFDbkIsT0FBTztDQUVULE9BQU9TLGdCQUFpQixLQUFLO0FBQy9CO0FBQ0EsU0FBUyxzQkFBc0IsT0FBTztDQUNwQyxJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsVUFBVSxVQUFVLFdBQVcsVUFBVSxJQUNsRixPQUFPO0NBRVQsT0FBTyxpQkFBaUIsS0FBSztBQUMvQiJ9