import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-6NAJDQ7D.js");import {
  EncryptionEngine,
  PsbtUtils,
  SocketService,
  UrService,
  WidgetDispatcherService
} from "/chunk-2GVOWOPG.js";
import {
  ConfigService,
  __async
} from "/chunk-PZ54WRVW.js";

// apps/client/src/app/pages/create/create.component.ts
import { Component, signal, inject, HostListener } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { CommonModule } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import { Router, RouterModule, ActivatedRoute } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
import { FormsModule } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_forms.js?v=cf17c1b4";
import { LucideCheck, LucideLoader2, LucideX, LucideUploadCloud, LucideFileJson, LucideAlertTriangle, LucideShield, LucideEye, LucideEyeOff, LucideQrCode, LucideEdit2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@lucide_angular.js?v=cf17c1b4";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/html5-qrcode.js?v=cf17c1b4";
import * as i0 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i1 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import * as i2 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
import * as i3 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_forms.js?v=cf17c1b4";
function CreateComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 1)(1, "div", 3);
    i0.\u0275\u0275element(2, "img", 4);
    i0.\u0275\u0275elementStart(3, "h3", 5);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementStart(5, "span", 6);
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(7, "svg", 7);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(8, "h2", 8);
    i0.\u0275\u0275text(9, "Waiting for Data...");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "p", 9);
    i0.\u0275\u0275text(11, "Please initialize the signing ceremony or pass the transaction payload from your host application.");
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("src", ctx_r0.configService.config().logoUrl, i0.\u0275\u0275sanitizeUrl)("alt", ctx_r0.configService.config().brandName);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r0.configService.config().brandSuffix || "");
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "img", 14);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("src", ctx_r0.configService.config().logoUrl, i0.\u0275\u0275sanitizeUrl)("alt", ctx_r0.configService.config().brandName);
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275elementStart(0, "svg", 15)(1, "g");
    i0.\u0275\u0275element(2, "path", 29)(3, "path", 30)(4, "path", 31)(5, "path", 32);
    i0.\u0275\u0275elementEnd()();
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_7_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start a Signing Room\xAE ");
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_7_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start ");
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275conditionalCreate(0, CreateComponent_Conditional_2_Conditional_0_Conditional_7_Conditional_0_Template, 1, 0)(1, CreateComponent_Conditional_2_Conditional_0_Conditional_7_Conditional_1_Template, 1, 0);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().useTradeMark ? 0 : 1);
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Launch Signing Room\xAE ");
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "img", 4);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("src", ctx_r0.configService.config().logoUrl, i0.\u0275\u0275sanitizeUrl)("alt", ctx_r0.configService.config().brandName);
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275elementStart(0, "svg", 22)(1, "g");
    i0.\u0275\u0275element(2, "path", 29)(3, "path", 30)(4, "path", 31)(5, "path", 32);
    i0.\u0275\u0275elementEnd()();
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_40_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start a Signing Room\xAE ");
  }
}
function CreateComponent_Conditional_2_Conditional_0_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start ");
  }
}
function CreateComponent_Conditional_2_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275element(0, "div", 11);
    i0.\u0275\u0275elementStart(1, "div", 12)(2, "div", 13);
    i0.\u0275\u0275conditionalCreate(3, CreateComponent_Conditional_2_Conditional_0_Conditional_3_Template, 1, 2, "img", 14)(4, CreateComponent_Conditional_2_Conditional_0_Conditional_4_Template, 6, 0, ":svg:svg", 15);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "h1", 16)(6, "span");
    i0.\u0275\u0275conditionalCreate(7, CreateComponent_Conditional_2_Conditional_0_Conditional_7_Template, 2, 1)(8, CreateComponent_Conditional_2_Conditional_0_Conditional_8_Template, 1, 0);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(9, "p", 17);
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(11, "div", 18)(12, "div", 19)(13, "div", 20)(14, "div", 21);
    i0.\u0275\u0275conditionalCreate(15, CreateComponent_Conditional_2_Conditional_0_Conditional_15_Template, 1, 2, "img", 4)(16, CreateComponent_Conditional_2_Conditional_0_Conditional_16_Template, 6, 0, ":svg:svg", 22);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(17, "div")(18, "h3", 5);
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275elementStart(20, "span", 6);
    i0.\u0275\u0275text(21);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(22, "div", 23);
    i0.\u0275\u0275text(23);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(24, "ul", 24)(25, "li", 25);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(26, "svg", 26);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(27, "span");
    i0.\u0275\u0275text(28, "Stateless Blind Relay (RAM-Only)");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(29, "li", 25);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(30, "svg", 26);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(31, "span");
    i0.\u0275\u0275text(32, "End-to-End AES-GCM Encryption");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(33, "li", 25);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(34, "svg", 26);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(35, "span");
    i0.\u0275\u0275text(36, "Ceremony Audit Logs");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(37, "button", 27);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_2_Conditional_0_Template_button_click_37_listener() {
      i0.\u0275\u0275restoreView(_r2);
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r0.showCreateModal.set(true));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(38, "svg", 28);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(39, "span");
    i0.\u0275\u0275conditionalCreate(40, CreateComponent_Conditional_2_Conditional_0_Conditional_40_Template, 1, 0)(41, CreateComponent_Conditional_2_Conditional_0_Conditional_41_Template, 1, 0);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().whitelabel ? 3 : 4);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().whitelabel ? 7 : 8);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(ctx_r0.configService.config().tagline);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().whitelabel ? 15 : 16);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r0.configService.config().brandSuffix || "");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r0.configService.config().subTagline);
    i0.\u0275\u0275advance(17);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().useTradeMark ? 40 : 41);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 47);
    i0.\u0275\u0275text(1, " Securing Room... ");
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_25_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start a Signing Room\xAE ");
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_25_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start ");
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275conditionalCreate(0, CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_25_Conditional_0_Template, 1, 0)(1, CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_25_Conditional_1_Template, 1, 0);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(4);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().useTradeMark ? 0 : 1);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 33)(1, "div", 34);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 35);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(3, "h3", 36);
    i0.\u0275\u0275text(4, "Confirm Ceremony");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(5, "div", 37)(6, "div", 38);
    i0.\u0275\u0275text(7, "Total Amount");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "div", 39);
    i0.\u0275\u0275text(9);
    i0.\u0275\u0275elementStart(10, "span", 17);
    i0.\u0275\u0275text(11, "BTC");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(12, "div", 40)(13, "div", 41)(14, "span", 42);
    i0.\u0275\u0275text(15, "Signers");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(16, "span", 43);
    i0.\u0275\u0275text(17);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(18, "div", 41)(19, "span", 42);
    i0.\u0275\u0275text(20, "Network");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(21, "span", 44);
    i0.\u0275\u0275text(22);
    i0.\u0275\u0275elementEnd()()()();
    i0.\u0275\u0275elementStart(23, "button", 45);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Template_button_click_23_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.launchRoom());
    });
    i0.\u0275\u0275conditionalCreate(24, CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_24_Template, 2, 0)(25, CreateComponent_Conditional_2_Conditional_1_Conditional_1_Conditional_25_Template, 2, 1);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(26, "button", 46);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_2_Conditional_1_Conditional_1_Template_button_click_26_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.clearPsbt());
    });
    i0.\u0275\u0275text(27, "Cancel and go back");
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275textInterpolate1("", ctx_r0.psbtAnalysis()?.amountBtc, " ");
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(ctx_r0.psbtAnalysis()?.signerCount);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(ctx_r0.selectedNetwork());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("disabled", ctx_r0.isLoading());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.isLoading() ? 24 : 25);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 56);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 57);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 56);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 57);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 18)(1, "div", 48)(2, "div", 20)(3, "div", 21);
    i0.\u0275\u0275element(4, "img", 4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "div")(6, "h3", 5);
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275elementStart(8, "span", 6);
    i0.\u0275\u0275text(9);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "div", 23);
    i0.\u0275\u0275text(11);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(12, "div", 49)(13, "div")(14, "div", 50)(15, "label", 51);
    i0.\u0275\u0275text(16, "Room ID");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(17, "span", 52);
    i0.\u0275\u0275text(18);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(19, "div", 53)(20, "input", 54);
    i0.\u0275\u0275twoWayListener("ngModelChange", function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template_input_ngModelChange_20_listener($event) {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      i0.\u0275\u0275twoWayBindingSet(ctx_r0.manualRoomId, $event) || (ctx_r0.manualRoomId = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(21, "button", 55);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.showManualRoomId = !ctx_r0.showManualRoomId);
    });
    i0.\u0275\u0275conditionalCreate(22, CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_22_Template, 1, 0, ":svg:svg", 56)(23, CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_23_Template, 1, 0, ":svg:svg", 57);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(24, "div")(25, "div", 50)(26, "label", 51);
    i0.\u0275\u0275text(27, "Decryption Key");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(28, "span", 52);
    i0.\u0275\u0275text(29);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(30, "div", 53)(31, "input", 58);
    i0.\u0275\u0275twoWayListener("ngModelChange", function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template_input_ngModelChange_31_listener($event) {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      i0.\u0275\u0275twoWayBindingSet(ctx_r0.manualKey, $event) || (ctx_r0.manualKey = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(32, "button", 59);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template_button_click_32_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.showManualKey = !ctx_r0.showManualKey);
    });
    i0.\u0275\u0275conditionalCreate(33, CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_33_Template, 1, 0, ":svg:svg", 56)(34, CreateComponent_Conditional_2_Conditional_1_Conditional_2_Conditional_34_Template, 1, 0, ":svg:svg", 57);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(35, "button", 60);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template_button_click_35_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.joinRoom());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(36, "svg", 61);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(37, "span");
    i0.\u0275\u0275text(38);
    i0.\u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275property("src", ctx_r0.configService.config().logoUrl, i0.\u0275\u0275sanitizeUrl)("alt", ctx_r0.configService.config().brandName);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r0.configService.config().brandSuffix || "");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r0.configService.config().subTagline);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275classProp("text-red-400", ctx_r0.manualRoomId.length >= 36)("text-brand-text-muted", ctx_r0.manualRoomId.length < 36);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.manualRoomId.length, " / 36 ");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("type", ctx_r0.showManualRoomId ? "text" : "password");
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r0.manualRoomId);
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r0.showManualRoomId ? 22 : 23);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275classProp("text-red-400", ctx_r0.manualKey.length >= 44)("text-brand-text-muted", ctx_r0.manualKey.length < 44);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.manualKey.length, " / 44 ");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("type", ctx_r0.showManualKey ? "text" : "password");
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r0.manualKey);
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r0.showManualKey ? 33 : 34);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("disabled", ctx_r0.manualRoomId.length !== 36 || ctx_r0.manualKey.length !== 44);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classProp("group-hover/btn:scale-125", ctx_r0.manualRoomId.length === 36 && ctx_r0.manualKey.length === 44);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("Enter ", ctx_r0.configService.config().brandName);
  }
}
function CreateComponent_Conditional_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 10);
    i0.\u0275\u0275conditionalCreate(1, CreateComponent_Conditional_2_Conditional_1_Conditional_1_Template, 28, 5, "div", 33)(2, CreateComponent_Conditional_2_Conditional_1_Conditional_2_Template, 39, 25, "div", 18);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.psbtAnalysis() ? 1 : 2);
  }
}
function CreateComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275conditionalCreate(0, CreateComponent_Conditional_2_Conditional_0_Template, 42, 8);
    i0.\u0275\u0275conditionalCreate(1, CreateComponent_Conditional_2_Conditional_1_Template, 3, 1, "div", 10);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275conditional(!ctx_r0.isEmbedded ? 0 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.isEmbedded ? 1 : -1);
  }
}
function CreateComponent_Conditional_3_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 75);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_3_Conditional_2_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r0.showCreateModal.set(false));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 76);
    i0.\u0275\u0275elementEnd();
  }
}
function CreateComponent_Conditional_3_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Configure Signing Room\xAE ");
  }
}
function CreateComponent_Conditional_3_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Configure ");
  }
}
function CreateComponent_Conditional_3_For_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 77);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_3_For_11_Template_button_click_0_listener() {
      const net_r8 = i0.\u0275\u0275restoreView(_r7).$implicit;
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r0.selectedNetwork.set(net_r8));
    });
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const net_r8 = ctx.$implicit;
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classProp("bg-brand-accent_20", ctx_r0.selectedNetwork() === net_r8)("border-brand-accent", ctx_r0.selectedNetwork() === net_r8)("text-brand-accent", ctx_r0.selectedNetwork() === net_r8)("bg-brand-bg", ctx_r0.selectedNetwork() !== net_r8)("border-brand-card-border", ctx_r0.selectedNetwork() !== net_r8)("text-brand-text-muted", ctx_r0.selectedNetwork() !== net_r8);
    i0.\u0275\u0275property("id", i0.\u0275\u0275interpolate1("select-network-", net_r8));
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", net_r8, " ");
  }
}
function CreateComponent_Conditional_3_Conditional_15_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 78);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 94);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "div")(3, "h4", 95);
    i0.\u0275\u0275text(4, "Processing Failed");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "p", 96);
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(ctx_r0.errorMessage());
  }
}
function CreateComponent_Conditional_3_Conditional_15_Conditional_17_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 105);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 117);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "span", 118);
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(4);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(ctx_r0.urService.scanError());
  }
}
function CreateComponent_Conditional_3_Conditional_15_Conditional_17_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 115)(1, "div", 119)(2, "span");
    i0.\u0275\u0275text(3, "RECONSTRUCTING PSBT...");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "span");
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "div", 120);
    i0.\u0275\u0275element(7, "div", 121);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(4);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate1("", (ctx_r0.urService.scanProgress() * 100).toFixed(0), "%");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275styleProp("width", ctx_r0.urService.scanProgress() * 100, "%");
  }
}
function CreateComponent_Conditional_3_Conditional_15_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 88)(1, "div", 97);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 98);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(3, "div", 99)(4, "p")(5, "strong");
    i0.\u0275\u0275text(6, "Secure Scanner:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(7, " Hold your hardware wallet displaying PSBT QR Code up to the camera. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "p", 100);
    i0.\u0275\u0275text(9, " \u{1F4A1} ");
    i0.\u0275\u0275elementStart(10, "strong");
    i0.\u0275\u0275text(11, "Tip:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(12);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(13, "div", 101)(14, "div", 102)(15, "span", 103);
    i0.\u0275\u0275text(16, "Raw Optical Feed");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(17, "span", 104);
    i0.\u0275\u0275text(18);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(19, CreateComponent_Conditional_3_Conditional_15_Conditional_17_Conditional_19_Template, 4, 1, "div", 105);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(20, "div", 106);
    i0.\u0275\u0275element(21, "div", 107);
    i0.\u0275\u0275elementStart(22, "div", 108)(23, "div", 109);
    i0.\u0275\u0275element(24, "div", 110)(25, "div", 111)(26, "div", 112)(27, "div", 113)(28, "div", 114);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(29, CreateComponent_Conditional_3_Conditional_15_Conditional_17_Conditional_29_Template, 8, 3, "div", 115);
    i0.\u0275\u0275elementStart(30, "button", 116);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_3_Conditional_15_Conditional_17_Template_button_click_30_listener() {
      i0.\u0275\u0275restoreView(_r10);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.stopScanner());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(31, "svg", 76);
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance(12);
    i0.\u0275\u0275textInterpolate1(" Sometimes QR codes are too small for webcams to read off a hardware device. You can use a mobile companion application to scan the hardware wallet, and then export the Signed PSBT to ", ctx_r0.configService.config().brandName, " through this reader. ");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("title", ctx_r0.urService.lastScannedText());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.urService.lastScannedText() || "Waiting for QR...", " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.urService.scanError() ? 19 : -1);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275conditional(ctx_r0.urService.scanProgress() > 0 ? 29 : -1);
  }
}
function CreateComponent_Conditional_3_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275conditionalCreate(0, CreateComponent_Conditional_3_Conditional_15_Conditional_0_Template, 7, 1, "div", 78);
    i0.\u0275\u0275elementStart(1, "div", 79)(2, "div", 80)(3, "input", 81);
    i0.\u0275\u0275listener("change", function CreateComponent_Conditional_3_Conditional_15_Template_input_change_3_listener($event) {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r0.onFileSelected($event));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "div", 82);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(5, "svg", 83);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(6, "span", 84);
    i0.\u0275\u0275text(7, "Upload PSBT File");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "span", 85);
    i0.\u0275\u0275text(9, ".psbt, .txt, or .hex");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "button", 86);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_3_Conditional_15_Template_button_click_10_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r0.startScanner());
    });
    i0.\u0275\u0275elementStart(11, "div", 82);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(12, "svg", 87);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(13, "span", 84);
    i0.\u0275\u0275text(14, "Scan QR Code");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(15, "span", 85);
    i0.\u0275\u0275text(16, "Air-gapped hardware optics");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275conditionalCreate(17, CreateComponent_Conditional_3_Conditional_15_Conditional_17_Template, 32, 5, "div", 88);
    i0.\u0275\u0275elementStart(18, "div", 89);
    i0.\u0275\u0275element(19, "div", 90);
    i0.\u0275\u0275elementStart(20, "span", 91);
    i0.\u0275\u0275text(21, "Or paste directly");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275element(22, "div", 90);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(23, "div", 53)(24, "textarea", 92);
    i0.\u0275\u0275twoWayListener("ngModelChange", function CreateComponent_Conditional_3_Conditional_15_Template_textarea_ngModelChange_24_listener($event) {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r0.rawHex, $event) || (ctx_r0.rawHex = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275listener("ngModelChange", function CreateComponent_Conditional_3_Conditional_15_Template_textarea_ngModelChange_24_listener($event) {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r0 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r0.analyzeRawHex($event));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(25, "svg", 93);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275conditional(ctx_r0.errorMessage() ? 0 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("opacity-50", ctx_r0.isScanning());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("disabled", ctx_r0.isScanning());
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275property("disabled", ctx_r0.isScanning());
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275conditional(ctx_r0.isScanning() ? 17 : -1);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r0.rawHex);
    i0.\u0275\u0275property("disabled", ctx_r0.isScanning());
    i0.\u0275\u0275control();
  }
}
function CreateComponent_Conditional_3_Conditional_16_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 134);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_3_Conditional_16_Conditional_10_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r11);
      const ctx_r0 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r0.clearPsbt());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 76);
    i0.\u0275\u0275elementEnd();
  }
}
function CreateComponent_Conditional_3_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 71)(1, "div", 122)(2, "div", 123)(3, "div", 124);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 125);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "div")(6, "div", 126);
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "div", 127);
    i0.\u0275\u0275text(9);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275conditionalCreate(10, CreateComponent_Conditional_3_Conditional_16_Conditional_10_Template, 2, 0, "button", 128);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(11, "div", 129)(12, "div", 130)(13, "div", 131);
    i0.\u0275\u0275text(14, "Amount");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(15, "div", 132);
    i0.\u0275\u0275text(16);
    i0.\u0275\u0275pipe(17, "number");
    i0.\u0275\u0275elementStart(18, "span", 133);
    i0.\u0275\u0275text(19, "BTC");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(20, "div", 130)(21, "div", 131);
    i0.\u0275\u0275text(22, "Network Fee");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(23, "div", 132);
    i0.\u0275\u0275text(24);
    i0.\u0275\u0275pipe(25, "number");
    i0.\u0275\u0275elementStart(26, "span", 133);
    i0.\u0275\u0275text(27, "sats");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(28, "div", 130)(29, "div", 131);
    i0.\u0275\u0275text(30, "Signers");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(31, "div", 132);
    i0.\u0275\u0275text(32);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.psbtFile()?.name || "Handled via Optics", " ");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.psbtAnalysis()?.outputCount, " Outputs detected ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(!ctx_r0.isEmbedded ? 10 : -1);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind2(17, 6, ctx_r0.psbtAnalysis()?.amountBtc, "1.4-4"), " ");
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind1(25, 9, ctx_r0.psbtAnalysis()?.networkFeeSat), " ");
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r0.psbtAnalysis()?.signerCount, " ");
  }
}
function CreateComponent_Conditional_3_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 72);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 135);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "div")(3, "div", 136);
    i0.\u0275\u0275text(4, "Network Mismatch");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "p", 137);
    i0.\u0275\u0275text(6, " Selected: ");
    i0.\u0275\u0275elementStart(7, "strong");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275pipe(9, "titlecase");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(10, ". PSBT: ");
    i0.\u0275\u0275elementStart(11, "strong");
    i0.\u0275\u0275text(12);
    i0.\u0275\u0275pipe(13, "titlecase");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14, ". ");
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(9, 2, ctx_r0.selectedNetwork()));
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(i0.\u0275\u0275pipeBind1(13, 4, ctx_r0.psbtAnalysis()?.detectedNetwork));
  }
}
function CreateComponent_Conditional_3_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 73);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 138);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "div")(3, "div", 139);
    i0.\u0275\u0275text(4, "High Fee Detected");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "p", 140);
    i0.\u0275\u0275text(6, "The network fee is unusually high (>100 sats/vB or >5% of total).");
    i0.\u0275\u0275elementEnd()()();
  }
}
function CreateComponent_Conditional_3_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 141);
    i0.\u0275\u0275text(1, " Creating... ");
  }
}
function CreateComponent_Conditional_3_Conditional_21_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start a Signing Room\xAE ");
  }
}
function CreateComponent_Conditional_3_Conditional_21_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Start ");
  }
}
function CreateComponent_Conditional_3_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 28);
    i0.\u0275\u0275conditionalCreate(1, CreateComponent_Conditional_3_Conditional_21_Conditional_1_Template, 1, 0)(2, CreateComponent_Conditional_3_Conditional_21_Conditional_2_Template, 1, 0);
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.configService.config().useTradeMark ? 1 : 2);
  }
}
function CreateComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 2)(1, "div", 62);
    i0.\u0275\u0275conditionalCreate(2, CreateComponent_Conditional_3_Conditional_2_Template, 2, 0, "button", 63);
    i0.\u0275\u0275elementStart(3, "h2", 64);
    i0.\u0275\u0275conditionalCreate(4, CreateComponent_Conditional_3_Conditional_4_Template, 1, 0)(5, CreateComponent_Conditional_3_Conditional_5_Template, 1, 0);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "div", 65)(7, "label", 66);
    i0.\u0275\u0275text(8, "Network");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(9, "div", 67);
    i0.\u0275\u0275repeaterCreate(10, CreateComponent_Conditional_3_For_11_Template, 2, 15, "button", 68, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(12, "div", 69)(13, "label", 70);
    i0.\u0275\u0275text(14, "Transaction Data (Required)");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(15, CreateComponent_Conditional_3_Conditional_15_Template, 26, 8)(16, CreateComponent_Conditional_3_Conditional_16_Template, 33, 11, "div", 71);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(17, CreateComponent_Conditional_3_Conditional_17_Template, 15, 6, "div", 72);
    i0.\u0275\u0275conditionalCreate(18, CreateComponent_Conditional_3_Conditional_18_Template, 7, 0, "div", 73);
    i0.\u0275\u0275elementStart(19, "button", 74);
    i0.\u0275\u0275listener("click", function CreateComponent_Conditional_3_Template_button_click_19_listener() {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r0 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r0.launchRoom());
    });
    i0.\u0275\u0275conditionalCreate(20, CreateComponent_Conditional_3_Conditional_20_Template, 2, 0)(21, CreateComponent_Conditional_3_Conditional_21_Template, 3, 1);
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(!ctx_r0.isEmbedded ? 2 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r0.configService.config().useTradeMark ? 4 : 5);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275repeater(ctx_r0.networks);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275conditional(!ctx_r0.psbtAnalysis() ? 15 : 16);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r0.isNetworkMismatch() ? 17 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.isHighFee() ? 18 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("disabled", ctx_r0.isLoading() || !ctx_r0.psbtAnalysis() || ctx_r0.isNetworkMismatch());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r0.isLoading() ? 20 : 21);
  }
}
var NETWORKS = ["bitcoin", "testnet", "signet"];
var CreateComponent = class _CreateComponent {
  viewMode = "default";
  showManualRoomId = false;
  showManualKey = false;
  expectedHost = "";
  socket = inject(SocketService);
  router = inject(Router);
  route = inject(ActivatedRoute);
  urService = inject(UrService);
  dispatcher = inject(WidgetDispatcherService);
  encryptionEngine = inject(EncryptionEngine);
  configService = inject(ConfigService);
  networks = NETWORKS;
  selectedNetwork = signal(
    "bitcoin",
    ...ngDevMode ? [{ debugName: "selectedNetwork" }] : (
      /* istanbul ignore next */
      []
    )
  );
  psbtFile = signal(
    null,
    ...ngDevMode ? [{ debugName: "psbtFile" }] : (
      /* istanbul ignore next */
      []
    )
  );
  psbtAnalysis = signal(
    null,
    ...ngDevMode ? [{ debugName: "psbtAnalysis" }] : (
      /* istanbul ignore next */
      []
    )
  );
  rawHex = "";
  showCreateModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showCreateModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isLoading = signal(
    false,
    ...ngDevMode ? [{ debugName: "isLoading" }] : (
      /* istanbul ignore next */
      []
    )
  );
  errorMessage = signal(
    null,
    ...ngDevMode ? [{ debugName: "errorMessage" }] : (
      /* istanbul ignore next */
      []
    )
  );
  // --- EMBED PROPERTIES ---
  isEmbedded = false;
  manualRoomId = "";
  manualKey = "";
  isScanning = signal(
    false,
    ...ngDevMode ? [{ debugName: "isScanning" }] : (
      /* istanbul ignore next */
      []
    )
  );
  html5QrCode = null;
  onMessage(event) {
    return __async(this, null, function* () {
      if (this.expectedHost && event.origin !== this.expectedHost) {
        console.warn(`[Security] Blocked unauthorized postMessage from: ${event.origin}`);
        return;
      }
      if (event.data?.type === "SIGNING_ROOM_COMMAND") {
        if (event.data.action === "LOAD_PSBT" && event.data.payload) {
          const hostNetwork = this.route.snapshot.queryParamMap.get("network");
          if (hostNetwork) {
            this.selectedNetwork.set(hostNetwork);
          }
          const payloadString = event.data.payload.trim();
          const dummyFile = new File([payloadString], "loaded_transaction.psbt.txt", {
            type: "text/plain"
          });
          let files = [dummyFile];
          if (typeof DataTransfer !== "undefined") {
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(dummyFile);
            files = dataTransfer.files;
          }
          const mockEvent = {
            target: { files },
            preventDefault: () => {
            },
            stopPropagation: () => {
            }
          };
          yield this.onFileSelected(mockEvent);
          this.showCreateModal.set(true);
        }
      }
    });
  }
  ngOnInit() {
    this.viewMode = this.route.snapshot.queryParamMap.get("view") || "default";
    this.expectedHost = this.route.snapshot.queryParamMap.get("host") || "";
    if (typeof window !== "undefined") {
      if (!this.expectedHost) {
        this.expectedHost = window.location.origin;
      }
      this.isEmbedded = window !== window.parent || window !== window.top;
      if (this.isEmbedded) {
        window.parent.postMessage({
          type: "SIGNING_ROOM_EVENT",
          action: "WIDGET_READY"
        }, this.expectedHost);
      }
    }
  }
  clearPsbt() {
    this.psbtFile.set(null);
    this.rawHex = "";
    this.psbtAnalysis.set(null);
    this.errorMessage.set(null);
  }
  launchRoom() {
    return __async(this, null, function* () {
      this.isLoading.set(true);
      try {
        const createRoomPayload = yield this.socket.createRoom(this.rawHex, this.selectedNetwork(), "Untitled Room");
        const encryptedToken = yield this.encryptionEngine.encrypt(createRoomPayload.httpPayload.adminToken, createRoomPayload.localData.encryptionKey);
        sessionStorage.setItem(`admin_token_${createRoomPayload.localData.roomId}`, encryptedToken);
        this.dispatcher.emitRoomCreated(createRoomPayload.localData.roomId, this.selectedNetwork());
        this.router.navigate(["/room", createRoomPayload.localData.roomId], {
          fragment: createRoomPayload.localData.encryptionKey
        });
      } catch (e) {
        console.error(e);
      } finally {
        this.isLoading.set(false);
      }
    });
  }
  joinRoom() {
    if (this.manualRoomId && this.manualKey) {
      const cleanKey = this.manualKey.includes("#") ? this.manualKey.split("#")[1] : this.manualKey;
      this.router.navigate(["/room", this.manualRoomId.trim()], {
        fragment: cleanKey.trim()
      });
    }
  }
  onFileSelected(event) {
    return __async(this, null, function* () {
      const file = event.target.files[0];
      if (!file)
        return;
      this.psbtFile.set(file);
      this.errorMessage.set(null);
      try {
        const buffer = yield file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        const isBinary = bytes[0] === 112 && bytes[1] === 115 && bytes[2] === 98 && bytes[3] === 116 && bytes[4] === 255;
        const content = isBinary ? Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("") : new TextDecoder().decode(bytes).trim();
        this.rawHex = content;
        this.analyzeRawHex(content);
      } catch (e) {
        console.error(e);
      }
    });
  }
  analyzeRawHex(data) {
    if (!data || data.length < 10)
      return;
    const analysis = PsbtUtils.analyze(data);
    if (analysis) {
      this.psbtAnalysis.set(analysis);
      this.errorMessage.set(null);
    } else {
      this.psbtAnalysis.set(null);
      this.errorMessage.set("Invalid PSBT format. Please ensure you are providing a valid Base64 or Hex encoded Partially Signed Bitcoin Transaction.");
      if (this.isEmbedded) {
        window.parent.postMessage({
          type: "SIGNING_ROOM_EVENT",
          action: "signingError",
          payload: {
            code: "PSBT_INVALID",
            message: "Failed to parse PSBT data."
          }
        }, this.expectedHost);
      }
    }
  }
  emitRoomCreated(roomId, network) {
    this.dispatcher.emitRoomCreated(roomId, network);
  }
  // UX Helpers
  isNetworkMismatch() {
    const analysis = this.psbtAnalysis();
    if (!analysis)
      return false;
    return analysis.detectedNetwork === "bitcoin" && this.selectedNetwork() !== "bitcoin" || analysis.detectedNetwork === "testnet" && this.selectedNetwork() === "bitcoin";
  }
  isHighFee() {
    const analysis = this.psbtAnalysis();
    if (!analysis || analysis.networkFeeSat === 0)
      return false;
    const estVBytes = analysis.signerCount * 68 + analysis.outputCount * 31 + 10;
    const rate = analysis.networkFeeSat / estVBytes;
    const totalSats = analysis.amountBtc * 1e8;
    return rate > 100 || totalSats > 0 && analysis.networkFeeSat / totalSats > 0.05;
  }
  isProcessingScan = false;
  startScanner() {
    return __async(this, null, function* () {
      this.isScanning.set(true);
      this.isProcessingScan = false;
      this.errorMessage.set(null);
      this.urService.resetDecoder();
      setTimeout(() => __async(this, null, function* () {
        this.html5QrCode = new Html5Qrcode("reader", {
          formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE],
          verbose: false,
          experimentalFeatures: {
            useBarCodeDetectorIfSupported: true
          }
        });
        let frameCount = 0;
        try {
          yield this.html5QrCode.start({ facingMode: "environment" }, {
            fps: 10,
            disableFlip: true,
            qrbox: { width: 350, height: 350 },
            videoConstraints: {
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }
          }, (decodedText) => this.handleScanResult(decodedText), (errorMessage) => {
            frameCount++;
            if (frameCount % 60 === 0) {
              console.warn(`[Optical Debug] Frame ${frameCount} - Engine failing to lock:`, errorMessage.split("\n")[0]);
            }
          });
        } catch (err) {
          console.warn("High-res camera start failed. Falling back to standard resolution...", err);
          try {
            yield this.html5QrCode.start({ facingMode: "environment" }, { fps: 10, disableFlip: false }, (decodedText) => this.handleScanResult(decodedText), () => {
              console.error("Fallback camera failed to start.");
            });
          } catch (fallbackErr) {
            console.error("Fallback camera start also failed:", fallbackErr);
            this.stopScanner();
          }
        }
      }), 100);
    });
  }
  handleScanResult(decodedText) {
    return __async(this, null, function* () {
      if (this.isProcessingScan)
        return;
      const upper = decodedText.toUpperCase();
      if (upper.startsWith("UR:") || upper.startsWith("B$")) {
        const fullHex = this.urService.processFragment(decodedText);
        if (fullHex) {
          this.isProcessingScan = true;
          yield this.safeStopScanner();
          this.rawHex = fullHex;
          this.analyzeRawHex(fullHex);
          this.isProcessingScan = false;
        }
      } else {
        this.isProcessingScan = true;
        yield this.safeStopScanner();
        this.rawHex = decodedText;
        this.analyzeRawHex(decodedText);
        this.isProcessingScan = false;
      }
    });
  }
  safeStopScanner() {
    return __async(this, null, function* () {
      if (this.html5QrCode) {
        try {
          if (this.html5QrCode.getState() === 2) {
            yield this.html5QrCode.stop();
          }
          this.html5QrCode.clear();
        } catch (e) {
          console.error("Camera stop error", e);
        }
      }
      this.isScanning.set(false);
    });
  }
  stopScanner() {
    this.safeStopScanner();
  }
  static \u0275fac = function CreateComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CreateComponent)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _CreateComponent, selectors: [["app-create"]], hostBindings: function CreateComponent_HostBindings(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275listener("message", function CreateComponent_message_HostBindingHandler($event) {
        return ctx.onMessage($event);
      }, i0.\u0275\u0275resolveWindow);
    }
  }, features: [i0.\u0275\u0275ProvidersFeature([EncryptionEngine])], decls: 4, vars: 6, consts: [["id", "container-create-dashboard", 1, "w-full", "flex", "flex-col", "items-center", "p-6", "relative"], ["id", "view-inject-waiting", 1, "flex", "flex-col", "items-center", "justify-center", "h-full", "min-h-[400px]", "text-center", "relative", "z-10", "animate-fade-in"], ["id", "modal-configure-room", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/90", "backdrop-blur-xl", "animate-fade-in"], [1, "flex", "items-center", "gap-3", "mb-10", "opacity-80"], [1, "w-8", "h-8", "object-contain", 3, "src", "alt"], [1, "text-2xl", "font-bold", "text-white", "tracking-tight"], [1, "text-brand-accent"], ["lucideLoader2", "", 1, "w-12", "h-12", "text-brand-accent", "animate-spin", "mb-6"], [1, "text-2xl", "font-bold", "text-white", "mb-2", "tracking-tight"], [1, "text-brand-text-muted", "text-sm", "max-w-sm"], ["id", "view-create-embedded", 1, "w-full", "max-w-xl", "z-10", "animate-fade-in"], [1, "absolute", "top-0", "left-1/2", "-translate-x-1/2", "w-[800px]", "h-[500px]", "bg-brand-accent/10", "rounded-full", "blur-[120px]", "pointer-events-none"], ["id", "view-create-standard", 1, "max-w-3xl", "w-full", "text-center", "mb-12", "relative", "z-10"], [1, "flex", "justify-center", "mb-6"], [1, "w-16", "h-16", "object-contain", "drop-shadow-[0_0_15px_var(--wl-accent)]", 3, "src", "alt"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 409 445", "preserveAspectRatio", "xMidYMid meet", 1, "w-16", "h-16", "text-brand-accent", "fill-current"], [1, "text-4xl", "md:text-5xl", "font-bold", "mb-4", "tracking-tight"], [1, "text-brand-text-muted", "text-lg"], [1, "w-full", "relative", "z-10", "flex", "justify-center", "max-w-xl"], ["id", "card-hero-welcome", 1, "bg-brand-card/50", "backdrop-blur-sm", "border", "border-brand-card-border", "rounded-2xl", "p-8", "flex", "flex-col", "hover:border-brand-accent/30", "transition-all", "group", "w-full", "shadow-2xl"], [1, "flex", "items-center", "gap-5", "mb-8"], [1, "w-14", "h-14", "bg-brand-accent/10", "rounded-2xl", "flex", "items-center", "justify-center", "border", "border-brand-accent/20", "shrink-0", "group-hover:scale-110", "transition-transform", "duration-300"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 409 445", "preserveAspectRatio", "xMidYMid meet", 1, "w-7", "h-7", "text-brand-accent", "fill-current"], [1, "text-brand-accent/70", "text-xs", "font-mono", "uppercase", "tracking-widest"], [1, "space-y-4", "mb-10", "flex-grow"], [1, "flex", "items-center", "gap-3", "text-slate-300"], ["lucideCheck", "", 1, "w-5", "h-5", "text-brand-accent"], ["id", "btn-start-ceremony", 1, "w-full", "py-4", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition", "shadow-lg", "shadow-brand-accent/20", "flex", "items-center", "justify-center", "gap-2", "group/btn", "cursor-pointer", 3, "click"], ["lucideShield", "", 1, "w-4", "h-4", "fill-brand-bg", "group-hover/btn:scale-125", "transition-transform"], ["d", "M185.5 425.7 c-35.4 -17.3 -72 -43.4 -98.2 -69.9 -31.6 -31.9 -50.3 -62.5 -59.1 -96.8 -5.6 -21.7 -5.7 -23.4 -5.7 -101 0 -66.6 0.1 -71.7 1.8 -75.1 2.3 -4.6 6.1 -6.7 22.2 -12.2 7.2 -2.5 31.9 -11.3 55 -19.7 79.4 -28.7 97.6 -35 100.4 -35 2.8 0 27.5 8.3 53.6 18 21.3 7.9 70.6 25.7 92 33.1 11 3.9 21.4 7.5 23 8.1 4.4 1.6 8.4 5.7 9.5 9.7 1.3 4.9 1.3 136.8 0 148.6 -4.9 42.6 -21.2 76.1 -55.1 113.1 -21 23 -49.7 46 -79.4 63.9 -15.9 9.6 -40.1 21.5 -43.6 21.5 -2.1 0 -8.2 -2.3 -16.4 -6.3z m24.6 -28.8 c31.4 -15.7 71.7 -45.6 92 -68 26.9 -29.8 39.3 -52 47.2 -84.4 2.1 -8.8 2.2 -10.3 2.2 -76.9 l0 -67.9 -17 -6.2 c-48.5 -17.7 -84.6 -30.6 -116 -41.6 l-16.9 -6 -20.1 7.1 c-11 4 -26.5 9.6 -34.5 12.5 -8 2.9 -18.3 6.7 -23 8.3 -11.6 4 -36.2 12.9 -43.5 15.7 -3.3 1.3 -10.9 4 -17 6.1 -6 2.1 -11.2 4.1 -11.5 4.5 -1 1.4 -1 113.3 -0.1 124.9 0.5 6.3 1.7 15.1 2.6 19.5 10.6 52.1 52.2 101.4 119 141 11.4 6.8 27 15.3 28.3 15.5 0.1 0 3.9 -1.8 8.3 -4.1z"], ["d", "M191.3 318.3 c-7.6 -7.4 -8.1 -8.1 -8.6 -12.8 -0.2 -2.7 -0.5 -27.9 -0.6 -55.9 0 -28 -0.2 -51 -0.3 -51.1 -0.2 -0.1 -2.5 -1.4 -5.1 -2.9 -7 -4 -11.1 -8 -16.1 -15.4 -5.9 -8.9 -8.6 -17.5 -8.6 -27.1 0 -27 19.5 -48.5 45.9 -50.7 13 -1.1 26.1 3.5 36.6 12.9 19.8 17.6 21.8 50.3 4.4 70.1 -4.1 4.6 -14.8 12.6 -16.8 12.6 -0.7 0 -1.1 6.3 -1.1 19 l0 19 -6.1 6.6 -6 6.7 6 6.1 c8.2 8.3 8.2 10.1 0 18.3 l-6 6 6 5.8 6.1 5.8 0 8.3 0 8.2 -9 9.1 c-5 5 -9.9 9.1 -10.9 9.1 -1 0 -5.4 -3.5 -9.8 -7.7z m17.7 -175 c3.6 -2.4 4.8 -4.3 5.5 -8.3 1 -5.7 -1.4 -11.1 -6 -13.7 -4.9 -2.8 -8.4 -2.9 -13.4 -0.3 -3.8 1.9 -4.5 2.8 -6.2 8.4 -1.2 4.1 0.8 10.2 4.4 13.2 3.6 3 11.8 3.4 15.7 0.7z"], ["d", "M130.1 304.2 l-7.1 -6.7 0 -48.2 0 -48.2 -5.5 -3.5 c-36.6 -23.5 -23.7 -79.4 19.1 -82.4 6.5 -0.4 17.4 1.2 17.4 2.5 0 0.3 -1.5 3.6 -3.2 7.4 -2.4 5 -3.7 6.6 -4.8 6.2 -0.8 -0.4 -3.6 -0.8 -6.3 -1.1 -4.3 -0.4 -5 -0.1 -8.2 3.1 -2.9 2.9 -3.5 4.2 -3.5 7.9 0 2.4 0.7 5.4 1.6 6.6 2 2.9 6.6 5.2 10.4 5.2 2.6 0 3 0.3 3 2.8 0 4.7 4 17.3 7.6 24.2 1.9 3.6 5.4 8.9 7.9 11.7 l4.6 5.2 -3.1 1.6 c-3.3 1.7 -3.4 2.4 -3 24.1 l0.2 9.1 -5.1 5.8 c-2.8 3.2 -5.1 6.1 -5.1 6.4 0 0.4 2.3 3.1 5 6.1 3 3.3 5 6.4 5 7.8 0 1.3 -1.9 4.3 -4.5 7.1 -2.5 2.6 -4.5 5.4 -4.5 6.1 0 0.7 2 3.5 4.5 6.1 4.4 4.7 4.5 4.9 4.5 11.6 l0 6.7 -7.9 7.8 c-4.5 4.4 -8.8 7.8 -9.9 7.8 -1.1 0 -5.2 -3 -9.1 -6.8z"], ["d", "M254.3 303.8 l-7.3 -7.1 0 -47.9 0 -47.9 -3.5 -2 c-1.9 -1.2 -3.5 -2.2 -3.5 -2.3 0 -0.1 2.1 -2.4 4.8 -5.2 8.2 -8.6 14.1 -22.8 14.2 -34.1 l0 -4.3 4.6 0 c3.9 0 5.1 -0.5 8 -3.4 2.8 -2.8 3.4 -4.2 3.4 -7.6 0 -9.6 -8.1 -14.6 -17.1 -10.6 -1.3 0.6 -2.5 -0.7 -5.3 -6 -3.9 -7.4 -3.8 -7.6 2.4 -9.4 7.4 -2.1 20 -0.5 28.8 3.7 10.4 4.9 20.7 19.4 23.2 32.5 1.5 7.5 0.3 17.7 -3 25.3 -2.7 6.4 -10.5 15.1 -17 19.1 l-6 3.7 0 16.1 0 16.2 -5.5 5.4 -5.5 5.4 5.5 5.6 c7 7.1 7.2 9.3 1 15.9 -2.5 2.6 -4.5 5.5 -4.5 6.2 0 0.8 2 3.5 4.5 5.9 4.5 4.4 4.5 4.4 4.5 11.5 l0 7.2 -7.9 7.6 c-4.3 4.2 -8.7 7.7 -9.7 7.7 -1.1 0 -5.2 -3.2 -9.1 -7.2z"], [1, "bg-brand-card", "border", "border-brand-accent/30", "rounded-2xl", "p-6", "shadow-2xl"], [1, "flex", "items-center", "gap-3", "mb-6"], ["lucideShield", "", 1, "w-6", "h-6", "text-brand-accent"], [1, "text-white", "font-bold", "text-xl"], ["id", "card-psbt-summary", 1, "bg-brand-bg", "border", "border-brand-card-border", "rounded-xl", "p-5", "mb-6"], [1, "text-xs", "text-brand-text-muted", "uppercase", "font-bold", "tracking-widest", "mb-1"], [1, "text-3xl", "font-bold", "text-white", "mb-4"], [1, "grid", "grid-cols-2", "gap-4"], [1, "text-sm"], [1, "text-brand-text-muted", "block"], [1, "text-white", "font-bold"], [1, "text-brand-accent", "font-bold", "capitalize"], ["id", "btn-launch-room", 1, "w-full", "py-4", "bg-brand-accent", "text-brand-bg", "font-bold", "rounded-xl", "flex", "items-center", "justify-center", "gap-2", "hover:bg-brand-accent-hover", "transition", "cursor-pointer", 3, "click", "disabled"], ["id", "btn-clear-psbt", 1, "w-full", "mt-3", "text-xs", "text-brand-text-muted", "hover:text-white", "transition", "cursor-pointer", 3, "click"], ["lucideLoader2", "", 1, "w-4", "h-4", "animate-spin"], ["id", "card-embedded-join", 1, "bg-brand-card/50", "backdrop-blur-sm", "border", "border-brand-card-border", "rounded-2xl", "p-8", "flex", "flex-col", "hover:border-brand-accent/30", "transition-all", "group", "w-full", "shadow-2xl"], [1, "space-y-4"], [1, "flex", "justify-between", "items-end", "mb-2"], [1, "block", "text-xs", "font-bold", "text-brand-text-muted", "uppercase", "tracking-wider"], [1, "text-[10px]", "font-mono"], [1, "relative"], ["id", "input-join-room-id", "maxlength", "36", "placeholder", "Paste Room ID...", "autocomplete", "off", "data-1p-ignore", "true", "data-lpignore", "true", "data-bwignore", "true", 1, "w-full", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "p-3", "pr-10", "text-white", "font-mono", "text-sm", "outline-none", "focus:border-brand-accent", "transition", 3, "ngModelChange", "type", "ngModel"], ["id", "btn-toggle-room-id-visibility", 1, "absolute", "right-3", "top-1/2", "-translate-y-1/2", "text-brand-text-muted", "hover:text-white", "transition", "cursor-pointer", 3, "click"], ["lucideEyeOff", "", 1, "w-4", "h-4"], ["lucideEye", "", 1, "w-4", "h-4"], ["id", "input-join-key", "maxlength", "44", "placeholder", "Paste Key...", "autocomplete", "off", "data-1p-ignore", "true", "data-lpignore", "true", "data-bwignore", "true", 1, "w-full", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "p-3", "pr-10", "text-white", "font-mono", "text-sm", "outline-none", "focus:border-brand-accent", "transition", 3, "ngModelChange", "type", "ngModel"], ["id", "btn-toggle-key-visibility", 1, "absolute", "right-3", "top-1/2", "-translate-y-1/2", "text-brand-text-muted", "hover:text-white", "transition", "cursor-pointer", 3, "click"], ["id", "btn-join-existing-room", 1, "w-full", "py-4", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition", "shadow-lg", "shadow-brand-accent/20", "flex", "items-center", "justify-center", "gap-2", "group/btn", "disabled:opacity-50", "disabled:cursor-not-allowed", "cursor-pointer", 3, "click", "disabled"], ["lucideShield", "", 1, "w-4", "h-4", "fill-brand-bg", "transition-transform"], [1, "bg-brand-card", "border", "border-brand-card-border", "p-8", "rounded-2xl", "shadow-2xl", "max-w-lg", "w-full", "relative"], ["id", "btn-modal-close", 1, "absolute", "top-4", "right-4", "text-brand-text-muted", "hover:text-white", "cursor-pointer"], [1, "text-2xl", "font-bold", "text-white", "mb-6"], [1, "mb-6"], [1, "block", "text-xs", "font-bold", "text-brand-text-muted", "uppercase", "tracking-wider", "mb-2"], [1, "grid", "grid-cols-3", "gap-2"], [1, "py-2", "px-3", "rounded-lg", "text-sm", "font-bold", "border", "transition-all", "capitalize", "cursor-pointer", 3, "id", "bg-brand-accent_20", "border-brand-accent", "text-brand-accent", "bg-brand-bg", "border-brand-card-border", "text-brand-text-muted"], [1, "bg-brand-card", "border", "border-brand-card-border", "rounded-xl", "p-6", "mb-6"], [1, "block", "text-xs", "font-bold", "uppercase", "tracking-wider", "mb-2", "text-brand-text-muted"], ["id", "card-psbt-summary", 1, "bg-brand-bg", "border", "border-brand-card-border", "rounded-xl", "p-4", "animate-in", "zoom-in-95", "duration-300"], [1, "mb-4", "p-3", "bg-rose-950/30", "border", "border-rose-900/50", "rounded-xl", "flex", "items-start", "gap-3"], [1, "mb-4", "p-3", "bg-amber-950/30", "border", "border-amber-900/50", "rounded-xl", "flex", "items-start", "gap-3"], ["id", "btn-launch-room", 1, "w-full", "py-4", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition", "shadow-lg", "shadow-brand-accent/20", "flex", "items-center", "justify-center", "gap-2", "group/btn", "disabled:opacity-50", "cursor-pointer", 3, "click", "disabled"], ["id", "btn-modal-close", 1, "absolute", "top-4", "right-4", "text-brand-text-muted", "hover:text-white", "cursor-pointer", 3, "click"], ["lucideX", "", 1, "w-5", "h-5"], [1, "py-2", "px-3", "rounded-lg", "text-sm", "font-bold", "border", "transition-all", "capitalize", "cursor-pointer", 3, "click", "id"], [1, "mb-6", "p-4", "bg-rose-500/10", "border", "border-rose-500/30", "rounded-xl", "flex", "items-start", "gap-3", "animate-in", "fade-in", "slide-in-from-top-2"], [1, "grid", "grid-cols-1", "md:grid-cols-2", "gap-4", "mb-2", "animate-in", "fade-in", "duration-300"], ["id", "btn-upload-psbt-file", 1, "relative", "group", "flex", "flex-col", "items-center", "justify-center", "p-8", "bg-brand-bg", "border-2", "border-dashed", "border-brand-card-border", "rounded-xl", "hover:border-brand-accent/50", "hover:bg-brand-accent/5", "transition-all", "cursor-pointer"], ["id", "input-psbt-file", "type", "file", "accept", ".psbt,.txt,.hex", 1, "absolute", "inset-0", "opacity-0", "cursor-pointer", "z-10", 3, "change", "disabled"], [1, "bg-brand-card", "p-3", "rounded-full", "mb-3", "group-hover:bg-brand-accent/20", "transition-colors"], ["lucideUploadCloud", "", 1, "text-brand-text-muted", "group-hover:text-brand-accent", "transition-colors"], [1, "text-sm", "font-medium", "text-slate-200"], [1, "text-xs", "text-brand-text-muted", "mt-1"], ["id", "btn-scan-psbt-qr", 1, "flex", "flex-col", "items-center", "justify-center", "p-8", "bg-brand-bg", "border-2", "border-dashed", "border-brand-card-border", "rounded-xl", "hover:border-brand-accent/50", "hover:bg-brand-accent/5", "transition-all", "group", "disabled:opacity-50", "cursor-pointer", 3, "click", "disabled"], ["lucideQrCode", "", 1, "text-brand-text-muted", "group-hover:text-brand-accent", "transition-colors"], [1, "animate-in", "fade-in", "slide-in-from-top-4", "duration-300", "mt-6", "mb-4"], [1, "relative", "flex", "items-center", "py-6"], [1, "flex-grow", "border-t", "border-brand-card-border"], [1, "flex-shrink-0", "mx-4", "text-brand-text-muted", "text-xs", "font-medium", "uppercase", "tracking-wider"], ["id", "input-psbt-text", "rows", "4", "placeholder", "Paste raw PSBT Base64 or Hex string here...", 1, "w-full", "bg-brand-bg/50", "border", "border-brand-card-border", "text-brand-text", "rounded-lg", "p-4", "font-mono", "text-xs", "focus:ring-1", "focus:ring-brand-accent/50", "focus:border-brand-accent/50", "transition-colors", "resize-none", "placeholder-brand-text-muted", 3, "ngModelChange", "ngModel", "disabled"], ["lucideEdit2", "", 1, "absolute", "top-4", "right-4", "text-brand-text-muted", "pointer-events-none", "w-4", "h-4"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-rose-400", "shrink-0"], [1, "text-sm", "font-bold", "text-rose-300", "mb-1"], [1, "text-xs", "text-rose-200/80", "leading-relaxed"], [1, "w-full", "bg-brand-accent/10", "border", "border-brand-accent/20", "rounded-lg", "p-3", "mb-6", "flex", "items-start", "gap-3"], ["lucideShield", "", 1, "w-5", "h-5", "text-brand-accent", "shrink-0", "mt-0.5"], [1, "text-xs", "text-brand-text", "leading-relaxed", "space-y-2"], [1, "text-[11px]", "text-brand-accent", "font-medium", "bg-brand-accent/10", "p-2", "rounded", "border", "border-brand-accent/20"], [1, "w-full", "mb-4", "space-y-2"], [1, "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "p-2.5", "flex", "items-center", "justify-between"], [1, "text-[10px]", "text-brand-text-muted", "font-bold", "uppercase", "tracking-wider"], [1, "text-[10px]", "text-brand-accent", "font-mono", "truncate", "max-w-[200px]", 3, "title"], [1, "bg-rose-500/10", "border", "border-rose-500/30", "rounded-lg", "p-2.5", "flex", "items-start", "gap-2", "animate-in", "fade-in", "zoom-in-95", "duration-200"], ["id", "card-psbt-scanner", 1, "relative", "bg-black", "rounded-xl", "overflow-hidden", "border", "border-brand-accent/30", "shadow-[0_0_15px_var(--wl-accent)]", "mt-6", "animate-in", "fade-in", "slide-in-from-top-4", "duration-300"], ["id", "reader", 1, "w-full", "h-72", "object-cover"], [1, "absolute", "inset-0", "pointer-events-none", "z-10", "flex", "flex-col", "items-center", "justify-center", "overflow-hidden"], [1, "relative", "w-56", "h-56", "rounded-xl", "shadow-[0_0_0_9999px_rgba(0,0,0,0.8)]", "border", "border-brand-accent/30"], [1, "absolute", "top-0", "left-0", "w-6", "h-6", "border-t-2", "border-l-2", "border-brand-accent", "rounded-tl-xl"], [1, "absolute", "top-0", "right-0", "w-6", "h-6", "border-t-2", "border-r-2", "border-brand-accent", "rounded-tr-xl"], [1, "absolute", "bottom-0", "left-0", "w-6", "h-6", "border-b-2", "border-l-2", "border-brand-accent", "rounded-bl-xl"], [1, "absolute", "bottom-0", "right-0", "w-6", "h-6", "border-b-2", "border-r-2", "border-brand-accent", "rounded-br-xl"], [1, "absolute", "left-0", "right-0", "h-[2px]", "bg-brand-accent", "shadow-[0_0_8px_2px_var(--wl-accent)]", "scanner-laser"], [1, "absolute", "bottom-0", "left-0", "right-0", "bg-brand-card/95", "backdrop-blur-sm", "p-3", "border-t", "border-brand-accent/30", "z-20"], ["id", "btn-stop-scanner", 1, "absolute", "top-4", "right-4", "z-20", "text-brand-text-muted", "bg-brand-card/80", "hover:text-white", "hover:bg-red-500/90", "p-2.5", "rounded-full", "transition-all", "backdrop-blur-sm", "border", "border-brand-card-border", "hover:border-red-500", "cursor-pointer", 3, "click"], ["lucideAlertTriangle", "", 1, "w-4", "h-4", "text-rose-400", "shrink-0"], [1, "text-xs", "text-rose-300"], [1, "flex", "justify-between", "text-xs", "text-brand-accent", "font-bold", "mb-2", "tracking-wider"], [1, "w-full", "bg-brand-bg", "rounded-full", "h-1.5", "overflow-hidden"], [1, "bg-brand-accent", "h-1.5", "rounded-full", "transition-all", "duration-200", "ease-out"], [1, "flex", "items-start", "justify-between", "mb-4"], [1, "flex", "items-center", "gap-3"], [1, "w-10", "h-10", "bg-brand-accent/10", "rounded-lg", "flex", "items-center", "justify-center", "text-brand-accent"], ["lucideFileJson", "", 1, "w-5", "h-5"], [1, "text-white", "text-sm", "font-bold", "truncate", "max-w-[150px]"], [1, "text-brand-accent", "text-xs", "font-mono"], ["id", "btn-clear-psbt", 1, "text-brand-text-muted", "hover:text-rose-400", "p-1", "rounded-md", "hover:bg-rose-400/10", "transition-colors", "cursor-pointer"], [1, "grid", "grid-cols-3", "gap-2", "text-center"], [1, "bg-brand-card", "rounded", "p-2", "border", "border-brand-card-border"], [1, "text-[10px]", "text-brand-text-muted", "uppercase", "tracking-tight"], [1, "text-white", "text-xs", "font-bold"], [1, "text-brand-text-muted"], ["id", "btn-clear-psbt", 1, "text-brand-text-muted", "hover:text-rose-400", "p-1", "rounded-md", "hover:bg-rose-400/10", "transition-colors", "cursor-pointer", 3, "click"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-rose-500", "shrink-0", "mt-0.5"], [1, "text-rose-200", "text-xs", "font-bold", "mb-1"], [1, "text-rose-400", "text-[10px]"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-amber-500", "shrink-0", "mt-0.5"], [1, "text-amber-200", "text-xs", "font-bold", "mb-1"], [1, "text-amber-400", "text-[10px]"], ["lucideLoader2", "", 1, "w-4", "h-4", "fill-brand-bg", "group-hover/btn:scale-125", "transition-transform", "animate-spin"]], template: function CreateComponent_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "div", 0);
      i0.\u0275\u0275conditionalCreate(1, CreateComponent_Conditional_1_Template, 12, 4, "div", 1)(2, CreateComponent_Conditional_2_Template, 2, 2);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(3, CreateComponent_Conditional_3_Template, 22, 7, "div", 2);
    }
    if (rf & 2) {
      i0.\u0275\u0275classProp("pt-12", !ctx.isEmbedded)("pt-6", ctx.isEmbedded);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.viewMode === "inject" ? 1 : 2);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.showCreateModal() ? 3 : -1);
    }
  }, dependencies: [
    CommonModule,
    i1.NgClass,
    i1.NgComponentOutlet,
    i1.NgForOf,
    i1.NgIf,
    i1.NgTemplateOutlet,
    i1.NgStyle,
    i1.NgSwitch,
    i1.NgSwitchCase,
    i1.NgSwitchDefault,
    i1.NgPlural,
    i1.NgPluralCase,
    RouterModule,
    i2.RouterOutlet,
    i2.RouterLink,
    i2.RouterLinkActive,
    i2.\u0275EmptyOutletComponent,
    FormsModule,
    i3.\u0275NgNoValidate,
    i3.NgSelectOption,
    i3.\u0275NgSelectMultipleOption,
    i3.DefaultValueAccessor,
    i3.NumberValueAccessor,
    i3.RangeValueAccessor,
    i3.CheckboxControlValueAccessor,
    i3.SelectControlValueAccessor,
    i3.SelectMultipleControlValueAccessor,
    i3.RadioControlValueAccessor,
    i3.NgControlStatus,
    i3.NgControlStatusGroup,
    i3.RequiredValidator,
    i3.MinLengthValidator,
    i3.MaxLengthValidator,
    i3.PatternValidator,
    i3.CheckboxRequiredValidator,
    i3.EmailValidator,
    i3.MinValidator,
    i3.MaxValidator,
    i3.NgModel,
    i3.NgModelGroup,
    i3.NgForm,
    LucideCheck,
    LucideLoader2,
    LucideX,
    LucideUploadCloud,
    LucideFileJson,
    LucideAlertTriangle,
    LucideShield,
    LucideEye,
    LucideEyeOff,
    LucideQrCode,
    LucideEdit2,
    i1.AsyncPipe,
    i1.UpperCasePipe,
    i1.LowerCasePipe,
    i1.JsonPipe,
    i1.SlicePipe,
    i1.DecimalPipe,
    i1.PercentPipe,
    i1.TitleCasePipe,
    i1.CurrencyPipe,
    i1.DatePipe,
    i1.I18nPluralPipe,
    i1.I18nSelectPipe,
    i1.KeyValuePipe
  ], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(CreateComponent, [{
    type: Component,
    args: [{ selector: "app-create", standalone: true, imports: [
      CommonModule,
      RouterModule,
      FormsModule,
      LucideCheck,
      LucideLoader2,
      LucideX,
      LucideUploadCloud,
      LucideFileJson,
      LucideAlertTriangle,
      LucideShield,
      LucideEye,
      LucideEyeOff,
      LucideQrCode,
      LucideEdit2
    ], providers: [EncryptionEngine], template: `<div id="container-create-dashboard" class="w-full flex flex-col items-center p-6 relative"\r
     [class.pt-12]="!isEmbedded" [class.pt-6]="isEmbedded">\r
\r
  @if (viewMode === 'inject') {\r
    <div id="view-inject-waiting" class="flex flex-col items-center justify-center h-full min-h-[400px] text-center relative z-10 animate-fade-in">\r
      \r
      <!-- Brand Header (Inject View) -->\r
      <div class="flex items-center gap-3 mb-10 opacity-80">\r
        <img [src]="configService.config().logoUrl" [alt]="configService.config().brandName" class="w-8 h-8 object-contain" />\r
        <h3 class="text-2xl font-bold text-white tracking-tight">\r
          {{ configService.config().brandName }}<span class="text-brand-accent">{{ configService.config().brandSuffix || '' }}</span>\r
        </h3>\r
      </div>\r
\r
      <svg lucideLoader2 class="w-12 h-12 text-brand-accent animate-spin mb-6"></svg>\r
      <h2 class="text-2xl font-bold text-white mb-2 tracking-tight">Waiting for Data...</h2>\r
      <p class="text-brand-text-muted text-sm max-w-sm">Please initialize the signing ceremony or pass the transaction payload from your host application.</p>\r
    </div>\r
  } \r
  @else {\r
    @if (!isEmbedded) {\r
      <!-- Glow background -->\r
      <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-brand-accent/10 rounded-full blur-[120px] pointer-events-none"></div>\r
\r
      <!-- Main Hero Header -->\r
      <div id="view-create-standard" class="max-w-3xl w-full text-center mb-12 relative z-10">\r
        <div class="flex justify-center mb-6">\r
            @if (configService.config().whitelabel) {\r
            <img [src]="configService.config().logoUrl" [alt]="configService.config().brandName" class="w-16 h-16 object-contain drop-shadow-[0_0_15px_var(--wl-accent)]" />\r
            } @else {\r
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 409 445" class="w-16 h-16 text-brand-accent fill-current" preserveAspectRatio="xMidYMid meet">\r
                <g>\r
                <path d="M185.5 425.7 c-35.4 -17.3 -72 -43.4 -98.2 -69.9 -31.6 -31.9 -50.3 -62.5 -59.1 -96.8 -5.6 -21.7 -5.7 -23.4 -5.7 -101 0 -66.6 0.1 -71.7 1.8 -75.1 2.3 -4.6 6.1 -6.7 22.2 -12.2 7.2 -2.5 31.9 -11.3 55 -19.7 79.4 -28.7 97.6 -35 100.4 -35 2.8 0 27.5 8.3 53.6 18 21.3 7.9 70.6 25.7 92 33.1 11 3.9 21.4 7.5 23 8.1 4.4 1.6 8.4 5.7 9.5 9.7 1.3 4.9 1.3 136.8 0 148.6 -4.9 42.6 -21.2 76.1 -55.1 113.1 -21 23 -49.7 46 -79.4 63.9 -15.9 9.6 -40.1 21.5 -43.6 21.5 -2.1 0 -8.2 -2.3 -16.4 -6.3z m24.6 -28.8 c31.4 -15.7 71.7 -45.6 92 -68 26.9 -29.8 39.3 -52 47.2 -84.4 2.1 -8.8 2.2 -10.3 2.2 -76.9 l0 -67.9 -17 -6.2 c-48.5 -17.7 -84.6 -30.6 -116 -41.6 l-16.9 -6 -20.1 7.1 c-11 4 -26.5 9.6 -34.5 12.5 -8 2.9 -18.3 6.7 -23 8.3 -11.6 4 -36.2 12.9 -43.5 15.7 -3.3 1.3 -10.9 4 -17 6.1 -6 2.1 -11.2 4.1 -11.5 4.5 -1 1.4 -1 113.3 -0.1 124.9 0.5 6.3 1.7 15.1 2.6 19.5 10.6 52.1 52.2 101.4 119 141 11.4 6.8 27 15.3 28.3 15.5 0.1 0 3.9 -1.8 8.3 -4.1z"/>\r
                <path d="M191.3 318.3 c-7.6 -7.4 -8.1 -8.1 -8.6 -12.8 -0.2 -2.7 -0.5 -27.9 -0.6 -55.9 0 -28 -0.2 -51 -0.3 -51.1 -0.2 -0.1 -2.5 -1.4 -5.1 -2.9 -7 -4 -11.1 -8 -16.1 -15.4 -5.9 -8.9 -8.6 -17.5 -8.6 -27.1 0 -27 19.5 -48.5 45.9 -50.7 13 -1.1 26.1 3.5 36.6 12.9 19.8 17.6 21.8 50.3 4.4 70.1 -4.1 4.6 -14.8 12.6 -16.8 12.6 -0.7 0 -1.1 6.3 -1.1 19 l0 19 -6.1 6.6 -6 6.7 6 6.1 c8.2 8.3 8.2 10.1 0 18.3 l-6 6 6 5.8 6.1 5.8 0 8.3 0 8.2 -9 9.1 c-5 5 -9.9 9.1 -10.9 9.1 -1 0 -5.4 -3.5 -9.8 -7.7z m17.7 -175 c3.6 -2.4 4.8 -4.3 5.5 -8.3 1 -5.7 -1.4 -11.1 -6 -13.7 -4.9 -2.8 -8.4 -2.9 -13.4 -0.3 -3.8 1.9 -4.5 2.8 -6.2 8.4 -1.2 4.1 0.8 10.2 4.4 13.2 3.6 3 11.8 3.4 15.7 0.7z"/>\r
                <path d="M130.1 304.2 l-7.1 -6.7 0 -48.2 0 -48.2 -5.5 -3.5 c-36.6 -23.5 -23.7 -79.4 19.1 -82.4 6.5 -0.4 17.4 1.2 17.4 2.5 0 0.3 -1.5 3.6 -3.2 7.4 -2.4 5 -3.7 6.6 -4.8 6.2 -0.8 -0.4 -3.6 -0.8 -6.3 -1.1 -4.3 -0.4 -5 -0.1 -8.2 3.1 -2.9 2.9 -3.5 4.2 -3.5 7.9 0 2.4 0.7 5.4 1.6 6.6 2 2.9 6.6 5.2 10.4 5.2 2.6 0 3 0.3 3 2.8 0 4.7 4 17.3 7.6 24.2 1.9 3.6 5.4 8.9 7.9 11.7 l4.6 5.2 -3.1 1.6 c-3.3 1.7 -3.4 2.4 -3 24.1 l0.2 9.1 -5.1 5.8 c-2.8 3.2 -5.1 6.1 -5.1 6.4 0 0.4 2.3 3.1 5 6.1 3 3.3 5 6.4 5 7.8 0 1.3 -1.9 4.3 -4.5 7.1 -2.5 2.6 -4.5 5.4 -4.5 6.1 0 0.7 2 3.5 4.5 6.1 4.4 4.7 4.5 4.9 4.5 11.6 l0 6.7 -7.9 7.8 c-4.5 4.4 -8.8 7.8 -9.9 7.8 -1.1 0 -5.2 -3 -9.1 -6.8z"/>\r
                <path d="M254.3 303.8 l-7.3 -7.1 0 -47.9 0 -47.9 -3.5 -2 c-1.9 -1.2 -3.5 -2.2 -3.5 -2.3 0 -0.1 2.1 -2.4 4.8 -5.2 8.2 -8.6 14.1 -22.8 14.2 -34.1 l0 -4.3 4.6 0 c3.9 0 5.1 -0.5 8 -3.4 2.8 -2.8 3.4 -4.2 3.4 -7.6 0 -9.6 -8.1 -14.6 -17.1 -10.6 -1.3 0.6 -2.5 -0.7 -5.3 -6 -3.9 -7.4 -3.8 -7.6 2.4 -9.4 7.4 -2.1 20 -0.5 28.8 3.7 10.4 4.9 20.7 19.4 23.2 32.5 1.5 7.5 0.3 17.7 -3 25.3 -2.7 6.4 -10.5 15.1 -17 19.1 l-6 3.7 0 16.1 0 16.2 -5.5 5.4 -5.5 5.4 5.5 5.6 c7 7.1 7.2 9.3 1 15.9 -2.5 2.6 -4.5 5.5 -4.5 6.2 0 0.8 2 3.5 4.5 5.9 4.5 4.4 4.5 4.4 4.5 11.5 l0 7.2 -7.9 7.6 c-4.3 4.2 -8.7 7.7 -9.7 7.7 -1.1 0 -5.2 -3.2 -9.1 -7.2z"/>\r
                </g>\r
            </svg>\r
            }\r
        </div>\r
        \r
        <h1 class="text-4xl md:text-5xl font-bold mb-4 tracking-tight">\r
            <span>\r
                @if (configService.config().whitelabel) {\r
                    @if (configService.config().useTradeMark) {\r
                    Start a Signing Room\xAE\r
                    } @else {\r
                    Start\r
                    }\r
                } @else {\r
                    Launch Signing Room\xAE\r
                }\r
            </span>\r
        </h1>\r
        \r
        <p class="text-brand-text-muted text-lg">{{ configService.config().tagline }}</p>\r
      </div>\r
\r
      <!-- Action Card -->\r
      <div class="w-full relative z-10 flex justify-center max-w-xl"> \r
        <div id="card-hero-welcome" class="bg-brand-card/50 backdrop-blur-sm border border-brand-card-border rounded-2xl p-8 flex flex-col hover:border-brand-accent/30 transition-all group w-full shadow-2xl">\r
          \r
          <div class="flex items-center gap-5 mb-8">\r
            <div class="w-14 h-14 bg-brand-accent/10 rounded-2xl flex items-center justify-center border border-brand-accent/20 shrink-0 group-hover:scale-110 transition-transform duration-300">\r
              @if (configService.config().whitelabel) {\r
                <img [src]="configService.config().logoUrl" [alt]="configService.config().brandName" class="w-8 h-8 object-contain" />\r
                } @else {\r
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 409 445" class="w-7 h-7 text-brand-accent fill-current" preserveAspectRatio="xMidYMid meet">\r
                    <g>\r
                    <path d="M185.5 425.7 c-35.4 -17.3 -72 -43.4 -98.2 -69.9 -31.6 -31.9 -50.3 -62.5 -59.1 -96.8 -5.6 -21.7 -5.7 -23.4 -5.7 -101 0 -66.6 0.1 -71.7 1.8 -75.1 2.3 -4.6 6.1 -6.7 22.2 -12.2 7.2 -2.5 31.9 -11.3 55 -19.7 79.4 -28.7 97.6 -35 100.4 -35 2.8 0 27.5 8.3 53.6 18 21.3 7.9 70.6 25.7 92 33.1 11 3.9 21.4 7.5 23 8.1 4.4 1.6 8.4 5.7 9.5 9.7 1.3 4.9 1.3 136.8 0 148.6 -4.9 42.6 -21.2 76.1 -55.1 113.1 -21 23 -49.7 46 -79.4 63.9 -15.9 9.6 -40.1 21.5 -43.6 21.5 -2.1 0 -8.2 -2.3 -16.4 -6.3z m24.6 -28.8 c31.4 -15.7 71.7 -45.6 92 -68 26.9 -29.8 39.3 -52 47.2 -84.4 2.1 -8.8 2.2 -10.3 2.2 -76.9 l0 -67.9 -17 -6.2 c-48.5 -17.7 -84.6 -30.6 -116 -41.6 l-16.9 -6 -20.1 7.1 c-11 4 -26.5 9.6 -34.5 12.5 -8 2.9 -18.3 6.7 -23 8.3 -11.6 4 -36.2 12.9 -43.5 15.7 -3.3 1.3 -10.9 4 -17 6.1 -6 2.1 -11.2 4.1 -11.5 4.5 -1 1.4 -1 113.3 -0.1 124.9 0.5 6.3 1.7 15.1 2.6 19.5 10.6 52.1 52.2 101.4 119 141 11.4 6.8 27 15.3 28.3 15.5 0.1 0 3.9 -1.8 8.3 -4.1z"/>\r
                    <path d="M191.3 318.3 c-7.6 -7.4 -8.1 -8.1 -8.6 -12.8 -0.2 -2.7 -0.5 -27.9 -0.6 -55.9 0 -28 -0.2 -51 -0.3 -51.1 -0.2 -0.1 -2.5 -1.4 -5.1 -2.9 -7 -4 -11.1 -8 -16.1 -15.4 -5.9 -8.9 -8.6 -17.5 -8.6 -27.1 0 -27 19.5 -48.5 45.9 -50.7 13 -1.1 26.1 3.5 36.6 12.9 19.8 17.6 21.8 50.3 4.4 70.1 -4.1 4.6 -14.8 12.6 -16.8 12.6 -0.7 0 -1.1 6.3 -1.1 19 l0 19 -6.1 6.6 -6 6.7 6 6.1 c8.2 8.3 8.2 10.1 0 18.3 l-6 6 6 5.8 6.1 5.8 0 8.3 0 8.2 -9 9.1 c-5 5 -9.9 9.1 -10.9 9.1 -1 0 -5.4 -3.5 -9.8 -7.7z m17.7 -175 c3.6 -2.4 4.8 -4.3 5.5 -8.3 1 -5.7 -1.4 -11.1 -6 -13.7 -4.9 -2.8 -8.4 -2.9 -13.4 -0.3 -3.8 1.9 -4.5 2.8 -6.2 8.4 -1.2 4.1 0.8 10.2 4.4 13.2 3.6 3 11.8 3.4 15.7 0.7z"/>\r
                    <path d="M130.1 304.2 l-7.1 -6.7 0 -48.2 0 -48.2 -5.5 -3.5 c-36.6 -23.5 -23.7 -79.4 19.1 -82.4 6.5 -0.4 17.4 1.2 17.4 2.5 0 0.3 -1.5 3.6 -3.2 7.4 -2.4 5 -3.7 6.6 -4.8 6.2 -0.8 -0.4 -3.6 -0.8 -6.3 -1.1 -4.3 -0.4 -5 -0.1 -8.2 3.1 -2.9 2.9 -3.5 4.2 -3.5 7.9 0 2.4 0.7 5.4 1.6 6.6 2 2.9 6.6 5.2 10.4 5.2 2.6 0 3 0.3 3 2.8 0 4.7 4 17.3 7.6 24.2 1.9 3.6 5.4 8.9 7.9 11.7 l4.6 5.2 -3.1 1.6 c-3.3 1.7 -3.4 2.4 -3 24.1 l0.2 9.1 -5.1 5.8 c-2.8 3.2 -5.1 6.1 -5.1 6.4 0 0.4 2.3 3.1 5 6.1 3 3.3 5 6.4 5 7.8 0 1.3 -1.9 4.3 -4.5 7.1 -2.5 2.6 -4.5 5.4 -4.5 6.1 0 0.7 2 3.5 4.5 6.1 4.4 4.7 4.5 4.9 4.5 11.6 l0 6.7 -7.9 7.8 c-4.5 4.4 -8.8 7.8 -9.9 7.8 -1.1 0 -5.2 -3 -9.1 -6.8z"/>\r
                    <path d="M254.3 303.8 l-7.3 -7.1 0 -47.9 0 -47.9 -3.5 -2 c-1.9 -1.2 -3.5 -2.2 -3.5 -2.3 0 -0.1 2.1 -2.4 4.8 -5.2 8.2 -8.6 14.1 -22.8 14.2 -34.1 l0 -4.3 4.6 0 c3.9 0 5.1 -0.5 8 -3.4 2.8 -2.8 3.4 -4.2 3.4 -7.6 0 -9.6 -8.1 -14.6 -17.1 -10.6 -1.3 0.6 -2.5 -0.7 -5.3 -6 -3.9 -7.4 -3.8 -7.6 2.4 -9.4 7.4 -2.1 20 -0.5 28.8 3.7 10.4 4.9 20.7 19.4 23.2 32.5 1.5 7.5 0.3 17.7 -3 25.3 -2.7 6.4 -10.5 15.1 -17 19.1 l-6 3.7 0 16.1 0 16.2 -5.5 5.4 -5.5 5.4 5.5 5.6 c7 7.1 7.2 9.3 1 15.9 -2.5 2.6 -4.5 5.5 -4.5 6.2 0 0.8 2 3.5 4.5 5.9 4.5 4.4 4.5 4.4 4.5 11.5 l0 7.2 -7.9 7.6 c-4.3 4.2 -8.7 7.7 -9.7 7.7 -1.1 0 -5.2 -3.2 -9.1 -7.2z"/>\r
                    </g>\r
                </svg>\r
                }\r
            </div>\r
            <div>\r
              <h3 class="text-2xl font-bold text-white tracking-tight">\r
                {{ configService.config().brandName }}<span class="text-brand-accent">{{ configService.config().brandSuffix || '' }}</span>\r
              </h3>\r
              <div class="text-brand-accent/70 text-xs font-mono uppercase tracking-widest">{{ configService.config().subTagline }}</div>\r
            </div>\r
          </div>\r
\r
          <ul class="space-y-4 mb-10 flex-grow">\r
            <li class="flex items-center gap-3 text-slate-300">\r
              <svg lucideCheck class="w-5 h-5 text-brand-accent"></svg> \r
              <span>Stateless Blind Relay (RAM-Only)</span>\r
            </li>\r
            <li class="flex items-center gap-3 text-slate-300">\r
              <svg lucideCheck class="w-5 h-5 text-brand-accent"></svg> \r
              <span>End-to-End AES-GCM Encryption</span>\r
            </li>\r
            <li class="flex items-center gap-3 text-slate-300">\r
              <svg lucideCheck class="w-5 h-5 text-brand-accent"></svg> \r
              <span>Ceremony Audit Logs</span>\r
            </li>\r
          </ul>\r
          \r
          <button id="btn-start-ceremony" (click)="showCreateModal.set(true)" class="w-full py-4 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition shadow-lg shadow-brand-accent/20 flex items-center justify-center gap-2 group/btn cursor-pointer">\r
            <svg lucideShield class="w-4 h-4 fill-brand-bg group-hover/btn:scale-125 transition-transform"></svg>\r
            <span>\r
                @if (configService.config().useTradeMark) {\r
                Start a Signing Room\xAE\r
                } @else {\r
                Start\r
                }\r
            </span>\r
            </button>\r
        </div>\r
      </div>\r
    }\r
\r
    @if (isEmbedded) {\r
      <div id="view-create-embedded" class="w-full max-w-xl z-10 animate-fade-in">\r
        \r
        @if (psbtAnalysis()) {\r
          <div class="bg-brand-card border border-brand-accent/30 rounded-2xl p-6 shadow-2xl">\r
            <div class="flex items-center gap-3 mb-6">\r
              <svg lucideShield class="w-6 h-6 text-brand-accent"></svg>\r
              <h3 class="text-white font-bold text-xl">Confirm Ceremony</h3>\r
            </div>\r
\r
            <div id="card-psbt-summary" class="bg-brand-bg border border-brand-card-border rounded-xl p-5 mb-6">\r
              <div class="text-xs text-brand-text-muted uppercase font-bold tracking-widest mb-1">Total Amount</div>\r
              <div class="text-3xl font-bold text-white mb-4">{{ psbtAnalysis()?.amountBtc }} <span class="text-brand-text-muted text-lg">BTC</span></div>\r
              \r
              <div class="grid grid-cols-2 gap-4">\r
                <div class="text-sm">\r
                  <span class="text-brand-text-muted block">Signers</span>\r
                  <span class="text-white font-bold">{{ psbtAnalysis()?.signerCount }}</span>\r
                </div>\r
                <div class="text-sm">\r
                  <span class="text-brand-text-muted block">Network</span>\r
                  <span class="text-brand-accent font-bold capitalize">{{ selectedNetwork() }}</span>\r
                </div>\r
              </div>\r
            </div>\r
\r
            <button id="btn-launch-room" (click)="launchRoom()" [disabled]="isLoading()" class="w-full py-4 bg-brand-accent text-brand-bg font-bold rounded-xl flex items-center justify-center gap-2 hover:bg-brand-accent-hover transition cursor-pointer">\r
                @if (isLoading()) { \r
                    <svg lucideLoader2 class="w-4 h-4 animate-spin"></svg> \r
                    Securing Room...\r
                } @else {\r
                    @if (configService.config().useTradeMark) {\r
                    Start a Signing Room\xAE\r
                    } @else {\r
                    Start\r
                    }\r
                }\r
            </button>\r
            <button id="btn-clear-psbt" (click)="clearPsbt()" class="w-full mt-3 text-xs text-brand-text-muted hover:text-white transition cursor-pointer">Cancel and go back</button>\r
          </div>\r
        } \r
        @else {\r
          <!-- Embedded Join Card -->\r
          <div class="w-full relative z-10 flex justify-center max-w-xl"> \r
            <div id="card-embedded-join" class="bg-brand-card/50 backdrop-blur-sm border border-brand-card-border rounded-2xl p-8 flex flex-col hover:border-brand-accent/30 transition-all group w-full shadow-2xl">\r
              \r
              <div class="flex items-center gap-5 mb-8">\r
                <div class="w-14 h-14 bg-brand-accent/10 rounded-2xl flex items-center justify-center border border-brand-accent/20 shrink-0 group-hover:scale-110 transition-transform duration-300">\r
                  <img [src]="configService.config().logoUrl" [alt]="configService.config().brandName" class="w-8 h-8 object-contain" />\r
                </div>\r
                <div>\r
                  <h3 class="text-2xl font-bold text-white tracking-tight">\r
                    {{ configService.config().brandName }}<span class="text-brand-accent">{{ configService.config().brandSuffix || '' }}</span>\r
                  </h3>\r
                  <div class="text-brand-accent/70 text-xs font-mono uppercase tracking-widest">{{ configService.config().subTagline }}</div>\r
                </div>\r
              </div>\r
              \r
              <div class="space-y-4">\r
                <div>\r
                  <div class="flex justify-between items-end mb-2">\r
                    <label class="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">Room ID</label>\r
                    <span class="text-[10px] font-mono" \r
                          [class.text-red-400]="manualRoomId.length >= 36" \r
                          [class.text-brand-text-muted]="manualRoomId.length < 36">\r
                      {{ manualRoomId.length }} / 36\r
                    </span>\r
                  </div>\r
                  <div class="relative">\r
                    <input id="input-join-room-id" [type]="showManualRoomId ? 'text' : 'password'" \r
                           [(ngModel)]="manualRoomId" \r
                           maxlength="36" \r
                           placeholder="Paste Room ID..." \r
                           autocomplete="off" \r
                           data-1p-ignore="true" \r
                           data-lpignore="true" \r
                           data-bwignore="true"\r
                           class="w-full bg-brand-bg border border-brand-card-border rounded-lg p-3 pr-10 text-white font-mono text-sm outline-none focus:border-brand-accent transition"/>\r
                    <button id="btn-toggle-room-id-visibility" (click)="showManualRoomId = !showManualRoomId" \r
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-brand-text-muted hover:text-white transition cursor-pointer">\r
                      @if (showManualRoomId) {\r
                        <svg lucideEyeOff class="w-4 h-4"></svg>\r
                      } @else {\r
                        <svg lucideEye class="w-4 h-4"></svg>\r
                      }\r
                    </button>\r
                  </div>\r
                </div>\r
                \r
                <div>\r
                  <div class="flex justify-between items-end mb-2">\r
                    <label class="block text-xs font-bold text-brand-text-muted uppercase tracking-wider">Decryption Key</label>\r
                    <span class="text-[10px] font-mono" \r
                          [class.text-red-400]="manualKey.length >= 44" \r
                          [class.text-brand-text-muted]="manualKey.length < 44">\r
                      {{ manualKey.length }} / 44\r
                    </span>\r
                  </div>\r
                  <div class="relative">\r
                    <input id="input-join-key" [type]="showManualKey ? 'text' : 'password'" \r
                           [(ngModel)]="manualKey" \r
                           maxlength="44" \r
                           placeholder="Paste Key..." \r
                           autocomplete="off" \r
                           data-1p-ignore="true" \r
                           data-lpignore="true" \r
                           data-bwignore="true"\r
                           class="w-full bg-brand-bg border border-brand-card-border rounded-lg p-3 pr-10 text-white font-mono text-sm outline-none focus:border-brand-accent transition"/>\r
                    <button id="btn-toggle-key-visibility" (click)="showManualKey = !showManualKey" \r
                            class="absolute right-3 top-1/2 -translate-y-1/2 text-brand-text-muted hover:text-white transition cursor-pointer">\r
                      @if (showManualKey) {\r
                        <svg lucideEyeOff class="w-4 h-4"></svg>\r
                      } @else {\r
                        <svg lucideEye class="w-4 h-4"></svg>\r
                      }\r
                    </button>\r
                  </div>\r
                </div>\r
                \r
                <button id="btn-join-existing-room"\r
                  (click)="joinRoom()" \r
                  [disabled]="manualRoomId.length !== 36 || manualKey.length !== 44" \r
                  class="w-full py-4 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition shadow-lg shadow-brand-accent/20 flex items-center justify-center gap-2 group/btn disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer">\r
                  \r
                  <svg lucideShield class="w-4 h-4 fill-brand-bg transition-transform"\r
                       [class.group-hover/btn:scale-125]="manualRoomId.length === 36 && manualKey.length === 44">\r
                  </svg>\r
                  \r
                  <span>Enter {{ configService.config().brandName }}</span>\r
                </button>\r
              </div>\r
            </div>\r
          </div>\r
        }\r
      </div>\r
    }\r
  }\r
</div>\r
\r
<!-- Modal Dialog -->\r
@if (showCreateModal()) {\r
  <div id="modal-configure-room" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/90 backdrop-blur-xl animate-fade-in">\r
    <div class="bg-brand-card border border-brand-card-border p-8 rounded-2xl shadow-2xl max-w-lg w-full relative">\r
      @if (!isEmbedded) {\r
        <button id="btn-modal-close" (click)="showCreateModal.set(false)" class="absolute top-4 right-4 text-brand-text-muted hover:text-white cursor-pointer">\r
          <svg lucideX class="w-5 h-5"></svg>\r
        </button>\r
      }\r
      <h2 class="text-2xl font-bold text-white mb-6">\r
        @if (configService.config().useTradeMark) {\r
            Configure Signing Room\xAE\r
        } @else {\r
            Configure\r
        }\r
      </h2>\r
\r
      <div class="mb-6">\r
        <label class="block text-xs font-bold text-brand-text-muted uppercase tracking-wider mb-2">Network</label>\r
        <div class="grid grid-cols-3 gap-2">\r
          @for (net of networks; track net) {\r
            <button id="select-network-{{ net }}" (click)="selectedNetwork.set(net)" \r
                    class="py-2 px-3 rounded-lg text-sm font-bold border transition-all capitalize cursor-pointer"\r
                    [class.bg-brand-accent_20]="selectedNetwork() === net"\r
                    [class.border-brand-accent]="selectedNetwork() === net"\r
                    [class.text-brand-accent]="selectedNetwork() === net"\r
                    [class.bg-brand-bg]="selectedNetwork() !== net"\r
                    [class.border-brand-card-border]="selectedNetwork() !== net"\r
                    [class.text-brand-text-muted]="selectedNetwork() !== net">\r
              {{ net }}\r
            </button>\r
          }\r
        </div>\r
      </div>\r
\r
      <div class="bg-brand-card border border-brand-card-border rounded-xl p-6 mb-6">\r
        <label class="block text-xs font-bold uppercase tracking-wider mb-2 text-brand-text-muted">Transaction Data (Required)</label>\r
\r
        @if (!psbtAnalysis()) {\r
          @if (errorMessage()) {\r
            <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-start gap-3 animate-in fade-in slide-in-from-top-2">\r
              <svg lucideAlertTriangle class="w-5 h-5 text-rose-400 shrink-0"></svg>\r
              <div>\r
                <h4 class="text-sm font-bold text-rose-300 mb-1">Processing Failed</h4>\r
                <p class="text-xs text-rose-200/80 leading-relaxed">{{ errorMessage() }}</p>\r
              </div>\r
            </div>\r
          }\r
\r
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-2 animate-in fade-in duration-300">\r
            <div id="btn-upload-psbt-file" class="relative group flex flex-col items-center justify-center p-8 bg-brand-bg border-2 border-dashed border-brand-card-border rounded-xl hover:border-brand-accent/50 hover:bg-brand-accent/5 transition-all cursor-pointer" [class.opacity-50]="isScanning()">\r
              <input id="input-psbt-file" type="file" (change)="onFileSelected($event)" accept=".psbt,.txt,.hex" class="absolute inset-0 opacity-0 cursor-pointer z-10" [disabled]="isScanning()">\r
              <div class="bg-brand-card p-3 rounded-full mb-3 group-hover:bg-brand-accent/20 transition-colors">\r
                <svg lucideUploadCloud class="text-brand-text-muted group-hover:text-brand-accent transition-colors"></svg>\r
              </div>\r
              <span class="text-sm font-medium text-slate-200">Upload PSBT File</span>\r
              <span class="text-xs text-brand-text-muted mt-1">.psbt, .txt, or .hex</span>\r
            </div>\r
\r
            <button id="btn-scan-psbt-qr" (click)="startScanner()" [disabled]="isScanning()" class="flex flex-col items-center justify-center p-8 bg-brand-bg border-2 border-dashed border-brand-card-border rounded-xl hover:border-brand-accent/50 hover:bg-brand-accent/5 transition-all group disabled:opacity-50 cursor-pointer">\r
              <div class="bg-brand-card p-3 rounded-full mb-3 group-hover:bg-brand-accent/20 transition-colors">\r
                <svg lucideQrCode class="text-brand-text-muted group-hover:text-brand-accent transition-colors"></svg>\r
              </div>\r
              <span class="text-sm font-medium text-slate-200">Scan QR Code</span>\r
              <span class="text-xs text-brand-text-muted mt-1">Air-gapped hardware optics</span>\r
            </button>\r
          </div>\r
\r
          @if (isScanning()) {\r
            <div class="animate-in fade-in slide-in-from-top-4 duration-300 mt-6 mb-4">\r
              <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 mb-6 flex items-start gap-3">\r
                <svg lucideShield class="w-5 h-5 text-brand-accent shrink-0 mt-0.5"></svg>\r
                <div class="text-xs text-brand-text leading-relaxed space-y-2">\r
                  <p>\r
                    <strong>Secure Scanner:</strong> Hold your hardware wallet displaying PSBT QR Code up to the camera.\r
                  </p>\r
                  <p class="text-[11px] text-brand-accent font-medium bg-brand-accent/10 p-2 rounded border border-brand-accent/20">\r
                    \u{1F4A1} <strong>Tip:</strong> Sometimes QR codes are too small for webcams to read off a hardware device. You can use a mobile companion application to scan the hardware wallet, and then export the Signed PSBT to {{ configService.config().brandName }} through this reader.\r
                  </p>\r
                </div>\r
              </div>\r
\r
              <div class="w-full mb-4 space-y-2">\r
                <div class="bg-brand-bg border border-brand-card-border rounded-lg p-2.5 flex items-center justify-between">\r
                  <span class="text-[10px] text-brand-text-muted font-bold uppercase tracking-wider">Raw Optical Feed</span>\r
                  <span class="text-[10px] text-brand-accent font-mono truncate max-w-[200px]" [title]="urService.lastScannedText()">\r
                    {{ urService.lastScannedText() || 'Waiting for QR...' }}\r
                  </span>\r
                </div>\r
                \r
                @if (urService.scanError()) {\r
                  <div class="bg-rose-500/10 border border-rose-500/30 rounded-lg p-2.5 flex items-start gap-2 animate-in fade-in zoom-in-95 duration-200">\r
                    <svg lucideAlertTriangle class="w-4 h-4 text-rose-400 shrink-0"></svg>\r
                    <span class="text-xs text-rose-300">{{ urService.scanError() }}</span>\r
                  </div>\r
                }\r
              </div>\r
\r
              <div id="card-psbt-scanner" class="relative bg-black rounded-xl overflow-hidden border border-brand-accent/30 shadow-[0_0_15px_var(--wl-accent)] mt-6 animate-in fade-in slide-in-from-top-4 duration-300">\r
                <div id="reader" class="w-full h-72 object-cover"></div>\r
                \r
                <div class="absolute inset-0 pointer-events-none z-10 flex flex-col items-center justify-center overflow-hidden">\r
\r
                  <div class="relative w-56 h-56 rounded-xl shadow-[0_0_0_9999px_rgba(0,0,0,0.8)] border border-brand-accent/30">\r
                    <div class="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-brand-accent rounded-tl-xl"></div>\r
                    <div class="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-brand-accent rounded-tr-xl"></div>\r
                    <div class="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-brand-accent rounded-bl-xl"></div>\r
                    <div class="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-brand-accent rounded-br-xl"></div>\r
                    \r
                    <div class="absolute left-0 right-0 h-[2px] bg-brand-accent shadow-[0_0_8px_2px_var(--wl-accent)] scanner-laser"></div>\r
                  </div>\r
                </div>\r
\r
                @if (urService.scanProgress() > 0) {\r
                  <div class="absolute bottom-0 left-0 right-0 bg-brand-card/95 backdrop-blur-sm p-3 border-t border-brand-accent/30 z-20">\r
                    <div class="flex justify-between text-xs text-brand-accent font-bold mb-2 tracking-wider">\r
                      <span>RECONSTRUCTING PSBT...</span>\r
                      <span>{{ (urService.scanProgress() * 100).toFixed(0) }}%</span>\r
                    </div>\r
                    <div class="w-full bg-brand-bg rounded-full h-1.5 overflow-hidden">\r
                      <div class="bg-brand-accent h-1.5 rounded-full transition-all duration-200 ease-out" \r
                           [style.width.%]="urService.scanProgress() * 100"></div>\r
                    </div>\r
                  </div>\r
                }\r
                \r
                <button id="btn-stop-scanner" (click)="stopScanner()" class="absolute top-4 right-4 z-20 text-brand-text-muted bg-brand-card/80 hover:text-white hover:bg-red-500/90 p-2.5 rounded-full transition-all backdrop-blur-sm border border-brand-card-border hover:border-red-500 cursor-pointer">\r
                  <svg lucideX class="w-5 h-5"></svg>\r
                </button>\r
              </div>\r
            </div>\r
          }\r
\r
          <div class="relative flex items-center py-6">\r
            <div class="flex-grow border-t border-brand-card-border"></div>\r
            <span class="flex-shrink-0 mx-4 text-brand-text-muted text-xs font-medium uppercase tracking-wider">Or paste directly</span>\r
            <div class="flex-grow border-t border-brand-card-border"></div>\r
          </div>\r
\r
          <div class="relative">\r
            <textarea id="input-psbt-text"\r
              class="w-full bg-brand-bg/50 border border-brand-card-border text-brand-text rounded-lg p-4 font-mono text-xs focus:ring-1 focus:ring-brand-accent/50 focus:border-brand-accent/50 transition-colors resize-none placeholder-brand-text-muted" \r
              rows="4" \r
              placeholder="Paste raw PSBT Base64 or Hex string here..."\r
              [(ngModel)]="rawHex" (ngModelChange)="analyzeRawHex($event)"\r
              [disabled]="isScanning()"></textarea>\r
            <svg lucideEdit2 class="absolute top-4 right-4 text-brand-text-muted pointer-events-none w-4 h-4"></svg>\r
          </div>\r
\r
        } @else {\r
          <!-- PSBT Analysis Summary -->\r
          <div id="card-psbt-summary" class="bg-brand-bg border border-brand-card-border rounded-xl p-4 animate-in zoom-in-95 duration-300">\r
            <div class="flex items-start justify-between mb-4">\r
              <div class="flex items-center gap-3">\r
                <div class="w-10 h-10 bg-brand-accent/10 rounded-lg flex items-center justify-center text-brand-accent">\r
                  <svg lucideFileJson class="w-5 h-5"></svg>\r
                </div>\r
                <div>\r
                  <div class="text-white text-sm font-bold truncate max-w-[150px]">\r
                    {{ psbtFile()?.name || 'Handled via Optics' }}\r
                  </div>\r
                  <div class="text-brand-accent text-xs font-mono">\r
                    {{ psbtAnalysis()?.outputCount }} Outputs detected\r
                  </div>\r
                </div>\r
              </div>\r
              @if (!isEmbedded) {\r
                <button id="btn-clear-psbt" (click)="clearPsbt()" class="text-brand-text-muted hover:text-rose-400 p-1 rounded-md hover:bg-rose-400/10 transition-colors cursor-pointer">\r
                  <svg lucideX class="w-5 h-5"></svg>\r
                </button>\r
              }\r
            </div>\r
\r
            <div class="grid grid-cols-3 gap-2 text-center">\r
              <div class="bg-brand-card rounded p-2 border border-brand-card-border">\r
                <div class="text-[10px] text-brand-text-muted uppercase tracking-tight">Amount</div>\r
                <div class="text-white text-xs font-bold">\r
                  {{ psbtAnalysis()?.amountBtc | number:'1.4-4' }} <span class="text-brand-text-muted">BTC</span>\r
                </div>\r
              </div>\r
              <div class="bg-brand-card rounded p-2 border border-brand-card-border">\r
                <div class="text-[10px] text-brand-text-muted uppercase tracking-tight">Network Fee</div>\r
                <div class="text-white text-xs font-bold">\r
                  {{ psbtAnalysis()?.networkFeeSat | number }} <span class="text-brand-text-muted">sats</span>\r
                </div>\r
              </div>\r
              <div class="bg-brand-card rounded p-2 border border-brand-card-border">\r
                <div class="text-[10px] text-brand-text-muted uppercase tracking-tight">Signers</div>\r
                <div class="text-white text-xs font-bold">\r
                  {{ psbtAnalysis()?.signerCount }}\r
                </div>\r
              </div>\r
            </div>\r
          </div>\r
        }\r
      </div>\r
\r
      @if (isNetworkMismatch()) {\r
        <div class="mb-4 p-3 bg-rose-950/30 border border-rose-900/50 rounded-xl flex items-start gap-3">\r
          <svg lucideAlertTriangle class="w-5 h-5 text-rose-500 shrink-0 mt-0.5"></svg>\r
          <div>\r
            <div class="text-rose-200 text-xs font-bold mb-1">Network Mismatch</div>\r
            <p class="text-rose-400 text-[10px]">\r
              Selected: <strong>{{ selectedNetwork() | titlecase }}</strong>. \r
              PSBT: <strong>{{ psbtAnalysis()?.detectedNetwork | titlecase }}</strong>.\r
            </p>\r
          </div>\r
        </div>\r
      }\r
\r
      @if (isHighFee()) {\r
        <div class="mb-4 p-3 bg-amber-950/30 border border-amber-900/50 rounded-xl flex items-start gap-3">\r
          <svg lucideAlertTriangle class="w-5 h-5 text-amber-500 shrink-0 mt-0.5"></svg>\r
          <div>\r
            <div class="text-amber-200 text-xs font-bold mb-1">High Fee Detected</div>\r
            <p class="text-amber-400 text-[10px]">The network fee is unusually high (>100 sats/vB or >5% of total).</p>\r
          </div>\r
        </div>\r
      }\r
\r
      <button id="btn-launch-room" (click)="launchRoom()" [disabled]="isLoading() || !psbtAnalysis() || isNetworkMismatch()" class="w-full py-4 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition shadow-lg shadow-brand-accent/20 flex items-center justify-center gap-2 group/btn disabled:opacity-50 cursor-pointer">\r
        @if (isLoading()) {\r
            <svg lucideLoader2 class="w-4 h-4 fill-brand-bg group-hover/btn:scale-125 transition-transform animate-spin"></svg>\r
            Creating...\r
        } @else {\r
            <svg lucideShield class="w-4 h-4 fill-brand-bg group-hover/btn:scale-125 transition-transform"></svg>\r
            @if (configService.config().useTradeMark) {\r
            Start a Signing Room\xAE\r
            } @else {\r
            Start\r
            }\r
        }\r
        </button>\r
    </div>\r
  </div>\r
}` }]
  }], null, { onMessage: [{
    type: HostListener,
    args: ["window:message", ["$event"]]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(CreateComponent, { className: "CreateComponent", filePath: "apps/client/src/app/pages/create/create.component.ts", lineNumber: 59 });
})();
(() => {
  const id = "apps%2Fclient%2Fsrc%2Fapp%2Fpages%2Fcreate%2Fcreate.component.ts%40CreateComponent";
  function CreateComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(CreateComponent, m.default, [i0, i1, i2, i3], [EncryptionEngine, CommonModule, RouterModule, FormsModule, LucideCheck, LucideLoader2, LucideX, LucideUploadCloud, LucideFileJson, LucideAlertTriangle, LucideShield, LucideEye, LucideEyeOff, LucideQrCode, LucideEdit2, Component, HostListener], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && CreateComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && CreateComponent_HmrLoad(d.timestamp)));
})();
export {
  CreateComponent
};
//# debugId=464575da-272b-587d-9682-5d1d9ed7bb3d


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcHMvY2xpZW50L3NyYy9hcHAvcGFnZXMvY3JlYXRlL2NyZWF0ZS5jb21wb25lbnQudHMiLCJhcHBzL2NsaWVudC9zcmMvYXBwL3BhZ2VzL2NyZWF0ZS9jcmVhdGUuY29tcG9uZW50Lmh0bWwiXSwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogQ29weXJpZ2h0IChDKSAyMDI2IFN0YXRlbGVzcyBSZXNlYXJjaCBMdGRcclxuICogTGljZW5zZWQgdW5kZXIgdGhlIEdOVSBBZmZlcm8gR2VuZXJhbCBQdWJsaWMgTGljZW5zZSB2My4wXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIHNpZ25hbCwgaW5qZWN0LCBIb3N0TGlzdGVuZXIsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IFJvdXRlciwgUm91dGVyTW9kdWxlLCBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBQc2J0VXRpbHMsIFBzYnRBbmFseXNpcywgRW5jcnlwdGlvbkVuZ2luZSB9IGZyb20gJ0BzaWduaW5nLXJvb20vc2RrJztcclxuaW1wb3J0IHsgQ29uZmlnU2VydmljZSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2NvbmZpZy9jb25maWcuc2VydmljZSc7XHJcblxyXG5pbXBvcnQge1xyXG4gIEx1Y2lkZVphcCxcclxuICBMdWNpZGVDaGVjayxcclxuICBMdWNpZGVMb2FkZXIyLFxyXG4gIEx1Y2lkZVgsXHJcbiAgTHVjaWRlVXBsb2FkQ2xvdWQsXHJcbiAgTHVjaWRlRmlsZUpzb24sXHJcbiAgTHVjaWRlQWxlcnRUcmlhbmdsZSxcclxuICBMdWNpZGVTaGllbGQsXHJcbiAgTHVjaWRlS2V5LFxyXG4gIEx1Y2lkZVVzZXJzLFxyXG4gIEx1Y2lkZUV5ZSxcclxuICBMdWNpZGVFeWVPZmYsXHJcbiAgTHVjaWRlUXJDb2RlLFxyXG4gIEx1Y2lkZUVkaXQyLFxyXG59IGZyb20gJ0BsdWNpZGUvYW5ndWxhcic7XHJcbmltcG9ydCB7IEh0bWw1UXJjb2RlLCBIdG1sNVFyY29kZVN1cHBvcnRlZEZvcm1hdHMgfSBmcm9tICdodG1sNS1xcmNvZGUnO1xyXG5pbXBvcnQgeyBVclNlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy91ci91ci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgV2lkZ2V0RGlzcGF0Y2hlclNlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy93aWRnZXQtZGlzcGF0Y2hlci93aWRnZXQtZGlzcGF0Y2hlci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgU29ja2V0U2VydmljZSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3NvY2tldC9zb2NrZXQuc2VydmljZSc7XHJcblxyXG5jb25zdCBORVRXT1JLUyA9IFsnYml0Y29pbicsICd0ZXN0bmV0JywgJ3NpZ25ldCddIGFzIGNvbnN0O1xyXG50eXBlIE5ldHdvcmsgPSAodHlwZW9mIE5FVFdPUktTKVtudW1iZXJdO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtY3JlYXRlJyxcclxuICBzdGFuZGFsb25lOiB0cnVlLFxyXG4gIGltcG9ydHM6IFtcclxuICAgIENvbW1vbk1vZHVsZSxcclxuICAgIFJvdXRlck1vZHVsZSxcclxuICAgIEZvcm1zTW9kdWxlLFxyXG4gICAgTHVjaWRlQ2hlY2ssXHJcbiAgICBMdWNpZGVMb2FkZXIyLFxyXG4gICAgTHVjaWRlWCxcclxuICAgIEx1Y2lkZVVwbG9hZENsb3VkLFxyXG4gICAgTHVjaWRlRmlsZUpzb24sXHJcbiAgICBMdWNpZGVBbGVydFRyaWFuZ2xlLFxyXG4gICAgTHVjaWRlU2hpZWxkLFxyXG4gICAgTHVjaWRlRXllLFxyXG4gICAgTHVjaWRlRXllT2ZmLFxyXG4gICAgTHVjaWRlUXJDb2RlLFxyXG4gICAgTHVjaWRlRWRpdDIsXHJcbiAgXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vY3JlYXRlLmNvbXBvbmVudC5odG1sJyxcclxuICBwcm92aWRlcnM6IFtFbmNyeXB0aW9uRW5naW5lXSxcclxufSlcclxuZXhwb3J0IGNsYXNzIENyZWF0ZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgcHVibGljIHZpZXdNb2RlOiAnZGVmYXVsdCcgfCAnaW5qZWN0JyB8ICdqb2luJyA9ICdkZWZhdWx0JztcclxuICBwdWJsaWMgc2hvd01hbnVhbFJvb21JZCA9IGZhbHNlO1xyXG4gIHB1YmxpYyBzaG93TWFudWFsS2V5ID0gZmFsc2U7XHJcbiAgcHVibGljIGV4cGVjdGVkSG9zdCA9ICcnO1xyXG5cclxuICBwcml2YXRlIHNvY2tldCA9IGluamVjdChTb2NrZXRTZXJ2aWNlKTtcclxuICBwcml2YXRlIHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG4gIHByaXZhdGUgcm91dGUgPSBpbmplY3QoQWN0aXZhdGVkUm91dGUpO1xyXG4gIHB1YmxpYyB1clNlcnZpY2UgPSBpbmplY3QoVXJTZXJ2aWNlKTtcclxuICBwcml2YXRlIGRpc3BhdGNoZXIgPSBpbmplY3QoV2lkZ2V0RGlzcGF0Y2hlclNlcnZpY2UpO1xyXG4gIHByaXZhdGUgZW5jcnlwdGlvbkVuZ2luZSA9IGluamVjdChFbmNyeXB0aW9uRW5naW5lKTtcclxuICBwdWJsaWMgcmVhZG9ubHkgY29uZmlnU2VydmljZSA9IGluamVjdChDb25maWdTZXJ2aWNlKTtcclxuXHJcbiAgcmVhZG9ubHkgbmV0d29ya3MgPSBORVRXT1JLUztcclxuXHJcbiAgcHVibGljIHNlbGVjdGVkTmV0d29yayA9IHNpZ25hbDxOZXR3b3JrPignYml0Y29pbicpO1xyXG4gIHB1YmxpYyBwc2J0RmlsZSA9IHNpZ25hbDxGaWxlIHwgbnVsbD4obnVsbCk7XHJcbiAgcHVibGljIHBzYnRBbmFseXNpcyA9IHNpZ25hbDxQc2J0QW5hbHlzaXMgfCBudWxsPihudWxsKTtcclxuICBwdWJsaWMgcmF3SGV4ID0gJyc7XHJcbiAgcHVibGljIHNob3dDcmVhdGVNb2RhbCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIGlzTG9hZGluZyA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIGVycm9yTWVzc2FnZSA9IHNpZ25hbDxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbiAgLy8gLS0tIEVNQkVEIFBST1BFUlRJRVMgLS0tXHJcbiAgcHVibGljIGlzRW1iZWRkZWQgPSBmYWxzZTtcclxuICBwdWJsaWMgbWFudWFsUm9vbUlkID0gJyc7XHJcbiAgcHVibGljIG1hbnVhbEtleSA9ICcnO1xyXG5cclxuICBpc1NjYW5uaW5nID0gc2lnbmFsPGJvb2xlYW4+KGZhbHNlKTtcclxuICBwdWJsaWMgaHRtbDVRckNvZGU6IEh0bWw1UXJjb2RlIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzptZXNzYWdlJywgWyckZXZlbnQnXSlcclxuICBhc3luYyBvbk1lc3NhZ2UoZXZlbnQ6IE1lc3NhZ2VFdmVudCkge1xyXG4gICAgaWYgKHRoaXMuZXhwZWN0ZWRIb3N0ICYmIGV2ZW50Lm9yaWdpbiAhPT0gdGhpcy5leHBlY3RlZEhvc3QpIHtcclxuICAgICAgY29uc29sZS53YXJuKGBbU2VjdXJpdHldIEJsb2NrZWQgdW5hdXRob3JpemVkIHBvc3RNZXNzYWdlIGZyb206ICR7ZXZlbnQub3JpZ2lufWApO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGV2ZW50LmRhdGE/LnR5cGUgPT09ICdTSUdOSU5HX1JPT01fQ09NTUFORCcpIHtcclxuICAgICAgaWYgKGV2ZW50LmRhdGEuYWN0aW9uID09PSAnTE9BRF9QU0JUJyAmJiBldmVudC5kYXRhLnBheWxvYWQpIHtcclxuICAgICAgICBjb25zdCBob3N0TmV0d29yayA9IHRoaXMucm91dGUuc25hcHNob3QucXVlcnlQYXJhbU1hcC5nZXQoJ25ldHdvcmsnKTtcclxuICAgICAgICBpZiAoaG9zdE5ldHdvcmspIHtcclxuICAgICAgICAgIHRoaXMuc2VsZWN0ZWROZXR3b3JrLnNldChob3N0TmV0d29yayBhcyBhbnkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcGF5bG9hZFN0cmluZyA9IGV2ZW50LmRhdGEucGF5bG9hZC50cmltKCk7XHJcblxyXG4gICAgICAgIGNvbnN0IGR1bW15RmlsZSA9IG5ldyBGaWxlKFtwYXlsb2FkU3RyaW5nXSwgJ2xvYWRlZF90cmFuc2FjdGlvbi5wc2J0LnR4dCcsIHtcclxuICAgICAgICAgIHR5cGU6ICd0ZXh0L3BsYWluJyxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgbGV0IGZpbGVzOiBhbnkgPSBbZHVtbXlGaWxlXTtcclxuICAgICAgICBpZiAodHlwZW9mIERhdGFUcmFuc2ZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgIGNvbnN0IGRhdGFUcmFuc2ZlciA9IG5ldyBEYXRhVHJhbnNmZXIoKTtcclxuICAgICAgICAgIGRhdGFUcmFuc2Zlci5pdGVtcy5hZGQoZHVtbXlGaWxlKTtcclxuICAgICAgICAgIGZpbGVzID0gZGF0YVRyYW5zZmVyLmZpbGVzO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgbW9ja0V2ZW50ID0ge1xyXG4gICAgICAgICAgdGFyZ2V0OiB7IGZpbGVzOiBmaWxlcyB9LFxyXG4gICAgICAgICAgcHJldmVudERlZmF1bHQ6ICgpID0+IHt9LFxyXG4gICAgICAgICAgc3RvcFByb3BhZ2F0aW9uOiAoKSA9PiB7fSxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICBhd2FpdCB0aGlzLm9uRmlsZVNlbGVjdGVkKG1vY2tFdmVudCBhcyBhbnkpO1xyXG4gICAgICAgIHRoaXMuc2hvd0NyZWF0ZU1vZGFsLnNldCh0cnVlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICB0aGlzLnZpZXdNb2RlID0gKHRoaXMucm91dGUuc25hcHNob3QucXVlcnlQYXJhbU1hcC5nZXQoJ3ZpZXcnKSBhcyBhbnkpIHx8ICdkZWZhdWx0JztcclxuXHJcbiAgICB0aGlzLmV4cGVjdGVkSG9zdCA9IHRoaXMucm91dGUuc25hcHNob3QucXVlcnlQYXJhbU1hcC5nZXQoJ2hvc3QnKSB8fCAnJztcclxuXHJcbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgaWYgKCF0aGlzLmV4cGVjdGVkSG9zdCkge1xyXG4gICAgICAgIHRoaXMuZXhwZWN0ZWRIb3N0ID0gd2luZG93LmxvY2F0aW9uLm9yaWdpbjtcclxuICAgICAgfVxyXG5cclxuICAgICAgdGhpcy5pc0VtYmVkZGVkID0gd2luZG93ICE9PSB3aW5kb3cucGFyZW50IHx8IHdpbmRvdyAhPT0gd2luZG93LnRvcDtcclxuXHJcbiAgICAgIGlmICh0aGlzLmlzRW1iZWRkZWQpIHtcclxuICAgICAgICB3aW5kb3cucGFyZW50LnBvc3RNZXNzYWdlKFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICB0eXBlOiAnU0lHTklOR19ST09NX0VWRU5UJyxcclxuICAgICAgICAgICAgYWN0aW9uOiAnV0lER0VUX1JFQURZJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB0aGlzLmV4cGVjdGVkSG9zdCxcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjbGVhclBzYnQoKSB7XHJcbiAgICB0aGlzLnBzYnRGaWxlLnNldChudWxsKTtcclxuICAgIHRoaXMucmF3SGV4ID0gJyc7XHJcbiAgICB0aGlzLnBzYnRBbmFseXNpcy5zZXQobnVsbCk7XHJcbiAgICB0aGlzLmVycm9yTWVzc2FnZS5zZXQobnVsbCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBsYXVuY2hSb29tKCkge1xyXG4gICAgdGhpcy5pc0xvYWRpbmcuc2V0KHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY3JlYXRlUm9vbVBheWxvYWQgPSBhd2FpdCB0aGlzLnNvY2tldC5jcmVhdGVSb29tKFxyXG4gICAgICAgIHRoaXMucmF3SGV4LFxyXG4gICAgICAgIHRoaXMuc2VsZWN0ZWROZXR3b3JrKCksXHJcbiAgICAgICAgJ1VudGl0bGVkIFJvb20nLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgZW5jcnlwdGVkVG9rZW4gPSBhd2FpdCB0aGlzLmVuY3J5cHRpb25FbmdpbmUuZW5jcnlwdChcclxuICAgICAgICBjcmVhdGVSb29tUGF5bG9hZC5odHRwUGF5bG9hZC5hZG1pblRva2VuLFxyXG4gICAgICAgIGNyZWF0ZVJvb21QYXlsb2FkLmxvY2FsRGF0YS5lbmNyeXB0aW9uS2V5LFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShgYWRtaW5fdG9rZW5fJHtjcmVhdGVSb29tUGF5bG9hZC5sb2NhbERhdGEucm9vbUlkfWAsIGVuY3J5cHRlZFRva2VuKTtcclxuICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRSb29tQ3JlYXRlZChjcmVhdGVSb29tUGF5bG9hZC5sb2NhbERhdGEucm9vbUlkLCB0aGlzLnNlbGVjdGVkTmV0d29yaygpKTtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvcm9vbScsIGNyZWF0ZVJvb21QYXlsb2FkLmxvY2FsRGF0YS5yb29tSWRdLCB7XHJcbiAgICAgICAgZnJhZ21lbnQ6IGNyZWF0ZVJvb21QYXlsb2FkLmxvY2FsRGF0YS5lbmNyeXB0aW9uS2V5LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHRoaXMuaXNMb2FkaW5nLnNldChmYWxzZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBqb2luUm9vbSgpIHtcclxuICAgIGlmICh0aGlzLm1hbnVhbFJvb21JZCAmJiB0aGlzLm1hbnVhbEtleSkge1xyXG4gICAgICBjb25zdCBjbGVhbktleSA9IHRoaXMubWFudWFsS2V5LmluY2x1ZGVzKCcjJykgPyB0aGlzLm1hbnVhbEtleS5zcGxpdCgnIycpWzFdIDogdGhpcy5tYW51YWxLZXk7XHJcblxyXG4gICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9yb29tJywgdGhpcy5tYW51YWxSb29tSWQudHJpbSgpXSwge1xyXG4gICAgICAgIGZyYWdtZW50OiBjbGVhbktleS50cmltKCksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgb25GaWxlU2VsZWN0ZWQoZXZlbnQ6IGFueSkge1xyXG4gICAgY29uc3QgZmlsZSA9IGV2ZW50LnRhcmdldC5maWxlc1swXTtcclxuXHJcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcclxuXHJcbiAgICB0aGlzLnBzYnRGaWxlLnNldChmaWxlKTtcclxuICAgIHRoaXMuZXJyb3JNZXNzYWdlLnNldChudWxsKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBidWZmZXIgPSBhd2FpdCBmaWxlLmFycmF5QnVmZmVyKCk7XHJcbiAgICAgIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcclxuICAgICAgLy8gTWFnaWMgYnl0ZXMgY2hlY2sgZm9yIEJpbmFyeSBQU0JUIChwc2J0XFx4ZmYpXHJcbiAgICAgIGNvbnN0IGlzQmluYXJ5ID1cclxuICAgICAgICBieXRlc1swXSA9PT0gMHg3MCAmJlxyXG4gICAgICAgIGJ5dGVzWzFdID09PSAweDczICYmXHJcbiAgICAgICAgYnl0ZXNbMl0gPT09IDB4NjIgJiZcclxuICAgICAgICBieXRlc1szXSA9PT0gMHg3NCAmJlxyXG4gICAgICAgIGJ5dGVzWzRdID09PSAweGZmO1xyXG5cclxuICAgICAgY29uc3QgY29udGVudCA9IGlzQmluYXJ5XHJcbiAgICAgICAgPyBBcnJheS5mcm9tKGJ5dGVzKVxyXG4gICAgICAgICAgICAubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxyXG4gICAgICAgICAgICAuam9pbignJylcclxuICAgICAgICA6IG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShieXRlcykudHJpbSgpO1xyXG5cclxuICAgICAgdGhpcy5yYXdIZXggPSBjb250ZW50O1xyXG5cclxuICAgICAgdGhpcy5hbmFseXplUmF3SGV4KGNvbnRlbnQpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYW5hbHl6ZVJhd0hleChkYXRhOiBzdHJpbmcpIHtcclxuICAgIGlmICghZGF0YSB8fCBkYXRhLmxlbmd0aCA8IDEwKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgYW5hbHlzaXMgPSBQc2J0VXRpbHMuYW5hbHl6ZShkYXRhKTtcclxuXHJcbiAgICBpZiAoYW5hbHlzaXMpIHtcclxuICAgICAgdGhpcy5wc2J0QW5hbHlzaXMuc2V0KGFuYWx5c2lzKTtcclxuICAgICAgdGhpcy5lcnJvck1lc3NhZ2Uuc2V0KG51bGwpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5wc2J0QW5hbHlzaXMuc2V0KG51bGwpO1xyXG4gICAgICB0aGlzLmVycm9yTWVzc2FnZS5zZXQoXHJcbiAgICAgICAgJ0ludmFsaWQgUFNCVCBmb3JtYXQuIFBsZWFzZSBlbnN1cmUgeW91IGFyZSBwcm92aWRpbmcgYSB2YWxpZCBCYXNlNjQgb3IgSGV4IGVuY29kZWQgUGFydGlhbGx5IFNpZ25lZCBCaXRjb2luIFRyYW5zYWN0aW9uLicsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBpZiAodGhpcy5pc0VtYmVkZGVkKSB7XHJcbiAgICAgICAgd2luZG93LnBhcmVudC5wb3N0TWVzc2FnZShcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgdHlwZTogJ1NJR05JTkdfUk9PTV9FVkVOVCcsXHJcbiAgICAgICAgICAgIGFjdGlvbjogJ3NpZ25pbmdFcnJvcicsXHJcbiAgICAgICAgICAgIHBheWxvYWQ6IHtcclxuICAgICAgICAgICAgICBjb2RlOiAnUFNCVF9JTlZBTElEJyxcclxuICAgICAgICAgICAgICBtZXNzYWdlOiAnRmFpbGVkIHRvIHBhcnNlIFBTQlQgZGF0YS4nLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHRoaXMuZXhwZWN0ZWRIb3N0LFxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGVtaXRSb29tQ3JlYXRlZChyb29tSWQ6IHN0cmluZywgbmV0d29yazogc3RyaW5nKTogdm9pZCB7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFJvb21DcmVhdGVkKHJvb21JZCwgbmV0d29yayk7XHJcbiAgfVxyXG5cclxuICAvLyBVWCBIZWxwZXJzXHJcbiAgaXNOZXR3b3JrTWlzbWF0Y2goKTogYm9vbGVhbiB7XHJcbiAgICBjb25zdCBhbmFseXNpcyA9IHRoaXMucHNidEFuYWx5c2lzKCk7XHJcbiAgICBpZiAoIWFuYWx5c2lzKSByZXR1cm4gZmFsc2U7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAoYW5hbHlzaXMuZGV0ZWN0ZWROZXR3b3JrID09PSAnYml0Y29pbicgJiYgdGhpcy5zZWxlY3RlZE5ldHdvcmsoKSAhPT0gJ2JpdGNvaW4nKSB8fFxyXG4gICAgICAoYW5hbHlzaXMuZGV0ZWN0ZWROZXR3b3JrID09PSAndGVzdG5ldCcgJiYgdGhpcy5zZWxlY3RlZE5ldHdvcmsoKSA9PT0gJ2JpdGNvaW4nKVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlzSGlnaEZlZSgpOiBib29sZWFuIHtcclxuICAgIGNvbnN0IGFuYWx5c2lzID0gdGhpcy5wc2J0QW5hbHlzaXMoKTtcclxuICAgIGlmICghYW5hbHlzaXMgfHwgYW5hbHlzaXMubmV0d29ya0ZlZVNhdCA9PT0gMCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgY29uc3QgZXN0VkJ5dGVzID0gYW5hbHlzaXMuc2lnbmVyQ291bnQgKiA2OCArIGFuYWx5c2lzLm91dHB1dENvdW50ICogMzEgKyAxMDtcclxuICAgIGNvbnN0IHJhdGUgPSBhbmFseXNpcy5uZXR3b3JrRmVlU2F0IC8gZXN0VkJ5dGVzO1xyXG4gICAgY29uc3QgdG90YWxTYXRzID0gYW5hbHlzaXMuYW1vdW50QnRjICogMTAwMDAwMDAwO1xyXG4gICAgcmV0dXJuIHJhdGUgPiAxMDAgfHwgKHRvdGFsU2F0cyA+IDAgJiYgYW5hbHlzaXMubmV0d29ya0ZlZVNhdCAvIHRvdGFsU2F0cyA+IDAuMDUpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBpc1Byb2Nlc3NpbmdTY2FuID0gZmFsc2U7XHJcblxyXG4gIGFzeW5jIHN0YXJ0U2Nhbm5lcigpIHtcclxuICAgIHRoaXMuaXNTY2FubmluZy5zZXQodHJ1ZSk7XHJcbiAgICB0aGlzLmlzUHJvY2Vzc2luZ1NjYW4gPSBmYWxzZTtcclxuICAgIHRoaXMuZXJyb3JNZXNzYWdlLnNldChudWxsKTsgLy8gQ2xlYXIgb2xkIGVycm9yc1xyXG4gICAgdGhpcy51clNlcnZpY2UucmVzZXREZWNvZGVyKCk7XHJcblxyXG4gICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRoaXMuaHRtbDVRckNvZGUgPSBuZXcgSHRtbDVRcmNvZGUoJ3JlYWRlcicsIHtcclxuICAgICAgICBmb3JtYXRzVG9TdXBwb3J0OiBbSHRtbDVRcmNvZGVTdXBwb3J0ZWRGb3JtYXRzLlFSX0NPREVdLFxyXG4gICAgICAgIHZlcmJvc2U6IGZhbHNlLFxyXG4gICAgICAgIGV4cGVyaW1lbnRhbEZlYXR1cmVzOiB7XHJcbiAgICAgICAgICB1c2VCYXJDb2RlRGV0ZWN0b3JJZlN1cHBvcnRlZDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGxldCBmcmFtZUNvdW50ID0gMDtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5odG1sNVFyQ29kZS5zdGFydChcclxuICAgICAgICAgIHsgZmFjaW5nTW9kZTogJ2Vudmlyb25tZW50JyB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBmcHM6IDEwLFxyXG4gICAgICAgICAgICBkaXNhYmxlRmxpcDogdHJ1ZSxcclxuICAgICAgICAgICAgcXJib3g6IHsgd2lkdGg6IDM1MCwgaGVpZ2h0OiAzNTAgfSxcclxuICAgICAgICAgICAgdmlkZW9Db25zdHJhaW50czoge1xyXG4gICAgICAgICAgICAgIHdpZHRoOiB7IGlkZWFsOiAxMjgwIH0sXHJcbiAgICAgICAgICAgICAgaGVpZ2h0OiB7IGlkZWFsOiA3MjAgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICAoZGVjb2RlZFRleHQpID0+IHRoaXMuaGFuZGxlU2NhblJlc3VsdChkZWNvZGVkVGV4dCksXHJcbiAgICAgICAgICAoZXJyb3JNZXNzYWdlKSA9PiB7XHJcbiAgICAgICAgICAgIGZyYW1lQ291bnQrKztcclxuICAgICAgICAgICAgaWYgKGZyYW1lQ291bnQgJSA2MCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUud2FybihcclxuICAgICAgICAgICAgICAgIGBbT3B0aWNhbCBEZWJ1Z10gRnJhbWUgJHtmcmFtZUNvdW50fSAtIEVuZ2luZSBmYWlsaW5nIHRvIGxvY2s6YCxcclxuICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZS5zcGxpdCgnXFxuJylbMF0sXHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICApO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLndhcm4oJ0hpZ2gtcmVzIGNhbWVyYSBzdGFydCBmYWlsZWQuIEZhbGxpbmcgYmFjayB0byBzdGFuZGFyZCByZXNvbHV0aW9uLi4uJywgZXJyKTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuaHRtbDVRckNvZGUuc3RhcnQoXHJcbiAgICAgICAgICAgIHsgZmFjaW5nTW9kZTogJ2Vudmlyb25tZW50JyB9LFxyXG4gICAgICAgICAgICB7IGZwczogMTAsIGRpc2FibGVGbGlwOiBmYWxzZSB9LFxyXG4gICAgICAgICAgICAoZGVjb2RlZFRleHQpID0+IHRoaXMuaGFuZGxlU2NhblJlc3VsdChkZWNvZGVkVGV4dCksXHJcbiAgICAgICAgICAgICgpID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdGYWxsYmFjayBjYW1lcmEgZmFpbGVkIHRvIHN0YXJ0LicpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9IGNhdGNoIChmYWxsYmFja0Vycikge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignRmFsbGJhY2sgY2FtZXJhIHN0YXJ0IGFsc28gZmFpbGVkOicsIGZhbGxiYWNrRXJyKTtcclxuICAgICAgICAgIHRoaXMuc3RvcFNjYW5uZXIoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0sIDEwMCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBoYW5kbGVTY2FuUmVzdWx0KGRlY29kZWRUZXh0OiBzdHJpbmcpIHtcclxuICAgIGlmICh0aGlzLmlzUHJvY2Vzc2luZ1NjYW4pIHJldHVybjtcclxuXHJcbiAgICBjb25zdCB1cHBlciA9IGRlY29kZWRUZXh0LnRvVXBwZXJDYXNlKCk7XHJcblxyXG4gICAgLy8gUm91dGUgQk9USCBGb3VudGFpbiBDb2RlcyAoVVIpIGFuZCBDb2xkY2FyZCBCQlFyIGNvZGVzIChCJCkgdG8gdGhlIE9tbmktRGVjb2RlclxyXG4gICAgaWYgKHVwcGVyLnN0YXJ0c1dpdGgoJ1VSOicpIHx8IHVwcGVyLnN0YXJ0c1dpdGgoJ0IkJykpIHtcclxuICAgICAgY29uc3QgZnVsbEhleCA9IHRoaXMudXJTZXJ2aWNlLnByb2Nlc3NGcmFnbWVudChkZWNvZGVkVGV4dCk7XHJcblxyXG4gICAgICBpZiAoZnVsbEhleCkge1xyXG4gICAgICAgIHRoaXMuaXNQcm9jZXNzaW5nU2NhbiA9IHRydWU7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5zYWZlU3RvcFNjYW5uZXIoKTtcclxuXHJcbiAgICAgICAgdGhpcy5yYXdIZXggPSBmdWxsSGV4O1xyXG5cclxuICAgICAgICB0aGlzLmFuYWx5emVSYXdIZXgoZnVsbEhleCk7XHJcbiAgICAgICAgdGhpcy5pc1Byb2Nlc3NpbmdTY2FuID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuaXNQcm9jZXNzaW5nU2NhbiA9IHRydWU7XHJcbiAgICAgIGF3YWl0IHRoaXMuc2FmZVN0b3BTY2FubmVyKCk7XHJcblxyXG4gICAgICB0aGlzLnJhd0hleCA9IGRlY29kZWRUZXh0O1xyXG5cclxuICAgICAgdGhpcy5hbmFseXplUmF3SGV4KGRlY29kZWRUZXh0KTtcclxuICAgICAgdGhpcy5pc1Byb2Nlc3NpbmdTY2FuID0gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBzYWZlU3RvcFNjYW5uZXIoKSB7XHJcbiAgICBpZiAodGhpcy5odG1sNVFyQ29kZSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmICh0aGlzLmh0bWw1UXJDb2RlLmdldFN0YXRlKCkgPT09IDIpIHtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuaHRtbDVRckNvZGUuc3RvcCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLmh0bWw1UXJDb2RlLmNsZWFyKCk7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdDYW1lcmEgc3RvcCBlcnJvcicsIGUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aGlzLmlzU2Nhbm5pbmcuc2V0KGZhbHNlKTtcclxuICB9XHJcblxyXG4gIHN0b3BTY2FubmVyKCkge1xyXG4gICAgdGhpcy5zYWZlU3RvcFNjYW5uZXIoKTtcclxuICB9XHJcbn1cclxuIiwiPGRpdiBpZD1cImNvbnRhaW5lci1jcmVhdGUtZGFzaGJvYXJkXCIgY2xhc3M9XCJ3LWZ1bGwgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcC02IHJlbGF0aXZlXCJcclxuICAgICBbY2xhc3MucHQtMTJdPVwiIWlzRW1iZWRkZWRcIiBbY2xhc3MucHQtNl09XCJpc0VtYmVkZGVkXCI+XHJcblxyXG4gIEBpZiAodmlld01vZGUgPT09ICdpbmplY3QnKSB7XHJcbiAgICA8ZGl2IGlkPVwidmlldy1pbmplY3Qtd2FpdGluZ1wiIGNsYXNzPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC1mdWxsIG1pbi1oLVs0MDBweF0gdGV4dC1jZW50ZXIgcmVsYXRpdmUgei0xMCBhbmltYXRlLWZhZGUtaW5cIj5cclxuICAgICAgXHJcbiAgICAgIDwhLS0gQnJhbmQgSGVhZGVyIChJbmplY3QgVmlldykgLS0+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0xMCBvcGFjaXR5LTgwXCI+XHJcbiAgICAgICAgPGltZyBbc3JjXT1cImNvbmZpZ1NlcnZpY2UuY29uZmlnKCkubG9nb1VybFwiIFthbHRdPVwiY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWVcIiBjbGFzcz1cInctOCBoLTggb2JqZWN0LWNvbnRhaW5cIiAvPlxyXG4gICAgICAgIDxoMyBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICB7eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kTmFtZSB9fTxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnRcIj57eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kU3VmZml4IHx8ICcnIH19PC9zcGFuPlxyXG4gICAgICAgIDwvaDM+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHN2ZyBsdWNpZGVMb2FkZXIyIGNsYXNzPVwidy0xMiBoLTEyIHRleHQtYnJhbmQtYWNjZW50IGFuaW1hdGUtc3BpbiBtYi02XCI+PC9zdmc+XHJcbiAgICAgIDxoMiBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTIgdHJhY2tpbmctdGlnaHRcIj5XYWl0aW5nIGZvciBEYXRhLi4uPC9oMj5cclxuICAgICAgPHAgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC1zbSBtYXgtdy1zbVwiPlBsZWFzZSBpbml0aWFsaXplIHRoZSBzaWduaW5nIGNlcmVtb255IG9yIHBhc3MgdGhlIHRyYW5zYWN0aW9uIHBheWxvYWQgZnJvbSB5b3VyIGhvc3QgYXBwbGljYXRpb24uPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgfSBcclxuICBAZWxzZSB7XHJcbiAgICBAaWYgKCFpc0VtYmVkZGVkKSB7XHJcbiAgICAgIDwhLS0gR2xvdyBiYWNrZ3JvdW5kIC0tPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB3LVs4MDBweF0gaC1bNTAwcHhdIGJnLWJyYW5kLWFjY2VudC8xMCByb3VuZGVkLWZ1bGwgYmx1ci1bMTIwcHhdIHBvaW50ZXItZXZlbnRzLW5vbmVcIj48L2Rpdj5cclxuXHJcbiAgICAgIDwhLS0gTWFpbiBIZXJvIEhlYWRlciAtLT5cclxuICAgICAgPGRpdiBpZD1cInZpZXctY3JlYXRlLXN0YW5kYXJkXCIgY2xhc3M9XCJtYXgtdy0zeGwgdy1mdWxsIHRleHQtY2VudGVyIG1iLTEyIHJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIEBpZiAoY29uZmlnU2VydmljZS5jb25maWcoKS53aGl0ZWxhYmVsKSB7XHJcbiAgICAgICAgICAgIDxpbWcgW3NyY109XCJjb25maWdTZXJ2aWNlLmNvbmZpZygpLmxvZ29VcmxcIiBbYWx0XT1cImNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuYnJhbmROYW1lXCIgY2xhc3M9XCJ3LTE2IGgtMTYgb2JqZWN0LWNvbnRhaW4gZHJvcC1zaGFkb3ctWzBfMF8xNXB4X3ZhcigtLXdsLWFjY2VudCldXCIgLz5cclxuICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgNDA5IDQ0NVwiIGNsYXNzPVwidy0xNiBoLTE2IHRleHQtYnJhbmQtYWNjZW50IGZpbGwtY3VycmVudFwiIHByZXNlcnZlQXNwZWN0UmF0aW89XCJ4TWlkWU1pZCBtZWV0XCI+XHJcbiAgICAgICAgICAgICAgICA8Zz5cclxuICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTg1LjUgNDI1LjcgYy0zNS40IC0xNy4zIC03MiAtNDMuNCAtOTguMiAtNjkuOSAtMzEuNiAtMzEuOSAtNTAuMyAtNjIuNSAtNTkuMSAtOTYuOCAtNS42IC0yMS43IC01LjcgLTIzLjQgLTUuNyAtMTAxIDAgLTY2LjYgMC4xIC03MS43IDEuOCAtNzUuMSAyLjMgLTQuNiA2LjEgLTYuNyAyMi4yIC0xMi4yIDcuMiAtMi41IDMxLjkgLTExLjMgNTUgLTE5LjcgNzkuNCAtMjguNyA5Ny42IC0zNSAxMDAuNCAtMzUgMi44IDAgMjcuNSA4LjMgNTMuNiAxOCAyMS4zIDcuOSA3MC42IDI1LjcgOTIgMzMuMSAxMSAzLjkgMjEuNCA3LjUgMjMgOC4xIDQuNCAxLjYgOC40IDUuNyA5LjUgOS43IDEuMyA0LjkgMS4zIDEzNi44IDAgMTQ4LjYgLTQuOSA0Mi42IC0yMS4yIDc2LjEgLTU1LjEgMTEzLjEgLTIxIDIzIC00OS43IDQ2IC03OS40IDYzLjkgLTE1LjkgOS42IC00MC4xIDIxLjUgLTQzLjYgMjEuNSAtMi4xIDAgLTguMiAtMi4zIC0xNi40IC02LjN6IG0yNC42IC0yOC44IGMzMS40IC0xNS43IDcxLjcgLTQ1LjYgOTIgLTY4IDI2LjkgLTI5LjggMzkuMyAtNTIgNDcuMiAtODQuNCAyLjEgLTguOCAyLjIgLTEwLjMgMi4yIC03Ni45IGwwIC02Ny45IC0xNyAtNi4yIGMtNDguNSAtMTcuNyAtODQuNiAtMzAuNiAtMTE2IC00MS42IGwtMTYuOSAtNiAtMjAuMSA3LjEgYy0xMSA0IC0yNi41IDkuNiAtMzQuNSAxMi41IC04IDIuOSAtMTguMyA2LjcgLTIzIDguMyAtMTEuNiA0IC0zNi4yIDEyLjkgLTQzLjUgMTUuNyAtMy4zIDEuMyAtMTAuOSA0IC0xNyA2LjEgLTYgMi4xIC0xMS4yIDQuMSAtMTEuNSA0LjUgLTEgMS40IC0xIDExMy4zIC0wLjEgMTI0LjkgMC41IDYuMyAxLjcgMTUuMSAyLjYgMTkuNSAxMC42IDUyLjEgNTIuMiAxMDEuNCAxMTkgMTQxIDExLjQgNi44IDI3IDE1LjMgMjguMyAxNS41IDAuMSAwIDMuOSAtMS44IDguMyAtNC4xelwiLz5cclxuICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTkxLjMgMzE4LjMgYy03LjYgLTcuNCAtOC4xIC04LjEgLTguNiAtMTIuOCAtMC4yIC0yLjcgLTAuNSAtMjcuOSAtMC42IC01NS45IDAgLTI4IC0wLjIgLTUxIC0wLjMgLTUxLjEgLTAuMiAtMC4xIC0yLjUgLTEuNCAtNS4xIC0yLjkgLTcgLTQgLTExLjEgLTggLTE2LjEgLTE1LjQgLTUuOSAtOC45IC04LjYgLTE3LjUgLTguNiAtMjcuMSAwIC0yNyAxOS41IC00OC41IDQ1LjkgLTUwLjcgMTMgLTEuMSAyNi4xIDMuNSAzNi42IDEyLjkgMTkuOCAxNy42IDIxLjggNTAuMyA0LjQgNzAuMSAtNC4xIDQuNiAtMTQuOCAxMi42IC0xNi44IDEyLjYgLTAuNyAwIC0xLjEgNi4zIC0xLjEgMTkgbDAgMTkgLTYuMSA2LjYgLTYgNi43IDYgNi4xIGM4LjIgOC4zIDguMiAxMC4xIDAgMTguMyBsLTYgNiA2IDUuOCA2LjEgNS44IDAgOC4zIDAgOC4yIC05IDkuMSBjLTUgNSAtOS45IDkuMSAtMTAuOSA5LjEgLTEgMCAtNS40IC0zLjUgLTkuOCAtNy43eiBtMTcuNyAtMTc1IGMzLjYgLTIuNCA0LjggLTQuMyA1LjUgLTguMyAxIC01LjcgLTEuNCAtMTEuMSAtNiAtMTMuNyAtNC45IC0yLjggLTguNCAtMi45IC0xMy40IC0wLjMgLTMuOCAxLjkgLTQuNSAyLjggLTYuMiA4LjQgLTEuMiA0LjEgMC44IDEwLjIgNC40IDEzLjIgMy42IDMgMTEuOCAzLjQgMTUuNyAwLjd6XCIvPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk0xMzAuMSAzMDQuMiBsLTcuMSAtNi43IDAgLTQ4LjIgMCAtNDguMiAtNS41IC0zLjUgYy0zNi42IC0yMy41IC0yMy43IC03OS40IDE5LjEgLTgyLjQgNi41IC0wLjQgMTcuNCAxLjIgMTcuNCAyLjUgMCAwLjMgLTEuNSAzLjYgLTMuMiA3LjQgLTIuNCA1IC0zLjcgNi42IC00LjggNi4yIC0wLjggLTAuNCAtMy42IC0wLjggLTYuMyAtMS4xIC00LjMgLTAuNCAtNSAtMC4xIC04LjIgMy4xIC0yLjkgMi45IC0zLjUgNC4yIC0zLjUgNy45IDAgMi40IDAuNyA1LjQgMS42IDYuNiAyIDIuOSA2LjYgNS4yIDEwLjQgNS4yIDIuNiAwIDMgMC4zIDMgMi44IDAgNC43IDQgMTcuMyA3LjYgMjQuMiAxLjkgMy42IDUuNCA4LjkgNy45IDExLjcgbDQuNiA1LjIgLTMuMSAxLjYgYy0zLjMgMS43IC0zLjQgMi40IC0zIDI0LjEgbDAuMiA5LjEgLTUuMSA1LjggYy0yLjggMy4yIC01LjEgNi4xIC01LjEgNi40IDAgMC40IDIuMyAzLjEgNSA2LjEgMyAzLjMgNSA2LjQgNSA3LjggMCAxLjMgLTEuOSA0LjMgLTQuNSA3LjEgLTIuNSAyLjYgLTQuNSA1LjQgLTQuNSA2LjEgMCAwLjcgMiAzLjUgNC41IDYuMSA0LjQgNC43IDQuNSA0LjkgNC41IDExLjYgbDAgNi43IC03LjkgNy44IGMtNC41IDQuNCAtOC44IDcuOCAtOS45IDcuOCAtMS4xIDAgLTUuMiAtMyAtOS4xIC02Ljh6XCIvPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yNTQuMyAzMDMuOCBsLTcuMyAtNy4xIDAgLTQ3LjkgMCAtNDcuOSAtMy41IC0yIGMtMS45IC0xLjIgLTMuNSAtMi4yIC0zLjUgLTIuMyAwIC0wLjEgMi4xIC0yLjQgNC44IC01LjIgOC4yIC04LjYgMTQuMSAtMjIuOCAxNC4yIC0zNC4xIGwwIC00LjMgNC42IDAgYzMuOSAwIDUuMSAtMC41IDggLTMuNCAyLjggLTIuOCAzLjQgLTQuMiAzLjQgLTcuNiAwIC05LjYgLTguMSAtMTQuNiAtMTcuMSAtMTAuNiAtMS4zIDAuNiAtMi41IC0wLjcgLTUuMyAtNiAtMy45IC03LjQgLTMuOCAtNy42IDIuNCAtOS40IDcuNCAtMi4xIDIwIC0wLjUgMjguOCAzLjcgMTAuNCA0LjkgMjAuNyAxOS40IDIzLjIgMzIuNSAxLjUgNy41IDAuMyAxNy43IC0zIDI1LjMgLTIuNyA2LjQgLTEwLjUgMTUuMSAtMTcgMTkuMSBsLTYgMy43IDAgMTYuMSAwIDE2LjIgLTUuNSA1LjQgLTUuNSA1LjQgNS41IDUuNiBjNyA3LjEgNy4yIDkuMyAxIDE1LjkgLTIuNSAyLjYgLTQuNSA1LjUgLTQuNSA2LjIgMCAwLjggMiAzLjUgNC41IDUuOSA0LjUgNC40IDQuNSA0LjQgNC41IDExLjUgbDAgNy4yIC03LjkgNy42IGMtNC4zIDQuMiAtOC43IDcuNyAtOS43IDcuNyAtMS4xIDAgLTUuMiAtMy4yIC05LjEgLTcuMnpcIi8+XHJcbiAgICAgICAgICAgICAgICA8L2c+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGgxIGNsYXNzPVwidGV4dC00eGwgbWQ6dGV4dC01eGwgZm9udC1ib2xkIG1iLTQgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICBAaWYgKGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkud2hpdGVsYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIEBpZiAoY29uZmlnU2VydmljZS5jb25maWcoKS51c2VUcmFkZU1hcmspIHtcclxuICAgICAgICAgICAgICAgICAgICBTdGFydCBhIFNpZ25pbmcgUm9vbcKuXHJcbiAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBMYXVuY2ggU2lnbmluZyBSb29twq5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvaDE+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC1sZ1wiPnt7IGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkudGFnbGluZSB9fTwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8IS0tIEFjdGlvbiBDYXJkIC0tPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIHJlbGF0aXZlIHotMTAgZmxleCBqdXN0aWZ5LWNlbnRlciBtYXgtdy14bFwiPiBcclxuICAgICAgICA8ZGl2IGlkPVwiY2FyZC1oZXJvLXdlbGNvbWVcIiBjbGFzcz1cImJnLWJyYW5kLWNhcmQvNTAgYmFja2Ryb3AtYmx1ci1zbSBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtMnhsIHAtOCBmbGV4IGZsZXgtY29sIGhvdmVyOmJvcmRlci1icmFuZC1hY2NlbnQvMzAgdHJhbnNpdGlvbi1hbGwgZ3JvdXAgdy1mdWxsIHNoYWRvdy0yeGxcIj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC01IG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTQgaC0xNCBiZy1icmFuZC1hY2NlbnQvMTAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgc2hyaW5rLTAgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgIEBpZiAoY29uZmlnU2VydmljZS5jb25maWcoKS53aGl0ZWxhYmVsKSB7XHJcbiAgICAgICAgICAgICAgICA8aW1nIFtzcmNdPVwiY29uZmlnU2VydmljZS5jb25maWcoKS5sb2dvVXJsXCIgW2FsdF09XCJjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kTmFtZVwiIGNsYXNzPVwidy04IGgtOCBvYmplY3QtY29udGFpblwiIC8+XHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZpZXdCb3g9XCIwIDAgNDA5IDQ0NVwiIGNsYXNzPVwidy03IGgtNyB0ZXh0LWJyYW5kLWFjY2VudCBmaWxsLWN1cnJlbnRcIiBwcmVzZXJ2ZUFzcGVjdFJhdGlvPVwieE1pZFlNaWQgbWVldFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTg1LjUgNDI1LjcgYy0zNS40IC0xNy4zIC03MiAtNDMuNCAtOTguMiAtNjkuOSAtMzEuNiAtMzEuOSAtNTAuMyAtNjIuNSAtNTkuMSAtOTYuOCAtNS42IC0yMS43IC01LjcgLTIzLjQgLTUuNyAtMTAxIDAgLTY2LjYgMC4xIC03MS43IDEuOCAtNzUuMSAyLjMgLTQuNiA2LjEgLTYuNyAyMi4yIC0xMi4yIDcuMiAtMi41IDMxLjkgLTExLjMgNTUgLTE5LjcgNzkuNCAtMjguNyA5Ny42IC0zNSAxMDAuNCAtMzUgMi44IDAgMjcuNSA4LjMgNTMuNiAxOCAyMS4zIDcuOSA3MC42IDI1LjcgOTIgMzMuMSAxMSAzLjkgMjEuNCA3LjUgMjMgOC4xIDQuNCAxLjYgOC40IDUuNyA5LjUgOS43IDEuMyA0LjkgMS4zIDEzNi44IDAgMTQ4LjYgLTQuOSA0Mi42IC0yMS4yIDc2LjEgLTU1LjEgMTEzLjEgLTIxIDIzIC00OS43IDQ2IC03OS40IDYzLjkgLTE1LjkgOS42IC00MC4xIDIxLjUgLTQzLjYgMjEuNSAtMi4xIDAgLTguMiAtMi4zIC0xNi40IC02LjN6IG0yNC42IC0yOC44IGMzMS40IC0xNS43IDcxLjcgLTQ1LjYgOTIgLTY4IDI2LjkgLTI5LjggMzkuMyAtNTIgNDcuMiAtODQuNCAyLjEgLTguOCAyLjIgLTEwLjMgMi4yIC03Ni45IGwwIC02Ny45IC0xNyAtNi4yIGMtNDguNSAtMTcuNyAtODQuNiAtMzAuNiAtMTE2IC00MS42IGwtMTYuOSAtNiAtMjAuMSA3LjEgYy0xMSA0IC0yNi41IDkuNiAtMzQuNSAxMi41IC04IDIuOSAtMTguMyA2LjcgLTIzIDguMyAtMTEuNiA0IC0zNi4yIDEyLjkgLTQzLjUgMTUuNyAtMy4zIDEuMyAtMTAuOSA0IC0xNyA2LjEgLTYgMi4xIC0xMS4yIDQuMSAtMTEuNSA0LjUgLTEgMS40IC0xIDExMy4zIC0wLjEgMTI0LjkgMC41IDYuMyAxLjcgMTUuMSAyLjYgMTkuNSAxMC42IDUyLjEgNTIuMiAxMDEuNCAxMTkgMTQxIDExLjQgNi44IDI3IDE1LjMgMjguMyAxNS41IDAuMSAwIDMuOSAtMS44IDguMyAtNC4xelwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTE5MS4zIDMxOC4zIGMtNy42IC03LjQgLTguMSAtOC4xIC04LjYgLTEyLjggLTAuMiAtMi43IC0wLjUgLTI3LjkgLTAuNiAtNTUuOSAwIC0yOCAtMC4yIC01MSAtMC4zIC01MS4xIC0wLjIgLTAuMSAtMi41IC0xLjQgLTUuMSAtMi45IC03IC00IC0xMS4xIC04IC0xNi4xIC0xNS40IC01LjkgLTguOSAtOC42IC0xNy41IC04LjYgLTI3LjEgMCAtMjcgMTkuNSAtNDguNSA0NS45IC01MC43IDEzIC0xLjEgMjYuMSAzLjUgMzYuNiAxMi45IDE5LjggMTcuNiAyMS44IDUwLjMgNC40IDcwLjEgLTQuMSA0LjYgLTE0LjggMTIuNiAtMTYuOCAxMi42IC0wLjcgMCAtMS4xIDYuMyAtMS4xIDE5IGwwIDE5IC02LjEgNi42IC02IDYuNyA2IDYuMSBjOC4yIDguMyA4LjIgMTAuMSAwIDE4LjMgbC02IDYgNiA1LjggNi4xIDUuOCAwIDguMyAwIDguMiAtOSA5LjEgYy01IDUgLTkuOSA5LjEgLTEwLjkgOS4xIC0xIDAgLTUuNCAtMy41IC05LjggLTcuN3ogbTE3LjcgLTE3NSBjMy42IC0yLjQgNC44IC00LjMgNS41IC04LjMgMSAtNS43IC0xLjQgLTExLjEgLTYgLTEzLjcgLTQuOSAtMi44IC04LjQgLTIuOSAtMTMuNCAtMC4zIC0zLjggMS45IC00LjUgMi44IC02LjIgOC40IC0xLjIgNC4xIDAuOCAxMC4yIDQuNCAxMy4yIDMuNiAzIDExLjggMy40IDE1LjcgMC43elwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEzMC4xIDMwNC4yIGwtNy4xIC02LjcgMCAtNDguMiAwIC00OC4yIC01LjUgLTMuNSBjLTM2LjYgLTIzLjUgLTIzLjcgLTc5LjQgMTkuMSAtODIuNCA2LjUgLTAuNCAxNy40IDEuMiAxNy40IDIuNSAwIDAuMyAtMS41IDMuNiAtMy4yIDcuNCAtMi40IDUgLTMuNyA2LjYgLTQuOCA2LjIgLTAuOCAtMC40IC0zLjYgLTAuOCAtNi4zIC0xLjEgLTQuMyAtMC40IC01IC0wLjEgLTguMiAzLjEgLTIuOSAyLjkgLTMuNSA0LjIgLTMuNSA3LjkgMCAyLjQgMC43IDUuNCAxLjYgNi42IDIgMi45IDYuNiA1LjIgMTAuNCA1LjIgMi42IDAgMyAwLjMgMyAyLjggMCA0LjcgNCAxNy4zIDcuNiAyNC4yIDEuOSAzLjYgNS40IDguOSA3LjkgMTEuNyBsNC42IDUuMiAtMy4xIDEuNiBjLTMuMyAxLjcgLTMuNCAyLjQgLTMgMjQuMSBsMC4yIDkuMSAtNS4xIDUuOCBjLTIuOCAzLjIgLTUuMSA2LjEgLTUuMSA2LjQgMCAwLjQgMi4zIDMuMSA1IDYuMSAzIDMuMyA1IDYuNCA1IDcuOCAwIDEuMyAtMS45IDQuMyAtNC41IDcuMSAtMi41IDIuNiAtNC41IDUuNCAtNC41IDYuMSAwIDAuNyAyIDMuNSA0LjUgNi4xIDQuNCA0LjcgNC41IDQuOSA0LjUgMTEuNiBsMCA2LjcgLTcuOSA3LjggYy00LjUgNC40IC04LjggNy44IC05LjkgNy44IC0xLjEgMCAtNS4yIC0zIC05LjEgLTYuOHpcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yNTQuMyAzMDMuOCBsLTcuMyAtNy4xIDAgLTQ3LjkgMCAtNDcuOSAtMy41IC0yIGMtMS45IC0xLjIgLTMuNSAtMi4yIC0zLjUgLTIuMyAwIC0wLjEgMi4xIC0yLjQgNC44IC01LjIgOC4yIC04LjYgMTQuMSAtMjIuOCAxNC4yIC0zNC4xIGwwIC00LjMgNC42IDAgYzMuOSAwIDUuMSAtMC41IDggLTMuNCAyLjggLTIuOCAzLjQgLTQuMiAzLjQgLTcuNiAwIC05LjYgLTguMSAtMTQuNiAtMTcuMSAtMTAuNiAtMS4zIDAuNiAtMi41IC0wLjcgLTUuMyAtNiAtMy45IC03LjQgLTMuOCAtNy42IDIuNCAtOS40IDcuNCAtMi4xIDIwIC0wLjUgMjguOCAzLjcgMTAuNCA0LjkgMjAuNyAxOS40IDIzLjIgMzIuNSAxLjUgNy41IDAuMyAxNy43IC0zIDI1LjMgLTIuNyA2LjQgLTEwLjUgMTUuMSAtMTcgMTkuMSBsLTYgMy43IDAgMTYuMSAwIDE2LjIgLTUuNSA1LjQgLTUuNSA1LjQgNS41IDUuNiBjNyA3LjEgNy4yIDkuMyAxIDE1LjkgLTIuNSAyLjYgLTQuNSA1LjUgLTQuNSA2LjIgMCAwLjggMiAzLjUgNC41IDUuOSA0LjUgNC40IDQuNSA0LjQgNC41IDExLjUgbDAgNy4yIC03LjkgNy42IGMtNC4zIDQuMiAtOC43IDcuNyAtOS43IDcuNyAtMS4xIDAgLTUuMiAtMy4yIC05LjEgLTcuMnpcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9nPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICB7eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kTmFtZSB9fTxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnRcIj57eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kU3VmZml4IHx8ICcnIH19PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtYnJhbmQtYWNjZW50LzcwIHRleHQteHMgZm9udC1tb25vIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj57eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLnN1YlRhZ2xpbmUgfX08L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8dWwgY2xhc3M9XCJzcGFjZS15LTQgbWItMTAgZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgIDxsaSBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVjayBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz4gXHJcbiAgICAgICAgICAgICAgPHNwYW4+U3RhdGVsZXNzIEJsaW5kIFJlbGF5IChSQU0tT25seSk8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVjayBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz4gXHJcbiAgICAgICAgICAgICAgPHNwYW4+RW5kLXRvLUVuZCBBRVMtR0NNIEVuY3J5cHRpb248L3NwYW4+XHJcbiAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgIDxsaSBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc2xhdGUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVjayBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz4gXHJcbiAgICAgICAgICAgICAgPHNwYW4+Q2VyZW1vbnkgQXVkaXQgTG9nczwvc3Bhbj5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tc3RhcnQtY2VyZW1vbnlcIiAoY2xpY2spPVwic2hvd0NyZWF0ZU1vZGFsLnNldCh0cnVlKVwiIGNsYXNzPVwidy1mdWxsIHB5LTQgYmctYnJhbmQtYWNjZW50IGhvdmVyOmJnLWJyYW5kLWFjY2VudC1ob3ZlciB0ZXh0LWJyYW5kLWJnIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24gc2hhZG93LWxnIHNoYWRvdy1icmFuZC1hY2NlbnQvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZ3JvdXAvYnRuIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy00IGgtNCBmaWxsLWJyYW5kLWJnIGdyb3VwLWhvdmVyL2J0bjpzY2FsZS0xMjUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj48L3N2Zz5cclxuICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICBAaWYgKGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkudXNlVHJhZGVNYXJrKSB7XHJcbiAgICAgICAgICAgICAgICBTdGFydCBhIFNpZ25pbmcgUm9vbcKuXHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgIFN0YXJ0XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgfVxyXG5cclxuICAgIEBpZiAoaXNFbWJlZGRlZCkge1xyXG4gICAgICA8ZGl2IGlkPVwidmlldy1jcmVhdGUtZW1iZWRkZWRcIiBjbGFzcz1cInctZnVsbCBtYXgtdy14bCB6LTEwIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgICAgIFxyXG4gICAgICAgIEBpZiAocHNidEFuYWx5c2lzKCkpIHtcclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzMwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctMnhsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGQgY2xhc3M9XCJ3LTYgaC02IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14bFwiPkNvbmZpcm0gQ2VyZW1vbnk8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgaWQ9XCJjYXJkLXBzYnQtc3VtbWFyeVwiIGNsYXNzPVwiYmctYnJhbmQtYmcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLXhsIHAtNSBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIHVwcGVyY2FzZSBmb250LWJvbGQgdHJhY2tpbmctd2lkZXN0IG1iLTFcIj5Ub3RhbCBBbW91bnQ8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItNFwiPnt7IHBzYnRBbmFseXNpcygpPy5hbW91bnRCdGMgfX0gPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC1sZ1wiPkJUQzwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgYmxvY2tcIj5TaWduZXJzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtd2hpdGUgZm9udC1ib2xkXCI+e3sgcHNidEFuYWx5c2lzKCk/LnNpZ25lckNvdW50IH19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBibG9ja1wiPk5ldHdvcms8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnQgZm9udC1ib2xkIGNhcGl0YWxpemVcIj57eyBzZWxlY3RlZE5ldHdvcmsoKSB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tbGF1bmNoLXJvb21cIiAoY2xpY2spPVwibGF1bmNoUm9vbSgpXCIgW2Rpc2FibGVkXT1cImlzTG9hZGluZygpXCIgY2xhc3M9XCJ3LWZ1bGwgcHktNCBiZy1icmFuZC1hY2NlbnQgdGV4dC1icmFuZC1iZyBmb250LWJvbGQgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBob3ZlcjpiZy1icmFuZC1hY2NlbnQtaG92ZXIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgQGlmIChpc0xvYWRpbmcoKSkgeyBcclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUxvYWRlcjIgY2xhc3M9XCJ3LTQgaC00IGFuaW1hdGUtc3BpblwiPjwvc3ZnPiBcclxuICAgICAgICAgICAgICAgICAgICBTZWN1cmluZyBSb29tLi4uXHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkudXNlVHJhZGVNYXJrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnQgYSBTaWduaW5nIFJvb23CrlxyXG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1jbGVhci1wc2J0XCIgKGNsaWNrKT1cImNsZWFyUHNidCgpXCIgY2xhc3M9XCJ3LWZ1bGwgbXQtMyB0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5DYW5jZWwgYW5kIGdvIGJhY2s8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH0gXHJcbiAgICAgICAgQGVsc2Uge1xyXG4gICAgICAgICAgPCEtLSBFbWJlZGRlZCBKb2luIENhcmQgLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIHJlbGF0aXZlIHotMTAgZmxleCBqdXN0aWZ5LWNlbnRlciBtYXgtdy14bFwiPiBcclxuICAgICAgICAgICAgPGRpdiBpZD1cImNhcmQtZW1iZWRkZWQtam9pblwiIGNsYXNzPVwiYmctYnJhbmQtY2FyZC81MCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC0yeGwgcC04IGZsZXggZmxleC1jb2wgaG92ZXI6Ym9yZGVyLWJyYW5kLWFjY2VudC8zMCB0cmFuc2l0aW9uLWFsbCBncm91cCB3LWZ1bGwgc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNCBoLTE0IGJnLWJyYW5kLWFjY2VudC8xMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8yMCBzaHJpbmstMCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbWcgW3NyY109XCJjb25maWdTZXJ2aWNlLmNvbmZpZygpLmxvZ29VcmxcIiBbYWx0XT1cImNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuYnJhbmROYW1lXCIgY2xhc3M9XCJ3LTggaC04IG9iamVjdC1jb250YWluXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kTmFtZSB9fTxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnRcIj57eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kU3VmZml4IHx8ICcnIH19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnQvNzAgdGV4dC14cyBmb250LW1vbm8gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdFwiPnt7IGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuc3ViVGFnbGluZSB9fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0LW11dGVkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlJvb20gSUQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1bMTBweF0gZm9udC1tb25vXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtcmVkLTQwMF09XCJtYW51YWxSb29tSWQubGVuZ3RoID49IDM2XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYnJhbmQtdGV4dC1tdXRlZF09XCJtYW51YWxSb29tSWQubGVuZ3RoIDwgMzZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt7IG1hbnVhbFJvb21JZC5sZW5ndGggfX0gLyAzNlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cImlucHV0LWpvaW4tcm9vbS1pZFwiIFt0eXBlXT1cInNob3dNYW51YWxSb29tSWQgPyAndGV4dCcgOiAncGFzc3dvcmQnXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIFsobmdNb2RlbCldPVwibWFudWFsUm9vbUlkXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGxlbmd0aD1cIjM2XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGFzdGUgUm9vbSBJRC4uLlwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvY29tcGxldGU9XCJvZmZcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS0xcC1pZ25vcmU9XCJ0cnVlXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtbHBpZ25vcmU9XCJ0cnVlXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtYndpZ25vcmU9XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgYmctYnJhbmQtYmcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLWxnIHAtMyBwci0xMCB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtYWNjZW50IHRyYW5zaXRpb25cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi10b2dnbGUtcm9vbS1pZC12aXNpYmlsaXR5XCIgKGNsaWNrKT1cInNob3dNYW51YWxSb29tSWQgPSAhc2hvd01hbnVhbFJvb21JZFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJhYnNvbHV0ZSByaWdodC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNob3dNYW51YWxSb29tSWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWVPZmYgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWUgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5EZWNyeXB0aW9uIEtleTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm9cIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1yZWQtNDAwXT1cIm1hbnVhbEtleS5sZW5ndGggPj0gNDRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0LW11dGVkXT1cIm1hbnVhbEtleS5sZW5ndGggPCA0NFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3sgbWFudWFsS2V5Lmxlbmd0aCB9fSAvIDQ0XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IGlkPVwiaW5wdXQtam9pbi1rZXlcIiBbdHlwZV09XCJzaG93TWFudWFsS2V5ID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBbKG5nTW9kZWwpXT1cIm1hbnVhbEtleVwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhsZW5ndGg9XCI0NFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBhc3RlIEtleS4uLlwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvY29tcGxldGU9XCJvZmZcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS0xcC1pZ25vcmU9XCJ0cnVlXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtbHBpZ25vcmU9XCJ0cnVlXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGEtYndpZ25vcmU9XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgYmctYnJhbmQtYmcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLWxnIHAtMyBwci0xMCB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtYWNjZW50IHRyYW5zaXRpb25cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi10b2dnbGUta2V5LXZpc2liaWxpdHlcIiAoY2xpY2spPVwic2hvd01hbnVhbEtleSA9ICFzaG93TWFudWFsS2V5XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc2hvd01hbnVhbEtleSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZU9mZiBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZSBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1qb2luLWV4aXN0aW5nLXJvb21cIlxyXG4gICAgICAgICAgICAgICAgICAoY2xpY2spPVwiam9pblJvb20oKVwiIFxyXG4gICAgICAgICAgICAgICAgICBbZGlzYWJsZWRdPVwibWFudWFsUm9vbUlkLmxlbmd0aCAhPT0gMzYgfHwgbWFudWFsS2V5Lmxlbmd0aCAhPT0gNDRcIiBcclxuICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgcHktNCBiZy1icmFuZC1hY2NlbnQgaG92ZXI6YmctYnJhbmQtYWNjZW50LWhvdmVyIHRleHQtYnJhbmQtYmcgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBzaGFkb3ctbGcgc2hhZG93LWJyYW5kLWFjY2VudC8yMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBncm91cC9idG4gZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy00IGgtNCBmaWxsLWJyYW5kLWJnIHRyYW5zaXRpb24tdHJhbnNmb3JtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuZ3JvdXAtaG92ZXIvYnRuOnNjYWxlLTEyNV09XCJtYW51YWxSb29tSWQubGVuZ3RoID09PSAzNiAmJiBtYW51YWxLZXkubGVuZ3RoID09PSA0NFwiPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkVudGVyIHt7IGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuYnJhbmROYW1lIH19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIH1cclxuICB9XHJcbjwvZGl2PlxyXG5cclxuPCEtLSBNb2RhbCBEaWFsb2cgLS0+XHJcbkBpZiAoc2hvd0NyZWF0ZU1vZGFsKCkpIHtcclxuICA8ZGl2IGlkPVwibW9kYWwtY29uZmlndXJlLXJvb21cIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMTAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy85MCBiYWNrZHJvcC1ibHVyLXhsIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBwLTggcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1sZyB3LWZ1bGwgcmVsYXRpdmVcIj5cclxuICAgICAgQGlmICghaXNFbWJlZGRlZCkge1xyXG4gICAgICAgIDxidXR0b24gaWQ9XCJidG4tbW9kYWwtY2xvc2VcIiAoY2xpY2spPVwic2hvd0NyZWF0ZU1vZGFsLnNldChmYWxzZSlcIiBjbGFzcz1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtd2hpdGUgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgIDxzdmcgbHVjaWRlWCBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgfVxyXG4gICAgICA8aDIgY2xhc3M9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi02XCI+XHJcbiAgICAgICAgQGlmIChjb25maWdTZXJ2aWNlLmNvbmZpZygpLnVzZVRyYWRlTWFyaykge1xyXG4gICAgICAgICAgICBDb25maWd1cmUgU2lnbmluZyBSb29twq5cclxuICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgQ29uZmlndXJlXHJcbiAgICAgICAgfVxyXG4gICAgICA8L2gyPlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cIm1iLTZcIj5cclxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTJcIj5OZXR3b3JrPC9sYWJlbD5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxyXG4gICAgICAgICAgQGZvciAobmV0IG9mIG5ldHdvcmtzOyB0cmFjayBuZXQpIHtcclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cInNlbGVjdC1uZXR3b3JrLXt7IG5ldCB9fVwiIChjbGljayk9XCJzZWxlY3RlZE5ldHdvcmsuc2V0KG5ldClcIiBcclxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInB5LTIgcHgtMyByb3VuZGVkLWxnIHRleHQtc20gZm9udC1ib2xkIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjYXBpdGFsaXplIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYWNjZW50XzIwXT1cInNlbGVjdGVkTmV0d29yaygpID09PSBuZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ib3JkZXItYnJhbmQtYWNjZW50XT1cInNlbGVjdGVkTmV0d29yaygpID09PSBuZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLWFjY2VudF09XCJzZWxlY3RlZE5ldHdvcmsoKSA9PT0gbmV0XCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYmddPVwic2VsZWN0ZWROZXR3b3JrKCkgIT09IG5ldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJvcmRlci1icmFuZC1jYXJkLWJvcmRlcl09XCJzZWxlY3RlZE5ldHdvcmsoKSAhPT0gbmV0XCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0LW11dGVkXT1cInNlbGVjdGVkTmV0d29yaygpICE9PSBuZXRcIj5cclxuICAgICAgICAgICAgICB7eyBuZXQgfX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLXhsIHAtNiBtYi02XCI+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTIgdGV4dC1icmFuZC10ZXh0LW11dGVkXCI+VHJhbnNhY3Rpb24gRGF0YSAoUmVxdWlyZWQpPC9sYWJlbD5cclxuXHJcbiAgICAgICAgQGlmICghcHNidEFuYWx5c2lzKCkpIHtcclxuICAgICAgICAgIEBpZiAoZXJyb3JNZXNzYWdlKCkpIHtcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1iLTYgcC00IGJnLXJvc2UtNTAwLzEwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIGFuaW1hdGUtaW4gZmFkZS1pbiBzbGlkZS1pbi1mcm9tLXRvcC0yXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy01IGgtNSB0ZXh0LXJvc2UtNDAwIHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzcz1cInRleHQtc20gZm9udC1ib2xkIHRleHQtcm9zZS0zMDAgbWItMVwiPlByb2Nlc3NpbmcgRmFpbGVkPC9oND5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LXJvc2UtMjAwLzgwIGxlYWRpbmctcmVsYXhlZFwiPnt7IGVycm9yTWVzc2FnZSgpIH19PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtYi0yIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgPGRpdiBpZD1cImJ0bi11cGxvYWQtcHNidC1maWxlXCIgY2xhc3M9XCJyZWxhdGl2ZSBncm91cCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTggYmctYnJhbmQtYmcgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC14bCBob3Zlcjpib3JkZXItYnJhbmQtYWNjZW50LzUwIGhvdmVyOmJnLWJyYW5kLWFjY2VudC81IHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyXCIgW2NsYXNzLm9wYWNpdHktNTBdPVwiaXNTY2FubmluZygpXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0IGlkPVwiaW5wdXQtcHNidC1maWxlXCIgdHlwZT1cImZpbGVcIiAoY2hhbmdlKT1cIm9uRmlsZVNlbGVjdGVkKCRldmVudClcIiBhY2NlcHQ9XCIucHNidCwudHh0LC5oZXhcIiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgb3BhY2l0eS0wIGN1cnNvci1wb2ludGVyIHotMTBcIiBbZGlzYWJsZWRdPVwiaXNTY2FubmluZygpXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgcC0zIHJvdW5kZWQtZnVsbCBtYi0zIGdyb3VwLWhvdmVyOmJnLWJyYW5kLWFjY2VudC8yMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVcGxvYWRDbG91ZCBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uLWNvbG9yc1wiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMFwiPlVwbG9hZCBQU0JUIEZpbGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtdC0xXCI+LnBzYnQsIC50eHQsIG9yIC5oZXg8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1zY2FuLXBzYnQtcXJcIiAoY2xpY2spPVwic3RhcnRTY2FubmVyKClcIiBbZGlzYWJsZWRdPVwiaXNTY2FubmluZygpXCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTggYmctYnJhbmQtYmcgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC14bCBob3Zlcjpib3JkZXItYnJhbmQtYWNjZW50LzUwIGhvdmVyOmJnLWJyYW5kLWFjY2VudC81IHRyYW5zaXRpb24tYWxsIGdyb3VwIGRpc2FibGVkOm9wYWNpdHktNTAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtY2FyZCBwLTMgcm91bmRlZC1mdWxsIG1iLTMgZ3JvdXAtaG92ZXI6YmctYnJhbmQtYWNjZW50LzIwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVFyQ29kZSBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uLWNvbG9yc1wiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTIwMFwiPlNjYW4gUVIgQ29kZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIG10LTFcIj5BaXItZ2FwcGVkIGhhcmR3YXJlIG9wdGljczwvc3Bhbj5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICBAaWYgKGlzU2Nhbm5pbmcoKSkge1xyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tdG9wLTQgZHVyYXRpb24tMzAwIG10LTYgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LWZ1bGwgYmctYnJhbmQtYWNjZW50LzEwIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzIwIHJvdW5kZWQtbGcgcC0zIG1iLTYgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGQgY2xhc3M9XCJ3LTUgaC01IHRleHQtYnJhbmQtYWNjZW50IHNocmluay0wIG10LTAuNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0IGxlYWRpbmctcmVsYXhlZCBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5TZWN1cmUgU2Nhbm5lcjo8L3N0cm9uZz4gSG9sZCB5b3VyIGhhcmR3YXJlIHdhbGxldCBkaXNwbGF5aW5nIFBTQlQgUVIgQ29kZSB1cCB0byB0aGUgY2FtZXJhLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1bMTFweF0gdGV4dC1icmFuZC1hY2NlbnQgZm9udC1tZWRpdW0gYmctYnJhbmQtYWNjZW50LzEwIHAtMiByb3VuZGVkIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg8J+SoSA8c3Ryb25nPlRpcDo8L3N0cm9uZz4gU29tZXRpbWVzIFFSIGNvZGVzIGFyZSB0b28gc21hbGwgZm9yIHdlYmNhbXMgdG8gcmVhZCBvZmYgYSBoYXJkd2FyZSBkZXZpY2UuIFlvdSBjYW4gdXNlIGEgbW9iaWxlIGNvbXBhbmlvbiBhcHBsaWNhdGlvbiB0byBzY2FuIHRoZSBoYXJkd2FyZSB3YWxsZXQsIGFuZCB0aGVuIGV4cG9ydCB0aGUgU2lnbmVkIFBTQlQgdG8ge3sgY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWUgfX0gdGhyb3VnaCB0aGlzIHJlYWRlci5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LWZ1bGwgbWItNCBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgcC0yLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1bMTBweF0gdGV4dC1icmFuZC10ZXh0LW11dGVkIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5SYXcgT3B0aWNhbCBGZWVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtWzEwcHhdIHRleHQtYnJhbmQtYWNjZW50IGZvbnQtbW9ubyB0cnVuY2F0ZSBtYXgtdy1bMjAwcHhdXCIgW3RpdGxlXT1cInVyU2VydmljZS5sYXN0U2Nhbm5lZFRleHQoKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7IHVyU2VydmljZS5sYXN0U2Nhbm5lZFRleHQoKSB8fCAnV2FpdGluZyBmb3IgUVIuLi4nIH19XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBAaWYgKHVyU2VydmljZS5zY2FuRXJyb3IoKSkge1xyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctcm9zZS01MDAvMTAgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMCByb3VuZGVkLWxnIHAtMi41IGZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy00IGgtNCB0ZXh0LXJvc2UtNDAwIHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIHRleHQtcm9zZS0zMDBcIj57eyB1clNlcnZpY2Uuc2NhbkVycm9yKCkgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGlkPVwiY2FyZC1wc2J0LXNjYW5uZXJcIiBjbGFzcz1cInJlbGF0aXZlIGJnLWJsYWNrIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzMwIHNoYWRvdy1bMF8wXzE1cHhfdmFyKC0td2wtYWNjZW50KV0gbXQtNiBhbmltYXRlLWluIGZhZGUtaW4gc2xpZGUtaW4tZnJvbS10b3AtNCBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJyZWFkZXJcIiBjbGFzcz1cInctZnVsbCBoLTcyIG9iamVjdC1jb3ZlclwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lIHotMTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgdy01NiBoLTU2IHJvdW5kZWQteGwgc2hhZG93LVswXzBfMF85OTk5cHhfcmdiYSgwLDAsMCwwLjgpXSBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8zMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgdy02IGgtNiBib3JkZXItdC0yIGJvcmRlci1sLTIgYm9yZGVyLWJyYW5kLWFjY2VudCByb3VuZGVkLXRsLXhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy02IGgtNiBib3JkZXItdC0yIGJvcmRlci1yLTIgYm9yZGVyLWJyYW5kLWFjY2VudCByb3VuZGVkLXRyLXhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCB3LTYgaC02IGJvcmRlci1iLTIgYm9yZGVyLWwtMiBib3JkZXItYnJhbmQtYWNjZW50IHJvdW5kZWQtYmwteGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCB3LTYgaC02IGJvcmRlci1iLTIgYm9yZGVyLXItMiBib3JkZXItYnJhbmQtYWNjZW50IHJvdW5kZWQtYnIteGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgbGVmdC0wIHJpZ2h0LTAgaC1bMnB4XSBiZy1icmFuZC1hY2NlbnQgc2hhZG93LVswXzBfOHB4XzJweF92YXIoLS13bC1hY2NlbnQpXSBzY2FubmVyLWxhc2VyXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgQGlmICh1clNlcnZpY2Uuc2NhblByb2dyZXNzKCkgPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgcmlnaHQtMCBiZy1icmFuZC1jYXJkLzk1IGJhY2tkcm9wLWJsdXItc20gcC0zIGJvcmRlci10IGJvcmRlci1icmFuZC1hY2NlbnQvMzAgei0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtYnJhbmQtYWNjZW50IGZvbnQtYm9sZCBtYi0yIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5SRUNPTlNUUlVDVElORyBQU0JULi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgKHVyU2VydmljZS5zY2FuUHJvZ3Jlc3MoKSAqIDEwMCkudG9GaXhlZCgwKSB9fSU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1iZyByb3VuZGVkLWZ1bGwgaC0xLjUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtYWNjZW50IGgtMS41IHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZWFzZS1vdXRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgW3N0eWxlLndpZHRoLiVdPVwidXJTZXJ2aWNlLnNjYW5Qcm9ncmVzcygpICogMTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXN0b3Atc2Nhbm5lclwiIChjbGljayk9XCJzdG9wU2Nhbm5lcigpXCIgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHotMjAgdGV4dC1icmFuZC10ZXh0LW11dGVkIGJnLWJyYW5kLWNhcmQvODAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1yZWQtNTAwLzkwIHAtMi41IHJvdW5kZWQtZnVsbCB0cmFuc2l0aW9uLWFsbCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgaG92ZXI6Ym9yZGVyLXJlZC01MDAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBweS02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LWdyb3cgYm9yZGVyLXQgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyXCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZmxleC1zaHJpbmstMCBteC00IHRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPk9yIHBhc3RlIGRpcmVjdGx5PC9zcGFuPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleC1ncm93IGJvcmRlci10IGJvcmRlci1icmFuZC1jYXJkLWJvcmRlclwiPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIDx0ZXh0YXJlYSBpZD1cImlucHV0LXBzYnQtdGV4dFwiXHJcbiAgICAgICAgICAgICAgY2xhc3M9XCJ3LWZ1bGwgYmctYnJhbmQtYmcvNTAgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQgcm91bmRlZC1sZyBwLTQgZm9udC1tb25vIHRleHQteHMgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctYnJhbmQtYWNjZW50LzUwIGZvY3VzOmJvcmRlci1icmFuZC1hY2NlbnQvNTAgdHJhbnNpdGlvbi1jb2xvcnMgcmVzaXplLW5vbmUgcGxhY2Vob2xkZXItYnJhbmQtdGV4dC1tdXRlZFwiIFxyXG4gICAgICAgICAgICAgIHJvd3M9XCI0XCIgXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJQYXN0ZSByYXcgUFNCVCBCYXNlNjQgb3IgSGV4IHN0cmluZyBoZXJlLi4uXCJcclxuICAgICAgICAgICAgICBbKG5nTW9kZWwpXT1cInJhd0hleFwiIChuZ01vZGVsQ2hhbmdlKT1cImFuYWx5emVSYXdIZXgoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgW2Rpc2FibGVkXT1cImlzU2Nhbm5pbmcoKVwiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlRWRpdDIgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHRleHQtYnJhbmQtdGV4dC1tdXRlZCBwb2ludGVyLWV2ZW50cy1ub25lIHctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgIDwhLS0gUFNCVCBBbmFseXNpcyBTdW1tYXJ5IC0tPlxyXG4gICAgICAgICAgPGRpdiBpZD1cImNhcmQtcHNidC1zdW1tYXJ5XCIgY2xhc3M9XCJiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQteGwgcC00IGFuaW1hdGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEwIGgtMTAgYmctYnJhbmQtYWNjZW50LzEwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1icmFuZC1hY2NlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVGaWxlSnNvbiBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtd2hpdGUgdGV4dC1zbSBmb250LWJvbGQgdHJ1bmNhdGUgbWF4LXctWzE1MHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7IHBzYnRGaWxlKCk/Lm5hbWUgfHwgJ0hhbmRsZWQgdmlhIE9wdGljcycgfX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWJyYW5kLWFjY2VudCB0ZXh0LXhzIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7IHBzYnRBbmFseXNpcygpPy5vdXRwdXRDb3VudCB9fSBPdXRwdXRzIGRldGVjdGVkXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgQGlmICghaXNFbWJlZGRlZCkge1xyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1jbGVhci1wc2J0XCIgKGNsaWNrKT1cImNsZWFyUHNidCgpXCIgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1yb3NlLTQwMCBwLTEgcm91bmRlZC1tZCBob3ZlcjpiZy1yb3NlLTQwMC8xMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVggY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtY2FyZCByb3VuZGVkIHAtMiBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1bMTBweF0gdGV4dC1icmFuZC10ZXh0LW11dGVkIHVwcGVyY2FzZSB0cmFja2luZy10aWdodFwiPkFtb3VudDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge3sgcHNidEFuYWx5c2lzKCk/LmFtb3VudEJ0YyB8IG51bWJlcjonMS40LTQnIH19IDxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkXCI+QlRDPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgcm91bmRlZCBwLTIgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtWzEwcHhdIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctdGlnaHRcIj5OZXR3b3JrIEZlZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge3sgcHNidEFuYWx5c2lzKCk/Lm5ldHdvcmtGZWVTYXQgfCBudW1iZXIgfX0gPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj5zYXRzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgcm91bmRlZCBwLTIgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtWzEwcHhdIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctdGlnaHRcIj5TaWduZXJzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7eyBwc2J0QW5hbHlzaXMoKT8uc2lnbmVyQ291bnQgfX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICBAaWYgKGlzTmV0d29ya01pc21hdGNoKCkpIHtcclxuICAgICAgICA8ZGl2IGNsYXNzPVwibWItNCBwLTMgYmctcm9zZS05NTAvMzAgYm9yZGVyIGJvcmRlci1yb3NlLTkwMC81MCByb3VuZGVkLXhsIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgIDxzdmcgbHVjaWRlQWxlcnRUcmlhbmdsZSBjbGFzcz1cInctNSBoLTUgdGV4dC1yb3NlLTUwMCBzaHJpbmstMCBtdC0wLjVcIj48L3N2Zz5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXJvc2UtMjAwIHRleHQteHMgZm9udC1ib2xkIG1iLTFcIj5OZXR3b3JrIE1pc21hdGNoPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1yb3NlLTQwMCB0ZXh0LVsxMHB4XVwiPlxyXG4gICAgICAgICAgICAgIFNlbGVjdGVkOiA8c3Ryb25nPnt7IHNlbGVjdGVkTmV0d29yaygpIHwgdGl0bGVjYXNlIH19PC9zdHJvbmc+LiBcclxuICAgICAgICAgICAgICBQU0JUOiA8c3Ryb25nPnt7IHBzYnRBbmFseXNpcygpPy5kZXRlY3RlZE5ldHdvcmsgfCB0aXRsZWNhc2UgfX08L3N0cm9uZz4uXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICB9XHJcblxyXG4gICAgICBAaWYgKGlzSGlnaEZlZSgpKSB7XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1iLTQgcC0zIGJnLWFtYmVyLTk1MC8zMCBib3JkZXIgYm9yZGVyLWFtYmVyLTkwMC81MCByb3VuZGVkLXhsIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgIDxzdmcgbHVjaWRlQWxlcnRUcmlhbmdsZSBjbGFzcz1cInctNSBoLTUgdGV4dC1hbWJlci01MDAgc2hyaW5rLTAgbXQtMC41XCI+PC9zdmc+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1hbWJlci0yMDAgdGV4dC14cyBmb250LWJvbGQgbWItMVwiPkhpZ2ggRmVlIERldGVjdGVkPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1hbWJlci00MDAgdGV4dC1bMTBweF1cIj5UaGUgbmV0d29yayBmZWUgaXMgdW51c3VhbGx5IGhpZ2ggKD4xMDAgc2F0cy92QiBvciA+NSUgb2YgdG90YWwpLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICB9XHJcblxyXG4gICAgICA8YnV0dG9uIGlkPVwiYnRuLWxhdW5jaC1yb29tXCIgKGNsaWNrKT1cImxhdW5jaFJvb20oKVwiIFtkaXNhYmxlZF09XCJpc0xvYWRpbmcoKSB8fCAhcHNidEFuYWx5c2lzKCkgfHwgaXNOZXR3b3JrTWlzbWF0Y2goKVwiIGNsYXNzPVwidy1mdWxsIHB5LTQgYmctYnJhbmQtYWNjZW50IGhvdmVyOmJnLWJyYW5kLWFjY2VudC1ob3ZlciB0ZXh0LWJyYW5kLWJnIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24gc2hhZG93LWxnIHNoYWRvdy1icmFuZC1hY2NlbnQvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZ3JvdXAvYnRuIGRpc2FibGVkOm9wYWNpdHktNTAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICBAaWYgKGlzTG9hZGluZygpKSB7XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlTG9hZGVyMiBjbGFzcz1cInctNCBoLTQgZmlsbC1icmFuZC1iZyBncm91cC1ob3Zlci9idG46c2NhbGUtMTI1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGFuaW1hdGUtc3BpblwiPjwvc3ZnPlxyXG4gICAgICAgICAgICBDcmVhdGluZy4uLlxyXG4gICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZCBjbGFzcz1cInctNCBoLTQgZmlsbC1icmFuZC1iZyBncm91cC1ob3Zlci9idG46c2NhbGUtMTI1IHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+PC9zdmc+XHJcbiAgICAgICAgICAgIEBpZiAoY29uZmlnU2VydmljZS5jb25maWcoKS51c2VUcmFkZU1hcmspIHtcclxuICAgICAgICAgICAgU3RhcnQgYSBTaWduaW5nIFJvb23CrlxyXG4gICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgU3RhcnRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG59Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBS0EsU0FBUyxXQUFtQixRQUFRLFFBQVEsb0JBQTJCO0FBQ3ZFLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsUUFBUSxjQUFjLHNCQUFzQjtBQUNyRCxTQUFTLG1CQUFtQjtBQUk1QixTQUVFLGFBQ0EsZUFDQSxTQUNBLG1CQUNBLGdCQUNBLHFCQUNBLGNBR0EsV0FDQSxjQUNBLGNBQ0EsbUJBQ0s7QUFDUCxTQUFTLGFBQWEsbUNBQW1DO0E7Ozs7OztBQ3hCckQsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUErSSxHQUFBLE9BQUEsQ0FBQTtBQUkzSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsQ0FBQTtBQUNFLElBQUEsb0JBQUEsQ0FBQTtBQUFzQyxJQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQWdDLElBQUEsb0JBQUEsQ0FBQTtBQUE4QyxJQUFBLDBCQUFBLEVBQU8sRUFDeEg7O0FBR1AsSUFBQSx1QkFBQSxHQUFBLE9BQUEsQ0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxDQUFBO0FBQThELElBQUEsb0JBQUEsR0FBQSxxQkFBQTtBQUFtQixJQUFBLDBCQUFBO0FBQ2pGLElBQUEsNEJBQUEsSUFBQSxLQUFBLENBQUE7QUFBa0QsSUFBQSxvQkFBQSxJQUFBLG9HQUFBO0FBQWtHLElBQUEsMEJBQUEsRUFBSTs7OztBQVJqSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBLDBCQUFBLEVBQXNDLE9BQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBO0FBRXpDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUE7QUFBc0UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLGVBQUEsRUFBQTs7Ozs7QUFrQnBFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7QUFBSyxJQUFBLHdCQUFBLE9BQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBLDBCQUFBLEVBQXNDLE9BQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBOzs7Ozs7QUFFM0MsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFtSixHQUFBLEdBQUE7QUFFL0ksSUFBQSx1QkFBQSxHQUFBLFFBQUEsRUFBQSxFQUFvNkIsR0FBQSxRQUFBLEVBQUEsRUFDL1EsR0FBQSxRQUFBLEVBQUEsRUFDQyxHQUFBLFFBQUEsRUFBQTtBQUV0cEIsSUFBQSwwQkFBQSxFQUFJOzs7OztBQVNBLElBQUEsb0JBQUEsR0FBQSw0QkFBQTs7Ozs7QUFFQSxJQUFBLG9CQUFBLEdBQUEsU0FBQTs7Ozs7QUFIQSxJQUFBLGlDQUFBLEdBQUEsa0ZBQUEsR0FBQSxDQUFBLEVBQTJDLEdBQUEsa0ZBQUEsR0FBQSxDQUFBOzs7O0FBQTNDLElBQUEsMkJBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxlQUFBLElBQUEsQ0FBQTs7Ozs7QUFNQSxJQUFBLG9CQUFBLEdBQUEsMkJBQUE7Ozs7O0FBZUosSUFBQSx1QkFBQSxHQUFBLE9BQUEsQ0FBQTs7OztBQUFLLElBQUEsd0JBQUEsT0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUEsMEJBQUEsRUFBc0MsT0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUE7Ozs7OztBQUUzQyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQWlKLEdBQUEsR0FBQTtBQUU3SSxJQUFBLHVCQUFBLEdBQUEsUUFBQSxFQUFBLEVBQW82QixHQUFBLFFBQUEsRUFBQSxFQUMvUSxHQUFBLFFBQUEsRUFBQSxFQUNDLEdBQUEsUUFBQSxFQUFBO0FBRXRwQixJQUFBLDBCQUFBLEVBQUk7Ozs7O0FBK0JSLElBQUEsb0JBQUEsR0FBQSw0QkFBQTs7Ozs7QUFFQSxJQUFBLG9CQUFBLEdBQUEsU0FBQTs7Ozs7O0FBcEZWLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7QUFHQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXdGLEdBQUEsT0FBQSxFQUFBO0FBRWxGLElBQUEsaUNBQUEsR0FBQSxvRUFBQSxHQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXlDLEdBQUEsb0VBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQTtBQVk3QyxJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsRUFBQSxFQUErRCxHQUFBLE1BQUE7QUFFdkQsSUFBQSxpQ0FBQSxHQUFBLG9FQUFBLEdBQUEsQ0FBQSxFQUF5QyxHQUFBLG9FQUFBLEdBQUEsQ0FBQTtBQVM3QyxJQUFBLDBCQUFBLEVBQU87QUFHWCxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQXlDLElBQUEsb0JBQUEsRUFBQTtBQUFvQyxJQUFBLDBCQUFBLEVBQUk7QUFJbkYsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUErRCxJQUFBLE9BQUEsRUFBQSxFQUMySSxJQUFBLE9BQUEsRUFBQSxFQUU1SixJQUFBLE9BQUEsRUFBQTtBQUV0QyxJQUFBLGlDQUFBLElBQUEscUVBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQSxFQUF5QyxJQUFBLHFFQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUE7QUFZM0MsSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEVBQUssSUFBQSxNQUFBLENBQUE7QUFFRCxJQUFBLG9CQUFBLEVBQUE7QUFBc0MsSUFBQSw0QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFnQyxJQUFBLG9CQUFBLEVBQUE7QUFBOEMsSUFBQSwwQkFBQSxFQUFPO0FBRTdILElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFBOEUsSUFBQSxvQkFBQSxFQUFBO0FBQXVDLElBQUEsMEJBQUEsRUFBTSxFQUN2SDtBQUdSLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUEsRUFBc0MsSUFBQSxNQUFBLEVBQUE7O0FBRWxDLElBQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLElBQUEsa0NBQUE7QUFBZ0MsSUFBQSwwQkFBQSxFQUFPO0FBRS9DLElBQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7O0FBQ0UsSUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTs7QUFDQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsSUFBQSwrQkFBQTtBQUE2QixJQUFBLDBCQUFBLEVBQU87QUFFNUMsSUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTs7QUFDRSxJQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxJQUFBLHFCQUFBO0FBQW1CLElBQUEsMEJBQUEsRUFBTyxFQUM3QjtBQUdQLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBZ0MsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0ZBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxnQkFBQSxJQUFvQixJQUFJLENBQUM7SUFBQSxDQUFBOztBQUNoRSxJQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQ0ksSUFBQSxpQ0FBQSxJQUFBLHFFQUFBLEdBQUEsQ0FBQSxFQUEyQyxJQUFBLHFFQUFBLEdBQUEsQ0FBQTtBQUsvQyxJQUFBLDBCQUFBLEVBQU8sRUFDRSxFQUNQOzs7O0FBbkZGLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxhQUFBLElBQUEsQ0FBQTtBQWdCSSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsYUFBQSxJQUFBLENBQUE7QUFZaUMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLE9BQUE7QUFTbkMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLGFBQUEsS0FBQSxFQUFBO0FBZUUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsU0FBQTtBQUFzRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsZUFBQSxFQUFBO0FBRU0sSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFVBQUE7QUFzQjVFLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxlQUFBLEtBQUEsRUFBQTs7Ozs7O0FBdUNJLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7Ozs7O0FBR0EsSUFBQSxvQkFBQSxHQUFBLDRCQUFBOzs7OztBQUVBLElBQUEsb0JBQUEsR0FBQSxTQUFBOzs7OztBQUhBLElBQUEsaUNBQUEsR0FBQSxpR0FBQSxHQUFBLENBQUEsRUFBMkMsR0FBQSxpR0FBQSxHQUFBLENBQUE7Ozs7QUFBM0MsSUFBQSwyQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLGVBQUEsSUFBQSxDQUFBOzs7Ozs7QUEzQlYsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFvRixHQUFBLE9BQUEsRUFBQTs7QUFFaEYsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQXlDLElBQUEsb0JBQUEsR0FBQSxrQkFBQTtBQUFnQixJQUFBLDBCQUFBLEVBQUs7QUFHaEUsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFvRyxHQUFBLE9BQUEsRUFBQTtBQUNkLElBQUEsb0JBQUEsR0FBQSxjQUFBO0FBQVksSUFBQSwwQkFBQTtBQUNoRyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQWdELElBQUEsb0JBQUEsQ0FBQTtBQUFnQyxJQUFBLDRCQUFBLElBQUEsUUFBQSxFQUFBO0FBQTRDLElBQUEsb0JBQUEsSUFBQSxLQUFBO0FBQUcsSUFBQSwwQkFBQSxFQUFPO0FBRXRJLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBb0MsSUFBQSxPQUFBLEVBQUEsRUFDYixJQUFBLFFBQUEsRUFBQTtBQUN1QixJQUFBLG9CQUFBLElBQUEsU0FBQTtBQUFPLElBQUEsMEJBQUE7QUFDakQsSUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFtQyxJQUFBLG9CQUFBLEVBQUE7QUFBaUMsSUFBQSwwQkFBQSxFQUFPO0FBRTdFLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBcUIsSUFBQSxRQUFBLEVBQUE7QUFDdUIsSUFBQSxvQkFBQSxJQUFBLFNBQUE7QUFBTyxJQUFBLDBCQUFBO0FBQ2pELElBQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBcUQsSUFBQSxvQkFBQSxFQUFBO0FBQXVCLElBQUEsMEJBQUEsRUFBTyxFQUMvRSxFQUNGO0FBR1IsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSw4RkFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFdBQUEsQ0FBWTtJQUFBLENBQUE7QUFDOUMsSUFBQSxpQ0FBQSxJQUFBLG1GQUFBLEdBQUEsQ0FBQSxFQUFtQixJQUFBLG1GQUFBLEdBQUEsQ0FBQTtBQVV2QixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUE0QixJQUFBLHdCQUFBLFNBQUEsU0FBQSw4RkFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFVBQUEsQ0FBVztJQUFBLENBQUE7QUFBK0YsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQWtCLElBQUEsMEJBQUEsRUFBUzs7OztBQTFCeEgsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxJQUFBLE9BQUEsYUFBQSxHQUFBLFdBQUEsR0FBQTtBQUtULElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxhQUFBLEdBQUEsV0FBQTtBQUlrQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsZ0JBQUEsQ0FBQTtBQUtQLElBQUEsdUJBQUE7QUFBQSxJQUFBLHdCQUFBLFlBQUEsT0FBQSxVQUFBLENBQUE7QUFDaEQsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxVQUFBLElBQUEsS0FBQSxFQUFBOzs7Ozs7QUFzRFEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7Ozs7O0FBRUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7Ozs7O0FBNEJBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7OztBQUVBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7OztBQXRFZCxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQStELEdBQUEsT0FBQSxFQUFBLEVBQzRJLEdBQUEsT0FBQSxFQUFBLEVBRTdKLEdBQUEsT0FBQSxFQUFBO0FBRXRDLElBQUEsdUJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBSyxHQUFBLE1BQUEsQ0FBQTtBQUVELElBQUEsb0JBQUEsQ0FBQTtBQUFzQyxJQUFBLDRCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQWdDLElBQUEsb0JBQUEsQ0FBQTtBQUE4QyxJQUFBLDBCQUFBLEVBQU87QUFFN0gsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUE4RSxJQUFBLG9CQUFBLEVBQUE7QUFBdUMsSUFBQSwwQkFBQSxFQUFNLEVBQ3ZIO0FBR1IsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF1QixJQUFBLEtBQUEsRUFDaEIsSUFBQSxPQUFBLEVBQUEsRUFDOEMsSUFBQSxTQUFBLEVBQUE7QUFDdUMsSUFBQSxvQkFBQSxJQUFBLFNBQUE7QUFBTyxJQUFBLDBCQUFBO0FBQzdGLElBQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFHRSxJQUFBLG9CQUFBLEVBQUE7QUFDRixJQUFBLDBCQUFBLEVBQU87QUFFVCxJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXNCLElBQUEsU0FBQSxFQUFBO0FBRWIsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLG1HQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxjQUFBLE1BQUEsTUFBQSxPQUFBLGVBQUE7QUFBQSxhQUFBLHlCQUFBLE1BQUE7SUFBQSxDQUFBO0FBRFAsSUFBQSwwQkFBQTtBQUNPLElBQUEsNkJBQUE7QUFRUCxJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTJDLElBQUEsd0JBQUEsU0FBQSxTQUFBLDhGQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFBLE9BQUEsbUJBQUEsQ0FBQSxPQUFBLGdCQUFBO0lBQUEsQ0FBQTtBQUV6QyxJQUFBLGlDQUFBLElBQUEsbUZBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQSxFQUF3QixJQUFBLG1GQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUE7QUFLMUIsSUFBQSwwQkFBQSxFQUFTLEVBQ0w7QUFHUixJQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFLLElBQUEsT0FBQSxFQUFBLEVBQzhDLElBQUEsU0FBQSxFQUFBO0FBQ3VDLElBQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUFjLElBQUEsMEJBQUE7QUFDcEcsSUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUdFLElBQUEsb0JBQUEsRUFBQTtBQUNGLElBQUEsMEJBQUEsRUFBTztBQUVULElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBc0IsSUFBQSxTQUFBLEVBQUE7QUFFYixJQUFBLDhCQUFBLGlCQUFBLFNBQUEsbUdBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxPQUFBLFdBQUEsTUFBQSxNQUFBLE9BQUEsWUFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFEUCxJQUFBLDBCQUFBO0FBQ08sSUFBQSw2QkFBQTtBQVFQLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBdUMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsOEZBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQUEsT0FBQSxnQkFBQSxDQUFBLE9BQUEsYUFBQTtJQUFBLENBQUE7QUFFckMsSUFBQSxpQ0FBQSxJQUFBLG1GQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBcUIsSUFBQSxtRkFBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBS3ZCLElBQUEsMEJBQUEsRUFBUyxFQUNMO0FBR1IsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUNFLElBQUEsd0JBQUEsU0FBQSxTQUFBLDhGQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsU0FBQSxDQUFVO0lBQUEsQ0FBQTs7QUFJbkIsSUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTs7QUFJQSxJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsRUFBQTtBQUE0QyxJQUFBLDBCQUFBLEVBQU8sRUFDbEQsRUFDTCxFQUNGOzs7O0FBbkZLLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsT0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUEsMEJBQUEsRUFBc0MsT0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUE7QUFJekMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsU0FBQTtBQUFzRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsZUFBQSxFQUFBO0FBRU0sSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFVBQUE7QUFTdEUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxPQUFBLGFBQUEsVUFBQSxFQUFBLEVBQWdELHlCQUFBLE9BQUEsYUFBQSxTQUFBLEVBQUE7QUFFcEQsSUFBQSx1QkFBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGFBQUEsUUFBQSxRQUFBO0FBSTZCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsUUFBQSxPQUFBLG1CQUFBLFNBQUEsVUFBQTtBQUN4QixJQUFBLDhCQUFBLFdBQUEsT0FBQSxZQUFBO0FBQUEsSUFBQSx1QkFBQTtBQVVMLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxtQkFBQSxLQUFBLEVBQUE7QUFhSSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLGdCQUFBLE9BQUEsVUFBQSxVQUFBLEVBQUEsRUFBNkMseUJBQUEsT0FBQSxVQUFBLFNBQUEsRUFBQTtBQUVqRCxJQUFBLHVCQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsVUFBQSxRQUFBLFFBQUE7QUFJeUIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxRQUFBLE9BQUEsZ0JBQUEsU0FBQSxVQUFBO0FBQ3BCLElBQUEsOEJBQUEsV0FBQSxPQUFBLFNBQUE7QUFBQSxJQUFBLHVCQUFBO0FBVUwsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGdCQUFBLEtBQUEsRUFBQTtBQVdKLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsWUFBQSxPQUFBLGFBQUEsV0FBQSxNQUFBLE9BQUEsVUFBQSxXQUFBLEVBQUE7QUFJSyxJQUFBLHVCQUFBO0FBQUEsSUFBQSx5QkFBQSw2QkFBQSxPQUFBLGFBQUEsV0FBQSxNQUFBLE9BQUEsVUFBQSxXQUFBLEVBQUE7QUFHQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFVBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBOzs7OztBQS9IbEIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUVFLElBQUEsaUNBQUEsR0FBQSxvRUFBQSxJQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXNCLEdBQUEsb0VBQUEsSUFBQSxJQUFBLE9BQUEsRUFBQTtBQW1JeEIsSUFBQSwwQkFBQTs7OztBQW5JRSxJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGFBQUEsSUFBQSxJQUFBLENBQUE7Ozs7O0FBakdKLElBQUEsaUNBQUEsR0FBQSxzREFBQSxJQUFBLENBQUE7QUE4RkEsSUFBQSxpQ0FBQSxHQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7QUE5RkEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxJQUFBLEVBQUE7QUE4RkEsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxhQUFBLElBQUEsRUFBQTs7Ozs7O0FBZ0pJLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0VBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxnQkFBQSxJQUFvQixLQUFLLENBQUM7SUFBQSxDQUFBOztBQUM5RCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0YsSUFBQSwwQkFBQTs7Ozs7QUFJSSxJQUFBLG9CQUFBLEdBQUEsOEJBQUE7Ozs7O0FBRUEsSUFBQSxvQkFBQSxHQUFBLGFBQUE7Ozs7OztBQVFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBc0MsSUFBQSx3QkFBQSxTQUFBLFNBQUEsd0VBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsR0FBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsZ0JBQUEsSUFBQSxNQUFBLENBQXdCO0lBQUEsQ0FBQTtBQVFyRSxJQUFBLG9CQUFBLENBQUE7QUFDRixJQUFBLDBCQUFBOzs7OztBQVBRLElBQUEseUJBQUEsc0JBQUEsT0FBQSxnQkFBQSxNQUFBLE1BQUEsRUFBc0QsdUJBQUEsT0FBQSxnQkFBQSxNQUFBLE1BQUEsRUFDQyxxQkFBQSxPQUFBLGdCQUFBLE1BQUEsTUFBQSxFQUNGLGVBQUEsT0FBQSxnQkFBQSxNQUFBLE1BQUEsRUFDTiw0QkFBQSxPQUFBLGdCQUFBLE1BQUEsTUFBQSxFQUNhLHlCQUFBLE9BQUEsZ0JBQUEsTUFBQSxNQUFBO0FBTjVELElBQUEsd0JBQUEsTUFBQSw0QkFBQSxtQkFBQSxNQUFBLENBQTZCO0FBUW5DLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsUUFBQSxHQUFBOzs7OztBQVdGLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7O0FBQ0UsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFLLEdBQUEsTUFBQSxFQUFBO0FBQzhDLElBQUEsb0JBQUEsR0FBQSxtQkFBQTtBQUFpQixJQUFBLDBCQUFBO0FBQ2xFLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBb0QsSUFBQSxvQkFBQSxDQUFBO0FBQW9CLElBQUEsMEJBQUEsRUFBSSxFQUN4RTs7OztBQURnRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsYUFBQSxDQUFBOzs7OztBQStDbEQsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDRSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEdBQUE7QUFBb0MsSUFBQSxvQkFBQSxDQUFBO0FBQTJCLElBQUEsMEJBQUEsRUFBTzs7OztBQUFsQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsVUFBQSxVQUFBLENBQUE7Ozs7O0FBcUJ0QyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQXlILEdBQUEsT0FBQSxHQUFBLEVBQzdCLEdBQUEsTUFBQTtBQUNsRixJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBc0IsSUFBQSwwQkFBQTtBQUM1QixJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTtBQUFrRCxJQUFBLDBCQUFBLEVBQU87QUFFakUsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFFRixJQUFBLDBCQUFBLEVBQU07Ozs7QUFMRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxVQUFBLGFBQUEsSUFBQSxLQUFBLFFBQUEsQ0FBQSxHQUFBLEdBQUE7QUFJRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFNBQUEsT0FBQSxVQUFBLGFBQUEsSUFBQSxLQUFBLEdBQUE7Ozs7OztBQXBEZixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTJFLEdBQUEsT0FBQSxFQUFBOztBQUV2RSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBK0QsR0FBQSxHQUFBLEVBQzFELEdBQUEsUUFBQTtBQUNPLElBQUEsb0JBQUEsR0FBQSxpQkFBQTtBQUFlLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLEdBQUEsdUVBQUE7QUFDbkMsSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7QUFDRSxJQUFBLG9CQUFBLEdBQUEsYUFBQTtBQUFHLElBQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxJQUFBLE1BQUE7QUFBSSxJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxFQUFBO0FBQzNCLElBQUEsMEJBQUEsRUFBSSxFQUNBO0FBR1IsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUFtQyxJQUFBLE9BQUEsR0FBQSxFQUMyRSxJQUFBLFFBQUEsR0FBQTtBQUN2QixJQUFBLG9CQUFBLElBQUEsa0JBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUNuRyxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBO0FBQ0UsSUFBQSxvQkFBQSxFQUFBO0FBQ0YsSUFBQSwwQkFBQSxFQUFPO0FBR1QsSUFBQSxpQ0FBQSxJQUFBLHFGQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFNRixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUNFLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFFQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQWlILElBQUEsT0FBQSxHQUFBO0FBRzdHLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBeUcsSUFBQSxPQUFBLEdBQUEsRUFDQyxJQUFBLE9BQUEsR0FBQSxFQUNFLElBQUEsT0FBQSxHQUFBLEVBQ0MsSUFBQSxPQUFBLEdBQUE7QUFHL0csSUFBQSwwQkFBQSxFQUFNO0FBR1IsSUFBQSxpQ0FBQSxJQUFBLHFGQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFhQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQThCLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdHQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTs7QUFDbEQsSUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNGLElBQUEsMEJBQUEsRUFBUyxFQUNMOzs7O0FBcER5QixJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLGdDQUFBLDRMQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsV0FBQSx3QkFBQTtBQVFrRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFNBQUEsT0FBQSxVQUFBLGdCQUFBLENBQUE7QUFDM0UsSUFBQSx1QkFBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLFVBQUEsZ0JBQUEsS0FBQSxxQkFBQSxHQUFBO0FBSUosSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxVQUFBLFVBQUEsSUFBQSxLQUFBLEVBQUE7QUF1QkEsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLFVBQUEsYUFBQSxJQUFBLElBQUEsS0FBQSxFQUFBOzs7Ozs7QUExRU4sSUFBQSxpQ0FBQSxHQUFBLHFFQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUFVQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXdGLEdBQUEsT0FBQSxFQUFBLEVBQzBNLEdBQUEsU0FBQSxFQUFBO0FBQ3RQLElBQUEsd0JBQUEsVUFBQSxTQUFBLDhFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVUsT0FBQSxlQUFBLE1BQUEsQ0FBc0I7SUFBQSxDQUFBO0FBQXhFLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBOztBQUNFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDRixJQUFBLDBCQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBaUQsSUFBQSxvQkFBQSxHQUFBLGtCQUFBO0FBQWdCLElBQUEsMEJBQUE7QUFDakUsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFpRCxJQUFBLG9CQUFBLEdBQUEsc0JBQUE7QUFBb0IsSUFBQSwwQkFBQSxFQUFPO0FBRzlFLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBOEIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUZBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxhQUFBLENBQWM7SUFBQSxDQUFBO0FBQ25ELElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7O0FBQ0UsSUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNGLElBQUEsMEJBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFpRCxJQUFBLG9CQUFBLElBQUEsY0FBQTtBQUFZLElBQUEsMEJBQUE7QUFDN0QsSUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFpRCxJQUFBLG9CQUFBLElBQUEsNEJBQUE7QUFBMEIsSUFBQSwwQkFBQSxFQUFPLEVBQzNFO0FBR1gsSUFBQSxpQ0FBQSxJQUFBLHNFQUFBLElBQUEsR0FBQSxPQUFBLEVBQUE7QUFpRUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW9HLElBQUEsb0JBQUEsSUFBQSxtQkFBQTtBQUFpQixJQUFBLDBCQUFBO0FBQ3JILElBQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFzQixJQUFBLFlBQUEsRUFBQTtBQUtsQixJQUFBLDhCQUFBLGlCQUFBLFNBQUEseUZBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxPQUFBLFFBQUEsTUFBQSxNQUFBLE9BQUEsU0FBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBcUIsSUFBQSx3QkFBQSxpQkFBQSxTQUFBLHlGQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQWlCLE9BQUEsY0FBQSxNQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUNqQyxJQUFBLDBCQUFBO0FBRDFCLElBQUEsNkJBQUE7O0FBRUYsSUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNGLElBQUEsMEJBQUE7Ozs7QUE1R0EsSUFBQSwyQkFBQSxPQUFBLGFBQUEsSUFBQSxJQUFBLEVBQUE7QUFXZ1EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxjQUFBLE9BQUEsV0FBQSxDQUFBO0FBQ2xHLElBQUEsdUJBQUE7QUFBQSxJQUFBLHdCQUFBLFlBQUEsT0FBQSxXQUFBLENBQUE7QUFRckcsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxZQUFBLE9BQUEsV0FBQSxDQUFBO0FBU3pELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxXQUFBLElBQUEsS0FBQSxFQUFBO0FBNEVJLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsOEJBQUEsV0FBQSxPQUFBLE1BQUE7QUFDQSxJQUFBLHdCQUFBLFlBQUEsT0FBQSxXQUFBLENBQUE7QUFEQSxJQUFBLHVCQUFBOzs7Ozs7QUF1QkUsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUE0QixJQUFBLHdCQUFBLFNBQUEsU0FBQSwrRkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFVBQUEsQ0FBVztJQUFBLENBQUE7O0FBQzlDLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDRixJQUFBLDBCQUFBOzs7OztBQWxCTixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQWtJLEdBQUEsT0FBQSxHQUFBLEVBQzdFLEdBQUEsT0FBQSxHQUFBLEVBQ1osR0FBQSxPQUFBLEdBQUE7O0FBRWpDLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDRixJQUFBLDBCQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUssR0FBQSxPQUFBLEdBQUE7QUFFRCxJQUFBLG9CQUFBLENBQUE7QUFDRixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNFLElBQUEsb0JBQUEsQ0FBQTtBQUNGLElBQUEsMEJBQUEsRUFBTSxFQUNGO0FBRVIsSUFBQSxpQ0FBQSxJQUFBLHNFQUFBLEdBQUEsR0FBQSxVQUFBLEdBQUE7QUFLRixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUFnRCxJQUFBLE9BQUEsR0FBQSxFQUN5QixJQUFBLE9BQUEsR0FBQTtBQUNHLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwwQkFBQTtBQUM5RSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0UsSUFBQSxvQkFBQSxFQUFBOztBQUFpRCxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBO0FBQW9DLElBQUEsb0JBQUEsSUFBQSxLQUFBO0FBQUcsSUFBQSwwQkFBQSxFQUFPLEVBQzNGO0FBRVIsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUF1RSxJQUFBLE9BQUEsR0FBQTtBQUNHLElBQUEsb0JBQUEsSUFBQSxhQUFBO0FBQVcsSUFBQSwwQkFBQTtBQUNuRixJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0UsSUFBQSxvQkFBQSxFQUFBOztBQUE2QyxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBO0FBQW9DLElBQUEsb0JBQUEsSUFBQSxNQUFBO0FBQUksSUFBQSwwQkFBQSxFQUFPLEVBQ3hGO0FBRVIsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUF1RSxJQUFBLE9BQUEsR0FBQTtBQUNHLElBQUEsb0JBQUEsSUFBQSxTQUFBO0FBQU8sSUFBQSwwQkFBQTtBQUMvRSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0UsSUFBQSxvQkFBQSxFQUFBO0FBQ0YsSUFBQSwwQkFBQSxFQUFNLEVBQ0YsRUFDRjs7OztBQWpDRSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxTQUFBLEdBQUEsUUFBQSxzQkFBQSxHQUFBO0FBR0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsYUFBQSxHQUFBLGFBQUEsb0JBQUE7QUFJTixJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxLQUFBLEVBQUE7QUFXSSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEseUJBQUEsSUFBQSxHQUFBLE9BQUEsYUFBQSxHQUFBLFdBQUEsT0FBQSxHQUFBLEdBQUE7QUFNQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEseUJBQUEsSUFBQSxHQUFBLE9BQUEsYUFBQSxHQUFBLGFBQUEsR0FBQSxHQUFBO0FBTUEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsYUFBQSxHQUFBLGFBQUEsR0FBQTs7Ozs7QUFTVixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBOztBQUNFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBSyxHQUFBLE9BQUEsR0FBQTtBQUMrQyxJQUFBLG9CQUFBLEdBQUEsa0JBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUNsRSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQ0UsSUFBQSxvQkFBQSxHQUFBLGFBQUE7QUFBVSxJQUFBLDRCQUFBLEdBQUEsUUFBQTtBQUFRLElBQUEsb0JBQUEsQ0FBQTs7QUFBbUMsSUFBQSwwQkFBQTtBQUFTLElBQUEsb0JBQUEsSUFBQSxVQUFBO0FBQ3hELElBQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxFQUFBOztBQUFpRCxJQUFBLDBCQUFBO0FBQVMsSUFBQSxvQkFBQSxJQUFBLElBQUE7QUFDMUUsSUFBQSwwQkFBQSxFQUFJLEVBQ0E7Ozs7QUFIZ0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSx5QkFBQSxHQUFBLEdBQUEsT0FBQSxnQkFBQSxDQUFBLENBQUE7QUFDSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLHlCQUFBLElBQUEsR0FBQSxPQUFBLGFBQUEsR0FBQSxlQUFBLENBQUE7Ozs7O0FBT3BCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7O0FBQ0UsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFLLEdBQUEsT0FBQSxHQUFBO0FBQ2dELElBQUEsb0JBQUEsR0FBQSxtQkFBQTtBQUFpQixJQUFBLDBCQUFBO0FBQ3BFLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLG1FQUFBO0FBQWlFLElBQUEsMEJBQUEsRUFBSSxFQUN2Rzs7Ozs7O0FBTUosSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxlQUFBOzs7OztBQUlBLElBQUEsb0JBQUEsR0FBQSw0QkFBQTs7Ozs7QUFFQSxJQUFBLG9CQUFBLEdBQUEsU0FBQTs7Ozs7O0FBSkEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEsaUNBQUEsR0FBQSxxRUFBQSxHQUFBLENBQUEsRUFBMkMsR0FBQSxxRUFBQSxHQUFBLENBQUE7Ozs7QUFBM0MsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxlQUFBLElBQUEsQ0FBQTs7Ozs7O0FBaE9WLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBOEksR0FBQSxPQUFBLEVBQUE7QUFFMUksSUFBQSxpQ0FBQSxHQUFBLHNEQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUE7QUFLQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxFQUFBO0FBQ0UsSUFBQSxpQ0FBQSxHQUFBLHNEQUFBLEdBQUEsQ0FBQSxFQUEyQyxHQUFBLHNEQUFBLEdBQUEsQ0FBQTtBQUs3QyxJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFrQixHQUFBLFNBQUEsRUFBQTtBQUMyRSxJQUFBLG9CQUFBLEdBQUEsU0FBQTtBQUFPLElBQUEsMEJBQUE7QUFDbEcsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsOEJBQUEsSUFBQSwrQ0FBQSxHQUFBLElBQUEsVUFBQSxJQUFBLHNDQUFBO0FBWUYsSUFBQSwwQkFBQSxFQUFNO0FBR1IsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUErRSxJQUFBLFNBQUEsRUFBQTtBQUNjLElBQUEsb0JBQUEsSUFBQSw2QkFBQTtBQUEyQixJQUFBLDBCQUFBO0FBRXRILElBQUEsaUNBQUEsSUFBQSx1REFBQSxJQUFBLENBQUEsRUFBdUIsSUFBQSx1REFBQSxJQUFBLElBQUEsT0FBQSxFQUFBO0FBNkp6QixJQUFBLDBCQUFBO0FBRUEsSUFBQSxpQ0FBQSxJQUFBLHVEQUFBLElBQUEsR0FBQSxPQUFBLEVBQUE7QUFhQSxJQUFBLGlDQUFBLElBQUEsdURBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQVVBLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsa0VBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsV0FBQSxDQUFZO0lBQUEsQ0FBQTtBQUNoRCxJQUFBLGlDQUFBLElBQUEsdURBQUEsR0FBQSxDQUFBLEVBQW1CLElBQUEsdURBQUEsR0FBQSxDQUFBO0FBV25CLElBQUEsMEJBQUEsRUFBUyxFQUNQOzs7O0FBck9KLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsQ0FBQSxPQUFBLGFBQUEsSUFBQSxFQUFBO0FBTUUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLGVBQUEsSUFBQSxDQUFBO0FBVUUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxPQUFBLFFBQUE7QUFrQkYsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxJQUFBLEtBQUEsRUFBQTtBQStKRixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsa0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFhQSxJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLFVBQUEsSUFBQSxLQUFBLEVBQUE7QUFVb0QsSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsWUFBQSxPQUFBLFVBQUEsS0FBQSxDQUFBLE9BQUEsYUFBQSxLQUFBLE9BQUEsa0JBQUEsQ0FBQTtBQUNsRCxJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLFVBQUEsSUFBQSxLQUFBLEVBQUE7OztBRHpiUixJQUFNLFdBQVcsQ0FBQyxXQUFXLFdBQVcsUUFBUTtBQXlCMUMsSUFBTyxrQkFBUCxNQUFPLGlCQUFpQztFQUNyQyxXQUEwQztFQUMxQyxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFFZCxTQUFTLE9BQU8sYUFBYTtFQUM3QixTQUFTLE9BQU8sTUFBTTtFQUN0QixRQUFRLE9BQU8sY0FBYztFQUM5QixZQUFZLE9BQU8sU0FBUztFQUMzQixhQUFhLE9BQU8sdUJBQXVCO0VBQzNDLG1CQUFtQixPQUFPLGdCQUFnQjtFQUNsQyxnQkFBZ0IsT0FBTyxhQUFhO0VBRTNDLFdBQVc7RUFFYixrQkFBa0I7SUFBZ0I7Ozs7OztFQUNsQyxXQUFXO0lBQW9COzs7Ozs7RUFDL0IsZUFBZTtJQUE0Qjs7Ozs7O0VBQzNDLFNBQVM7RUFDVCxrQkFBa0I7SUFBTzs7Ozs7O0VBQ3pCLFlBQVk7SUFBTzs7Ozs7O0VBQ25CLGVBQWU7SUFBc0I7Ozs7Ozs7RUFHckMsYUFBYTtFQUNiLGVBQWU7RUFDZixZQUFZO0VBRW5CLGFBQWE7SUFBZ0I7Ozs7OztFQUN0QixjQUFrQztFQUduQyxVQUFVLE9BQW1COztBQUNqQyxVQUFJLEtBQUssZ0JBQWdCLE1BQU0sV0FBVyxLQUFLLGNBQWM7QUFDM0QsZ0JBQVEsS0FBSyxxREFBcUQsTUFBTSxNQUFNLEVBQUU7QUFDaEY7TUFDRjtBQUVBLFVBQUksTUFBTSxNQUFNLFNBQVMsd0JBQXdCO0FBQy9DLFlBQUksTUFBTSxLQUFLLFdBQVcsZUFBZSxNQUFNLEtBQUssU0FBUztBQUMzRCxnQkFBTSxjQUFjLEtBQUssTUFBTSxTQUFTLGNBQWMsSUFBSSxTQUFTO0FBQ25FLGNBQUksYUFBYTtBQUNmLGlCQUFLLGdCQUFnQixJQUFJLFdBQWtCO1VBQzdDO0FBRUEsZ0JBQU0sZ0JBQWdCLE1BQU0sS0FBSyxRQUFRLEtBQUk7QUFFN0MsZ0JBQU0sWUFBWSxJQUFJLEtBQUssQ0FBQyxhQUFhLEdBQUcsK0JBQStCO1lBQ3pFLE1BQU07V0FDUDtBQUVELGNBQUksUUFBYSxDQUFDLFNBQVM7QUFDM0IsY0FBSSxPQUFPLGlCQUFpQixhQUFhO0FBQ3ZDLGtCQUFNLGVBQWUsSUFBSSxhQUFZO0FBQ3JDLHlCQUFhLE1BQU0sSUFBSSxTQUFTO0FBQ2hDLG9CQUFRLGFBQWE7VUFDdkI7QUFFQSxnQkFBTSxZQUFZO1lBQ2hCLFFBQVEsRUFBRSxNQUFZO1lBQ3RCLGdCQUFnQixNQUFLO1lBQUU7WUFDdkIsaUJBQWlCLE1BQUs7WUFBRTs7QUFHMUIsZ0JBQU0sS0FBSyxlQUFlLFNBQWdCO0FBQzFDLGVBQUssZ0JBQWdCLElBQUksSUFBSTtRQUMvQjtNQUNGO0lBQ0Y7O0VBRUEsV0FBUTtBQUNOLFNBQUssV0FBWSxLQUFLLE1BQU0sU0FBUyxjQUFjLElBQUksTUFBTSxLQUFhO0FBRTFFLFNBQUssZUFBZSxLQUFLLE1BQU0sU0FBUyxjQUFjLElBQUksTUFBTSxLQUFLO0FBRXJFLFFBQUksT0FBTyxXQUFXLGFBQWE7QUFDakMsVUFBSSxDQUFDLEtBQUssY0FBYztBQUN0QixhQUFLLGVBQWUsT0FBTyxTQUFTO01BQ3RDO0FBRUEsV0FBSyxhQUFhLFdBQVcsT0FBTyxVQUFVLFdBQVcsT0FBTztBQUVoRSxVQUFJLEtBQUssWUFBWTtBQUNuQixlQUFPLE9BQU8sWUFDWjtVQUNFLE1BQU07VUFDTixRQUFRO1dBRVYsS0FBSyxZQUFZO01BRXJCO0lBQ0Y7RUFDRjtFQUVBLFlBQVM7QUFDUCxTQUFLLFNBQVMsSUFBSSxJQUFJO0FBQ3RCLFNBQUssU0FBUztBQUNkLFNBQUssYUFBYSxJQUFJLElBQUk7QUFDMUIsU0FBSyxhQUFhLElBQUksSUFBSTtFQUM1QjtFQUVNLGFBQVU7O0FBQ2QsV0FBSyxVQUFVLElBQUksSUFBSTtBQUN2QixVQUFJO0FBQ0YsY0FBTSxvQkFBb0IsTUFBTSxLQUFLLE9BQU8sV0FDMUMsS0FBSyxRQUNMLEtBQUssZ0JBQWUsR0FDcEIsZUFBZTtBQUdqQixjQUFNLGlCQUFpQixNQUFNLEtBQUssaUJBQWlCLFFBQ2pELGtCQUFrQixZQUFZLFlBQzlCLGtCQUFrQixVQUFVLGFBQWE7QUFHM0MsdUJBQWUsUUFBUSxlQUFlLGtCQUFrQixVQUFVLE1BQU0sSUFBSSxjQUFjO0FBQzFGLGFBQUssV0FBVyxnQkFBZ0Isa0JBQWtCLFVBQVUsUUFBUSxLQUFLLGdCQUFlLENBQUU7QUFDMUYsYUFBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLGtCQUFrQixVQUFVLE1BQU0sR0FBRztVQUNsRSxVQUFVLGtCQUFrQixVQUFVO1NBQ3ZDO01BQ0gsU0FBUyxHQUFHO0FBQ1YsZ0JBQVEsTUFBTSxDQUFDO01BQ2pCO0FBQ0UsYUFBSyxVQUFVLElBQUksS0FBSztNQUMxQjtJQUNGOztFQUVBLFdBQVE7QUFDTixRQUFJLEtBQUssZ0JBQWdCLEtBQUssV0FBVztBQUN2QyxZQUFNLFdBQVcsS0FBSyxVQUFVLFNBQVMsR0FBRyxJQUFJLEtBQUssVUFBVSxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUksS0FBSztBQUVwRixXQUFLLE9BQU8sU0FBUyxDQUFDLFNBQVMsS0FBSyxhQUFhLEtBQUksQ0FBRSxHQUFHO1FBQ3hELFVBQVUsU0FBUyxLQUFJO09BQ3hCO0lBQ0g7RUFDRjtFQUVNLGVBQWUsT0FBVTs7QUFDN0IsWUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNLENBQUM7QUFFakMsVUFBSSxDQUFDO0FBQU07QUFFWCxXQUFLLFNBQVMsSUFBSSxJQUFJO0FBQ3RCLFdBQUssYUFBYSxJQUFJLElBQUk7QUFFMUIsVUFBSTtBQUNGLGNBQU0sU0FBUyxNQUFNLEtBQUssWUFBVztBQUNyQyxjQUFNLFFBQVEsSUFBSSxXQUFXLE1BQU07QUFFbkMsY0FBTSxXQUNKLE1BQU0sQ0FBQyxNQUFNLE9BQ2IsTUFBTSxDQUFDLE1BQU0sT0FDYixNQUFNLENBQUMsTUFBTSxNQUNiLE1BQU0sQ0FBQyxNQUFNLE9BQ2IsTUFBTSxDQUFDLE1BQU07QUFFZixjQUFNLFVBQVUsV0FDWixNQUFNLEtBQUssS0FBSyxFQUNiLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUUsSUFDVixJQUFJLFlBQVcsRUFBRyxPQUFPLEtBQUssRUFBRSxLQUFJO0FBRXhDLGFBQUssU0FBUztBQUVkLGFBQUssY0FBYyxPQUFPO01BQzVCLFNBQVMsR0FBRztBQUNWLGdCQUFRLE1BQU0sQ0FBQztNQUNqQjtJQUNGOztFQUVBLGNBQWMsTUFBWTtBQUN4QixRQUFJLENBQUMsUUFBUSxLQUFLLFNBQVM7QUFBSTtBQUUvQixVQUFNLFdBQVcsVUFBVSxRQUFRLElBQUk7QUFFdkMsUUFBSSxVQUFVO0FBQ1osV0FBSyxhQUFhLElBQUksUUFBUTtBQUM5QixXQUFLLGFBQWEsSUFBSSxJQUFJO0lBQzVCLE9BQU87QUFDTCxXQUFLLGFBQWEsSUFBSSxJQUFJO0FBQzFCLFdBQUssYUFBYSxJQUNoQiwwSEFBMEg7QUFHNUgsVUFBSSxLQUFLLFlBQVk7QUFDbkIsZUFBTyxPQUFPLFlBQ1o7VUFDRSxNQUFNO1VBQ04sUUFBUTtVQUNSLFNBQVM7WUFDUCxNQUFNO1lBQ04sU0FBUzs7V0FHYixLQUFLLFlBQVk7TUFFckI7SUFDRjtFQUNGO0VBRUEsZ0JBQWdCLFFBQWdCLFNBQXNCO0FBQ3BELFNBQUssV0FBVyxnQkFBZ0IsUUFBUSxPQUFPO0VBQ2pEOztFQUdBLG9CQUE0QjtBQUMxQixVQUFNLFdBQVcsS0FBSyxhQUFZO0FBQ2xDLFFBQUksQ0FBQztBQUFVLGFBQU87QUFDdEIsV0FDRyxTQUFTLG9CQUFvQixhQUFhLEtBQUssZ0JBQWUsTUFBTyxhQUNyRSxTQUFTLG9CQUFvQixhQUFhLEtBQUssZ0JBQWUsTUFBTztFQUUxRTtFQUVBLFlBQW9CO0FBQ2xCLFVBQU0sV0FBVyxLQUFLLGFBQVk7QUFDbEMsUUFBSSxDQUFDLFlBQVksU0FBUyxrQkFBa0I7QUFBRyxhQUFPO0FBQ3RELFVBQU0sWUFBWSxTQUFTLGNBQWMsS0FBSyxTQUFTLGNBQWMsS0FBSztBQUMxRSxVQUFNLE9BQU8sU0FBUyxnQkFBZ0I7QUFDdEMsVUFBTSxZQUFZLFNBQVMsWUFBWTtBQUN2QyxXQUFPLE9BQU8sT0FBUSxZQUFZLEtBQUssU0FBUyxnQkFBZ0IsWUFBWTtFQUM5RTtFQUVRLG1CQUFtQjtFQUVyQixlQUFZOztBQUNoQixXQUFLLFdBQVcsSUFBSSxJQUFJO0FBQ3hCLFdBQUssbUJBQW1CO0FBQ3hCLFdBQUssYUFBYSxJQUFJLElBQUk7QUFDMUIsV0FBSyxVQUFVLGFBQVk7QUFFM0IsaUJBQVcsTUFBVztBQUNwQixhQUFLLGNBQWMsSUFBSSxZQUFZLFVBQVU7VUFDM0Msa0JBQWtCLENBQUMsNEJBQTRCLE9BQU87VUFDdEQsU0FBUztVQUNULHNCQUFzQjtZQUNwQiwrQkFBK0I7O1NBRWxDO0FBRUQsWUFBSSxhQUFhO0FBRWpCLFlBQUk7QUFDRixnQkFBTSxLQUFLLFlBQVksTUFDckIsRUFBRSxZQUFZLGNBQWEsR0FDM0I7WUFDRSxLQUFLO1lBQ0wsYUFBYTtZQUNiLE9BQU8sRUFBRSxPQUFPLEtBQUssUUFBUSxJQUFHO1lBQ2hDLGtCQUFrQjtjQUNoQixPQUFPLEVBQUUsT0FBTyxLQUFJO2NBQ3BCLFFBQVEsRUFBRSxPQUFPLElBQUc7O2FBR3hCLENBQUMsZ0JBQWdCLEtBQUssaUJBQWlCLFdBQVcsR0FDbEQsQ0FBQyxpQkFBZ0I7QUFDZjtBQUNBLGdCQUFJLGFBQWEsT0FBTyxHQUFHO0FBQ3pCLHNCQUFRLEtBQ04seUJBQXlCLFVBQVUsOEJBQ25DLGFBQWEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBRS9CO1VBQ0YsQ0FBQztRQUVMLFNBQVMsS0FBSztBQUNaLGtCQUFRLEtBQUssd0VBQXdFLEdBQUc7QUFFeEYsY0FBSTtBQUNGLGtCQUFNLEtBQUssWUFBWSxNQUNyQixFQUFFLFlBQVksY0FBYSxHQUMzQixFQUFFLEtBQUssSUFBSSxhQUFhLE1BQUssR0FDN0IsQ0FBQyxnQkFBZ0IsS0FBSyxpQkFBaUIsV0FBVyxHQUNsRCxNQUFLO0FBQ0gsc0JBQVEsTUFBTSxrQ0FBa0M7WUFDbEQsQ0FBQztVQUVMLFNBQVMsYUFBYTtBQUNwQixvQkFBUSxNQUFNLHNDQUFzQyxXQUFXO0FBQy9ELGlCQUFLLFlBQVc7VUFDbEI7UUFDRjtNQUNGLElBQUcsR0FBRztJQUNSOztFQUVNLGlCQUFpQixhQUFtQjs7QUFDeEMsVUFBSSxLQUFLO0FBQWtCO0FBRTNCLFlBQU0sUUFBUSxZQUFZLFlBQVc7QUFHckMsVUFBSSxNQUFNLFdBQVcsS0FBSyxLQUFLLE1BQU0sV0FBVyxJQUFJLEdBQUc7QUFDckQsY0FBTSxVQUFVLEtBQUssVUFBVSxnQkFBZ0IsV0FBVztBQUUxRCxZQUFJLFNBQVM7QUFDWCxlQUFLLG1CQUFtQjtBQUN4QixnQkFBTSxLQUFLLGdCQUFlO0FBRTFCLGVBQUssU0FBUztBQUVkLGVBQUssY0FBYyxPQUFPO0FBQzFCLGVBQUssbUJBQW1CO1FBQzFCO01BQ0YsT0FBTztBQUNMLGFBQUssbUJBQW1CO0FBQ3hCLGNBQU0sS0FBSyxnQkFBZTtBQUUxQixhQUFLLFNBQVM7QUFFZCxhQUFLLGNBQWMsV0FBVztBQUM5QixhQUFLLG1CQUFtQjtNQUMxQjtJQUNGOztFQUVNLGtCQUFlOztBQUNuQixVQUFJLEtBQUssYUFBYTtBQUNwQixZQUFJO0FBQ0YsY0FBSSxLQUFLLFlBQVksU0FBUSxNQUFPLEdBQUc7QUFDckMsa0JBQU0sS0FBSyxZQUFZLEtBQUk7VUFDN0I7QUFDQSxlQUFLLFlBQVksTUFBSztRQUN4QixTQUFTLEdBQUc7QUFDVixrQkFBUSxNQUFNLHFCQUFxQixDQUFDO1FBQ3RDO01BQ0Y7QUFDQSxXQUFLLFdBQVcsSUFBSSxLQUFLO0lBQzNCOztFQUVBLGNBQVc7QUFDVCxTQUFLLGdCQUFlO0VBQ3RCOztxQ0EzVVcsa0JBQWU7RUFBQTs0RUFBZixrQkFBZSxXQUFBLENBQUEsQ0FBQSxZQUFBLENBQUEsR0FBQSxjQUFBLFNBQUEsNkJBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUFBZixNQUFBLHdCQUFBLFdBQUEsU0FBQSwyQ0FBQSxRQUFBO0FBQUEsZUFBQSxJQUFBLFVBQUEsTUFBQTtNQUFpQixHQUFBLDRCQUFBOztnREFGakIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxNQUFBLDhCQUFBLEdBQUEsVUFBQSxRQUFBLFlBQUEsZ0JBQUEsT0FBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLHVCQUFBLEdBQUEsUUFBQSxZQUFBLGdCQUFBLGtCQUFBLFVBQUEsaUJBQUEsZUFBQSxZQUFBLFFBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxTQUFBLFdBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLGtCQUFBLG9CQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsU0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxjQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsQ0FBQSxpQkFBQSxJQUFBLEdBQUEsUUFBQSxRQUFBLHFCQUFBLGdCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxhQUFBLGNBQUEsUUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSx5QkFBQSxXQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxVQUFBLFlBQUEsUUFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsWUFBQSxvQkFBQSxhQUFBLGFBQUEsc0JBQUEsZ0JBQUEsZ0JBQUEscUJBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxhQUFBLFVBQUEsZUFBQSxTQUFBLFlBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGtCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLGtCQUFBLDJDQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxTQUFBLDhCQUFBLFdBQUEsZUFBQSx1QkFBQSxpQkFBQSxHQUFBLFFBQUEsUUFBQSxxQkFBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZUFBQSxhQUFBLFFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEseUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFlBQUEsUUFBQSxRQUFBLGtCQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEscUJBQUEsR0FBQSxvQkFBQSxvQkFBQSxVQUFBLDRCQUFBLGVBQUEsT0FBQSxRQUFBLFlBQUEsZ0NBQUEsa0JBQUEsU0FBQSxVQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxnQkFBQSxTQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLHNCQUFBLGVBQUEsUUFBQSxnQkFBQSxrQkFBQSxVQUFBLDBCQUFBLFlBQUEseUJBQUEsd0JBQUEsY0FBQSxHQUFBLENBQUEsU0FBQSw4QkFBQSxXQUFBLGVBQUEsdUJBQUEsaUJBQUEsR0FBQSxPQUFBLE9BQUEscUJBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSx3QkFBQSxXQUFBLGFBQUEsYUFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLFNBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFNBQUEsZ0JBQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxtQkFBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxHQUFBLFVBQUEsUUFBQSxtQkFBQSwrQkFBQSxpQkFBQSxhQUFBLGNBQUEsY0FBQSxhQUFBLDBCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxhQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSw2QkFBQSxzQkFBQSxHQUFBLENBQUEsS0FBQSwwNUJBQUEsR0FBQSxDQUFBLEtBQUEsMm9CQUFBLEdBQUEsQ0FBQSxLQUFBLDRvQkFBQSxHQUFBLENBQUEsS0FBQSxpbUJBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsVUFBQSwwQkFBQSxlQUFBLE9BQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFNBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLGFBQUEsU0FBQSxHQUFBLENBQUEsTUFBQSxxQkFBQSxHQUFBLGVBQUEsVUFBQSw0QkFBQSxjQUFBLE9BQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHlCQUFBLGFBQUEsYUFBQSxtQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSx5QkFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxhQUFBLFlBQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxVQUFBLFFBQUEsbUJBQUEsaUJBQUEsYUFBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSwrQkFBQSxjQUFBLGtCQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEsVUFBQSxRQUFBLFdBQUEseUJBQUEsb0JBQUEsY0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGlCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxHQUFBLG9CQUFBLG9CQUFBLFVBQUEsNEJBQUEsZUFBQSxPQUFBLFFBQUEsWUFBQSxnQ0FBQSxrQkFBQSxTQUFBLFVBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsbUJBQUEsYUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsV0FBQSxhQUFBLHlCQUFBLGFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEsc0JBQUEsYUFBQSxNQUFBLGVBQUEsb0JBQUEsZ0JBQUEsT0FBQSxrQkFBQSxRQUFBLGlCQUFBLFFBQUEsaUJBQUEsUUFBQSxHQUFBLFVBQUEsZUFBQSxVQUFBLDRCQUFBLGNBQUEsT0FBQSxTQUFBLGNBQUEsYUFBQSxXQUFBLGdCQUFBLDZCQUFBLGNBQUEsR0FBQSxpQkFBQSxRQUFBLFNBQUEsR0FBQSxDQUFBLE1BQUEsaUNBQUEsR0FBQSxZQUFBLFdBQUEsV0FBQSxvQkFBQSx5QkFBQSxvQkFBQSxjQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLGFBQUEsTUFBQSxlQUFBLGdCQUFBLGdCQUFBLE9BQUEsa0JBQUEsUUFBQSxpQkFBQSxRQUFBLGlCQUFBLFFBQUEsR0FBQSxVQUFBLGVBQUEsVUFBQSw0QkFBQSxjQUFBLE9BQUEsU0FBQSxjQUFBLGFBQUEsV0FBQSxnQkFBQSw2QkFBQSxjQUFBLEdBQUEsaUJBQUEsUUFBQSxTQUFBLEdBQUEsQ0FBQSxNQUFBLDZCQUFBLEdBQUEsWUFBQSxXQUFBLFdBQUEsb0JBQUEseUJBQUEsb0JBQUEsY0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLE1BQUEsMEJBQUEsR0FBQSxVQUFBLFFBQUEsbUJBQUEsK0JBQUEsaUJBQUEsYUFBQSxjQUFBLGNBQUEsYUFBQSwwQkFBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsYUFBQSx1QkFBQSwrQkFBQSxrQkFBQSxHQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSxzQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxVQUFBLDRCQUFBLE9BQUEsZUFBQSxjQUFBLFlBQUEsVUFBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLEdBQUEsWUFBQSxTQUFBLFdBQUEseUJBQUEsb0JBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxhQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsV0FBQSxhQUFBLHlCQUFBLGFBQUEsa0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGVBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsY0FBQSxXQUFBLGFBQUEsVUFBQSxrQkFBQSxjQUFBLGtCQUFBLEdBQUEsTUFBQSxzQkFBQSx1QkFBQSxxQkFBQSxlQUFBLDRCQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLFVBQUEsNEJBQUEsY0FBQSxPQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxXQUFBLGFBQUEsYUFBQSxrQkFBQSxRQUFBLHVCQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsZUFBQSxVQUFBLDRCQUFBLGNBQUEsT0FBQSxjQUFBLGNBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLE9BQUEsa0JBQUEsVUFBQSxzQkFBQSxjQUFBLFFBQUEsZUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsT0FBQSxtQkFBQSxVQUFBLHVCQUFBLGNBQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxVQUFBLFFBQUEsbUJBQUEsK0JBQUEsaUJBQUEsYUFBQSxjQUFBLGNBQUEsYUFBQSwwQkFBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsYUFBQSx1QkFBQSxrQkFBQSxHQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxHQUFBLFlBQUEsU0FBQSxXQUFBLHlCQUFBLG9CQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsV0FBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxjQUFBLFdBQUEsYUFBQSxVQUFBLGtCQUFBLGNBQUEsa0JBQUEsR0FBQSxTQUFBLElBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxPQUFBLGtCQUFBLFVBQUEsc0JBQUEsY0FBQSxRQUFBLGVBQUEsU0FBQSxjQUFBLFdBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxlQUFBLGtCQUFBLFNBQUEsUUFBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFlBQUEsU0FBQSxRQUFBLFlBQUEsZ0JBQUEsa0JBQUEsT0FBQSxlQUFBLFlBQUEsaUJBQUEsNEJBQUEsY0FBQSxnQ0FBQSwyQkFBQSxrQkFBQSxnQkFBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxRQUFBLFFBQUEsVUFBQSxtQkFBQSxHQUFBLFlBQUEsV0FBQSxhQUFBLGtCQUFBLFFBQUEsR0FBQSxVQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsT0FBQSxnQkFBQSxRQUFBLGtDQUFBLG1CQUFBLEdBQUEsQ0FBQSxxQkFBQSxJQUFBLEdBQUEseUJBQUEsaUNBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxlQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEseUJBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLFFBQUEsWUFBQSxnQkFBQSxrQkFBQSxPQUFBLGVBQUEsWUFBQSxpQkFBQSw0QkFBQSxjQUFBLGdDQUFBLDJCQUFBLGtCQUFBLFNBQUEsdUJBQUEsa0JBQUEsR0FBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSx5QkFBQSxpQ0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLFdBQUEsdUJBQUEsZ0JBQUEsUUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsUUFBQSxnQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsWUFBQSwwQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxRQUFBLHlCQUFBLFdBQUEsZUFBQSxhQUFBLGdCQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLFFBQUEsS0FBQSxlQUFBLCtDQUFBLEdBQUEsVUFBQSxrQkFBQSxVQUFBLDRCQUFBLG1CQUFBLGNBQUEsT0FBQSxhQUFBLFdBQUEsZ0JBQUEsOEJBQUEsZ0NBQUEscUJBQUEsZUFBQSxnQ0FBQSxHQUFBLGlCQUFBLFdBQUEsVUFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsWUFBQSxTQUFBLFdBQUEseUJBQUEsdUJBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSx1QkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGlCQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxhQUFBLGlCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxvQkFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLHNCQUFBLFVBQUEsMEJBQUEsY0FBQSxPQUFBLFFBQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEscUJBQUEsWUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsbUJBQUEsbUJBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHFCQUFBLGVBQUEsc0JBQUEsT0FBQSxXQUFBLFVBQUEsd0JBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxRQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxVQUFBLDRCQUFBLGNBQUEsU0FBQSxRQUFBLGdCQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEseUJBQUEsYUFBQSxhQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEscUJBQUEsYUFBQSxZQUFBLGlCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxVQUFBLHNCQUFBLGNBQUEsU0FBQSxRQUFBLGVBQUEsU0FBQSxjQUFBLFdBQUEsY0FBQSxjQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsWUFBQSxZQUFBLGNBQUEsbUJBQUEsVUFBQSwwQkFBQSxzQ0FBQSxRQUFBLGNBQUEsV0FBQSx1QkFBQSxjQUFBLEdBQUEsQ0FBQSxNQUFBLFVBQUEsR0FBQSxVQUFBLFFBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsdUJBQUEsUUFBQSxRQUFBLFlBQUEsZ0JBQUEsa0JBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxRQUFBLFFBQUEsY0FBQSx5Q0FBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLE9BQUEsT0FBQSxjQUFBLGNBQUEsdUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsV0FBQSxPQUFBLE9BQUEsY0FBQSxjQUFBLHVCQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxZQUFBLFVBQUEsT0FBQSxPQUFBLGNBQUEsY0FBQSx1QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsWUFBQSxXQUFBLE9BQUEsT0FBQSxjQUFBLGNBQUEsdUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsV0FBQSxXQUFBLG1CQUFBLHlDQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxZQUFBLFVBQUEsV0FBQSxvQkFBQSxvQkFBQSxPQUFBLFlBQUEsMEJBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLFlBQUEsU0FBQSxXQUFBLFFBQUEseUJBQUEsb0JBQUEsb0JBQUEsdUJBQUEsU0FBQSxnQkFBQSxrQkFBQSxvQkFBQSxVQUFBLDRCQUFBLHdCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsdUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLG1CQUFBLFdBQUEscUJBQUEsYUFBQSxRQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsZUFBQSxnQkFBQSxTQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLFNBQUEsZ0JBQUEsa0JBQUEsZ0JBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGVBQUEsbUJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLHNCQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxtQkFBQSxHQUFBLENBQUEsa0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLFdBQUEsYUFBQSxZQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsV0FBQSxXQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEseUJBQUEsdUJBQUEsT0FBQSxjQUFBLHdCQUFBLHFCQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxTQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsV0FBQSxPQUFBLFVBQUEsMEJBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSx5QkFBQSxhQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsV0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLHVCQUFBLEdBQUEsQ0FBQSxNQUFBLGtCQUFBLEdBQUEseUJBQUEsdUJBQUEsT0FBQSxjQUFBLHdCQUFBLHFCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsdUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSxZQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsV0FBQSxhQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsYUFBQSxHQUFBLENBQUEsdUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxrQkFBQSxZQUFBLFFBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsV0FBQSxhQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsYUFBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSw2QkFBQSx3QkFBQSxjQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEseUJBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUN4RC9CLE1BQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFHRSxNQUFBLGlDQUFBLEdBQUEsd0NBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQSxFQUE2QixHQUFBLHdDQUFBLEdBQUEsQ0FBQTtBQXdQL0IsTUFBQSwwQkFBQTtBQUdBLE1BQUEsaUNBQUEsR0FBQSx3Q0FBQSxJQUFBLEdBQUEsT0FBQSxDQUFBOzs7QUE3UEssTUFBQSx5QkFBQSxTQUFBLENBQUEsSUFBQSxVQUFBLEVBQTJCLFFBQUEsSUFBQSxVQUFBO0FBRTlCLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsYUFBQSxXQUFBLElBQUEsQ0FBQTtBQTJQRixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsZ0JBQUEsSUFBQSxJQUFBLEVBQUE7OztJRHROSTtJQUFZO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFDWjtJQUFZO0lBQUE7SUFBQTtJQUFBO0lBQ1o7SUFBVztJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQ1g7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUFXO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0VBQUEsR0FBQSxlQUFBLEVBQUEsQ0FBQTs7OytFQUtGLGlCQUFlLENBQUE7VUF0QjNCO3VCQUNXLGNBQVksWUFDVixNQUFJLFNBQ1A7TUFDUDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO09BQ0QsV0FFVSxDQUFDLGdCQUFnQixHQUFDLFVBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBQUEsQ0FBQTs7VUFrQzVCO1dBQWEsa0JBQWtCLENBQUMsUUFBUSxDQUFDOzs7O2dGQWhDL0IsaUJBQWUsRUFBQSxXQUFBLG1CQUFBLFVBQUEsd0RBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OzhEQUFmLGlCQUFlLEVBQUEsU0FBQSxDQUFBLElBQUEsSUFBQSxJQUFBLEVBQUEsR0FBQSxDQUFBLGtCQUFBLGNBQUEsY0FBQSxhQUFBLGFBQUEsZUFBQSxTQUFBLG1CQUFBLGdCQUFBLHFCQUFBLGNBQUEsV0FBQSxjQUFBLGNBQUEsYUFBQSxXQUFBLFlBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLHdCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxDQUFBLE1BQUEsRUFBQSxPQUFBLE1BQUEsd0JBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbXSwiZGVidWdJZCI6IjQ2NDU3NWRhLTI3MmItNTg3ZC05NjgyLTVkMWQ5ZWQ3YmIzZCJ9