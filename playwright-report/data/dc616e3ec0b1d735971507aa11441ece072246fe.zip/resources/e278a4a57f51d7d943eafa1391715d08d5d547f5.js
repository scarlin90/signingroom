import { t as _defineProperty } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/defineProperty-wQpB4Zl9.js?v=cf17c1b4";
import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
import { Ar as _sanitizeUrl, Br as bypassSanitizationTrustUrl, Cc as INJECTOR_SCOPE, Cr as TracingService, Dr as ViewEncapsulation, El as ɵɵdefineInjector, F as createPlatformFactory, Fn as Injectable, Gi as setDocument, Hc as RuntimeError, Ic as PLATFORM_ID, Ir as bypassSanitizationTrustHtml, Kc as Version, Lc as PLATFORM_INITIALIZER, Lr as bypassSanitizationTrustResourceUrl, Nr as allLeavingAnimations, Pc as NgZone, Pn as Inject, Pr as allowSanitizationBypassAndThrow, Pt as CACHE_ACTIVE, Qi as unwrapSafeValue, Qn as Optional, Rr as bypassSanitizationTrustScript, Tc as InjectionToken, Tl as ɵɵdefineInjectable, Tr as USE_PENDING_TASKS, Uc as SecurityContext, Ui as setClassMetadata, Yc as _global, Yt as APP_BOOTSTRAP_LISTENER, Z as internalCreateApplication, ar as RendererFactory2, br as TestabilityRegistry, bt as withI18nSupport$1, dc as CSP_NONCE, dr as Service, fl as makeEnvironmentProviders, fn as Console, hc as ENVIRONMENT_INITIALIZER, hr as TESTABILITY_GETTER, io as ɵɵdefineService, jn as IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, kl as ɵɵinject, kr as _sanitizeHtml, lc as APP_ID, mr as TESTABILITY, nl as forwardRef, no as ɵɵdefineNgModule, ol as inject, or as RendererStyleFlags2, ot as platformCore, pc as DOCUMENT, qn as NgModule, sr as SHARED_STYLES_HOST, t as ApplicationModule, tl as formatRuntimeError, tn as ApplicationRef, ut as provideStabilityDebugging, vc as ErrorHandler, vt as withDomHydration, xt as withIncrementalHydration$1, yr as Testability, yt as withEventReplay$1, zr as bypassSanitizationTrustStyle } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/core-BV_jmGG7.js?v=cf17c1b4";
import { t as _asyncToGenerator } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/asyncToGenerator-B0cJ8fiL.js?v=cf17c1b4";
import { c as setRootDomAdapter, i as DomAdapter, n as parseCookieValue, s as getDOM } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/_xhr-chunk-CYugLJIp.js?v=cf17c1b4";
import { a as PLATFORM_BROWSER_ID, x as CommonModule } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/common-WY4jSC-k.js?v=cf17c1b4";
import { r as withHttpTransferCache } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/http-DHAZZSzh.js?v=cf17c1b4";
//#region node_modules/@angular/platform-browser/fesm2022/_dom_renderer-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _DomEventsPlugin;
var _EventManager;
var _SharedStylesHost;
var _DomRendererFactory;
var EventManagerPlugin = class {
	constructor(_doc) {
		_defineProperty(this, "_doc", void 0);
		_defineProperty(this, "manager", void 0);
		this._doc = _doc;
	}
};
var DomEventsPlugin = class extends EventManagerPlugin {
	constructor(doc) {
		super(doc);
	}
	supports(eventName) {
		return true;
	}
	addEventListener(element, eventName, handler, options) {
		element.addEventListener(eventName, handler, options);
		return () => this.removeEventListener(element, eventName, handler, options);
	}
	removeEventListener(target, eventName, callback, options) {
		return target.removeEventListener(eventName, callback, options);
	}
};
_DomEventsPlugin = DomEventsPlugin;
_defineProperty(DomEventsPlugin, "ɵfac", function DomEventsPlugin_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DomEventsPlugin)(ɵɵinject(DOCUMENT));
});
_defineProperty(DomEventsPlugin, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _DomEventsPlugin,
	factory: _DomEventsPlugin.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DomEventsPlugin, [{ type: Injectable }], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [DOCUMENT]
		}]
	}], null);
})();
var EVENT_MANAGER_PLUGINS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "EventManagerPlugins" : "");
var EventManager = class {
	constructor(plugins, _zone) {
		_defineProperty(this, "_zone", void 0);
		_defineProperty(this, "_plugins", void 0);
		_defineProperty(this, "_eventNameToPlugin", /* @__PURE__ */ new Map());
		this._zone = _zone;
		plugins.forEach((plugin) => {
			plugin.manager = this;
		});
		const otherPlugins = plugins.filter((p) => !(p instanceof DomEventsPlugin));
		this._plugins = otherPlugins.slice().reverse();
		const domEventPlugin = plugins.find((p) => p instanceof DomEventsPlugin);
		if (domEventPlugin) this._plugins.push(domEventPlugin);
	}
	addEventListener(element, eventName, handler, options) {
		return this._findPluginFor(eventName).addEventListener(element, eventName, handler, options);
	}
	getZone() {
		return this._zone;
	}
	_findPluginFor(eventName) {
		let plugin = this._eventNameToPlugin.get(eventName);
		if (plugin) return plugin;
		plugin = this._plugins.find((plugin) => plugin.supports(eventName));
		if (!plugin) throw new RuntimeError(-5101, (typeof ngDevMode === "undefined" || ngDevMode) && `No event manager plugin found for event ${eventName}`);
		this._eventNameToPlugin.set(eventName, plugin);
		return plugin;
	}
};
_EventManager = EventManager;
_defineProperty(EventManager, "ɵfac", function EventManager_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _EventManager)(ɵɵinject(EVENT_MANAGER_PLUGINS), ɵɵinject(NgZone));
});
_defineProperty(EventManager, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _EventManager,
	factory: _EventManager.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EventManager, [{ type: Injectable }], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [EVENT_MANAGER_PLUGINS]
		}]
	}, { type: NgZone }], null);
})();
var APP_ID_ATTRIBUTE_NAME = "ng-app-id";
function removeElements(elements) {
	for (const element of elements) element.remove();
}
function createStyleElement(style, doc) {
	const styleElement = doc.createElement("style");
	styleElement.textContent = style;
	return styleElement;
}
function addServerStyles(doc, appId, inline, external) {
	var _doc$head;
	const elements = (_doc$head = doc.head) === null || _doc$head === void 0 ? void 0 : _doc$head.querySelectorAll(`style[${APP_ID_ATTRIBUTE_NAME}="${appId}"],link[${APP_ID_ATTRIBUTE_NAME}="${appId}"]`);
	if (!elements || elements.length === 0) return false;
	for (const styleElement of elements) {
		styleElement.removeAttribute(APP_ID_ATTRIBUTE_NAME);
		if (styleElement instanceof HTMLLinkElement) external.set(styleElement.href.slice(styleElement.href.lastIndexOf("/") + 1), {
			usage: 0,
			elements: [styleElement]
		});
		else if (styleElement.textContent) inline.set(styleElement.textContent, {
			usage: 0,
			elements: [styleElement]
		});
	}
	return true;
}
function createLinkElement(url, doc) {
	const linkElement = doc.createElement("link");
	linkElement.setAttribute("rel", "stylesheet");
	linkElement.setAttribute("href", url);
	return linkElement;
}
var SharedStylesHost = class {
	constructor(doc, appId, nonce, platformId = {}) {
		_defineProperty(this, "doc", void 0);
		_defineProperty(this, "appId", void 0);
		_defineProperty(this, "nonce", void 0);
		_defineProperty(this, "inline", /* @__PURE__ */ new Map());
		_defineProperty(this, "external", /* @__PURE__ */ new Map());
		_defineProperty(this, "hosts", /* @__PURE__ */ new Set());
		this.doc = doc;
		this.appId = appId;
		this.nonce = nonce;
		if (addServerStyles(doc, appId, this.inline, this.external)) this.hosts.add(doc.head);
	}
	addStyles(styles, urls) {
		for (const value of styles) this.addUsage(value, this.inline, createStyleElement);
		urls === null || urls === void 0 || urls.forEach((value) => this.addUsage(value, this.external, createLinkElement));
	}
	removeStyles(styles, urls) {
		for (const value of styles) this.removeUsage(value, this.inline);
		urls === null || urls === void 0 || urls.forEach((value) => this.removeUsage(value, this.external));
	}
	addUsage(value, usages, creator) {
		const record = usages.get(value);
		if (record) {
			if ((typeof ngDevMode === "undefined" || ngDevMode) && record.usage === 0) record.elements.forEach((element) => element.setAttribute("ng-style-reused", ""));
			record.usage++;
		} else usages.set(value, {
			usage: 1,
			elements: [...this.hosts].map((host) => this.addElement(host, creator(value, this.doc)))
		});
	}
	removeUsage(value, usages) {
		const record = usages.get(value);
		if (record) {
			record.usage--;
			if (record.usage <= 0) {
				removeElements(record.elements);
				usages.delete(value);
			}
		}
	}
	ngOnDestroy() {
		for (const [, { elements }] of [...this.inline, ...this.external]) removeElements(elements);
		this.hosts.clear();
	}
	addHost(hostNode) {
		if (this.hosts.has(hostNode)) return;
		this.hosts.add(hostNode);
		for (const [style, { elements }] of this.inline) elements.push(this.addElement(hostNode, createStyleElement(style, this.doc)));
		for (const [url, { elements }] of this.external) elements.push(this.addElement(hostNode, createLinkElement(url, this.doc)));
	}
	removeHost(hostNode) {
		this.hosts.delete(hostNode);
		for (const record of [...this.inline.values(), ...this.external.values()]) {
			const remaining = [];
			for (const element of record.elements) if (element.parentNode === hostNode) element.remove();
			else remaining.push(element);
			record.elements = remaining;
		}
	}
	addElement(host, element) {
		if (this.nonce) element.setAttribute("nonce", this.nonce);
		return host.appendChild(element);
	}
};
_SharedStylesHost = SharedStylesHost;
_defineProperty(SharedStylesHost, "ɵfac", function SharedStylesHost_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _SharedStylesHost)(ɵɵinject(DOCUMENT), ɵɵinject(APP_ID), ɵɵinject(CSP_NONCE, 8), ɵɵinject(PLATFORM_ID));
});
_defineProperty(SharedStylesHost, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _SharedStylesHost,
	factory: _SharedStylesHost.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SharedStylesHost, [{ type: Injectable }], () => [
		{
			type: Document,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [APP_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [CSP_NONCE]
			}, { type: Optional }]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [PLATFORM_ID]
			}]
		}
	], null);
})();
var NAMESPACE_URIS = {
	"svg": "http://www.w3.org/2000/svg",
	"xhtml": "http://www.w3.org/1999/xhtml",
	"xlink": "http://www.w3.org/1999/xlink",
	"xml": "http://www.w3.org/XML/1998/namespace",
	"xmlns": "http://www.w3.org/2000/xmlns/",
	"math": "http://www.w3.org/1998/Math/MathML"
};
var COMPONENT_REGEX = /%COMP%/g;
var SOURCEMAP_URL_REGEXP = /\/\*#\s*sourceMappingURL=([^\s*]+)\s*\*\//;
var PROTOCOL_REGEXP = /^https?:/;
var COMPONENT_VARIABLE = "%COMP%";
var HOST_ATTR = `_nghost-${COMPONENT_VARIABLE}`;
var CONTENT_ATTR = `_ngcontent-${COMPONENT_VARIABLE}`;
var REMOVE_STYLES_ON_COMPONENT_DESTROY_DEFAULT = true;
var REMOVE_STYLES_ON_COMPONENT_DESTROY = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "RemoveStylesOnCompDestroy" : "", { factory: () => REMOVE_STYLES_ON_COMPONENT_DESTROY_DEFAULT });
var CSS_VAR_NAMESPACE = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "CSS_VAR_NAMESPACE" : "");
function provideCssVarNamespacing(namespace) {
	return makeEnvironmentProviders([{
		provide: CSS_VAR_NAMESPACE,
		useFactory: (appId) => `${namespace !== null && namespace !== void 0 ? namespace : appId}_`,
		deps: [APP_ID]
	}]);
}
function shimContentAttribute(componentShortId) {
	return CONTENT_ATTR.replace(COMPONENT_REGEX, componentShortId);
}
function shimHostAttribute(componentShortId) {
	return HOST_ATTR.replace(COMPONENT_REGEX, componentShortId);
}
function shimStylesContent(compId, styles) {
	return styles.map((s) => s.replace(COMPONENT_REGEX, compId));
}
function addBaseHrefToCssSourceMap(baseHref, styles) {
	if (!baseHref) return styles;
	const absoluteBaseHrefUrl = new URL(baseHref, "http://localhost");
	return styles.map((cssContent) => {
		if (!cssContent.includes("sourceMappingURL=")) return cssContent;
		return cssContent.replace(SOURCEMAP_URL_REGEXP, (_, sourceMapUrl) => {
			if (sourceMapUrl[0] === "/" || sourceMapUrl.startsWith("data:") || PROTOCOL_REGEXP.test(sourceMapUrl)) return `/*# sourceMappingURL=${sourceMapUrl} */`;
			const { pathname: resolvedSourceMapUrl } = new URL(sourceMapUrl, absoluteBaseHrefUrl);
			return `/*# sourceMappingURL=${resolvedSourceMapUrl} */`;
		});
	});
}
var DomRendererFactory2 = class {
	constructor(eventManager, sharedStylesHost, appId, removeStylesOnCompDestroy, doc, ngZone, nonce = null, tracingService = null, cssVarNamespace = null) {
		_defineProperty(this, "eventManager", void 0);
		_defineProperty(this, "sharedStylesHost", void 0);
		_defineProperty(this, "appId", void 0);
		_defineProperty(this, "removeStylesOnCompDestroy", void 0);
		_defineProperty(this, "doc", void 0);
		_defineProperty(this, "ngZone", void 0);
		_defineProperty(this, "nonce", void 0);
		_defineProperty(this, "tracingService", void 0);
		_defineProperty(this, "rendererByCompId", /* @__PURE__ */ new Map());
		_defineProperty(this, "defaultRenderer", void 0);
		_defineProperty(this, "cssVarNamespace", void 0);
		this.eventManager = eventManager;
		this.sharedStylesHost = sharedStylesHost;
		this.appId = appId;
		this.removeStylesOnCompDestroy = removeStylesOnCompDestroy;
		this.doc = doc;
		this.ngZone = ngZone;
		this.nonce = nonce;
		this.tracingService = tracingService;
		this.cssVarNamespace = cssVarNamespace !== null && cssVarNamespace !== void 0 ? cssVarNamespace : "";
		this.defaultRenderer = new DefaultDomRenderer2(eventManager, doc, ngZone, this.tracingService, this.cssVarNamespace);
	}
	createRenderer(element, type) {
		if (!element || !type) return this.defaultRenderer;
		const renderer = this.getOrCreateRenderer(element, type);
		if (renderer instanceof EmulatedEncapsulationDomRenderer2) renderer.applyToHost(element);
		else if (renderer instanceof NoneEncapsulationDomRenderer) renderer.applyStyles();
		return renderer;
	}
	getOrCreateRenderer(element, type) {
		const rendererByCompId = this.rendererByCompId;
		let renderer = rendererByCompId.get(type.id);
		if (!renderer) {
			const doc = this.doc;
			const ngZone = this.ngZone;
			const eventManager = this.eventManager;
			const sharedStylesHost = this.sharedStylesHost;
			const removeStylesOnCompDestroy = this.removeStylesOnCompDestroy;
			const tracingService = this.tracingService;
			switch (type.encapsulation) {
				case ViewEncapsulation.Emulated:
					renderer = new EmulatedEncapsulationDomRenderer2(eventManager, sharedStylesHost, type, this.appId, removeStylesOnCompDestroy, doc, ngZone, tracingService, this.cssVarNamespace);
					break;
				case ViewEncapsulation.ShadowDom: return new ShadowDomRenderer(eventManager, element, type, doc, ngZone, this.nonce, tracingService, this.cssVarNamespace, sharedStylesHost);
				case ViewEncapsulation.ExperimentalIsolatedShadowDom: return new ShadowDomRenderer(eventManager, element, type, doc, ngZone, this.nonce, tracingService, this.cssVarNamespace);
				default:
					renderer = new NoneEncapsulationDomRenderer(eventManager, sharedStylesHost, type, removeStylesOnCompDestroy, doc, ngZone, tracingService, this.cssVarNamespace);
					break;
			}
			rendererByCompId.set(type.id, renderer);
		}
		return renderer;
	}
	ngOnDestroy() {
		this.rendererByCompId.clear();
	}
	componentReplaced(componentId) {
		this.rendererByCompId.delete(componentId);
	}
};
_DomRendererFactory = DomRendererFactory2;
_defineProperty(DomRendererFactory2, "ɵfac", function DomRendererFactory2_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DomRendererFactory)(ɵɵinject(EventManager), ɵɵinject(SHARED_STYLES_HOST), ɵɵinject(APP_ID), ɵɵinject(REMOVE_STYLES_ON_COMPONENT_DESTROY), ɵɵinject(DOCUMENT), ɵɵinject(NgZone), ɵɵinject(CSP_NONCE), ɵɵinject(TracingService, 8), ɵɵinject(CSS_VAR_NAMESPACE, 8));
});
_defineProperty(DomRendererFactory2, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _DomRendererFactory,
	factory: _DomRendererFactory.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DomRendererFactory2, [{ type: Injectable }], () => [
		{ type: EventManager },
		{
			type: SharedStylesHost,
			decorators: [{
				type: Inject,
				args: [SHARED_STYLES_HOST]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [APP_ID]
			}]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [REMOVE_STYLES_ON_COMPONENT_DESTROY]
			}]
		},
		{
			type: Document,
			decorators: [{
				type: Inject,
				args: [DOCUMENT]
			}]
		},
		{ type: NgZone },
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [CSP_NONCE]
			}]
		},
		{
			type: TracingService,
			decorators: [{
				type: Inject,
				args: [TracingService]
			}, { type: Optional }]
		},
		{
			type: void 0,
			decorators: [{
				type: Inject,
				args: [CSS_VAR_NAMESPACE]
			}, { type: Optional }]
		}
	], null);
})();
var DefaultDomRenderer2 = class {
	constructor(eventManager, doc, ngZone, tracingService, cssVarNamespace = "") {
		_defineProperty(this, "eventManager", void 0);
		_defineProperty(this, "doc", void 0);
		_defineProperty(this, "ngZone", void 0);
		_defineProperty(this, "tracingService", void 0);
		_defineProperty(this, "cssVarNamespace", void 0);
		_defineProperty(this, "data", Object.create(null));
		_defineProperty(this, "throwOnSyntheticProps", true);
		_defineProperty(this, "destroyNode", null);
		this.eventManager = eventManager;
		this.doc = doc;
		this.ngZone = ngZone;
		this.tracingService = tracingService;
		this.cssVarNamespace = cssVarNamespace;
	}
	destroy() {}
	createElement(name, namespace) {
		if (namespace) return this.doc.createElementNS(NAMESPACE_URIS[namespace] || namespace, name);
		return this.doc.createElement(name);
	}
	createComment(value) {
		return this.doc.createComment(value);
	}
	createText(value) {
		return this.doc.createTextNode(value);
	}
	appendChild(parent, newChild) {
		(isTemplateNode(parent) ? parent.content : parent).appendChild(newChild);
	}
	insertBefore(parent, newChild, refChild) {
		if (parent) (isTemplateNode(parent) ? parent.content : parent).insertBefore(newChild, refChild);
	}
	removeChild(_parent, oldChild) {
		oldChild.remove();
	}
	selectRootElement(selectorOrNode, preserveContent) {
		let el = typeof selectorOrNode === "string" ? this.doc.querySelector(selectorOrNode) : selectorOrNode;
		if (!el) throw new RuntimeError(-5104, (typeof ngDevMode === "undefined" || ngDevMode) && `The selector "${selectorOrNode}" did not match any elements`);
		if (!preserveContent) el.textContent = "";
		return el;
	}
	parentNode(node) {
		return node.parentNode;
	}
	nextSibling(node) {
		return node.nextSibling;
	}
	setAttribute(el, name, value, namespace) {
		if (namespace) {
			name = namespace + ":" + name;
			const namespaceUri = NAMESPACE_URIS[namespace];
			if (namespaceUri) el.setAttributeNS(namespaceUri, name, value);
			else el.setAttribute(name, value);
		} else el.setAttribute(name, value);
	}
	removeAttribute(el, name, namespace) {
		if (namespace) {
			const namespaceUri = NAMESPACE_URIS[namespace];
			if (namespaceUri) el.removeAttributeNS(namespaceUri, name);
			else el.removeAttribute(`${namespace}:${name}`);
		} else el.removeAttribute(name);
	}
	addClass(el, name) {
		el.classList.add(name);
	}
	removeClass(el, name) {
		el.classList.remove(name);
	}
	setStyle(el, style, value, flags) {
		const isVariable = style.startsWith("--");
		if (isVariable) style = style.replace("%NS%", this.cssVarNamespace);
		if (isVariable || flags & (RendererStyleFlags2.DashCase | RendererStyleFlags2.Important)) el.style.setProperty(style, value, flags & RendererStyleFlags2.Important ? "important" : "");
		else el.style[style] = value;
	}
	removeStyle(el, style, flags) {
		const isVariable = style.startsWith("--");
		if (isVariable) style = style.replace("%NS%", this.cssVarNamespace);
		if (isVariable || flags & RendererStyleFlags2.DashCase) el.style.removeProperty(style);
		else el.style[style] = "";
	}
	setProperty(el, name, value) {
		if (el == null) return;
		(typeof ngDevMode === "undefined" || ngDevMode) && this.throwOnSyntheticProps && checkNoSyntheticProp(name, "property");
		el[name] = value;
	}
	setValue(node, value) {
		node.nodeValue = value;
	}
	listen(target, event, callback, options) {
		var _this$tracingService;
		(typeof ngDevMode === "undefined" || ngDevMode) && this.throwOnSyntheticProps && checkNoSyntheticProp(event, "listener");
		if (typeof target === "string") {
			target = getDOM().getGlobalEventTarget(this.doc, target);
			if (!target) throw new RuntimeError(-5102, (typeof ngDevMode === "undefined" || ngDevMode) && `Unsupported event target ${target} for event ${event}`);
		}
		let wrappedCallback = this.decoratePreventDefault(callback);
		if ((_this$tracingService = this.tracingService) === null || _this$tracingService === void 0 ? void 0 : _this$tracingService.wrapEventListener) wrappedCallback = this.tracingService.wrapEventListener(target, event, wrappedCallback);
		return this.eventManager.addEventListener(target, event, wrappedCallback, options);
	}
	decoratePreventDefault(eventHandler) {
		return (event) => {
			if (event === "__ngUnwrap__") return eventHandler;
			if (eventHandler(event) === false) event.preventDefault();
		};
	}
};
var AT_CHARCODE = (() => "@".charCodeAt(0))();
function checkNoSyntheticProp(name, nameKind) {
	if (name.charCodeAt(0) === AT_CHARCODE) throw new RuntimeError(5105, `Unexpected synthetic ${nameKind} ${name} found. Please make sure that:
  - Make sure \`provideAnimationsAsync()\`, \`provideAnimations()\` or \`provideNoopAnimations()\` call was added to a list of providers used to bootstrap an application.
  - There is a corresponding animation configuration named \`${name}\` defined in the \`animations\` field of the \`@Component\` decorator (see https://angular.dev/api/core/Component#animations).`);
}
function isTemplateNode(node) {
	return node.tagName === "TEMPLATE" && node.content !== void 0;
}
var ShadowDomRenderer = class extends DefaultDomRenderer2 {
	constructor(eventManager, hostEl, component, doc, ngZone, nonce, tracingService, cssVarNamespace, sharedStylesHost) {
		var _component$getExterna;
		super(eventManager, doc, ngZone, tracingService, cssVarNamespace);
		_defineProperty(this, "hostEl", void 0);
		_defineProperty(this, "sharedStylesHost", void 0);
		_defineProperty(this, "shadowRoot", void 0);
		this.hostEl = hostEl;
		this.sharedStylesHost = sharedStylesHost;
		this.shadowRoot = hostEl.attachShadow({ mode: "open" });
		if (this.sharedStylesHost) this.sharedStylesHost.addHost(this.shadowRoot);
		let styles = component.styles;
		if (ngDevMode) {
			var _getDOM$getBaseHref;
			styles = addBaseHrefToCssSourceMap((_getDOM$getBaseHref = getDOM().getBaseHref(doc)) !== null && _getDOM$getBaseHref !== void 0 ? _getDOM$getBaseHref : "", styles);
		}
		styles = shimStylesContent(component.id, styles).map((s) => s.replace(/%NS%/g, cssVarNamespace));
		for (const style of styles) {
			const styleEl = document.createElement("style");
			if (nonce) styleEl.setAttribute("nonce", nonce);
			styleEl.textContent = style;
			this.shadowRoot.appendChild(styleEl);
		}
		const styleUrls = (_component$getExterna = component.getExternalStyles) === null || _component$getExterna === void 0 ? void 0 : _component$getExterna.call(component);
		if (styleUrls) for (const styleUrl of styleUrls) {
			const linkEl = createLinkElement(styleUrl, doc);
			if (nonce) linkEl.setAttribute("nonce", nonce);
			this.shadowRoot.appendChild(linkEl);
		}
	}
	nodeOrShadowRoot(node) {
		return node === this.hostEl ? this.shadowRoot : node;
	}
	appendChild(parent, newChild) {
		return super.appendChild(this.nodeOrShadowRoot(parent), newChild);
	}
	insertBefore(parent, newChild, refChild) {
		return super.insertBefore(this.nodeOrShadowRoot(parent), newChild, refChild);
	}
	removeChild(_parent, oldChild) {
		return super.removeChild(null, oldChild);
	}
	parentNode(node) {
		return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(node)));
	}
	destroy() {
		if (this.sharedStylesHost) this.sharedStylesHost.removeHost(this.shadowRoot);
	}
};
var NoneEncapsulationDomRenderer = class extends DefaultDomRenderer2 {
	constructor(eventManager, sharedStylesHost, component, removeStylesOnCompDestroy, doc, ngZone, tracingService, cssVarNamespace, compId) {
		var _component$getExterna2;
		super(eventManager, doc, ngZone, tracingService, cssVarNamespace);
		_defineProperty(this, "sharedStylesHost", void 0);
		_defineProperty(this, "removeStylesOnCompDestroy", void 0);
		_defineProperty(this, "styles", void 0);
		_defineProperty(this, "styleUrls", void 0);
		this.sharedStylesHost = sharedStylesHost;
		this.removeStylesOnCompDestroy = removeStylesOnCompDestroy;
		let styles = component.styles;
		if (ngDevMode) {
			var _getDOM$getBaseHref2;
			styles = addBaseHrefToCssSourceMap((_getDOM$getBaseHref2 = getDOM().getBaseHref(doc)) !== null && _getDOM$getBaseHref2 !== void 0 ? _getDOM$getBaseHref2 : "", styles);
		}
		const shimmed = compId ? shimStylesContent(compId, styles) : styles;
		this.styles = shimmed.map((s) => s.replace(/%NS%/g, cssVarNamespace));
		this.styleUrls = (_component$getExterna2 = component.getExternalStyles) === null || _component$getExterna2 === void 0 ? void 0 : _component$getExterna2.call(component, compId);
	}
	applyStyles() {
		this.sharedStylesHost.addStyles(this.styles, this.styleUrls);
	}
	destroy() {
		if (!this.removeStylesOnCompDestroy) return;
		if (allLeavingAnimations.size === 0) this.sharedStylesHost.removeStyles(this.styles, this.styleUrls);
	}
};
var EmulatedEncapsulationDomRenderer2 = class extends NoneEncapsulationDomRenderer {
	constructor(eventManager, sharedStylesHost, component, appId, removeStylesOnCompDestroy, doc, ngZone, tracingService, cssVarNamespace) {
		const compId = appId + "-" + component.id;
		super(eventManager, sharedStylesHost, component, removeStylesOnCompDestroy, doc, ngZone, tracingService, cssVarNamespace, compId);
		_defineProperty(this, "contentAttr", void 0);
		_defineProperty(this, "hostAttr", void 0);
		this.contentAttr = shimContentAttribute(compId);
		this.hostAttr = shimHostAttribute(compId);
	}
	applyToHost(element) {
		this.applyStyles();
		this.setAttribute(element, this.hostAttr, "");
	}
	createElement(parent, name) {
		const el = super.createElement(parent, name);
		super.setAttribute(el, this.contentAttr, "");
		return el;
	}
};
//#endregion
//#region node_modules/@angular/platform-browser/fesm2022/_browser-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _KeyEventsPlugin;
var _BrowserModule;
var BrowserDomAdapter = class BrowserDomAdapter extends DomAdapter {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "supportsDOMEvents", true);
	}
	static makeCurrent() {
		setRootDomAdapter(new BrowserDomAdapter());
	}
	onAndCancel(el, evt, listener, options) {
		el.addEventListener(evt, listener, options);
		return () => {
			el.removeEventListener(evt, listener, options);
		};
	}
	dispatchEvent(el, evt) {
		el.dispatchEvent(evt);
	}
	remove(node) {
		node.remove();
	}
	createElement(tagName, doc) {
		doc = doc || this.getDefaultDocument();
		return doc.createElement(tagName);
	}
	createHtmlDocument() {
		return document.implementation.createHTMLDocument("fakeTitle");
	}
	getDefaultDocument() {
		return document;
	}
	isElementNode(node) {
		return node.nodeType === Node.ELEMENT_NODE;
	}
	isShadowRoot(node) {
		return node instanceof DocumentFragment;
	}
	getGlobalEventTarget(doc, target) {
		if (target === "window") return window;
		if (target === "document") return doc;
		if (target === "body") return doc.body;
		return null;
	}
	getBaseHref(doc) {
		const href = getBaseElementHref();
		return href == null ? null : relativePath(href);
	}
	resetBaseElement() {
		baseElement = null;
	}
	getUserAgent() {
		return window.navigator.userAgent;
	}
	getCookie(name) {
		return parseCookieValue(document.cookie, name);
	}
};
var baseElement = null;
function getBaseElementHref() {
	baseElement = baseElement || document.head.querySelector("base");
	return baseElement ? baseElement.getAttribute("href") : null;
}
function relativePath(url) {
	return new URL(url, document.baseURI).pathname;
}
var BrowserGetTestability = class {
	addToWindow(registry) {
		_global["getAngularTestability"] = (elem, findInAncestors = true) => {
			const testability = registry.findTestabilityInTree(elem, findInAncestors);
			if (testability == null) throw new RuntimeError(5103, (typeof ngDevMode === "undefined" || ngDevMode) && "Could not find testability for element.");
			return testability;
		};
		_global["getAllAngularTestabilities"] = () => registry.getAllTestabilities();
		_global["getAllAngularRootElements"] = () => registry.getAllRootElements();
		const whenAllStable = (callback) => {
			const testabilities = _global["getAllAngularTestabilities"]();
			let count = testabilities.length;
			const decrement = function() {
				count--;
				if (count == 0) callback();
			};
			testabilities.forEach((testability) => {
				testability.whenStable(decrement);
			});
		};
		if (!_global["frameworkStabilizers"]) _global["frameworkStabilizers"] = [];
		_global["frameworkStabilizers"].push(whenAllStable);
	}
	findTestabilityInTree(registry, elem, findInAncestors) {
		if (elem == null) return null;
		const t = registry.getTestability(elem);
		if (t != null) return t;
		else if (!findInAncestors) return null;
		if (getDOM().isShadowRoot(elem)) return this.findTestabilityInTree(registry, elem.host, true);
		return this.findTestabilityInTree(registry, elem.parentElement, true);
	}
};
var MODIFIER_KEYS = [
	"alt",
	"control",
	"meta",
	"shift"
];
var _keyMap = {
	"\b": "Backspace",
	"	": "Tab",
	"": "Delete",
	"\x1B": "Escape",
	"Del": "Delete",
	"Esc": "Escape",
	"Left": "ArrowLeft",
	"Right": "ArrowRight",
	"Up": "ArrowUp",
	"Down": "ArrowDown",
	"Menu": "ContextMenu",
	"Scroll": "ScrollLock",
	"Win": "OS"
};
var MODIFIER_KEY_GETTERS = {
	"alt": (event) => event.altKey,
	"control": (event) => event.ctrlKey,
	"meta": (event) => event.metaKey,
	"shift": (event) => event.shiftKey
};
var KeyEventsPlugin = class KeyEventsPlugin extends EventManagerPlugin {
	constructor(doc) {
		super(doc);
	}
	supports(eventName) {
		return KeyEventsPlugin.parseEventName(eventName) != null;
	}
	addEventListener(element, eventName, handler, options) {
		const parsedEvent = KeyEventsPlugin.parseEventName(eventName);
		const outsideHandler = KeyEventsPlugin.eventCallback(parsedEvent["fullKey"], handler, this.manager.getZone());
		return this.manager.getZone().runOutsideAngular(() => {
			return getDOM().onAndCancel(element, parsedEvent["domEventName"], outsideHandler, options);
		});
	}
	static parseEventName(eventName) {
		const parts = eventName.toLowerCase().split(".");
		const domEventName = parts.shift();
		if (parts.length === 0 || !(domEventName === "keydown" || domEventName === "keyup")) return null;
		const key = KeyEventsPlugin._normalizeKey(parts.pop());
		let fullKey = "";
		let codeIX = parts.indexOf("code");
		if (codeIX > -1) {
			parts.splice(codeIX, 1);
			fullKey = "code.";
		}
		MODIFIER_KEYS.forEach((modifierName) => {
			const index = parts.indexOf(modifierName);
			if (index > -1) {
				parts.splice(index, 1);
				fullKey += modifierName + ".";
			}
		});
		fullKey += key;
		if (parts.length != 0 || key.length === 0) return null;
		const result = {};
		result["domEventName"] = domEventName;
		result["fullKey"] = fullKey;
		return result;
	}
	static matchEventFullKeyCode(event, fullKeyCode) {
		let keycode = _keyMap[event.key] || event.key;
		let key = "";
		if (fullKeyCode.indexOf("code.") > -1) {
			keycode = event.code;
			key = "code.";
		}
		if (keycode == null || !keycode) return false;
		keycode = keycode.toLowerCase();
		if (keycode === " ") keycode = "space";
		else if (keycode === ".") keycode = "dot";
		MODIFIER_KEYS.forEach((modifierName) => {
			if (modifierName !== keycode) {
				const modifierGetter = MODIFIER_KEY_GETTERS[modifierName];
				if (modifierGetter(event)) key += modifierName + ".";
			}
		});
		key += keycode;
		return key === fullKeyCode;
	}
	static eventCallback(fullKey, handler, zone) {
		return (event) => {
			if (KeyEventsPlugin.matchEventFullKeyCode(event, fullKey)) zone.runGuarded(() => handler(event));
		};
	}
	static _normalizeKey(keyName) {
		return keyName === "esc" ? "escape" : keyName;
	}
};
_KeyEventsPlugin = KeyEventsPlugin;
_defineProperty(KeyEventsPlugin, "ɵfac", function KeyEventsPlugin_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _KeyEventsPlugin)(ɵɵinject(DOCUMENT));
});
_defineProperty(KeyEventsPlugin, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _KeyEventsPlugin,
	factory: _KeyEventsPlugin.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(KeyEventsPlugin, [{ type: Injectable }], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [DOCUMENT]
		}]
	}], null);
})();
function bootstrapApplication(_x, _x2, _x3) {
	return _bootstrapApplication.apply(this, arguments);
}
function _bootstrapApplication() {
	_bootstrapApplication = _asyncToGenerator(function* (rootComponent, options, context) {
		return internalCreateApplication(_objectSpread2({ rootComponent }, createProvidersConfig(options, context)));
	});
	return _bootstrapApplication.apply(this, arguments);
}
function createApplication(_x4, _x5) {
	return _createApplication.apply(this, arguments);
}
function _createApplication() {
	_createApplication = _asyncToGenerator(function* (options, context) {
		return internalCreateApplication(createProvidersConfig(options, context));
	});
	return _createApplication.apply(this, arguments);
}
function createProvidersConfig(options, context) {
	var _options$providers;
	return {
		platformRef: context === null || context === void 0 ? void 0 : context.platformRef,
		appProviders: [...BROWSER_MODULE_PROVIDERS, ...(_options$providers = options === null || options === void 0 ? void 0 : options.providers) !== null && _options$providers !== void 0 ? _options$providers : []],
		platformProviders: INTERNAL_BROWSER_PLATFORM_PROVIDERS
	};
}
function provideProtractorTestingSupport(options = {}) {
	var _options$usePendingTa;
	return [...TESTABILITY_PROVIDERS, (options === null || options === void 0 ? void 0 : options.usePendingTasksForStability) !== void 0 ? {
		provide: USE_PENDING_TASKS,
		useValue: (_options$usePendingTa = options.usePendingTasksForStability) !== null && _options$usePendingTa !== void 0 ? _options$usePendingTa : false
	} : []];
}
function initDomAdapter() {
	BrowserDomAdapter.makeCurrent();
}
function errorHandler() {
	return new ErrorHandler();
}
function _document() {
	setDocument(document);
	return document;
}
var INTERNAL_BROWSER_PLATFORM_PROVIDERS = [
	{
		provide: PLATFORM_ID,
		useValue: PLATFORM_BROWSER_ID
	},
	{
		provide: PLATFORM_INITIALIZER,
		useValue: initDomAdapter,
		multi: true
	},
	{
		provide: DOCUMENT,
		useFactory: _document
	}
];
var platformBrowser = createPlatformFactory(platformCore, "browser", INTERNAL_BROWSER_PLATFORM_PROVIDERS);
var BROWSER_MODULE_PROVIDERS_MARKER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "BrowserModule Providers Marker" : "");
var TESTABILITY_PROVIDERS = [
	{
		provide: TESTABILITY_GETTER,
		useClass: BrowserGetTestability
	},
	{
		provide: TESTABILITY,
		useClass: Testability,
		deps: [
			NgZone,
			TestabilityRegistry,
			TESTABILITY_GETTER
		]
	},
	{
		provide: Testability,
		useClass: Testability,
		deps: [
			NgZone,
			TestabilityRegistry,
			TESTABILITY_GETTER
		]
	}
];
var BROWSER_MODULE_PROVIDERS = [
	{
		provide: INJECTOR_SCOPE,
		useValue: "root"
	},
	{
		provide: ErrorHandler,
		useFactory: errorHandler
	},
	{
		provide: EVENT_MANAGER_PLUGINS,
		useClass: DomEventsPlugin,
		multi: true
	},
	{
		provide: EVENT_MANAGER_PLUGINS,
		useClass: KeyEventsPlugin,
		multi: true
	},
	DomRendererFactory2,
	{
		provide: SHARED_STYLES_HOST,
		useClass: SharedStylesHost
	},
	{
		provide: SharedStylesHost,
		useExisting: SHARED_STYLES_HOST
	},
	EventManager,
	{
		provide: RendererFactory2,
		useExisting: DomRendererFactory2
	},
	typeof ngDevMode === "undefined" || ngDevMode ? {
		provide: BROWSER_MODULE_PROVIDERS_MARKER,
		useValue: true
	} : []
];
var BrowserModule = class {
	constructor() {
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			if (inject(BROWSER_MODULE_PROVIDERS_MARKER, {
				optional: true,
				skipSelf: true
			})) throw new RuntimeError(5100, "Providers from the `BrowserModule` have already been loaded. If you need access to common directives such as NgIf and NgFor, import the `CommonModule` instead.");
		}
	}
};
_BrowserModule = BrowserModule;
_defineProperty(BrowserModule, "ɵfac", function BrowserModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _BrowserModule)();
});
_defineProperty(BrowserModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({
	type: _BrowserModule,
	exports: [CommonModule, ApplicationModule]
}));
_defineProperty(BrowserModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({
	providers: [...BROWSER_MODULE_PROVIDERS, ...TESTABILITY_PROVIDERS],
	imports: [CommonModule, ApplicationModule]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BrowserModule, [{
		type: NgModule,
		args: [{
			providers: [...BROWSER_MODULE_PROVIDERS, ...TESTABILITY_PROVIDERS],
			exports: [CommonModule, ApplicationModule]
		}]
	}], () => [], null);
})();
//#endregion
//#region node_modules/@angular/platform-browser/fesm2022/platform-browser.mjs
var _Meta;
var _Title;
var _CssVarNamespacer;
var _DomSanitizer;
var _DomSanitizerImpl;
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var Meta = class {
	constructor() {
		_defineProperty(this, "_doc", inject(DOCUMENT));
		_defineProperty(this, "_dom", getDOM());
		_defineProperty(this, "_cachedHead", void 0);
	}
	addTag(tag, forceCreation = false) {
		if (!tag) return null;
		return this._getOrCreateElement(tag, forceCreation);
	}
	addTags(tags, forceCreation = false) {
		return tags.filter((tag) => !!tag).map((tag) => this._getOrCreateElement(tag, forceCreation));
	}
	getTag(attrSelector) {
		if (!attrSelector) return null;
		const meta = this._doc.querySelector(buildMetaSelector(attrSelector));
		return isMetaTag(meta) ? meta : null;
	}
	getTags(attrSelector) {
		if (!attrSelector) return [];
		const list = this._doc.querySelectorAll(buildMetaSelector(attrSelector));
		return list ? Array.from(list).filter((elem) => isMetaTag(elem)) : [];
	}
	updateTag(tag, selector) {
		var _selector;
		(_selector = selector) !== null && _selector !== void 0 || (selector = parseSelector(tag));
		const meta = this.getTag(selector);
		if (meta) {
			setMetaElementAttributes(tag, meta);
			return meta;
		}
		return this._getOrCreateElement(tag, true);
	}
	removeTag(attrSelector) {
		this.removeTagElement(this.getTag(attrSelector));
	}
	removeTagElement(meta) {
		if (meta) this._dom.remove(meta);
	}
	_getOrCreateElement(meta, forceCreation = false) {
		if (!forceCreation) {
			const selector = parseSelector(meta);
			const elem = this.getTags(selector).filter((elem) => containsAttributes(meta, elem))[0];
			if (elem !== void 0) return elem;
		}
		const element = this._dom.createElement("meta");
		setMetaElementAttributes(meta, element);
		this._doc.getElementsByTagName("head")[0].appendChild(element);
		return element;
	}
};
_Meta = Meta;
_defineProperty(Meta, "ɵfac", function Meta_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _Meta)();
});
_defineProperty(Meta, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _Meta,
	factory: _Meta.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Meta, [{ type: Service }], null, null);
})();
function buildMetaSelector(attrSelector) {
	return `meta[${attrSelector}]`;
}
function setMetaElementAttributes(tag, el) {
	Object.keys(tag).forEach((prop) => el.setAttribute(getMetaKeyMap(prop), tag[prop]));
}
function parseSelector(tag) {
	const attr = tag.name ? "name" : "property";
	return `${attr}=${escapeSelectorValue(String(tag[attr]))}`;
}
function escapeSelectorValue(value) {
	return `"${value.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
}
function containsAttributes(tag, elem) {
	return Object.keys(tag).every((key) => elem.getAttribute(getMetaKeyMap(key)) === tag[key]);
}
function getMetaKeyMap(prop) {
	return META_KEYS_MAP[prop] || prop;
}
function isMetaTag(tag) {
	return (tag === null || tag === void 0 ? void 0 : tag.nodeName.toLowerCase()) === "meta";
}
var META_KEYS_MAP = { httpEquiv: "http-equiv" };
var Title = class {
	constructor(_doc) {
		_defineProperty(this, "_doc", void 0);
		this._doc = _doc;
	}
	getTitle() {
		return this._doc.title;
	}
	setTitle(newTitle) {
		this._doc.title = newTitle || "";
	}
};
_Title = Title;
_defineProperty(Title, "ɵfac", function Title_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _Title)(ɵɵinject(DOCUMENT));
});
_defineProperty(Title, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _Title,
	factory: _Title.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Title, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [DOCUMENT]
		}]
	}], null);
})();
function exportNgVar(name, value) {
	if (typeof COMPILED === "undefined" || !COMPILED) {
		const ng = _global["ng"] = _global["ng"] || {};
		ng[name] = value;
	}
}
var ChangeDetectionPerfRecord = class {
	constructor(msPerTick, numTicks) {
		_defineProperty(this, "msPerTick", void 0);
		_defineProperty(this, "numTicks", void 0);
		this.msPerTick = msPerTick;
		this.numTicks = numTicks;
	}
};
var AngularProfiler = class {
	constructor(ref) {
		_defineProperty(this, "appRef", void 0);
		this.appRef = ref.injector.get(ApplicationRef);
	}
	timeChangeDetection(config) {
		const record = config && config["record"];
		const profileName = "Change Detection";
		if (record && "profile" in console && typeof console.profile === "function") console.profile(profileName);
		const start = performance.now();
		let numTicks = 0;
		while (numTicks < 5 || performance.now() - start < 500) {
			this.appRef.tick();
			numTicks++;
		}
		const end = performance.now();
		if (record && "profileEnd" in console && typeof console.profileEnd === "function") console.profileEnd(profileName);
		const msPerTick = (end - start) / numTicks;
		console.log(`ran ${numTicks} change detection cycles`);
		console.log(`${msPerTick.toFixed(2)} ms per check`);
		return new ChangeDetectionPerfRecord(msPerTick, numTicks);
	}
};
var PROFILER_GLOBAL_NAME = "profiler";
function enableDebugTools(ref) {
	exportNgVar(PROFILER_GLOBAL_NAME, new AngularProfiler(ref));
	return ref;
}
function disableDebugTools() {
	exportNgVar(PROFILER_GLOBAL_NAME, null);
}
var By = class {
	static all() {
		return () => true;
	}
	static css(selector) {
		return (debugElement) => {
			return debugElement.nativeElement != null ? elementMatches(debugElement.nativeElement, selector) : false;
		};
	}
	static directive(type) {
		return (debugNode) => debugNode.providerTokens.indexOf(type) !== -1;
	}
};
function elementMatches(n, selector) {
	if (getDOM().isElementNode(n)) return n.matches && n.matches(selector) || n.msMatchesSelector && n.msMatchesSelector(selector) || n.webkitMatchesSelector && n.webkitMatchesSelector(selector);
	return false;
}
var CssVarNamespacer = class {
	constructor() {
		var _inject;
		_defineProperty(this, "namespacePrefix", (_inject = inject(CSS_VAR_NAMESPACE, { optional: true })) !== null && _inject !== void 0 ? _inject : "");
	}
	namespace(name) {
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			if (!name.startsWith("--")) throw new Error(`CSS variable names passed to \`CssVarNamespacer\` must start with '--', got: '${name}'`);
		}
		if (!this.namespacePrefix) return name;
		return `--${this.namespacePrefix}${name.substring(2)}`;
	}
};
_CssVarNamespacer = CssVarNamespacer;
_defineProperty(CssVarNamespacer, "ɵfac", function CssVarNamespacer_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _CssVarNamespacer)();
});
_defineProperty(CssVarNamespacer, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _CssVarNamespacer,
	factory: _CssVarNamespacer.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CssVarNamespacer, [{ type: Service }], null, null);
})();
var HydrationFeatureKind;
(function(HydrationFeatureKind) {
	HydrationFeatureKind[HydrationFeatureKind["NoHttpTransferCache"] = 0] = "NoHttpTransferCache";
	HydrationFeatureKind[HydrationFeatureKind["HttpTransferCacheOptions"] = 1] = "HttpTransferCacheOptions";
	HydrationFeatureKind[HydrationFeatureKind["I18nSupport"] = 2] = "I18nSupport";
	HydrationFeatureKind[HydrationFeatureKind["EventReplay"] = 3] = "EventReplay";
	HydrationFeatureKind[HydrationFeatureKind["IncrementalHydration"] = 4] = "IncrementalHydration";
	HydrationFeatureKind[HydrationFeatureKind["NoIncrementalHydration"] = 5] = "NoIncrementalHydration";
})(HydrationFeatureKind || (HydrationFeatureKind = {}));
function hydrationFeature(ɵkind, ɵproviders = [], ɵoptions = {}) {
	return {
		ɵkind,
		ɵproviders
	};
}
function withNoHttpTransferCache() {
	return hydrationFeature(HydrationFeatureKind.NoHttpTransferCache);
}
function withHttpTransferCacheOptions(options) {
	return hydrationFeature(HydrationFeatureKind.HttpTransferCacheOptions, withHttpTransferCache(options));
}
function withI18nSupport() {
	return hydrationFeature(HydrationFeatureKind.I18nSupport, withI18nSupport$1());
}
function withEventReplay() {
	return hydrationFeature(HydrationFeatureKind.EventReplay, withEventReplay$1());
}
function withIncrementalHydration() {
	return hydrationFeature(HydrationFeatureKind.IncrementalHydration, withIncrementalHydration$1());
}
function withNoIncrementalHydration() {
	return hydrationFeature(HydrationFeatureKind.NoIncrementalHydration);
}
function provideEnabledBlockingInitialNavigationDetector() {
	return [{
		provide: ENVIRONMENT_INITIALIZER,
		useValue: () => {
			if (inject(IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, { optional: true })) {
				const console = inject(Console);
				const message = formatRuntimeError(5001, "Configuration error: found both hydration and enabledBlocking initial navigation in the same application, which is a contradiction.");
				console.warn(message);
			}
		},
		multi: true
	}];
}
function provideClientHydration(...features) {
	const providers = [];
	const featuresKind = /* @__PURE__ */ new Set();
	for (const { ɵproviders, ɵkind } of features) {
		featuresKind.add(ɵkind);
		if (ɵproviders.length) providers.push(ɵproviders);
	}
	const hasHttpTransferCacheOptions = featuresKind.has(HydrationFeatureKind.HttpTransferCacheOptions);
	if (typeof ngDevMode !== "undefined" && ngDevMode) {
		if (featuresKind.has(HydrationFeatureKind.NoHttpTransferCache) && hasHttpTransferCacheOptions) throw new RuntimeError(5001, "Configuration error: found both withHttpTransferCacheOptions() and withNoHttpTransferCache() in the same call to provideClientHydration(), which is a contradiction.");
		if (featuresKind.has(HydrationFeatureKind.IncrementalHydration) && featuresKind.has(HydrationFeatureKind.NoIncrementalHydration)) throw new RuntimeError(5001, "Configuration error: found both withIncrementalHydration() and withNoIncrementalHydration() in the same call to provideClientHydration(), which is a contradiction.");
	}
	return makeEnvironmentProviders([
		typeof ngDevMode !== "undefined" && ngDevMode ? provideEnabledBlockingInitialNavigationDetector() : [],
		typeof ngDevMode !== "undefined" && ngDevMode ? provideStabilityDebugging() : [],
		withDomHydration(),
		featuresKind.has(HydrationFeatureKind.NoHttpTransferCache) || hasHttpTransferCacheOptions ? [] : withHttpTransferCache({}),
		featuresKind.has(HydrationFeatureKind.NoIncrementalHydration) ? [] : withIncrementalHydration$1(),
		providers,
		{
			provide: CACHE_ACTIVE,
			useValue: { isActive: true }
		},
		{
			provide: APP_BOOTSTRAP_LISTENER,
			multi: true,
			useFactory: () => {
				const appRef = inject(ApplicationRef);
				const cacheState = inject(CACHE_ACTIVE);
				return () => {
					appRef.whenStable().then(() => {
						cacheState.isActive = false;
					});
				};
			}
		}
	]);
}
var DomSanitizer = class {};
_DomSanitizer = DomSanitizer;
_defineProperty(DomSanitizer, "ɵfac", function DomSanitizer_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DomSanitizer)();
});
_defineProperty(DomSanitizer, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _DomSanitizer,
	factory: function DomSanitizer_Factory(__ngFactoryType__) {
		let __ngConditionalFactory__ = null;
		if (__ngFactoryType__) __ngConditionalFactory__ = new (__ngFactoryType__ || _DomSanitizer)();
		else __ngConditionalFactory__ = ɵɵinject(DomSanitizerImpl);
		return __ngConditionalFactory__;
	},
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DomSanitizer, [{
		type: Injectable,
		args: [{
			providedIn: "root",
			useExisting: forwardRef(() => DomSanitizerImpl)
		}]
	}], null, null);
})();
var DomSanitizerImpl = class extends DomSanitizer {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "_doc", inject(DOCUMENT));
	}
	sanitize(ctx, value) {
		if (value == null) return null;
		switch (ctx) {
			case SecurityContext.NONE: return value;
			case SecurityContext.HTML:
				if (allowSanitizationBypassAndThrow(value, "HTML")) return unwrapSafeValue(value);
				return _sanitizeHtml(this._doc, String(value)).toString();
			case SecurityContext.STYLE:
				if (allowSanitizationBypassAndThrow(value, "Style")) return unwrapSafeValue(value);
				return value;
			case SecurityContext.SCRIPT:
				if (allowSanitizationBypassAndThrow(value, "Script")) return unwrapSafeValue(value);
				throw new RuntimeError(5200, (typeof ngDevMode === "undefined" || ngDevMode) && "unsafe value used in a script context");
			case SecurityContext.URL:
				if (allowSanitizationBypassAndThrow(value, "URL")) return unwrapSafeValue(value);
				return _sanitizeUrl(String(value));
			case SecurityContext.RESOURCE_URL:
				if (allowSanitizationBypassAndThrow(value, "ResourceURL")) return unwrapSafeValue(value);
				throw new RuntimeError(-5201, (typeof ngDevMode === "undefined" || ngDevMode) && `unsafe value used in a resource URL context (see https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss)`);
			default: throw new RuntimeError(5202, (typeof ngDevMode === "undefined" || ngDevMode) && `Unexpected SecurityContext ${ctx} (see https://angular.dev/best-practices/security#preventing-cross-site-scripting-xss)`);
		}
	}
	bypassSecurityTrustHtml(value) {
		return bypassSanitizationTrustHtml(value);
	}
	bypassSecurityTrustStyle(value) {
		return bypassSanitizationTrustStyle(value);
	}
	bypassSecurityTrustScript(value) {
		return bypassSanitizationTrustScript(value);
	}
	bypassSecurityTrustUrl(value) {
		return bypassSanitizationTrustUrl(value);
	}
	bypassSecurityTrustResourceUrl(value) {
		return bypassSanitizationTrustResourceUrl(value);
	}
};
_DomSanitizerImpl = DomSanitizerImpl;
_defineProperty(DomSanitizerImpl, "ɵfac", function DomSanitizerImpl_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DomSanitizerImpl)();
});
_defineProperty(DomSanitizerImpl, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _DomSanitizerImpl,
	factory: _DomSanitizerImpl.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DomSanitizerImpl, [{ type: Service }], null, null);
})();
var VERSION = /* @__PURE__ */ new Version("22.1.2");
//#endregion
export { EventManagerPlugin as A, createApplication as C, DomRendererFactory2 as D, DomEventsPlugin as E, SharedStylesHost as M, provideCssVarNamespacing as N, EVENT_MANAGER_PLUGINS as O, bootstrapApplication as S, provideProtractorTestingSupport as T, withNoIncrementalHydration as _, HydrationFeatureKind as a, BrowserModule as b, VERSION as c, provideClientHydration as d, withEventReplay as f, withNoHttpTransferCache as g, withIncrementalHydration as h, DomSanitizerImpl as i, REMOVE_STYLES_ON_COMPONENT_DESTROY as j, EventManager as k, disableDebugTools as l, withI18nSupport as m, CssVarNamespacer as n, Meta as o, withHttpTransferCacheOptions as p, DomSanitizer as r, Title as s, By as t, enableDebugTools as u, BrowserDomAdapter as v, platformBrowser as w, KeyEventsPlugin as x, BrowserGetTestability as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGxhdGZvcm0tYnJvd3Nlci1Cc0p4NXdOYy5qcyIsIm5hbWVzIjpbIkRvbUV2ZW50c1BsdWdpbiIsImkwLsm1ybVpbmplY3QiLCJpMC7JtXNldENsYXNzTWV0YWRhdGEiLCJfUnVudGltZUVycm9yIiwiRXZlbnRNYW5hZ2VyIiwiaTAuTmdab25lIiwiU2hhcmVkU3R5bGVzSG9zdCIsIkRvbVJlbmRlcmVyRmFjdG9yeTIiLCJfU0hBUkVEX1NUWUxFU19IT1NUIiwiX1RyYWNpbmdTZXJ2aWNlIiwiaTAuybVUcmFjaW5nU2VydmljZSIsIl9nZXRET00iLCJfYWxsTGVhdmluZ0FuaW1hdGlvbnMiLCJfRG9tQWRhcHRlciIsIl9wYXJzZUNvb2tpZVZhbHVlIiwiX1J1bnRpbWVFcnJvciIsIl9nZXRET00iLCJLZXlFdmVudHNQbHVnaW4iLCJpMC7Jtcm1aW5qZWN0IiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiX2ludGVybmFsQ3JlYXRlQXBwbGljYXRpb24iLCJfVVNFX1BFTkRJTkdfVEFTS1MiLCJfUExBVEZPUk1fQlJPV1NFUl9JRCIsIl9URVNUQUJJTElUWV9HRVRURVIiLCJfVEVTVEFCSUxJVFkiLCJfSU5KRUNUT1JfU0NPUEUiLCJfU0hBUkVEX1NUWUxFU19IT1NUIiwiQnJvd3Nlck1vZHVsZSIsIl9nZXRET00iLCJNZXRhIiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiVGl0bGUiLCJpMC7Jtcm1aW5qZWN0IiwiQ3NzVmFyTmFtZXNwYWNlciIsIl93aXRoSHR0cFRyYW5zZmVyQ2FjaGUiLCJfd2l0aEkxOG5TdXBwb3J0IiwiX3dpdGhFdmVudFJlcGxheSIsIl93aXRoSW5jcmVtZW50YWxIeWRyYXRpb24iLCJfSVNfRU5BQkxFRF9CTE9DS0lOR19JTklUSUFMX05BVklHQVRJT04iLCJfQ29uc29sZSIsIl9mb3JtYXRSdW50aW1lRXJyb3IiLCJfUnVudGltZUVycm9yIiwiX3dpdGhEb21IeWRyYXRpb24iLCJfQ0FDSEVfQUNUSVZFIiwiRG9tU2FuaXRpemVyIiwiX2FsbG93U2FuaXRpemF0aW9uQnlwYXNzQW5kVGhyb3ciLCJfdW53cmFwU2FmZVZhbHVlIiwiX19zYW5pdGl6ZUh0bWwiLCJfX3Nhbml0aXplVXJsIiwiX2J5cGFzc1Nhbml0aXphdGlvblRydXN0SHRtbCIsIl9ieXBhc3NTYW5pdGl6YXRpb25UcnVzdFN0eWxlIiwiX2J5cGFzc1Nhbml0aXphdGlvblRydXN0U2NyaXB0IiwiX2J5cGFzc1Nhbml0aXphdGlvblRydXN0VXJsIiwiX2J5cGFzc1Nhbml0aXphdGlvblRydXN0UmVzb3VyY2VVcmwiLCJEb21TYW5pdGl6ZXJJbXBsIl0sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXIvZmVzbTIwMjIvX2RvbV9yZW5kZXJlci1jaHVuay5tanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlci9mZXNtMjAyMi9fYnJvd3Nlci1jaHVuay5tanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlci9mZXNtMjAyMi9wbGF0Zm9ybS1icm93c2VyLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjIyLjEuMlxuICogKGMpIDIwMTAtMjAyNiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuZGV2L1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0IHsgRE9DVU1FTlQsIMm1Z2V0RE9NIGFzIF9nZXRET00gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0ICogYXMgaTAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJbmplY3QsIEluamVjdGFibGUsIEluamVjdGlvblRva2VuLCDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCBBUFBfSUQsIENTUF9OT05DRSwgUExBVEZPUk1fSUQsIE9wdGlvbmFsLCBtYWtlRW52aXJvbm1lbnRQcm92aWRlcnMsIFZpZXdFbmNhcHN1bGF0aW9uLCDJtVNIQVJFRF9TVFlMRVNfSE9TVCBhcyBfU0hBUkVEX1NUWUxFU19IT1NULCDJtVRyYWNpbmdTZXJ2aWNlIGFzIF9UcmFjaW5nU2VydmljZSwgUmVuZGVyZXJTdHlsZUZsYWdzMiwgybVhbGxMZWF2aW5nQW5pbWF0aW9ucyBhcyBfYWxsTGVhdmluZ0FuaW1hdGlvbnMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmNsYXNzIEV2ZW50TWFuYWdlclBsdWdpbiB7XG4gIF9kb2M7XG4gIGNvbnN0cnVjdG9yKF9kb2MpIHtcbiAgICB0aGlzLl9kb2MgPSBfZG9jO1xuICB9XG4gIG1hbmFnZXI7XG59XG5jbGFzcyBEb21FdmVudHNQbHVnaW4gZXh0ZW5kcyBFdmVudE1hbmFnZXJQbHVnaW4ge1xuICBjb25zdHJ1Y3Rvcihkb2MpIHtcbiAgICBzdXBlcihkb2MpO1xuICB9XG4gIHN1cHBvcnRzKGV2ZW50TmFtZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFkZEV2ZW50TGlzdGVuZXIoZWxlbWVudCwgZXZlbnROYW1lLCBoYW5kbGVyLCBvcHRpb25zKSB7XG4gICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgaGFuZGxlciwgb3B0aW9ucyk7XG4gICAgcmV0dXJuICgpID0+IHRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihlbGVtZW50LCBldmVudE5hbWUsIGhhbmRsZXIsIG9wdGlvbnMpO1xuICB9XG4gIHJlbW92ZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBldmVudE5hbWUsIGNhbGxiYWNrLCBvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRhcmdldC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgY2FsbGJhY2ssIG9wdGlvbnMpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIERvbUV2ZW50c1BsdWdpbl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IERvbUV2ZW50c1BsdWdpbikoaTAuybXJtWluamVjdChET0NVTUVOVCkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBEb21FdmVudHNQbHVnaW4sXG4gICAgZmFjdG9yeTogRG9tRXZlbnRzUGx1Z2luLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRG9tRXZlbnRzUGx1Z2luLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbRE9DVU1FTlRdXG4gICAgfV1cbiAgfV0sIG51bGwpO1xufSkoKTtcbmNvbnN0IEVWRU5UX01BTkFHRVJfUExVR0lOUyA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnRXZlbnRNYW5hZ2VyUGx1Z2lucycgOiAnJyk7XG5jbGFzcyBFdmVudE1hbmFnZXIge1xuICBfem9uZTtcbiAgX3BsdWdpbnM7XG4gIF9ldmVudE5hbWVUb1BsdWdpbiA9IG5ldyBNYXAoKTtcbiAgY29uc3RydWN0b3IocGx1Z2lucywgX3pvbmUpIHtcbiAgICB0aGlzLl96b25lID0gX3pvbmU7XG4gICAgcGx1Z2lucy5mb3JFYWNoKHBsdWdpbiA9PiB7XG4gICAgICBwbHVnaW4ubWFuYWdlciA9IHRoaXM7XG4gICAgfSk7XG4gICAgY29uc3Qgb3RoZXJQbHVnaW5zID0gcGx1Z2lucy5maWx0ZXIocCA9PiAhKHAgaW5zdGFuY2VvZiBEb21FdmVudHNQbHVnaW4pKTtcbiAgICB0aGlzLl9wbHVnaW5zID0gb3RoZXJQbHVnaW5zLnNsaWNlKCkucmV2ZXJzZSgpO1xuICAgIGNvbnN0IGRvbUV2ZW50UGx1Z2luID0gcGx1Z2lucy5maW5kKHAgPT4gcCBpbnN0YW5jZW9mIERvbUV2ZW50c1BsdWdpbik7XG4gICAgaWYgKGRvbUV2ZW50UGx1Z2luKSB7XG4gICAgICB0aGlzLl9wbHVnaW5zLnB1c2goZG9tRXZlbnRQbHVnaW4pO1xuICAgIH1cbiAgfVxuICBhZGRFdmVudExpc3RlbmVyKGVsZW1lbnQsIGV2ZW50TmFtZSwgaGFuZGxlciwgb3B0aW9ucykge1xuICAgIGNvbnN0IHBsdWdpbiA9IHRoaXMuX2ZpbmRQbHVnaW5Gb3IoZXZlbnROYW1lKTtcbiAgICByZXR1cm4gcGx1Z2luLmFkZEV2ZW50TGlzdGVuZXIoZWxlbWVudCwgZXZlbnROYW1lLCBoYW5kbGVyLCBvcHRpb25zKTtcbiAgfVxuICBnZXRab25lKCkge1xuICAgIHJldHVybiB0aGlzLl96b25lO1xuICB9XG4gIF9maW5kUGx1Z2luRm9yKGV2ZW50TmFtZSkge1xuICAgIGxldCBwbHVnaW4gPSB0aGlzLl9ldmVudE5hbWVUb1BsdWdpbi5nZXQoZXZlbnROYW1lKTtcbiAgICBpZiAocGx1Z2luKSB7XG4gICAgICByZXR1cm4gcGx1Z2luO1xuICAgIH1cbiAgICBjb25zdCBwbHVnaW5zID0gdGhpcy5fcGx1Z2lucztcbiAgICBwbHVnaW4gPSBwbHVnaW5zLmZpbmQocGx1Z2luID0+IHBsdWdpbi5zdXBwb3J0cyhldmVudE5hbWUpKTtcbiAgICBpZiAoIXBsdWdpbikge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoLTUxMDEsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGBObyBldmVudCBtYW5hZ2VyIHBsdWdpbiBmb3VuZCBmb3IgZXZlbnQgJHtldmVudE5hbWV9YCk7XG4gICAgfVxuICAgIHRoaXMuX2V2ZW50TmFtZVRvUGx1Z2luLnNldChldmVudE5hbWUsIHBsdWdpbik7XG4gICAgcmV0dXJuIHBsdWdpbjtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBFdmVudE1hbmFnZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBFdmVudE1hbmFnZXIpKGkwLsm1ybVpbmplY3QoRVZFTlRfTUFOQUdFUl9QTFVHSU5TKSwgaTAuybXJtWluamVjdChpMC5OZ1pvbmUpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogRXZlbnRNYW5hZ2VyLFxuICAgIGZhY3Rvcnk6IEV2ZW50TWFuYWdlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEV2ZW50TWFuYWdlciwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0VWRU5UX01BTkFHRVJfUExVR0lOU11cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogaTAuTmdab25lXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jb25zdCBBUFBfSURfQVRUUklCVVRFX05BTUUgPSAnbmctYXBwLWlkJztcbmZ1bmN0aW9uIHJlbW92ZUVsZW1lbnRzKGVsZW1lbnRzKSB7XG4gIGZvciAoY29uc3QgZWxlbWVudCBvZiBlbGVtZW50cykge1xuICAgIGVsZW1lbnQucmVtb3ZlKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0eWxlRWxlbWVudChzdHlsZSwgZG9jKSB7XG4gIGNvbnN0IHN0eWxlRWxlbWVudCA9IGRvYy5jcmVhdGVFbGVtZW50KCdzdHlsZScpO1xuICBzdHlsZUVsZW1lbnQudGV4dENvbnRlbnQgPSBzdHlsZTtcbiAgcmV0dXJuIHN0eWxlRWxlbWVudDtcbn1cbmZ1bmN0aW9uIGFkZFNlcnZlclN0eWxlcyhkb2MsIGFwcElkLCBpbmxpbmUsIGV4dGVybmFsKSB7XG4gIGNvbnN0IGVsZW1lbnRzID0gZG9jLmhlYWQ/LnF1ZXJ5U2VsZWN0b3JBbGwoYHN0eWxlWyR7QVBQX0lEX0FUVFJJQlVURV9OQU1FfT1cIiR7YXBwSWR9XCJdLGxpbmtbJHtBUFBfSURfQVRUUklCVVRFX05BTUV9PVwiJHthcHBJZH1cIl1gKTtcbiAgaWYgKCFlbGVtZW50cyB8fCBlbGVtZW50cy5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZTtcbiAgZm9yIChjb25zdCBzdHlsZUVsZW1lbnQgb2YgZWxlbWVudHMpIHtcbiAgICBzdHlsZUVsZW1lbnQucmVtb3ZlQXR0cmlidXRlKEFQUF9JRF9BVFRSSUJVVEVfTkFNRSk7XG4gICAgaWYgKHN0eWxlRWxlbWVudCBpbnN0YW5jZW9mIEhUTUxMaW5rRWxlbWVudCkge1xuICAgICAgZXh0ZXJuYWwuc2V0KHN0eWxlRWxlbWVudC5ocmVmLnNsaWNlKHN0eWxlRWxlbWVudC5ocmVmLmxhc3RJbmRleE9mKCcvJykgKyAxKSwge1xuICAgICAgICB1c2FnZTogMCxcbiAgICAgICAgZWxlbWVudHM6IFtzdHlsZUVsZW1lbnRdXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHN0eWxlRWxlbWVudC50ZXh0Q29udGVudCkge1xuICAgICAgaW5saW5lLnNldChzdHlsZUVsZW1lbnQudGV4dENvbnRlbnQsIHtcbiAgICAgICAgdXNhZ2U6IDAsXG4gICAgICAgIGVsZW1lbnRzOiBbc3R5bGVFbGVtZW50XVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gY3JlYXRlTGlua0VsZW1lbnQodXJsLCBkb2MpIHtcbiAgY29uc3QgbGlua0VsZW1lbnQgPSBkb2MuY3JlYXRlRWxlbWVudCgnbGluaycpO1xuICBsaW5rRWxlbWVudC5zZXRBdHRyaWJ1dGUoJ3JlbCcsICdzdHlsZXNoZWV0Jyk7XG4gIGxpbmtFbGVtZW50LnNldEF0dHJpYnV0ZSgnaHJlZicsIHVybCk7XG4gIHJldHVybiBsaW5rRWxlbWVudDtcbn1cbmNsYXNzIFNoYXJlZFN0eWxlc0hvc3Qge1xuICBkb2M7XG4gIGFwcElkO1xuICBub25jZTtcbiAgaW5saW5lID0gbmV3IE1hcCgpO1xuICBleHRlcm5hbCA9IG5ldyBNYXAoKTtcbiAgaG9zdHMgPSBuZXcgU2V0KCk7XG4gIGNvbnN0cnVjdG9yKGRvYywgYXBwSWQsIG5vbmNlLCBwbGF0Zm9ybUlkID0ge30pIHtcbiAgICB0aGlzLmRvYyA9IGRvYztcbiAgICB0aGlzLmFwcElkID0gYXBwSWQ7XG4gICAgdGhpcy5ub25jZSA9IG5vbmNlO1xuICAgIGNvbnN0IGFkZGVkID0gYWRkU2VydmVyU3R5bGVzKGRvYywgYXBwSWQsIHRoaXMuaW5saW5lLCB0aGlzLmV4dGVybmFsKTtcbiAgICBpZiAoYWRkZWQpIHRoaXMuaG9zdHMuYWRkKGRvYy5oZWFkKTtcbiAgfVxuICBhZGRTdHlsZXMoc3R5bGVzLCB1cmxzKSB7XG4gICAgZm9yIChjb25zdCB2YWx1ZSBvZiBzdHlsZXMpIHtcbiAgICAgIHRoaXMuYWRkVXNhZ2UodmFsdWUsIHRoaXMuaW5saW5lLCBjcmVhdGVTdHlsZUVsZW1lbnQpO1xuICAgIH1cbiAgICB1cmxzPy5mb3JFYWNoKHZhbHVlID0+IHRoaXMuYWRkVXNhZ2UodmFsdWUsIHRoaXMuZXh0ZXJuYWwsIGNyZWF0ZUxpbmtFbGVtZW50KSk7XG4gIH1cbiAgcmVtb3ZlU3R5bGVzKHN0eWxlcywgdXJscykge1xuICAgIGZvciAoY29uc3QgdmFsdWUgb2Ygc3R5bGVzKSB7XG4gICAgICB0aGlzLnJlbW92ZVVzYWdlKHZhbHVlLCB0aGlzLmlubGluZSk7XG4gICAgfVxuICAgIHVybHM/LmZvckVhY2godmFsdWUgPT4gdGhpcy5yZW1vdmVVc2FnZSh2YWx1ZSwgdGhpcy5leHRlcm5hbCkpO1xuICB9XG4gIGFkZFVzYWdlKHZhbHVlLCB1c2FnZXMsIGNyZWF0b3IpIHtcbiAgICBjb25zdCByZWNvcmQgPSB1c2FnZXMuZ2V0KHZhbHVlKTtcbiAgICBpZiAocmVjb3JkKSB7XG4gICAgICBpZiAoKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgcmVjb3JkLnVzYWdlID09PSAwKSB7XG4gICAgICAgIHJlY29yZC5lbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4gZWxlbWVudC5zZXRBdHRyaWJ1dGUoJ25nLXN0eWxlLXJldXNlZCcsICcnKSk7XG4gICAgICB9XG4gICAgICByZWNvcmQudXNhZ2UrKztcbiAgICB9IGVsc2Uge1xuICAgICAgdXNhZ2VzLnNldCh2YWx1ZSwge1xuICAgICAgICB1c2FnZTogMSxcbiAgICAgICAgZWxlbWVudHM6IFsuLi50aGlzLmhvc3RzXS5tYXAoaG9zdCA9PiB0aGlzLmFkZEVsZW1lbnQoaG9zdCwgY3JlYXRvcih2YWx1ZSwgdGhpcy5kb2MpKSlcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZW1vdmVVc2FnZSh2YWx1ZSwgdXNhZ2VzKSB7XG4gICAgY29uc3QgcmVjb3JkID0gdXNhZ2VzLmdldCh2YWx1ZSk7XG4gICAgaWYgKHJlY29yZCkge1xuICAgICAgcmVjb3JkLnVzYWdlLS07XG4gICAgICBpZiAocmVjb3JkLnVzYWdlIDw9IDApIHtcbiAgICAgICAgcmVtb3ZlRWxlbWVudHMocmVjb3JkLmVsZW1lbnRzKTtcbiAgICAgICAgdXNhZ2VzLmRlbGV0ZSh2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIGZvciAoY29uc3QgWywge1xuICAgICAgZWxlbWVudHNcbiAgICB9XSBvZiBbLi4udGhpcy5pbmxpbmUsIC4uLnRoaXMuZXh0ZXJuYWxdKSB7XG4gICAgICByZW1vdmVFbGVtZW50cyhlbGVtZW50cyk7XG4gICAgfVxuICAgIHRoaXMuaG9zdHMuY2xlYXIoKTtcbiAgfVxuICBhZGRIb3N0KGhvc3ROb2RlKSB7XG4gICAgaWYgKHRoaXMuaG9zdHMuaGFzKGhvc3ROb2RlKSkgcmV0dXJuO1xuICAgIHRoaXMuaG9zdHMuYWRkKGhvc3ROb2RlKTtcbiAgICBmb3IgKGNvbnN0IFtzdHlsZSwge1xuICAgICAgZWxlbWVudHNcbiAgICB9XSBvZiB0aGlzLmlubGluZSkge1xuICAgICAgZWxlbWVudHMucHVzaCh0aGlzLmFkZEVsZW1lbnQoaG9zdE5vZGUsIGNyZWF0ZVN0eWxlRWxlbWVudChzdHlsZSwgdGhpcy5kb2MpKSk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgW3VybCwge1xuICAgICAgZWxlbWVudHNcbiAgICB9XSBvZiB0aGlzLmV4dGVybmFsKSB7XG4gICAgICBlbGVtZW50cy5wdXNoKHRoaXMuYWRkRWxlbWVudChob3N0Tm9kZSwgY3JlYXRlTGlua0VsZW1lbnQodXJsLCB0aGlzLmRvYykpKTtcbiAgICB9XG4gIH1cbiAgcmVtb3ZlSG9zdChob3N0Tm9kZSkge1xuICAgIHRoaXMuaG9zdHMuZGVsZXRlKGhvc3ROb2RlKTtcbiAgICBmb3IgKGNvbnN0IHJlY29yZCBvZiBbLi4udGhpcy5pbmxpbmUudmFsdWVzKCksIC4uLnRoaXMuZXh0ZXJuYWwudmFsdWVzKCldKSB7XG4gICAgICBjb25zdCByZW1haW5pbmcgPSBbXTtcbiAgICAgIGZvciAoY29uc3QgZWxlbWVudCBvZiByZWNvcmQuZWxlbWVudHMpIHtcbiAgICAgICAgaWYgKGVsZW1lbnQucGFyZW50Tm9kZSA9PT0gaG9zdE5vZGUpIHtcbiAgICAgICAgICBlbGVtZW50LnJlbW92ZSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlbWFpbmluZy5wdXNoKGVsZW1lbnQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZWNvcmQuZWxlbWVudHMgPSByZW1haW5pbmc7XG4gICAgfVxuICB9XG4gIGFkZEVsZW1lbnQoaG9zdCwgZWxlbWVudCkge1xuICAgIGlmICh0aGlzLm5vbmNlKSB7XG4gICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnbm9uY2UnLCB0aGlzLm5vbmNlKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBuZ1NlcnZlck1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nU2VydmVyTW9kZSkge1xuICAgICAgZWxlbWVudC5zZXRBdHRyaWJ1dGUoQVBQX0lEX0FUVFJJQlVURV9OQU1FLCB0aGlzLmFwcElkKTtcbiAgICB9XG4gICAgcmV0dXJuIGhvc3QuYXBwZW5kQ2hpbGQoZWxlbWVudCk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gU2hhcmVkU3R5bGVzSG9zdF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFNoYXJlZFN0eWxlc0hvc3QpKGkwLsm1ybVpbmplY3QoRE9DVU1FTlQpLCBpMC7Jtcm1aW5qZWN0KEFQUF9JRCksIGkwLsm1ybVpbmplY3QoQ1NQX05PTkNFLCA4KSwgaTAuybXJtWluamVjdChQTEFURk9STV9JRCkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBTaGFyZWRTdHlsZXNIb3N0LFxuICAgIGZhY3Rvcnk6IFNoYXJlZFN0eWxlc0hvc3QuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShTaGFyZWRTdHlsZXNIb3N0LCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogRG9jdW1lbnQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtET0NVTUVOVF1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbQVBQX0lEXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtDU1BfTk9OQ0VdXG4gICAgfSwge1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbUExBVEZPUk1fSURdXG4gICAgfV1cbiAgfV0sIG51bGwpO1xufSkoKTtcbmNvbnN0IE5BTUVTUEFDRV9VUklTID0ge1xuICAnc3ZnJzogJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyxcbiAgJ3hodG1sJzogJ2h0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWwnLFxuICAneGxpbmsnOiAnaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluaycsXG4gICd4bWwnOiAnaHR0cDovL3d3dy53My5vcmcvWE1MLzE5OTgvbmFtZXNwYWNlJyxcbiAgJ3htbG5zJzogJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAveG1sbnMvJyxcbiAgJ21hdGgnOiAnaHR0cDovL3d3dy53My5vcmcvMTk5OC9NYXRoL01hdGhNTCdcbn07XG5jb25zdCBDT01QT05FTlRfUkVHRVggPSAvJUNPTVAlL2c7XG5jb25zdCBTT1VSQ0VNQVBfVVJMX1JFR0VYUCA9IC9cXC9cXCojXFxzKnNvdXJjZU1hcHBpbmdVUkw9KFteXFxzKl0rKVxccypcXCpcXC8vO1xuY29uc3QgUFJPVE9DT0xfUkVHRVhQID0gL15odHRwcz86LztcbmNvbnN0IENPTVBPTkVOVF9WQVJJQUJMRSA9ICclQ09NUCUnO1xuY29uc3QgSE9TVF9BVFRSID0gYF9uZ2hvc3QtJHtDT01QT05FTlRfVkFSSUFCTEV9YDtcbmNvbnN0IENPTlRFTlRfQVRUUiA9IGBfbmdjb250ZW50LSR7Q09NUE9ORU5UX1ZBUklBQkxFfWA7XG5jb25zdCBSRU1PVkVfU1RZTEVTX09OX0NPTVBPTkVOVF9ERVNUUk9ZX0RFRkFVTFQgPSB0cnVlO1xuY29uc3QgUkVNT1ZFX1NUWUxFU19PTl9DT01QT05FTlRfREVTVFJPWSA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAnUmVtb3ZlU3R5bGVzT25Db21wRGVzdHJveScgOiAnJywge1xuICBmYWN0b3J5OiAoKSA9PiBSRU1PVkVfU1RZTEVTX09OX0NPTVBPTkVOVF9ERVNUUk9ZX0RFRkFVTFRcbn0pO1xuY29uc3QgQ1NTX1ZBUl9OQU1FU1BBQ0UgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ0NTU19WQVJfTkFNRVNQQUNFJyA6ICcnKTtcbmZ1bmN0aW9uIHByb3ZpZGVDc3NWYXJOYW1lc3BhY2luZyhuYW1lc3BhY2UpIHtcbiAgcmV0dXJuIG1ha2VFbnZpcm9ubWVudFByb3ZpZGVycyhbe1xuICAgIHByb3ZpZGU6IENTU19WQVJfTkFNRVNQQUNFLFxuICAgIHVzZUZhY3Rvcnk6IGFwcElkID0+IGAke25hbWVzcGFjZSA/PyBhcHBJZH1fYCxcbiAgICBkZXBzOiBbQVBQX0lEXVxuICB9XSk7XG59XG5mdW5jdGlvbiBzaGltQ29udGVudEF0dHJpYnV0ZShjb21wb25lbnRTaG9ydElkKSB7XG4gIHJldHVybiBDT05URU5UX0FUVFIucmVwbGFjZShDT01QT05FTlRfUkVHRVgsIGNvbXBvbmVudFNob3J0SWQpO1xufVxuZnVuY3Rpb24gc2hpbUhvc3RBdHRyaWJ1dGUoY29tcG9uZW50U2hvcnRJZCkge1xuICByZXR1cm4gSE9TVF9BVFRSLnJlcGxhY2UoQ09NUE9ORU5UX1JFR0VYLCBjb21wb25lbnRTaG9ydElkKTtcbn1cbmZ1bmN0aW9uIHNoaW1TdHlsZXNDb250ZW50KGNvbXBJZCwgc3R5bGVzKSB7XG4gIHJldHVybiBzdHlsZXMubWFwKHMgPT4gcy5yZXBsYWNlKENPTVBPTkVOVF9SRUdFWCwgY29tcElkKSk7XG59XG5mdW5jdGlvbiBhZGRCYXNlSHJlZlRvQ3NzU291cmNlTWFwKGJhc2VIcmVmLCBzdHlsZXMpIHtcbiAgaWYgKCFiYXNlSHJlZikge1xuICAgIHJldHVybiBzdHlsZXM7XG4gIH1cbiAgY29uc3QgYWJzb2x1dGVCYXNlSHJlZlVybCA9IG5ldyBVUkwoYmFzZUhyZWYsICdodHRwOi8vbG9jYWxob3N0Jyk7XG4gIHJldHVybiBzdHlsZXMubWFwKGNzc0NvbnRlbnQgPT4ge1xuICAgIGlmICghY3NzQ29udGVudC5pbmNsdWRlcygnc291cmNlTWFwcGluZ1VSTD0nKSkge1xuICAgICAgcmV0dXJuIGNzc0NvbnRlbnQ7XG4gICAgfVxuICAgIHJldHVybiBjc3NDb250ZW50LnJlcGxhY2UoU09VUkNFTUFQX1VSTF9SRUdFWFAsIChfLCBzb3VyY2VNYXBVcmwpID0+IHtcbiAgICAgIGlmIChzb3VyY2VNYXBVcmxbMF0gPT09ICcvJyB8fCBzb3VyY2VNYXBVcmwuc3RhcnRzV2l0aCgnZGF0YTonKSB8fCBQUk9UT0NPTF9SRUdFWFAudGVzdChzb3VyY2VNYXBVcmwpKSB7XG4gICAgICAgIHJldHVybiBgLyojIHNvdXJjZU1hcHBpbmdVUkw9JHtzb3VyY2VNYXBVcmx9ICovYDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcGF0aG5hbWU6IHJlc29sdmVkU291cmNlTWFwVXJsXG4gICAgICB9ID0gbmV3IFVSTChzb3VyY2VNYXBVcmwsIGFic29sdXRlQmFzZUhyZWZVcmwpO1xuICAgICAgcmV0dXJuIGAvKiMgc291cmNlTWFwcGluZ1VSTD0ke3Jlc29sdmVkU291cmNlTWFwVXJsfSAqL2A7XG4gICAgfSk7XG4gIH0pO1xufVxuY2xhc3MgRG9tUmVuZGVyZXJGYWN0b3J5MiB7XG4gIGV2ZW50TWFuYWdlcjtcbiAgc2hhcmVkU3R5bGVzSG9zdDtcbiAgYXBwSWQ7XG4gIHJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3k7XG4gIGRvYztcbiAgbmdab25lO1xuICBub25jZTtcbiAgdHJhY2luZ1NlcnZpY2U7XG4gIHJlbmRlcmVyQnlDb21wSWQgPSBuZXcgTWFwKCk7XG4gIGRlZmF1bHRSZW5kZXJlcjtcbiAgY3NzVmFyTmFtZXNwYWNlO1xuICBjb25zdHJ1Y3RvcihldmVudE1hbmFnZXIsIHNoYXJlZFN0eWxlc0hvc3QsIGFwcElkLCByZW1vdmVTdHlsZXNPbkNvbXBEZXN0cm95LCBkb2MsIG5nWm9uZSwgbm9uY2UgPSBudWxsLCB0cmFjaW5nU2VydmljZSA9IG51bGwsIGNzc1Zhck5hbWVzcGFjZSA9IG51bGwpIHtcbiAgICB0aGlzLmV2ZW50TWFuYWdlciA9IGV2ZW50TWFuYWdlcjtcbiAgICB0aGlzLnNoYXJlZFN0eWxlc0hvc3QgPSBzaGFyZWRTdHlsZXNIb3N0O1xuICAgIHRoaXMuYXBwSWQgPSBhcHBJZDtcbiAgICB0aGlzLnJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3kgPSByZW1vdmVTdHlsZXNPbkNvbXBEZXN0cm95O1xuICAgIHRoaXMuZG9jID0gZG9jO1xuICAgIHRoaXMubmdab25lID0gbmdab25lO1xuICAgIHRoaXMubm9uY2UgPSBub25jZTtcbiAgICB0aGlzLnRyYWNpbmdTZXJ2aWNlID0gdHJhY2luZ1NlcnZpY2U7XG4gICAgdGhpcy5jc3NWYXJOYW1lc3BhY2UgPSBjc3NWYXJOYW1lc3BhY2UgPz8gJyc7XG4gICAgdGhpcy5kZWZhdWx0UmVuZGVyZXIgPSBuZXcgRGVmYXVsdERvbVJlbmRlcmVyMihldmVudE1hbmFnZXIsIGRvYywgbmdab25lLCB0aGlzLnRyYWNpbmdTZXJ2aWNlLCB0aGlzLmNzc1Zhck5hbWVzcGFjZSk7XG4gIH1cbiAgY3JlYXRlUmVuZGVyZXIoZWxlbWVudCwgdHlwZSkge1xuICAgIGlmICghZWxlbWVudCB8fCAhdHlwZSkge1xuICAgICAgcmV0dXJuIHRoaXMuZGVmYXVsdFJlbmRlcmVyO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdTZXJ2ZXJNb2RlICYmICh0eXBlLmVuY2Fwc3VsYXRpb24gPT09IFZpZXdFbmNhcHN1bGF0aW9uLlNoYWRvd0RvbSB8fCB0eXBlLmVuY2Fwc3VsYXRpb24gPT09IFZpZXdFbmNhcHN1bGF0aW9uLkV4cGVyaW1lbnRhbElzb2xhdGVkU2hhZG93RG9tKSkge1xuICAgICAgdHlwZSA9IHtcbiAgICAgICAgLi4udHlwZSxcbiAgICAgICAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uRW11bGF0ZWRcbiAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5nZXRPckNyZWF0ZVJlbmRlcmVyKGVsZW1lbnQsIHR5cGUpO1xuICAgIGlmIChyZW5kZXJlciBpbnN0YW5jZW9mIEVtdWxhdGVkRW5jYXBzdWxhdGlvbkRvbVJlbmRlcmVyMikge1xuICAgICAgcmVuZGVyZXIuYXBwbHlUb0hvc3QoZWxlbWVudCk7XG4gICAgfSBlbHNlIGlmIChyZW5kZXJlciBpbnN0YW5jZW9mIE5vbmVFbmNhcHN1bGF0aW9uRG9tUmVuZGVyZXIpIHtcbiAgICAgIHJlbmRlcmVyLmFwcGx5U3R5bGVzKCk7XG4gICAgfVxuICAgIHJldHVybiByZW5kZXJlcjtcbiAgfVxuICBnZXRPckNyZWF0ZVJlbmRlcmVyKGVsZW1lbnQsIHR5cGUpIHtcbiAgICBjb25zdCByZW5kZXJlckJ5Q29tcElkID0gdGhpcy5yZW5kZXJlckJ5Q29tcElkO1xuICAgIGxldCByZW5kZXJlciA9IHJlbmRlcmVyQnlDb21wSWQuZ2V0KHR5cGUuaWQpO1xuICAgIGlmICghcmVuZGVyZXIpIHtcbiAgICAgIGNvbnN0IGRvYyA9IHRoaXMuZG9jO1xuICAgICAgY29uc3Qgbmdab25lID0gdGhpcy5uZ1pvbmU7XG4gICAgICBjb25zdCBldmVudE1hbmFnZXIgPSB0aGlzLmV2ZW50TWFuYWdlcjtcbiAgICAgIGNvbnN0IHNoYXJlZFN0eWxlc0hvc3QgPSB0aGlzLnNoYXJlZFN0eWxlc0hvc3Q7XG4gICAgICBjb25zdCByZW1vdmVTdHlsZXNPbkNvbXBEZXN0cm95ID0gdGhpcy5yZW1vdmVTdHlsZXNPbkNvbXBEZXN0cm95O1xuICAgICAgY29uc3QgdHJhY2luZ1NlcnZpY2UgPSB0aGlzLnRyYWNpbmdTZXJ2aWNlO1xuICAgICAgc3dpdGNoICh0eXBlLmVuY2Fwc3VsYXRpb24pIHtcbiAgICAgICAgY2FzZSBWaWV3RW5jYXBzdWxhdGlvbi5FbXVsYXRlZDpcbiAgICAgICAgICByZW5kZXJlciA9IG5ldyBFbXVsYXRlZEVuY2Fwc3VsYXRpb25Eb21SZW5kZXJlcjIoZXZlbnRNYW5hZ2VyLCBzaGFyZWRTdHlsZXNIb3N0LCB0eXBlLCB0aGlzLmFwcElkLCByZW1vdmVTdHlsZXNPbkNvbXBEZXN0cm95LCBkb2MsIG5nWm9uZSwgdHJhY2luZ1NlcnZpY2UsIHRoaXMuY3NzVmFyTmFtZXNwYWNlKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBWaWV3RW5jYXBzdWxhdGlvbi5TaGFkb3dEb206XG4gICAgICAgICAgcmV0dXJuIG5ldyBTaGFkb3dEb21SZW5kZXJlcihldmVudE1hbmFnZXIsIGVsZW1lbnQsIHR5cGUsIGRvYywgbmdab25lLCB0aGlzLm5vbmNlLCB0cmFjaW5nU2VydmljZSwgdGhpcy5jc3NWYXJOYW1lc3BhY2UsIHNoYXJlZFN0eWxlc0hvc3QpO1xuICAgICAgICBjYXNlIFZpZXdFbmNhcHN1bGF0aW9uLkV4cGVyaW1lbnRhbElzb2xhdGVkU2hhZG93RG9tOlxuICAgICAgICAgIHJldHVybiBuZXcgU2hhZG93RG9tUmVuZGVyZXIoZXZlbnRNYW5hZ2VyLCBlbGVtZW50LCB0eXBlLCBkb2MsIG5nWm9uZSwgdGhpcy5ub25jZSwgdHJhY2luZ1NlcnZpY2UsIHRoaXMuY3NzVmFyTmFtZXNwYWNlKTtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICByZW5kZXJlciA9IG5ldyBOb25lRW5jYXBzdWxhdGlvbkRvbVJlbmRlcmVyKGV2ZW50TWFuYWdlciwgc2hhcmVkU3R5bGVzSG9zdCwgdHlwZSwgcmVtb3ZlU3R5bGVzT25Db21wRGVzdHJveSwgZG9jLCBuZ1pvbmUsIHRyYWNpbmdTZXJ2aWNlLCB0aGlzLmNzc1Zhck5hbWVzcGFjZSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICByZW5kZXJlckJ5Q29tcElkLnNldCh0eXBlLmlkLCByZW5kZXJlcik7XG4gICAgfVxuICAgIHJldHVybiByZW5kZXJlcjtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLnJlbmRlcmVyQnlDb21wSWQuY2xlYXIoKTtcbiAgfVxuICBjb21wb25lbnRSZXBsYWNlZChjb21wb25lbnRJZCkge1xuICAgIHRoaXMucmVuZGVyZXJCeUNvbXBJZC5kZWxldGUoY29tcG9uZW50SWQpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIERvbVJlbmRlcmVyRmFjdG9yeTJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBEb21SZW5kZXJlckZhY3RvcnkyKShpMC7Jtcm1aW5qZWN0KEV2ZW50TWFuYWdlciksIGkwLsm1ybVpbmplY3QoX1NIQVJFRF9TVFlMRVNfSE9TVCksIGkwLsm1ybVpbmplY3QoQVBQX0lEKSwgaTAuybXJtWluamVjdChSRU1PVkVfU1RZTEVTX09OX0NPTVBPTkVOVF9ERVNUUk9ZKSwgaTAuybXJtWluamVjdChET0NVTUVOVCksIGkwLsm1ybVpbmplY3QoaTAuTmdab25lKSwgaTAuybXJtWluamVjdChDU1BfTk9OQ0UpLCBpMC7Jtcm1aW5qZWN0KF9UcmFjaW5nU2VydmljZSwgOCksIGkwLsm1ybVpbmplY3QoQ1NTX1ZBUl9OQU1FU1BBQ0UsIDgpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogRG9tUmVuZGVyZXJGYWN0b3J5MixcbiAgICBmYWN0b3J5OiBEb21SZW5kZXJlckZhY3RvcnkyLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRG9tUmVuZGVyZXJGYWN0b3J5MiwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IEV2ZW50TWFuYWdlclxuICB9LCB7XG4gICAgdHlwZTogU2hhcmVkU3R5bGVzSG9zdCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW19TSEFSRURfU1RZTEVTX0hPU1RdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0FQUF9JRF1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbUkVNT1ZFX1NUWUxFU19PTl9DT01QT05FTlRfREVTVFJPWV1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogRG9jdW1lbnQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtET0NVTUVOVF1cbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogaTAuTmdab25lXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtDU1BfTk9OQ0VdXG4gICAgfV1cbiAgfSwge1xuICAgIHR5cGU6IGkwLsm1VHJhY2luZ1NlcnZpY2UsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEluamVjdCxcbiAgICAgIGFyZ3M6IFtfVHJhY2luZ1NlcnZpY2VdXG4gICAgfSwge1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9XVxuICB9LCB7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbQ1NTX1ZBUl9OQU1FU1BBQ0VdXG4gICAgfSwge1xuICAgICAgdHlwZTogT3B0aW9uYWxcbiAgICB9XVxuICB9XSwgbnVsbCk7XG59KSgpO1xuY2xhc3MgRGVmYXVsdERvbVJlbmRlcmVyMiB7XG4gIGV2ZW50TWFuYWdlcjtcbiAgZG9jO1xuICBuZ1pvbmU7XG4gIHRyYWNpbmdTZXJ2aWNlO1xuICBjc3NWYXJOYW1lc3BhY2U7XG4gIGRhdGEgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB0aHJvd09uU3ludGhldGljUHJvcHMgPSB0cnVlO1xuICBjb25zdHJ1Y3RvcihldmVudE1hbmFnZXIsIGRvYywgbmdab25lLCB0cmFjaW5nU2VydmljZSwgY3NzVmFyTmFtZXNwYWNlID0gJycpIHtcbiAgICB0aGlzLmV2ZW50TWFuYWdlciA9IGV2ZW50TWFuYWdlcjtcbiAgICB0aGlzLmRvYyA9IGRvYztcbiAgICB0aGlzLm5nWm9uZSA9IG5nWm9uZTtcbiAgICB0aGlzLnRyYWNpbmdTZXJ2aWNlID0gdHJhY2luZ1NlcnZpY2U7XG4gICAgdGhpcy5jc3NWYXJOYW1lc3BhY2UgPSBjc3NWYXJOYW1lc3BhY2U7XG4gIH1cbiAgZGVzdHJveSgpIHt9XG4gIGRlc3Ryb3lOb2RlID0gbnVsbDtcbiAgY3JlYXRlRWxlbWVudChuYW1lLCBuYW1lc3BhY2UpIHtcbiAgICBpZiAobmFtZXNwYWNlKSB7XG4gICAgICByZXR1cm4gdGhpcy5kb2MuY3JlYXRlRWxlbWVudE5TKE5BTUVTUEFDRV9VUklTW25hbWVzcGFjZV0gfHwgbmFtZXNwYWNlLCBuYW1lKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZG9jLmNyZWF0ZUVsZW1lbnQobmFtZSk7XG4gIH1cbiAgY3JlYXRlQ29tbWVudCh2YWx1ZSkge1xuICAgIHJldHVybiB0aGlzLmRvYy5jcmVhdGVDb21tZW50KHZhbHVlKTtcbiAgfVxuICBjcmVhdGVUZXh0KHZhbHVlKSB7XG4gICAgcmV0dXJuIHRoaXMuZG9jLmNyZWF0ZVRleHROb2RlKHZhbHVlKTtcbiAgfVxuICBhcHBlbmRDaGlsZChwYXJlbnQsIG5ld0NoaWxkKSB7XG4gICAgY29uc3QgdGFyZ2V0UGFyZW50ID0gaXNUZW1wbGF0ZU5vZGUocGFyZW50KSA/IHBhcmVudC5jb250ZW50IDogcGFyZW50O1xuICAgIHRhcmdldFBhcmVudC5hcHBlbmRDaGlsZChuZXdDaGlsZCk7XG4gIH1cbiAgaW5zZXJ0QmVmb3JlKHBhcmVudCwgbmV3Q2hpbGQsIHJlZkNoaWxkKSB7XG4gICAgaWYgKHBhcmVudCkge1xuICAgICAgY29uc3QgdGFyZ2V0UGFyZW50ID0gaXNUZW1wbGF0ZU5vZGUocGFyZW50KSA/IHBhcmVudC5jb250ZW50IDogcGFyZW50O1xuICAgICAgdGFyZ2V0UGFyZW50Lmluc2VydEJlZm9yZShuZXdDaGlsZCwgcmVmQ2hpbGQpO1xuICAgIH1cbiAgfVxuICByZW1vdmVDaGlsZChfcGFyZW50LCBvbGRDaGlsZCkge1xuICAgIG9sZENoaWxkLnJlbW92ZSgpO1xuICB9XG4gIHNlbGVjdFJvb3RFbGVtZW50KHNlbGVjdG9yT3JOb2RlLCBwcmVzZXJ2ZUNvbnRlbnQpIHtcbiAgICBsZXQgZWwgPSB0eXBlb2Ygc2VsZWN0b3JPck5vZGUgPT09ICdzdHJpbmcnID8gdGhpcy5kb2MucXVlcnlTZWxlY3RvcihzZWxlY3Rvck9yTm9kZSkgOiBzZWxlY3Rvck9yTm9kZTtcbiAgICBpZiAoIWVsKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcigtNTEwNCwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgYFRoZSBzZWxlY3RvciBcIiR7c2VsZWN0b3JPck5vZGV9XCIgZGlkIG5vdCBtYXRjaCBhbnkgZWxlbWVudHNgKTtcbiAgICB9XG4gICAgaWYgKCFwcmVzZXJ2ZUNvbnRlbnQpIHtcbiAgICAgIGVsLnRleHRDb250ZW50ID0gJyc7XG4gICAgfVxuICAgIHJldHVybiBlbDtcbiAgfVxuICBwYXJlbnROb2RlKG5vZGUpIHtcbiAgICByZXR1cm4gbm9kZS5wYXJlbnROb2RlO1xuICB9XG4gIG5leHRTaWJsaW5nKG5vZGUpIHtcbiAgICByZXR1cm4gbm9kZS5uZXh0U2libGluZztcbiAgfVxuICBzZXRBdHRyaWJ1dGUoZWwsIG5hbWUsIHZhbHVlLCBuYW1lc3BhY2UpIHtcbiAgICBpZiAobmFtZXNwYWNlKSB7XG4gICAgICBuYW1lID0gbmFtZXNwYWNlICsgJzonICsgbmFtZTtcbiAgICAgIGNvbnN0IG5hbWVzcGFjZVVyaSA9IE5BTUVTUEFDRV9VUklTW25hbWVzcGFjZV07XG4gICAgICBpZiAobmFtZXNwYWNlVXJpKSB7XG4gICAgICAgIGVsLnNldEF0dHJpYnV0ZU5TKG5hbWVzcGFjZVVyaSwgbmFtZSwgdmFsdWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZWwuc2V0QXR0cmlidXRlKG5hbWUsIHZhbHVlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgZWwuc2V0QXR0cmlidXRlKG5hbWUsIHZhbHVlKTtcbiAgICB9XG4gIH1cbiAgcmVtb3ZlQXR0cmlidXRlKGVsLCBuYW1lLCBuYW1lc3BhY2UpIHtcbiAgICBpZiAobmFtZXNwYWNlKSB7XG4gICAgICBjb25zdCBuYW1lc3BhY2VVcmkgPSBOQU1FU1BBQ0VfVVJJU1tuYW1lc3BhY2VdO1xuICAgICAgaWYgKG5hbWVzcGFjZVVyaSkge1xuICAgICAgICBlbC5yZW1vdmVBdHRyaWJ1dGVOUyhuYW1lc3BhY2VVcmksIG5hbWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZWwucmVtb3ZlQXR0cmlidXRlKGAke25hbWVzcGFjZX06JHtuYW1lfWApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBlbC5yZW1vdmVBdHRyaWJ1dGUobmFtZSk7XG4gICAgfVxuICB9XG4gIGFkZENsYXNzKGVsLCBuYW1lKSB7XG4gICAgZWwuY2xhc3NMaXN0LmFkZChuYW1lKTtcbiAgfVxuICByZW1vdmVDbGFzcyhlbCwgbmFtZSkge1xuICAgIGVsLmNsYXNzTGlzdC5yZW1vdmUobmFtZSk7XG4gIH1cbiAgc2V0U3R5bGUoZWwsIHN0eWxlLCB2YWx1ZSwgZmxhZ3MpIHtcbiAgICBjb25zdCBpc1ZhcmlhYmxlID0gc3R5bGUuc3RhcnRzV2l0aCgnLS0nKTtcbiAgICBpZiAoaXNWYXJpYWJsZSkge1xuICAgICAgc3R5bGUgPSBzdHlsZS5yZXBsYWNlKCclTlMlJywgdGhpcy5jc3NWYXJOYW1lc3BhY2UpO1xuICAgIH1cbiAgICBpZiAoaXNWYXJpYWJsZSB8fCBmbGFncyAmIChSZW5kZXJlclN0eWxlRmxhZ3MyLkRhc2hDYXNlIHwgUmVuZGVyZXJTdHlsZUZsYWdzMi5JbXBvcnRhbnQpKSB7XG4gICAgICBlbC5zdHlsZS5zZXRQcm9wZXJ0eShzdHlsZSwgdmFsdWUsIGZsYWdzICYgUmVuZGVyZXJTdHlsZUZsYWdzMi5JbXBvcnRhbnQgPyAnaW1wb3J0YW50JyA6ICcnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gdmFsdWU7XG4gICAgfVxuICB9XG4gIHJlbW92ZVN0eWxlKGVsLCBzdHlsZSwgZmxhZ3MpIHtcbiAgICBjb25zdCBpc1ZhcmlhYmxlID0gc3R5bGUuc3RhcnRzV2l0aCgnLS0nKTtcbiAgICBpZiAoaXNWYXJpYWJsZSkge1xuICAgICAgc3R5bGUgPSBzdHlsZS5yZXBsYWNlKCclTlMlJywgdGhpcy5jc3NWYXJOYW1lc3BhY2UpO1xuICAgIH1cbiAgICBpZiAoaXNWYXJpYWJsZSB8fCBmbGFncyAmIFJlbmRlcmVyU3R5bGVGbGFnczIuRGFzaENhc2UpIHtcbiAgICAgIGVsLnN0eWxlLnJlbW92ZVByb3BlcnR5KHN0eWxlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWwuc3R5bGVbc3R5bGVdID0gJyc7XG4gICAgfVxuICB9XG4gIHNldFByb3BlcnR5KGVsLCBuYW1lLCB2YWx1ZSkge1xuICAgIGlmIChlbCA9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIHRoaXMudGhyb3dPblN5bnRoZXRpY1Byb3BzICYmIGNoZWNrTm9TeW50aGV0aWNQcm9wKG5hbWUsICdwcm9wZXJ0eScpO1xuICAgIGVsW25hbWVdID0gdmFsdWU7XG4gIH1cbiAgc2V0VmFsdWUobm9kZSwgdmFsdWUpIHtcbiAgICBub2RlLm5vZGVWYWx1ZSA9IHZhbHVlO1xuICB9XG4gIGxpc3Rlbih0YXJnZXQsIGV2ZW50LCBjYWxsYmFjaywgb3B0aW9ucykge1xuICAgICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIHRoaXMudGhyb3dPblN5bnRoZXRpY1Byb3BzICYmIGNoZWNrTm9TeW50aGV0aWNQcm9wKGV2ZW50LCAnbGlzdGVuZXInKTtcbiAgICBpZiAodHlwZW9mIHRhcmdldCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHRhcmdldCA9IF9nZXRET00oKS5nZXRHbG9iYWxFdmVudFRhcmdldCh0aGlzLmRvYywgdGFyZ2V0KTtcbiAgICAgIGlmICghdGFyZ2V0KSB7XG4gICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKC01MTAyLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBgVW5zdXBwb3J0ZWQgZXZlbnQgdGFyZ2V0ICR7dGFyZ2V0fSBmb3IgZXZlbnQgJHtldmVudH1gKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IHdyYXBwZWRDYWxsYmFjayA9IHRoaXMuZGVjb3JhdGVQcmV2ZW50RGVmYXVsdChjYWxsYmFjayk7XG4gICAgaWYgKHRoaXMudHJhY2luZ1NlcnZpY2U/LndyYXBFdmVudExpc3RlbmVyKSB7XG4gICAgICB3cmFwcGVkQ2FsbGJhY2sgPSB0aGlzLnRyYWNpbmdTZXJ2aWNlLndyYXBFdmVudExpc3RlbmVyKHRhcmdldCwgZXZlbnQsIHdyYXBwZWRDYWxsYmFjayk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmV2ZW50TWFuYWdlci5hZGRFdmVudExpc3RlbmVyKHRhcmdldCwgZXZlbnQsIHdyYXBwZWRDYWxsYmFjaywgb3B0aW9ucyk7XG4gIH1cbiAgZGVjb3JhdGVQcmV2ZW50RGVmYXVsdChldmVudEhhbmRsZXIpIHtcbiAgICByZXR1cm4gZXZlbnQgPT4ge1xuICAgICAgaWYgKGV2ZW50ID09PSAnX19uZ1Vud3JhcF9fJykge1xuICAgICAgICByZXR1cm4gZXZlbnRIYW5kbGVyO1xuICAgICAgfVxuICAgICAgY29uc3QgYWxsb3dEZWZhdWx0QmVoYXZpb3IgPSB0eXBlb2YgbmdTZXJ2ZXJNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ1NlcnZlck1vZGUgPyB0aGlzLm5nWm9uZS5ydW5HdWFyZGVkKCgpID0+IGV2ZW50SGFuZGxlcihldmVudCkpIDogZXZlbnRIYW5kbGVyKGV2ZW50KTtcbiAgICAgIGlmIChhbGxvd0RlZmF1bHRCZWhhdmlvciA9PT0gZmFsc2UpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfTtcbiAgfVxufVxuY29uc3QgQVRfQ0hBUkNPREUgPSAoKCkgPT4gJ0AnLmNoYXJDb2RlQXQoMCkpKCk7XG5mdW5jdGlvbiBjaGVja05vU3ludGhldGljUHJvcChuYW1lLCBuYW1lS2luZCkge1xuICBpZiAobmFtZS5jaGFyQ29kZUF0KDApID09PSBBVF9DSEFSQ09ERSkge1xuICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDUxMDUsIGBVbmV4cGVjdGVkIHN5bnRoZXRpYyAke25hbWVLaW5kfSAke25hbWV9IGZvdW5kLiBQbGVhc2UgbWFrZSBzdXJlIHRoYXQ6XG4gIC0gTWFrZSBzdXJlIFxcYHByb3ZpZGVBbmltYXRpb25zQXN5bmMoKVxcYCwgXFxgcHJvdmlkZUFuaW1hdGlvbnMoKVxcYCBvciBcXGBwcm92aWRlTm9vcEFuaW1hdGlvbnMoKVxcYCBjYWxsIHdhcyBhZGRlZCB0byBhIGxpc3Qgb2YgcHJvdmlkZXJzIHVzZWQgdG8gYm9vdHN0cmFwIGFuIGFwcGxpY2F0aW9uLlxuICAtIFRoZXJlIGlzIGEgY29ycmVzcG9uZGluZyBhbmltYXRpb24gY29uZmlndXJhdGlvbiBuYW1lZCBcXGAke25hbWV9XFxgIGRlZmluZWQgaW4gdGhlIFxcYGFuaW1hdGlvbnNcXGAgZmllbGQgb2YgdGhlIFxcYEBDb21wb25lbnRcXGAgZGVjb3JhdG9yIChzZWUgaHR0cHM6Ly9hbmd1bGFyLmRldi9hcGkvY29yZS9Db21wb25lbnQjYW5pbWF0aW9ucykuYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGlzVGVtcGxhdGVOb2RlKG5vZGUpIHtcbiAgcmV0dXJuIG5vZGUudGFnTmFtZSA9PT0gJ1RFTVBMQVRFJyAmJiBub2RlLmNvbnRlbnQgIT09IHVuZGVmaW5lZDtcbn1cbmNsYXNzIFNoYWRvd0RvbVJlbmRlcmVyIGV4dGVuZHMgRGVmYXVsdERvbVJlbmRlcmVyMiB7XG4gIGhvc3RFbDtcbiAgc2hhcmVkU3R5bGVzSG9zdDtcbiAgc2hhZG93Um9vdDtcbiAgY29uc3RydWN0b3IoZXZlbnRNYW5hZ2VyLCBob3N0RWwsIGNvbXBvbmVudCwgZG9jLCBuZ1pvbmUsIG5vbmNlLCB0cmFjaW5nU2VydmljZSwgY3NzVmFyTmFtZXNwYWNlLCBzaGFyZWRTdHlsZXNIb3N0KSB7XG4gICAgc3VwZXIoZXZlbnRNYW5hZ2VyLCBkb2MsIG5nWm9uZSwgdHJhY2luZ1NlcnZpY2UsIGNzc1Zhck5hbWVzcGFjZSk7XG4gICAgdGhpcy5ob3N0RWwgPSBob3N0RWw7XG4gICAgdGhpcy5zaGFyZWRTdHlsZXNIb3N0ID0gc2hhcmVkU3R5bGVzSG9zdDtcbiAgICB0aGlzLnNoYWRvd1Jvb3QgPSBob3N0RWwuYXR0YWNoU2hhZG93KHtcbiAgICAgIG1vZGU6ICdvcGVuJ1xuICAgIH0pO1xuICAgIGlmICh0aGlzLnNoYXJlZFN0eWxlc0hvc3QpIHtcbiAgICAgIHRoaXMuc2hhcmVkU3R5bGVzSG9zdC5hZGRIb3N0KHRoaXMuc2hhZG93Um9vdCk7XG4gICAgfVxuICAgIGxldCBzdHlsZXMgPSBjb21wb25lbnQuc3R5bGVzO1xuICAgIGlmIChuZ0Rldk1vZGUpIHtcbiAgICAgIGNvbnN0IGJhc2VIcmVmID0gX2dldERPTSgpLmdldEJhc2VIcmVmKGRvYykgPz8gJyc7XG4gICAgICBzdHlsZXMgPSBhZGRCYXNlSHJlZlRvQ3NzU291cmNlTWFwKGJhc2VIcmVmLCBzdHlsZXMpO1xuICAgIH1cbiAgICBzdHlsZXMgPSBzaGltU3R5bGVzQ29udGVudChjb21wb25lbnQuaWQsIHN0eWxlcykubWFwKHMgPT4gcy5yZXBsYWNlKC8lTlMlL2csIGNzc1Zhck5hbWVzcGFjZSkpO1xuICAgIGZvciAoY29uc3Qgc3R5bGUgb2Ygc3R5bGVzKSB7XG4gICAgICBjb25zdCBzdHlsZUVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgICAgIGlmIChub25jZSkge1xuICAgICAgICBzdHlsZUVsLnNldEF0dHJpYnV0ZSgnbm9uY2UnLCBub25jZSk7XG4gICAgICB9XG4gICAgICBzdHlsZUVsLnRleHRDb250ZW50ID0gc3R5bGU7XG4gICAgICB0aGlzLnNoYWRvd1Jvb3QuYXBwZW5kQ2hpbGQoc3R5bGVFbCk7XG4gICAgfVxuICAgIGNvbnN0IHN0eWxlVXJscyA9IGNvbXBvbmVudC5nZXRFeHRlcm5hbFN0eWxlcz8uKCk7XG4gICAgaWYgKHN0eWxlVXJscykge1xuICAgICAgZm9yIChjb25zdCBzdHlsZVVybCBvZiBzdHlsZVVybHMpIHtcbiAgICAgICAgY29uc3QgbGlua0VsID0gY3JlYXRlTGlua0VsZW1lbnQoc3R5bGVVcmwsIGRvYyk7XG4gICAgICAgIGlmIChub25jZSkge1xuICAgICAgICAgIGxpbmtFbC5zZXRBdHRyaWJ1dGUoJ25vbmNlJywgbm9uY2UpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2hhZG93Um9vdC5hcHBlbmRDaGlsZChsaW5rRWwpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBub2RlT3JTaGFkb3dSb290KG5vZGUpIHtcbiAgICByZXR1cm4gbm9kZSA9PT0gdGhpcy5ob3N0RWwgPyB0aGlzLnNoYWRvd1Jvb3QgOiBub2RlO1xuICB9XG4gIGFwcGVuZENoaWxkKHBhcmVudCwgbmV3Q2hpbGQpIHtcbiAgICByZXR1cm4gc3VwZXIuYXBwZW5kQ2hpbGQodGhpcy5ub2RlT3JTaGFkb3dSb290KHBhcmVudCksIG5ld0NoaWxkKTtcbiAgfVxuICBpbnNlcnRCZWZvcmUocGFyZW50LCBuZXdDaGlsZCwgcmVmQ2hpbGQpIHtcbiAgICByZXR1cm4gc3VwZXIuaW5zZXJ0QmVmb3JlKHRoaXMubm9kZU9yU2hhZG93Um9vdChwYXJlbnQpLCBuZXdDaGlsZCwgcmVmQ2hpbGQpO1xuICB9XG4gIHJlbW92ZUNoaWxkKF9wYXJlbnQsIG9sZENoaWxkKSB7XG4gICAgcmV0dXJuIHN1cGVyLnJlbW92ZUNoaWxkKG51bGwsIG9sZENoaWxkKTtcbiAgfVxuICBwYXJlbnROb2RlKG5vZGUpIHtcbiAgICByZXR1cm4gdGhpcy5ub2RlT3JTaGFkb3dSb290KHN1cGVyLnBhcmVudE5vZGUodGhpcy5ub2RlT3JTaGFkb3dSb290KG5vZGUpKSk7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5zaGFyZWRTdHlsZXNIb3N0KSB7XG4gICAgICB0aGlzLnNoYXJlZFN0eWxlc0hvc3QucmVtb3ZlSG9zdCh0aGlzLnNoYWRvd1Jvb3QpO1xuICAgIH1cbiAgfVxufVxuY2xhc3MgTm9uZUVuY2Fwc3VsYXRpb25Eb21SZW5kZXJlciBleHRlbmRzIERlZmF1bHREb21SZW5kZXJlcjIge1xuICBzaGFyZWRTdHlsZXNIb3N0O1xuICByZW1vdmVTdHlsZXNPbkNvbXBEZXN0cm95O1xuICBzdHlsZXM7XG4gIHN0eWxlVXJscztcbiAgY29uc3RydWN0b3IoZXZlbnRNYW5hZ2VyLCBzaGFyZWRTdHlsZXNIb3N0LCBjb21wb25lbnQsIHJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3ksIGRvYywgbmdab25lLCB0cmFjaW5nU2VydmljZSwgY3NzVmFyTmFtZXNwYWNlLCBjb21wSWQpIHtcbiAgICBzdXBlcihldmVudE1hbmFnZXIsIGRvYywgbmdab25lLCB0cmFjaW5nU2VydmljZSwgY3NzVmFyTmFtZXNwYWNlKTtcbiAgICB0aGlzLnNoYXJlZFN0eWxlc0hvc3QgPSBzaGFyZWRTdHlsZXNIb3N0O1xuICAgIHRoaXMucmVtb3ZlU3R5bGVzT25Db21wRGVzdHJveSA9IHJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3k7XG4gICAgbGV0IHN0eWxlcyA9IGNvbXBvbmVudC5zdHlsZXM7XG4gICAgaWYgKG5nRGV2TW9kZSkge1xuICAgICAgY29uc3QgYmFzZUhyZWYgPSBfZ2V0RE9NKCkuZ2V0QmFzZUhyZWYoZG9jKSA/PyAnJztcbiAgICAgIHN0eWxlcyA9IGFkZEJhc2VIcmVmVG9Dc3NTb3VyY2VNYXAoYmFzZUhyZWYsIHN0eWxlcyk7XG4gICAgfVxuICAgIGNvbnN0IHNoaW1tZWQgPSBjb21wSWQgPyBzaGltU3R5bGVzQ29udGVudChjb21wSWQsIHN0eWxlcykgOiBzdHlsZXM7XG4gICAgdGhpcy5zdHlsZXMgPSBzaGltbWVkLm1hcChzID0+IHMucmVwbGFjZSgvJU5TJS9nLCBjc3NWYXJOYW1lc3BhY2UpKTtcbiAgICB0aGlzLnN0eWxlVXJscyA9IGNvbXBvbmVudC5nZXRFeHRlcm5hbFN0eWxlcz8uKGNvbXBJZCk7XG4gIH1cbiAgYXBwbHlTdHlsZXMoKSB7XG4gICAgdGhpcy5zaGFyZWRTdHlsZXNIb3N0LmFkZFN0eWxlcyh0aGlzLnN0eWxlcywgdGhpcy5zdHlsZVVybHMpO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgaWYgKCF0aGlzLnJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3kpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKF9hbGxMZWF2aW5nQW5pbWF0aW9ucy5zaXplID09PSAwKSB7XG4gICAgICB0aGlzLnNoYXJlZFN0eWxlc0hvc3QucmVtb3ZlU3R5bGVzKHRoaXMuc3R5bGVzLCB0aGlzLnN0eWxlVXJscyk7XG4gICAgfVxuICB9XG59XG5jbGFzcyBFbXVsYXRlZEVuY2Fwc3VsYXRpb25Eb21SZW5kZXJlcjIgZXh0ZW5kcyBOb25lRW5jYXBzdWxhdGlvbkRvbVJlbmRlcmVyIHtcbiAgY29udGVudEF0dHI7XG4gIGhvc3RBdHRyO1xuICBjb25zdHJ1Y3RvcihldmVudE1hbmFnZXIsIHNoYXJlZFN0eWxlc0hvc3QsIGNvbXBvbmVudCwgYXBwSWQsIHJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3ksIGRvYywgbmdab25lLCB0cmFjaW5nU2VydmljZSwgY3NzVmFyTmFtZXNwYWNlKSB7XG4gICAgY29uc3QgY29tcElkID0gYXBwSWQgKyAnLScgKyBjb21wb25lbnQuaWQ7XG4gICAgc3VwZXIoZXZlbnRNYW5hZ2VyLCBzaGFyZWRTdHlsZXNIb3N0LCBjb21wb25lbnQsIHJlbW92ZVN0eWxlc09uQ29tcERlc3Ryb3ksIGRvYywgbmdab25lLCB0cmFjaW5nU2VydmljZSwgY3NzVmFyTmFtZXNwYWNlLCBjb21wSWQpO1xuICAgIHRoaXMuY29udGVudEF0dHIgPSBzaGltQ29udGVudEF0dHJpYnV0ZShjb21wSWQpO1xuICAgIHRoaXMuaG9zdEF0dHIgPSBzaGltSG9zdEF0dHJpYnV0ZShjb21wSWQpO1xuICB9XG4gIGFwcGx5VG9Ib3N0KGVsZW1lbnQpIHtcbiAgICB0aGlzLmFwcGx5U3R5bGVzKCk7XG4gICAgdGhpcy5zZXRBdHRyaWJ1dGUoZWxlbWVudCwgdGhpcy5ob3N0QXR0ciwgJycpO1xuICB9XG4gIGNyZWF0ZUVsZW1lbnQocGFyZW50LCBuYW1lKSB7XG4gICAgY29uc3QgZWwgPSBzdXBlci5jcmVhdGVFbGVtZW50KHBhcmVudCwgbmFtZSk7XG4gICAgc3VwZXIuc2V0QXR0cmlidXRlKGVsLCB0aGlzLmNvbnRlbnRBdHRyLCAnJyk7XG4gICAgcmV0dXJuIGVsO1xuICB9XG59XG5leHBvcnQgeyBDU1NfVkFSX05BTUVTUEFDRSwgRG9tRXZlbnRzUGx1Z2luLCBEb21SZW5kZXJlckZhY3RvcnkyLCBFVkVOVF9NQU5BR0VSX1BMVUdJTlMsIEV2ZW50TWFuYWdlciwgRXZlbnRNYW5hZ2VyUGx1Z2luLCBSRU1PVkVfU1RZTEVTX09OX0NPTVBPTkVOVF9ERVNUUk9ZLCBTaGFyZWRTdHlsZXNIb3N0LCBwcm92aWRlQ3NzVmFyTmFtZXNwYWNpbmcgfTtcbiIsIi8qKlxuICogQGxpY2Vuc2UgQW5ndWxhciB2MjIuMS4yXG4gKiAoYykgMjAxMC0yMDI2IEdvb2dsZSBMTEMuIGh0dHBzOi8vYW5ndWxhci5kZXYvXG4gKiBMaWNlbnNlOiBNSVRcbiAqL1xuXG5pbXBvcnQgeyDJtURvbUFkYXB0ZXIgYXMgX0RvbUFkYXB0ZXIsIMm1c2V0Um9vdERvbUFkYXB0ZXIgYXMgX3NldFJvb3REb21BZGFwdGVyLCDJtXBhcnNlQ29va2llVmFsdWUgYXMgX3BhcnNlQ29va2llVmFsdWUsIMm1Z2V0RE9NIGFzIF9nZXRET00sIERPQ1VNRU5ULCBDb21tb25Nb2R1bGUsIMm1UExBVEZPUk1fQlJPV1NFUl9JRCBhcyBfUExBVEZPUk1fQlJPV1NFUl9JRCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgKiBhcyBpMCBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IMm1Z2xvYmFsIGFzIF9nbG9iYWwsIMm1UnVudGltZUVycm9yIGFzIF9SdW50aW1lRXJyb3IsIEluamVjdCwgSW5qZWN0YWJsZSwgaW5qZWN0LCBJbmplY3Rpb25Ub2tlbiwgQXBwbGljYXRpb25Nb2R1bGUsIMm1SU5KRUNUT1JfU0NPUEUgYXMgX0lOSkVDVE9SX1NDT1BFLCBFcnJvckhhbmRsZXIsIMm1U0hBUkVEX1NUWUxFU19IT1NUIGFzIF9TSEFSRURfU1RZTEVTX0hPU1QsIFJlbmRlcmVyRmFjdG9yeTIsIMm1VEVTVEFCSUxJVFlfR0VUVEVSIGFzIF9URVNUQUJJTElUWV9HRVRURVIsIE5nWm9uZSwgVGVzdGFiaWxpdHlSZWdpc3RyeSwgVGVzdGFiaWxpdHksIMm1VEVTVEFCSUxJVFkgYXMgX1RFU1RBQklMSVRZLCDJtWludGVybmFsQ3JlYXRlQXBwbGljYXRpb24gYXMgX2ludGVybmFsQ3JlYXRlQXBwbGljYXRpb24sIGNyZWF0ZVBsYXRmb3JtRmFjdG9yeSwgcGxhdGZvcm1Db3JlLCBQTEFURk9STV9JRCwgUExBVEZPUk1fSU5JVElBTElaRVIsIMm1VVNFX1BFTkRJTkdfVEFTS1MgYXMgX1VTRV9QRU5ESU5HX1RBU0tTLCDJtXJlc29sdmVDb21wb25lbnRSZXNvdXJjZXMgYXMgX3Jlc29sdmVDb21wb25lbnRSZXNvdXJjZXMsIMm1c2V0RG9jdW1lbnQgYXMgX3NldERvY3VtZW50LCBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRXZlbnRNYW5hZ2VyUGx1Z2luLCBEb21FdmVudHNQbHVnaW4sIEVWRU5UX01BTkFHRVJfUExVR0lOUywgRG9tUmVuZGVyZXJGYWN0b3J5MiwgU2hhcmVkU3R5bGVzSG9zdCwgRXZlbnRNYW5hZ2VyIH0gZnJvbSAnLi9fZG9tX3JlbmRlcmVyLWNodW5rLm1qcyc7XG5jbGFzcyBCcm93c2VyRG9tQWRhcHRlciBleHRlbmRzIF9Eb21BZGFwdGVyIHtcbiAgc3VwcG9ydHNET01FdmVudHMgPSB0cnVlO1xuICBzdGF0aWMgbWFrZUN1cnJlbnQoKSB7XG4gICAgX3NldFJvb3REb21BZGFwdGVyKG5ldyBCcm93c2VyRG9tQWRhcHRlcigpKTtcbiAgfVxuICBvbkFuZENhbmNlbChlbCwgZXZ0LCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoZXZ0LCBsaXN0ZW5lciwgb3B0aW9ucyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZ0LCBsaXN0ZW5lciwgb3B0aW9ucyk7XG4gICAgfTtcbiAgfVxuICBkaXNwYXRjaEV2ZW50KGVsLCBldnQpIHtcbiAgICBlbC5kaXNwYXRjaEV2ZW50KGV2dCk7XG4gIH1cbiAgcmVtb3ZlKG5vZGUpIHtcbiAgICBub2RlLnJlbW92ZSgpO1xuICB9XG4gIGNyZWF0ZUVsZW1lbnQodGFnTmFtZSwgZG9jKSB7XG4gICAgZG9jID0gZG9jIHx8IHRoaXMuZ2V0RGVmYXVsdERvY3VtZW50KCk7XG4gICAgcmV0dXJuIGRvYy5jcmVhdGVFbGVtZW50KHRhZ05hbWUpO1xuICB9XG4gIGNyZWF0ZUh0bWxEb2N1bWVudCgpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQuaW1wbGVtZW50YXRpb24uY3JlYXRlSFRNTERvY3VtZW50KCdmYWtlVGl0bGUnKTtcbiAgfVxuICBnZXREZWZhdWx0RG9jdW1lbnQoKSB7XG4gICAgcmV0dXJuIGRvY3VtZW50O1xuICB9XG4gIGlzRWxlbWVudE5vZGUobm9kZSkge1xuICAgIHJldHVybiBub2RlLm5vZGVUeXBlID09PSBOb2RlLkVMRU1FTlRfTk9ERTtcbiAgfVxuICBpc1NoYWRvd1Jvb3Qobm9kZSkge1xuICAgIHJldHVybiBub2RlIGluc3RhbmNlb2YgRG9jdW1lbnRGcmFnbWVudDtcbiAgfVxuICBnZXRHbG9iYWxFdmVudFRhcmdldChkb2MsIHRhcmdldCkge1xuICAgIGlmICh0YXJnZXQgPT09ICd3aW5kb3cnKSB7XG4gICAgICByZXR1cm4gd2luZG93O1xuICAgIH1cbiAgICBpZiAodGFyZ2V0ID09PSAnZG9jdW1lbnQnKSB7XG4gICAgICByZXR1cm4gZG9jO1xuICAgIH1cbiAgICBpZiAodGFyZ2V0ID09PSAnYm9keScpIHtcbiAgICAgIHJldHVybiBkb2MuYm9keTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgZ2V0QmFzZUhyZWYoZG9jKSB7XG4gICAgY29uc3QgaHJlZiA9IGdldEJhc2VFbGVtZW50SHJlZigpO1xuICAgIHJldHVybiBocmVmID09IG51bGwgPyBudWxsIDogcmVsYXRpdmVQYXRoKGhyZWYpO1xuICB9XG4gIHJlc2V0QmFzZUVsZW1lbnQoKSB7XG4gICAgYmFzZUVsZW1lbnQgPSBudWxsO1xuICB9XG4gIGdldFVzZXJBZ2VudCgpIHtcbiAgICByZXR1cm4gd2luZG93Lm5hdmlnYXRvci51c2VyQWdlbnQ7XG4gIH1cbiAgZ2V0Q29va2llKG5hbWUpIHtcbiAgICByZXR1cm4gX3BhcnNlQ29va2llVmFsdWUoZG9jdW1lbnQuY29va2llLCBuYW1lKTtcbiAgfVxufVxubGV0IGJhc2VFbGVtZW50ID0gbnVsbDtcbmZ1bmN0aW9uIGdldEJhc2VFbGVtZW50SHJlZigpIHtcbiAgYmFzZUVsZW1lbnQgPSBiYXNlRWxlbWVudCB8fCBkb2N1bWVudC5oZWFkLnF1ZXJ5U2VsZWN0b3IoJ2Jhc2UnKTtcbiAgcmV0dXJuIGJhc2VFbGVtZW50ID8gYmFzZUVsZW1lbnQuZ2V0QXR0cmlidXRlKCdocmVmJykgOiBudWxsO1xufVxuZnVuY3Rpb24gcmVsYXRpdmVQYXRoKHVybCkge1xuICByZXR1cm4gbmV3IFVSTCh1cmwsIGRvY3VtZW50LmJhc2VVUkkpLnBhdGhuYW1lO1xufVxuY2xhc3MgQnJvd3NlckdldFRlc3RhYmlsaXR5IHtcbiAgYWRkVG9XaW5kb3cocmVnaXN0cnkpIHtcbiAgICBfZ2xvYmFsWydnZXRBbmd1bGFyVGVzdGFiaWxpdHknXSA9IChlbGVtLCBmaW5kSW5BbmNlc3RvcnMgPSB0cnVlKSA9PiB7XG4gICAgICBjb25zdCB0ZXN0YWJpbGl0eSA9IHJlZ2lzdHJ5LmZpbmRUZXN0YWJpbGl0eUluVHJlZShlbGVtLCBmaW5kSW5BbmNlc3RvcnMpO1xuICAgICAgaWYgKHRlc3RhYmlsaXR5ID09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNTEwMywgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgJ0NvdWxkIG5vdCBmaW5kIHRlc3RhYmlsaXR5IGZvciBlbGVtZW50LicpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRlc3RhYmlsaXR5O1xuICAgIH07XG4gICAgX2dsb2JhbFsnZ2V0QWxsQW5ndWxhclRlc3RhYmlsaXRpZXMnXSA9ICgpID0+IHJlZ2lzdHJ5LmdldEFsbFRlc3RhYmlsaXRpZXMoKTtcbiAgICBfZ2xvYmFsWydnZXRBbGxBbmd1bGFyUm9vdEVsZW1lbnRzJ10gPSAoKSA9PiByZWdpc3RyeS5nZXRBbGxSb290RWxlbWVudHMoKTtcbiAgICBjb25zdCB3aGVuQWxsU3RhYmxlID0gY2FsbGJhY2sgPT4ge1xuICAgICAgY29uc3QgdGVzdGFiaWxpdGllcyA9IF9nbG9iYWxbJ2dldEFsbEFuZ3VsYXJUZXN0YWJpbGl0aWVzJ10oKTtcbiAgICAgIGxldCBjb3VudCA9IHRlc3RhYmlsaXRpZXMubGVuZ3RoO1xuICAgICAgY29uc3QgZGVjcmVtZW50ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBjb3VudC0tO1xuICAgICAgICBpZiAoY291bnQgPT0gMCkge1xuICAgICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICB0ZXN0YWJpbGl0aWVzLmZvckVhY2godGVzdGFiaWxpdHkgPT4ge1xuICAgICAgICB0ZXN0YWJpbGl0eS53aGVuU3RhYmxlKGRlY3JlbWVudCk7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIGlmICghX2dsb2JhbFsnZnJhbWV3b3JrU3RhYmlsaXplcnMnXSkge1xuICAgICAgX2dsb2JhbFsnZnJhbWV3b3JrU3RhYmlsaXplcnMnXSA9IFtdO1xuICAgIH1cbiAgICBfZ2xvYmFsWydmcmFtZXdvcmtTdGFiaWxpemVycyddLnB1c2god2hlbkFsbFN0YWJsZSk7XG4gIH1cbiAgZmluZFRlc3RhYmlsaXR5SW5UcmVlKHJlZ2lzdHJ5LCBlbGVtLCBmaW5kSW5BbmNlc3RvcnMpIHtcbiAgICBpZiAoZWxlbSA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgdCA9IHJlZ2lzdHJ5LmdldFRlc3RhYmlsaXR5KGVsZW0pO1xuICAgIGlmICh0ICE9IG51bGwpIHtcbiAgICAgIHJldHVybiB0O1xuICAgIH0gZWxzZSBpZiAoIWZpbmRJbkFuY2VzdG9ycykge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmIChfZ2V0RE9NKCkuaXNTaGFkb3dSb290KGVsZW0pKSB7XG4gICAgICByZXR1cm4gdGhpcy5maW5kVGVzdGFiaWxpdHlJblRyZWUocmVnaXN0cnksIGVsZW0uaG9zdCwgdHJ1ZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmZpbmRUZXN0YWJpbGl0eUluVHJlZShyZWdpc3RyeSwgZWxlbS5wYXJlbnRFbGVtZW50LCB0cnVlKTtcbiAgfVxufVxuY29uc3QgTU9ESUZJRVJfS0VZUyA9IFsnYWx0JywgJ2NvbnRyb2wnLCAnbWV0YScsICdzaGlmdCddO1xuY29uc3QgX2tleU1hcCA9IHtcbiAgJ1xcYic6ICdCYWNrc3BhY2UnLFxuICAnXFx0JzogJ1RhYicsXG4gICdcXHg3Ric6ICdEZWxldGUnLFxuICAnXFx4MUInOiAnRXNjYXBlJyxcbiAgJ0RlbCc6ICdEZWxldGUnLFxuICAnRXNjJzogJ0VzY2FwZScsXG4gICdMZWZ0JzogJ0Fycm93TGVmdCcsXG4gICdSaWdodCc6ICdBcnJvd1JpZ2h0JyxcbiAgJ1VwJzogJ0Fycm93VXAnLFxuICAnRG93bic6ICdBcnJvd0Rvd24nLFxuICAnTWVudSc6ICdDb250ZXh0TWVudScsXG4gICdTY3JvbGwnOiAnU2Nyb2xsTG9jaycsXG4gICdXaW4nOiAnT1MnXG59O1xuY29uc3QgTU9ESUZJRVJfS0VZX0dFVFRFUlMgPSB7XG4gICdhbHQnOiBldmVudCA9PiBldmVudC5hbHRLZXksXG4gICdjb250cm9sJzogZXZlbnQgPT4gZXZlbnQuY3RybEtleSxcbiAgJ21ldGEnOiBldmVudCA9PiBldmVudC5tZXRhS2V5LFxuICAnc2hpZnQnOiBldmVudCA9PiBldmVudC5zaGlmdEtleVxufTtcbmNsYXNzIEtleUV2ZW50c1BsdWdpbiBleHRlbmRzIEV2ZW50TWFuYWdlclBsdWdpbiB7XG4gIGNvbnN0cnVjdG9yKGRvYykge1xuICAgIHN1cGVyKGRvYyk7XG4gIH1cbiAgc3VwcG9ydHMoZXZlbnROYW1lKSB7XG4gICAgcmV0dXJuIEtleUV2ZW50c1BsdWdpbi5wYXJzZUV2ZW50TmFtZShldmVudE5hbWUpICE9IG51bGw7XG4gIH1cbiAgYWRkRXZlbnRMaXN0ZW5lcihlbGVtZW50LCBldmVudE5hbWUsIGhhbmRsZXIsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBwYXJzZWRFdmVudCA9IEtleUV2ZW50c1BsdWdpbi5wYXJzZUV2ZW50TmFtZShldmVudE5hbWUpO1xuICAgIGNvbnN0IG91dHNpZGVIYW5kbGVyID0gS2V5RXZlbnRzUGx1Z2luLmV2ZW50Q2FsbGJhY2socGFyc2VkRXZlbnRbJ2Z1bGxLZXknXSwgaGFuZGxlciwgdGhpcy5tYW5hZ2VyLmdldFpvbmUoKSk7XG4gICAgcmV0dXJuIHRoaXMubWFuYWdlci5nZXRab25lKCkucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgcmV0dXJuIF9nZXRET00oKS5vbkFuZENhbmNlbChlbGVtZW50LCBwYXJzZWRFdmVudFsnZG9tRXZlbnROYW1lJ10sIG91dHNpZGVIYW5kbGVyLCBvcHRpb25zKTtcbiAgICB9KTtcbiAgfVxuICBzdGF0aWMgcGFyc2VFdmVudE5hbWUoZXZlbnROYW1lKSB7XG4gICAgY29uc3QgcGFydHMgPSBldmVudE5hbWUudG9Mb3dlckNhc2UoKS5zcGxpdCgnLicpO1xuICAgIGNvbnN0IGRvbUV2ZW50TmFtZSA9IHBhcnRzLnNoaWZ0KCk7XG4gICAgaWYgKHBhcnRzLmxlbmd0aCA9PT0gMCB8fCAhKGRvbUV2ZW50TmFtZSA9PT0gJ2tleWRvd24nIHx8IGRvbUV2ZW50TmFtZSA9PT0gJ2tleXVwJykpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBrZXkgPSBLZXlFdmVudHNQbHVnaW4uX25vcm1hbGl6ZUtleShwYXJ0cy5wb3AoKSk7XG4gICAgbGV0IGZ1bGxLZXkgPSAnJztcbiAgICBsZXQgY29kZUlYID0gcGFydHMuaW5kZXhPZignY29kZScpO1xuICAgIGlmIChjb2RlSVggPiAtMSkge1xuICAgICAgcGFydHMuc3BsaWNlKGNvZGVJWCwgMSk7XG4gICAgICBmdWxsS2V5ID0gJ2NvZGUuJztcbiAgICB9XG4gICAgTU9ESUZJRVJfS0VZUy5mb3JFYWNoKG1vZGlmaWVyTmFtZSA9PiB7XG4gICAgICBjb25zdCBpbmRleCA9IHBhcnRzLmluZGV4T2YobW9kaWZpZXJOYW1lKTtcbiAgICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICAgIHBhcnRzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgIGZ1bGxLZXkgKz0gbW9kaWZpZXJOYW1lICsgJy4nO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGZ1bGxLZXkgKz0ga2V5O1xuICAgIGlmIChwYXJ0cy5sZW5ndGggIT0gMCB8fCBrZXkubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgcmVzdWx0Wydkb21FdmVudE5hbWUnXSA9IGRvbUV2ZW50TmFtZTtcbiAgICByZXN1bHRbJ2Z1bGxLZXknXSA9IGZ1bGxLZXk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBzdGF0aWMgbWF0Y2hFdmVudEZ1bGxLZXlDb2RlKGV2ZW50LCBmdWxsS2V5Q29kZSkge1xuICAgIGxldCBrZXljb2RlID0gX2tleU1hcFtldmVudC5rZXldIHx8IGV2ZW50LmtleTtcbiAgICBsZXQga2V5ID0gJyc7XG4gICAgaWYgKGZ1bGxLZXlDb2RlLmluZGV4T2YoJ2NvZGUuJykgPiAtMSkge1xuICAgICAga2V5Y29kZSA9IGV2ZW50LmNvZGU7XG4gICAgICBrZXkgPSAnY29kZS4nO1xuICAgIH1cbiAgICBpZiAoa2V5Y29kZSA9PSBudWxsIHx8ICFrZXljb2RlKSByZXR1cm4gZmFsc2U7XG4gICAga2V5Y29kZSA9IGtleWNvZGUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoa2V5Y29kZSA9PT0gJyAnKSB7XG4gICAgICBrZXljb2RlID0gJ3NwYWNlJztcbiAgICB9IGVsc2UgaWYgKGtleWNvZGUgPT09ICcuJykge1xuICAgICAga2V5Y29kZSA9ICdkb3QnO1xuICAgIH1cbiAgICBNT0RJRklFUl9LRVlTLmZvckVhY2gobW9kaWZpZXJOYW1lID0+IHtcbiAgICAgIGlmIChtb2RpZmllck5hbWUgIT09IGtleWNvZGUpIHtcbiAgICAgICAgY29uc3QgbW9kaWZpZXJHZXR0ZXIgPSBNT0RJRklFUl9LRVlfR0VUVEVSU1ttb2RpZmllck5hbWVdO1xuICAgICAgICBpZiAobW9kaWZpZXJHZXR0ZXIoZXZlbnQpKSB7XG4gICAgICAgICAga2V5ICs9IG1vZGlmaWVyTmFtZSArICcuJztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIGtleSArPSBrZXljb2RlO1xuICAgIHJldHVybiBrZXkgPT09IGZ1bGxLZXlDb2RlO1xuICB9XG4gIHN0YXRpYyBldmVudENhbGxiYWNrKGZ1bGxLZXksIGhhbmRsZXIsIHpvbmUpIHtcbiAgICByZXR1cm4gZXZlbnQgPT4ge1xuICAgICAgaWYgKEtleUV2ZW50c1BsdWdpbi5tYXRjaEV2ZW50RnVsbEtleUNvZGUoZXZlbnQsIGZ1bGxLZXkpKSB7XG4gICAgICAgIHpvbmUucnVuR3VhcmRlZCgoKSA9PiBoYW5kbGVyKGV2ZW50KSk7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuICBzdGF0aWMgX25vcm1hbGl6ZUtleShrZXlOYW1lKSB7XG4gICAgcmV0dXJuIGtleU5hbWUgPT09ICdlc2MnID8gJ2VzY2FwZScgOiBrZXlOYW1lO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEtleUV2ZW50c1BsdWdpbl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEtleUV2ZW50c1BsdWdpbikoaTAuybXJtWluamVjdChET0NVTUVOVCkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBLZXlFdmVudHNQbHVnaW4sXG4gICAgZmFjdG9yeTogS2V5RXZlbnRzUGx1Z2luLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoS2V5RXZlbnRzUGx1Z2luLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkLFxuICAgIGRlY29yYXRvcnM6IFt7XG4gICAgICB0eXBlOiBJbmplY3QsXG4gICAgICBhcmdzOiBbRE9DVU1FTlRdXG4gICAgfV1cbiAgfV0sIG51bGwpO1xufSkoKTtcbmFzeW5jIGZ1bmN0aW9uIGJvb3RzdHJhcEFwcGxpY2F0aW9uKHJvb3RDb21wb25lbnQsIG9wdGlvbnMsIGNvbnRleHQpIHtcbiAgY29uc3QgY29uZmlnID0ge1xuICAgIHJvb3RDb21wb25lbnQsXG4gICAgLi4uY3JlYXRlUHJvdmlkZXJzQ29uZmlnKG9wdGlvbnMsIGNvbnRleHQpXG4gIH07XG4gIGlmICgodHlwZW9mIG5nSml0TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdKaXRNb2RlKSAmJiB0eXBlb2YgZmV0Y2ggPT09ICdmdW5jdGlvbicpIHtcbiAgICBhd2FpdCByZXNvbHZlSml0UmVzb3VyY2VzKCk7XG4gIH1cbiAgcmV0dXJuIF9pbnRlcm5hbENyZWF0ZUFwcGxpY2F0aW9uKGNvbmZpZyk7XG59XG5hc3luYyBmdW5jdGlvbiBjcmVhdGVBcHBsaWNhdGlvbihvcHRpb25zLCBjb250ZXh0KSB7XG4gIGlmICgodHlwZW9mIG5nSml0TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdKaXRNb2RlKSAmJiB0eXBlb2YgZmV0Y2ggPT09ICdmdW5jdGlvbicpIHtcbiAgICBhd2FpdCByZXNvbHZlSml0UmVzb3VyY2VzKCk7XG4gIH1cbiAgcmV0dXJuIF9pbnRlcm5hbENyZWF0ZUFwcGxpY2F0aW9uKGNyZWF0ZVByb3ZpZGVyc0NvbmZpZyhvcHRpb25zLCBjb250ZXh0KSk7XG59XG5mdW5jdGlvbiBjcmVhdGVQcm92aWRlcnNDb25maWcob3B0aW9ucywgY29udGV4dCkge1xuICByZXR1cm4ge1xuICAgIHBsYXRmb3JtUmVmOiBjb250ZXh0Py5wbGF0Zm9ybVJlZixcbiAgICBhcHBQcm92aWRlcnM6IFsuLi5CUk9XU0VSX01PRFVMRV9QUk9WSURFUlMsIC4uLihvcHRpb25zPy5wcm92aWRlcnMgPz8gW10pXSxcbiAgICBwbGF0Zm9ybVByb3ZpZGVyczogSU5URVJOQUxfQlJPV1NFUl9QTEFURk9STV9QUk9WSURFUlNcbiAgfTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHJlc29sdmVKaXRSZXNvdXJjZXMoKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGF3YWl0IF9yZXNvbHZlQ29tcG9uZW50UmVzb3VyY2VzKGZldGNoKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgfVxufVxuZnVuY3Rpb24gcHJvdmlkZVByb3RyYWN0b3JUZXN0aW5nU3VwcG9ydChvcHRpb25zID0ge30pIHtcbiAgcmV0dXJuIFsuLi5URVNUQUJJTElUWV9QUk9WSURFUlMsIG9wdGlvbnM/LnVzZVBlbmRpbmdUYXNrc0ZvclN0YWJpbGl0eSAhPT0gdW5kZWZpbmVkID8ge1xuICAgIHByb3ZpZGU6IF9VU0VfUEVORElOR19UQVNLUyxcbiAgICB1c2VWYWx1ZTogb3B0aW9ucy51c2VQZW5kaW5nVGFza3NGb3JTdGFiaWxpdHkgPz8gZmFsc2VcbiAgfSA6IFtdXTtcbn1cbmZ1bmN0aW9uIGluaXREb21BZGFwdGVyKCkge1xuICBCcm93c2VyRG9tQWRhcHRlci5tYWtlQ3VycmVudCgpO1xufVxuZnVuY3Rpb24gZXJyb3JIYW5kbGVyKCkge1xuICByZXR1cm4gbmV3IEVycm9ySGFuZGxlcigpO1xufVxuZnVuY3Rpb24gX2RvY3VtZW50KCkge1xuICBfc2V0RG9jdW1lbnQoZG9jdW1lbnQpO1xuICByZXR1cm4gZG9jdW1lbnQ7XG59XG5jb25zdCBJTlRFUk5BTF9CUk9XU0VSX1BMQVRGT1JNX1BST1ZJREVSUyA9IFt7XG4gIHByb3ZpZGU6IFBMQVRGT1JNX0lELFxuICB1c2VWYWx1ZTogX1BMQVRGT1JNX0JST1dTRVJfSURcbn0sIHtcbiAgcHJvdmlkZTogUExBVEZPUk1fSU5JVElBTElaRVIsXG4gIHVzZVZhbHVlOiBpbml0RG9tQWRhcHRlcixcbiAgbXVsdGk6IHRydWVcbn0sIHtcbiAgcHJvdmlkZTogRE9DVU1FTlQsXG4gIHVzZUZhY3Rvcnk6IF9kb2N1bWVudFxufV07XG5jb25zdCBwbGF0Zm9ybUJyb3dzZXIgPSBjcmVhdGVQbGF0Zm9ybUZhY3RvcnkocGxhdGZvcm1Db3JlLCAnYnJvd3NlcicsIElOVEVSTkFMX0JST1dTRVJfUExBVEZPUk1fUFJPVklERVJTKTtcbmNvbnN0IEJST1dTRVJfTU9EVUxFX1BST1ZJREVSU19NQVJLRVIgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ0Jyb3dzZXJNb2R1bGUgUHJvdmlkZXJzIE1hcmtlcicgOiAnJyk7XG5jb25zdCBURVNUQUJJTElUWV9QUk9WSURFUlMgPSBbe1xuICBwcm92aWRlOiBfVEVTVEFCSUxJVFlfR0VUVEVSLFxuICB1c2VDbGFzczogQnJvd3NlckdldFRlc3RhYmlsaXR5XG59LCB7XG4gIHByb3ZpZGU6IF9URVNUQUJJTElUWSxcbiAgdXNlQ2xhc3M6IFRlc3RhYmlsaXR5LFxuICBkZXBzOiBbTmdab25lLCBUZXN0YWJpbGl0eVJlZ2lzdHJ5LCBfVEVTVEFCSUxJVFlfR0VUVEVSXVxufSwge1xuICBwcm92aWRlOiBUZXN0YWJpbGl0eSxcbiAgdXNlQ2xhc3M6IFRlc3RhYmlsaXR5LFxuICBkZXBzOiBbTmdab25lLCBUZXN0YWJpbGl0eVJlZ2lzdHJ5LCBfVEVTVEFCSUxJVFlfR0VUVEVSXVxufV07XG5jb25zdCBCUk9XU0VSX01PRFVMRV9QUk9WSURFUlMgPSBbe1xuICBwcm92aWRlOiBfSU5KRUNUT1JfU0NPUEUsXG4gIHVzZVZhbHVlOiAncm9vdCdcbn0sIHtcbiAgcHJvdmlkZTogRXJyb3JIYW5kbGVyLFxuICB1c2VGYWN0b3J5OiBlcnJvckhhbmRsZXJcbn0sIHtcbiAgcHJvdmlkZTogRVZFTlRfTUFOQUdFUl9QTFVHSU5TLFxuICB1c2VDbGFzczogRG9tRXZlbnRzUGx1Z2luLFxuICBtdWx0aTogdHJ1ZVxufSwge1xuICBwcm92aWRlOiBFVkVOVF9NQU5BR0VSX1BMVUdJTlMsXG4gIHVzZUNsYXNzOiBLZXlFdmVudHNQbHVnaW4sXG4gIG11bHRpOiB0cnVlXG59LCBEb21SZW5kZXJlckZhY3RvcnkyLCB7XG4gIHByb3ZpZGU6IF9TSEFSRURfU1RZTEVTX0hPU1QsXG4gIHVzZUNsYXNzOiBTaGFyZWRTdHlsZXNIb3N0XG59LCB7XG4gIHByb3ZpZGU6IFNoYXJlZFN0eWxlc0hvc3QsXG4gIHVzZUV4aXN0aW5nOiBfU0hBUkVEX1NUWUxFU19IT1NUXG59LCBFdmVudE1hbmFnZXIsIHtcbiAgcHJvdmlkZTogUmVuZGVyZXJGYWN0b3J5MixcbiAgdXNlRXhpc3Rpbmc6IERvbVJlbmRlcmVyRmFjdG9yeTJcbn0sIHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IHtcbiAgcHJvdmlkZTogQlJPV1NFUl9NT0RVTEVfUFJPVklERVJTX01BUktFUixcbiAgdXNlVmFsdWU6IHRydWVcbn0gOiBbXV07XG5jbGFzcyBCcm93c2VyTW9kdWxlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgY29uc3QgcHJvdmlkZXJzQWxyZWFkeVByZXNlbnQgPSBpbmplY3QoQlJPV1NFUl9NT0RVTEVfUFJPVklERVJTX01BUktFUiwge1xuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICAgICAgc2tpcFNlbGY6IHRydWVcbiAgICAgIH0pO1xuICAgICAgaWYgKHByb3ZpZGVyc0FscmVhZHlQcmVzZW50KSB7XG4gICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDUxMDAsIGBQcm92aWRlcnMgZnJvbSB0aGUgXFxgQnJvd3Nlck1vZHVsZVxcYCBoYXZlIGFscmVhZHkgYmVlbiBsb2FkZWQuIElmIHlvdSBuZWVkIGFjY2VzcyBgICsgYHRvIGNvbW1vbiBkaXJlY3RpdmVzIHN1Y2ggYXMgTmdJZiBhbmQgTmdGb3IsIGltcG9ydCB0aGUgXFxgQ29tbW9uTW9kdWxlXFxgIGluc3RlYWQuYCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEJyb3dzZXJNb2R1bGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEJyb3dzZXJNb2R1bGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtW1vZCA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVOZ01vZHVsZSh7XG4gICAgdHlwZTogQnJvd3Nlck1vZHVsZSxcbiAgICBleHBvcnRzOiBbQ29tbW9uTW9kdWxlLCBBcHBsaWNhdGlvbk1vZHVsZV1cbiAgfSk7XG4gIHN0YXRpYyDJtWluaiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3Rvcih7XG4gICAgcHJvdmlkZXJzOiBbLi4uQlJPV1NFUl9NT0RVTEVfUFJPVklERVJTLCAuLi5URVNUQUJJTElUWV9QUk9WSURFUlNdLFxuICAgIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEFwcGxpY2F0aW9uTW9kdWxlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEJyb3dzZXJNb2R1bGUsIFt7XG4gICAgdHlwZTogTmdNb2R1bGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVyczogWy4uLkJST1dTRVJfTU9EVUxFX1BST1ZJREVSUywgLi4uVEVTVEFCSUxJVFlfUFJPVklERVJTXSxcbiAgICAgIGV4cG9ydHM6IFtDb21tb25Nb2R1bGUsIEFwcGxpY2F0aW9uTW9kdWxlXVxuICAgIH1dXG4gIH1dLCAoKSA9PiBbXSwgbnVsbCk7XG59KSgpO1xuZXhwb3J0IHsgQnJvd3NlckRvbUFkYXB0ZXIsIEJyb3dzZXJHZXRUZXN0YWJpbGl0eSwgQnJvd3Nlck1vZHVsZSwgS2V5RXZlbnRzUGx1Z2luLCBib290c3RyYXBBcHBsaWNhdGlvbiwgY3JlYXRlQXBwbGljYXRpb24sIHBsYXRmb3JtQnJvd3NlciwgcHJvdmlkZVByb3RyYWN0b3JUZXN0aW5nU3VwcG9ydCB9O1xuIiwiLyoqXG4gKiBAbGljZW5zZSBBbmd1bGFyIHYyMi4xLjJcbiAqIChjKSAyMDEwLTIwMjYgR29vZ2xlIExMQy4gaHR0cHM6Ly9hbmd1bGFyLmRldi9cbiAqIExpY2Vuc2U6IE1JVFxuICovXG5cbmV4cG9ydCB7IEJyb3dzZXJNb2R1bGUsIGJvb3RzdHJhcEFwcGxpY2F0aW9uLCBjcmVhdGVBcHBsaWNhdGlvbiwgcGxhdGZvcm1Ccm93c2VyLCBwcm92aWRlUHJvdHJhY3RvclRlc3RpbmdTdXBwb3J0LCBCcm93c2VyRG9tQWRhcHRlciBhcyDJtUJyb3dzZXJEb21BZGFwdGVyLCBCcm93c2VyR2V0VGVzdGFiaWxpdHkgYXMgybVCcm93c2VyR2V0VGVzdGFiaWxpdHksIEtleUV2ZW50c1BsdWdpbiBhcyDJtUtleUV2ZW50c1BsdWdpbiB9IGZyb20gJy4vX2Jyb3dzZXItY2h1bmsubWpzJztcbmltcG9ydCB7IERPQ1VNRU5ULCDJtWdldERPTSBhcyBfZ2V0RE9NIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmV4cG9ydCB7IMm1Z2V0RE9NIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCAqIGFzIGkwIGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgaW5qZWN0LCBTZXJ2aWNlLCBJbmplY3QsIEluamVjdGFibGUsIMm1Z2xvYmFsIGFzIF9nbG9iYWwsIEFwcGxpY2F0aW9uUmVmLCDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCBtYWtlRW52aXJvbm1lbnRQcm92aWRlcnMsIMm1Q0FDSEVfQUNUSVZFIGFzIF9DQUNIRV9BQ1RJVkUsIEFQUF9CT09UU1RSQVBfTElTVEVORVIsIHByb3ZpZGVTdGFiaWxpdHlEZWJ1Z2dpbmcsIMm1d2l0aERvbUh5ZHJhdGlvbiBhcyBfd2l0aERvbUh5ZHJhdGlvbiwgybV3aXRoSW5jcmVtZW50YWxIeWRyYXRpb24gYXMgX3dpdGhJbmNyZW1lbnRhbEh5ZHJhdGlvbiwgybV3aXRoRXZlbnRSZXBsYXkgYXMgX3dpdGhFdmVudFJlcGxheSwgybV3aXRoSTE4blN1cHBvcnQgYXMgX3dpdGhJMThuU3VwcG9ydCwgRU5WSVJPTk1FTlRfSU5JVElBTElaRVIsIMm1SVNfRU5BQkxFRF9CTE9DS0lOR19JTklUSUFMX05BVklHQVRJT04gYXMgX0lTX0VOQUJMRURfQkxPQ0tJTkdfSU5JVElBTF9OQVZJR0FUSU9OLCDJtUNvbnNvbGUgYXMgX0NvbnNvbGUsIMm1Zm9ybWF0UnVudGltZUVycm9yIGFzIF9mb3JtYXRSdW50aW1lRXJyb3IsIMm1WFNTX1NFQ1VSSVRZX1VSTCBhcyBfWFNTX1NFQ1VSSVRZX1VSTCwgU2VjdXJpdHlDb250ZXh0LCDJtWFsbG93U2FuaXRpemF0aW9uQnlwYXNzQW5kVGhyb3cgYXMgX2FsbG93U2FuaXRpemF0aW9uQnlwYXNzQW5kVGhyb3csIMm1dW53cmFwU2FmZVZhbHVlIGFzIF91bndyYXBTYWZlVmFsdWUsIMm1X3Nhbml0aXplVXJsIGFzIF9fc2FuaXRpemVVcmwsIMm1X3Nhbml0aXplSHRtbCBhcyBfX3Nhbml0aXplSHRtbCwgybVieXBhc3NTYW5pdGl6YXRpb25UcnVzdEh0bWwgYXMgX2J5cGFzc1Nhbml0aXphdGlvblRydXN0SHRtbCwgybVieXBhc3NTYW5pdGl6YXRpb25UcnVzdFN0eWxlIGFzIF9ieXBhc3NTYW5pdGl6YXRpb25UcnVzdFN0eWxlLCDJtWJ5cGFzc1Nhbml0aXphdGlvblRydXN0U2NyaXB0IGFzIF9ieXBhc3NTYW5pdGl6YXRpb25UcnVzdFNjcmlwdCwgybVieXBhc3NTYW5pdGl6YXRpb25UcnVzdFVybCBhcyBfYnlwYXNzU2FuaXRpemF0aW9uVHJ1c3RVcmwsIMm1YnlwYXNzU2FuaXRpemF0aW9uVHJ1c3RSZXNvdXJjZVVybCBhcyBfYnlwYXNzU2FuaXRpemF0aW9uVHJ1c3RSZXNvdXJjZVVybCwgZm9yd2FyZFJlZiwgVmVyc2lvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ1NTX1ZBUl9OQU1FU1BBQ0UgfSBmcm9tICcuL19kb21fcmVuZGVyZXItY2h1bmsubWpzJztcbmV4cG9ydCB7IEVWRU5UX01BTkFHRVJfUExVR0lOUywgRXZlbnRNYW5hZ2VyLCBFdmVudE1hbmFnZXJQbHVnaW4sIFJFTU9WRV9TVFlMRVNfT05fQ09NUE9ORU5UX0RFU1RST1ksIHByb3ZpZGVDc3NWYXJOYW1lc3BhY2luZywgRG9tRXZlbnRzUGx1Z2luIGFzIMm1RG9tRXZlbnRzUGx1Z2luLCBEb21SZW5kZXJlckZhY3RvcnkyIGFzIMm1RG9tUmVuZGVyZXJGYWN0b3J5MiwgU2hhcmVkU3R5bGVzSG9zdCBhcyDJtVNoYXJlZFN0eWxlc0hvc3QgfSBmcm9tICcuL19kb21fcmVuZGVyZXItY2h1bmsubWpzJztcbmltcG9ydCB7IMm1d2l0aEh0dHBUcmFuc2ZlckNhY2hlIGFzIF93aXRoSHR0cFRyYW5zZmVyQ2FjaGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5jbGFzcyBNZXRhIHtcbiAgX2RvYyA9IGluamVjdChET0NVTUVOVCk7XG4gIF9kb20gPSBfZ2V0RE9NKCk7XG4gIF9jYWNoZWRIZWFkO1xuICBhZGRUYWcodGFnLCBmb3JjZUNyZWF0aW9uID0gZmFsc2UpIHtcbiAgICBpZiAoIXRhZykgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHRoaXMuX2dldE9yQ3JlYXRlRWxlbWVudCh0YWcsIGZvcmNlQ3JlYXRpb24pO1xuICB9XG4gIGFkZFRhZ3ModGFncywgZm9yY2VDcmVhdGlvbiA9IGZhbHNlKSB7XG4gICAgcmV0dXJuIHRhZ3MuZmlsdGVyKHRhZyA9PiAhIXRhZykubWFwKHRhZyA9PiB0aGlzLl9nZXRPckNyZWF0ZUVsZW1lbnQodGFnLCBmb3JjZUNyZWF0aW9uKSk7XG4gIH1cbiAgZ2V0VGFnKGF0dHJTZWxlY3Rvcikge1xuICAgIGlmICghYXR0clNlbGVjdG9yKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBtZXRhID0gdGhpcy5fZG9jLnF1ZXJ5U2VsZWN0b3IoYnVpbGRNZXRhU2VsZWN0b3IoYXR0clNlbGVjdG9yKSk7XG4gICAgcmV0dXJuIGlzTWV0YVRhZyhtZXRhKSA/IG1ldGEgOiBudWxsO1xuICB9XG4gIGdldFRhZ3MoYXR0clNlbGVjdG9yKSB7XG4gICAgaWYgKCFhdHRyU2VsZWN0b3IpIHJldHVybiBbXTtcbiAgICBjb25zdCBsaXN0ID0gdGhpcy5fZG9jLnF1ZXJ5U2VsZWN0b3JBbGwoYnVpbGRNZXRhU2VsZWN0b3IoYXR0clNlbGVjdG9yKSk7XG4gICAgcmV0dXJuIGxpc3QgPyBBcnJheS5mcm9tKGxpc3QpLmZpbHRlcihlbGVtID0+IGlzTWV0YVRhZyhlbGVtKSkgOiBbXTtcbiAgfVxuICB1cGRhdGVUYWcodGFnLCBzZWxlY3Rvcikge1xuICAgIHNlbGVjdG9yID8/PSBwYXJzZVNlbGVjdG9yKHRhZyk7XG4gICAgY29uc3QgbWV0YSA9IHRoaXMuZ2V0VGFnKHNlbGVjdG9yKTtcbiAgICBpZiAobWV0YSkge1xuICAgICAgc2V0TWV0YUVsZW1lbnRBdHRyaWJ1dGVzKHRhZywgbWV0YSk7XG4gICAgICByZXR1cm4gbWV0YTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2dldE9yQ3JlYXRlRWxlbWVudCh0YWcsIHRydWUpO1xuICB9XG4gIHJlbW92ZVRhZyhhdHRyU2VsZWN0b3IpIHtcbiAgICB0aGlzLnJlbW92ZVRhZ0VsZW1lbnQodGhpcy5nZXRUYWcoYXR0clNlbGVjdG9yKSk7XG4gIH1cbiAgcmVtb3ZlVGFnRWxlbWVudChtZXRhKSB7XG4gICAgaWYgKG1ldGEpIHtcbiAgICAgIHRoaXMuX2RvbS5yZW1vdmUobWV0YSk7XG4gICAgfVxuICB9XG4gIF9nZXRPckNyZWF0ZUVsZW1lbnQobWV0YSwgZm9yY2VDcmVhdGlvbiA9IGZhbHNlKSB7XG4gICAgaWYgKCFmb3JjZUNyZWF0aW9uKSB7XG4gICAgICBjb25zdCBzZWxlY3RvciA9IHBhcnNlU2VsZWN0b3IobWV0YSk7XG4gICAgICBjb25zdCBlbGVtID0gdGhpcy5nZXRUYWdzKHNlbGVjdG9yKS5maWx0ZXIoZWxlbSA9PiBjb250YWluc0F0dHJpYnV0ZXMobWV0YSwgZWxlbSkpWzBdO1xuICAgICAgaWYgKGVsZW0gIT09IHVuZGVmaW5lZCkgcmV0dXJuIGVsZW07XG4gICAgfVxuICAgIGNvbnN0IGVsZW1lbnQgPSB0aGlzLl9kb20uY3JlYXRlRWxlbWVudCgnbWV0YScpO1xuICAgIHNldE1ldGFFbGVtZW50QXR0cmlidXRlcyhtZXRhLCBlbGVtZW50KTtcbiAgICBjb25zdCBoZWFkID0gdGhpcy5fZG9jLmdldEVsZW1lbnRzQnlUYWdOYW1lKCdoZWFkJylbMF07XG4gICAgaGVhZC5hcHBlbmRDaGlsZChlbGVtZW50KTtcbiAgICByZXR1cm4gZWxlbWVudDtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBNZXRhX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBNZXRhKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBNZXRhLFxuICAgIGZhY3Rvcnk6IE1ldGEuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShNZXRhLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIGJ1aWxkTWV0YVNlbGVjdG9yKGF0dHJTZWxlY3Rvcikge1xuICByZXR1cm4gYG1ldGFbJHthdHRyU2VsZWN0b3J9XWA7XG59XG5mdW5jdGlvbiBzZXRNZXRhRWxlbWVudEF0dHJpYnV0ZXModGFnLCBlbCkge1xuICBPYmplY3Qua2V5cyh0YWcpLmZvckVhY2gocHJvcCA9PiBlbC5zZXRBdHRyaWJ1dGUoZ2V0TWV0YUtleU1hcChwcm9wKSwgdGFnW3Byb3BdKSk7XG59XG5mdW5jdGlvbiBwYXJzZVNlbGVjdG9yKHRhZykge1xuICBjb25zdCBhdHRyID0gdGFnLm5hbWUgPyAnbmFtZScgOiAncHJvcGVydHknO1xuICByZXR1cm4gYCR7YXR0cn09JHtlc2NhcGVTZWxlY3RvclZhbHVlKFN0cmluZyh0YWdbYXR0cl0pKX1gO1xufVxuZnVuY3Rpb24gZXNjYXBlU2VsZWN0b3JWYWx1ZSh2YWx1ZSkge1xuICByZXR1cm4gYFwiJHt2YWx1ZS5yZXBsYWNlKC9cXFxcL2csICdcXFxcXFxcXCcpLnJlcGxhY2UoL1wiL2csICdcXFxcXCInKX1cImA7XG59XG5mdW5jdGlvbiBjb250YWluc0F0dHJpYnV0ZXModGFnLCBlbGVtKSB7XG4gIHJldHVybiBPYmplY3Qua2V5cyh0YWcpLmV2ZXJ5KGtleSA9PiBlbGVtLmdldEF0dHJpYnV0ZShnZXRNZXRhS2V5TWFwKGtleSkpID09PSB0YWdba2V5XSk7XG59XG5mdW5jdGlvbiBnZXRNZXRhS2V5TWFwKHByb3ApIHtcbiAgcmV0dXJuIE1FVEFfS0VZU19NQVBbcHJvcF0gfHwgcHJvcDtcbn1cbmZ1bmN0aW9uIGlzTWV0YVRhZyh0YWcpIHtcbiAgcmV0dXJuIHRhZz8ubm9kZU5hbWUudG9Mb3dlckNhc2UoKSA9PT0gJ21ldGEnO1xufVxuY29uc3QgTUVUQV9LRVlTX01BUCA9IHtcbiAgaHR0cEVxdWl2OiAnaHR0cC1lcXVpdidcbn07XG5jbGFzcyBUaXRsZSB7XG4gIF9kb2M7XG4gIGNvbnN0cnVjdG9yKF9kb2MpIHtcbiAgICB0aGlzLl9kb2MgPSBfZG9jO1xuICB9XG4gIGdldFRpdGxlKCkge1xuICAgIHJldHVybiB0aGlzLl9kb2MudGl0bGU7XG4gIH1cbiAgc2V0VGl0bGUobmV3VGl0bGUpIHtcbiAgICB0aGlzLl9kb2MudGl0bGUgPSBuZXdUaXRsZSB8fCAnJztcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBUaXRsZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFRpdGxlKShpMC7Jtcm1aW5qZWN0KERPQ1VNRU5UKSk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0YWJsZSh7XG4gICAgdG9rZW46IFRpdGxlLFxuICAgIGZhY3Rvcnk6IFRpdGxlLsm1ZmFjLFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFRpdGxlLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGUsXG4gICAgYXJnczogW3tcbiAgICAgIHByb3ZpZGVkSW46ICdyb290J1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICBkZWNvcmF0b3JzOiBbe1xuICAgICAgdHlwZTogSW5qZWN0LFxuICAgICAgYXJnczogW0RPQ1VNRU5UXVxuICAgIH1dXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBleHBvcnROZ1ZhcihuYW1lLCB2YWx1ZSkge1xuICBpZiAodHlwZW9mIENPTVBJTEVEID09PSAndW5kZWZpbmVkJyB8fCAhQ09NUElMRUQpIHtcbiAgICBjb25zdCBuZyA9IF9nbG9iYWxbJ25nJ10gPSBfZ2xvYmFsWyduZyddIHx8IHt9O1xuICAgIG5nW25hbWVdID0gdmFsdWU7XG4gIH1cbn1cbmNsYXNzIENoYW5nZURldGVjdGlvblBlcmZSZWNvcmQge1xuICBtc1BlclRpY2s7XG4gIG51bVRpY2tzO1xuICBjb25zdHJ1Y3Rvcihtc1BlclRpY2ssIG51bVRpY2tzKSB7XG4gICAgdGhpcy5tc1BlclRpY2sgPSBtc1BlclRpY2s7XG4gICAgdGhpcy5udW1UaWNrcyA9IG51bVRpY2tzO1xuICB9XG59XG5jbGFzcyBBbmd1bGFyUHJvZmlsZXIge1xuICBhcHBSZWY7XG4gIGNvbnN0cnVjdG9yKHJlZikge1xuICAgIHRoaXMuYXBwUmVmID0gcmVmLmluamVjdG9yLmdldChBcHBsaWNhdGlvblJlZik7XG4gIH1cbiAgdGltZUNoYW5nZURldGVjdGlvbihjb25maWcpIHtcbiAgICBjb25zdCByZWNvcmQgPSBjb25maWcgJiYgY29uZmlnWydyZWNvcmQnXTtcbiAgICBjb25zdCBwcm9maWxlTmFtZSA9ICdDaGFuZ2UgRGV0ZWN0aW9uJztcbiAgICBpZiAocmVjb3JkICYmICdwcm9maWxlJyBpbiBjb25zb2xlICYmIHR5cGVvZiBjb25zb2xlLnByb2ZpbGUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNvbnNvbGUucHJvZmlsZShwcm9maWxlTmFtZSk7XG4gICAgfVxuICAgIGNvbnN0IHN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgbGV0IG51bVRpY2tzID0gMDtcbiAgICB3aGlsZSAobnVtVGlja3MgPCA1IHx8IHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhcnQgPCA1MDApIHtcbiAgICAgIHRoaXMuYXBwUmVmLnRpY2soKTtcbiAgICAgIG51bVRpY2tzKys7XG4gICAgfVxuICAgIGNvbnN0IGVuZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgIGlmIChyZWNvcmQgJiYgJ3Byb2ZpbGVFbmQnIGluIGNvbnNvbGUgJiYgdHlwZW9mIGNvbnNvbGUucHJvZmlsZUVuZCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY29uc29sZS5wcm9maWxlRW5kKHByb2ZpbGVOYW1lKTtcbiAgICB9XG4gICAgY29uc3QgbXNQZXJUaWNrID0gKGVuZCAtIHN0YXJ0KSAvIG51bVRpY2tzO1xuICAgIGNvbnNvbGUubG9nKGByYW4gJHtudW1UaWNrc30gY2hhbmdlIGRldGVjdGlvbiBjeWNsZXNgKTtcbiAgICBjb25zb2xlLmxvZyhgJHttc1BlclRpY2sudG9GaXhlZCgyKX0gbXMgcGVyIGNoZWNrYCk7XG4gICAgcmV0dXJuIG5ldyBDaGFuZ2VEZXRlY3Rpb25QZXJmUmVjb3JkKG1zUGVyVGljaywgbnVtVGlja3MpO1xuICB9XG59XG5jb25zdCBQUk9GSUxFUl9HTE9CQUxfTkFNRSA9ICdwcm9maWxlcic7XG5mdW5jdGlvbiBlbmFibGVEZWJ1Z1Rvb2xzKHJlZikge1xuICBleHBvcnROZ1ZhcihQUk9GSUxFUl9HTE9CQUxfTkFNRSwgbmV3IEFuZ3VsYXJQcm9maWxlcihyZWYpKTtcbiAgcmV0dXJuIHJlZjtcbn1cbmZ1bmN0aW9uIGRpc2FibGVEZWJ1Z1Rvb2xzKCkge1xuICBleHBvcnROZ1ZhcihQUk9GSUxFUl9HTE9CQUxfTkFNRSwgbnVsbCk7XG59XG5jbGFzcyBCeSB7XG4gIHN0YXRpYyBhbGwoKSB7XG4gICAgcmV0dXJuICgpID0+IHRydWU7XG4gIH1cbiAgc3RhdGljIGNzcyhzZWxlY3Rvcikge1xuICAgIHJldHVybiBkZWJ1Z0VsZW1lbnQgPT4ge1xuICAgICAgcmV0dXJuIGRlYnVnRWxlbWVudC5uYXRpdmVFbGVtZW50ICE9IG51bGwgPyBlbGVtZW50TWF0Y2hlcyhkZWJ1Z0VsZW1lbnQubmF0aXZlRWxlbWVudCwgc2VsZWN0b3IpIDogZmFsc2U7XG4gICAgfTtcbiAgfVxuICBzdGF0aWMgZGlyZWN0aXZlKHR5cGUpIHtcbiAgICByZXR1cm4gZGVidWdOb2RlID0+IGRlYnVnTm9kZS5wcm92aWRlclRva2Vucy5pbmRleE9mKHR5cGUpICE9PSAtMTtcbiAgfVxufVxuZnVuY3Rpb24gZWxlbWVudE1hdGNoZXMobiwgc2VsZWN0b3IpIHtcbiAgaWYgKF9nZXRET00oKS5pc0VsZW1lbnROb2RlKG4pKSB7XG4gICAgcmV0dXJuIG4ubWF0Y2hlcyAmJiBuLm1hdGNoZXMoc2VsZWN0b3IpIHx8IG4ubXNNYXRjaGVzU2VsZWN0b3IgJiYgbi5tc01hdGNoZXNTZWxlY3RvcihzZWxlY3RvcikgfHwgbi53ZWJraXRNYXRjaGVzU2VsZWN0b3IgJiYgbi53ZWJraXRNYXRjaGVzU2VsZWN0b3Ioc2VsZWN0b3IpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmNsYXNzIENzc1Zhck5hbWVzcGFjZXIge1xuICBuYW1lc3BhY2VQcmVmaXggPSBpbmplY3QoQ1NTX1ZBUl9OQU1FU1BBQ0UsIHtcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9KSA/PyAnJztcbiAgbmFtZXNwYWNlKG5hbWUpIHtcbiAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgICBpZiAoIW5hbWUuc3RhcnRzV2l0aCgnLS0nKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENTUyB2YXJpYWJsZSBuYW1lcyBwYXNzZWQgdG8gXFxgQ3NzVmFyTmFtZXNwYWNlclxcYCBtdXN0IHN0YXJ0IHdpdGggJy0tJywgZ290OiAnJHtuYW1lfSdgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCF0aGlzLm5hbWVzcGFjZVByZWZpeCkgcmV0dXJuIG5hbWU7XG4gICAgcmV0dXJuIGAtLSR7dGhpcy5uYW1lc3BhY2VQcmVmaXh9JHtuYW1lLnN1YnN0cmluZygnLS0nLmxlbmd0aCl9YDtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBDc3NWYXJOYW1lc3BhY2VyX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBDc3NWYXJOYW1lc3BhY2VyKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBDc3NWYXJOYW1lc3BhY2VyLFxuICAgIGZhY3Rvcnk6IENzc1Zhck5hbWVzcGFjZXIuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShDc3NWYXJOYW1lc3BhY2VyLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbnZhciBIeWRyYXRpb25GZWF0dXJlS2luZDtcbihmdW5jdGlvbiAoSHlkcmF0aW9uRmVhdHVyZUtpbmQpIHtcbiAgSHlkcmF0aW9uRmVhdHVyZUtpbmRbSHlkcmF0aW9uRmVhdHVyZUtpbmRbXCJOb0h0dHBUcmFuc2ZlckNhY2hlXCJdID0gMF0gPSBcIk5vSHR0cFRyYW5zZmVyQ2FjaGVcIjtcbiAgSHlkcmF0aW9uRmVhdHVyZUtpbmRbSHlkcmF0aW9uRmVhdHVyZUtpbmRbXCJIdHRwVHJhbnNmZXJDYWNoZU9wdGlvbnNcIl0gPSAxXSA9IFwiSHR0cFRyYW5zZmVyQ2FjaGVPcHRpb25zXCI7XG4gIEh5ZHJhdGlvbkZlYXR1cmVLaW5kW0h5ZHJhdGlvbkZlYXR1cmVLaW5kW1wiSTE4blN1cHBvcnRcIl0gPSAyXSA9IFwiSTE4blN1cHBvcnRcIjtcbiAgSHlkcmF0aW9uRmVhdHVyZUtpbmRbSHlkcmF0aW9uRmVhdHVyZUtpbmRbXCJFdmVudFJlcGxheVwiXSA9IDNdID0gXCJFdmVudFJlcGxheVwiO1xuICBIeWRyYXRpb25GZWF0dXJlS2luZFtIeWRyYXRpb25GZWF0dXJlS2luZFtcIkluY3JlbWVudGFsSHlkcmF0aW9uXCJdID0gNF0gPSBcIkluY3JlbWVudGFsSHlkcmF0aW9uXCI7XG4gIEh5ZHJhdGlvbkZlYXR1cmVLaW5kW0h5ZHJhdGlvbkZlYXR1cmVLaW5kW1wiTm9JbmNyZW1lbnRhbEh5ZHJhdGlvblwiXSA9IDVdID0gXCJOb0luY3JlbWVudGFsSHlkcmF0aW9uXCI7XG59KShIeWRyYXRpb25GZWF0dXJlS2luZCB8fCAoSHlkcmF0aW9uRmVhdHVyZUtpbmQgPSB7fSkpO1xuZnVuY3Rpb24gaHlkcmF0aW9uRmVhdHVyZSjJtWtpbmQsIMm1cHJvdmlkZXJzID0gW10sIMm1b3B0aW9ucyA9IHt9KSB7XG4gIHJldHVybiB7XG4gICAgybVraW5kLFxuICAgIMm1cHJvdmlkZXJzXG4gIH07XG59XG5mdW5jdGlvbiB3aXRoTm9IdHRwVHJhbnNmZXJDYWNoZSgpIHtcbiAgcmV0dXJuIGh5ZHJhdGlvbkZlYXR1cmUoSHlkcmF0aW9uRmVhdHVyZUtpbmQuTm9IdHRwVHJhbnNmZXJDYWNoZSk7XG59XG5mdW5jdGlvbiB3aXRoSHR0cFRyYW5zZmVyQ2FjaGVPcHRpb25zKG9wdGlvbnMpIHtcbiAgcmV0dXJuIGh5ZHJhdGlvbkZlYXR1cmUoSHlkcmF0aW9uRmVhdHVyZUtpbmQuSHR0cFRyYW5zZmVyQ2FjaGVPcHRpb25zLCBfd2l0aEh0dHBUcmFuc2ZlckNhY2hlKG9wdGlvbnMpKTtcbn1cbmZ1bmN0aW9uIHdpdGhJMThuU3VwcG9ydCgpIHtcbiAgcmV0dXJuIGh5ZHJhdGlvbkZlYXR1cmUoSHlkcmF0aW9uRmVhdHVyZUtpbmQuSTE4blN1cHBvcnQsIF93aXRoSTE4blN1cHBvcnQoKSk7XG59XG5mdW5jdGlvbiB3aXRoRXZlbnRSZXBsYXkoKSB7XG4gIHJldHVybiBoeWRyYXRpb25GZWF0dXJlKEh5ZHJhdGlvbkZlYXR1cmVLaW5kLkV2ZW50UmVwbGF5LCBfd2l0aEV2ZW50UmVwbGF5KCkpO1xufVxuZnVuY3Rpb24gd2l0aEluY3JlbWVudGFsSHlkcmF0aW9uKCkge1xuICByZXR1cm4gaHlkcmF0aW9uRmVhdHVyZShIeWRyYXRpb25GZWF0dXJlS2luZC5JbmNyZW1lbnRhbEh5ZHJhdGlvbiwgX3dpdGhJbmNyZW1lbnRhbEh5ZHJhdGlvbigpKTtcbn1cbmZ1bmN0aW9uIHdpdGhOb0luY3JlbWVudGFsSHlkcmF0aW9uKCkge1xuICByZXR1cm4gaHlkcmF0aW9uRmVhdHVyZShIeWRyYXRpb25GZWF0dXJlS2luZC5Ob0luY3JlbWVudGFsSHlkcmF0aW9uKTtcbn1cbmZ1bmN0aW9uIHByb3ZpZGVFbmFibGVkQmxvY2tpbmdJbml0aWFsTmF2aWdhdGlvbkRldGVjdG9yKCkge1xuICByZXR1cm4gW3tcbiAgICBwcm92aWRlOiBFTlZJUk9OTUVOVF9JTklUSUFMSVpFUixcbiAgICB1c2VWYWx1ZTogKCkgPT4ge1xuICAgICAgY29uc3QgaXNFbmFibGVkQmxvY2tpbmdJbml0aWFsTmF2aWdhdGlvbiA9IGluamVjdChfSVNfRU5BQkxFRF9CTE9DS0lOR19JTklUSUFMX05BVklHQVRJT04sIHtcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICAgIH0pO1xuICAgICAgaWYgKGlzRW5hYmxlZEJsb2NraW5nSW5pdGlhbE5hdmlnYXRpb24pIHtcbiAgICAgICAgY29uc3QgY29uc29sZSA9IGluamVjdChfQ29uc29sZSk7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBfZm9ybWF0UnVudGltZUVycm9yKDUwMDEsICdDb25maWd1cmF0aW9uIGVycm9yOiBmb3VuZCBib3RoIGh5ZHJhdGlvbiBhbmQgZW5hYmxlZEJsb2NraW5nIGluaXRpYWwgbmF2aWdhdGlvbiAnICsgJ2luIHRoZSBzYW1lIGFwcGxpY2F0aW9uLCB3aGljaCBpcyBhIGNvbnRyYWRpY3Rpb24uJyk7XG4gICAgICAgIGNvbnNvbGUud2FybihtZXNzYWdlKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG11bHRpOiB0cnVlXG4gIH1dO1xufVxuZnVuY3Rpb24gcHJvdmlkZUNsaWVudEh5ZHJhdGlvbiguLi5mZWF0dXJlcykge1xuICBjb25zdCBwcm92aWRlcnMgPSBbXTtcbiAgY29uc3QgZmVhdHVyZXNLaW5kID0gbmV3IFNldCgpO1xuICBmb3IgKGNvbnN0IHtcbiAgICDJtXByb3ZpZGVycyxcbiAgICDJtWtpbmRcbiAgfSBvZiBmZWF0dXJlcykge1xuICAgIGZlYXR1cmVzS2luZC5hZGQoybVraW5kKTtcbiAgICBpZiAoybVwcm92aWRlcnMubGVuZ3RoKSB7XG4gICAgICBwcm92aWRlcnMucHVzaCjJtXByb3ZpZGVycyk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGhhc0h0dHBUcmFuc2ZlckNhY2hlT3B0aW9ucyA9IGZlYXR1cmVzS2luZC5oYXMoSHlkcmF0aW9uRmVhdHVyZUtpbmQuSHR0cFRyYW5zZmVyQ2FjaGVPcHRpb25zKTtcbiAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSkge1xuICAgIGlmIChmZWF0dXJlc0tpbmQuaGFzKEh5ZHJhdGlvbkZlYXR1cmVLaW5kLk5vSHR0cFRyYW5zZmVyQ2FjaGUpICYmIGhhc0h0dHBUcmFuc2ZlckNhY2hlT3B0aW9ucykge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNTAwMSwgJ0NvbmZpZ3VyYXRpb24gZXJyb3I6IGZvdW5kIGJvdGggd2l0aEh0dHBUcmFuc2ZlckNhY2hlT3B0aW9ucygpIGFuZCB3aXRoTm9IdHRwVHJhbnNmZXJDYWNoZSgpIGluIHRoZSBzYW1lIGNhbGwgdG8gcHJvdmlkZUNsaWVudEh5ZHJhdGlvbigpLCB3aGljaCBpcyBhIGNvbnRyYWRpY3Rpb24uJyk7XG4gICAgfVxuICAgIGlmIChmZWF0dXJlc0tpbmQuaGFzKEh5ZHJhdGlvbkZlYXR1cmVLaW5kLkluY3JlbWVudGFsSHlkcmF0aW9uKSAmJiBmZWF0dXJlc0tpbmQuaGFzKEh5ZHJhdGlvbkZlYXR1cmVLaW5kLk5vSW5jcmVtZW50YWxIeWRyYXRpb24pKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig1MDAxLCAnQ29uZmlndXJhdGlvbiBlcnJvcjogZm91bmQgYm90aCB3aXRoSW5jcmVtZW50YWxIeWRyYXRpb24oKSBhbmQgd2l0aE5vSW5jcmVtZW50YWxIeWRyYXRpb24oKSBpbiB0aGUgc2FtZSBjYWxsIHRvIHByb3ZpZGVDbGllbnRIeWRyYXRpb24oKSwgd2hpY2ggaXMgYSBjb250cmFkaWN0aW9uLicpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbWFrZUVudmlyb25tZW50UHJvdmlkZXJzKFt0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyBwcm92aWRlRW5hYmxlZEJsb2NraW5nSW5pdGlhbE5hdmlnYXRpb25EZXRlY3RvcigpIDogW10sIHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/IHByb3ZpZGVTdGFiaWxpdHlEZWJ1Z2dpbmcoKSA6IFtdLCBfd2l0aERvbUh5ZHJhdGlvbigpLCBmZWF0dXJlc0tpbmQuaGFzKEh5ZHJhdGlvbkZlYXR1cmVLaW5kLk5vSHR0cFRyYW5zZmVyQ2FjaGUpIHx8IGhhc0h0dHBUcmFuc2ZlckNhY2hlT3B0aW9ucyA/IFtdIDogX3dpdGhIdHRwVHJhbnNmZXJDYWNoZSh7fSksIGZlYXR1cmVzS2luZC5oYXMoSHlkcmF0aW9uRmVhdHVyZUtpbmQuTm9JbmNyZW1lbnRhbEh5ZHJhdGlvbikgPyBbXSA6IF93aXRoSW5jcmVtZW50YWxIeWRyYXRpb24oKSwgcHJvdmlkZXJzLCB7XG4gICAgcHJvdmlkZTogX0NBQ0hFX0FDVElWRSxcbiAgICB1c2VWYWx1ZToge1xuICAgICAgaXNBY3RpdmU6IHRydWVcbiAgICB9XG4gIH0sIHtcbiAgICBwcm92aWRlOiBBUFBfQk9PVFNUUkFQX0xJU1RFTkVSLFxuICAgIG11bHRpOiB0cnVlLFxuICAgIHVzZUZhY3Rvcnk6ICgpID0+IHtcbiAgICAgIGNvbnN0IGFwcFJlZiA9IGluamVjdChBcHBsaWNhdGlvblJlZik7XG4gICAgICBjb25zdCBjYWNoZVN0YXRlID0gaW5qZWN0KF9DQUNIRV9BQ1RJVkUpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgYXBwUmVmLndoZW5TdGFibGUoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICBjYWNoZVN0YXRlLmlzQWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9XG4gIH1dKTtcbn1cbmNsYXNzIERvbVNhbml0aXplciB7XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIERvbVNhbml0aXplcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRG9tU2FuaXRpemVyKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBEb21TYW5pdGl6ZXIsXG4gICAgZmFjdG9yeTogZnVuY3Rpb24gRG9tU2FuaXRpemVyX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAgIGxldCBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X18gPSBudWxsO1xuICAgICAgaWYgKF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgICAgIF9fbmdDb25kaXRpb25hbEZhY3RvcnlfXyA9IG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRG9tU2FuaXRpemVyKSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLyogQHRzLWlnbm9yZSAqL1xuICAgICAgICBfX25nQ29uZGl0aW9uYWxGYWN0b3J5X18gPSBpMC7Jtcm1aW5qZWN0KERvbVNhbml0aXplckltcGwpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIF9fbmdDb25kaXRpb25hbEZhY3RvcnlfXztcbiAgICB9LFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKERvbVNhbml0aXplciwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlZEluOiAncm9vdCcsXG4gICAgICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBEb21TYW5pdGl6ZXJJbXBsKVxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBEb21TYW5pdGl6ZXJJbXBsIGV4dGVuZHMgRG9tU2FuaXRpemVyIHtcbiAgX2RvYyA9IGluamVjdChET0NVTUVOVCk7XG4gIHNhbml0aXplKGN0eCwgdmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gICAgc3dpdGNoIChjdHgpIHtcbiAgICAgIGNhc2UgU2VjdXJpdHlDb250ZXh0Lk5PTkU6XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIGNhc2UgU2VjdXJpdHlDb250ZXh0LkhUTUw6XG4gICAgICAgIGlmIChfYWxsb3dTYW5pdGl6YXRpb25CeXBhc3NBbmRUaHJvdyh2YWx1ZSwgXCJIVE1MXCIpKSB7XG4gICAgICAgICAgcmV0dXJuIF91bndyYXBTYWZlVmFsdWUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfX3Nhbml0aXplSHRtbCh0aGlzLl9kb2MsIFN0cmluZyh2YWx1ZSkpLnRvU3RyaW5nKCk7XG4gICAgICBjYXNlIFNlY3VyaXR5Q29udGV4dC5TVFlMRTpcbiAgICAgICAgaWYgKF9hbGxvd1Nhbml0aXphdGlvbkJ5cGFzc0FuZFRocm93KHZhbHVlLCBcIlN0eWxlXCIpKSB7XG4gICAgICAgICAgcmV0dXJuIF91bndyYXBTYWZlVmFsdWUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIGNhc2UgU2VjdXJpdHlDb250ZXh0LlNDUklQVDpcbiAgICAgICAgaWYgKF9hbGxvd1Nhbml0aXphdGlvbkJ5cGFzc0FuZFRocm93KHZhbHVlLCBcIlNjcmlwdFwiKSkge1xuICAgICAgICAgIHJldHVybiBfdW53cmFwU2FmZVZhbHVlKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig1MjAwLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiAndW5zYWZlIHZhbHVlIHVzZWQgaW4gYSBzY3JpcHQgY29udGV4dCcpO1xuICAgICAgY2FzZSBTZWN1cml0eUNvbnRleHQuVVJMOlxuICAgICAgICBpZiAoX2FsbG93U2FuaXRpemF0aW9uQnlwYXNzQW5kVGhyb3codmFsdWUsIFwiVVJMXCIpKSB7XG4gICAgICAgICAgcmV0dXJuIF91bndyYXBTYWZlVmFsdWUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfX3Nhbml0aXplVXJsKFN0cmluZyh2YWx1ZSkpO1xuICAgICAgY2FzZSBTZWN1cml0eUNvbnRleHQuUkVTT1VSQ0VfVVJMOlxuICAgICAgICBpZiAoX2FsbG93U2FuaXRpemF0aW9uQnlwYXNzQW5kVGhyb3codmFsdWUsIFwiUmVzb3VyY2VVUkxcIikpIHtcbiAgICAgICAgICByZXR1cm4gX3Vud3JhcFNhZmVWYWx1ZSh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoLTUyMDEsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGB1bnNhZmUgdmFsdWUgdXNlZCBpbiBhIHJlc291cmNlIFVSTCBjb250ZXh0IChzZWUgJHtfWFNTX1NFQ1VSSVRZX1VSTH0pYCk7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig1MjAyLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBgVW5leHBlY3RlZCBTZWN1cml0eUNvbnRleHQgJHtjdHh9IChzZWUgJHtfWFNTX1NFQ1VSSVRZX1VSTH0pYCk7XG4gICAgfVxuICB9XG4gIGJ5cGFzc1NlY3VyaXR5VHJ1c3RIdG1sKHZhbHVlKSB7XG4gICAgcmV0dXJuIF9ieXBhc3NTYW5pdGl6YXRpb25UcnVzdEh0bWwodmFsdWUpO1xuICB9XG4gIGJ5cGFzc1NlY3VyaXR5VHJ1c3RTdHlsZSh2YWx1ZSkge1xuICAgIHJldHVybiBfYnlwYXNzU2FuaXRpemF0aW9uVHJ1c3RTdHlsZSh2YWx1ZSk7XG4gIH1cbiAgYnlwYXNzU2VjdXJpdHlUcnVzdFNjcmlwdCh2YWx1ZSkge1xuICAgIHJldHVybiBfYnlwYXNzU2FuaXRpemF0aW9uVHJ1c3RTY3JpcHQodmFsdWUpO1xuICB9XG4gIGJ5cGFzc1NlY3VyaXR5VHJ1c3RVcmwodmFsdWUpIHtcbiAgICByZXR1cm4gX2J5cGFzc1Nhbml0aXphdGlvblRydXN0VXJsKHZhbHVlKTtcbiAgfVxuICBieXBhc3NTZWN1cml0eVRydXN0UmVzb3VyY2VVcmwodmFsdWUpIHtcbiAgICByZXR1cm4gX2J5cGFzc1Nhbml0aXphdGlvblRydXN0UmVzb3VyY2VVcmwodmFsdWUpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIERvbVNhbml0aXplckltcGxfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IERvbVNhbml0aXplckltcGwpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lU2VydmljZSh7XG4gICAgdG9rZW46IERvbVNhbml0aXplckltcGwsXG4gICAgZmFjdG9yeTogRG9tU2FuaXRpemVySW1wbC7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKERvbVNhbml0aXplckltcGwsIFt7XG4gICAgdHlwZTogU2VydmljZVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY29uc3QgVkVSU0lPTiA9IC8qIEBfX1BVUkVfXyAqL25ldyBWZXJzaW9uKCcyMi4xLjInKTtcbmV4cG9ydCB7IEJ5LCBDc3NWYXJOYW1lc3BhY2VyLCBEb21TYW5pdGl6ZXIsIEh5ZHJhdGlvbkZlYXR1cmVLaW5kLCBNZXRhLCBUaXRsZSwgVkVSU0lPTiwgZGlzYWJsZURlYnVnVG9vbHMsIGVuYWJsZURlYnVnVG9vbHMsIHByb3ZpZGVDbGllbnRIeWRyYXRpb24sIHdpdGhFdmVudFJlcGxheSwgd2l0aEh0dHBUcmFuc2ZlckNhY2hlT3B0aW9ucywgd2l0aEkxOG5TdXBwb3J0LCB3aXRoSW5jcmVtZW50YWxIeWRyYXRpb24sIHdpdGhOb0h0dHBUcmFuc2ZlckNhY2hlLCB3aXRoTm9JbmNyZW1lbnRhbEh5ZHJhdGlvbiwgRG9tU2FuaXRpemVySW1wbCBhcyDJtURvbVNhbml0aXplckltcGwgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBsYXRmb3JtLWJyb3dzZXIubWpzLm1hcCJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFTQSxJQUFNLHFCQUFOLE1BQXlCO0NBRXZCLFlBQVksTUFBTTt3QkFEbEIsUUFBQSxLQUFBLENBQUE7d0JBSUEsV0FBQSxLQUFBLENBQUE7RUFGRSxLQUFLLE9BQU87Q0FDZDtBQUVGO0FBQ0EsSUFBTSxrQkFBTixjQUE4QixtQkFBbUI7Q0FDL0MsWUFBWSxLQUFLO0VBQ2YsTUFBTSxHQUFHO0NBQ1g7Q0FDQSxTQUFTLFdBQVc7RUFDbEIsT0FBTztDQUNUO0NBQ0EsaUJBQWlCLFNBQVMsV0FBVyxTQUFTLFNBQVM7RUFDckQsUUFBUSxpQkFBaUIsV0FBVyxTQUFTLE9BQU87RUFDcEQsYUFBYSxLQUFLLG9CQUFvQixTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQzVFO0NBQ0Esb0JBQW9CLFFBQVEsV0FBVyxVQUFVLFNBQVM7RUFDeEQsT0FBTyxPQUFPLG9CQUFvQixXQUFXLFVBQVUsT0FBTztDQUNoRTtBQVNGOztpQ0FSUyxRQUFPLFNBQVMsd0JBQXdCLG1CQUFtQjtDQUVoRSxPQUFPLEtBQUsscUJBQXFCQSxrQkFBaUJDLFNBQVksUUFBUSxDQUFDO0FBQ3pFLENBQUE7aUNBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9EO0NBQ1AsU0FBU0EsaUJBQWdCO0FBQzNCLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjRSxpQkFBcUIsaUJBQWlCLENBQUMsRUFDeEYsTUFBTSxXQUNSLENBQUMsU0FBUyxDQUFDO0VBQ1QsTUFBTSxLQUFBO0VBQ04sWUFBWSxDQUFDO0dBQ1gsTUFBTTtHQUNOLE1BQU0sQ0FBQyxRQUFRO0VBQ2pCLENBQUM7Q0FDSCxDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sd0JBQXdCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHdCQUF3QixFQUFFO0FBQzNILElBQU0sZUFBTixNQUFtQjtDQUlqQixZQUFZLFNBQVMsT0FBTzt3QkFINUIsU0FBQSxLQUFBLENBQUE7d0JBQ0EsWUFBQSxLQUFBLENBQUE7d0JBQ0Esc0NBQXFCLElBQUksSUFBSSxDQUFBO0VBRTNCLEtBQUssUUFBUTtFQUNiLFFBQVEsU0FBUSxXQUFVO0dBQ3hCLE9BQU8sVUFBVTtFQUNuQixDQUFDO0VBQ0QsTUFBTSxlQUFlLFFBQVEsUUFBTyxNQUFLLEVBQUUsYUFBYSxnQkFBZ0I7RUFDeEUsS0FBSyxXQUFXLGFBQWEsTUFBTSxDQUFDLENBQUMsUUFBUTtFQUM3QyxNQUFNLGlCQUFpQixRQUFRLE1BQUssTUFBSyxhQUFhLGVBQWU7RUFDckUsSUFBSSxnQkFDRixLQUFLLFNBQVMsS0FBSyxjQUFjO0NBRXJDO0NBQ0EsaUJBQWlCLFNBQVMsV0FBVyxTQUFTLFNBQVM7RUFFckQsT0FEZSxLQUFLLGVBQWUsU0FDdkIsQ0FBQyxDQUFDLGlCQUFpQixTQUFTLFdBQVcsU0FBUyxPQUFPO0NBQ3JFO0NBQ0EsVUFBVTtFQUNSLE9BQU8sS0FBSztDQUNkO0NBQ0EsZUFBZSxXQUFXO0VBQ3hCLElBQUksU0FBUyxLQUFLLG1CQUFtQixJQUFJLFNBQVM7RUFDbEQsSUFBSSxRQUNGLE9BQU87RUFHVCxTQURnQixLQUFLLFNBQ0osTUFBSyxXQUFVLE9BQU8sU0FBUyxTQUFTLENBQUM7RUFDMUQsSUFBSSxDQUFDLFFBQ0gsTUFBTSxJQUFJQyxhQUFjLFFBQVEsT0FBTyxjQUFjLGVBQWUsY0FBYywyQ0FBMkMsV0FBVztFQUUxSSxLQUFLLG1CQUFtQixJQUFJLFdBQVcsTUFBTTtFQUM3QyxPQUFPO0NBQ1Q7QUFTRjs7OEJBUlMsUUFBTyxTQUFTLHFCQUFxQixtQkFBbUI7Q0FFN0QsT0FBTyxLQUFLLHFCQUFxQkMsZUFBY0gsU0FBWSxxQkFBcUIsR0FBR0EsU0FBWUksTUFBUyxDQUFDO0FBQzNHLENBQUE7OEJBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9EO0NBQ1AsU0FBU0EsY0FBYTtBQUN4QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0YsaUJBQXFCLGNBQWMsQ0FBQyxFQUNyRixNQUFNLFdBQ1IsQ0FBQyxTQUFTLENBQUM7RUFDVCxNQUFNLEtBQUE7RUFDTixZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLHFCQUFxQjtFQUM5QixDQUFDO0NBQ0gsR0FBRyxFQUNELE1BQU1HLE9BQ1IsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLHdCQUF3QjtBQUM5QixTQUFTLGVBQWUsVUFBVTtDQUNoQyxLQUFLLE1BQU0sV0FBVyxVQUNwQixRQUFRLE9BQU87QUFFbkI7QUFDQSxTQUFTLG1CQUFtQixPQUFPLEtBQUs7Q0FDdEMsTUFBTSxlQUFlLElBQUksY0FBYyxPQUFPO0NBQzlDLGFBQWEsY0FBYztDQUMzQixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixLQUFLLE9BQU8sUUFBUSxVQUFVOztDQUNyRCxNQUFNLFlBQUEsWUFBVyxJQUFJLFVBQUEsUUFBQSxjQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsVUFBTSxpQkFBaUIsU0FBUyxzQkFBc0IsSUFBSSxNQUFNLFVBQVUsc0JBQXNCLElBQUksTUFBTSxHQUFHO0NBQ2xJLElBQUksQ0FBQyxZQUFZLFNBQVMsV0FBVyxHQUFHLE9BQU87Q0FDL0MsS0FBSyxNQUFNLGdCQUFnQixVQUFVO0VBQ25DLGFBQWEsZ0JBQWdCLHFCQUFxQjtFQUNsRCxJQUFJLHdCQUF3QixpQkFDMUIsU0FBUyxJQUFJLGFBQWEsS0FBSyxNQUFNLGFBQWEsS0FBSyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUc7R0FDNUUsT0FBTztHQUNQLFVBQVUsQ0FBQyxZQUFZO0VBQ3pCLENBQUM7T0FDSSxJQUFJLGFBQWEsYUFDdEIsT0FBTyxJQUFJLGFBQWEsYUFBYTtHQUNuQyxPQUFPO0dBQ1AsVUFBVSxDQUFDLFlBQVk7RUFDekIsQ0FBQztDQUVMO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsS0FBSyxLQUFLO0NBQ25DLE1BQU0sY0FBYyxJQUFJLGNBQWMsTUFBTTtDQUM1QyxZQUFZLGFBQWEsT0FBTyxZQUFZO0NBQzVDLFlBQVksYUFBYSxRQUFRLEdBQUc7Q0FDcEMsT0FBTztBQUNUO0FBQ0EsSUFBTSxtQkFBTixNQUF1QjtDQU9yQixZQUFZLEtBQUssT0FBTyxPQUFPLGFBQWEsQ0FBQyxHQUFHO3dCQU5oRCxPQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSwwQkFBUyxJQUFJLElBQUksQ0FBQTt3QkFDakIsNEJBQVcsSUFBSSxJQUFJLENBQUE7d0JBQ25CLHlCQUFRLElBQUksSUFBSSxDQUFBO0VBRWQsS0FBSyxNQUFNO0VBQ1gsS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBRWIsSUFEYyxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLFFBQ3BELEdBQUcsS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJO0NBQ3BDO0NBQ0EsVUFBVSxRQUFRLE1BQU07RUFDdEIsS0FBSyxNQUFNLFNBQVMsUUFDbEIsS0FBSyxTQUFTLE9BQU8sS0FBSyxRQUFRLGtCQUFrQjtFQUV0RCxTQUFBLFFBQUEsU0FBQSxLQUFBLEtBQUEsS0FBTSxTQUFRLFVBQVMsS0FBSyxTQUFTLE9BQU8sS0FBSyxVQUFVLGlCQUFpQixDQUFDO0NBQy9FO0NBQ0EsYUFBYSxRQUFRLE1BQU07RUFDekIsS0FBSyxNQUFNLFNBQVMsUUFDbEIsS0FBSyxZQUFZLE9BQU8sS0FBSyxNQUFNO0VBRXJDLFNBQUEsUUFBQSxTQUFBLEtBQUEsS0FBQSxLQUFNLFNBQVEsVUFBUyxLQUFLLFlBQVksT0FBTyxLQUFLLFFBQVEsQ0FBQztDQUMvRDtDQUNBLFNBQVMsT0FBTyxRQUFRLFNBQVM7RUFDL0IsTUFBTSxTQUFTLE9BQU8sSUFBSSxLQUFLO0VBQy9CLElBQUksUUFBUTtHQUNWLEtBQUssT0FBTyxjQUFjLGVBQWUsY0FBYyxPQUFPLFVBQVUsR0FDdEUsT0FBTyxTQUFTLFNBQVEsWUFBVyxRQUFRLGFBQWEsbUJBQW1CLEVBQUUsQ0FBQztHQUVoRixPQUFPO0VBQ1QsT0FDRSxPQUFPLElBQUksT0FBTztHQUNoQixPQUFPO0dBQ1AsVUFBVSxDQUFDLEdBQUcsS0FBSyxLQUFLLENBQUMsQ0FBQyxLQUFJLFNBQVEsS0FBSyxXQUFXLE1BQU0sUUFBUSxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUM7RUFDdkYsQ0FBQztDQUVMO0NBQ0EsWUFBWSxPQUFPLFFBQVE7RUFDekIsTUFBTSxTQUFTLE9BQU8sSUFBSSxLQUFLO0VBQy9CLElBQUksUUFBUTtHQUNWLE9BQU87R0FDUCxJQUFJLE9BQU8sU0FBUyxHQUFHO0lBQ3JCLGVBQWUsT0FBTyxRQUFRO0lBQzlCLE9BQU8sT0FBTyxLQUFLO0dBQ3JCO0VBQ0Y7Q0FDRjtDQUNBLGNBQWM7RUFDWixLQUFLLE1BQU0sR0FBRyxFQUNaLGVBQ0ksQ0FBQyxHQUFHLEtBQUssUUFBUSxHQUFHLEtBQUssUUFBUSxHQUNyQyxlQUFlLFFBQVE7RUFFekIsS0FBSyxNQUFNLE1BQU07Q0FDbkI7Q0FDQSxRQUFRLFVBQVU7RUFDaEIsSUFBSSxLQUFLLE1BQU0sSUFBSSxRQUFRLEdBQUc7RUFDOUIsS0FBSyxNQUFNLElBQUksUUFBUTtFQUN2QixLQUFLLE1BQU0sQ0FBQyxPQUFPLEVBQ2pCLGVBQ0ksS0FBSyxRQUNULFNBQVMsS0FBSyxLQUFLLFdBQVcsVUFBVSxtQkFBbUIsT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0VBRTlFLEtBQUssTUFBTSxDQUFDLEtBQUssRUFDZixlQUNJLEtBQUssVUFDVCxTQUFTLEtBQUssS0FBSyxXQUFXLFVBQVUsa0JBQWtCLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQztDQUU3RTtDQUNBLFdBQVcsVUFBVTtFQUNuQixLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQzFCLEtBQUssTUFBTSxVQUFVLENBQUMsR0FBRyxLQUFLLE9BQU8sT0FBTyxHQUFHLEdBQUcsS0FBSyxTQUFTLE9BQU8sQ0FBQyxHQUFHO0dBQ3pFLE1BQU0sWUFBWSxDQUFDO0dBQ25CLEtBQUssTUFBTSxXQUFXLE9BQU8sVUFDM0IsSUFBSSxRQUFRLGVBQWUsVUFDekIsUUFBUSxPQUFPO1FBRWYsVUFBVSxLQUFLLE9BQU87R0FHMUIsT0FBTyxXQUFXO0VBQ3BCO0NBQ0Y7Q0FDQSxXQUFXLE1BQU0sU0FBUztFQUN4QixJQUFJLEtBQUssT0FDUCxRQUFRLGFBQWEsU0FBUyxLQUFLLEtBQUs7RUFLMUMsT0FBTyxLQUFLLFlBQVksT0FBTztDQUNqQztBQVNGOztrQ0FSUyxRQUFPLFNBQVMseUJBQXlCLG1CQUFtQjtDQUVqRSxPQUFPLEtBQUsscUJBQXFCQyxtQkFBa0JMLFNBQVksUUFBUSxHQUFHQSxTQUFZLE1BQU0sR0FBR0EsU0FBWSxXQUFXLENBQUMsR0FBR0EsU0FBWSxXQUFXLENBQUM7QUFDcEosQ0FBQTtrQ0FDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0s7Q0FDUCxTQUFTQSxrQkFBaUI7QUFDNUIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNKLGlCQUFxQixrQkFBa0IsQ0FBQyxFQUN6RixNQUFNLFdBQ1IsQ0FBQyxTQUFTO0VBQUM7R0FDVCxNQUFNO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyxRQUFRO0dBQ2pCLENBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyxNQUFNO0dBQ2YsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZLENBQUM7SUFDWCxNQUFNO0lBQ04sTUFBTSxDQUFDLFNBQVM7R0FDbEIsR0FBRyxFQUNELE1BQU0sU0FDUixDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVksQ0FBQztJQUNYLE1BQU07SUFDTixNQUFNLENBQUMsV0FBVztHQUNwQixDQUFDO0VBQ0g7Q0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLGlCQUFpQjtDQUNyQixPQUFPO0NBQ1AsU0FBUztDQUNULFNBQVM7Q0FDVCxPQUFPO0NBQ1AsU0FBUztDQUNULFFBQVE7QUFDVjtBQUNBLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sdUJBQXVCO0FBQzdCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0scUJBQXFCO0FBQzNCLElBQU0sWUFBWSxXQUFXO0FBQzdCLElBQU0sZUFBZSxjQUFjO0FBQ25DLElBQU0sNkNBQTZDO0FBQ25ELElBQU0scUNBQXFDLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLDhCQUE4QixJQUFJLEVBQzlJLGVBQWUsMkNBQ2pCLENBQUM7QUFDRCxJQUFNLG9CQUFvQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxzQkFBc0IsRUFBRTtBQUNySCxTQUFTLHlCQUF5QixXQUFXO0NBQzNDLE9BQU8seUJBQXlCLENBQUM7RUFDL0IsU0FBUztFQUNULGFBQVksVUFBUyxHQUFHLGNBQUEsUUFBQSxjQUFBLEtBQUEsSUFBQSxZQUFhLE1BQU07RUFDM0MsTUFBTSxDQUFDLE1BQU07Q0FDZixDQUFDLENBQUM7QUFDSjtBQUNBLFNBQVMscUJBQXFCLGtCQUFrQjtDQUM5QyxPQUFPLGFBQWEsUUFBUSxpQkFBaUIsZ0JBQWdCO0FBQy9EO0FBQ0EsU0FBUyxrQkFBa0Isa0JBQWtCO0NBQzNDLE9BQU8sVUFBVSxRQUFRLGlCQUFpQixnQkFBZ0I7QUFDNUQ7QUFDQSxTQUFTLGtCQUFrQixRQUFRLFFBQVE7Q0FDekMsT0FBTyxPQUFPLEtBQUksTUFBSyxFQUFFLFFBQVEsaUJBQWlCLE1BQU0sQ0FBQztBQUMzRDtBQUNBLFNBQVMsMEJBQTBCLFVBQVUsUUFBUTtDQUNuRCxJQUFJLENBQUMsVUFDSCxPQUFPO0NBRVQsTUFBTSxzQkFBc0IsSUFBSSxJQUFJLFVBQVUsa0JBQWtCO0NBQ2hFLE9BQU8sT0FBTyxLQUFJLGVBQWM7RUFDOUIsSUFBSSxDQUFDLFdBQVcsU0FBUyxtQkFBbUIsR0FDMUMsT0FBTztFQUVULE9BQU8sV0FBVyxRQUFRLHVCQUF1QixHQUFHLGlCQUFpQjtHQUNuRSxJQUFJLGFBQWEsT0FBTyxPQUFPLGFBQWEsV0FBVyxPQUFPLEtBQUssZ0JBQWdCLEtBQUssWUFBWSxHQUNsRyxPQUFPLHdCQUF3QixhQUFhO0dBRTlDLE1BQU0sRUFDSixVQUFVLHlCQUNSLElBQUksSUFBSSxjQUFjLG1CQUFtQjtHQUM3QyxPQUFPLHdCQUF3QixxQkFBcUI7RUFDdEQsQ0FBQztDQUNILENBQUM7QUFDSDtBQUNBLElBQU0sc0JBQU4sTUFBMEI7Q0FZeEIsWUFBWSxjQUFjLGtCQUFrQixPQUFPLDJCQUEyQixLQUFLLFFBQVEsUUFBUSxNQUFNLGlCQUFpQixNQUFNLGtCQUFrQixNQUFNO3dCQVh4SixnQkFBQSxLQUFBLENBQUE7d0JBQ0Esb0JBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLDZCQUFBLEtBQUEsQ0FBQTt3QkFDQSxPQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBQSxLQUFBLENBQUE7d0JBQ0Esb0NBQW1CLElBQUksSUFBSSxDQUFBO3dCQUMzQixtQkFBQSxLQUFBLENBQUE7d0JBQ0EsbUJBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxlQUFlO0VBQ3BCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssUUFBUTtFQUNiLEtBQUssNEJBQTRCO0VBQ2pDLEtBQUssTUFBTTtFQUNYLEtBQUssU0FBUztFQUNkLEtBQUssUUFBUTtFQUNiLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssa0JBQWtCLG9CQUFBLFFBQUEsb0JBQUEsS0FBQSxJQUFBLGtCQUFtQjtFQUMxQyxLQUFLLGtCQUFrQixJQUFJLG9CQUFvQixjQUFjLEtBQUssUUFBUSxLQUFLLGdCQUFnQixLQUFLLGVBQWU7Q0FDckg7Q0FDQSxlQUFlLFNBQVMsTUFBTTtFQUM1QixJQUFJLENBQUMsV0FBVyxDQUFDLE1BQ2YsT0FBTyxLQUFLO0VBUWQsTUFBTSxXQUFXLEtBQUssb0JBQW9CLFNBQVMsSUFBSTtFQUN2RCxJQUFJLG9CQUFvQixtQ0FDdEIsU0FBUyxZQUFZLE9BQU87T0FDdkIsSUFBSSxvQkFBb0IsOEJBQzdCLFNBQVMsWUFBWTtFQUV2QixPQUFPO0NBQ1Q7Q0FDQSxvQkFBb0IsU0FBUyxNQUFNO0VBQ2pDLE1BQU0sbUJBQW1CLEtBQUs7RUFDOUIsSUFBSSxXQUFXLGlCQUFpQixJQUFJLEtBQUssRUFBRTtFQUMzQyxJQUFJLENBQUMsVUFBVTtHQUNiLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLE1BQU0sU0FBUyxLQUFLO0dBQ3BCLE1BQU0sZUFBZSxLQUFLO0dBQzFCLE1BQU0sbUJBQW1CLEtBQUs7R0FDOUIsTUFBTSw0QkFBNEIsS0FBSztHQUN2QyxNQUFNLGlCQUFpQixLQUFLO0dBQzVCLFFBQVEsS0FBSyxlQUFiO0lBQ0UsS0FBSyxrQkFBa0I7S0FDckIsV0FBVyxJQUFJLGtDQUFrQyxjQUFjLGtCQUFrQixNQUFNLEtBQUssT0FBTywyQkFBMkIsS0FBSyxRQUFRLGdCQUFnQixLQUFLLGVBQWU7S0FDL0s7SUFDRixLQUFLLGtCQUFrQixXQUNyQixPQUFPLElBQUksa0JBQWtCLGNBQWMsU0FBUyxNQUFNLEtBQUssUUFBUSxLQUFLLE9BQU8sZ0JBQWdCLEtBQUssaUJBQWlCLGdCQUFnQjtJQUMzSSxLQUFLLGtCQUFrQiwrQkFDckIsT0FBTyxJQUFJLGtCQUFrQixjQUFjLFNBQVMsTUFBTSxLQUFLLFFBQVEsS0FBSyxPQUFPLGdCQUFnQixLQUFLLGVBQWU7SUFDekg7S0FDRSxXQUFXLElBQUksNkJBQTZCLGNBQWMsa0JBQWtCLE1BQU0sMkJBQTJCLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxlQUFlO0tBQzlKO0dBQ0o7R0FDQSxpQkFBaUIsSUFBSSxLQUFLLElBQUksUUFBUTtFQUN4QztFQUNBLE9BQU87Q0FDVDtDQUNBLGNBQWM7RUFDWixLQUFLLGlCQUFpQixNQUFNO0NBQzlCO0NBQ0Esa0JBQWtCLGFBQWE7RUFDN0IsS0FBSyxpQkFBaUIsT0FBTyxXQUFXO0NBQzFDO0FBU0Y7O3FDQVJTLFFBQU8sU0FBUyw0QkFBNEIsbUJBQW1CO0NBRXBFLE9BQU8sS0FBSyxxQkFBcUJLLHFCQUFxQk4sU0FBWSxZQUFZLEdBQUdBLFNBQVlPLGtCQUFtQixHQUFHUCxTQUFZLE1BQU0sR0FBR0EsU0FBWSxrQ0FBa0MsR0FBR0EsU0FBWSxRQUFRLEdBQUdBLFNBQVlJLE1BQVMsR0FBR0osU0FBWSxTQUFTLEdBQUdBLFNBQVlRLGdCQUFpQixDQUFDLEdBQUdSLFNBQVksbUJBQW1CLENBQUMsQ0FBQztBQUNwVSxDQUFBO3FDQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPTTtDQUNQLFNBQVNBLG9CQUFvQjtBQUMvQixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0wsaUJBQXFCLHFCQUFxQixDQUFDLEVBQzVGLE1BQU0sV0FDUixDQUFDLFNBQVM7RUFBQyxFQUNULE1BQU0sYUFDUjtFQUFHO0dBQ0QsTUFBTTtHQUNOLFlBQVksQ0FBQztJQUNYLE1BQU07SUFDTixNQUFNLENBQUNNLGtCQUFtQjtHQUM1QixDQUFDO0VBQ0g7RUFBRztHQUNELE1BQU0sS0FBQTtHQUNOLFlBQVksQ0FBQztJQUNYLE1BQU07SUFDTixNQUFNLENBQUMsTUFBTTtHQUNmLENBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyxrQ0FBa0M7R0FDM0MsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyxRQUFRO0dBQ2pCLENBQUM7RUFDSDtFQUFHLEVBQ0QsTUFBTUgsT0FDUjtFQUFHO0dBQ0QsTUFBTSxLQUFBO0dBQ04sWUFBWSxDQUFDO0lBQ1gsTUFBTTtJQUNOLE1BQU0sQ0FBQyxTQUFTO0dBQ2xCLENBQUM7RUFDSDtFQUFHO0dBQ0QsTUFBTUs7R0FDTixZQUFZLENBQUM7SUFDWCxNQUFNO0lBQ04sTUFBTSxDQUFDRCxjQUFlO0dBQ3hCLEdBQUcsRUFDRCxNQUFNLFNBQ1IsQ0FBQztFQUNIO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZLENBQUM7SUFDWCxNQUFNO0lBQ04sTUFBTSxDQUFDLGlCQUFpQjtHQUMxQixHQUFHLEVBQ0QsTUFBTSxTQUNSLENBQUM7RUFDSDtDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sc0JBQU4sTUFBMEI7Q0FReEIsWUFBWSxjQUFjLEtBQUssUUFBUSxnQkFBZ0Isa0JBQWtCLElBQUk7d0JBUDdFLGdCQUFBLEtBQUEsQ0FBQTt3QkFDQSxPQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBQSxLQUFBLENBQUE7d0JBQ0EsbUJBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQU8sT0FBTyxPQUFPLElBQUksQ0FBQTt3QkFDekIseUJBQXdCLElBQUE7d0JBU3hCLGVBQWMsSUFBQTtFQVBaLEtBQUssZUFBZTtFQUNwQixLQUFLLE1BQU07RUFDWCxLQUFLLFNBQVM7RUFDZCxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGtCQUFrQjtDQUN6QjtDQUNBLFVBQVUsQ0FBQztDQUVYLGNBQWMsTUFBTSxXQUFXO0VBQzdCLElBQUksV0FDRixPQUFPLEtBQUssSUFBSSxnQkFBZ0IsZUFBZSxjQUFjLFdBQVcsSUFBSTtFQUU5RSxPQUFPLEtBQUssSUFBSSxjQUFjLElBQUk7Q0FDcEM7Q0FDQSxjQUFjLE9BQU87RUFDbkIsT0FBTyxLQUFLLElBQUksY0FBYyxLQUFLO0NBQ3JDO0NBQ0EsV0FBVyxPQUFPO0VBQ2hCLE9BQU8sS0FBSyxJQUFJLGVBQWUsS0FBSztDQUN0QztDQUNBLFlBQVksUUFBUSxVQUFVO0VBRTVCLENBRHFCLGVBQWUsTUFBTSxJQUFJLE9BQU8sVUFBVSxPQUFBLENBQ2xELFlBQVksUUFBUTtDQUNuQztDQUNBLGFBQWEsUUFBUSxVQUFVLFVBQVU7RUFDdkMsSUFBSSxRQUVGLENBRHFCLGVBQWUsTUFBTSxJQUFJLE9BQU8sVUFBVSxPQUFBLENBQ2xELGFBQWEsVUFBVSxRQUFRO0NBRWhEO0NBQ0EsWUFBWSxTQUFTLFVBQVU7RUFDN0IsU0FBUyxPQUFPO0NBQ2xCO0NBQ0Esa0JBQWtCLGdCQUFnQixpQkFBaUI7RUFDakQsSUFBSSxLQUFLLE9BQU8sbUJBQW1CLFdBQVcsS0FBSyxJQUFJLGNBQWMsY0FBYyxJQUFJO0VBQ3ZGLElBQUksQ0FBQyxJQUNILE1BQU0sSUFBSU4sYUFBYyxRQUFRLE9BQU8sY0FBYyxlQUFlLGNBQWMsaUJBQWlCLGVBQWUsNkJBQTZCO0VBRWpKLElBQUksQ0FBQyxpQkFDSCxHQUFHLGNBQWM7RUFFbkIsT0FBTztDQUNUO0NBQ0EsV0FBVyxNQUFNO0VBQ2YsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxZQUFZLE1BQU07RUFDaEIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxhQUFhLElBQUksTUFBTSxPQUFPLFdBQVc7RUFDdkMsSUFBSSxXQUFXO0dBQ2IsT0FBTyxZQUFZLE1BQU07R0FDekIsTUFBTSxlQUFlLGVBQWU7R0FDcEMsSUFBSSxjQUNGLEdBQUcsZUFBZSxjQUFjLE1BQU0sS0FBSztRQUUzQyxHQUFHLGFBQWEsTUFBTSxLQUFLO0VBRS9CLE9BQ0UsR0FBRyxhQUFhLE1BQU0sS0FBSztDQUUvQjtDQUNBLGdCQUFnQixJQUFJLE1BQU0sV0FBVztFQUNuQyxJQUFJLFdBQVc7R0FDYixNQUFNLGVBQWUsZUFBZTtHQUNwQyxJQUFJLGNBQ0YsR0FBRyxrQkFBa0IsY0FBYyxJQUFJO1FBRXZDLEdBQUcsZ0JBQWdCLEdBQUcsVUFBVSxHQUFHLE1BQU07RUFFN0MsT0FDRSxHQUFHLGdCQUFnQixJQUFJO0NBRTNCO0NBQ0EsU0FBUyxJQUFJLE1BQU07RUFDakIsR0FBRyxVQUFVLElBQUksSUFBSTtDQUN2QjtDQUNBLFlBQVksSUFBSSxNQUFNO0VBQ3BCLEdBQUcsVUFBVSxPQUFPLElBQUk7Q0FDMUI7Q0FDQSxTQUFTLElBQUksT0FBTyxPQUFPLE9BQU87RUFDaEMsTUFBTSxhQUFhLE1BQU0sV0FBVyxJQUFJO0VBQ3hDLElBQUksWUFDRixRQUFRLE1BQU0sUUFBUSxRQUFRLEtBQUssZUFBZTtFQUVwRCxJQUFJLGNBQWMsU0FBUyxvQkFBb0IsV0FBVyxvQkFBb0IsWUFDNUUsR0FBRyxNQUFNLFlBQVksT0FBTyxPQUFPLFFBQVEsb0JBQW9CLFlBQVksY0FBYyxFQUFFO09BRTNGLEdBQUcsTUFBTSxTQUFTO0NBRXRCO0NBQ0EsWUFBWSxJQUFJLE9BQU8sT0FBTztFQUM1QixNQUFNLGFBQWEsTUFBTSxXQUFXLElBQUk7RUFDeEMsSUFBSSxZQUNGLFFBQVEsTUFBTSxRQUFRLFFBQVEsS0FBSyxlQUFlO0VBRXBELElBQUksY0FBYyxRQUFRLG9CQUFvQixVQUM1QyxHQUFHLE1BQU0sZUFBZSxLQUFLO09BRTdCLEdBQUcsTUFBTSxTQUFTO0NBRXRCO0NBQ0EsWUFBWSxJQUFJLE1BQU0sT0FBTztFQUMzQixJQUFJLE1BQU0sTUFDUjtFQUVGLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYyxLQUFLLHlCQUF5QixxQkFBcUIsTUFBTSxVQUFVO0VBQ3RILEdBQUcsUUFBUTtDQUNiO0NBQ0EsU0FBUyxNQUFNLE9BQU87RUFDcEIsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsT0FBTyxRQUFRLE9BQU8sVUFBVSxTQUFTOztFQUN2QyxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWMsS0FBSyx5QkFBeUIscUJBQXFCLE9BQU8sVUFBVTtFQUN2SCxJQUFJLE9BQU8sV0FBVyxVQUFVO0dBQzlCLFNBQVNRLE9BQVEsQ0FBQyxDQUFDLHFCQUFxQixLQUFLLEtBQUssTUFBTTtHQUN4RCxJQUFJLENBQUMsUUFDSCxNQUFNLElBQUlSLGFBQWMsUUFBUSxPQUFPLGNBQWMsZUFBZSxjQUFjLDRCQUE0QixPQUFPLGFBQWEsT0FBTztFQUU3STtFQUNBLElBQUksa0JBQWtCLEtBQUssdUJBQXVCLFFBQVE7RUFDMUQsS0FBQSx1QkFBSSxLQUFLLG9CQUFBLFFBQUEseUJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxxQkFBZ0IsbUJBQ3ZCLGtCQUFrQixLQUFLLGVBQWUsa0JBQWtCLFFBQVEsT0FBTyxlQUFlO0VBRXhGLE9BQU8sS0FBSyxhQUFhLGlCQUFpQixRQUFRLE9BQU8saUJBQWlCLE9BQU87Q0FDbkY7Q0FDQSx1QkFBdUIsY0FBYztFQUNuQyxRQUFPLFVBQVM7R0FDZCxJQUFJLFVBQVUsZ0JBQ1osT0FBTztHQUdULElBRHVJLGFBQWEsS0FDN0gsTUFBTSxPQUMzQixNQUFNLGVBQWU7RUFHekI7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxxQkFBcUIsSUFBSSxXQUFXLENBQUMsRUFBQSxDQUFHO0FBQzlDLFNBQVMscUJBQXFCLE1BQU0sVUFBVTtDQUM1QyxJQUFJLEtBQUssV0FBVyxDQUFDLE1BQU0sYUFDekIsTUFBTSxJQUFJQSxhQUFjLE1BQU0sd0JBQXdCLFNBQVMsR0FBRyxLQUFLOzsrREFFWixLQUFLLGdJQUFnSTtBQUVwTTtBQUNBLFNBQVMsZUFBZSxNQUFNO0NBQzVCLE9BQU8sS0FBSyxZQUFZLGNBQWMsS0FBSyxZQUFZLEtBQUE7QUFDekQ7QUFDQSxJQUFNLG9CQUFOLGNBQWdDLG9CQUFvQjtDQUlsRCxZQUFZLGNBQWMsUUFBUSxXQUFXLEtBQUssUUFBUSxPQUFPLGdCQUFnQixpQkFBaUIsa0JBQWtCOztFQUNsSCxNQUFNLGNBQWMsS0FBSyxRQUFRLGdCQUFnQixlQUFlO3dCQUpsRSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxvQkFBQSxLQUFBLENBQUE7d0JBQ0EsY0FBQSxLQUFBLENBQUE7RUFHRSxLQUFLLFNBQVM7RUFDZCxLQUFLLG1CQUFtQjtFQUN4QixLQUFLLGFBQWEsT0FBTyxhQUFhLEVBQ3BDLE1BQU0sT0FDUixDQUFDO0VBQ0QsSUFBSSxLQUFLLGtCQUNQLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxVQUFVO0VBRS9DLElBQUksU0FBUyxVQUFVO0VBQ3ZCLElBQUksV0FBVzs7R0FFYixTQUFTLDJCQUFBLHNCQURRUSxPQUFRLENBQUMsQ0FBQyxZQUFZLEdBQUcsT0FBQSxRQUFBLHdCQUFBLEtBQUEsSUFBQSxzQkFBSyxJQUNGLE1BQU07RUFDckQ7RUFDQSxTQUFTLGtCQUFrQixVQUFVLElBQUksTUFBTSxDQUFDLENBQUMsS0FBSSxNQUFLLEVBQUUsUUFBUSxTQUFTLGVBQWUsQ0FBQztFQUM3RixLQUFLLE1BQU0sU0FBUyxRQUFRO0dBQzFCLE1BQU0sVUFBVSxTQUFTLGNBQWMsT0FBTztHQUM5QyxJQUFJLE9BQ0YsUUFBUSxhQUFhLFNBQVMsS0FBSztHQUVyQyxRQUFRLGNBQWM7R0FDdEIsS0FBSyxXQUFXLFlBQVksT0FBTztFQUNyQztFQUNBLE1BQU0sYUFBQSx3QkFBWSxVQUFVLHVCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxzQkFBQSxLQUFBLFNBQW9CO0VBQ2hELElBQUksV0FDRixLQUFLLE1BQU0sWUFBWSxXQUFXO0dBQ2hDLE1BQU0sU0FBUyxrQkFBa0IsVUFBVSxHQUFHO0dBQzlDLElBQUksT0FDRixPQUFPLGFBQWEsU0FBUyxLQUFLO0dBRXBDLEtBQUssV0FBVyxZQUFZLE1BQU07RUFDcEM7Q0FFSjtDQUNBLGlCQUFpQixNQUFNO0VBQ3JCLE9BQU8sU0FBUyxLQUFLLFNBQVMsS0FBSyxhQUFhO0NBQ2xEO0NBQ0EsWUFBWSxRQUFRLFVBQVU7RUFDNUIsT0FBTyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsTUFBTSxHQUFHLFFBQVE7Q0FDbEU7Q0FDQSxhQUFhLFFBQVEsVUFBVSxVQUFVO0VBQ3ZDLE9BQU8sTUFBTSxhQUFhLEtBQUssaUJBQWlCLE1BQU0sR0FBRyxVQUFVLFFBQVE7Q0FDN0U7Q0FDQSxZQUFZLFNBQVMsVUFBVTtFQUM3QixPQUFPLE1BQU0sWUFBWSxNQUFNLFFBQVE7Q0FDekM7Q0FDQSxXQUFXLE1BQU07RUFDZixPQUFPLEtBQUssaUJBQWlCLE1BQU0sV0FBVyxLQUFLLGlCQUFpQixJQUFJLENBQUMsQ0FBQztDQUM1RTtDQUNBLFVBQVU7RUFDUixJQUFJLEtBQUssa0JBQ1AsS0FBSyxpQkFBaUIsV0FBVyxLQUFLLFVBQVU7Q0FFcEQ7QUFDRjtBQUNBLElBQU0sK0JBQU4sY0FBMkMsb0JBQW9CO0NBSzdELFlBQVksY0FBYyxrQkFBa0IsV0FBVywyQkFBMkIsS0FBSyxRQUFRLGdCQUFnQixpQkFBaUIsUUFBUTs7RUFDdEksTUFBTSxjQUFjLEtBQUssUUFBUSxnQkFBZ0IsZUFBZTt3QkFMbEUsb0JBQUEsS0FBQSxDQUFBO3dCQUNBLDZCQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFBLEtBQUEsQ0FBQTtFQUdFLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssNEJBQTRCO0VBQ2pDLElBQUksU0FBUyxVQUFVO0VBQ3ZCLElBQUksV0FBVzs7R0FFYixTQUFTLDJCQUFBLHVCQURRQSxPQUFRLENBQUMsQ0FBQyxZQUFZLEdBQUcsT0FBQSxRQUFBLHlCQUFBLEtBQUEsSUFBQSx1QkFBSyxJQUNGLE1BQU07RUFDckQ7RUFDQSxNQUFNLFVBQVUsU0FBUyxrQkFBa0IsUUFBUSxNQUFNLElBQUk7RUFDN0QsS0FBSyxTQUFTLFFBQVEsS0FBSSxNQUFLLEVBQUUsUUFBUSxTQUFTLGVBQWUsQ0FBQztFQUNsRSxLQUFLLGFBQUEseUJBQVksVUFBVSx1QkFBQSxRQUFBLDJCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsdUJBQUEsS0FBQSxXQUFvQixNQUFNO0NBQ3ZEO0NBQ0EsY0FBYztFQUNaLEtBQUssaUJBQWlCLFVBQVUsS0FBSyxRQUFRLEtBQUssU0FBUztDQUM3RDtDQUNBLFVBQVU7RUFDUixJQUFJLENBQUMsS0FBSywyQkFDUjtFQUVGLElBQUlDLHFCQUFzQixTQUFTLEdBQ2pDLEtBQUssaUJBQWlCLGFBQWEsS0FBSyxRQUFRLEtBQUssU0FBUztDQUVsRTtBQUNGO0FBQ0EsSUFBTSxvQ0FBTixjQUFnRCw2QkFBNkI7Q0FHM0UsWUFBWSxjQUFjLGtCQUFrQixXQUFXLE9BQU8sMkJBQTJCLEtBQUssUUFBUSxnQkFBZ0IsaUJBQWlCO0VBQ3JJLE1BQU0sU0FBUyxRQUFRLE1BQU0sVUFBVTtFQUN2QyxNQUFNLGNBQWMsa0JBQWtCLFdBQVcsMkJBQTJCLEtBQUssUUFBUSxnQkFBZ0IsaUJBQWlCLE1BQU07d0JBSmxJLGVBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO0VBSUUsS0FBSyxjQUFjLHFCQUFxQixNQUFNO0VBQzlDLEtBQUssV0FBVyxrQkFBa0IsTUFBTTtDQUMxQztDQUNBLFlBQVksU0FBUztFQUNuQixLQUFLLFlBQVk7RUFDakIsS0FBSyxhQUFhLFNBQVMsS0FBSyxVQUFVLEVBQUU7Q0FDOUM7Q0FDQSxjQUFjLFFBQVEsTUFBTTtFQUMxQixNQUFNLEtBQUssTUFBTSxjQUFjLFFBQVEsSUFBSTtFQUMzQyxNQUFNLGFBQWEsSUFBSSxLQUFLLGFBQWEsRUFBRTtFQUMzQyxPQUFPO0NBQ1Q7QUFDRjs7Ozs7Ozs7OztBQzF0QkEsSUFBTSxvQkFBTixNQUFNLDBCQUEwQkMsV0FBWTs7O3dCQUMxQyxxQkFBb0IsSUFBQTs7Q0FDcEIsT0FBTyxjQUFjO0VBQ25CLGtCQUFtQixJQUFJLGtCQUFrQixDQUFDO0NBQzVDO0NBQ0EsWUFBWSxJQUFJLEtBQUssVUFBVSxTQUFTO0VBQ3RDLEdBQUcsaUJBQWlCLEtBQUssVUFBVSxPQUFPO0VBQzFDLGFBQWE7R0FDWCxHQUFHLG9CQUFvQixLQUFLLFVBQVUsT0FBTztFQUMvQztDQUNGO0NBQ0EsY0FBYyxJQUFJLEtBQUs7RUFDckIsR0FBRyxjQUFjLEdBQUc7Q0FDdEI7Q0FDQSxPQUFPLE1BQU07RUFDWCxLQUFLLE9BQU87Q0FDZDtDQUNBLGNBQWMsU0FBUyxLQUFLO0VBQzFCLE1BQU0sT0FBTyxLQUFLLG1CQUFtQjtFQUNyQyxPQUFPLElBQUksY0FBYyxPQUFPO0NBQ2xDO0NBQ0EscUJBQXFCO0VBQ25CLE9BQU8sU0FBUyxlQUFlLG1CQUFtQixXQUFXO0NBQy9EO0NBQ0EscUJBQXFCO0VBQ25CLE9BQU87Q0FDVDtDQUNBLGNBQWMsTUFBTTtFQUNsQixPQUFPLEtBQUssYUFBYSxLQUFLO0NBQ2hDO0NBQ0EsYUFBYSxNQUFNO0VBQ2pCLE9BQU8sZ0JBQWdCO0NBQ3pCO0NBQ0EscUJBQXFCLEtBQUssUUFBUTtFQUNoQyxJQUFJLFdBQVcsVUFDYixPQUFPO0VBRVQsSUFBSSxXQUFXLFlBQ2IsT0FBTztFQUVULElBQUksV0FBVyxRQUNiLE9BQU8sSUFBSTtFQUViLE9BQU87Q0FDVDtDQUNBLFlBQVksS0FBSztFQUNmLE1BQU0sT0FBTyxtQkFBbUI7RUFDaEMsT0FBTyxRQUFRLE9BQU8sT0FBTyxhQUFhLElBQUk7Q0FDaEQ7Q0FDQSxtQkFBbUI7RUFDakIsY0FBYztDQUNoQjtDQUNBLGVBQWU7RUFDYixPQUFPLE9BQU8sVUFBVTtDQUMxQjtDQUNBLFVBQVUsTUFBTTtFQUNkLE9BQU9DLGlCQUFrQixTQUFTLFFBQVEsSUFBSTtDQUNoRDtBQUNGO0FBQ0EsSUFBSSxjQUFjO0FBQ2xCLFNBQVMscUJBQXFCO0NBQzVCLGNBQWMsZUFBZSxTQUFTLEtBQUssY0FBYyxNQUFNO0NBQy9ELE9BQU8sY0FBYyxZQUFZLGFBQWEsTUFBTSxJQUFJO0FBQzFEO0FBQ0EsU0FBUyxhQUFhLEtBQUs7Q0FDekIsT0FBTyxJQUFJLElBQUksS0FBSyxTQUFTLE9BQU8sQ0FBQyxDQUFDO0FBQ3hDO0FBQ0EsSUFBTSx3QkFBTixNQUE0QjtDQUMxQixZQUFZLFVBQVU7RUFDcEIsUUFBUSw0QkFBNEIsTUFBTSxrQkFBa0IsU0FBUztHQUNuRSxNQUFNLGNBQWMsU0FBUyxzQkFBc0IsTUFBTSxlQUFlO0dBQ3hFLElBQUksZUFBZSxNQUNqQixNQUFNLElBQUlDLGFBQWMsT0FBTyxPQUFPLGNBQWMsZUFBZSxjQUFjLHlDQUF5QztHQUU1SCxPQUFPO0VBQ1Q7RUFDQSxRQUFRLHNDQUFzQyxTQUFTLG9CQUFvQjtFQUMzRSxRQUFRLHFDQUFxQyxTQUFTLG1CQUFtQjtFQUN6RSxNQUFNLGlCQUFnQixhQUFZO0dBQ2hDLE1BQU0sZ0JBQWdCLFFBQVEsNkJBQTZCLENBQUM7R0FDNUQsSUFBSSxRQUFRLGNBQWM7R0FDMUIsTUFBTSxZQUFZLFdBQVk7SUFDNUI7SUFDQSxJQUFJLFNBQVMsR0FDWCxTQUFTO0dBRWI7R0FDQSxjQUFjLFNBQVEsZ0JBQWU7SUFDbkMsWUFBWSxXQUFXLFNBQVM7R0FDbEMsQ0FBQztFQUNIO0VBQ0EsSUFBSSxDQUFDLFFBQVEseUJBQ1gsUUFBUSwwQkFBMEIsQ0FBQztFQUVyQyxRQUFRLHVCQUF1QixDQUFDLEtBQUssYUFBYTtDQUNwRDtDQUNBLHNCQUFzQixVQUFVLE1BQU0saUJBQWlCO0VBQ3JELElBQUksUUFBUSxNQUNWLE9BQU87RUFFVCxNQUFNLElBQUksU0FBUyxlQUFlLElBQUk7RUFDdEMsSUFBSSxLQUFLLE1BQ1AsT0FBTztPQUNGLElBQUksQ0FBQyxpQkFDVixPQUFPO0VBRVQsSUFBSUMsT0FBUSxDQUFDLENBQUMsYUFBYSxJQUFJLEdBQzdCLE9BQU8sS0FBSyxzQkFBc0IsVUFBVSxLQUFLLE1BQU0sSUFBSTtFQUU3RCxPQUFPLEtBQUssc0JBQXNCLFVBQVUsS0FBSyxlQUFlLElBQUk7Q0FDdEU7QUFDRjtBQUNBLElBQU0sZ0JBQWdCO0NBQUM7Q0FBTztDQUFXO0NBQVE7QUFBTztBQUN4RCxJQUFNLFVBQVU7Q0FDZCxNQUFNO0NBQ04sS0FBTTtDQUNOLEtBQVE7Q0FDUixRQUFRO0NBQ1IsT0FBTztDQUNQLE9BQU87Q0FDUCxRQUFRO0NBQ1IsU0FBUztDQUNULE1BQU07Q0FDTixRQUFRO0NBQ1IsUUFBUTtDQUNSLFVBQVU7Q0FDVixPQUFPO0FBQ1Q7QUFDQSxJQUFNLHVCQUF1QjtDQUMzQixRQUFPLFVBQVMsTUFBTTtDQUN0QixZQUFXLFVBQVMsTUFBTTtDQUMxQixTQUFRLFVBQVMsTUFBTTtDQUN2QixVQUFTLFVBQVMsTUFBTTtBQUMxQjtBQUNBLElBQU0sa0JBQU4sTUFBTSx3QkFBd0IsbUJBQW1CO0NBQy9DLFlBQVksS0FBSztFQUNmLE1BQU0sR0FBRztDQUNYO0NBQ0EsU0FBUyxXQUFXO0VBQ2xCLE9BQU8sZ0JBQWdCLGVBQWUsU0FBUyxLQUFLO0NBQ3REO0NBQ0EsaUJBQWlCLFNBQVMsV0FBVyxTQUFTLFNBQVM7RUFDckQsTUFBTSxjQUFjLGdCQUFnQixlQUFlLFNBQVM7RUFDNUQsTUFBTSxpQkFBaUIsZ0JBQWdCLGNBQWMsWUFBWSxZQUFZLFNBQVMsS0FBSyxRQUFRLFFBQVEsQ0FBQztFQUM1RyxPQUFPLEtBQUssUUFBUSxRQUFRLENBQUMsQ0FBQyx3QkFBd0I7R0FDcEQsT0FBT0EsT0FBUSxDQUFDLENBQUMsWUFBWSxTQUFTLFlBQVksaUJBQWlCLGdCQUFnQixPQUFPO0VBQzVGLENBQUM7Q0FDSDtDQUNBLE9BQU8sZUFBZSxXQUFXO0VBQy9CLE1BQU0sUUFBUSxVQUFVLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRztFQUMvQyxNQUFNLGVBQWUsTUFBTSxNQUFNO0VBQ2pDLElBQUksTUFBTSxXQUFXLEtBQUssRUFBRSxpQkFBaUIsYUFBYSxpQkFBaUIsVUFDekUsT0FBTztFQUVULE1BQU0sTUFBTSxnQkFBZ0IsY0FBYyxNQUFNLElBQUksQ0FBQztFQUNyRCxJQUFJLFVBQVU7RUFDZCxJQUFJLFNBQVMsTUFBTSxRQUFRLE1BQU07RUFDakMsSUFBSSxTQUFTLElBQUk7R0FDZixNQUFNLE9BQU8sUUFBUSxDQUFDO0dBQ3RCLFVBQVU7RUFDWjtFQUNBLGNBQWMsU0FBUSxpQkFBZ0I7R0FDcEMsTUFBTSxRQUFRLE1BQU0sUUFBUSxZQUFZO0dBQ3hDLElBQUksUUFBUSxJQUFJO0lBQ2QsTUFBTSxPQUFPLE9BQU8sQ0FBQztJQUNyQixXQUFXLGVBQWU7R0FDNUI7RUFDRixDQUFDO0VBQ0QsV0FBVztFQUNYLElBQUksTUFBTSxVQUFVLEtBQUssSUFBSSxXQUFXLEdBQ3RDLE9BQU87RUFFVCxNQUFNLFNBQVMsQ0FBQztFQUNoQixPQUFPLGtCQUFrQjtFQUN6QixPQUFPLGFBQWE7RUFDcEIsT0FBTztDQUNUO0NBQ0EsT0FBTyxzQkFBc0IsT0FBTyxhQUFhO0VBQy9DLElBQUksVUFBVSxRQUFRLE1BQU0sUUFBUSxNQUFNO0VBQzFDLElBQUksTUFBTTtFQUNWLElBQUksWUFBWSxRQUFRLE9BQU8sSUFBSSxJQUFJO0dBQ3JDLFVBQVUsTUFBTTtHQUNoQixNQUFNO0VBQ1I7RUFDQSxJQUFJLFdBQVcsUUFBUSxDQUFDLFNBQVMsT0FBTztFQUN4QyxVQUFVLFFBQVEsWUFBWTtFQUM5QixJQUFJLFlBQVksS0FDZCxVQUFVO09BQ0wsSUFBSSxZQUFZLEtBQ3JCLFVBQVU7RUFFWixjQUFjLFNBQVEsaUJBQWdCO0dBQ3BDLElBQUksaUJBQWlCLFNBQVM7SUFDNUIsTUFBTSxpQkFBaUIscUJBQXFCO0lBQzVDLElBQUksZUFBZSxLQUFLLEdBQ3RCLE9BQU8sZUFBZTtHQUUxQjtFQUNGLENBQUM7RUFDRCxPQUFPO0VBQ1AsT0FBTyxRQUFRO0NBQ2pCO0NBQ0EsT0FBTyxjQUFjLFNBQVMsU0FBUyxNQUFNO0VBQzNDLFFBQU8sVUFBUztHQUNkLElBQUksZ0JBQWdCLHNCQUFzQixPQUFPLE9BQU8sR0FDdEQsS0FBSyxpQkFBaUIsUUFBUSxLQUFLLENBQUM7RUFFeEM7Q0FDRjtDQUNBLE9BQU8sY0FBYyxTQUFTO0VBQzVCLE9BQU8sWUFBWSxRQUFRLFdBQVc7Q0FDeEM7QUFTRjs7aUNBUlMsUUFBTyxTQUFTLHdCQUF3QixtQkFBbUI7Q0FFaEUsT0FBTyxLQUFLLHFCQUFxQkMsa0JBQWlCQyxTQUFZLFFBQVEsQ0FBQztBQUN6RSxDQUFBO2lDQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPRDtDQUNQLFNBQVNBLGlCQUFnQjtBQUMzQixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0UsaUJBQXFCLGlCQUFpQixDQUFDLEVBQ3hGLE1BQU0sV0FDUixDQUFDLFNBQVMsQ0FBQztFQUNULE1BQU0sS0FBQTtFQUNOLFlBQVksQ0FBQztHQUNYLE1BQU07R0FDTixNQUFNLENBQUMsUUFBUTtFQUNqQixDQUFDO0NBQ0gsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxTQUFlLHFCQUFxQixJQUFlLEtBQVMsS0FBQTs7OztzREFBeEIsZUFBZSxTQUFTLFNBQVM7RUFRbkUsT0FBT0MsMEJBQUFBLGVBQUFBLEVBTkwsY0FBQSxHQUNHLHNCQUFzQixTQUFTLE9BQU8sQ0FLSixDQUFDO0NBQzFDLENBQUE7OztBQUNBLFNBQWUsa0JBQWtCLEtBQVMsS0FBQTs7OzttREFBVCxTQUFTLFNBQVM7RUFJakQsT0FBT0EsMEJBQTJCLHNCQUFzQixTQUFTLE9BQU8sQ0FBQztDQUMzRSxDQUFBOzs7QUFDQSxTQUFTLHNCQUFzQixTQUFTLFNBQVM7O0NBQy9DLE9BQU87RUFDTCxhQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxLQUFBLElBQWEsUUFBUztFQUN0QixjQUFjLENBQUMsR0FBRywwQkFBMEIsSUFBQSxxQkFBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFJLFFBQVMsZUFBQSxRQUFBLHVCQUFBLEtBQUEsSUFBQSxxQkFBYSxDQUFDLENBQUU7RUFDekUsbUJBQW1CO0NBQ3JCO0FBQ0Y7QUFRQSxTQUFTLGdDQUFnQyxVQUFVLENBQUMsR0FBRzs7Q0FDckQsT0FBTyxDQUFDLEdBQUcsd0JBQUEsWUFBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLEtBQUEsSUFBdUIsUUFBUyxpQ0FBZ0MsS0FBQSxJQUFZO0VBQ3JGLFNBQVNDO0VBQ1QsV0FBQSx3QkFBVSxRQUFRLGlDQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUErQjtDQUNuRCxJQUFJLENBQUMsQ0FBQztBQUNSO0FBQ0EsU0FBUyxpQkFBaUI7Q0FDeEIsa0JBQWtCLFlBQVk7QUFDaEM7QUFDQSxTQUFTLGVBQWU7Q0FDdEIsT0FBTyxJQUFJLGFBQWE7QUFDMUI7QUFDQSxTQUFTLFlBQVk7Q0FDbkIsWUFBYSxRQUFRO0NBQ3JCLE9BQU87QUFDVDtBQUNBLElBQU0sc0NBQXNDO0NBQUM7RUFDM0MsU0FBUztFQUNULFVBQVVDO0NBQ1o7Q0FBRztFQUNELFNBQVM7RUFDVCxVQUFVO0VBQ1YsT0FBTztDQUNUO0NBQUc7RUFDRCxTQUFTO0VBQ1QsWUFBWTtDQUNkO0FBQUM7QUFDRCxJQUFNLGtCQUFrQixzQkFBc0IsY0FBYyxXQUFXLG1DQUFtQztBQUMxRyxJQUFNLGtDQUFrQyxJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxtQ0FBbUMsRUFBRTtBQUNoSixJQUFNLHdCQUF3QjtDQUFDO0VBQzdCLFNBQVNDO0VBQ1QsVUFBVTtDQUNaO0NBQUc7RUFDRCxTQUFTQztFQUNULFVBQVU7RUFDVixNQUFNO0dBQUM7R0FBUTtHQUFxQkQ7RUFBbUI7Q0FDekQ7Q0FBRztFQUNELFNBQVM7RUFDVCxVQUFVO0VBQ1YsTUFBTTtHQUFDO0dBQVE7R0FBcUJBO0VBQW1CO0NBQ3pEO0FBQUM7QUFDRCxJQUFNLDJCQUEyQjtDQUFDO0VBQ2hDLFNBQVNFO0VBQ1QsVUFBVTtDQUNaO0NBQUc7RUFDRCxTQUFTO0VBQ1QsWUFBWTtDQUNkO0NBQUc7RUFDRCxTQUFTO0VBQ1QsVUFBVTtFQUNWLE9BQU87Q0FDVDtDQUFHO0VBQ0QsU0FBUztFQUNULFVBQVU7RUFDVixPQUFPO0NBQ1Q7Q0FBRztDQUFxQjtFQUN0QixTQUFTQztFQUNULFVBQVU7Q0FDWjtDQUFHO0VBQ0QsU0FBUztFQUNULGFBQWFBO0NBQ2Y7Q0FBRztDQUFjO0VBQ2YsU0FBUztFQUNULGFBQWE7Q0FDZjtDQUFHLE9BQU8sY0FBYyxlQUFlLFlBQVk7RUFDakQsU0FBUztFQUNULFVBQVU7Q0FDWixJQUFJLENBQUM7QUFBQztBQUNOLElBQU0sZ0JBQU4sTUFBb0I7Q0FDbEIsY0FBYztFQUNaLElBQUksT0FBTyxjQUFjLGVBQWU7T0FDTixPQUFPLGlDQUFpQztJQUN0RSxVQUFVO0lBQ1YsVUFBVTtHQUNaLENBQzBCLEdBQ3hCLE1BQU0sSUFBSVgsYUFBYyxNQUFNLGlLQUEwSztFQUFBO0NBRzlNO0FBWUY7OytCQVhTLFFBQU8sU0FBUyxzQkFBc0IsbUJBQW1CO0NBQzlELE9BQU8sS0FBSyxxQkFBcUJZLGdCQUFlO0FBQ2xELENBQUE7K0JBQ08sUUFBc0IsaUNBQW9CO0NBQy9DLE1BQU1BO0NBQ04sU0FBUyxDQUFDLGNBQWMsaUJBQWlCO0FBQzNDLENBQUMsQ0FBQTsrQkFDTSxRQUFzQixpQ0FBb0I7Q0FDL0MsV0FBVyxDQUFDLEdBQUcsMEJBQTBCLEdBQUcscUJBQXFCO0NBQ2pFLFNBQVMsQ0FBQyxjQUFjLGlCQUFpQjtBQUMzQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1IsaUJBQXFCLGVBQWUsQ0FBQztFQUN0RixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsV0FBVyxDQUFDLEdBQUcsMEJBQTBCLEdBQUcscUJBQXFCO0dBQ2pFLFNBQVMsQ0FBQyxjQUFjLGlCQUFpQjtFQUMzQyxDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJO0FBQ3BCLEVBQUEsQ0FBRzs7Ozs7Ozs7Ozs7OztBQ3RXSCxJQUFNLE9BQU4sTUFBVzs7d0JBQ1QsUUFBTyxPQUFPLFFBQVEsQ0FBQTt3QkFDdEIsUUFBT1MsT0FBUSxDQUFBO3dCQUNmLGVBQUEsS0FBQSxDQUFBOztDQUNBLE9BQU8sS0FBSyxnQkFBZ0IsT0FBTztFQUNqQyxJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2pCLE9BQU8sS0FBSyxvQkFBb0IsS0FBSyxhQUFhO0NBQ3BEO0NBQ0EsUUFBUSxNQUFNLGdCQUFnQixPQUFPO0VBQ25DLE9BQU8sS0FBSyxRQUFPLFFBQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUksUUFBTyxLQUFLLG9CQUFvQixLQUFLLGFBQWEsQ0FBQztDQUMxRjtDQUNBLE9BQU8sY0FBYztFQUNuQixJQUFJLENBQUMsY0FBYyxPQUFPO0VBQzFCLE1BQU0sT0FBTyxLQUFLLEtBQUssY0FBYyxrQkFBa0IsWUFBWSxDQUFDO0VBQ3BFLE9BQU8sVUFBVSxJQUFJLElBQUksT0FBTztDQUNsQztDQUNBLFFBQVEsY0FBYztFQUNwQixJQUFJLENBQUMsY0FBYyxPQUFPLENBQUM7RUFDM0IsTUFBTSxPQUFPLEtBQUssS0FBSyxpQkFBaUIsa0JBQWtCLFlBQVksQ0FBQztFQUN2RSxPQUFPLE9BQU8sTUFBTSxLQUFLLElBQUksQ0FBQyxDQUFDLFFBQU8sU0FBUSxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUM7Q0FDcEU7Q0FDQSxVQUFVLEtBQUssVUFBVTs7RUFDdkIsQ0FBQSxZQUFBLGNBQUEsUUFBQSxjQUFBLEtBQUEsTUFBQSxXQUFhLGNBQWMsR0FBRztFQUM5QixNQUFNLE9BQU8sS0FBSyxPQUFPLFFBQVE7RUFDakMsSUFBSSxNQUFNO0dBQ1IseUJBQXlCLEtBQUssSUFBSTtHQUNsQyxPQUFPO0VBQ1Q7RUFDQSxPQUFPLEtBQUssb0JBQW9CLEtBQUssSUFBSTtDQUMzQztDQUNBLFVBQVUsY0FBYztFQUN0QixLQUFLLGlCQUFpQixLQUFLLE9BQU8sWUFBWSxDQUFDO0NBQ2pEO0NBQ0EsaUJBQWlCLE1BQU07RUFDckIsSUFBSSxNQUNGLEtBQUssS0FBSyxPQUFPLElBQUk7Q0FFekI7Q0FDQSxvQkFBb0IsTUFBTSxnQkFBZ0IsT0FBTztFQUMvQyxJQUFJLENBQUMsZUFBZTtHQUNsQixNQUFNLFdBQVcsY0FBYyxJQUFJO0dBQ25DLE1BQU0sT0FBTyxLQUFLLFFBQVEsUUFBUSxDQUFDLENBQUMsUUFBTyxTQUFRLG1CQUFtQixNQUFNLElBQUksQ0FBQyxDQUFDLENBQUM7R0FDbkYsSUFBSSxTQUFTLEtBQUEsR0FBVyxPQUFPO0VBQ2pDO0VBQ0EsTUFBTSxVQUFVLEtBQUssS0FBSyxjQUFjLE1BQU07RUFDOUMseUJBQXlCLE1BQU0sT0FBTztFQUV0QyxLQURrQixLQUFLLHFCQUFxQixNQUFNLENBQUMsQ0FBQyxFQUNoRCxDQUFDLFlBQVksT0FBTztFQUN4QixPQUFPO0NBQ1Q7QUFRRjs7c0JBUFMsUUFBTyxTQUFTLGFBQWEsbUJBQW1CO0NBQ3JELE9BQU8sS0FBSyxxQkFBcUJDLE9BQU07QUFDekMsQ0FBQTtzQkFDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxTQUFTQSxNQUFLO0FBQ2hCLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjQyxpQkFBcUIsTUFBTSxDQUFDLEVBQzdFLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILFNBQVMsa0JBQWtCLGNBQWM7Q0FDdkMsT0FBTyxRQUFRLGFBQWE7QUFDOUI7QUFDQSxTQUFTLHlCQUF5QixLQUFLLElBQUk7Q0FDekMsT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLFNBQVEsU0FBUSxHQUFHLGFBQWEsY0FBYyxJQUFJLEdBQUcsSUFBSSxLQUFLLENBQUM7QUFDbEY7QUFDQSxTQUFTLGNBQWMsS0FBSztDQUMxQixNQUFNLE9BQU8sSUFBSSxPQUFPLFNBQVM7Q0FDakMsT0FBTyxHQUFHLEtBQUssR0FBRyxvQkFBb0IsT0FBTyxJQUFJLEtBQUssQ0FBQztBQUN6RDtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsT0FBTyxJQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sQ0FBQyxDQUFDLFFBQVEsTUFBTSxNQUFLLEVBQUU7QUFDL0Q7QUFDQSxTQUFTLG1CQUFtQixLQUFLLE1BQU07Q0FDckMsT0FBTyxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTSxRQUFPLEtBQUssYUFBYSxjQUFjLEdBQUcsQ0FBQyxNQUFNLElBQUksSUFBSTtBQUN6RjtBQUNBLFNBQVMsY0FBYyxNQUFNO0NBQzNCLE9BQU8sY0FBYyxTQUFTO0FBQ2hDO0FBQ0EsU0FBUyxVQUFVLEtBQUs7Q0FDdEIsUUFBQSxRQUFBLFFBQUEsUUFBQSxLQUFBLElBQUEsS0FBQSxJQUFPLElBQUssU0FBUyxZQUFZLE9BQU07QUFDekM7QUFDQSxJQUFNLGdCQUFnQixFQUNwQixXQUFXLGFBQ2I7QUFDQSxJQUFNLFFBQU4sTUFBWTtDQUVWLFlBQVksTUFBTTt3QkFEbEIsUUFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLE9BQU87Q0FDZDtDQUNBLFdBQVc7RUFDVCxPQUFPLEtBQUssS0FBSztDQUNuQjtDQUNBLFNBQVMsVUFBVTtFQUNqQixLQUFLLEtBQUssUUFBUSxZQUFZO0NBQ2hDO0FBVUY7O3VCQVRTLFFBQU8sU0FBUyxjQUFjLG1CQUFtQjtDQUV0RCxPQUFPLEtBQUsscUJBQXFCQyxRQUFPQyxTQUFZLFFBQVEsQ0FBQztBQUMvRCxDQUFBO3VCQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPRDtDQUNQLFNBQVNBLE9BQU07Q0FDZixZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNELGlCQUFxQixPQUFPLENBQUM7RUFDOUUsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFlBQVksT0FDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTLENBQUM7RUFDVCxNQUFNLEtBQUE7RUFDTixZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLFFBQVE7RUFDakIsQ0FBQztDQUNILENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsU0FBUyxZQUFZLE1BQU0sT0FBTztDQUNoQyxJQUFJLE9BQU8sYUFBYSxlQUFlLENBQUMsVUFBVTtFQUNoRCxNQUFNLEtBQUssUUFBUSxRQUFRLFFBQVEsU0FBUyxDQUFDO0VBQzdDLEdBQUcsUUFBUTtDQUNiO0FBQ0Y7QUFDQSxJQUFNLDRCQUFOLE1BQWdDO0NBRzlCLFlBQVksV0FBVyxVQUFVO3dCQUZqQyxhQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssWUFBWTtFQUNqQixLQUFLLFdBQVc7Q0FDbEI7QUFDRjtBQUNBLElBQU0sa0JBQU4sTUFBc0I7Q0FFcEIsWUFBWSxLQUFLO3dCQURqQixVQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssU0FBUyxJQUFJLFNBQVMsSUFBSSxjQUFjO0NBQy9DO0NBQ0Esb0JBQW9CLFFBQVE7RUFDMUIsTUFBTSxTQUFTLFVBQVUsT0FBTztFQUNoQyxNQUFNLGNBQWM7RUFDcEIsSUFBSSxVQUFVLGFBQWEsV0FBVyxPQUFPLFFBQVEsWUFBWSxZQUMvRCxRQUFRLFFBQVEsV0FBVztFQUU3QixNQUFNLFFBQVEsWUFBWSxJQUFJO0VBQzlCLElBQUksV0FBVztFQUNmLE9BQU8sV0FBVyxLQUFLLFlBQVksSUFBSSxJQUFJLFFBQVEsS0FBSztHQUN0RCxLQUFLLE9BQU8sS0FBSztHQUNqQjtFQUNGO0VBQ0EsTUFBTSxNQUFNLFlBQVksSUFBSTtFQUM1QixJQUFJLFVBQVUsZ0JBQWdCLFdBQVcsT0FBTyxRQUFRLGVBQWUsWUFDckUsUUFBUSxXQUFXLFdBQVc7RUFFaEMsTUFBTSxhQUFhLE1BQU0sU0FBUztFQUNsQyxRQUFRLElBQUksT0FBTyxTQUFTLHlCQUF5QjtFQUNyRCxRQUFRLElBQUksR0FBRyxVQUFVLFFBQVEsQ0FBQyxFQUFFLGNBQWM7RUFDbEQsT0FBTyxJQUFJLDBCQUEwQixXQUFXLFFBQVE7Q0FDMUQ7QUFDRjtBQUNBLElBQU0sdUJBQXVCO0FBQzdCLFNBQVMsaUJBQWlCLEtBQUs7Q0FDN0IsWUFBWSxzQkFBc0IsSUFBSSxnQkFBZ0IsR0FBRyxDQUFDO0NBQzFELE9BQU87QUFDVDtBQUNBLFNBQVMsb0JBQW9CO0NBQzNCLFlBQVksc0JBQXNCLElBQUk7QUFDeEM7QUFDQSxJQUFNLEtBQU4sTUFBUztDQUNQLE9BQU8sTUFBTTtFQUNYLGFBQWE7Q0FDZjtDQUNBLE9BQU8sSUFBSSxVQUFVO0VBQ25CLFFBQU8saUJBQWdCO0dBQ3JCLE9BQU8sYUFBYSxpQkFBaUIsT0FBTyxlQUFlLGFBQWEsZUFBZSxRQUFRLElBQUk7RUFDckc7Q0FDRjtDQUNBLE9BQU8sVUFBVSxNQUFNO0VBQ3JCLFFBQU8sY0FBYSxVQUFVLGVBQWUsUUFBUSxJQUFJLE1BQU07Q0FDakU7QUFDRjtBQUNBLFNBQVMsZUFBZSxHQUFHLFVBQVU7Q0FDbkMsSUFBSUYsT0FBUSxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQzNCLE9BQU8sRUFBRSxXQUFXLEVBQUUsUUFBUSxRQUFRLEtBQUssRUFBRSxxQkFBcUIsRUFBRSxrQkFBa0IsUUFBUSxLQUFLLEVBQUUseUJBQXlCLEVBQUUsc0JBQXNCLFFBQVE7Q0FFaEssT0FBTztBQUNUO0FBQ0EsSUFBTSxtQkFBTixNQUF1Qjs7O3dCQUNyQixvQkFBQSxVQUFrQixPQUFPLG1CQUFtQixFQUMxQyxVQUFVLEtBQ1osQ0FBQyxPQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsVUFBSyxFQUFBOztDQUNOLFVBQVUsTUFBTTtFQUNkLElBQUksT0FBTyxjQUFjLGVBQWU7T0FDbEMsQ0FBQyxLQUFLLFdBQVcsSUFBSSxHQUN2QixNQUFNLElBQUksTUFBTSxpRkFBaUYsS0FBSyxFQUFFO0VBQUE7RUFHNUcsSUFBSSxDQUFDLEtBQUssaUJBQWlCLE9BQU87RUFDbEMsT0FBTyxLQUFLLEtBQUssa0JBQWtCLEtBQUssVUFBVSxDQUFXO0NBQy9EO0FBUUY7O2tDQVBTLFFBQU8sU0FBUyx5QkFBeUIsbUJBQW1CO0NBQ2pFLE9BQU8sS0FBSyxxQkFBcUJLLG1CQUFrQjtBQUNyRCxDQUFBO2tDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLGtCQUFpQjtBQUM1QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0gsaUJBQXFCLGtCQUFrQixDQUFDLEVBQ3pGLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQUk7Q0FDSCxTQUFVLHNCQUFzQjtDQUMvQixxQkFBcUIscUJBQXFCLHlCQUF5QixLQUFLO0NBQ3hFLHFCQUFxQixxQkFBcUIsOEJBQThCLEtBQUs7Q0FDN0UscUJBQXFCLHFCQUFxQixpQkFBaUIsS0FBSztDQUNoRSxxQkFBcUIscUJBQXFCLGlCQUFpQixLQUFLO0NBQ2hFLHFCQUFxQixxQkFBcUIsMEJBQTBCLEtBQUs7Q0FDekUscUJBQXFCLHFCQUFxQiw0QkFBNEIsS0FBSztBQUM3RSxFQUFBLENBQUcseUJBQXlCLHVCQUF1QixDQUFDLEVBQUU7QUFDdEQsU0FBUyxpQkFBaUIsT0FBTyxhQUFhLENBQUMsR0FBRyxXQUFXLENBQUMsR0FBRztDQUMvRCxPQUFPO0VBQ0w7RUFDQTtDQUNGO0FBQ0Y7QUFDQSxTQUFTLDBCQUEwQjtDQUNqQyxPQUFPLGlCQUFpQixxQkFBcUIsbUJBQW1CO0FBQ2xFO0FBQ0EsU0FBUyw2QkFBNkIsU0FBUztDQUM3QyxPQUFPLGlCQUFpQixxQkFBcUIsMEJBQTBCSSxzQkFBdUIsT0FBTyxDQUFDO0FBQ3hHO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDekIsT0FBTyxpQkFBaUIscUJBQXFCLGFBQWFDLGtCQUFpQixDQUFDO0FBQzlFO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDekIsT0FBTyxpQkFBaUIscUJBQXFCLGFBQWFDLGtCQUFpQixDQUFDO0FBQzlFO0FBQ0EsU0FBUywyQkFBMkI7Q0FDbEMsT0FBTyxpQkFBaUIscUJBQXFCLHNCQUFzQkMsMkJBQTBCLENBQUM7QUFDaEc7QUFDQSxTQUFTLDZCQUE2QjtDQUNwQyxPQUFPLGlCQUFpQixxQkFBcUIsc0JBQXNCO0FBQ3JFO0FBQ0EsU0FBUyxrREFBa0Q7Q0FDekQsT0FBTyxDQUFDO0VBQ04sU0FBUztFQUNULGdCQUFnQjtHQUlkLElBSDJDLE9BQU9DLHdDQUF5QyxFQUN6RixVQUFVLEtBQ1osQ0FDcUMsR0FBRztJQUN0QyxNQUFNLFVBQVUsT0FBT0MsT0FBUTtJQUMvQixNQUFNLFVBQVVDLG1CQUFvQixNQUFNLHFJQUEwSTtJQUNwTCxRQUFRLEtBQUssT0FBTztHQUN0QjtFQUNGO0VBQ0EsT0FBTztDQUNULENBQUM7QUFDSDtBQUNBLFNBQVMsdUJBQXVCLEdBQUcsVUFBVTtDQUMzQyxNQUFNLFlBQVksQ0FBQztDQUNuQixNQUFNLCtCQUFlLElBQUksSUFBSTtDQUM3QixLQUFLLE1BQU0sRUFDVCxZQUNBLFdBQ0csVUFBVTtFQUNiLGFBQWEsSUFBSSxLQUFLO0VBQ3RCLElBQUksV0FBVyxRQUNiLFVBQVUsS0FBSyxVQUFVO0NBRTdCO0NBQ0EsTUFBTSw4QkFBOEIsYUFBYSxJQUFJLHFCQUFxQix3QkFBd0I7Q0FDbEcsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUFXO0VBQ2pELElBQUksYUFBYSxJQUFJLHFCQUFxQixtQkFBbUIsS0FBSyw2QkFDaEUsTUFBTSxJQUFJQyxhQUFjLE1BQU0sc0tBQXNLO0VBRXRNLElBQUksYUFBYSxJQUFJLHFCQUFxQixvQkFBb0IsS0FBSyxhQUFhLElBQUkscUJBQXFCLHNCQUFzQixHQUM3SCxNQUFNLElBQUlBLGFBQWMsTUFBTSxxS0FBcUs7Q0FFdk07Q0FDQSxPQUFPLHlCQUF5QjtFQUFDLE9BQU8sY0FBYyxlQUFlLFlBQVksZ0RBQWdELElBQUksQ0FBQztFQUFHLE9BQU8sY0FBYyxlQUFlLFlBQVksMEJBQTBCLElBQUksQ0FBQztFQUFHQyxpQkFBa0I7RUFBRyxhQUFhLElBQUkscUJBQXFCLG1CQUFtQixLQUFLLDhCQUE4QixDQUFDLElBQUlSLHNCQUF1QixDQUFDLENBQUM7RUFBRyxhQUFhLElBQUkscUJBQXFCLHNCQUFzQixJQUFJLENBQUMsSUFBSUcsMkJBQTBCO0VBQUc7RUFBVztHQUN4ZCxTQUFTTTtHQUNULFVBQVUsRUFDUixVQUFVLEtBQ1o7RUFDRjtFQUFHO0dBQ0QsU0FBUztHQUNULE9BQU87R0FDUCxrQkFBa0I7SUFDaEIsTUFBTSxTQUFTLE9BQU8sY0FBYztJQUNwQyxNQUFNLGFBQWEsT0FBT0EsWUFBYTtJQUN2QyxhQUFhO0tBQ1gsT0FBTyxXQUFXLENBQUMsQ0FBQyxXQUFXO01BQzdCLFdBQVcsV0FBVztLQUN4QixDQUFDO0lBQ0g7R0FDRjtFQUNGO0NBQUMsQ0FBQztBQUNKO0FBQ0EsSUFBTSxlQUFOLE1BQW1CLENBa0JuQjs7OEJBakJTLFFBQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0NBQzdELE9BQU8sS0FBSyxxQkFBcUJDLGVBQWM7QUFDakQsQ0FBQTs4QkFDTyxTQUF1QixtQ0FBc0I7Q0FDbEQsT0FBT0E7Q0FDUCxTQUFTLFNBQVMscUJBQXFCLG1CQUFtQjtFQUN4RCxJQUFJLDJCQUEyQjtFQUMvQixJQUFJLG1CQUNGLDJCQUEyQixLQUFLLHFCQUFxQkEsZUFBYztPQUduRSwyQkFBMkJaLFNBQVksZ0JBQWdCO0VBRXpELE9BQU87Q0FDVDtDQUNBLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0YsaUJBQXFCLGNBQWMsQ0FBQztFQUNyRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsWUFBWTtHQUNaLGFBQWEsaUJBQWlCLGdCQUFnQjtFQUNoRCxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLG1CQUFOLGNBQStCLGFBQWE7Ozt3QkFDMUMsUUFBTyxPQUFPLFFBQVEsQ0FBQTs7Q0FDdEIsU0FBUyxLQUFLLE9BQU87RUFDbkIsSUFBSSxTQUFTLE1BQU0sT0FBTztFQUMxQixRQUFRLEtBQVI7R0FDRSxLQUFLLGdCQUFnQixNQUNuQixPQUFPO0dBQ1QsS0FBSyxnQkFBZ0I7SUFDbkIsSUFBSWUsZ0NBQWlDLE9BQU8sTUFBTSxHQUNoRCxPQUFPQyxnQkFBaUIsS0FBSztJQUUvQixPQUFPQyxjQUFlLEtBQUssTUFBTSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUztHQUMzRCxLQUFLLGdCQUFnQjtJQUNuQixJQUFJRixnQ0FBaUMsT0FBTyxPQUFPLEdBQ2pELE9BQU9DLGdCQUFpQixLQUFLO0lBRS9CLE9BQU87R0FDVCxLQUFLLGdCQUFnQjtJQUNuQixJQUFJRCxnQ0FBaUMsT0FBTyxRQUFRLEdBQ2xELE9BQU9DLGdCQUFpQixLQUFLO0lBRS9CLE1BQU0sSUFBSUwsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsdUNBQXVDO0dBQzFILEtBQUssZ0JBQWdCO0lBQ25CLElBQUlJLGdDQUFpQyxPQUFPLEtBQUssR0FDL0MsT0FBT0MsZ0JBQWlCLEtBQUs7SUFFL0IsT0FBT0UsYUFBYyxPQUFPLEtBQUssQ0FBQztHQUNwQyxLQUFLLGdCQUFnQjtJQUNuQixJQUFJSCxnQ0FBaUMsT0FBTyxhQUFhLEdBQ3ZELE9BQU9DLGdCQUFpQixLQUFLO0lBRS9CLE1BQU0sSUFBSUwsYUFBYyxRQUFRLE9BQU8sY0FBYyxlQUFlLGNBQWMsbUlBQXdFO0dBQzVKLFNBQ0UsTUFBTSxJQUFJQSxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyw4QkFBOEIsSUFBSSx1RkFBNEI7RUFDbko7Q0FDRjtDQUNBLHdCQUF3QixPQUFPO0VBQzdCLE9BQU9RLDRCQUE2QixLQUFLO0NBQzNDO0NBQ0EseUJBQXlCLE9BQU87RUFDOUIsT0FBT0MsNkJBQThCLEtBQUs7Q0FDNUM7Q0FDQSwwQkFBMEIsT0FBTztFQUMvQixPQUFPQyw4QkFBK0IsS0FBSztDQUM3QztDQUNBLHVCQUF1QixPQUFPO0VBQzVCLE9BQU9DLDJCQUE0QixLQUFLO0NBQzFDO0NBQ0EsK0JBQStCLE9BQU87RUFDcEMsT0FBT0MsbUNBQW9DLEtBQUs7Q0FDbEQ7QUFRRjs7a0NBUFMsUUFBTyxTQUFTLHlCQUF5QixtQkFBbUI7Q0FDakUsT0FBTyxLQUFLLHFCQUFxQkMsbUJBQWtCO0FBQ3JELENBQUE7a0NBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0Esa0JBQWlCO0FBQzVCLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjeEIsaUJBQXFCLGtCQUFrQixDQUFDLEVBQ3pGLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sMEJBQXlCLElBQUksUUFBUSxRQUFRIn0=