import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
//#region node_modules/uuid/dist/esm-browser/max.js
var max_default = "ffffffff-ffff-ffff-ffff-ffffffffffff";
//#endregion
//#region node_modules/uuid/dist/esm-browser/nil.js
var nil_default = "00000000-0000-0000-0000-000000000000";
//#endregion
//#region node_modules/uuid/dist/esm-browser/regex.js
var regex_default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
//#endregion
//#region node_modules/uuid/dist/esm-browser/validate.js
function validate(uuid) {
	return typeof uuid === "string" && regex_default.test(uuid);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/parse.js
function parse(uuid) {
	if (!validate(uuid)) throw TypeError("Invalid UUID");
	let v;
	return Uint8Array.of((v = parseInt(uuid.slice(0, 8), 16)) >>> 24, v >>> 16 & 255, v >>> 8 & 255, v & 255, (v = parseInt(uuid.slice(9, 13), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(14, 18), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(19, 23), 16)) >>> 8, v & 255, (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255, v / 4294967296 & 255, v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) byteToHex.push((i + 256).toString(16).slice(1));
function unsafeStringify(arr, offset = 0) {
	return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}
function stringify(arr, offset = 0) {
	const uuid = unsafeStringify(arr, offset);
	if (!validate(uuid)) throw TypeError("Stringified UUID is invalid");
	return uuid;
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/rng.js
var getRandomValues;
var rnds8 = /* @__PURE__ */ new Uint8Array(16);
function rng() {
	if (!getRandomValues) {
		if (typeof crypto === "undefined" || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
		getRandomValues = crypto.getRandomValues.bind(crypto);
	}
	return getRandomValues(rnds8);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v1.js
var _state$1 = {};
function v1(options, buf, offset) {
	var _options$_v;
	let bytes;
	const isV6 = (_options$_v = options === null || options === void 0 ? void 0 : options._v6) !== null && _options$_v !== void 0 ? _options$_v : false;
	if (options) {
		const optionsKeys = Object.keys(options);
		if (optionsKeys.length === 1 && optionsKeys[0] === "_v6") options = void 0;
	}
	if (options) {
		var _ref, _options$random, _options$rng;
		bytes = v1Bytes((_ref = (_options$random = options.random) !== null && _options$random !== void 0 ? _options$random : (_options$rng = options.rng) === null || _options$rng === void 0 ? void 0 : _options$rng.call(options)) !== null && _ref !== void 0 ? _ref : rng(), options.msecs, options.nsecs, options.clockseq, options.node, buf, offset);
	} else {
		const now = Date.now();
		const rnds = rng();
		updateV1State(_state$1, now, rnds);
		bytes = v1Bytes(rnds, _state$1.msecs, _state$1.nsecs, isV6 ? void 0 : _state$1.clockseq, isV6 ? void 0 : _state$1.node, buf, offset);
	}
	return buf !== null && buf !== void 0 ? buf : unsafeStringify(bytes);
}
function updateV1State(state, now, rnds) {
	var _state$msecs, _state$nsecs;
	(_state$msecs = state.msecs) !== null && _state$msecs !== void 0 || (state.msecs = -Infinity);
	(_state$nsecs = state.nsecs) !== null && _state$nsecs !== void 0 || (state.nsecs = 0);
	if (now === state.msecs) {
		state.nsecs++;
		if (state.nsecs >= 1e4) {
			state.node = void 0;
			state.nsecs = 0;
		}
	} else if (now > state.msecs) state.nsecs = 0;
	else if (now < state.msecs) state.node = void 0;
	if (!state.node) {
		state.node = rnds.slice(10, 16);
		state.node[0] |= 1;
		state.clockseq = (rnds[8] << 8 | rnds[9]) & 16383;
	}
	state.msecs = now;
	return state;
}
function v1Bytes(rnds, msecs, nsecs, clockseq, node, buf, offset = 0) {
	var _msecs, _nsecs, _clockseq, _node;
	if (rnds.length < 16) throw new Error("Random bytes length must be >= 16");
	if (!buf) {
		buf = /* @__PURE__ */ new Uint8Array(16);
		offset = 0;
	} else if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
	(_msecs = msecs) !== null && _msecs !== void 0 || (msecs = Date.now());
	(_nsecs = nsecs) !== null && _nsecs !== void 0 || (nsecs = 0);
	(_clockseq = clockseq) !== null && _clockseq !== void 0 || (clockseq = (rnds[8] << 8 | rnds[9]) & 16383);
	(_node = node) !== null && _node !== void 0 || (node = rnds.slice(10, 16));
	msecs += 0xb1d069b5400;
	const tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
	buf[offset++] = tl >>> 24 & 255;
	buf[offset++] = tl >>> 16 & 255;
	buf[offset++] = tl >>> 8 & 255;
	buf[offset++] = tl & 255;
	const tmh = msecs / 4294967296 * 1e4 & 268435455;
	buf[offset++] = tmh >>> 8 & 255;
	buf[offset++] = tmh & 255;
	buf[offset++] = tmh >>> 24 & 15 | 16;
	buf[offset++] = tmh >>> 16 & 255;
	buf[offset++] = clockseq >>> 8 | 128;
	buf[offset++] = clockseq & 255;
	for (let n = 0; n < 6; ++n) buf[offset++] = node[n];
	return buf;
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v1ToV6.js
function v1ToV6(uuid) {
	const v6Bytes = _v1ToV6(typeof uuid === "string" ? parse(uuid) : uuid);
	return typeof uuid === "string" ? unsafeStringify(v6Bytes) : v6Bytes;
}
function _v1ToV6(v1Bytes) {
	return Uint8Array.of((v1Bytes[6] & 15) << 4 | v1Bytes[7] >> 4 & 15, (v1Bytes[7] & 15) << 4 | (v1Bytes[4] & 240) >> 4, (v1Bytes[4] & 15) << 4 | (v1Bytes[5] & 240) >> 4, (v1Bytes[5] & 15) << 4 | (v1Bytes[0] & 240) >> 4, (v1Bytes[0] & 15) << 4 | (v1Bytes[1] & 240) >> 4, (v1Bytes[1] & 15) << 4 | (v1Bytes[2] & 240) >> 4, 96 | v1Bytes[2] & 15, v1Bytes[3], v1Bytes[8], v1Bytes[9], v1Bytes[10], v1Bytes[11], v1Bytes[12], v1Bytes[13], v1Bytes[14], v1Bytes[15]);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/md5.js
function md5(bytes) {
	return uint32ToUint8(wordsToMd5(uint8ToUint32(bytes), bytes.length * 8));
}
function uint32ToUint8(input) {
	const bytes = new Uint8Array(input.length * 4);
	for (let i = 0; i < input.length * 4; i++) bytes[i] = input[i >> 2] >>> i % 4 * 8 & 255;
	return bytes;
}
function getOutputLength(inputLength8) {
	return (inputLength8 + 64 >>> 9 << 4) + 14 + 1;
}
function wordsToMd5(x, len) {
	const xpad = new Uint32Array(getOutputLength(len)).fill(0);
	xpad.set(x);
	xpad[len >> 5] |= 128 << len % 32;
	xpad[xpad.length - 1] = len;
	x = xpad;
	let a = 1732584193;
	let b = -271733879;
	let c = -1732584194;
	let d = 271733878;
	for (let i = 0; i < x.length; i += 16) {
		const olda = a;
		const oldb = b;
		const oldc = c;
		const oldd = d;
		a = md5ff(a, b, c, d, x[i], 7, -680876936);
		d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
		c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
		b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
		a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
		d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
		c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
		b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
		a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
		d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
		c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
		b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
		a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
		d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
		c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
		b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
		a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
		d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
		c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
		b = md5gg(b, c, d, a, x[i], 20, -373897302);
		a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
		d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
		c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
		b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
		a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
		d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
		c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
		b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
		a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
		d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
		c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
		b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
		a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
		d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
		c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
		b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
		a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
		d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
		c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
		b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
		a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
		d = md5hh(d, a, b, c, x[i], 11, -358537222);
		c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
		b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
		a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
		d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
		c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
		b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
		a = md5ii(a, b, c, d, x[i], 6, -198630844);
		d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
		c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
		b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
		a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
		d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
		c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
		b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
		a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
		d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
		c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
		b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
		a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
		d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
		c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
		b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
		a = safeAdd(a, olda);
		b = safeAdd(b, oldb);
		c = safeAdd(c, oldc);
		d = safeAdd(d, oldd);
	}
	return Uint32Array.of(a, b, c, d);
}
function uint8ToUint32(input) {
	if (input.length === 0) return /* @__PURE__ */ new Uint32Array();
	const output = new Uint32Array(getOutputLength(input.length * 8)).fill(0);
	for (let i = 0; i < input.length; i++) output[i >> 2] |= (input[i] & 255) << i % 4 * 8;
	return output;
}
function safeAdd(x, y) {
	const lsw = (x & 65535) + (y & 65535);
	return (x >> 16) + (y >> 16) + (lsw >> 16) << 16 | lsw & 65535;
}
function bitRotateLeft(num, cnt) {
	return num << cnt | num >>> 32 - cnt;
}
function md5cmn(q, a, b, x, s, t) {
	return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
}
function md5ff(a, b, c, d, x, s, t) {
	return md5cmn(b & c | ~b & d, a, b, x, s, t);
}
function md5gg(a, b, c, d, x, s, t) {
	return md5cmn(b & d | c & ~d, a, b, x, s, t);
}
function md5hh(a, b, c, d, x, s, t) {
	return md5cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5ii(a, b, c, d, x, s, t) {
	return md5cmn(c ^ (b | ~d), a, b, x, s, t);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v35.js
function stringToBytes(str) {
	str = unescape(encodeURIComponent(str));
	const bytes = new Uint8Array(str.length);
	for (let i = 0; i < str.length; ++i) bytes[i] = str.charCodeAt(i);
	return bytes;
}
var DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
var URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
function v35(version, hash, value, namespace, buf, offset) {
	const valueBytes = typeof value === "string" ? stringToBytes(value) : value;
	const namespaceBytes = typeof namespace === "string" ? parse(namespace) : namespace;
	if (typeof namespace === "string") namespace = parse(namespace);
	if ((namespace === null || namespace === void 0 ? void 0 : namespace.length) !== 16) throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
	let bytes = new Uint8Array(16 + valueBytes.length);
	bytes.set(namespaceBytes);
	bytes.set(valueBytes, namespaceBytes.length);
	bytes = hash(bytes);
	bytes[6] = bytes[6] & 15 | version;
	bytes[8] = bytes[8] & 63 | 128;
	if (buf) {
		offset = offset || 0;
		if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
		for (let i = 0; i < 16; ++i) buf[offset + i] = bytes[i];
		return buf;
	}
	return unsafeStringify(bytes);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v3.js
function v3(value, namespace, buf, offset) {
	return v35(48, md5, value, namespace, buf, offset);
}
v3.DNS = DNS;
v3.URL = URL;
var native_default = { randomUUID: typeof crypto !== "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto) };
//#endregion
//#region node_modules/uuid/dist/esm-browser/v4.js
function v4(options, buf, offset) {
	var _ref, _options$random, _options$rng;
	if (native_default.randomUUID && !buf && !options) return native_default.randomUUID();
	options = options || {};
	const rnds = (_ref = (_options$random = options.random) !== null && _options$random !== void 0 ? _options$random : (_options$rng = options.rng) === null || _options$rng === void 0 ? void 0 : _options$rng.call(options)) !== null && _ref !== void 0 ? _ref : rng();
	if (rnds.length < 16) throw new Error("Random bytes length must be >= 16");
	rnds[6] = rnds[6] & 15 | 64;
	rnds[8] = rnds[8] & 63 | 128;
	if (buf) {
		offset = offset || 0;
		if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
		for (let i = 0; i < 16; ++i) buf[offset + i] = rnds[i];
		return buf;
	}
	return unsafeStringify(rnds);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/sha1.js
function f(s, x, y, z) {
	switch (s) {
		case 0: return x & y ^ ~x & z;
		case 1: return x ^ y ^ z;
		case 2: return x & y ^ x & z ^ y & z;
		case 3: return x ^ y ^ z;
	}
}
function ROTL(x, n) {
	return x << n | x >>> 32 - n;
}
function sha1(bytes) {
	const K = [
		1518500249,
		1859775393,
		2400959708,
		3395469782
	];
	const H = [
		1732584193,
		4023233417,
		2562383102,
		271733878,
		3285377520
	];
	const newBytes = new Uint8Array(bytes.length + 1);
	newBytes.set(bytes);
	newBytes[bytes.length] = 128;
	bytes = newBytes;
	const l = bytes.length / 4 + 2;
	const N = Math.ceil(l / 16);
	const M = new Array(N);
	for (let i = 0; i < N; ++i) {
		const arr = /* @__PURE__ */ new Uint32Array(16);
		for (let j = 0; j < 16; ++j) arr[j] = bytes[i * 64 + j * 4] << 24 | bytes[i * 64 + j * 4 + 1] << 16 | bytes[i * 64 + j * 4 + 2] << 8 | bytes[i * 64 + j * 4 + 3];
		M[i] = arr;
	}
	M[N - 1][14] = (bytes.length - 1) * 8 / Math.pow(2, 32);
	M[N - 1][14] = Math.floor(M[N - 1][14]);
	M[N - 1][15] = (bytes.length - 1) * 8 & 4294967295;
	for (let i = 0; i < N; ++i) {
		const W = /* @__PURE__ */ new Uint32Array(80);
		for (let t = 0; t < 16; ++t) W[t] = M[i][t];
		for (let t = 16; t < 80; ++t) W[t] = ROTL(W[t - 3] ^ W[t - 8] ^ W[t - 14] ^ W[t - 16], 1);
		let a = H[0];
		let b = H[1];
		let c = H[2];
		let d = H[3];
		let e = H[4];
		for (let t = 0; t < 80; ++t) {
			const s = Math.floor(t / 20);
			const T = ROTL(a, 5) + f(s, b, c, d) + e + K[s] + W[t] >>> 0;
			e = d;
			d = c;
			c = ROTL(b, 30) >>> 0;
			b = a;
			a = T;
		}
		H[0] = H[0] + a >>> 0;
		H[1] = H[1] + b >>> 0;
		H[2] = H[2] + c >>> 0;
		H[3] = H[3] + d >>> 0;
		H[4] = H[4] + e >>> 0;
	}
	return Uint8Array.of(H[0] >> 24, H[0] >> 16, H[0] >> 8, H[0], H[1] >> 24, H[1] >> 16, H[1] >> 8, H[1], H[2] >> 24, H[2] >> 16, H[2] >> 8, H[2], H[3] >> 24, H[3] >> 16, H[3] >> 8, H[3], H[4] >> 24, H[4] >> 16, H[4] >> 8, H[4]);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v5.js
function v5(value, namespace, buf, offset) {
	return v35(80, sha1, value, namespace, buf, offset);
}
v5.DNS = DNS;
v5.URL = URL;
//#endregion
//#region node_modules/uuid/dist/esm-browser/v6.js
function v6(options, buf, offset) {
	var _options, _offset;
	(_options = options) !== null && _options !== void 0 || (options = {});
	(_offset = offset) !== null && _offset !== void 0 || (offset = 0);
	let bytes = v1(_objectSpread2(_objectSpread2({}, options), {}, { _v6: true }), /* @__PURE__ */ new Uint8Array(16));
	bytes = v1ToV6(bytes);
	if (buf) {
		if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
		for (let i = 0; i < 16; i++) buf[offset + i] = bytes[i];
		return buf;
	}
	return unsafeStringify(bytes);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v6ToV1.js
function v6ToV1(uuid) {
	const v1Bytes = _v6ToV1(typeof uuid === "string" ? parse(uuid) : uuid);
	return typeof uuid === "string" ? unsafeStringify(v1Bytes) : v1Bytes;
}
function _v6ToV1(v6Bytes) {
	return Uint8Array.of((v6Bytes[3] & 15) << 4 | v6Bytes[4] >> 4 & 15, (v6Bytes[4] & 15) << 4 | (v6Bytes[5] & 240) >> 4, (v6Bytes[5] & 15) << 4 | v6Bytes[6] & 15, v6Bytes[7], (v6Bytes[1] & 15) << 4 | (v6Bytes[2] & 240) >> 4, (v6Bytes[2] & 15) << 4 | (v6Bytes[3] & 240) >> 4, 16 | (v6Bytes[0] & 240) >> 4, (v6Bytes[0] & 15) << 4 | (v6Bytes[1] & 240) >> 4, v6Bytes[8], v6Bytes[9], v6Bytes[10], v6Bytes[11], v6Bytes[12], v6Bytes[13], v6Bytes[14], v6Bytes[15]);
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/v7.js
var _state = {};
function v7(options, buf, offset) {
	let bytes;
	if (options) {
		var _ref, _options$random, _options$rng;
		bytes = v7Bytes((_ref = (_options$random = options.random) !== null && _options$random !== void 0 ? _options$random : (_options$rng = options.rng) === null || _options$rng === void 0 ? void 0 : _options$rng.call(options)) !== null && _ref !== void 0 ? _ref : rng(), options.msecs, options.seq, buf, offset);
	} else {
		const now = Date.now();
		const rnds = rng();
		updateV7State(_state, now, rnds);
		bytes = v7Bytes(rnds, _state.msecs, _state.seq, buf, offset);
	}
	return buf !== null && buf !== void 0 ? buf : unsafeStringify(bytes);
}
function updateV7State(state, now, rnds) {
	var _state$msecs, _state$seq;
	(_state$msecs = state.msecs) !== null && _state$msecs !== void 0 || (state.msecs = -Infinity);
	(_state$seq = state.seq) !== null && _state$seq !== void 0 || (state.seq = 0);
	if (now > state.msecs) {
		state.seq = rnds[6] << 23 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
		state.msecs = now;
	} else {
		state.seq = state.seq + 1 | 0;
		if (state.seq === 0) state.msecs++;
	}
	return state;
}
function v7Bytes(rnds, msecs, seq, buf, offset = 0) {
	var _msecs, _seq;
	if (rnds.length < 16) throw new Error("Random bytes length must be >= 16");
	if (!buf) {
		buf = /* @__PURE__ */ new Uint8Array(16);
		offset = 0;
	} else if (offset < 0 || offset + 16 > buf.length) throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
	(_msecs = msecs) !== null && _msecs !== void 0 || (msecs = Date.now());
	(_seq = seq) !== null && _seq !== void 0 || (seq = rnds[6] * 127 << 24 | rnds[7] << 16 | rnds[8] << 8 | rnds[9]);
	buf[offset++] = msecs / 1099511627776 & 255;
	buf[offset++] = msecs / 4294967296 & 255;
	buf[offset++] = msecs / 16777216 & 255;
	buf[offset++] = msecs / 65536 & 255;
	buf[offset++] = msecs / 256 & 255;
	buf[offset++] = msecs & 255;
	buf[offset++] = 112 | seq >>> 28 & 15;
	buf[offset++] = seq >>> 20 & 255;
	buf[offset++] = 128 | seq >>> 14 & 63;
	buf[offset++] = seq >>> 6 & 255;
	buf[offset++] = seq << 2 & 255 | rnds[10] & 3;
	buf[offset++] = rnds[11];
	buf[offset++] = rnds[12];
	buf[offset++] = rnds[13];
	buf[offset++] = rnds[14];
	buf[offset++] = rnds[15];
	return buf;
}
//#endregion
//#region node_modules/uuid/dist/esm-browser/version.js
function version(uuid) {
	if (!validate(uuid)) throw TypeError("Invalid UUID");
	return parseInt(uuid.slice(14, 15), 16);
}
//#endregion
export { max_default as MAX, nil_default as NIL, parse, stringify, v1, v1ToV6, v3, v4, v5, v6, v6ToV1, v7, validate, version };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXVpZC5qcyIsIm5hbWVzIjpbIlJFR0VYIiwiX3N0YXRlIiwibmF0aXZlIl0sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci9tYXguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXVpZC9kaXN0L2VzbS1icm93c2VyL25pbC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dWlkL2Rpc3QvZXNtLWJyb3dzZXIvcmVnZXguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXVpZC9kaXN0L2VzbS1icm93c2VyL3ZhbGlkYXRlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci9wYXJzZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dWlkL2Rpc3QvZXNtLWJyb3dzZXIvc3RyaW5naWZ5LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci9ybmcuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXVpZC9kaXN0L2VzbS1icm93c2VyL3YxLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci92MVRvVjYuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXVpZC9kaXN0L2VzbS1icm93c2VyL21kNS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dWlkL2Rpc3QvZXNtLWJyb3dzZXIvdjM1LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci92My5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dWlkL2Rpc3QvZXNtLWJyb3dzZXIvbmF0aXZlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci92NC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dWlkL2Rpc3QvZXNtLWJyb3dzZXIvc2hhMS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy91dWlkL2Rpc3QvZXNtLWJyb3dzZXIvdjUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXVpZC9kaXN0L2VzbS1icm93c2VyL3Y2LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci92NlRvVjEuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdXVpZC9kaXN0L2VzbS1icm93c2VyL3Y3LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3V1aWQvZGlzdC9lc20tYnJvd3Nlci92ZXJzaW9uLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0ICdmZmZmZmZmZi1mZmZmLWZmZmYtZmZmZi1mZmZmZmZmZmZmZmYnO1xuIiwiZXhwb3J0IGRlZmF1bHQgJzAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMCc7XG4iLCJleHBvcnQgZGVmYXVsdCAvXig/OlswLTlhLWZdezh9LVswLTlhLWZdezR9LVsxLThdWzAtOWEtZl17M30tWzg5YWJdWzAtOWEtZl17M30tWzAtOWEtZl17MTJ9fDAwMDAwMDAwLTAwMDAtMDAwMC0wMDAwLTAwMDAwMDAwMDAwMHxmZmZmZmZmZi1mZmZmLWZmZmYtZmZmZi1mZmZmZmZmZmZmZmYpJC9pO1xuIiwiaW1wb3J0IFJFR0VYIGZyb20gJy4vcmVnZXguanMnO1xuZnVuY3Rpb24gdmFsaWRhdGUodXVpZCkge1xuICAgIHJldHVybiB0eXBlb2YgdXVpZCA9PT0gJ3N0cmluZycgJiYgUkVHRVgudGVzdCh1dWlkKTtcbn1cbmV4cG9ydCBkZWZhdWx0IHZhbGlkYXRlO1xuIiwiaW1wb3J0IHZhbGlkYXRlIGZyb20gJy4vdmFsaWRhdGUuanMnO1xuZnVuY3Rpb24gcGFyc2UodXVpZCkge1xuICAgIGlmICghdmFsaWRhdGUodXVpZCkpIHtcbiAgICAgICAgdGhyb3cgVHlwZUVycm9yKCdJbnZhbGlkIFVVSUQnKTtcbiAgICB9XG4gICAgbGV0IHY7XG4gICAgcmV0dXJuIFVpbnQ4QXJyYXkub2YoKHYgPSBwYXJzZUludCh1dWlkLnNsaWNlKDAsIDgpLCAxNikpID4+PiAyNCwgKHYgPj4+IDE2KSAmIDB4ZmYsICh2ID4+PiA4KSAmIDB4ZmYsIHYgJiAweGZmLCAodiA9IHBhcnNlSW50KHV1aWQuc2xpY2UoOSwgMTMpLCAxNikpID4+PiA4LCB2ICYgMHhmZiwgKHYgPSBwYXJzZUludCh1dWlkLnNsaWNlKDE0LCAxOCksIDE2KSkgPj4+IDgsIHYgJiAweGZmLCAodiA9IHBhcnNlSW50KHV1aWQuc2xpY2UoMTksIDIzKSwgMTYpKSA+Pj4gOCwgdiAmIDB4ZmYsICgodiA9IHBhcnNlSW50KHV1aWQuc2xpY2UoMjQsIDM2KSwgMTYpKSAvIDB4MTAwMDAwMDAwMDApICYgMHhmZiwgKHYgLyAweDEwMDAwMDAwMCkgJiAweGZmLCAodiA+Pj4gMjQpICYgMHhmZiwgKHYgPj4+IDE2KSAmIDB4ZmYsICh2ID4+PiA4KSAmIDB4ZmYsIHYgJiAweGZmKTtcbn1cbmV4cG9ydCBkZWZhdWx0IHBhcnNlO1xuIiwiaW1wb3J0IHZhbGlkYXRlIGZyb20gJy4vdmFsaWRhdGUuanMnO1xuY29uc3QgYnl0ZVRvSGV4ID0gW107XG5mb3IgKGxldCBpID0gMDsgaSA8IDI1NjsgKytpKSB7XG4gICAgYnl0ZVRvSGV4LnB1c2goKGkgKyAweDEwMCkudG9TdHJpbmcoMTYpLnNsaWNlKDEpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1bnNhZmVTdHJpbmdpZnkoYXJyLCBvZmZzZXQgPSAwKSB7XG4gICAgcmV0dXJuIChieXRlVG9IZXhbYXJyW29mZnNldCArIDBdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMV1dICtcbiAgICAgICAgYnl0ZVRvSGV4W2FycltvZmZzZXQgKyAyXV0gK1xuICAgICAgICBieXRlVG9IZXhbYXJyW29mZnNldCArIDNdXSArXG4gICAgICAgICctJyArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgNF1dICtcbiAgICAgICAgYnl0ZVRvSGV4W2FycltvZmZzZXQgKyA1XV0gK1xuICAgICAgICAnLScgK1xuICAgICAgICBieXRlVG9IZXhbYXJyW29mZnNldCArIDZdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgN11dICtcbiAgICAgICAgJy0nICtcbiAgICAgICAgYnl0ZVRvSGV4W2FycltvZmZzZXQgKyA4XV0gK1xuICAgICAgICBieXRlVG9IZXhbYXJyW29mZnNldCArIDldXSArXG4gICAgICAgICctJyArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTBdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTFdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTJdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTNdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTRdXSArXG4gICAgICAgIGJ5dGVUb0hleFthcnJbb2Zmc2V0ICsgMTVdXSkudG9Mb3dlckNhc2UoKTtcbn1cbmZ1bmN0aW9uIHN0cmluZ2lmeShhcnIsIG9mZnNldCA9IDApIHtcbiAgICBjb25zdCB1dWlkID0gdW5zYWZlU3RyaW5naWZ5KGFyciwgb2Zmc2V0KTtcbiAgICBpZiAoIXZhbGlkYXRlKHV1aWQpKSB7XG4gICAgICAgIHRocm93IFR5cGVFcnJvcignU3RyaW5naWZpZWQgVVVJRCBpcyBpbnZhbGlkJyk7XG4gICAgfVxuICAgIHJldHVybiB1dWlkO1xufVxuZXhwb3J0IGRlZmF1bHQgc3RyaW5naWZ5O1xuIiwibGV0IGdldFJhbmRvbVZhbHVlcztcbmNvbnN0IHJuZHM4ID0gbmV3IFVpbnQ4QXJyYXkoMTYpO1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gcm5nKCkge1xuICAgIGlmICghZ2V0UmFuZG9tVmFsdWVzKSB7XG4gICAgICAgIGlmICh0eXBlb2YgY3J5cHRvID09PSAndW5kZWZpbmVkJyB8fCAhY3J5cHRvLmdldFJhbmRvbVZhbHVlcykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKCkgbm90IHN1cHBvcnRlZC4gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS91dWlkanMvdXVpZCNnZXRyYW5kb212YWx1ZXMtbm90LXN1cHBvcnRlZCcpO1xuICAgICAgICB9XG4gICAgICAgIGdldFJhbmRvbVZhbHVlcyA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMuYmluZChjcnlwdG8pO1xuICAgIH1cbiAgICByZXR1cm4gZ2V0UmFuZG9tVmFsdWVzKHJuZHM4KTtcbn1cbiIsImltcG9ydCBybmcgZnJvbSAnLi9ybmcuanMnO1xuaW1wb3J0IHsgdW5zYWZlU3RyaW5naWZ5IH0gZnJvbSAnLi9zdHJpbmdpZnkuanMnO1xuY29uc3QgX3N0YXRlID0ge307XG5mdW5jdGlvbiB2MShvcHRpb25zLCBidWYsIG9mZnNldCkge1xuICAgIGxldCBieXRlcztcbiAgICBjb25zdCBpc1Y2ID0gb3B0aW9ucz8uX3Y2ID8/IGZhbHNlO1xuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IG9wdGlvbnNLZXlzID0gT2JqZWN0LmtleXMob3B0aW9ucyk7XG4gICAgICAgIGlmIChvcHRpb25zS2V5cy5sZW5ndGggPT09IDEgJiYgb3B0aW9uc0tleXNbMF0gPT09ICdfdjYnKSB7XG4gICAgICAgICAgICBvcHRpb25zID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChvcHRpb25zKSB7XG4gICAgICAgIGJ5dGVzID0gdjFCeXRlcyhvcHRpb25zLnJhbmRvbSA/PyBvcHRpb25zLnJuZz8uKCkgPz8gcm5nKCksIG9wdGlvbnMubXNlY3MsIG9wdGlvbnMubnNlY3MsIG9wdGlvbnMuY2xvY2tzZXEsIG9wdGlvbnMubm9kZSwgYnVmLCBvZmZzZXQpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgY29uc3Qgcm5kcyA9IHJuZygpO1xuICAgICAgICB1cGRhdGVWMVN0YXRlKF9zdGF0ZSwgbm93LCBybmRzKTtcbiAgICAgICAgYnl0ZXMgPSB2MUJ5dGVzKHJuZHMsIF9zdGF0ZS5tc2VjcywgX3N0YXRlLm5zZWNzLCBpc1Y2ID8gdW5kZWZpbmVkIDogX3N0YXRlLmNsb2Nrc2VxLCBpc1Y2ID8gdW5kZWZpbmVkIDogX3N0YXRlLm5vZGUsIGJ1Ziwgb2Zmc2V0KTtcbiAgICB9XG4gICAgcmV0dXJuIGJ1ZiA/PyB1bnNhZmVTdHJpbmdpZnkoYnl0ZXMpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZVYxU3RhdGUoc3RhdGUsIG5vdywgcm5kcykge1xuICAgIHN0YXRlLm1zZWNzID8/PSAtSW5maW5pdHk7XG4gICAgc3RhdGUubnNlY3MgPz89IDA7XG4gICAgaWYgKG5vdyA9PT0gc3RhdGUubXNlY3MpIHtcbiAgICAgICAgc3RhdGUubnNlY3MrKztcbiAgICAgICAgaWYgKHN0YXRlLm5zZWNzID49IDEwMDAwKSB7XG4gICAgICAgICAgICBzdGF0ZS5ub2RlID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgc3RhdGUubnNlY3MgPSAwO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2UgaWYgKG5vdyA+IHN0YXRlLm1zZWNzKSB7XG4gICAgICAgIHN0YXRlLm5zZWNzID0gMDtcbiAgICB9XG4gICAgZWxzZSBpZiAobm93IDwgc3RhdGUubXNlY3MpIHtcbiAgICAgICAgc3RhdGUubm9kZSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKCFzdGF0ZS5ub2RlKSB7XG4gICAgICAgIHN0YXRlLm5vZGUgPSBybmRzLnNsaWNlKDEwLCAxNik7XG4gICAgICAgIHN0YXRlLm5vZGVbMF0gfD0gMHgwMTtcbiAgICAgICAgc3RhdGUuY2xvY2tzZXEgPSAoKHJuZHNbOF0gPDwgOCkgfCBybmRzWzldKSAmIDB4M2ZmZjtcbiAgICB9XG4gICAgc3RhdGUubXNlY3MgPSBub3c7XG4gICAgcmV0dXJuIHN0YXRlO1xufVxuZnVuY3Rpb24gdjFCeXRlcyhybmRzLCBtc2VjcywgbnNlY3MsIGNsb2Nrc2VxLCBub2RlLCBidWYsIG9mZnNldCA9IDApIHtcbiAgICBpZiAocm5kcy5sZW5ndGggPCAxNikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JhbmRvbSBieXRlcyBsZW5ndGggbXVzdCBiZSA+PSAxNicpO1xuICAgIH1cbiAgICBpZiAoIWJ1Zikge1xuICAgICAgICBidWYgPSBuZXcgVWludDhBcnJheSgxNik7XG4gICAgICAgIG9mZnNldCA9IDA7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBpZiAob2Zmc2V0IDwgMCB8fCBvZmZzZXQgKyAxNiA+IGJ1Zi5sZW5ndGgpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKGBVVUlEIGJ5dGUgcmFuZ2UgJHtvZmZzZXR9OiR7b2Zmc2V0ICsgMTV9IGlzIG91dCBvZiBidWZmZXIgYm91bmRzYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgbXNlY3MgPz89IERhdGUubm93KCk7XG4gICAgbnNlY3MgPz89IDA7XG4gICAgY2xvY2tzZXEgPz89ICgocm5kc1s4XSA8PCA4KSB8IHJuZHNbOV0pICYgMHgzZmZmO1xuICAgIG5vZGUgPz89IHJuZHMuc2xpY2UoMTAsIDE2KTtcbiAgICBtc2VjcyArPSAxMjIxOTI5MjgwMDAwMDtcbiAgICBjb25zdCB0bCA9ICgobXNlY3MgJiAweGZmZmZmZmYpICogMTAwMDAgKyBuc2VjcykgJSAweDEwMDAwMDAwMDtcbiAgICBidWZbb2Zmc2V0KytdID0gKHRsID4+PiAyNCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAodGwgPj4+IDE2KSAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9ICh0bCA+Pj4gOCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSB0bCAmIDB4ZmY7XG4gICAgY29uc3QgdG1oID0gKChtc2VjcyAvIDB4MTAwMDAwMDAwKSAqIDEwMDAwKSAmIDB4ZmZmZmZmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKHRtaCA+Pj4gOCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSB0bWggJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAoKHRtaCA+Pj4gMjQpICYgMHhmKSB8IDB4MTA7XG4gICAgYnVmW29mZnNldCsrXSA9ICh0bWggPj4+IDE2KSAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9IChjbG9ja3NlcSA+Pj4gOCkgfCAweDgwO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBjbG9ja3NlcSAmIDB4ZmY7XG4gICAgZm9yIChsZXQgbiA9IDA7IG4gPCA2OyArK24pIHtcbiAgICAgICAgYnVmW29mZnNldCsrXSA9IG5vZGVbbl07XG4gICAgfVxuICAgIHJldHVybiBidWY7XG59XG5leHBvcnQgZGVmYXVsdCB2MTtcbiIsImltcG9ydCBwYXJzZSBmcm9tICcuL3BhcnNlLmpzJztcbmltcG9ydCB7IHVuc2FmZVN0cmluZ2lmeSB9IGZyb20gJy4vc3RyaW5naWZ5LmpzJztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHYxVG9WNih1dWlkKSB7XG4gICAgY29uc3QgdjFCeXRlcyA9IHR5cGVvZiB1dWlkID09PSAnc3RyaW5nJyA/IHBhcnNlKHV1aWQpIDogdXVpZDtcbiAgICBjb25zdCB2NkJ5dGVzID0gX3YxVG9WNih2MUJ5dGVzKTtcbiAgICByZXR1cm4gdHlwZW9mIHV1aWQgPT09ICdzdHJpbmcnID8gdW5zYWZlU3RyaW5naWZ5KHY2Qnl0ZXMpIDogdjZCeXRlcztcbn1cbmZ1bmN0aW9uIF92MVRvVjYodjFCeXRlcykge1xuICAgIHJldHVybiBVaW50OEFycmF5Lm9mKCgodjFCeXRlc1s2XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzddID4+IDQpICYgMHgwZiksICgodjFCeXRlc1s3XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzRdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1s0XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzVdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1s1XSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzBdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1swXSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzFdICYgMHhmMCkgPj4gNCksICgodjFCeXRlc1sxXSAmIDB4MGYpIDw8IDQpIHwgKCh2MUJ5dGVzWzJdICYgMHhmMCkgPj4gNCksIDB4NjAgfCAodjFCeXRlc1syXSAmIDB4MGYpLCB2MUJ5dGVzWzNdLCB2MUJ5dGVzWzhdLCB2MUJ5dGVzWzldLCB2MUJ5dGVzWzEwXSwgdjFCeXRlc1sxMV0sIHYxQnl0ZXNbMTJdLCB2MUJ5dGVzWzEzXSwgdjFCeXRlc1sxNF0sIHYxQnl0ZXNbMTVdKTtcbn1cbiIsImZ1bmN0aW9uIG1kNShieXRlcykge1xuICAgIGNvbnN0IHdvcmRzID0gdWludDhUb1VpbnQzMihieXRlcyk7XG4gICAgY29uc3QgbWQ1Qnl0ZXMgPSB3b3Jkc1RvTWQ1KHdvcmRzLCBieXRlcy5sZW5ndGggKiA4KTtcbiAgICByZXR1cm4gdWludDMyVG9VaW50OChtZDVCeXRlcyk7XG59XG5mdW5jdGlvbiB1aW50MzJUb1VpbnQ4KGlucHV0KSB7XG4gICAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShpbnB1dC5sZW5ndGggKiA0KTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGlucHV0Lmxlbmd0aCAqIDQ7IGkrKykge1xuICAgICAgICBieXRlc1tpXSA9IChpbnB1dFtpID4+IDJdID4+PiAoKGkgJSA0KSAqIDgpKSAmIDB4ZmY7XG4gICAgfVxuICAgIHJldHVybiBieXRlcztcbn1cbmZ1bmN0aW9uIGdldE91dHB1dExlbmd0aChpbnB1dExlbmd0aDgpIHtcbiAgICByZXR1cm4gKCgoaW5wdXRMZW5ndGg4ICsgNjQpID4+PiA5KSA8PCA0KSArIDE0ICsgMTtcbn1cbmZ1bmN0aW9uIHdvcmRzVG9NZDUoeCwgbGVuKSB7XG4gICAgY29uc3QgeHBhZCA9IG5ldyBVaW50MzJBcnJheShnZXRPdXRwdXRMZW5ndGgobGVuKSkuZmlsbCgwKTtcbiAgICB4cGFkLnNldCh4KTtcbiAgICB4cGFkW2xlbiA+PiA1XSB8PSAweDgwIDw8IGxlbiAlIDMyO1xuICAgIHhwYWRbeHBhZC5sZW5ndGggLSAxXSA9IGxlbjtcbiAgICB4ID0geHBhZDtcbiAgICBsZXQgYSA9IDE3MzI1ODQxOTM7XG4gICAgbGV0IGIgPSAtMjcxNzMzODc5O1xuICAgIGxldCBjID0gLTE3MzI1ODQxOTQ7XG4gICAgbGV0IGQgPSAyNzE3MzM4Nzg7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB4Lmxlbmd0aDsgaSArPSAxNikge1xuICAgICAgICBjb25zdCBvbGRhID0gYTtcbiAgICAgICAgY29uc3Qgb2xkYiA9IGI7XG4gICAgICAgIGNvbnN0IG9sZGMgPSBjO1xuICAgICAgICBjb25zdCBvbGRkID0gZDtcbiAgICAgICAgYSA9IG1kNWZmKGEsIGIsIGMsIGQsIHhbaV0sIDcsIC02ODA4NzY5MzYpO1xuICAgICAgICBkID0gbWQ1ZmYoZCwgYSwgYiwgYywgeFtpICsgMV0sIDEyLCAtMzg5NTY0NTg2KTtcbiAgICAgICAgYyA9IG1kNWZmKGMsIGQsIGEsIGIsIHhbaSArIDJdLCAxNywgNjA2MTA1ODE5KTtcbiAgICAgICAgYiA9IG1kNWZmKGIsIGMsIGQsIGEsIHhbaSArIDNdLCAyMiwgLTEwNDQ1MjUzMzApO1xuICAgICAgICBhID0gbWQ1ZmYoYSwgYiwgYywgZCwgeFtpICsgNF0sIDcsIC0xNzY0MTg4OTcpO1xuICAgICAgICBkID0gbWQ1ZmYoZCwgYSwgYiwgYywgeFtpICsgNV0sIDEyLCAxMjAwMDgwNDI2KTtcbiAgICAgICAgYyA9IG1kNWZmKGMsIGQsIGEsIGIsIHhbaSArIDZdLCAxNywgLTE0NzMyMzEzNDEpO1xuICAgICAgICBiID0gbWQ1ZmYoYiwgYywgZCwgYSwgeFtpICsgN10sIDIyLCAtNDU3MDU5ODMpO1xuICAgICAgICBhID0gbWQ1ZmYoYSwgYiwgYywgZCwgeFtpICsgOF0sIDcsIDE3NzAwMzU0MTYpO1xuICAgICAgICBkID0gbWQ1ZmYoZCwgYSwgYiwgYywgeFtpICsgOV0sIDEyLCAtMTk1ODQxNDQxNyk7XG4gICAgICAgIGMgPSBtZDVmZihjLCBkLCBhLCBiLCB4W2kgKyAxMF0sIDE3LCAtNDIwNjMpO1xuICAgICAgICBiID0gbWQ1ZmYoYiwgYywgZCwgYSwgeFtpICsgMTFdLCAyMiwgLTE5OTA0MDQxNjIpO1xuICAgICAgICBhID0gbWQ1ZmYoYSwgYiwgYywgZCwgeFtpICsgMTJdLCA3LCAxODA0NjAzNjgyKTtcbiAgICAgICAgZCA9IG1kNWZmKGQsIGEsIGIsIGMsIHhbaSArIDEzXSwgMTIsIC00MDM0MTEwMSk7XG4gICAgICAgIGMgPSBtZDVmZihjLCBkLCBhLCBiLCB4W2kgKyAxNF0sIDE3LCAtMTUwMjAwMjI5MCk7XG4gICAgICAgIGIgPSBtZDVmZihiLCBjLCBkLCBhLCB4W2kgKyAxNV0sIDIyLCAxMjM2NTM1MzI5KTtcbiAgICAgICAgYSA9IG1kNWdnKGEsIGIsIGMsIGQsIHhbaSArIDFdLCA1LCAtMTY1Nzk2NTEwKTtcbiAgICAgICAgZCA9IG1kNWdnKGQsIGEsIGIsIGMsIHhbaSArIDZdLCA5LCAtMTA2OTUwMTYzMik7XG4gICAgICAgIGMgPSBtZDVnZyhjLCBkLCBhLCBiLCB4W2kgKyAxMV0sIDE0LCA2NDM3MTc3MTMpO1xuICAgICAgICBiID0gbWQ1Z2coYiwgYywgZCwgYSwgeFtpXSwgMjAsIC0zNzM4OTczMDIpO1xuICAgICAgICBhID0gbWQ1Z2coYSwgYiwgYywgZCwgeFtpICsgNV0sIDUsIC03MDE1NTg2OTEpO1xuICAgICAgICBkID0gbWQ1Z2coZCwgYSwgYiwgYywgeFtpICsgMTBdLCA5LCAzODAxNjA4Myk7XG4gICAgICAgIGMgPSBtZDVnZyhjLCBkLCBhLCBiLCB4W2kgKyAxNV0sIDE0LCAtNjYwNDc4MzM1KTtcbiAgICAgICAgYiA9IG1kNWdnKGIsIGMsIGQsIGEsIHhbaSArIDRdLCAyMCwgLTQwNTUzNzg0OCk7XG4gICAgICAgIGEgPSBtZDVnZyhhLCBiLCBjLCBkLCB4W2kgKyA5XSwgNSwgNTY4NDQ2NDM4KTtcbiAgICAgICAgZCA9IG1kNWdnKGQsIGEsIGIsIGMsIHhbaSArIDE0XSwgOSwgLTEwMTk4MDM2OTApO1xuICAgICAgICBjID0gbWQ1Z2coYywgZCwgYSwgYiwgeFtpICsgM10sIDE0LCAtMTg3MzYzOTYxKTtcbiAgICAgICAgYiA9IG1kNWdnKGIsIGMsIGQsIGEsIHhbaSArIDhdLCAyMCwgMTE2MzUzMTUwMSk7XG4gICAgICAgIGEgPSBtZDVnZyhhLCBiLCBjLCBkLCB4W2kgKyAxM10sIDUsIC0xNDQ0NjgxNDY3KTtcbiAgICAgICAgZCA9IG1kNWdnKGQsIGEsIGIsIGMsIHhbaSArIDJdLCA5LCAtNTE0MDM3ODQpO1xuICAgICAgICBjID0gbWQ1Z2coYywgZCwgYSwgYiwgeFtpICsgN10sIDE0LCAxNzM1MzI4NDczKTtcbiAgICAgICAgYiA9IG1kNWdnKGIsIGMsIGQsIGEsIHhbaSArIDEyXSwgMjAsIC0xOTI2NjA3NzM0KTtcbiAgICAgICAgYSA9IG1kNWhoKGEsIGIsIGMsIGQsIHhbaSArIDVdLCA0LCAtMzc4NTU4KTtcbiAgICAgICAgZCA9IG1kNWhoKGQsIGEsIGIsIGMsIHhbaSArIDhdLCAxMSwgLTIwMjI1NzQ0NjMpO1xuICAgICAgICBjID0gbWQ1aGgoYywgZCwgYSwgYiwgeFtpICsgMTFdLCAxNiwgMTgzOTAzMDU2Mik7XG4gICAgICAgIGIgPSBtZDVoaChiLCBjLCBkLCBhLCB4W2kgKyAxNF0sIDIzLCAtMzUzMDk1NTYpO1xuICAgICAgICBhID0gbWQ1aGgoYSwgYiwgYywgZCwgeFtpICsgMV0sIDQsIC0xNTMwOTkyMDYwKTtcbiAgICAgICAgZCA9IG1kNWhoKGQsIGEsIGIsIGMsIHhbaSArIDRdLCAxMSwgMTI3Mjg5MzM1Myk7XG4gICAgICAgIGMgPSBtZDVoaChjLCBkLCBhLCBiLCB4W2kgKyA3XSwgMTYsIC0xNTU0OTc2MzIpO1xuICAgICAgICBiID0gbWQ1aGgoYiwgYywgZCwgYSwgeFtpICsgMTBdLCAyMywgLTEwOTQ3MzA2NDApO1xuICAgICAgICBhID0gbWQ1aGgoYSwgYiwgYywgZCwgeFtpICsgMTNdLCA0LCA2ODEyNzkxNzQpO1xuICAgICAgICBkID0gbWQ1aGgoZCwgYSwgYiwgYywgeFtpXSwgMTEsIC0zNTg1MzcyMjIpO1xuICAgICAgICBjID0gbWQ1aGgoYywgZCwgYSwgYiwgeFtpICsgM10sIDE2LCAtNzIyNTIxOTc5KTtcbiAgICAgICAgYiA9IG1kNWhoKGIsIGMsIGQsIGEsIHhbaSArIDZdLCAyMywgNzYwMjkxODkpO1xuICAgICAgICBhID0gbWQ1aGgoYSwgYiwgYywgZCwgeFtpICsgOV0sIDQsIC02NDAzNjQ0ODcpO1xuICAgICAgICBkID0gbWQ1aGgoZCwgYSwgYiwgYywgeFtpICsgMTJdLCAxMSwgLTQyMTgxNTgzNSk7XG4gICAgICAgIGMgPSBtZDVoaChjLCBkLCBhLCBiLCB4W2kgKyAxNV0sIDE2LCA1MzA3NDI1MjApO1xuICAgICAgICBiID0gbWQ1aGgoYiwgYywgZCwgYSwgeFtpICsgMl0sIDIzLCAtOTk1MzM4NjUxKTtcbiAgICAgICAgYSA9IG1kNWlpKGEsIGIsIGMsIGQsIHhbaV0sIDYsIC0xOTg2MzA4NDQpO1xuICAgICAgICBkID0gbWQ1aWkoZCwgYSwgYiwgYywgeFtpICsgN10sIDEwLCAxMTI2ODkxNDE1KTtcbiAgICAgICAgYyA9IG1kNWlpKGMsIGQsIGEsIGIsIHhbaSArIDE0XSwgMTUsIC0xNDE2MzU0OTA1KTtcbiAgICAgICAgYiA9IG1kNWlpKGIsIGMsIGQsIGEsIHhbaSArIDVdLCAyMSwgLTU3NDM0MDU1KTtcbiAgICAgICAgYSA9IG1kNWlpKGEsIGIsIGMsIGQsIHhbaSArIDEyXSwgNiwgMTcwMDQ4NTU3MSk7XG4gICAgICAgIGQgPSBtZDVpaShkLCBhLCBiLCBjLCB4W2kgKyAzXSwgMTAsIC0xODk0OTg2NjA2KTtcbiAgICAgICAgYyA9IG1kNWlpKGMsIGQsIGEsIGIsIHhbaSArIDEwXSwgMTUsIC0xMDUxNTIzKTtcbiAgICAgICAgYiA9IG1kNWlpKGIsIGMsIGQsIGEsIHhbaSArIDFdLCAyMSwgLTIwNTQ5MjI3OTkpO1xuICAgICAgICBhID0gbWQ1aWkoYSwgYiwgYywgZCwgeFtpICsgOF0sIDYsIDE4NzMzMTMzNTkpO1xuICAgICAgICBkID0gbWQ1aWkoZCwgYSwgYiwgYywgeFtpICsgMTVdLCAxMCwgLTMwNjExNzQ0KTtcbiAgICAgICAgYyA9IG1kNWlpKGMsIGQsIGEsIGIsIHhbaSArIDZdLCAxNSwgLTE1NjAxOTgzODApO1xuICAgICAgICBiID0gbWQ1aWkoYiwgYywgZCwgYSwgeFtpICsgMTNdLCAyMSwgMTMwOTE1MTY0OSk7XG4gICAgICAgIGEgPSBtZDVpaShhLCBiLCBjLCBkLCB4W2kgKyA0XSwgNiwgLTE0NTUyMzA3MCk7XG4gICAgICAgIGQgPSBtZDVpaShkLCBhLCBiLCBjLCB4W2kgKyAxMV0sIDEwLCAtMTEyMDIxMDM3OSk7XG4gICAgICAgIGMgPSBtZDVpaShjLCBkLCBhLCBiLCB4W2kgKyAyXSwgMTUsIDcxODc4NzI1OSk7XG4gICAgICAgIGIgPSBtZDVpaShiLCBjLCBkLCBhLCB4W2kgKyA5XSwgMjEsIC0zNDM0ODU1NTEpO1xuICAgICAgICBhID0gc2FmZUFkZChhLCBvbGRhKTtcbiAgICAgICAgYiA9IHNhZmVBZGQoYiwgb2xkYik7XG4gICAgICAgIGMgPSBzYWZlQWRkKGMsIG9sZGMpO1xuICAgICAgICBkID0gc2FmZUFkZChkLCBvbGRkKTtcbiAgICB9XG4gICAgcmV0dXJuIFVpbnQzMkFycmF5Lm9mKGEsIGIsIGMsIGQpO1xufVxuZnVuY3Rpb24gdWludDhUb1VpbnQzMihpbnB1dCkge1xuICAgIGlmIChpbnB1dC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIG5ldyBVaW50MzJBcnJheSgpO1xuICAgIH1cbiAgICBjb25zdCBvdXRwdXQgPSBuZXcgVWludDMyQXJyYXkoZ2V0T3V0cHV0TGVuZ3RoKGlucHV0Lmxlbmd0aCAqIDgpKS5maWxsKDApO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgb3V0cHV0W2kgPj4gMl0gfD0gKGlucHV0W2ldICYgMHhmZikgPDwgKChpICUgNCkgKiA4KTtcbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbn1cbmZ1bmN0aW9uIHNhZmVBZGQoeCwgeSkge1xuICAgIGNvbnN0IGxzdyA9ICh4ICYgMHhmZmZmKSArICh5ICYgMHhmZmZmKTtcbiAgICBjb25zdCBtc3cgPSAoeCA+PiAxNikgKyAoeSA+PiAxNikgKyAobHN3ID4+IDE2KTtcbiAgICByZXR1cm4gKG1zdyA8PCAxNikgfCAobHN3ICYgMHhmZmZmKTtcbn1cbmZ1bmN0aW9uIGJpdFJvdGF0ZUxlZnQobnVtLCBjbnQpIHtcbiAgICByZXR1cm4gKG51bSA8PCBjbnQpIHwgKG51bSA+Pj4gKDMyIC0gY250KSk7XG59XG5mdW5jdGlvbiBtZDVjbW4ocSwgYSwgYiwgeCwgcywgdCkge1xuICAgIHJldHVybiBzYWZlQWRkKGJpdFJvdGF0ZUxlZnQoc2FmZUFkZChzYWZlQWRkKGEsIHEpLCBzYWZlQWRkKHgsIHQpKSwgcyksIGIpO1xufVxuZnVuY3Rpb24gbWQ1ZmYoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuICAgIHJldHVybiBtZDVjbW4oKGIgJiBjKSB8ICh+YiAmIGQpLCBhLCBiLCB4LCBzLCB0KTtcbn1cbmZ1bmN0aW9uIG1kNWdnKGEsIGIsIGMsIGQsIHgsIHMsIHQpIHtcbiAgICByZXR1cm4gbWQ1Y21uKChiICYgZCkgfCAoYyAmIH5kKSwgYSwgYiwgeCwgcywgdCk7XG59XG5mdW5jdGlvbiBtZDVoaChhLCBiLCBjLCBkLCB4LCBzLCB0KSB7XG4gICAgcmV0dXJuIG1kNWNtbihiIF4gYyBeIGQsIGEsIGIsIHgsIHMsIHQpO1xufVxuZnVuY3Rpb24gbWQ1aWkoYSwgYiwgYywgZCwgeCwgcywgdCkge1xuICAgIHJldHVybiBtZDVjbW4oYyBeIChiIHwgfmQpLCBhLCBiLCB4LCBzLCB0KTtcbn1cbmV4cG9ydCBkZWZhdWx0IG1kNTtcbiIsImltcG9ydCBwYXJzZSBmcm9tICcuL3BhcnNlLmpzJztcbmltcG9ydCB7IHVuc2FmZVN0cmluZ2lmeSB9IGZyb20gJy4vc3RyaW5naWZ5LmpzJztcbmV4cG9ydCBmdW5jdGlvbiBzdHJpbmdUb0J5dGVzKHN0cikge1xuICAgIHN0ciA9IHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChzdHIpKTtcbiAgICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KHN0ci5sZW5ndGgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgKytpKSB7XG4gICAgICAgIGJ5dGVzW2ldID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgfVxuICAgIHJldHVybiBieXRlcztcbn1cbmV4cG9ydCBjb25zdCBETlMgPSAnNmJhN2I4MTAtOWRhZC0xMWQxLTgwYjQtMDBjMDRmZDQzMGM4JztcbmV4cG9ydCBjb25zdCBVUkwgPSAnNmJhN2I4MTEtOWRhZC0xMWQxLTgwYjQtMDBjMDRmZDQzMGM4JztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHYzNSh2ZXJzaW9uLCBoYXNoLCB2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCkge1xuICAgIGNvbnN0IHZhbHVlQnl0ZXMgPSB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnID8gc3RyaW5nVG9CeXRlcyh2YWx1ZSkgOiB2YWx1ZTtcbiAgICBjb25zdCBuYW1lc3BhY2VCeXRlcyA9IHR5cGVvZiBuYW1lc3BhY2UgPT09ICdzdHJpbmcnID8gcGFyc2UobmFtZXNwYWNlKSA6IG5hbWVzcGFjZTtcbiAgICBpZiAodHlwZW9mIG5hbWVzcGFjZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgbmFtZXNwYWNlID0gcGFyc2UobmFtZXNwYWNlKTtcbiAgICB9XG4gICAgaWYgKG5hbWVzcGFjZT8ubGVuZ3RoICE9PSAxNikge1xuICAgICAgICB0aHJvdyBUeXBlRXJyb3IoJ05hbWVzcGFjZSBtdXN0IGJlIGFycmF5LWxpa2UgKDE2IGl0ZXJhYmxlIGludGVnZXIgdmFsdWVzLCAwLTI1NSknKTtcbiAgICB9XG4gICAgbGV0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoMTYgKyB2YWx1ZUJ5dGVzLmxlbmd0aCk7XG4gICAgYnl0ZXMuc2V0KG5hbWVzcGFjZUJ5dGVzKTtcbiAgICBieXRlcy5zZXQodmFsdWVCeXRlcywgbmFtZXNwYWNlQnl0ZXMubGVuZ3RoKTtcbiAgICBieXRlcyA9IGhhc2goYnl0ZXMpO1xuICAgIGJ5dGVzWzZdID0gKGJ5dGVzWzZdICYgMHgwZikgfCB2ZXJzaW9uO1xuICAgIGJ5dGVzWzhdID0gKGJ5dGVzWzhdICYgMHgzZikgfCAweDgwO1xuICAgIGlmIChidWYpIHtcbiAgICAgICAgb2Zmc2V0ID0gb2Zmc2V0IHx8IDA7XG4gICAgICAgIGlmIChvZmZzZXQgPCAwIHx8IG9mZnNldCArIDE2ID4gYnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYFVVSUQgYnl0ZSByYW5nZSAke29mZnNldH06JHtvZmZzZXQgKyAxNX0gaXMgb3V0IG9mIGJ1ZmZlciBib3VuZHNgKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDE2OyArK2kpIHtcbiAgICAgICAgICAgIGJ1ZltvZmZzZXQgKyBpXSA9IGJ5dGVzW2ldO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBidWY7XG4gICAgfVxuICAgIHJldHVybiB1bnNhZmVTdHJpbmdpZnkoYnl0ZXMpO1xufVxuIiwiaW1wb3J0IG1kNSBmcm9tICcuL21kNS5qcyc7XG5pbXBvcnQgdjM1LCB7IEROUywgVVJMIH0gZnJvbSAnLi92MzUuanMnO1xuZXhwb3J0IHsgRE5TLCBVUkwgfSBmcm9tICcuL3YzNS5qcyc7XG5mdW5jdGlvbiB2Myh2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCkge1xuICAgIHJldHVybiB2MzUoMHgzMCwgbWQ1LCB2YWx1ZSwgbmFtZXNwYWNlLCBidWYsIG9mZnNldCk7XG59XG52My5ETlMgPSBETlM7XG52My5VUkwgPSBVUkw7XG5leHBvcnQgZGVmYXVsdCB2MztcbiIsImNvbnN0IHJhbmRvbVVVSUQgPSB0eXBlb2YgY3J5cHRvICE9PSAndW5kZWZpbmVkJyAmJiBjcnlwdG8ucmFuZG9tVVVJRCAmJiBjcnlwdG8ucmFuZG9tVVVJRC5iaW5kKGNyeXB0byk7XG5leHBvcnQgZGVmYXVsdCB7IHJhbmRvbVVVSUQgfTtcbiIsImltcG9ydCBuYXRpdmUgZnJvbSAnLi9uYXRpdmUuanMnO1xuaW1wb3J0IHJuZyBmcm9tICcuL3JuZy5qcyc7XG5pbXBvcnQgeyB1bnNhZmVTdHJpbmdpZnkgfSBmcm9tICcuL3N0cmluZ2lmeS5qcyc7XG5mdW5jdGlvbiB2NChvcHRpb25zLCBidWYsIG9mZnNldCkge1xuICAgIGlmIChuYXRpdmUucmFuZG9tVVVJRCAmJiAhYnVmICYmICFvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiBuYXRpdmUucmFuZG9tVVVJRCgpO1xuICAgIH1cbiAgICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgICBjb25zdCBybmRzID0gb3B0aW9ucy5yYW5kb20gPz8gb3B0aW9ucy5ybmc/LigpID8/IHJuZygpO1xuICAgIGlmIChybmRzLmxlbmd0aCA8IDE2KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUmFuZG9tIGJ5dGVzIGxlbmd0aCBtdXN0IGJlID49IDE2Jyk7XG4gICAgfVxuICAgIHJuZHNbNl0gPSAocm5kc1s2XSAmIDB4MGYpIHwgMHg0MDtcbiAgICBybmRzWzhdID0gKHJuZHNbOF0gJiAweDNmKSB8IDB4ODA7XG4gICAgaWYgKGJ1Zikge1xuICAgICAgICBvZmZzZXQgPSBvZmZzZXQgfHwgMDtcbiAgICAgICAgaWYgKG9mZnNldCA8IDAgfHwgb2Zmc2V0ICsgMTYgPiBidWYubGVuZ3RoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgVVVJRCBieXRlIHJhbmdlICR7b2Zmc2V0fToke29mZnNldCArIDE1fSBpcyBvdXQgb2YgYnVmZmVyIGJvdW5kc2ApO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMTY7ICsraSkge1xuICAgICAgICAgICAgYnVmW29mZnNldCArIGldID0gcm5kc1tpXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnVmO1xuICAgIH1cbiAgICByZXR1cm4gdW5zYWZlU3RyaW5naWZ5KHJuZHMpO1xufVxuZXhwb3J0IGRlZmF1bHQgdjQ7XG4iLCJmdW5jdGlvbiBmKHMsIHgsIHksIHopIHtcbiAgICBzd2l0Y2ggKHMpIHtcbiAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgcmV0dXJuICh4ICYgeSkgXiAofnggJiB6KTtcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgcmV0dXJuIHggXiB5IF4gejtcbiAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgcmV0dXJuICh4ICYgeSkgXiAoeCAmIHopIF4gKHkgJiB6KTtcbiAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgcmV0dXJuIHggXiB5IF4gejtcbiAgICB9XG59XG5mdW5jdGlvbiBST1RMKHgsIG4pIHtcbiAgICByZXR1cm4gKHggPDwgbikgfCAoeCA+Pj4gKDMyIC0gbikpO1xufVxuZnVuY3Rpb24gc2hhMShieXRlcykge1xuICAgIGNvbnN0IEsgPSBbMHg1YTgyNzk5OSwgMHg2ZWQ5ZWJhMSwgMHg4ZjFiYmNkYywgMHhjYTYyYzFkNl07XG4gICAgY29uc3QgSCA9IFsweDY3NDUyMzAxLCAweGVmY2RhYjg5LCAweDk4YmFkY2ZlLCAweDEwMzI1NDc2LCAweGMzZDJlMWYwXTtcbiAgICBjb25zdCBuZXdCeXRlcyA9IG5ldyBVaW50OEFycmF5KGJ5dGVzLmxlbmd0aCArIDEpO1xuICAgIG5ld0J5dGVzLnNldChieXRlcyk7XG4gICAgbmV3Qnl0ZXNbYnl0ZXMubGVuZ3RoXSA9IDB4ODA7XG4gICAgYnl0ZXMgPSBuZXdCeXRlcztcbiAgICBjb25zdCBsID0gYnl0ZXMubGVuZ3RoIC8gNCArIDI7XG4gICAgY29uc3QgTiA9IE1hdGguY2VpbChsIC8gMTYpO1xuICAgIGNvbnN0IE0gPSBuZXcgQXJyYXkoTik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBOOyArK2kpIHtcbiAgICAgICAgY29uc3QgYXJyID0gbmV3IFVpbnQzMkFycmF5KDE2KTtcbiAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCAxNjsgKytqKSB7XG4gICAgICAgICAgICBhcnJbal0gPVxuICAgICAgICAgICAgICAgIChieXRlc1tpICogNjQgKyBqICogNF0gPDwgMjQpIHxcbiAgICAgICAgICAgICAgICAgICAgKGJ5dGVzW2kgKiA2NCArIGogKiA0ICsgMV0gPDwgMTYpIHxcbiAgICAgICAgICAgICAgICAgICAgKGJ5dGVzW2kgKiA2NCArIGogKiA0ICsgMl0gPDwgOCkgfFxuICAgICAgICAgICAgICAgICAgICBieXRlc1tpICogNjQgKyBqICogNCArIDNdO1xuICAgICAgICB9XG4gICAgICAgIE1baV0gPSBhcnI7XG4gICAgfVxuICAgIE1bTiAtIDFdWzE0XSA9ICgoYnl0ZXMubGVuZ3RoIC0gMSkgKiA4KSAvIE1hdGgucG93KDIsIDMyKTtcbiAgICBNW04gLSAxXVsxNF0gPSBNYXRoLmZsb29yKE1bTiAtIDFdWzE0XSk7XG4gICAgTVtOIC0gMV1bMTVdID0gKChieXRlcy5sZW5ndGggLSAxKSAqIDgpICYgMHhmZmZmZmZmZjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IE47ICsraSkge1xuICAgICAgICBjb25zdCBXID0gbmV3IFVpbnQzMkFycmF5KDgwKTtcbiAgICAgICAgZm9yIChsZXQgdCA9IDA7IHQgPCAxNjsgKyt0KSB7XG4gICAgICAgICAgICBXW3RdID0gTVtpXVt0XTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCB0ID0gMTY7IHQgPCA4MDsgKyt0KSB7XG4gICAgICAgICAgICBXW3RdID0gUk9UTChXW3QgLSAzXSBeIFdbdCAtIDhdIF4gV1t0IC0gMTRdIF4gV1t0IC0gMTZdLCAxKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgYSA9IEhbMF07XG4gICAgICAgIGxldCBiID0gSFsxXTtcbiAgICAgICAgbGV0IGMgPSBIWzJdO1xuICAgICAgICBsZXQgZCA9IEhbM107XG4gICAgICAgIGxldCBlID0gSFs0XTtcbiAgICAgICAgZm9yIChsZXQgdCA9IDA7IHQgPCA4MDsgKyt0KSB7XG4gICAgICAgICAgICBjb25zdCBzID0gTWF0aC5mbG9vcih0IC8gMjApO1xuICAgICAgICAgICAgY29uc3QgVCA9IChST1RMKGEsIDUpICsgZihzLCBiLCBjLCBkKSArIGUgKyBLW3NdICsgV1t0XSkgPj4+IDA7XG4gICAgICAgICAgICBlID0gZDtcbiAgICAgICAgICAgIGQgPSBjO1xuICAgICAgICAgICAgYyA9IFJPVEwoYiwgMzApID4+PiAwO1xuICAgICAgICAgICAgYiA9IGE7XG4gICAgICAgICAgICBhID0gVDtcbiAgICAgICAgfVxuICAgICAgICBIWzBdID0gKEhbMF0gKyBhKSA+Pj4gMDtcbiAgICAgICAgSFsxXSA9IChIWzFdICsgYikgPj4+IDA7XG4gICAgICAgIEhbMl0gPSAoSFsyXSArIGMpID4+PiAwO1xuICAgICAgICBIWzNdID0gKEhbM10gKyBkKSA+Pj4gMDtcbiAgICAgICAgSFs0XSA9IChIWzRdICsgZSkgPj4+IDA7XG4gICAgfVxuICAgIHJldHVybiBVaW50OEFycmF5Lm9mKEhbMF0gPj4gMjQsIEhbMF0gPj4gMTYsIEhbMF0gPj4gOCwgSFswXSwgSFsxXSA+PiAyNCwgSFsxXSA+PiAxNiwgSFsxXSA+PiA4LCBIWzFdLCBIWzJdID4+IDI0LCBIWzJdID4+IDE2LCBIWzJdID4+IDgsIEhbMl0sIEhbM10gPj4gMjQsIEhbM10gPj4gMTYsIEhbM10gPj4gOCwgSFszXSwgSFs0XSA+PiAyNCwgSFs0XSA+PiAxNiwgSFs0XSA+PiA4LCBIWzRdKTtcbn1cbmV4cG9ydCBkZWZhdWx0IHNoYTE7XG4iLCJpbXBvcnQgc2hhMSBmcm9tICcuL3NoYTEuanMnO1xuaW1wb3J0IHYzNSwgeyBETlMsIFVSTCB9IGZyb20gJy4vdjM1LmpzJztcbmV4cG9ydCB7IEROUywgVVJMIH0gZnJvbSAnLi92MzUuanMnO1xuZnVuY3Rpb24gdjUodmFsdWUsIG5hbWVzcGFjZSwgYnVmLCBvZmZzZXQpIHtcbiAgICByZXR1cm4gdjM1KDB4NTAsIHNoYTEsIHZhbHVlLCBuYW1lc3BhY2UsIGJ1Ziwgb2Zmc2V0KTtcbn1cbnY1LkROUyA9IEROUztcbnY1LlVSTCA9IFVSTDtcbmV4cG9ydCBkZWZhdWx0IHY1O1xuIiwiaW1wb3J0IHsgdW5zYWZlU3RyaW5naWZ5IH0gZnJvbSAnLi9zdHJpbmdpZnkuanMnO1xuaW1wb3J0IHYxIGZyb20gJy4vdjEuanMnO1xuaW1wb3J0IHYxVG9WNiBmcm9tICcuL3YxVG9WNi5qcyc7XG5mdW5jdGlvbiB2NihvcHRpb25zLCBidWYsIG9mZnNldCkge1xuICAgIG9wdGlvbnMgPz89IHt9O1xuICAgIG9mZnNldCA/Pz0gMDtcbiAgICBsZXQgYnl0ZXMgPSB2MSh7IC4uLm9wdGlvbnMsIF92NjogdHJ1ZSB9LCBuZXcgVWludDhBcnJheSgxNikpO1xuICAgIGJ5dGVzID0gdjFUb1Y2KGJ5dGVzKTtcbiAgICBpZiAoYnVmKSB7XG4gICAgICAgIGlmIChvZmZzZXQgPCAwIHx8IG9mZnNldCArIDE2ID4gYnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYFVVSUQgYnl0ZSByYW5nZSAke29mZnNldH06JHtvZmZzZXQgKyAxNX0gaXMgb3V0IG9mIGJ1ZmZlciBib3VuZHNgKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDE2OyBpKyspIHtcbiAgICAgICAgICAgIGJ1ZltvZmZzZXQgKyBpXSA9IGJ5dGVzW2ldO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBidWY7XG4gICAgfVxuICAgIHJldHVybiB1bnNhZmVTdHJpbmdpZnkoYnl0ZXMpO1xufVxuZXhwb3J0IGRlZmF1bHQgdjY7XG4iLCJpbXBvcnQgcGFyc2UgZnJvbSAnLi9wYXJzZS5qcyc7XG5pbXBvcnQgeyB1bnNhZmVTdHJpbmdpZnkgfSBmcm9tICcuL3N0cmluZ2lmeS5qcyc7XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB2NlRvVjEodXVpZCkge1xuICAgIGNvbnN0IHY2Qnl0ZXMgPSB0eXBlb2YgdXVpZCA9PT0gJ3N0cmluZycgPyBwYXJzZSh1dWlkKSA6IHV1aWQ7XG4gICAgY29uc3QgdjFCeXRlcyA9IF92NlRvVjEodjZCeXRlcyk7XG4gICAgcmV0dXJuIHR5cGVvZiB1dWlkID09PSAnc3RyaW5nJyA/IHVuc2FmZVN0cmluZ2lmeSh2MUJ5dGVzKSA6IHYxQnl0ZXM7XG59XG5mdW5jdGlvbiBfdjZUb1YxKHY2Qnl0ZXMpIHtcbiAgICByZXR1cm4gVWludDhBcnJheS5vZigoKHY2Qnl0ZXNbM10gJiAweDBmKSA8PCA0KSB8ICgodjZCeXRlc1s0XSA+PiA0KSAmIDB4MGYpLCAoKHY2Qnl0ZXNbNF0gJiAweDBmKSA8PCA0KSB8ICgodjZCeXRlc1s1XSAmIDB4ZjApID4+IDQpLCAoKHY2Qnl0ZXNbNV0gJiAweDBmKSA8PCA0KSB8ICh2NkJ5dGVzWzZdICYgMHgwZiksIHY2Qnl0ZXNbN10sICgodjZCeXRlc1sxXSAmIDB4MGYpIDw8IDQpIHwgKCh2NkJ5dGVzWzJdICYgMHhmMCkgPj4gNCksICgodjZCeXRlc1syXSAmIDB4MGYpIDw8IDQpIHwgKCh2NkJ5dGVzWzNdICYgMHhmMCkgPj4gNCksIDB4MTAgfCAoKHY2Qnl0ZXNbMF0gJiAweGYwKSA+PiA0KSwgKCh2NkJ5dGVzWzBdICYgMHgwZikgPDwgNCkgfCAoKHY2Qnl0ZXNbMV0gJiAweGYwKSA+PiA0KSwgdjZCeXRlc1s4XSwgdjZCeXRlc1s5XSwgdjZCeXRlc1sxMF0sIHY2Qnl0ZXNbMTFdLCB2NkJ5dGVzWzEyXSwgdjZCeXRlc1sxM10sIHY2Qnl0ZXNbMTRdLCB2NkJ5dGVzWzE1XSk7XG59XG4iLCJpbXBvcnQgcm5nIGZyb20gJy4vcm5nLmpzJztcbmltcG9ydCB7IHVuc2FmZVN0cmluZ2lmeSB9IGZyb20gJy4vc3RyaW5naWZ5LmpzJztcbmNvbnN0IF9zdGF0ZSA9IHt9O1xuZnVuY3Rpb24gdjcob3B0aW9ucywgYnVmLCBvZmZzZXQpIHtcbiAgICBsZXQgYnl0ZXM7XG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgYnl0ZXMgPSB2N0J5dGVzKG9wdGlvbnMucmFuZG9tID8/IG9wdGlvbnMucm5nPy4oKSA/PyBybmcoKSwgb3B0aW9ucy5tc2Vjcywgb3B0aW9ucy5zZXEsIGJ1Ziwgb2Zmc2V0KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IHJuZHMgPSBybmcoKTtcbiAgICAgICAgdXBkYXRlVjdTdGF0ZShfc3RhdGUsIG5vdywgcm5kcyk7XG4gICAgICAgIGJ5dGVzID0gdjdCeXRlcyhybmRzLCBfc3RhdGUubXNlY3MsIF9zdGF0ZS5zZXEsIGJ1Ziwgb2Zmc2V0KTtcbiAgICB9XG4gICAgcmV0dXJuIGJ1ZiA/PyB1bnNhZmVTdHJpbmdpZnkoYnl0ZXMpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZVY3U3RhdGUoc3RhdGUsIG5vdywgcm5kcykge1xuICAgIHN0YXRlLm1zZWNzID8/PSAtSW5maW5pdHk7XG4gICAgc3RhdGUuc2VxID8/PSAwO1xuICAgIGlmIChub3cgPiBzdGF0ZS5tc2Vjcykge1xuICAgICAgICBzdGF0ZS5zZXEgPSAocm5kc1s2XSA8PCAyMykgfCAocm5kc1s3XSA8PCAxNikgfCAocm5kc1s4XSA8PCA4KSB8IHJuZHNbOV07XG4gICAgICAgIHN0YXRlLm1zZWNzID0gbm93O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc3RhdGUuc2VxID0gKHN0YXRlLnNlcSArIDEpIHwgMDtcbiAgICAgICAgaWYgKHN0YXRlLnNlcSA9PT0gMCkge1xuICAgICAgICAgICAgc3RhdGUubXNlY3MrKztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3RhdGU7XG59XG5mdW5jdGlvbiB2N0J5dGVzKHJuZHMsIG1zZWNzLCBzZXEsIGJ1Ziwgb2Zmc2V0ID0gMCkge1xuICAgIGlmIChybmRzLmxlbmd0aCA8IDE2KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignUmFuZG9tIGJ5dGVzIGxlbmd0aCBtdXN0IGJlID49IDE2Jyk7XG4gICAgfVxuICAgIGlmICghYnVmKSB7XG4gICAgICAgIGJ1ZiA9IG5ldyBVaW50OEFycmF5KDE2KTtcbiAgICAgICAgb2Zmc2V0ID0gMDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGlmIChvZmZzZXQgPCAwIHx8IG9mZnNldCArIDE2ID4gYnVmLmxlbmd0aCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYFVVSUQgYnl0ZSByYW5nZSAke29mZnNldH06JHtvZmZzZXQgKyAxNX0gaXMgb3V0IG9mIGJ1ZmZlciBib3VuZHNgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBtc2VjcyA/Pz0gRGF0ZS5ub3coKTtcbiAgICBzZXEgPz89ICgocm5kc1s2XSAqIDB4N2YpIDw8IDI0KSB8IChybmRzWzddIDw8IDE2KSB8IChybmRzWzhdIDw8IDgpIHwgcm5kc1s5XTtcbiAgICBidWZbb2Zmc2V0KytdID0gKG1zZWNzIC8gMHgxMDAwMDAwMDAwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAobXNlY3MgLyAweDEwMDAwMDAwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAobXNlY3MgLyAweDEwMDAwMDApICYgMHhmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKG1zZWNzIC8gMHgxMDAwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSAobXNlY3MgLyAweDEwMCkgJiAweGZmO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBtc2VjcyAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9IDB4NzAgfCAoKHNlcSA+Pj4gMjgpICYgMHgwZik7XG4gICAgYnVmW29mZnNldCsrXSA9IChzZXEgPj4+IDIwKSAmIDB4ZmY7XG4gICAgYnVmW29mZnNldCsrXSA9IDB4ODAgfCAoKHNlcSA+Pj4gMTQpICYgMHgzZik7XG4gICAgYnVmW29mZnNldCsrXSA9IChzZXEgPj4+IDYpICYgMHhmZjtcbiAgICBidWZbb2Zmc2V0KytdID0gKChzZXEgPDwgMikgJiAweGZmKSB8IChybmRzWzEwXSAmIDB4MDMpO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBybmRzWzExXTtcbiAgICBidWZbb2Zmc2V0KytdID0gcm5kc1sxMl07XG4gICAgYnVmW29mZnNldCsrXSA9IHJuZHNbMTNdO1xuICAgIGJ1ZltvZmZzZXQrK10gPSBybmRzWzE0XTtcbiAgICBidWZbb2Zmc2V0KytdID0gcm5kc1sxNV07XG4gICAgcmV0dXJuIGJ1Zjtcbn1cbmV4cG9ydCBkZWZhdWx0IHY3O1xuIiwiaW1wb3J0IHZhbGlkYXRlIGZyb20gJy4vdmFsaWRhdGUuanMnO1xuZnVuY3Rpb24gdmVyc2lvbih1dWlkKSB7XG4gICAgaWYgKCF2YWxpZGF0ZSh1dWlkKSkge1xuICAgICAgICB0aHJvdyBUeXBlRXJyb3IoJ0ludmFsaWQgVVVJRCcpO1xuICAgIH1cbiAgICByZXR1cm4gcGFyc2VJbnQodXVpZC5zbGljZSgxNCwgMTUpLCAxNik7XG59XG5leHBvcnQgZGVmYXVsdCB2ZXJzaW9uO1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5XSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBQSxjQUFlOzs7QUNBZixJQUFBLGNBQWU7OztBQ0FmLElBQUEsZ0JBQWU7OztBQ0NmLFNBQVMsU0FBUyxNQUFNO0NBQ3BCLE9BQU8sT0FBTyxTQUFTLFlBQVlBLGNBQU0sS0FBSyxJQUFJO0FBQ3REOzs7QUNGQSxTQUFTLE1BQU0sTUFBTTtDQUNqQixJQUFJLENBQUMsU0FBUyxJQUFJLEdBQ2QsTUFBTSxVQUFVLGNBQWM7Q0FFbEMsSUFBSTtDQUNKLE9BQU8sV0FBVyxJQUFJLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxDQUFDLEdBQUcsRUFBRSxPQUFPLElBQUssTUFBTSxLQUFNLEtBQU8sTUFBTSxJQUFLLEtBQU0sSUFBSSxNQUFPLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEdBQUcsSUFBSSxNQUFPLElBQUksU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEdBQUcsSUFBSSxNQUFPLElBQUksU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFFLEdBQUcsRUFBRSxPQUFPLEdBQUcsSUFBSSxNQUFRLElBQUksU0FBUyxLQUFLLE1BQU0sSUFBSSxFQUFFLEdBQUcsRUFBRSxLQUFLLGdCQUFpQixLQUFPLElBQUksYUFBZSxLQUFPLE1BQU0sS0FBTSxLQUFPLE1BQU0sS0FBTSxLQUFPLE1BQU0sSUFBSyxLQUFNLElBQUksR0FBSTtBQUN2Yjs7O0FDTkEsSUFBTSxZQUFZLENBQUM7QUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRSxHQUN2QixVQUFVLE1BQU0sSUFBSSxJQUFBLENBQU8sU0FBUyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUVwRCxTQUFnQixnQkFBZ0IsS0FBSyxTQUFTLEdBQUc7Q0FDN0MsUUFBUSxVQUFVLElBQUksU0FBUyxNQUMzQixVQUFVLElBQUksU0FBUyxNQUN2QixVQUFVLElBQUksU0FBUyxNQUN2QixVQUFVLElBQUksU0FBUyxNQUN2QixNQUNBLFVBQVUsSUFBSSxTQUFTLE1BQ3ZCLFVBQVUsSUFBSSxTQUFTLE1BQ3ZCLE1BQ0EsVUFBVSxJQUFJLFNBQVMsTUFDdkIsVUFBVSxJQUFJLFNBQVMsTUFDdkIsTUFDQSxVQUFVLElBQUksU0FBUyxNQUN2QixVQUFVLElBQUksU0FBUyxNQUN2QixNQUNBLFVBQVUsSUFBSSxTQUFTLE9BQ3ZCLFVBQVUsSUFBSSxTQUFTLE9BQ3ZCLFVBQVUsSUFBSSxTQUFTLE9BQ3ZCLFVBQVUsSUFBSSxTQUFTLE9BQ3ZCLFVBQVUsSUFBSSxTQUFTLE9BQ3ZCLFVBQVUsSUFBSSxTQUFTLEtBQUEsQ0FBTSxZQUFZO0FBQ2pEO0FBQ0EsU0FBUyxVQUFVLEtBQUssU0FBUyxHQUFHO0NBQ2hDLE1BQU0sT0FBTyxnQkFBZ0IsS0FBSyxNQUFNO0NBQ3hDLElBQUksQ0FBQyxTQUFTLElBQUksR0FDZCxNQUFNLFVBQVUsNkJBQTZCO0NBRWpELE9BQU87QUFDWDs7O0FDakNBLElBQUk7QUFDSixJQUFNLHdCQUFRLElBQUksV0FBVyxFQUFFO0FBQy9CLFNBQXdCLE1BQU07Q0FDMUIsSUFBSSxDQUFDLGlCQUFpQjtFQUNsQixJQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsT0FBTyxpQkFDekMsTUFBTSxJQUFJLE1BQU0sMEdBQTBHO0VBRTlILGtCQUFrQixPQUFPLGdCQUFnQixLQUFLLE1BQU07Q0FDeEQ7Q0FDQSxPQUFPLGdCQUFnQixLQUFLO0FBQ2hDOzs7QUNSQSxJQUFNQyxXQUFTLENBQUM7QUFDaEIsU0FBUyxHQUFHLFNBQVMsS0FBSyxRQUFROztDQUM5QixJQUFJO0NBQ0osTUFBTSxRQUFBLGNBQUEsWUFBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLEtBQUEsSUFBTyxRQUFTLFNBQUEsUUFBQSxnQkFBQSxLQUFBLElBQUEsY0FBTztDQUM3QixJQUFJLFNBQVM7RUFDVCxNQUFNLGNBQWMsT0FBTyxLQUFLLE9BQU87RUFDdkMsSUFBSSxZQUFZLFdBQVcsS0FBSyxZQUFZLE9BQU8sT0FDL0MsVUFBVSxLQUFBO0NBRWxCO0NBQ0EsSUFBSSxTQUFTOztFQUNULFFBQVEsU0FBQSxRQUFBLGtCQUFRLFFBQVEsWUFBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxtQkFBQSxlQUFVLFFBQVEsU0FBQSxRQUFBLGlCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsYUFBQSxLQUFBLE9BQU0sT0FBQSxRQUFBLFNBQUEsS0FBQSxJQUFBLE9BQUssSUFBSSxHQUFHLFFBQVEsT0FBTyxRQUFRLE9BQU8sUUFBUSxVQUFVLFFBQVEsTUFBTSxLQUFLLE1BQU07Q0FDekksT0FDSztFQUNELE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSxPQUFPLElBQUk7RUFDakIsY0FBY0EsVUFBUSxLQUFLLElBQUk7RUFDL0IsUUFBUSxRQUFRLE1BQU1BLFNBQU8sT0FBT0EsU0FBTyxPQUFPLE9BQU8sS0FBQSxJQUFZQSxTQUFPLFVBQVUsT0FBTyxLQUFBLElBQVlBLFNBQU8sTUFBTSxLQUFLLE1BQU07Q0FDckk7Q0FDQSxPQUFPLFFBQUEsUUFBQSxRQUFBLEtBQUEsSUFBQSxNQUFPLGdCQUFnQixLQUFLO0FBQ3ZDO0FBQ0EsU0FBZ0IsY0FBYyxPQUFPLEtBQUssTUFBTTs7Q0FDNUMsQ0FBQSxlQUFBLE1BQU0sV0FBQSxRQUFBLGlCQUFBLEtBQUEsTUFBTixNQUFNLFFBQVU7Q0FDaEIsQ0FBQSxlQUFBLE1BQU0sV0FBQSxRQUFBLGlCQUFBLEtBQUEsTUFBTixNQUFNLFFBQVU7Q0FDaEIsSUFBSSxRQUFRLE1BQU0sT0FBTztFQUNyQixNQUFNO0VBQ04sSUFBSSxNQUFNLFNBQVMsS0FBTztHQUN0QixNQUFNLE9BQU8sS0FBQTtHQUNiLE1BQU0sUUFBUTtFQUNsQjtDQUNKLE9BQ0ssSUFBSSxNQUFNLE1BQU0sT0FDakIsTUFBTSxRQUFRO01BRWIsSUFBSSxNQUFNLE1BQU0sT0FDakIsTUFBTSxPQUFPLEtBQUE7Q0FFakIsSUFBSSxDQUFDLE1BQU0sTUFBTTtFQUNiLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxFQUFFO0VBQzlCLE1BQU0sS0FBSyxNQUFNO0VBQ2pCLE1BQU0sWUFBYSxLQUFLLE1BQU0sSUFBSyxLQUFLLE1BQU07Q0FDbEQ7Q0FDQSxNQUFNLFFBQVE7Q0FDZCxPQUFPO0FBQ1g7QUFDQSxTQUFTLFFBQVEsTUFBTSxPQUFPLE9BQU8sVUFBVSxNQUFNLEtBQUssU0FBUyxHQUFHOztDQUNsRSxJQUFJLEtBQUssU0FBUyxJQUNkLE1BQU0sSUFBSSxNQUFNLG1DQUFtQztDQUV2RCxJQUFJLENBQUMsS0FBSztFQUNOLHNCQUFNLElBQUksV0FBVyxFQUFFO0VBQ3ZCLFNBQVM7Q0FDYixPQUVJLElBQUksU0FBUyxLQUFLLFNBQVMsS0FBSyxJQUFJLFFBQ2hDLE1BQU0sSUFBSSxXQUFXLG1CQUFtQixPQUFPLEdBQUcsU0FBUyxHQUFHLHlCQUF5QjtDQUcvRixDQUFBLFNBQUEsV0FBQSxRQUFBLFdBQUEsS0FBQSxNQUFBLFFBQVUsS0FBSyxJQUFJO0NBQ25CLENBQUEsU0FBQSxXQUFBLFFBQUEsV0FBQSxLQUFBLE1BQUEsUUFBVTtDQUNWLENBQUEsWUFBQSxjQUFBLFFBQUEsY0FBQSxLQUFBLE1BQUEsWUFBZSxLQUFLLE1BQU0sSUFBSyxLQUFLLE1BQU07Q0FDMUMsQ0FBQSxRQUFBLFVBQUEsUUFBQSxVQUFBLEtBQUEsTUFBQSxPQUFTLEtBQUssTUFBTSxJQUFJLEVBQUU7Q0FDMUIsU0FBUztDQUNULE1BQU0sT0FBTyxRQUFRLGFBQWEsTUFBUSxTQUFTO0NBQ25ELElBQUksWUFBYSxPQUFPLEtBQU07Q0FDOUIsSUFBSSxZQUFhLE9BQU8sS0FBTTtDQUM5QixJQUFJLFlBQWEsT0FBTyxJQUFLO0NBQzdCLElBQUksWUFBWSxLQUFLO0NBQ3JCLE1BQU0sTUFBUSxRQUFRLGFBQWUsTUFBUztDQUM5QyxJQUFJLFlBQWEsUUFBUSxJQUFLO0NBQzlCLElBQUksWUFBWSxNQUFNO0NBQ3RCLElBQUksWUFBYyxRQUFRLEtBQU0sS0FBTztDQUN2QyxJQUFJLFlBQWEsUUFBUSxLQUFNO0NBQy9CLElBQUksWUFBYSxhQUFhLElBQUs7Q0FDbkMsSUFBSSxZQUFZLFdBQVc7Q0FDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUNyQixJQUFJLFlBQVksS0FBSztDQUV6QixPQUFPO0FBQ1g7OztBQy9FQSxTQUF3QixPQUFPLE1BQU07Q0FFakMsTUFBTSxVQUFVLFFBREEsT0FBTyxTQUFTLFdBQVcsTUFBTSxJQUFJLElBQUksSUFDMUI7Q0FDL0IsT0FBTyxPQUFPLFNBQVMsV0FBVyxnQkFBZ0IsT0FBTyxJQUFJO0FBQ2pFO0FBQ0EsU0FBUyxRQUFRLFNBQVM7Q0FDdEIsT0FBTyxXQUFXLElBQUssUUFBUSxLQUFLLE9BQVMsSUFBTyxRQUFRLE1BQU0sSUFBSyxLQUFTLFFBQVEsS0FBSyxPQUFTLEtBQU8sUUFBUSxLQUFLLFFBQVMsSUFBTSxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLElBQU0sUUFBUSxLQUFLLE9BQVMsS0FBTyxRQUFRLEtBQUssUUFBUyxJQUFNLFFBQVEsS0FBSyxPQUFTLEtBQU8sUUFBUSxLQUFLLFFBQVMsSUFBTSxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLEdBQUksS0FBUSxRQUFRLEtBQUssSUFBTyxRQUFRLElBQUksUUFBUSxJQUFJLFFBQVEsSUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsR0FBRztBQUMzZjs7O0FDVEEsU0FBUyxJQUFJLE9BQU87Q0FHaEIsT0FBTyxjQURVLFdBREgsY0FBYyxLQUNJLEdBQUcsTUFBTSxTQUFTLENBQ3RCLENBQUM7QUFDakM7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUMxQixNQUFNLFFBQVEsSUFBSSxXQUFXLE1BQU0sU0FBUyxDQUFDO0NBQzdDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUNsQyxNQUFNLEtBQU0sTUFBTSxLQUFLLE9BQVMsSUFBSSxJQUFLLElBQU07Q0FFbkQsT0FBTztBQUNYO0FBQ0EsU0FBUyxnQkFBZ0IsY0FBYztDQUNuQyxRQUFVLGVBQWUsT0FBUSxLQUFNLEtBQUssS0FBSztBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUFHLEtBQUs7Q0FDeEIsTUFBTSxPQUFPLElBQUksWUFBWSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Q0FDekQsS0FBSyxJQUFJLENBQUM7Q0FDVixLQUFLLE9BQU8sTUFBTSxPQUFRLE1BQU07Q0FDaEMsS0FBSyxLQUFLLFNBQVMsS0FBSztDQUN4QixJQUFJO0NBQ0osSUFBSSxJQUFJO0NBQ1IsSUFBSSxJQUFJO0NBQ1IsSUFBSSxJQUFJO0NBQ1IsSUFBSSxJQUFJO0NBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUk7RUFDbkMsTUFBTSxPQUFPO0VBQ2IsTUFBTSxPQUFPO0VBQ2IsTUFBTSxPQUFPO0VBQ2IsTUFBTSxPQUFPO0VBQ2IsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEdBQUcsVUFBVTtFQUN6QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxTQUFTO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksV0FBVztFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFVBQVU7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksV0FBVztFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFNBQVM7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxVQUFVO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksV0FBVztFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLE1BQU07RUFDM0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxXQUFXO0VBQ2hELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLEdBQUcsVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFNBQVM7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxXQUFXO0VBQ2hELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksVUFBVTtFQUMvQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFVBQVU7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxXQUFXO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksU0FBUztFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxVQUFVO0VBQzFDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsVUFBVTtFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxHQUFHLFFBQVE7RUFDNUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxVQUFVO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFNBQVM7RUFDNUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxXQUFXO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxXQUFXO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsU0FBUztFQUM1QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxXQUFXO0VBQ2hELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsT0FBTztFQUMxQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFdBQVc7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxVQUFVO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksU0FBUztFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFdBQVc7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFdBQVc7RUFDaEQsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssR0FBRyxTQUFTO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLFVBQVU7RUFDMUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0VBQzlDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksUUFBUTtFQUM1QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxHQUFHLFVBQVU7RUFDN0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxVQUFVO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksU0FBUztFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEdBQUcsVUFBVTtFQUN6QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxXQUFXO0VBQ2hELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksU0FBUztFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxHQUFHLFVBQVU7RUFDOUMsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxXQUFXO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksUUFBUTtFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFdBQVc7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksR0FBRyxVQUFVO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxLQUFLLElBQUksU0FBUztFQUM5QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksSUFBSSxJQUFJLFdBQVc7RUFDL0MsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLEtBQUssSUFBSSxVQUFVO0VBQy9DLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLEdBQUcsVUFBVTtFQUM3QyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLFdBQVc7RUFDaEQsSUFBSSxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLElBQUksSUFBSSxTQUFTO0VBQzdDLElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxJQUFJLElBQUksVUFBVTtFQUM5QyxJQUFJLFFBQVEsR0FBRyxJQUFJO0VBQ25CLElBQUksUUFBUSxHQUFHLElBQUk7RUFDbkIsSUFBSSxRQUFRLEdBQUcsSUFBSTtFQUNuQixJQUFJLFFBQVEsR0FBRyxJQUFJO0NBQ3ZCO0NBQ0EsT0FBTyxZQUFZLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUNwQztBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLElBQUksTUFBTSxXQUFXLEdBQ2pCLHVCQUFPLElBQUksWUFBWTtDQUUzQixNQUFNLFNBQVMsSUFBSSxZQUFZLGdCQUFnQixNQUFNLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Q0FDeEUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUM5QixPQUFPLEtBQUssT0FBTyxNQUFNLEtBQUssUUFBVyxJQUFJLElBQUs7Q0FFdEQsT0FBTztBQUNYO0FBQ0EsU0FBUyxRQUFRLEdBQUcsR0FBRztDQUNuQixNQUFNLE9BQU8sSUFBSSxVQUFXLElBQUk7Q0FFaEMsUUFEYSxLQUFLLE9BQU8sS0FBSyxPQUFPLE9BQU8sT0FDN0IsS0FBTyxNQUFNO0FBQ2hDO0FBQ0EsU0FBUyxjQUFjLEtBQUssS0FBSztDQUM3QixPQUFRLE9BQU8sTUFBUSxRQUFTLEtBQUs7QUFDekM7QUFDQSxTQUFTLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDOUIsT0FBTyxRQUFRLGNBQWMsUUFBUSxRQUFRLEdBQUcsQ0FBQyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUM3RTtBQUNBLFNBQVMsTUFBTSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ2hDLE9BQU8sT0FBUSxJQUFJLElBQU0sQ0FBQyxJQUFJLEdBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ25EO0FBQ0EsU0FBUyxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDaEMsT0FBTyxPQUFRLElBQUksSUFBTSxJQUFJLENBQUMsR0FBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDbkQ7QUFDQSxTQUFTLE1BQU0sR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRztDQUNoQyxPQUFPLE9BQU8sSUFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQzFDO0FBQ0EsU0FBUyxNQUFNLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDaEMsT0FBTyxPQUFPLEtBQUssSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQzdDOzs7QUNuSUEsU0FBZ0IsY0FBYyxLQUFLO0NBQy9CLE1BQU0sU0FBUyxtQkFBbUIsR0FBRyxDQUFDO0NBQ3RDLE1BQU0sUUFBUSxJQUFJLFdBQVcsSUFBSSxNQUFNO0NBQ3ZDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsRUFBRSxHQUM5QixNQUFNLEtBQUssSUFBSSxXQUFXLENBQUM7Q0FFL0IsT0FBTztBQUNYO0FBQ0EsSUFBYSxNQUFNO0FBQ25CLElBQWEsTUFBTTtBQUNuQixTQUF3QixJQUFJLFNBQVMsTUFBTSxPQUFPLFdBQVcsS0FBSyxRQUFRO0NBQ3RFLE1BQU0sYUFBYSxPQUFPLFVBQVUsV0FBVyxjQUFjLEtBQUssSUFBSTtDQUN0RSxNQUFNLGlCQUFpQixPQUFPLGNBQWMsV0FBVyxNQUFNLFNBQVMsSUFBSTtDQUMxRSxJQUFJLE9BQU8sY0FBYyxVQUNyQixZQUFZLE1BQU0sU0FBUztDQUUvQixLQUFBLGNBQUEsUUFBQSxjQUFBLEtBQUEsSUFBQSxLQUFBLElBQUksVUFBVyxZQUFXLElBQ3RCLE1BQU0sVUFBVSxrRUFBa0U7Q0FFdEYsSUFBSSxRQUFRLElBQUksV0FBVyxLQUFLLFdBQVcsTUFBTTtDQUNqRCxNQUFNLElBQUksY0FBYztDQUN4QixNQUFNLElBQUksWUFBWSxlQUFlLE1BQU07Q0FDM0MsUUFBUSxLQUFLLEtBQUs7Q0FDbEIsTUFBTSxLQUFNLE1BQU0sS0FBSyxLQUFRO0NBQy9CLE1BQU0sS0FBTSxNQUFNLEtBQUssS0FBUTtDQUMvQixJQUFJLEtBQUs7RUFDTCxTQUFTLFVBQVU7RUFDbkIsSUFBSSxTQUFTLEtBQUssU0FBUyxLQUFLLElBQUksUUFDaEMsTUFBTSxJQUFJLFdBQVcsbUJBQW1CLE9BQU8sR0FBRyxTQUFTLEdBQUcseUJBQXlCO0VBRTNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsR0FDdEIsSUFBSSxTQUFTLEtBQUssTUFBTTtFQUU1QixPQUFPO0NBQ1g7Q0FDQSxPQUFPLGdCQUFnQixLQUFLO0FBQ2hDOzs7QUNuQ0EsU0FBUyxHQUFHLE9BQU8sV0FBVyxLQUFLLFFBQVE7Q0FDdkMsT0FBTyxJQUFJLElBQU0sS0FBSyxPQUFPLFdBQVcsS0FBSyxNQUFNO0FBQ3ZEO0FBQ0EsR0FBRyxNQUFNO0FBQ1QsR0FBRyxNQUFNO0FDTlQsSUFBQSxpQkFBZSxFQUFFLFlBREUsT0FBTyxXQUFXLGVBQWUsT0FBTyxjQUFjLE9BQU8sV0FBVyxLQUFLLE1BQU0sRUFDMUU7OztBQ0U1QixTQUFTLEdBQUcsU0FBUyxLQUFLLFFBQVE7O0NBQzlCLElBQUlDLGVBQU8sY0FBYyxDQUFDLE9BQU8sQ0FBQyxTQUM5QixPQUFPQSxlQUFPLFdBQVc7Q0FFN0IsVUFBVSxXQUFXLENBQUM7Q0FDdEIsTUFBTSxRQUFBLFFBQUEsa0JBQU8sUUFBUSxZQUFBLFFBQUEsb0JBQUEsS0FBQSxJQUFBLG1CQUFBLGVBQVUsUUFBUSxTQUFBLFFBQUEsaUJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxhQUFBLEtBQUEsT0FBTSxPQUFBLFFBQUEsU0FBQSxLQUFBLElBQUEsT0FBSyxJQUFJO0NBQ3RELElBQUksS0FBSyxTQUFTLElBQ2QsTUFBTSxJQUFJLE1BQU0sbUNBQW1DO0NBRXZELEtBQUssS0FBTSxLQUFLLEtBQUssS0FBUTtDQUM3QixLQUFLLEtBQU0sS0FBSyxLQUFLLEtBQVE7Q0FDN0IsSUFBSSxLQUFLO0VBQ0wsU0FBUyxVQUFVO0VBQ25CLElBQUksU0FBUyxLQUFLLFNBQVMsS0FBSyxJQUFJLFFBQ2hDLE1BQU0sSUFBSSxXQUFXLG1CQUFtQixPQUFPLEdBQUcsU0FBUyxHQUFHLHlCQUF5QjtFQUUzRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLElBQUksU0FBUyxLQUFLLEtBQUs7RUFFM0IsT0FBTztDQUNYO0NBQ0EsT0FBTyxnQkFBZ0IsSUFBSTtBQUMvQjs7O0FDekJBLFNBQVMsRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ25CLFFBQVEsR0FBUjtFQUNJLEtBQUssR0FDRCxPQUFRLElBQUksSUFBTSxDQUFDLElBQUk7RUFDM0IsS0FBSyxHQUNELE9BQU8sSUFBSSxJQUFJO0VBQ25CLEtBQUssR0FDRCxPQUFRLElBQUksSUFBTSxJQUFJLElBQU0sSUFBSTtFQUNwQyxLQUFLLEdBQ0QsT0FBTyxJQUFJLElBQUk7Q0FDdkI7QUFDSjtBQUNBLFNBQVMsS0FBSyxHQUFHLEdBQUc7Q0FDaEIsT0FBUSxLQUFLLElBQU0sTUFBTyxLQUFLO0FBQ25DO0FBQ0EsU0FBUyxLQUFLLE9BQU87Q0FDakIsTUFBTSxJQUFJO0VBQUM7RUFBWTtFQUFZO0VBQVk7Q0FBVTtDQUN6RCxNQUFNLElBQUk7RUFBQztFQUFZO0VBQVk7RUFBWTtFQUFZO0NBQVU7Q0FDckUsTUFBTSxXQUFXLElBQUksV0FBVyxNQUFNLFNBQVMsQ0FBQztDQUNoRCxTQUFTLElBQUksS0FBSztDQUNsQixTQUFTLE1BQU0sVUFBVTtDQUN6QixRQUFRO0NBQ1IsTUFBTSxJQUFJLE1BQU0sU0FBUyxJQUFJO0NBQzdCLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFO0NBQzFCLE1BQU0sSUFBSSxJQUFJLE1BQU0sQ0FBQztDQUNyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUc7RUFDeEIsTUFBTSxzQkFBTSxJQUFJLFlBQVksRUFBRTtFQUM5QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLElBQUksS0FDQyxNQUFNLElBQUksS0FBSyxJQUFJLE1BQU0sS0FDckIsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sS0FDN0IsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sSUFDOUIsTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJO0VBRW5DLEVBQUUsS0FBSztDQUNYO0NBQ0EsRUFBRSxJQUFJLEVBQUUsQ0FBQyxPQUFRLE1BQU0sU0FBUyxLQUFLLElBQUssS0FBSyxJQUFJLEdBQUcsRUFBRTtDQUN4RCxFQUFFLElBQUksRUFBRSxDQUFDLE1BQU0sS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLENBQUMsR0FBRztDQUN0QyxFQUFFLElBQUksRUFBRSxDQUFDLE9BQVEsTUFBTSxTQUFTLEtBQUssSUFBSztDQUMxQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUc7RUFDeEIsTUFBTSxvQkFBSSxJQUFJLFlBQVksRUFBRTtFQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztFQUVoQixLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQ3ZCLEVBQUUsS0FBSyxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7RUFFOUQsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLElBQUksRUFBRTtFQUNWLElBQUksSUFBSSxFQUFFO0VBQ1YsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLElBQUksRUFBRTtFQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsR0FBRztHQUN6QixNQUFNLElBQUksS0FBSyxNQUFNLElBQUksRUFBRTtHQUMzQixNQUFNLElBQUssS0FBSyxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQVE7R0FDN0QsSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJLEtBQUssR0FBRyxFQUFFLE1BQU07R0FDcEIsSUFBSTtHQUNKLElBQUk7RUFDUjtFQUNBLEVBQUUsS0FBTSxFQUFFLEtBQUssTUFBTztFQUN0QixFQUFFLEtBQU0sRUFBRSxLQUFLLE1BQU87RUFDdEIsRUFBRSxLQUFNLEVBQUUsS0FBSyxNQUFPO0VBQ3RCLEVBQUUsS0FBTSxFQUFFLEtBQUssTUFBTztFQUN0QixFQUFFLEtBQU0sRUFBRSxLQUFLLE1BQU87Q0FDMUI7Q0FDQSxPQUFPLFdBQVcsR0FBRyxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxFQUFFO0FBQ3BPOzs7QUNqRUEsU0FBUyxHQUFHLE9BQU8sV0FBVyxLQUFLLFFBQVE7Q0FDdkMsT0FBTyxJQUFJLElBQU0sTUFBTSxPQUFPLFdBQVcsS0FBSyxNQUFNO0FBQ3hEO0FBQ0EsR0FBRyxNQUFNO0FBQ1QsR0FBRyxNQUFNOzs7QUNKVCxTQUFTLEdBQUcsU0FBUyxLQUFLLFFBQVE7O0NBQzlCLENBQUEsV0FBQSxhQUFBLFFBQUEsYUFBQSxLQUFBLE1BQUEsVUFBWSxDQUFDO0NBQ2IsQ0FBQSxVQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsTUFBQSxTQUFXO0NBQ1gsSUFBSSxRQUFRLEdBQUEsZUFBQSxlQUFBLENBQUEsR0FBUSxPQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQVMsS0FBSyxLQUFBLENBQUssbUJBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQztDQUM1RCxRQUFRLE9BQU8sS0FBSztDQUNwQixJQUFJLEtBQUs7RUFDTCxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssSUFBSSxRQUNoQyxNQUFNLElBQUksV0FBVyxtQkFBbUIsT0FBTyxHQUFHLFNBQVMsR0FBRyx5QkFBeUI7RUFFM0YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksS0FDcEIsSUFBSSxTQUFTLEtBQUssTUFBTTtFQUU1QixPQUFPO0NBQ1g7Q0FDQSxPQUFPLGdCQUFnQixLQUFLO0FBQ2hDOzs7QUNoQkEsU0FBd0IsT0FBTyxNQUFNO0NBRWpDLE1BQU0sVUFBVSxRQURBLE9BQU8sU0FBUyxXQUFXLE1BQU0sSUFBSSxJQUFJLElBQzFCO0NBQy9CLE9BQU8sT0FBTyxTQUFTLFdBQVcsZ0JBQWdCLE9BQU8sSUFBSTtBQUNqRTtBQUNBLFNBQVMsUUFBUSxTQUFTO0NBQ3RCLE9BQU8sV0FBVyxJQUFLLFFBQVEsS0FBSyxPQUFTLElBQU8sUUFBUSxNQUFNLElBQUssS0FBUyxRQUFRLEtBQUssT0FBUyxLQUFPLFFBQVEsS0FBSyxRQUFTLElBQU0sUUFBUSxLQUFLLE9BQVMsSUFBTSxRQUFRLEtBQUssSUFBTyxRQUFRLEtBQU0sUUFBUSxLQUFLLE9BQVMsS0FBTyxRQUFRLEtBQUssUUFBUyxJQUFNLFFBQVEsS0FBSyxPQUFTLEtBQU8sUUFBUSxLQUFLLFFBQVMsR0FBSSxNQUFTLFFBQVEsS0FBSyxRQUFTLElBQU0sUUFBUSxLQUFLLE9BQVMsS0FBTyxRQUFRLEtBQUssUUFBUyxHQUFJLFFBQVEsSUFBSSxRQUFRLElBQUksUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUc7QUFDM2Y7OztBQ1BBLElBQU0sU0FBUyxDQUFDO0FBQ2hCLFNBQVMsR0FBRyxTQUFTLEtBQUssUUFBUTtDQUM5QixJQUFJO0NBQ0osSUFBSSxTQUFTOztFQUNULFFBQVEsU0FBQSxRQUFBLGtCQUFRLFFBQVEsWUFBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxtQkFBQSxlQUFVLFFBQVEsU0FBQSxRQUFBLGlCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsYUFBQSxLQUFBLE9BQU0sT0FBQSxRQUFBLFNBQUEsS0FBQSxJQUFBLE9BQUssSUFBSSxHQUFHLFFBQVEsT0FBTyxRQUFRLEtBQUssS0FBSyxNQUFNO0NBQ3ZHLE9BQ0s7RUFDRCxNQUFNLE1BQU0sS0FBSyxJQUFJO0VBQ3JCLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLGNBQWMsUUFBUSxLQUFLLElBQUk7RUFDL0IsUUFBUSxRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU07Q0FDL0Q7Q0FDQSxPQUFPLFFBQUEsUUFBQSxRQUFBLEtBQUEsSUFBQSxNQUFPLGdCQUFnQixLQUFLO0FBQ3ZDO0FBQ0EsU0FBZ0IsY0FBYyxPQUFPLEtBQUssTUFBTTs7Q0FDNUMsQ0FBQSxlQUFBLE1BQU0sV0FBQSxRQUFBLGlCQUFBLEtBQUEsTUFBTixNQUFNLFFBQVU7Q0FDaEIsQ0FBQSxhQUFBLE1BQU0sU0FBQSxRQUFBLGVBQUEsS0FBQSxNQUFOLE1BQU0sTUFBUTtDQUNkLElBQUksTUFBTSxNQUFNLE9BQU87RUFDbkIsTUFBTSxNQUFPLEtBQUssTUFBTSxLQUFPLEtBQUssTUFBTSxLQUFPLEtBQUssTUFBTSxJQUFLLEtBQUs7RUFDdEUsTUFBTSxRQUFRO0NBQ2xCLE9BQ0s7RUFDRCxNQUFNLE1BQU8sTUFBTSxNQUFNLElBQUs7RUFDOUIsSUFBSSxNQUFNLFFBQVEsR0FDZCxNQUFNO0NBRWQ7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLFFBQVEsTUFBTSxPQUFPLEtBQUssS0FBSyxTQUFTLEdBQUc7O0NBQ2hELElBQUksS0FBSyxTQUFTLElBQ2QsTUFBTSxJQUFJLE1BQU0sbUNBQW1DO0NBRXZELElBQUksQ0FBQyxLQUFLO0VBQ04sc0JBQU0sSUFBSSxXQUFXLEVBQUU7RUFDdkIsU0FBUztDQUNiLE9BRUksSUFBSSxTQUFTLEtBQUssU0FBUyxLQUFLLElBQUksUUFDaEMsTUFBTSxJQUFJLFdBQVcsbUJBQW1CLE9BQU8sR0FBRyxTQUFTLEdBQUcseUJBQXlCO0NBRy9GLENBQUEsU0FBQSxXQUFBLFFBQUEsV0FBQSxLQUFBLE1BQUEsUUFBVSxLQUFLLElBQUk7Q0FDbkIsQ0FBQSxPQUFBLFNBQUEsUUFBQSxTQUFBLEtBQUEsTUFBQSxNQUFVLEtBQUssS0FBSyxPQUFTLEtBQU8sS0FBSyxNQUFNLEtBQU8sS0FBSyxNQUFNLElBQUssS0FBSztDQUMzRSxJQUFJLFlBQWEsUUFBUSxnQkFBaUI7Q0FDMUMsSUFBSSxZQUFhLFFBQVEsYUFBZTtDQUN4QyxJQUFJLFlBQWEsUUFBUSxXQUFhO0NBQ3RDLElBQUksWUFBYSxRQUFRLFFBQVc7Q0FDcEMsSUFBSSxZQUFhLFFBQVEsTUFBUztDQUNsQyxJQUFJLFlBQVksUUFBUTtDQUN4QixJQUFJLFlBQVksTUFBUyxRQUFRLEtBQU07Q0FDdkMsSUFBSSxZQUFhLFFBQVEsS0FBTTtDQUMvQixJQUFJLFlBQVksTUFBUyxRQUFRLEtBQU07Q0FDdkMsSUFBSSxZQUFhLFFBQVEsSUFBSztDQUM5QixJQUFJLFlBQWMsT0FBTyxJQUFLLE1BQVMsS0FBSyxNQUFNO0NBQ2xELElBQUksWUFBWSxLQUFLO0NBQ3JCLElBQUksWUFBWSxLQUFLO0NBQ3JCLElBQUksWUFBWSxLQUFLO0NBQ3JCLElBQUksWUFBWSxLQUFLO0NBQ3JCLElBQUksWUFBWSxLQUFLO0NBQ3JCLE9BQU87QUFDWDs7O0FDOURBLFNBQVMsUUFBUSxNQUFNO0NBQ25CLElBQUksQ0FBQyxTQUFTLElBQUksR0FDZCxNQUFNLFVBQVUsY0FBYztDQUVsQyxPQUFPLFNBQVMsS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUU7QUFDMUMifQ==