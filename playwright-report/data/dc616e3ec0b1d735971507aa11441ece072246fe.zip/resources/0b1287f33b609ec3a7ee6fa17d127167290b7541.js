import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/main.js");const Buffer = __vite__cjsImport34_buffer["Buffer"];import {
  ConfigService,
  __spreadValues,
  environment
} from "/chunk-PZ54WRVW.js";

// apps/client/src/main.ts
import { bootstrapApplication } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_platform-browser.js?v=cf17c1b4";

// apps/client/src/app/app.config.ts
import {
  provideAppInitializer,
  inject as inject2,
  provideBrowserGlobalErrorListeners,
  provideZoneChangeDetection,
  isDevMode
} from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { provideRouter } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";

// apps/client/src/app/pages/home/home.component.ts
import { Component } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { RouterModule } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
import { LucideZap, LucideUsers, LucideTerminal, LucideChevronRight, LucideLock, LucideCode2, LucideHelpCircle, LucideGlobe, LucideXCircle, LucideCheckCircle2, LucideAlertTriangle, LucideNetwork, LucideFileKey, LucideCpu, LucideFingerprint, LucideMaximize, LucideScale, LucideEyeOff, LucideShieldCheck, LucideFileText, LucideBuilding2, LucideExternalLink } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@lucide_angular.js?v=cf17c1b4";
import * as i0 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i1 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
var HomeComponent = class _HomeComponent {
  ngOnInit() {
  }
  toggleFullscreen(element) {
    if (!document.fullscreenElement) {
      element.requestFullscreen().catch((err) => {
        console.error(`Error enabling fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  }
  static \u0275fac = function HomeComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _HomeComponent)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _HomeComponent, selectors: [["app-home"]], decls: 407, vars: 0, consts: [["demoContainer", ""], [1, "max-w-6xl", "mx-auto", "text-center", "pt-24", "px-6", "relative"], [1, "absolute", "top-0", "left-1/2", "-translate-x-1/2", "w-[800px]", "h-[600px]", "bg-emerald-500/10", "rounded-full", "blur-[120px]", "pointer-events-none"], ["href", "https://github.com/scarlin90/SigningRoom", "target", "_blank", 1, "inline-flex", "items-center", "gap-2", "px-3", "py-1", "rounded-full", "bg-slate-800/80", "backdrop-blur-md", "border", "border-slate-700", "text-slate-400", "hover:text-white", "hover:border-slate-600", "transition", "mb-8", "cursor-pointer", "group", "relative", "z-10"], ["lucideCode2", "", 1, "w-3", "h-3", "text-emerald-400"], [1, "text-xs", "font-medium"], ["lucideChevronRight", "", 1, "w-3", "h-3", "group-hover:translate-x-0.5", "transition-transform"], [1, "text-5xl", "md:text-7xl", "font-extrabold", "tracking-tight", "text-white", "mb-6", "leading-tight", "relative", "z-10"], [1, "text-transparent", "bg-clip-text", "bg-gradient-to-r", "from-emerald-400", "to-cyan-400", "text-3xl", "md:text-5xl"], [1, "text-lg", "md:text-xl", "text-slate-400", "mb-10", "max-w-2xl", "mx-auto", "leading-relaxed", "relative", "z-10"], [1, "hidden", "md:block"], [1, "text-slate-200", "font-semibold"], [1, "flex", "flex-col", "sm:flex-row", "items-center", "justify-center", "gap-4", "relative", "z-10"], ["routerLink", "/create", 1, "px-8", "py-4", "rounded-lg", "bg-emerald-500", "hover:bg-emerald-400", "text-slate-950", "font-bold", "transition-all", "flex", "items-center", "gap-2", "shadow-[0_0_20px_rgba(16,185,129,0.3)]", "cursor-pointer", "w-full", "sm:w-auto", "justify-center", "hover:scale-105", "transform", "duration-200"], ["lucideZap", "", 1, "w-5", "h-5", "fill-slate-950"], ["href", "https://arxiv.org/abs/2601.17875", "target", "_blank", 1, "px-8", "py-4", "rounded-lg", "bg-slate-800/80", "hover:bg-slate-700", "text-slate-200", "font-medium", "transition-all", "flex", "items-center", "gap-2", "border", "border-slate-700", "hover:border-slate-600", "w-full", "sm:w-auto", "justify-center"], ["lucideFileText", "", 1, "w-5", "h-5", "text-emerald-400"], ["href", "https://github.com/scarlin90/signingroom/tree/main/libs/sdk", "target", "_blank", 1, "px-8", "py-4", "rounded-lg", "bg-slate-800/80", "hover:bg-slate-700", "text-white", "font-medium", "transition-all", "flex", "items-center", "gap-2", "border", "border-slate-700", "hover:border-slate-600", "w-full", "sm:w-auto", "justify-center"], ["xmlns", "http://www.w3.org/2000/svg", "width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "w-5", "h-5"], ["d", "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"], ["d", "M9 18c-4.51 2-5-2-7-2"], ["href", "/webcomponent-demo.html?ngsw-bypass=true", "target", "_blank", "rel", "external noopener noreferrer", 1, "px-8", "py-4", "rounded-lg", "bg-slate-800/80", "hover:bg-slate-700", "text-white", "font-medium", "transition-all", "flex", "items-center", "gap-2", "border", "border-slate-700", "hover:border-slate-600", "w-full", "sm:w-auto", "justify-center"], ["lucideTerminal", "", 1, "w-4", "h-4"], [1, "max-w-5xl", "mx-auto", "mt-16", "px-6", "relative", "z-10", "animate-fade-in-up"], [1, "rounded-2xl", "overflow-hidden", "border", "border-slate-800", "shadow-2xl", "shadow-emerald-500/10", "bg-slate-900/50", "backdrop-blur-sm", "relative", "group"], [1, "absolute", "inset-0", "bg-gradient-to-t", "from-slate-950/80", "via-transparent", "to-transparent", "pointer-events-none", "z-10"], ["src", "assets/multisig-demo.gif", "alt", "Real-time Multisig Signing Demo", 1, "w-full", "h-auto", "object-cover", "opacity-90", "group-hover:opacity-100", "transition", "duration-700"], [1, "absolute", "top-4", "right-4", "z-30", "p-2", "rounded-lg", "bg-slate-900/50", "hover:bg-emerald-500", "hover:text-slate-950", "border", "border-slate-700", "hover:border-emerald-400", "text-slate-300", "transition-all", "opacity-0", "group-hover:opacity-100", "transform", "translate-y-2", "group-hover:translate-y-0", "duration-300", 3, "click"], ["lucideMaximize", "", 1, "w-5", "h-5"], [1, "absolute", "bottom-6", "left-6", "z-20", "flex", "items-center", "gap-3"], [1, "px-3", "py-1.5", "rounded-full", "bg-black/50", "backdrop-blur-md", "border", "border-slate-700", "text-xs", "text-white", "font-mono", "flex", "items-center", "gap-2"], [1, "w-2", "h-2", "rounded-full", "bg-red-500", "animate-pulse"], [1, "px-3", "py-1.5", "rounded-full", "bg-emerald-500/20", "backdrop-blur-md", "border", "border-emerald-500/30", "text-xs", "text-emerald-400", "font-mono", "font-bold"], [1, "max-w-4xl", "mx-auto", "mt-24", "px-6", "relative", "z-10"], [1, "text-center", "mb-10"], [1, "text-3xl", "font-bold", "text-white", "mb-2"], [1, "text-slate-400"], [1, "grid", "md:grid-cols-2", "gap-8"], [1, "p-8", "rounded-2xl", "bg-slate-900/30", "border", "border-red-900/20", "relative", "overflow-hidden"], [1, "absolute", "top-0", "left-0", "w-full", "h-1", "bg-gradient-to-r", "from-red-500/0", "via-red-500/50", "to-red-500/0"], [1, "text-lg", "font-bold", "text-slate-300", "mb-6", "flex", "items-center", "gap-2"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-red-400"], [1, "space-y-4"], [1, "flex", "items-start", "gap-3", "text-sm", "text-slate-400"], ["lucideXCircle", "", 1, "w-5", "h-5", "text-red-500", "shrink-0"], [1, "p-8", "rounded-2xl", "bg-emerald-900/10", "border", "border-emerald-500/20", "relative", "overflow-hidden"], [1, "absolute", "top-0", "left-0", "w-full", "h-1", "bg-gradient-to-r", "from-emerald-500/0", "via-emerald-500/50", "to-emerald-500/0"], [1, "text-lg", "font-bold", "text-white", "mb-6", "flex", "items-center", "gap-2"], ["lucideZap", "", 1, "w-5", "h-5", "text-emerald-400"], [1, "flex", "items-start", "gap-3", "text-sm", "text-slate-200"], ["lucideCheckCircle2", "", 1, "w-5", "h-5", "text-emerald-400", "shrink-0"], [1, "mt-32", "border-y", "border-slate-800/60", "bg-slate-900/30", "backdrop-blur-sm", "py-20", "relative", "overflow-hidden"], [1, "absolute", "top-1/2", "left-1/2", "-translate-x-1/2", "-translate-y-1/2", "w-[600px]", "h-[600px]", "bg-emerald-500/5", "rounded-full", "blur-[100px]", "pointer-events-none"], [1, "max-w-6xl", "mx-auto", "px-6", "relative", "z-10"], [1, "text-center", "mb-16"], [1, "text-3xl", "font-bold", "text-white", "mb-4"], [1, "text-slate-400", "max-w-2xl", "mx-auto"], [1, "text-emerald-400", "font-medium"], [1, "grid", "grid-cols-1", "md:grid-cols-2", "lg:grid-cols-4", "gap-8"], [1, "p-6", "rounded-2xl", "bg-slate-950/50", "border", "border-slate-800", "hover:border-emerald-500/50", "transition", "group"], [1, "w-12", "h-12", "rounded-lg", "bg-emerald-500/10", "flex", "items-center", "justify-center", "mb-4", "group-hover:scale-110", "transition-transform", "duration-300"], ["lucideEyeOff", "", 1, "w-6", "h-6", "text-emerald-400"], [1, "text-lg", "font-bold", "text-white", "mb-1"], [1, "text-xs", "font-mono", "text-emerald-500", "mb-3", "uppercase", "tracking-wider"], [1, "text-slate-400", "text-sm", "leading-relaxed"], [1, "opacity-50", "mt-2", "block", "border-t", "border-slate-800", "pt-2"], ["lucideScale", "", 1, "w-6", "h-6", "text-emerald-400"], ["lucideShieldCheck", "", 1, "w-6", "h-6", "text-emerald-400"], ["lucideGlobe", "", 1, "w-6", "h-6", "text-emerald-400"], [1, "max-w-6xl", "mx-auto", "mt-24", "px-6", "relative", "z-10"], [1, "relative", "group", "mb-32"], [1, "absolute", "-inset-1", "bg-gradient-to-r", "from-emerald-500/20", "to-cyan-500/20", "rounded-xl", "blur-lg", "opacity-50", "group-hover:opacity-70", "transition", "duration-1000"], [1, "relative", "rounded-xl", "bg-slate-950/80", "backdrop-blur-xl", "border", "border-slate-800", "shadow-2xl", "overflow-hidden", "p-8", "md:p-12"], [1, "flex", "flex-col", "md:flex-row", "items-center", "justify-between", "gap-8"], [1, "flex", "flex-col", "items-center", "text-center"], [1, "w-16", "h-16", "bg-slate-900", "rounded-full", "flex", "items-center", "justify-center", "border", "border-slate-700", "mb-4"], ["lucideUsers", "", 1, "w-8", "h-8", "text-emerald-400"], [1, "text-sm", "font-bold", "text-white"], [1, "text-xs", "text-slate-500"], [1, "flex", "flex-col", "items-center", "gap-2", "flex-1"], [1, "w-full", "h-0.5", "bg-slate-800", "relative"], [1, "absolute", "inset-0", "bg-emerald-500/50", "w-1/2", "animate-pulse"], [1, "px-3", "py-1", "bg-slate-900", "rounded", "border", "border-slate-800", "text-[10px]", "text-emerald-400", "font-mono", "flex", "items-center", "gap-2"], ["lucideLock", "", 1, "w-3", "h-3"], [1, "w-20", "h-20", "bg-slate-900", "rounded-xl", "flex", "items-center", "justify-center", "border", "border-slate-700", "mb-4", "relative"], ["lucideNetwork", "", 1, "w-10", "h-10", "text-slate-600"], [1, "absolute", "-top-3", "-right-3", "bg-rose-500/20", "text-rose-400", "text-[10px]", "px-2", "py-0.5", "rounded", "border", "border-rose-500/30"], [1, "absolute", "right-0", "top-0", "bottom-0", "bg-emerald-500/50", "w-1/2", "animate-pulse"], [1, "px-3", "py-1", "bg-slate-900", "rounded", "border", "border-slate-800", "text-[10px]", "text-cyan-400", "font-mono", "flex", "items-center", "gap-2"], ["lucideFileKey", "", 1, "w-3", "h-3"], ["lucideUsers", "", 1, "w-8", "h-8", "text-cyan-400"], [1, "max-w-5xl", "mx-auto", "mt-24", "px-6", "relative", "z-10"], [1, "text-center", "mb-12"], [1, "grid", "md:grid-cols-3", "gap-6"], [1, "bg-slate-900/40", "border", "border-slate-800", "p-6", "rounded-2xl", "hover:bg-slate-900/60", "transition", "group"], [1, "w-12", "h-12", "bg-indigo-950/30", "rounded-lg", "flex", "items-center", "justify-center", "mb-4", "group-hover:scale-110", "transition-transform"], ["lucideUsers", "", 1, "w-6", "h-6", "text-indigo-400"], [1, "text-lg", "font-bold", "text-white", "mb-2"], [1, "text-sm", "text-slate-400", "leading-relaxed"], [1, "w-12", "h-12", "bg-rose-950/30", "rounded-lg", "flex", "items-center", "justify-center", "mb-4", "group-hover:scale-110", "transition-transform"], ["lucideAlertTriangle", "", 1, "w-6", "h-6", "text-rose-500"], [1, "bg-emerald-950/10", "border", "border-emerald-500/30", "p-6", "rounded-2xl", "hover:bg-emerald-950/20", "transition", "group", "relative", "overflow-hidden"], [1, "absolute", "top-0", "right-0", "w-16", "h-16", "bg-emerald-500/10", "blur-xl", "rounded-full"], [1, "w-12", "h-12", "bg-emerald-950/30", "rounded-lg", "flex", "items-center", "justify-center", "mb-4", "group-hover:scale-110", "transition-transform"], ["lucideZap", "", 1, "w-6", "h-6", "text-emerald-400"], [1, "text-sm", "text-slate-300", "leading-relaxed"], [1, "p-8", "rounded-2xl", "bg-gradient-to-br", "from-slate-900", "to-slate-950", "border", "border-slate-800", "flex", "flex-col", "md:flex-row", "items-center", "gap-8", "shadow-2xl"], [1, "flex-1", "text-left"], [1, "text-xl", "font-bold", "text-white", "mb-3", "flex", "items-center", "gap-2"], ["lucideCode2", "", 1, "w-6", "h-6", "text-emerald-400"], [1, "text-sm", "text-slate-400", "leading-relaxed", "mb-6"], [1, "flex", "flex-wrap", "gap-3"], ["href", "https://www.npmjs.com/package/@signing-room/sdk", "target", "_blank", 1, "px-5", "py-2.5", "rounded-lg", "bg-emerald-500", "hover:bg-emerald-400", "text-slate-950", "font-bold", "text-sm", "transition", "flex", "items-center", "gap-2"], ["lucideExternalLink", "", 1, "w-4", "h-4"], ["href", "https://github.com/scarlin90/signingroom/tree/main/libs/sdk", "target", "_blank", 1, "px-5", "py-2.5", "rounded-lg", "bg-slate-800", "hover:bg-slate-700", "text-white", "font-medium", "text-sm", "transition", "border", "border-slate-700", "flex", "items-center", "gap-2"], ["lucideFileText", "", 1, "w-4", "h-4"], ["href", "https://youtu.be/yzcFlK6c6t0", "target", "_blank", 1, "px-5", "py-2.5", "rounded-lg", "bg-slate-800", "hover:bg-slate-700", "text-white", "font-medium", "text-sm", "transition", "border", "border-slate-700", "flex", "items-center", "gap-2"], ["xmlns", "http://www.w3.org/2000/svg", "width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "w-4", "h-4"], ["d", "M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"], ["d", "m10 15 5-3-5-3z"], [1, "w-full", "md:w-1/3", "bg-black", "rounded-lg", "p-4", "font-mono", "text-[10px]", "text-emerald-400", "border", "border-slate-800", "overflow-x-auto"], ["lucideBuilding2", "", 1, "w-6", "h-6", "text-cyan-400"], ["href", "https://staging-branded.signingroom.io", "target", "_blank", 1, "px-5", "py-2.5", "rounded-lg", "bg-cyan-500/10", "hover:bg-cyan-500/20", "text-cyan-400", "border", "border-cyan-500/30", "font-medium", "text-sm", "transition", "flex", "items-center", "gap-2"], ["src", "brand/branded-logo.svg", "alt", "Zoros Financial", "onerror", "this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjJkM2VlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0iTTIgMTJoMjAiLz48cGF0aCBkPSJNMjIgNkgzIi8+PHBhdGggZD0iTTIgMThoMjAiLz48L3N2Zz4='", 1, "w-4", "h-4", "object-contain"], ["href", "https://statelessresearch.com", "target", "_blank", 1, "px-5", "py-2.5", "rounded-lg", "bg-slate-800", "hover:bg-slate-700", "text-white", "font-medium", "text-sm", "transition", "border", "border-slate-700", "flex", "items-center", "gap-2"], [1, "w-full", "md:w-1/3", "flex", "justify-center"], ["href", "https://staging-branded.signingroom.io", "target", "_blank", 1, "relative", "w-48", "h-48", "block", "group", "cursor-pointer"], [1, "absolute", "inset-0", "bg-cyan-500/20", "rounded-full", "blur-2xl", "animate-pulse", "group-hover:bg-cyan-500/40", "transition-all", "duration-500"], [1, "relative", "w-full", "h-full", "bg-slate-900", "border", "border-slate-700", "group-hover:border-cyan-500/50", "rounded-xl", "flex", "flex-col", "items-center", "justify-center", "p-6", "shadow-xl", "transition-all", "duration-300", "transform", "group-hover:-translate-y-2"], ["src", "brand/branded-logo.svg", "alt", "Custom Branding", "onerror", "this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjJkM2VlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0iTTIgMTJoMjAiLz48cGF0aCBkPSJNMjIgNkgzIi8+PHBhdGggZD0iTTIgMThoMjAiLz48L3N2Zz4='", 1, "w-16", "h-16", "object-contain", "mb-4"], [1, "font-bold", "text-white", "text-lg", "tracking-tight", "leading-none", "mb-1"], [1, "text-xs", "text-cyan-400", "font-medium", "tracking-widest", "uppercase"], [1, "grid", "grid-cols-2", "md:grid-cols-4", "gap-4", "text-center"], [1, "p-4", "rounded-lg", "bg-slate-900/30", "border", "border-slate-800"], ["lucideCpu", "", 1, "w-6", "h-6", "text-slate-500", "mx-auto", "mb-2"], [1, "text-xs", "text-slate-500", "font-mono"], [1, "text-sm", "font-bold", "text-slate-300"], ["lucideLock", "", 1, "w-6", "h-6", "text-slate-500", "mx-auto", "mb-2"], ["lucideNetwork", "", 1, "w-6", "h-6", "text-slate-500", "mx-auto", "mb-2"], ["lucideFingerprint", "", 1, "w-6", "h-6", "text-slate-500", "mx-auto", "mb-2"], [1, "max-w-4xl", "mx-auto", "mt-12", "px-6", "text-center", "relative", "z-10"], [1, "text-slate-500", "text-sm", "font-semibold", "uppercase", "tracking-widest", "mb-8"], [1, "flex", "flex-wrap", "justify-center", "gap-4"], [1, "px-4", "py-2", "rounded-lg", "bg-slate-900", "border", "border-slate-800", "text-slate-300", "text-sm", "font-bold"], [1, "max-w-3xl", "mx-auto", "mt-20", "mb-20", "px-6", "relative", "z-10"], [1, "text-2xl", "font-bold", "text-white", "mb-8", "text-center"], [1, "p-6", "bg-slate-900/50", "rounded-xl", "border", "border-slate-800", "hover:bg-slate-900", "transition"], [1, "font-bold", "text-white", "mb-2", "flex", "items-center", "gap-2"], ["lucideHelpCircle", "", 1, "w-4", "h-4", "text-emerald-400"], [1, "text-slate-300"], [1, "mb-2"], [1, "text-slate-200"], ["lucideBuilding2", "", 1, "w-4", "h-4", "text-cyan-400"], ["href", "https://statelessresearch.com", "target", "_blank", 1, "text-emerald-400", "hover:underline"], [1, "border-t", "border-slate-800", "bg-slate-900/50", "py-20", "text-center", "px-6", "relative", "z-10"], [1, "text-3xl", "font-bold", "text-white", "mb-6"], [1, "text-slate-400", "mb-8", "max-w-lg", "mx-auto"], ["routerLink", "/create", 1, "inline-flex", "px-8", "py-4", "rounded-lg", "bg-emerald-500", "hover:bg-emerald-400", "text-slate-950", "font-bold", "transition-all", "items-center", "gap-2", "shadow-lg", "shadow-emerald-500/20", "cursor-pointer"], ["lucideChevronRight", "", 1, "w-5", "h-5"]], template: function HomeComponent_Template(rf, ctx) {
    if (rf & 1) {
      const _r1 = i0.\u0275\u0275getCurrentView();
      i0.\u0275\u0275elementStart(0, "div", 1);
      i0.\u0275\u0275element(1, "div", 2);
      i0.\u0275\u0275elementStart(2, "a", 3);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(3, "svg", 4);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(4, "span", 5);
      i0.\u0275\u0275text(5, "Open Source (AGPL v3) \u2022 Verify the code");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(6, "svg", 6);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(7, "h1", 7);
      i0.\u0275\u0275text(8, " Signing Room\xAE ");
      i0.\u0275\u0275element(9, "br");
      i0.\u0275\u0275elementStart(10, "span", 8);
      i0.\u0275\u0275text(11, " The Real-Time Bitcoin Multisig Coordinator ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(12, "p", 9);
      i0.\u0275\u0275text(13, " Stop emailing PSBT files. Coordinate Bitcoin multisig teams instantly. ");
      i0.\u0275\u0275element(14, "br", 10);
      i0.\u0275\u0275elementStart(15, "span", 11);
      i0.\u0275\u0275text(16, "No accounts.");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(17, "span", 11);
      i0.\u0275\u0275text(18, "No database.");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(19, "span", 11);
      i0.\u0275\u0275text(20, "End-to-End Encrypted.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(21, "div", 12)(22, "a", 13);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(23, "svg", 14);
      i0.\u0275\u0275text(24, " Start Signing ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(25, "a", 15);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(26, "svg", 16);
      i0.\u0275\u0275text(27, " Whitepaper ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(28, "a", 17);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275elementStart(29, "svg", 18);
      i0.\u0275\u0275element(30, "path", 19)(31, "path", 20);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(32, " TypeScript SDK ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(33, "a", 21);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(34, "svg", 22);
      i0.\u0275\u0275text(35, " Web Component Demo ");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(36, "div", 23)(37, "div", 24, 0);
      i0.\u0275\u0275element(39, "div", 25)(40, "img", 26);
      i0.\u0275\u0275elementStart(41, "button", 27);
      i0.\u0275\u0275listener("click", function HomeComponent_Template_button_click_41_listener() {
        i0.\u0275\u0275restoreView(_r1);
        const demoContainer_r2 = i0.\u0275\u0275reference(38);
        return i0.\u0275\u0275resetView(ctx.toggleFullscreen(demoContainer_r2));
      });
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(42, "svg", 28);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(43, "div", 29)(44, "div", 30);
      i0.\u0275\u0275element(45, "span", 31);
      i0.\u0275\u0275text(46, " Live Preview ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(47, "div", 32);
      i0.\u0275\u0275text(48, " 3-of-5 Multisig ");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275elementStart(49, "div", 33)(50, "div", 34)(51, "h2", 35);
      i0.\u0275\u0275text(52, "Why change your workflow?");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(53, "p", 36);
      i0.\u0275\u0275text(54, "Manual file merging is error-prone and slow. There is a better way.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(55, "div", 37)(56, "div", 38);
      i0.\u0275\u0275element(57, "div", 39);
      i0.\u0275\u0275elementStart(58, "h3", 40);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(59, "svg", 41);
      i0.\u0275\u0275text(60, " The Old Way (Email/Slack) ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(61, "ul", 42)(62, "li", 43);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(63, "svg", 44);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(64, "span");
      i0.\u0275\u0275text(65, "Manually merging 5 different email attachments.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(66, "li", 43);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(67, "svg", 44);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(68, "span");
      i0.\u0275\u0275text(69, "Files stored permanently on Slack/Google servers.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(70, "li", 43);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(71, "svg", 44);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(72, "span");
      i0.\u0275\u0275text(73, "Slow, asynchronous delays between signers.");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275elementStart(74, "div", 45);
      i0.\u0275\u0275element(75, "div", 46);
      i0.\u0275\u0275elementStart(76, "h3", 47);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(77, "svg", 48);
      i0.\u0275\u0275text(78, " The Signing Room\xAE Way ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(79, "ul", 42)(80, "li", 49);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(81, "svg", 50);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(82, "span");
      i0.\u0275\u0275text(83, "Real-time merging. Everyone sees the same state.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(84, "li", 49);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(85, "svg", 50);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(86, "span");
      i0.\u0275\u0275text(87, "Data lives in RAM, encrypted, and vanishes on expiry.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(88, "li", 49);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(89, "svg", 50);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(90, "span");
      i0.\u0275\u0275text(91, "Instant broadcast once signatures are collected.");
      i0.\u0275\u0275elementEnd()()()()()();
      i0.\u0275\u0275elementStart(92, "section", 51);
      i0.\u0275\u0275element(93, "div", 52);
      i0.\u0275\u0275elementStart(94, "div", 53)(95, "div", 54)(96, "h2", 55);
      i0.\u0275\u0275text(97, "Code is Law. Physics is Enforcement.");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(98, "p", 56);
      i0.\u0275\u0275text(99, " We enforce the ");
      i0.\u0275\u0275elementStart(100, "span", 57);
      i0.\u0275\u0275text(101, "Universal Declaration of Human Rights");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(102, " not through policy, but through cryptographic guarantees. ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(103, "div", 58)(104, "div", 59)(105, "div", 60);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(106, "svg", 61);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(107, "h3", 62);
      i0.\u0275\u0275text(108, "Article 12");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(109, "div", 63);
      i0.\u0275\u0275text(110, "Privacy");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(111, "p", 64);
      i0.\u0275\u0275text(112, ' "No one shall be subjected to arbitrary interference with his privacy." ');
      i0.\u0275\u0275element(113, "br");
      i0.\u0275\u0275elementStart(114, "span", 65);
      i0.\u0275\u0275text(115, "Enforced via AES-256-GCM.");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(116, "div", 59)(117, "div", 60);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(118, "svg", 66);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(119, "h3", 62);
      i0.\u0275\u0275text(120, "Article 20");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(121, "div", 63);
      i0.\u0275\u0275text(122, "Assembly");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(123, "p", 64);
      i0.\u0275\u0275text(124, ' "Everyone has the right to freedom of peaceful assembly and association." ');
      i0.\u0275\u0275element(125, "br");
      i0.\u0275\u0275elementStart(126, "span", 65);
      i0.\u0275\u0275text(127, "Enforced via Ephemeral Rooms.");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(128, "div", 59)(129, "div", 60);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(130, "svg", 67);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(131, "h3", 62);
      i0.\u0275\u0275text(132, "Article 17");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(133, "div", 63);
      i0.\u0275\u0275text(134, "Property");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(135, "p", 64);
      i0.\u0275\u0275text(136, ' "No one shall be arbitrarily deprived of his property." ');
      i0.\u0275\u0275element(137, "br");
      i0.\u0275\u0275elementStart(138, "span", 65);
      i0.\u0275\u0275text(139, "Enforced via Non-Custodial Multisig.");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(140, "div", 59)(141, "div", 60);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(142, "svg", 68);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(143, "h3", 62);
      i0.\u0275\u0275text(144, "Article 19");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(145, "div", 63);
      i0.\u0275\u0275text(146, "Expression");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(147, "p", 64);
      i0.\u0275\u0275text(148, ' "Right to freedom of opinion and expression... through any media." ');
      i0.\u0275\u0275element(149, "br");
      i0.\u0275\u0275elementStart(150, "span", 65);
      i0.\u0275\u0275text(151, "Enforced via Unstoppable Code.");
      i0.\u0275\u0275elementEnd()()()()()();
      i0.\u0275\u0275elementStart(152, "div", 69)(153, "div", 34)(154, "h2", 35);
      i0.\u0275\u0275text(155, "The Blind Relay");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(156, "p", 36);
      i0.\u0275\u0275text(157, "We forward your encrypted packets. We never hold the keys.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(158, "div", 70);
      i0.\u0275\u0275element(159, "div", 71);
      i0.\u0275\u0275elementStart(160, "div", 72)(161, "div", 73)(162, "div", 74)(163, "div", 75);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(164, "svg", 76);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(165, "div", 77);
      i0.\u0275\u0275text(166, "Client Side");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(167, "div", 78);
      i0.\u0275\u0275text(168, "Encrypts with Key");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(169, "div", 79)(170, "div", 80);
      i0.\u0275\u0275element(171, "div", 81);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(172, "div", 82);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(173, "svg", 83);
      i0.\u0275\u0275text(174, " AES-256-GCM ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(175, "div", 74)(176, "div", 84);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(177, "svg", 85);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(178, "div", 86);
      i0.\u0275\u0275text(179, "BLIND");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(180, "div", 77);
      i0.\u0275\u0275text(181, "The Room (Server)");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(182, "div", 78);
      i0.\u0275\u0275text(183, "Stores Encrypted Blob");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(184, "div", 79)(185, "div", 80);
      i0.\u0275\u0275element(186, "div", 87);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(187, "div", 88);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(188, "svg", 89);
      i0.\u0275\u0275text(189, " Sync State ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(190, "div", 74)(191, "div", 75);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(192, "svg", 90);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(193, "div", 77);
      i0.\u0275\u0275text(194, "Peer Side");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(195, "div", 78);
      i0.\u0275\u0275text(196, "Decrypts via Secret Link");
      i0.\u0275\u0275elementEnd()()()()()();
      i0.\u0275\u0275elementStart(197, "div", 91)(198, "div", 92)(199, "h2", 55);
      i0.\u0275\u0275text(200, "Built for Organizational Resilience");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(201, "p", 56);
      i0.\u0275\u0275text(202, " Single-signature wallets are a liability for teams. ");
      i0.\u0275\u0275element(203, "br");
      i0.\u0275\u0275text(204, "Multisig ensures no single person\u2014not even the CEO\u2014is a single point of failure. ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(205, "div", 93)(206, "div", 94)(207, "div", 95);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(208, "svg", 96);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(209, "h3", 97);
      i0.\u0275\u0275text(210, 'Flexible "M-of-N" Consensus');
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(211, "p", 98);
      i0.\u0275\u0275text(212, " Don't be locked into a rigid structure. Whether you need a ");
      i0.\u0275\u0275elementStart(213, "strong");
      i0.\u0275\u0275text(214, "2-of-3");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(215, " for founders or a ");
      i0.\u0275\u0275elementStart(216, "strong");
      i0.\u0275\u0275text(217, "3-of-5");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(218, " for the board, you define the quorum required to authorize funds. ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(219, "div", 94)(220, "div", 99);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(221, "svg", 100);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(222, "h3", 97);
      i0.\u0275\u0275text(223, 'Mitigate "Key Person" Risk');
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(224, "p", 98);
      i0.\u0275\u0275text(225, " What if the CEO is in an accident or loses access to their keys? In a multisig setup, the remaining board members can still approve payroll, ensuring business continuity. ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(226, "div", 101);
      i0.\u0275\u0275element(227, "div", 102);
      i0.\u0275\u0275elementStart(228, "div", 103);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(229, "svg", 104);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(230, "h3", 97);
      i0.\u0275\u0275text(231, "Security without the friction");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(232, "p", 105);
      i0.\u0275\u0275text(233, " Historically, coordinating a board vote on-chain was slow and painful. SigningRoom fixes this. We combine the ");
      i0.\u0275\u0275elementStart(234, "strong");
      i0.\u0275\u0275text(235, "governance");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(236, " of multisig with the ");
      i0.\u0275\u0275elementStart(237, "strong");
      i0.\u0275\u0275text(238, "speed");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(239, " of a real-time chat room. ");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275elementStart(240, "div", 33)(241, "div", 34)(242, "h2", 35);
      i0.\u0275\u0275text(243, "Build with Signing Room SDK");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(244, "p", 36);
      i0.\u0275\u0275text(245, "Integrate our robust multisig coordination logic into your own applications.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(246, "div", 106)(247, "div", 107)(248, "h3", 108);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(249, "svg", 109);
      i0.\u0275\u0275text(250, " Signing Room SDK ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(251, "p", 110);
      i0.\u0275\u0275text(252, " A framework-agnostic TypeScript SDK for managing end-to-end encrypted multisig ceremonies. Handle room lifecycle, PSBT merging, and audit trail generation programmatically. ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(253, "div", 111)(254, "a", 112);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(255, "svg", 113);
      i0.\u0275\u0275text(256, " View on NPM ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(257, "a", 114);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(258, "svg", 115);
      i0.\u0275\u0275text(259, " Read Docs ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(260, "a", 116);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275elementStart(261, "svg", 117);
      i0.\u0275\u0275element(262, "path", 118)(263, "path", 119);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(264, " Watch ");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(265, "div", 120);
      i0.\u0275\u0275text(266, " npm install @signing-room/sdk");
      i0.\u0275\u0275element(267, "br")(268, "br");
      i0.\u0275\u0275text(269, " const client = new SigningRoomClient({");
      i0.\u0275\u0275element(270, "br");
      i0.\u0275\u0275text(271, " \xA0\xA0apiUrl: '...'");
      i0.\u0275\u0275element(272, "br");
      i0.\u0275\u0275text(273, " });");
      i0.\u0275\u0275element(274, "br")(275, "br");
      i0.\u0275\u0275text(276, " await client.createRoomAndJoin(...); ");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(277, "div", 33)(278, "div", 34)(279, "h2", 35);
      i0.\u0275\u0275text(280, "Commercial Whitelabeling");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(281, "p", 36);
      i0.\u0275\u0275text(282, "Deploy a dedicated, branded instance for your enterprise or institution.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(283, "div", 106)(284, "div", 107)(285, "h3", 108);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(286, "svg", 121);
      i0.\u0275\u0275text(287, " Enterprise Self-Hosting ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(288, "p", 110);
      i0.\u0275\u0275text(289, " Maintain complete sovereignty over your coordination layer. Deploy Signing Room to your own infrastructure with a custom domain, tailored branding, and full commercial support via an AGPL waiver. ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(290, "div", 111)(291, "a", 122);
      i0.\u0275\u0275element(292, "img", 123);
      i0.\u0275\u0275text(293, " Zoros Financial (Demo) ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(294, "a", 124);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(295, "svg", 113);
      i0.\u0275\u0275text(296, " Contact Sales ");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(297, "div", 125)(298, "a", 126);
      i0.\u0275\u0275element(299, "div", 127);
      i0.\u0275\u0275elementStart(300, "div", 128);
      i0.\u0275\u0275element(301, "img", 129);
      i0.\u0275\u0275elementStart(302, "div", 130);
      i0.\u0275\u0275text(303, "Zoros");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(304, "div", 131);
      i0.\u0275\u0275text(305, "Financial");
      i0.\u0275\u0275elementEnd()()()()()();
      i0.\u0275\u0275elementStart(306, "div", 33)(307, "div", 34)(308, "h2", 35);
      i0.\u0275\u0275text(309, "Technical Standards");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(310, "p", 36);
      i0.\u0275\u0275text(311, "Built on open Bitcoin protocols and industrial encryption.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(312, "div", 132)(313, "div", 133);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(314, "svg", 134);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(315, "div", 135);
      i0.\u0275\u0275text(316, "BIP-174");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(317, "div", 136);
      i0.\u0275\u0275text(318, "PSBT Native");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(319, "div", 133);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(320, "svg", 137);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(321, "div", 135);
      i0.\u0275\u0275text(322, "AES-GCM");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(323, "div", 136);
      i0.\u0275\u0275text(324, "End-to-End Encrypted");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(325, "div", 133);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(326, "svg", 138);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(327, "div", 135);
      i0.\u0275\u0275text(328, "WebSocket");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(329, "div", 136);
      i0.\u0275\u0275text(330, "Real-time");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(331, "div", 133);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(332, "svg", 139);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(333, "div", 135);
      i0.\u0275\u0275text(334, "Ephemeral");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(335, "div", 136);
      i0.\u0275\u0275text(336, "No Logs");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275elementStart(337, "div", 140)(338, "p", 141);
      i0.\u0275\u0275text(339, "Compatible with your Hardware Wallets & Software");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(340, "div", 142)(341, "span", 143);
      i0.\u0275\u0275text(342, "Sparrow");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(343, "span", 143);
      i0.\u0275\u0275text(344, "Electrum");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(345, "span", 143);
      i0.\u0275\u0275text(346, "Coldcard");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(347, "span", 143);
      i0.\u0275\u0275text(348, "Trezor");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(349, "span", 143);
      i0.\u0275\u0275text(350, "Ledger");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(351, "span", 143);
      i0.\u0275\u0275text(352, "Nunchuk");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(353, "span", 143);
      i0.\u0275\u0275text(354, "BitBox02");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(355, "div", 144)(356, "h2", 145);
      i0.\u0275\u0275text(357, "Frequently Asked Questions");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(358, "div", 42)(359, "div", 146)(360, "h3", 147);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(361, "svg", 148);
      i0.\u0275\u0275text(362, " Where is my private key? ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(363, "p", 64);
      i0.\u0275\u0275text(364, " It stays on your hardware wallet or signing device. You only upload a ");
      i0.\u0275\u0275elementStart(365, "span", 149);
      i0.\u0275\u0275text(366, "PSBT (Partially Signed Bitcoin Transaction)");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(367, ", which contains no private keys, only public data and signatures. ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(368, "div", 146)(369, "h3", 147);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(370, "svg", 148);
      i0.\u0275\u0275text(371, " Can you see my transaction details? ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(372, "p", 64);
      i0.\u0275\u0275text(373, " No. Your transaction is encrypted in your browser using a key that is contained in the URL link hash (fragment). This key is never sent to our servers, so we literally cannot decrypt your data. ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(374, "div", 146)(375, "h3", 147);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(376, "svg", 148);
      i0.\u0275\u0275text(377, " Is it really free? ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(378, "div", 64)(379, "p", 150)(380, "strong", 151);
      i0.\u0275\u0275text(381, "Yes.");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(382, " SigningRoom.io is a 100% free, open-source public good. ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(383, "p");
      i0.\u0275\u0275text(384, " We cover our costs through optional donations and enterprise licensing. There are no paid tiers for the public service. ");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(385, "div", 146)(386, "h3", 147);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(387, "svg", 152);
      i0.\u0275\u0275text(388, " Can I host this myself? (Enterprise) ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(389, "div", 64)(390, "p", 150)(391, "strong", 151);
      i0.\u0275\u0275text(392, "Yes.");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(393, " The code is open source (AGPL v3), so you can audit and run it yourself. ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(394, "p");
      i0.\u0275\u0275text(395, " For institutions requiring a commercial license (AGPL waiver) to integrate into proprietary, closed-source infrastructure, please contact ");
      i0.\u0275\u0275elementStart(396, "a", 153);
      i0.\u0275\u0275text(397, "Stateless Research Ltd");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(398, ". ");
      i0.\u0275\u0275elementEnd()()()()();
      i0.\u0275\u0275elementStart(399, "div", 154)(400, "h2", 155);
      i0.\u0275\u0275text(401, "Ready to coordinate?");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(402, "p", 156);
      i0.\u0275\u0275text(403, " No accounts required. Just upload a PSBT and share the secure link. ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(404, "a", 157);
      i0.\u0275\u0275text(405, " Start Signing ");
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(406, "svg", 158);
      i0.\u0275\u0275elementEnd()();
    }
  }, dependencies: [
    RouterModule,
    i1.RouterOutlet,
    i1.RouterLink,
    i1.RouterLinkActive,
    i1.\u0275EmptyOutletComponent,
    LucideZap,
    LucideUsers,
    LucideTerminal,
    LucideChevronRight,
    LucideLock,
    LucideCode2,
    LucideHelpCircle,
    LucideGlobe,
    LucideXCircle,
    LucideCheckCircle2,
    LucideAlertTriangle,
    LucideNetwork,
    LucideFileKey,
    LucideCpu,
    LucideFingerprint,
    LucideMaximize,
    LucideScale,
    LucideEyeOff,
    LucideShieldCheck,
    LucideFileText,
    LucideBuilding2,
    LucideExternalLink
  ], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(HomeComponent, [{
    type: Component,
    args: [{
      selector: "app-home",
      standalone: true,
      imports: [
        RouterModule,
        LucideZap,
        LucideUsers,
        LucideTerminal,
        LucideChevronRight,
        LucideLock,
        LucideCode2,
        LucideHelpCircle,
        LucideGlobe,
        LucideXCircle,
        LucideCheckCircle2,
        LucideAlertTriangle,
        LucideNetwork,
        LucideFileKey,
        LucideCpu,
        LucideFingerprint,
        LucideMaximize,
        LucideScale,
        LucideEyeOff,
        LucideShieldCheck,
        LucideFileText,
        LucideBuilding2,
        LucideExternalLink
      ],
      template: `
    <div class="max-w-6xl mx-auto text-center pt-24 px-6 relative">
       
       <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none"></div>

       <a href="https://github.com/scarlin90/SigningRoom" target="_blank" class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 backdrop-blur-md border border-slate-700 text-slate-400 hover:text-white hover:border-slate-600 transition mb-8 cursor-pointer group relative z-10">
        <svg lucideCode2 class="w-3 h-3 text-emerald-400"></svg>
        <span class="text-xs font-medium">Open Source (AGPL v3) &bull; Verify the code</span>
        <svg lucideChevronRight class="w-3 h-3 group-hover:translate-x-0.5 transition-transform"></svg>
      </a>

      <h1 class="text-5xl md:text-7xl font-extrabold tracking-tight text-white mb-6 leading-tight relative z-10">
        Signing Room\xAE <br />
        <span class="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400 text-3xl md:text-5xl">
          The Real-Time Bitcoin Multisig Coordinator
        </span>
      </h1>

      <p class="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed relative z-10">
        Stop emailing PSBT files. Coordinate Bitcoin multisig teams instantly.
        <br class="hidden md:block" />
        <span class="text-slate-200 font-semibold">No accounts.</span> 
        <span class="text-slate-200 font-semibold">No database.</span> 
        <span class="text-slate-200 font-semibold">End-to-End Encrypted.</span>
      </p>

      <div class="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10">
        <a routerLink="/create" class="px-8 py-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)] cursor-pointer w-full sm:w-auto justify-center hover:scale-105 transform duration-200">
          <svg lucideZap class="w-5 h-5 fill-slate-950"></svg>
          Start Signing
        </a>
        
        <a href="https://arxiv.org/abs/2601.17875" target="_blank" class="px-8 py-4 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-medium transition-all flex items-center gap-2 border border-slate-700 hover:border-slate-600 w-full sm:w-auto justify-center">
          <svg lucideFileText class="w-5 h-5 text-emerald-400"></svg>
          Whitepaper
        </a>

        <a href="https://github.com/scarlin90/signingroom/tree/main/libs/sdk" target="_blank" class="px-8 py-4 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-white font-medium transition-all flex items-center gap-2 border border-slate-700 hover:border-slate-600 w-full sm:w-auto justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>
          TypeScript SDK
        </a>

        <a href="/webcomponent-demo.html?ngsw-bypass=true" target="_blank" rel="external noopener noreferrer"  class="px-8 py-4 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-white font-medium transition-all flex items-center gap-2 border border-slate-700 hover:border-slate-600 w-full sm:w-auto justify-center">
          <svg lucideTerminal class="w-4 h-4"></svg>
          Web Component Demo
      </a>
      </div>
    </div>

    <div class="max-w-5xl mx-auto mt-16 px-6 relative z-10 animate-fade-in-up">
        <div #demoContainer class="rounded-2xl overflow-hidden border border-slate-800 shadow-2xl shadow-emerald-500/10 bg-slate-900/50 backdrop-blur-sm relative group">
            
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none z-10"></div>
            
            <img src="assets/multisig-demo.gif" alt="Real-time Multisig Signing Demo" class="w-full h-auto object-cover opacity-90 group-hover:opacity-100 transition duration-700">
            
            <button (click)="toggleFullscreen(demoContainer)" class="absolute top-4 right-4 z-30 p-2 rounded-lg bg-slate-900/50 hover:bg-emerald-500 hover:text-slate-950 border border-slate-700 hover:border-emerald-400 text-slate-300 transition-all opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 duration-300">
                <svg lucideMaximize class="w-5 h-5"></svg>
            </button>

            <div class="absolute bottom-6 left-6 z-20 flex items-center gap-3">
                <div class="px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-slate-700 text-xs text-white font-mono flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                    Live Preview
                </div>
                <div class="px-3 py-1.5 rounded-full bg-emerald-500/20 backdrop-blur-md border border-emerald-500/30 text-xs text-emerald-400 font-mono font-bold">
                    3-of-5 Multisig
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto mt-24 px-6 relative z-10">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-white mb-2">Why change your workflow?</h2>
            <p class="text-slate-400">Manual file merging is error-prone and slow. There is a better way.</p>
        </div>

        <div class="grid md:grid-cols-2 gap-8">
            <div class="p-8 rounded-2xl bg-slate-900/30 border border-red-900/20 relative overflow-hidden">
                <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500/0 via-red-500/50 to-red-500/0"></div>
                <h3 class="text-lg font-bold text-slate-300 mb-6 flex items-center gap-2">
                    <svg lucideAlertTriangle class="w-5 h-5 text-red-400"></svg>
                    The Old Way (Email/Slack)
                </h3>
                <ul class="space-y-4">
                    <li class="flex items-start gap-3 text-sm text-slate-400">
                        <svg lucideXCircle class="w-5 h-5 text-red-500 shrink-0"></svg>
                        <span>Manually merging 5 different email attachments.</span>
                    </li>
                    <li class="flex items-start gap-3 text-sm text-slate-400">
                        <svg lucideXCircle class="w-5 h-5 text-red-500 shrink-0"></svg>
                        <span>Files stored permanently on Slack/Google servers.</span>
                    </li>
                    <li class="flex items-start gap-3 text-sm text-slate-400">
                        <svg lucideXCircle class="w-5 h-5 text-red-500 shrink-0"></svg>
                        <span>Slow, asynchronous delays between signers.</span>
                    </li>
                </ul>
            </div>

            <div class="p-8 rounded-2xl bg-emerald-900/10 border border-emerald-500/20 relative overflow-hidden">
                <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500/0 via-emerald-500/50 to-emerald-500/0"></div>
                <h3 class="text-lg font-bold text-white mb-6 flex items-center gap-2">
                    <svg lucideZap class="w-5 h-5 text-emerald-400"></svg>
                    The Signing Room\xAE Way
                </h3>
                <ul class="space-y-4">
                    <li class="flex items-start gap-3 text-sm text-slate-200">
                        <svg lucideCheckCircle2 class="w-5 h-5 text-emerald-400 shrink-0"></svg>
                        <span>Real-time merging. Everyone sees the same state.</span>
                    </li>
                    <li class="flex items-start gap-3 text-sm text-slate-200">
                        <svg lucideCheckCircle2 class="w-5 h-5 text-emerald-400 shrink-0"></svg>
                        <span>Data lives in RAM, encrypted, and vanishes on expiry.</span>
                    </li>
                    <li class="flex items-start gap-3 text-sm text-slate-200">
                        <svg lucideCheckCircle2 class="w-5 h-5 text-emerald-400 shrink-0"></svg>
                        <span>Instant broadcast once signatures are collected.</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <section class="mt-32 border-y border-slate-800/60 bg-slate-900/30 backdrop-blur-sm py-20 relative overflow-hidden">
      <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div class="max-w-6xl mx-auto px-6 relative z-10">
        <div class="text-center mb-16">
          <h2 class="text-3xl font-bold text-white mb-4">Code is Law. Physics is Enforcement.</h2>
          <p class="text-slate-400 max-w-2xl mx-auto">
            We enforce the <span class="text-emerald-400 font-medium">Universal Declaration of Human Rights</span> 
            not through policy, but through cryptographic guarantees.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          <div class="p-6 rounded-2xl bg-slate-950/50 border border-slate-800 hover:border-emerald-500/50 transition group">
            <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <svg lucideEyeOff class="w-6 h-6 text-emerald-400"></svg>
            </div>
            <h3 class="text-lg font-bold text-white mb-1">Article 12</h3>
            <div class="text-xs font-mono text-emerald-500 mb-3 uppercase tracking-wider">Privacy</div>
            <p class="text-slate-400 text-sm leading-relaxed">
              "No one shall be subjected to arbitrary interference with his privacy."
              <br/><span class="opacity-50 mt-2 block border-t border-slate-800 pt-2">Enforced via AES-256-GCM.</span>
            </p>
          </div>

          <div class="p-6 rounded-2xl bg-slate-950/50 border border-slate-800 hover:border-emerald-500/50 transition group">
            <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <svg lucideScale class="w-6 h-6 text-emerald-400"></svg>
            </div>
            <h3 class="text-lg font-bold text-white mb-1">Article 20</h3>
            <div class="text-xs font-mono text-emerald-500 mb-3 uppercase tracking-wider">Assembly</div>
            <p class="text-slate-400 text-sm leading-relaxed">
              "Everyone has the right to freedom of peaceful assembly and association."
              <br/><span class="opacity-50 mt-2 block border-t border-slate-800 pt-2">Enforced via Ephemeral Rooms.</span>
            </p>
          </div>

          <div class="p-6 rounded-2xl bg-slate-950/50 border border-slate-800 hover:border-emerald-500/50 transition group">
            <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <svg lucideShieldCheck class="w-6 h-6 text-emerald-400"></svg>
            </div>
            <h3 class="text-lg font-bold text-white mb-1">Article 17</h3>
            <div class="text-xs font-mono text-emerald-500 mb-3 uppercase tracking-wider">Property</div>
            <p class="text-slate-400 text-sm leading-relaxed">
              "No one shall be arbitrarily deprived of his property."
              <br/><span class="opacity-50 mt-2 block border-t border-slate-800 pt-2">Enforced via Non-Custodial Multisig.</span>
            </p>
          </div>

          <div class="p-6 rounded-2xl bg-slate-950/50 border border-slate-800 hover:border-emerald-500/50 transition group">
            <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <svg lucideGlobe class="w-6 h-6 text-emerald-400"></svg>
            </div>
            <h3 class="text-lg font-bold text-white mb-1">Article 19</h3>
            <div class="text-xs font-mono text-emerald-500 mb-3 uppercase tracking-wider">Expression</div>
            <p class="text-slate-400 text-sm leading-relaxed">
              "Right to freedom of opinion and expression... through any media."
              <br/><span class="opacity-50 mt-2 block border-t border-slate-800 pt-2">Enforced via Unstoppable Code.</span>
            </p>
          </div>

        </div>
      </div>
    </section>

    <div class="max-w-6xl mx-auto mt-24 px-6 relative z-10">
        
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-white mb-2">The Blind Relay</h2>
            <p class="text-slate-400">We forward your encrypted packets. We never hold the keys.</p>
        </div>

        <div class="relative group mb-32">
            <div class="absolute -inset-1 bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 rounded-xl blur-lg opacity-50 group-hover:opacity-70 transition duration-1000"></div>
            <div class="relative rounded-xl bg-slate-950/80 backdrop-blur-xl border border-slate-800 shadow-2xl overflow-hidden p-8 md:p-12">
                <div class="flex flex-col md:flex-row items-center justify-between gap-8">
                    
                    <div class="flex flex-col items-center text-center">
                        <div class="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center border border-slate-700 mb-4">
                            <svg lucideUsers class="w-8 h-8 text-emerald-400"></svg>
                        </div>
                        <div class="text-sm font-bold text-white">Client Side</div>
                        <div class="text-xs text-slate-500">Encrypts with Key</div>
                    </div>

                    <div class="flex flex-col items-center gap-2 flex-1">
                        <div class="w-full h-0.5 bg-slate-800 relative">
                            <div class="absolute inset-0 bg-emerald-500/50 w-1/2 animate-pulse"></div>
                        </div>
                        <div class="px-3 py-1 bg-slate-900 rounded border border-slate-800 text-[10px] text-emerald-400 font-mono flex items-center gap-2">
                            <svg lucideLock class="w-3 h-3"></svg> AES-256-GCM
                        </div>
                    </div>

                    <div class="flex flex-col items-center text-center">
                        <div class="w-20 h-20 bg-slate-900 rounded-xl flex items-center justify-center border border-slate-700 mb-4 relative">
                            <svg lucideNetwork class="w-10 h-10 text-slate-600"></svg>
                            <div class="absolute -top-3 -right-3 bg-rose-500/20 text-rose-400 text-[10px] px-2 py-0.5 rounded border border-rose-500/30">BLIND</div>
                        </div>
                        <div class="text-sm font-bold text-white">The Room (Server)</div>
                        <div class="text-xs text-slate-500">Stores Encrypted Blob</div>
                    </div>

                    <div class="flex flex-col items-center gap-2 flex-1">
                        <div class="w-full h-0.5 bg-slate-800 relative">
                            <div class="absolute right-0 top-0 bottom-0 bg-emerald-500/50 w-1/2 animate-pulse"></div>
                        </div>
                         <div class="px-3 py-1 bg-slate-900 rounded border border-slate-800 text-[10px] text-cyan-400 font-mono flex items-center gap-2">
                            <svg lucideFileKey class="w-3 h-3"></svg> Sync State
                        </div>
                    </div>

                    <div class="flex flex-col items-center text-center">
                        <div class="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center border border-slate-700 mb-4">
                            <svg lucideUsers class="w-8 h-8 text-cyan-400"></svg>
                        </div>
                        <div class="text-sm font-bold text-white">Peer Side</div>
                        <div class="text-xs text-slate-500">Decrypts via Secret Link</div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="max-w-5xl mx-auto mt-24 px-6 relative z-10">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-white mb-4">Built for Organizational Resilience</h2>
            <p class="text-slate-400 max-w-2xl mx-auto">
                Single-signature wallets are a liability for teams. 
                <br>Multisig ensures no single person\u2014not even the CEO\u2014is a single point of failure.
            </p>
        </div>

        <div class="grid md:grid-cols-3 gap-6">
            <div class="bg-slate-900/40 border border-slate-800 p-6 rounded-2xl hover:bg-slate-900/60 transition group">
                <div class="w-12 h-12 bg-indigo-950/30 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <svg lucideUsers class="w-6 h-6 text-indigo-400"></svg>
                </div>
                <h3 class="text-lg font-bold text-white mb-2">Flexible "M-of-N" Consensus</h3>
                <p class="text-sm text-slate-400 leading-relaxed">
                    Don't be locked into a rigid structure. Whether you need a <strong>2-of-3</strong> for founders or a <strong>3-of-5</strong> for the board, you define the quorum required to authorize funds.
                </p>
            </div>

            <div class="bg-slate-900/40 border border-slate-800 p-6 rounded-2xl hover:bg-slate-900/60 transition group">
                <div class="w-12 h-12 bg-rose-950/30 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <svg lucideAlertTriangle class="w-6 h-6 text-rose-500"></svg>
                </div>
                <h3 class="text-lg font-bold text-white mb-2">Mitigate "Key Person" Risk</h3>
                <p class="text-sm text-slate-400 leading-relaxed">
                    What if the CEO is in an accident or loses access to their keys? In a multisig setup, the remaining board members can still approve payroll, ensuring business continuity.
                </p>
            </div>

            <div class="bg-emerald-950/10 border border-emerald-500/30 p-6 rounded-2xl hover:bg-emerald-950/20 transition group relative overflow-hidden">
                <div class="absolute top-0 right-0 w-16 h-16 bg-emerald-500/10 blur-xl rounded-full"></div>
                <div class="w-12 h-12 bg-emerald-950/30 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <svg lucideZap class="w-6 h-6 text-emerald-400"></svg>
                </div>
                <h3 class="text-lg font-bold text-white mb-2">Security without the friction</h3>
                <p class="text-sm text-slate-300 leading-relaxed">
                    Historically, coordinating a board vote on-chain was slow and painful. SigningRoom fixes this. We combine the <strong>governance</strong> of multisig with the <strong>speed</strong> of a real-time chat room.
                </p>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto mt-24 px-6 relative z-10">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-white mb-2">Build with Signing Room SDK</h2>
            <p class="text-slate-400">Integrate our robust multisig coordination logic into your own applications.</p>
        </div>

        <div class="p-8 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 flex flex-col md:flex-row items-center gap-8 shadow-2xl">
            <div class="flex-1 text-left">
                <h3 class="text-xl font-bold text-white mb-3 flex items-center gap-2">
                    <svg lucideCode2 class="w-6 h-6 text-emerald-400"></svg>
                    Signing Room SDK
                </h3>
                <p class="text-sm text-slate-400 leading-relaxed mb-6">
                    A framework-agnostic TypeScript SDK for managing end-to-end encrypted multisig ceremonies. 
                    Handle room lifecycle, PSBT merging, and audit trail generation programmatically.
                </p>
                <div class="flex flex-wrap gap-3">
                    <a href="https://www.npmjs.com/package/@signing-room/sdk" target="_blank" class="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition flex items-center gap-2">
                        <svg lucideExternalLink class="w-4 h-4"></svg>
                        View on NPM
                    </a>
                    <a href="https://github.com/scarlin90/signingroom/tree/main/libs/sdk" target="_blank" class="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-sm transition border border-slate-700 flex items-center gap-2">
                        <svg lucideFileText class="w-4 h-4"></svg>
                        Read Docs
                    </a>
                    <a href="https://youtu.be/yzcFlK6c6t0" target="_blank" class="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-sm transition border border-slate-700 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/></svg>
                        Watch
                    </a>
                </div>
            </div>
            <div class="w-full md:w-1/3 bg-black rounded-lg p-4 font-mono text-[10px] text-emerald-400 border border-slate-800 overflow-x-auto">
                npm install @signing-room/sdk<br><br>
                const client = new SigningRoomClient(&#123;<br>
                &nbsp;&nbsp;apiUrl: '...'<br>
                &#125;);<br><br>
                await client.createRoomAndJoin(...);
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto mt-24 px-6 relative z-10">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-white mb-2">Commercial Whitelabeling</h2>
            <p class="text-slate-400">Deploy a dedicated, branded instance for your enterprise or institution.</p>
        </div>

        <div class="p-8 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 flex flex-col md:flex-row items-center gap-8 shadow-2xl">
            <div class="flex-1 text-left">
                <h3 class="text-xl font-bold text-white mb-3 flex items-center gap-2">
                    <svg lucideBuilding2 class="w-6 h-6 text-cyan-400"></svg>
                    Enterprise Self-Hosting
                </h3>
                <p class="text-sm text-slate-400 leading-relaxed mb-6">
                    Maintain complete sovereignty over your coordination layer. 
                    Deploy Signing Room to your own infrastructure with a custom domain, tailored branding, and full commercial support via an AGPL waiver.
                </p>
                <div class="flex flex-wrap gap-3">
                    <a href="https://staging-branded.signingroom.io" target="_blank" class="px-5 py-2.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 font-medium text-sm transition flex items-center gap-2">
                        <!-- Small fallback SVG if branded-logo is missing in the unbranded environment -->
                        <img src="brand/branded-logo.svg" alt="Zoros Financial" class="w-4 h-4 object-contain" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjJkM2VlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0iTTIgMTJoMjAiLz48cGF0aCBkPSJNMjIgNkgzIi8+PHBhdGggZD0iTTIgMThoMjAiLz48L3N2Zz4='">
                        Zoros Financial (Demo)
                    </a>
                    <a href="https://statelessresearch.com" target="_blank" class="px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-sm transition border border-slate-700 flex items-center gap-2">
                        <svg lucideExternalLink class="w-4 h-4"></svg>
                        Contact Sales
                    </a>
                </div>
            </div>
            <div class="w-full md:w-1/3 flex justify-center">
                 <a href="https://staging-branded.signingroom.io" target="_blank" class="relative w-48 h-48 block group cursor-pointer">
                    <div class="absolute inset-0 bg-cyan-500/20 rounded-full blur-2xl animate-pulse group-hover:bg-cyan-500/40 transition-all duration-500"></div>
                    <div class="relative w-full h-full bg-slate-900 border border-slate-700 group-hover:border-cyan-500/50 rounded-xl flex flex-col items-center justify-center p-6 shadow-xl transition-all duration-300 transform group-hover:-translate-y-2">
                         <img src="brand/branded-logo.svg" alt="Custom Branding" class="w-16 h-16 object-contain mb-4" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjJkM2VlIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0iTTIgMTJoMjAiLz48cGF0aCBkPSJNMjIgNkgzIi8+PHBhdGggZD0iTTIgMThoMjAiLz48L3N2Zz4='">
                         <div class="font-bold text-white text-lg tracking-tight leading-none mb-1">Zoros</div>
                         <div class="text-xs text-cyan-400 font-medium tracking-widest uppercase">Financial</div>
                    </div>
                 </a>
            </div>
        </div>
    </div>


    <div class="max-w-4xl mx-auto mt-24 px-6 relative z-10">
        <div class="text-center mb-10">
            <h2 class="text-3xl font-bold text-white mb-2">Technical Standards</h2>
            <p class="text-slate-400">Built on open Bitcoin protocols and industrial encryption.</p>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
             <div class="p-4 rounded-lg bg-slate-900/30 border border-slate-800">
                <svg lucideCpu class="w-6 h-6 text-slate-500 mx-auto mb-2"></svg>
                <div class="text-xs text-slate-500 font-mono">BIP-174</div>
                <div class="text-sm font-bold text-slate-300">PSBT Native</div>
             </div>
             <div class="p-4 rounded-lg bg-slate-900/30 border border-slate-800">
                <svg lucideLock class="w-6 h-6 text-slate-500 mx-auto mb-2"></svg>
                <div class="text-xs text-slate-500 font-mono">AES-GCM</div>
                <div class="text-sm font-bold text-slate-300">End-to-End Encrypted</div>
             </div>
             <div class="p-4 rounded-lg bg-slate-900/30 border border-slate-800">
                <svg lucideNetwork class="w-6 h-6 text-slate-500 mx-auto mb-2"></svg>
                <div class="text-xs text-slate-500 font-mono">WebSocket</div>
                <div class="text-sm font-bold text-slate-300">Real-time</div>
             </div>
             <div class="p-4 rounded-lg bg-slate-900/30 border border-slate-800">
                <svg lucideFingerprint class="w-6 h-6 text-slate-500 mx-auto mb-2"></svg>
                <div class="text-xs text-slate-500 font-mono">Ephemeral</div>
                <div class="text-sm font-bold text-slate-300">No Logs</div>
             </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto mt-12 px-6 text-center relative z-10">
        <p class="text-slate-500 text-sm font-semibold uppercase tracking-widest mb-8">Compatible with your Hardware Wallets & Software</p>
        <div class="flex flex-wrap justify-center gap-4">
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">Sparrow</span>
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">Electrum</span>
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">Coldcard</span>
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">Trezor</span>
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">Ledger</span>
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">Nunchuk</span>
            <span class="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-sm font-bold">BitBox02</span>
        </div>
    </div>

    <div class="max-w-3xl mx-auto mt-20 mb-20 px-6 relative z-10">
      <h2 class="text-2xl font-bold text-white mb-8 text-center">Frequently Asked Questions</h2>
      <div class="space-y-4">
        
        <div class="p-6 bg-slate-900/50 rounded-xl border border-slate-800 hover:bg-slate-900 transition">
          <h3 class="font-bold text-white mb-2 flex items-center gap-2">
            <svg lucideHelpCircle class="w-4 h-4 text-emerald-400"></svg>
            Where is my private key?
          </h3>
          <p class="text-slate-400 text-sm leading-relaxed">
            It stays on your hardware wallet or signing device. You only upload a 
            <span class="text-slate-300">PSBT (Partially Signed Bitcoin Transaction)</span>, 
            which contains no private keys, only public data and signatures.
          </p>
        </div>

        <div class="p-6 bg-slate-900/50 rounded-xl border border-slate-800 hover:bg-slate-900 transition">
          <h3 class="font-bold text-white mb-2 flex items-center gap-2">
            <svg lucideHelpCircle class="w-4 h-4 text-emerald-400"></svg>
            Can you see my transaction details?
          </h3>
          <p class="text-slate-400 text-sm leading-relaxed">
            No. Your transaction is encrypted in your browser using a key that is contained in the URL link hash (fragment). 
            This key is never sent to our servers, so we literally cannot decrypt your data.
          </p>
        </div>

        <div class="p-6 bg-slate-900/50 rounded-xl border border-slate-800 hover:bg-slate-900 transition">
          <h3 class="font-bold text-white mb-2 flex items-center gap-2">
            <svg lucideHelpCircle class="w-4 h-4 text-emerald-400"></svg>
            Is it really free?
          </h3>
          <div class="text-slate-400 text-sm leading-relaxed">
            <p class="mb-2">
              <strong class="text-slate-200">Yes.</strong> SigningRoom.io is a 100% free, open-source public good.
            </p>
            <p>
              We cover our costs through optional donations and enterprise licensing. There are no paid tiers for the public service.
            </p>
          </div>
        </div>

        <div class="p-6 bg-slate-900/50 rounded-xl border border-slate-800 hover:bg-slate-900 transition">
          <h3 class="font-bold text-white mb-2 flex items-center gap-2">
            <svg lucideBuilding2 class="w-4 h-4 text-cyan-400"></svg>
            Can I host this myself? (Enterprise)
          </h3>
          <div class="text-slate-400 text-sm leading-relaxed">
            <p class="mb-2">
              <strong class="text-slate-200">Yes.</strong> The code is open source (AGPL v3), so you can audit and run it yourself.
            </p>
            <p>
              For institutions requiring a commercial license (AGPL waiver) to integrate into proprietary, closed-source infrastructure, please contact 
              <a href="https://statelessresearch.com" target="_blank" class="text-emerald-400 hover:underline">Stateless Research Ltd</a>.
            </p>
          </div>
        </div>

      </div>
    </div>

    <div class="border-t border-slate-800 bg-slate-900/50 py-20 text-center px-6 relative z-10">
        <h2 class="text-3xl font-bold text-white mb-6">Ready to coordinate?</h2>
        <p class="text-slate-400 mb-8 max-w-lg mx-auto">
            No accounts required. Just upload a PSBT and share the secure link.
        </p>
        <a routerLink="/create" class="inline-flex px-8 py-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all items-center gap-2 shadow-lg shadow-emerald-500/20 cursor-pointer">
          Start Signing
          <svg lucideChevronRight class="w-5 h-5"></svg>
        </a>
    </div>
  `
    }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(HomeComponent, { className: "HomeComponent", filePath: "apps/client/src/app/pages/home/home.component.ts", lineNumber: 554 });
})();
(() => {
  const id = "apps%2Fclient%2Fsrc%2Fapp%2Fpages%2Fhome%2Fhome.component.ts%40HomeComponent";
  function HomeComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(HomeComponent, m.default, [i0, i1], [RouterModule, LucideZap, LucideUsers, LucideTerminal, LucideChevronRight, LucideLock, LucideCode2, LucideHelpCircle, LucideGlobe, LucideXCircle, LucideCheckCircle2, LucideAlertTriangle, LucideNetwork, LucideFileKey, LucideCpu, LucideFingerprint, LucideMaximize, LucideScale, LucideEyeOff, LucideShieldCheck, LucideFileText, LucideBuilding2, LucideExternalLink, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && HomeComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && HomeComponent_HmrLoad(d.timestamp)));
})();

// apps/client/src/app/guards/whitelabel.guard.ts
import { inject } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { Router } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
var whitelabelGuard = () => {
  const configService = inject(ConfigService);
  const router = inject(Router);
  if (configService.config().whitelabel) {
    return router.createUrlTree(["/create"]);
  }
  return true;
};

// apps/client/src/app/app.routes.ts
var appRoutes = [
  { path: "", component: HomeComponent, canActivate: [whitelabelGuard] },
  __spreadValues({
    path: "create",
    loadComponent: () => import("/chunk-6NAJDQ7D.js").then((m) => m.CreateComponent)
  }, false ? { \u0275entryName: "src/app/pages/create/create.component.ts" } : {}),
  __spreadValues({
    path: "room/:id",
    loadComponent: () => import("/chunk-ER42ASSE.js").then((m) => m.RoomComponent)
  }, false ? { \u0275entryName: "src/app/pages/room/room.component.ts" } : {}),
  { path: "**", redirectTo: "" }
];

// apps/client/src/app/app.config.ts
import { provideHttpClient } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common_http.js?v=cf17c1b4";
import { provideServiceWorker } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_service-worker.js?v=cf17c1b4";
var appConfig = {
  providers: [
    //provideClientHydration(withEventReplay()),
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(appRoutes),
    provideHttpClient(),
    provideServiceWorker("ngsw-worker.js", {
      enabled: !isDevMode(),
      registrationStrategy: "registerWhenStable:30000"
    }),
    provideAppInitializer(() => {
      const configService = inject2(ConfigService);
      return configService.loadConfig();
    })
  ]
};

// apps/client/src/app/app.ts
import { Component as Component2, ViewEncapsulation, inject as inject3, Renderer2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { CommonModule, DOCUMENT } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import { RouterModule as RouterModule2, Router as Router2, NavigationEnd } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
import { filter } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/rxjs_operators.js?v=cf17c1b4";
import { Title, Meta } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_platform-browser.js?v=cf17c1b4";
import { LucideShield, LucideZap as LucideZap2, LucideKey, LucideGlobe as LucideGlobe2, LucideMail } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@lucide_angular.js?v=cf17c1b4";
import * as i02 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i12 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import * as i2 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
var _c0 = (a0) => ({ "pt-20": a0 });
function App_Conditional_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275element(0, "img", 7);
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext(2);
    i02.\u0275\u0275property("src", ctx_r0.configService.config().logoUrl, i02.\u0275\u0275sanitizeUrl)("alt", ctx_r0.configService.config().brandName);
  }
}
function App_Conditional_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275elementStart(0, "svg", 8)(1, "g");
    i02.\u0275\u0275element(2, "path", 12)(3, "path", 13)(4, "path", 14)(5, "path", 15);
    i02.\u0275\u0275elementEnd()();
  }
}
function App_Conditional_1_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "div", 11)(1, "span");
    i02.\u0275\u0275text(2, "Stateless");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(3, "span");
    i02.\u0275\u0275text(4, "Non-Custodial");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(5, "span");
    i02.\u0275\u0275text(6, "Real-time");
    i02.\u0275\u0275elementEnd()();
  }
}
function App_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "nav", 1)(1, "div", 5)(2, "div", 6);
    i02.\u0275\u0275conditionalCreate(3, App_Conditional_1_Conditional_3_Template, 1, 2, "img", 7)(4, App_Conditional_1_Conditional_4_Template, 6, 0, ":svg:svg", 8);
    i02.\u0275\u0275elementStart(5, "span", 9);
    i02.\u0275\u0275text(6);
    i02.\u0275\u0275elementStart(7, "span", 10);
    i02.\u0275\u0275text(8);
    i02.\u0275\u0275elementEnd()()();
    i02.\u0275\u0275conditionalCreate(9, App_Conditional_1_Conditional_9_Template, 7, 0, "div", 11);
    i02.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275conditional(ctx_r0.configService.config().whitelabel ? 3 : 4);
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(ctx_r0.configService.config().brandSuffix || "");
    i02.\u0275\u0275advance();
    i02.\u0275\u0275conditional(!ctx_r0.configService.config().hideNetworkBadges ? 9 : -1);
  }
}
function App_Conditional_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "div", 11)(1, "span");
    i02.\u0275\u0275text(2, "Stateless");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(3, "span");
    i02.\u0275\u0275text(4, "Non-Custodial");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(5, "span");
    i02.\u0275\u0275text(6, "Real-time");
    i02.\u0275\u0275elementEnd()();
  }
}
function App_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "nav", 1)(1, "div", 5)(2, "div", 16);
    i02.\u0275\u0275element(3, "img", 7);
    i02.\u0275\u0275elementStart(4, "span", 9);
    i02.\u0275\u0275text(5);
    i02.\u0275\u0275elementStart(6, "span", 10);
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275elementEnd()()();
    i02.\u0275\u0275conditionalCreate(8, App_Conditional_2_Conditional_8_Template, 7, 0, "div", 11);
    i02.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(3);
    i02.\u0275\u0275property("src", ctx_r0.configService.config().logoUrl, i02.\u0275\u0275sanitizeUrl)("alt", ctx_r0.configService.config().brandName);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(ctx_r0.configService.config().brandSuffix || "");
    i02.\u0275\u0275advance();
    i02.\u0275\u0275conditional(!ctx_r0.configService.config().hideNetworkBadges ? 8 : -1);
  }
}
function App_Conditional_5_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275text(0, " \xA0");
    i02.\u0275\u0275elementStart(1, "span", 10);
    i02.\u0275\u0275text(2, "Signing Room\xAE");
    i02.\u0275\u0275elementEnd();
  }
}
function App_Conditional_5_Conditional_79_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "span", 58);
    i02.\u0275\u0275text(1, "\u2022");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(2, "p");
    i02.\u0275\u0275text(3, "Signing Room\xAE is a registered trademark of Stateless Research Ltd.");
    i02.\u0275\u0275elementEnd();
  }
}
function App_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "footer", 3)(1, "div", 17)(2, "div", 18)(3, "div", 19)(4, "div", 20);
    i02.\u0275\u0275text(5);
    i02.\u0275\u0275elementStart(6, "span", 10);
    i02.\u0275\u0275text(7);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275conditionalCreate(8, App_Conditional_5_Conditional_8_Template, 3, 0);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(9, "p", 21);
    i02.\u0275\u0275text(10, " 100% Free \u2022 Zero Knowledge \u2022 Bitcoin Only ");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275elementStart(11, "div", 22)(12, "button", 23);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275element(13, "svg", 24);
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(14, "span");
    i02.\u0275\u0275text(15, "Donate");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275elementStart(16, "div", 25)(17, "div", 26)(18, "button", 27);
    i02.\u0275\u0275text(19, " \u2715 ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(20, "div", 28)(21, "h3", 29);
    i02.\u0275\u0275text(22);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(23, "p", 30);
    i02.\u0275\u0275text(24, "Scan with any Lightning wallet");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(25, "div", 31);
    i02.\u0275\u0275element(26, "img", 32);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(27, "div", 33)(28, "label", 34);
    i02.\u0275\u0275text(29, "Lightning Address");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(30, "div", 35);
    i02.\u0275\u0275text(31, " seancarlin@walletofsatoshi.com ");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275elementStart(32, "div")(33, "label", 34);
    i02.\u0275\u0275text(34, "LNURL");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(35, "div", 36);
    i02.\u0275\u0275text(36, " lnurl1dp68gurn8ghj7ampd3kx2ar0veekzar0wd5xjtnrdakj7tnhv4kxctttdehhwm30d3h82unvwqhhxetpde3kzunvd9hqmzg7zp ");
    i02.\u0275\u0275elementEnd()()()()();
    i02.\u0275\u0275elementStart(37, "a", 37);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275element(38, "svg", 38);
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(39, "a", 39);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275elementStart(40, "svg", 40);
    i02.\u0275\u0275element(41, "path", 41)(42, "path", 42);
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(43, "a", 43);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275elementStart(44, "svg", 40);
    i02.\u0275\u0275element(45, "path", 44);
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(46, "a", 45);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275elementStart(47, "svg", 40);
    i02.\u0275\u0275element(48, "path", 46)(49, "path", 47);
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(50, "a", 48);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275element(51, "svg", 49);
    i02.\u0275\u0275elementEnd()()();
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(52, "div", 50)(53, "div", 51)(54, "p", 52)(55, "strong");
    i02.\u0275\u0275text(56, "DISCLAIMER OF WARRANTY:");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(57, " This is free, open-source software released under the ");
    i02.\u0275\u0275elementStart(58, "a", 53);
    i02.\u0275\u0275text(59, "AGPLv3 License");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(60, '. It is provided "as is", without warranty of any kind. ');
    i02.\u0275\u0275element(61, "br")(62, "br");
    i02.\u0275\u0275elementStart(63, "strong");
    i02.\u0275\u0275text(64, "NON-CUSTODIAL:");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(65);
    i02.\u0275\u0275element(66, "br")(67, "br");
    i02.\u0275\u0275elementStart(68, "strong");
    i02.\u0275\u0275text(69, "USER RESPONSIBILITY:");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275text(70, " You are solely responsible for verifying transaction details (addresses, amounts, fees) on your hardware device screen before signing. The developers assume no liability for lost funds or software errors. ");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275elementStart(71, "div", 54)(72, "div", 55)(73, "div", 56)(74, "p");
    i02.\u0275\u0275text(75);
    i02.\u0275\u0275elementStart(76, "strong")(77, "a", 57);
    i02.\u0275\u0275text(78, "Stateless Research Ltd");
    i02.\u0275\u0275elementEnd()()();
    i02.\u0275\u0275conditionalCreate(79, App_Conditional_5_Conditional_79_Template, 4, 0);
    i02.\u0275\u0275elementStart(80, "span", 58);
    i02.\u0275\u0275text(81, "\u2022");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(82, "p");
    i02.\u0275\u0275text(83, "Made for Bitcoiners");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(84, "span", 58);
    i02.\u0275\u0275text(85, "\u2022");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(86, "p");
    i02.\u0275\u0275text(87, "No Tracking / No Cookies");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275elementStart(88, "p", 59);
    i02.\u0275\u0275text(89, "Registered in England & Wales (No. 16990515)");
    i02.\u0275\u0275elementEnd()();
    i02.\u0275\u0275elementStart(90, "div", 60)(91, "a", 61);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275element(92, "svg", 62);
    i02.\u0275\u0275text(93, " Warrant Canary ");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275namespaceHTML();
    i02.\u0275\u0275elementStart(94, "span", 63);
    i02.\u0275\u0275text(95, "\u2022");
    i02.\u0275\u0275elementEnd();
    i02.\u0275\u0275elementStart(96, "a", 64);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275element(97, "svg", 65);
    i02.\u0275\u0275text(98, " PGP Key ");
    i02.\u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = i02.\u0275\u0275nextContext();
    i02.\u0275\u0275advance(5);
    i02.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName);
    i02.\u0275\u0275advance(2);
    i02.\u0275\u0275textInterpolate(ctx_r0.configService.config().brandSuffix || "");
    i02.\u0275\u0275advance();
    i02.\u0275\u0275conditional(ctx_r0.configService.config().whitelabel && ctx_r0.configService.config().useTradeMark ? 8 : -1);
    i02.\u0275\u0275advance(14);
    i02.\u0275\u0275textInterpolate1("Support ", ctx_r0.configService.config().brandName);
    i02.\u0275\u0275advance(43);
    i02.\u0275\u0275textInterpolate1(" ", ctx_r0.configService.config().brandName, " is a stateless coordination tool, not a wallet or financial institution. We do not have access to your private keys, funds, or unencrypted transaction data. We do not maintain user accounts or historical logs. ");
    i02.\u0275\u0275advance(10);
    i02.\u0275\u0275textInterpolate1(" \xA9 ", ctx_r0.currentYear, " ");
    i02.\u0275\u0275advance(4);
    i02.\u0275\u0275conditional(ctx_r0.configService.config().useTradeMark ? 79 : -1);
  }
}
function App_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "div", 4)(1, "a", 66);
    i02.\u0275\u0275namespaceSVG();
    i02.\u0275\u0275element(2, "svg", 67);
    i02.\u0275\u0275text(3, " Powered by Signing Room ");
    i02.\u0275\u0275elementEnd()();
  }
}
var App = class _App {
  isEmbedded = false;
  hideHeader = false;
  currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  router = inject3(Router2);
  configService = inject3(ConfigService);
  titleService = inject3(Title);
  metaService = inject3(Meta);
  document = inject3(DOCUMENT);
  renderer = inject3(Renderer2);
  constructor() {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe(() => {
      if (typeof window !== "undefined") {
        window.scrollTo(0, 0);
      }
    });
  }
  ngOnInit() {
    this.applyBrandMetadata();
    if (typeof window !== "undefined") {
      this.isEmbedded = window !== window.parent || window !== window.top;
      const urlParams = new URLSearchParams(window.location.search);
      this.hideHeader = urlParams.get("hideHeader") === "true";
      if (!window.isSecureContext) {
        document.body.innerHTML = `
                <div style="background:#020617; color:#f43f5e; height:100vh; display:flex; flex-direction:column; items-center; justify-content:center; font-family:sans-serif; text-align:center; padding:20px;">
                    <h1 style="margin-bottom:10px;">Security Error</h1>
                    <p>SigningRoom requires a Secure Context (HTTPS).</p>
                    <p style="color:#94a3b8; font-size:14px;">The Web Cryptography API is disabled in insecure environments.</p>
                </div>
            `;
        throw new Error("Insecure Context - Crypto API disabled");
      }
    }
  }
  applyBrandMetadata() {
    const config = this.configService.config();
    const brandFullName = config.brandName + (config.brandSuffix ? config.brandSuffix : "");
    const pageTitle = `${brandFullName} | ${config.tagline || "Real-Time Multisig Coordinator"}`;
    const pageDesc = config.subTagline || "The stateless, zero-knowledge Bitcoin multisig coordinator.";
    this.titleService.setTitle(pageTitle);
    this.metaService.updateTag({ name: "description", content: pageDesc });
    if (config.brandColorHex) {
      this.metaService.updateTag({ name: "theme-color", content: config.brandColorHex });
    }
    this.metaService.updateTag({ property: "og:title", content: pageTitle });
    this.metaService.updateTag({ property: "og:description", content: pageDesc });
    this.metaService.updateTag({ property: "og:site_name", content: brandFullName });
    this.metaService.updateTag({ name: "twitter:title", content: pageTitle });
    this.metaService.updateTag({ name: "twitter:description", content: pageDesc });
    const schema = {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      name: brandFullName,
      operatingSystem: "Any",
      applicationCategory: "FinanceApplication",
      description: pageDesc,
      featureList: [
        "Real-time PSBT Merging",
        "Zero-Knowledge Encryption",
        "Stateless Architecture",
        "Cryptographic Audit Logs",
        "Hardware Wallet Compatibility"
      ],
      url: this.document.defaultView?.location.href || "",
      author: {
        "@type": "Organization",
        name: config.useTradeMark ? "Stateless Research Ltd" : brandFullName
      }
    };
    const script = this.renderer.createElement("script");
    this.renderer.setAttribute(script, "type", "application/ld+json");
    this.renderer.setProperty(script, "text", JSON.stringify(schema));
    this.renderer.appendChild(this.document.head, script);
  }
  static \u0275fac = function App_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _App)();
  };
  static \u0275cmp = /* @__PURE__ */ i02.\u0275\u0275defineComponent({ type: _App, selectors: [["app-root"]], decls: 7, vars: 7, consts: [[1, "min-h-screen", "flex", "flex-col", "bg-brand-bg", "text-brand-text"], [1, "w-full", "border-b", "border-brand-card-border/60", "backdrop-blur-md", "fixed", "top-0", "z-50", "bg-brand-bg/80"], [1, "flex-grow", 3, "ngClass"], [1, "border-t", "border-brand-card-border", "bg-brand-bg", "py-12", "mt-auto", "relative", "z-20"], [1, "w-full", "py-3", "flex", "justify-center", "mt-auto", "pb-4"], [1, "max-w-6xl", "mx-auto", "px-6", "h-16", "flex", "items-center", "justify-between"], ["routerLink", "/", 1, "flex", "items-center", "gap-3", "cursor-pointer", "hover:opacity-80", "transition-opacity"], [1, "w-7", "h-7", "object-contain", 3, "src", "alt"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 409 445", "preserveAspectRatio", "xMidYMid meet", 1, "w-7", "h-7", "text-brand-accent", "fill-current"], [1, "text-xl", "font-bold", "tracking-tight", "text-brand-text"], [1, "text-brand-accent"], [1, "hidden", "md:flex", "items-center", "gap-6", "text-sm", "font-medium", "text-brand-text-muted"], ["d", "M185.5 425.7 c-35.4 -17.3 -72 -43.4 -98.2 -69.9 -31.6 -31.9 -50.3 -62.5 -59.1 -96.8 -5.6 -21.7 -5.7 -23.4 -5.7 -101 0 -66.6 0.1 -71.7 1.8 -75.1 2.3 -4.6 6.1 -6.7 22.2 -12.2 7.2 -2.5 31.9 -11.3 55 -19.7 79.4 -28.7 97.6 -35 100.4 -35 2.8 0 27.5 8.3 53.6 18 21.3 7.9 70.6 25.7 92 33.1 11 3.9 21.4 7.5 23 8.1 4.4 1.6 8.4 5.7 9.5 9.7 1.3 4.9 1.3 136.8 0 148.6 -4.9 42.6 -21.2 76.1 -55.1 113.1 -21 23 -49.7 46 -79.4 63.9 -15.9 9.6 -40.1 21.5 -43.6 21.5 -2.1 0 -8.2 -2.3 -16.4 -6.3z m24.6 -28.8 c31.4 -15.7 71.7 -45.6 92 -68 26.9 -29.8 39.3 -52 47.2 -84.4 2.1 -8.8 2.2 -10.3 2.2 -76.9 l0 -67.9 -17 -6.2 c-48.5 -17.7 -84.6 -30.6 -116 -41.6 l-16.9 -6 -20.1 7.1 c-11 4 -26.5 9.6 -34.5 12.5 -8 2.9 -18.3 6.7 -23 8.3 -11.6 4 -36.2 12.9 -43.5 15.7 -3.3 1.3 -10.9 4 -17 6.1 -6 2.1 -11.2 4.1 -11.5 4.5 -1 1.4 -1 113.3 -0.1 124.9 0.5 6.3 1.7 15.1 2.6 19.5 10.6 52.1 52.2 101.4 119 141 11.4 6.8 27 15.3 28.3 15.5 0.1 0 3.9 -1.8 8.3 -4.1z"], ["d", "M191.3 318.3 c-7.6 -7.4 -8.1 -8.1 -8.6 -12.8 -0.2 -2.7 -0.5 -27.9 -0.6 -55.9 0 -28 -0.2 -51 -0.3 -51.1 -0.2 -0.1 -2.5 -1.4 -5.1 -2.9 -7 -4 -11.1 -8 -16.1 -15.4 -5.9 -8.9 -8.6 -17.5 -8.6 -27.1 0 -27 19.5 -48.5 45.9 -50.7 13 -1.1 26.1 3.5 36.6 12.9 19.8 17.6 21.8 50.3 4.4 70.1 -4.1 4.6 -14.8 12.6 -16.8 12.6 -0.7 0 -1.1 6.3 -1.1 19 l0 19 -6.1 6.6 -6 6.7 6 6.1 c8.2 8.3 8.2 10.1 0 18.3 l-6 6 6 5.8 6.1 5.8 0 8.3 0 8.2 -9 9.1 c-5 5 -9.9 9.1 -10.9 9.1 -1 0 -5.4 -3.5 -9.8 -7.7z m17.7 -175 c3.6 -2.4 4.8 -4.3 5.5 -8.3 1 -5.7 -1.4 -11.1 -6 -13.7 -4.9 -2.8 -8.4 -2.9 -13.4 -0.3 -3.8 1.9 -4.5 2.8 -6.2 8.4 -1.2 4.1 0.8 10.2 4.4 13.2 3.6 3 11.8 3.4 15.7 0.7z"], ["d", "M130.1 304.2 l-7.1 -6.7 0 -48.2 0 -48.2 -5.5 -3.5 c-36.6 -23.5 -23.7 -79.4 19.1 -82.4 6.5 -0.4 17.4 1.2 17.4 2.5 0 0.3 -1.5 3.6 -3.2 7.4 -2.4 5 -3.7 6.6 -4.8 6.2 -0.8 -0.4 -3.6 -0.8 -6.3 -1.1 -4.3 -0.4 -5 -0.1 -8.2 3.1 -2.9 2.9 -3.5 4.2 -3.5 7.9 0 2.4 0.7 5.4 1.6 6.6 2 2.9 6.6 5.2 10.4 5.2 2.6 0 3 0.3 3 2.8 0 4.7 4 17.3 7.6 24.2 1.9 3.6 5.4 8.9 7.9 11.7 l4.6 5.2 -3.1 1.6 c-3.3 1.7 -3.4 2.4 -3 24.1 l0.2 9.1 -5.1 5.8 c-2.8 3.2 -5.1 6.1 -5.1 6.4 0 0.4 2.3 3.1 5 6.1 3 3.3 5 6.4 5 7.8 0 1.3 -1.9 4.3 -4.5 7.1 -2.5 2.6 -4.5 5.4 -4.5 6.1 0 0.7 2 3.5 4.5 6.1 4.4 4.7 4.5 4.9 4.5 11.6 l0 6.7 -7.9 7.8 c-4.5 4.4 -8.8 7.8 -9.9 7.8 -1.1 0 -5.2 -3 -9.1 -6.8z"], ["d", "M254.3 303.8 l-7.3 -7.1 0 -47.9 0 -47.9 -3.5 -2 c-1.9 -1.2 -3.5 -2.2 -3.5 -2.3 0 -0.1 2.1 -2.4 4.8 -5.2 8.2 -8.6 14.1 -22.8 14.2 -34.1 l0 -4.3 4.6 0 c3.9 0 5.1 -0.5 8 -3.4 2.8 -2.8 3.4 -4.2 3.4 -7.6 0 -9.6 -8.1 -14.6 -17.1 -10.6 -1.3 0.6 -2.5 -0.7 -5.3 -6 -3.9 -7.4 -3.8 -7.6 2.4 -9.4 7.4 -2.1 20 -0.5 28.8 3.7 10.4 4.9 20.7 19.4 23.2 32.5 1.5 7.5 0.3 17.7 -3 25.3 -2.7 6.4 -10.5 15.1 -17 19.1 l-6 3.7 0 16.1 0 16.2 -5.5 5.4 -5.5 5.4 5.5 5.6 c7 7.1 7.2 9.3 1 15.9 -2.5 2.6 -4.5 5.5 -4.5 6.2 0 0.8 2 3.5 4.5 5.9 4.5 4.4 4.5 4.4 4.5 11.5 l0 7.2 -7.9 7.6 c-4.3 4.2 -8.7 7.7 -9.7 7.7 -1.1 0 -5.2 -3.2 -9.1 -7.2z"], [1, "flex", "items-center", "gap-3", "cursor-pointer", "hover:opacity-80", "transition-opacity"], [1, "max-w-5xl", "mx-auto", "px-6"], [1, "flex", "flex-col", "md:flex-row", "justify-between", "items-start", "md:items-center", "gap-8", "mb-10"], [1, "text-center", "md:text-left"], [1, "font-bold", "text-brand-text", "text-lg", "mb-1", "flex", "items-center"], [1, "text-xs", "text-brand-text-muted"], [1, "flex", "items-center", "gap-6"], ["onclick", "document.getElementById('donate-modal').classList.remove('hidden')", 1, "flex", "items-center", "gap-2", "px-3", "py-1.5", "rounded-full", "bg-brand-card", "border", "border-brand-card-border", "hover:border-yellow-500/50", "hover:bg-yellow-500/10", "transition", "group", "text-xs", "font-medium", "text-brand-text-muted", "hover:text-yellow-400"], ["lucideZap", "", 1, "w-3.5", "h-3.5", "text-yellow-500", "group-hover:fill-yellow-500", "transition"], ["id", "donate-modal", 1, "hidden", "fixed", "inset-0", "bg-black/60", "backdrop-blur-sm", "flex", "items-center", "justify-center", "z-50"], [1, "bg-brand-card", "border", "border-brand-card-border", "p-6", "rounded-2xl", "max-w-sm", "w-full", "mx-4", "shadow-2xl", "relative"], ["onclick", "document.getElementById('donate-modal').classList.add('hidden')", 1, "absolute", "top-4", "right-4", "text-brand-text-muted", "hover:text-white", "transition"], [1, "text-center"], [1, "text-lg", "font-semibold", "text-white", "mb-2"], [1, "text-sm", "text-brand-text-muted", "mb-6"], [1, "bg-white", "p-2", "rounded-xl", "inline-block", "mb-6", "shadow-sm"], ["src", "/assets/address.png", "alt", "Lightning QR Code", 1, "w-48", "h-48", "object-contain"], [1, "mb-4"], [1, "block", "text-xs", "font-medium", "text-brand-text-muted", "mb-1", "uppercase", "tracking-wider"], [1, "bg-brand-bg", "text-brand-text", "px-3", "py-2", "rounded-lg", "text-sm", "font-mono", "select-all"], [1, "bg-brand-bg", "text-brand-text-muted", "px-3", "py-2", "rounded-lg", "text-[10px]", "font-mono", "break-all", "select-all"], ["href", "mailto:support@signingroom.io", 1, "text-brand-text-muted", "hover:text-white", "transition"], ["lucideMail", "", 1, "w-5", "h-5"], ["href", "https://github.com/scarlin90/SigningRoom", "target", "_blank", 1, "text-brand-text-muted", "hover:text-white", "transition"], ["xmlns", "http://www.w3.org/2000/svg", "width", "24", "height", "24", "viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", 1, "w-5", "h-5"], ["d", "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"], ["d", "M9 18c-4.51 2-5-2-7-2"], ["href", "https://x.com/SigningRoom", "target", "_blank", 1, "text-brand-text-muted", "hover:text-white", "transition"], ["d", "M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"], ["href", "https://www.youtube.com/@SigningRoom", "target", "_blank", 1, "text-brand-text-muted", "hover:text-white", "transition"], ["d", "M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"], ["d", "m10 15 5-3-5-3z"], ["href", "https://njump.me/npub1a6tk6kcs2p40eumeu2mru4jwqssnhvc8xtupwlpc6l3gymjha03sek436a", "target", "_blank", "title", "Nostr", 1, "text-brand-text-muted", "hover:text-white", "transition"], ["lucideGlobe", "", 1, "w-5", "h-5"], [1, "border-t", "border-brand-card-border", "pt-8"], [1, "bg-brand-card/30", "p-4", "rounded-xl", "border", "border-brand-card-border/50", "mb-6"], [1, "text-[10px]", "text-brand-text-muted", "leading-relaxed", "text-justify", "font-mono"], ["href", "https://www.gnu.org/licenses/agpl-3.0.html", "target", "_blank", 1, "underline", "hover:text-white"], [1, "flex", "flex-col", "items-center", "justify-center", "gap-4"], [1, "flex", "flex-col", "items-center", "gap-1", "text-xs", "text-brand-text-muted"], [1, "flex", "flex-wrap", "justify-center", "items-center", "gap-x-4"], ["href", "https://statelessresearch.com", "target", "_blank", 1, "hover:text-brand-accent", "transition"], [1, "hidden", "sm:inline"], [1, "text-[10px]", "opacity-60"], [1, "flex", "items-center", "gap-4", "opacity-70", "hover:opacity-100", "transition"], ["href", "/security.txt", "target", "_blank", 1, "flex", "items-center", "gap-1.5", "text-[10px]", "uppercase", "tracking-widest", "text-brand-text-muted", "hover:text-brand-accent", "transition", "group"], ["lucideShield", "", 1, "w-3", "h-3", "group-hover:text-brand-accent", "transition"], [1, "text-brand-card-border", "text-[10px]"], ["href", "/pgp-key.asc", "target", "_blank", 1, "flex", "items-center", "gap-1.5", "text-[10px]", "uppercase", "tracking-widest", "text-brand-text-muted", "hover:text-brand-accent", "transition", "group"], ["lucideKey", "", 1, "w-3", "h-3", "group-hover:text-brand-accent", "transition"], ["href", "https://signingroom.io?utm_source=widget&utm_medium=embed", "target", "_blank", "rel", "noopener noreferrer", 1, "flex", "items-center", "gap-1.5", "text-[11px]", "font-medium", "text-brand-text-muted", "hover:text-brand-accent", "transition-colors", "opacity-80", "hover:opacity-100"], ["lucideShield", "", 1, "w-3.5", "h-3.5"]], template: function App_Template(rf, ctx) {
    if (rf & 1) {
      i02.\u0275\u0275elementStart(0, "div", 0);
      i02.\u0275\u0275conditionalCreate(1, App_Conditional_1_Template, 10, 4, "nav", 1);
      i02.\u0275\u0275conditionalCreate(2, App_Conditional_2_Template, 9, 5, "nav", 1);
      i02.\u0275\u0275elementStart(3, "div", 2);
      i02.\u0275\u0275element(4, "router-outlet");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275conditionalCreate(5, App_Conditional_5_Template, 99, 7, "footer", 3);
      i02.\u0275\u0275conditionalCreate(6, App_Conditional_6_Template, 4, 0, "div", 4);
      i02.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i02.\u0275\u0275advance();
      i02.\u0275\u0275conditional(!ctx.isEmbedded ? 1 : -1);
      i02.\u0275\u0275advance();
      i02.\u0275\u0275conditional(ctx.isEmbedded && !ctx.hideHeader ? 2 : -1);
      i02.\u0275\u0275advance();
      i02.\u0275\u0275property("ngClass", i02.\u0275\u0275pureFunction1(5, _c0, !ctx.isEmbedded || ctx.isEmbedded && !ctx.hideHeader));
      i02.\u0275\u0275advance(2);
      i02.\u0275\u0275conditional(!ctx.isEmbedded && !ctx.configService.config().hideFooter ? 5 : -1);
      i02.\u0275\u0275advance();
      i02.\u0275\u0275conditional(ctx.isEmbedded && !ctx.configService.config().hideFooter ? 6 : -1);
    }
  }, dependencies: [
    CommonModule,
    i12.NgClass,
    i12.NgComponentOutlet,
    i12.NgForOf,
    i12.NgIf,
    i12.NgTemplateOutlet,
    i12.NgStyle,
    i12.NgSwitch,
    i12.NgSwitchCase,
    i12.NgSwitchDefault,
    i12.NgPlural,
    i12.NgPluralCase,
    RouterModule2,
    i2.RouterOutlet,
    i2.RouterLink,
    i2.RouterLinkActive,
    i2.\u0275EmptyOutletComponent,
    LucideShield,
    LucideZap2,
    LucideKey,
    LucideGlobe2,
    LucideMail,
    i12.AsyncPipe,
    i12.UpperCasePipe,
    i12.LowerCasePipe,
    i12.JsonPipe,
    i12.SlicePipe,
    i12.DecimalPipe,
    i12.PercentPipe,
    i12.TitleCasePipe,
    i12.CurrencyPipe,
    i12.DatePipe,
    i12.I18nPluralPipe,
    i12.I18nSelectPipe,
    i12.KeyValuePipe
  ], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(App, [{
    type: Component2,
    args: [{
      selector: "app-root",
      standalone: true,
      imports: [
        CommonModule,
        RouterModule2,
        LucideShield,
        LucideZap2,
        LucideKey,
        LucideGlobe2,
        LucideMail
      ],
      encapsulation: ViewEncapsulation.None,
      template: `
    <div class="min-h-screen flex flex-col bg-brand-bg text-brand-text">
      @if (!isEmbedded) {
        <nav class="w-full border-b border-brand-card-border/60 backdrop-blur-md fixed top-0 z-50 bg-brand-bg/80">
          <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
            
            <div class="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity" routerLink="/">
              @if (configService.config().whitelabel) {
                <img [src]="configService.config().logoUrl" [alt]="configService.config().brandName" class="w-7 h-7 object-contain" />
              } @else {
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 409 445" class="w-7 h-7 text-brand-accent fill-current" preserveAspectRatio="xMidYMid meet">
                  <g>
                    <path d="M185.5 425.7 c-35.4 -17.3 -72 -43.4 -98.2 -69.9 -31.6 -31.9 -50.3 -62.5 -59.1 -96.8 -5.6 -21.7 -5.7 -23.4 -5.7 -101 0 -66.6 0.1 -71.7 1.8 -75.1 2.3 -4.6 6.1 -6.7 22.2 -12.2 7.2 -2.5 31.9 -11.3 55 -19.7 79.4 -28.7 97.6 -35 100.4 -35 2.8 0 27.5 8.3 53.6 18 21.3 7.9 70.6 25.7 92 33.1 11 3.9 21.4 7.5 23 8.1 4.4 1.6 8.4 5.7 9.5 9.7 1.3 4.9 1.3 136.8 0 148.6 -4.9 42.6 -21.2 76.1 -55.1 113.1 -21 23 -49.7 46 -79.4 63.9 -15.9 9.6 -40.1 21.5 -43.6 21.5 -2.1 0 -8.2 -2.3 -16.4 -6.3z m24.6 -28.8 c31.4 -15.7 71.7 -45.6 92 -68 26.9 -29.8 39.3 -52 47.2 -84.4 2.1 -8.8 2.2 -10.3 2.2 -76.9 l0 -67.9 -17 -6.2 c-48.5 -17.7 -84.6 -30.6 -116 -41.6 l-16.9 -6 -20.1 7.1 c-11 4 -26.5 9.6 -34.5 12.5 -8 2.9 -18.3 6.7 -23 8.3 -11.6 4 -36.2 12.9 -43.5 15.7 -3.3 1.3 -10.9 4 -17 6.1 -6 2.1 -11.2 4.1 -11.5 4.5 -1 1.4 -1 113.3 -0.1 124.9 0.5 6.3 1.7 15.1 2.6 19.5 10.6 52.1 52.2 101.4 119 141 11.4 6.8 27 15.3 28.3 15.5 0.1 0 3.9 -1.8 8.3 -4.1z"/>
                    <path d="M191.3 318.3 c-7.6 -7.4 -8.1 -8.1 -8.6 -12.8 -0.2 -2.7 -0.5 -27.9 -0.6 -55.9 0 -28 -0.2 -51 -0.3 -51.1 -0.2 -0.1 -2.5 -1.4 -5.1 -2.9 -7 -4 -11.1 -8 -16.1 -15.4 -5.9 -8.9 -8.6 -17.5 -8.6 -27.1 0 -27 19.5 -48.5 45.9 -50.7 13 -1.1 26.1 3.5 36.6 12.9 19.8 17.6 21.8 50.3 4.4 70.1 -4.1 4.6 -14.8 12.6 -16.8 12.6 -0.7 0 -1.1 6.3 -1.1 19 l0 19 -6.1 6.6 -6 6.7 6 6.1 c8.2 8.3 8.2 10.1 0 18.3 l-6 6 6 5.8 6.1 5.8 0 8.3 0 8.2 -9 9.1 c-5 5 -9.9 9.1 -10.9 9.1 -1 0 -5.4 -3.5 -9.8 -7.7z m17.7 -175 c3.6 -2.4 4.8 -4.3 5.5 -8.3 1 -5.7 -1.4 -11.1 -6 -13.7 -4.9 -2.8 -8.4 -2.9 -13.4 -0.3 -3.8 1.9 -4.5 2.8 -6.2 8.4 -1.2 4.1 0.8 10.2 4.4 13.2 3.6 3 11.8 3.4 15.7 0.7z"/>
                    <path d="M130.1 304.2 l-7.1 -6.7 0 -48.2 0 -48.2 -5.5 -3.5 c-36.6 -23.5 -23.7 -79.4 19.1 -82.4 6.5 -0.4 17.4 1.2 17.4 2.5 0 0.3 -1.5 3.6 -3.2 7.4 -2.4 5 -3.7 6.6 -4.8 6.2 -0.8 -0.4 -3.6 -0.8 -6.3 -1.1 -4.3 -0.4 -5 -0.1 -8.2 3.1 -2.9 2.9 -3.5 4.2 -3.5 7.9 0 2.4 0.7 5.4 1.6 6.6 2 2.9 6.6 5.2 10.4 5.2 2.6 0 3 0.3 3 2.8 0 4.7 4 17.3 7.6 24.2 1.9 3.6 5.4 8.9 7.9 11.7 l4.6 5.2 -3.1 1.6 c-3.3 1.7 -3.4 2.4 -3 24.1 l0.2 9.1 -5.1 5.8 c-2.8 3.2 -5.1 6.1 -5.1 6.4 0 0.4 2.3 3.1 5 6.1 3 3.3 5 6.4 5 7.8 0 1.3 -1.9 4.3 -4.5 7.1 -2.5 2.6 -4.5 5.4 -4.5 6.1 0 0.7 2 3.5 4.5 6.1 4.4 4.7 4.5 4.9 4.5 11.6 l0 6.7 -7.9 7.8 c-4.5 4.4 -8.8 7.8 -9.9 7.8 -1.1 0 -5.2 -3 -9.1 -6.8z"/>
                    <path d="M254.3 303.8 l-7.3 -7.1 0 -47.9 0 -47.9 -3.5 -2 c-1.9 -1.2 -3.5 -2.2 -3.5 -2.3 0 -0.1 2.1 -2.4 4.8 -5.2 8.2 -8.6 14.1 -22.8 14.2 -34.1 l0 -4.3 4.6 0 c3.9 0 5.1 -0.5 8 -3.4 2.8 -2.8 3.4 -4.2 3.4 -7.6 0 -9.6 -8.1 -14.6 -17.1 -10.6 -1.3 0.6 -2.5 -0.7 -5.3 -6 -3.9 -7.4 -3.8 -7.6 2.4 -9.4 7.4 -2.1 20 -0.5 28.8 3.7 10.4 4.9 20.7 19.4 23.2 32.5 1.5 7.5 0.3 17.7 -3 25.3 -2.7 6.4 -10.5 15.1 -17 19.1 l-6 3.7 0 16.1 0 16.2 -5.5 5.4 -5.5 5.4 5.5 5.6 c7 7.1 7.2 9.3 1 15.9 -2.5 2.6 -4.5 5.5 -4.5 6.2 0 0.8 2 3.5 4.5 5.9 4.5 4.4 4.5 4.4 4.5 11.5 l0 7.2 -7.9 7.6 c-4.3 4.2 -8.7 7.7 -9.7 7.7 -1.1 0 -5.2 -3.2 -9.1 -7.2z"/>
                  </g>
                </svg>
              }
              
              <span class="text-xl font-bold tracking-tight text-brand-text">
                {{ configService.config().brandName }}<span class="text-brand-accent">{{ configService.config().brandSuffix || '' }}</span>
                
              </span>
            </div>

            @if (!configService.config().hideNetworkBadges) {
              <div class="hidden md:flex items-center gap-6 text-sm font-medium text-brand-text-muted">
                <span>Stateless</span>
                <span>Non-Custodial</span>
                <span>Real-time</span>
              </div>
            }
          </div>
        </nav>
      }

      @if (isEmbedded && !hideHeader) {
        <nav class="w-full border-b border-brand-card-border/60 backdrop-blur-md fixed top-0 z-50 bg-brand-bg/80">
          <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
            
            <div class="flex items-center gap-3 cursor-pointer hover:opacity-80 transition-opacity">
              <img [src]="configService.config().logoUrl" [alt]="configService.config().brandName" class="w-7 h-7 object-contain" />
              
              <span class="text-xl font-bold tracking-tight text-brand-text">
                  {{ configService.config().brandName }}<span class="text-brand-accent">{{ configService.config().brandSuffix || '' }}</span>
              </span>
            </div>

            @if (!configService.config().hideNetworkBadges) {
              <div class="hidden md:flex items-center gap-6 text-sm font-medium text-brand-text-muted">
                <span>Stateless</span>
                <span>Non-Custodial</span>
                <span>Real-time</span>
              </div>
            }
          </div>
        </nav>
      }

      <div class="flex-grow" [ngClass]="{ 'pt-20': !isEmbedded || (isEmbedded && !hideHeader) }">
        <router-outlet></router-outlet>
      </div>

      @if (!isEmbedded && !configService.config().hideFooter) {
        <footer class="border-t border-brand-card-border bg-brand-bg py-12 mt-auto relative z-20">
          <div class="max-w-5xl mx-auto px-6">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-10">
              <div class="text-center md:text-left">
                <div class="font-bold text-brand-text text-lg mb-1 flex items-center">
                  {{ configService.config().brandName }}<span class="text-brand-accent">{{ configService.config().brandSuffix || '' }}</span>
                  @if (configService.config().whitelabel && configService.config().useTradeMark) {
                    &nbsp;<span class="text-brand-accent">Signing Room\xAE</span>
                  }
                </div>
                <p class="text-xs text-brand-text-muted">
                  100% Free &bull; Zero Knowledge &bull; Bitcoin Only
                </p>
              </div>

              <div class="flex items-center gap-6">
                <!-- The Donate Button -->
                <button
                  onclick="document.getElementById('donate-modal').classList.remove('hidden')"
                  class="flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-card border border-brand-card-border hover:border-yellow-500/50 hover:bg-yellow-500/10 transition group text-xs font-medium text-brand-text-muted hover:text-yellow-400">
                  <svg lucideZap class="w-3.5 h-3.5 text-yellow-500 group-hover:fill-yellow-500 transition"></svg>
                  <span>Donate</span>
                </button>

                <!-- The Modal / Popover Overlay -->
                <div id="donate-modal" class="hidden fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
                  <div class="bg-brand-card border border-brand-card-border p-6 rounded-2xl max-w-sm w-full mx-4 shadow-2xl relative">
                    
                    <!-- Close Button -->
                    <button 
                      onclick="document.getElementById('donate-modal').classList.add('hidden')"
                      class="absolute top-4 right-4 text-brand-text-muted hover:text-white transition">
                      \u2715
                    </button>

                    <div class="text-center">
                      <h3 class="text-lg font-semibold text-white mb-2">Support {{ configService.config().brandName }}</h3>
                      <p class="text-sm text-brand-text-muted mb-6">Scan with any Lightning wallet</p>
                      
                      <!-- QR Code Image -->
                      <div class="bg-white p-2 rounded-xl inline-block mb-6 shadow-sm">
                        <img src="/assets/address.png" alt="Lightning QR Code" class="w-48 h-48 object-contain" />
                      </div>

                      <!-- Lightning Address -->
                      <div class="mb-4">
                        <label class="block text-xs font-medium text-brand-text-muted mb-1 uppercase tracking-wider">Lightning Address</label>
                        <div class="bg-brand-bg text-brand-text px-3 py-2 rounded-lg text-sm font-mono select-all">
                          seancarlin@walletofsatoshi.com
                        </div>
                      </div>

                      <!-- LNURL Fallback -->
                      <div>
                        <label class="block text-xs font-medium text-brand-text-muted mb-1 uppercase tracking-wider">LNURL</label>
                        <div class="bg-brand-bg text-brand-text-muted px-3 py-2 rounded-lg text-[10px] font-mono break-all select-all">
                          lnurl1dp68gurn8ghj7ampd3kx2ar0veekzar0wd5xjtnrdakj7tnhv4kxctttdehhwm30d3h82unvwqhhxetpde3kzunvd9hqmzg7zp
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>

                <a
                  href="mailto:support@signingroom.io"
                  class="text-brand-text-muted hover:text-white transition">
                  <svg lucideMail class="w-5 h-5"></svg>
                </a>

                <a
                  href="https://github.com/scarlin90/SigningRoom"
                  target="_blank"
                  class="text-brand-text-muted hover:text-white transition">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    class="w-5 h-5">
                    <path
                      d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
                    <path d="M9 18c-4.51 2-5-2-7-2" />
                  </svg>
                </a>

                <a
                  href="https://x.com/SigningRoom"
                  target="_blank"
                  class="text-brand-text-muted hover:text-white transition">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    class="w-5 h-5">
                    <path
                      d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                  </svg>
                </a>

                <a
                  href="https://www.youtube.com/@SigningRoom"
                  target="_blank"
                  class="text-brand-text-muted hover:text-white transition">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    class="w-5 h-5">
                    <path
                      d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
                    <path d="m10 15 5-3-5-3z" />
                  </svg>
                </a>

                <a
                  href="https://njump.me/npub1a6tk6kcs2p40eumeu2mru4jwqssnhvc8xtupwlpc6l3gymjha03sek436a"
                  target="_blank"
                  class="text-brand-text-muted hover:text-white transition"
                  title="Nostr">
                  <svg lucideGlobe class="w-5 h-5"></svg>
                </a>
              </div>
            </div>

            <div class="border-t border-brand-card-border pt-8">
              <div class="bg-brand-card/30 p-4 rounded-xl border border-brand-card-border/50 mb-6">
                <p class="text-[10px] text-brand-text-muted leading-relaxed text-justify font-mono">
                  <strong>DISCLAIMER OF WARRANTY:</strong> This is free, open-source software
                  released under the
                  <a
                    href="https://www.gnu.org/licenses/agpl-3.0.html"
                    target="_blank"
                    class="underline hover:text-white"
                    >AGPLv3 License</a
                  >. It is provided "as is", without warranty of any kind. <br /><br />
                  <strong>NON-CUSTODIAL:</strong> {{ configService.config().brandName }} is a stateless coordination tool,
                  not a wallet or financial institution. We do not have access to your private keys,
                  funds, or unencrypted transaction data. We do not maintain user accounts or
                  historical logs. <br /><br />
                  <strong>USER RESPONSIBILITY:</strong> You are solely responsible for verifying
                  transaction details (addresses, amounts, fees) on your hardware device screen
                  before signing. The developers assume no liability for lost funds or software
                  errors.
                </p>
              </div>

              <div class="flex flex-col items-center justify-center gap-4">
                <div class="flex flex-col items-center gap-1 text-xs text-brand-text-muted">
                  <div class="flex flex-wrap justify-center items-center gap-x-4">
                    <p>
                      &copy; {{ currentYear }}
                      <strong
                        ><a
                          href="https://statelessresearch.com"
                          target="_blank"
                          class="hover:text-brand-accent transition"
                          >Stateless Research Ltd</a
                        ></strong
                      >
                    </p>
                    @if (configService.config().useTradeMark) {
                      <span class="hidden sm:inline">&bull;</span>
                      <p>Signing Room\xAE is a registered trademark of Stateless Research Ltd.</p>
                    }
                    <span class="hidden sm:inline">&bull;</span>
                    <p>Made for Bitcoiners</p>
                    <span class="hidden sm:inline">&bull;</span>
                    <p>No Tracking / No Cookies</p>
                  </div>
                  <p class="text-[10px] opacity-60">Registered in England & Wales (No. 16990515)</p>
                </div>

                <div class="flex items-center gap-4 opacity-70 hover:opacity-100 transition">
                  <a
                    href="/security.txt"
                    target="_blank"
                    class="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-brand-text-muted hover:text-brand-accent transition group">
                    <svg lucideShield class="w-3 h-3 group-hover:text-brand-accent transition"></svg>
                    Warrant Canary
                  </a>

                  <span class="text-brand-card-border text-[10px]">&bull;</span>

                  <a
                    href="/pgp-key.asc"
                    target="_blank"
                    class="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-brand-text-muted hover:text-brand-accent transition group">
                    <svg lucideKey class="w-3 h-3 group-hover:text-brand-accent transition"></svg>
                    PGP Key
                  </a>
                </div>
              </div>
            </div>
          </div>
        </footer>
      }

      @if (isEmbedded && !configService.config().hideFooter) {
        <div class="w-full py-3 flex justify-center mt-auto pb-4">
          <a
            href="https://signingroom.io?utm_source=widget&utm_medium=embed"
            target="_blank"
            rel="noopener noreferrer"
            class="flex items-center gap-1.5 text-[11px] font-medium text-brand-text-muted hover:text-brand-accent transition-colors opacity-80 hover:opacity-100">
            <svg lucideShield class="w-3.5 h-3.5"></svg>
            Powered by Signing Room
          </a>
        </div>
      }
  `
    }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(App, { className: "App", filePath: "apps/client/src/app/app.ts", lineNumber: 337 });
})();
(() => {
  const id = "apps%2Fclient%2Fsrc%2Fapp%2Fapp.ts%40App";
  function App_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i02.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i02.\u0275\u0275replaceMetadata(App, m.default, [i02, i12, i2], [CommonModule, RouterModule2, LucideShield, LucideZap2, LucideKey, LucideGlobe2, LucideMail, Component2, ViewEncapsulation], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && App_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && App_HmrLoad(d.timestamp)));
})();

// apps/client/src/main.ts
import __vite__cjsImport34_buffer from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/buffer.js?v=cf17c1b4";
window.global = window;
window.Buffer = Buffer;
window.process = {
  env: { DEBUG: void 0 },
  version: "",
  nextTick: function(cb) {
    setTimeout(cb, 0);
  }
};
if (environment.production) {
  console.log = () => {
  };
  console.debug = () => {
  };
  console.info = () => {
  };
  console.warn = () => {
  };
}
bootstrapApplication(App, appConfig).catch((err) => console.error(err));
//# debugId=1c483117-a503-552d-bd3c-a95d1779de78


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcHMvY2xpZW50L3NyYy9tYWluLnRzIiwiYXBwcy9jbGllbnQvc3JjL2FwcC9hcHAuY29uZmlnLnRzIiwiYXBwcy9jbGllbnQvc3JjL2FwcC9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50LnRzIiwiYXBwcy9jbGllbnQvc3JjL2FwcC9ndWFyZHMvd2hpdGVsYWJlbC5ndWFyZC50cyIsImFwcHMvY2xpZW50L3NyYy9hcHAvYXBwLnJvdXRlcy50cyIsImFwcHMvY2xpZW50L3NyYy9hcHAvYXBwLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGJvb3RzdHJhcEFwcGxpY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7IGFwcENvbmZpZyB9IGZyb20gJy4vYXBwL2FwcC5jb25maWcnO1xyXG5pbXBvcnQgeyBBcHAgfSBmcm9tICcuL2FwcC9hcHAnO1xyXG5pbXBvcnQgeyBlbnZpcm9ubWVudCB9IGZyb20gJy4vZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuLy8gMS4gSW1wb3J0IHRoZSBuZXdseSBpbnN0YWxsZWQgYnVmZmVyIHBhY2thZ2VcclxuaW1wb3J0IHsgQnVmZmVyIH0gZnJvbSAnYnVmZmVyJztcclxuXHJcbi8vIDIuIFNoaW0gTm9kZS5qcyBnbG9iYWxzIGZvciBicm93c2VyLWNvbXBhdGliaWxpdHlcclxuKHdpbmRvdyBhcyBhbnkpLmdsb2JhbCA9IHdpbmRvdztcclxuKHdpbmRvdyBhcyBhbnkpLkJ1ZmZlciA9IEJ1ZmZlcjtcclxuKHdpbmRvdyBhcyBhbnkpLnByb2Nlc3MgPSB7XHJcbiAgZW52OiB7IERFQlVHOiB1bmRlZmluZWQgfSxcclxuICB2ZXJzaW9uOiAnJyxcclxuICBuZXh0VGljazogZnVuY3Rpb24oY2I6IGFueSkgeyBzZXRUaW1lb3V0KGNiLCAwKTsgfVxyXG59O1xyXG5cclxuaWYgKGVudmlyb25tZW50LnByb2R1Y3Rpb24pIHtcclxuICBjb25zb2xlLmxvZyA9ICgpID0+IHt9O1xyXG4gIGNvbnNvbGUuZGVidWcgPSAoKSA9PiB7fTtcclxuICBjb25zb2xlLmluZm8gPSAoKSA9PiB7fTtcclxuICBjb25zb2xlLndhcm4gPSAoKSA9PiB7fTtcclxufVxyXG5cclxuYm9vdHN0cmFwQXBwbGljYXRpb24oQXBwLCBhcHBDb25maWcpLmNhdGNoKChlcnIpID0+IGNvbnNvbGUuZXJyb3IoZXJyKSk7XHJcbiIsImltcG9ydCB7XHJcbiAgcHJvdmlkZUFwcEluaXRpYWxpemVyLFxyXG4gIGluamVjdCxcclxuICBBcHBsaWNhdGlvbkNvbmZpZyxcclxuICBwcm92aWRlQnJvd3Nlckdsb2JhbEVycm9yTGlzdGVuZXJzLFxyXG4gIHByb3ZpZGVab25lQ2hhbmdlRGV0ZWN0aW9uLFxyXG4gIGlzRGV2TW9kZSxcclxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgcHJvdmlkZVJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IGFwcFJvdXRlcyB9IGZyb20gJy4vYXBwLnJvdXRlcyc7XHJcbmltcG9ydCB7IHByb3ZpZGVIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBwcm92aWRlU2VydmljZVdvcmtlciB9IGZyb20gJ0Bhbmd1bGFyL3NlcnZpY2Utd29ya2VyJztcclxuaW1wb3J0IHsgQ29uZmlnU2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvY29uZmlnL2NvbmZpZy5zZXJ2aWNlJztcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbml0aWFsaXplQXBwKGNvbmZpZ1NlcnZpY2U6IENvbmZpZ1NlcnZpY2UpIHtcclxuICByZXR1cm4gKCkgPT4gY29uZmlnU2VydmljZS5sb2FkQ29uZmlnKCk7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBhcHBDb25maWc6IEFwcGxpY2F0aW9uQ29uZmlnID0ge1xyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgLy9wcm92aWRlQ2xpZW50SHlkcmF0aW9uKHdpdGhFdmVudFJlcGxheSgpKSxcclxuICAgIHByb3ZpZGVCcm93c2VyR2xvYmFsRXJyb3JMaXN0ZW5lcnMoKSxcclxuICAgIHByb3ZpZGVab25lQ2hhbmdlRGV0ZWN0aW9uKHsgZXZlbnRDb2FsZXNjaW5nOiB0cnVlIH0pLFxyXG4gICAgcHJvdmlkZVJvdXRlcihhcHBSb3V0ZXMpLFxyXG4gICAgcHJvdmlkZUh0dHBDbGllbnQoKSxcclxuICAgIHByb3ZpZGVTZXJ2aWNlV29ya2VyKCduZ3N3LXdvcmtlci5qcycsIHtcclxuICAgICAgZW5hYmxlZDogIWlzRGV2TW9kZSgpLFxyXG4gICAgICByZWdpc3RyYXRpb25TdHJhdGVneTogJ3JlZ2lzdGVyV2hlblN0YWJsZTozMDAwMCcsXHJcbiAgICB9KSxcclxuICAgIHByb3ZpZGVBcHBJbml0aWFsaXplcigoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGNvbmZpZ1NlcnZpY2UgPSBpbmplY3QoQ29uZmlnU2VydmljZSk7XHJcblxyXG4gICAgICByZXR1cm4gY29uZmlnU2VydmljZS5sb2FkQ29uZmlnKCk7XHJcbiAgICB9KSxcclxuICBdLFxyXG59O1xyXG4iLCIvKlxyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMjYgU3RhdGVsZXNzIFJlc2VhcmNoIEx0ZFxyXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgR05VIEFmZmVybyBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIHYzLjBcclxuICovXHJcblxyXG5pbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQge1xyXG4gIEx1Y2lkZVphcCxcclxuICBMdWNpZGVVc2VycyxcclxuICBMdWNpZGVUZXJtaW5hbCxcclxuICBMdWNpZGVDaGV2cm9uUmlnaHQsXHJcbiAgTHVjaWRlTG9jayxcclxuICBMdWNpZGVDb2RlMixcclxuICBMdWNpZGVIZWxwQ2lyY2xlLFxyXG4gIEx1Y2lkZUdsb2JlLFxyXG4gIEx1Y2lkZVhDaXJjbGUsXHJcbiAgTHVjaWRlQ2hlY2tDaXJjbGUyLFxyXG4gIEx1Y2lkZUFsZXJ0VHJpYW5nbGUsXHJcbiAgTHVjaWRlTmV0d29yayxcclxuICBMdWNpZGVGaWxlS2V5LFxyXG4gIEx1Y2lkZUNwdSxcclxuICBMdWNpZGVGaW5nZXJwcmludCxcclxuICBMdWNpZGVNYXhpbWl6ZSxcclxuICBMdWNpZGVTY2FsZSxcclxuICBMdWNpZGVFeWVPZmYsXHJcbiAgTHVjaWRlU2hpZWxkQ2hlY2ssXHJcbiAgTHVjaWRlRmlsZVRleHQsXHJcbiAgTHVjaWRlQnVpbGRpbmcyLFxyXG4gIEx1Y2lkZUV4dGVybmFsTGluayxcclxufSBmcm9tICdAbHVjaWRlL2FuZ3VsYXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtaG9tZScsXHJcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcclxuICBpbXBvcnRzOiBbXHJcbiAgICBSb3V0ZXJNb2R1bGUsXHJcbiAgICBMdWNpZGVaYXAsXHJcbiAgICBMdWNpZGVVc2VycyxcclxuICAgIEx1Y2lkZVRlcm1pbmFsLFxyXG4gICAgTHVjaWRlQ2hldnJvblJpZ2h0LFxyXG4gICAgTHVjaWRlTG9jayxcclxuICAgIEx1Y2lkZUNvZGUyLFxyXG4gICAgTHVjaWRlSGVscENpcmNsZSxcclxuICAgIEx1Y2lkZUdsb2JlLFxyXG4gICAgTHVjaWRlWENpcmNsZSxcclxuICAgIEx1Y2lkZUNoZWNrQ2lyY2xlMixcclxuICAgIEx1Y2lkZUFsZXJ0VHJpYW5nbGUsXHJcbiAgICBMdWNpZGVOZXR3b3JrLFxyXG4gICAgTHVjaWRlRmlsZUtleSxcclxuICAgIEx1Y2lkZUNwdSxcclxuICAgIEx1Y2lkZUZpbmdlcnByaW50LFxyXG4gICAgTHVjaWRlTWF4aW1pemUsXHJcbiAgICBMdWNpZGVTY2FsZSxcclxuICAgIEx1Y2lkZUV5ZU9mZixcclxuICAgIEx1Y2lkZVNoaWVsZENoZWNrLFxyXG4gICAgTHVjaWRlRmlsZVRleHQsXHJcbiAgICBMdWNpZGVCdWlsZGluZzIsXHJcbiAgICBMdWNpZGVFeHRlcm5hbExpbmssXHJcbiAgXSxcclxuICB0ZW1wbGF0ZTogYFxyXG4gICAgPGRpdiBjbGFzcz1cIm1heC13LTZ4bCBteC1hdXRvIHRleHQtY2VudGVyIHB0LTI0IHB4LTYgcmVsYXRpdmVcIj5cclxuICAgICAgIFxyXG4gICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgdy1bODAwcHhdIGgtWzYwMHB4XSBiZy1lbWVyYWxkLTUwMC8xMCByb3VuZGVkLWZ1bGwgYmx1ci1bMTIwcHhdIHBvaW50ZXItZXZlbnRzLW5vbmVcIj48L2Rpdj5cclxuXHJcbiAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly9naXRodWIuY29tL3NjYXJsaW45MC9TaWduaW5nUm9vbVwiIHRhcmdldD1cIl9ibGFua1wiIGNsYXNzPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwLzgwIGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3Zlcjpib3JkZXItc2xhdGUtNjAwIHRyYW5zaXRpb24gbWItOCBjdXJzb3ItcG9pbnRlciBncm91cCByZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgPHN2ZyBsdWNpZGVDb2RlMiBjbGFzcz1cInctMyBoLTMgdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyBmb250LW1lZGl1bVwiPk9wZW4gU291cmNlIChBR1BMIHYzKSAmYnVsbDsgVmVyaWZ5IHRoZSBjb2RlPC9zcGFuPlxyXG4gICAgICAgIDxzdmcgbHVjaWRlQ2hldnJvblJpZ2h0IGNsYXNzPVwidy0zIGgtMyBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wLjUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj48L3N2Zz5cclxuICAgICAgPC9hPlxyXG5cclxuICAgICAgPGgxIGNsYXNzPVwidGV4dC01eGwgbWQ6dGV4dC03eGwgZm9udC1leHRyYWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZSBtYi02IGxlYWRpbmctdGlnaHQgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgIFNpZ25pbmcgUm9vbcKuIDxiciAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC10cmFuc3BhcmVudCBiZy1jbGlwLXRleHQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNDAwIHRvLWN5YW4tNDAwIHRleHQtM3hsIG1kOnRleHQtNXhsXCI+XHJcbiAgICAgICAgICBUaGUgUmVhbC1UaW1lIEJpdGNvaW4gTXVsdGlzaWcgQ29vcmRpbmF0b3JcclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgIDwvaDE+XHJcblxyXG4gICAgICA8cCBjbGFzcz1cInRleHQtbGcgbWQ6dGV4dC14bCB0ZXh0LXNsYXRlLTQwMCBtYi0xMCBtYXgtdy0yeGwgbXgtYXV0byBsZWFkaW5nLXJlbGF4ZWQgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgIFN0b3AgZW1haWxpbmcgUFNCVCBmaWxlcy4gQ29vcmRpbmF0ZSBCaXRjb2luIG11bHRpc2lnIHRlYW1zIGluc3RhbnRseS5cclxuICAgICAgICA8YnIgY2xhc3M9XCJoaWRkZW4gbWQ6YmxvY2tcIiAvPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1zbGF0ZS0yMDAgZm9udC1zZW1pYm9sZFwiPk5vIGFjY291bnRzLjwvc3Bhbj4gXHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXNsYXRlLTIwMCBmb250LXNlbWlib2xkXCI+Tm8gZGF0YWJhc2UuPC9zcGFuPiBcclxuICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtc2xhdGUtMjAwIGZvbnQtc2VtaWJvbGRcIj5FbmQtdG8tRW5kIEVuY3J5cHRlZC48L3NwYW4+XHJcbiAgICAgIDwvcD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNCByZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgPGEgcm91dGVyTGluaz1cIi9jcmVhdGVcIiBjbGFzcz1cInB4LTggcHktNCByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNTAwIGhvdmVyOmJnLWVtZXJhbGQtNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaGFkb3ctWzBfMF8yMHB4X3JnYmEoMTYsMTg1LDEyOSwwLjMpXSBjdXJzb3ItcG9pbnRlciB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktY2VudGVyIGhvdmVyOnNjYWxlLTEwNSB0cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICA8c3ZnIGx1Y2lkZVphcCBjbGFzcz1cInctNSBoLTUgZmlsbC1zbGF0ZS05NTBcIj48L3N2Zz5cclxuICAgICAgICAgIFN0YXJ0IFNpZ25pbmdcclxuICAgICAgICA8L2E+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vYXJ4aXYub3JnL2Ficy8yNjAxLjE3ODc1XCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJweC04IHB5LTQgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAvODAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1zbGF0ZS02MDAgdy1mdWxsIHNtOnctYXV0byBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgPHN2ZyBsdWNpZGVGaWxlVGV4dCBjbGFzcz1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgV2hpdGVwYXBlclxyXG4gICAgICAgIDwvYT5cclxuXHJcbiAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS9zY2FybGluOTAvc2lnbmluZ3Jvb20vdHJlZS9tYWluL2xpYnMvc2RrXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJweC04IHB5LTQgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAvODAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTYwMCB3LWZ1bGwgc206dy1hdXRvIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgY2xhc3M9XCJ3LTUgaC01XCI+PHBhdGggZD1cIk0xNSAyMnYtNGE0LjggNC44IDAgMCAwLTEtMy41YzMgMCA2LTIgNi01LjUuMDgtMS4yNS0uMjctMi40OC0xLTMuNS4yOC0xLjE1LjI4LTIuMzUgMC0zLjUgMCAwLTEgMC0zIDEuNS0yLjY0LS41LTUuMzYtLjUtOCAwQzYgMiA1IDIgNSAyYy0uMyAxLjE1LS4zIDIuMzUgMCAzLjVBNS40MDMgNS40MDMgMCAwIDAgNCA5YzAgMy41IDMgNS41IDYgNS41LS4zOS40OS0uNjggMS4wNS0uODUgMS42NS0uMTcuNi0uMjIgMS4yMy0uMTUgMS44NXY0XCIvPjxwYXRoIGQ9XCJNOSAxOGMtNC41MSAyLTUtMi03LTJcIi8+PC9zdmc+XHJcbiAgICAgICAgICBUeXBlU2NyaXB0IFNES1xyXG4gICAgICAgIDwvYT5cclxuXHJcbiAgICAgICAgPGEgaHJlZj1cIi93ZWJjb21wb25lbnQtZGVtby5odG1sP25nc3ctYnlwYXNzPXRydWVcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJleHRlcm5hbCBub29wZW5lciBub3JlZmVycmVyXCIgIGNsYXNzPVwicHgtOCBweS00IHJvdW5kZWQtbGcgYmctc2xhdGUtODAwLzgwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1zbGF0ZS02MDAgdy1mdWxsIHNtOnctYXV0byBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgPHN2ZyBsdWNpZGVUZXJtaW5hbCBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgIFdlYiBDb21wb25lbnQgRGVtb1xyXG4gICAgICA8L2E+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cIm1heC13LTV4bCBteC1hdXRvIG10LTE2IHB4LTYgcmVsYXRpdmUgei0xMCBhbmltYXRlLWZhZGUtaW4tdXBcIj5cclxuICAgICAgICA8ZGl2ICNkZW1vQ29udGFpbmVyIGNsYXNzPVwicm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNoYWRvdy0yeGwgc2hhZG93LWVtZXJhbGQtNTAwLzEwIGJnLXNsYXRlLTkwMC81MCBiYWNrZHJvcC1ibHVyLXNtIHJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1ncmFkaWVudC10by10IGZyb20tc2xhdGUtOTUwLzgwIHZpYS10cmFuc3BhcmVudCB0by10cmFuc3BhcmVudCBwb2ludGVyLWV2ZW50cy1ub25lIHotMTBcIj48L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxpbWcgc3JjPVwiYXNzZXRzL211bHRpc2lnLWRlbW8uZ2lmXCIgYWx0PVwiUmVhbC10aW1lIE11bHRpc2lnIFNpZ25pbmcgRGVtb1wiIGNsYXNzPVwidy1mdWxsIGgtYXV0byBvYmplY3QtY292ZXIgb3BhY2l0eS05MCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTcwMFwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwidG9nZ2xlRnVsbHNjcmVlbihkZW1vQ29udGFpbmVyKVwiIGNsYXNzPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB6LTMwIHAtMiByb3VuZGVkLWxnIGJnLXNsYXRlLTkwMC81MCBob3ZlcjpiZy1lbWVyYWxkLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItZW1lcmFsZC00MDAgdGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1hbGwgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zZm9ybSB0cmFuc2xhdGUteS0yIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS15LTAgZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZU1heGltaXplIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBib3R0b20tNiBsZWZ0LTYgei0yMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1ibGFjay81MCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRleHQteHMgdGV4dC13aGl0ZSBmb250LW1vbm8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXJlZC01MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBMaXZlIFByZXZpZXdcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMC8yMCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC14cyB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAzLW9mLTUgTXVsdGlzaWdcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJtYXgtdy00eGwgbXgtYXV0byBtdC0yNCBweC02IHJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgbWItMTBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItMlwiPldoeSBjaGFuZ2UgeW91ciB3b3JrZmxvdz88L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtNDAwXCI+TWFudWFsIGZpbGUgbWVyZ2luZyBpcyBlcnJvci1wcm9uZSBhbmQgc2xvdy4gVGhlcmUgaXMgYSBiZXR0ZXIgd2F5LjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgbWQ6Z3JpZC1jb2xzLTIgZ2FwLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtOCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05MDAvMzAgYm9yZGVyIGJvcmRlci1yZWQtOTAwLzIwIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIGxlZnQtMCB3LWZ1bGwgaC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1yZWQtNTAwLzAgdmlhLXJlZC01MDAvNTAgdG8tcmVkLTUwMC8wXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBtYi02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy01IGgtNSB0ZXh0LXJlZC00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICBUaGUgT2xkIFdheSAoRW1haWwvU2xhY2spXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyB0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWENpcmNsZSBjbGFzcz1cInctNSBoLTUgdGV4dC1yZWQtNTAwIHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1hbnVhbGx5IG1lcmdpbmcgNSBkaWZmZXJlbnQgZW1haWwgYXR0YWNobWVudHMuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyB0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWENpcmNsZSBjbGFzcz1cInctNSBoLTUgdGV4dC1yZWQtNTAwIHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkZpbGVzIHN0b3JlZCBwZXJtYW5lbnRseSBvbiBTbGFjay9Hb29nbGUgc2VydmVycy48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3M9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHRleHQtc20gdGV4dC1zbGF0ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYQ2lyY2xlIGNsYXNzPVwidy01IGgtNSB0ZXh0LXJlZC01MDAgc2hyaW5rLTBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2xvdywgYXN5bmNocm9ub3VzIGRlbGF5cyBiZXR3ZWVuIHNpZ25lcnMuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTggcm91bmRlZC0yeGwgYmctZW1lcmFsZC05MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgdy1mdWxsIGgtMSBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC01MDAvMCB2aWEtZW1lcmFsZC01MDAvNTAgdG8tZW1lcmFsZC01MDAvMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVaYXAgY2xhc3M9XCJ3LTUgaC01IHRleHQtZW1lcmFsZC00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICBUaGUgU2lnbmluZyBSb29twq4gV2F5XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyB0ZXh0LXNtIHRleHQtc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ2hlY2tDaXJjbGUyIGNsYXNzPVwidy01IGgtNSB0ZXh0LWVtZXJhbGQtNDAwIHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlYWwtdGltZSBtZXJnaW5nLiBFdmVyeW9uZSBzZWVzIHRoZSBzYW1lIHN0YXRlLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgdGV4dC1zbSB0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrQ2lyY2xlMiBjbGFzcz1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTQwMCBzaHJpbmstMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EYXRhIGxpdmVzIGluIFJBTSwgZW5jcnlwdGVkLCBhbmQgdmFuaXNoZXMgb24gZXhwaXJ5Ljwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzcz1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgdGV4dC1zbSB0ZXh0LXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrQ2lyY2xlMiBjbGFzcz1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTQwMCBzaHJpbmstMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5JbnN0YW50IGJyb2FkY2FzdCBvbmNlIHNpZ25hdHVyZXMgYXJlIGNvbGxlY3RlZC48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPHNlY3Rpb24gY2xhc3M9XCJtdC0zMiBib3JkZXIteSBib3JkZXItc2xhdGUtODAwLzYwIGJnLXNsYXRlLTkwMC8zMCBiYWNrZHJvcC1ibHVyLXNtIHB5LTIwIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTEvMiBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIC10cmFuc2xhdGUteS0xLzIgdy1bNjAwcHhdIGgtWzYwMHB4XSBiZy1lbWVyYWxkLTUwMC81IHJvdW5kZWQtZnVsbCBibHVyLVsxMDBweF0gcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cIm1heC13LTZ4bCBteC1hdXRvIHB4LTYgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBtYi0xNlwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItNFwiPkNvZGUgaXMgTGF3LiBQaHlzaWNzIGlzIEVuZm9yY2VtZW50LjwvaDI+XHJcbiAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtNDAwIG1heC13LTJ4bCBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIFdlIGVuZm9yY2UgdGhlIDxzcGFuIGNsYXNzPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LW1lZGl1bVwiPlVuaXZlcnNhbCBEZWNsYXJhdGlvbiBvZiBIdW1hbiBSaWdodHM8L3NwYW4+IFxyXG4gICAgICAgICAgICBub3QgdGhyb3VnaCBwb2xpY3ksIGJ1dCB0aHJvdWdoIGNyeXB0b2dyYXBoaWMgZ3VhcmFudGVlcy5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLThcIj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInAtNiByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAvNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNTAwLzUwIHRyYW5zaXRpb24gZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTIgaC0xMiByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNTAwLzEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTQgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxzdmcgbHVjaWRlRXllT2ZmIGNsYXNzPVwidy02IGgtNiB0ZXh0LWVtZXJhbGQtNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDMgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTFcIj5BcnRpY2xlIDEyPC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgZm9udC1tb25vIHRleHQtZW1lcmFsZC01MDAgbWItMyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Qcml2YWN5PC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICBcIk5vIG9uZSBzaGFsbCBiZSBzdWJqZWN0ZWQgdG8gYXJiaXRyYXJ5IGludGVyZmVyZW5jZSB3aXRoIGhpcyBwcml2YWN5LlwiXHJcbiAgICAgICAgICAgICAgPGJyLz48c3BhbiBjbGFzcz1cIm9wYWNpdHktNTAgbXQtMiBibG9jayBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIHB0LTJcIj5FbmZvcmNlZCB2aWEgQUVTLTI1Ni1HQ00uPC9zcGFuPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwicC02IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MC81MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAvNTAgdHJhbnNpdGlvbiBncm91cFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xMiBoLTEyIHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MDAvMTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItNCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTY2FsZSBjbGFzcz1cInctNiBoLTYgdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0xXCI+QXJ0aWNsZSAyMDwvaDM+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWVtZXJhbGQtNTAwIG1iLTMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+QXNzZW1ibHk8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgIFwiRXZlcnlvbmUgaGFzIHRoZSByaWdodCB0byBmcmVlZG9tIG9mIHBlYWNlZnVsIGFzc2VtYmx5IGFuZCBhc3NvY2lhdGlvbi5cIlxyXG4gICAgICAgICAgICAgIDxici8+PHNwYW4gY2xhc3M9XCJvcGFjaXR5LTUwIG10LTIgYmxvY2sgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC0yXCI+RW5mb3JjZWQgdmlhIEVwaGVtZXJhbCBSb29tcy48L3NwYW4+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTYgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwLzUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTUwMC81MCB0cmFuc2l0aW9uIGdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEyIGgtMTIgcm91bmRlZC1sZyBiZy1lbWVyYWxkLTUwMC8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00IGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZENoZWNrIGNsYXNzPVwidy02IGgtNiB0ZXh0LWVtZXJhbGQtNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDMgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTFcIj5BcnRpY2xlIDE3PC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgZm9udC1tb25vIHRleHQtZW1lcmFsZC01MDAgbWItMyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Qcm9wZXJ0eTwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgXCJObyBvbmUgc2hhbGwgYmUgYXJiaXRyYXJpbHkgZGVwcml2ZWQgb2YgaGlzIHByb3BlcnR5LlwiXHJcbiAgICAgICAgICAgICAgPGJyLz48c3BhbiBjbGFzcz1cIm9wYWNpdHktNTAgbXQtMiBibG9jayBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIHB0LTJcIj5FbmZvcmNlZCB2aWEgTm9uLUN1c3RvZGlhbCBNdWx0aXNpZy48L3NwYW4+XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTYgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwLzUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTUwMC81MCB0cmFuc2l0aW9uIGdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEyIGgtMTIgcm91bmRlZC1sZyBiZy1lbWVyYWxkLTUwMC8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00IGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUdsb2JlIGNsYXNzPVwidy02IGgtNiB0ZXh0LWVtZXJhbGQtNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8aDMgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTFcIj5BcnRpY2xlIDE5PC9oMz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgZm9udC1tb25vIHRleHQtZW1lcmFsZC01MDAgbWItMyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5FeHByZXNzaW9uPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICBcIlJpZ2h0IHRvIGZyZWVkb20gb2Ygb3BpbmlvbiBhbmQgZXhwcmVzc2lvbi4uLiB0aHJvdWdoIGFueSBtZWRpYS5cIlxyXG4gICAgICAgICAgICAgIDxici8+PHNwYW4gY2xhc3M9XCJvcGFjaXR5LTUwIG10LTIgYmxvY2sgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBwdC0yXCI+RW5mb3JjZWQgdmlhIFVuc3RvcHBhYmxlIENvZGUuPC9zcGFuPlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9zZWN0aW9uPlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJtYXgtdy02eGwgbXgtYXV0byBtdC0yNCBweC02IHJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgbWItMTBcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItMlwiPlRoZSBCbGluZCBSZWxheTwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDBcIj5XZSBmb3J3YXJkIHlvdXIgZW5jcnlwdGVkIHBhY2tldHMuIFdlIG5ldmVyIGhvbGQgdGhlIGtleXMuPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgZ3JvdXAgbWItMzJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIC1pbnNldC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTUwMC8yMCB0by1jeWFuLTUwMC8yMCByb3VuZGVkLXhsIGJsdXItbGcgb3BhY2l0eS01MCBncm91cC1ob3ZlcjpvcGFjaXR5LTcwIHRyYW5zaXRpb24gZHVyYXRpb24tMTAwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvODAgYmFja2Ryb3AtYmx1ci14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBwLTggbWQ6cC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNiBoLTE2IGJnLXNsYXRlLTkwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVc2VycyBjbGFzcz1cInctOCBoLTggdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtc20gZm9udC1ib2xkIHRleHQtd2hpdGVcIj5DbGllbnQgU2lkZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPkVuY3J5cHRzIHdpdGggS2V5PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBoLTAuNSBiZy1zbGF0ZS04MDAgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWVtZXJhbGQtNTAwLzUwIHctMS8yIGFuaW1hdGUtcHVsc2VcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJweC0zIHB5LTEgYmctc2xhdGUtOTAwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlTG9jayBjbGFzcz1cInctMyBoLTNcIj48L3N2Zz4gQUVTLTI1Ni1HQ01cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0yMCBoLTIwIGJnLXNsYXRlLTkwMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIG1iLTQgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlTmV0d29yayBjbGFzcz1cInctMTAgaC0xMCB0ZXh0LXNsYXRlLTYwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIC10b3AtMyAtcmlnaHQtMyBiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwIHRleHQtWzEwcHhdIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMFwiPkJMSU5EPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlRoZSBSb29tIChTZXJ2ZXIpPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+U3RvcmVzIEVuY3J5cHRlZCBCbG9iPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBoLTAuNSBiZy1zbGF0ZS04MDAgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSByaWdodC0wIHRvcC0wIGJvdHRvbS0wIGJnLWVtZXJhbGQtNTAwLzUwIHctMS8yIGFuaW1hdGUtcHVsc2VcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicHgtMyBweS0xIGJnLXNsYXRlLTkwMCByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtWzEwcHhdIHRleHQtY3lhbi00MDAgZm9udC1tb25vIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUZpbGVLZXkgY2xhc3M9XCJ3LTMgaC0zXCI+PC9zdmc+IFN5bmMgU3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNiBoLTE2IGJnLXNsYXRlLTkwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVc2VycyBjbGFzcz1cInctOCBoLTggdGV4dC1jeWFuLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtc20gZm9udC1ib2xkIHRleHQtd2hpdGVcIj5QZWVyIFNpZGU8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5EZWNyeXB0cyB2aWEgU2VjcmV0IExpbms8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibWF4LXctNXhsIG14LWF1dG8gbXQtMjQgcHgtNiByZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtY2VudGVyIG1iLTEyXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTRcIj5CdWlsdCBmb3IgT3JnYW5pemF0aW9uYWwgUmVzaWxpZW5jZTwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDAgbWF4LXctMnhsIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIFNpbmdsZS1zaWduYXR1cmUgd2FsbGV0cyBhcmUgYSBsaWFiaWxpdHkgZm9yIHRlYW1zLiBcclxuICAgICAgICAgICAgICAgIDxicj5NdWx0aXNpZyBlbnN1cmVzIG5vIHNpbmdsZSBwZXJzb27igJRub3QgZXZlbiB0aGUgQ0VP4oCUaXMgYSBzaW5nbGUgcG9pbnQgb2YgZmFpbHVyZS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctc2xhdGUtOTAwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNiByb3VuZGVkLTJ4bCBob3ZlcjpiZy1zbGF0ZS05MDAvNjAgdHJhbnNpdGlvbiBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTIgaC0xMiBiZy1pbmRpZ28tOTUwLzMwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItNCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVVzZXJzIGNsYXNzPVwidy02IGgtNiB0ZXh0LWluZGlnby00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0yXCI+RmxleGlibGUgXCJNLW9mLU5cIiBDb25zZW5zdXM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERvbid0IGJlIGxvY2tlZCBpbnRvIGEgcmlnaWQgc3RydWN0dXJlLiBXaGV0aGVyIHlvdSBuZWVkIGEgPHN0cm9uZz4yLW9mLTM8L3N0cm9uZz4gZm9yIGZvdW5kZXJzIG9yIGEgPHN0cm9uZz4zLW9mLTU8L3N0cm9uZz4gZm9yIHRoZSBib2FyZCwgeW91IGRlZmluZSB0aGUgcXVvcnVtIHJlcXVpcmVkIHRvIGF1dGhvcml6ZSBmdW5kcy5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctc2xhdGUtOTAwLzQwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNiByb3VuZGVkLTJ4bCBob3ZlcjpiZy1zbGF0ZS05MDAvNjAgdHJhbnNpdGlvbiBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTIgaC0xMiBiZy1yb3NlLTk1MC8zMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTQgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy02IGgtNiB0ZXh0LXJvc2UtNTAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItMlwiPk1pdGlnYXRlIFwiS2V5IFBlcnNvblwiIFJpc2s8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFdoYXQgaWYgdGhlIENFTyBpcyBpbiBhbiBhY2NpZGVudCBvciBsb3NlcyBhY2Nlc3MgdG8gdGhlaXIga2V5cz8gSW4gYSBtdWx0aXNpZyBzZXR1cCwgdGhlIHJlbWFpbmluZyBib2FyZCBtZW1iZXJzIGNhbiBzdGlsbCBhcHByb3ZlIHBheXJvbGwsIGVuc3VyaW5nIGJ1c2luZXNzIGNvbnRpbnVpdHkuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLWVtZXJhbGQtOTUwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgcC02IHJvdW5kZWQtMnhsIGhvdmVyOmJnLWVtZXJhbGQtOTUwLzIwIHRyYW5zaXRpb24gZ3JvdXAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTE2IGgtMTYgYmctZW1lcmFsZC01MDAvMTAgYmx1ci14bCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEyIGgtMTIgYmctZW1lcmFsZC05NTAvMzAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00IGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWmFwIGNsYXNzPVwidy02IGgtNiB0ZXh0LWVtZXJhbGQtNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGUgbWItMlwiPlNlY3VyaXR5IHdpdGhvdXQgdGhlIGZyaWN0aW9uPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBIaXN0b3JpY2FsbHksIGNvb3JkaW5hdGluZyBhIGJvYXJkIHZvdGUgb24tY2hhaW4gd2FzIHNsb3cgYW5kIHBhaW5mdWwuIFNpZ25pbmdSb29tIGZpeGVzIHRoaXMuIFdlIGNvbWJpbmUgdGhlIDxzdHJvbmc+Z292ZXJuYW5jZTwvc3Ryb25nPiBvZiBtdWx0aXNpZyB3aXRoIHRoZSA8c3Ryb25nPnNwZWVkPC9zdHJvbmc+IG9mIGEgcmVhbC10aW1lIGNoYXQgcm9vbS5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibWF4LXctNHhsIG14LWF1dG8gbXQtMjQgcHgtNiByZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtY2VudGVyIG1iLTEwXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTJcIj5CdWlsZCB3aXRoIFNpZ25pbmcgUm9vbSBTREs8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtNDAwXCI+SW50ZWdyYXRlIG91ciByb2J1c3QgbXVsdGlzaWcgY29vcmRpbmF0aW9uIGxvZ2ljIGludG8geW91ciBvd24gYXBwbGljYXRpb25zLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtOCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTkwMCB0by1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBpdGVtcy1jZW50ZXIgZ2FwLTggc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleC0xIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDb2RlMiBjbGFzcz1cInctNiBoLTYgdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIFNpZ25pbmcgUm9vbSBTREtcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc20gdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICBBIGZyYW1ld29yay1hZ25vc3RpYyBUeXBlU2NyaXB0IFNESyBmb3IgbWFuYWdpbmcgZW5kLXRvLWVuZCBlbmNyeXB0ZWQgbXVsdGlzaWcgY2VyZW1vbmllcy4gXHJcbiAgICAgICAgICAgICAgICAgICAgSGFuZGxlIHJvb20gbGlmZWN5Y2xlLCBQU0JUIG1lcmdpbmcsIGFuZCBhdWRpdCB0cmFpbCBnZW5lcmF0aW9uIHByb2dyYW1tYXRpY2FsbHkuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly93d3cubnBtanMuY29tL3BhY2thZ2UvQHNpZ25pbmctcm9vbS9zZGtcIiB0YXJnZXQ9XCJfYmxhbmtcIiBjbGFzcz1cInB4LTUgcHktMi41IHJvdW5kZWQtbGcgYmctZW1lcmFsZC01MDAgaG92ZXI6YmctZW1lcmFsZC00MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ib2xkIHRleHQtc20gdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV4dGVybmFsTGluayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBvbiBOUE1cclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS9zY2FybGluOTAvc2lnbmluZ3Jvb20vdHJlZS9tYWluL2xpYnMvc2RrXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJweC01IHB5LTIuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVGaWxlVGV4dCBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVhZCBEb2NzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL3lvdXR1LmJlL3l6Y0ZsSzZjNnQwXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJweC01IHB5LTIuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIGNsYXNzPVwidy00IGgtNFwiPjxwYXRoIGQ9XCJNMi41IDE3YTI0LjEyIDI0LjEyIDAgMCAxIDAtMTAgMiAyIDAgMCAxIDEuNC0xLjQgNDkuNTYgNDkuNTYgMCAwIDEgMTYuMiAwQTIgMiAwIDAgMSAyMS41IDdhMjQuMTIgMjQuMTIgMCAwIDEgMCAxMCAyIDIgMCAwIDEtMS40IDEuNCA0OS41NSA0OS41NSAwIDAgMS0xNi4yIDBBMiAyIDAgMCAxIDIuNSAxN1wiLz48cGF0aCBkPVwibTEwIDE1IDUtMy01LTN6XCIvPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBXYXRjaFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBtZDp3LTEvMyBiZy1ibGFjayByb3VuZGVkLWxnIHAtNCBmb250LW1vbm8gdGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIG5wbSBpbnN0YWxsIEBzaWduaW5nLXJvb20vc2RrPGJyPjxicj5cclxuICAgICAgICAgICAgICAgIGNvbnN0IGNsaWVudCA9IG5ldyBTaWduaW5nUm9vbUNsaWVudCgmIzEyMzs8YnI+XHJcbiAgICAgICAgICAgICAgICAmbmJzcDsmbmJzcDthcGlVcmw6ICcuLi4nPGJyPlxyXG4gICAgICAgICAgICAgICAgJiMxMjU7KTs8YnI+PGJyPlxyXG4gICAgICAgICAgICAgICAgYXdhaXQgY2xpZW50LmNyZWF0ZVJvb21BbmRKb2luKC4uLik7XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cIm1heC13LTR4bCBteC1hdXRvIG10LTI0IHB4LTYgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBtYi0xMFwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0yXCI+Q29tbWVyY2lhbCBXaGl0ZWxhYmVsaW5nPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNsYXRlLTQwMFwiPkRlcGxveSBhIGRlZGljYXRlZCwgYnJhbmRlZCBpbnN0YW5jZSBmb3IgeW91ciBlbnRlcnByaXNlIG9yIGluc3RpdHV0aW9uLjwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtOCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTkwMCB0by1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBpdGVtcy1jZW50ZXIgZ2FwLTggc2hhZG93LTJ4bFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleC0xIHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVCdWlsZGluZzIgY2xhc3M9XCJ3LTYgaC02IHRleHQtY3lhbi00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICBFbnRlcnByaXNlIFNlbGYtSG9zdGluZ1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXJlbGF4ZWQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE1haW50YWluIGNvbXBsZXRlIHNvdmVyZWlnbnR5IG92ZXIgeW91ciBjb29yZGluYXRpb24gbGF5ZXIuIFxyXG4gICAgICAgICAgICAgICAgICAgIERlcGxveSBTaWduaW5nIFJvb20gdG8geW91ciBvd24gaW5mcmFzdHJ1Y3R1cmUgd2l0aCBhIGN1c3RvbSBkb21haW4sIHRhaWxvcmVkIGJyYW5kaW5nLCBhbmQgZnVsbCBjb21tZXJjaWFsIHN1cHBvcnQgdmlhIGFuIEFHUEwgd2FpdmVyLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC13cmFwIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vc3RhZ2luZy1icmFuZGVkLnNpZ25pbmdyb29tLmlvXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJweC01IHB5LTIuNSByb3VuZGVkLWxnIGJnLWN5YW4tNTAwLzEwIGhvdmVyOmJnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi00MDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8zMCBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSBTbWFsbCBmYWxsYmFjayBTVkcgaWYgYnJhbmRlZC1sb2dvIGlzIG1pc3NpbmcgaW4gdGhlIHVuYnJhbmRlZCBlbnZpcm9ubWVudCAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCJicmFuZC9icmFuZGVkLWxvZ28uc3ZnXCIgYWx0PVwiWm9yb3MgRmluYW5jaWFsXCIgY2xhc3M9XCJ3LTQgaC00IG9iamVjdC1jb250YWluXCIgb25lcnJvcj1cInRoaXMuc3JjPSdkYXRhOmltYWdlL3N2Zyt4bWw7YmFzZTY0LFBITjJaeUI0Yld4dWN6MGlhSFIwY0RvdkwzZDNkeTUzTXk1dmNtY3ZNakF3TUM5emRtY2lJSFpwWlhkQ2IzZzlJakFnTUNBeU5DQXlOQ0lnWm1sc2JEMGlibTl1WlNJZ2MzUnliMnRsUFNJak1qSmtNMlZsSWlCemRISnZhMlV0ZDJsa2RHZzlJaklpSUhOMGNtOXJaUzFzYVc1bFkyRndQU0p5YjNWdVpDSWdjM1J5YjJ0bExXeHBibVZxYjJsdVBTSnliM1Z1WkNJK1BIQmhkR2dnWkQwaVRUSWdNVEpvTWpBaUx6NDhjR0YwYUNCa1BTSk5NaklnTmtneklpOCtQSEJoZEdnZ1pEMGlUVElnTVRob01qQWlMejQ4TDNOMlp6ND0nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFpvcm9zIEZpbmFuY2lhbCAoRGVtbylcclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vc3RhdGVsZXNzcmVzZWFyY2guY29tXCIgdGFyZ2V0PVwiX2JsYW5rXCIgY2xhc3M9XCJweC01IHB5LTIuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeHRlcm5hbExpbmsgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbnRhY3QgU2FsZXNcclxuICAgICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LWZ1bGwgbWQ6dy0xLzMgZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL3N0YWdpbmctYnJhbmRlZC5zaWduaW5ncm9vbS5pb1wiIHRhcmdldD1cIl9ibGFua1wiIGNsYXNzPVwicmVsYXRpdmUgdy00OCBoLTQ4IGJsb2NrIGdyb3VwIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgYmctY3lhbi01MDAvMjAgcm91bmRlZC1mdWxsIGJsdXItMnhsIGFuaW1hdGUtcHVsc2UgZ3JvdXAtaG92ZXI6YmctY3lhbi01MDAvNDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIHctZnVsbCBoLWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGdyb3VwLWhvdmVyOmJvcmRlci1jeWFuLTUwMC81MCByb3VuZGVkLXhsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiBzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHRyYW5zZm9ybSBncm91cC1ob3ZlcjotdHJhbnNsYXRlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCJicmFuZC9icmFuZGVkLWxvZ28uc3ZnXCIgYWx0PVwiQ3VzdG9tIEJyYW5kaW5nXCIgY2xhc3M9XCJ3LTE2IGgtMTYgb2JqZWN0LWNvbnRhaW4gbWItNFwiIG9uZXJyb3I9XCJ0aGlzLnNyYz0nZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQSE4yWnlCNGJXeHVjejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TWpBd01DOXpkbWNpSUhacFpYZENiM2c5SWpBZ01DQXlOQ0F5TkNJZ1ptbHNiRDBpYm05dVpTSWdjM1J5YjJ0bFBTSWpNakprTTJWbElpQnpkSEp2YTJVdGQybGtkR2c5SWpJaUlITjBjbTlyWlMxc2FXNWxZMkZ3UFNKeWIzVnVaQ0lnYzNSeWIydGxMV3hwYm1WcWIybHVQU0p5YjNWdVpDSStQSEJoZEdnZ1pEMGlUVElnTVRKb01qQWlMejQ4Y0dGMGFDQmtQU0pOTWpJZ05rZ3pJaTgrUEhCaGRHZ2daRDBpVFRJZ01UaG9NakFpTHo0OEwzTjJaejQ9J1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtbGcgdHJhY2tpbmctdGlnaHQgbGVhZGluZy1ub25lIG1iLTFcIj5ab3JvczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1jeWFuLTQwMCBmb250LW1lZGl1bSB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlXCI+RmluYW5jaWFsPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibWF4LXctNHhsIG14LWF1dG8gbXQtMjQgcHgtNiByZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtY2VudGVyIG1iLTEwXCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTJcIj5UZWNobmljYWwgU3RhbmRhcmRzPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNsYXRlLTQwMFwiPkJ1aWx0IG9uIG9wZW4gQml0Y29pbiBwcm90b2NvbHMgYW5kIGluZHVzdHJpYWwgZW5jcnlwdGlvbi48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy00IGdhcC00IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicC00IHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwLzMwIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNwdSBjbGFzcz1cInctNiBoLTYgdGV4dC1zbGF0ZS01MDAgbXgtYXV0byBtYi0yXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5CSVAtMTc0PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5QU0JUIE5hdGl2ZTwvZGl2PlxyXG4gICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicC00IHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwLzMwIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUxvY2sgY2xhc3M9XCJ3LTYgaC02IHRleHQtc2xhdGUtNTAwIG14LWF1dG8gbWItMlwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+QUVTLUdDTTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwXCI+RW5kLXRvLUVuZCBFbmNyeXB0ZWQ8L2Rpdj5cclxuICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtNCByb3VuZGVkLWxnIGJnLXNsYXRlLTkwMC8zMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVOZXR3b3JrIGNsYXNzPVwidy02IGgtNiB0ZXh0LXNsYXRlLTUwMCBteC1hdXRvIG1iLTJcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPldlYlNvY2tldDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwXCI+UmVhbC10aW1lPC9kaXY+XHJcbiAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTQgcm91bmRlZC1sZyBiZy1zbGF0ZS05MDAvMzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRmluZ2VycHJpbnQgY2xhc3M9XCJ3LTYgaC02IHRleHQtc2xhdGUtNTAwIG14LWF1dG8gbWItMlwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+RXBoZW1lcmFsPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5ObyBMb2dzPC9kaXY+XHJcbiAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJtYXgtdy00eGwgbXgtYXV0byBtdC0xMiBweC02IHRleHQtY2VudGVyIHJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtNTAwIHRleHQtc20gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IG1iLThcIj5Db21wYXRpYmxlIHdpdGggeW91ciBIYXJkd2FyZSBXYWxsZXRzICYgU29mdHdhcmU8L3A+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC13cmFwIGp1c3RpZnktY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicHgtNCBweS0yIHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIHRleHQtc20gZm9udC1ib2xkXCI+U3BhcnJvdzwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJweC00IHB5LTIgcm91bmRlZC1sZyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBmb250LWJvbGRcIj5FbGVjdHJ1bTwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJweC00IHB5LTIgcm91bmRlZC1sZyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBmb250LWJvbGRcIj5Db2xkY2FyZDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJweC00IHB5LTIgcm91bmRlZC1sZyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBmb250LWJvbGRcIj5UcmV6b3I8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicHgtNCBweS0yIHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIHRleHQtc20gZm9udC1ib2xkXCI+TGVkZ2VyPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzcz1cInB4LTQgcHktMiByb3VuZGVkLWxnIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCB0ZXh0LXNtIGZvbnQtYm9sZFwiPk51bmNodWs8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicHgtNCBweS0yIHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIHRleHQtc20gZm9udC1ib2xkXCI+Qml0Qm94MDI8L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwibWF4LXctM3hsIG14LWF1dG8gbXQtMjAgbWItMjAgcHgtNiByZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgIDxoMiBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG1iLTggdGV4dC1jZW50ZXJcIj5GcmVxdWVudGx5IEFza2VkIFF1ZXN0aW9uczwvaDI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC02IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTkwMCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlSGVscENpcmNsZSBjbGFzcz1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICBXaGVyZSBpcyBteSBwcml2YXRlIGtleT9cclxuICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgIEl0IHN0YXlzIG9uIHlvdXIgaGFyZHdhcmUgd2FsbGV0IG9yIHNpZ25pbmcgZGV2aWNlLiBZb3Ugb25seSB1cGxvYWQgYSBcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXNsYXRlLTMwMFwiPlBTQlQgKFBhcnRpYWxseSBTaWduZWQgQml0Y29pbiBUcmFuc2FjdGlvbik8L3NwYW4+LCBcclxuICAgICAgICAgICAgd2hpY2ggY29udGFpbnMgbm8gcHJpdmF0ZSBrZXlzLCBvbmx5IHB1YmxpYyBkYXRhIGFuZCBzaWduYXR1cmVzLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC02IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTkwMCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlSGVscENpcmNsZSBjbGFzcz1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICBDYW4geW91IHNlZSBteSB0cmFuc2FjdGlvbiBkZXRhaWxzP1xyXG4gICAgICAgICAgPC9oMz5cclxuICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgTm8uIFlvdXIgdHJhbnNhY3Rpb24gaXMgZW5jcnlwdGVkIGluIHlvdXIgYnJvd3NlciB1c2luZyBhIGtleSB0aGF0IGlzIGNvbnRhaW5lZCBpbiB0aGUgVVJMIGxpbmsgaGFzaCAoZnJhZ21lbnQpLiBcclxuICAgICAgICAgICAgVGhpcyBrZXkgaXMgbmV2ZXIgc2VudCB0byBvdXIgc2VydmVycywgc28gd2UgbGl0ZXJhbGx5IGNhbm5vdCBkZWNyeXB0IHlvdXIgZGF0YS5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNiBiZy1zbGF0ZS05MDAvNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS05MDAgdHJhbnNpdGlvblwiPlxyXG4gICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8c3ZnIGx1Y2lkZUhlbHBDaXJjbGUgY2xhc3M9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgSXMgaXQgcmVhbGx5IGZyZWU/XHJcbiAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3M9XCJ0ZXh0LXNsYXRlLTIwMFwiPlllcy48L3N0cm9uZz4gU2lnbmluZ1Jvb20uaW8gaXMgYSAxMDAlIGZyZWUsIG9wZW4tc291cmNlIHB1YmxpYyBnb29kLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIFdlIGNvdmVyIG91ciBjb3N0cyB0aHJvdWdoIG9wdGlvbmFsIGRvbmF0aW9ucyBhbmQgZW50ZXJwcmlzZSBsaWNlbnNpbmcuIFRoZXJlIGFyZSBubyBwYWlkIHRpZXJzIGZvciB0aGUgcHVibGljIHNlcnZpY2UuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC02IGJnLXNsYXRlLTkwMC81MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTkwMCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC13aGl0ZSBtYi0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlQnVpbGRpbmcyIGNsYXNzPVwidy00IGgtNCB0ZXh0LWN5YW4tNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgIENhbiBJIGhvc3QgdGhpcyBteXNlbGY/IChFbnRlcnByaXNlKVxyXG4gICAgICAgICAgPC9oMz5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzPVwidGV4dC1zbGF0ZS0yMDBcIj5ZZXMuPC9zdHJvbmc+IFRoZSBjb2RlIGlzIG9wZW4gc291cmNlIChBR1BMIHYzKSwgc28geW91IGNhbiBhdWRpdCBhbmQgcnVuIGl0IHlvdXJzZWxmLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgIEZvciBpbnN0aXR1dGlvbnMgcmVxdWlyaW5nIGEgY29tbWVyY2lhbCBsaWNlbnNlIChBR1BMIHdhaXZlcikgdG8gaW50ZWdyYXRlIGludG8gcHJvcHJpZXRhcnksIGNsb3NlZC1zb3VyY2UgaW5mcmFzdHJ1Y3R1cmUsIHBsZWFzZSBjb250YWN0IFxyXG4gICAgICAgICAgICAgIDxhIGhyZWY9XCJodHRwczovL3N0YXRlbGVzc3Jlc2VhcmNoLmNvbVwiIHRhcmdldD1cIl9ibGFua1wiIGNsYXNzPVwidGV4dC1lbWVyYWxkLTQwMCBob3Zlcjp1bmRlcmxpbmVcIj5TdGF0ZWxlc3MgUmVzZWFyY2ggTHRkPC9hPi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJib3JkZXItdCBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTkwMC81MCBweS0yMCB0ZXh0LWNlbnRlciBweC02IHJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICA8aDIgY2xhc3M9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC13aGl0ZSBtYi02XCI+UmVhZHkgdG8gY29vcmRpbmF0ZT88L2gyPlxyXG4gICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbGF0ZS00MDAgbWItOCBtYXgtdy1sZyBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIE5vIGFjY291bnRzIHJlcXVpcmVkLiBKdXN0IHVwbG9hZCBhIFBTQlQgYW5kIHNoYXJlIHRoZSBzZWN1cmUgbGluay5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgPGEgcm91dGVyTGluaz1cIi9jcmVhdGVcIiBjbGFzcz1cImlubGluZS1mbGV4IHB4LTggcHktNCByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNTAwIGhvdmVyOmJnLWVtZXJhbGQtNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBpdGVtcy1jZW50ZXIgZ2FwLTIgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTUwMC8yMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgU3RhcnQgU2lnbmluZ1xyXG4gICAgICAgICAgPHN2ZyBsdWNpZGVDaGV2cm9uUmlnaHQgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgPC9kaXY+XHJcbiAgYCxcclxufSlcclxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIG5nT25Jbml0KCkge31cclxuXHJcbiAgdG9nZ2xlRnVsbHNjcmVlbihlbGVtZW50OiBIVE1MRWxlbWVudCkge1xyXG4gICAgaWYgKCFkb2N1bWVudC5mdWxsc2NyZWVuRWxlbWVudCkge1xyXG4gICAgICBlbGVtZW50LnJlcXVlc3RGdWxsc2NyZWVuKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIGVuYWJsaW5nIGZ1bGxzY3JlZW46ICR7ZXJyLm1lc3NhZ2V9YCk7XHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZG9jdW1lbnQuZXhpdEZ1bGxzY3JlZW4oKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlciwgQ2FuQWN0aXZhdGVGbiB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IENvbmZpZ1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jb25maWcvY29uZmlnLnNlcnZpY2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IHdoaXRlbGFiZWxHdWFyZDogQ2FuQWN0aXZhdGVGbiA9ICgpID0+IHtcclxuICBjb25zdCBjb25maWdTZXJ2aWNlID0gaW5qZWN0KENvbmZpZ1NlcnZpY2UpO1xyXG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG5cclxuICBpZiAoY29uZmlnU2VydmljZS5jb25maWcoKS53aGl0ZWxhYmVsKSB7XHJcbiAgICByZXR1cm4gcm91dGVyLmNyZWF0ZVVybFRyZWUoWycvY3JlYXRlJ10pO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHRydWU7XHJcbn07XHJcbiIsImltcG9ydCB7IFJvdXRlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEhvbWVDb21wb25lbnQgfSBmcm9tICcuL3BhZ2VzL2hvbWUvaG9tZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgd2hpdGVsYWJlbEd1YXJkIH0gZnJvbSAnLi9ndWFyZHMvd2hpdGVsYWJlbC5ndWFyZCc7XG5cbmV4cG9ydCBjb25zdCBhcHBSb3V0ZXM6IFJvdXRlW10gPSBbXG4gIHsgcGF0aDogJycsIGNvbXBvbmVudDogSG9tZUNvbXBvbmVudCwgY2FuQWN0aXZhdGU6IFt3aGl0ZWxhYmVsR3VhcmRdIH0sXG4gIHtcbiAgICBwYXRoOiAnY3JlYXRlJyxcbiAgICBsb2FkQ29tcG9uZW50OiAoKSA9PiBpbXBvcnQoJy4vcGFnZXMvY3JlYXRlL2NyZWF0ZS5jb21wb25lbnQnKS50aGVuKChtKSA9PiBtLkNyZWF0ZUNvbXBvbmVudCksXG4gIH0sXG4gIHtcbiAgICBwYXRoOiAncm9vbS86aWQnLFxuICAgIGxvYWRDb21wb25lbnQ6ICgpID0+IGltcG9ydCgnLi9wYWdlcy9yb29tL3Jvb20uY29tcG9uZW50JykudGhlbigobSkgPT4gbS5Sb29tQ29tcG9uZW50KSxcbiAgfSxcbiAgeyBwYXRoOiAnKionLCByZWRpcmVjdFRvOiAnJyB9LFxuXTtcbiIsIi8qXHJcbiAqIENvcHlyaWdodCAoQykgMjAyNiBTdGF0ZWxlc3MgUmVzZWFyY2ggTHRkXHJcbiAqXHJcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOiB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XHJcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEFmZmVybyBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZFxyXG4gKiBieSB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uLCBlaXRoZXIgdmVyc2lvbiAzIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZGlzdHJpYnV0ZWQgaW4gdGhlIGhvcGUgdGhhdCBpdCB3aWxsIGJlIHVzZWZ1bCxcclxuICogYnV0IFdJVEhPVVQgQU5ZIFdBUlJBTlRZOyB3aXRob3V0IGV2ZW4gdGhlIGltcGxpZWQgd2FycmFudHkgb2ZcclxuICogTUVSQ0hBTlRBQklMSVRZIG9yIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFLiBTZWUgdGhlXHJcbiAqIEdOVSBBZmZlcm8gR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBmb3IgbW9yZSBkZXRhaWxzLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7IENvbXBvbmVudCwgVmlld0VuY2Fwc3VsYXRpb24sIGluamVjdCwgT25Jbml0LCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlLCBET0NVTUVOVCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IFJvdXRlck1vZHVsZSwgUm91dGVyLCBOYXZpZ2F0aW9uRW5kIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5pbXBvcnQgeyBDb25maWdTZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9jb25maWcvY29uZmlnLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBUaXRsZSwgTWV0YSB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xyXG5pbXBvcnQge1xyXG4gIEx1Y2lkZVNoaWVsZCxcclxuICBMdWNpZGVVc2VycyxcclxuICBMdWNpZGVaYXAsXHJcbiAgTHVjaWRlS2V5LFxyXG4gIEx1Y2lkZUdsb2JlLFxyXG4gIEx1Y2lkZU1haWwsXHJcbn0gZnJvbSAnQGx1Y2lkZS9hbmd1bGFyJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLXJvb3QnLFxyXG4gIHN0YW5kYWxvbmU6IHRydWUsXHJcbiAgaW1wb3J0czogW1xyXG4gICAgQ29tbW9uTW9kdWxlLFxyXG4gICAgUm91dGVyTW9kdWxlLFxyXG4gICAgTHVjaWRlU2hpZWxkLFxyXG4gICAgTHVjaWRlWmFwLFxyXG4gICAgTHVjaWRlS2V5LFxyXG4gICAgTHVjaWRlR2xvYmUsXHJcbiAgICBMdWNpZGVNYWlsLFxyXG4gIF0sXHJcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcclxuICB0ZW1wbGF0ZTogYFxyXG4gICAgPGRpdiBjbGFzcz1cIm1pbi1oLXNjcmVlbiBmbGV4IGZsZXgtY29sIGJnLWJyYW5kLWJnIHRleHQtYnJhbmQtdGV4dFwiPlxyXG4gICAgICBAaWYgKCFpc0VtYmVkZGVkKSB7XHJcbiAgICAgICAgPG5hdiBjbGFzcz1cInctZnVsbCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIvNjAgYmFja2Ryb3AtYmx1ci1tZCBmaXhlZCB0b3AtMCB6LTUwIGJnLWJyYW5kLWJnLzgwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibWF4LXctNnhsIG14LWF1dG8gcHgtNiBoLTE2IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODAgdHJhbnNpdGlvbi1vcGFjaXR5XCIgcm91dGVyTGluaz1cIi9cIj5cclxuICAgICAgICAgICAgICBAaWYgKGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkud2hpdGVsYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgPGltZyBbc3JjXT1cImNvbmZpZ1NlcnZpY2UuY29uZmlnKCkubG9nb1VybFwiIFthbHRdPVwiY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWVcIiBjbGFzcz1cInctNyBoLTcgb2JqZWN0LWNvbnRhaW5cIiAvPlxyXG4gICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCA0MDkgNDQ1XCIgY2xhc3M9XCJ3LTcgaC03IHRleHQtYnJhbmQtYWNjZW50IGZpbGwtY3VycmVudFwiIHByZXNlcnZlQXNwZWN0UmF0aW89XCJ4TWlkWU1pZCBtZWV0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTg1LjUgNDI1LjcgYy0zNS40IC0xNy4zIC03MiAtNDMuNCAtOTguMiAtNjkuOSAtMzEuNiAtMzEuOSAtNTAuMyAtNjIuNSAtNTkuMSAtOTYuOCAtNS42IC0yMS43IC01LjcgLTIzLjQgLTUuNyAtMTAxIDAgLTY2LjYgMC4xIC03MS43IDEuOCAtNzUuMSAyLjMgLTQuNiA2LjEgLTYuNyAyMi4yIC0xMi4yIDcuMiAtMi41IDMxLjkgLTExLjMgNTUgLTE5LjcgNzkuNCAtMjguNyA5Ny42IC0zNSAxMDAuNCAtMzUgMi44IDAgMjcuNSA4LjMgNTMuNiAxOCAyMS4zIDcuOSA3MC42IDI1LjcgOTIgMzMuMSAxMSAzLjkgMjEuNCA3LjUgMjMgOC4xIDQuNCAxLjYgOC40IDUuNyA5LjUgOS43IDEuMyA0LjkgMS4zIDEzNi44IDAgMTQ4LjYgLTQuOSA0Mi42IC0yMS4yIDc2LjEgLTU1LjEgMTEzLjEgLTIxIDIzIC00OS43IDQ2IC03OS40IDYzLjkgLTE1LjkgOS42IC00MC4xIDIxLjUgLTQzLjYgMjEuNSAtMi4xIDAgLTguMiAtMi4zIC0xNi40IC02LjN6IG0yNC42IC0yOC44IGMzMS40IC0xNS43IDcxLjcgLTQ1LjYgOTIgLTY4IDI2LjkgLTI5LjggMzkuMyAtNTIgNDcuMiAtODQuNCAyLjEgLTguOCAyLjIgLTEwLjMgMi4yIC03Ni45IGwwIC02Ny45IC0xNyAtNi4yIGMtNDguNSAtMTcuNyAtODQuNiAtMzAuNiAtMTE2IC00MS42IGwtMTYuOSAtNiAtMjAuMSA3LjEgYy0xMSA0IC0yNi41IDkuNiAtMzQuNSAxMi41IC04IDIuOSAtMTguMyA2LjcgLTIzIDguMyAtMTEuNiA0IC0zNi4yIDEyLjkgLTQzLjUgMTUuNyAtMy4zIDEuMyAtMTAuOSA0IC0xNyA2LjEgLTYgMi4xIC0xMS4yIDQuMSAtMTEuNSA0LjUgLTEgMS40IC0xIDExMy4zIC0wLjEgMTI0LjkgMC41IDYuMyAxLjcgMTUuMSAyLjYgMTkuNSAxMC42IDUyLjEgNTIuMiAxMDEuNCAxMTkgMTQxIDExLjQgNi44IDI3IDE1LjMgMjguMyAxNS41IDAuMSAwIDMuOSAtMS44IDguMyAtNC4xelwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTE5MS4zIDMxOC4zIGMtNy42IC03LjQgLTguMSAtOC4xIC04LjYgLTEyLjggLTAuMiAtMi43IC0wLjUgLTI3LjkgLTAuNiAtNTUuOSAwIC0yOCAtMC4yIC01MSAtMC4zIC01MS4xIC0wLjIgLTAuMSAtMi41IC0xLjQgLTUuMSAtMi45IC03IC00IC0xMS4xIC04IC0xNi4xIC0xNS40IC01LjkgLTguOSAtOC42IC0xNy41IC04LjYgLTI3LjEgMCAtMjcgMTkuNSAtNDguNSA0NS45IC01MC43IDEzIC0xLjEgMjYuMSAzLjUgMzYuNiAxMi45IDE5LjggMTcuNiAyMS44IDUwLjMgNC40IDcwLjEgLTQuMSA0LjYgLTE0LjggMTIuNiAtMTYuOCAxMi42IC0wLjcgMCAtMS4xIDYuMyAtMS4xIDE5IGwwIDE5IC02LjEgNi42IC02IDYuNyA2IDYuMSBjOC4yIDguMyA4LjIgMTAuMSAwIDE4LjMgbC02IDYgNiA1LjggNi4xIDUuOCAwIDguMyAwIDguMiAtOSA5LjEgYy01IDUgLTkuOSA5LjEgLTEwLjkgOS4xIC0xIDAgLTUuNCAtMy41IC05LjggLTcuN3ogbTE3LjcgLTE3NSBjMy42IC0yLjQgNC44IC00LjMgNS41IC04LjMgMSAtNS43IC0xLjQgLTExLjEgLTYgLTEzLjcgLTQuOSAtMi44IC04LjQgLTIuOSAtMTMuNCAtMC4zIC0zLjggMS45IC00LjUgMi44IC02LjIgOC40IC0xLjIgNC4xIDAuOCAxMC4yIDQuNCAxMy4yIDMuNiAzIDExLjggMy40IDE1LjcgMC43elwiLz5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwiTTEzMC4xIDMwNC4yIGwtNy4xIC02LjcgMCAtNDguMiAwIC00OC4yIC01LjUgLTMuNSBjLTM2LjYgLTIzLjUgLTIzLjcgLTc5LjQgMTkuMSAtODIuNCA2LjUgLTAuNCAxNy40IDEuMiAxNy40IDIuNSAwIDAuMyAtMS41IDMuNiAtMy4yIDcuNCAtMi40IDUgLTMuNyA2LjYgLTQuOCA2LjIgLTAuOCAtMC40IC0zLjYgLTAuOCAtNi4zIC0xLjEgLTQuMyAtMC40IC01IC0wLjEgLTguMiAzLjEgLTIuOSAyLjkgLTMuNSA0LjIgLTMuNSA3LjkgMCAyLjQgMC43IDUuNCAxLjYgNi42IDIgMi45IDYuNiA1LjIgMTAuNCA1LjIgMi42IDAgMyAwLjMgMyAyLjggMCA0LjcgNCAxNy4zIDcuNiAyNC4yIDEuOSAzLjYgNS40IDguOSA3LjkgMTEuNyBsNC42IDUuMiAtMy4xIDEuNiBjLTMuMyAxLjcgLTMuNCAyLjQgLTMgMjQuMSBsMC4yIDkuMSAtNS4xIDUuOCBjLTIuOCAzLjIgLTUuMSA2LjEgLTUuMSA2LjQgMCAwLjQgMi4zIDMuMSA1IDYuMSAzIDMuMyA1IDYuNCA1IDcuOCAwIDEuMyAtMS45IDQuMyAtNC41IDcuMSAtMi41IDIuNiAtNC41IDUuNCAtNC41IDYuMSAwIDAuNyAyIDMuNSA0LjUgNi4xIDQuNCA0LjcgNC41IDQuOSA0LjUgMTEuNiBsMCA2LjcgLTcuOSA3LjggYy00LjUgNC40IC04LjggNy44IC05LjkgNy44IC0xLjEgMCAtNS4yIC0zIC05LjEgLTYuOHpcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk0yNTQuMyAzMDMuOCBsLTcuMyAtNy4xIDAgLTQ3LjkgMCAtNDcuOSAtMy41IC0yIGMtMS45IC0xLjIgLTMuNSAtMi4yIC0zLjUgLTIuMyAwIC0wLjEgMi4xIC0yLjQgNC44IC01LjIgOC4yIC04LjYgMTQuMSAtMjIuOCAxNC4yIC0zNC4xIGwwIC00LjMgNC42IDAgYzMuOSAwIDUuMSAtMC41IDggLTMuNCAyLjggLTIuOCAzLjQgLTQuMiAzLjQgLTcuNiAwIC05LjYgLTguMSAtMTQuNiAtMTcuMSAtMTAuNiAtMS4zIDAuNiAtMi41IC0wLjcgLTUuMyAtNiAtMy45IC03LjQgLTMuOCAtNy42IDIuNCAtOS40IDcuNCAtMi4xIDIwIC0wLjUgMjguOCAzLjcgMTAuNCA0LjkgMjAuNyAxOS40IDIzLjIgMzIuNSAxLjUgNy41IDAuMyAxNy43IC0zIDI1LjMgLTIuNyA2LjQgLTEwLjUgMTUuMSAtMTcgMTkuMSBsLTYgMy43IDAgMTYuMSAwIDE2LjIgLTUuNSA1LjQgLTUuNSA1LjQgNS41IDUuNiBjNyA3LjEgNy4yIDkuMyAxIDE1LjkgLTIuNSAyLjYgLTQuNSA1LjUgLTQuNSA2LjIgMCAwLjggMiAzLjUgNC41IDUuOSA0LjUgNC40IDQuNSA0LjQgNC41IDExLjUgbDAgNy4yIC03LjkgNy42IGMtNC4zIDQuMiAtOC43IDcuNyAtOS43IDcuNyAtMS4xIDAgLTUuMiAtMy4yIC05LjEgLTcuMnpcIi8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYnJhbmQtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAge3sgY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWUgfX08c3BhbiBjbGFzcz1cInRleHQtYnJhbmQtYWNjZW50XCI+e3sgY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZFN1ZmZpeCB8fCAnJyB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICBAaWYgKCFjb25maWdTZXJ2aWNlLmNvbmZpZygpLmhpZGVOZXR3b3JrQmFkZ2VzKSB7XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpZGRlbiBtZDpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYnJhbmQtdGV4dC1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+U3RhdGVsZXNzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+Tm9uLUN1c3RvZGlhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlJlYWwtdGltZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uYXY+XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIEBpZiAoaXNFbWJlZGRlZCAmJiAhaGlkZUhlYWRlcikge1xyXG4gICAgICAgIDxuYXYgY2xhc3M9XCJ3LWZ1bGwgYm9yZGVyLWIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyLzYwIGJhY2tkcm9wLWJsdXItbWQgZml4ZWQgdG9wLTAgei01MCBiZy1icmFuZC1iZy84MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm1heC13LTZ4bCBteC1hdXRvIHB4LTYgaC0xNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBjdXJzb3ItcG9pbnRlciBob3ZlcjpvcGFjaXR5LTgwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxyXG4gICAgICAgICAgICAgIDxpbWcgW3NyY109XCJjb25maWdTZXJ2aWNlLmNvbmZpZygpLmxvZ29VcmxcIiBbYWx0XT1cImNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuYnJhbmROYW1lXCIgY2xhc3M9XCJ3LTcgaC03IG9iamVjdC1jb250YWluXCIgLz5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtYnJhbmQtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICB7eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kTmFtZSB9fTxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnRcIj57eyBjb25maWdTZXJ2aWNlLmNvbmZpZygpLmJyYW5kU3VmZml4IHx8ICcnIH19PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICBAaWYgKCFjb25maWdTZXJ2aWNlLmNvbmZpZygpLmhpZGVOZXR3b3JrQmFkZ2VzKSB7XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpZGRlbiBtZDpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYnJhbmQtdGV4dC1tdXRlZFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+U3RhdGVsZXNzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4+Tm9uLUN1c3RvZGlhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuPlJlYWwtdGltZTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uYXY+XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4LWdyb3dcIiBbbmdDbGFzc109XCJ7ICdwdC0yMCc6ICFpc0VtYmVkZGVkIHx8IChpc0VtYmVkZGVkICYmICFoaWRlSGVhZGVyKSB9XCI+XHJcbiAgICAgICAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIEBpZiAoIWlzRW1iZWRkZWQgJiYgIWNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuaGlkZUZvb3Rlcikge1xyXG4gICAgICAgIDxmb290ZXIgY2xhc3M9XCJib3JkZXItdCBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgYmctYnJhbmQtYmcgcHktMTIgbXQtYXV0byByZWxhdGl2ZSB6LTIwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibWF4LXctNXhsIG14LWF1dG8gcHgtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWQ6aXRlbXMtY2VudGVyIGdhcC04IG1iLTEwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtY2VudGVyIG1kOnRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQgdGV4dC1sZyBtYi0xIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt7IGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuYnJhbmROYW1lIH19PHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLWFjY2VudFwiPnt7IGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkuYnJhbmRTdWZmaXggfHwgJycgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIEBpZiAoY29uZmlnU2VydmljZS5jb25maWcoKS53aGl0ZWxhYmVsICYmIGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkudXNlVHJhZGVNYXJrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgJm5ic3A7PHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLWFjY2VudFwiPlNpZ25pbmcgUm9vbcKuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgMTAwJSBGcmVlICZidWxsOyBaZXJvIEtub3dsZWRnZSAmYnVsbDsgQml0Y29pbiBPbmx5XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPCEtLSBUaGUgRG9uYXRlIEJ1dHRvbiAtLT5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25jbGljaz1cImRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkb25hdGUtbW9kYWwnKS5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xLjUgcm91bmRlZC1mdWxsIGJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBob3Zlcjpib3JkZXIteWVsbG93LTUwMC81MCBob3ZlcjpiZy15ZWxsb3ctNTAwLzEwIHRyYW5zaXRpb24gZ3JvdXAgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC15ZWxsb3ctNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWmFwIGNsYXNzPVwidy0zLjUgaC0zLjUgdGV4dC15ZWxsb3ctNTAwIGdyb3VwLWhvdmVyOmZpbGwteWVsbG93LTUwMCB0cmFuc2l0aW9uXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuPkRvbmF0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgIDwhLS0gVGhlIE1vZGFsIC8gUG9wb3ZlciBPdmVybGF5IC0tPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBpZD1cImRvbmF0ZS1tb2RhbFwiIGNsYXNzPVwiaGlkZGVuIGZpeGVkIGluc2V0LTAgYmctYmxhY2svNjAgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcC02IHJvdW5kZWQtMnhsIG1heC13LXNtIHctZnVsbCBteC00IHNoYWRvdy0yeGwgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8IS0tIENsb3NlIEJ1dHRvbiAtLT5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgb25jbGljaz1cImRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkb25hdGUtbW9kYWwnKS5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4pyVXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgbWItMlwiPlN1cHBvcnQge3sgY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWUgfX08L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtYi02XCI+U2NhbiB3aXRoIGFueSBMaWdodG5pbmcgd2FsbGV0PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICA8IS0tIFFSIENvZGUgSW1hZ2UgLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctd2hpdGUgcC0yIHJvdW5kZWQteGwgaW5saW5lLWJsb2NrIG1iLTYgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPVwiL2Fzc2V0cy9hZGRyZXNzLnBuZ1wiIGFsdD1cIkxpZ2h0bmluZyBRUiBDb2RlXCIgY2xhc3M9XCJ3LTQ4IGgtNDggb2JqZWN0LWNvbnRhaW5cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPCEtLSBMaWdodG5pbmcgQWRkcmVzcyAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLTEgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+TGlnaHRuaW5nIEFkZHJlc3M8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtYmcgdGV4dC1icmFuZC10ZXh0IHB4LTMgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tb25vIHNlbGVjdC1hbGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFuY2FybGluQHdhbGxldG9mc2F0b3NoaS5jb21cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8IS0tIExOVVJMIEZhbGxiYWNrIC0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgbWItMSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5MTlVSTDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1iZyB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgcHgtMyBweS0yIHJvdW5kZWQtbGcgdGV4dC1bMTBweF0gZm9udC1tb25vIGJyZWFrLWFsbCBzZWxlY3QtYWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbG51cmwxZHA2OGd1cm44Z2hqN2FtcGQza3gyYXIwdmVla3phcjB3ZDV4anRucmRha2o3dG5odjRreGN0dHRkZWhod20zMGQzaDgydW52d3FoaHhldHBkZTNrenVudmQ5aHFtemc3enBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9XCJtYWlsdG86c3VwcG9ydEBzaWduaW5ncm9vbS5pb1wiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZU1haWwgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS9zY2FybGluOTAvU2lnbmluZ1Jvb21cIlxyXG4gICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjI0XCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2Utd2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2UtbGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ3LTUgaC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTUgMjJ2LTRhNC44IDQuOCAwIDAgMC0xLTMuNWMzIDAgNi0yIDYtNS41LjA4LTEuMjUtLjI3LTIuNDgtMS0zLjUuMjgtMS4xNS4yOC0yLjM1IDAtMy41IDAgMC0xIDAtMyAxLjUtMi42NC0uNS01LjM2LS41LTggMEM2IDIgNSAyIDUgMmMtLjMgMS4xNS0uMyAyLjM1IDAgMy41QTUuNDAzIDUuNDAzIDAgMCAwIDQgOWMwIDMuNSAzIDUuNSA2IDUuNS0uMzkuNDktLjY4IDEuMDUtLjg1IDEuNjUtLjE3LjYtLjIyIDEuMjMtLjE1IDEuODV2NFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD1cIk05IDE4Yy00LjUxIDItNS0yLTctMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG5cclxuICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3guY29tL1NpZ25pbmdSb29tXCJcclxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD1cIjI0XCJcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlLXdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidy01IGgtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTIyIDRzLS43IDIuMS0yIDMuNGMxLjYgMTAtOS40IDE3LjMtMTggMTEuNiAyLjIuMSA0LjQtLjYgNi0yQzMgMTUuNS41IDkuNiAzIDVjMi4yIDIuNiA1LjYgNC4xIDkgNC0uOS00LjIgNC02LjYgNy0zLjggMS4xIDAgMy0xLjIgMy0xLjJ6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL0BTaWduaW5nUm9vbVwiXHJcbiAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZS13aWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctNSBoLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgZD1cIk0yLjUgMTdhMjQuMTIgMjQuMTIgMCAwIDEgMC0xMCAyIDIgMCAwIDEgMS40LTEuNCA0OS41NiA0OS41NiAwIDAgMSAxNi4yIDBBMiAyIDAgMCAxIDIxLjUgN2EyNC4xMiAyNC4xMiAwIDAgMSAwIDEwIDIgMiAwIDAgMS0xLjQgMS40IDQ5LjU1IDQ5LjU1IDAgMCAxLTE2LjIgMEEyIDIgMCAwIDEgMi41IDE3XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPVwibTEwIDE1IDUtMy01LTN6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcblxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgaHJlZj1cImh0dHBzOi8vbmp1bXAubWUvbnB1YjFhNnRrNmtjczJwNDBldW1ldTJtcnU0andxc3NuaHZjOHh0dXB3bHBjNmwzZ3ltamhhMDNzZWs0MzZhXCJcclxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJOb3N0clwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUdsb2JlIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3JkZXItdCBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcHQtOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkLzMwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIvNTAgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgbGVhZGluZy1yZWxheGVkIHRleHQtanVzdGlmeSBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5ESVNDTEFJTUVSIE9GIFdBUlJBTlRZOjwvc3Ryb25nPiBUaGlzIGlzIGZyZWUsIG9wZW4tc291cmNlIHNvZnR3YXJlXHJcbiAgICAgICAgICAgICAgICAgIHJlbGVhc2VkIHVuZGVyIHRoZVxyXG4gICAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3d3dy5nbnUub3JnL2xpY2Vuc2VzL2FncGwtMy4wLmh0bWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ1bmRlcmxpbmUgaG92ZXI6dGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPkFHUEx2MyBMaWNlbnNlPC9hXHJcbiAgICAgICAgICAgICAgICAgID4uIEl0IGlzIHByb3ZpZGVkIFwiYXMgaXNcIiwgd2l0aG91dCB3YXJyYW50eSBvZiBhbnkga2luZC4gPGJyIC8+PGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Tk9OLUNVU1RPRElBTDo8L3N0cm9uZz4ge3sgY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWUgfX0gaXMgYSBzdGF0ZWxlc3MgY29vcmRpbmF0aW9uIHRvb2wsXHJcbiAgICAgICAgICAgICAgICAgIG5vdCBhIHdhbGxldCBvciBmaW5hbmNpYWwgaW5zdGl0dXRpb24uIFdlIGRvIG5vdCBoYXZlIGFjY2VzcyB0byB5b3VyIHByaXZhdGUga2V5cyxcclxuICAgICAgICAgICAgICAgICAgZnVuZHMsIG9yIHVuZW5jcnlwdGVkIHRyYW5zYWN0aW9uIGRhdGEuIFdlIGRvIG5vdCBtYWludGFpbiB1c2VyIGFjY291bnRzIG9yXHJcbiAgICAgICAgICAgICAgICAgIGhpc3RvcmljYWwgbG9ncy4gPGJyIC8+PGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VVNFUiBSRVNQT05TSUJJTElUWTo8L3N0cm9uZz4gWW91IGFyZSBzb2xlbHkgcmVzcG9uc2libGUgZm9yIHZlcmlmeWluZ1xyXG4gICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbiBkZXRhaWxzIChhZGRyZXNzZXMsIGFtb3VudHMsIGZlZXMpIG9uIHlvdXIgaGFyZHdhcmUgZGV2aWNlIHNjcmVlblxyXG4gICAgICAgICAgICAgICAgICBiZWZvcmUgc2lnbmluZy4gVGhlIGRldmVsb3BlcnMgYXNzdW1lIG5vIGxpYWJpbGl0eSBmb3IgbG9zdCBmdW5kcyBvciBzb2Z0d2FyZVxyXG4gICAgICAgICAgICAgICAgICBlcnJvcnMuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtd3JhcCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgJmNvcHk7IHt7IGN1cnJlbnRZZWFyIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID48YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3N0YXRlbGVzc3Jlc2VhcmNoLmNvbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImhvdmVyOnRleHQtYnJhbmQtYWNjZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5TdGF0ZWxlc3MgUmVzZWFyY2ggTHRkPC9hXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L3N0cm9uZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkudXNlVHJhZGVNYXJrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImhpZGRlbiBzbTppbmxpbmVcIj4mYnVsbDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cD5TaWduaW5nIFJvb23CriBpcyBhIHJlZ2lzdGVyZWQgdHJhZGVtYXJrIG9mIFN0YXRlbGVzcyBSZXNlYXJjaCBMdGQuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImhpZGRlbiBzbTppbmxpbmVcIj4mYnVsbDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+TWFkZSBmb3IgQml0Y29pbmVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImhpZGRlbiBzbTppbmxpbmVcIj4mYnVsbDs8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+Tm8gVHJhY2tpbmcgLyBObyBDb29raWVzPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LVsxMHB4XSBvcGFjaXR5LTYwXCI+UmVnaXN0ZXJlZCBpbiBFbmdsYW5kICYgV2FsZXMgKE5vLiAxNjk5MDUxNSk8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgb3BhY2l0eS03MCBob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9zZWN1cml0eS50eHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtYWNjZW50IHRyYW5zaXRpb24gZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZCBjbGFzcz1cInctMyBoLTMgZ3JvdXAtaG92ZXI6dGV4dC1icmFuZC1hY2NlbnQgdHJhbnNpdGlvblwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIFdhcnJhbnQgQ2FuYXJ5XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LVsxMHB4XVwiPiZidWxsOzwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9wZ3Ata2V5LmFzY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC1hY2NlbnQgdHJhbnNpdGlvbiBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlS2V5IGNsYXNzPVwidy0zIGgtMyBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgUEdQIEtleVxyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Zvb3Rlcj5cclxuICAgICAgfVxyXG5cclxuICAgICAgQGlmIChpc0VtYmVkZGVkICYmICFjb25maWdTZXJ2aWNlLmNvbmZpZygpLmhpZGVGb290ZXIpIHtcclxuICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIHB5LTMgZmxleCBqdXN0aWZ5LWNlbnRlciBtdC1hdXRvIHBiLTRcIj5cclxuICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgIGhyZWY9XCJodHRwczovL3NpZ25pbmdyb29tLmlvP3V0bV9zb3VyY2U9d2lkZ2V0JnV0bV9tZWRpdW09ZW1iZWRcIlxyXG4gICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uLWNvbG9ycyBvcGFjaXR5LTgwIGhvdmVyOm9wYWNpdHktMTAwXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy0zLjUgaC0zLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgUG93ZXJlZCBieSBTaWduaW5nIFJvb21cclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgfVxyXG4gIGAsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcHAgaW1wbGVtZW50cyBPbkluaXQge1xyXG4gIGlzRW1iZWRkZWQgPSBmYWxzZTtcclxuICBoaWRlSGVhZGVyID0gZmFsc2U7XHJcblxyXG4gIHJlYWRvbmx5IGN1cnJlbnRZZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpO1xyXG5cclxuICBwcml2YXRlIHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG4gIHB1YmxpYyByZWFkb25seSBjb25maWdTZXJ2aWNlID0gaW5qZWN0KENvbmZpZ1NlcnZpY2UpO1xyXG4gIHByaXZhdGUgdGl0bGVTZXJ2aWNlID0gaW5qZWN0KFRpdGxlKTtcclxuICBwcml2YXRlIG1ldGFTZXJ2aWNlID0gaW5qZWN0KE1ldGEpO1xyXG4gIHByaXZhdGUgZG9jdW1lbnQgPSBpbmplY3QoRE9DVU1FTlQpO1xyXG4gIHByaXZhdGUgcmVuZGVyZXIgPSBpbmplY3QoUmVuZGVyZXIyKTtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLnJvdXRlci5ldmVudHMucGlwZShmaWx0ZXIoKGV2ZW50KSA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgMCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKSB7XHJcbiAgICB0aGlzLmFwcGx5QnJhbmRNZXRhZGF0YSgpO1xyXG5cclxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICB0aGlzLmlzRW1iZWRkZWQgPSB3aW5kb3cgIT09IHdpbmRvdy5wYXJlbnQgfHwgd2luZG93ICE9PSB3aW5kb3cudG9wO1xyXG5cclxuICAgICAgY29uc3QgdXJsUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyh3aW5kb3cubG9jYXRpb24uc2VhcmNoKTtcclxuICAgICAgdGhpcy5oaWRlSGVhZGVyID0gdXJsUGFyYW1zLmdldCgnaGlkZUhlYWRlcicpID09PSAndHJ1ZSc7XHJcblxyXG4gICAgICBpZiAoIXdpbmRvdy5pc1NlY3VyZUNvbnRleHQpIHtcclxuICAgICAgICBkb2N1bWVudC5ib2R5LmlubmVySFRNTCA9IGBcclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJiYWNrZ3JvdW5kOiMwMjA2MTc7IGNvbG9yOiNmNDNmNWU7IGhlaWdodDoxMDB2aDsgZGlzcGxheTpmbGV4OyBmbGV4LWRpcmVjdGlvbjpjb2x1bW47IGl0ZW1zLWNlbnRlcjsganVzdGlmeS1jb250ZW50OmNlbnRlcjsgZm9udC1mYW1pbHk6c2Fucy1zZXJpZjsgdGV4dC1hbGlnbjpjZW50ZXI7IHBhZGRpbmc6MjBweDtcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDEgc3R5bGU9XCJtYXJnaW4tYm90dG9tOjEwcHg7XCI+U2VjdXJpdHkgRXJyb3I8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwPlNpZ25pbmdSb29tIHJlcXVpcmVzIGEgU2VjdXJlIENvbnRleHQgKEhUVFBTKS48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9XCJjb2xvcjojOTRhM2I4OyBmb250LXNpemU6MTRweDtcIj5UaGUgV2ViIENyeXB0b2dyYXBoeSBBUEkgaXMgZGlzYWJsZWQgaW4gaW5zZWN1cmUgZW52aXJvbm1lbnRzLjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICBgO1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignSW5zZWN1cmUgQ29udGV4dCAtIENyeXB0byBBUEkgZGlzYWJsZWQnKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhcHBseUJyYW5kTWV0YWRhdGEoKSB7XHJcbiAgICBjb25zdCBjb25maWcgPSB0aGlzLmNvbmZpZ1NlcnZpY2UuY29uZmlnKCk7XHJcbiAgICBjb25zdCBicmFuZEZ1bGxOYW1lID0gY29uZmlnLmJyYW5kTmFtZSArIChjb25maWcuYnJhbmRTdWZmaXggPyBjb25maWcuYnJhbmRTdWZmaXggOiAnJyk7XHJcblxyXG4gICAgY29uc3QgcGFnZVRpdGxlID0gYCR7YnJhbmRGdWxsTmFtZX0gfCAke2NvbmZpZy50YWdsaW5lIHx8ICdSZWFsLVRpbWUgTXVsdGlzaWcgQ29vcmRpbmF0b3InfWA7XHJcbiAgICBjb25zdCBwYWdlRGVzYyA9XHJcbiAgICAgIGNvbmZpZy5zdWJUYWdsaW5lIHx8ICdUaGUgc3RhdGVsZXNzLCB6ZXJvLWtub3dsZWRnZSBCaXRjb2luIG11bHRpc2lnIGNvb3JkaW5hdG9yLic7XHJcblxyXG4gICAgdGhpcy50aXRsZVNlcnZpY2Uuc2V0VGl0bGUocGFnZVRpdGxlKTtcclxuICAgIHRoaXMubWV0YVNlcnZpY2UudXBkYXRlVGFnKHsgbmFtZTogJ2Rlc2NyaXB0aW9uJywgY29udGVudDogcGFnZURlc2MgfSk7XHJcblxyXG4gICAgaWYgKGNvbmZpZy5icmFuZENvbG9ySGV4KSB7XHJcbiAgICAgIHRoaXMubWV0YVNlcnZpY2UudXBkYXRlVGFnKHsgbmFtZTogJ3RoZW1lLWNvbG9yJywgY29udGVudDogY29uZmlnLmJyYW5kQ29sb3JIZXggfSk7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5tZXRhU2VydmljZS51cGRhdGVUYWcoeyBwcm9wZXJ0eTogJ29nOnRpdGxlJywgY29udGVudDogcGFnZVRpdGxlIH0pO1xyXG4gICAgdGhpcy5tZXRhU2VydmljZS51cGRhdGVUYWcoeyBwcm9wZXJ0eTogJ29nOmRlc2NyaXB0aW9uJywgY29udGVudDogcGFnZURlc2MgfSk7XHJcbiAgICB0aGlzLm1ldGFTZXJ2aWNlLnVwZGF0ZVRhZyh7IHByb3BlcnR5OiAnb2c6c2l0ZV9uYW1lJywgY29udGVudDogYnJhbmRGdWxsTmFtZSB9KTtcclxuXHJcbiAgICB0aGlzLm1ldGFTZXJ2aWNlLnVwZGF0ZVRhZyh7IG5hbWU6ICd0d2l0dGVyOnRpdGxlJywgY29udGVudDogcGFnZVRpdGxlIH0pO1xyXG4gICAgdGhpcy5tZXRhU2VydmljZS51cGRhdGVUYWcoeyBuYW1lOiAndHdpdHRlcjpkZXNjcmlwdGlvbicsIGNvbnRlbnQ6IHBhZ2VEZXNjIH0pO1xyXG5cclxuICAgIC8vIEluamVjdCBEeW5hbWljIEpTT04tTEQgU3RydWN0dXJlZCBEYXRhIFNhZmVseVxyXG4gICAgY29uc3Qgc2NoZW1hID0ge1xyXG4gICAgICAnQGNvbnRleHQnOiAnaHR0cHM6Ly9zY2hlbWEub3JnJyxcclxuICAgICAgJ0B0eXBlJzogJ1NvZnR3YXJlQXBwbGljYXRpb24nLFxyXG4gICAgICBuYW1lOiBicmFuZEZ1bGxOYW1lLFxyXG4gICAgICBvcGVyYXRpbmdTeXN0ZW06ICdBbnknLFxyXG4gICAgICBhcHBsaWNhdGlvbkNhdGVnb3J5OiAnRmluYW5jZUFwcGxpY2F0aW9uJyxcclxuICAgICAgZGVzY3JpcHRpb246IHBhZ2VEZXNjLFxyXG4gICAgICBmZWF0dXJlTGlzdDogW1xyXG4gICAgICAgICdSZWFsLXRpbWUgUFNCVCBNZXJnaW5nJyxcclxuICAgICAgICAnWmVyby1Lbm93bGVkZ2UgRW5jcnlwdGlvbicsXHJcbiAgICAgICAgJ1N0YXRlbGVzcyBBcmNoaXRlY3R1cmUnLFxyXG4gICAgICAgICdDcnlwdG9ncmFwaGljIEF1ZGl0IExvZ3MnLFxyXG4gICAgICAgICdIYXJkd2FyZSBXYWxsZXQgQ29tcGF0aWJpbGl0eScsXHJcbiAgICAgIF0sXHJcbiAgICAgIHVybDogdGhpcy5kb2N1bWVudC5kZWZhdWx0Vmlldz8ubG9jYXRpb24uaHJlZiB8fCAnJyxcclxuICAgICAgYXV0aG9yOiB7XHJcbiAgICAgICAgJ0B0eXBlJzogJ09yZ2FuaXphdGlvbicsXHJcbiAgICAgICAgbmFtZTogY29uZmlnLnVzZVRyYWRlTWFyayA/ICdTdGF0ZWxlc3MgUmVzZWFyY2ggTHRkJyA6IGJyYW5kRnVsbE5hbWUsXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHNjcmlwdCA9IHRoaXMucmVuZGVyZXIuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XHJcbiAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShzY3JpcHQsICd0eXBlJywgJ2FwcGxpY2F0aW9uL2xkK2pzb24nKTtcclxuICAgIHRoaXMucmVuZGVyZXIuc2V0UHJvcGVydHkoc2NyaXB0LCAndGV4dCcsIEpTT04uc3RyaW5naWZ5KHNjaGVtYSkpO1xyXG5cclxuICAgIHRoaXMucmVuZGVyZXIuYXBwZW5kQ2hpbGQodGhpcy5kb2N1bWVudC5oZWFkLCBzY3JpcHQpO1xyXG4gIH1cclxufVxyXG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQSxTQUFTLDRCQUE0Qjs7O0FDQXJDO0FBQUEsRUFDRTtBQUFBLEVBQ0EsVUFBQUE7QUFBQSxFQUVBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUNLO0FBQ1AsU0FBUyxxQkFBcUI7OztBQ0g5QixTQUFTLGlCQUF5QjtBQUNsQyxTQUFTLG9CQUFvQjtBQUM3QixTQUNFLFdBQ0EsYUFDQSxnQkFDQSxvQkFDQSxZQUNBLGFBQ0Esa0JBQ0EsYUFDQSxlQUNBLG9CQUNBLHFCQUNBLGVBQ0EsZUFDQSxXQUNBLG1CQUNBLGdCQUNBLGFBQ0EsY0FDQSxtQkFDQSxnQkFDQSxpQkFDQSwwQkFDSzs7O0FBMmdCRCxJQUFPLGdCQUFQLE1BQU8sZUFBK0I7RUFDMUMsV0FBUTtFQUFJO0VBRVosaUJBQWlCLFNBQW9CO0FBQ25DLFFBQUksQ0FBQyxTQUFTLG1CQUFtQjtBQUMvQixjQUFRLGtCQUFpQixFQUFHLE1BQU0sQ0FBQyxRQUFPO0FBQ3hDLGdCQUFRLE1BQU0sOEJBQThCLElBQUksT0FBTyxFQUFFO01BQzNELENBQUM7SUFDSCxPQUFPO0FBQ0wsZUFBUyxlQUFjO0lBQ3pCO0VBQ0Y7O3FDQVhXLGdCQUFhO0VBQUE7NEVBQWIsZ0JBQWEsV0FBQSxDQUFBLENBQUEsVUFBQSxDQUFBLEdBQUEsT0FBQSxLQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxpQkFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsV0FBQSxlQUFBLFNBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxZQUFBLG9CQUFBLGFBQUEsYUFBQSxxQkFBQSxnQkFBQSxnQkFBQSxxQkFBQSxHQUFBLENBQUEsUUFBQSw0Q0FBQSxVQUFBLFVBQUEsR0FBQSxlQUFBLGdCQUFBLFNBQUEsUUFBQSxRQUFBLGdCQUFBLG1CQUFBLG9CQUFBLFVBQUEsb0JBQUEsa0JBQUEsb0JBQUEsMEJBQUEsY0FBQSxRQUFBLGtCQUFBLFNBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxhQUFBLEdBQUEsQ0FBQSxzQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLCtCQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZUFBQSxrQkFBQSxrQkFBQSxjQUFBLFFBQUEsaUJBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLGdCQUFBLG9CQUFBLG9CQUFBLGVBQUEsWUFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsY0FBQSxrQkFBQSxTQUFBLGFBQUEsV0FBQSxtQkFBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLGVBQUEsZ0JBQUEsa0JBQUEsU0FBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLGNBQUEsV0FBQSxHQUFBLFFBQUEsUUFBQSxjQUFBLGtCQUFBLHdCQUFBLGtCQUFBLGFBQUEsa0JBQUEsUUFBQSxnQkFBQSxTQUFBLDBDQUFBLGtCQUFBLFVBQUEsYUFBQSxrQkFBQSxtQkFBQSxhQUFBLGNBQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxnQkFBQSxHQUFBLENBQUEsUUFBQSxvQ0FBQSxVQUFBLFVBQUEsR0FBQSxRQUFBLFFBQUEsY0FBQSxtQkFBQSxzQkFBQSxrQkFBQSxlQUFBLGtCQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLG9CQUFBLDBCQUFBLFVBQUEsYUFBQSxnQkFBQSxHQUFBLENBQUEsa0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSwrREFBQSxVQUFBLFVBQUEsR0FBQSxRQUFBLFFBQUEsY0FBQSxtQkFBQSxzQkFBQSxjQUFBLGVBQUEsa0JBQUEsUUFBQSxnQkFBQSxTQUFBLFVBQUEsb0JBQUEsMEJBQUEsVUFBQSxhQUFBLGdCQUFBLEdBQUEsQ0FBQSxTQUFBLDhCQUFBLFNBQUEsTUFBQSxVQUFBLE1BQUEsV0FBQSxhQUFBLFFBQUEsUUFBQSxVQUFBLGdCQUFBLGdCQUFBLEtBQUEsa0JBQUEsU0FBQSxtQkFBQSxTQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxLQUFBLDBQQUFBLEdBQUEsQ0FBQSxLQUFBLHVCQUFBLEdBQUEsQ0FBQSxRQUFBLDRDQUFBLFVBQUEsVUFBQSxPQUFBLGdDQUFBLEdBQUEsUUFBQSxRQUFBLGNBQUEsbUJBQUEsc0JBQUEsY0FBQSxlQUFBLGtCQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLG9CQUFBLDBCQUFBLFVBQUEsYUFBQSxnQkFBQSxHQUFBLENBQUEsa0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLFdBQUEsU0FBQSxRQUFBLFlBQUEsUUFBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLG1CQUFBLFVBQUEsb0JBQUEsY0FBQSx5QkFBQSxtQkFBQSxvQkFBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLG9CQUFBLHFCQUFBLG1CQUFBLGtCQUFBLHVCQUFBLE1BQUEsR0FBQSxDQUFBLE9BQUEsNEJBQUEsT0FBQSxtQ0FBQSxHQUFBLFVBQUEsVUFBQSxnQkFBQSxjQUFBLDJCQUFBLGNBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsV0FBQSxRQUFBLE9BQUEsY0FBQSxtQkFBQSx3QkFBQSx3QkFBQSxVQUFBLG9CQUFBLDRCQUFBLGtCQUFBLGtCQUFBLGFBQUEsMkJBQUEsYUFBQSxpQkFBQSw2QkFBQSxnQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGtCQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxZQUFBLFVBQUEsUUFBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLGdCQUFBLGVBQUEsb0JBQUEsVUFBQSxvQkFBQSxXQUFBLGNBQUEsYUFBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxPQUFBLGdCQUFBLGNBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsZ0JBQUEscUJBQUEsb0JBQUEsVUFBQSx5QkFBQSxXQUFBLG9CQUFBLGFBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLFdBQUEsU0FBQSxRQUFBLFlBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxhQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGtCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLG1CQUFBLFVBQUEscUJBQUEsWUFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsVUFBQSxVQUFBLE9BQUEsb0JBQUEsa0JBQUEsa0JBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGFBQUEsa0JBQUEsUUFBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLHVCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxTQUFBLFdBQUEsZ0JBQUEsR0FBQSxDQUFBLGlCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsZ0JBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEscUJBQUEsVUFBQSx5QkFBQSxZQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLFVBQUEsT0FBQSxvQkFBQSxzQkFBQSxzQkFBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGFBQUEsY0FBQSxRQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxTQUFBLFdBQUEsZ0JBQUEsR0FBQSxDQUFBLHNCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsb0JBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFlBQUEsdUJBQUEsbUJBQUEsb0JBQUEsU0FBQSxZQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxZQUFBLG9CQUFBLG9CQUFBLGFBQUEsYUFBQSxvQkFBQSxnQkFBQSxnQkFBQSxxQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLFdBQUEsUUFBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsYUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxlQUFBLGtCQUFBLGtCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxlQUFBLG1CQUFBLFVBQUEsb0JBQUEsK0JBQUEsY0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxjQUFBLHFCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsUUFBQSx5QkFBQSx3QkFBQSxjQUFBLEdBQUEsQ0FBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxhQUFBLG9CQUFBLFFBQUEsYUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxXQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsUUFBQSxTQUFBLFlBQUEsb0JBQUEsTUFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLEdBQUEsQ0FBQSxxQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxXQUFBLFNBQUEsUUFBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxZQUFBLG9CQUFBLHVCQUFBLGtCQUFBLGNBQUEsV0FBQSxjQUFBLDBCQUFBLGNBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGNBQUEsbUJBQUEsb0JBQUEsVUFBQSxvQkFBQSxjQUFBLG1CQUFBLE9BQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFlBQUEsZUFBQSxnQkFBQSxtQkFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxnQkFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxnQkFBQSxnQkFBQSxRQUFBLGdCQUFBLGtCQUFBLFVBQUEsb0JBQUEsTUFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLGdCQUFBLFNBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZ0JBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEscUJBQUEsU0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxnQkFBQSxXQUFBLFVBQUEsb0JBQUEsZUFBQSxvQkFBQSxhQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsY0FBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxnQkFBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsVUFBQSxvQkFBQSxRQUFBLFVBQUEsR0FBQSxDQUFBLGlCQUFBLElBQUEsR0FBQSxRQUFBLFFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLFlBQUEsa0JBQUEsaUJBQUEsZUFBQSxRQUFBLFVBQUEsV0FBQSxVQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxTQUFBLFlBQUEscUJBQUEsU0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxnQkFBQSxXQUFBLFVBQUEsb0JBQUEsZUFBQSxpQkFBQSxhQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxXQUFBLFNBQUEsUUFBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsa0JBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxVQUFBLG9CQUFBLE9BQUEsZUFBQSx5QkFBQSxjQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLG9CQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxRQUFBLHlCQUFBLHNCQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxhQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGtCQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxrQkFBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsUUFBQSx5QkFBQSxzQkFBQSxHQUFBLENBQUEsdUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLFVBQUEseUJBQUEsT0FBQSxlQUFBLDJCQUFBLGNBQUEsU0FBQSxZQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxXQUFBLFFBQUEsUUFBQSxxQkFBQSxXQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLHFCQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxRQUFBLHlCQUFBLHNCQUFBLEdBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxrQkFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGVBQUEscUJBQUEsa0JBQUEsZ0JBQUEsVUFBQSxvQkFBQSxRQUFBLFlBQUEsZUFBQSxnQkFBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSxjQUFBLFFBQUEsUUFBQSxnQkFBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxrQkFBQSxtQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsYUFBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLG1EQUFBLFVBQUEsVUFBQSxHQUFBLFFBQUEsVUFBQSxjQUFBLGtCQUFBLHdCQUFBLGtCQUFBLGFBQUEsV0FBQSxjQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsc0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsUUFBQSwrREFBQSxVQUFBLFVBQUEsR0FBQSxRQUFBLFVBQUEsY0FBQSxnQkFBQSxzQkFBQSxjQUFBLGVBQUEsV0FBQSxjQUFBLFVBQUEsb0JBQUEsUUFBQSxnQkFBQSxPQUFBLEdBQUEsQ0FBQSxrQkFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxRQUFBLGdDQUFBLFVBQUEsVUFBQSxHQUFBLFFBQUEsVUFBQSxjQUFBLGdCQUFBLHNCQUFBLGNBQUEsZUFBQSxXQUFBLGNBQUEsVUFBQSxvQkFBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLFNBQUEsOEJBQUEsU0FBQSxNQUFBLFVBQUEsTUFBQSxXQUFBLGFBQUEsUUFBQSxRQUFBLFVBQUEsZ0JBQUEsZ0JBQUEsS0FBQSxrQkFBQSxTQUFBLG1CQUFBLFNBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEtBQUEsK0tBQUEsR0FBQSxDQUFBLEtBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxZQUFBLFlBQUEsY0FBQSxPQUFBLGFBQUEsZUFBQSxvQkFBQSxVQUFBLG9CQUFBLGlCQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGVBQUEsR0FBQSxDQUFBLFFBQUEsMENBQUEsVUFBQSxVQUFBLEdBQUEsUUFBQSxVQUFBLGNBQUEsa0JBQUEsd0JBQUEsaUJBQUEsVUFBQSxzQkFBQSxlQUFBLFdBQUEsY0FBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLE9BQUEsMEJBQUEsT0FBQSxtQkFBQSxXQUFBLDZVQUFBLEdBQUEsT0FBQSxPQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLGlDQUFBLFVBQUEsVUFBQSxHQUFBLFFBQUEsVUFBQSxjQUFBLGdCQUFBLHNCQUFBLGNBQUEsZUFBQSxXQUFBLGNBQUEsVUFBQSxvQkFBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxZQUFBLFFBQUEsZ0JBQUEsR0FBQSxDQUFBLFFBQUEsMENBQUEsVUFBQSxVQUFBLEdBQUEsWUFBQSxRQUFBLFFBQUEsU0FBQSxTQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxrQkFBQSxnQkFBQSxZQUFBLGlCQUFBLDhCQUFBLGtCQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLFVBQUEsZ0JBQUEsVUFBQSxvQkFBQSxrQ0FBQSxjQUFBLFFBQUEsWUFBQSxnQkFBQSxrQkFBQSxPQUFBLGFBQUEsa0JBQUEsZ0JBQUEsYUFBQSw0QkFBQSxHQUFBLENBQUEsT0FBQSwwQkFBQSxPQUFBLG1CQUFBLFdBQUEsNlVBQUEsR0FBQSxRQUFBLFFBQUEsa0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLGNBQUEsV0FBQSxrQkFBQSxnQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsaUJBQUEsZUFBQSxtQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxrQkFBQSxTQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxjQUFBLG1CQUFBLFVBQUEsa0JBQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxrQkFBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxrQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSxnQkFBQSxHQUFBLENBQUEsY0FBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLFdBQUEsTUFBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxrQkFBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLHFCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsV0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsV0FBQSxTQUFBLFFBQUEsZUFBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsV0FBQSxpQkFBQSxhQUFBLG1CQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxhQUFBLGtCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLGNBQUEsZ0JBQUEsVUFBQSxvQkFBQSxrQkFBQSxXQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxXQUFBLFNBQUEsU0FBQSxRQUFBLFlBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGFBQUEsY0FBQSxRQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxtQkFBQSxjQUFBLFVBQUEsb0JBQUEsc0JBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLGNBQUEsUUFBQSxRQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLG9CQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsbUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxlQUFBLEdBQUEsQ0FBQSxRQUFBLGlDQUFBLFVBQUEsVUFBQSxHQUFBLG9CQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsb0JBQUEsbUJBQUEsU0FBQSxlQUFBLFFBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxjQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsUUFBQSxZQUFBLFNBQUEsR0FBQSxDQUFBLGNBQUEsV0FBQSxHQUFBLGVBQUEsUUFBQSxRQUFBLGNBQUEsa0JBQUEsd0JBQUEsa0JBQUEsYUFBQSxrQkFBQSxnQkFBQSxTQUFBLGFBQUEseUJBQUEsZ0JBQUEsR0FBQSxDQUFBLHNCQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx1QkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTs7QUE1ZXRCLE1BQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFFRyxNQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBO0FBRUEsTUFBQSw0QkFBQSxHQUFBLEtBQUEsQ0FBQTs7QUFDQyxNQUFBLHVCQUFBLEdBQUEsT0FBQSxDQUFBOztBQUNBLE1BQUEsNEJBQUEsR0FBQSxRQUFBLENBQUE7QUFBa0MsTUFBQSxvQkFBQSxHQUFBLDhDQUFBO0FBQTRDLE1BQUEsMEJBQUE7O0FBQzlFLE1BQUEsdUJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRixNQUFBLDBCQUFBOztBQUVBLE1BQUEsNEJBQUEsR0FBQSxNQUFBLENBQUE7QUFDRSxNQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBYyxNQUFBLHVCQUFBLEdBQUEsSUFBQTtBQUNkLE1BQUEsNEJBQUEsSUFBQSxRQUFBLENBQUE7QUFDRSxNQUFBLG9CQUFBLElBQUEsOENBQUE7QUFDRixNQUFBLDBCQUFBLEVBQU87QUFHVCxNQUFBLDRCQUFBLElBQUEsS0FBQSxDQUFBO0FBQ0UsTUFBQSxvQkFBQSxJQUFBLDBFQUFBO0FBQ0EsTUFBQSx1QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUNBLE1BQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBMkMsTUFBQSxvQkFBQSxJQUFBLGNBQUE7QUFBWSxNQUFBLDBCQUFBO0FBQ3ZELE1BQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBMkMsTUFBQSxvQkFBQSxJQUFBLGNBQUE7QUFBWSxNQUFBLDBCQUFBO0FBQ3ZELE1BQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBMkMsTUFBQSxvQkFBQSxJQUFBLHVCQUFBO0FBQXFCLE1BQUEsMEJBQUEsRUFBTztBQUd6RSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXVGLElBQUEsS0FBQSxFQUFBOztBQUVuRixNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0EsTUFBQSxvQkFBQSxJQUFBLGlCQUFBO0FBQ0YsTUFBQSwwQkFBQTs7QUFFQSxNQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBOztBQUNFLE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDQSxNQUFBLG9CQUFBLElBQUEsY0FBQTtBQUNGLE1BQUEsMEJBQUE7O0FBRUEsTUFBQSw0QkFBQSxJQUFBLEtBQUEsRUFBQTs7QUFDRSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQXFNLE1BQUEsdUJBQUEsSUFBQSxRQUFBLEVBQUEsRUFBb1EsSUFBQSxRQUFBLEVBQUE7QUFBaUMsTUFBQSwwQkFBQTtBQUMxZSxNQUFBLG9CQUFBLElBQUEsa0JBQUE7QUFDRixNQUFBLDBCQUFBOztBQUVBLE1BQUEsNEJBQUEsSUFBQSxLQUFBLEVBQUE7O0FBQ0UsTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNBLE1BQUEsb0JBQUEsSUFBQSxzQkFBQTtBQUNKLE1BQUEsMEJBQUEsRUFBSSxFQUNFOztBQUdSLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMkUsSUFBQSxPQUFBLElBQUEsQ0FBQTtBQUduRSxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBLEVBQStILElBQUEsT0FBQSxFQUFBO0FBSS9ILE1BQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBUSxNQUFBLHdCQUFBLFNBQUEsU0FBQSxrREFBQTtBQUFBLFFBQUEsMkJBQUEsR0FBQTtBQUFBLGNBQUEsbUJBQUEseUJBQUEsRUFBQTtBQUFBLGVBQUEseUJBQVMsSUFBQSxpQkFBQSxnQkFBQSxDQUErQjtNQUFBLENBQUE7O0FBQzVDLE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBOztBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBbUUsSUFBQSxPQUFBLEVBQUE7QUFFM0QsTUFBQSx1QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNBLE1BQUEsb0JBQUEsSUFBQSxnQkFBQTtBQUNKLE1BQUEsMEJBQUE7QUFDQSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksTUFBQSxvQkFBQSxJQUFBLG1CQUFBO0FBQ0osTUFBQSwwQkFBQSxFQUFNLEVBQ0osRUFDSjtBQUdWLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0QsSUFBQSxPQUFBLEVBQUEsRUFDckIsSUFBQSxNQUFBLEVBQUE7QUFDb0IsTUFBQSxvQkFBQSxJQUFBLDJCQUFBO0FBQXlCLE1BQUEsMEJBQUE7QUFDeEUsTUFBQSw0QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUEwQixNQUFBLG9CQUFBLElBQUEscUVBQUE7QUFBbUUsTUFBQSwwQkFBQSxFQUFJO0FBR3JHLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBdUMsSUFBQSxPQUFBLEVBQUE7QUFFL0IsTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNBLE1BQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7O0FBQ0ksTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNBLE1BQUEsb0JBQUEsSUFBQSw2QkFBQTtBQUNKLE1BQUEsMEJBQUE7O0FBQ0EsTUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQSxFQUFzQixJQUFBLE1BQUEsRUFBQTs7QUFFZCxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBOztBQUNBLE1BQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sTUFBQSxvQkFBQSxJQUFBLGlEQUFBO0FBQStDLE1BQUEsMEJBQUEsRUFBTztBQUVoRSxNQUFBLDRCQUFBLElBQUEsTUFBQSxFQUFBOztBQUNJLE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7O0FBQ0EsTUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxNQUFBLG9CQUFBLElBQUEsbURBQUE7QUFBaUQsTUFBQSwwQkFBQSxFQUFPO0FBRWxFLE1BQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7O0FBQ0ksTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTs7QUFDQSxNQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLE1BQUEsb0JBQUEsSUFBQSw0Q0FBQTtBQUEwQyxNQUFBLDBCQUFBLEVBQU8sRUFDdEQsRUFDSjtBQUdULE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0EsTUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTs7QUFDSSxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0EsTUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQ0osTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLElBQUEsTUFBQSxFQUFBLEVBQXNCLElBQUEsTUFBQSxFQUFBOztBQUVkLE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7O0FBQ0EsTUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxNQUFBLG9CQUFBLElBQUEsa0RBQUE7QUFBZ0QsTUFBQSwwQkFBQSxFQUFPO0FBRWpFLE1BQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7O0FBQ0ksTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTs7QUFDQSxNQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLE1BQUEsb0JBQUEsSUFBQSx1REFBQTtBQUFxRCxNQUFBLDBCQUFBLEVBQU87QUFFdEUsTUFBQSw0QkFBQSxJQUFBLE1BQUEsRUFBQTs7QUFDSSxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBOztBQUNBLE1BQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sTUFBQSxvQkFBQSxJQUFBLGtEQUFBO0FBQWdELE1BQUEsMEJBQUEsRUFBTyxFQUM1RCxFQUNKLEVBQ0gsRUFDSjtBQUdWLE1BQUEsNEJBQUEsSUFBQSxXQUFBLEVBQUE7QUFDRSxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFrRCxJQUFBLE9BQUEsRUFBQSxFQUNqQixJQUFBLE1BQUEsRUFBQTtBQUNrQixNQUFBLG9CQUFBLElBQUEsc0NBQUE7QUFBb0MsTUFBQSwwQkFBQTtBQUNuRixNQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxJQUFBLGtCQUFBO0FBQWUsTUFBQSw0QkFBQSxLQUFBLFFBQUEsRUFBQTtBQUEyQyxNQUFBLG9CQUFBLEtBQUEsdUNBQUE7QUFBcUMsTUFBQSwwQkFBQTtBQUMvRixNQUFBLG9CQUFBLEtBQUEsNkRBQUE7QUFDRixNQUFBLDBCQUFBLEVBQUk7QUFHTixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQWtFLEtBQUEsT0FBQSxFQUFBLEVBRWtELEtBQUEsT0FBQSxFQUFBOztBQUU5RyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0YsTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxZQUFBO0FBQVUsTUFBQSwwQkFBQTtBQUN4RCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQThFLE1BQUEsb0JBQUEsS0FBQSxTQUFBO0FBQU8sTUFBQSwwQkFBQTtBQUNyRixNQUFBLDRCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxLQUFBLDJFQUFBO0FBQ0EsTUFBQSx1QkFBQSxLQUFBLElBQUE7QUFBSyxNQUFBLDRCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQW1FLE1BQUEsb0JBQUEsS0FBQSwyQkFBQTtBQUF5QixNQUFBLDBCQUFBLEVBQU8sRUFDdEc7QUFHTixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQWtILEtBQUEsT0FBQSxFQUFBOztBQUU5RyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0YsTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxZQUFBO0FBQVUsTUFBQSwwQkFBQTtBQUN4RCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQThFLE1BQUEsb0JBQUEsS0FBQSxVQUFBO0FBQVEsTUFBQSwwQkFBQTtBQUN0RixNQUFBLDRCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxLQUFBLDZFQUFBO0FBQ0EsTUFBQSx1QkFBQSxLQUFBLElBQUE7QUFBSyxNQUFBLDRCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQW1FLE1BQUEsb0JBQUEsS0FBQSwrQkFBQTtBQUE2QixNQUFBLDBCQUFBLEVBQU8sRUFDMUc7QUFHTixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQWtILEtBQUEsT0FBQSxFQUFBOztBQUU5RyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0YsTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxZQUFBO0FBQVUsTUFBQSwwQkFBQTtBQUN4RCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQThFLE1BQUEsb0JBQUEsS0FBQSxVQUFBO0FBQVEsTUFBQSwwQkFBQTtBQUN0RixNQUFBLDRCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxLQUFBLDJEQUFBO0FBQ0EsTUFBQSx1QkFBQSxLQUFBLElBQUE7QUFBSyxNQUFBLDRCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQW1FLE1BQUEsb0JBQUEsS0FBQSxzQ0FBQTtBQUFvQyxNQUFBLDBCQUFBLEVBQU8sRUFDakg7QUFHTixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQWtILEtBQUEsT0FBQSxFQUFBOztBQUU5RyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0YsTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxZQUFBO0FBQVUsTUFBQSwwQkFBQTtBQUN4RCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQThFLE1BQUEsb0JBQUEsS0FBQSxZQUFBO0FBQVUsTUFBQSwwQkFBQTtBQUN4RixNQUFBLDRCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxLQUFBLHNFQUFBO0FBQ0EsTUFBQSx1QkFBQSxLQUFBLElBQUE7QUFBSyxNQUFBLDRCQUFBLEtBQUEsUUFBQSxFQUFBO0FBQW1FLE1BQUEsb0JBQUEsS0FBQSxnQ0FBQTtBQUE4QixNQUFBLDBCQUFBLEVBQU8sRUFDM0csRUFDQSxFQUVGLEVBQ0Y7QUFHUixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQXdELEtBQUEsT0FBQSxFQUFBLEVBRXJCLEtBQUEsTUFBQSxFQUFBO0FBQ29CLE1BQUEsb0JBQUEsS0FBQSxpQkFBQTtBQUFlLE1BQUEsMEJBQUE7QUFDOUQsTUFBQSw0QkFBQSxLQUFBLEtBQUEsRUFBQTtBQUEwQixNQUFBLG9CQUFBLEtBQUEsNERBQUE7QUFBMEQsTUFBQSwwQkFBQSxFQUFJO0FBRzVGLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUE7QUFDSSxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0EsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQSxFQUFpSSxLQUFBLE9BQUEsRUFBQSxFQUNuRCxLQUFBLE9BQUEsRUFBQSxFQUVsQixLQUFBLE9BQUEsRUFBQTs7QUFFNUMsTUFBQSx1QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUNKLE1BQUEsMEJBQUE7O0FBQ0EsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUEwQyxNQUFBLG9CQUFBLEtBQUEsYUFBQTtBQUFXLE1BQUEsMEJBQUE7QUFDckQsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUFvQyxNQUFBLG9CQUFBLEtBQUEsbUJBQUE7QUFBaUIsTUFBQSwwQkFBQSxFQUFNO0FBRy9ELE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBcUQsS0FBQSxPQUFBLEVBQUE7QUFFN0MsTUFBQSx1QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUNKLE1BQUEsMEJBQUE7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBOztBQUNJLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEVBQUE7QUFBdUMsTUFBQSxvQkFBQSxLQUFBLGVBQUE7QUFDM0MsTUFBQSwwQkFBQSxFQUFNOztBQUdWLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBb0QsS0FBQSxPQUFBLEVBQUE7O0FBRTVDLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEVBQUE7O0FBQ0EsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUE2SCxNQUFBLG9CQUFBLEtBQUEsT0FBQTtBQUFLLE1BQUEsMEJBQUEsRUFBTTtBQUU1SSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQTBDLE1BQUEsb0JBQUEsS0FBQSxtQkFBQTtBQUFpQixNQUFBLDBCQUFBO0FBQzNELE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUE7QUFBb0MsTUFBQSxvQkFBQSxLQUFBLHVCQUFBO0FBQXFCLE1BQUEsMEJBQUEsRUFBTTtBQUduRSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQXFELEtBQUEsT0FBQSxFQUFBO0FBRTdDLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBO0FBQ0MsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQTs7QUFDRyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQTBDLE1BQUEsb0JBQUEsS0FBQSxjQUFBO0FBQzlDLE1BQUEsMEJBQUEsRUFBTTs7QUFHVixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQW9ELEtBQUEsT0FBQSxFQUFBOztBQUU1QyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0osTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQTBDLE1BQUEsb0JBQUEsS0FBQSxXQUFBO0FBQVMsTUFBQSwwQkFBQTtBQUNuRCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQW9DLE1BQUEsb0JBQUEsS0FBQSwwQkFBQTtBQUF3QixNQUFBLDBCQUFBLEVBQU0sRUFDaEUsRUFFSixFQUNKLEVBQ0o7QUFHVixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQXdELEtBQUEsT0FBQSxFQUFBLEVBQ3JCLEtBQUEsTUFBQSxFQUFBO0FBQ29CLE1BQUEsb0JBQUEsS0FBQSxxQ0FBQTtBQUFtQyxNQUFBLDBCQUFBO0FBQ2xGLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEVBQUE7QUFDSSxNQUFBLG9CQUFBLEtBQUEsdURBQUE7QUFDQSxNQUFBLHVCQUFBLEtBQUEsSUFBQTtBQUFJLE1BQUEsb0JBQUEsS0FBQSw2RkFBQTtBQUNSLE1BQUEsMEJBQUEsRUFBSTtBQUdSLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBdUMsS0FBQSxPQUFBLEVBQUEsRUFDeUUsS0FBQSxPQUFBLEVBQUE7O0FBRXBHLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxNQUFBLEVBQUE7QUFBOEMsTUFBQSxvQkFBQSxLQUFBLDZCQUFBO0FBQTJCLE1BQUEsMEJBQUE7QUFDekUsTUFBQSw0QkFBQSxLQUFBLEtBQUEsRUFBQTtBQUNJLE1BQUEsb0JBQUEsS0FBQSw4REFBQTtBQUEyRCxNQUFBLDRCQUFBLEtBQUEsUUFBQTtBQUFRLE1BQUEsb0JBQUEsS0FBQSxRQUFBO0FBQU0sTUFBQSwwQkFBQTtBQUFVLE1BQUEsb0JBQUEsS0FBQSxxQkFBQTtBQUFrQixNQUFBLDRCQUFBLEtBQUEsUUFBQTtBQUFRLE1BQUEsb0JBQUEsS0FBQSxRQUFBO0FBQU0sTUFBQSwwQkFBQTtBQUFVLE1BQUEsb0JBQUEsS0FBQSxxRUFBQTtBQUNqSSxNQUFBLDBCQUFBLEVBQUk7QUFHUixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQTRHLEtBQUEsT0FBQSxFQUFBOztBQUVwRyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0osTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsTUFBQSxFQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSw0QkFBQTtBQUEwQixNQUFBLDBCQUFBO0FBQ3hFLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEVBQUE7QUFDSSxNQUFBLG9CQUFBLEtBQUEsOEtBQUE7QUFDSixNQUFBLDBCQUFBLEVBQUk7QUFHUixNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0ksTUFBQSx1QkFBQSxLQUFBLE9BQUEsR0FBQTtBQUNBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7O0FBQ0ksTUFBQSx1QkFBQSxLQUFBLE9BQUEsR0FBQTtBQUNKLE1BQUEsMEJBQUE7O0FBQ0EsTUFBQSw0QkFBQSxLQUFBLE1BQUEsRUFBQTtBQUE4QyxNQUFBLG9CQUFBLEtBQUEsK0JBQUE7QUFBNkIsTUFBQSwwQkFBQTtBQUMzRSxNQUFBLDRCQUFBLEtBQUEsS0FBQSxHQUFBO0FBQ0ksTUFBQSxvQkFBQSxLQUFBLGlIQUFBO0FBQThHLE1BQUEsNEJBQUEsS0FBQSxRQUFBO0FBQVEsTUFBQSxvQkFBQSxLQUFBLFlBQUE7QUFBVSxNQUFBLDBCQUFBO0FBQVUsTUFBQSxvQkFBQSxLQUFBLHdCQUFBO0FBQXFCLE1BQUEsNEJBQUEsS0FBQSxRQUFBO0FBQVEsTUFBQSxvQkFBQSxLQUFBLE9BQUE7QUFBSyxNQUFBLDBCQUFBO0FBQVUsTUFBQSxvQkFBQSxLQUFBLDZCQUFBO0FBQzFMLE1BQUEsMEJBQUEsRUFBSSxFQUNGLEVBQ0o7QUFHVixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQXdELEtBQUEsT0FBQSxFQUFBLEVBQ3JCLEtBQUEsTUFBQSxFQUFBO0FBQ29CLE1BQUEsb0JBQUEsS0FBQSw2QkFBQTtBQUEyQixNQUFBLDBCQUFBO0FBQzFFLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEVBQUE7QUFBMEIsTUFBQSxvQkFBQSxLQUFBLDhFQUFBO0FBQTRFLE1BQUEsMEJBQUEsRUFBSTtBQUc5RyxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQTJKLEtBQUEsT0FBQSxHQUFBLEVBQ3pILEtBQUEsTUFBQSxHQUFBOztBQUV0QixNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSxvQkFBQSxLQUFBLG9CQUFBO0FBQ0osTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsS0FBQSxHQUFBO0FBQ0ksTUFBQSxvQkFBQSxLQUFBLGdMQUFBO0FBRUosTUFBQSwwQkFBQTtBQUNBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUEsRUFBa0MsS0FBQSxLQUFBLEdBQUE7O0FBRTFCLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDQSxNQUFBLG9CQUFBLEtBQUEsZUFBQTtBQUNKLE1BQUEsMEJBQUE7O0FBQ0EsTUFBQSw0QkFBQSxLQUFBLEtBQUEsR0FBQTs7QUFDSSxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSxvQkFBQSxLQUFBLGFBQUE7QUFDSixNQUFBLDBCQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEdBQUE7O0FBQ0ksTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQTtBQUFxTSxNQUFBLHVCQUFBLEtBQUEsUUFBQSxHQUFBLEVBQXlMLEtBQUEsUUFBQSxHQUFBO0FBQTJCLE1BQUEsMEJBQUE7QUFDelosTUFBQSxvQkFBQSxLQUFBLFNBQUE7QUFDSixNQUFBLDBCQUFBLEVBQUksRUFDRjs7QUFFVixNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0ksTUFBQSxvQkFBQSxLQUFBLGdDQUFBO0FBQTZCLE1BQUEsdUJBQUEsS0FBQSxJQUFBLEVBQUksS0FBQSxJQUFBO0FBQ2pDLE1BQUEsb0JBQUEsS0FBQSx5Q0FBQTtBQUEyQyxNQUFBLHVCQUFBLEtBQUEsSUFBQTtBQUMzQyxNQUFBLG9CQUFBLEtBQUEsd0JBQUE7QUFBeUIsTUFBQSx1QkFBQSxLQUFBLElBQUE7QUFDekIsTUFBQSxvQkFBQSxLQUFBLE1BQUE7QUFBUSxNQUFBLHVCQUFBLEtBQUEsSUFBQSxFQUFJLEtBQUEsSUFBQTtBQUNaLE1BQUEsb0JBQUEsS0FBQSx3Q0FBQTtBQUNKLE1BQUEsMEJBQUEsRUFBTSxFQUNKO0FBR1YsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQSxFQUF3RCxLQUFBLE9BQUEsRUFBQSxFQUNyQixLQUFBLE1BQUEsRUFBQTtBQUNvQixNQUFBLG9CQUFBLEtBQUEsMEJBQUE7QUFBd0IsTUFBQSwwQkFBQTtBQUN2RSxNQUFBLDRCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQTBCLE1BQUEsb0JBQUEsS0FBQSwwRUFBQTtBQUF3RSxNQUFBLDBCQUFBLEVBQUk7QUFHMUcsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQSxFQUEySixLQUFBLE9BQUEsR0FBQSxFQUN6SCxLQUFBLE1BQUEsR0FBQTs7QUFFdEIsTUFBQSx1QkFBQSxLQUFBLE9BQUEsR0FBQTtBQUNBLE1BQUEsb0JBQUEsS0FBQSwyQkFBQTtBQUNKLE1BQUEsMEJBQUE7O0FBQ0EsTUFBQSw0QkFBQSxLQUFBLEtBQUEsR0FBQTtBQUNJLE1BQUEsb0JBQUEsS0FBQSx1TUFBQTtBQUVKLE1BQUEsMEJBQUE7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQWtDLEtBQUEsS0FBQSxHQUFBO0FBRzFCLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDQSxNQUFBLG9CQUFBLEtBQUEsMEJBQUE7QUFDSixNQUFBLDBCQUFBO0FBQ0EsTUFBQSw0QkFBQSxLQUFBLEtBQUEsR0FBQTs7QUFDSSxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSxvQkFBQSxLQUFBLGlCQUFBO0FBQ0osTUFBQSwwQkFBQSxFQUFJLEVBQ0Y7O0FBRVYsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQSxFQUFpRCxLQUFBLEtBQUEsR0FBQTtBQUV6QyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQTtBQUNLLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQTJFLE1BQUEsb0JBQUEsS0FBQSxPQUFBO0FBQUssTUFBQSwwQkFBQTtBQUNoRixNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQXlFLE1BQUEsb0JBQUEsS0FBQSxXQUFBO0FBQVMsTUFBQSwwQkFBQSxFQUFNLEVBQ3ZGLEVBQ0wsRUFDSCxFQUNKO0FBSVYsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQSxFQUF3RCxLQUFBLE9BQUEsRUFBQSxFQUNyQixLQUFBLE1BQUEsRUFBQTtBQUNvQixNQUFBLG9CQUFBLEtBQUEscUJBQUE7QUFBbUIsTUFBQSwwQkFBQTtBQUNsRSxNQUFBLDRCQUFBLEtBQUEsS0FBQSxFQUFBO0FBQTBCLE1BQUEsb0JBQUEsS0FBQSw0REFBQTtBQUEwRCxNQUFBLDBCQUFBLEVBQUk7QUFHNUYsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQSxFQUErRCxLQUFBLE9BQUEsR0FBQTs7QUFFdkQsTUFBQSx1QkFBQSxLQUFBLE9BQUEsR0FBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxTQUFBO0FBQU8sTUFBQSwwQkFBQTtBQUNyRCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxhQUFBO0FBQVcsTUFBQSwwQkFBQSxFQUFNO0FBRWxFLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7O0FBQ0csTUFBQSx1QkFBQSxLQUFBLE9BQUEsR0FBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxTQUFBO0FBQU8sTUFBQSwwQkFBQTtBQUNyRCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQThDLE1BQUEsb0JBQUEsS0FBQSxzQkFBQTtBQUFvQixNQUFBLDBCQUFBLEVBQU07QUFFM0UsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQTs7QUFDRyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFBOEMsTUFBQSxvQkFBQSxLQUFBLFdBQUE7QUFBUyxNQUFBLDBCQUFBO0FBQ3ZELE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFBOEMsTUFBQSxvQkFBQSxLQUFBLFdBQUE7QUFBUyxNQUFBLDBCQUFBLEVBQU07QUFFaEUsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQTs7QUFDRyxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFBOEMsTUFBQSxvQkFBQSxLQUFBLFdBQUE7QUFBUyxNQUFBLDBCQUFBO0FBQ3ZELE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFBOEMsTUFBQSxvQkFBQSxLQUFBLFNBQUE7QUFBTyxNQUFBLDBCQUFBLEVBQU0sRUFDeEQsRUFDTDtBQUdWLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUEsRUFBb0UsS0FBQSxLQUFBLEdBQUE7QUFDZSxNQUFBLG9CQUFBLEtBQUEsa0RBQUE7QUFBZ0QsTUFBQSwwQkFBQTtBQUMvSCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQWlELEtBQUEsUUFBQSxHQUFBO0FBQzRELE1BQUEsb0JBQUEsS0FBQSxTQUFBO0FBQU8sTUFBQSwwQkFBQTtBQUNoSCxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQXlHLE1BQUEsb0JBQUEsS0FBQSxVQUFBO0FBQVEsTUFBQSwwQkFBQTtBQUNqSCxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQXlHLE1BQUEsb0JBQUEsS0FBQSxVQUFBO0FBQVEsTUFBQSwwQkFBQTtBQUNqSCxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQXlHLE1BQUEsb0JBQUEsS0FBQSxRQUFBO0FBQU0sTUFBQSwwQkFBQTtBQUMvRyxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQXlHLE1BQUEsb0JBQUEsS0FBQSxRQUFBO0FBQU0sTUFBQSwwQkFBQTtBQUMvRyxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQXlHLE1BQUEsb0JBQUEsS0FBQSxTQUFBO0FBQU8sTUFBQSwwQkFBQTtBQUNoSCxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQXlHLE1BQUEsb0JBQUEsS0FBQSxVQUFBO0FBQVEsTUFBQSwwQkFBQSxFQUFPLEVBQ3RIO0FBR1YsTUFBQSw0QkFBQSxLQUFBLE9BQUEsR0FBQSxFQUE4RCxLQUFBLE1BQUEsR0FBQTtBQUNELE1BQUEsb0JBQUEsS0FBQSw0QkFBQTtBQUEwQixNQUFBLDBCQUFBO0FBQ3JGLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBdUIsS0FBQSxPQUFBLEdBQUEsRUFFNkUsS0FBQSxNQUFBLEdBQUE7O0FBRTlGLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDQSxNQUFBLG9CQUFBLEtBQUEsNEJBQUE7QUFDRixNQUFBLDBCQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEVBQUE7QUFDRSxNQUFBLG9CQUFBLEtBQUEseUVBQUE7QUFDQSxNQUFBLDRCQUFBLEtBQUEsUUFBQSxHQUFBO0FBQTZCLE1BQUEsb0JBQUEsS0FBQSw2Q0FBQTtBQUEyQyxNQUFBLDBCQUFBO0FBQU8sTUFBQSxvQkFBQSxLQUFBLHFFQUFBO0FBRWpGLE1BQUEsMEJBQUEsRUFBSTtBQUdOLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUEsRUFBa0csS0FBQSxNQUFBLEdBQUE7O0FBRTlGLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDQSxNQUFBLG9CQUFBLEtBQUEsdUNBQUE7QUFDRixNQUFBLDBCQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEVBQUE7QUFDRSxNQUFBLG9CQUFBLEtBQUEscU1BQUE7QUFFRixNQUFBLDBCQUFBLEVBQUk7QUFHTixNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQWtHLEtBQUEsTUFBQSxHQUFBOztBQUU5RixNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSxvQkFBQSxLQUFBLHNCQUFBO0FBQ0YsTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQW9ELEtBQUEsS0FBQSxHQUFBLEVBQ2xDLEtBQUEsVUFBQSxHQUFBO0FBQ2lCLE1BQUEsb0JBQUEsS0FBQSxNQUFBO0FBQUksTUFBQSwwQkFBQTtBQUFVLE1BQUEsb0JBQUEsS0FBQSwyREFBQTtBQUMvQyxNQUFBLDBCQUFBO0FBQ0EsTUFBQSw0QkFBQSxLQUFBLEdBQUE7QUFDRSxNQUFBLG9CQUFBLEtBQUEsMkhBQUE7QUFDRixNQUFBLDBCQUFBLEVBQUksRUFDQTtBQUdSLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUEsRUFBa0csS0FBQSxNQUFBLEdBQUE7O0FBRTlGLE1BQUEsdUJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDQSxNQUFBLG9CQUFBLEtBQUEsd0NBQUE7QUFDRixNQUFBLDBCQUFBOztBQUNBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBb0QsS0FBQSxLQUFBLEdBQUEsRUFDbEMsS0FBQSxVQUFBLEdBQUE7QUFDaUIsTUFBQSxvQkFBQSxLQUFBLE1BQUE7QUFBSSxNQUFBLDBCQUFBO0FBQVUsTUFBQSxvQkFBQSxLQUFBLDRFQUFBO0FBQy9DLE1BQUEsMEJBQUE7QUFDQSxNQUFBLDRCQUFBLEtBQUEsR0FBQTtBQUNFLE1BQUEsb0JBQUEsS0FBQSw2SUFBQTtBQUNBLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEdBQUE7QUFBaUcsTUFBQSxvQkFBQSxLQUFBLHdCQUFBO0FBQXNCLE1BQUEsMEJBQUE7QUFBSSxNQUFBLG9CQUFBLEtBQUEsSUFBQTtBQUM3SCxNQUFBLDBCQUFBLEVBQUksRUFDQSxFQUNGLEVBRUY7QUFHUixNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQTRGLEtBQUEsTUFBQSxHQUFBO0FBQ3pDLE1BQUEsb0JBQUEsS0FBQSxzQkFBQTtBQUFvQixNQUFBLDBCQUFBO0FBQ25FLE1BQUEsNEJBQUEsS0FBQSxLQUFBLEdBQUE7QUFDSSxNQUFBLG9CQUFBLEtBQUEsdUVBQUE7QUFDSixNQUFBLDBCQUFBO0FBQ0EsTUFBQSw0QkFBQSxLQUFBLEtBQUEsR0FBQTtBQUNFLE1BQUEsb0JBQUEsS0FBQSxpQkFBQTs7QUFDQSxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0YsTUFBQSwwQkFBQSxFQUFJOzs7SUFqZ0JSO0lBQVk7SUFBQTtJQUFBO0lBQUE7SUFDWjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtFQUFrQixHQUFBLGVBQUEsRUFBQSxDQUFBOzs7K0VBK2VULGVBQWEsQ0FBQTtVQXpnQnpCO1dBQVU7TUFDVCxVQUFVO01BQ1YsWUFBWTtNQUNaLFNBQVM7UUFDUDtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztNQUVGLFVBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQTRlWDs7OztnRkFDWSxlQUFhLEVBQUEsV0FBQSxpQkFBQSxVQUFBLG9EQUFBLFlBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7Ozs4REFBYixlQUFhLEVBQUEsU0FBQSxDQUFBLElBQUEsRUFBQSxHQUFBLENBQUEsY0FBQSxXQUFBLGFBQUEsZ0JBQUEsb0JBQUEsWUFBQSxhQUFBLGtCQUFBLGFBQUEsZUFBQSxvQkFBQSxxQkFBQSxlQUFBLGVBQUEsV0FBQSxtQkFBQSxnQkFBQSxhQUFBLGNBQUEsbUJBQUEsZ0JBQUEsaUJBQUEsb0JBQUEsU0FBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsc0JBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLENBQUEsTUFBQSxFQUFBLE9BQUEsTUFBQSxzQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBQ3ppQjFCLFNBQVMsY0FBYztBQUN2QixTQUFTLGNBQTZCO0FBRy9CLElBQU0sa0JBQWlDLE1BQU07QUFDbEQsUUFBTSxnQkFBZ0IsT0FBTyxhQUFhO0FBQzFDLFFBQU0sU0FBUyxPQUFPLE1BQU07QUFFNUIsTUFBSSxjQUFjLE9BQU8sRUFBRSxZQUFZO0FBQ3JDLFdBQU8sT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDO0FBQUEsRUFDekM7QUFFQSxTQUFPO0FBQ1Q7OztBQ1RPLElBQU0sWUFBcUI7RUFDaEMsRUFBRSxNQUFNLElBQUksV0FBVyxlQUFlLGFBQWEsQ0FBQyxlQUFlLEVBQUM7RUFDcEU7SUFDRSxNQUFNO0lBQ04sZUFBZSxNQUFNLE9BQU8scUJBQWlDLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxlQUFlOztFQUU5RjtJQUNFLE1BQU07SUFDTixlQUFlLE1BQU0sT0FBTyxxQkFBNkIsRUFBRSxLQUFLLENBQUMsTUFBTSxFQUFFLGFBQWE7O0VBRXhGLEVBQUUsTUFBTSxNQUFNLFlBQVksR0FBRTs7OztBSEo5QixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLDRCQUE0QjtBQU85QixJQUFNLFlBQStCO0FBQUEsRUFDMUMsV0FBVztBQUFBO0FBQUEsSUFFVCxtQ0FBbUM7QUFBQSxJQUNuQywyQkFBMkIsRUFBRSxpQkFBaUIsS0FBSyxDQUFDO0FBQUEsSUFDcEQsY0FBYyxTQUFTO0FBQUEsSUFDdkIsa0JBQWtCO0FBQUEsSUFDbEIscUJBQXFCLGtCQUFrQjtBQUFBLE1BQ3JDLFNBQVMsQ0FBQyxVQUFVO0FBQUEsTUFDcEIsc0JBQXNCO0FBQUEsSUFDeEIsQ0FBQztBQUFBLElBQ0Qsc0JBQXNCLE1BQU07QUFDMUIsWUFBTSxnQkFBZ0JDLFFBQU8sYUFBYTtBQUUxQyxhQUFPLGNBQWMsV0FBVztBQUFBLElBQ2xDLENBQUM7QUFBQSxFQUNIO0FBQ0Y7OztBSXJCQSxTQUFTLGFBQUFDLFlBQVcsbUJBQW1CLFVBQUFDLFNBQWdCLGlCQUFpQjtBQUN4RSxTQUFTLGNBQWMsZ0JBQWdCO0FBQ3ZDLFNBQVMsZ0JBQUFDLGVBQWMsVUFBQUMsU0FBUSxxQkFBcUI7QUFDcEQsU0FBUyxjQUFjO0FBRXZCLFNBQVMsT0FBTyxZQUFZO0FBQzVCLFNBQ0UsY0FFQSxhQUFBQyxZQUNBLFdBQ0EsZUFBQUMsY0FDQSxrQkFDSzs7Ozs7OztBQXVCUyxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBOzs7O0FBQUssSUFBQSx5QkFBQSxPQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsU0FBQSwyQkFBQSxFQUFzQyxPQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsU0FBQTs7Ozs7O0FBRTNDLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBaUosR0FBQSxHQUFBO0FBRTdJLElBQUEsd0JBQUEsR0FBQSxRQUFBLEVBQUEsRUFBbzZCLEdBQUEsUUFBQSxFQUFBLEVBQy9RLEdBQUEsUUFBQSxFQUFBLEVBQ0MsR0FBQSxRQUFBLEVBQUE7QUFFeHBCLElBQUEsMkJBQUEsRUFBSTs7Ozs7QUFXUixJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXlGLEdBQUEsTUFBQTtBQUNqRixJQUFBLHFCQUFBLEdBQUEsV0FBQTtBQUFTLElBQUEsMkJBQUE7QUFDZixJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsR0FBQSxlQUFBO0FBQWEsSUFBQSwyQkFBQTtBQUNuQixJQUFBLDZCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSwyQkFBQSxFQUFPOzs7OztBQTNCOUIsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUEwRyxHQUFBLE9BQUEsQ0FBQSxFQUM3QixHQUFBLE9BQUEsQ0FBQTtBQUd2RSxJQUFBLGtDQUFBLEdBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQSxFQUF5QyxHQUFBLDBDQUFBLEdBQUEsR0FBQSxZQUFBLENBQUE7QUFhekMsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNFLElBQUEscUJBQUEsQ0FBQTtBQUFzQyxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWdDLElBQUEscUJBQUEsQ0FBQTtBQUE4QyxJQUFBLDJCQUFBLEVBQU8sRUFFdEg7QUFHVCxJQUFBLGtDQUFBLEdBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQU9GLElBQUEsMkJBQUEsRUFBTTs7OztBQTFCRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsYUFBQSxJQUFBLENBQUE7QUFjRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBO0FBQXNFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxlQUFBLEVBQUE7QUFLMUUsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsQ0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLG9CQUFBLElBQUEsRUFBQTs7Ozs7QUF3QkUsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF5RixHQUFBLE1BQUE7QUFDakYsSUFBQSxxQkFBQSxHQUFBLFdBQUE7QUFBUyxJQUFBLDJCQUFBO0FBQ2YsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEdBQUEsZUFBQTtBQUFhLElBQUEsMkJBQUE7QUFDbkIsSUFBQSw2QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHFCQUFBLEdBQUEsV0FBQTtBQUFTLElBQUEsMkJBQUEsRUFBTzs7Ozs7QUFmOUIsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUEwRyxHQUFBLE9BQUEsQ0FBQSxFQUM3QixHQUFBLE9BQUEsRUFBQTtBQUd2RSxJQUFBLHdCQUFBLEdBQUEsT0FBQSxDQUFBO0FBRUEsSUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUNJLElBQUEscUJBQUEsQ0FBQTtBQUFzQyxJQUFBLDZCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWdDLElBQUEscUJBQUEsQ0FBQTtBQUE4QyxJQUFBLDJCQUFBLEVBQU8sRUFDeEg7QUFHVCxJQUFBLGtDQUFBLEdBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQU9GLElBQUEsMkJBQUEsRUFBTTs7OztBQWRHLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUEsMkJBQUEsRUFBc0MsT0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFNBQUE7QUFHdkMsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsU0FBQTtBQUFzRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsZUFBQSxFQUFBO0FBSTVFLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLENBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxvQkFBQSxJQUFBLEVBQUE7Ozs7O0FBdUJRLElBQUEscUJBQUEsR0FBQSxPQUFBO0FBQU0sSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUFnQyxJQUFBLHFCQUFBLEdBQUEsa0JBQUE7QUFBYSxJQUFBLDJCQUFBOzs7OztBQTRLakQsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUErQixJQUFBLHFCQUFBLEdBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDckMsSUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFBRyxJQUFBLHFCQUFBLEdBQUEsdUVBQUE7QUFBa0UsSUFBQSwyQkFBQTs7Ozs7QUFwTG5GLElBQUEsNkJBQUEsR0FBQSxVQUFBLENBQUEsRUFBMEYsR0FBQSxPQUFBLEVBQUEsRUFDcEQsR0FBQSxPQUFBLEVBQUEsRUFDNkQsR0FBQSxPQUFBLEVBQUEsRUFDdkQsR0FBQSxPQUFBLEVBQUE7QUFFbEMsSUFBQSxxQkFBQSxDQUFBO0FBQXNDLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBZ0MsSUFBQSxxQkFBQSxDQUFBO0FBQThDLElBQUEsMkJBQUE7QUFDcEgsSUFBQSxrQ0FBQSxHQUFBLDBDQUFBLEdBQUEsQ0FBQTtBQUdGLElBQUEsMkJBQUE7QUFDQSxJQUFBLDZCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0UsSUFBQSxxQkFBQSxJQUFBLHVEQUFBO0FBQ0YsSUFBQSwyQkFBQSxFQUFJO0FBR04sSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFxQyxJQUFBLFVBQUEsRUFBQTs7QUFLakMsSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTs7QUFDQSxJQUFBLDZCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQSxFQUFPO0FBSXJCLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBdUgsSUFBQSxPQUFBLEVBQUEsRUFDRCxJQUFBLFVBQUEsRUFBQTtBQU1oSCxJQUFBLHFCQUFBLElBQUEsVUFBQTtBQUNGLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXlCLElBQUEsTUFBQSxFQUFBO0FBQzJCLElBQUEscUJBQUEsRUFBQTtBQUE4QyxJQUFBLDJCQUFBO0FBQ2hHLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBOEMsSUFBQSxxQkFBQSxJQUFBLGdDQUFBO0FBQThCLElBQUEsMkJBQUE7QUFHNUUsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsd0JBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRixJQUFBLDJCQUFBO0FBR0EsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFrQixJQUFBLFNBQUEsRUFBQTtBQUM2RSxJQUFBLHFCQUFBLElBQUEsbUJBQUE7QUFBaUIsSUFBQSwyQkFBQTtBQUM5RyxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSxxQkFBQSxJQUFBLGtDQUFBO0FBQ0YsSUFBQSwyQkFBQSxFQUFNO0FBSVIsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBSyxJQUFBLFNBQUEsRUFBQTtBQUMwRixJQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMkJBQUE7QUFDbEcsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEscUJBQUEsSUFBQSw0R0FBQTtBQUNGLElBQUEsMkJBQUEsRUFBTSxFQUNGLEVBRUYsRUFDRjtBQUdSLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7O0FBR0UsSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNGLElBQUEsMkJBQUE7O0FBRUEsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTs7QUFJRSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBV0UsSUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQSxFQUNpUSxJQUFBLFFBQUEsRUFBQTtBQUVuUSxJQUFBLDJCQUFBLEVBQU07O0FBR1IsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTs7QUFJRSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBV0UsSUFBQSx3QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUVGLElBQUEsMkJBQUEsRUFBTTs7QUFHUixJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBOztBQUlFLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFXRSxJQUFBLHdCQUFBLElBQUEsUUFBQSxFQUFBLEVBQ3NMLElBQUEsUUFBQSxFQUFBO0FBRXhMLElBQUEsMkJBQUEsRUFBTTs7QUFHUixJQUFBLDZCQUFBLElBQUEsS0FBQSxFQUFBOztBQUtFLElBQUEsd0JBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRixJQUFBLDJCQUFBLEVBQUksRUFDQTs7QUFHUixJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQW9ELElBQUEsT0FBQSxFQUFBLEVBQ21DLElBQUEsS0FBQSxFQUFBLEVBQ0MsSUFBQSxRQUFBO0FBQzFFLElBQUEscUJBQUEsSUFBQSx5QkFBQTtBQUF1QixJQUFBLDJCQUFBO0FBQVUsSUFBQSxxQkFBQSxJQUFBLHlEQUFBO0FBRXpDLElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7QUFJRyxJQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBYyxJQUFBLDJCQUFBO0FBQ2hCLElBQUEscUJBQUEsSUFBQSwwREFBQTtBQUF3RCxJQUFBLHdCQUFBLElBQUEsSUFBQSxFQUFNLElBQUEsSUFBQTtBQUMvRCxJQUFBLDZCQUFBLElBQUEsUUFBQTtBQUFRLElBQUEscUJBQUEsSUFBQSxnQkFBQTtBQUFjLElBQUEsMkJBQUE7QUFBVSxJQUFBLHFCQUFBLEVBQUE7QUFHZixJQUFBLHdCQUFBLElBQUEsSUFBQSxFQUFNLElBQUEsSUFBQTtBQUN2QixJQUFBLDZCQUFBLElBQUEsUUFBQTtBQUFRLElBQUEscUJBQUEsSUFBQSxzQkFBQTtBQUFvQixJQUFBLDJCQUFBO0FBQVUsSUFBQSxxQkFBQSxJQUFBLGdOQUFBO0FBSXhDLElBQUEsMkJBQUEsRUFBSTtBQUdOLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNkQsSUFBQSxPQUFBLEVBQUEsRUFDaUIsSUFBQSxPQUFBLEVBQUEsRUFDVixJQUFBLEdBQUE7QUFFNUQsSUFBQSxxQkFBQSxFQUFBO0FBQ0EsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFDRyxJQUFBLEtBQUEsRUFBQTtBQUlFLElBQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFzQixJQUFBLDJCQUFBLEVBQ3hCLEVBQ0Y7QUFFSCxJQUFBLGtDQUFBLElBQUEsMkNBQUEsR0FBQSxDQUFBO0FBSUEsSUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUErQixJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDckMsSUFBQSw2QkFBQSxJQUFBLEdBQUE7QUFBRyxJQUFBLHFCQUFBLElBQUEscUJBQUE7QUFBbUIsSUFBQSwyQkFBQTtBQUN0QixJQUFBLDZCQUFBLElBQUEsUUFBQSxFQUFBO0FBQStCLElBQUEscUJBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwyQkFBQTtBQUNyQyxJQUFBLDZCQUFBLElBQUEsR0FBQTtBQUFHLElBQUEscUJBQUEsSUFBQSwwQkFBQTtBQUF3QixJQUFBLDJCQUFBLEVBQUk7QUFFakMsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUFrQyxJQUFBLHFCQUFBLElBQUEsOENBQUE7QUFBNEMsSUFBQSwyQkFBQSxFQUFJO0FBR3BGLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNkUsSUFBQSxLQUFBLEVBQUE7O0FBS3pFLElBQUEsd0JBQUEsSUFBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLHFCQUFBLElBQUEsa0JBQUE7QUFDRixJQUFBLDJCQUFBOztBQUVBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBaUQsSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDJCQUFBO0FBRXZELElBQUEsNkJBQUEsSUFBQSxLQUFBLEVBQUE7O0FBSUUsSUFBQSx3QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsSUFBQSxXQUFBO0FBQ0YsSUFBQSwyQkFBQSxFQUFJLEVBQ0EsRUFDRixFQUNGLEVBQ0Y7Ozs7QUE5TUUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsU0FBQTtBQUFzRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsZUFBQSxFQUFBO0FBQ3RFLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsY0FBQSxPQUFBLEVBQUEsY0FBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLGVBQUEsSUFBQSxFQUFBO0FBOEJzRCxJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLGlDQUFBLFlBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxTQUFBO0FBcUh0QixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxXQUFBLHFOQUFBO0FBZTVCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsaUNBQUEsVUFBQSxPQUFBLGFBQUEsR0FBQTtBQVVGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsT0FBQSxjQUFBLE9BQUEsRUFBQSxlQUFBLEtBQUEsRUFBQTs7Ozs7QUFzQ1osSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUEwRCxHQUFBLEtBQUEsRUFBQTs7QUFNdEQsSUFBQSx3QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSwyQkFBQTtBQUNGLElBQUEsMkJBQUEsRUFBSTs7O0FBS1IsSUFBTyxNQUFQLE1BQU8sS0FBcUI7RUFDaEMsYUFBYTtFQUNiLGFBQWE7RUFFSixlQUFjLG9CQUFJLEtBQUksR0FBRyxZQUFXO0VBRXJDLFNBQVNDLFFBQU9DLE9BQU07RUFDZCxnQkFBZ0JELFFBQU8sYUFBYTtFQUM1QyxlQUFlQSxRQUFPLEtBQUs7RUFDM0IsY0FBY0EsUUFBTyxJQUFJO0VBQ3pCLFdBQVdBLFFBQU8sUUFBUTtFQUMxQixXQUFXQSxRQUFPLFNBQVM7RUFFbkMsY0FBQTtBQUNFLFNBQUssT0FBTyxPQUFPLEtBQUssT0FBTyxDQUFDLFVBQVUsaUJBQWlCLGFBQWEsQ0FBQyxFQUFFLFVBQVUsTUFBSztBQUN4RixVQUFJLE9BQU8sV0FBVyxhQUFhO0FBQ2pDLGVBQU8sU0FBUyxHQUFHLENBQUM7TUFDdEI7SUFDRixDQUFDO0VBQ0g7RUFFQSxXQUFRO0FBQ04sU0FBSyxtQkFBa0I7QUFFdkIsUUFBSSxPQUFPLFdBQVcsYUFBYTtBQUNqQyxXQUFLLGFBQWEsV0FBVyxPQUFPLFVBQVUsV0FBVyxPQUFPO0FBRWhFLFlBQU0sWUFBWSxJQUFJLGdCQUFnQixPQUFPLFNBQVMsTUFBTTtBQUM1RCxXQUFLLGFBQWEsVUFBVSxJQUFJLFlBQVksTUFBTTtBQUVsRCxVQUFJLENBQUMsT0FBTyxpQkFBaUI7QUFDM0IsaUJBQVMsS0FBSyxZQUFZOzs7Ozs7O0FBTzFCLGNBQU0sSUFBSSxNQUFNLHdDQUF3QztNQUMxRDtJQUNGO0VBQ0Y7RUFFUSxxQkFBa0I7QUFDeEIsVUFBTSxTQUFTLEtBQUssY0FBYyxPQUFNO0FBQ3hDLFVBQU0sZ0JBQWdCLE9BQU8sYUFBYSxPQUFPLGNBQWMsT0FBTyxjQUFjO0FBRXBGLFVBQU0sWUFBWSxHQUFHLGFBQWEsTUFBTSxPQUFPLFdBQVcsZ0NBQWdDO0FBQzFGLFVBQU0sV0FDSixPQUFPLGNBQWM7QUFFdkIsU0FBSyxhQUFhLFNBQVMsU0FBUztBQUNwQyxTQUFLLFlBQVksVUFBVSxFQUFFLE1BQU0sZUFBZSxTQUFTLFNBQVEsQ0FBRTtBQUVyRSxRQUFJLE9BQU8sZUFBZTtBQUN4QixXQUFLLFlBQVksVUFBVSxFQUFFLE1BQU0sZUFBZSxTQUFTLE9BQU8sY0FBYSxDQUFFO0lBQ25GO0FBRUEsU0FBSyxZQUFZLFVBQVUsRUFBRSxVQUFVLFlBQVksU0FBUyxVQUFTLENBQUU7QUFDdkUsU0FBSyxZQUFZLFVBQVUsRUFBRSxVQUFVLGtCQUFrQixTQUFTLFNBQVEsQ0FBRTtBQUM1RSxTQUFLLFlBQVksVUFBVSxFQUFFLFVBQVUsZ0JBQWdCLFNBQVMsY0FBYSxDQUFFO0FBRS9FLFNBQUssWUFBWSxVQUFVLEVBQUUsTUFBTSxpQkFBaUIsU0FBUyxVQUFTLENBQUU7QUFDeEUsU0FBSyxZQUFZLFVBQVUsRUFBRSxNQUFNLHVCQUF1QixTQUFTLFNBQVEsQ0FBRTtBQUc3RSxVQUFNLFNBQVM7TUFDYixZQUFZO01BQ1osU0FBUztNQUNULE1BQU07TUFDTixpQkFBaUI7TUFDakIscUJBQXFCO01BQ3JCLGFBQWE7TUFDYixhQUFhO1FBQ1g7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7TUFFRixLQUFLLEtBQUssU0FBUyxhQUFhLFNBQVMsUUFBUTtNQUNqRCxRQUFRO1FBQ04sU0FBUztRQUNULE1BQU0sT0FBTyxlQUFlLDJCQUEyQjs7O0FBSTNELFVBQU0sU0FBUyxLQUFLLFNBQVMsY0FBYyxRQUFRO0FBQ25ELFNBQUssU0FBUyxhQUFhLFFBQVEsUUFBUSxxQkFBcUI7QUFDaEUsU0FBSyxTQUFTLFlBQVksUUFBUSxRQUFRLEtBQUssVUFBVSxNQUFNLENBQUM7QUFFaEUsU0FBSyxTQUFTLFlBQVksS0FBSyxTQUFTLE1BQU0sTUFBTTtFQUN0RDs7cUNBNUZXLE1BQUc7RUFBQTs2RUFBSCxNQUFHLFdBQUEsQ0FBQSxDQUFBLFVBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxnQkFBQSxRQUFBLFlBQUEsZUFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFlBQUEsK0JBQUEsb0JBQUEsU0FBQSxTQUFBLFFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSw0QkFBQSxlQUFBLFNBQUEsV0FBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxRQUFBLFFBQUEsa0JBQUEsV0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsV0FBQSxRQUFBLFFBQUEsUUFBQSxnQkFBQSxpQkFBQSxHQUFBLENBQUEsY0FBQSxLQUFBLEdBQUEsUUFBQSxnQkFBQSxTQUFBLGtCQUFBLG9CQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsT0FBQSxrQkFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsU0FBQSw4QkFBQSxXQUFBLGVBQUEsdUJBQUEsaUJBQUEsR0FBQSxPQUFBLE9BQUEscUJBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGFBQUEsa0JBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxXQUFBLGdCQUFBLFNBQUEsV0FBQSxlQUFBLHVCQUFBLEdBQUEsQ0FBQSxLQUFBLDA1QkFBQSxHQUFBLENBQUEsS0FBQSwyb0JBQUEsR0FBQSxDQUFBLEtBQUEsNG9CQUFBLEdBQUEsQ0FBQSxLQUFBLGltQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFNBQUEsa0JBQUEsb0JBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLGVBQUEsbUJBQUEsZUFBQSxtQkFBQSxTQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsbUJBQUEsV0FBQSxRQUFBLFFBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsV0FBQSxzRUFBQSxHQUFBLFFBQUEsZ0JBQUEsU0FBQSxRQUFBLFVBQUEsZ0JBQUEsaUJBQUEsVUFBQSw0QkFBQSw4QkFBQSwwQkFBQSxjQUFBLFNBQUEsV0FBQSxlQUFBLHlCQUFBLHVCQUFBLEdBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxTQUFBLFNBQUEsbUJBQUEsK0JBQUEsWUFBQSxHQUFBLENBQUEsTUFBQSxnQkFBQSxHQUFBLFVBQUEsU0FBQSxXQUFBLGVBQUEsb0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLFVBQUEsNEJBQUEsT0FBQSxlQUFBLFlBQUEsVUFBQSxRQUFBLGNBQUEsVUFBQSxHQUFBLENBQUEsV0FBQSxtRUFBQSxHQUFBLFlBQUEsU0FBQSxXQUFBLHlCQUFBLG9CQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGlCQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHlCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxPQUFBLGNBQUEsZ0JBQUEsUUFBQSxXQUFBLEdBQUEsQ0FBQSxPQUFBLHVCQUFBLE9BQUEscUJBQUEsR0FBQSxRQUFBLFFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLFdBQUEsZUFBQSx5QkFBQSxRQUFBLGFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxtQkFBQSxRQUFBLFFBQUEsY0FBQSxXQUFBLGFBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHlCQUFBLFFBQUEsUUFBQSxjQUFBLGVBQUEsYUFBQSxhQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsaUNBQUEsR0FBQSx5QkFBQSxvQkFBQSxZQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLFFBQUEsNENBQUEsVUFBQSxVQUFBLEdBQUEseUJBQUEsb0JBQUEsWUFBQSxHQUFBLENBQUEsU0FBQSw4QkFBQSxTQUFBLE1BQUEsVUFBQSxNQUFBLFdBQUEsYUFBQSxRQUFBLFFBQUEsVUFBQSxnQkFBQSxnQkFBQSxLQUFBLGtCQUFBLFNBQUEsbUJBQUEsU0FBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsS0FBQSwwUEFBQSxHQUFBLENBQUEsS0FBQSx1QkFBQSxHQUFBLENBQUEsUUFBQSw2QkFBQSxVQUFBLFVBQUEsR0FBQSx5QkFBQSxvQkFBQSxZQUFBLEdBQUEsQ0FBQSxLQUFBLHlJQUFBLEdBQUEsQ0FBQSxRQUFBLHdDQUFBLFVBQUEsVUFBQSxHQUFBLHlCQUFBLG9CQUFBLFlBQUEsR0FBQSxDQUFBLEtBQUEsK0tBQUEsR0FBQSxDQUFBLEtBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsb0ZBQUEsVUFBQSxVQUFBLFNBQUEsU0FBQSxHQUFBLHlCQUFBLG9CQUFBLFlBQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLDRCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsT0FBQSxjQUFBLFVBQUEsK0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHlCQUFBLG1CQUFBLGdCQUFBLFdBQUEsR0FBQSxDQUFBLFFBQUEsOENBQUEsVUFBQSxVQUFBLEdBQUEsYUFBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFlBQUEsZ0JBQUEsa0JBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFlBQUEsZ0JBQUEsU0FBQSxXQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsYUFBQSxrQkFBQSxnQkFBQSxTQUFBLEdBQUEsQ0FBQSxRQUFBLGlDQUFBLFVBQUEsVUFBQSxHQUFBLDJCQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFNBQUEsY0FBQSxxQkFBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLGlCQUFBLFVBQUEsVUFBQSxHQUFBLFFBQUEsZ0JBQUEsV0FBQSxlQUFBLGFBQUEsbUJBQUEseUJBQUEsMkJBQUEsY0FBQSxPQUFBLEdBQUEsQ0FBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGlDQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsMEJBQUEsYUFBQSxHQUFBLENBQUEsUUFBQSxnQkFBQSxVQUFBLFVBQUEsR0FBQSxRQUFBLGdCQUFBLFdBQUEsZUFBQSxhQUFBLG1CQUFBLHlCQUFBLDJCQUFBLGNBQUEsT0FBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGlDQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsNkRBQUEsVUFBQSxVQUFBLE9BQUEsdUJBQUEsR0FBQSxRQUFBLGdCQUFBLFdBQUEsZUFBQSxlQUFBLHlCQUFBLDJCQUFBLHFCQUFBLGNBQUEsbUJBQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSxTQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxhQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FBclNaLE1BQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFDRSxNQUFBLGtDQUFBLEdBQUEsNEJBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQTtBQW1DQSxNQUFBLGtDQUFBLEdBQUEsNEJBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQXVCQSxNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsTUFBQSx3QkFBQSxHQUFBLGVBQUE7QUFDRixNQUFBLDJCQUFBO0FBRUEsTUFBQSxrQ0FBQSxHQUFBLDRCQUFBLElBQUEsR0FBQSxVQUFBLENBQUE7QUF3TkEsTUFBQSxrQ0FBQSxHQUFBLDRCQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUF2UkYsTUFBQSwyQkFBQTs7O0FBQ0UsTUFBQSx3QkFBQTtBQUFBLE1BQUEsNEJBQUEsQ0FBQSxJQUFBLGFBQUEsSUFBQSxFQUFBO0FBbUNBLE1BQUEsd0JBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUEsY0FBQSxDQUFBLElBQUEsYUFBQSxJQUFBLEVBQUE7QUF1QnVCLE1BQUEsd0JBQUE7QUFBQSxNQUFBLHlCQUFBLFdBQUEsOEJBQUEsR0FBQSxLQUFBLENBQUEsSUFBQSxjQUFBLElBQUEsY0FBQSxDQUFBLElBQUEsVUFBQSxDQUFBO0FBSXZCLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsNEJBQUEsQ0FBQSxJQUFBLGNBQUEsQ0FBQSxJQUFBLGNBQUEsT0FBQSxFQUFBLGFBQUEsSUFBQSxFQUFBO0FBd05BLE1BQUEsd0JBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUEsY0FBQSxDQUFBLElBQUEsY0FBQSxPQUFBLEVBQUEsYUFBQSxJQUFBLEVBQUE7OztJQWpTRjtJQUFZO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFDWkU7SUFBWTtJQUFBO0lBQUE7SUFBQTtJQUNaO0lBQ0FKO0lBQ0E7SUFDQUM7SUFDQTtJQUFVO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0VBQUEsR0FBQSxlQUFBLEVBQUEsQ0FBQTs7O2dGQXlTRCxLQUFHLENBQUE7VUFuVGZJO1dBQVU7TUFDVCxVQUFVO01BQ1YsWUFBWTtNQUNaLFNBQVM7UUFDUDtRQUNBRDtRQUNBO1FBQ0FKO1FBQ0E7UUFDQUM7UUFDQTs7TUFFRixlQUFlLGtCQUFrQjtNQUNqQyxVQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQXFTWDs7OztpRkFDWSxLQUFHLEVBQUEsV0FBQSxPQUFBLFVBQUEsOEJBQUEsWUFBQSxJQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OytEQUFILEtBQUcsRUFBQSxTQUFBLENBQUFLLEtBQUFDLEtBQUEsRUFBQSxHQUFBLENBQUEsY0FBQUgsZUFBQSxjQUFBSixZQUFBLFdBQUFDLGNBQUEsWUFBQUksWUFBQSxpQkFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsWUFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsQ0FBQSxNQUFBLEVBQUEsT0FBQSxNQUFBLFlBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUwzVWhCLFNBQVMsY0FBYztBQUd0QixPQUFlLFNBQVM7QUFDeEIsT0FBZSxTQUFTO0FBQ3hCLE9BQWUsVUFBVTtBQUFBLEVBQ3hCLEtBQUssRUFBRSxPQUFPLE9BQVU7QUFBQSxFQUN4QixTQUFTO0FBQUEsRUFDVCxVQUFVLFNBQVMsSUFBUztBQUFFLGVBQVcsSUFBSSxDQUFDO0FBQUEsRUFBRztBQUNuRDtBQUVBLElBQUksWUFBWSxZQUFZO0FBQzFCLFVBQVEsTUFBTSxNQUFNO0FBQUEsRUFBQztBQUNyQixVQUFRLFFBQVEsTUFBTTtBQUFBLEVBQUM7QUFDdkIsVUFBUSxPQUFPLE1BQU07QUFBQSxFQUFDO0FBQ3RCLFVBQVEsT0FBTyxNQUFNO0FBQUEsRUFBQztBQUN4QjtBQUVBLHFCQUFxQixLQUFLLFNBQVMsRUFBRSxNQUFNLENBQUMsUUFBUSxRQUFRLE1BQU0sR0FBRyxDQUFDOyIsIm5hbWVzIjpbImluamVjdCIsImluamVjdCIsIkNvbXBvbmVudCIsImluamVjdCIsIlJvdXRlck1vZHVsZSIsIlJvdXRlciIsIkx1Y2lkZVphcCIsIkx1Y2lkZUdsb2JlIiwiaW5qZWN0IiwiUm91dGVyIiwiUm91dGVyTW9kdWxlIiwiQ29tcG9uZW50IiwiaTAiLCJpMSJdLCJkZWJ1Z0lkIjoiMWM0ODMxMTctYTUwMy01NTJkLWJkM2MtYTk1ZDE3NzlkZTc4In0=