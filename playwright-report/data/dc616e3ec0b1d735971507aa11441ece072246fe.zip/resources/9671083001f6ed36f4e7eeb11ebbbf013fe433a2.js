import { t as _defineProperty } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/defineProperty-wQpB4Zl9.js?v=cf17c1b4";
import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
import { Ec as Injector, Ei as provideAppInitializer, El as ɵɵdefineInjector, Fn as Injectable, Hc as RuntimeError, Pc as NgZone, Tc as InjectionToken, Tl as ɵɵdefineInjectable, Ui as setClassMetadata, fl as makeEnvironmentProviders, kl as ɵɵinject, no as ɵɵdefineNgModule, ol as inject, qn as NgModule, tl as formatRuntimeError, tn as ApplicationRef } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/core-BV_jmGG7.js?v=cf17c1b4";
import { Et as take, Qt as filter, Wn as Subject, Yn as Observable, fn as map, x as switchMap } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zipWith-DkrnN79P.js?v=cf17c1b4";
import { a as NEVER } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/esm5-1bPjeIHk.js?v=cf17c1b4";
//#region node_modules/@angular/service-worker/fesm2022/service-worker.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _SwPush;
var _SwUpdate;
var _ServiceWorkerModule;
var ERR_SW_NOT_SUPPORTED = "Service workers are disabled or not supported by this browser";
var NgswCommChannel = class {
	constructor(serviceWorker, injector) {
		_defineProperty(this, "serviceWorker", void 0);
		_defineProperty(this, "worker", void 0);
		_defineProperty(this, "registration", void 0);
		_defineProperty(this, "events", void 0);
		this.serviceWorker = serviceWorker;
		if (!serviceWorker) this.worker = this.events = this.registration = new Observable((subscriber) => subscriber.error(new RuntimeError(5601, (typeof ngDevMode === "undefined" || ngDevMode) && ERR_SW_NOT_SUPPORTED)));
		else {
			let currentWorker = null;
			const workerSubject = new Subject();
			this.worker = new Observable((subscriber) => {
				if (currentWorker !== null) subscriber.next(currentWorker);
				return workerSubject.subscribe((v) => subscriber.next(v));
			});
			const updateController = () => {
				const { controller } = serviceWorker;
				if (controller === null) return;
				currentWorker = controller;
				workerSubject.next(currentWorker);
			};
			serviceWorker.addEventListener("controllerchange", updateController);
			updateController();
			this.registration = this.worker.pipe(switchMap(() => serviceWorker.getRegistration().then((registration) => {
				if (!registration) throw new RuntimeError(5601, (typeof ngDevMode === "undefined" || ngDevMode) && ERR_SW_NOT_SUPPORTED);
				return registration;
			})));
			const _events = new Subject();
			this.events = _events.asObservable();
			const messageListener = (event) => {
				const { data } = event;
				if (data === null || data === void 0 ? void 0 : data.type) _events.next(data);
			};
			serviceWorker.addEventListener("message", messageListener);
			const appRef = injector === null || injector === void 0 ? void 0 : injector.get(ApplicationRef, null, { optional: true });
			appRef === null || appRef === void 0 || appRef.onDestroy(() => {
				serviceWorker.removeEventListener("controllerchange", updateController);
				serviceWorker.removeEventListener("message", messageListener);
			});
		}
	}
	postMessage(action, payload) {
		return new Promise((resolve) => {
			this.worker.pipe(take(1)).subscribe((sw) => {
				sw.postMessage(_objectSpread2({ action }, payload));
				resolve();
			});
		});
	}
	postMessageWithOperation(type, payload, operationNonce) {
		const waitForOperationCompleted = this.waitForOperationCompleted(operationNonce);
		const postMessage = this.postMessage(type, payload);
		return Promise.all([postMessage, waitForOperationCompleted]).then(([, result]) => result);
	}
	generateNonce() {
		return Math.round(Math.random() * 1e7);
	}
	eventsOfType(type) {
		let filterFn;
		if (typeof type === "string") filterFn = (event) => event.type === type;
		else filterFn = (event) => type.includes(event.type);
		return this.events.pipe(filter(filterFn));
	}
	nextEventOfType(type) {
		return this.eventsOfType(type).pipe(take(1));
	}
	waitForOperationCompleted(nonce) {
		return new Promise((resolve, reject) => {
			this.eventsOfType("OPERATION_COMPLETED").pipe(filter((event) => event.nonce === nonce), take(1), map((event) => {
				if (event.result !== void 0) return event.result;
				throw new Error(event.error);
			})).subscribe({
				next: resolve,
				error: reject
			});
		});
	}
	get isEnabled() {
		return !!this.serviceWorker;
	}
};
var SwPush = class {
	get isEnabled() {
		return this.sw.isEnabled;
	}
	constructor(sw) {
		_defineProperty(this, "sw", void 0);
		_defineProperty(this, "messages", void 0);
		_defineProperty(this, "notificationClicks", void 0);
		_defineProperty(this, "notificationCloses", void 0);
		_defineProperty(this, "pushSubscriptionChanges", void 0);
		_defineProperty(this, "subscription", void 0);
		_defineProperty(this, "pushManager", null);
		_defineProperty(this, "subscriptionChanges", new Subject());
		this.sw = sw;
		if (!sw.isEnabled) {
			this.messages = NEVER;
			this.notificationClicks = NEVER;
			this.notificationCloses = NEVER;
			this.pushSubscriptionChanges = NEVER;
			this.subscription = NEVER;
			return;
		}
		this.messages = this.sw.eventsOfType("PUSH").pipe(map((message) => message.data));
		this.notificationClicks = this.sw.eventsOfType("NOTIFICATION_CLICK").pipe(map((message) => message.data));
		this.notificationCloses = this.sw.eventsOfType("NOTIFICATION_CLOSE").pipe(map((message) => message.data));
		this.pushSubscriptionChanges = this.sw.eventsOfType("PUSH_SUBSCRIPTION_CHANGE").pipe(map((message) => message.data));
		this.pushManager = this.sw.registration.pipe(map((registration) => registration.pushManager));
		const workerDrivenSubscriptions = this.pushManager.pipe(switchMap((pm) => pm.getSubscription()));
		this.subscription = new Observable((subscriber) => {
			const workerDrivenSubscription = workerDrivenSubscriptions.subscribe(subscriber);
			const subscriptionChanges = this.subscriptionChanges.subscribe(subscriber);
			return () => {
				workerDrivenSubscription.unsubscribe();
				subscriptionChanges.unsubscribe();
			};
		});
	}
	requestSubscription(options) {
		if (!this.sw.isEnabled || this.pushManager === null) return Promise.reject(/* @__PURE__ */ new Error(ERR_SW_NOT_SUPPORTED));
		const pushOptions = { userVisibleOnly: true };
		let key = this.decodeBase64(options.serverPublicKey.replace(/_/g, "/").replace(/-/g, "+"));
		let applicationServerKey = new Uint8Array(new ArrayBuffer(key.length));
		for (let i = 0; i < key.length; i++) applicationServerKey[i] = key.charCodeAt(i);
		pushOptions.applicationServerKey = applicationServerKey;
		return new Promise((resolve, reject) => {
			this.pushManager.pipe(switchMap((pm) => pm.subscribe(pushOptions)), take(1)).subscribe({
				next: (sub) => {
					this.subscriptionChanges.next(sub);
					resolve(sub);
				},
				error: reject
			});
		});
	}
	unsubscribe() {
		if (!this.sw.isEnabled) return Promise.reject(/* @__PURE__ */ new Error(ERR_SW_NOT_SUPPORTED));
		const doUnsubscribe = (sub) => {
			if (sub === null) throw new RuntimeError(5602, (typeof ngDevMode === "undefined" || ngDevMode) && "Not subscribed to push notifications.");
			return sub.unsubscribe().then((success) => {
				if (!success) throw new RuntimeError(5603, (typeof ngDevMode === "undefined" || ngDevMode) && "Unsubscribe failed!");
				this.subscriptionChanges.next(null);
			});
		};
		return new Promise((resolve, reject) => {
			this.subscription.pipe(take(1), switchMap(doUnsubscribe)).subscribe({
				next: resolve,
				error: reject
			});
		});
	}
	decodeBase64(input) {
		return atob(input);
	}
};
_SwPush = SwPush;
_defineProperty(SwPush, "ɵfac", function SwPush_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _SwPush)(ɵɵinject(NgswCommChannel));
});
_defineProperty(SwPush, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _SwPush,
	factory: _SwPush.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SwPush, [{ type: Injectable }], () => [{ type: NgswCommChannel }], null);
})();
var SwUpdate = class {
	get isEnabled() {
		return this.sw.isEnabled;
	}
	constructor(sw) {
		_defineProperty(this, "sw", void 0);
		_defineProperty(this, "versionUpdates", void 0);
		_defineProperty(this, "unrecoverable", void 0);
		_defineProperty(this, "ongoingCheckForUpdate", null);
		this.sw = sw;
		if (!sw.isEnabled) {
			this.versionUpdates = NEVER;
			this.unrecoverable = NEVER;
			return;
		}
		this.versionUpdates = this.sw.eventsOfType([
			"VERSION_DETECTED",
			"VERSION_INSTALLATION_FAILED",
			"VERSION_READY",
			"NO_NEW_VERSION_DETECTED"
		]);
		this.unrecoverable = this.sw.eventsOfType("UNRECOVERABLE_STATE");
	}
	checkForUpdate() {
		if (!this.sw.isEnabled) return Promise.reject(/* @__PURE__ */ new Error(ERR_SW_NOT_SUPPORTED));
		if (this.ongoingCheckForUpdate) return this.ongoingCheckForUpdate;
		const nonce = this.sw.generateNonce();
		this.ongoingCheckForUpdate = this.sw.postMessageWithOperation("CHECK_FOR_UPDATES", { nonce }, nonce).finally(() => {
			this.ongoingCheckForUpdate = null;
		});
		return this.ongoingCheckForUpdate;
	}
	activateUpdate() {
		if (!this.sw.isEnabled) return Promise.reject(new RuntimeError(5601, (typeof ngDevMode === "undefined" || ngDevMode) && ERR_SW_NOT_SUPPORTED));
		const nonce = this.sw.generateNonce();
		return this.sw.postMessageWithOperation("ACTIVATE_UPDATE", { nonce }, nonce);
	}
};
_SwUpdate = SwUpdate;
_defineProperty(SwUpdate, "ɵfac", function SwUpdate_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _SwUpdate)(ɵɵinject(NgswCommChannel));
});
_defineProperty(SwUpdate, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _SwUpdate,
	factory: _SwUpdate.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SwUpdate, [{ type: Injectable }], () => [{ type: NgswCommChannel }], null);
})();
var SCRIPT = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "NGSW_REGISTER_SCRIPT" : "");
function ngswAppInitializer() {
	const options = inject(SwRegistrationOptions);
	if (!("serviceWorker" in navigator && options.enabled !== false)) return;
	const script = inject(SCRIPT);
	const ngZone = inject(NgZone);
	const appRef = inject(ApplicationRef);
	ngZone.runOutsideAngular(() => {
		const sw = navigator.serviceWorker;
		const onControllerChange = () => {
			var _sw$controller;
			return (_sw$controller = sw.controller) === null || _sw$controller === void 0 ? void 0 : _sw$controller.postMessage({ action: "INITIALIZE" });
		};
		sw.addEventListener("controllerchange", onControllerChange);
		appRef.onDestroy(() => {
			sw.removeEventListener("controllerchange", onControllerChange);
		});
	});
	ngZone.runOutsideAngular(() => {
		let readyToRegister;
		const { registrationStrategy } = options;
		if (typeof registrationStrategy === "function") readyToRegister = new Promise((resolve) => registrationStrategy().subscribe(() => resolve()));
		else {
			const [strategy, ...args] = (registrationStrategy || "registerWhenStable:30000").split(":");
			switch (strategy) {
				case "registerImmediately":
					readyToRegister = Promise.resolve();
					break;
				case "registerWithDelay":
					readyToRegister = delayWithTimeout(+args[0] || 0);
					break;
				case "registerWhenStable":
					readyToRegister = Promise.race([appRef.whenStable(), delayWithTimeout(+args[0])]);
					break;
				default: throw new RuntimeError(5600, (typeof ngDevMode === "undefined" || ngDevMode) && `Unknown ServiceWorker registration strategy: ${options.registrationStrategy}`);
			}
		}
		readyToRegister.then(() => {
			if (appRef.destroyed) return;
			navigator.serviceWorker.register(script, {
				scope: options.scope,
				updateViaCache: options.updateViaCache,
				type: options.type
			}).catch((err) => console.error(formatRuntimeError(5604, (typeof ngDevMode === "undefined" || ngDevMode) && "Service worker registration failed with: " + err)));
		});
	});
}
function delayWithTimeout(timeout) {
	return new Promise((resolve) => setTimeout(resolve, timeout));
}
function ngswCommChannelFactory() {
	const opts = inject(SwRegistrationOptions);
	const injector = inject(Injector);
	return new NgswCommChannel(opts.enabled !== false ? navigator.serviceWorker : void 0, injector);
}
var SwRegistrationOptions = class {
	constructor() {
		_defineProperty(this, "enabled", void 0);
		_defineProperty(this, "updateViaCache", void 0);
		_defineProperty(this, "type", void 0);
		_defineProperty(this, "scope", void 0);
		_defineProperty(this, "registrationStrategy", void 0);
	}
};
function provideServiceWorker(script, options = {}) {
	return makeEnvironmentProviders([
		SwPush,
		SwUpdate,
		{
			provide: SCRIPT,
			useValue: script
		},
		{
			provide: SwRegistrationOptions,
			useValue: options
		},
		{
			provide: NgswCommChannel,
			useFactory: ngswCommChannelFactory
		},
		provideAppInitializer(ngswAppInitializer)
	]);
}
var ServiceWorkerModule = class ServiceWorkerModule {
	static register(script, options = {}) {
		return {
			ngModule: ServiceWorkerModule,
			providers: [provideServiceWorker(script, options)]
		};
	}
};
_ServiceWorkerModule = ServiceWorkerModule;
_defineProperty(ServiceWorkerModule, "ɵfac", function ServiceWorkerModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ServiceWorkerModule)();
});
_defineProperty(ServiceWorkerModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({ type: _ServiceWorkerModule }));
_defineProperty(ServiceWorkerModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({ providers: [SwPush, SwUpdate] }));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ServiceWorkerModule, [{
		type: NgModule,
		args: [{ providers: [SwPush, SwUpdate] }]
	}], null, null);
})();
//#endregion
export { ServiceWorkerModule, SwPush, SwRegistrationOptions, SwUpdate, provideServiceWorker };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGFuZ3VsYXJfc2VydmljZS13b3JrZXIuanMiLCJuYW1lcyI6WyJfUnVudGltZUVycm9yIiwiU3dQdXNoIiwiaTAuybXJtWluamVjdCIsImkwLsm1c2V0Q2xhc3NNZXRhZGF0YSIsIlN3VXBkYXRlIiwiX2Zvcm1hdFJ1bnRpbWVFcnJvciIsIlNlcnZpY2VXb3JrZXJNb2R1bGUiXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvc2VydmljZS13b3JrZXIvZmVzbTIwMjIvc2VydmljZS13b3JrZXIubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2UgQW5ndWxhciB2MjIuMS4yXG4gKiAoYykgMjAxMC0yMDI2IEdvb2dsZSBMTEMuIGh0dHBzOi8vYW5ndWxhci5kZXYvXG4gKiBMaWNlbnNlOiBNSVRcbiAqL1xuXG5pbXBvcnQgKiBhcyBpMCBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IMm1UnVudGltZUVycm9yIGFzIF9SdW50aW1lRXJyb3IsIEFwcGxpY2F0aW9uUmVmLCBJbmplY3RhYmxlLCBtYWtlRW52aXJvbm1lbnRQcm92aWRlcnMsIEluamVjdGlvblRva2VuLCBwcm92aWRlQXBwSW5pdGlhbGl6ZXIsIGluamVjdCwgSW5qZWN0b3IsIE5nWm9uZSwgybVmb3JtYXRSdW50aW1lRXJyb3IgYXMgX2Zvcm1hdFJ1bnRpbWVFcnJvciwgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE9ic2VydmFibGUsIFN1YmplY3QsIE5FVkVSIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBzd2l0Y2hNYXAsIHRha2UsIGZpbHRlciwgbWFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuY29uc3QgRVJSX1NXX05PVF9TVVBQT1JURUQgPSAnU2VydmljZSB3b3JrZXJzIGFyZSBkaXNhYmxlZCBvciBub3Qgc3VwcG9ydGVkIGJ5IHRoaXMgYnJvd3Nlcic7XG5jbGFzcyBOZ3N3Q29tbUNoYW5uZWwge1xuICBzZXJ2aWNlV29ya2VyO1xuICB3b3JrZXI7XG4gIHJlZ2lzdHJhdGlvbjtcbiAgZXZlbnRzO1xuICBjb25zdHJ1Y3RvcihzZXJ2aWNlV29ya2VyLCBpbmplY3Rvcikge1xuICAgIHRoaXMuc2VydmljZVdvcmtlciA9IHNlcnZpY2VXb3JrZXI7XG4gICAgaWYgKCFzZXJ2aWNlV29ya2VyKSB7XG4gICAgICB0aGlzLndvcmtlciA9IHRoaXMuZXZlbnRzID0gdGhpcy5yZWdpc3RyYXRpb24gPSBuZXcgT2JzZXJ2YWJsZShzdWJzY3JpYmVyID0+IHN1YnNjcmliZXIuZXJyb3IobmV3IF9SdW50aW1lRXJyb3IoNTYwMSwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgRVJSX1NXX05PVF9TVVBQT1JURUQpKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCBjdXJyZW50V29ya2VyID0gbnVsbDtcbiAgICAgIGNvbnN0IHdvcmtlclN1YmplY3QgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgdGhpcy53b3JrZXIgPSBuZXcgT2JzZXJ2YWJsZShzdWJzY3JpYmVyID0+IHtcbiAgICAgICAgaWYgKGN1cnJlbnRXb3JrZXIgIT09IG51bGwpIHtcbiAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoY3VycmVudFdvcmtlcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHdvcmtlclN1YmplY3Quc3Vic2NyaWJlKHYgPT4gc3Vic2NyaWJlci5uZXh0KHYpKTtcbiAgICAgIH0pO1xuICAgICAgY29uc3QgdXBkYXRlQ29udHJvbGxlciA9ICgpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGNvbnRyb2xsZXJcbiAgICAgICAgfSA9IHNlcnZpY2VXb3JrZXI7XG4gICAgICAgIGlmIChjb250cm9sbGVyID09PSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRXb3JrZXIgPSBjb250cm9sbGVyO1xuICAgICAgICB3b3JrZXJTdWJqZWN0Lm5leHQoY3VycmVudFdvcmtlcik7XG4gICAgICB9O1xuICAgICAgc2VydmljZVdvcmtlci5hZGRFdmVudExpc3RlbmVyKCdjb250cm9sbGVyY2hhbmdlJywgdXBkYXRlQ29udHJvbGxlcik7XG4gICAgICB1cGRhdGVDb250cm9sbGVyKCk7XG4gICAgICB0aGlzLnJlZ2lzdHJhdGlvbiA9IHRoaXMud29ya2VyLnBpcGUoc3dpdGNoTWFwKCgpID0+IHNlcnZpY2VXb3JrZXIuZ2V0UmVnaXN0cmF0aW9uKCkudGhlbihyZWdpc3RyYXRpb24gPT4ge1xuICAgICAgICBpZiAoIXJlZ2lzdHJhdGlvbikge1xuICAgICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDU2MDEsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIEVSUl9TV19OT1RfU1VQUE9SVEVEKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVnaXN0cmF0aW9uO1xuICAgICAgfSkpKTtcbiAgICAgIGNvbnN0IF9ldmVudHMgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgdGhpcy5ldmVudHMgPSBfZXZlbnRzLmFzT2JzZXJ2YWJsZSgpO1xuICAgICAgY29uc3QgbWVzc2FnZUxpc3RlbmVyID0gZXZlbnQgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgZGF0YVxuICAgICAgICB9ID0gZXZlbnQ7XG4gICAgICAgIGlmIChkYXRhPy50eXBlKSB7XG4gICAgICAgICAgX2V2ZW50cy5uZXh0KGRhdGEpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgc2VydmljZVdvcmtlci5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgbWVzc2FnZUxpc3RlbmVyKTtcbiAgICAgIGNvbnN0IGFwcFJlZiA9IGluamVjdG9yPy5nZXQoQXBwbGljYXRpb25SZWYsIG51bGwsIHtcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICAgIH0pO1xuICAgICAgYXBwUmVmPy5vbkRlc3Ryb3koKCkgPT4ge1xuICAgICAgICBzZXJ2aWNlV29ya2VyLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbnRyb2xsZXJjaGFuZ2UnLCB1cGRhdGVDb250cm9sbGVyKTtcbiAgICAgICAgc2VydmljZVdvcmtlci5yZW1vdmVFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgbWVzc2FnZUxpc3RlbmVyKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBwb3N0TWVzc2FnZShhY3Rpb24sIHBheWxvYWQpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICB0aGlzLndvcmtlci5waXBlKHRha2UoMSkpLnN1YnNjcmliZShzdyA9PiB7XG4gICAgICAgIHN3LnBvc3RNZXNzYWdlKHtcbiAgICAgICAgICBhY3Rpb24sXG4gICAgICAgICAgLi4ucGF5bG9hZFxuICAgICAgICB9KTtcbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgcG9zdE1lc3NhZ2VXaXRoT3BlcmF0aW9uKHR5cGUsIHBheWxvYWQsIG9wZXJhdGlvbk5vbmNlKSB7XG4gICAgY29uc3Qgd2FpdEZvck9wZXJhdGlvbkNvbXBsZXRlZCA9IHRoaXMud2FpdEZvck9wZXJhdGlvbkNvbXBsZXRlZChvcGVyYXRpb25Ob25jZSk7XG4gICAgY29uc3QgcG9zdE1lc3NhZ2UgPSB0aGlzLnBvc3RNZXNzYWdlKHR5cGUsIHBheWxvYWQpO1xuICAgIHJldHVybiBQcm9taXNlLmFsbChbcG9zdE1lc3NhZ2UsIHdhaXRGb3JPcGVyYXRpb25Db21wbGV0ZWRdKS50aGVuKChbLCByZXN1bHRdKSA9PiByZXN1bHQpO1xuICB9XG4gIGdlbmVyYXRlTm9uY2UoKSB7XG4gICAgcmV0dXJuIE1hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIDEwMDAwMDAwKTtcbiAgfVxuICBldmVudHNPZlR5cGUodHlwZSkge1xuICAgIGxldCBmaWx0ZXJGbjtcbiAgICBpZiAodHlwZW9mIHR5cGUgPT09ICdzdHJpbmcnKSB7XG4gICAgICBmaWx0ZXJGbiA9IGV2ZW50ID0+IGV2ZW50LnR5cGUgPT09IHR5cGU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpbHRlckZuID0gZXZlbnQgPT4gdHlwZS5pbmNsdWRlcyhldmVudC50eXBlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZXZlbnRzLnBpcGUoZmlsdGVyKGZpbHRlckZuKSk7XG4gIH1cbiAgbmV4dEV2ZW50T2ZUeXBlKHR5cGUpIHtcbiAgICByZXR1cm4gdGhpcy5ldmVudHNPZlR5cGUodHlwZSkucGlwZSh0YWtlKDEpKTtcbiAgfVxuICB3YWl0Rm9yT3BlcmF0aW9uQ29tcGxldGVkKG5vbmNlKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMuZXZlbnRzT2ZUeXBlKCdPUEVSQVRJT05fQ09NUExFVEVEJykucGlwZShmaWx0ZXIoZXZlbnQgPT4gZXZlbnQubm9uY2UgPT09IG5vbmNlKSwgdGFrZSgxKSwgbWFwKGV2ZW50ID0+IHtcbiAgICAgICAgaWYgKGV2ZW50LnJlc3VsdCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgcmV0dXJuIGV2ZW50LnJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZXZlbnQuZXJyb3IpO1xuICAgICAgfSkpLnN1YnNjcmliZSh7XG4gICAgICAgIG5leHQ6IHJlc29sdmUsXG4gICAgICAgIGVycm9yOiByZWplY3RcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGdldCBpc0VuYWJsZWQoKSB7XG4gICAgcmV0dXJuICEhdGhpcy5zZXJ2aWNlV29ya2VyO1xuICB9XG59XG5jbGFzcyBTd1B1c2gge1xuICBzdztcbiAgbWVzc2FnZXM7XG4gIG5vdGlmaWNhdGlvbkNsaWNrcztcbiAgbm90aWZpY2F0aW9uQ2xvc2VzO1xuICBwdXNoU3Vic2NyaXB0aW9uQ2hhbmdlcztcbiAgc3Vic2NyaXB0aW9uO1xuICBnZXQgaXNFbmFibGVkKCkge1xuICAgIHJldHVybiB0aGlzLnN3LmlzRW5hYmxlZDtcbiAgfVxuICBwdXNoTWFuYWdlciA9IG51bGw7XG4gIHN1YnNjcmlwdGlvbkNoYW5nZXMgPSBuZXcgU3ViamVjdCgpO1xuICBjb25zdHJ1Y3Rvcihzdykge1xuICAgIHRoaXMuc3cgPSBzdztcbiAgICBpZiAoIXN3LmlzRW5hYmxlZCkge1xuICAgICAgdGhpcy5tZXNzYWdlcyA9IE5FVkVSO1xuICAgICAgdGhpcy5ub3RpZmljYXRpb25DbGlja3MgPSBORVZFUjtcbiAgICAgIHRoaXMubm90aWZpY2F0aW9uQ2xvc2VzID0gTkVWRVI7XG4gICAgICB0aGlzLnB1c2hTdWJzY3JpcHRpb25DaGFuZ2VzID0gTkVWRVI7XG4gICAgICB0aGlzLnN1YnNjcmlwdGlvbiA9IE5FVkVSO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLm1lc3NhZ2VzID0gdGhpcy5zdy5ldmVudHNPZlR5cGUoJ1BVU0gnKS5waXBlKG1hcChtZXNzYWdlID0+IG1lc3NhZ2UuZGF0YSkpO1xuICAgIHRoaXMubm90aWZpY2F0aW9uQ2xpY2tzID0gdGhpcy5zdy5ldmVudHNPZlR5cGUoJ05PVElGSUNBVElPTl9DTElDSycpLnBpcGUobWFwKG1lc3NhZ2UgPT4gbWVzc2FnZS5kYXRhKSk7XG4gICAgdGhpcy5ub3RpZmljYXRpb25DbG9zZXMgPSB0aGlzLnN3LmV2ZW50c09mVHlwZSgnTk9USUZJQ0FUSU9OX0NMT1NFJykucGlwZShtYXAobWVzc2FnZSA9PiBtZXNzYWdlLmRhdGEpKTtcbiAgICB0aGlzLnB1c2hTdWJzY3JpcHRpb25DaGFuZ2VzID0gdGhpcy5zdy5ldmVudHNPZlR5cGUoJ1BVU0hfU1VCU0NSSVBUSU9OX0NIQU5HRScpLnBpcGUobWFwKG1lc3NhZ2UgPT4gbWVzc2FnZS5kYXRhKSk7XG4gICAgdGhpcy5wdXNoTWFuYWdlciA9IHRoaXMuc3cucmVnaXN0cmF0aW9uLnBpcGUobWFwKHJlZ2lzdHJhdGlvbiA9PiByZWdpc3RyYXRpb24ucHVzaE1hbmFnZXIpKTtcbiAgICBjb25zdCB3b3JrZXJEcml2ZW5TdWJzY3JpcHRpb25zID0gdGhpcy5wdXNoTWFuYWdlci5waXBlKHN3aXRjaE1hcChwbSA9PiBwbS5nZXRTdWJzY3JpcHRpb24oKSkpO1xuICAgIHRoaXMuc3Vic2NyaXB0aW9uID0gbmV3IE9ic2VydmFibGUoc3Vic2NyaWJlciA9PiB7XG4gICAgICBjb25zdCB3b3JrZXJEcml2ZW5TdWJzY3JpcHRpb24gPSB3b3JrZXJEcml2ZW5TdWJzY3JpcHRpb25zLnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgIGNvbnN0IHN1YnNjcmlwdGlvbkNoYW5nZXMgPSB0aGlzLnN1YnNjcmlwdGlvbkNoYW5nZXMuc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgd29ya2VyRHJpdmVuU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIHN1YnNjcmlwdGlvbkNoYW5nZXMudW5zdWJzY3JpYmUoKTtcbiAgICAgIH07XG4gICAgfSk7XG4gIH1cbiAgcmVxdWVzdFN1YnNjcmlwdGlvbihvcHRpb25zKSB7XG4gICAgaWYgKCF0aGlzLnN3LmlzRW5hYmxlZCB8fCB0aGlzLnB1c2hNYW5hZ2VyID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKEVSUl9TV19OT1RfU1VQUE9SVEVEKSk7XG4gICAgfVxuICAgIGNvbnN0IHB1c2hPcHRpb25zID0ge1xuICAgICAgdXNlclZpc2libGVPbmx5OiB0cnVlXG4gICAgfTtcbiAgICBsZXQga2V5ID0gdGhpcy5kZWNvZGVCYXNlNjQob3B0aW9ucy5zZXJ2ZXJQdWJsaWNLZXkucmVwbGFjZSgvXy9nLCAnLycpLnJlcGxhY2UoLy0vZywgJysnKSk7XG4gICAgbGV0IGFwcGxpY2F0aW9uU2VydmVyS2V5ID0gbmV3IFVpbnQ4QXJyYXkobmV3IEFycmF5QnVmZmVyKGtleS5sZW5ndGgpKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGtleS5sZW5ndGg7IGkrKykge1xuICAgICAgYXBwbGljYXRpb25TZXJ2ZXJLZXlbaV0gPSBrZXkuY2hhckNvZGVBdChpKTtcbiAgICB9XG4gICAgcHVzaE9wdGlvbnMuYXBwbGljYXRpb25TZXJ2ZXJLZXkgPSBhcHBsaWNhdGlvblNlcnZlcktleTtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5wdXNoTWFuYWdlci5waXBlKHN3aXRjaE1hcChwbSA9PiBwbS5zdWJzY3JpYmUocHVzaE9wdGlvbnMpKSwgdGFrZSgxKSkuc3Vic2NyaWJlKHtcbiAgICAgICAgbmV4dDogc3ViID0+IHtcbiAgICAgICAgICB0aGlzLnN1YnNjcmlwdGlvbkNoYW5nZXMubmV4dChzdWIpO1xuICAgICAgICAgIHJlc29sdmUoc3ViKTtcbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IHJlamVjdFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgdW5zdWJzY3JpYmUoKSB7XG4gICAgaWYgKCF0aGlzLnN3LmlzRW5hYmxlZCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihFUlJfU1dfTk9UX1NVUFBPUlRFRCkpO1xuICAgIH1cbiAgICBjb25zdCBkb1Vuc3Vic2NyaWJlID0gc3ViID0+IHtcbiAgICAgIGlmIChzdWIgPT09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNTYwMiwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgJ05vdCBzdWJzY3JpYmVkIHRvIHB1c2ggbm90aWZpY2F0aW9ucy4nKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdWIudW5zdWJzY3JpYmUoKS50aGVuKHN1Y2Nlc3MgPT4ge1xuICAgICAgICBpZiAoIXN1Y2Nlc3MpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig1NjAzLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiAnVW5zdWJzY3JpYmUgZmFpbGVkIScpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3Vic2NyaXB0aW9uQ2hhbmdlcy5uZXh0KG51bGwpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5zdWJzY3JpcHRpb24ucGlwZSh0YWtlKDEpLCBzd2l0Y2hNYXAoZG9VbnN1YnNjcmliZSkpLnN1YnNjcmliZSh7XG4gICAgICAgIG5leHQ6IHJlc29sdmUsXG4gICAgICAgIGVycm9yOiByZWplY3RcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIGRlY29kZUJhc2U2NChpbnB1dCkge1xuICAgIHJldHVybiBhdG9iKGlucHV0KTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBTd1B1c2hfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBTd1B1c2gpKGkwLsm1ybVpbmplY3QoTmdzd0NvbW1DaGFubmVsKSk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lSW5qZWN0YWJsZSh7XG4gICAgdG9rZW46IFN3UHVzaCxcbiAgICBmYWN0b3J5OiBTd1B1c2guybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShTd1B1c2gsIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBOZ3N3Q29tbUNoYW5uZWxcbiAgfV0sIG51bGwpO1xufSkoKTtcbmNsYXNzIFN3VXBkYXRlIHtcbiAgc3c7XG4gIHZlcnNpb25VcGRhdGVzO1xuICB1bnJlY292ZXJhYmxlO1xuICBnZXQgaXNFbmFibGVkKCkge1xuICAgIHJldHVybiB0aGlzLnN3LmlzRW5hYmxlZDtcbiAgfVxuICBvbmdvaW5nQ2hlY2tGb3JVcGRhdGUgPSBudWxsO1xuICBjb25zdHJ1Y3Rvcihzdykge1xuICAgIHRoaXMuc3cgPSBzdztcbiAgICBpZiAoIXN3LmlzRW5hYmxlZCkge1xuICAgICAgdGhpcy52ZXJzaW9uVXBkYXRlcyA9IE5FVkVSO1xuICAgICAgdGhpcy51bnJlY292ZXJhYmxlID0gTkVWRVI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMudmVyc2lvblVwZGF0ZXMgPSB0aGlzLnN3LmV2ZW50c09mVHlwZShbJ1ZFUlNJT05fREVURUNURUQnLCAnVkVSU0lPTl9JTlNUQUxMQVRJT05fRkFJTEVEJywgJ1ZFUlNJT05fUkVBRFknLCAnTk9fTkVXX1ZFUlNJT05fREVURUNURUQnXSk7XG4gICAgdGhpcy51bnJlY292ZXJhYmxlID0gdGhpcy5zdy5ldmVudHNPZlR5cGUoJ1VOUkVDT1ZFUkFCTEVfU1RBVEUnKTtcbiAgfVxuICBjaGVja0ZvclVwZGF0ZSgpIHtcbiAgICBpZiAoIXRoaXMuc3cuaXNFbmFibGVkKSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKEVSUl9TV19OT1RfU1VQUE9SVEVEKSk7XG4gICAgfVxuICAgIGlmICh0aGlzLm9uZ29pbmdDaGVja0ZvclVwZGF0ZSkge1xuICAgICAgcmV0dXJuIHRoaXMub25nb2luZ0NoZWNrRm9yVXBkYXRlO1xuICAgIH1cbiAgICBjb25zdCBub25jZSA9IHRoaXMuc3cuZ2VuZXJhdGVOb25jZSgpO1xuICAgIHRoaXMub25nb2luZ0NoZWNrRm9yVXBkYXRlID0gdGhpcy5zdy5wb3N0TWVzc2FnZVdpdGhPcGVyYXRpb24oJ0NIRUNLX0ZPUl9VUERBVEVTJywge1xuICAgICAgbm9uY2VcbiAgICB9LCBub25jZSkuZmluYWxseSgoKSA9PiB7XG4gICAgICB0aGlzLm9uZ29pbmdDaGVja0ZvclVwZGF0ZSA9IG51bGw7XG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXMub25nb2luZ0NoZWNrRm9yVXBkYXRlO1xuICB9XG4gIGFjdGl2YXRlVXBkYXRlKCkge1xuICAgIGlmICghdGhpcy5zdy5pc0VuYWJsZWQpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChuZXcgX1J1bnRpbWVFcnJvcig1NjAxLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBFUlJfU1dfTk9UX1NVUFBPUlRFRCkpO1xuICAgIH1cbiAgICBjb25zdCBub25jZSA9IHRoaXMuc3cuZ2VuZXJhdGVOb25jZSgpO1xuICAgIHJldHVybiB0aGlzLnN3LnBvc3RNZXNzYWdlV2l0aE9wZXJhdGlvbignQUNUSVZBVEVfVVBEQVRFJywge1xuICAgICAgbm9uY2VcbiAgICB9LCBub25jZSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gU3dVcGRhdGVfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBTd1VwZGF0ZSkoaTAuybXJtWluamVjdChOZ3N3Q29tbUNoYW5uZWwpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogU3dVcGRhdGUsXG4gICAgZmFjdG9yeTogU3dVcGRhdGUuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShTd1VwZGF0ZSwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlXG4gIH1dLCAoKSA9PiBbe1xuICAgIHR5cGU6IE5nc3dDb21tQ2hhbm5lbFxuICB9XSwgbnVsbCk7XG59KSgpO1xuY29uc3QgU0NSSVBUID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgIT09ICd1bmRlZmluZWQnICYmIG5nRGV2TW9kZSA/ICdOR1NXX1JFR0lTVEVSX1NDUklQVCcgOiAnJyk7XG5mdW5jdGlvbiBuZ3N3QXBwSW5pdGlhbGl6ZXIoKSB7XG4gIGlmICh0eXBlb2YgbmdTZXJ2ZXJNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ1NlcnZlck1vZGUpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3Qgb3B0aW9ucyA9IGluamVjdChTd1JlZ2lzdHJhdGlvbk9wdGlvbnMpO1xuICBpZiAoISgnc2VydmljZVdvcmtlcicgaW4gbmF2aWdhdG9yICYmIG9wdGlvbnMuZW5hYmxlZCAhPT0gZmFsc2UpKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNjcmlwdCA9IGluamVjdChTQ1JJUFQpO1xuICBjb25zdCBuZ1pvbmUgPSBpbmplY3QoTmdab25lKTtcbiAgY29uc3QgYXBwUmVmID0gaW5qZWN0KEFwcGxpY2F0aW9uUmVmKTtcbiAgbmdab25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICBjb25zdCBzdyA9IG5hdmlnYXRvci5zZXJ2aWNlV29ya2VyO1xuICAgIGNvbnN0IG9uQ29udHJvbGxlckNoYW5nZSA9ICgpID0+IHN3LmNvbnRyb2xsZXI/LnBvc3RNZXNzYWdlKHtcbiAgICAgIGFjdGlvbjogJ0lOSVRJQUxJWkUnXG4gICAgfSk7XG4gICAgc3cuYWRkRXZlbnRMaXN0ZW5lcignY29udHJvbGxlcmNoYW5nZScsIG9uQ29udHJvbGxlckNoYW5nZSk7XG4gICAgYXBwUmVmLm9uRGVzdHJveSgoKSA9PiB7XG4gICAgICBzdy5yZW1vdmVFdmVudExpc3RlbmVyKCdjb250cm9sbGVyY2hhbmdlJywgb25Db250cm9sbGVyQ2hhbmdlKTtcbiAgICB9KTtcbiAgfSk7XG4gIG5nWm9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB7XG4gICAgbGV0IHJlYWR5VG9SZWdpc3RlcjtcbiAgICBjb25zdCB7XG4gICAgICByZWdpc3RyYXRpb25TdHJhdGVneVxuICAgIH0gPSBvcHRpb25zO1xuICAgIGlmICh0eXBlb2YgcmVnaXN0cmF0aW9uU3RyYXRlZ3kgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHJlYWR5VG9SZWdpc3RlciA9IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gcmVnaXN0cmF0aW9uU3RyYXRlZ3koKS5zdWJzY3JpYmUoKCkgPT4gcmVzb2x2ZSgpKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IFtzdHJhdGVneSwgLi4uYXJnc10gPSAocmVnaXN0cmF0aW9uU3RyYXRlZ3kgfHwgJ3JlZ2lzdGVyV2hlblN0YWJsZTozMDAwMCcpLnNwbGl0KCc6Jyk7XG4gICAgICBzd2l0Y2ggKHN0cmF0ZWd5KSB7XG4gICAgICAgIGNhc2UgJ3JlZ2lzdGVySW1tZWRpYXRlbHknOlxuICAgICAgICAgIHJlYWR5VG9SZWdpc3RlciA9IFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdyZWdpc3RlcldpdGhEZWxheSc6XG4gICAgICAgICAgcmVhZHlUb1JlZ2lzdGVyID0gZGVsYXlXaXRoVGltZW91dCgrYXJnc1swXSB8fCAwKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAncmVnaXN0ZXJXaGVuU3RhYmxlJzpcbiAgICAgICAgICByZWFkeVRvUmVnaXN0ZXIgPSBQcm9taXNlLnJhY2UoW2FwcFJlZi53aGVuU3RhYmxlKCksIGRlbGF5V2l0aFRpbWVvdXQoK2FyZ3NbMF0pXSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNTYwMCwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgYFVua25vd24gU2VydmljZVdvcmtlciByZWdpc3RyYXRpb24gc3RyYXRlZ3k6ICR7b3B0aW9ucy5yZWdpc3RyYXRpb25TdHJhdGVneX1gKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmVhZHlUb1JlZ2lzdGVyLnRoZW4oKCkgPT4ge1xuICAgICAgaWYgKGFwcFJlZi5kZXN0cm95ZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbmF2aWdhdG9yLnNlcnZpY2VXb3JrZXIucmVnaXN0ZXIoc2NyaXB0LCB7XG4gICAgICAgIHNjb3BlOiBvcHRpb25zLnNjb3BlLFxuICAgICAgICB1cGRhdGVWaWFDYWNoZTogb3B0aW9ucy51cGRhdGVWaWFDYWNoZSxcbiAgICAgICAgdHlwZTogb3B0aW9ucy50eXBlXG4gICAgICB9KS5jYXRjaChlcnIgPT4gY29uc29sZS5lcnJvcihfZm9ybWF0UnVudGltZUVycm9yKDU2MDQsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICdTZXJ2aWNlIHdvcmtlciByZWdpc3RyYXRpb24gZmFpbGVkIHdpdGg6ICcgKyBlcnIpKSk7XG4gICAgfSk7XG4gIH0pO1xufVxuZnVuY3Rpb24gZGVsYXlXaXRoVGltZW91dCh0aW1lb3V0KSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgdGltZW91dCkpO1xufVxuZnVuY3Rpb24gbmdzd0NvbW1DaGFubmVsRmFjdG9yeSgpIHtcbiAgY29uc3Qgb3B0cyA9IGluamVjdChTd1JlZ2lzdHJhdGlvbk9wdGlvbnMpO1xuICBjb25zdCBpbmplY3RvciA9IGluamVjdChJbmplY3Rvcik7XG4gIGNvbnN0IGlzQnJvd3NlciA9ICEodHlwZW9mIG5nU2VydmVyTW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdTZXJ2ZXJNb2RlKTtcbiAgcmV0dXJuIG5ldyBOZ3N3Q29tbUNoYW5uZWwoaXNCcm93c2VyICYmIG9wdHMuZW5hYmxlZCAhPT0gZmFsc2UgPyBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlciA6IHVuZGVmaW5lZCwgaW5qZWN0b3IpO1xufVxuY2xhc3MgU3dSZWdpc3RyYXRpb25PcHRpb25zIHtcbiAgZW5hYmxlZDtcbiAgdXBkYXRlVmlhQ2FjaGU7XG4gIHR5cGU7XG4gIHNjb3BlO1xuICByZWdpc3RyYXRpb25TdHJhdGVneTtcbn1cbmZ1bmN0aW9uIHByb3ZpZGVTZXJ2aWNlV29ya2VyKHNjcmlwdCwgb3B0aW9ucyA9IHt9KSB7XG4gIHJldHVybiBtYWtlRW52aXJvbm1lbnRQcm92aWRlcnMoW1N3UHVzaCwgU3dVcGRhdGUsIHtcbiAgICBwcm92aWRlOiBTQ1JJUFQsXG4gICAgdXNlVmFsdWU6IHNjcmlwdFxuICB9LCB7XG4gICAgcHJvdmlkZTogU3dSZWdpc3RyYXRpb25PcHRpb25zLFxuICAgIHVzZVZhbHVlOiBvcHRpb25zXG4gIH0sIHtcbiAgICBwcm92aWRlOiBOZ3N3Q29tbUNoYW5uZWwsXG4gICAgdXNlRmFjdG9yeTogbmdzd0NvbW1DaGFubmVsRmFjdG9yeVxuICB9LCBwcm92aWRlQXBwSW5pdGlhbGl6ZXIobmdzd0FwcEluaXRpYWxpemVyKV0pO1xufVxuY2xhc3MgU2VydmljZVdvcmtlck1vZHVsZSB7XG4gIHN0YXRpYyByZWdpc3RlcihzY3JpcHQsIG9wdGlvbnMgPSB7fSkge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogU2VydmljZVdvcmtlck1vZHVsZSxcbiAgICAgIHByb3ZpZGVyczogW3Byb3ZpZGVTZXJ2aWNlV29ya2VyKHNjcmlwdCwgb3B0aW9ucyldXG4gICAgfTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBTZXJ2aWNlV29ya2VyTW9kdWxlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBTZXJ2aWNlV29ya2VyTW9kdWxlKSgpO1xuICB9O1xuICBzdGF0aWMgybVtb2QgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lTmdNb2R1bGUoe1xuICAgIHR5cGU6IFNlcnZpY2VXb3JrZXJNb2R1bGVcbiAgfSk7XG4gIHN0YXRpYyDJtWluaiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3Rvcih7XG4gICAgcHJvdmlkZXJzOiBbU3dQdXNoLCBTd1VwZGF0ZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShTZXJ2aWNlV29ya2VyTW9kdWxlLCBbe1xuICAgIHR5cGU6IE5nTW9kdWxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlcnM6IFtTd1B1c2gsIFN3VXBkYXRlXVxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5leHBvcnQgeyBTZXJ2aWNlV29ya2VyTW9kdWxlLCBTd1B1c2gsIFN3UmVnaXN0cmF0aW9uT3B0aW9ucywgU3dVcGRhdGUsIHByb3ZpZGVTZXJ2aWNlV29ya2VyIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFVQSxJQUFNLHVCQUF1QjtBQUM3QixJQUFNLGtCQUFOLE1BQXNCO0NBS3BCLFlBQVksZUFBZSxVQUFVO3dCQUpyQyxpQkFBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7d0JBQ0EsZ0JBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxnQkFBZ0I7RUFDckIsSUFBSSxDQUFDLGVBQ0gsS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLGVBQWUsSUFBSSxZQUFXLGVBQWMsV0FBVyxNQUFNLElBQUlBLGFBQWMsT0FBTyxPQUFPLGNBQWMsZUFBZSxjQUFjLG9CQUFvQixDQUFDLENBQUM7T0FDMUw7R0FDTCxJQUFJLGdCQUFnQjtHQUNwQixNQUFNLGdCQUFnQixJQUFJLFFBQVE7R0FDbEMsS0FBSyxTQUFTLElBQUksWUFBVyxlQUFjO0lBQ3pDLElBQUksa0JBQWtCLE1BQ3BCLFdBQVcsS0FBSyxhQUFhO0lBRS9CLE9BQU8sY0FBYyxXQUFVLE1BQUssV0FBVyxLQUFLLENBQUMsQ0FBQztHQUN4RCxDQUFDO0dBQ0QsTUFBTSx5QkFBeUI7SUFDN0IsTUFBTSxFQUNKLGVBQ0U7SUFDSixJQUFJLGVBQWUsTUFDakI7SUFFRixnQkFBZ0I7SUFDaEIsY0FBYyxLQUFLLGFBQWE7R0FDbEM7R0FDQSxjQUFjLGlCQUFpQixvQkFBb0IsZ0JBQWdCO0dBQ25FLGlCQUFpQjtHQUNqQixLQUFLLGVBQWUsS0FBSyxPQUFPLEtBQUssZ0JBQWdCLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFLLGlCQUFnQjtJQUN4RyxJQUFJLENBQUMsY0FDSCxNQUFNLElBQUlBLGFBQWMsT0FBTyxPQUFPLGNBQWMsZUFBZSxjQUFjLG9CQUFvQjtJQUV2RyxPQUFPO0dBQ1QsQ0FBQyxDQUFDLENBQUM7R0FDSCxNQUFNLFVBQVUsSUFBSSxRQUFRO0dBQzVCLEtBQUssU0FBUyxRQUFRLGFBQWE7R0FDbkMsTUFBTSxtQkFBa0IsVUFBUztJQUMvQixNQUFNLEVBQ0osU0FDRTtJQUNKLElBQUEsU0FBQSxRQUFBLFNBQUEsS0FBQSxJQUFBLEtBQUEsSUFBSSxLQUFNLE1BQ1IsUUFBUSxLQUFLLElBQUk7R0FFckI7R0FDQSxjQUFjLGlCQUFpQixXQUFXLGVBQWU7R0FDekQsTUFBTSxTQUFBLGFBQUEsUUFBQSxhQUFBLEtBQUEsSUFBQSxLQUFBLElBQVMsU0FBVSxJQUFJLGdCQUFnQixNQUFNLEVBQ2pELFVBQVUsS0FDWixDQUFDO0dBQ0QsV0FBQSxRQUFBLFdBQUEsS0FBQSxLQUFBLE9BQVEsZ0JBQWdCO0lBQ3RCLGNBQWMsb0JBQW9CLG9CQUFvQixnQkFBZ0I7SUFDdEUsY0FBYyxvQkFBb0IsV0FBVyxlQUFlO0dBQzlELENBQUM7RUFDSDtDQUNGO0NBQ0EsWUFBWSxRQUFRLFNBQVM7RUFDM0IsT0FBTyxJQUFJLFNBQVEsWUFBVztHQUM1QixLQUFLLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVSxPQUFNO0lBQ3hDLEdBQUcsWUFBQSxlQUFBLEVBQ0QsT0FBQSxHQUNHLE9BQ0wsQ0FBQztJQUNELFFBQVE7R0FDVixDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EseUJBQXlCLE1BQU0sU0FBUyxnQkFBZ0I7RUFDdEQsTUFBTSw0QkFBNEIsS0FBSywwQkFBMEIsY0FBYztFQUMvRSxNQUFNLGNBQWMsS0FBSyxZQUFZLE1BQU0sT0FBTztFQUNsRCxPQUFPLFFBQVEsSUFBSSxDQUFDLGFBQWEseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxZQUFZLE1BQU07Q0FDMUY7Q0FDQSxnQkFBZ0I7RUFDZCxPQUFPLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFRO0NBQzVDO0NBQ0EsYUFBYSxNQUFNO0VBQ2pCLElBQUk7RUFDSixJQUFJLE9BQU8sU0FBUyxVQUNsQixZQUFXLFVBQVMsTUFBTSxTQUFTO09BRW5DLFlBQVcsVUFBUyxLQUFLLFNBQVMsTUFBTSxJQUFJO0VBRTlDLE9BQU8sS0FBSyxPQUFPLEtBQUssT0FBTyxRQUFRLENBQUM7Q0FDMUM7Q0FDQSxnQkFBZ0IsTUFBTTtFQUNwQixPQUFPLEtBQUssYUFBYSxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDO0NBQzdDO0NBQ0EsMEJBQTBCLE9BQU87RUFDL0IsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0dBQ3RDLEtBQUssYUFBYSxxQkFBcUIsQ0FBQyxDQUFDLEtBQUssUUFBTyxVQUFTLE1BQU0sVUFBVSxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsS0FBSSxVQUFTO0lBQzFHLElBQUksTUFBTSxXQUFXLEtBQUEsR0FDbkIsT0FBTyxNQUFNO0lBRWYsTUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFLO0dBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtJQUNaLE1BQU07SUFDTixPQUFPO0dBQ1QsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLElBQUksWUFBWTtFQUNkLE9BQU8sQ0FBQyxDQUFDLEtBQUs7Q0FDaEI7QUFDRjtBQUNBLElBQU0sU0FBTixNQUFhO0NBT1gsSUFBSSxZQUFZO0VBQ2QsT0FBTyxLQUFLLEdBQUc7Q0FDakI7Q0FHQSxZQUFZLElBQUk7d0JBWGhCLE1BQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLHNCQUFBLEtBQUEsQ0FBQTt3QkFDQSxzQkFBQSxLQUFBLENBQUE7d0JBQ0EsMkJBQUEsS0FBQSxDQUFBO3dCQUNBLGdCQUFBLEtBQUEsQ0FBQTt3QkFJQSxlQUFjLElBQUE7d0JBQ2QsdUJBQXNCLElBQUksUUFBUSxDQUFBO0VBRWhDLEtBQUssS0FBSztFQUNWLElBQUksQ0FBQyxHQUFHLFdBQVc7R0FDakIsS0FBSyxXQUFXO0dBQ2hCLEtBQUsscUJBQXFCO0dBQzFCLEtBQUsscUJBQXFCO0dBQzFCLEtBQUssMEJBQTBCO0dBQy9CLEtBQUssZUFBZTtHQUNwQjtFQUNGO0VBQ0EsS0FBSyxXQUFXLEtBQUssR0FBRyxhQUFhLE1BQU0sQ0FBQyxDQUFDLEtBQUssS0FBSSxZQUFXLFFBQVEsSUFBSSxDQUFDO0VBQzlFLEtBQUsscUJBQXFCLEtBQUssR0FBRyxhQUFhLG9CQUFvQixDQUFDLENBQUMsS0FBSyxLQUFJLFlBQVcsUUFBUSxJQUFJLENBQUM7RUFDdEcsS0FBSyxxQkFBcUIsS0FBSyxHQUFHLGFBQWEsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLEtBQUksWUFBVyxRQUFRLElBQUksQ0FBQztFQUN0RyxLQUFLLDBCQUEwQixLQUFLLEdBQUcsYUFBYSwwQkFBMEIsQ0FBQyxDQUFDLEtBQUssS0FBSSxZQUFXLFFBQVEsSUFBSSxDQUFDO0VBQ2pILEtBQUssY0FBYyxLQUFLLEdBQUcsYUFBYSxLQUFLLEtBQUksaUJBQWdCLGFBQWEsV0FBVyxDQUFDO0VBQzFGLE1BQU0sNEJBQTRCLEtBQUssWUFBWSxLQUFLLFdBQVUsT0FBTSxHQUFHLGdCQUFnQixDQUFDLENBQUM7RUFDN0YsS0FBSyxlQUFlLElBQUksWUFBVyxlQUFjO0dBQy9DLE1BQU0sMkJBQTJCLDBCQUEwQixVQUFVLFVBQVU7R0FDL0UsTUFBTSxzQkFBc0IsS0FBSyxvQkFBb0IsVUFBVSxVQUFVO0dBQ3pFLGFBQWE7SUFDWCx5QkFBeUIsWUFBWTtJQUNyQyxvQkFBb0IsWUFBWTtHQUNsQztFQUNGLENBQUM7Q0FDSDtDQUNBLG9CQUFvQixTQUFTO0VBQzNCLElBQUksQ0FBQyxLQUFLLEdBQUcsYUFBYSxLQUFLLGdCQUFnQixNQUM3QyxPQUFPLFFBQVEsdUJBQU8sSUFBSSxNQUFNLG9CQUFvQixDQUFDO0VBRXZELE1BQU0sY0FBYyxFQUNsQixpQkFBaUIsS0FDbkI7RUFDQSxJQUFJLE1BQU0sS0FBSyxhQUFhLFFBQVEsZ0JBQWdCLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLE1BQU0sR0FBRyxDQUFDO0VBQ3pGLElBQUksdUJBQXVCLElBQUksV0FBVyxJQUFJLFlBQVksSUFBSSxNQUFNLENBQUM7RUFDckUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUM5QixxQkFBcUIsS0FBSyxJQUFJLFdBQVcsQ0FBQztFQUU1QyxZQUFZLHVCQUF1QjtFQUNuQyxPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDdEMsS0FBSyxZQUFZLEtBQUssV0FBVSxPQUFNLEdBQUcsVUFBVSxXQUFXLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtJQUNuRixPQUFNLFFBQU87S0FDWCxLQUFLLG9CQUFvQixLQUFLLEdBQUc7S0FDakMsUUFBUSxHQUFHO0lBQ2I7SUFDQSxPQUFPO0dBQ1QsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLGNBQWM7RUFDWixJQUFJLENBQUMsS0FBSyxHQUFHLFdBQ1gsT0FBTyxRQUFRLHVCQUFPLElBQUksTUFBTSxvQkFBb0IsQ0FBQztFQUV2RCxNQUFNLGlCQUFnQixRQUFPO0dBQzNCLElBQUksUUFBUSxNQUNWLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsdUNBQXVDO0dBRTFILE9BQU8sSUFBSSxZQUFZLENBQUMsQ0FBQyxNQUFLLFlBQVc7SUFDdkMsSUFBSSxDQUFDLFNBQ0gsTUFBTSxJQUFJQSxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyxxQkFBcUI7SUFFeEcsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0dBQ3BDLENBQUM7RUFDSDtFQUNBLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztHQUN0QyxLQUFLLGFBQWEsS0FBSyxLQUFLLENBQUMsR0FBRyxVQUFVLGFBQWEsQ0FBQyxDQUFDLENBQUMsVUFBVTtJQUNsRSxNQUFNO0lBQ04sT0FBTztHQUNULENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxhQUFhLE9BQU87RUFDbEIsT0FBTyxLQUFLLEtBQUs7Q0FDbkI7QUFTRjs7d0JBUlMsUUFBTyxTQUFTLGVBQWUsbUJBQW1CO0NBRXZELE9BQU8sS0FBSyxxQkFBcUJDLFNBQVFDLFNBQVksZUFBZSxDQUFDO0FBQ3ZFLENBQUE7d0JBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9EO0NBQ1AsU0FBU0EsUUFBTztBQUNsQixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0UsaUJBQXFCLFFBQVEsQ0FBQyxFQUMvRSxNQUFNLFdBQ1IsQ0FBQyxTQUFTLENBQUMsRUFDVCxNQUFNLGdCQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxXQUFOLE1BQWU7Q0FJYixJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUssR0FBRztDQUNqQjtDQUVBLFlBQVksSUFBSTt3QkFQaEIsTUFBQSxLQUFBLENBQUE7d0JBQ0Esa0JBQUEsS0FBQSxDQUFBO3dCQUNBLGlCQUFBLEtBQUEsQ0FBQTt3QkFJQSx5QkFBd0IsSUFBQTtFQUV0QixLQUFLLEtBQUs7RUFDVixJQUFJLENBQUMsR0FBRyxXQUFXO0dBQ2pCLEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssZ0JBQWdCO0dBQ3JCO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixLQUFLLEdBQUcsYUFBYTtHQUFDO0dBQW9CO0dBQStCO0dBQWlCO0VBQXlCLENBQUM7RUFDMUksS0FBSyxnQkFBZ0IsS0FBSyxHQUFHLGFBQWEscUJBQXFCO0NBQ2pFO0NBQ0EsaUJBQWlCO0VBQ2YsSUFBSSxDQUFDLEtBQUssR0FBRyxXQUNYLE9BQU8sUUFBUSx1QkFBTyxJQUFJLE1BQU0sb0JBQW9CLENBQUM7RUFFdkQsSUFBSSxLQUFLLHVCQUNQLE9BQU8sS0FBSztFQUVkLE1BQU0sUUFBUSxLQUFLLEdBQUcsY0FBYztFQUNwQyxLQUFLLHdCQUF3QixLQUFLLEdBQUcseUJBQXlCLHFCQUFxQixFQUNqRixNQUNGLEdBQUcsS0FBSyxDQUFDLENBQUMsY0FBYztHQUN0QixLQUFLLHdCQUF3QjtFQUMvQixDQUFDO0VBQ0QsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxpQkFBaUI7RUFDZixJQUFJLENBQUMsS0FBSyxHQUFHLFdBQ1gsT0FBTyxRQUFRLE9BQU8sSUFBSUgsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsb0JBQW9CLENBQUM7RUFFeEgsTUFBTSxRQUFRLEtBQUssR0FBRyxjQUFjO0VBQ3BDLE9BQU8sS0FBSyxHQUFHLHlCQUF5QixtQkFBbUIsRUFDekQsTUFDRixHQUFHLEtBQUs7Q0FDVjtBQVNGOzswQkFSUyxRQUFPLFNBQVMsaUJBQWlCLG1CQUFtQjtDQUV6RCxPQUFPLEtBQUsscUJBQXFCSSxXQUFVRixTQUFZLGVBQWUsQ0FBQztBQUN6RSxDQUFBOzBCQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPRTtDQUNQLFNBQVNBLFVBQVM7QUFDcEIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNELGlCQUFxQixVQUFVLENBQUMsRUFDakYsTUFBTSxXQUNSLENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTSxnQkFDUixDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sU0FBUyxJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSx5QkFBeUIsRUFBRTtBQUM3RyxTQUFTLHFCQUFxQjtDQUk1QixNQUFNLFVBQVUsT0FBTyxxQkFBcUI7Q0FDNUMsSUFBSSxFQUFFLG1CQUFtQixhQUFhLFFBQVEsWUFBWSxRQUN4RDtDQUVGLE1BQU0sU0FBUyxPQUFPLE1BQU07Q0FDNUIsTUFBTSxTQUFTLE9BQU8sTUFBTTtDQUM1QixNQUFNLFNBQVMsT0FBTyxjQUFjO0NBQ3BDLE9BQU8sd0JBQXdCO0VBQzdCLE1BQU0sS0FBSyxVQUFVO0VBQ3JCLE1BQU0sMkJBQTJCOzsrQkFBRyxnQkFBQSxRQUFBLG1CQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsZUFBWSxZQUFZLEVBQzFELFFBQVEsYUFDVixDQUFDOztFQUNELEdBQUcsaUJBQWlCLG9CQUFvQixrQkFBa0I7RUFDMUQsT0FBTyxnQkFBZ0I7R0FDckIsR0FBRyxvQkFBb0Isb0JBQW9CLGtCQUFrQjtFQUMvRCxDQUFDO0NBQ0gsQ0FBQztDQUNELE9BQU8sd0JBQXdCO0VBQzdCLElBQUk7RUFDSixNQUFNLEVBQ0oseUJBQ0U7RUFDSixJQUFJLE9BQU8seUJBQXlCLFlBQ2xDLGtCQUFrQixJQUFJLFNBQVEsWUFBVyxxQkFBcUIsQ0FBQyxDQUFDLGdCQUFnQixRQUFRLENBQUMsQ0FBQztPQUNyRjtHQUNMLE1BQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyx3QkFBd0IsMkJBQUEsQ0FBNEIsTUFBTSxHQUFHO0dBQzFGLFFBQVEsVUFBUjtJQUNFLEtBQUs7S0FDSCxrQkFBa0IsUUFBUSxRQUFRO0tBQ2xDO0lBQ0YsS0FBSztLQUNILGtCQUFrQixpQkFBaUIsQ0FBQyxLQUFLLE1BQU0sQ0FBQztLQUNoRDtJQUNGLEtBQUs7S0FDSCxrQkFBa0IsUUFBUSxLQUFLLENBQUMsT0FBTyxXQUFXLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztLQUNoRjtJQUNGLFNBQ0UsTUFBTSxJQUFJSCxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyxnREFBZ0QsUUFBUSxzQkFBc0I7R0FDbks7RUFDRjtFQUNBLGdCQUFnQixXQUFXO0dBQ3pCLElBQUksT0FBTyxXQUNUO0dBRUYsVUFBVSxjQUFjLFNBQVMsUUFBUTtJQUN2QyxPQUFPLFFBQVE7SUFDZixnQkFBZ0IsUUFBUTtJQUN4QixNQUFNLFFBQVE7R0FDaEIsQ0FBQyxDQUFDLENBQUMsT0FBTSxRQUFPLFFBQVEsTUFBTUssbUJBQW9CLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyw4Q0FBOEMsR0FBRyxDQUFDLENBQUM7RUFDaEssQ0FBQztDQUNILENBQUM7QUFDSDtBQUNBLFNBQVMsaUJBQWlCLFNBQVM7Q0FDakMsT0FBTyxJQUFJLFNBQVEsWUFBVyxXQUFXLFNBQVMsT0FBTyxDQUFDO0FBQzVEO0FBQ0EsU0FBUyx5QkFBeUI7Q0FDaEMsTUFBTSxPQUFPLE9BQU8scUJBQXFCO0NBQ3pDLE1BQU0sV0FBVyxPQUFPLFFBQVE7Q0FFaEMsT0FBTyxJQUFJLGdCQUE2QixLQUFLLFlBQVksUUFBUSxVQUFVLGdCQUFnQixLQUFBLEdBQVcsUUFBUTtBQUNoSDtBQUNBLElBQU0sd0JBQU4sTUFBNEI7O3dCQUMxQixXQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBQSxLQUFBLENBQUE7d0JBQ0EsUUFBQSxLQUFBLENBQUE7d0JBQ0EsU0FBQSxLQUFBLENBQUE7d0JBQ0Esd0JBQUEsS0FBQSxDQUFBOztBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUSxVQUFVLENBQUMsR0FBRztDQUNsRCxPQUFPLHlCQUF5QjtFQUFDO0VBQVE7RUFBVTtHQUNqRCxTQUFTO0dBQ1QsVUFBVTtFQUNaO0VBQUc7R0FDRCxTQUFTO0dBQ1QsVUFBVTtFQUNaO0VBQUc7R0FDRCxTQUFTO0dBQ1QsWUFBWTtFQUNkO0VBQUcsc0JBQXNCLGtCQUFrQjtDQUFDLENBQUM7QUFDL0M7QUFDQSxJQUFNLHNCQUFOLE1BQU0sb0JBQW9CO0NBQ3hCLE9BQU8sU0FBUyxRQUFRLFVBQVUsQ0FBQyxHQUFHO0VBQ3BDLE9BQU87R0FDTCxVQUFVO0dBQ1YsV0FBVyxDQUFDLHFCQUFxQixRQUFRLE9BQU8sQ0FBQztFQUNuRDtDQUNGO0FBVUY7O3FDQVRTLFFBQU8sU0FBUyw0QkFBNEIsbUJBQW1CO0NBQ3BFLE9BQU8sS0FBSyxxQkFBcUJDLHNCQUFxQjtBQUN4RCxDQUFBO3FDQUNPLFFBQXNCLGlDQUFvQixFQUMvQyxNQUFNQSxxQkFDUixDQUFDLENBQUE7cUNBQ00sUUFBc0IsaUNBQW9CLEVBQy9DLFdBQVcsQ0FBQyxRQUFRLFFBQVEsRUFDOUIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNILGlCQUFxQixxQkFBcUIsQ0FBQztFQUM1RixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsV0FBVyxDQUFDLFFBQVEsUUFBUSxFQUM5QixDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUcifQ==