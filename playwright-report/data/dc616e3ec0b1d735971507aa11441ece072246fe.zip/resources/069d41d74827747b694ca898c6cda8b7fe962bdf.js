var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b ||= {})
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// apps/client/src/environments/environment.ts
var environment = {
  production: false,
  configUrl: "/brand/config.json",
  apiUrl: typeof window !== "undefined" && window.__env?.apiUrl ? window.__env.apiUrl : "http://localhost:8787"
};

// apps/client/src/app/services/config/config.service.ts
var config_service_exports = {};
__export(config_service_exports, {
  ConfigService: () => ConfigService
});
import { Injectable, signal } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { firstValueFrom } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/rxjs.js?v=cf17c1b4";

// apps/client/src/app/models/branding-config.model.ts
var DEFAULT_BRANDING_CONFIG = {
  whitelabel: false,
  useTradeMark: true,
  brandName: "Signing Room\xAE",
  brandSuffix: ".io",
  brandColorHex: "#10b981",
  tagline: "The secure coordination layer for Bitcoin multisig ceremonies.",
  subTagline: "Multi-Signature Consensus",
  logoUrl: "/brand/logo.svg",
  defaultRoomName: "Signing Room",
  hideFooter: false,
  hideNetworkBadges: false
};

// apps/client/src/app/services/config/config.service.ts
import * as i0 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i1 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common_http.js?v=cf17c1b4";
var ConfigService = class _ConfigService {
  constructor(http) {
    this.http = http;
  }
  http;
  _config = signal(
    DEFAULT_BRANDING_CONFIG,
    ...ngDevMode ? [{ debugName: "_config" }] : (
      /* istanbul ignore next */
      []
    )
  );
  config = this._config.asReadonly();
  loadConfig() {
    return __async(this, null, function* () {
      try {
        const response = yield firstValueFrom(this.http.get(`${environment.configUrl}?t=${Date.now()}`));
        this._config.set(__spreadValues(__spreadValues({}, DEFAULT_BRANDING_CONFIG), response));
        console.log("Brand configuration loaded successfully.");
      } catch (e) {
        console.log("No custom brand config found. Using default SigningRoom branding.");
        this._config.set(DEFAULT_BRANDING_CONFIG);
      }
    });
  }
  get settings() {
    return this._config();
  }
  static \u0275fac = function ConfigService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _ConfigService)(i0.\u0275\u0275inject(i1.HttpClient));
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _ConfigService, factory: _ConfigService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(ConfigService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [{ type: i1.HttpClient }], null);
})();

export {
  __spreadValues,
  __spreadProps,
  __export,
  __async,
  environment,
  ConfigService,
  config_service_exports
};
//# debugId=585eed57-fef3-5f42-ba3f-6140ee25c335


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcHMvY2xpZW50L3NyYy9lbnZpcm9ubWVudHMvZW52aXJvbm1lbnQudHMiLCJhcHBzL2NsaWVudC9zcmMvYXBwL3NlcnZpY2VzL2NvbmZpZy9jb25maWcuc2VydmljZS50cyIsImFwcHMvY2xpZW50L3NyYy9hcHAvbW9kZWxzL2JyYW5kaW5nLWNvbmZpZy5tb2RlbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgZW52aXJvbm1lbnQgPSB7XHJcbiAgcHJvZHVjdGlvbjogZmFsc2UsXHJcbiAgY29uZmlnVXJsOiAnL2JyYW5kL2NvbmZpZy5qc29uJyxcclxuICBhcGlVcmw6XHJcbiAgICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiAod2luZG93IGFzIGFueSkuX19lbnY/LmFwaVVybFxyXG4gICAgICA/ICh3aW5kb3cgYXMgYW55KS5fX2Vudi5hcGlVcmxcclxuICAgICAgOiAnaHR0cDovL2xvY2FsaG9zdDo4Nzg3JyxcclxufTtcclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgc2lnbmFsIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IGZpcnN0VmFsdWVGcm9tIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnLi4vLi4vLi4vZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuaW1wb3J0IHsgQnJhbmRpbmdDb25maWcsIERFRkFVTFRfQlJBTkRJTkdfQ09ORklHIH0gZnJvbSAnLi4vLi4vbW9kZWxzL2JyYW5kaW5nLWNvbmZpZy5tb2RlbCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgQ29uZmlnU2VydmljZSB7XHJcbiAgcHJpdmF0ZSByZWFkb25seSBfY29uZmlnID0gc2lnbmFsPEJyYW5kaW5nQ29uZmlnPihERUZBVUxUX0JSQU5ESU5HX0NPTkZJRyk7XHJcbiAgcHVibGljIHJlYWRvbmx5IGNvbmZpZyA9IHRoaXMuX2NvbmZpZy5hc1JlYWRvbmx5KCk7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgaHR0cDogSHR0cENsaWVudCkge31cclxuXHJcbiAgYXN5bmMgbG9hZENvbmZpZygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmlyc3RWYWx1ZUZyb20oXHJcbiAgICAgICAgdGhpcy5odHRwLmdldDxQYXJ0aWFsPEJyYW5kaW5nQ29uZmlnPj4oYCR7ZW52aXJvbm1lbnQuY29uZmlnVXJsfT90PSR7RGF0ZS5ub3coKX1gKSxcclxuICAgICAgKTtcclxuICAgICAgdGhpcy5fY29uZmlnLnNldCh7IC4uLkRFRkFVTFRfQlJBTkRJTkdfQ09ORklHLCAuLi5yZXNwb25zZSB9KTtcclxuICAgICAgY29uc29sZS5sb2coJ0JyYW5kIGNvbmZpZ3VyYXRpb24gbG9hZGVkIHN1Y2Nlc3NmdWxseS4nKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBjb25zb2xlLmxvZygnTm8gY3VzdG9tIGJyYW5kIGNvbmZpZyBmb3VuZC4gVXNpbmcgZGVmYXVsdCBTaWduaW5nUm9vbSBicmFuZGluZy4nKTtcclxuICAgICAgdGhpcy5fY29uZmlnLnNldChERUZBVUxUX0JSQU5ESU5HX0NPTkZJRyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXQgc2V0dGluZ3MoKTogQnJhbmRpbmdDb25maWcge1xyXG4gICAgcmV0dXJuIHRoaXMuX2NvbmZpZygpO1xyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgaW50ZXJmYWNlIEJyYW5kaW5nQ29uZmlnIHtcclxuICB3aGl0ZWxhYmVsOiBib29sZWFuO1xyXG4gIHVzZVRyYWRlTWFyazogYm9vbGVhbjtcclxuICBicmFuZE5hbWU6IHN0cmluZztcclxuICBicmFuZFN1ZmZpeD86IHN0cmluZztcclxuICBicmFuZENvbG9ySGV4OiBzdHJpbmc7XHJcbiAgdGFnbGluZTogc3RyaW5nO1xyXG4gIHN1YlRhZ2xpbmU6IHN0cmluZztcclxuICBsb2dvVXJsOiBzdHJpbmc7XHJcbiAgZGVmYXVsdFJvb21OYW1lOiBzdHJpbmc7XHJcbiAgaGlkZUZvb3RlcjogYm9vbGVhbjtcclxuICBoaWRlTmV0d29ya0JhZGdlczogYm9vbGVhbjtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfQlJBTkRJTkdfQ09ORklHOiBCcmFuZGluZ0NvbmZpZyA9IHtcclxuICB3aGl0ZWxhYmVsOiBmYWxzZSxcclxuICB1c2VUcmFkZU1hcms6IHRydWUsXHJcbiAgYnJhbmROYW1lOiAnU2lnbmluZyBSb29twq4nLFxyXG4gIGJyYW5kU3VmZml4OiAnLmlvJyxcclxuICBicmFuZENvbG9ySGV4OiAnIzEwYjk4MScsXHJcbiAgdGFnbGluZTogJ1RoZSBzZWN1cmUgY29vcmRpbmF0aW9uIGxheWVyIGZvciBCaXRjb2luIG11bHRpc2lnIGNlcmVtb25pZXMuJyxcclxuICBzdWJUYWdsaW5lOiAnTXVsdGktU2lnbmF0dXJlIENvbnNlbnN1cycsXHJcbiAgbG9nb1VybDogJy9icmFuZC9sb2dvLnN2ZycsXHJcbiAgZGVmYXVsdFJvb21OYW1lOiAnU2lnbmluZyBSb29tJyxcclxuICBoaWRlRm9vdGVyOiBmYWxzZSxcclxuICBoaWRlTmV0d29ya0JhZGdlczogZmFsc2UsXHJcbn07XHJcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU8sSUFBTSxjQUFjO0FBQUEsRUFDekIsWUFBWTtBQUFBLEVBQ1osV0FBVztBQUFBLEVBQ1gsUUFDRSxPQUFPLFdBQVcsZUFBZ0IsT0FBZSxPQUFPLFNBQ25ELE9BQWUsTUFBTSxTQUN0QjtBQUNSOzs7QUNQQTs7OztTQUFTLFlBQVksY0FBYztBQUVuQyxTQUFTLHNCQUFzQjs7O0FDWXhCLElBQU0sMEJBQTBDO0FBQUEsRUFDckQsWUFBWTtBQUFBLEVBQ1osY0FBYztBQUFBLEVBQ2QsV0FBVztBQUFBLEVBQ1gsYUFBYTtBQUFBLEVBQ2IsZUFBZTtBQUFBLEVBQ2YsU0FBUztBQUFBLEVBQ1QsWUFBWTtBQUFBLEVBQ1osU0FBUztBQUFBLEVBQ1QsaUJBQWlCO0FBQUEsRUFDakIsWUFBWTtBQUFBLEVBQ1osbUJBQW1CO0FBQ3JCO0E7Ozs7QURqQk0sSUFBTyxnQkFBUCxNQUFPLGVBQWE7RUFJeEIsWUFBNkIsTUFBZ0I7QUFBaEI7RUFBbUI7RUFBbkI7RUFIWixVQUFVO0lBQXVCOzs7Ozs7RUFDbEMsU0FBUyxLQUFLLFFBQVEsV0FBVTtFQUkxQyxhQUEyQjs7QUFDL0IsVUFBSTtBQUNGLGNBQU0sV0FBVyxNQUFNLGVBQ3JCLEtBQUssS0FBSyxJQUE2QixHQUFHLFlBQVksU0FBUyxNQUFNLEtBQUssSUFBRyxDQUFFLEVBQUUsQ0FBQztBQUVwRixhQUFLLFFBQVEsSUFBSSxrQ0FBSywwQkFBNEIsU0FBVTtBQUM1RCxnQkFBUSxJQUFJLDBDQUEwQztNQUN4RCxTQUFRO0FBQ04sZ0JBQVEsSUFBSSxtRUFBbUU7QUFDL0UsYUFBSyxRQUFRLElBQUksdUJBQXVCO01BQzFDO0lBQ0Y7O0VBRUEsSUFBSSxXQUEwQjtBQUM1QixXQUFPLEtBQUssUUFBTztFQUNyQjs7cUNBckJXLGdCQUFhLHNCQUFBLGFBQUEsQ0FBQTtFQUFBOytFQUFiLGdCQUFhLFNBQWIsZUFBYSxXQUFBLFlBRlosT0FBTSxDQUFBOzs7K0VBRVAsZUFBYSxDQUFBO1VBSHpCO1dBQVc7TUFDVixZQUFZO0tBQ2I7OzsiLCJuYW1lcyI6W10sImRlYnVnSWQiOiI1ODVlZWQ1Ny1mZWYzLTVmNDItYmEzZi02MTQwZWUyNWMzMzUifQ==