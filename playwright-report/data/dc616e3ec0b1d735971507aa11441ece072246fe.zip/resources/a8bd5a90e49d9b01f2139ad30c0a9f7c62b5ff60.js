import { $n as SafeSubscriber, $t as not, An as popNumber, Bn as AsyncAction, Cn as from, Dn as observeOn, En as subscribeOn, Jn as createOperatorSubscriber, Mn as popScheduler, Nn as isScheduler, On as innerFrom, Pn as EMPTY, Qt as filter, Rn as AsyncScheduler, Tn as scheduleIterable, Vn as AsyncSubject, Wn as Subject, Yn as Observable, Zn as identity, ar as isFunction, cr as __read, dn as mapOneOrManyArgs, jn as popResultSelector, kn as isArrayLike, ln as createObject, lr as __spreadArray, on as mergeAll, or as __extends, rr as Subscription, sn as mergeMap, sr as __generator, tr as noop, un as argsArgArrayOrObject, vn as EmptyError } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zipWith-DkrnN79P.js?v=cf17c1b4";
//#region node_modules/rxjs/dist/esm5/internal/scheduler/performanceTimestampProvider.js
var performanceTimestampProvider = {
	now: function() {
		return (performanceTimestampProvider.delegate || performance).now();
	},
	delegate: void 0
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/animationFrameProvider.js
var animationFrameProvider = {
	schedule: function(callback) {
		var request = requestAnimationFrame;
		var cancel = cancelAnimationFrame;
		var delegate = animationFrameProvider.delegate;
		if (delegate) {
			request = delegate.requestAnimationFrame;
			cancel = delegate.cancelAnimationFrame;
		}
		var handle = request(function(timestamp) {
			cancel = void 0;
			callback(timestamp);
		});
		return new Subscription(function() {
			return cancel === null || cancel === void 0 ? void 0 : cancel(handle);
		});
	},
	requestAnimationFrame: function() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var delegate = animationFrameProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.requestAnimationFrame) || requestAnimationFrame).apply(void 0, __spreadArray([], __read(args)));
	},
	cancelAnimationFrame: function() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var delegate = animationFrameProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.cancelAnimationFrame) || cancelAnimationFrame).apply(void 0, __spreadArray([], __read(args)));
	},
	delegate: void 0
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/dom/animationFrames.js
function animationFrames(timestampProvider) {
	return timestampProvider ? animationFramesFactory(timestampProvider) : DEFAULT_ANIMATION_FRAMES;
}
function animationFramesFactory(timestampProvider) {
	return new Observable(function(subscriber) {
		var provider = timestampProvider || performanceTimestampProvider;
		var start = provider.now();
		var id = 0;
		var run = function() {
			if (!subscriber.closed) id = animationFrameProvider.requestAnimationFrame(function(timestamp) {
				id = 0;
				var now = provider.now();
				subscriber.next({
					timestamp: timestampProvider ? now : timestamp,
					elapsed: now - start
				});
				run();
			});
		};
		run();
		return function() {
			if (id) animationFrameProvider.cancelAnimationFrame(id);
		};
	});
}
var DEFAULT_ANIMATION_FRAMES = animationFramesFactory();
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/Immediate.js
var nextHandle = 1;
var resolved;
var activeHandles = {};
function findAndClearHandle(handle) {
	if (handle in activeHandles) {
		delete activeHandles[handle];
		return true;
	}
	return false;
}
var Immediate = {
	setImmediate: function(cb) {
		var handle = nextHandle++;
		activeHandles[handle] = true;
		if (!resolved) resolved = Promise.resolve();
		resolved.then(function() {
			return findAndClearHandle(handle) && cb();
		});
		return handle;
	},
	clearImmediate: function(handle) {
		findAndClearHandle(handle);
	}
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/immediateProvider.js
var setImmediate = Immediate.setImmediate;
var clearImmediate = Immediate.clearImmediate;
var immediateProvider = {
	setImmediate: function() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var delegate = immediateProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.setImmediate) || setImmediate).apply(void 0, __spreadArray([], __read(args)));
	},
	clearImmediate: function(handle) {
		var delegate = immediateProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearImmediate) || clearImmediate)(handle);
	},
	delegate: void 0
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/AsapAction.js
var AsapAction = function(_super) {
	__extends(AsapAction, _super);
	function AsapAction(scheduler, work) {
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		return _this;
	}
	AsapAction.prototype.requestAsyncId = function(scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		if (delay !== null && delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
		scheduler.actions.push(this);
		return scheduler._scheduled || (scheduler._scheduled = immediateProvider.setImmediate(scheduler.flush.bind(scheduler, void 0)));
	};
	AsapAction.prototype.recycleAsyncId = function(scheduler, id, delay) {
		var _a;
		if (delay === void 0) delay = 0;
		if (delay != null ? delay > 0 : this.delay > 0) return _super.prototype.recycleAsyncId.call(this, scheduler, id, delay);
		var actions = scheduler.actions;
		if (id != null && ((_a = actions[actions.length - 1]) === null || _a === void 0 ? void 0 : _a.id) !== id) {
			immediateProvider.clearImmediate(id);
			if (scheduler._scheduled === id) scheduler._scheduled = void 0;
		}
	};
	return AsapAction;
}(AsyncAction);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/asap.js
var asapScheduler = new (function(_super) {
	__extends(AsapScheduler, _super);
	function AsapScheduler() {
		return _super !== null && _super.apply(this, arguments) || this;
	}
	AsapScheduler.prototype.flush = function(action) {
		this._active = true;
		var flushId = this._scheduled;
		this._scheduled = void 0;
		var actions = this.actions;
		var error;
		action = action || actions.shift();
		do
			if (error = action.execute(action.state, action.delay)) break;
		while ((action = actions[0]) && action.id === flushId && actions.shift());
		this._active = false;
		if (error) {
			while ((action = actions[0]) && action.id === flushId && actions.shift()) action.unsubscribe();
			throw error;
		}
	};
	return AsapScheduler;
}(AsyncScheduler))(AsapAction);
var asap = asapScheduler;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/QueueAction.js
var QueueAction = function(_super) {
	__extends(QueueAction, _super);
	function QueueAction(scheduler, work) {
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		return _this;
	}
	QueueAction.prototype.schedule = function(state, delay) {
		if (delay === void 0) delay = 0;
		if (delay > 0) return _super.prototype.schedule.call(this, state, delay);
		this.delay = delay;
		this.state = state;
		this.scheduler.flush(this);
		return this;
	};
	QueueAction.prototype.execute = function(state, delay) {
		return delay > 0 || this.closed ? _super.prototype.execute.call(this, state, delay) : this._execute(state, delay);
	};
	QueueAction.prototype.requestAsyncId = function(scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		if (delay != null && delay > 0 || delay == null && this.delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
		scheduler.flush(this);
		return 0;
	};
	return QueueAction;
}(AsyncAction);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/queue.js
var queueScheduler = new (function(_super) {
	__extends(QueueScheduler, _super);
	function QueueScheduler() {
		return _super !== null && _super.apply(this, arguments) || this;
	}
	return QueueScheduler;
}(AsyncScheduler))(QueueAction);
var queue = queueScheduler;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/AnimationFrameAction.js
var AnimationFrameAction = function(_super) {
	__extends(AnimationFrameAction, _super);
	function AnimationFrameAction(scheduler, work) {
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		return _this;
	}
	AnimationFrameAction.prototype.requestAsyncId = function(scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		if (delay !== null && delay > 0) return _super.prototype.requestAsyncId.call(this, scheduler, id, delay);
		scheduler.actions.push(this);
		return scheduler._scheduled || (scheduler._scheduled = animationFrameProvider.requestAnimationFrame(function() {
			return scheduler.flush(void 0);
		}));
	};
	AnimationFrameAction.prototype.recycleAsyncId = function(scheduler, id, delay) {
		var _a;
		if (delay === void 0) delay = 0;
		if (delay != null ? delay > 0 : this.delay > 0) return _super.prototype.recycleAsyncId.call(this, scheduler, id, delay);
		var actions = scheduler.actions;
		if (id != null && id === scheduler._scheduled && ((_a = actions[actions.length - 1]) === null || _a === void 0 ? void 0 : _a.id) !== id) {
			animationFrameProvider.cancelAnimationFrame(id);
			scheduler._scheduled = void 0;
		}
	};
	return AnimationFrameAction;
}(AsyncAction);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/animationFrame.js
var animationFrameScheduler = new (function(_super) {
	__extends(AnimationFrameScheduler, _super);
	function AnimationFrameScheduler() {
		return _super !== null && _super.apply(this, arguments) || this;
	}
	AnimationFrameScheduler.prototype.flush = function(action) {
		this._active = true;
		var flushId;
		if (action) flushId = action.id;
		else {
			flushId = this._scheduled;
			this._scheduled = void 0;
		}
		var actions = this.actions;
		var error;
		action = action || actions.shift();
		do
			if (error = action.execute(action.state, action.delay)) break;
		while ((action = actions[0]) && action.id === flushId && actions.shift());
		this._active = false;
		if (error) {
			while ((action = actions[0]) && action.id === flushId && actions.shift()) action.unsubscribe();
			throw error;
		}
	};
	return AnimationFrameScheduler;
}(AsyncScheduler))(AnimationFrameAction);
var animationFrame = animationFrameScheduler;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/VirtualTimeScheduler.js
var VirtualTimeScheduler = function(_super) {
	__extends(VirtualTimeScheduler, _super);
	function VirtualTimeScheduler(schedulerActionCtor, maxFrames) {
		if (schedulerActionCtor === void 0) schedulerActionCtor = VirtualAction;
		if (maxFrames === void 0) maxFrames = Infinity;
		var _this = _super.call(this, schedulerActionCtor, function() {
			return _this.frame;
		}) || this;
		_this.maxFrames = maxFrames;
		_this.frame = 0;
		_this.index = -1;
		return _this;
	}
	VirtualTimeScheduler.prototype.flush = function() {
		var _a = this, actions = _a.actions, maxFrames = _a.maxFrames;
		var error;
		var action;
		while ((action = actions[0]) && action.delay <= maxFrames) {
			actions.shift();
			this.frame = action.delay;
			if (error = action.execute(action.state, action.delay)) break;
		}
		if (error) {
			while (action = actions.shift()) action.unsubscribe();
			throw error;
		}
	};
	VirtualTimeScheduler.frameTimeFactor = 10;
	return VirtualTimeScheduler;
}(AsyncScheduler);
var VirtualAction = function(_super) {
	__extends(VirtualAction, _super);
	function VirtualAction(scheduler, work, index) {
		if (index === void 0) index = scheduler.index += 1;
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		_this.index = index;
		_this.active = true;
		_this.index = scheduler.index = index;
		return _this;
	}
	VirtualAction.prototype.schedule = function(state, delay) {
		if (delay === void 0) delay = 0;
		if (Number.isFinite(delay)) {
			if (!this.id) return _super.prototype.schedule.call(this, state, delay);
			this.active = false;
			var action = new VirtualAction(this.scheduler, this.work);
			this.add(action);
			return action.schedule(state, delay);
		} else return Subscription.EMPTY;
	};
	VirtualAction.prototype.requestAsyncId = function(scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		this.delay = scheduler.frame + delay;
		var actions = scheduler.actions;
		actions.push(this);
		actions.sort(VirtualAction.sortActions);
		return 1;
	};
	VirtualAction.prototype.recycleAsyncId = function(scheduler, id, delay) {
		if (delay === void 0) delay = 0;
	};
	VirtualAction.prototype._execute = function(state, delay) {
		if (this.active === true) return _super.prototype._execute.call(this, state, delay);
	};
	VirtualAction.sortActions = function(a, b) {
		if (a.delay === b.delay) if (a.index === b.index) return 0;
		else if (a.index > b.index) return 1;
		else return -1;
		else if (a.delay > b.delay) return 1;
		else return -1;
	};
	return VirtualAction;
}(AsyncAction);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isObservable.js
function isObservable(obj) {
	return !!obj && (obj instanceof Observable || isFunction(obj.lift) && isFunction(obj.subscribe));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/lastValueFrom.js
function lastValueFrom(source, config) {
	var hasConfig = typeof config === "object";
	return new Promise(function(resolve, reject) {
		var _hasValue = false;
		var _value;
		source.subscribe({
			next: function(value) {
				_value = value;
				_hasValue = true;
			},
			error: reject,
			complete: function() {
				if (_hasValue) resolve(_value);
				else if (hasConfig) resolve(config.defaultValue);
				else reject(new EmptyError());
			}
		});
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/firstValueFrom.js
function firstValueFrom(source, config) {
	var hasConfig = typeof config === "object";
	return new Promise(function(resolve, reject) {
		var subscriber = new SafeSubscriber({
			next: function(value) {
				resolve(value);
				subscriber.unsubscribe();
			},
			error: reject,
			complete: function() {
				if (hasConfig) resolve(config.defaultValue);
				else reject(new EmptyError());
			}
		});
		source.subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/bindCallbackInternals.js
function bindCallbackInternals(isNodeStyle, callbackFunc, resultSelector, scheduler) {
	if (resultSelector) if (isScheduler(resultSelector)) scheduler = resultSelector;
	else return function() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		return bindCallbackInternals(isNodeStyle, callbackFunc, scheduler).apply(this, args).pipe(mapOneOrManyArgs(resultSelector));
	};
	if (scheduler) return function() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		return bindCallbackInternals(isNodeStyle, callbackFunc).apply(this, args).pipe(subscribeOn(scheduler), observeOn(scheduler));
	};
	return function() {
		var _this = this;
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		var subject = new AsyncSubject();
		var uninitialized = true;
		return new Observable(function(subscriber) {
			var subs = subject.subscribe(subscriber);
			if (uninitialized) {
				uninitialized = false;
				var isAsync_1 = false;
				var isComplete_1 = false;
				callbackFunc.apply(_this, __spreadArray(__spreadArray([], __read(args)), [function() {
					var results = [];
					for (var _i = 0; _i < arguments.length; _i++) results[_i] = arguments[_i];
					if (isNodeStyle) {
						var err = results.shift();
						if (err != null) {
							subject.error(err);
							return;
						}
					}
					subject.next(1 < results.length ? results : results[0]);
					isComplete_1 = true;
					if (isAsync_1) subject.complete();
				}]));
				if (isComplete_1) subject.complete();
				isAsync_1 = true;
			}
			return subs;
		});
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/bindCallback.js
function bindCallback(callbackFunc, resultSelector, scheduler) {
	return bindCallbackInternals(false, callbackFunc, resultSelector, scheduler);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/bindNodeCallback.js
function bindNodeCallback(callbackFunc, resultSelector, scheduler) {
	return bindCallbackInternals(true, callbackFunc, resultSelector, scheduler);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/defer.js
function defer(observableFactory) {
	return new Observable(function(subscriber) {
		innerFrom(observableFactory()).subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/connectable.js
var DEFAULT_CONFIG = {
	connector: function() {
		return new Subject();
	},
	resetOnDisconnect: true
};
function connectable(source, config) {
	if (config === void 0) config = DEFAULT_CONFIG;
	var connection = null;
	var connector = config.connector, _a = config.resetOnDisconnect, resetOnDisconnect = _a === void 0 ? true : _a;
	var subject = connector();
	var result = new Observable(function(subscriber) {
		return subject.subscribe(subscriber);
	});
	result.connect = function() {
		if (!connection || connection.closed) {
			connection = defer(function() {
				return source;
			}).subscribe(subject);
			if (resetOnDisconnect) connection.add(function() {
				return subject = connector();
			});
		}
		return connection;
	};
	return result;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/forkJoin.js
function forkJoin() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var resultSelector = popResultSelector(args);
	var _a = argsArgArrayOrObject(args), sources = _a.args, keys = _a.keys;
	var result = new Observable(function(subscriber) {
		var length = sources.length;
		if (!length) {
			subscriber.complete();
			return;
		}
		var values = new Array(length);
		var remainingCompletions = length;
		var remainingEmissions = length;
		var _loop_1 = function(sourceIndex) {
			var hasValue = false;
			innerFrom(sources[sourceIndex]).subscribe(createOperatorSubscriber(subscriber, function(value) {
				if (!hasValue) {
					hasValue = true;
					remainingEmissions--;
				}
				values[sourceIndex] = value;
			}, function() {
				return remainingCompletions--;
			}, void 0, function() {
				if (!remainingCompletions || !hasValue) {
					if (!remainingEmissions) subscriber.next(keys ? createObject(keys, values) : values);
					subscriber.complete();
				}
			}));
		};
		for (var sourceIndex = 0; sourceIndex < length; sourceIndex++) _loop_1(sourceIndex);
	});
	return resultSelector ? result.pipe(mapOneOrManyArgs(resultSelector)) : result;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/fromEvent.js
var nodeEventEmitterMethods = ["addListener", "removeListener"];
var eventTargetMethods = ["addEventListener", "removeEventListener"];
var jqueryMethods = ["on", "off"];
function fromEvent(target, eventName, options, resultSelector) {
	if (isFunction(options)) {
		resultSelector = options;
		options = void 0;
	}
	if (resultSelector) return fromEvent(target, eventName, options).pipe(mapOneOrManyArgs(resultSelector));
	var _a = __read(isEventTarget(target) ? eventTargetMethods.map(function(methodName) {
		return function(handler) {
			return target[methodName](eventName, handler, options);
		};
	}) : isNodeStyleEventEmitter(target) ? nodeEventEmitterMethods.map(toCommonHandlerRegistry(target, eventName)) : isJQueryStyleEventEmitter(target) ? jqueryMethods.map(toCommonHandlerRegistry(target, eventName)) : [], 2), add = _a[0], remove = _a[1];
	if (!add) {
		if (isArrayLike(target)) return mergeMap(function(subTarget) {
			return fromEvent(subTarget, eventName, options);
		})(innerFrom(target));
	}
	if (!add) throw new TypeError("Invalid event target");
	return new Observable(function(subscriber) {
		var handler = function() {
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			return subscriber.next(1 < args.length ? args : args[0]);
		};
		add(handler);
		return function() {
			return remove(handler);
		};
	});
}
function toCommonHandlerRegistry(target, eventName) {
	return function(methodName) {
		return function(handler) {
			return target[methodName](eventName, handler);
		};
	};
}
function isNodeStyleEventEmitter(target) {
	return isFunction(target.addListener) && isFunction(target.removeListener);
}
function isJQueryStyleEventEmitter(target) {
	return isFunction(target.on) && isFunction(target.off);
}
function isEventTarget(target) {
	return isFunction(target.addEventListener) && isFunction(target.removeEventListener);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/fromEventPattern.js
function fromEventPattern(addHandler, removeHandler, resultSelector) {
	if (resultSelector) return fromEventPattern(addHandler, removeHandler).pipe(mapOneOrManyArgs(resultSelector));
	return new Observable(function(subscriber) {
		var handler = function() {
			var e = [];
			for (var _i = 0; _i < arguments.length; _i++) e[_i] = arguments[_i];
			return subscriber.next(e.length === 1 ? e[0] : e);
		};
		var retValue = addHandler(handler);
		return isFunction(removeHandler) ? function() {
			return removeHandler(handler, retValue);
		} : void 0;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/generate.js
function generate(initialStateOrOptions, condition, iterate, resultSelectorOrScheduler, scheduler) {
	var _a, _b;
	var resultSelector;
	var initialState;
	if (arguments.length === 1) _a = initialStateOrOptions, initialState = _a.initialState, condition = _a.condition, iterate = _a.iterate, _b = _a.resultSelector, resultSelector = _b === void 0 ? identity : _b, scheduler = _a.scheduler;
	else {
		initialState = initialStateOrOptions;
		if (!resultSelectorOrScheduler || isScheduler(resultSelectorOrScheduler)) {
			resultSelector = identity;
			scheduler = resultSelectorOrScheduler;
		} else resultSelector = resultSelectorOrScheduler;
	}
	function gen() {
		var state;
		return __generator(this, function(_a) {
			switch (_a.label) {
				case 0:
					state = initialState;
					_a.label = 1;
				case 1:
					if (!(!condition || condition(state))) return [3, 4];
					return [4, resultSelector(state)];
				case 2:
					_a.sent();
					_a.label = 3;
				case 3:
					state = iterate(state);
					return [3, 1];
				case 4: return [2];
			}
		});
	}
	return defer(scheduler ? function() {
		return scheduleIterable(gen(), scheduler);
	} : gen);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/iif.js
function iif(condition, trueResult, falseResult) {
	return defer(function() {
		return condition() ? trueResult : falseResult;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/merge.js
function merge() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var scheduler = popScheduler(args);
	var concurrent = popNumber(args, Infinity);
	var sources = args;
	return !sources.length ? EMPTY : sources.length === 1 ? innerFrom(sources[0]) : mergeAll(concurrent)(from(sources, scheduler));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/never.js
var NEVER = new Observable(noop);
function never() {
	return NEVER;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/pairs.js
function pairs(obj, scheduler) {
	return from(Object.entries(obj), scheduler);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/partition.js
function partition(source, predicate, thisArg) {
	return [filter(predicate, thisArg)(innerFrom(source)), filter(not(predicate, thisArg))(innerFrom(source))];
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/range.js
function range(start, count, scheduler) {
	if (count == null) {
		count = start;
		start = 0;
	}
	if (count <= 0) return EMPTY;
	var end = count + start;
	return new Observable(scheduler ? function(subscriber) {
		var n = start;
		return scheduler.schedule(function() {
			if (n < end) {
				subscriber.next(n++);
				this.schedule();
			} else subscriber.complete();
		});
	} : function(subscriber) {
		var n = start;
		while (n < end && !subscriber.closed) subscriber.next(n++);
		subscriber.complete();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/using.js
function using(resourceFactory, observableFactory) {
	return new Observable(function(subscriber) {
		var resource = resourceFactory();
		var result = observableFactory(resource);
		(result ? innerFrom(result) : EMPTY).subscribe(subscriber);
		return function() {
			if (resource) resource.unsubscribe();
		};
	});
}
//#endregion
export { animationFrameScheduler as C, asapScheduler as D, asap as E, animationFrames as O, animationFrame as S, queueScheduler as T, firstValueFrom as _, NEVER as a, VirtualAction as b, iif as c, fromEvent as d, forkJoin as f, bindCallback as g, bindNodeCallback as h, pairs as i, generate as l, defer as m, range as n, never as o, connectable as p, partition as r, merge as s, using as t, fromEventPattern as u, lastValueFrom as v, queue as w, VirtualTimeScheduler as x, isObservable as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXNtNS0xYlBqZUlIay5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL3BlcmZvcm1hbmNlVGltZXN0YW1wUHJvdmlkZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL2FuaW1hdGlvbkZyYW1lUHJvdmlkZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9kb20vYW5pbWF0aW9uRnJhbWVzLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3V0aWwvSW1tZWRpYXRlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3NjaGVkdWxlci9pbW1lZGlhdGVQcm92aWRlci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvQXNhcEFjdGlvbi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvQXNhcFNjaGVkdWxlci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvYXNhcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvUXVldWVBY3Rpb24uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL1F1ZXVlU2NoZWR1bGVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3NjaGVkdWxlci9xdWV1ZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvQW5pbWF0aW9uRnJhbWVBY3Rpb24uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL0FuaW1hdGlvbkZyYW1lU2NoZWR1bGVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3NjaGVkdWxlci9hbmltYXRpb25GcmFtZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvVmlydHVhbFRpbWVTY2hlZHVsZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pc09ic2VydmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvbGFzdFZhbHVlRnJvbS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9maXJzdFZhbHVlRnJvbS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2JpbmRDYWxsYmFja0ludGVybmFscy5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2JpbmRDYWxsYmFjay5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2JpbmROb2RlQ2FsbGJhY2suanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9kZWZlci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2Nvbm5lY3RhYmxlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29ic2VydmFibGUvZm9ya0pvaW4uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9mcm9tRXZlbnQuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9mcm9tRXZlbnRQYXR0ZXJuLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29ic2VydmFibGUvZ2VuZXJhdGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9paWYuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9tZXJnZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL25ldmVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29ic2VydmFibGUvcGFpcnMuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9wYXJ0aXRpb24uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9yYW5nZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL3VzaW5nLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB2YXIgcGVyZm9ybWFuY2VUaW1lc3RhbXBQcm92aWRlciA9IHtcbiAgICBub3c6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIChwZXJmb3JtYW5jZVRpbWVzdGFtcFByb3ZpZGVyLmRlbGVnYXRlIHx8IHBlcmZvcm1hbmNlKS5ub3coKTtcbiAgICB9LFxuICAgIGRlbGVnYXRlOiB1bmRlZmluZWQsXG59O1xuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICcuLi9TdWJzY3JpcHRpb24nO1xuZXhwb3J0IHZhciBhbmltYXRpb25GcmFtZVByb3ZpZGVyID0ge1xuICAgIHNjaGVkdWxlOiBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgICAgICAgdmFyIHJlcXVlc3QgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWU7XG4gICAgICAgIHZhciBjYW5jZWwgPSBjYW5jZWxBbmltYXRpb25GcmFtZTtcbiAgICAgICAgdmFyIGRlbGVnYXRlID0gYW5pbWF0aW9uRnJhbWVQcm92aWRlci5kZWxlZ2F0ZTtcbiAgICAgICAgaWYgKGRlbGVnYXRlKSB7XG4gICAgICAgICAgICByZXF1ZXN0ID0gZGVsZWdhdGUucmVxdWVzdEFuaW1hdGlvbkZyYW1lO1xuICAgICAgICAgICAgY2FuY2VsID0gZGVsZWdhdGUuY2FuY2VsQW5pbWF0aW9uRnJhbWU7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGhhbmRsZSA9IHJlcXVlc3QoZnVuY3Rpb24gKHRpbWVzdGFtcCkge1xuICAgICAgICAgICAgY2FuY2VsID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgY2FsbGJhY2sodGltZXN0YW1wKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBuZXcgU3Vic2NyaXB0aW9uKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGNhbmNlbCA9PT0gbnVsbCB8fCBjYW5jZWwgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGNhbmNlbChoYW5kbGUpOyB9KTtcbiAgICB9LFxuICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZTogZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgYXJncyA9IFtdO1xuICAgICAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICB9XG4gICAgICAgIHZhciBkZWxlZ2F0ZSA9IGFuaW1hdGlvbkZyYW1lUHJvdmlkZXIuZGVsZWdhdGU7XG4gICAgICAgIHJldHVybiAoKGRlbGVnYXRlID09PSBudWxsIHx8IGRlbGVnYXRlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkZWxlZ2F0ZS5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUpIHx8IHJlcXVlc3RBbmltYXRpb25GcmFtZSkuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQoYXJncykpKTtcbiAgICB9LFxuICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBhcmdzID0gW107XG4gICAgICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICBhcmdzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGRlbGVnYXRlID0gYW5pbWF0aW9uRnJhbWVQcm92aWRlci5kZWxlZ2F0ZTtcbiAgICAgICAgcmV0dXJuICgoZGVsZWdhdGUgPT09IG51bGwgfHwgZGVsZWdhdGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRlbGVnYXRlLmNhbmNlbEFuaW1hdGlvbkZyYW1lKSB8fCBjYW5jZWxBbmltYXRpb25GcmFtZSkuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQoYXJncykpKTtcbiAgICB9LFxuICAgIGRlbGVnYXRlOiB1bmRlZmluZWQsXG59O1xuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uLy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgcGVyZm9ybWFuY2VUaW1lc3RhbXBQcm92aWRlciB9IGZyb20gJy4uLy4uL3NjaGVkdWxlci9wZXJmb3JtYW5jZVRpbWVzdGFtcFByb3ZpZGVyJztcbmltcG9ydCB7IGFuaW1hdGlvbkZyYW1lUHJvdmlkZXIgfSBmcm9tICcuLi8uLi9zY2hlZHVsZXIvYW5pbWF0aW9uRnJhbWVQcm92aWRlcic7XG5leHBvcnQgZnVuY3Rpb24gYW5pbWF0aW9uRnJhbWVzKHRpbWVzdGFtcFByb3ZpZGVyKSB7XG4gICAgcmV0dXJuIHRpbWVzdGFtcFByb3ZpZGVyID8gYW5pbWF0aW9uRnJhbWVzRmFjdG9yeSh0aW1lc3RhbXBQcm92aWRlcikgOiBERUZBVUxUX0FOSU1BVElPTl9GUkFNRVM7XG59XG5mdW5jdGlvbiBhbmltYXRpb25GcmFtZXNGYWN0b3J5KHRpbWVzdGFtcFByb3ZpZGVyKSB7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBwcm92aWRlciA9IHRpbWVzdGFtcFByb3ZpZGVyIHx8IHBlcmZvcm1hbmNlVGltZXN0YW1wUHJvdmlkZXI7XG4gICAgICAgIHZhciBzdGFydCA9IHByb3ZpZGVyLm5vdygpO1xuICAgICAgICB2YXIgaWQgPSAwO1xuICAgICAgICB2YXIgcnVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKCFzdWJzY3JpYmVyLmNsb3NlZCkge1xuICAgICAgICAgICAgICAgIGlkID0gYW5pbWF0aW9uRnJhbWVQcm92aWRlci5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUoZnVuY3Rpb24gKHRpbWVzdGFtcCkge1xuICAgICAgICAgICAgICAgICAgICBpZCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIHZhciBub3cgPSBwcm92aWRlci5ub3coKTtcbiAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVzdGFtcDogdGltZXN0YW1wUHJvdmlkZXIgPyBub3cgOiB0aW1lc3RhbXAsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGFwc2VkOiBub3cgLSBzdGFydCxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHJ1bigpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBydW4oKTtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChpZCkge1xuICAgICAgICAgICAgICAgIGFuaW1hdGlvbkZyYW1lUHJvdmlkZXIuY2FuY2VsQW5pbWF0aW9uRnJhbWUoaWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xufVxudmFyIERFRkFVTFRfQU5JTUFUSU9OX0ZSQU1FUyA9IGFuaW1hdGlvbkZyYW1lc0ZhY3RvcnkoKTtcbiIsInZhciBuZXh0SGFuZGxlID0gMTtcbnZhciByZXNvbHZlZDtcbnZhciBhY3RpdmVIYW5kbGVzID0ge307XG5mdW5jdGlvbiBmaW5kQW5kQ2xlYXJIYW5kbGUoaGFuZGxlKSB7XG4gICAgaWYgKGhhbmRsZSBpbiBhY3RpdmVIYW5kbGVzKSB7XG4gICAgICAgIGRlbGV0ZSBhY3RpdmVIYW5kbGVzW2hhbmRsZV07XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59XG5leHBvcnQgdmFyIEltbWVkaWF0ZSA9IHtcbiAgICBzZXRJbW1lZGlhdGU6IGZ1bmN0aW9uIChjYikge1xuICAgICAgICB2YXIgaGFuZGxlID0gbmV4dEhhbmRsZSsrO1xuICAgICAgICBhY3RpdmVIYW5kbGVzW2hhbmRsZV0gPSB0cnVlO1xuICAgICAgICBpZiAoIXJlc29sdmVkKSB7XG4gICAgICAgICAgICByZXNvbHZlZCA9IFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICAgIHJlc29sdmVkLnRoZW4oZnVuY3Rpb24gKCkgeyByZXR1cm4gZmluZEFuZENsZWFySGFuZGxlKGhhbmRsZSkgJiYgY2IoKTsgfSk7XG4gICAgICAgIHJldHVybiBoYW5kbGU7XG4gICAgfSxcbiAgICBjbGVhckltbWVkaWF0ZTogZnVuY3Rpb24gKGhhbmRsZSkge1xuICAgICAgICBmaW5kQW5kQ2xlYXJIYW5kbGUoaGFuZGxlKTtcbiAgICB9LFxufTtcbmV4cG9ydCB2YXIgVGVzdFRvb2xzID0ge1xuICAgIHBlbmRpbmc6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKGFjdGl2ZUhhbmRsZXMpLmxlbmd0aDtcbiAgICB9XG59O1xuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBJbW1lZGlhdGUgfSBmcm9tICcuLi91dGlsL0ltbWVkaWF0ZSc7XG52YXIgc2V0SW1tZWRpYXRlID0gSW1tZWRpYXRlLnNldEltbWVkaWF0ZSwgY2xlYXJJbW1lZGlhdGUgPSBJbW1lZGlhdGUuY2xlYXJJbW1lZGlhdGU7XG5leHBvcnQgdmFyIGltbWVkaWF0ZVByb3ZpZGVyID0ge1xuICAgIHNldEltbWVkaWF0ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgYXJncyA9IFtdO1xuICAgICAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICB9XG4gICAgICAgIHZhciBkZWxlZ2F0ZSA9IGltbWVkaWF0ZVByb3ZpZGVyLmRlbGVnYXRlO1xuICAgICAgICByZXR1cm4gKChkZWxlZ2F0ZSA9PT0gbnVsbCB8fCBkZWxlZ2F0ZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogZGVsZWdhdGUuc2V0SW1tZWRpYXRlKSB8fCBzZXRJbW1lZGlhdGUpLmFwcGx5KHZvaWQgMCwgX19zcHJlYWRBcnJheShbXSwgX19yZWFkKGFyZ3MpKSk7XG4gICAgfSxcbiAgICBjbGVhckltbWVkaWF0ZTogZnVuY3Rpb24gKGhhbmRsZSkge1xuICAgICAgICB2YXIgZGVsZWdhdGUgPSBpbW1lZGlhdGVQcm92aWRlci5kZWxlZ2F0ZTtcbiAgICAgICAgcmV0dXJuICgoZGVsZWdhdGUgPT09IG51bGwgfHwgZGVsZWdhdGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRlbGVnYXRlLmNsZWFySW1tZWRpYXRlKSB8fCBjbGVhckltbWVkaWF0ZSkoaGFuZGxlKTtcbiAgICB9LFxuICAgIGRlbGVnYXRlOiB1bmRlZmluZWQsXG59O1xuIiwiaW1wb3J0IHsgX19leHRlbmRzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBBc3luY0FjdGlvbiB9IGZyb20gJy4vQXN5bmNBY3Rpb24nO1xuaW1wb3J0IHsgaW1tZWRpYXRlUHJvdmlkZXIgfSBmcm9tICcuL2ltbWVkaWF0ZVByb3ZpZGVyJztcbnZhciBBc2FwQWN0aW9uID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQXNhcEFjdGlvbiwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBc2FwQWN0aW9uKHNjaGVkdWxlciwgd29yaykge1xuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzLCBzY2hlZHVsZXIsIHdvcmspIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLnNjaGVkdWxlciA9IHNjaGVkdWxlcjtcbiAgICAgICAgX3RoaXMud29yayA9IHdvcms7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgQXNhcEFjdGlvbi5wcm90b3R5cGUucmVxdWVzdEFzeW5jSWQgPSBmdW5jdGlvbiAoc2NoZWR1bGVyLCBpZCwgZGVsYXkpIHtcbiAgICAgICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgICAgIGlmIChkZWxheSAhPT0gbnVsbCAmJiBkZWxheSA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBfc3VwZXIucHJvdG90eXBlLnJlcXVlc3RBc3luY0lkLmNhbGwodGhpcywgc2NoZWR1bGVyLCBpZCwgZGVsYXkpO1xuICAgICAgICB9XG4gICAgICAgIHNjaGVkdWxlci5hY3Rpb25zLnB1c2godGhpcyk7XG4gICAgICAgIHJldHVybiBzY2hlZHVsZXIuX3NjaGVkdWxlZCB8fCAoc2NoZWR1bGVyLl9zY2hlZHVsZWQgPSBpbW1lZGlhdGVQcm92aWRlci5zZXRJbW1lZGlhdGUoc2NoZWR1bGVyLmZsdXNoLmJpbmQoc2NoZWR1bGVyLCB1bmRlZmluZWQpKSk7XG4gICAgfTtcbiAgICBBc2FwQWN0aW9uLnByb3RvdHlwZS5yZWN5Y2xlQXN5bmNJZCA9IGZ1bmN0aW9uIChzY2hlZHVsZXIsIGlkLCBkZWxheSkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmIChkZWxheSA9PT0gdm9pZCAwKSB7IGRlbGF5ID0gMDsgfVxuICAgICAgICBpZiAoZGVsYXkgIT0gbnVsbCA/IGRlbGF5ID4gMCA6IHRoaXMuZGVsYXkgPiAwKSB7XG4gICAgICAgICAgICByZXR1cm4gX3N1cGVyLnByb3RvdHlwZS5yZWN5Y2xlQXN5bmNJZC5jYWxsKHRoaXMsIHNjaGVkdWxlciwgaWQsIGRlbGF5KTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgYWN0aW9ucyA9IHNjaGVkdWxlci5hY3Rpb25zO1xuICAgICAgICBpZiAoaWQgIT0gbnVsbCAmJiAoKF9hID0gYWN0aW9uc1thY3Rpb25zLmxlbmd0aCAtIDFdKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaWQpICE9PSBpZCkge1xuICAgICAgICAgICAgaW1tZWRpYXRlUHJvdmlkZXIuY2xlYXJJbW1lZGlhdGUoaWQpO1xuICAgICAgICAgICAgaWYgKHNjaGVkdWxlci5fc2NoZWR1bGVkID09PSBpZCkge1xuICAgICAgICAgICAgICAgIHNjaGVkdWxlci5fc2NoZWR1bGVkID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICByZXR1cm4gQXNhcEFjdGlvbjtcbn0oQXN5bmNBY3Rpb24pKTtcbmV4cG9ydCB7IEFzYXBBY3Rpb24gfTtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgQXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuL0FzeW5jU2NoZWR1bGVyJztcbnZhciBBc2FwU2NoZWR1bGVyID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQXNhcFNjaGVkdWxlciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBc2FwU2NoZWR1bGVyKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIEFzYXBTY2hlZHVsZXIucHJvdG90eXBlLmZsdXNoID0gZnVuY3Rpb24gKGFjdGlvbikge1xuICAgICAgICB0aGlzLl9hY3RpdmUgPSB0cnVlO1xuICAgICAgICB2YXIgZmx1c2hJZCA9IHRoaXMuX3NjaGVkdWxlZDtcbiAgICAgICAgdGhpcy5fc2NoZWR1bGVkID0gdW5kZWZpbmVkO1xuICAgICAgICB2YXIgYWN0aW9ucyA9IHRoaXMuYWN0aW9ucztcbiAgICAgICAgdmFyIGVycm9yO1xuICAgICAgICBhY3Rpb24gPSBhY3Rpb24gfHwgYWN0aW9ucy5zaGlmdCgpO1xuICAgICAgICBkbyB7XG4gICAgICAgICAgICBpZiAoKGVycm9yID0gYWN0aW9uLmV4ZWN1dGUoYWN0aW9uLnN0YXRlLCBhY3Rpb24uZGVsYXkpKSkge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IHdoaWxlICgoYWN0aW9uID0gYWN0aW9uc1swXSkgJiYgYWN0aW9uLmlkID09PSBmbHVzaElkICYmIGFjdGlvbnMuc2hpZnQoKSk7XG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IGZhbHNlO1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHdoaWxlICgoYWN0aW9uID0gYWN0aW9uc1swXSkgJiYgYWN0aW9uLmlkID09PSBmbHVzaElkICYmIGFjdGlvbnMuc2hpZnQoKSkge1xuICAgICAgICAgICAgICAgIGFjdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBBc2FwU2NoZWR1bGVyO1xufShBc3luY1NjaGVkdWxlcikpO1xuZXhwb3J0IHsgQXNhcFNjaGVkdWxlciB9O1xuIiwiaW1wb3J0IHsgQXNhcEFjdGlvbiB9IGZyb20gJy4vQXNhcEFjdGlvbic7XG5pbXBvcnQgeyBBc2FwU2NoZWR1bGVyIH0gZnJvbSAnLi9Bc2FwU2NoZWR1bGVyJztcbmV4cG9ydCB2YXIgYXNhcFNjaGVkdWxlciA9IG5ldyBBc2FwU2NoZWR1bGVyKEFzYXBBY3Rpb24pO1xuZXhwb3J0IHZhciBhc2FwID0gYXNhcFNjaGVkdWxlcjtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgQXN5bmNBY3Rpb24gfSBmcm9tICcuL0FzeW5jQWN0aW9uJztcbnZhciBRdWV1ZUFjdGlvbiA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFF1ZXVlQWN0aW9uLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFF1ZXVlQWN0aW9uKHNjaGVkdWxlciwgd29yaykge1xuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzLCBzY2hlZHVsZXIsIHdvcmspIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLnNjaGVkdWxlciA9IHNjaGVkdWxlcjtcbiAgICAgICAgX3RoaXMud29yayA9IHdvcms7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgUXVldWVBY3Rpb24ucHJvdG90eXBlLnNjaGVkdWxlID0gZnVuY3Rpb24gKHN0YXRlLCBkZWxheSkge1xuICAgICAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICAgICAgaWYgKGRlbGF5ID4gMCkge1xuICAgICAgICAgICAgcmV0dXJuIF9zdXBlci5wcm90b3R5cGUuc2NoZWR1bGUuY2FsbCh0aGlzLCBzdGF0ZSwgZGVsYXkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZGVsYXkgPSBkZWxheTtcbiAgICAgICAgdGhpcy5zdGF0ZSA9IHN0YXRlO1xuICAgICAgICB0aGlzLnNjaGVkdWxlci5mbHVzaCh0aGlzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICBRdWV1ZUFjdGlvbi5wcm90b3R5cGUuZXhlY3V0ZSA9IGZ1bmN0aW9uIChzdGF0ZSwgZGVsYXkpIHtcbiAgICAgICAgcmV0dXJuIGRlbGF5ID4gMCB8fCB0aGlzLmNsb3NlZCA/IF9zdXBlci5wcm90b3R5cGUuZXhlY3V0ZS5jYWxsKHRoaXMsIHN0YXRlLCBkZWxheSkgOiB0aGlzLl9leGVjdXRlKHN0YXRlLCBkZWxheSk7XG4gICAgfTtcbiAgICBRdWV1ZUFjdGlvbi5wcm90b3R5cGUucmVxdWVzdEFzeW5jSWQgPSBmdW5jdGlvbiAoc2NoZWR1bGVyLCBpZCwgZGVsYXkpIHtcbiAgICAgICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgICAgIGlmICgoZGVsYXkgIT0gbnVsbCAmJiBkZWxheSA+IDApIHx8IChkZWxheSA9PSBudWxsICYmIHRoaXMuZGVsYXkgPiAwKSkge1xuICAgICAgICAgICAgcmV0dXJuIF9zdXBlci5wcm90b3R5cGUucmVxdWVzdEFzeW5jSWQuY2FsbCh0aGlzLCBzY2hlZHVsZXIsIGlkLCBkZWxheSk7XG4gICAgICAgIH1cbiAgICAgICAgc2NoZWR1bGVyLmZsdXNoKHRoaXMpO1xuICAgICAgICByZXR1cm4gMDtcbiAgICB9O1xuICAgIHJldHVybiBRdWV1ZUFjdGlvbjtcbn0oQXN5bmNBY3Rpb24pKTtcbmV4cG9ydCB7IFF1ZXVlQWN0aW9uIH07XG4iLCJpbXBvcnQgeyBfX2V4dGVuZHMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IEFzeW5jU2NoZWR1bGVyIH0gZnJvbSAnLi9Bc3luY1NjaGVkdWxlcic7XG52YXIgUXVldWVTY2hlZHVsZXIgPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhRdWV1ZVNjaGVkdWxlciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBRdWV1ZVNjaGVkdWxlcigpIHtcbiAgICAgICAgcmV0dXJuIF9zdXBlciAhPT0gbnVsbCAmJiBfc3VwZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKSB8fCB0aGlzO1xuICAgIH1cbiAgICByZXR1cm4gUXVldWVTY2hlZHVsZXI7XG59KEFzeW5jU2NoZWR1bGVyKSk7XG5leHBvcnQgeyBRdWV1ZVNjaGVkdWxlciB9O1xuIiwiaW1wb3J0IHsgUXVldWVBY3Rpb24gfSBmcm9tICcuL1F1ZXVlQWN0aW9uJztcbmltcG9ydCB7IFF1ZXVlU2NoZWR1bGVyIH0gZnJvbSAnLi9RdWV1ZVNjaGVkdWxlcic7XG5leHBvcnQgdmFyIHF1ZXVlU2NoZWR1bGVyID0gbmV3IFF1ZXVlU2NoZWR1bGVyKFF1ZXVlQWN0aW9uKTtcbmV4cG9ydCB2YXIgcXVldWUgPSBxdWV1ZVNjaGVkdWxlcjtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgQXN5bmNBY3Rpb24gfSBmcm9tICcuL0FzeW5jQWN0aW9uJztcbmltcG9ydCB7IGFuaW1hdGlvbkZyYW1lUHJvdmlkZXIgfSBmcm9tICcuL2FuaW1hdGlvbkZyYW1lUHJvdmlkZXInO1xudmFyIEFuaW1hdGlvbkZyYW1lQWN0aW9uID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQW5pbWF0aW9uRnJhbWVBY3Rpb24sIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gQW5pbWF0aW9uRnJhbWVBY3Rpb24oc2NoZWR1bGVyLCB3b3JrKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMsIHNjaGVkdWxlciwgd29yaykgfHwgdGhpcztcbiAgICAgICAgX3RoaXMuc2NoZWR1bGVyID0gc2NoZWR1bGVyO1xuICAgICAgICBfdGhpcy53b3JrID0gd29yaztcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBBbmltYXRpb25GcmFtZUFjdGlvbi5wcm90b3R5cGUucmVxdWVzdEFzeW5jSWQgPSBmdW5jdGlvbiAoc2NoZWR1bGVyLCBpZCwgZGVsYXkpIHtcbiAgICAgICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgICAgIGlmIChkZWxheSAhPT0gbnVsbCAmJiBkZWxheSA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBfc3VwZXIucHJvdG90eXBlLnJlcXVlc3RBc3luY0lkLmNhbGwodGhpcywgc2NoZWR1bGVyLCBpZCwgZGVsYXkpO1xuICAgICAgICB9XG4gICAgICAgIHNjaGVkdWxlci5hY3Rpb25zLnB1c2godGhpcyk7XG4gICAgICAgIHJldHVybiBzY2hlZHVsZXIuX3NjaGVkdWxlZCB8fCAoc2NoZWR1bGVyLl9zY2hlZHVsZWQgPSBhbmltYXRpb25GcmFtZVByb3ZpZGVyLnJlcXVlc3RBbmltYXRpb25GcmFtZShmdW5jdGlvbiAoKSB7IHJldHVybiBzY2hlZHVsZXIuZmx1c2godW5kZWZpbmVkKTsgfSkpO1xuICAgIH07XG4gICAgQW5pbWF0aW9uRnJhbWVBY3Rpb24ucHJvdG90eXBlLnJlY3ljbGVBc3luY0lkID0gZnVuY3Rpb24gKHNjaGVkdWxlciwgaWQsIGRlbGF5KSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgICAgIGlmIChkZWxheSAhPSBudWxsID8gZGVsYXkgPiAwIDogdGhpcy5kZWxheSA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiBfc3VwZXIucHJvdG90eXBlLnJlY3ljbGVBc3luY0lkLmNhbGwodGhpcywgc2NoZWR1bGVyLCBpZCwgZGVsYXkpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBhY3Rpb25zID0gc2NoZWR1bGVyLmFjdGlvbnM7XG4gICAgICAgIGlmIChpZCAhPSBudWxsICYmIGlkID09PSBzY2hlZHVsZXIuX3NjaGVkdWxlZCAmJiAoKF9hID0gYWN0aW9uc1thY3Rpb25zLmxlbmd0aCAtIDFdKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuaWQpICE9PSBpZCkge1xuICAgICAgICAgICAgYW5pbWF0aW9uRnJhbWVQcm92aWRlci5jYW5jZWxBbmltYXRpb25GcmFtZShpZCk7XG4gICAgICAgICAgICBzY2hlZHVsZXIuX3NjaGVkdWxlZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH07XG4gICAgcmV0dXJuIEFuaW1hdGlvbkZyYW1lQWN0aW9uO1xufShBc3luY0FjdGlvbikpO1xuZXhwb3J0IHsgQW5pbWF0aW9uRnJhbWVBY3Rpb24gfTtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgQXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuL0FzeW5jU2NoZWR1bGVyJztcbnZhciBBbmltYXRpb25GcmFtZVNjaGVkdWxlciA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKEFuaW1hdGlvbkZyYW1lU2NoZWR1bGVyLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIEFuaW1hdGlvbkZyYW1lU2NoZWR1bGVyKCkge1xuICAgICAgICByZXR1cm4gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgfVxuICAgIEFuaW1hdGlvbkZyYW1lU2NoZWR1bGVyLnByb3RvdHlwZS5mbHVzaCA9IGZ1bmN0aW9uIChhY3Rpb24pIHtcbiAgICAgICAgdGhpcy5fYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgdmFyIGZsdXNoSWQ7XG4gICAgICAgIGlmIChhY3Rpb24pIHtcbiAgICAgICAgICAgIGZsdXNoSWQgPSBhY3Rpb24uaWQ7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBmbHVzaElkID0gdGhpcy5fc2NoZWR1bGVkO1xuICAgICAgICAgICAgdGhpcy5fc2NoZWR1bGVkID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHZhciBhY3Rpb25zID0gdGhpcy5hY3Rpb25zO1xuICAgICAgICB2YXIgZXJyb3I7XG4gICAgICAgIGFjdGlvbiA9IGFjdGlvbiB8fCBhY3Rpb25zLnNoaWZ0KCk7XG4gICAgICAgIGRvIHtcbiAgICAgICAgICAgIGlmICgoZXJyb3IgPSBhY3Rpb24uZXhlY3V0ZShhY3Rpb24uc3RhdGUsIGFjdGlvbi5kZWxheSkpKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gd2hpbGUgKChhY3Rpb24gPSBhY3Rpb25zWzBdKSAmJiBhY3Rpb24uaWQgPT09IGZsdXNoSWQgJiYgYWN0aW9ucy5zaGlmdCgpKTtcbiAgICAgICAgdGhpcy5fYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgd2hpbGUgKChhY3Rpb24gPSBhY3Rpb25zWzBdKSAmJiBhY3Rpb24uaWQgPT09IGZsdXNoSWQgJiYgYWN0aW9ucy5zaGlmdCgpKSB7XG4gICAgICAgICAgICAgICAgYWN0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIEFuaW1hdGlvbkZyYW1lU2NoZWR1bGVyO1xufShBc3luY1NjaGVkdWxlcikpO1xuZXhwb3J0IHsgQW5pbWF0aW9uRnJhbWVTY2hlZHVsZXIgfTtcbiIsImltcG9ydCB7IEFuaW1hdGlvbkZyYW1lQWN0aW9uIH0gZnJvbSAnLi9BbmltYXRpb25GcmFtZUFjdGlvbic7XG5pbXBvcnQgeyBBbmltYXRpb25GcmFtZVNjaGVkdWxlciB9IGZyb20gJy4vQW5pbWF0aW9uRnJhbWVTY2hlZHVsZXInO1xuZXhwb3J0IHZhciBhbmltYXRpb25GcmFtZVNjaGVkdWxlciA9IG5ldyBBbmltYXRpb25GcmFtZVNjaGVkdWxlcihBbmltYXRpb25GcmFtZUFjdGlvbik7XG5leHBvcnQgdmFyIGFuaW1hdGlvbkZyYW1lID0gYW5pbWF0aW9uRnJhbWVTY2hlZHVsZXI7XG4iLCJpbXBvcnQgeyBfX2V4dGVuZHMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IEFzeW5jQWN0aW9uIH0gZnJvbSAnLi9Bc3luY0FjdGlvbic7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICcuLi9TdWJzY3JpcHRpb24nO1xuaW1wb3J0IHsgQXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuL0FzeW5jU2NoZWR1bGVyJztcbnZhciBWaXJ0dWFsVGltZVNjaGVkdWxlciA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFZpcnR1YWxUaW1lU2NoZWR1bGVyLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFZpcnR1YWxUaW1lU2NoZWR1bGVyKHNjaGVkdWxlckFjdGlvbkN0b3IsIG1heEZyYW1lcykge1xuICAgICAgICBpZiAoc2NoZWR1bGVyQWN0aW9uQ3RvciA9PT0gdm9pZCAwKSB7IHNjaGVkdWxlckFjdGlvbkN0b3IgPSBWaXJ0dWFsQWN0aW9uOyB9XG4gICAgICAgIGlmIChtYXhGcmFtZXMgPT09IHZvaWQgMCkgeyBtYXhGcmFtZXMgPSBJbmZpbml0eTsgfVxuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzLCBzY2hlZHVsZXJBY3Rpb25DdG9yLCBmdW5jdGlvbiAoKSB7IHJldHVybiBfdGhpcy5mcmFtZTsgfSkgfHwgdGhpcztcbiAgICAgICAgX3RoaXMubWF4RnJhbWVzID0gbWF4RnJhbWVzO1xuICAgICAgICBfdGhpcy5mcmFtZSA9IDA7XG4gICAgICAgIF90aGlzLmluZGV4ID0gLTE7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgVmlydHVhbFRpbWVTY2hlZHVsZXIucHJvdG90eXBlLmZsdXNoID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX2EgPSB0aGlzLCBhY3Rpb25zID0gX2EuYWN0aW9ucywgbWF4RnJhbWVzID0gX2EubWF4RnJhbWVzO1xuICAgICAgICB2YXIgZXJyb3I7XG4gICAgICAgIHZhciBhY3Rpb247XG4gICAgICAgIHdoaWxlICgoYWN0aW9uID0gYWN0aW9uc1swXSkgJiYgYWN0aW9uLmRlbGF5IDw9IG1heEZyYW1lcykge1xuICAgICAgICAgICAgYWN0aW9ucy5zaGlmdCgpO1xuICAgICAgICAgICAgdGhpcy5mcmFtZSA9IGFjdGlvbi5kZWxheTtcbiAgICAgICAgICAgIGlmICgoZXJyb3IgPSBhY3Rpb24uZXhlY3V0ZShhY3Rpb24uc3RhdGUsIGFjdGlvbi5kZWxheSkpKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICB3aGlsZSAoKGFjdGlvbiA9IGFjdGlvbnMuc2hpZnQoKSkpIHtcbiAgICAgICAgICAgICAgICBhY3Rpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBWaXJ0dWFsVGltZVNjaGVkdWxlci5mcmFtZVRpbWVGYWN0b3IgPSAxMDtcbiAgICByZXR1cm4gVmlydHVhbFRpbWVTY2hlZHVsZXI7XG59KEFzeW5jU2NoZWR1bGVyKSk7XG5leHBvcnQgeyBWaXJ0dWFsVGltZVNjaGVkdWxlciB9O1xudmFyIFZpcnR1YWxBY3Rpb24gPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhWaXJ0dWFsQWN0aW9uLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFZpcnR1YWxBY3Rpb24oc2NoZWR1bGVyLCB3b3JrLCBpbmRleCkge1xuICAgICAgICBpZiAoaW5kZXggPT09IHZvaWQgMCkgeyBpbmRleCA9IChzY2hlZHVsZXIuaW5kZXggKz0gMSk7IH1cbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyLmNhbGwodGhpcywgc2NoZWR1bGVyLCB3b3JrKSB8fCB0aGlzO1xuICAgICAgICBfdGhpcy5zY2hlZHVsZXIgPSBzY2hlZHVsZXI7XG4gICAgICAgIF90aGlzLndvcmsgPSB3b3JrO1xuICAgICAgICBfdGhpcy5pbmRleCA9IGluZGV4O1xuICAgICAgICBfdGhpcy5hY3RpdmUgPSB0cnVlO1xuICAgICAgICBfdGhpcy5pbmRleCA9IHNjaGVkdWxlci5pbmRleCA9IGluZGV4O1xuICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgfVxuICAgIFZpcnR1YWxBY3Rpb24ucHJvdG90eXBlLnNjaGVkdWxlID0gZnVuY3Rpb24gKHN0YXRlLCBkZWxheSkge1xuICAgICAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICAgICAgaWYgKE51bWJlci5pc0Zpbml0ZShkZWxheSkpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5pZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfc3VwZXIucHJvdG90eXBlLnNjaGVkdWxlLmNhbGwodGhpcywgc3RhdGUsIGRlbGF5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICB2YXIgYWN0aW9uID0gbmV3IFZpcnR1YWxBY3Rpb24odGhpcy5zY2hlZHVsZXIsIHRoaXMud29yayk7XG4gICAgICAgICAgICB0aGlzLmFkZChhY3Rpb24pO1xuICAgICAgICAgICAgcmV0dXJuIGFjdGlvbi5zY2hlZHVsZShzdGF0ZSwgZGVsYXkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIFN1YnNjcmlwdGlvbi5FTVBUWTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgVmlydHVhbEFjdGlvbi5wcm90b3R5cGUucmVxdWVzdEFzeW5jSWQgPSBmdW5jdGlvbiAoc2NoZWR1bGVyLCBpZCwgZGVsYXkpIHtcbiAgICAgICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgICAgIHRoaXMuZGVsYXkgPSBzY2hlZHVsZXIuZnJhbWUgKyBkZWxheTtcbiAgICAgICAgdmFyIGFjdGlvbnMgPSBzY2hlZHVsZXIuYWN0aW9ucztcbiAgICAgICAgYWN0aW9ucy5wdXNoKHRoaXMpO1xuICAgICAgICBhY3Rpb25zLnNvcnQoVmlydHVhbEFjdGlvbi5zb3J0QWN0aW9ucyk7XG4gICAgICAgIHJldHVybiAxO1xuICAgIH07XG4gICAgVmlydHVhbEFjdGlvbi5wcm90b3R5cGUucmVjeWNsZUFzeW5jSWQgPSBmdW5jdGlvbiAoc2NoZWR1bGVyLCBpZCwgZGVsYXkpIHtcbiAgICAgICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICBWaXJ0dWFsQWN0aW9uLnByb3RvdHlwZS5fZXhlY3V0ZSA9IGZ1bmN0aW9uIChzdGF0ZSwgZGVsYXkpIHtcbiAgICAgICAgaWYgKHRoaXMuYWN0aXZlID09PSB0cnVlKSB7XG4gICAgICAgICAgICByZXR1cm4gX3N1cGVyLnByb3RvdHlwZS5fZXhlY3V0ZS5jYWxsKHRoaXMsIHN0YXRlLCBkZWxheSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFZpcnR1YWxBY3Rpb24uc29ydEFjdGlvbnMgPSBmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICBpZiAoYS5kZWxheSA9PT0gYi5kZWxheSkge1xuICAgICAgICAgICAgaWYgKGEuaW5kZXggPT09IGIuaW5kZXgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGEuaW5kZXggPiBiLmluZGV4KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYS5kZWxheSA+IGIuZGVsYXkpIHtcbiAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gVmlydHVhbEFjdGlvbjtcbn0oQXN5bmNBY3Rpb24pKTtcbmV4cG9ydCB7IFZpcnR1YWxBY3Rpb24gfTtcbiIsImltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuLi9PYnNlcnZhYmxlJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuL2lzRnVuY3Rpb24nO1xuZXhwb3J0IGZ1bmN0aW9uIGlzT2JzZXJ2YWJsZShvYmopIHtcbiAgICByZXR1cm4gISFvYmogJiYgKG9iaiBpbnN0YW5jZW9mIE9ic2VydmFibGUgfHwgKGlzRnVuY3Rpb24ob2JqLmxpZnQpICYmIGlzRnVuY3Rpb24ob2JqLnN1YnNjcmliZSkpKTtcbn1cbiIsImltcG9ydCB7IEVtcHR5RXJyb3IgfSBmcm9tICcuL3V0aWwvRW1wdHlFcnJvcic7XG5leHBvcnQgZnVuY3Rpb24gbGFzdFZhbHVlRnJvbShzb3VyY2UsIGNvbmZpZykge1xuICAgIHZhciBoYXNDb25maWcgPSB0eXBlb2YgY29uZmlnID09PSAnb2JqZWN0JztcbiAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICB2YXIgX2hhc1ZhbHVlID0gZmFsc2U7XG4gICAgICAgIHZhciBfdmFsdWU7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgX3ZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgX2hhc1ZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogcmVqZWN0LFxuICAgICAgICAgICAgY29tcGxldGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAoX2hhc1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoX3ZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaGFzQ29uZmlnKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoY29uZmlnLmRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZWplY3QobmV3IEVtcHR5RXJyb3IoKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBFbXB0eUVycm9yIH0gZnJvbSAnLi91dGlsL0VtcHR5RXJyb3InO1xuaW1wb3J0IHsgU2FmZVN1YnNjcmliZXIgfSBmcm9tICcuL1N1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGZpcnN0VmFsdWVGcm9tKHNvdXJjZSwgY29uZmlnKSB7XG4gICAgdmFyIGhhc0NvbmZpZyA9IHR5cGVvZiBjb25maWcgPT09ICdvYmplY3QnO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgIHZhciBzdWJzY3JpYmVyID0gbmV3IFNhZmVTdWJzY3JpYmVyKHtcbiAgICAgICAgICAgIG5leHQ6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogcmVqZWN0LFxuICAgICAgICAgICAgY29tcGxldGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAoaGFzQ29uZmlnKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUoY29uZmlnLmRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZWplY3QobmV3IEVtcHR5RXJyb3IoKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGlzU2NoZWR1bGVyIH0gZnJvbSAnLi4vdXRpbC9pc1NjaGVkdWxlcic7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBzdWJzY3JpYmVPbiB9IGZyb20gJy4uL29wZXJhdG9ycy9zdWJzY3JpYmVPbic7XG5pbXBvcnQgeyBtYXBPbmVPck1hbnlBcmdzIH0gZnJvbSAnLi4vdXRpbC9tYXBPbmVPck1hbnlBcmdzJztcbmltcG9ydCB7IG9ic2VydmVPbiB9IGZyb20gJy4uL29wZXJhdG9ycy9vYnNlcnZlT24nO1xuaW1wb3J0IHsgQXN5bmNTdWJqZWN0IH0gZnJvbSAnLi4vQXN5bmNTdWJqZWN0JztcbmV4cG9ydCBmdW5jdGlvbiBiaW5kQ2FsbGJhY2tJbnRlcm5hbHMoaXNOb2RlU3R5bGUsIGNhbGxiYWNrRnVuYywgcmVzdWx0U2VsZWN0b3IsIHNjaGVkdWxlcikge1xuICAgIGlmIChyZXN1bHRTZWxlY3Rvcikge1xuICAgICAgICBpZiAoaXNTY2hlZHVsZXIocmVzdWx0U2VsZWN0b3IpKSB7XG4gICAgICAgICAgICBzY2hlZHVsZXIgPSByZXN1bHRTZWxlY3RvcjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIGFyZ3MgPSBbXTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgICAgICAgICBhcmdzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBiaW5kQ2FsbGJhY2tJbnRlcm5hbHMoaXNOb2RlU3R5bGUsIGNhbGxiYWNrRnVuYywgc2NoZWR1bGVyKVxuICAgICAgICAgICAgICAgICAgICAuYXBwbHkodGhpcywgYXJncylcbiAgICAgICAgICAgICAgICAgICAgLnBpcGUobWFwT25lT3JNYW55QXJncyhyZXN1bHRTZWxlY3RvcikpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoc2NoZWR1bGVyKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgYXJncyA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICBhcmdzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gYmluZENhbGxiYWNrSW50ZXJuYWxzKGlzTm9kZVN0eWxlLCBjYWxsYmFja0Z1bmMpXG4gICAgICAgICAgICAgICAgLmFwcGx5KHRoaXMsIGFyZ3MpXG4gICAgICAgICAgICAgICAgLnBpcGUoc3Vic2NyaWJlT24oc2NoZWR1bGVyKSwgb2JzZXJ2ZU9uKHNjaGVkdWxlcikpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB2YXIgYXJncyA9IFtdO1xuICAgICAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICB9XG4gICAgICAgIHZhciBzdWJqZWN0ID0gbmV3IEFzeW5jU3ViamVjdCgpO1xuICAgICAgICB2YXIgdW5pbml0aWFsaXplZCA9IHRydWU7XG4gICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICAgICAgdmFyIHN1YnMgPSBzdWJqZWN0LnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgICAgIGlmICh1bmluaXRpYWxpemVkKSB7XG4gICAgICAgICAgICAgICAgdW5pbml0aWFsaXplZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHZhciBpc0FzeW5jXzEgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB2YXIgaXNDb21wbGV0ZV8xID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2tGdW5jLmFwcGx5KF90aGlzLCBfX3NwcmVhZEFycmF5KF9fc3ByZWFkQXJyYXkoW10sIF9fcmVhZChhcmdzKSksIFtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0c1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzTm9kZVN0eWxlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGVyciA9IHJlc3VsdHMuc2hpZnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3ViamVjdC5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgc3ViamVjdC5uZXh0KDEgPCByZXN1bHRzLmxlbmd0aCA/IHJlc3VsdHMgOiByZXN1bHRzWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29tcGxldGVfMSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNBc3luY18xKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3ViamVjdC5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF0pKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNDb21wbGV0ZV8xKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1YmplY3QuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaXNBc3luY18xID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBzdWJzO1xuICAgICAgICB9KTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgYmluZENhbGxiYWNrSW50ZXJuYWxzIH0gZnJvbSAnLi9iaW5kQ2FsbGJhY2tJbnRlcm5hbHMnO1xuZXhwb3J0IGZ1bmN0aW9uIGJpbmRDYWxsYmFjayhjYWxsYmFja0Z1bmMsIHJlc3VsdFNlbGVjdG9yLCBzY2hlZHVsZXIpIHtcbiAgICByZXR1cm4gYmluZENhbGxiYWNrSW50ZXJuYWxzKGZhbHNlLCBjYWxsYmFja0Z1bmMsIHJlc3VsdFNlbGVjdG9yLCBzY2hlZHVsZXIpO1xufVxuIiwiaW1wb3J0IHsgYmluZENhbGxiYWNrSW50ZXJuYWxzIH0gZnJvbSAnLi9iaW5kQ2FsbGJhY2tJbnRlcm5hbHMnO1xuZXhwb3J0IGZ1bmN0aW9uIGJpbmROb2RlQ2FsbGJhY2soY2FsbGJhY2tGdW5jLCByZXN1bHRTZWxlY3Rvciwgc2NoZWR1bGVyKSB7XG4gICAgcmV0dXJuIGJpbmRDYWxsYmFja0ludGVybmFscyh0cnVlLCBjYWxsYmFja0Z1bmMsIHJlc3VsdFNlbGVjdG9yLCBzY2hlZHVsZXIpO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGRlZmVyKG9ic2VydmFibGVGYWN0b3J5KSB7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIGlubmVyRnJvbShvYnNlcnZhYmxlRmFjdG9yeSgpKS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAnLi4vU3ViamVjdCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBkZWZlciB9IGZyb20gJy4vZGVmZXInO1xudmFyIERFRkFVTFRfQ09ORklHID0ge1xuICAgIGNvbm5lY3RvcjogZnVuY3Rpb24gKCkgeyByZXR1cm4gbmV3IFN1YmplY3QoKTsgfSxcbiAgICByZXNldE9uRGlzY29ubmVjdDogdHJ1ZSxcbn07XG5leHBvcnQgZnVuY3Rpb24gY29ubmVjdGFibGUoc291cmNlLCBjb25maWcpIHtcbiAgICBpZiAoY29uZmlnID09PSB2b2lkIDApIHsgY29uZmlnID0gREVGQVVMVF9DT05GSUc7IH1cbiAgICB2YXIgY29ubmVjdGlvbiA9IG51bGw7XG4gICAgdmFyIGNvbm5lY3RvciA9IGNvbmZpZy5jb25uZWN0b3IsIF9hID0gY29uZmlnLnJlc2V0T25EaXNjb25uZWN0LCByZXNldE9uRGlzY29ubmVjdCA9IF9hID09PSB2b2lkIDAgPyB0cnVlIDogX2E7XG4gICAgdmFyIHN1YmplY3QgPSBjb25uZWN0b3IoKTtcbiAgICB2YXIgcmVzdWx0ID0gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgcmV0dXJuIHN1YmplY3Quc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgIH0pO1xuICAgIHJlc3VsdC5jb25uZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoIWNvbm5lY3Rpb24gfHwgY29ubmVjdGlvbi5jbG9zZWQpIHtcbiAgICAgICAgICAgIGNvbm5lY3Rpb24gPSBkZWZlcihmdW5jdGlvbiAoKSB7IHJldHVybiBzb3VyY2U7IH0pLnN1YnNjcmliZShzdWJqZWN0KTtcbiAgICAgICAgICAgIGlmIChyZXNldE9uRGlzY29ubmVjdCkge1xuICAgICAgICAgICAgICAgIGNvbm5lY3Rpb24uYWRkKGZ1bmN0aW9uICgpIHsgcmV0dXJuIChzdWJqZWN0ID0gY29ubmVjdG9yKCkpOyB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29ubmVjdGlvbjtcbiAgICB9O1xuICAgIHJldHVybiByZXN1bHQ7XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBhcmdzQXJnQXJyYXlPck9iamVjdCB9IGZyb20gJy4uL3V0aWwvYXJnc0FyZ0FycmF5T3JPYmplY3QnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi9pbm5lckZyb20nO1xuaW1wb3J0IHsgcG9wUmVzdWx0U2VsZWN0b3IgfSBmcm9tICcuLi91dGlsL2FyZ3MnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi4vb3BlcmF0b3JzL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBtYXBPbmVPck1hbnlBcmdzIH0gZnJvbSAnLi4vdXRpbC9tYXBPbmVPck1hbnlBcmdzJztcbmltcG9ydCB7IGNyZWF0ZU9iamVjdCB9IGZyb20gJy4uL3V0aWwvY3JlYXRlT2JqZWN0JztcbmV4cG9ydCBmdW5jdGlvbiBmb3JrSm9pbigpIHtcbiAgICB2YXIgYXJncyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIGFyZ3NbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIHJlc3VsdFNlbGVjdG9yID0gcG9wUmVzdWx0U2VsZWN0b3IoYXJncyk7XG4gICAgdmFyIF9hID0gYXJnc0FyZ0FycmF5T3JPYmplY3QoYXJncyksIHNvdXJjZXMgPSBfYS5hcmdzLCBrZXlzID0gX2Eua2V5cztcbiAgICB2YXIgcmVzdWx0ID0gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGxlbmd0aCA9IHNvdXJjZXMubGVuZ3RoO1xuICAgICAgICBpZiAoIWxlbmd0aCkge1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciB2YWx1ZXMgPSBuZXcgQXJyYXkobGVuZ3RoKTtcbiAgICAgICAgdmFyIHJlbWFpbmluZ0NvbXBsZXRpb25zID0gbGVuZ3RoO1xuICAgICAgICB2YXIgcmVtYWluaW5nRW1pc3Npb25zID0gbGVuZ3RoO1xuICAgICAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uIChzb3VyY2VJbmRleCkge1xuICAgICAgICAgICAgdmFyIGhhc1ZhbHVlID0gZmFsc2U7XG4gICAgICAgICAgICBpbm5lckZyb20oc291cmNlc1tzb3VyY2VJbmRleF0pLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFoYXNWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBoYXNWYWx1ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHJlbWFpbmluZ0VtaXNzaW9ucy0tO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YWx1ZXNbc291cmNlSW5kZXhdID0gdmFsdWU7XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7IHJldHVybiByZW1haW5pbmdDb21wbGV0aW9ucy0tOyB9LCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXJlbWFpbmluZ0NvbXBsZXRpb25zIHx8ICFoYXNWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXJlbWFpbmluZ0VtaXNzaW9ucykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGtleXMgPyBjcmVhdGVPYmplY3Qoa2V5cywgdmFsdWVzKSA6IHZhbHVlcyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgfTtcbiAgICAgICAgZm9yICh2YXIgc291cmNlSW5kZXggPSAwOyBzb3VyY2VJbmRleCA8IGxlbmd0aDsgc291cmNlSW5kZXgrKykge1xuICAgICAgICAgICAgX2xvb3BfMShzb3VyY2VJbmRleCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gcmVzdWx0U2VsZWN0b3IgPyByZXN1bHQucGlwZShtYXBPbmVPck1hbnlBcmdzKHJlc3VsdFNlbGVjdG9yKSkgOiByZXN1bHQ7XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuLi9PYnNlcnZhYmxlJztcbmltcG9ydCB7IG1lcmdlTWFwIH0gZnJvbSAnLi4vb3BlcmF0b3JzL21lcmdlTWFwJztcbmltcG9ydCB7IGlzQXJyYXlMaWtlIH0gZnJvbSAnLi4vdXRpbC9pc0FycmF5TGlrZSc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi4vdXRpbC9pc0Z1bmN0aW9uJztcbmltcG9ydCB7IG1hcE9uZU9yTWFueUFyZ3MgfSBmcm9tICcuLi91dGlsL21hcE9uZU9yTWFueUFyZ3MnO1xudmFyIG5vZGVFdmVudEVtaXR0ZXJNZXRob2RzID0gWydhZGRMaXN0ZW5lcicsICdyZW1vdmVMaXN0ZW5lciddO1xudmFyIGV2ZW50VGFyZ2V0TWV0aG9kcyA9IFsnYWRkRXZlbnRMaXN0ZW5lcicsICdyZW1vdmVFdmVudExpc3RlbmVyJ107XG52YXIganF1ZXJ5TWV0aG9kcyA9IFsnb24nLCAnb2ZmJ107XG5leHBvcnQgZnVuY3Rpb24gZnJvbUV2ZW50KHRhcmdldCwgZXZlbnROYW1lLCBvcHRpb25zLCByZXN1bHRTZWxlY3Rvcikge1xuICAgIGlmIChpc0Z1bmN0aW9uKG9wdGlvbnMpKSB7XG4gICAgICAgIHJlc3VsdFNlbGVjdG9yID0gb3B0aW9ucztcbiAgICAgICAgb3B0aW9ucyA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKHJlc3VsdFNlbGVjdG9yKSB7XG4gICAgICAgIHJldHVybiBmcm9tRXZlbnQodGFyZ2V0LCBldmVudE5hbWUsIG9wdGlvbnMpLnBpcGUobWFwT25lT3JNYW55QXJncyhyZXN1bHRTZWxlY3RvcikpO1xuICAgIH1cbiAgICB2YXIgX2EgPSBfX3JlYWQoaXNFdmVudFRhcmdldCh0YXJnZXQpXG4gICAgICAgID8gZXZlbnRUYXJnZXRNZXRob2RzLm1hcChmdW5jdGlvbiAobWV0aG9kTmFtZSkgeyByZXR1cm4gZnVuY3Rpb24gKGhhbmRsZXIpIHsgcmV0dXJuIHRhcmdldFttZXRob2ROYW1lXShldmVudE5hbWUsIGhhbmRsZXIsIG9wdGlvbnMpOyB9OyB9KVxuICAgICAgICA6XG4gICAgICAgICAgICBpc05vZGVTdHlsZUV2ZW50RW1pdHRlcih0YXJnZXQpXG4gICAgICAgICAgICAgICAgPyBub2RlRXZlbnRFbWl0dGVyTWV0aG9kcy5tYXAodG9Db21tb25IYW5kbGVyUmVnaXN0cnkodGFyZ2V0LCBldmVudE5hbWUpKVxuICAgICAgICAgICAgICAgIDogaXNKUXVlcnlTdHlsZUV2ZW50RW1pdHRlcih0YXJnZXQpXG4gICAgICAgICAgICAgICAgICAgID8ganF1ZXJ5TWV0aG9kcy5tYXAodG9Db21tb25IYW5kbGVyUmVnaXN0cnkodGFyZ2V0LCBldmVudE5hbWUpKVxuICAgICAgICAgICAgICAgICAgICA6IFtdLCAyKSwgYWRkID0gX2FbMF0sIHJlbW92ZSA9IF9hWzFdO1xuICAgIGlmICghYWRkKSB7XG4gICAgICAgIGlmIChpc0FycmF5TGlrZSh0YXJnZXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gbWVyZ2VNYXAoZnVuY3Rpb24gKHN1YlRhcmdldCkgeyByZXR1cm4gZnJvbUV2ZW50KHN1YlRhcmdldCwgZXZlbnROYW1lLCBvcHRpb25zKTsgfSkoaW5uZXJGcm9tKHRhcmdldCkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmICghYWRkKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0ludmFsaWQgZXZlbnQgdGFyZ2V0Jyk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgaGFuZGxlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBhcmdzID0gW107XG4gICAgICAgICAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICAgICAgICAgIGFyZ3NbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBzdWJzY3JpYmVyLm5leHQoMSA8IGFyZ3MubGVuZ3RoID8gYXJncyA6IGFyZ3NbMF0pO1xuICAgICAgICB9O1xuICAgICAgICBhZGQoaGFuZGxlcik7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7IHJldHVybiByZW1vdmUoaGFuZGxlcik7IH07XG4gICAgfSk7XG59XG5mdW5jdGlvbiB0b0NvbW1vbkhhbmRsZXJSZWdpc3RyeSh0YXJnZXQsIGV2ZW50TmFtZSkge1xuICAgIHJldHVybiBmdW5jdGlvbiAobWV0aG9kTmFtZSkgeyByZXR1cm4gZnVuY3Rpb24gKGhhbmRsZXIpIHsgcmV0dXJuIHRhcmdldFttZXRob2ROYW1lXShldmVudE5hbWUsIGhhbmRsZXIpOyB9OyB9O1xufVxuZnVuY3Rpb24gaXNOb2RlU3R5bGVFdmVudEVtaXR0ZXIodGFyZ2V0KSB7XG4gICAgcmV0dXJuIGlzRnVuY3Rpb24odGFyZ2V0LmFkZExpc3RlbmVyKSAmJiBpc0Z1bmN0aW9uKHRhcmdldC5yZW1vdmVMaXN0ZW5lcik7XG59XG5mdW5jdGlvbiBpc0pRdWVyeVN0eWxlRXZlbnRFbWl0dGVyKHRhcmdldCkge1xuICAgIHJldHVybiBpc0Z1bmN0aW9uKHRhcmdldC5vbikgJiYgaXNGdW5jdGlvbih0YXJnZXQub2ZmKTtcbn1cbmZ1bmN0aW9uIGlzRXZlbnRUYXJnZXQodGFyZ2V0KSB7XG4gICAgcmV0dXJuIGlzRnVuY3Rpb24odGFyZ2V0LmFkZEV2ZW50TGlzdGVuZXIpICYmIGlzRnVuY3Rpb24odGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIpO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4uL3V0aWwvaXNGdW5jdGlvbic7XG5pbXBvcnQgeyBtYXBPbmVPck1hbnlBcmdzIH0gZnJvbSAnLi4vdXRpbC9tYXBPbmVPck1hbnlBcmdzJztcbmV4cG9ydCBmdW5jdGlvbiBmcm9tRXZlbnRQYXR0ZXJuKGFkZEhhbmRsZXIsIHJlbW92ZUhhbmRsZXIsIHJlc3VsdFNlbGVjdG9yKSB7XG4gICAgaWYgKHJlc3VsdFNlbGVjdG9yKSB7XG4gICAgICAgIHJldHVybiBmcm9tRXZlbnRQYXR0ZXJuKGFkZEhhbmRsZXIsIHJlbW92ZUhhbmRsZXIpLnBpcGUobWFwT25lT3JNYW55QXJncyhyZXN1bHRTZWxlY3RvcikpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGhhbmRsZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgZSA9IFtdO1xuICAgICAgICAgICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICBlW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gc3Vic2NyaWJlci5uZXh0KGUubGVuZ3RoID09PSAxID8gZVswXSA6IGUpO1xuICAgICAgICB9O1xuICAgICAgICB2YXIgcmV0VmFsdWUgPSBhZGRIYW5kbGVyKGhhbmRsZXIpO1xuICAgICAgICByZXR1cm4gaXNGdW5jdGlvbihyZW1vdmVIYW5kbGVyKSA/IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHJlbW92ZUhhbmRsZXIoaGFuZGxlciwgcmV0VmFsdWUpOyB9IDogdW5kZWZpbmVkO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgX19nZW5lcmF0b3IgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGlkZW50aXR5IH0gZnJvbSAnLi4vdXRpbC9pZGVudGl0eSc7XG5pbXBvcnQgeyBpc1NjaGVkdWxlciB9IGZyb20gJy4uL3V0aWwvaXNTY2hlZHVsZXInO1xuaW1wb3J0IHsgZGVmZXIgfSBmcm9tICcuL2RlZmVyJztcbmltcG9ydCB7IHNjaGVkdWxlSXRlcmFibGUgfSBmcm9tICcuLi9zY2hlZHVsZWQvc2NoZWR1bGVJdGVyYWJsZSc7XG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGUoaW5pdGlhbFN0YXRlT3JPcHRpb25zLCBjb25kaXRpb24sIGl0ZXJhdGUsIHJlc3VsdFNlbGVjdG9yT3JTY2hlZHVsZXIsIHNjaGVkdWxlcikge1xuICAgIHZhciBfYSwgX2I7XG4gICAgdmFyIHJlc3VsdFNlbGVjdG9yO1xuICAgIHZhciBpbml0aWFsU3RhdGU7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgKF9hID0gaW5pdGlhbFN0YXRlT3JPcHRpb25zLCBpbml0aWFsU3RhdGUgPSBfYS5pbml0aWFsU3RhdGUsIGNvbmRpdGlvbiA9IF9hLmNvbmRpdGlvbiwgaXRlcmF0ZSA9IF9hLml0ZXJhdGUsIF9iID0gX2EucmVzdWx0U2VsZWN0b3IsIHJlc3VsdFNlbGVjdG9yID0gX2IgPT09IHZvaWQgMCA/IGlkZW50aXR5IDogX2IsIHNjaGVkdWxlciA9IF9hLnNjaGVkdWxlcik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBpbml0aWFsU3RhdGUgPSBpbml0aWFsU3RhdGVPck9wdGlvbnM7XG4gICAgICAgIGlmICghcmVzdWx0U2VsZWN0b3JPclNjaGVkdWxlciB8fCBpc1NjaGVkdWxlcihyZXN1bHRTZWxlY3Rvck9yU2NoZWR1bGVyKSkge1xuICAgICAgICAgICAgcmVzdWx0U2VsZWN0b3IgPSBpZGVudGl0eTtcbiAgICAgICAgICAgIHNjaGVkdWxlciA9IHJlc3VsdFNlbGVjdG9yT3JTY2hlZHVsZXI7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXN1bHRTZWxlY3RvciA9IHJlc3VsdFNlbGVjdG9yT3JTY2hlZHVsZXI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gZ2VuKCkge1xuICAgICAgICB2YXIgc3RhdGU7XG4gICAgICAgIHJldHVybiBfX2dlbmVyYXRvcih0aGlzLCBmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgIHN3aXRjaCAoX2EubGFiZWwpIHtcbiAgICAgICAgICAgICAgICBjYXNlIDA6XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlID0gaW5pdGlhbFN0YXRlO1xuICAgICAgICAgICAgICAgICAgICBfYS5sYWJlbCA9IDE7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBpZiAoISghY29uZGl0aW9uIHx8IGNvbmRpdGlvbihzdGF0ZSkpKSByZXR1cm4gWzMsIDRdO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzQsIHJlc3VsdFNlbGVjdG9yKHN0YXRlKV07XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBfYS5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIF9hLmxhYmVsID0gMztcbiAgICAgICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlID0gaXRlcmF0ZShzdGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMywgMV07XG4gICAgICAgICAgICAgICAgY2FzZSA0OiByZXR1cm4gWzJdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGRlZmVyKChzY2hlZHVsZXJcbiAgICAgICAgP1xuICAgICAgICAgICAgZnVuY3Rpb24gKCkgeyByZXR1cm4gc2NoZWR1bGVJdGVyYWJsZShnZW4oKSwgc2NoZWR1bGVyKTsgfVxuICAgICAgICA6XG4gICAgICAgICAgICBnZW4pKTtcbn1cbiIsImltcG9ydCB7IGRlZmVyIH0gZnJvbSAnLi9kZWZlcic7XG5leHBvcnQgZnVuY3Rpb24gaWlmKGNvbmRpdGlvbiwgdHJ1ZVJlc3VsdCwgZmFsc2VSZXN1bHQpIHtcbiAgICByZXR1cm4gZGVmZXIoZnVuY3Rpb24gKCkgeyByZXR1cm4gKGNvbmRpdGlvbigpID8gdHJ1ZVJlc3VsdCA6IGZhbHNlUmVzdWx0KTsgfSk7XG59XG4iLCJpbXBvcnQgeyBtZXJnZUFsbCB9IGZyb20gJy4uL29wZXJhdG9ycy9tZXJnZUFsbCc7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBFTVBUWSB9IGZyb20gJy4vZW1wdHknO1xuaW1wb3J0IHsgcG9wTnVtYmVyLCBwb3BTY2hlZHVsZXIgfSBmcm9tICcuLi91dGlsL2FyZ3MnO1xuaW1wb3J0IHsgZnJvbSB9IGZyb20gJy4vZnJvbSc7XG5leHBvcnQgZnVuY3Rpb24gbWVyZ2UoKSB7XG4gICAgdmFyIGFyZ3MgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICBhcmdzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHZhciBzY2hlZHVsZXIgPSBwb3BTY2hlZHVsZXIoYXJncyk7XG4gICAgdmFyIGNvbmN1cnJlbnQgPSBwb3BOdW1iZXIoYXJncywgSW5maW5pdHkpO1xuICAgIHZhciBzb3VyY2VzID0gYXJncztcbiAgICByZXR1cm4gIXNvdXJjZXMubGVuZ3RoXG4gICAgICAgID9cbiAgICAgICAgICAgIEVNUFRZXG4gICAgICAgIDogc291cmNlcy5sZW5ndGggPT09IDFcbiAgICAgICAgICAgID9cbiAgICAgICAgICAgICAgICBpbm5lckZyb20oc291cmNlc1swXSlcbiAgICAgICAgICAgIDpcbiAgICAgICAgICAgICAgICBtZXJnZUFsbChjb25jdXJyZW50KShmcm9tKHNvdXJjZXMsIHNjaGVkdWxlcikpO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gJy4uL3V0aWwvbm9vcCc7XG5leHBvcnQgdmFyIE5FVkVSID0gbmV3IE9ic2VydmFibGUobm9vcCk7XG5leHBvcnQgZnVuY3Rpb24gbmV2ZXIoKSB7XG4gICAgcmV0dXJuIE5FVkVSO1xufVxuIiwiaW1wb3J0IHsgZnJvbSB9IGZyb20gJy4vZnJvbSc7XG5leHBvcnQgZnVuY3Rpb24gcGFpcnMob2JqLCBzY2hlZHVsZXIpIHtcbiAgICByZXR1cm4gZnJvbShPYmplY3QuZW50cmllcyhvYmopLCBzY2hlZHVsZXIpO1xufVxuIiwiaW1wb3J0IHsgbm90IH0gZnJvbSAnLi4vdXRpbC9ub3QnO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAnLi4vb3BlcmF0b3JzL2ZpbHRlcic7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuL2lubmVyRnJvbSc7XG5leHBvcnQgZnVuY3Rpb24gcGFydGl0aW9uKHNvdXJjZSwgcHJlZGljYXRlLCB0aGlzQXJnKSB7XG4gICAgcmV0dXJuIFtmaWx0ZXIocHJlZGljYXRlLCB0aGlzQXJnKShpbm5lckZyb20oc291cmNlKSksIGZpbHRlcihub3QocHJlZGljYXRlLCB0aGlzQXJnKSkoaW5uZXJGcm9tKHNvdXJjZSkpXTtcbn1cbiIsImltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuLi9PYnNlcnZhYmxlJztcbmltcG9ydCB7IEVNUFRZIH0gZnJvbSAnLi9lbXB0eSc7XG5leHBvcnQgZnVuY3Rpb24gcmFuZ2Uoc3RhcnQsIGNvdW50LCBzY2hlZHVsZXIpIHtcbiAgICBpZiAoY291bnQgPT0gbnVsbCkge1xuICAgICAgICBjb3VudCA9IHN0YXJ0O1xuICAgICAgICBzdGFydCA9IDA7XG4gICAgfVxuICAgIGlmIChjb3VudCA8PSAwKSB7XG4gICAgICAgIHJldHVybiBFTVBUWTtcbiAgICB9XG4gICAgdmFyIGVuZCA9IGNvdW50ICsgc3RhcnQ7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKHNjaGVkdWxlclxuICAgICAgICA/XG4gICAgICAgICAgICBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICAgICAgICAgIHZhciBuID0gc3RhcnQ7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHNjaGVkdWxlci5zY2hlZHVsZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChuIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQobisrKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICA6XG4gICAgICAgICAgICBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICAgICAgICAgIHZhciBuID0gc3RhcnQ7XG4gICAgICAgICAgICAgICAgd2hpbGUgKG4gPCBlbmQgJiYgIXN1YnNjcmliZXIuY2xvc2VkKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChuKyspO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9KTtcbn1cbiIsImltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuLi9PYnNlcnZhYmxlJztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4vaW5uZXJGcm9tJztcbmltcG9ydCB7IEVNUFRZIH0gZnJvbSAnLi9lbXB0eSc7XG5leHBvcnQgZnVuY3Rpb24gdXNpbmcocmVzb3VyY2VGYWN0b3J5LCBvYnNlcnZhYmxlRmFjdG9yeSkge1xuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgcmVzb3VyY2UgPSByZXNvdXJjZUZhY3RvcnkoKTtcbiAgICAgICAgdmFyIHJlc3VsdCA9IG9ic2VydmFibGVGYWN0b3J5KHJlc291cmNlKTtcbiAgICAgICAgdmFyIHNvdXJjZSA9IHJlc3VsdCA/IGlubmVyRnJvbShyZXN1bHQpIDogRU1QVFk7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAocmVzb3VyY2UpIHtcbiAgICAgICAgICAgICAgICByZXNvdXJjZS51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzXSwibWFwcGluZ3MiOiI7O0FBQUEsSUFBVywrQkFBK0I7Q0FDdEMsS0FBSyxXQUFZO0VBQ2IsUUFBUSw2QkFBNkIsWUFBWSxZQUFBLENBQWEsSUFBSTtDQUN0RTtDQUNBLFVBQVUsS0FBQTtBQUNkOzs7QUNIQSxJQUFXLHlCQUF5QjtDQUNoQyxVQUFVLFNBQVUsVUFBVTtFQUMxQixJQUFJLFVBQVU7RUFDZCxJQUFJLFNBQVM7RUFDYixJQUFJLFdBQVcsdUJBQXVCO0VBQ3RDLElBQUksVUFBVTtHQUNWLFVBQVUsU0FBUztHQUNuQixTQUFTLFNBQVM7RUFDdEI7RUFDQSxJQUFJLFNBQVMsUUFBUSxTQUFVLFdBQVc7R0FDdEMsU0FBUyxLQUFBO0dBQ1QsU0FBUyxTQUFTO0VBQ3RCLENBQUM7RUFDRCxPQUFPLElBQUksYUFBYSxXQUFZO0dBQUUsT0FBTyxXQUFXLFFBQVEsV0FBVyxLQUFLLElBQUksS0FBSyxJQUFJLE9BQU8sTUFBTTtFQUFHLENBQUM7Q0FDbEg7Q0FDQSx1QkFBdUIsV0FBWTtFQUMvQixJQUFJLE9BQU8sQ0FBQztFQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7RUFFekIsSUFBSSxXQUFXLHVCQUF1QjtFQUN0QyxTQUFTLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUywwQkFBMEIsc0JBQUEsQ0FBdUIsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQztDQUN4SztDQUNBLHNCQUFzQixXQUFZO0VBQzlCLElBQUksT0FBTyxDQUFDO0VBQ1osS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxLQUFLLE1BQU0sVUFBVTtFQUV6QixJQUFJLFdBQVcsdUJBQXVCO0VBQ3RDLFNBQVMsYUFBYSxRQUFRLGFBQWEsS0FBSyxJQUFJLEtBQUssSUFBSSxTQUFTLHlCQUF5QixxQkFBQSxDQUFzQixNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDO0NBQ3RLO0NBQ0EsVUFBVSxLQUFBO0FBQ2Q7OztBQy9CQSxTQUFnQixnQkFBZ0IsbUJBQW1CO0NBQy9DLE9BQU8sb0JBQW9CLHVCQUF1QixpQkFBaUIsSUFBSTtBQUMzRTtBQUNBLFNBQVMsdUJBQXVCLG1CQUFtQjtDQUMvQyxPQUFPLElBQUksV0FBVyxTQUFVLFlBQVk7RUFDeEMsSUFBSSxXQUFXLHFCQUFxQjtFQUNwQyxJQUFJLFFBQVEsU0FBUyxJQUFJO0VBQ3pCLElBQUksS0FBSztFQUNULElBQUksTUFBTSxXQUFZO0dBQ2xCLElBQUksQ0FBQyxXQUFXLFFBQ1osS0FBSyx1QkFBdUIsc0JBQXNCLFNBQVUsV0FBVztJQUNuRSxLQUFLO0lBQ0wsSUFBSSxNQUFNLFNBQVMsSUFBSTtJQUN2QixXQUFXLEtBQUs7S0FDWixXQUFXLG9CQUFvQixNQUFNO0tBQ3JDLFNBQVMsTUFBTTtJQUNuQixDQUFDO0lBQ0QsSUFBSTtHQUNSLENBQUM7RUFFVDtFQUNBLElBQUk7RUFDSixPQUFPLFdBQVk7R0FDZixJQUFJLElBQ0EsdUJBQXVCLHFCQUFxQixFQUFFO0VBRXREO0NBQ0osQ0FBQztBQUNMO0FBQ0EsSUFBSSwyQkFBMkIsdUJBQXVCOzs7QUNoQ3RELElBQUksYUFBYTtBQUNqQixJQUFJO0FBQ0osSUFBSSxnQkFBZ0IsQ0FBQztBQUNyQixTQUFTLG1CQUFtQixRQUFRO0NBQ2hDLElBQUksVUFBVSxlQUFlO0VBQ3pCLE9BQU8sY0FBYztFQUNyQixPQUFPO0NBQ1g7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxJQUFXLFlBQVk7Q0FDbkIsY0FBYyxTQUFVLElBQUk7RUFDeEIsSUFBSSxTQUFTO0VBQ2IsY0FBYyxVQUFVO0VBQ3hCLElBQUksQ0FBQyxVQUNELFdBQVcsUUFBUSxRQUFRO0VBRS9CLFNBQVMsS0FBSyxXQUFZO0dBQUUsT0FBTyxtQkFBbUIsTUFBTSxLQUFLLEdBQUc7RUFBRyxDQUFDO0VBQ3hFLE9BQU87Q0FDWDtDQUNBLGdCQUFnQixTQUFVLFFBQVE7RUFDOUIsbUJBQW1CLE1BQU07Q0FDN0I7QUFDSjs7O0FDckJBLElBQUksZUFBZSxVQUFVO0lBQWMsaUJBQWlCLFVBQVU7QUFDdEUsSUFBVyxvQkFBb0I7Q0FDM0IsY0FBYyxXQUFZO0VBQ3RCLElBQUksT0FBTyxDQUFDO0VBQ1osS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxLQUFLLE1BQU0sVUFBVTtFQUV6QixJQUFJLFdBQVcsa0JBQWtCO0VBQ2pDLFNBQVMsYUFBYSxRQUFRLGFBQWEsS0FBSyxJQUFJLEtBQUssSUFBSSxTQUFTLGlCQUFpQixhQUFBLENBQWMsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQztDQUN0SjtDQUNBLGdCQUFnQixTQUFVLFFBQVE7RUFDOUIsSUFBSSxXQUFXLGtCQUFrQjtFQUNqQyxTQUFTLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxtQkFBbUIsZUFBQSxDQUFnQixNQUFNO0NBQ25IO0NBQ0EsVUFBVSxLQUFBO0FBQ2Q7OztBQ2RBLElBQUksYUFBYyxTQUFVLFFBQVE7Q0FDaEMsVUFBVSxZQUFZLE1BQU07Q0FDNUIsU0FBUyxXQUFXLFdBQVcsTUFBTTtFQUNqQyxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0sV0FBVyxJQUFJLEtBQUs7RUFDbEQsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sT0FBTztFQUNiLE9BQU87Q0FDWDtDQUNBLFdBQVcsVUFBVSxpQkFBaUIsU0FBVSxXQUFXLElBQUksT0FBTztFQUNsRSxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7RUFDaEMsSUFBSSxVQUFVLFFBQVEsUUFBUSxHQUMxQixPQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssTUFBTSxXQUFXLElBQUksS0FBSztFQUUxRSxVQUFVLFFBQVEsS0FBSyxJQUFJO0VBQzNCLE9BQU8sVUFBVSxlQUFlLFVBQVUsYUFBYSxrQkFBa0IsYUFBYSxVQUFVLE1BQU0sS0FBSyxXQUFXLEtBQUEsQ0FBUyxDQUFDO0NBQ3BJO0NBQ0EsV0FBVyxVQUFVLGlCQUFpQixTQUFVLFdBQVcsSUFBSSxPQUFPO0VBQ2xFLElBQUk7RUFDSixJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7RUFDaEMsSUFBSSxTQUFTLE9BQU8sUUFBUSxJQUFJLEtBQUssUUFBUSxHQUN6QyxPQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssTUFBTSxXQUFXLElBQUksS0FBSztFQUUxRSxJQUFJLFVBQVUsVUFBVTtFQUN4QixJQUFJLE1BQU0sVUFBVSxLQUFLLFFBQVEsUUFBUSxTQUFTLFFBQVEsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxRQUFRLElBQUk7R0FDdEcsa0JBQWtCLGVBQWUsRUFBRTtHQUNuQyxJQUFJLFVBQVUsZUFBZSxJQUN6QixVQUFVLGFBQWEsS0FBQTtFQUUvQjtDQUVKO0NBQ0EsT0FBTztBQUNYLEVBQUUsV0FBVzs7O0FFakNiLElBQVcsZ0JBQWdCLEtEQU4sU0FBVSxRQUFRO0NBQ25DLFVBQVUsZUFBZSxNQUFNO0NBQy9CLFNBQVMsZ0JBQWdCO0VBQ3JCLE9BQU8sV0FBVyxRQUFRLE9BQU8sTUFBTSxNQUFNLFNBQVMsS0FBSztDQUMvRDtDQUNBLGNBQWMsVUFBVSxRQUFRLFNBQVUsUUFBUTtFQUM5QyxLQUFLLFVBQVU7RUFDZixJQUFJLFVBQVUsS0FBSztFQUNuQixLQUFLLGFBQWEsS0FBQTtFQUNsQixJQUFJLFVBQVUsS0FBSztFQUNuQixJQUFJO0VBQ0osU0FBUyxVQUFVLFFBQVEsTUFBTTtFQUNqQztHQUNJLElBQUssUUFBUSxPQUFPLFFBQVEsT0FBTyxPQUFPLE9BQU8sS0FBSyxHQUNsRDtVQUVFLFNBQVMsUUFBUSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVEsTUFBTTtFQUN6RSxLQUFLLFVBQVU7RUFDZixJQUFJLE9BQU87R0FDUCxRQUFRLFNBQVMsUUFBUSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVEsTUFBTSxHQUNuRSxPQUFPLFlBQVk7R0FFdkIsTUFBTTtFQUNWO0NBQ0o7Q0FDQSxPQUFPO0FBQ1gsRUFBRSxjQzFCNkIsR0FBYyxVQUFVO0FBQ3ZELElBQVcsT0FBTzs7O0FDRGxCLElBQUksY0FBZSxTQUFVLFFBQVE7Q0FDakMsVUFBVSxhQUFhLE1BQU07Q0FDN0IsU0FBUyxZQUFZLFdBQVcsTUFBTTtFQUNsQyxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0sV0FBVyxJQUFJLEtBQUs7RUFDbEQsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sT0FBTztFQUNiLE9BQU87Q0FDWDtDQUNBLFlBQVksVUFBVSxXQUFXLFNBQVUsT0FBTyxPQUFPO0VBQ3JELElBQUksVUFBVSxLQUFLLEdBQUssUUFBUTtFQUNoQyxJQUFJLFFBQVEsR0FDUixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssTUFBTSxPQUFPLEtBQUs7RUFFNUQsS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxVQUFVLE1BQU0sSUFBSTtFQUN6QixPQUFPO0NBQ1g7Q0FDQSxZQUFZLFVBQVUsVUFBVSxTQUFVLE9BQU8sT0FBTztFQUNwRCxPQUFPLFFBQVEsS0FBSyxLQUFLLFNBQVMsT0FBTyxVQUFVLFFBQVEsS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQUssU0FBUyxPQUFPLEtBQUs7Q0FDcEg7Q0FDQSxZQUFZLFVBQVUsaUJBQWlCLFNBQVUsV0FBVyxJQUFJLE9BQU87RUFDbkUsSUFBSSxVQUFVLEtBQUssR0FBSyxRQUFRO0VBQ2hDLElBQUssU0FBUyxRQUFRLFFBQVEsS0FBTyxTQUFTLFFBQVEsS0FBSyxRQUFRLEdBQy9ELE9BQU8sT0FBTyxVQUFVLGVBQWUsS0FBSyxNQUFNLFdBQVcsSUFBSSxLQUFLO0VBRTFFLFVBQVUsTUFBTSxJQUFJO0VBQ3BCLE9BQU87Q0FDWDtDQUNBLE9BQU87QUFDWCxFQUFFLFdBQVc7OztBRTlCYixJQUFXLGlCQUFpQixLREFOLFNBQVUsUUFBUTtDQUNwQyxVQUFVLGdCQUFnQixNQUFNO0NBQ2hDLFNBQVMsaUJBQWlCO0VBQ3RCLE9BQU8sV0FBVyxRQUFRLE9BQU8sTUFBTSxNQUFNLFNBQVMsS0FBSztDQUMvRDtDQUNBLE9BQU87QUFDWCxFQUFFLGNDTjhCLEdBQWUsV0FBVztBQUMxRCxJQUFXLFFBQVE7OztBQ0FuQixJQUFJLHVCQUF3QixTQUFVLFFBQVE7Q0FDMUMsVUFBVSxzQkFBc0IsTUFBTTtDQUN0QyxTQUFTLHFCQUFxQixXQUFXLE1BQU07RUFDM0MsSUFBSSxRQUFRLE9BQU8sS0FBSyxNQUFNLFdBQVcsSUFBSSxLQUFLO0VBQ2xELE1BQU0sWUFBWTtFQUNsQixNQUFNLE9BQU87RUFDYixPQUFPO0NBQ1g7Q0FDQSxxQkFBcUIsVUFBVSxpQkFBaUIsU0FBVSxXQUFXLElBQUksT0FBTztFQUM1RSxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7RUFDaEMsSUFBSSxVQUFVLFFBQVEsUUFBUSxHQUMxQixPQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssTUFBTSxXQUFXLElBQUksS0FBSztFQUUxRSxVQUFVLFFBQVEsS0FBSyxJQUFJO0VBQzNCLE9BQU8sVUFBVSxlQUFlLFVBQVUsYUFBYSx1QkFBdUIsc0JBQXNCLFdBQVk7R0FBRSxPQUFPLFVBQVUsTUFBTSxLQUFBLENBQVM7RUFBRyxDQUFDO0NBQzFKO0NBQ0EscUJBQXFCLFVBQVUsaUJBQWlCLFNBQVUsV0FBVyxJQUFJLE9BQU87RUFDNUUsSUFBSTtFQUNKLElBQUksVUFBVSxLQUFLLEdBQUssUUFBUTtFQUNoQyxJQUFJLFNBQVMsT0FBTyxRQUFRLElBQUksS0FBSyxRQUFRLEdBQ3pDLE9BQU8sT0FBTyxVQUFVLGVBQWUsS0FBSyxNQUFNLFdBQVcsSUFBSSxLQUFLO0VBRTFFLElBQUksVUFBVSxVQUFVO0VBQ3hCLElBQUksTUFBTSxRQUFRLE9BQU8sVUFBVSxnQkFBZ0IsS0FBSyxRQUFRLFFBQVEsU0FBUyxRQUFRLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsUUFBUSxJQUFJO0dBQ3JJLHVCQUF1QixxQkFBcUIsRUFBRTtHQUM5QyxVQUFVLGFBQWEsS0FBQTtFQUMzQjtDQUVKO0NBQ0EsT0FBTztBQUNYLEVBQUUsV0FBVzs7O0FFL0JiLElBQVcsMEJBQTBCLEtEQU4sU0FBVSxRQUFRO0NBQzdDLFVBQVUseUJBQXlCLE1BQU07Q0FDekMsU0FBUywwQkFBMEI7RUFDL0IsT0FBTyxXQUFXLFFBQVEsT0FBTyxNQUFNLE1BQU0sU0FBUyxLQUFLO0NBQy9EO0NBQ0Esd0JBQXdCLFVBQVUsUUFBUSxTQUFVLFFBQVE7RUFDeEQsS0FBSyxVQUFVO0VBQ2YsSUFBSTtFQUNKLElBQUksUUFDQSxVQUFVLE9BQU87T0FFaEI7R0FDRCxVQUFVLEtBQUs7R0FDZixLQUFLLGFBQWEsS0FBQTtFQUN0QjtFQUNBLElBQUksVUFBVSxLQUFLO0VBQ25CLElBQUk7RUFDSixTQUFTLFVBQVUsUUFBUSxNQUFNO0VBQ2pDO0dBQ0ksSUFBSyxRQUFRLE9BQU8sUUFBUSxPQUFPLE9BQU8sT0FBTyxLQUFLLEdBQ2xEO1VBRUUsU0FBUyxRQUFRLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUSxNQUFNO0VBQ3pFLEtBQUssVUFBVTtFQUNmLElBQUksT0FBTztHQUNQLFFBQVEsU0FBUyxRQUFRLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUSxNQUFNLEdBQ25FLE9BQU8sWUFBWTtHQUV2QixNQUFNO0VBQ1Y7Q0FDSjtDQUNBLE9BQU87QUFDWCxFQUFFLGNDaEN1QyxHQUF3QixvQkFBb0I7QUFDckYsSUFBVyxpQkFBaUI7OztBQ0M1QixJQUFJLHVCQUF3QixTQUFVLFFBQVE7Q0FDMUMsVUFBVSxzQkFBc0IsTUFBTTtDQUN0QyxTQUFTLHFCQUFxQixxQkFBcUIsV0FBVztFQUMxRCxJQUFJLHdCQUF3QixLQUFLLEdBQUssc0JBQXNCO0VBQzVELElBQUksY0FBYyxLQUFLLEdBQUssWUFBWTtFQUN4QyxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0scUJBQXFCLFdBQVk7R0FBRSxPQUFPLE1BQU07RUFBTyxDQUFDLEtBQUs7RUFDM0YsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sUUFBUTtFQUNkLE1BQU0sUUFBUTtFQUNkLE9BQU87Q0FDWDtDQUNBLHFCQUFxQixVQUFVLFFBQVEsV0FBWTtFQUMvQyxJQUFJLEtBQUssTUFBTSxVQUFVLEdBQUcsU0FBUyxZQUFZLEdBQUc7RUFDcEQsSUFBSTtFQUNKLElBQUk7RUFDSixRQUFRLFNBQVMsUUFBUSxPQUFPLE9BQU8sU0FBUyxXQUFXO0dBQ3ZELFFBQVEsTUFBTTtHQUNkLEtBQUssUUFBUSxPQUFPO0dBQ3BCLElBQUssUUFBUSxPQUFPLFFBQVEsT0FBTyxPQUFPLE9BQU8sS0FBSyxHQUNsRDtFQUVSO0VBQ0EsSUFBSSxPQUFPO0dBQ1AsT0FBUSxTQUFTLFFBQVEsTUFBTSxHQUMzQixPQUFPLFlBQVk7R0FFdkIsTUFBTTtFQUNWO0NBQ0o7Q0FDQSxxQkFBcUIsa0JBQWtCO0NBQ3ZDLE9BQU87QUFDWCxFQUFFLGNBQWM7QUFFaEIsSUFBSSxnQkFBaUIsU0FBVSxRQUFRO0NBQ25DLFVBQVUsZUFBZSxNQUFNO0NBQy9CLFNBQVMsY0FBYyxXQUFXLE1BQU0sT0FBTztFQUMzQyxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVMsVUFBVSxTQUFTO0VBQ3BELElBQUksUUFBUSxPQUFPLEtBQUssTUFBTSxXQUFXLElBQUksS0FBSztFQUNsRCxNQUFNLFlBQVk7RUFDbEIsTUFBTSxPQUFPO0VBQ2IsTUFBTSxRQUFRO0VBQ2QsTUFBTSxTQUFTO0VBQ2YsTUFBTSxRQUFRLFVBQVUsUUFBUTtFQUNoQyxPQUFPO0NBQ1g7Q0FDQSxjQUFjLFVBQVUsV0FBVyxTQUFVLE9BQU8sT0FBTztFQUN2RCxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7RUFDaEMsSUFBSSxPQUFPLFNBQVMsS0FBSyxHQUFHO0dBQ3hCLElBQUksQ0FBQyxLQUFLLElBQ04sT0FBTyxPQUFPLFVBQVUsU0FBUyxLQUFLLE1BQU0sT0FBTyxLQUFLO0dBRTVELEtBQUssU0FBUztHQUNkLElBQUksU0FBUyxJQUFJLGNBQWMsS0FBSyxXQUFXLEtBQUssSUFBSTtHQUN4RCxLQUFLLElBQUksTUFBTTtHQUNmLE9BQU8sT0FBTyxTQUFTLE9BQU8sS0FBSztFQUN2QyxPQUVJLE9BQU8sYUFBYTtDQUU1QjtDQUNBLGNBQWMsVUFBVSxpQkFBaUIsU0FBVSxXQUFXLElBQUksT0FBTztFQUNyRSxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7RUFDaEMsS0FBSyxRQUFRLFVBQVUsUUFBUTtFQUMvQixJQUFJLFVBQVUsVUFBVTtFQUN4QixRQUFRLEtBQUssSUFBSTtFQUNqQixRQUFRLEtBQUssY0FBYyxXQUFXO0VBQ3RDLE9BQU87Q0FDWDtDQUNBLGNBQWMsVUFBVSxpQkFBaUIsU0FBVSxXQUFXLElBQUksT0FBTztFQUNyRSxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7Q0FFcEM7Q0FDQSxjQUFjLFVBQVUsV0FBVyxTQUFVLE9BQU8sT0FBTztFQUN2RCxJQUFJLEtBQUssV0FBVyxNQUNoQixPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssTUFBTSxPQUFPLEtBQUs7Q0FFaEU7Q0FDQSxjQUFjLGNBQWMsU0FBVSxHQUFHLEdBQUc7RUFDeEMsSUFBSSxFQUFFLFVBQVUsRUFBRSxPQUNkLElBQUksRUFBRSxVQUFVLEVBQUUsT0FDZCxPQUFPO09BRU4sSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUNqQixPQUFPO09BR1AsT0FBTztPQUdWLElBQUksRUFBRSxRQUFRLEVBQUUsT0FDakIsT0FBTztPQUdQLE9BQU87Q0FFZjtDQUNBLE9BQU87QUFDWCxFQUFFLFdBQVc7OztBQ25HYixTQUFnQixhQUFhLEtBQUs7Q0FDOUIsT0FBTyxDQUFDLENBQUMsUUFBUSxlQUFlLGNBQWUsV0FBVyxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksU0FBUztBQUNuRzs7O0FDSEEsU0FBZ0IsY0FBYyxRQUFRLFFBQVE7Q0FDMUMsSUFBSSxZQUFZLE9BQU8sV0FBVztDQUNsQyxPQUFPLElBQUksUUFBUSxTQUFVLFNBQVMsUUFBUTtFQUMxQyxJQUFJLFlBQVk7RUFDaEIsSUFBSTtFQUNKLE9BQU8sVUFBVTtHQUNiLE1BQU0sU0FBVSxPQUFPO0lBQ25CLFNBQVM7SUFDVCxZQUFZO0dBQ2hCO0dBQ0EsT0FBTztHQUNQLFVBQVUsV0FBWTtJQUNsQixJQUFJLFdBQ0EsUUFBUSxNQUFNO1NBRWIsSUFBSSxXQUNMLFFBQVEsT0FBTyxZQUFZO1NBRzNCLE9BQU8sSUFBSSxXQUFXLENBQUM7R0FFL0I7RUFDSixDQUFDO0NBQ0wsQ0FBQztBQUNMOzs7QUN2QkEsU0FBZ0IsZUFBZSxRQUFRLFFBQVE7Q0FDM0MsSUFBSSxZQUFZLE9BQU8sV0FBVztDQUNsQyxPQUFPLElBQUksUUFBUSxTQUFVLFNBQVMsUUFBUTtFQUMxQyxJQUFJLGFBQWEsSUFBSSxlQUFlO0dBQ2hDLE1BQU0sU0FBVSxPQUFPO0lBQ25CLFFBQVEsS0FBSztJQUNiLFdBQVcsWUFBWTtHQUMzQjtHQUNBLE9BQU87R0FDUCxVQUFVLFdBQVk7SUFDbEIsSUFBSSxXQUNBLFFBQVEsT0FBTyxZQUFZO1NBRzNCLE9BQU8sSUFBSSxXQUFXLENBQUM7R0FFL0I7RUFDSixDQUFDO0VBQ0QsT0FBTyxVQUFVLFVBQVU7Q0FDL0IsQ0FBQztBQUNMOzs7QUNmQSxTQUFnQixzQkFBc0IsYUFBYSxjQUFjLGdCQUFnQixXQUFXO0NBQ3hGLElBQUksZ0JBQ0EsSUFBSSxZQUFZLGNBQWMsR0FDMUIsWUFBWTtNQUdaLE9BQU8sV0FBWTtFQUNmLElBQUksT0FBTyxDQUFDO0VBQ1osS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxLQUFLLE1BQU0sVUFBVTtFQUV6QixPQUFPLHNCQUFzQixhQUFhLGNBQWMsU0FBUyxDQUFDLENBQzdELE1BQU0sTUFBTSxJQUFJLENBQUMsQ0FDakIsS0FBSyxpQkFBaUIsY0FBYyxDQUFDO0NBQzlDO0NBR1IsSUFBSSxXQUNBLE9BQU8sV0FBWTtFQUNmLElBQUksT0FBTyxDQUFDO0VBQ1osS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxLQUFLLE1BQU0sVUFBVTtFQUV6QixPQUFPLHNCQUFzQixhQUFhLFlBQVksQ0FBQyxDQUNsRCxNQUFNLE1BQU0sSUFBSSxDQUFDLENBQ2pCLEtBQUssWUFBWSxTQUFTLEdBQUcsVUFBVSxTQUFTLENBQUM7Q0FDMUQ7Q0FFSixPQUFPLFdBQVk7RUFDZixJQUFJLFFBQVE7RUFDWixJQUFJLE9BQU8sQ0FBQztFQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7RUFFekIsSUFBSSxVQUFVLElBQUksYUFBYTtFQUMvQixJQUFJLGdCQUFnQjtFQUNwQixPQUFPLElBQUksV0FBVyxTQUFVLFlBQVk7R0FDeEMsSUFBSSxPQUFPLFFBQVEsVUFBVSxVQUFVO0dBQ3ZDLElBQUksZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixJQUFJLFlBQVk7SUFDaEIsSUFBSSxlQUFlO0lBQ25CLGFBQWEsTUFBTSxPQUFPLGNBQWMsY0FBYyxDQUFDLEdBQUcsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUNyRSxXQUFZO0tBQ1IsSUFBSSxVQUFVLENBQUM7S0FDZixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLFFBQVEsTUFBTSxVQUFVO0tBRTVCLElBQUksYUFBYTtNQUNiLElBQUksTUFBTSxRQUFRLE1BQU07TUFDeEIsSUFBSSxPQUFPLE1BQU07T0FDYixRQUFRLE1BQU0sR0FBRztPQUNqQjtNQUNKO0tBQ0o7S0FDQSxRQUFRLEtBQUssSUFBSSxRQUFRLFNBQVMsVUFBVSxRQUFRLEVBQUU7S0FDdEQsZUFBZTtLQUNmLElBQUksV0FDQSxRQUFRLFNBQVM7SUFFekIsQ0FDSixDQUFDLENBQUM7SUFDRixJQUFJLGNBQ0EsUUFBUSxTQUFTO0lBRXJCLFlBQVk7R0FDaEI7R0FDQSxPQUFPO0VBQ1gsQ0FBQztDQUNMO0FBQ0o7OztBQzVFQSxTQUFnQixhQUFhLGNBQWMsZ0JBQWdCLFdBQVc7Q0FDbEUsT0FBTyxzQkFBc0IsT0FBTyxjQUFjLGdCQUFnQixTQUFTO0FBQy9FOzs7QUNGQSxTQUFnQixpQkFBaUIsY0FBYyxnQkFBZ0IsV0FBVztDQUN0RSxPQUFPLHNCQUFzQixNQUFNLGNBQWMsZ0JBQWdCLFNBQVM7QUFDOUU7OztBQ0RBLFNBQWdCLE1BQU0sbUJBQW1CO0NBQ3JDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxVQUFVLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxVQUFVLFVBQVU7Q0FDdkQsQ0FBQztBQUNMOzs7QUNIQSxJQUFJLGlCQUFpQjtDQUNqQixXQUFXLFdBQVk7RUFBRSxPQUFPLElBQUksUUFBUTtDQUFHO0NBQy9DLG1CQUFtQjtBQUN2QjtBQUNBLFNBQWdCLFlBQVksUUFBUSxRQUFRO0NBQ3hDLElBQUksV0FBVyxLQUFLLEdBQUssU0FBUztDQUNsQyxJQUFJLGFBQWE7Q0FDakIsSUFBSSxZQUFZLE9BQU8sV0FBVyxLQUFLLE9BQU8sbUJBQW1CLG9CQUFvQixPQUFPLEtBQUssSUFBSSxPQUFPO0NBQzVHLElBQUksVUFBVSxVQUFVO0NBQ3hCLElBQUksU0FBUyxJQUFJLFdBQVcsU0FBVSxZQUFZO0VBQzlDLE9BQU8sUUFBUSxVQUFVLFVBQVU7Q0FDdkMsQ0FBQztDQUNELE9BQU8sVUFBVSxXQUFZO0VBQ3pCLElBQUksQ0FBQyxjQUFjLFdBQVcsUUFBUTtHQUNsQyxhQUFhLE1BQU0sV0FBWTtJQUFFLE9BQU87R0FBUSxDQUFDLENBQUMsQ0FBQyxVQUFVLE9BQU87R0FDcEUsSUFBSSxtQkFDQSxXQUFXLElBQUksV0FBWTtJQUFFLE9BQVEsVUFBVSxVQUFVO0dBQUksQ0FBQztFQUV0RTtFQUNBLE9BQU87Q0FDWDtDQUNBLE9BQU87QUFDWDs7O0FDbEJBLFNBQWdCLFdBQVc7Q0FDdkIsSUFBSSxPQUFPLENBQUM7Q0FDWixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLEtBQUssTUFBTSxVQUFVO0NBRXpCLElBQUksaUJBQWlCLGtCQUFrQixJQUFJO0NBQzNDLElBQUksS0FBSyxxQkFBcUIsSUFBSSxHQUFHLFVBQVUsR0FBRyxNQUFNLE9BQU8sR0FBRztDQUNsRSxJQUFJLFNBQVMsSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUM5QyxJQUFJLFNBQVMsUUFBUTtFQUNyQixJQUFJLENBQUMsUUFBUTtHQUNULFdBQVcsU0FBUztHQUNwQjtFQUNKO0VBQ0EsSUFBSSxTQUFTLElBQUksTUFBTSxNQUFNO0VBQzdCLElBQUksdUJBQXVCO0VBQzNCLElBQUkscUJBQXFCO0VBQ3pCLElBQUksVUFBVSxTQUFVLGFBQWE7R0FDakMsSUFBSSxXQUFXO0dBQ2YsVUFBVSxRQUFRLFlBQVksQ0FBQyxDQUFDLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0lBQzVGLElBQUksQ0FBQyxVQUFVO0tBQ1gsV0FBVztLQUNYO0lBQ0o7SUFDQSxPQUFPLGVBQWU7R0FDMUIsR0FBRyxXQUFZO0lBQUUsT0FBTztHQUF3QixHQUFHLEtBQUEsR0FBVyxXQUFZO0lBQ3RFLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxVQUFVO0tBQ3BDLElBQUksQ0FBQyxvQkFDRCxXQUFXLEtBQUssT0FBTyxhQUFhLE1BQU0sTUFBTSxJQUFJLE1BQU07S0FFOUQsV0FBVyxTQUFTO0lBQ3hCO0dBQ0osQ0FBQyxDQUFDO0VBQ047RUFDQSxLQUFLLElBQUksY0FBYyxHQUFHLGNBQWMsUUFBUSxlQUM1QyxRQUFRLFdBQVc7Q0FFM0IsQ0FBQztDQUNELE9BQU8saUJBQWlCLE9BQU8sS0FBSyxpQkFBaUIsY0FBYyxDQUFDLElBQUk7QUFDNUU7OztBQ3RDQSxJQUFJLDBCQUEwQixDQUFDLGVBQWUsZ0JBQWdCO0FBQzlELElBQUkscUJBQXFCLENBQUMsb0JBQW9CLHFCQUFxQjtBQUNuRSxJQUFJLGdCQUFnQixDQUFDLE1BQU0sS0FBSztBQUNoQyxTQUFnQixVQUFVLFFBQVEsV0FBVyxTQUFTLGdCQUFnQjtDQUNsRSxJQUFJLFdBQVcsT0FBTyxHQUFHO0VBQ3JCLGlCQUFpQjtFQUNqQixVQUFVLEtBQUE7Q0FDZDtDQUNBLElBQUksZ0JBQ0EsT0FBTyxVQUFVLFFBQVEsV0FBVyxPQUFPLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixjQUFjLENBQUM7Q0FFdEYsSUFBSSxLQUFLLE9BQU8sY0FBYyxNQUFNLElBQzlCLG1CQUFtQixJQUFJLFNBQVUsWUFBWTtFQUFFLE9BQU8sU0FBVSxTQUFTO0dBQUUsT0FBTyxPQUFPLFdBQVcsQ0FBQyxXQUFXLFNBQVMsT0FBTztFQUFHO0NBQUcsQ0FBQyxJQUVySSx3QkFBd0IsTUFBTSxJQUN4Qix3QkFBd0IsSUFBSSx3QkFBd0IsUUFBUSxTQUFTLENBQUMsSUFDdEUsMEJBQTBCLE1BQU0sSUFDNUIsY0FBYyxJQUFJLHdCQUF3QixRQUFRLFNBQVMsQ0FBQyxJQUM1RCxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxJQUFJLFNBQVMsR0FBRztDQUNuRCxJQUFJLENBQUM7TUFDRyxZQUFZLE1BQU0sR0FDbEIsT0FBTyxTQUFTLFNBQVUsV0FBVztHQUFFLE9BQU8sVUFBVSxXQUFXLFdBQVcsT0FBTztFQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsTUFBTSxDQUFDO0NBQUE7Q0FHcEgsSUFBSSxDQUFDLEtBQ0QsTUFBTSxJQUFJLFVBQVUsc0JBQXNCO0NBRTlDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxJQUFJLFVBQVUsV0FBWTtHQUN0QixJQUFJLE9BQU8sQ0FBQztHQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7R0FFekIsT0FBTyxXQUFXLEtBQUssSUFBSSxLQUFLLFNBQVMsT0FBTyxLQUFLLEVBQUU7RUFDM0Q7RUFDQSxJQUFJLE9BQU87RUFDWCxPQUFPLFdBQVk7R0FBRSxPQUFPLE9BQU8sT0FBTztFQUFHO0NBQ2pELENBQUM7QUFDTDtBQUNBLFNBQVMsd0JBQXdCLFFBQVEsV0FBVztDQUNoRCxPQUFPLFNBQVUsWUFBWTtFQUFFLE9BQU8sU0FBVSxTQUFTO0dBQUUsT0FBTyxPQUFPLFdBQVcsQ0FBQyxXQUFXLE9BQU87RUFBRztDQUFHO0FBQ2pIO0FBQ0EsU0FBUyx3QkFBd0IsUUFBUTtDQUNyQyxPQUFPLFdBQVcsT0FBTyxXQUFXLEtBQUssV0FBVyxPQUFPLGNBQWM7QUFDN0U7QUFDQSxTQUFTLDBCQUEwQixRQUFRO0NBQ3ZDLE9BQU8sV0FBVyxPQUFPLEVBQUUsS0FBSyxXQUFXLE9BQU8sR0FBRztBQUN6RDtBQUNBLFNBQVMsY0FBYyxRQUFRO0NBQzNCLE9BQU8sV0FBVyxPQUFPLGdCQUFnQixLQUFLLFdBQVcsT0FBTyxtQkFBbUI7QUFDdkY7OztBQ3REQSxTQUFnQixpQkFBaUIsWUFBWSxlQUFlLGdCQUFnQjtDQUN4RSxJQUFJLGdCQUNBLE9BQU8saUJBQWlCLFlBQVksYUFBYSxDQUFDLENBQUMsS0FBSyxpQkFBaUIsY0FBYyxDQUFDO0NBRTVGLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxJQUFJLFVBQVUsV0FBWTtHQUN0QixJQUFJLElBQUksQ0FBQztHQUNULEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsRUFBRSxNQUFNLFVBQVU7R0FFdEIsT0FBTyxXQUFXLEtBQUssRUFBRSxXQUFXLElBQUksRUFBRSxLQUFLLENBQUM7RUFDcEQ7RUFDQSxJQUFJLFdBQVcsV0FBVyxPQUFPO0VBQ2pDLE9BQU8sV0FBVyxhQUFhLElBQUksV0FBWTtHQUFFLE9BQU8sY0FBYyxTQUFTLFFBQVE7RUFBRyxJQUFJLEtBQUE7Q0FDbEcsQ0FBQztBQUNMOzs7QUNiQSxTQUFnQixTQUFTLHVCQUF1QixXQUFXLFNBQVMsMkJBQTJCLFdBQVc7Q0FDdEcsSUFBSSxJQUFJO0NBQ1IsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLFVBQVUsV0FBVyxHQUNyQixLQUFNLHVCQUF1QixlQUFlLEdBQUcsY0FBYyxZQUFZLEdBQUcsV0FBVyxVQUFVLEdBQUcsU0FBUyxLQUFLLEdBQUcsZ0JBQWdCLGlCQUFpQixPQUFPLEtBQUssSUFBSSxXQUFXLElBQUksWUFBWSxHQUFHO01BRW5NO0VBQ0QsZUFBZTtFQUNmLElBQUksQ0FBQyw2QkFBNkIsWUFBWSx5QkFBeUIsR0FBRztHQUN0RSxpQkFBaUI7R0FDakIsWUFBWTtFQUNoQixPQUVJLGlCQUFpQjtDQUV6QjtDQUNBLFNBQVMsTUFBTTtFQUNYLElBQUk7RUFDSixPQUFPLFlBQVksTUFBTSxTQUFVLElBQUk7R0FDbkMsUUFBUSxHQUFHLE9BQVg7SUFDSSxLQUFLO0tBQ0QsUUFBUTtLQUNSLEdBQUcsUUFBUTtJQUNmLEtBQUs7S0FDRCxJQUFJLEVBQUUsQ0FBQyxhQUFhLFVBQVUsS0FBSyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUM7S0FDbkQsT0FBTyxDQUFDLEdBQUcsZUFBZSxLQUFLLENBQUM7SUFDcEMsS0FBSztLQUNELEdBQUcsS0FBSztLQUNSLEdBQUcsUUFBUTtJQUNmLEtBQUs7S0FDRCxRQUFRLFFBQVEsS0FBSztLQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDO0lBQ2hCLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBQztHQUNyQjtFQUNKLENBQUM7Q0FDTDtDQUNBLE9BQU8sTUFBTyxZQUVOLFdBQVk7RUFBRSxPQUFPLGlCQUFpQixJQUFJLEdBQUcsU0FBUztDQUFHLElBRXpELEdBQUk7QUFDaEI7OztBQzlDQSxTQUFnQixJQUFJLFdBQVcsWUFBWSxhQUFhO0NBQ3BELE9BQU8sTUFBTSxXQUFZO0VBQUUsT0FBUSxVQUFVLElBQUksYUFBYTtDQUFjLENBQUM7QUFDakY7OztBQ0VBLFNBQWdCLFFBQVE7Q0FDcEIsSUFBSSxPQUFPLENBQUM7Q0FDWixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLEtBQUssTUFBTSxVQUFVO0NBRXpCLElBQUksWUFBWSxhQUFhLElBQUk7Q0FDakMsSUFBSSxhQUFhLFVBQVUsTUFBTSxRQUFRO0NBQ3pDLElBQUksVUFBVTtDQUNkLE9BQU8sQ0FBQyxRQUFRLFNBRVIsUUFDRixRQUFRLFdBQVcsSUFFYixVQUFVLFFBQVEsRUFBRSxJQUVwQixTQUFTLFVBQVUsQ0FBQyxDQUFDLEtBQUssU0FBUyxTQUFTLENBQUM7QUFDN0Q7OztBQ25CQSxJQUFXLFFBQVEsSUFBSSxXQUFXLElBQUk7QUFDdEMsU0FBZ0IsUUFBUTtDQUNwQixPQUFPO0FBQ1g7OztBQ0pBLFNBQWdCLE1BQU0sS0FBSyxXQUFXO0NBQ2xDLE9BQU8sS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHLFNBQVM7QUFDOUM7OztBQ0FBLFNBQWdCLFVBQVUsUUFBUSxXQUFXLFNBQVM7Q0FDbEQsT0FBTyxDQUFDLE9BQU8sV0FBVyxPQUFPLENBQUMsQ0FBQyxVQUFVLE1BQU0sQ0FBQyxHQUFHLE9BQU8sSUFBSSxXQUFXLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVSxNQUFNLENBQUMsQ0FBQztBQUM3Rzs7O0FDSEEsU0FBZ0IsTUFBTSxPQUFPLE9BQU8sV0FBVztDQUMzQyxJQUFJLFNBQVMsTUFBTTtFQUNmLFFBQVE7RUFDUixRQUFRO0NBQ1o7Q0FDQSxJQUFJLFNBQVMsR0FDVCxPQUFPO0NBRVgsSUFBSSxNQUFNLFFBQVE7Q0FDbEIsT0FBTyxJQUFJLFdBQVcsWUFFZCxTQUFVLFlBQVk7RUFDbEIsSUFBSSxJQUFJO0VBQ1IsT0FBTyxVQUFVLFNBQVMsV0FBWTtHQUNsQyxJQUFJLElBQUksS0FBSztJQUNULFdBQVcsS0FBSyxHQUFHO0lBQ25CLEtBQUssU0FBUztHQUNsQixPQUVJLFdBQVcsU0FBUztFQUU1QixDQUFDO0NBQ0wsSUFFQSxTQUFVLFlBQVk7RUFDbEIsSUFBSSxJQUFJO0VBQ1IsT0FBTyxJQUFJLE9BQU8sQ0FBQyxXQUFXLFFBQzFCLFdBQVcsS0FBSyxHQUFHO0VBRXZCLFdBQVcsU0FBUztDQUN4QixDQUFDO0FBQ2I7OztBQzlCQSxTQUFnQixNQUFNLGlCQUFpQixtQkFBbUI7Q0FDdEQsT0FBTyxJQUFJLFdBQVcsU0FBVSxZQUFZO0VBQ3hDLElBQUksV0FBVyxnQkFBZ0I7RUFDL0IsSUFBSSxTQUFTLGtCQUFrQixRQUFRO0VBRXZDLENBRGEsU0FBUyxVQUFVLE1BQU0sSUFBSSxNQUFBLENBQ25DLFVBQVUsVUFBVTtFQUMzQixPQUFPLFdBQVk7R0FDZixJQUFJLFVBQ0EsU0FBUyxZQUFZO0VBRTdCO0NBQ0osQ0FBQztBQUNMIn0=