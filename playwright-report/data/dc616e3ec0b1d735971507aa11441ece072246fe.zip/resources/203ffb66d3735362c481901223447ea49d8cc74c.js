import { t as _defineProperty } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/defineProperty-wQpB4Zl9.js?v=cf17c1b4";
import { t as _objectSpread2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/objectSpread2-mmN4sTVb.js?v=cf17c1b4";
import { $n as Output, Bc as PendingTasksInternal, Bt as computed, Ec as Injector, Ei as provideAppInitializer, El as ɵɵdefineInjector, En as ElementRef, Er as ViewContainerRef, Fn as Injectable, Hc as RuntimeError, In as Input, Io as ɵɵinjectAttribute, Jo as ɵɵlistener, Kc as Version, Mn as IS_HYDRATION_DOM_REUSE_ENABLED, Mr as afterNextRender, Ns as ɵɵsanitizeUrlOrResourceUrl, O as booleanAttribute, Pc as NgZone, Ta as ɵɵcontentQuery, Tc as InjectionToken, Ti as performanceMarkFeature, Tl as ɵɵdefineInjectable, Ui as setClassMetadata, Wt as linkedSignal, X as input, Yn as NgModuleFactory$1, Yo as ɵɵloadQuery, Yt as APP_BOOTSTRAP_LISTENER, _c as EnvironmentInjector, _i as isNgModule, _s as ɵɵqueryRefresh, a as ContentChildren, an as ChangeDetectionStrategy, ao as ɵɵdirectiveInject, bl as signal, ca as ɵɵNgOnChangesFeature, cl as isInjectable, cn as Component, dr as Service, el as effect, eo as ɵɵdefineComponent, et as maybeUnwrapDefaultExport, f as HostAttributeToken, fl as makeEnvironmentProviders, fn as Console, ft as reflectComponentType, gl as provideEnvironmentInitializer, hc as ENVIRONMENT_INITIALIZER, ho as ɵɵelement, io as ɵɵdefineService, ir as Renderer2, ji as publishNonCoreGlobalUtil, jn as IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, kl as ɵɵinject, kn as HostListener, mc as DestroyRef, ml as promiseWithResolvers, nn as Attribute, no as ɵɵdefineNgModule, ol as inject, on as Compiler, pc as DOCUMENT, qn as NgModule, qo as ɵɵinvalidFactory, qr as createEnvironmentInjector, qt as untracked, r as ChangeDetectorRef, tl as formatRuntimeError, tn as ApplicationRef, to as ɵɵdefineDirective, ul as isStandalone, va as ɵɵattribute, vi as isPromise, vl as runInInjectionContext, wc as INTERNAL_APPLICATION_ERROR_HANDLER, wn as Directive, yc as EventEmitter } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/core-BV_jmGG7.js?v=cf17c1b4";
import { Cn as from, Et as take, Ft as concatMap, Ht as catchError, Pn as EMPTY, Qt as filter, S as startWith, Sn as of, Un as BehaviorSubject, Wn as Subject, Xn as pipe, Yn as Observable, _ as takeUntil, cn as combineLatest, fn as map, h as tap, in as concat, lt as finalize, on as mergeAll, ot as first, rr as Subscription, rt as takeLast, sn as mergeMap, vn as EmptyError, x as switchMap, xn as throwError } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/zipWith-DkrnN79P.js?v=cf17c1b4";
import { m as defer, y as isObservable } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/esm5-1bPjeIHk.js?v=cf17c1b4";
import { t as _asyncToGenerator } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/asyncToGenerator-B0cJ8fiL.js?v=cf17c1b4";
import { a as LOCATION_INITIALIZED, o as PlatformLocation } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/_xhr-chunk-CYugLJIp.js?v=cf17c1b4";
import { Mt as LocationStrategy, Pt as PathLocationStrategy, jt as Location, k as HashLocationStrategy, l as ViewportScroller, n as NavigationAdapterForLocation, v as PRECOMMIT_HANDLER_SUPPORTED, y as PlatformNavigation } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/common-WY4jSC-k.js?v=cf17c1b4";
import { s as Title } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/platform-browser-BsJx5wNc.js?v=cf17c1b4";
//#region node_modules/@angular/router/fesm2022/_router-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _UrlSerializer;
var _ChildrenOutletContexts;
var _RouterOutlet;
var _RoutedComponentInputBinder;
var _ɵEmptyOutletComponent;
var _TitleStrategy;
var _DefaultTitleStrategy;
var _RouterConfigLoader;
var _UrlHandlingStrategy;
var _DefaultUrlHandlingStrategy;
var _NavigationTransitions;
var _RouteReuseStrategy;
var _DefaultRouteReuseStrategy;
var _StateManager;
var _HistoryStateManager;
var _Router;
var PRIMARY_OUTLET = "primary";
var RouteTitleKey = /* @__PURE__ */ Symbol("RouteTitle");
var ParamsAsMap = class {
	constructor(params) {
		_defineProperty(this, "params", void 0);
		this.params = params || {};
	}
	has(name) {
		return Object.prototype.hasOwnProperty.call(this.params, name);
	}
	get(name) {
		if (this.has(name)) {
			const v = this.params[name];
			return Array.isArray(v) ? v[0] : v;
		}
		return null;
	}
	getAll(name) {
		if (this.has(name)) {
			const v = this.params[name];
			return Array.isArray(v) ? v : [v];
		}
		return [];
	}
	get keys() {
		return Object.keys(this.params);
	}
};
function convertToParamMap(params) {
	return new ParamsAsMap(params);
}
function matchParts(routeParts, urlSegments, posParams) {
	for (let i = 0; i < routeParts.length; i++) {
		const part = routeParts[i];
		const segment = urlSegments[i];
		if (part[0] === ":") posParams[part.substring(1)] = segment;
		else if (part !== segment.path) return false;
	}
	return true;
}
function defaultUrlMatcher(segments, segmentGroup, route) {
	const parts = route.path.split("/");
	const wildcardIndex = parts.indexOf("**");
	if (wildcardIndex === -1) {
		if (parts.length > segments.length) return null;
		if (route.pathMatch === "full" && (segmentGroup.hasChildren() || parts.length < segments.length)) return null;
		const posParams = {};
		const consumed = segments.slice(0, parts.length);
		if (!matchParts(parts, consumed, posParams)) return null;
		return {
			consumed,
			posParams
		};
	}
	if (wildcardIndex !== parts.lastIndexOf("**")) return null;
	const pre = parts.slice(0, wildcardIndex);
	const post = parts.slice(wildcardIndex + 1);
	if (pre.length + post.length > segments.length) return null;
	if (route.pathMatch === "full" && segmentGroup.hasChildren() && route.path !== "**") return null;
	const posParams = {};
	if (!matchParts(pre, segments.slice(0, pre.length), posParams)) return null;
	if (!matchParts(post, segments.slice(segments.length - post.length), posParams)) return null;
	return {
		consumed: segments,
		posParams
	};
}
function firstValueFrom(source) {
	return new Promise((resolve, reject) => {
		source.pipe(first()).subscribe({
			next: (value) => resolve(value),
			error: (err) => reject(err)
		});
	});
}
function shallowEqualArrays(a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; ++i) if (!shallowEqual(a[i], b[i])) return false;
	return true;
}
function shallowEqual(a, b) {
	const k1 = a ? getDataKeys(a) : void 0;
	const k2 = b ? getDataKeys(b) : void 0;
	if (!k1 || !k2 || k1.length != k2.length) return false;
	let key;
	for (let i = 0; i < k1.length; i++) {
		key = k1[i];
		if (!equalArraysOrString(a[key], b[key])) return false;
	}
	return true;
}
function getDataKeys(obj) {
	return [...Object.keys(obj), ...Object.getOwnPropertySymbols(obj)];
}
function equalArraysOrString(a, b) {
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return false;
		const aSorted = [...a].sort();
		const bSorted = [...b].sort();
		return aSorted.every((val, index) => bSorted[index] === val);
	} else return a === b;
}
function last(a) {
	return a.length > 0 ? a[a.length - 1] : null;
}
function wrapIntoObservable(value) {
	if (isObservable(value)) return value;
	if (isPromise(value)) return from(Promise.resolve(value));
	return of(value);
}
function wrapIntoPromise(value) {
	if (isObservable(value)) return firstValueFrom(value);
	return Promise.resolve(value);
}
var pathCompareMap = {
	"exact": equalSegmentGroups,
	"subset": containsSegmentGroup
};
var paramCompareMap = {
	"exact": equalParams,
	"subset": containsParams,
	"ignored": () => true
};
var exactMatchOptions = {
	paths: "exact",
	fragment: "ignored",
	matrixParams: "ignored",
	queryParams: "exact"
};
var subsetMatchOptions = {
	paths: "subset",
	fragment: "ignored",
	matrixParams: "ignored",
	queryParams: "subset"
};
function isActive(url, router, matchOptions) {
	const urlTree = url instanceof UrlTree ? url : router.parseUrl(url);
	return computed(() => {
		var _router$lastSuccessfu, _router$lastSuccessfu2;
		return containsTree((_router$lastSuccessfu = (_router$lastSuccessfu2 = router.lastSuccessfulNavigation()) === null || _router$lastSuccessfu2 === void 0 ? void 0 : _router$lastSuccessfu2.finalUrl) !== null && _router$lastSuccessfu !== void 0 ? _router$lastSuccessfu : new UrlTree(), urlTree, _objectSpread2(_objectSpread2({}, subsetMatchOptions), matchOptions));
	});
}
function containsTree(container, containee, options) {
	return pathCompareMap[options.paths](container.root, containee.root, options.matrixParams) && paramCompareMap[options.queryParams](container.queryParams, containee.queryParams) && !(options.fragment === "exact" && container.fragment !== containee.fragment);
}
function equalParams(container, containee) {
	return shallowEqual(container, containee);
}
function equalSegmentGroups(container, containee, matrixParams) {
	if (!equalPath(container.segments, containee.segments)) return false;
	if (!matrixParamsMatch(container.segments, containee.segments, matrixParams)) return false;
	if (container.numberOfChildren !== containee.numberOfChildren) return false;
	for (const c in containee.children) {
		if (!container.children[c]) return false;
		if (!equalSegmentGroups(container.children[c], containee.children[c], matrixParams)) return false;
	}
	return true;
}
function containsParams(container, containee) {
	return Object.keys(containee).length <= Object.keys(container).length && Object.keys(containee).every((key) => equalArraysOrString(container[key], containee[key]));
}
function containsSegmentGroup(container, containee, matrixParams) {
	return containsSegmentGroupHelper(container, containee, containee.segments, matrixParams);
}
function containsSegmentGroupHelper(container, containee, containeePaths, matrixParams) {
	if (container.segments.length > containeePaths.length) {
		const current = container.segments.slice(0, containeePaths.length);
		if (!equalPath(current, containeePaths)) return false;
		if (containee.hasChildren()) return false;
		if (!matrixParamsMatch(current, containeePaths, matrixParams)) return false;
		return true;
	} else if (container.segments.length === containeePaths.length) {
		if (!equalPath(container.segments, containeePaths)) return false;
		if (!matrixParamsMatch(container.segments, containeePaths, matrixParams)) return false;
		for (const c in containee.children) {
			if (!container.children[c]) return false;
			if (!containsSegmentGroup(container.children[c], containee.children[c], matrixParams)) return false;
		}
		return true;
	} else {
		const current = containeePaths.slice(0, container.segments.length);
		const next = containeePaths.slice(container.segments.length);
		if (!equalPath(container.segments, current)) return false;
		if (!matrixParamsMatch(container.segments, current, matrixParams)) return false;
		if (!container.children["primary"]) return false;
		return containsSegmentGroupHelper(container.children[PRIMARY_OUTLET], containee, next, matrixParams);
	}
}
function matrixParamsMatch(containerPaths, containeePaths, options) {
	return containeePaths.every((containeeSegment, i) => {
		return paramCompareMap[options](containerPaths[i].parameters, containeeSegment.parameters);
	});
}
var UrlTree = class {
	constructor(root = new UrlSegmentGroup([], {}), queryParams = {}, fragment = null) {
		_defineProperty(this, "root", void 0);
		_defineProperty(this, "queryParams", void 0);
		_defineProperty(this, "fragment", void 0);
		_defineProperty(this, "_queryParamMap", void 0);
		this.root = root;
		this.queryParams = queryParams;
		this.fragment = fragment;
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			if (root.segments.length > 0) throw new RuntimeError(4015, "The root `UrlSegmentGroup` should not contain `segments`. Instead, these segments belong in the `children` so they can be associated with a named outlet.");
		}
	}
	get queryParamMap() {
		var _this$_queryParamMap;
		(_this$_queryParamMap = this._queryParamMap) !== null && _this$_queryParamMap !== void 0 || (this._queryParamMap = convertToParamMap(this.queryParams));
		return this._queryParamMap;
	}
	toString() {
		return DEFAULT_SERIALIZER.serialize(this);
	}
};
var UrlSegmentGroup = class {
	constructor(segments, children) {
		_defineProperty(this, "segments", void 0);
		_defineProperty(this, "children", void 0);
		_defineProperty(this, "parent", null);
		this.segments = segments;
		this.children = children;
		Object.values(children).forEach((v) => v.parent = this);
	}
	hasChildren() {
		return this.numberOfChildren > 0;
	}
	get numberOfChildren() {
		return Object.keys(this.children).length;
	}
	toString() {
		return serializePaths(this);
	}
};
var UrlSegment = class {
	constructor(path, parameters) {
		_defineProperty(this, "path", void 0);
		_defineProperty(this, "parameters", void 0);
		_defineProperty(this, "_parameterMap", void 0);
		this.path = path;
		this.parameters = parameters;
	}
	get parameterMap() {
		var _this$_parameterMap;
		(_this$_parameterMap = this._parameterMap) !== null && _this$_parameterMap !== void 0 || (this._parameterMap = convertToParamMap(this.parameters));
		return this._parameterMap;
	}
	toString() {
		return serializePath(this);
	}
};
function equalSegments(as, bs) {
	return equalPath(as, bs) && as.every((a, i) => shallowEqual(a.parameters, bs[i].parameters));
}
function equalPath(as, bs) {
	if (as.length !== bs.length) return false;
	return as.every((a, i) => a.path === bs[i].path);
}
function mapChildrenIntoArray(segment, fn) {
	let res = [];
	Object.entries(segment.children).forEach(([childOutlet, child]) => {
		if (childOutlet === "primary") res = res.concat(fn(child, childOutlet));
	});
	Object.entries(segment.children).forEach(([childOutlet, child]) => {
		if (childOutlet !== "primary") res = res.concat(fn(child, childOutlet));
	});
	return res;
}
var UrlSerializer = class {};
_UrlSerializer = UrlSerializer;
_defineProperty(UrlSerializer, "ɵfac", function UrlSerializer_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _UrlSerializer)();
});
_defineProperty(UrlSerializer, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _UrlSerializer,
	factory: () => (() => new DefaultUrlSerializer())()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UrlSerializer, [{
		type: Service,
		args: [{ factory: () => new DefaultUrlSerializer() }]
	}], null, null);
})();
var DefaultUrlSerializer = class {
	parse(url) {
		const p = new UrlParser(url);
		return new UrlTree(p.parseRootSegment(), p.parseQueryParams(), p.parseFragment());
	}
	serialize(tree) {
		const segment = `/${serializeSegment(tree.root, true)}`;
		if (segment.startsWith("//")) throw new RuntimeError(4019, (typeof ngDevMode === "undefined" || ngDevMode) && "Cannot serialize a UrlTree that would produce a protocol-relative URL.");
		return `${segment}${serializeQueryParams(tree.queryParams)}${typeof tree.fragment === `string` ? `#${encodeUriFragment(tree.fragment)}` : ""}`;
	}
};
var DEFAULT_SERIALIZER = new DefaultUrlSerializer();
function serializePaths(segment) {
	return segment.segments.map((p) => serializePath(p)).join("/");
}
function serializeSegment(segment, root) {
	if (!segment.hasChildren()) return serializePaths(segment);
	if (root) {
		const primary = segment.children["primary"] ? serializeSegment(segment.children[PRIMARY_OUTLET], false) : "";
		const children = [];
		Object.entries(segment.children).forEach(([k, v]) => {
			if (k !== "primary") children.push(`${k}:${serializeSegment(v, false)}`);
		});
		return children.length > 0 ? `${primary}(${children.join("//")})` : primary;
	} else {
		const children = mapChildrenIntoArray(segment, (v, k) => {
			if (k === "primary") return [serializeSegment(segment.children[PRIMARY_OUTLET], false)];
			return [`${k}:${serializeSegment(v, false)}`];
		});
		if (Object.keys(segment.children).length === 1 && segment.children["primary"] != null) return `${serializePaths(segment)}/${children[0]}`;
		return `${serializePaths(segment)}/(${children.join("//")})`;
	}
}
function encodeUriString(s) {
	return encodeURIComponent(s).replace(/%40/g, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",");
}
function encodeUriQuery(s) {
	return encodeUriString(s).replace(/%3B/gi, ";");
}
function encodeUriFragment(s) {
	return encodeURI(s);
}
function encodeUriSegment(s) {
	return encodeUriString(s).replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/%26/gi, "&");
}
function decode(s) {
	return decodeURIComponent(s);
}
function decodeQuery(s) {
	return decode(s.replace(/\+/g, "%20"));
}
function serializePath(path) {
	return `${encodeUriSegment(path.path)}${serializeMatrixParams(path.parameters)}`;
}
function serializeMatrixParams(params) {
	return Object.entries(params).map(([key, value]) => `;${encodeUriSegment(key)}=${encodeUriSegment(value)}`).join("");
}
function serializeQueryParams(params) {
	const strParams = Object.entries(params).map(([name, value]) => {
		return Array.isArray(value) ? value.map((v) => `${encodeUriQuery(name)}=${encodeUriQuery(v)}`).join("&") : `${encodeUriQuery(name)}=${encodeUriQuery(value)}`;
	}).filter((s) => s);
	return strParams.length ? `?${strParams.join("&")}` : "";
}
var SEGMENT_RE = /^[^\/()?;#]+/;
function matchSegments(str) {
	const match = str.match(SEGMENT_RE);
	return match ? match[0] : "";
}
var MATRIX_PARAM_SEGMENT_RE = /^[^\/()?;=#]+/;
function matchMatrixKeySegments(str) {
	const match = str.match(MATRIX_PARAM_SEGMENT_RE);
	return match ? match[0] : "";
}
var QUERY_PARAM_RE = /^[^=?&#]+/;
function matchQueryParams(str) {
	const match = str.match(QUERY_PARAM_RE);
	return match ? match[0] : "";
}
var QUERY_PARAM_VALUE_RE = /^[^&#]+/;
function matchUrlQueryParamValue(str) {
	const match = str.match(QUERY_PARAM_VALUE_RE);
	return match ? match[0] : "";
}
var UrlParser = class {
	constructor(url) {
		_defineProperty(this, "url", void 0);
		_defineProperty(this, "remaining", void 0);
		this.url = url;
		this.remaining = url;
	}
	parseRootSegment() {
		while (this.consumeOptional("/"));
		if (this.remaining === "" || this.peekStartsWith("?") || this.peekStartsWith("#")) return new UrlSegmentGroup([], {});
		return new UrlSegmentGroup([], this.parseChildren());
	}
	parseQueryParams() {
		const params = {};
		if (this.consumeOptional("?")) do
			this.parseQueryParam(params);
		while (this.consumeOptional("&"));
		return params;
	}
	parseFragment() {
		return this.consumeOptional("#") ? decodeURIComponent(this.remaining) : null;
	}
	parseChildren(depth = 0) {
		if (depth > 50) throw new RuntimeError(4010, (typeof ngDevMode === "undefined" || ngDevMode) && "URL is too deep");
		if (this.remaining === "") return {};
		this.consumeOptional("/");
		const segments = [];
		if (!this.peekStartsWith("(")) segments.push(this.parseSegment());
		while (this.peekStartsWith("/") && !this.peekStartsWith("//") && !this.peekStartsWith("/(")) {
			this.capture("/");
			segments.push(this.parseSegment());
		}
		let children = {};
		if (this.peekStartsWith("/(")) {
			this.capture("/");
			children = this.parseParens(true, depth);
		}
		let res = {};
		if (this.peekStartsWith("(")) res = this.parseParens(false, depth);
		if (segments.length > 0 || Object.keys(children).length > 0) res[PRIMARY_OUTLET] = new UrlSegmentGroup(segments, children);
		return res;
	}
	parseSegment() {
		const path = matchSegments(this.remaining);
		if (path === "" && this.peekStartsWith(";")) throw new RuntimeError(4009, (typeof ngDevMode === "undefined" || ngDevMode) && `Empty path url segment cannot have parameters: '${this.remaining}'.`);
		this.capture(path);
		return new UrlSegment(decode(path), this.parseMatrixParams());
	}
	parseMatrixParams() {
		const params = {};
		while (this.consumeOptional(";")) this.parseParam(params);
		return params;
	}
	parseParam(params) {
		const key = matchMatrixKeySegments(this.remaining);
		if (!key) return;
		this.capture(key);
		let value = "";
		if (this.consumeOptional("=")) {
			const valueMatch = matchSegments(this.remaining);
			if (valueMatch) {
				value = valueMatch;
				this.capture(value);
			}
		}
		params[decode(key)] = decode(value);
	}
	parseQueryParam(params) {
		const key = matchQueryParams(this.remaining);
		if (!key) return;
		this.capture(key);
		let value = "";
		if (this.consumeOptional("=")) {
			const valueMatch = matchUrlQueryParamValue(this.remaining);
			if (valueMatch) {
				value = valueMatch;
				this.capture(value);
			}
		}
		const decodedKey = decodeQuery(key);
		const decodedVal = decodeQuery(value);
		if (Object.hasOwn(params, decodedKey)) {
			let currentVal = params[decodedKey];
			if (!Array.isArray(currentVal)) {
				currentVal = [currentVal];
				params[decodedKey] = currentVal;
			}
			currentVal.push(decodedVal);
		} else params[decodedKey] = decodedVal;
	}
	parseParens(allowPrimary, depth) {
		const segments = Object.create(null);
		this.capture("(");
		while (!this.consumeOptional(")") && this.remaining.length > 0) {
			var _outletName;
			const path = matchSegments(this.remaining);
			const next = this.remaining[path.length];
			if (next !== "/" && next !== ")" && next !== ";") throw new RuntimeError(4010, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot parse url '${this.url}'`);
			let outletName;
			if (path.indexOf(":") > -1) {
				outletName = path.slice(0, path.indexOf(":"));
				this.capture(outletName);
				this.capture(":");
			} else if (allowPrimary) outletName = PRIMARY_OUTLET;
			const children = this.parseChildren(depth + 1);
			segments[(_outletName = outletName) !== null && _outletName !== void 0 ? _outletName : PRIMARY_OUTLET] = Object.keys(children).length === 1 && children["primary"] ? children[PRIMARY_OUTLET] : new UrlSegmentGroup([], children);
			this.consumeOptional("//");
		}
		return segments;
	}
	peekStartsWith(str) {
		return this.remaining.startsWith(str);
	}
	consumeOptional(str) {
		if (this.peekStartsWith(str)) {
			this.remaining = this.remaining.substring(str.length);
			return true;
		}
		return false;
	}
	capture(str) {
		if (!this.consumeOptional(str)) throw new RuntimeError(4011, (typeof ngDevMode === "undefined" || ngDevMode) && `Expected "${str}".`);
	}
};
function createRoot(rootCandidate) {
	return rootCandidate.segments.length > 0 ? new UrlSegmentGroup([], { [PRIMARY_OUTLET]: rootCandidate }) : rootCandidate;
}
function squashSegmentGroup(segmentGroup) {
	const newChildren = Object.create(null);
	for (const [childOutlet, child] of Object.entries(segmentGroup.children)) {
		const childCandidate = squashSegmentGroup(child);
		if (childOutlet === "primary" && childCandidate.segments.length === 0 && childCandidate.hasChildren()) for (const [grandChildOutlet, grandChild] of Object.entries(childCandidate.children)) newChildren[grandChildOutlet] = grandChild;
		else if (childCandidate.segments.length > 0 || childCandidate.hasChildren()) newChildren[childOutlet] = childCandidate;
	}
	return mergeTrivialChildren(new UrlSegmentGroup(segmentGroup.segments, newChildren));
}
function mergeTrivialChildren(s) {
	if (s.numberOfChildren === 1 && s.children["primary"]) {
		const c = s.children[PRIMARY_OUTLET];
		return new UrlSegmentGroup(s.segments.concat(c.segments), c.children);
	}
	return s;
}
function isUrlTree(v) {
	return v instanceof UrlTree;
}
function createUrlTreeFromSnapshot(relativeTo, commands, queryParams = null, fragment = null, urlSerializer = new DefaultUrlSerializer()) {
	return createUrlTreeFromSegmentGroup(createSegmentGroupFromRoute(relativeTo), commands, queryParams, fragment, urlSerializer);
}
function createSegmentGroupFromRoute(route) {
	var _targetGroup;
	let targetGroup;
	function createSegmentGroupFromRouteRecursive(currentRoute) {
		const childOutlets = {};
		for (const childSnapshot of currentRoute.children) {
			const root = createSegmentGroupFromRouteRecursive(childSnapshot);
			childOutlets[childSnapshot.outlet] = root;
		}
		const segmentGroup = new UrlSegmentGroup(currentRoute.url, childOutlets);
		if (currentRoute === route) targetGroup = segmentGroup;
		return segmentGroup;
	}
	const rootSegmentGroup = createRoot(createSegmentGroupFromRouteRecursive(route.root));
	return (_targetGroup = targetGroup) !== null && _targetGroup !== void 0 ? _targetGroup : rootSegmentGroup;
}
function createUrlTreeFromSegmentGroup(relativeTo, commands, queryParams, fragment, urlSerializer) {
	let root = relativeTo;
	while (root.parent) root = root.parent;
	if (commands.length === 0) return tree(root, root, root, queryParams, fragment, urlSerializer);
	const nav = computeNavigation(commands);
	if (nav.toRoot()) return tree(root, root, new UrlSegmentGroup([], {}), queryParams, fragment, urlSerializer);
	const position = findStartingPositionForTargetGroup(nav, root, relativeTo);
	const newSegmentGroup = position.processChildren ? updateSegmentGroupChildren(position.segmentGroup, position.index, nav.commands) : updateSegmentGroup(position.segmentGroup, position.index, nav.commands);
	return tree(root, position.segmentGroup, newSegmentGroup, queryParams, fragment, urlSerializer);
}
function isMatrixParams(command) {
	return typeof command === "object" && command != null && !command.outlets && !command.segmentPath;
}
function isCommandWithOutlets(command) {
	return typeof command === "object" && command != null && command.outlets;
}
function normalizeQueryParams(k, v, urlSerializer) {
	k || (k = "ɵ");
	const tree = new UrlTree();
	tree.queryParams = { [k]: v };
	return urlSerializer.parse(urlSerializer.serialize(tree)).queryParams[k];
}
function tree(oldRoot, oldSegmentGroup, newSegmentGroup, queryParams, fragment, urlSerializer) {
	const qp = {};
	for (const [key, value] of Object.entries(queryParams !== null && queryParams !== void 0 ? queryParams : {})) qp[key] = Array.isArray(value) ? value.map((v) => normalizeQueryParams(key, v, urlSerializer)) : normalizeQueryParams(key, value, urlSerializer);
	let rootCandidate;
	if (oldRoot === oldSegmentGroup) rootCandidate = newSegmentGroup;
	else rootCandidate = replaceSegment(oldRoot, oldSegmentGroup, newSegmentGroup);
	return new UrlTree(createRoot(squashSegmentGroup(rootCandidate)), qp, fragment);
}
function replaceSegment(current, oldSegment, newSegment) {
	const children = Object.create(null);
	Object.entries(current.children).forEach(([outletName, c]) => {
		if (c === oldSegment) children[outletName] = newSegment;
		else children[outletName] = replaceSegment(c, oldSegment, newSegment);
	});
	return new UrlSegmentGroup(current.segments, children);
}
var Navigation = class {
	constructor(isAbsolute, numberOfDoubleDots, commands) {
		_defineProperty(this, "isAbsolute", void 0);
		_defineProperty(this, "numberOfDoubleDots", void 0);
		_defineProperty(this, "commands", void 0);
		this.isAbsolute = isAbsolute;
		this.numberOfDoubleDots = numberOfDoubleDots;
		this.commands = commands;
		if (isAbsolute && commands.length > 0 && isMatrixParams(commands[0])) throw new RuntimeError(4003, (typeof ngDevMode === "undefined" || ngDevMode) && "Root segment cannot have matrix parameters");
		const cmdWithOutlet = commands.find(isCommandWithOutlets);
		if (cmdWithOutlet && cmdWithOutlet !== last(commands)) throw new RuntimeError(4004, (typeof ngDevMode === "undefined" || ngDevMode) && "{outlets:{}} has to be the last command");
	}
	toRoot() {
		return this.isAbsolute && this.commands.length === 1 && this.commands[0] == "/";
	}
};
function computeNavigation(commands) {
	if (typeof commands[0] === "string" && commands.length === 1 && commands[0] === "/") return new Navigation(true, 0, commands);
	let numberOfDoubleDots = 0;
	let isAbsolute = false;
	const res = commands.reduce((res, cmd, cmdIdx) => {
		if (typeof cmd === "object" && cmd != null) {
			if (cmd.outlets) {
				const outlets = {};
				Object.entries(cmd.outlets).forEach(([name, commands]) => {
					outlets[name] = typeof commands === "string" ? commands.split("/") : commands;
				});
				return [...res, { outlets }];
			}
			if (cmd.segmentPath) return [...res, cmd.segmentPath];
		}
		if (!(typeof cmd === "string")) return [...res, cmd];
		if (cmdIdx === 0) {
			cmd.split("/").forEach((urlPart, partIndex) => {
				if (partIndex == 0 && urlPart === ".");
				else if (partIndex == 0 && urlPart === "") isAbsolute = true;
				else if (urlPart === "..") numberOfDoubleDots++;
				else if (urlPart != "") res.push(urlPart);
			});
			return res;
		}
		return [...res, cmd];
	}, []);
	return new Navigation(isAbsolute, numberOfDoubleDots, res);
}
var Position = class {
	constructor(segmentGroup, processChildren, index) {
		_defineProperty(this, "segmentGroup", void 0);
		_defineProperty(this, "processChildren", void 0);
		_defineProperty(this, "index", void 0);
		this.segmentGroup = segmentGroup;
		this.processChildren = processChildren;
		this.index = index;
	}
};
function findStartingPositionForTargetGroup(nav, root, target) {
	if (nav.isAbsolute) return new Position(root, true, 0);
	if (!target) return new Position(root, false, NaN);
	if (target.parent === null) return new Position(target, true, 0);
	const modifier = isMatrixParams(nav.commands[0]) ? 0 : 1;
	return createPositionApplyingDoubleDots(target, target.segments.length - 1 + modifier, nav.numberOfDoubleDots);
}
function createPositionApplyingDoubleDots(group, index, numberOfDoubleDots) {
	let g = group;
	let ci = index;
	let dd = numberOfDoubleDots;
	while (dd > ci) {
		dd -= ci;
		g = g.parent;
		if (!g) throw new RuntimeError(4005, (typeof ngDevMode === "undefined" || ngDevMode) && "Invalid number of '../'");
		ci = g.segments.length;
	}
	return new Position(g, false, ci - dd);
}
function getOutlets(commands) {
	if (isCommandWithOutlets(commands[0])) return commands[0].outlets;
	return { [PRIMARY_OUTLET]: commands };
}
function updateSegmentGroup(segmentGroup, startIndex, commands) {
	var _segmentGroup;
	(_segmentGroup = segmentGroup) !== null && _segmentGroup !== void 0 || (segmentGroup = new UrlSegmentGroup([], {}));
	if (segmentGroup.segments.length === 0 && segmentGroup.hasChildren()) return updateSegmentGroupChildren(segmentGroup, startIndex, commands);
	const m = prefixedWith(segmentGroup, startIndex, commands);
	const slicedCommands = commands.slice(m.commandIndex);
	if (m.match && m.pathIndex < segmentGroup.segments.length) {
		const g = new UrlSegmentGroup(segmentGroup.segments.slice(0, m.pathIndex), {});
		g.children[PRIMARY_OUTLET] = new UrlSegmentGroup(segmentGroup.segments.slice(m.pathIndex), segmentGroup.children);
		return updateSegmentGroupChildren(g, 0, slicedCommands);
	} else if (m.match && slicedCommands.length === 0) return new UrlSegmentGroup(segmentGroup.segments, {});
	else if (m.match && !segmentGroup.hasChildren()) return createNewSegmentGroup(segmentGroup, startIndex, commands);
	else if (m.match) return updateSegmentGroupChildren(segmentGroup, 0, slicedCommands);
	else return createNewSegmentGroup(segmentGroup, startIndex, commands);
}
function updateSegmentGroupChildren(segmentGroup, startIndex, commands) {
	if (commands.length === 0) return new UrlSegmentGroup(segmentGroup.segments, {});
	else {
		const outlets = getOutlets(commands);
		const children = Object.create(null);
		if (Object.keys(outlets).some((o) => o !== "primary") && segmentGroup.children["primary"] && segmentGroup.numberOfChildren === 1 && segmentGroup.children["primary"].segments.length === 0) {
			const childrenOfEmptyChild = updateSegmentGroupChildren(segmentGroup.children[PRIMARY_OUTLET], startIndex, commands);
			return new UrlSegmentGroup(segmentGroup.segments, childrenOfEmptyChild.children);
		}
		Object.entries(outlets).forEach(([outlet, commands]) => {
			if (typeof commands === "string") commands = [commands];
			if (commands !== null) children[outlet] = updateSegmentGroup(segmentGroup.children[outlet], startIndex, commands);
		});
		Object.entries(segmentGroup.children).forEach(([childOutlet, child]) => {
			if (outlets[childOutlet] === void 0) children[childOutlet] = child;
		});
		return new UrlSegmentGroup(segmentGroup.segments, children);
	}
}
function prefixedWith(segmentGroup, startIndex, commands) {
	let currentCommandIndex = 0;
	let currentPathIndex = startIndex;
	const noMatch = {
		match: false,
		pathIndex: 0,
		commandIndex: 0
	};
	while (currentPathIndex < segmentGroup.segments.length) {
		if (currentCommandIndex >= commands.length) return noMatch;
		const path = segmentGroup.segments[currentPathIndex];
		const command = commands[currentCommandIndex];
		if (isCommandWithOutlets(command)) break;
		const curr = `${command}`;
		const next = currentCommandIndex < commands.length - 1 ? commands[currentCommandIndex + 1] : null;
		if (currentPathIndex > 0 && curr === void 0) break;
		if (curr && next && typeof next === "object" && next.outlets === void 0) {
			if (!compare(curr, next, path)) return noMatch;
			currentCommandIndex += 2;
		} else {
			if (!compare(curr, {}, path)) return noMatch;
			currentCommandIndex++;
		}
		currentPathIndex++;
	}
	return {
		match: true,
		pathIndex: currentPathIndex,
		commandIndex: currentCommandIndex
	};
}
function createNewSegmentGroup(segmentGroup, startIndex, commands) {
	const paths = segmentGroup.segments.slice(0, startIndex);
	let i = 0;
	while (i < commands.length) {
		const command = commands[i];
		if (isCommandWithOutlets(command)) return new UrlSegmentGroup(paths, createNewSegmentChildren(command.outlets));
		if (i === 0 && isMatrixParams(commands[0])) {
			const p = segmentGroup.segments[startIndex];
			paths.push(new UrlSegment(p.path, stringify(commands[0])));
			i++;
			continue;
		}
		const curr = isCommandWithOutlets(command) ? command.outlets[PRIMARY_OUTLET] : `${command}`;
		const next = i < commands.length - 1 ? commands[i + 1] : null;
		if (curr && next && isMatrixParams(next)) {
			paths.push(new UrlSegment(curr, stringify(next)));
			i += 2;
		} else {
			paths.push(new UrlSegment(curr, {}));
			i++;
		}
	}
	return new UrlSegmentGroup(paths, {});
}
function createNewSegmentChildren(outlets) {
	const children = {};
	Object.entries(outlets).forEach(([outlet, commands]) => {
		if (typeof commands === "string") commands = [commands];
		if (commands !== null) children[outlet] = createNewSegmentGroup(new UrlSegmentGroup([], {}), 0, commands);
	});
	return children;
}
function stringify(params) {
	const res = {};
	Object.entries(params).forEach(([k, v]) => res[k] = `${v}`);
	return res;
}
function compare(path, params, segment) {
	return path == segment.path && shallowEqual(params, segment.parameters);
}
var IMPERATIVE_NAVIGATION = "imperative";
var EventType;
(function(EventType) {
	EventType[EventType["NavigationStart"] = 0] = "NavigationStart";
	EventType[EventType["NavigationEnd"] = 1] = "NavigationEnd";
	EventType[EventType["NavigationCancel"] = 2] = "NavigationCancel";
	EventType[EventType["NavigationError"] = 3] = "NavigationError";
	EventType[EventType["RoutesRecognized"] = 4] = "RoutesRecognized";
	EventType[EventType["ResolveStart"] = 5] = "ResolveStart";
	EventType[EventType["ResolveEnd"] = 6] = "ResolveEnd";
	EventType[EventType["GuardsCheckStart"] = 7] = "GuardsCheckStart";
	EventType[EventType["GuardsCheckEnd"] = 8] = "GuardsCheckEnd";
	EventType[EventType["RouteConfigLoadStart"] = 9] = "RouteConfigLoadStart";
	EventType[EventType["RouteConfigLoadEnd"] = 10] = "RouteConfigLoadEnd";
	EventType[EventType["ChildActivationStart"] = 11] = "ChildActivationStart";
	EventType[EventType["ChildActivationEnd"] = 12] = "ChildActivationEnd";
	EventType[EventType["ActivationStart"] = 13] = "ActivationStart";
	EventType[EventType["ActivationEnd"] = 14] = "ActivationEnd";
	EventType[EventType["Scroll"] = 15] = "Scroll";
	EventType[EventType["NavigationSkipped"] = 16] = "NavigationSkipped";
})(EventType || (EventType = {}));
var RouterEvent = class {
	constructor(id, url) {
		_defineProperty(this, "id", void 0);
		_defineProperty(this, "url", void 0);
		this.id = id;
		this.url = url;
	}
};
var NavigationStart = class extends RouterEvent {
	constructor(id, url, navigationTrigger = "imperative", restoredState = null) {
		super(id, url);
		_defineProperty(this, "type", EventType.NavigationStart);
		_defineProperty(this, "navigationTrigger", void 0);
		_defineProperty(this, "restoredState", void 0);
		this.navigationTrigger = navigationTrigger;
		this.restoredState = restoredState;
	}
	toString() {
		return `NavigationStart(id: ${this.id}, url: '${this.url}')`;
	}
};
var NavigationEnd = class extends RouterEvent {
	constructor(id, url, urlAfterRedirects) {
		super(id, url);
		_defineProperty(this, "urlAfterRedirects", void 0);
		_defineProperty(this, "type", EventType.NavigationEnd);
		this.urlAfterRedirects = urlAfterRedirects;
	}
	toString() {
		return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`;
	}
};
var NavigationCancellationCode;
(function(NavigationCancellationCode) {
	NavigationCancellationCode[NavigationCancellationCode["Redirect"] = 0] = "Redirect";
	NavigationCancellationCode[NavigationCancellationCode["SupersededByNewNavigation"] = 1] = "SupersededByNewNavigation";
	NavigationCancellationCode[NavigationCancellationCode["NoDataFromResolver"] = 2] = "NoDataFromResolver";
	NavigationCancellationCode[NavigationCancellationCode["GuardRejected"] = 3] = "GuardRejected";
	NavigationCancellationCode[NavigationCancellationCode["Aborted"] = 4] = "Aborted";
})(NavigationCancellationCode || (NavigationCancellationCode = {}));
var NavigationSkippedCode;
(function(NavigationSkippedCode) {
	NavigationSkippedCode[NavigationSkippedCode["IgnoredSameUrlNavigation"] = 0] = "IgnoredSameUrlNavigation";
	NavigationSkippedCode[NavigationSkippedCode["IgnoredByUrlHandlingStrategy"] = 1] = "IgnoredByUrlHandlingStrategy";
})(NavigationSkippedCode || (NavigationSkippedCode = {}));
var NavigationCancel = class extends RouterEvent {
	constructor(id, url, reason, code) {
		super(id, url);
		_defineProperty(this, "reason", void 0);
		_defineProperty(this, "code", void 0);
		_defineProperty(this, "type", EventType.NavigationCancel);
		this.reason = reason;
		this.code = code;
	}
	toString() {
		return `NavigationCancel(id: ${this.id}, url: '${this.url}')`;
	}
};
function isRedirectingEvent(event) {
	return event instanceof NavigationCancel && (event.code === NavigationCancellationCode.Redirect || event.code === NavigationCancellationCode.SupersededByNewNavigation);
}
var NavigationSkipped = class extends RouterEvent {
	constructor(id, url, reason, code) {
		super(id, url);
		_defineProperty(this, "reason", void 0);
		_defineProperty(this, "code", void 0);
		_defineProperty(this, "type", EventType.NavigationSkipped);
		this.reason = reason;
		this.code = code;
	}
};
var NavigationError = class extends RouterEvent {
	constructor(id, url, error, target) {
		super(id, url);
		_defineProperty(this, "error", void 0);
		_defineProperty(this, "target", void 0);
		_defineProperty(this, "type", EventType.NavigationError);
		this.error = error;
		this.target = target;
	}
	toString() {
		return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`;
	}
};
var RoutesRecognized = class extends RouterEvent {
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		_defineProperty(this, "urlAfterRedirects", void 0);
		_defineProperty(this, "state", void 0);
		_defineProperty(this, "type", EventType.RoutesRecognized);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var GuardsCheckStart = class extends RouterEvent {
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		_defineProperty(this, "urlAfterRedirects", void 0);
		_defineProperty(this, "state", void 0);
		_defineProperty(this, "type", EventType.GuardsCheckStart);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var GuardsCheckEnd = class extends RouterEvent {
	constructor(id, url, urlAfterRedirects, state, shouldActivate) {
		super(id, url);
		_defineProperty(this, "urlAfterRedirects", void 0);
		_defineProperty(this, "state", void 0);
		_defineProperty(this, "shouldActivate", void 0);
		_defineProperty(this, "type", EventType.GuardsCheckEnd);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
		this.shouldActivate = shouldActivate;
	}
	toString() {
		return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`;
	}
};
var ResolveStart = class extends RouterEvent {
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		_defineProperty(this, "urlAfterRedirects", void 0);
		_defineProperty(this, "state", void 0);
		_defineProperty(this, "type", EventType.ResolveStart);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var ResolveEnd = class extends RouterEvent {
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		_defineProperty(this, "urlAfterRedirects", void 0);
		_defineProperty(this, "state", void 0);
		_defineProperty(this, "type", EventType.ResolveEnd);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var RouteConfigLoadStart = class {
	constructor(route) {
		_defineProperty(this, "route", void 0);
		_defineProperty(this, "type", EventType.RouteConfigLoadStart);
		this.route = route;
	}
	toString() {
		return `RouteConfigLoadStart(path: ${this.route.path})`;
	}
};
var RouteConfigLoadEnd = class {
	constructor(route) {
		_defineProperty(this, "route", void 0);
		_defineProperty(this, "type", EventType.RouteConfigLoadEnd);
		this.route = route;
	}
	toString() {
		return `RouteConfigLoadEnd(path: ${this.route.path})`;
	}
};
var ChildActivationStart = class {
	constructor(snapshot) {
		_defineProperty(this, "snapshot", void 0);
		_defineProperty(this, "type", EventType.ChildActivationStart);
		this.snapshot = snapshot;
	}
	toString() {
		return `ChildActivationStart(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var ChildActivationEnd = class {
	constructor(snapshot) {
		_defineProperty(this, "snapshot", void 0);
		_defineProperty(this, "type", EventType.ChildActivationEnd);
		this.snapshot = snapshot;
	}
	toString() {
		return `ChildActivationEnd(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var ActivationStart = class {
	constructor(snapshot) {
		_defineProperty(this, "snapshot", void 0);
		_defineProperty(this, "type", EventType.ActivationStart);
		this.snapshot = snapshot;
	}
	toString() {
		return `ActivationStart(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var ActivationEnd = class {
	constructor(snapshot) {
		_defineProperty(this, "snapshot", void 0);
		_defineProperty(this, "type", EventType.ActivationEnd);
		this.snapshot = snapshot;
	}
	toString() {
		return `ActivationEnd(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var Scroll = class {
	constructor(routerEvent, position, anchor, scrollBehavior) {
		_defineProperty(this, "routerEvent", void 0);
		_defineProperty(this, "position", void 0);
		_defineProperty(this, "anchor", void 0);
		_defineProperty(this, "scrollBehavior", void 0);
		_defineProperty(this, "type", EventType.Scroll);
		this.routerEvent = routerEvent;
		this.position = position;
		this.anchor = anchor;
		this.scrollBehavior = scrollBehavior;
	}
	toString() {
		const pos = this.position ? `${this.position[0]}, ${this.position[1]}` : null;
		return `Scroll(anchor: '${this.anchor}', position: '${pos}')`;
	}
};
var BeforeActivateRoutes = class {};
var BeforeRoutesRecognized = class {};
var RedirectRequest = class {
	constructor(url, navigationBehaviorOptions) {
		_defineProperty(this, "url", void 0);
		_defineProperty(this, "navigationBehaviorOptions", void 0);
		this.url = url;
		this.navigationBehaviorOptions = navigationBehaviorOptions;
	}
};
function isPublicRouterEvent(e) {
	return !(e instanceof BeforeActivateRoutes) && !(e instanceof RedirectRequest) && !(e instanceof BeforeRoutesRecognized);
}
function stringifyEvent(routerEvent) {
	switch (routerEvent.type) {
		case EventType.ActivationEnd:
			var _routerEvent$snapshot;
			return `ActivationEnd(path: '${((_routerEvent$snapshot = routerEvent.snapshot.routeConfig) === null || _routerEvent$snapshot === void 0 ? void 0 : _routerEvent$snapshot.path) || ""}')`;
		case EventType.ActivationStart:
			var _routerEvent$snapshot2;
			return `ActivationStart(path: '${((_routerEvent$snapshot2 = routerEvent.snapshot.routeConfig) === null || _routerEvent$snapshot2 === void 0 ? void 0 : _routerEvent$snapshot2.path) || ""}')`;
		case EventType.ChildActivationEnd:
			var _routerEvent$snapshot3;
			return `ChildActivationEnd(path: '${((_routerEvent$snapshot3 = routerEvent.snapshot.routeConfig) === null || _routerEvent$snapshot3 === void 0 ? void 0 : _routerEvent$snapshot3.path) || ""}')`;
		case EventType.ChildActivationStart:
			var _routerEvent$snapshot4;
			return `ChildActivationStart(path: '${((_routerEvent$snapshot4 = routerEvent.snapshot.routeConfig) === null || _routerEvent$snapshot4 === void 0 ? void 0 : _routerEvent$snapshot4.path) || ""}')`;
		case EventType.GuardsCheckEnd: return `GuardsCheckEnd(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state}, shouldActivate: ${routerEvent.shouldActivate})`;
		case EventType.GuardsCheckStart: return `GuardsCheckStart(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.NavigationCancel: return `NavigationCancel(id: ${routerEvent.id}, url: '${routerEvent.url}')`;
		case EventType.NavigationSkipped: return `NavigationSkipped(id: ${routerEvent.id}, url: '${routerEvent.url}')`;
		case EventType.NavigationEnd: return `NavigationEnd(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}')`;
		case EventType.NavigationError: return `NavigationError(id: ${routerEvent.id}, url: '${routerEvent.url}', error: ${routerEvent.error})`;
		case EventType.NavigationStart: return `NavigationStart(id: ${routerEvent.id}, url: '${routerEvent.url}')`;
		case EventType.ResolveEnd: return `ResolveEnd(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.ResolveStart: return `ResolveStart(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.RouteConfigLoadEnd: return `RouteConfigLoadEnd(path: ${routerEvent.route.path})`;
		case EventType.RouteConfigLoadStart: return `RouteConfigLoadStart(path: ${routerEvent.route.path})`;
		case EventType.RoutesRecognized: return `RoutesRecognized(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.Scroll:
			const pos = routerEvent.position ? `${routerEvent.position[0]}, ${routerEvent.position[1]}` : null;
			return `Scroll(anchor: '${routerEvent.anchor}', position: '${pos}')`;
	}
}
var OutletContext = class {
	get injector() {
		var _this$route$snapshot$, _this$route;
		return (_this$route$snapshot$ = (_this$route = this.route) === null || _this$route === void 0 ? void 0 : _this$route.snapshot._environmentInjector) !== null && _this$route$snapshot$ !== void 0 ? _this$route$snapshot$ : this.rootInjector;
	}
	constructor(rootInjector) {
		_defineProperty(this, "rootInjector", void 0);
		_defineProperty(this, "outlet", null);
		_defineProperty(this, "route", null);
		_defineProperty(this, "children", void 0);
		_defineProperty(this, "attachRef", null);
		this.rootInjector = rootInjector;
		this.children = new ChildrenOutletContexts(this.rootInjector);
	}
};
var ChildrenOutletContexts = class {
	constructor(rootInjector) {
		_defineProperty(this, "rootInjector", void 0);
		_defineProperty(this, "contexts", /* @__PURE__ */ new Map());
		this.rootInjector = rootInjector;
	}
	onChildOutletCreated(childName, outlet) {
		const context = this.getOrCreateContext(childName);
		context.outlet = outlet;
		this.contexts.set(childName, context);
	}
	onChildOutletDestroyed(childName) {
		const context = this.getContext(childName);
		if (context) {
			context.outlet = null;
			context.attachRef = null;
		}
	}
	onOutletDeactivated() {
		const contexts = this.contexts;
		this.contexts = /* @__PURE__ */ new Map();
		return contexts;
	}
	onOutletReAttached(contexts) {
		this.contexts = contexts;
	}
	getOrCreateContext(childName) {
		let context = this.getContext(childName);
		if (!context) {
			context = new OutletContext(this.rootInjector);
			this.contexts.set(childName, context);
		}
		return context;
	}
	getContext(childName) {
		return this.contexts.get(childName) || null;
	}
};
_ChildrenOutletContexts = ChildrenOutletContexts;
_defineProperty(ChildrenOutletContexts, "ɵfac", function ChildrenOutletContexts_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ChildrenOutletContexts)(ɵɵinject(EnvironmentInjector));
});
_defineProperty(ChildrenOutletContexts, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _ChildrenOutletContexts,
	factory: _ChildrenOutletContexts.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChildrenOutletContexts, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: EnvironmentInjector }], null);
})();
var Tree = class {
	constructor(root) {
		_defineProperty(this, "_root", void 0);
		this._root = root;
	}
	get root() {
		return this._root.value;
	}
	parent(t) {
		const p = this.pathFromRoot(t);
		return p.length > 1 ? p[p.length - 2] : null;
	}
	children(t) {
		const n = findNode(t, this._root);
		return n ? n.children.map((t) => t.value) : [];
	}
	firstChild(t) {
		const n = findNode(t, this._root);
		return n && n.children.length > 0 ? n.children[0].value : null;
	}
	siblings(t) {
		const p = findPath(t, this._root);
		if (p.length < 2) return [];
		return p[p.length - 2].children.map((c) => c.value).filter((cc) => cc !== t);
	}
	pathFromRoot(t) {
		return findPath(t, this._root).map((s) => s.value);
	}
};
function findNode(value, node) {
	if (value === node.value) return node;
	for (const child of node.children) {
		const node = findNode(value, child);
		if (node) return node;
	}
	return null;
}
function findPath(value, node) {
	if (value === node.value) return [node];
	for (const child of node.children) {
		const path = findPath(value, child);
		if (path.length) {
			path.unshift(node);
			return path;
		}
	}
	return [];
}
var TreeNode = class {
	constructor(value, children) {
		_defineProperty(this, "value", void 0);
		_defineProperty(this, "children", void 0);
		this.value = value;
		this.children = children;
	}
	toString() {
		return `TreeNode(${this.value})`;
	}
};
function nodeChildrenAsMap(node) {
	const map = {};
	if (node) node.children.forEach((child) => map[child.value.outlet] = child);
	return map;
}
var RouterState = class extends Tree {
	constructor(root, snapshot) {
		super(root);
		_defineProperty(this, "snapshot", void 0);
		this.snapshot = snapshot;
		setRouterState(this, root);
	}
	toString() {
		return this.snapshot.toString();
	}
};
function createEmptyState(rootComponent, injector) {
	const snapshot = createEmptyStateSnapshot(rootComponent, injector);
	const emptyUrl = new BehaviorSubject([new UrlSegment("", {})]);
	const emptyParams = new BehaviorSubject({});
	const emptyData = new BehaviorSubject({});
	const activated = new ActivatedRoute(emptyUrl, emptyParams, new BehaviorSubject({}), new BehaviorSubject(""), emptyData, PRIMARY_OUTLET, rootComponent, snapshot.root);
	activated.snapshot = snapshot.root;
	return new RouterState(new TreeNode(activated, []), snapshot);
}
function createEmptyStateSnapshot(rootComponent, injector) {
	return new RouterStateSnapshot("", new TreeNode(new ActivatedRouteSnapshot([], {}, {}, "", {}, PRIMARY_OUTLET, rootComponent, null, {}, injector), []));
}
var ActivatedRoute = class {
	constructor(urlSubject, paramsSubject, queryParamsSubject, fragmentSubject, dataSubject, outlet, component, futureSnapshot) {
		var _this$dataSubject$pip, _this$dataSubject;
		_defineProperty(this, "urlSubject", void 0);
		_defineProperty(this, "paramsSubject", void 0);
		_defineProperty(this, "queryParamsSubject", void 0);
		_defineProperty(this, "fragmentSubject", void 0);
		_defineProperty(this, "dataSubject", void 0);
		_defineProperty(this, "outlet", void 0);
		_defineProperty(this, "component", void 0);
		_defineProperty(this, "snapshot", void 0);
		_defineProperty(this, "_futureSnapshot", void 0);
		_defineProperty(this, "_routerState", void 0);
		_defineProperty(this, "_paramMap", void 0);
		_defineProperty(this, "_queryParamMap", void 0);
		_defineProperty(this, "title", void 0);
		_defineProperty(this, "url", void 0);
		_defineProperty(this, "params", void 0);
		_defineProperty(this, "queryParams", void 0);
		_defineProperty(this, "fragment", void 0);
		_defineProperty(this, "data", void 0);
		_defineProperty(this, "_localInjector", void 0);
		this.urlSubject = urlSubject;
		this.paramsSubject = paramsSubject;
		this.queryParamsSubject = queryParamsSubject;
		this.fragmentSubject = fragmentSubject;
		this.dataSubject = dataSubject;
		this.outlet = outlet;
		this.component = component;
		this._futureSnapshot = futureSnapshot;
		this.title = (_this$dataSubject$pip = (_this$dataSubject = this.dataSubject) === null || _this$dataSubject === void 0 ? void 0 : _this$dataSubject.pipe(map((d) => d[RouteTitleKey]))) !== null && _this$dataSubject$pip !== void 0 ? _this$dataSubject$pip : of(void 0);
		this.url = urlSubject;
		this.params = paramsSubject;
		this.queryParams = queryParamsSubject;
		this.fragment = fragmentSubject;
		this.data = dataSubject;
	}
	get routeConfig() {
		return this._futureSnapshot.routeConfig;
	}
	get root() {
		return this._routerState.root;
	}
	get parent() {
		return this._routerState.parent(this);
	}
	get firstChild() {
		return this._routerState.firstChild(this);
	}
	get children() {
		return this._routerState.children(this);
	}
	get pathFromRoot() {
		return this._routerState.pathFromRoot(this);
	}
	get paramMap() {
		var _this$_paramMap;
		(_this$_paramMap = this._paramMap) !== null && _this$_paramMap !== void 0 || (this._paramMap = this.params.pipe(map((p) => convertToParamMap(p))));
		return this._paramMap;
	}
	get queryParamMap() {
		var _this$_queryParamMap2;
		(_this$_queryParamMap2 = this._queryParamMap) !== null && _this$_queryParamMap2 !== void 0 || (this._queryParamMap = this.queryParams.pipe(map((p) => convertToParamMap(p))));
		return this._queryParamMap;
	}
	toString() {
		return this.snapshot ? this.snapshot.toString() : `Future(${this._futureSnapshot})`;
	}
};
var DEFAULT_PARAMS_INHERITANCE_STRATEGY = "always";
function getInherited(route, parent, paramsInheritanceStrategy) {
	var _parent$routeConfig;
	let inherited;
	const { routeConfig } = route;
	if (parent !== null && (paramsInheritanceStrategy === "always" || (routeConfig === null || routeConfig === void 0 ? void 0 : routeConfig.path) === "" || !parent.component && !((_parent$routeConfig = parent.routeConfig) === null || _parent$routeConfig === void 0 ? void 0 : _parent$routeConfig.loadComponent))) inherited = {
		params: _objectSpread2(_objectSpread2({}, parent.params), route.params),
		data: _objectSpread2(_objectSpread2({}, parent.data), route.data),
		resolve: _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, route.data), parent.data), routeConfig === null || routeConfig === void 0 ? void 0 : routeConfig.data), route._resolvedData)
	};
	else {
		var _route$_resolvedData;
		inherited = {
			params: _objectSpread2({}, route.params),
			data: _objectSpread2({}, route.data),
			resolve: _objectSpread2(_objectSpread2({}, route.data), (_route$_resolvedData = route._resolvedData) !== null && _route$_resolvedData !== void 0 ? _route$_resolvedData : {})
		};
	}
	if (routeConfig && hasStaticTitle(routeConfig)) inherited.resolve[RouteTitleKey] = routeConfig.title;
	return inherited;
}
var ActivatedRouteSnapshot = class {
	get title() {
		var _this$data;
		return (_this$data = this.data) === null || _this$data === void 0 ? void 0 : _this$data[RouteTitleKey];
	}
	constructor(url, params, queryParams, fragment, data, outlet, component, routeConfig, resolve, environmentInjector) {
		_defineProperty(this, "url", void 0);
		_defineProperty(this, "params", void 0);
		_defineProperty(this, "queryParams", void 0);
		_defineProperty(this, "fragment", void 0);
		_defineProperty(this, "data", void 0);
		_defineProperty(this, "outlet", void 0);
		_defineProperty(this, "component", void 0);
		_defineProperty(this, "routeConfig", void 0);
		_defineProperty(this, "_resolve", void 0);
		_defineProperty(this, "_resolvedData", void 0);
		_defineProperty(this, "_routerState", void 0);
		_defineProperty(this, "_paramMap", void 0);
		_defineProperty(this, "_queryParamMap", void 0);
		_defineProperty(this, "_environmentInjector", void 0);
		this.url = url;
		this.params = params;
		this.queryParams = queryParams;
		this.fragment = fragment;
		this.data = data;
		this.outlet = outlet;
		this.component = component;
		this.routeConfig = routeConfig;
		this._resolve = resolve;
		this._environmentInjector = environmentInjector;
	}
	get root() {
		return this._routerState.root;
	}
	get parent() {
		return this._routerState.parent(this);
	}
	get firstChild() {
		return this._routerState.firstChild(this);
	}
	get children() {
		return this._routerState.children(this);
	}
	get pathFromRoot() {
		return this._routerState.pathFromRoot(this);
	}
	get paramMap() {
		var _this$_paramMap2;
		(_this$_paramMap2 = this._paramMap) !== null && _this$_paramMap2 !== void 0 || (this._paramMap = convertToParamMap(this.params));
		return this._paramMap;
	}
	get queryParamMap() {
		var _this$_queryParamMap3;
		(_this$_queryParamMap3 = this._queryParamMap) !== null && _this$_queryParamMap3 !== void 0 || (this._queryParamMap = convertToParamMap(this.queryParams));
		return this._queryParamMap;
	}
	toString() {
		return `Route(url:'${this.url.map((segment) => segment.toString()).join("/")}', path:'${this.routeConfig ? this.routeConfig.path : ""}')`;
	}
};
var RouterStateSnapshot = class extends Tree {
	constructor(url, root) {
		super(root);
		_defineProperty(this, "url", void 0);
		this.url = url;
		setRouterState(this, root);
	}
	toString() {
		return serializeNode(this._root);
	}
};
function setRouterState(state, node) {
	node.value._routerState = state;
	node.children.forEach((c) => setRouterState(state, c));
}
function serializeNode(node) {
	const c = node.children.length > 0 ? ` { ${node.children.map(serializeNode).join(", ")} } ` : "";
	return `${node.value}${c}`;
}
function advanceActivatedRoute(route) {
	if (route.snapshot) {
		const currentSnapshot = route.snapshot;
		const nextSnapshot = route._futureSnapshot;
		route.snapshot = nextSnapshot;
		if (!shallowEqual(currentSnapshot.queryParams, nextSnapshot.queryParams)) route.queryParamsSubject.next(nextSnapshot.queryParams);
		if (currentSnapshot.fragment !== nextSnapshot.fragment) route.fragmentSubject.next(nextSnapshot.fragment);
		if (!shallowEqual(currentSnapshot.params, nextSnapshot.params)) route.paramsSubject.next(nextSnapshot.params);
		if (!shallowEqualArrays(currentSnapshot.url, nextSnapshot.url)) route.urlSubject.next(nextSnapshot.url);
		if (!shallowEqual(currentSnapshot.data, nextSnapshot.data)) route.dataSubject.next(nextSnapshot.data);
	} else {
		route.snapshot = route._futureSnapshot;
		route.dataSubject.next(route._futureSnapshot.data);
	}
}
function equalParamsAndUrlSegments(a, b) {
	const equalUrlParams = shallowEqual(a.params, b.params) && equalSegments(a.url, b.url);
	const parentsMismatch = !a.parent !== !b.parent;
	return equalUrlParams && !parentsMismatch && (!a.parent || equalParamsAndUrlSegments(a.parent, b.parent));
}
function hasStaticTitle(config) {
	return typeof config.title === "string" || config.title === null;
}
var ROUTER_OUTLET_DATA = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "RouterOutlet data" : "");
var RouterOutlet = class {
	constructor() {
		_defineProperty(this, "activated", null);
		_defineProperty(this, "_activatedRoute", null);
		_defineProperty(this, "name", PRIMARY_OUTLET);
		_defineProperty(this, "activateEvents", new EventEmitter());
		_defineProperty(this, "deactivateEvents", new EventEmitter());
		_defineProperty(this, "attachEvents", new EventEmitter());
		_defineProperty(this, "detachEvents", new EventEmitter());
		_defineProperty(this, "routerOutletData", input(...ngDevMode ? [void 0, { debugName: "routerOutletData" }] : []));
		_defineProperty(this, "parentContexts", inject(ChildrenOutletContexts));
		_defineProperty(this, "location", inject(ViewContainerRef));
		_defineProperty(this, "changeDetector", inject(ChangeDetectorRef));
		_defineProperty(this, "inputBinder", inject(INPUT_BINDER, { optional: true }));
		_defineProperty(this, "supportsBindingToComponentInputs", true);
	}
	get activatedComponentRef() {
		return this.activated;
	}
	ngOnChanges(changes) {
		if (changes["name"]) {
			const { firstChange, previousValue } = changes["name"];
			if (firstChange) return;
			if (this.isTrackedInParentContexts(previousValue)) {
				this.deactivate();
				this.parentContexts.onChildOutletDestroyed(previousValue);
			}
			this.initializeOutletWithName();
		}
	}
	ngOnDestroy() {
		var _this$inputBinder;
		if (this.isTrackedInParentContexts(this.name)) this.parentContexts.onChildOutletDestroyed(this.name);
		(_this$inputBinder = this.inputBinder) === null || _this$inputBinder === void 0 || _this$inputBinder.unsubscribeFromRouteData(this);
	}
	isTrackedInParentContexts(outletName) {
		var _this$parentContexts$;
		return ((_this$parentContexts$ = this.parentContexts.getContext(outletName)) === null || _this$parentContexts$ === void 0 ? void 0 : _this$parentContexts$.outlet) === this;
	}
	ngOnInit() {
		this.initializeOutletWithName();
	}
	initializeOutletWithName() {
		this.parentContexts.onChildOutletCreated(this.name, this);
		if (this.activated) return;
		const context = this.parentContexts.getContext(this.name);
		if (context === null || context === void 0 ? void 0 : context.route) if (context.attachRef) this.attach(context.attachRef, context.route);
		else this.activateWith(context.route, context.injector);
	}
	get isActivated() {
		return !!this.activated;
	}
	get component() {
		if (!this.activated) throw new RuntimeError(4012, (typeof ngDevMode === "undefined" || ngDevMode) && "Outlet is not activated");
		return this.activated.instance;
	}
	get activatedRoute() {
		if (!this.activated) throw new RuntimeError(4012, (typeof ngDevMode === "undefined" || ngDevMode) && "Outlet is not activated");
		return this._activatedRoute;
	}
	get activatedRouteData() {
		if (this._activatedRoute) return this._activatedRoute.snapshot.data;
		return {};
	}
	detach() {
		if (!this.activated) throw new RuntimeError(4012, (typeof ngDevMode === "undefined" || ngDevMode) && "Outlet is not activated");
		this.location.detach();
		const cmp = this.activated;
		this.activated = null;
		this._activatedRoute = null;
		this.detachEvents.emit(cmp.instance);
		return cmp;
	}
	attach(ref, activatedRoute) {
		var _this$inputBinder2;
		this.activated = ref;
		this._activatedRoute = activatedRoute;
		this.location.insert(ref.hostView);
		(_this$inputBinder2 = this.inputBinder) === null || _this$inputBinder2 === void 0 || _this$inputBinder2.bindActivatedRouteToOutletComponent(this);
		this.attachEvents.emit(ref.instance);
	}
	deactivate() {
		if (this.activated) {
			const c = this.component;
			this.activated.destroy();
			this.activated = null;
			this._activatedRoute = null;
			this.deactivateEvents.emit(c);
		}
	}
	activateWith(activatedRoute, environmentInjector) {
		var _this$inputBinder3;
		if (this.isActivated) throw new RuntimeError(4013, (typeof ngDevMode === "undefined" || ngDevMode) && "Cannot activate an already activated outlet");
		this._activatedRoute = activatedRoute;
		const location = this.location;
		const component = activatedRoute.snapshot.component;
		const childContexts = this.parentContexts.getOrCreateContext(this.name).children;
		const injector = new OutletInjector(activatedRoute, childContexts, location.injector, this.routerOutletData);
		this.activated = location.createComponent(component, {
			index: location.length,
			injector,
			environmentInjector
		});
		this.changeDetector.markForCheck();
		(_this$inputBinder3 = this.inputBinder) === null || _this$inputBinder3 === void 0 || _this$inputBinder3.bindActivatedRouteToOutletComponent(this);
		this.activateEvents.emit(this.activated.instance);
	}
};
_RouterOutlet = RouterOutlet;
_defineProperty(RouterOutlet, "ɵfac", function RouterOutlet_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouterOutlet)();
});
_defineProperty(RouterOutlet, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _RouterOutlet,
	selectors: [["router-outlet"]],
	inputs: {
		name: "name",
		routerOutletData: [1, "routerOutletData"]
	},
	outputs: {
		activateEvents: "activate",
		deactivateEvents: "deactivate",
		attachEvents: "attach",
		detachEvents: "detach"
	},
	exportAs: ["outlet"],
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterOutlet, [{
		type: Directive,
		args: [{
			selector: "router-outlet",
			exportAs: "outlet"
		}]
	}], null, {
		name: [{ type: Input }],
		activateEvents: [{
			type: Output,
			args: ["activate"]
		}],
		deactivateEvents: [{
			type: Output,
			args: ["deactivate"]
		}],
		attachEvents: [{
			type: Output,
			args: ["attach"]
		}],
		detachEvents: [{
			type: Output,
			args: ["detach"]
		}],
		routerOutletData: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "routerOutletData",
				required: false
			}]
		}]
	});
})();
var OutletInjector = class {
	constructor(route, childContexts, parent, outletData) {
		_defineProperty(this, "route", void 0);
		_defineProperty(this, "childContexts", void 0);
		_defineProperty(this, "parent", void 0);
		_defineProperty(this, "outletData", void 0);
		this.route = route;
		this.childContexts = childContexts;
		this.parent = parent;
		this.outletData = outletData;
	}
	get(token, notFoundValue) {
		if (token === ActivatedRoute) return this.route;
		if (token === ChildrenOutletContexts) return this.childContexts;
		if (token === ROUTER_OUTLET_DATA) return this.outletData;
		return this.parent.get(token, notFoundValue);
	}
};
var INPUT_BINDER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Router Input Binder" : "");
var RoutedComponentInputBinder = class {
	constructor(options) {
		var _this$options, _this$options$queryPa;
		_defineProperty(this, "options", void 0);
		_defineProperty(this, "outletDataSubscriptions", /* @__PURE__ */ new Map());
		_defineProperty(this, "outletSeenKeys", /* @__PURE__ */ new Map());
		this.options = options;
		(_this$options$queryPa = (_this$options = this.options).queryParams) !== null && _this$options$queryPa !== void 0 || (_this$options.queryParams = true);
	}
	bindActivatedRouteToOutletComponent(outlet) {
		this.unsubscribeFromRouteData(outlet);
		this.subscribeToRouteData(outlet);
	}
	unsubscribeFromRouteData(outlet) {
		var _this$outletDataSubsc;
		(_this$outletDataSubsc = this.outletDataSubscriptions.get(outlet)) === null || _this$outletDataSubsc === void 0 || _this$outletDataSubsc.unsubscribe();
		this.outletDataSubscriptions.delete(outlet);
		this.outletSeenKeys.delete(outlet);
	}
	subscribeToRouteData(outlet) {
		const { activatedRoute } = outlet;
		const dataSubscription = combineLatest([
			this.options.queryParams ? activatedRoute.queryParams : of({}),
			activatedRoute.params,
			activatedRoute.data
		]).pipe(switchMap(([queryParams, params, data], index) => {
			data = _objectSpread2(_objectSpread2(_objectSpread2({}, queryParams), params), data);
			if (index === 0) return of(data);
			return Promise.resolve(data);
		})).subscribe((data) => {
			var _this$options$unmatch;
			if (!outlet.isActivated || !outlet.activatedComponentRef || outlet.activatedRoute !== activatedRoute || activatedRoute.component === null) {
				this.unsubscribeFromRouteData(outlet);
				return;
			}
			const mirror = reflectComponentType(activatedRoute.component);
			if (!mirror) {
				this.unsubscribeFromRouteData(outlet);
				return;
			}
			let seenKeys = this.outletSeenKeys.get(outlet);
			if (!seenKeys) {
				seenKeys = /* @__PURE__ */ new Set();
				this.outletSeenKeys.set(outlet, seenKeys);
			}
			for (const key of Object.keys(data)) seenKeys.add(key);
			const behavior = (_this$options$unmatch = this.options.unmatchedInputBehavior) !== null && _this$options$unmatch !== void 0 ? _this$options$unmatch : "alwaysUndefined";
			for (const { templateName } of mirror.inputs) {
				const value = data[templateName];
				if (value !== void 0 || behavior === "alwaysUndefined" || seenKeys.has(templateName)) outlet.activatedComponentRef.setInput(templateName, value);
			}
		});
		this.outletDataSubscriptions.set(outlet, dataSubscription);
	}
};
_RoutedComponentInputBinder = RoutedComponentInputBinder;
_defineProperty(RoutedComponentInputBinder, "ɵfac", function RoutedComponentInputBinder_Factory(__ngFactoryType__) {
	ɵɵinvalidFactory();
});
_defineProperty(RoutedComponentInputBinder, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _RoutedComponentInputBinder,
	factory: _RoutedComponentInputBinder.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RoutedComponentInputBinder, [{ type: Injectable }], () => [{ type: void 0 }], null);
})();
var ɵEmptyOutletComponent = class {};
_ɵEmptyOutletComponent = ɵEmptyOutletComponent;
_defineProperty(ɵEmptyOutletComponent, "ɵfac", function ɵEmptyOutletComponent_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ɵEmptyOutletComponent)();
});
_defineProperty(ɵEmptyOutletComponent, "ɵcmp", /* @__PURE__ */ ɵɵdefineComponent({
	type: _ɵEmptyOutletComponent,
	selectors: [["ng-component"]],
	exportAs: ["emptyRouterOutlet"],
	decls: 1,
	vars: 0,
	template: function _EmptyOutletComponent_Template(rf, ctx) {
		if (rf & 1) ɵɵelement(0, "router-outlet");
	},
	dependencies: [RouterOutlet],
	encapsulation: 2,
	changeDetection: 1
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ɵEmptyOutletComponent, [{
		type: Component,
		args: [{
			template: `<router-outlet />`,
			imports: [RouterOutlet],
			exportAs: "emptyRouterOutlet",
			changeDetection: ChangeDetectionStrategy.Eager
		}]
	}], null, null);
})();
function standardizeConfig(r) {
	const children = r.children && r.children.map(standardizeConfig);
	const c = children ? _objectSpread2(_objectSpread2({}, r), {}, { children }) : _objectSpread2({}, r);
	if (!c.component && !c.loadComponent && (children || c.loadChildren) && c.outlet && c.outlet !== "primary") c.component = ɵEmptyOutletComponent;
	return c;
}
function createRouterState(routeReuseStrategy, curr, prevState) {
	const newlyCreatedRoutes = /* @__PURE__ */ new Set();
	return {
		newlyCreatedRoutes,
		state: new RouterState(createNode(routeReuseStrategy, curr._root, prevState ? prevState._root : void 0, newlyCreatedRoutes), curr)
	};
}
function createNode(routeReuseStrategy, curr, prevState, newlyCreatedRoutes) {
	if (prevState && routeReuseStrategy.shouldReuseRoute(curr.value, prevState.value.snapshot)) {
		const value = prevState.value;
		value._futureSnapshot = curr.value;
		return new TreeNode(value, createOrReuseChildren(routeReuseStrategy, curr, prevState, newlyCreatedRoutes));
	} else {
		if (routeReuseStrategy.shouldAttach(curr.value)) {
			const detachedRouteHandle = routeReuseStrategy.retrieve(curr.value);
			if (detachedRouteHandle !== null) {
				const tree = detachedRouteHandle.route;
				tree.value._futureSnapshot = curr.value;
				tree.children = curr.children.map((c) => createNode(routeReuseStrategy, c, void 0, newlyCreatedRoutes));
				return tree;
			}
		}
		const value = createActivatedRoute(curr.value);
		newlyCreatedRoutes.add(value);
		return new TreeNode(value, curr.children.map((c) => createNode(routeReuseStrategy, c, void 0, newlyCreatedRoutes)));
	}
}
function createOrReuseChildren(routeReuseStrategy, curr, prevState, newlyCreatedRoutes) {
	return curr.children.map((child) => {
		for (const p of prevState.children) if (routeReuseStrategy.shouldReuseRoute(child.value, p.value.snapshot)) return createNode(routeReuseStrategy, child, p, newlyCreatedRoutes);
		return createNode(routeReuseStrategy, child, void 0, newlyCreatedRoutes);
	});
}
function createActivatedRoute(c) {
	return new ActivatedRoute(new BehaviorSubject(c.url), new BehaviorSubject(c.params), new BehaviorSubject(c.queryParams), new BehaviorSubject(c.fragment), new BehaviorSubject(c.data), c.outlet, c.component, c);
}
var RedirectCommand = class {
	constructor(redirectTo, navigationBehaviorOptions) {
		_defineProperty(this, "redirectTo", void 0);
		_defineProperty(this, "navigationBehaviorOptions", void 0);
		this.redirectTo = redirectTo;
		this.navigationBehaviorOptions = navigationBehaviorOptions;
	}
};
var NAVIGATION_CANCELING_ERROR = "ngNavigationCancelingError";
function redirectingNavigationError(urlSerializer, redirect) {
	const { redirectTo, navigationBehaviorOptions } = isUrlTree(redirect) ? {
		redirectTo: redirect,
		navigationBehaviorOptions: void 0
	} : redirect;
	const error = navigationCancelingError(ngDevMode && `Redirecting to "${urlSerializer.serialize(redirectTo)}"`, NavigationCancellationCode.Redirect);
	error.url = redirectTo;
	error.navigationBehaviorOptions = navigationBehaviorOptions;
	return error;
}
function navigationCancelingError(message, code) {
	const error = /* @__PURE__ */ new Error(`NavigationCancelingError: ${message || ""}`);
	error[NAVIGATION_CANCELING_ERROR] = true;
	error.cancellationCode = code;
	return error;
}
function isRedirectingNavigationCancelingError(error) {
	return isNavigationCancelingError(error) && isUrlTree(error.url);
}
function isNavigationCancelingError(error) {
	return !!error && error[NAVIGATION_CANCELING_ERROR];
}
var warnedAboutUnsupportedInputBinding = false;
var ActivateRoutes = class {
	constructor(routeReuseStrategy, futureState, currState, forwardEvent, inputBindingEnabled) {
		_defineProperty(this, "routeReuseStrategy", void 0);
		_defineProperty(this, "futureState", void 0);
		_defineProperty(this, "currState", void 0);
		_defineProperty(this, "forwardEvent", void 0);
		_defineProperty(this, "inputBindingEnabled", void 0);
		this.routeReuseStrategy = routeReuseStrategy;
		this.futureState = futureState;
		this.currState = currState;
		this.forwardEvent = forwardEvent;
		this.inputBindingEnabled = inputBindingEnabled;
	}
	activate(parentContexts) {
		const futureRoot = this.futureState._root;
		const currRoot = this.currState ? this.currState._root : null;
		this.deactivateChildRoutes(futureRoot, currRoot, parentContexts);
		advanceActivatedRoute(this.futureState.root);
		this.activateChildRoutes(futureRoot, currRoot, parentContexts);
	}
	deactivateChildRoutes(futureNode, currNode, contexts) {
		const children = nodeChildrenAsMap(currNode);
		futureNode.children.forEach((futureChild) => {
			const childOutletName = futureChild.value.outlet;
			this.deactivateRoutes(futureChild, children[childOutletName], contexts);
			delete children[childOutletName];
		});
		Object.values(children).forEach((v) => {
			this.deactivateRouteAndItsChildren(v, contexts);
		});
	}
	deactivateRoutes(futureNode, currNode, parentContext) {
		const future = futureNode.value;
		const curr = currNode ? currNode.value : null;
		if (future === curr) if (future.component) {
			const context = parentContext.getContext(future.outlet);
			if (context) this.deactivateChildRoutes(futureNode, currNode, context.children);
		} else this.deactivateChildRoutes(futureNode, currNode, parentContext);
		else if (curr) this.deactivateRouteAndItsChildren(currNode, parentContext);
	}
	deactivateRouteAndItsChildren(route, parentContexts) {
		if (route.value.component && this.routeReuseStrategy.shouldDetach(route.value.snapshot)) this.detachAndStoreRouteSubtree(route, parentContexts);
		else this.deactivateRouteAndOutlet(route, parentContexts);
	}
	detachAndStoreRouteSubtree(route, parentContexts) {
		const context = parentContexts.getContext(route.value.outlet);
		const contexts = context && route.value.component ? context.children : parentContexts;
		const children = nodeChildrenAsMap(route);
		for (const treeNode of Object.values(children)) this.deactivateRouteAndItsChildren(treeNode, contexts);
		if (context && context.outlet) {
			const componentRef = context.outlet.detach();
			const contexts = context.children.onOutletDeactivated();
			this.routeReuseStrategy.store(route.value.snapshot, {
				componentRef,
				route,
				contexts
			});
		}
	}
	deactivateRouteAndOutlet(route, parentContexts) {
		var _route$value$_localIn;
		const context = parentContexts.getContext(route.value.outlet);
		const contexts = context && route.value.component ? context.children : parentContexts;
		const children = nodeChildrenAsMap(route);
		for (const treeNode of Object.values(children)) this.deactivateRouteAndItsChildren(treeNode, contexts);
		if (context) {
			if (context.outlet) {
				context.outlet.deactivate();
				context.children.onOutletDeactivated();
			}
			context.attachRef = null;
			context.route = null;
		}
		(_route$value$_localIn = route.value._localInjector) === null || _route$value$_localIn === void 0 || _route$value$_localIn.destroy();
	}
	activateChildRoutes(futureNode, currNode, contexts) {
		const children = nodeChildrenAsMap(currNode);
		futureNode.children.forEach((c) => {
			this.activateRoutes(c, children[c.value.outlet], contexts);
			this.forwardEvent(new ActivationEnd(c.value.snapshot));
		});
		if (futureNode.children.length) this.forwardEvent(new ChildActivationEnd(futureNode.value.snapshot));
	}
	activateRoutes(futureNode, currNode, parentContexts) {
		const future = futureNode.value;
		const curr = currNode ? currNode.value : null;
		advanceActivatedRoute(future);
		if (future === curr) if (future.component) {
			const context = parentContexts.getOrCreateContext(future.outlet);
			this.activateChildRoutes(futureNode, currNode, context.children);
		} else this.activateChildRoutes(futureNode, currNode, parentContexts);
		else if (future.component) {
			const context = parentContexts.getOrCreateContext(future.outlet);
			if (this.routeReuseStrategy.shouldAttach(future.snapshot)) {
				const stored = this.routeReuseStrategy.retrieve(future.snapshot);
				this.routeReuseStrategy.store(future.snapshot, null);
				context.children.onOutletReAttached(stored.contexts);
				context.attachRef = stored.componentRef;
				context.route = stored.route.value;
				if (context.outlet) context.outlet.attach(stored.componentRef, stored.route.value);
				advanceActivatedRoute(stored.route.value);
				this.activateChildRoutes(futureNode, null, context.children);
			} else {
				context.attachRef = null;
				context.route = future;
				if (context.outlet) context.outlet.activateWith(future, context.injector);
				this.activateChildRoutes(futureNode, null, context.children);
			}
		} else this.activateChildRoutes(futureNode, null, parentContexts);
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			const outlet = parentContexts.getOrCreateContext(future.outlet).outlet;
			if (outlet && this.inputBindingEnabled && !outlet.supportsBindingToComponentInputs && !warnedAboutUnsupportedInputBinding) {
				console.warn("'withComponentInputBinding' feature is enabled but this application is using an outlet that may not support binding to component inputs.");
				warnedAboutUnsupportedInputBinding = true;
			}
		}
	}
};
var CanActivate = class {
	constructor(path) {
		_defineProperty(this, "path", void 0);
		_defineProperty(this, "route", void 0);
		this.path = path;
		this.route = this.path[this.path.length - 1];
	}
};
var CanDeactivate = class {
	constructor(component, route) {
		_defineProperty(this, "component", void 0);
		_defineProperty(this, "route", void 0);
		this.component = component;
		this.route = route;
	}
};
function getAllRouteGuards(future, curr, parentContexts) {
	const futureRoot = future._root;
	return getChildRouteGuards(futureRoot, curr ? curr._root : null, parentContexts, [futureRoot.value]);
}
function getCanActivateChild(p) {
	const canActivateChild = p.routeConfig ? p.routeConfig.canActivateChild : null;
	if (!canActivateChild || canActivateChild.length === 0) return null;
	return {
		node: p,
		guards: canActivateChild
	};
}
function getTokenOrFunctionIdentity(tokenOrFunction, injector) {
	const NOT_FOUND = Symbol();
	const result = injector.get(tokenOrFunction, NOT_FOUND);
	if (result === NOT_FOUND) if (typeof tokenOrFunction === "function" && !isInjectable(tokenOrFunction)) return tokenOrFunction;
	else return injector.get(tokenOrFunction);
	return result;
}
function getChildRouteGuards(futureNode, currNode, contexts, futurePath, checks = {
	canDeactivateChecks: [],
	canActivateChecks: []
}) {
	const prevChildren = nodeChildrenAsMap(currNode);
	futureNode.children.forEach((c) => {
		getRouteGuards(c, prevChildren[c.value.outlet], contexts, futurePath.concat([c.value]), checks);
		delete prevChildren[c.value.outlet];
	});
	Object.entries(prevChildren).forEach(([k, v]) => deactivateRouteAndItsChildren(v, contexts.getContext(k), checks));
	return checks;
}
function getRouteGuards(futureNode, currNode, parentContexts, futurePath, checks = {
	canDeactivateChecks: [],
	canActivateChecks: []
}) {
	const future = futureNode.value;
	const curr = currNode ? currNode.value : null;
	const context = parentContexts ? parentContexts.getContext(futureNode.value.outlet) : null;
	if (curr && future.routeConfig === curr.routeConfig) {
		const shouldRun = shouldRunGuardsAndResolvers(curr, future, future.routeConfig.runGuardsAndResolvers);
		if (shouldRun) checks.canActivateChecks.push(new CanActivate(futurePath));
		else {
			future.data = curr.data;
			future._resolvedData = curr._resolvedData;
		}
		if (future.component) getChildRouteGuards(futureNode, currNode, context ? context.children : null, futurePath, checks);
		else getChildRouteGuards(futureNode, currNode, parentContexts, futurePath, checks);
		if (shouldRun && context && context.outlet && context.outlet.isActivated) checks.canDeactivateChecks.push(new CanDeactivate(context.outlet.component, curr));
	} else {
		if (curr) deactivateRouteAndItsChildren(currNode, context, checks);
		checks.canActivateChecks.push(new CanActivate(futurePath));
		if (future.component) getChildRouteGuards(futureNode, null, context ? context.children : null, futurePath, checks);
		else getChildRouteGuards(futureNode, null, parentContexts, futurePath, checks);
	}
	return checks;
}
function shouldRunGuardsAndResolvers(curr, future, mode) {
	if (typeof mode === "function") return runInInjectionContext(future._environmentInjector, () => mode(curr, future));
	switch (mode) {
		case "pathParamsChange": return !equalPath(curr.url, future.url);
		case "pathParamsOrQueryParamsChange": return !equalPath(curr.url, future.url) || !shallowEqual(curr.queryParams, future.queryParams);
		case "always": return true;
		case "paramsOrQueryParamsChange": return !equalParamsAndUrlSegments(curr, future) || !shallowEqual(curr.queryParams, future.queryParams);
		default: return !equalParamsAndUrlSegments(curr, future);
	}
}
function deactivateRouteAndItsChildren(route, context, checks) {
	const children = nodeChildrenAsMap(route);
	const r = route.value;
	Object.entries(children).forEach(([childName, node]) => {
		if (!r.component) deactivateRouteAndItsChildren(node, context, checks);
		else if (context) deactivateRouteAndItsChildren(node, context.children.getContext(childName), checks);
		else deactivateRouteAndItsChildren(node, null, checks);
	});
	if (!r.component) checks.canDeactivateChecks.push(new CanDeactivate(null, r));
	else if (context && context.outlet && context.outlet.isActivated) checks.canDeactivateChecks.push(new CanDeactivate(context.outlet.component, r));
	else checks.canDeactivateChecks.push(new CanDeactivate(null, r));
}
function isFunction(v) {
	return typeof v === "function";
}
function isBoolean(v) {
	return typeof v === "boolean";
}
function isCanLoad(guard) {
	return guard && isFunction(guard.canLoad);
}
function isCanActivate(guard) {
	return guard && isFunction(guard.canActivate);
}
function isCanActivateChild(guard) {
	return guard && isFunction(guard.canActivateChild);
}
function isCanDeactivate(guard) {
	return guard && isFunction(guard.canDeactivate);
}
function isCanMatch(guard) {
	return guard && isFunction(guard.canMatch);
}
function isEmptyError(e) {
	return e instanceof EmptyError || (e === null || e === void 0 ? void 0 : e.name) === "EmptyError";
}
var INITIAL_VALUE = /* @__PURE__ */ Symbol("INITIAL_VALUE");
function prioritizedGuardValue() {
	return switchMap((obs) => {
		return combineLatest(obs.map((o) => o.pipe(take(1), startWith(INITIAL_VALUE)))).pipe(map((results) => {
			for (const result of results) if (result === true) continue;
			else if (result === INITIAL_VALUE) return INITIAL_VALUE;
			else if (result === false || isRedirect(result)) return result;
			return true;
		}), filter((item) => item !== INITIAL_VALUE), take(1));
	});
}
function isRedirect(val) {
	return isUrlTree(val) || val instanceof RedirectCommand;
}
function abortSignalToObservable(signal) {
	if (signal.aborted) return of(void 0).pipe(take(1));
	return new Observable((subscriber) => {
		const handler = () => {
			subscriber.next();
			subscriber.complete();
		};
		signal.addEventListener("abort", handler);
		return () => signal.removeEventListener("abort", handler);
	});
}
function takeUntilAbort(signal) {
	return takeUntil(abortSignalToObservable(signal));
}
function checkGuards(forwardEvent) {
	return mergeMap((t) => {
		const { targetSnapshot, currentSnapshot, guards: { canActivateChecks, canDeactivateChecks } } = t;
		if (canDeactivateChecks.length === 0 && canActivateChecks.length === 0) return of(_objectSpread2(_objectSpread2({}, t), {}, { guardsResult: true }));
		return runCanDeactivateChecks(canDeactivateChecks, targetSnapshot, currentSnapshot).pipe(mergeMap((canDeactivate) => {
			return canDeactivate && isBoolean(canDeactivate) ? runCanActivateChecks(targetSnapshot, canActivateChecks, forwardEvent) : of(canDeactivate);
		}), map((guardsResult) => _objectSpread2(_objectSpread2({}, t), {}, { guardsResult })));
	});
}
function runCanDeactivateChecks(checks, futureRSS, currRSS) {
	return from(checks).pipe(mergeMap((check) => runCanDeactivate(check.component, check.route, currRSS, futureRSS)), first((result) => {
		return result !== true;
	}, true));
}
function runCanActivateChecks(futureSnapshot, checks, forwardEvent) {
	return from(checks).pipe(concatMap((check) => {
		return concat(fireChildActivationStart(check.route.parent, forwardEvent), fireActivationStart(check.route, forwardEvent), runCanActivateChild(futureSnapshot, check.path), runCanActivate(futureSnapshot, check.route));
	}), first((result) => {
		return result !== true;
	}, true));
}
function fireActivationStart(snapshot, forwardEvent) {
	if (snapshot !== null && forwardEvent) forwardEvent(new ActivationStart(snapshot));
	return of(true);
}
function fireChildActivationStart(snapshot, forwardEvent) {
	if (snapshot !== null && forwardEvent) forwardEvent(new ChildActivationStart(snapshot));
	return of(true);
}
function runCanActivate(futureRSS, futureARS) {
	const canActivate = futureARS.routeConfig ? futureARS.routeConfig.canActivate : null;
	if (!canActivate || canActivate.length === 0) return of(true);
	return of(canActivate.map((canActivate) => {
		return defer(() => {
			const closestInjector = futureARS._environmentInjector;
			const guard = getTokenOrFunctionIdentity(canActivate, closestInjector);
			return wrapIntoObservable(isCanActivate(guard) ? guard.canActivate(futureARS, futureRSS) : runInInjectionContext(closestInjector, () => guard(futureARS, futureRSS))).pipe(first());
		});
	})).pipe(prioritizedGuardValue());
}
function runCanActivateChild(futureRSS, path) {
	const futureARS = path[path.length - 1];
	return of(path.slice(0, path.length - 1).reverse().map((p) => getCanActivateChild(p)).filter((_) => _ !== null).map((d) => {
		return defer(() => {
			return of(d.guards.map((canActivateChild) => {
				const closestInjector = d.node._environmentInjector;
				const guard = getTokenOrFunctionIdentity(canActivateChild, closestInjector);
				return wrapIntoObservable(isCanActivateChild(guard) ? guard.canActivateChild(futureARS, futureRSS) : runInInjectionContext(closestInjector, () => guard(futureARS, futureRSS))).pipe(first());
			})).pipe(prioritizedGuardValue());
		});
	})).pipe(prioritizedGuardValue());
}
function runCanDeactivate(component, currARS, currRSS, futureRSS) {
	const canDeactivate = currARS && currARS.routeConfig ? currARS.routeConfig.canDeactivate : null;
	if (!canDeactivate || canDeactivate.length === 0) return of(true);
	return of(canDeactivate.map((c) => {
		const closestInjector = currARS._environmentInjector;
		const guard = getTokenOrFunctionIdentity(c, closestInjector);
		return wrapIntoObservable(isCanDeactivate(guard) ? guard.canDeactivate(component, currARS, currRSS, futureRSS) : runInInjectionContext(closestInjector, () => guard(component, currARS, currRSS, futureRSS))).pipe(first());
	})).pipe(prioritizedGuardValue());
}
function runCanLoadGuards(injector, route, segments, urlSerializer, abortSignal) {
	const canLoad = route.canLoad;
	if (canLoad === void 0 || canLoad.length === 0) return of(true);
	return of(canLoad.map((injectionToken) => {
		const guard = getTokenOrFunctionIdentity(injectionToken, injector);
		const obs$ = wrapIntoObservable(isCanLoad(guard) ? guard.canLoad(route, segments) : runInInjectionContext(injector, () => guard(route, segments)));
		return abortSignal ? obs$.pipe(takeUntilAbort(abortSignal)) : obs$;
	})).pipe(prioritizedGuardValue(), redirectIfUrlTree(urlSerializer));
}
function redirectIfUrlTree(urlSerializer) {
	return pipe(tap((result) => {
		if (typeof result === "boolean") return;
		throw redirectingNavigationError(urlSerializer, result);
	}), map((result) => result === true));
}
function runCanMatchGuards(injector, route, segments, urlSerializer, currentSnapshot, abortSignal) {
	const canMatch = route.canMatch;
	if (!canMatch || canMatch.length === 0) return of(true);
	return of(canMatch.map((injectionToken) => {
		const guard = getTokenOrFunctionIdentity(injectionToken, injector);
		return wrapIntoObservable(isCanMatch(guard) ? guard.canMatch(route, segments, currentSnapshot) : runInInjectionContext(injector, () => guard(route, segments, currentSnapshot))).pipe(takeUntilAbort(abortSignal));
	})).pipe(prioritizedGuardValue(), redirectIfUrlTree(urlSerializer));
}
var NoMatch = class NoMatch extends Error {
	constructor(segmentGroup) {
		super();
		_defineProperty(this, "segmentGroup", void 0);
		this.segmentGroup = segmentGroup || null;
		Object.setPrototypeOf(this, NoMatch.prototype);
	}
};
var AbsoluteRedirect = class AbsoluteRedirect extends Error {
	constructor(urlTree) {
		super();
		_defineProperty(this, "urlTree", void 0);
		this.urlTree = urlTree;
		Object.setPrototypeOf(this, AbsoluteRedirect.prototype);
	}
};
function namedOutletsRedirect(redirectTo) {
	throw new RuntimeError(4e3, (typeof ngDevMode === "undefined" || ngDevMode) && `Only absolute redirects can have named outlets. redirectTo: '${redirectTo}'`);
}
function canLoadFails(route) {
	throw navigationCancelingError((typeof ngDevMode === "undefined" || ngDevMode) && `Cannot load children because the guard of the route "path: '${route.path}'" returned false`, NavigationCancellationCode.GuardRejected);
}
var ApplyRedirects = class {
	constructor(urlSerializer, urlTree) {
		_defineProperty(this, "urlSerializer", void 0);
		_defineProperty(this, "urlTree", void 0);
		this.urlSerializer = urlSerializer;
		this.urlTree = urlTree;
	}
	lineralizeSegments(route, urlTree) {
		return _asyncToGenerator(function* () {
			let res = [];
			let c = urlTree.root;
			while (true) {
				res = res.concat(c.segments);
				if (c.numberOfChildren === 0) return res;
				if (c.numberOfChildren > 1 || !c.children["primary"]) throw namedOutletsRedirect(`${route.redirectTo}`);
				c = c.children[PRIMARY_OUTLET];
			}
		})();
	}
	applyRedirectCommands(segments, redirectTo, posParams, currentSnapshot, injector) {
		var _this = this;
		return _asyncToGenerator(function* () {
			const redirect = yield getRedirectResult(redirectTo, currentSnapshot, injector);
			if (redirect instanceof UrlTree) throw new AbsoluteRedirect(redirect);
			const newTree = _this.applyRedirectCreateUrlTree(redirect, _this.urlSerializer.parse(redirect), segments, posParams);
			if (redirect[0] === "/") throw new AbsoluteRedirect(newTree);
			return newTree;
		})();
	}
	applyRedirectCreateUrlTree(redirectTo, urlTree, segments, posParams) {
		return new UrlTree(this.createSegmentGroup(redirectTo, urlTree.root, segments, posParams), this.createQueryParams(urlTree.queryParams, this.urlTree.queryParams), urlTree.fragment);
	}
	createQueryParams(redirectToParams, actualParams) {
		const res = {};
		Object.entries(redirectToParams).forEach(([k, v]) => {
			if (typeof v === "string" && v[0] === ":") {
				const sourceName = v.substring(1);
				res[k] = actualParams[sourceName];
			} else res[k] = v;
		});
		return res;
	}
	createSegmentGroup(redirectTo, group, segments, posParams) {
		const updatedSegments = this.createSegments(redirectTo, group.segments, segments, posParams);
		let children = Object.create(null);
		Object.entries(group.children).forEach(([name, child]) => {
			children[name] = this.createSegmentGroup(redirectTo, child, segments, posParams);
		});
		return new UrlSegmentGroup(updatedSegments, children);
	}
	createSegments(redirectTo, redirectToSegments, actualSegments, posParams) {
		return redirectToSegments.map((s) => s.path[0] === ":" ? this.findPosParam(redirectTo, s, posParams) : this.findOrReturn(s, actualSegments));
	}
	findPosParam(redirectTo, redirectToUrlSegment, posParams) {
		const pos = posParams[redirectToUrlSegment.path.substring(1)];
		if (!pos) throw new RuntimeError(4001, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot redirect to '${redirectTo}'. Cannot find '${redirectToUrlSegment.path}'.`);
		return pos;
	}
	findOrReturn(redirectToUrlSegment, actualSegments) {
		let idx = 0;
		for (const s of actualSegments) {
			if (s.path === redirectToUrlSegment.path) {
				actualSegments.splice(idx);
				return s;
			}
			idx++;
		}
		return redirectToUrlSegment;
	}
};
function getRedirectResult(redirectTo, currentSnapshot, injector) {
	if (typeof redirectTo === "string") return Promise.resolve(redirectTo);
	const redirectToFn = redirectTo;
	return firstValueFrom(wrapIntoObservable(runInInjectionContext(injector, () => redirectToFn(currentSnapshot))));
}
function getOrCreateRouteInjectorIfNeeded(route, currentInjector) {
	var _route$_injector;
	if (route.providers && !route._injector) route._injector = createEnvironmentInjector(route.providers, currentInjector, `Route: ${route.path}`);
	return (_route$_injector = route._injector) !== null && _route$_injector !== void 0 ? _route$_injector : currentInjector;
}
function validateConfig(config, parentPath = "", requireStandaloneComponents = false) {
	for (let i = 0; i < config.length; i++) {
		const route = config[i];
		validateNode(route, getFullPath(parentPath, route), requireStandaloneComponents);
	}
}
function assertStandalone(fullPath, component) {
	if (component && isNgModule(component)) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}'. You are using 'loadComponent' with a module, but it must be used with standalone components. Use 'loadChildren' instead.`);
	else if (component && !isStandalone(component)) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}'. The component must be standalone.`);
}
function validateNode(route, fullPath, requireStandaloneComponents) {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		if (!route) throw new RuntimeError(4014, `
      Invalid configuration of route '${fullPath}': Encountered undefined route.
      The reason might be an extra comma.

      Example:
      const routes: Routes = [
        { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
        { path: 'dashboard',  component: DashboardComponent },, << two commas
        { path: 'detail/:id', component: HeroDetailComponent }
      ];
    `);
		if (Array.isArray(route)) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': Array cannot be specified`);
		if (!route.redirectTo && !route.component && !route.loadComponent && !route.children && !route.loadChildren && route.outlet && route.outlet !== "primary") throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': a componentless route without children or loadChildren cannot have a named outlet set`);
		if (route.redirectTo && route.children) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and children cannot be used together`);
		if (route.redirectTo && route.loadChildren) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and loadChildren cannot be used together`);
		if (route.children && route.loadChildren) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': children and loadChildren cannot be used together`);
		if (route.component && route.loadComponent) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': component and loadComponent cannot be used together`);
		if (route.redirectTo) {
			if (route.component || route.loadComponent) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and component/loadComponent cannot be used together`);
			if (route.canMatch || route.canActivate) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and ${route.canMatch ? "canMatch" : "canActivate"} cannot be used together.Redirects happen before guards are executed.`);
		}
		if (route.path && route.matcher) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': path and matcher cannot be used together`);
		if (route.redirectTo === void 0 && !route.component && !route.loadComponent && !route.children && !route.loadChildren) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}'. One of the following must be provided: component, loadComponent, redirectTo, children or loadChildren`);
		if (route.path === void 0 && route.matcher === void 0) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': routes must have either a path or a matcher specified`);
		if (typeof route.path === "string" && route.path.charAt(0) === "/") throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': path cannot start with a slash`);
		if (route.path === "" && route.redirectTo !== void 0 && route.pathMatch === void 0) throw new RuntimeError(4014, `Invalid configuration of route '{path: "${fullPath}", redirectTo: "${route.redirectTo}"}': please provide 'pathMatch'. The default value of 'pathMatch' is 'prefix', but often the intent is to use 'full'.`);
		if (requireStandaloneComponents) assertStandalone(fullPath, route.component);
	}
	if (route.children) validateConfig(route.children, fullPath, requireStandaloneComponents);
}
function getFullPath(parentPath, currentRoute) {
	if (!currentRoute) return parentPath;
	if (!parentPath && !currentRoute.path) return "";
	else if (parentPath && !currentRoute.path) return `${parentPath}/`;
	else if (!parentPath && currentRoute.path) return currentRoute.path;
	else return `${parentPath}/${currentRoute.path}`;
}
function getOutlet(route) {
	return route.outlet || "primary";
}
function sortByMatchingOutlets(routes, outletName) {
	const sortedConfig = routes.filter((r) => getOutlet(r) === outletName);
	sortedConfig.push(...routes.filter((r) => getOutlet(r) !== outletName));
	return sortedConfig;
}
var noMatch = {
	matched: false,
	consumedSegments: [],
	remainingSegments: [],
	parameters: {},
	positionalParamSegments: {}
};
function createPreMatchRouteSnapshot(snapshot) {
	return {
		routeConfig: snapshot.routeConfig,
		url: snapshot.url,
		params: snapshot.params,
		queryParams: snapshot.queryParams,
		fragment: snapshot.fragment,
		data: snapshot.data,
		outlet: snapshot.outlet,
		title: snapshot.title,
		paramMap: snapshot.paramMap,
		queryParamMap: snapshot.queryParamMap
	};
}
function matchWithChecks(segmentGroup, route, segments, injector, urlSerializer, createSnapshot, abortSignal) {
	const result = match(segmentGroup, route, segments);
	if (!result.matched) return of(result);
	const currentSnapshot = createPreMatchRouteSnapshot(createSnapshot(result));
	injector = getOrCreateRouteInjectorIfNeeded(route, injector);
	return runCanMatchGuards(injector, route, segments, urlSerializer, currentSnapshot, abortSignal).pipe(map((v) => v === true ? result : _objectSpread2({}, noMatch)));
}
function match(segmentGroup, route, segments) {
	var _res$posParams, _res$posParams2;
	if (route.path === "") {
		if (route.pathMatch === "full" && (segmentGroup.hasChildren() || segments.length > 0)) return _objectSpread2({}, noMatch);
		return {
			matched: true,
			consumedSegments: [],
			remainingSegments: segments,
			parameters: {},
			positionalParamSegments: {}
		};
	}
	const res = (route.matcher || defaultUrlMatcher)(segments, segmentGroup, route);
	if (!res) return _objectSpread2({}, noMatch);
	const posParams = {};
	Object.entries((_res$posParams = res.posParams) !== null && _res$posParams !== void 0 ? _res$posParams : {}).forEach(([k, v]) => {
		posParams[k] = v.path;
	});
	const parameters = res.consumed.length > 0 ? _objectSpread2(_objectSpread2({}, posParams), res.consumed[res.consumed.length - 1].parameters) : posParams;
	return {
		matched: true,
		consumedSegments: res.consumed,
		remainingSegments: segments.slice(res.consumed.length),
		parameters,
		positionalParamSegments: (_res$posParams2 = res.posParams) !== null && _res$posParams2 !== void 0 ? _res$posParams2 : {}
	};
}
function split(segmentGroup, consumedSegments, slicedSegments, config, outlet) {
	if (slicedSegments.length > 0 && containsEmptyPathMatchesWithNamedOutlets(segmentGroup, slicedSegments, config, outlet)) return {
		segmentGroup: new UrlSegmentGroup(consumedSegments, createChildrenForEmptyPaths(config, new UrlSegmentGroup(slicedSegments, segmentGroup.children))),
		slicedSegments: []
	};
	if (slicedSegments.length === 0 && containsEmptyPathMatches(segmentGroup, slicedSegments, config)) return {
		segmentGroup: new UrlSegmentGroup(segmentGroup.segments, addEmptyPathsToChildrenIfNeeded(segmentGroup, slicedSegments, config, segmentGroup.children)),
		slicedSegments
	};
	return {
		segmentGroup: new UrlSegmentGroup(segmentGroup.segments, segmentGroup.children),
		slicedSegments
	};
}
function addEmptyPathsToChildrenIfNeeded(segmentGroup, slicedSegments, routes, children) {
	const res = {};
	for (const r of routes) if (emptyPathMatch(segmentGroup, slicedSegments, r) && !children[getOutlet(r)]) {
		const s = new UrlSegmentGroup([], {});
		res[getOutlet(r)] = s;
	}
	return _objectSpread2(_objectSpread2({}, children), res);
}
function createChildrenForEmptyPaths(routes, primarySegment) {
	const res = {};
	res[PRIMARY_OUTLET] = primarySegment;
	for (const r of routes) if (r.path === "" && getOutlet(r) !== "primary") {
		const s = new UrlSegmentGroup([], {});
		res[getOutlet(r)] = s;
	}
	return res;
}
function containsEmptyPathMatchesWithNamedOutlets(segmentGroup, slicedSegments, routes, outlet) {
	return routes.some((r) => {
		if (!emptyPathMatch(segmentGroup, slicedSegments, r)) return false;
		if (!(getOutlet(r) !== "primary")) return false;
		return !(outlet !== void 0 && getOutlet(r) === outlet);
	});
}
function containsEmptyPathMatches(segmentGroup, slicedSegments, routes) {
	return routes.some((r) => emptyPathMatch(segmentGroup, slicedSegments, r));
}
function emptyPathMatch(segmentGroup, slicedSegments, r) {
	if ((segmentGroup.hasChildren() || slicedSegments.length > 0) && r.pathMatch === "full") return false;
	return r.path === "";
}
function noLeftoversInUrl(segmentGroup, segments, outlet) {
	return segments.length === 0 && !segmentGroup.children[outlet];
}
var NoLeftoversInUrl = class {};
function recognize$1(_x, _x2, _x3, _x4, _x5, _x6, _x7, _x8) {
	return _recognize$.apply(this, arguments);
}
function _recognize$() {
	_recognize$ = _asyncToGenerator(function* (injector, configLoader, rootComponentType, config, urlTree, urlSerializer, paramsInheritanceStrategy, abortSignal) {
		return new Recognizer(injector, configLoader, rootComponentType, config, urlTree, paramsInheritanceStrategy, urlSerializer, abortSignal).recognize();
	});
	return _recognize$.apply(this, arguments);
}
var MAX_ALLOWED_REDIRECTS = 31;
var Recognizer = class {
	constructor(injector, configLoader, rootComponentType, config, urlTree, paramsInheritanceStrategy, urlSerializer, abortSignal) {
		_defineProperty(this, "injector", void 0);
		_defineProperty(this, "configLoader", void 0);
		_defineProperty(this, "rootComponentType", void 0);
		_defineProperty(this, "config", void 0);
		_defineProperty(this, "urlTree", void 0);
		_defineProperty(this, "paramsInheritanceStrategy", void 0);
		_defineProperty(this, "urlSerializer", void 0);
		_defineProperty(this, "abortSignal", void 0);
		_defineProperty(this, "applyRedirects", void 0);
		_defineProperty(this, "absoluteRedirectCount", 0);
		_defineProperty(this, "allowRedirects", true);
		this.injector = injector;
		this.configLoader = configLoader;
		this.rootComponentType = rootComponentType;
		this.config = config;
		this.urlTree = urlTree;
		this.paramsInheritanceStrategy = paramsInheritanceStrategy;
		this.urlSerializer = urlSerializer;
		this.abortSignal = abortSignal;
		this.applyRedirects = new ApplyRedirects(this.urlSerializer, this.urlTree);
	}
	noMatchError(e) {
		return new RuntimeError(4002, typeof ngDevMode === "undefined" || ngDevMode ? `Cannot match any routes. URL Segment: '${e.segmentGroup}'` : `'${e.segmentGroup}'`);
	}
	recognize() {
		var _this2 = this;
		return _asyncToGenerator(function* () {
			const rootSegmentGroup = split(_this2.urlTree.root, [], [], _this2.config).segmentGroup;
			const { children, rootSnapshot } = yield _this2.match(rootSegmentGroup);
			const routeState = new RouterStateSnapshot("", new TreeNode(rootSnapshot, children));
			const tree = createUrlTreeFromSnapshot(rootSnapshot, [], _this2.urlTree.queryParams, _this2.urlTree.fragment);
			tree.queryParams = _this2.urlTree.queryParams;
			routeState.url = _this2.urlSerializer.serialize(tree);
			return {
				state: routeState,
				tree
			};
		})();
	}
	match(rootSegmentGroup) {
		var _this3 = this;
		return _asyncToGenerator(function* () {
			const rootSnapshot = new ActivatedRouteSnapshot([], Object.freeze({}), Object.freeze(_objectSpread2({}, _this3.urlTree.queryParams)), _this3.urlTree.fragment, Object.freeze({}), PRIMARY_OUTLET, _this3.rootComponentType, null, {}, _this3.injector);
			try {
				return {
					children: yield _this3.processSegmentGroup(_this3.injector, _this3.config, rootSegmentGroup, PRIMARY_OUTLET, rootSnapshot),
					rootSnapshot
				};
			} catch (e) {
				if (e instanceof AbsoluteRedirect) {
					_this3.urlTree = e.urlTree;
					return _this3.match(e.urlTree.root);
				}
				if (e instanceof NoMatch) throw _this3.noMatchError(e);
				throw e;
			}
		})();
	}
	processSegmentGroup(injector, config, segmentGroup, outlet, parentRoute) {
		var _this4 = this;
		return _asyncToGenerator(function* () {
			if (segmentGroup.segments.length === 0 && segmentGroup.hasChildren()) return _this4.processChildren(injector, config, segmentGroup, parentRoute);
			const child = yield _this4.processSegment(injector, config, segmentGroup, segmentGroup.segments, outlet, true, parentRoute);
			return child instanceof TreeNode ? [child] : [];
		})();
	}
	processChildren(injector, config, segmentGroup, parentRoute) {
		var _this5 = this;
		return _asyncToGenerator(function* () {
			const childOutlets = [];
			for (const child of Object.keys(segmentGroup.children)) if (child === "primary") childOutlets.unshift(child);
			else childOutlets.push(child);
			let children = [];
			for (const childOutlet of childOutlets) {
				const child = segmentGroup.children[childOutlet];
				const sortedConfig = sortByMatchingOutlets(config, childOutlet);
				const outletChildren = yield _this5.processSegmentGroup(injector, sortedConfig, child, childOutlet, parentRoute);
				children.push(...outletChildren);
			}
			const mergedChildren = mergeEmptyPathMatches(children);
			if (typeof ngDevMode === "undefined" || ngDevMode) checkOutletNameUniqueness(mergedChildren);
			sortActivatedRouteSnapshots(mergedChildren);
			return mergedChildren;
		})();
	}
	processSegment(injector, routes, segmentGroup, segments, outlet, allowRedirects, parentRoute) {
		var _this6 = this;
		return _asyncToGenerator(function* () {
			for (const r of routes) try {
				var _r$_injector;
				return yield _this6.processSegmentAgainstRoute((_r$_injector = r._injector) !== null && _r$_injector !== void 0 ? _r$_injector : injector, routes, r, segmentGroup, segments, outlet, allowRedirects, parentRoute);
			} catch (e) {
				if (e instanceof NoMatch || isEmptyError(e)) continue;
				throw e;
			}
			if (noLeftoversInUrl(segmentGroup, segments, outlet)) return new NoLeftoversInUrl();
			throw new NoMatch(segmentGroup);
		})();
	}
	processSegmentAgainstRoute(injector, routes, route, rawSegment, segments, outlet, allowRedirects, parentRoute) {
		var _this7 = this;
		return _asyncToGenerator(function* () {
			if (getOutlet(route) !== outlet && (outlet === "primary" || !emptyPathMatch(rawSegment, segments, route))) throw new NoMatch(rawSegment);
			if (route.redirectTo === void 0) return _this7.matchSegmentAgainstRoute(injector, rawSegment, route, segments, outlet, parentRoute);
			if (_this7.allowRedirects && allowRedirects) return _this7.expandSegmentAgainstRouteUsingRedirect(injector, rawSegment, routes, route, segments, outlet, parentRoute);
			throw new NoMatch(rawSegment);
		})();
	}
	expandSegmentAgainstRouteUsingRedirect(injector, segmentGroup, routes, route, segments, outlet, parentRoute) {
		var _this8 = this;
		return _asyncToGenerator(function* () {
			const { matched, parameters, consumedSegments, positionalParamSegments, remainingSegments } = match(segmentGroup, route, segments);
			if (!matched) throw new NoMatch(segmentGroup);
			if (typeof route.redirectTo === "string" && route.redirectTo[0] === "/") {
				_this8.absoluteRedirectCount++;
				if (_this8.absoluteRedirectCount > MAX_ALLOWED_REDIRECTS) {
					if (ngDevMode) throw new RuntimeError(4016, `Detected possible infinite redirect when redirecting from '${_this8.urlTree}' to '${route.redirectTo}'.\nThis is currently a dev mode only error but will become a call stack size exceeded error in production in a future major version.`);
					_this8.allowRedirects = false;
				}
			}
			const currentSnapshot = _this8.createSnapshot(injector, route, segments, parameters, parentRoute);
			if (_this8.abortSignal.aborted) throw new Error(_this8.abortSignal.reason);
			const newTree = yield _this8.applyRedirects.applyRedirectCommands(consumedSegments, route.redirectTo, positionalParamSegments, createPreMatchRouteSnapshot(currentSnapshot), injector);
			const newSegments = yield _this8.applyRedirects.lineralizeSegments(route, newTree);
			return _this8.processSegment(injector, routes, segmentGroup, newSegments.concat(remainingSegments), outlet, false, parentRoute);
		})();
	}
	createSnapshot(injector, route, segments, parameters, parentRoute) {
		var _ref, _route$component;
		const snapshot = new ActivatedRouteSnapshot(segments, parameters, Object.freeze(_objectSpread2({}, this.urlTree.queryParams)), this.urlTree.fragment, getData(route), getOutlet(route), (_ref = (_route$component = route.component) !== null && _route$component !== void 0 ? _route$component : route._loadedComponent) !== null && _ref !== void 0 ? _ref : null, route, getResolve(route), injector);
		const inherited = getInherited(snapshot, parentRoute, this.paramsInheritanceStrategy);
		snapshot.params = Object.freeze(inherited.params);
		snapshot.data = Object.freeze(inherited.data);
		return snapshot;
	}
	matchSegmentAgainstRoute(injector, rawSegment, route, segments, outlet, parentRoute) {
		var _this9 = this;
		return _asyncToGenerator(function* () {
			var _route$_injector2, _route$_loadedInjecto;
			if (_this9.abortSignal.aborted) throw new Error(_this9.abortSignal.reason);
			const createSnapshot = (result) => _this9.createSnapshot(injector, route, result.consumedSegments, result.parameters, parentRoute);
			const result = yield firstValueFrom(matchWithChecks(rawSegment, route, segments, injector, _this9.urlSerializer, createSnapshot, _this9.abortSignal));
			if (route.path === "**") rawSegment.children = {};
			if (!(result === null || result === void 0 ? void 0 : result.matched)) throw new NoMatch(rawSegment);
			injector = (_route$_injector2 = route._injector) !== null && _route$_injector2 !== void 0 ? _route$_injector2 : injector;
			const { routes: childConfig } = yield _this9.getChildConfig(injector, route, segments);
			const childInjector = (_route$_loadedInjecto = route._loadedInjector) !== null && _route$_loadedInjecto !== void 0 ? _route$_loadedInjecto : injector;
			const { parameters, consumedSegments, remainingSegments } = result;
			const snapshot = _this9.createSnapshot(injector, route, consumedSegments, parameters, parentRoute);
			const { segmentGroup, slicedSegments } = split(rawSegment, consumedSegments, remainingSegments, childConfig, outlet);
			if (slicedSegments.length === 0 && segmentGroup.hasChildren()) return new TreeNode(snapshot, yield _this9.processChildren(childInjector, childConfig, segmentGroup, snapshot));
			if (childConfig.length === 0 && slicedSegments.length === 0) return new TreeNode(snapshot, []);
			const matchedOnOutlet = getOutlet(route) === outlet;
			const child = yield _this9.processSegment(childInjector, childConfig, segmentGroup, slicedSegments, matchedOnOutlet ? PRIMARY_OUTLET : outlet, true, snapshot);
			return new TreeNode(snapshot, child instanceof TreeNode ? [child] : []);
		})();
	}
	getChildConfig(injector, route, segments) {
		var _this10 = this;
		return _asyncToGenerator(function* () {
			if (route.children) return {
				routes: route.children,
				injector
			};
			if (route.loadChildren) {
				if (route._loadedRoutes !== void 0) {
					const ngModuleFactory = route._loadedNgModuleFactory;
					if (ngModuleFactory && !route._loadedInjector) route._loadedInjector = ngModuleFactory.create(injector).injector;
					return {
						routes: route._loadedRoutes,
						injector: route._loadedInjector
					};
				}
				if (_this10.abortSignal.aborted) throw new Error(_this10.abortSignal.reason);
				if (yield firstValueFrom(runCanLoadGuards(injector, route, segments, _this10.urlSerializer, _this10.abortSignal))) {
					const cfg = yield _this10.configLoader.loadChildren(injector, route);
					route._loadedRoutes = cfg.routes;
					route._loadedInjector = cfg.injector;
					route._loadedNgModuleFactory = cfg.factory;
					return cfg;
				}
				throw canLoadFails(route);
			}
			return {
				routes: [],
				injector
			};
		})();
	}
};
function sortActivatedRouteSnapshots(nodes) {
	nodes.sort((a, b) => {
		if (a.value.outlet === "primary") return -1;
		if (b.value.outlet === "primary") return 1;
		return a.value.outlet.localeCompare(b.value.outlet);
	});
}
function hasEmptyPathConfig(node) {
	const config = node.value.routeConfig;
	return config && config.path === "";
}
function mergeEmptyPathMatches(nodes) {
	const result = [];
	const mergedNodes = /* @__PURE__ */ new Set();
	for (const node of nodes) {
		if (!hasEmptyPathConfig(node)) {
			result.push(node);
			continue;
		}
		const duplicateEmptyPathNode = result.find((resultNode) => node.value.routeConfig === resultNode.value.routeConfig);
		if (duplicateEmptyPathNode !== void 0) {
			duplicateEmptyPathNode.children.push(...node.children);
			mergedNodes.add(duplicateEmptyPathNode);
		} else result.push(node);
	}
	for (const mergedNode of mergedNodes) {
		const mergedChildren = mergeEmptyPathMatches(mergedNode.children);
		result.push(new TreeNode(mergedNode.value, mergedChildren));
	}
	return result.filter((n) => !mergedNodes.has(n));
}
function checkOutletNameUniqueness(nodes) {
	const names = {};
	nodes.forEach((n) => {
		const routeWithSameOutletName = names[n.value.outlet];
		if (routeWithSameOutletName) {
			const p = routeWithSameOutletName.url.map((s) => s.toString()).join("/");
			const c = n.value.url.map((s) => s.toString()).join("/");
			throw new RuntimeError(4006, (typeof ngDevMode === "undefined" || ngDevMode) && `Two segments cannot have the same outlet name: '${p}' and '${c}'.`);
		}
		names[n.value.outlet] = n.value;
	});
}
function getData(route) {
	return route.data || {};
}
function getResolve(route) {
	return route.resolve || {};
}
function recognize(injector, configLoader, rootComponentType, config, serializer, paramsInheritanceStrategy, abortSignal) {
	return mergeMap(function() {
		var _ref2 = _asyncToGenerator(function* (t) {
			const { state: targetSnapshot, tree: urlAfterRedirects } = yield recognize$1(injector, configLoader, rootComponentType, config, t.extractedUrl, serializer, paramsInheritanceStrategy, abortSignal);
			return _objectSpread2(_objectSpread2({}, t), {}, {
				targetSnapshot,
				urlAfterRedirects
			});
		});
		return function(_x9) {
			return _ref2.apply(this, arguments);
		};
	}());
}
function resolveData(paramsInheritanceStrategy) {
	return mergeMap((t) => {
		const { targetSnapshot, guards: { canActivateChecks } } = t;
		if (!canActivateChecks.length) return of(t);
		const routesWithResolversToRun = new Set(canActivateChecks.map((check) => check.route));
		const routesNeedingDataUpdates = /* @__PURE__ */ new Set();
		for (const route of routesWithResolversToRun) {
			if (routesNeedingDataUpdates.has(route)) continue;
			for (const newRoute of flattenRouteTree(route)) routesNeedingDataUpdates.add(newRoute);
		}
		let routesProcessed = 0;
		return from(routesNeedingDataUpdates).pipe(concatMap((route) => {
			if (routesWithResolversToRun.has(route)) return runResolve(route, targetSnapshot, paramsInheritanceStrategy);
			else {
				route.data = getInherited(route, route.parent, paramsInheritanceStrategy).resolve;
				return of(void 0);
			}
		}), tap(() => routesProcessed++), takeLast(1), mergeMap((_) => routesProcessed === routesNeedingDataUpdates.size ? of(t) : EMPTY));
	});
}
function flattenRouteTree(route) {
	return [route, ...route.children.map((child) => flattenRouteTree(child)).flat()];
}
function runResolve(futureARS, futureRSS, paramsInheritanceStrategy) {
	const config = futureARS.routeConfig;
	const resolve = futureARS._resolve;
	if ((config === null || config === void 0 ? void 0 : config.title) !== void 0 && !hasStaticTitle(config)) resolve[RouteTitleKey] = config.title;
	return defer(() => {
		futureARS.data = getInherited(futureARS, futureARS.parent, paramsInheritanceStrategy).resolve;
		return resolveNode(resolve, futureARS, futureRSS).pipe(map((resolvedData) => {
			futureARS._resolvedData = resolvedData;
			futureARS.data = _objectSpread2(_objectSpread2({}, futureARS.data), resolvedData);
			return null;
		}));
	});
}
function resolveNode(resolve, futureARS, futureRSS) {
	const keys = getDataKeys(resolve);
	if (keys.length === 0) return of({});
	const data = {};
	return from(keys).pipe(mergeMap((key) => getResolver(resolve[key], futureARS, futureRSS).pipe(first(), tap((value) => {
		if (value instanceof RedirectCommand) throw redirectingNavigationError(new DefaultUrlSerializer(), value);
		data[key] = value;
	}))), takeLast(1), map(() => data), catchError((e) => isEmptyError(e) ? EMPTY : throwError(e)));
}
function getResolver(injectionToken, futureARS, futureRSS) {
	const closestInjector = futureARS._environmentInjector;
	const resolver = getTokenOrFunctionIdentity(injectionToken, closestInjector);
	return wrapIntoObservable(resolver.resolve ? resolver.resolve(futureARS, futureRSS) : runInInjectionContext(closestInjector, () => resolver(futureARS, futureRSS)));
}
function switchTap(next) {
	return switchMap((v) => {
		const nextResult = next(v);
		if (nextResult) return from(nextResult).pipe(map(() => v));
		return of(v);
	});
}
var TitleStrategy = class {
	buildTitle(snapshot) {
		let pageTitle;
		let route = snapshot.root;
		while (route !== void 0) {
			var _this$getResolvedTitl;
			pageTitle = (_this$getResolvedTitl = this.getResolvedTitleForRoute(route)) !== null && _this$getResolvedTitl !== void 0 ? _this$getResolvedTitl : pageTitle;
			route = route.children.find((child) => child.outlet === PRIMARY_OUTLET);
		}
		return pageTitle;
	}
	getResolvedTitleForRoute(snapshot) {
		return snapshot.data[RouteTitleKey];
	}
};
_TitleStrategy = TitleStrategy;
_defineProperty(TitleStrategy, "ɵfac", function TitleStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _TitleStrategy)();
});
_defineProperty(TitleStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _TitleStrategy,
	factory: () => (() => inject(DefaultTitleStrategy))()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TitleStrategy, [{
		type: Service,
		args: [{ factory: () => inject(DefaultTitleStrategy) }]
	}], null, null);
})();
var DefaultTitleStrategy = class extends TitleStrategy {
	constructor(title) {
		super();
		_defineProperty(this, "title", void 0);
		this.title = title;
	}
	updateTitle(snapshot) {
		const title = this.buildTitle(snapshot);
		if (title !== void 0) this.title.setTitle(title);
	}
};
_DefaultTitleStrategy = DefaultTitleStrategy;
_defineProperty(DefaultTitleStrategy, "ɵfac", function DefaultTitleStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DefaultTitleStrategy)(ɵɵinject(Title));
});
_defineProperty(DefaultTitleStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _DefaultTitleStrategy,
	factory: _DefaultTitleStrategy.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultTitleStrategy, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: Title }], null);
})();
var ROUTER_CONFIGURATION = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "router config" : "", { factory: () => ({}) });
var ROUTES = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ROUTES" : "");
var RouterConfigLoader = class {
	constructor() {
		_defineProperty(this, "componentLoaders", /* @__PURE__ */ new WeakMap());
		_defineProperty(this, "childrenLoaders", /* @__PURE__ */ new WeakMap());
		_defineProperty(this, "onLoadStartListener", void 0);
		_defineProperty(this, "onLoadEndListener", void 0);
		_defineProperty(this, "compiler", inject(Compiler));
	}
	loadComponent(injector, route) {
		var _this11 = this;
		return _asyncToGenerator(function* () {
			if (_this11.componentLoaders.get(route)) return _this11.componentLoaders.get(route);
			else if (route._loadedComponent) return Promise.resolve(route._loadedComponent);
			if (_this11.onLoadStartListener) _this11.onLoadStartListener(route);
			const loader = _asyncToGenerator(function* () {
				try {
					var _route$path;
					const component = yield maybeResolveResources(maybeUnwrapDefaultExport(yield wrapIntoPromise(runInInjectionContext(injector, () => route.loadComponent()))));
					if (_this11.onLoadEndListener) _this11.onLoadEndListener(route);
					(typeof ngDevMode === "undefined" || ngDevMode) && assertStandalone((_route$path = route.path) !== null && _route$path !== void 0 ? _route$path : "", component);
					route._loadedComponent = component;
					return component;
				} finally {
					_this11.componentLoaders.delete(route);
				}
			})();
			_this11.componentLoaders.set(route, loader);
			return loader;
		})();
	}
	loadChildren(parentInjector, route) {
		var _this12 = this;
		if (this.childrenLoaders.get(route)) return this.childrenLoaders.get(route);
		else if (route._loadedRoutes) return Promise.resolve({
			routes: route._loadedRoutes,
			injector: route._loadedInjector
		});
		if (this.onLoadStartListener) this.onLoadStartListener(route);
		const loader = _asyncToGenerator(function* () {
			try {
				const result = yield loadChildren(route, _this12.compiler, parentInjector, _this12.onLoadEndListener);
				route._loadedRoutes = result.routes;
				route._loadedInjector = result.injector;
				route._loadedNgModuleFactory = result.factory;
				return result;
			} finally {
				_this12.childrenLoaders.delete(route);
			}
		})();
		this.childrenLoaders.set(route, loader);
		return loader;
	}
};
_RouterConfigLoader = RouterConfigLoader;
_defineProperty(RouterConfigLoader, "ɵfac", function RouterConfigLoader_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouterConfigLoader)();
});
_defineProperty(RouterConfigLoader, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _RouterConfigLoader,
	factory: _RouterConfigLoader.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterConfigLoader, [{ type: Service }], null, null);
})();
function loadChildren(_x10, _x11, _x12, _x13) {
	return _loadChildren.apply(this, arguments);
}
function _loadChildren() {
	_loadChildren = _asyncToGenerator(function* (route, compiler, parentInjector, onLoadEndListener) {
		const t = yield maybeResolveResources(maybeUnwrapDefaultExport(yield wrapIntoPromise(runInInjectionContext(parentInjector, () => route.loadChildren()))));
		let factoryOrRoutes;
		if (t instanceof NgModuleFactory$1 || Array.isArray(t)) factoryOrRoutes = t;
		else factoryOrRoutes = yield compiler.compileModuleAsync(t);
		if (onLoadEndListener) onLoadEndListener(route);
		let injector;
		let rawRoutes;
		let requireStandaloneComponents = false;
		let factory = void 0;
		if (Array.isArray(factoryOrRoutes)) {
			rawRoutes = factoryOrRoutes;
			requireStandaloneComponents = true;
		} else {
			injector = factoryOrRoutes.create(parentInjector).injector;
			factory = factoryOrRoutes;
			rawRoutes = injector.get(ROUTES, [], {
				optional: true,
				self: true
			}).flat();
		}
		const routes = rawRoutes.map(standardizeConfig);
		(typeof ngDevMode === "undefined" || ngDevMode) && validateConfig(routes, route.path, requireStandaloneComponents);
		return {
			routes,
			injector,
			factory
		};
	});
	return _loadChildren.apply(this, arguments);
}
function maybeResolveResources(_x14) {
	return _maybeResolveResources.apply(this, arguments);
}
function _maybeResolveResources() {
	_maybeResolveResources = _asyncToGenerator(function* (value) {
		return value;
	});
	return _maybeResolveResources.apply(this, arguments);
}
var UrlHandlingStrategy = class {};
_UrlHandlingStrategy = UrlHandlingStrategy;
_defineProperty(UrlHandlingStrategy, "ɵfac", function UrlHandlingStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _UrlHandlingStrategy)();
});
_defineProperty(UrlHandlingStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _UrlHandlingStrategy,
	factory: () => (() => inject(DefaultUrlHandlingStrategy))()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UrlHandlingStrategy, [{
		type: Service,
		args: [{ factory: () => inject(DefaultUrlHandlingStrategy) }]
	}], null, null);
})();
var DefaultUrlHandlingStrategy = class {
	shouldProcessUrl(url) {
		return true;
	}
	extract(url) {
		return url;
	}
	merge(newUrlPart, wholeUrl) {
		return newUrlPart;
	}
};
_DefaultUrlHandlingStrategy = DefaultUrlHandlingStrategy;
_defineProperty(DefaultUrlHandlingStrategy, "ɵfac", function DefaultUrlHandlingStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DefaultUrlHandlingStrategy)();
});
_defineProperty(DefaultUrlHandlingStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _DefaultUrlHandlingStrategy,
	factory: _DefaultUrlHandlingStrategy.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultUrlHandlingStrategy, [{ type: Service }], null, null);
})();
var CREATE_VIEW_TRANSITION = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "view transition helper" : "");
var VIEW_TRANSITION_OPTIONS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "view transition options" : "");
function createViewTransition(injector, from, to) {
	const transitionOptions = injector.get(VIEW_TRANSITION_OPTIONS);
	const document = injector.get(DOCUMENT);
	if (!document.startViewTransition || transitionOptions.skipNextTransition) {
		transitionOptions.skipNextTransition = false;
		return new Promise((resolve) => setTimeout(resolve));
	}
	let resolveViewTransitionStarted;
	const viewTransitionStarted = new Promise((resolve) => {
		resolveViewTransitionStarted = resolve;
	});
	const transition = document.startViewTransition(() => {
		resolveViewTransitionStarted();
		return createRenderPromise(injector);
	});
	transition.updateCallbackDone.catch((error) => {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.error(error);
	});
	transition.ready.catch((error) => {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.error(error);
	});
	transition.finished.catch((error) => {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.error(error);
	});
	const { onViewTransitionCreated } = transitionOptions;
	if (onViewTransitionCreated) runInInjectionContext(injector, () => onViewTransitionCreated({
		transition,
		from,
		to
	}));
	return viewTransitionStarted;
}
function createRenderPromise(injector) {
	return new Promise((resolve) => {
		afterNextRender({ read: () => setTimeout(resolve) }, { injector });
	});
}
var ACTIVATED_ROUTE_INJECTOR_FEATURE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "ActivatedRoute injector feature" : "");
var noop = () => {};
var NAVIGATION_ERROR_HANDLER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "navigation error handler" : "");
var NavigationTransitions = class {
	get hasRequestedNavigation() {
		return this.navigationId !== 0;
	}
	constructor() {
		_defineProperty(this, "currentNavigation", signal(null, _objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "currentNavigation" } : {}), {}, { equal: () => false })));
		_defineProperty(this, "currentTransition", null);
		_defineProperty(this, "lastSuccessfulNavigation", signal(null, ...ngDevMode ? [{ debugName: "lastSuccessfulNavigation" }] : []));
		_defineProperty(this, "events", new Subject());
		_defineProperty(this, "transitionAbortWithErrorSubject", new Subject());
		_defineProperty(this, "configLoader", inject(RouterConfigLoader));
		_defineProperty(this, "environmentInjector", inject(EnvironmentInjector));
		_defineProperty(this, "destroyRef", inject(DestroyRef));
		_defineProperty(this, "urlSerializer", inject(UrlSerializer));
		_defineProperty(this, "rootContexts", inject(ChildrenOutletContexts));
		_defineProperty(this, "location", inject(Location));
		_defineProperty(this, "inputBindingEnabled", inject(INPUT_BINDER, { optional: true }) !== null);
		_defineProperty(this, "titleStrategy", inject(TitleStrategy));
		_defineProperty(this, "options", inject(ROUTER_CONFIGURATION, { optional: true }) || {});
		_defineProperty(this, "paramsInheritanceStrategy", this.options.paramsInheritanceStrategy || DEFAULT_PARAMS_INHERITANCE_STRATEGY);
		_defineProperty(this, "urlHandlingStrategy", inject(UrlHandlingStrategy));
		_defineProperty(this, "createViewTransition", inject(CREATE_VIEW_TRANSITION, { optional: true }));
		_defineProperty(this, "navigationErrorHandler", inject(NAVIGATION_ERROR_HANDLER, { optional: true }));
		_defineProperty(this, "activatedRouteInjectorFeature", inject(ACTIVATED_ROUTE_INJECTOR_FEATURE, { optional: true }));
		_defineProperty(this, "navigationId", 0);
		_defineProperty(this, "transitions", void 0);
		_defineProperty(this, "afterPreactivation", () => of(void 0));
		_defineProperty(this, "rootComponentType", null);
		_defineProperty(this, "destroyed", false);
		const onLoadStart = (r) => this.events.next(new RouteConfigLoadStart(r));
		const onLoadEnd = (r) => this.events.next(new RouteConfigLoadEnd(r));
		this.configLoader.onLoadEndListener = onLoadEnd;
		this.configLoader.onLoadStartListener = onLoadStart;
		this.destroyRef.onDestroy(() => {
			this.destroyed = true;
		});
	}
	complete() {
		var _this$transitions;
		(_this$transitions = this.transitions) === null || _this$transitions === void 0 || _this$transitions.complete();
	}
	handleNavigationRequest(request) {
		const id = ++this.navigationId;
		untracked(() => {
			var _this$transitions2;
			(_this$transitions2 = this.transitions) === null || _this$transitions2 === void 0 || _this$transitions2.next(_objectSpread2(_objectSpread2({}, request), {}, {
				extractedUrl: this.urlHandlingStrategy.extract(request.rawUrl),
				targetSnapshot: null,
				targetRouterState: null,
				guards: {
					canActivateChecks: [],
					canDeactivateChecks: []
				},
				guardsResult: null,
				id,
				routesRecognizeHandler: {},
				beforeActivateHandler: {}
			}));
		});
	}
	setupNavigations(router) {
		this.transitions = new BehaviorSubject(null);
		return this.transitions.pipe(filter((t) => t !== null), switchMap((overallTransitionState) => {
			var _this$activatedRouteI, _this$activatedRouteI2;
			let abortable = true;
			let completedOrAborted = false;
			const abortController = new AbortController();
			const shouldContinueNavigation = () => {
				var _this$currentTransiti;
				return !completedOrAborted && ((_this$currentTransiti = this.currentTransition) === null || _this$currentTransiti === void 0 ? void 0 : _this$currentTransiti.id) === overallTransitionState.id;
			};
			return of(overallTransitionState).pipe(switchMap((t) => {
				var _t$extras$onSameUrlNa;
				if (this.navigationId > overallTransitionState.id) {
					const cancellationReason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation ID ${overallTransitionState.id} is not equal to the current navigation id ${this.navigationId}` : "";
					this.cancelNavigationTransition(overallTransitionState, cancellationReason, NavigationCancellationCode.SupersededByNewNavigation);
					return EMPTY;
				}
				this.currentTransition = overallTransitionState;
				const lastSuccessfulNavigation = this.lastSuccessfulNavigation();
				this.currentNavigation.set({
					id: t.id,
					initialUrl: t.rawUrl,
					extractedUrl: t.extractedUrl,
					targetBrowserUrl: typeof t.extras.browserUrl === "string" ? this.urlSerializer.parse(t.extras.browserUrl) : t.extras.browserUrl,
					trigger: t.source,
					extras: t.extras,
					previousNavigation: !lastSuccessfulNavigation ? null : _objectSpread2(_objectSpread2({}, lastSuccessfulNavigation), {}, { previousNavigation: null }),
					abort: () => abortController.abort(),
					routesRecognizeHandler: t.routesRecognizeHandler,
					beforeActivateHandler: t.beforeActivateHandler
				});
				const urlTransition = !router.navigated || this.isUpdatingInternalState() || this.isUpdatedBrowserUrl();
				const onSameUrlNavigation = (_t$extras$onSameUrlNa = t.extras.onSameUrlNavigation) !== null && _t$extras$onSameUrlNa !== void 0 ? _t$extras$onSameUrlNa : router.onSameUrlNavigation;
				if (!urlTransition && onSameUrlNavigation !== "reload") {
					const reason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation to ${t.rawUrl} was ignored because it is the same as the current Router URL.` : "";
					this.events.next(new NavigationSkipped(t.id, this.urlSerializer.serialize(t.rawUrl), reason, NavigationSkippedCode.IgnoredSameUrlNavigation));
					t.resolve(false);
					return EMPTY;
				}
				if (this.urlHandlingStrategy.shouldProcessUrl(t.rawUrl)) return of(t).pipe(switchMap((t) => {
					this.events.next(new NavigationStart(t.id, this.urlSerializer.serialize(t.extractedUrl), t.source, t.restoredState));
					if (t.id !== this.navigationId) return EMPTY;
					return Promise.resolve(t);
				}), recognize(this.environmentInjector, this.configLoader, this.rootComponentType, router.config, this.urlSerializer, this.paramsInheritanceStrategy, abortController.signal), tap((t) => {
					overallTransitionState.targetSnapshot = t.targetSnapshot;
					overallTransitionState.urlAfterRedirects = t.urlAfterRedirects;
					this.currentNavigation.update((nav) => {
						nav.finalUrl = t.urlAfterRedirects;
						return nav;
					});
					this.events.next(new BeforeRoutesRecognized());
				}), switchMap((value) => {
					var _overallTransitionSta;
					return from((_overallTransitionSta = overallTransitionState.routesRecognizeHandler.deferredHandle) !== null && _overallTransitionSta !== void 0 ? _overallTransitionSta : of(void 0)).pipe(map(() => value));
				}), tap(() => {
					const routesRecognized = new RoutesRecognized(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
					this.events.next(routesRecognized);
				}));
				else if (urlTransition && this.urlHandlingStrategy.shouldProcessUrl(t.currentRawUrl)) {
					const { id, extractedUrl, source, restoredState, extras } = t;
					const navStart = new NavigationStart(id, this.urlSerializer.serialize(extractedUrl), source, restoredState);
					this.events.next(navStart);
					const targetSnapshot = createEmptyState(this.rootComponentType, this.environmentInjector).snapshot;
					this.currentTransition = overallTransitionState = _objectSpread2(_objectSpread2({}, t), {}, {
						targetSnapshot,
						urlAfterRedirects: extractedUrl,
						extras: _objectSpread2(_objectSpread2({}, extras), {}, {
							skipLocationChange: false,
							replaceUrl: false
						})
					});
					this.currentNavigation.update((nav) => {
						nav.finalUrl = extractedUrl;
						return nav;
					});
					return of(overallTransitionState);
				} else {
					const reason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation was ignored because the UrlHandlingStrategy indicated neither the current URL ${t.currentRawUrl} nor target URL ${t.rawUrl} should be processed.` : "";
					this.events.next(new NavigationSkipped(t.id, this.urlSerializer.serialize(t.extractedUrl), reason, NavigationSkippedCode.IgnoredByUrlHandlingStrategy));
					t.resolve(false);
					return EMPTY;
				}
			}), map((t) => {
				const guardsStart = new GuardsCheckStart(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
				this.events.next(guardsStart);
				this.currentTransition = overallTransitionState = _objectSpread2(_objectSpread2({}, t), {}, { guards: getAllRouteGuards(t.targetSnapshot, t.currentSnapshot, this.rootContexts) });
				return overallTransitionState;
			}), checkGuards((evt) => this.events.next(evt)), switchMap((t) => {
				overallTransitionState.guardsResult = t.guardsResult;
				if (t.guardsResult && typeof t.guardsResult !== "boolean") throw redirectingNavigationError(this.urlSerializer, t.guardsResult);
				const guardsEnd = new GuardsCheckEnd(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot, !!t.guardsResult);
				this.events.next(guardsEnd);
				if (!shouldContinueNavigation()) return EMPTY;
				if (!t.guardsResult) {
					this.cancelNavigationTransition(t, "", NavigationCancellationCode.GuardRejected);
					return EMPTY;
				}
				if (t.guards.canActivateChecks.length === 0) return of(t);
				const resolveStart = new ResolveStart(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
				this.events.next(resolveStart);
				if (!shouldContinueNavigation()) return EMPTY;
				let dataResolved = false;
				return of(t).pipe(resolveData(this.paramsInheritanceStrategy), tap({
					next: () => {
						dataResolved = true;
						const resolveEnd = new ResolveEnd(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
						this.events.next(resolveEnd);
					},
					complete: () => {
						if (!dataResolved) this.cancelNavigationTransition(t, typeof ngDevMode === "undefined" || ngDevMode ? `At least one route resolver didn't emit any value.` : "", NavigationCancellationCode.NoDataFromResolver);
					}
				}));
			}), switchTap((t) => {
				const loadComponents = (route) => {
					var _route$routeConfig, _route$routeConfig3;
					const loaders = [];
					if ((_route$routeConfig = route.routeConfig) === null || _route$routeConfig === void 0 ? void 0 : _route$routeConfig._loadedComponent) {
						var _route$routeConfig2;
						route.component = (_route$routeConfig2 = route.routeConfig) === null || _route$routeConfig2 === void 0 ? void 0 : _route$routeConfig2._loadedComponent;
					} else if ((_route$routeConfig3 = route.routeConfig) === null || _route$routeConfig3 === void 0 ? void 0 : _route$routeConfig3.loadComponent) {
						const injector = route._environmentInjector;
						loaders.push(this.configLoader.loadComponent(injector, route.routeConfig).then((loadedComponent) => {
							route.component = loadedComponent;
						}));
					}
					for (const child of route.children) loaders.push(...loadComponents(child));
					return loaders;
				};
				const loaders = loadComponents(t.targetSnapshot.root);
				return loaders.length === 0 ? of(t) : from(Promise.all(loaders).then(() => t));
			}), switchMap((t) => {
				const { newlyCreatedRoutes, state } = createRouterState(router.routeReuseStrategy, t.targetSnapshot, t.currentRouterState);
				this.currentTransition = overallTransitionState = t = _objectSpread2(_objectSpread2({}, t), {}, {
					targetRouterState: state,
					newlyCreatedRoutes
				});
				this.currentNavigation.update((nav) => {
					nav.targetRouterState = state;
					return nav;
				});
				return of(t);
			}), (_this$activatedRouteI = (_this$activatedRouteI2 = this.activatedRouteInjectorFeature) === null || _this$activatedRouteI2 === void 0 ? void 0 : _this$activatedRouteI2.operator()) !== null && _this$activatedRouteI !== void 0 ? _this$activatedRouteI : ((t) => t), switchTap(() => this.afterPreactivation()), switchMap(() => {
				var _this$createViewTrans;
				const { currentSnapshot, targetSnapshot } = overallTransitionState;
				const viewTransitionStarted = (_this$createViewTrans = this.createViewTransition) === null || _this$createViewTrans === void 0 ? void 0 : _this$createViewTrans.call(this, this.environmentInjector, currentSnapshot.root, targetSnapshot.root);
				return viewTransitionStarted ? from(viewTransitionStarted).pipe(map(() => overallTransitionState)) : of(overallTransitionState);
			}), take(1), switchMap((t) => {
				abortable = false;
				this.events.next(new BeforeActivateRoutes());
				const deferred = overallTransitionState.beforeActivateHandler.deferredHandle;
				return deferred ? from(deferred.then(() => t)) : of(t);
			}), tap((t) => {
				var _t$newlyCreatedRoutes, _this$titleStrategy;
				new ActivateRoutes(router.routeReuseStrategy, overallTransitionState.targetRouterState, overallTransitionState.currentRouterState, (evt) => this.events.next(evt), this.inputBindingEnabled).activate(this.rootContexts);
				(_t$newlyCreatedRoutes = t.newlyCreatedRoutes) === null || _t$newlyCreatedRoutes === void 0 || _t$newlyCreatedRoutes.clear();
				if (!shouldContinueNavigation()) return;
				completedOrAborted = true;
				this.currentNavigation.update((nav) => {
					nav.abort = noop;
					return nav;
				});
				this.lastSuccessfulNavigation.set(untracked(this.currentNavigation));
				this.events.next(new NavigationEnd(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects)));
				(_this$titleStrategy = this.titleStrategy) === null || _this$titleStrategy === void 0 || _this$titleStrategy.updateTitle(t.targetRouterState.snapshot);
				t.resolve(true);
			}), takeUntil(abortSignalToObservable(abortController.signal).pipe(filter(() => !completedOrAborted && abortable), tap(() => {
				this.cancelNavigationTransition(overallTransitionState, abortController.signal.reason + "", NavigationCancellationCode.Aborted);
			}))), tap({ complete: () => {
				completedOrAborted = true;
			} }), takeUntil(this.transitionAbortWithErrorSubject.pipe(tap((err) => {
				throw err;
			}))), finalize(() => {
				var _this$currentTransiti2;
				abortController.abort();
				if (!completedOrAborted) {
					const cancelationReason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation ID ${overallTransitionState.id} is not equal to the current navigation id ${this.navigationId}` : "";
					this.cancelNavigationTransition(overallTransitionState, cancelationReason, NavigationCancellationCode.SupersededByNewNavigation);
				}
				if (((_this$currentTransiti2 = this.currentTransition) === null || _this$currentTransiti2 === void 0 ? void 0 : _this$currentTransiti2.id) === overallTransitionState.id) {
					this.currentNavigation.set(null);
					this.currentTransition = null;
				}
			}), catchError((e) => {
				completedOrAborted = true;
				discardNewActivatedRoutes(overallTransitionState);
				if (this.destroyed) {
					overallTransitionState.resolve(false);
					return EMPTY;
				}
				if (isNavigationCancelingError(e)) {
					this.events.next(new NavigationCancel(overallTransitionState.id, this.urlSerializer.serialize(overallTransitionState.extractedUrl), e.message, e.cancellationCode));
					if (!isRedirectingNavigationCancelingError(e)) overallTransitionState.resolve(false);
					else this.events.next(new RedirectRequest(e.url, e.navigationBehaviorOptions));
				} else {
					var _overallTransitionSta2;
					const navigationError = new NavigationError(overallTransitionState.id, this.urlSerializer.serialize(overallTransitionState.extractedUrl), e, (_overallTransitionSta2 = overallTransitionState.targetSnapshot) !== null && _overallTransitionSta2 !== void 0 ? _overallTransitionSta2 : void 0);
					try {
						const navigationErrorHandlerResult = runInInjectionContext(this.environmentInjector, () => {
							var _this$navigationError;
							return (_this$navigationError = this.navigationErrorHandler) === null || _this$navigationError === void 0 ? void 0 : _this$navigationError.call(this, navigationError);
						});
						if (navigationErrorHandlerResult instanceof RedirectCommand) {
							const { message, cancellationCode } = redirectingNavigationError(this.urlSerializer, navigationErrorHandlerResult);
							this.events.next(new NavigationCancel(overallTransitionState.id, this.urlSerializer.serialize(overallTransitionState.extractedUrl), message, cancellationCode));
							this.events.next(new RedirectRequest(navigationErrorHandlerResult.redirectTo, navigationErrorHandlerResult.navigationBehaviorOptions));
						} else {
							this.events.next(navigationError);
							throw e;
						}
					} catch (ee) {
						if (this.options.resolveNavigationPromiseOnError) overallTransitionState.resolve(false);
						else overallTransitionState.reject(ee);
					}
				}
				return EMPTY;
			}));
		}));
	}
	cancelNavigationTransition(t, reason, code) {
		discardNewActivatedRoutes(t);
		const navCancel = new NavigationCancel(t.id, this.urlSerializer.serialize(t.extractedUrl), reason, code);
		this.events.next(navCancel);
		t.resolve(false);
	}
	isUpdatingInternalState() {
		var _this$currentTransiti3, _this$currentTransiti4;
		return ((_this$currentTransiti3 = this.currentTransition) === null || _this$currentTransiti3 === void 0 ? void 0 : _this$currentTransiti3.extractedUrl.toString()) !== ((_this$currentTransiti4 = this.currentTransition) === null || _this$currentTransiti4 === void 0 ? void 0 : _this$currentTransiti4.currentUrlTree.toString());
	}
	isUpdatedBrowserUrl() {
		var _currentNavigation$ta;
		const currentBrowserUrl = this.urlHandlingStrategy.extract(this.urlSerializer.parse(this.location.path(true)));
		const currentNavigation = untracked(this.currentNavigation);
		const targetBrowserUrl = (_currentNavigation$ta = currentNavigation === null || currentNavigation === void 0 ? void 0 : currentNavigation.targetBrowserUrl) !== null && _currentNavigation$ta !== void 0 ? _currentNavigation$ta : currentNavigation === null || currentNavigation === void 0 ? void 0 : currentNavigation.extractedUrl;
		return currentBrowserUrl.toString() !== (targetBrowserUrl === null || targetBrowserUrl === void 0 ? void 0 : targetBrowserUrl.toString()) && !(currentNavigation === null || currentNavigation === void 0 ? void 0 : currentNavigation.extras.skipLocationChange);
	}
};
_NavigationTransitions = NavigationTransitions;
_defineProperty(NavigationTransitions, "ɵfac", function NavigationTransitions_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NavigationTransitions)();
});
_defineProperty(NavigationTransitions, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _NavigationTransitions,
	factory: _NavigationTransitions.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NavigationTransitions, [{ type: Service }], () => [], null);
})();
function isBrowserTriggeredNavigation(source) {
	return source !== IMPERATIVE_NAVIGATION;
}
function discardNewActivatedRoutes(t) {
	if (!t.newlyCreatedRoutes) return;
	for (const r of t.newlyCreatedRoutes) {
		var _r$_localInjector;
		(_r$_localInjector = r._localInjector) === null || _r$_localInjector === void 0 || _r$_localInjector.destroy();
	}
}
var ROUTE_INJECTOR_CLEANUP = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "RouteInjectorCleanup" : "");
function routeInjectorCleanup(routeReuseStrategy, routerState, config) {
	var _routeReuseStrategy$r;
	const activeRoutes = /* @__PURE__ */ new Set();
	if (routerState.snapshot.root) collectDescendants(routerState.snapshot.root, activeRoutes);
	const storedHandles = ((_routeReuseStrategy$r = routeReuseStrategy.retrieveStoredRouteHandles) === null || _routeReuseStrategy$r === void 0 ? void 0 : _routeReuseStrategy$r.call(routeReuseStrategy)) || [];
	for (const handle of storedHandles) {
		var _internalHandle$route;
		const internalHandle = handle;
		if (internalHandle === null || internalHandle === void 0 || (_internalHandle$route = internalHandle.route) === null || _internalHandle$route === void 0 || (_internalHandle$route = _internalHandle$route.value) === null || _internalHandle$route === void 0 ? void 0 : _internalHandle$route.snapshot) {
			for (const snapshot of internalHandle.route.value.snapshot.pathFromRoot) if (snapshot.routeConfig) activeRoutes.add(snapshot.routeConfig);
		}
	}
	destroyUnusedInjectors(config, activeRoutes, routeReuseStrategy, false);
}
function collectDescendants(snapshot, activeRoutes) {
	if (snapshot.routeConfig) activeRoutes.add(snapshot.routeConfig);
	for (const child of snapshot.children) collectDescendants(child, activeRoutes);
}
function destroyUnusedInjectors(routes, activeRoutes, strategy, inheritedForceDestroy) {
	for (const route of routes) {
		var _strategy$shouldDestr, _strategy$shouldDestr2;
		const shouldDestroyCurrentRoute = inheritedForceDestroy || !!((route._injector || route._loadedInjector) && !activeRoutes.has(route) && ((_strategy$shouldDestr = (_strategy$shouldDestr2 = strategy.shouldDestroyInjector) === null || _strategy$shouldDestr2 === void 0 ? void 0 : _strategy$shouldDestr2.call(strategy, route)) !== null && _strategy$shouldDestr !== void 0 ? _strategy$shouldDestr : false));
		if (route.children) destroyUnusedInjectors(route.children, activeRoutes, strategy, shouldDestroyCurrentRoute);
		if (route.loadChildren && route._loadedRoutes) destroyUnusedInjectors(route._loadedRoutes, activeRoutes, strategy, shouldDestroyCurrentRoute);
		if (shouldDestroyCurrentRoute) {
			if (route._injector) {
				route._injector.destroy();
				route._injector = void 0;
			}
			if (route._loadedInjector) {
				route._loadedInjector.destroy();
				route._loadedInjector = void 0;
			}
		}
	}
}
function destroyDetachedRouteHandle(handle) {
	const internalHandle = handle;
	if (internalHandle && internalHandle.componentRef) {
		var _internalHandle$route2;
		internalHandle.componentRef.destroy();
		(_internalHandle$route2 = internalHandle.route.value._localInjector) === null || _internalHandle$route2 === void 0 || _internalHandle$route2.destroy();
	}
}
var RouteReuseStrategy = class {};
_RouteReuseStrategy = RouteReuseStrategy;
_defineProperty(RouteReuseStrategy, "ɵfac", function RouteReuseStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouteReuseStrategy)();
});
_defineProperty(RouteReuseStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _RouteReuseStrategy,
	factory: () => (() => inject(DefaultRouteReuseStrategy))()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouteReuseStrategy, [{
		type: Service,
		args: [{ factory: () => inject(DefaultRouteReuseStrategy) }]
	}], null, null);
})();
var BaseRouteReuseStrategy = class {
	shouldDetach(route) {
		return false;
	}
	store(route, detachedTree) {}
	shouldAttach(route) {
		return false;
	}
	retrieve(route) {
		return null;
	}
	shouldReuseRoute(future, curr) {
		return future.routeConfig === curr.routeConfig;
	}
	shouldDestroyInjector(route) {
		return true;
	}
};
var DefaultRouteReuseStrategy = class extends BaseRouteReuseStrategy {};
_DefaultRouteReuseStrategy = DefaultRouteReuseStrategy;
_defineProperty(DefaultRouteReuseStrategy, "ɵfac", function DefaultRouteReuseStrategy_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _DefaultRouteReuseStrategy)();
});
_defineProperty(DefaultRouteReuseStrategy, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _DefaultRouteReuseStrategy,
	factory: _DefaultRouteReuseStrategy.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultRouteReuseStrategy, [{ type: Service }], null, null);
})();
var StateManager = class {
	constructor() {
		_defineProperty(this, "urlSerializer", inject(UrlSerializer));
		_defineProperty(this, "options", inject(ROUTER_CONFIGURATION, { optional: true }) || {});
		_defineProperty(this, "canceledNavigationResolution", this.options.canceledNavigationResolution || "replace");
		_defineProperty(this, "location", inject(Location));
		_defineProperty(this, "urlHandlingStrategy", inject(UrlHandlingStrategy));
		_defineProperty(this, "urlUpdateStrategy", this.options.urlUpdateStrategy || "deferred");
		_defineProperty(this, "currentUrlTree", new UrlTree());
		_defineProperty(this, "rawUrlTree", this.currentUrlTree);
		_defineProperty(this, "routerState", createEmptyState(null, inject(EnvironmentInjector)));
		_defineProperty(this, "_stateMemento", this.createStateMemento());
	}
	getCurrentUrlTree() {
		return this.currentUrlTree;
	}
	getRawUrlTree() {
		return this.rawUrlTree;
	}
	createBrowserPath({ finalUrl, initialUrl, targetBrowserUrl }) {
		const rawUrl = finalUrl !== void 0 ? this.urlHandlingStrategy.merge(finalUrl, initialUrl) : initialUrl;
		const url = targetBrowserUrl !== null && targetBrowserUrl !== void 0 ? targetBrowserUrl : rawUrl;
		return url instanceof UrlTree ? this.urlSerializer.serialize(url) : url;
	}
	routerUrlState(navigation) {
		if ((navigation === null || navigation === void 0 ? void 0 : navigation.targetBrowserUrl) === void 0 || (navigation === null || navigation === void 0 ? void 0 : navigation.finalUrl) === void 0) return {};
		return { ɵrouterUrl: this.urlSerializer.serialize(navigation.finalUrl) };
	}
	commitTransition({ targetRouterState, finalUrl, initialUrl }) {
		if (finalUrl && targetRouterState) {
			this.currentUrlTree = finalUrl;
			this.rawUrlTree = this.urlHandlingStrategy.merge(finalUrl, initialUrl);
			this.routerState = targetRouterState;
		} else this.rawUrlTree = initialUrl;
	}
	getRouterState() {
		return this.routerState;
	}
	get stateMemento() {
		return this._stateMemento;
	}
	updateStateMemento() {
		this._stateMemento = this.createStateMemento();
	}
	createStateMemento() {
		return {
			rawUrlTree: this.rawUrlTree,
			currentUrlTree: this.currentUrlTree,
			routerState: this.routerState
		};
	}
	restoredState() {
		return this.location.getState();
	}
};
_StateManager = StateManager;
_defineProperty(StateManager, "ɵfac", function StateManager_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _StateManager)();
});
_defineProperty(StateManager, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _StateManager,
	factory: () => (() => inject(HistoryStateManager))()
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StateManager, [{
		type: Service,
		args: [{ factory: () => inject(HistoryStateManager) }]
	}], null, null);
})();
var HistoryStateManager = class extends StateManager {
	constructor(..._args) {
		super(..._args);
		_defineProperty(this, "currentPageId", 0);
		_defineProperty(this, "lastSuccessfulId", -1);
	}
	get browserPageId() {
		var _this$restoredState$, _this$restoredState;
		if (this.canceledNavigationResolution !== "computed") return this.currentPageId;
		return (_this$restoredState$ = (_this$restoredState = this.restoredState()) === null || _this$restoredState === void 0 ? void 0 : _this$restoredState.ɵrouterPageId) !== null && _this$restoredState$ !== void 0 ? _this$restoredState$ : this.currentPageId;
	}
	registerNonRouterCurrentEntryChangeListener(listener) {
		return this.location.subscribe((event) => {
			if (event["type"] === "popstate") setTimeout(() => {
				listener(event["url"], event.state, "popstate", { replaceUrl: true });
			});
		});
	}
	handleRouterEvent(e, currentTransition) {
		if (e instanceof NavigationStart) this.updateStateMemento();
		else if (e instanceof NavigationSkipped) this.commitTransition(currentTransition);
		else if (e instanceof RoutesRecognized) {
			if (this.urlUpdateStrategy === "eager") {
				if (!currentTransition.extras.skipLocationChange) this.setBrowserUrl(this.createBrowserPath(currentTransition), currentTransition);
			}
		} else if (e instanceof BeforeActivateRoutes) {
			this.commitTransition(currentTransition);
			if (this.urlUpdateStrategy === "deferred" && !currentTransition.extras.skipLocationChange) this.setBrowserUrl(this.createBrowserPath(currentTransition), currentTransition);
		} else if (e instanceof NavigationCancel && !isRedirectingEvent(e)) this.restoreHistory(currentTransition);
		else if (e instanceof NavigationError) this.restoreHistory(currentTransition, true);
		else if (e instanceof NavigationEnd) {
			this.lastSuccessfulId = e.id;
			this.currentPageId = this.browserPageId;
		}
	}
	setBrowserUrl(path, navigation) {
		const { extras, id } = navigation;
		const { replaceUrl, state } = extras;
		if (this.location.isCurrentPathEqualTo(path) || !!replaceUrl) {
			const currentBrowserPageId = this.browserPageId;
			const newState = _objectSpread2(_objectSpread2({}, state), this.generateNgRouterState(id, currentBrowserPageId, navigation));
			this.location.replaceState(path, "", newState);
		} else {
			const newState = _objectSpread2(_objectSpread2({}, state), this.generateNgRouterState(id, this.browserPageId + 1, navigation));
			this.location.go(path, "", newState);
		}
	}
	restoreHistory(navigation, restoringFromCaughtError = false) {
		if (this.canceledNavigationResolution === "computed") {
			const currentBrowserPageId = this.browserPageId;
			const targetPagePosition = this.currentPageId - currentBrowserPageId;
			if (targetPagePosition !== 0) this.location.historyGo(targetPagePosition);
			else if (this.getCurrentUrlTree() === navigation.finalUrl && targetPagePosition === 0) {
				this.resetInternalState(navigation);
				this.resetUrlToCurrentUrlTree();
			}
		} else if (this.canceledNavigationResolution === "replace") {
			if (restoringFromCaughtError) this.resetInternalState(navigation);
			this.resetUrlToCurrentUrlTree();
		}
	}
	resetInternalState({ finalUrl }) {
		this.routerState = this.stateMemento.routerState;
		this.currentUrlTree = this.stateMemento.currentUrlTree;
		this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, finalUrl !== null && finalUrl !== void 0 ? finalUrl : this.rawUrlTree);
	}
	resetUrlToCurrentUrlTree() {
		this.location.replaceState(this.urlSerializer.serialize(this.getRawUrlTree()), "", this.generateNgRouterState(this.lastSuccessfulId, this.currentPageId));
	}
	generateNgRouterState(navigationId, routerPageId, navigation) {
		if (this.canceledNavigationResolution === "computed") return _objectSpread2({
			navigationId,
			ɵrouterPageId: routerPageId
		}, this.routerUrlState(navigation));
		return _objectSpread2({ navigationId }, this.routerUrlState(navigation));
	}
};
_HistoryStateManager = HistoryStateManager;
_defineProperty(HistoryStateManager, "ɵfac", function HistoryStateManager_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _HistoryStateManager)();
});
_defineProperty(HistoryStateManager, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _HistoryStateManager,
	factory: _HistoryStateManager.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HistoryStateManager, [{ type: Service }], null, null);
})();
function afterNextNavigation(router, action) {
	router.events.pipe(filter((e) => e instanceof NavigationEnd || e instanceof NavigationCancel || e instanceof NavigationError || e instanceof NavigationSkipped), map((e) => {
		if (e instanceof NavigationEnd || e instanceof NavigationSkipped) return 0;
		return (e instanceof NavigationCancel ? e.code === NavigationCancellationCode.Redirect || e.code === NavigationCancellationCode.SupersededByNewNavigation : false) ? 2 : 1;
	}), filter((result) => result !== 2), take(1)).subscribe(() => {
		action();
	});
}
var Router = class {
	get currentUrlTree() {
		return this.stateManager.getCurrentUrlTree();
	}
	get rawUrlTree() {
		return this.stateManager.getRawUrlTree();
	}
	get events() {
		return this._events;
	}
	get routerState() {
		return this.stateManager.getRouterState();
	}
	constructor() {
		var _inject$flat, _inject;
		_defineProperty(this, "disposed", false);
		_defineProperty(this, "nonRouterCurrentEntryChangeSubscription", void 0);
		_defineProperty(this, "console", inject(Console));
		_defineProperty(this, "stateManager", inject(StateManager));
		_defineProperty(this, "options", inject(ROUTER_CONFIGURATION, { optional: true }) || {});
		_defineProperty(this, "pendingTasks", inject(PendingTasksInternal));
		_defineProperty(this, "urlUpdateStrategy", this.options.urlUpdateStrategy || "deferred");
		_defineProperty(this, "navigationTransitions", inject(NavigationTransitions));
		_defineProperty(this, "urlSerializer", inject(UrlSerializer));
		_defineProperty(this, "location", inject(Location));
		_defineProperty(this, "urlHandlingStrategy", inject(UrlHandlingStrategy));
		_defineProperty(this, "injector", inject(EnvironmentInjector));
		_defineProperty(this, "_events", new Subject());
		_defineProperty(this, "navigated", false);
		_defineProperty(this, "routeReuseStrategy", inject(RouteReuseStrategy));
		_defineProperty(this, "injectorCleanup", inject(ROUTE_INJECTOR_CLEANUP, { optional: true }));
		_defineProperty(this, "onSameUrlNavigation", this.options.onSameUrlNavigation || "ignore");
		_defineProperty(this, "config", (_inject$flat = (_inject = inject(ROUTES, { optional: true })) === null || _inject === void 0 ? void 0 : _inject.flat()) !== null && _inject$flat !== void 0 ? _inject$flat : []);
		_defineProperty(this, "componentInputBindingEnabled", !!inject(INPUT_BINDER, { optional: true }));
		_defineProperty(this, "currentNavigation", this.navigationTransitions.currentNavigation.asReadonly());
		_defineProperty(this, "eventsSubscription", new Subscription());
		this.resetConfig(this.config);
		this.navigationTransitions.setupNavigations(this).subscribe({ error: (e) => {} });
		this.subscribeToNavigationEvents();
	}
	subscribeToNavigationEvents() {
		const subscription = this.navigationTransitions.events.subscribe((e) => {
			try {
				const currentTransition = this.navigationTransitions.currentTransition;
				const currentNavigation = untracked(this.navigationTransitions.currentNavigation);
				if (currentTransition !== null && currentNavigation !== null) {
					this.stateManager.handleRouterEvent(e, currentNavigation);
					if (e instanceof NavigationCancel && e.code !== NavigationCancellationCode.Redirect && e.code !== NavigationCancellationCode.SupersededByNewNavigation) this.navigated = true;
					else if (e instanceof NavigationEnd) {
						var _this$injectorCleanup;
						this.navigated = true;
						(_this$injectorCleanup = this.injectorCleanup) === null || _this$injectorCleanup === void 0 || _this$injectorCleanup.call(this, this.routeReuseStrategy, this.routerState, this.config);
					} else if (e instanceof RedirectRequest) {
						const opts = e.navigationBehaviorOptions;
						const mergedTree = this.urlHandlingStrategy.merge(e.url, currentTransition.currentRawUrl);
						const extras = _objectSpread2({
							scroll: currentTransition.extras.scroll,
							browserUrl: currentTransition.extras.browserUrl,
							info: currentTransition.extras.info,
							skipLocationChange: currentTransition.extras.skipLocationChange,
							replaceUrl: currentTransition.extras.replaceUrl || this.urlUpdateStrategy === "eager" || isBrowserTriggeredNavigation(currentTransition.source)
						}, opts);
						this.scheduleNavigation(mergedTree, IMPERATIVE_NAVIGATION, null, extras, {
							resolve: currentTransition.resolve,
							reject: currentTransition.reject,
							promise: currentTransition.promise
						});
					}
				}
				if (isPublicRouterEvent(e)) this._events.next(e);
			} catch (e) {
				this.navigationTransitions.transitionAbortWithErrorSubject.next(e);
			}
		});
		this.eventsSubscription.add(subscription);
	}
	resetRootComponentType(rootComponentType) {
		this.routerState.root.component = rootComponentType;
		this.navigationTransitions.rootComponentType = rootComponentType;
	}
	initialNavigation() {
		this.setUpLocationChangeListener();
		if (!this.navigationTransitions.hasRequestedNavigation) this.navigateToSyncWithBrowser(this.location.path(true), IMPERATIVE_NAVIGATION, this.stateManager.restoredState(), { replaceUrl: true });
	}
	setUpLocationChangeListener() {
		var _this$nonRouterCurren;
		(_this$nonRouterCurren = this.nonRouterCurrentEntryChangeSubscription) !== null && _this$nonRouterCurren !== void 0 || (this.nonRouterCurrentEntryChangeSubscription = this.stateManager.registerNonRouterCurrentEntryChangeListener((url, state, source, extras) => {
			this.navigateToSyncWithBrowser(url, source, state, extras);
		}));
	}
	navigateToSyncWithBrowser(url, source, state, extras) {
		var _state$ɵrouterUrl;
		const restoredState = (state === null || state === void 0 ? void 0 : state.navigationId) ? state : null;
		const routerUrl = (_state$ɵrouterUrl = state === null || state === void 0 ? void 0 : state.ɵrouterUrl) !== null && _state$ɵrouterUrl !== void 0 ? _state$ɵrouterUrl : url;
		if (state === null || state === void 0 ? void 0 : state.ɵrouterUrl) extras = _objectSpread2(_objectSpread2({}, extras), {}, { browserUrl: url });
		if (state) {
			const stateCopy = _objectSpread2({}, state);
			delete stateCopy.navigationId;
			delete stateCopy.ɵrouterPageId;
			delete stateCopy.ɵrouterUrl;
			if (Object.keys(stateCopy).length !== 0) extras.state = stateCopy;
		}
		const urlTree = this.parseUrl(routerUrl);
		this.scheduleNavigation(urlTree, source, restoredState, extras).catch((e) => {
			if (this.disposed) return;
			this.injector.get(INTERNAL_APPLICATION_ERROR_HANDLER)(e);
		});
	}
	get url() {
		return this.serializeUrl(this.currentUrlTree);
	}
	getCurrentNavigation() {
		return untracked(this.navigationTransitions.currentNavigation);
	}
	get lastSuccessfulNavigation() {
		return this.navigationTransitions.lastSuccessfulNavigation;
	}
	resetConfig(config) {
		(typeof ngDevMode === "undefined" || ngDevMode) && validateConfig(config);
		this.config = config.map(standardizeConfig);
		this.navigated = false;
	}
	ngOnDestroy() {
		this.dispose();
	}
	dispose() {
		var _this$nonRouterCurren2;
		this._events.unsubscribe();
		this.navigationTransitions.complete();
		(_this$nonRouterCurren2 = this.nonRouterCurrentEntryChangeSubscription) === null || _this$nonRouterCurren2 === void 0 || _this$nonRouterCurren2.unsubscribe();
		this.nonRouterCurrentEntryChangeSubscription = void 0;
		this.disposed = true;
		this.eventsSubscription.unsubscribe();
	}
	createUrlTree(commands, navigationExtras = {}) {
		const { relativeTo, queryParams, fragment, queryParamsHandling, preserveFragment } = navigationExtras;
		const f = preserveFragment ? this.currentUrlTree.fragment : fragment;
		let q = null;
		switch (queryParamsHandling !== null && queryParamsHandling !== void 0 ? queryParamsHandling : this.options.defaultQueryParamsHandling) {
			case "merge":
				q = _objectSpread2(_objectSpread2({}, this.currentUrlTree.queryParams), queryParams);
				break;
			case "preserve":
				q = this.currentUrlTree.queryParams;
				break;
			default: q = queryParams || null;
		}
		if (q !== null) q = this.removeEmptyProps(q);
		let relativeToUrlSegmentGroup;
		try {
			relativeToUrlSegmentGroup = createSegmentGroupFromRoute(relativeTo ? relativeTo.snapshot : this.routerState.snapshot.root);
		} catch (e) {
			if (typeof commands[0] !== "string" || commands[0][0] !== "/") commands = [];
			relativeToUrlSegmentGroup = this.currentUrlTree.root;
		}
		return createUrlTreeFromSegmentGroup(relativeToUrlSegmentGroup, commands, q, f !== null && f !== void 0 ? f : null, this.urlSerializer);
	}
	navigateByUrl(url, extras = { skipLocationChange: false }) {
		const urlTree = isUrlTree(url) ? url : this.parseUrl(url);
		const mergedTree = this.urlHandlingStrategy.merge(urlTree, this.rawUrlTree);
		return this.scheduleNavigation(mergedTree, IMPERATIVE_NAVIGATION, null, extras);
	}
	navigate(commands, extras = { skipLocationChange: false }) {
		validateCommands(commands);
		return this.navigateByUrl(this.createUrlTree(commands, extras), extras);
	}
	serializeUrl(url) {
		return this.urlSerializer.serialize(url);
	}
	parseUrl(url) {
		try {
			return this.urlSerializer.parse(url);
		} catch (e) {
			this.console.warn(formatRuntimeError(4018, ngDevMode && `Error parsing URL ${url}. Falling back to '/' instead. \n` + e));
			return this.urlSerializer.parse("/");
		}
	}
	isActive(url, matchOptions) {
		let options;
		if (matchOptions === true) options = _objectSpread2({}, exactMatchOptions);
		else if (matchOptions === false) options = _objectSpread2({}, subsetMatchOptions);
		else options = _objectSpread2(_objectSpread2({}, subsetMatchOptions), matchOptions);
		if (isUrlTree(url)) return containsTree(this.currentUrlTree, url, options);
		const urlTree = this.parseUrl(url);
		return containsTree(this.currentUrlTree, urlTree, options);
	}
	removeEmptyProps(params) {
		return Object.entries(params).reduce((result, [key, value]) => {
			if (value !== null && value !== void 0) result[key] = value;
			return result;
		}, {});
	}
	scheduleNavigation(rawUrl, source, restoredState, extras, priorPromise) {
		if (this.disposed) return Promise.resolve(false);
		let resolve;
		let reject;
		let promise;
		if (priorPromise) {
			resolve = priorPromise.resolve;
			reject = priorPromise.reject;
			promise = priorPromise.promise;
		} else promise = new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		});
		const taskId = this.pendingTasks.add();
		afterNextNavigation(this, () => {
			queueMicrotask(() => this.pendingTasks.remove(taskId));
		});
		this.navigationTransitions.handleNavigationRequest({
			source,
			restoredState,
			currentUrlTree: this.currentUrlTree,
			currentRawUrl: this.currentUrlTree,
			rawUrl,
			extras,
			resolve,
			reject,
			promise,
			currentSnapshot: this.routerState.snapshot,
			currentRouterState: this.routerState
		});
		return promise.catch(Promise.reject.bind(Promise));
	}
};
_Router = Router;
_defineProperty(Router, "ɵfac", function Router_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _Router)();
});
_defineProperty(Router, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _Router,
	factory: _Router.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Router, [{ type: Service }], () => [], null);
})();
function validateCommands(commands) {
	for (let i = 0; i < commands.length; i++) {
		const cmd = commands[i];
		if (cmd == null) throw new RuntimeError(4008, (typeof ngDevMode === "undefined" || ngDevMode) && `The requested path contains ${cmd} segment at index ${i}`);
	}
}
//#endregion
//#region node_modules/@angular/router/fesm2022/_router_module-chunk.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var _ReactiveRouterState;
var _RouterLink;
var _RouterLinkActive;
var _PreloadAllModules;
var _NoPreloading;
var _RouterPreloader;
var _RouterScroller;
var _NavigationStateManager;
var _RouterModule;
var ReactiveRouterState = class {
	constructor() {
		var _this$router$events;
		_defineProperty(this, "router", inject(Router));
		_defineProperty(this, "stateManager", inject(StateManager));
		_defineProperty(this, "fragment", signal("", ...ngDevMode ? [{ debugName: "fragment" }] : []));
		_defineProperty(this, "queryParams", signal({}, ...ngDevMode ? [{ debugName: "queryParams" }] : []));
		_defineProperty(this, "path", signal("", ...ngDevMode ? [{ debugName: "path" }] : []));
		_defineProperty(this, "serializer", inject(UrlSerializer));
		this.updateState();
		(_this$router$events = this.router.events) === null || _this$router$events === void 0 || _this$router$events.subscribe((e) => {
			if (e instanceof NavigationEnd) this.updateState();
		});
	}
	updateState() {
		const { fragment, root, queryParams } = this.stateManager.getCurrentUrlTree();
		this.fragment.set(fragment);
		this.queryParams.set(queryParams);
		this.path.set(this.serializer.serialize(new UrlTree(root)));
	}
};
_ReactiveRouterState = ReactiveRouterState;
_defineProperty(ReactiveRouterState, "ɵfac", function ReactiveRouterState_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _ReactiveRouterState)();
});
_defineProperty(ReactiveRouterState, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _ReactiveRouterState,
	factory: _ReactiveRouterState.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReactiveRouterState, [{ type: Service }], () => [], null);
})();
var RouterLink = class {
	get href() {
		return untracked(this.reactiveHref);
	}
	set href(value) {
		this.reactiveHref.set(value);
	}
	set target(value) {
		this._target.set(value);
	}
	get target() {
		return untracked(this._target);
	}
	set queryParams(value) {
		this._queryParams.set(value);
	}
	get queryParams() {
		return untracked(this._queryParams);
	}
	set fragment(value) {
		this._fragment.set(value);
	}
	get fragment() {
		return untracked(this._fragment);
	}
	set queryParamsHandling(value) {
		this._queryParamsHandling.set(value);
	}
	get queryParamsHandling() {
		return untracked(this._queryParamsHandling);
	}
	set state(value) {
		this._state.set(value);
	}
	get state() {
		return untracked(this._state);
	}
	set info(value) {
		this._info.set(value);
	}
	get info() {
		return untracked(this._info);
	}
	set relativeTo(value) {
		this._relativeTo.set(value);
	}
	get relativeTo() {
		return untracked(this._relativeTo);
	}
	set preserveFragment(value) {
		this._preserveFragment.set(value);
	}
	get preserveFragment() {
		return untracked(this._preserveFragment);
	}
	set skipLocationChange(value) {
		this._skipLocationChange.set(value);
	}
	get skipLocationChange() {
		return untracked(this._skipLocationChange);
	}
	set replaceUrl(value) {
		this._replaceUrl.set(value);
	}
	get replaceUrl() {
		return untracked(this._replaceUrl);
	}
	constructor(router, route, tabIndexAttribute, renderer, el, locationStrategy) {
		var _el$nativeElement$tag, _customElements$get, _customElements$get$i;
		_defineProperty(this, "router", void 0);
		_defineProperty(this, "route", void 0);
		_defineProperty(this, "tabIndexAttribute", void 0);
		_defineProperty(this, "renderer", void 0);
		_defineProperty(this, "el", void 0);
		_defineProperty(this, "locationStrategy", void 0);
		_defineProperty(this, "hrefAttributeValue", inject(new HostAttributeToken("href"), { optional: true }));
		_defineProperty(this, "reactiveHref", linkedSignal(() => {
			if (!this.isAnchorElement) return this.hrefAttributeValue;
			return this.computeHref(this._urlTree());
		}, ...ngDevMode ? [{ debugName: "reactiveHref" }] : []));
		_defineProperty(this, "_target", signal(void 0, ...ngDevMode ? [{ debugName: "_target" }] : []));
		_defineProperty(this, "_queryParams", signal(void 0, _objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_queryParams" } : {}), {}, { equal: () => false })));
		_defineProperty(this, "_fragment", signal(void 0, ...ngDevMode ? [{ debugName: "_fragment" }] : []));
		_defineProperty(this, "_queryParamsHandling", signal(void 0, ...ngDevMode ? [{ debugName: "_queryParamsHandling" }] : []));
		_defineProperty(this, "_state", signal(void 0, _objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_state" } : {}), {}, { equal: () => false })));
		_defineProperty(this, "_info", signal(void 0, _objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_info" } : {}), {}, { equal: () => false })));
		_defineProperty(this, "_relativeTo", signal(void 0, ...ngDevMode ? [{ debugName: "_relativeTo" }] : []));
		_defineProperty(this, "_preserveFragment", signal(false, ...ngDevMode ? [{ debugName: "_preserveFragment" }] : []));
		_defineProperty(this, "_skipLocationChange", signal(false, ...ngDevMode ? [{ debugName: "_skipLocationChange" }] : []));
		_defineProperty(this, "_replaceUrl", signal(false, ...ngDevMode ? [{ debugName: "_replaceUrl" }] : []));
		_defineProperty(this, "browserUrl", input(void 0, ...ngDevMode ? [{ debugName: "browserUrl" }] : []));
		_defineProperty(this, "isAnchorElement", void 0);
		_defineProperty(this, "onChanges", new Subject());
		_defineProperty(this, "applicationErrorHandler", inject(INTERNAL_APPLICATION_ERROR_HANDLER));
		_defineProperty(this, "options", inject(ROUTER_CONFIGURATION, { optional: true }));
		_defineProperty(this, "reactiveRouterState", inject(ReactiveRouterState));
		_defineProperty(this, "routerLinkInput", signal(null, ...ngDevMode ? [{ debugName: "routerLinkInput" }] : []));
		_defineProperty(this, "_urlTree", computed(() => {
			var _this$options;
			this.reactiveRouterState.path();
			if (this._preserveFragment()) this.reactiveRouterState.fragment();
			const shouldTrackParams = (handling) => handling === "preserve" || handling === "merge";
			if (shouldTrackParams(this._queryParamsHandling()) || shouldTrackParams((_this$options = this.options) === null || _this$options === void 0 ? void 0 : _this$options.defaultQueryParamsHandling)) this.reactiveRouterState.queryParams();
			const routerLinkInput = this.routerLinkInput();
			if (routerLinkInput === null || !this.router.createUrlTree) return null;
			else if (isUrlTree(routerLinkInput)) return routerLinkInput;
			return this.router.createUrlTree(routerLinkInput, {
				relativeTo: this._relativeTo() !== void 0 ? this._relativeTo() : this.route,
				queryParams: this._queryParams(),
				fragment: this._fragment(),
				queryParamsHandling: this._queryParamsHandling(),
				preserveFragment: this._preserveFragment()
			});
		}, _objectSpread2(_objectSpread2({}, ngDevMode ? { debugName: "_urlTree" } : {}), {}, { equal: (a, b) => this.computeHref(a) === this.computeHref(b) })));
		this.router = router;
		this.route = route;
		this.tabIndexAttribute = tabIndexAttribute;
		this.renderer = renderer;
		this.el = el;
		this.locationStrategy = locationStrategy;
		const tagName = (_el$nativeElement$tag = el.nativeElement.tagName) === null || _el$nativeElement$tag === void 0 ? void 0 : _el$nativeElement$tag.toLowerCase();
		this.isAnchorElement = tagName === "a" || tagName === "area" || !!(typeof customElements === "object" && ((_customElements$get = customElements.get(tagName)) === null || _customElements$get === void 0 || (_customElements$get = _customElements$get.observedAttributes) === null || _customElements$get === void 0 || (_customElements$get$i = _customElements$get.includes) === null || _customElements$get$i === void 0 ? void 0 : _customElements$get$i.call(_customElements$get, "href")));
		if (typeof ngDevMode !== "undefined" && ngDevMode) effect(() => {
			if (isUrlTree(this.routerLinkInput()) && (this._fragment() !== void 0 || this._queryParams() || this._queryParamsHandling() || this._preserveFragment() || this._relativeTo())) throw new RuntimeError(4017, "Cannot configure queryParams or fragment when using a UrlTree as the routerLink input value.");
		});
	}
	setTabIndexIfNotOnNativeEl(newTabIndex) {
		if (this.tabIndexAttribute != null || this.isAnchorElement) return;
		this.applyAttributeValue("tabindex", newTabIndex);
	}
	ngOnChanges(changes) {
		this.onChanges.next(this);
	}
	set routerLink(commandsOrUrlTree) {
		if (commandsOrUrlTree == null) {
			this.routerLinkInput.set(null);
			this.setTabIndexIfNotOnNativeEl(null);
		} else {
			if (isUrlTree(commandsOrUrlTree)) this.routerLinkInput.set(commandsOrUrlTree);
			else this.routerLinkInput.set(Array.isArray(commandsOrUrlTree) ? commandsOrUrlTree : [commandsOrUrlTree]);
			this.setTabIndexIfNotOnNativeEl("0");
		}
	}
	onClick(button, ctrlKey, shiftKey, altKey, metaKey) {
		var _this$router$navigate;
		const urlTree = this._urlTree();
		if (urlTree === null) return true;
		if (this.isAnchorElement) {
			if (button !== 0 || ctrlKey || shiftKey || altKey || metaKey) return true;
			if (typeof this.target === "string" && this.target != "_self") return true;
		}
		const browserUrl = this.browserUrl();
		const extras = _objectSpread2({
			skipLocationChange: this.skipLocationChange,
			replaceUrl: this.replaceUrl,
			state: this.state,
			info: this.info
		}, browserUrl !== void 0 && { browserUrl });
		(_this$router$navigate = this.router.navigateByUrl(urlTree, extras)) === null || _this$router$navigate === void 0 || _this$router$navigate.catch((e) => {
			this.applicationErrorHandler(e);
		});
		return !this.isAnchorElement;
	}
	ngOnDestroy() {}
	applyAttributeValue(attrName, attrValue) {
		const renderer = this.renderer;
		const nativeElement = this.el.nativeElement;
		if (attrValue !== null) renderer.setAttribute(nativeElement, attrName, attrValue);
		else renderer.removeAttribute(nativeElement, attrName);
	}
	get urlTree() {
		return untracked(this._urlTree);
	}
	computeHref(urlTree) {
		var _this$locationStrateg, _this$locationStrateg2;
		return urlTree !== null && this.locationStrategy ? (_this$locationStrateg = (_this$locationStrateg2 = this.locationStrategy) === null || _this$locationStrateg2 === void 0 ? void 0 : _this$locationStrateg2.prepareExternalUrl(this.router.serializeUrl(urlTree))) !== null && _this$locationStrateg !== void 0 ? _this$locationStrateg : "" : null;
	}
};
_RouterLink = RouterLink;
_defineProperty(RouterLink, "ɵfac", function RouterLink_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouterLink)(ɵɵdirectiveInject(Router), ɵɵdirectiveInject(ActivatedRoute), ɵɵinjectAttribute("tabindex"), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(LocationStrategy));
});
_defineProperty(RouterLink, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _RouterLink,
	selectors: [[
		"",
		"routerLink",
		""
	]],
	hostVars: 2,
	hostBindings: function RouterLink_HostBindings(rf, ctx) {
		if (rf & 1) ɵɵlistener("click", function RouterLink_click_HostBindingHandler($event) {
			return ctx.onClick($event.button, $event.ctrlKey, $event.shiftKey, $event.altKey, $event.metaKey);
		});
		if (rf & 2) ɵɵattribute("href", ctx.reactiveHref(), ɵɵsanitizeUrlOrResourceUrl)("target", ctx._target());
	},
	inputs: {
		target: "target",
		queryParams: "queryParams",
		fragment: "fragment",
		queryParamsHandling: "queryParamsHandling",
		state: "state",
		info: "info",
		relativeTo: "relativeTo",
		preserveFragment: [
			2,
			"preserveFragment",
			"preserveFragment",
			booleanAttribute
		],
		skipLocationChange: [
			2,
			"skipLocationChange",
			"skipLocationChange",
			booleanAttribute
		],
		replaceUrl: [
			2,
			"replaceUrl",
			"replaceUrl",
			booleanAttribute
		],
		browserUrl: [1, "browserUrl"],
		routerLink: "routerLink"
	},
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterLink, [{
		type: Directive,
		args: [{
			selector: "[routerLink]",
			host: {
				"[attr.href]": "reactiveHref()",
				"[attr.target]": "_target()"
			}
		}]
	}], () => [
		{ type: Router },
		{ type: ActivatedRoute },
		{
			type: void 0,
			decorators: [{
				type: Attribute,
				args: ["tabindex"]
			}]
		},
		{ type: Renderer2 },
		{ type: ElementRef },
		{ type: LocationStrategy }
	], {
		target: [{ type: Input }],
		queryParams: [{ type: Input }],
		fragment: [{ type: Input }],
		queryParamsHandling: [{ type: Input }],
		state: [{ type: Input }],
		info: [{ type: Input }],
		relativeTo: [{ type: Input }],
		preserveFragment: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		skipLocationChange: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		replaceUrl: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		browserUrl: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "browserUrl",
				required: false
			}]
		}],
		routerLink: [{ type: Input }],
		onClick: [{
			type: HostListener,
			args: ["click", [
				"$event.button",
				"$event.ctrlKey",
				"$event.shiftKey",
				"$event.altKey",
				"$event.metaKey"
			]]
		}]
	});
})();
var RouterLinkActive = class {
	get isActive() {
		return this._isActive;
	}
	constructor(router, element, renderer, cdr) {
		_defineProperty(this, "router", void 0);
		_defineProperty(this, "element", void 0);
		_defineProperty(this, "renderer", void 0);
		_defineProperty(this, "cdr", void 0);
		_defineProperty(this, "links", void 0);
		_defineProperty(this, "classes", []);
		_defineProperty(this, "routerEventsSubscription", void 0);
		_defineProperty(this, "linkInputChangesSubscription", void 0);
		_defineProperty(this, "_isActive", false);
		_defineProperty(this, "routerLinkActiveOptions", { exact: false });
		_defineProperty(this, "ariaCurrentWhenActive", void 0);
		_defineProperty(this, "isActiveChange", new EventEmitter());
		_defineProperty(this, "link", inject(RouterLink, { optional: true }));
		this.router = router;
		this.element = element;
		this.renderer = renderer;
		this.cdr = cdr;
		this.routerEventsSubscription = router.events.subscribe((s) => {
			if (s instanceof NavigationEnd) this.update();
		});
	}
	ngAfterContentInit() {
		of(this.links.changes, of(null)).pipe(mergeAll()).subscribe((_) => {
			this.update();
			this.subscribeToEachLinkOnChanges();
		});
	}
	subscribeToEachLinkOnChanges() {
		var _this$linkInputChange;
		(_this$linkInputChange = this.linkInputChangesSubscription) === null || _this$linkInputChange === void 0 || _this$linkInputChange.unsubscribe();
		const allLinkChanges = [...this.links.toArray(), this.link].filter((link) => !!link).map((link) => link.onChanges);
		this.linkInputChangesSubscription = from(allLinkChanges).pipe(mergeAll()).subscribe((link) => {
			if (this._isActive !== this.isLinkActive(this.router)(link)) this.update();
		});
	}
	set routerLinkActive(data) {
		if (data == null) {
			this.classes = [];
			return;
		}
		const classes = Array.isArray(data) ? data : data.split(" ");
		this.classes = classes.filter((c) => !!c);
	}
	ngOnChanges(changes) {
		this.update();
	}
	ngOnDestroy() {
		var _this$linkInputChange2;
		this.routerEventsSubscription.unsubscribe();
		(_this$linkInputChange2 = this.linkInputChangesSubscription) === null || _this$linkInputChange2 === void 0 || _this$linkInputChange2.unsubscribe();
	}
	update() {
		if (!this.links || !this.router.navigated) return;
		if (this.routerLinkActiveOptions === null && !this._isActive) return;
		queueMicrotask(() => {
			const hasActiveLinks = this.hasActiveLinks();
			this.classes.forEach((c) => {
				if (hasActiveLinks) this.renderer.addClass(this.element.nativeElement, c);
				else this.renderer.removeClass(this.element.nativeElement, c);
			});
			if (hasActiveLinks && this.ariaCurrentWhenActive !== void 0) this.renderer.setAttribute(this.element.nativeElement, "aria-current", this.ariaCurrentWhenActive.toString());
			else this.renderer.removeAttribute(this.element.nativeElement, "aria-current");
			if (this._isActive !== hasActiveLinks) {
				this._isActive = hasActiveLinks;
				this.cdr.markForCheck();
				this.isActiveChange.emit(hasActiveLinks);
			}
		});
	}
	isLinkActive(router) {
		var _opts$exact;
		const opts = this.routerLinkActiveOptions;
		if (opts === null) return () => false;
		let options;
		if (opts === void 0) options = _objectSpread2({}, subsetMatchOptions);
		else if (isActiveMatchOptions(opts)) options = opts;
		else if ((_opts$exact = opts.exact) !== null && _opts$exact !== void 0 ? _opts$exact : false) options = _objectSpread2({}, exactMatchOptions);
		else options = _objectSpread2({}, subsetMatchOptions);
		return (link) => {
			const urlTree = link.urlTree;
			return urlTree ? untracked(isActive(urlTree, router, options)) : false;
		};
	}
	hasActiveLinks() {
		const isActiveCheckFn = this.isLinkActive(this.router);
		return this.link && isActiveCheckFn(this.link) || this.links.some(isActiveCheckFn);
	}
};
_RouterLinkActive = RouterLinkActive;
_defineProperty(RouterLinkActive, "ɵfac", function RouterLinkActive_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouterLinkActive)(ɵɵdirectiveInject(Router), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ChangeDetectorRef));
});
_defineProperty(RouterLinkActive, "ɵdir", /* @__PURE__ */ ɵɵdefineDirective({
	type: _RouterLinkActive,
	selectors: [[
		"",
		"routerLinkActive",
		""
	]],
	contentQueries: function RouterLinkActive_ContentQueries(rf, ctx, dirIndex) {
		if (rf & 1) ɵɵcontentQuery(dirIndex, RouterLink, 5);
		if (rf & 2) {
			let _t;
			ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.links = _t);
		}
	},
	inputs: {
		routerLinkActiveOptions: "routerLinkActiveOptions",
		ariaCurrentWhenActive: "ariaCurrentWhenActive",
		routerLinkActive: "routerLinkActive"
	},
	outputs: { isActiveChange: "isActiveChange" },
	exportAs: ["routerLinkActive"],
	features: [ɵɵNgOnChangesFeature]
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterLinkActive, [{
		type: Directive,
		args: [{
			selector: "[routerLinkActive]",
			exportAs: "routerLinkActive"
		}]
	}], () => [
		{ type: Router },
		{ type: ElementRef },
		{ type: Renderer2 },
		{ type: ChangeDetectorRef }
	], {
		links: [{
			type: ContentChildren,
			args: [RouterLink, { descendants: true }]
		}],
		routerLinkActiveOptions: [{ type: Input }],
		ariaCurrentWhenActive: [{ type: Input }],
		isActiveChange: [{ type: Output }],
		routerLinkActive: [{ type: Input }]
	});
})();
function isActiveMatchOptions(options) {
	const o = options;
	return !!(o.paths || o.matrixParams || o.queryParams || o.fragment);
}
var PreloadingStrategy = class {};
var PreloadAllModules = class {
	preload(route, fn) {
		return fn().pipe(catchError(() => of(null)));
	}
};
_PreloadAllModules = PreloadAllModules;
_defineProperty(PreloadAllModules, "ɵfac", function PreloadAllModules_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _PreloadAllModules)();
});
_defineProperty(PreloadAllModules, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _PreloadAllModules,
	factory: _PreloadAllModules.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PreloadAllModules, [{ type: Service }], null, null);
})();
var NoPreloading = class {
	preload(route, fn) {
		return of(null);
	}
};
_NoPreloading = NoPreloading;
_defineProperty(NoPreloading, "ɵfac", function NoPreloading_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NoPreloading)();
});
_defineProperty(NoPreloading, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _NoPreloading,
	factory: _NoPreloading.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NoPreloading, [{ type: Service }], null, null);
})();
var RouterPreloader = class {
	constructor(router, injector, preloadingStrategy, loader) {
		_defineProperty(this, "router", void 0);
		_defineProperty(this, "injector", void 0);
		_defineProperty(this, "preloadingStrategy", void 0);
		_defineProperty(this, "loader", void 0);
		_defineProperty(this, "subscription", void 0);
		this.router = router;
		this.injector = injector;
		this.preloadingStrategy = preloadingStrategy;
		this.loader = loader;
	}
	setUpPreloading() {
		this.subscription = this.router.events.pipe(filter((e) => e instanceof NavigationEnd), concatMap(() => this.preload())).subscribe(() => {});
	}
	preload() {
		return this.processRoutes(this.injector, this.router.config);
	}
	ngOnDestroy() {
		var _this$subscription;
		(_this$subscription = this.subscription) === null || _this$subscription === void 0 || _this$subscription.unsubscribe();
	}
	processRoutes(injector, routes) {
		const res = [];
		for (const route of routes) {
			var _route$_injector, _route$_loadedInjecto;
			if (route.providers && !route._injector) route._injector = createEnvironmentInjector(route.providers, injector, typeof ngDevMode === "undefined" || ngDevMode ? `Route: ${route.path}` : "");
			const injectorForCurrentRoute = (_route$_injector = route._injector) !== null && _route$_injector !== void 0 ? _route$_injector : injector;
			if (route._loadedNgModuleFactory && !route._loadedInjector) route._loadedInjector = route._loadedNgModuleFactory.create(injectorForCurrentRoute).injector;
			const injectorForChildren = (_route$_loadedInjecto = route._loadedInjector) !== null && _route$_loadedInjecto !== void 0 ? _route$_loadedInjecto : injectorForCurrentRoute;
			if (route.loadChildren && !route._loadedRoutes && route.canLoad === void 0 || route.loadComponent && !route._loadedComponent) res.push(this.preloadConfig(injectorForCurrentRoute, route));
			if (route.children || route._loadedRoutes) {
				var _route$children;
				res.push(this.processRoutes(injectorForChildren, (_route$children = route.children) !== null && _route$children !== void 0 ? _route$children : route._loadedRoutes));
			}
		}
		return from(res).pipe(mergeAll());
	}
	preloadConfig(injector, route) {
		return this.preloadingStrategy.preload(route, () => {
			if (injector.destroyed) return of(null);
			let loadedChildren$;
			if (route.loadChildren && route.canLoad === void 0) loadedChildren$ = from(this.loader.loadChildren(injector, route));
			else loadedChildren$ = of(null);
			const recursiveLoadChildren$ = loadedChildren$.pipe(mergeMap((config) => {
				var _config$injector;
				if (config === null) return of(void 0);
				route._loadedRoutes = config.routes;
				route._loadedInjector = config.injector;
				route._loadedNgModuleFactory = config.factory;
				return this.processRoutes((_config$injector = config.injector) !== null && _config$injector !== void 0 ? _config$injector : injector, config.routes);
			}));
			if (route.loadComponent && !route._loadedComponent) return from([recursiveLoadChildren$, this.loader.loadComponent(injector, route)]).pipe(mergeAll());
			else return recursiveLoadChildren$;
		});
	}
};
_RouterPreloader = RouterPreloader;
_defineProperty(RouterPreloader, "ɵfac", function RouterPreloader_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouterPreloader)(ɵɵinject(Router), ɵɵinject(EnvironmentInjector), ɵɵinject(PreloadingStrategy), ɵɵinject(RouterConfigLoader));
});
_defineProperty(RouterPreloader, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _RouterPreloader,
	factory: _RouterPreloader.ɵfac,
	providedIn: "root"
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterPreloader, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [
		{ type: Router },
		{ type: EnvironmentInjector },
		{ type: PreloadingStrategy },
		{ type: RouterConfigLoader }
	], null);
})();
var ROUTER_SCROLLER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Router Scroller" : "");
var RouterScroller = class {
	constructor(options) {
		var _inject, _this$options2, _this$options3;
		_defineProperty(this, "options", void 0);
		_defineProperty(this, "routerEventsSubscription", void 0);
		_defineProperty(this, "scrollEventsSubscription", void 0);
		_defineProperty(this, "lastId", 0);
		_defineProperty(this, "lastSource", IMPERATIVE_NAVIGATION);
		_defineProperty(this, "restoredId", 0);
		_defineProperty(this, "store", {});
		_defineProperty(this, "isHydrating", (_inject = inject(IS_HYDRATION_DOM_REUSE_ENABLED, { optional: true })) !== null && _inject !== void 0 ? _inject : false);
		_defineProperty(this, "urlSerializer", inject(UrlSerializer));
		_defineProperty(this, "zone", inject(NgZone));
		_defineProperty(this, "viewportScroller", inject(ViewportScroller));
		_defineProperty(this, "transitions", inject(NavigationTransitions));
		this.options = options;
		(_this$options2 = this.options).scrollPositionRestoration || (_this$options2.scrollPositionRestoration = "disabled");
		(_this$options3 = this.options).anchorScrolling || (_this$options3.anchorScrolling = "disabled");
		if (this.isHydrating) inject(ApplicationRef).whenStable().then(() => {
			this.isHydrating = false;
		});
	}
	init() {
		if (this.options.scrollPositionRestoration !== "disabled") this.viewportScroller.setHistoryScrollRestoration("manual");
		this.routerEventsSubscription = this.createScrollEvents();
		this.scrollEventsSubscription = this.consumeScrollEvents();
	}
	createScrollEvents() {
		return this.transitions.events.subscribe((e) => {
			if (e instanceof NavigationStart) {
				this.store[this.lastId] = this.viewportScroller.getScrollPosition();
				this.lastSource = e.navigationTrigger;
				this.restoredId = e.restoredState ? e.restoredState.navigationId : 0;
			} else if (e instanceof NavigationEnd) {
				this.lastId = e.id;
				this.scheduleScrollEvent(e, this.urlSerializer.parse(e.urlAfterRedirects).fragment);
			} else if (e instanceof NavigationSkipped && e.code === NavigationSkippedCode.IgnoredSameUrlNavigation) {
				this.lastSource = void 0;
				this.restoredId = 0;
				this.scheduleScrollEvent(e, this.urlSerializer.parse(e.url).fragment);
			}
		});
	}
	consumeScrollEvents() {
		return this.transitions.events.subscribe((e) => {
			if (!(e instanceof Scroll) || e.scrollBehavior === "manual") return;
			const instantScroll = { behavior: "instant" };
			if (e.position) {
				if (this.options.scrollPositionRestoration === "top") this.viewportScroller.scrollToPosition([0, 0], instantScroll);
				else if (this.options.scrollPositionRestoration === "enabled") this.viewportScroller.scrollToPosition(e.position, instantScroll);
			} else if (e.anchor && this.options.anchorScrolling === "enabled") this.viewportScroller.scrollToAnchor(e.anchor);
			else if (this.options.scrollPositionRestoration !== "disabled") this.viewportScroller.scrollToPosition([0, 0]);
		});
	}
	scheduleScrollEvent(routerEvent, anchor) {
		var _this = this;
		var _untracked;
		if (this.isHydrating) return;
		const scroll = (_untracked = untracked(this.transitions.currentNavigation)) === null || _untracked === void 0 ? void 0 : _untracked.extras.scroll;
		this.zone.runOutsideAngular(_asyncToGenerator(function* () {
			yield new Promise((resolve) => {
				setTimeout(resolve);
				if (typeof requestAnimationFrame !== "undefined") requestAnimationFrame(resolve);
			});
			_this.zone.run(() => {
				_this.transitions.events.next(new Scroll(routerEvent, _this.lastSource === "popstate" ? _this.store[_this.restoredId] : null, anchor, scroll));
			});
		}));
	}
	ngOnDestroy() {
		var _this$routerEventsSub, _this$scrollEventsSub;
		(_this$routerEventsSub = this.routerEventsSubscription) === null || _this$routerEventsSub === void 0 || _this$routerEventsSub.unsubscribe();
		(_this$scrollEventsSub = this.scrollEventsSubscription) === null || _this$scrollEventsSub === void 0 || _this$scrollEventsSub.unsubscribe();
	}
};
_RouterScroller = RouterScroller;
_defineProperty(RouterScroller, "ɵfac", function RouterScroller_Factory(__ngFactoryType__) {
	ɵɵinvalidFactory();
});
_defineProperty(RouterScroller, "ɵprov", /* @__PURE__ */ ɵɵdefineInjectable({
	token: _RouterScroller,
	factory: _RouterScroller.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterScroller, [{ type: Injectable }], () => [{ type: void 0 }], null);
})();
function getLoadedRoutes(route) {
	return route._loadedRoutes;
}
function getRouterInstance(injector) {
	return injector.get(Router, null, { optional: true });
}
function navigateByUrl(router, url) {
	if (!(router instanceof Router)) throw new Error("The provided router is not an Angular Router.");
	return router.navigateByUrl(url);
}
var NavigationStateManager = class extends StateManager {
	get registered() {
		return this.nonRouterEntryChangeListener !== void 0 && !this.nonRouterEntryChangeListener.closed;
	}
	constructor() {
		var _this$location$prepar, _this$location$prepar2, _this$location;
		super();
		_defineProperty(this, "injector", inject(EnvironmentInjector));
		_defineProperty(this, "navigation", inject(PlatformNavigation));
		_defineProperty(this, "inMemoryScrollingEnabled", inject(ROUTER_SCROLLER, { optional: true }) !== null);
		_defineProperty(this, "base", new URL(inject(PlatformLocation).href).origin);
		_defineProperty(this, "appRootUrl", new URL((_this$location$prepar = (_this$location$prepar2 = (_this$location = this.location).prepareExternalUrl) === null || _this$location$prepar2 === void 0 ? void 0 : _this$location$prepar2.call(_this$location, "/")) !== null && _this$location$prepar !== void 0 ? _this$location$prepar : "/", this.base));
		_defineProperty(this, "precommitHandlerSupported", inject(PRECOMMIT_HANDLER_SUPPORTED));
		_defineProperty(this, "activeHistoryEntry", this.navigation.currentEntry);
		_defineProperty(this, "currentNavigation", {});
		_defineProperty(this, "nonRouterCurrentEntryChangeSubject", new Subject());
		_defineProperty(this, "nonRouterEntryChangeListener", void 0);
		const navigateListener = (event) => {
			this.handleNavigate(event);
		};
		this.navigation.addEventListener("navigate", navigateListener);
		inject(DestroyRef).onDestroy(() => this.navigation.removeEventListener("navigate", navigateListener));
	}
	registerNonRouterCurrentEntryChangeListener(listener) {
		this.activeHistoryEntry = this.navigation.currentEntry;
		this.nonRouterEntryChangeListener = this.nonRouterCurrentEntryChangeSubject.subscribe(({ path, state }) => {
			listener(path, state, "popstate", !this.precommitHandlerSupported ? { replaceUrl: true } : {});
		});
		return this.nonRouterEntryChangeListener;
	}
	handleRouterEvent(e, transition) {
		var _this2 = this;
		return _asyncToGenerator(function* () {
			_this2.currentNavigation = _objectSpread2(_objectSpread2({}, _this2.currentNavigation), {}, { routerTransition: transition });
			if (e instanceof NavigationStart) {
				_this2.updateStateMemento();
				if (_this2.precommitHandlerSupported) _this2.maybeCreateNavigationForTransition(transition);
			} else if (e instanceof NavigationSkipped) {
				_this2.finishNavigation();
				_this2.commitTransition(transition);
			} else if (e instanceof BeforeRoutesRecognized) transition.routesRecognizeHandler.deferredHandle = new Promise(function() {
				var _ref = _asyncToGenerator(function* (resolve) {
					if (_this2.urlUpdateStrategy === "eager") try {
						var _this$currentNavigati, _this$currentNavigati2;
						_this2.maybeCreateNavigationForTransition(transition);
						yield (_this$currentNavigati = (_this$currentNavigati2 = _this2.currentNavigation).commitUrl) === null || _this$currentNavigati === void 0 ? void 0 : _this$currentNavigati.call(_this$currentNavigati2);
					} catch (_unused) {
						return;
					}
					resolve();
				});
				return function(_x) {
					return _ref.apply(this, arguments);
				};
			}());
			else if (e instanceof BeforeActivateRoutes) transition.beforeActivateHandler.deferredHandle = new Promise(function() {
				var _ref2 = _asyncToGenerator(function* (resolve) {
					if (_this2.urlUpdateStrategy === "deferred") try {
						var _this$currentNavigati3, _this$currentNavigati4;
						_this2.maybeCreateNavigationForTransition(transition);
						yield (_this$currentNavigati3 = (_this$currentNavigati4 = _this2.currentNavigation).commitUrl) === null || _this$currentNavigati3 === void 0 ? void 0 : _this$currentNavigati3.call(_this$currentNavigati4);
					} catch (_unused2) {
						return;
					}
					_this2.commitTransition(transition);
					resolve();
				});
				return function(_x2) {
					return _ref2.apply(this, arguments);
				};
			}());
			else if (e instanceof NavigationCancel || e instanceof NavigationError) {
				if (e instanceof NavigationCancel && e.code === NavigationCancellationCode.Redirect && !!_this2.currentNavigation.commitUrl) return;
				_this2.cancel(transition, e);
			} else if (e instanceof NavigationEnd) {
				const { resolveHandler, removeAbortListener } = _this2.currentNavigation;
				_this2.currentNavigation = {};
				removeAbortListener === null || removeAbortListener === void 0 || removeAbortListener();
				_this2.activeHistoryEntry = _this2.navigation.currentEntry;
				afterNextRender({ read: () => resolveHandler === null || resolveHandler === void 0 ? void 0 : resolveHandler() }, { injector: _this2.injector });
			}
		})();
	}
	maybeCreateNavigationForTransition(transition) {
		var _this$currentNavigati5, _this$currentNavigati6;
		const { navigationEvent, commitUrl } = this.currentNavigation;
		if (commitUrl || navigationEvent && navigationEvent.navigationType === "traverse" && this.eventAndRouterDestinationsMatch(navigationEvent, transition)) return;
		(_this$currentNavigati5 = (_this$currentNavigati6 = this.currentNavigation).removeAbortListener) === null || _this$currentNavigati5 === void 0 || _this$currentNavigati5.call(_this$currentNavigati6);
		const path = this.createBrowserPath(transition);
		this.navigate(path, transition);
	}
	navigate(internalPath, transition) {
		const path = transition.extras.skipLocationChange ? this.navigation.currentEntry.url : this.location.prepareExternalUrl(internalPath);
		const state = _objectSpread2(_objectSpread2({}, transition.extras.state), this.generateNgRouterState(transition));
		const info = { ɵrouterInfo: { intercept: true } };
		if (!this.navigation.transition && this.currentNavigation.navigationEvent) transition.extras.replaceUrl = false;
		const history = this.location.isCurrentPathEqualTo(path) || transition.extras.replaceUrl || transition.extras.skipLocationChange ? "replace" : "push";
		handleResultRejections(this.navigation.navigate(path, {
			state,
			history,
			info
		}));
	}
	finishNavigation() {
		var _this$currentNavigati7, _this$currentNavigati8, _this$currentNavigati9, _this$currentNavigati10;
		(_this$currentNavigati7 = (_this$currentNavigati8 = this.currentNavigation).commitUrl) === null || _this$currentNavigati7 === void 0 || _this$currentNavigati7.call(_this$currentNavigati8);
		(_this$currentNavigati9 = this.currentNavigation) === null || _this$currentNavigati9 === void 0 || (_this$currentNavigati10 = _this$currentNavigati9.resolveHandler) === null || _this$currentNavigati10 === void 0 || _this$currentNavigati10.call(_this$currentNavigati9);
		this.currentNavigation = {};
	}
	cancel(transition, cause) {
		var _this3 = this;
		return _asyncToGenerator(function* () {
			var _this$currentNavigati11, _this$currentNavigati12;
			(_this$currentNavigati11 = (_this$currentNavigati12 = _this3.currentNavigation).rejectNavigateEvent) === null || _this$currentNavigati11 === void 0 || _this$currentNavigati11.call(_this$currentNavigati12);
			const clearedState = {};
			_this3.currentNavigation = clearedState;
			if (isRedirectingEvent(cause)) return;
			const isTraversalReset = _this3.canceledNavigationResolution === "computed" && _this3.navigation.currentEntry.key !== _this3.activeHistoryEntry.key;
			_this3.resetInternalState(transition.finalUrl, isTraversalReset);
			if (_this3.navigation.currentEntry.id === _this3.activeHistoryEntry.id) return;
			if (cause instanceof NavigationCancel && cause.code === NavigationCancellationCode.Aborted) {
				yield Promise.resolve();
				if (_this3.currentNavigation !== clearedState) return;
			}
			if (isTraversalReset) handleResultRejections(_this3.navigation.traverseTo(_this3.activeHistoryEntry.key, { info: { ɵrouterInfo: { intercept: false } } }));
			else {
				const internalPath = _this3.urlSerializer.serialize(_this3.getCurrentUrlTree());
				const pathOrUrl = _this3.location.prepareExternalUrl(internalPath);
				handleResultRejections(_this3.navigation.navigate(pathOrUrl, {
					state: _this3.activeHistoryEntry.getState(),
					history: "replace",
					info: { ɵrouterInfo: { intercept: false } }
				}));
			}
		})();
	}
	resetInternalState(finalUrl, traversalReset) {
		this.routerState = this.stateMemento.routerState;
		this.currentUrlTree = this.stateMemento.currentUrlTree;
		this.rawUrlTree = traversalReset ? this.stateMemento.rawUrlTree : this.urlHandlingStrategy.merge(this.currentUrlTree, finalUrl !== null && finalUrl !== void 0 ? finalUrl : this.rawUrlTree);
	}
	handleNavigate(event) {
		var _this4 = this;
		var _event$info, _this$currentNavigati15, _this$currentNavigati16;
		if (!event.canIntercept || event.navigationType === "reload") return;
		const routerInfo = event === null || event === void 0 || (_event$info = event.info) === null || _event$info === void 0 ? void 0 : _event$info.ɵrouterInfo;
		if (routerInfo && !routerInfo.intercept) return;
		const isTriggeredByRouterTransition = !!routerInfo;
		if (!isTriggeredByRouterTransition) {
			var _this$currentNavigati13;
			const { pathname: destPathname, origin: destOrigin } = new URL(event.destination.url);
			const { pathname: rootPathname, origin: appOrigin } = this.appRootUrl;
			const rootPath = rootPathname.endsWith("/") ? rootPathname : rootPathname + "/";
			if (destOrigin !== appOrigin || destPathname !== rootPathname && !destPathname.startsWith(rootPath)) return;
			(_this$currentNavigati13 = this.currentNavigation.routerTransition) === null || _this$currentNavigati13 === void 0 || _this$currentNavigati13.abort();
			if (!this.registered) {
				this.finishNavigation();
				return;
			}
		}
		this.currentNavigation = _objectSpread2({}, this.currentNavigation);
		this.currentNavigation.navigationEvent = event;
		const abortHandler = () => {
			var _this$currentNavigati14;
			(_this$currentNavigati14 = this.currentNavigation.routerTransition) === null || _this$currentNavigati14 === void 0 || _this$currentNavigati14.abort();
		};
		event.signal.addEventListener("abort", abortHandler);
		this.currentNavigation.removeAbortListener = () => event.signal.removeEventListener("abort", abortHandler);
		const interceptOptions = { scroll: this.inMemoryScrollingEnabled ? "manual" : (_this$currentNavigati15 = (_this$currentNavigati16 = this.currentNavigation.routerTransition) === null || _this$currentNavigati16 === void 0 ? void 0 : _this$currentNavigati16.extras.scroll) !== null && _this$currentNavigati15 !== void 0 ? _this$currentNavigati15 : "after-transition" };
		const { promise: handlerPromise, resolve: resolveHandler, reject: rejectHandler } = promiseWithResolvers();
		const { promise: precommitHandlerPromise, resolve: resolvePrecommitHandler, reject: rejectPrecommitHandler } = promiseWithResolvers();
		this.currentNavigation.rejectNavigateEvent = () => {
			event.signal.removeEventListener("abort", abortHandler);
			rejectPrecommitHandler();
			rejectHandler();
		};
		this.currentNavigation.resolveHandler = () => {
			var _this$currentNavigati17, _this$currentNavigati18;
			(_this$currentNavigati17 = (_this$currentNavigati18 = this.currentNavigation).removeAbortListener) === null || _this$currentNavigati17 === void 0 || _this$currentNavigati17.call(_this$currentNavigati18);
			resolveHandler();
		};
		handlerPromise.catch(() => {});
		precommitHandlerPromise.catch(() => {});
		interceptOptions.handler = () => handlerPromise;
		if (this.deferredCommitSupported(event)) {
			const redirect = new Promise((resolve) => {
				interceptOptions.precommitHandler = (controller) => {
					var _this$navigation$tran;
					if (((_this$navigation$tran = this.navigation.transition) === null || _this$navigation$tran === void 0 ? void 0 : _this$navigation$tran.navigationType) === "traverse") resolve(() => {});
					else resolve(controller.redirect.bind(controller));
					return precommitHandlerPromise;
				};
			});
			this.currentNavigation.commitUrl = _asyncToGenerator(function* () {
				var _this$navigation$tran2;
				_this4.currentNavigation.commitUrl = void 0;
				const transition = _this4.currentNavigation.routerTransition;
				if (transition && !transition.extras.skipLocationChange) {
					const internalPath = _this4.createBrowserPath(transition);
					const history = _this4.location.isCurrentPathEqualTo(internalPath) || !!transition.extras.replaceUrl ? "replace" : "push";
					const state = _objectSpread2(_objectSpread2({}, transition.extras.state), _this4.generateNgRouterState(transition));
					const pathOrUrl = _this4.location.prepareExternalUrl(internalPath);
					(yield redirect)(pathOrUrl, {
						state,
						history
					});
				}
				resolvePrecommitHandler();
				return yield (_this$navigation$tran2 = _this4.navigation.transition) === null || _this$navigation$tran2 === void 0 ? void 0 : _this$navigation$tran2.committed;
			});
		}
		event.intercept(interceptOptions);
		if (!isTriggeredByRouterTransition) this.handleNavigateEventTriggeredOutsideRouterAPIs(event);
	}
	handleNavigateEventTriggeredOutsideRouterAPIs(event) {
		const path = event.destination.url.substring(this.appRootUrl.href.length - 1);
		const state = event.destination.getState();
		this.nonRouterCurrentEntryChangeSubject.next({
			path,
			state
		});
	}
	eventAndRouterDestinationsMatch(navigateEvent, transition) {
		const internalPath = this.createBrowserPath(transition);
		const eventDestination = new URL(navigateEvent.destination.url);
		const routerDestination = new URL(this.location.prepareExternalUrl(internalPath), eventDestination.origin);
		eventDestination.searchParams.sort();
		routerDestination.searchParams.sort();
		const { pathname: destPathname, search: destSearch, hash: hashDest } = routerDestination;
		const { pathname: eventDestPathname, search: eventDestSearch, hash: eventDestHash } = eventDestination;
		return destSearch === eventDestSearch && hashDest === eventDestHash && Location.stripTrailingSlash(destPathname) === Location.stripTrailingSlash(eventDestPathname);
	}
	generateNgRouterState(transition) {
		return _objectSpread2(_objectSpread2({}, this.routerUrlState(transition)), {}, { navigationId: transition.id });
	}
	deferredCommitSupported(event) {
		return this.precommitHandlerSupported && event.cancelable;
	}
};
_NavigationStateManager = NavigationStateManager;
_defineProperty(NavigationStateManager, "ɵfac", function NavigationStateManager_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _NavigationStateManager)();
});
_defineProperty(NavigationStateManager, "ɵprov", /* @__PURE__ */ ɵɵdefineService({
	token: _NavigationStateManager,
	factory: _NavigationStateManager.ɵfac
}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NavigationStateManager, [{ type: Service }], () => [], null);
})();
function handleResultRejections(result) {
	var _result$finished, _result$committed;
	(_result$finished = result.finished) === null || _result$finished === void 0 || _result$finished.catch(() => {});
	(_result$committed = result.committed) === null || _result$committed === void 0 || _result$committed.catch(() => {});
	return result;
}
function setupActivatedRouteInjectors() {
	return tap(({ newlyCreatedRoutes, targetRouterState }) => {
		if (!newlyCreatedRoutes || !targetRouterState) return;
		const traverse = (stateNode) => {
			const route = stateNode.value;
			if (route) processRoute(route, newlyCreatedRoutes);
			for (const childState of stateNode.children) traverse(childState);
		};
		traverse(targetRouterState._root);
	});
}
function processRoute(route, newlyCreatedRoutes) {
	var _route$routeConfig;
	if (!(route === null || route === void 0 || (_route$routeConfig = route.routeConfig) === null || _route$routeConfig === void 0 ? void 0 : _route$routeConfig.ɵUseActivatedRouteInjector)) return;
	if (newlyCreatedRoutes.has(route)) setupNewActivatedRouteInjector(route._futureSnapshot, route);
}
function setupNewActivatedRouteInjector(snapshot, route) {
	if (ngDevMode && !!route._localInjector) throw new Error("invalid state: _localInjector should not exist on newly created ActivatedRoute yet");
	route._localInjector = createEnvironmentInjector([], snapshot._environmentInjector);
}
function provideRouter(routes, ...features) {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		publishNonCoreGlobalUtil("ɵgetLoadedRoutes", getLoadedRoutes);
		publishNonCoreGlobalUtil("ɵgetRouterInstance", getRouterInstance);
		publishNonCoreGlobalUtil("ɵnavigateByUrl", navigateByUrl);
	}
	return makeEnvironmentProviders([
		{
			provide: ROUTES,
			multi: true,
			useValue: routes
		},
		{
			provide: ActivatedRoute,
			useFactory: rootRoute
		},
		{
			provide: APP_BOOTSTRAP_LISTENER,
			multi: true,
			useFactory: getBootstrapListener
		},
		features.map((feature) => feature.ɵproviders)
	]);
}
function rootRoute() {
	return inject(Router).routerState.root;
}
function routerFeature(kind, providers) {
	return {
		ɵkind: kind,
		ɵproviders: providers
	};
}
function withInMemoryScrolling(options = {}) {
	return routerFeature(4, [{
		provide: ROUTER_SCROLLER,
		useFactory: () => new RouterScroller(options)
	}]);
}
function withExperimentalPlatformNavigation() {
	const devModeLocationCheck = typeof ngDevMode === "undefined" || ngDevMode ? [provideEnvironmentInitializer(() => {
		const locationInstance = inject(Location);
		if (!(locationInstance instanceof NavigationAdapterForLocation)) {
			const locationConstructorName = locationInstance.constructor.name;
			let message = `'withExperimentalPlatformNavigation' provides a 'Location' implementation that ensures navigation APIs are consistently used. An instance of ${locationConstructorName} was found instead.`;
			if (locationConstructorName === "SpyLocation") message += ` One of 'RouterTestingModule' or 'provideLocationMocks' was likely used. 'withExperimentalPlatformNavigation' does not work with these because they override the Location implementation.`;
			throw new Error(message);
		}
	})] : [];
	return routerFeature(11, [
		{
			provide: StateManager,
			useExisting: NavigationStateManager
		},
		{
			provide: Location,
			useClass: NavigationAdapterForLocation
		},
		devModeLocationCheck
	]);
}
function getBootstrapListener() {
	const injector = inject(Injector);
	return (bootstrappedComponentRef) => {
		var _injector$get, _injector$get2;
		const ref = injector.get(ApplicationRef);
		if (bootstrappedComponentRef !== ref.components[0]) return;
		const router = injector.get(Router);
		const bootstrapDone = injector.get(BOOTSTRAP_DONE);
		if (injector.get(INITIAL_NAVIGATION) === 1) router.initialNavigation();
		(_injector$get = injector.get(ROUTER_PRELOADER, null, { optional: true })) === null || _injector$get === void 0 || _injector$get.setUpPreloading();
		(_injector$get2 = injector.get(ROUTER_SCROLLER, null, { optional: true })) === null || _injector$get2 === void 0 || _injector$get2.init();
		router.resetRootComponentType(ref.componentTypes[0]);
		if (!bootstrapDone.closed) {
			bootstrapDone.next();
			bootstrapDone.complete();
			bootstrapDone.unsubscribe();
		}
	};
}
var BOOTSTRAP_DONE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "bootstrap done indicator" : "", { factory: () => {
	return new Subject();
} });
var INITIAL_NAVIGATION = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "initial navigation" : "", { factory: () => 1 });
function withEnabledBlockingInitialNavigation() {
	return routerFeature(2, [
		{
			provide: IS_ENABLED_BLOCKING_INITIAL_NAVIGATION,
			useValue: true
		},
		{
			provide: INITIAL_NAVIGATION,
			useValue: 0
		},
		provideAppInitializer(() => {
			const injector = inject(Injector);
			return injector.get(LOCATION_INITIALIZED, Promise.resolve()).then(() => {
				return new Promise((resolve) => {
					const router = injector.get(Router);
					const bootstrapDone = injector.get(BOOTSTRAP_DONE);
					afterNextNavigation(router, () => {
						resolve(true);
					});
					injector.get(NavigationTransitions).afterPreactivation = () => {
						resolve(true);
						return bootstrapDone.closed ? of(void 0) : bootstrapDone;
					};
					router.initialNavigation();
				});
			});
		})
	]);
}
function withDisabledInitialNavigation() {
	return routerFeature(3, [provideAppInitializer(() => {
		inject(Router).setUpLocationChangeListener();
	}), {
		provide: INITIAL_NAVIGATION,
		useValue: 2
	}]);
}
function withDebugTracing() {
	let providers = [];
	if (typeof ngDevMode === "undefined" || ngDevMode) providers = [{
		provide: ENVIRONMENT_INITIALIZER,
		multi: true,
		useFactory: () => {
			const router = inject(Router);
			return () => router.events.subscribe((e) => {
				var _console$group, _console, _console$groupEnd, _console2;
				(_console$group = (_console = console).group) === null || _console$group === void 0 || _console$group.call(_console, `Router Event: ${e.constructor.name}`);
				console.log(stringifyEvent(e));
				console.log(e);
				(_console$groupEnd = (_console2 = console).groupEnd) === null || _console$groupEnd === void 0 || _console$groupEnd.call(_console2);
			});
		}
	}];
	else providers = [];
	return routerFeature(1, providers);
}
var ROUTER_PRELOADER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "router preloader" : "");
function withPreloading(preloadingStrategy) {
	return routerFeature(0, [{
		provide: ROUTER_PRELOADER,
		useExisting: RouterPreloader
	}, {
		provide: PreloadingStrategy,
		useExisting: preloadingStrategy
	}]);
}
function withRouterConfig(options) {
	return routerFeature(5, [{
		provide: ROUTER_CONFIGURATION,
		useValue: options
	}]);
}
function withHashLocation() {
	return routerFeature(6, [{
		provide: LocationStrategy,
		useClass: HashLocationStrategy
	}]);
}
function withNavigationErrorHandler(handler) {
	return routerFeature(7, [{
		provide: NAVIGATION_ERROR_HANDLER,
		useValue: handler
	}]);
}
function withExperimentalAutoCleanupInjectors() {
	return routerFeature(10, [{
		provide: ROUTE_INJECTOR_CLEANUP,
		useValue: routeInjectorCleanup
	}]);
}
function withComponentInputBinding(options = {}) {
	return routerFeature(8, [{
		provide: INPUT_BINDER,
		useFactory: () => new RoutedComponentInputBinder(options)
	}]);
}
function withViewTransitions(options) {
	performanceMarkFeature("NgRouterViewTransitions");
	return routerFeature(9, [{
		provide: CREATE_VIEW_TRANSITION,
		useValue: createViewTransition
	}, {
		provide: VIEW_TRANSITION_OPTIONS,
		useValue: _objectSpread2({ skipNextTransition: !!(options === null || options === void 0 ? void 0 : options.skipInitialTransition) }, options)
	}]);
}
function withActivatedRouteInjectors() {
	return routerFeature(9, [{
		provide: ACTIVATED_ROUTE_INJECTOR_FEATURE,
		useValue: { operator: setupActivatedRouteInjectors }
	}]);
}
var ROUTER_DIRECTIVES = [
	RouterOutlet,
	RouterLink,
	RouterLinkActive,
	ɵEmptyOutletComponent
];
var ROUTER_FORROOT_GUARD = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "router duplicate forRoot guard" : "");
var ROUTER_PROVIDERS = [
	Location,
	{
		provide: UrlSerializer,
		useClass: DefaultUrlSerializer
	},
	Router,
	ChildrenOutletContexts,
	{
		provide: ActivatedRoute,
		useFactory: rootRoute
	},
	RouterConfigLoader
];
var RouterModule = class RouterModule {
	constructor() {
		if (typeof ngDevMode === "undefined" || ngDevMode) inject(ROUTER_FORROOT_GUARD, { optional: true });
	}
	static forRoot(routes, config) {
		return {
			ngModule: RouterModule,
			providers: [
				ROUTER_PROVIDERS,
				typeof ngDevMode === "undefined" || ngDevMode ? (config === null || config === void 0 ? void 0 : config.enableTracing) ? withDebugTracing().ɵproviders : [] : [],
				{
					provide: ROUTES,
					multi: true,
					useValue: routes
				},
				typeof ngDevMode === "undefined" || ngDevMode ? {
					provide: ROUTER_FORROOT_GUARD,
					useFactory: provideForRootGuard
				} : [],
				(config === null || config === void 0 ? void 0 : config.errorHandler) ? {
					provide: NAVIGATION_ERROR_HANDLER,
					useValue: config.errorHandler
				} : [],
				{
					provide: ROUTER_CONFIGURATION,
					useValue: config ? config : {}
				},
				(config === null || config === void 0 ? void 0 : config.useHash) ? provideHashLocationStrategy() : providePathLocationStrategy(),
				provideRouterScroller(),
				(config === null || config === void 0 ? void 0 : config.preloadingStrategy) ? withPreloading(config.preloadingStrategy).ɵproviders : [],
				(config === null || config === void 0 ? void 0 : config.initialNavigation) ? provideInitialNavigation(config) : [],
				(config === null || config === void 0 ? void 0 : config.bindToComponentInputs) ? withComponentInputBinding(typeof config.bindToComponentInputs === "object" ? config.bindToComponentInputs : {}).ɵproviders : [],
				(config === null || config === void 0 ? void 0 : config.enableViewTransitions) ? withViewTransitions().ɵproviders : [],
				provideRouterInitializer()
			]
		};
	}
	static forChild(routes) {
		return {
			ngModule: RouterModule,
			providers: [{
				provide: ROUTES,
				multi: true,
				useValue: routes
			}]
		};
	}
};
_RouterModule = RouterModule;
_defineProperty(RouterModule, "ɵfac", function RouterModule_Factory(__ngFactoryType__) {
	return new (__ngFactoryType__ || _RouterModule)();
});
_defineProperty(RouterModule, "ɵmod", /* @__PURE__ */ ɵɵdefineNgModule({
	type: _RouterModule,
	imports: [
		RouterOutlet,
		RouterLink,
		RouterLinkActive,
		ɵEmptyOutletComponent
	],
	exports: [
		RouterOutlet,
		RouterLink,
		RouterLinkActive,
		ɵEmptyOutletComponent
	]
}));
_defineProperty(RouterModule, "ɵinj", /* @__PURE__ */ ɵɵdefineInjector({}));
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterModule, [{
		type: NgModule,
		args: [{
			imports: ROUTER_DIRECTIVES,
			exports: ROUTER_DIRECTIVES
		}]
	}], () => [], null);
})();
function provideRouterScroller() {
	return {
		provide: ROUTER_SCROLLER,
		useFactory: () => {
			const viewportScroller = inject(ViewportScroller);
			const config = inject(ROUTER_CONFIGURATION);
			if (config.scrollOffset) viewportScroller.setOffset(config.scrollOffset);
			return new RouterScroller(config);
		}
	};
}
function provideHashLocationStrategy() {
	return {
		provide: LocationStrategy,
		useClass: HashLocationStrategy
	};
}
function providePathLocationStrategy() {
	return {
		provide: LocationStrategy,
		useClass: PathLocationStrategy
	};
}
function provideForRootGuard() {
	if (inject(Router, {
		optional: true,
		skipSelf: true
	})) throw new RuntimeError(4007, "The Router was provided more than once. This can happen if 'forRoot' is used outside of the root injector. Lazy loaded modules should use RouterModule.forChild() instead.");
	return "guarded";
}
function provideInitialNavigation(config) {
	return [config.initialNavigation === "disabled" ? withDisabledInitialNavigation().ɵproviders : [], config.initialNavigation === "enabledBlocking" ? withEnabledBlockingInitialNavigation().ɵproviders : []];
}
var ROUTER_INITIALIZER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "Router Initializer" : "");
function provideRouterInitializer() {
	return [{
		provide: ROUTER_INITIALIZER,
		useFactory: getBootstrapListener
	}, {
		provide: APP_BOOTSTRAP_LISTENER,
		multi: true,
		useExisting: ROUTER_INITIALIZER
	}];
}
//#endregion
//#region node_modules/@angular/router/fesm2022/router.mjs
/**
* @license Angular v22.1.2
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function mapToCanMatch(providers) {
	return providers.map((provider) => (...params) => inject(provider).canMatch(...params));
}
function mapToCanActivate(providers) {
	return providers.map((provider) => (...params) => inject(provider).canActivate(...params));
}
function mapToCanActivateChild(providers) {
	return providers.map((provider) => (...params) => inject(provider).canActivateChild(...params));
}
function mapToCanDeactivate(providers) {
	return providers.map((provider) => (...params) => inject(provider).canDeactivate(...params));
}
function mapToResolve(provider) {
	return (...params) => inject(provider).resolve(...params);
}
var VERSION = /* @__PURE__ */ new Version("22.1.2");
//#endregion
export { ActivatedRoute, ActivatedRouteSnapshot, ActivationEnd, ActivationStart, BaseRouteReuseStrategy, ChildActivationEnd, ChildActivationStart, ChildrenOutletContexts, DefaultTitleStrategy, DefaultUrlSerializer, EventType, GuardsCheckEnd, GuardsCheckStart, NavigationCancel, NavigationCancellationCode, NavigationEnd, NavigationError, NavigationSkipped, NavigationSkippedCode, NavigationStart, NoPreloading, OutletContext, PRIMARY_OUTLET, PreloadAllModules, PreloadingStrategy, ROUTER_CONFIGURATION, ROUTER_INITIALIZER, ROUTER_OUTLET_DATA, ROUTES, RedirectCommand, ResolveEnd, ResolveStart, RouteConfigLoadEnd, RouteConfigLoadStart, RouteReuseStrategy, Router, RouterEvent, RouterLink, RouterLink as RouterLinkWithHref, RouterLinkActive, RouterModule, RouterOutlet, RouterPreloader, RouterState, RouterStateSnapshot, RoutesRecognized, Scroll, TitleStrategy, UrlHandlingStrategy, UrlSegment, UrlSegmentGroup, UrlSerializer, UrlTree, VERSION, convertToParamMap, createUrlTreeFromSnapshot, defaultUrlMatcher, destroyDetachedRouteHandle, isActive, mapToCanActivate, mapToCanActivateChild, mapToCanDeactivate, mapToCanMatch, mapToResolve, provideRouter, withComponentInputBinding, withDebugTracing, withDisabledInitialNavigation, withEnabledBlockingInitialNavigation, withExperimentalAutoCleanupInjectors, withExperimentalPlatformNavigation, withHashLocation, withInMemoryScrolling, withNavigationErrorHandler, withPreloading, withRouterConfig, withViewTransitions, ɵEmptyOutletComponent, ROUTER_PROVIDERS as ɵROUTER_PROVIDERS, afterNextNavigation as ɵafterNextNavigation, loadChildren as ɵloadChildren, withActivatedRouteInjectors as ɵwithActivatedRouteInjectors };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGFuZ3VsYXJfcm91dGVyLmpzIiwibmFtZXMiOlsiX2lzUHJvbWlzZSIsIl9SdW50aW1lRXJyb3IiLCJVcmxTZXJpYWxpemVyIiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiQ2hpbGRyZW5PdXRsZXRDb250ZXh0cyIsImkwLsm1ybVpbmplY3QiLCJpMC5FbnZpcm9ubWVudEluamVjdG9yIiwiUm91dGVyT3V0bGV0IiwiaTAuybXJtU5nT25DaGFuZ2VzRmVhdHVyZSIsImkwLklucHV0IiwiUm91dGVkQ29tcG9uZW50SW5wdXRCaW5kZXIiLCLJtUVtcHR5T3V0bGV0Q29tcG9uZW50IiwiX2lzSW5qZWN0YWJsZSIsInRoaXMiLCJfaXNOZ01vZHVsZSIsIlRpdGxlU3RyYXRlZ3kiLCJEZWZhdWx0VGl0bGVTdHJhdGVneSIsImkxLlRpdGxlIiwiX21heWJlVW53cmFwRGVmYXVsdEV4cG9ydCIsIlJvdXRlckNvbmZpZ0xvYWRlciIsIk5nTW9kdWxlRmFjdG9yeSIsIlVybEhhbmRsaW5nU3RyYXRlZ3kiLCJEZWZhdWx0VXJsSGFuZGxpbmdTdHJhdGVneSIsIk5hdmlnYXRpb25UcmFuc2l0aW9ucyIsIlJvdXRlUmV1c2VTdHJhdGVneSIsIkRlZmF1bHRSb3V0ZVJldXNlU3RyYXRlZ3kiLCJTdGF0ZU1hbmFnZXIiLCJIaXN0b3J5U3RhdGVNYW5hZ2VyIiwiX0NvbnNvbGUiLCJfUGVuZGluZ1Rhc2tzSW50ZXJuYWwiLCJfSU5URVJOQUxfQVBQTElDQVRJT05fRVJST1JfSEFORExFUiIsIl9mb3JtYXRSdW50aW1lRXJyb3IiLCJSb3V0ZXIiLCJSZWFjdGl2ZVJvdXRlclN0YXRlIiwiaTAuybVzZXRDbGFzc01ldGFkYXRhIiwiX0lOVEVSTkFMX0FQUExJQ0FUSU9OX0VSUk9SX0hBTkRMRVIiLCJfUnVudGltZUVycm9yIiwiUm91dGVyTGluayIsImkwLsm1ybVkaXJlY3RpdmVJbmplY3QiLCJpMC7Jtcm1aW5qZWN0QXR0cmlidXRlIiwiaTAuUmVuZGVyZXIyIiwiaTAuRWxlbWVudFJlZiIsImkzLkxvY2F0aW9uU3RyYXRlZ3kiLCJpMC7Jtcm1c2FuaXRpemVVcmxPclJlc291cmNlVXJsIiwiaTAuybXJtU5nT25DaGFuZ2VzRmVhdHVyZSIsImkwLklucHV0IiwiUm91dGVyTGlua0FjdGl2ZSIsImkwLkNoYW5nZURldGVjdG9yUmVmIiwiaTAuybXJtWxvYWRRdWVyeSIsIlByZWxvYWRBbGxNb2R1bGVzIiwiTm9QcmVsb2FkaW5nIiwiUm91dGVyUHJlbG9hZGVyIiwiaTAuybXJtWluamVjdCIsImkwLkVudmlyb25tZW50SW5qZWN0b3IiLCJfSVNfSFlEUkFUSU9OX0RPTV9SRVVTRV9FTkFCTEVEIiwidGhpcyIsIlJvdXRlclNjcm9sbGVyIiwiX1BSRUNPTU1JVF9IQU5ETEVSX1NVUFBPUlRFRCIsIl9wcm9taXNlV2l0aFJlc29sdmVycyIsIk5hdmlnYXRpb25TdGF0ZU1hbmFnZXIiLCJfTmF2aWdhdGlvbkFkYXB0ZXJGb3JMb2NhdGlvbiIsIl9JU19FTkFCTEVEX0JMT0NLSU5HX0lOSVRJQUxfTkFWSUdBVElPTiIsIl9FbXB0eU91dGxldENvbXBvbmVudCIsIlJvdXRlck1vZHVsZSJdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AYW5ndWxhci9yb3V0ZXIvZmVzbTIwMjIvX3JvdXRlci1jaHVuay5tanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvQGFuZ3VsYXIvcm91dGVyL2Zlc20yMDIyL19yb3V0ZXJfbW9kdWxlLWNodW5rLm1qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AYW5ndWxhci9yb3V0ZXIvZmVzbTIwMjIvcm91dGVyLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXIgdjIyLjEuMlxuICogKGMpIDIwMTAtMjAyNiBHb29nbGUgTExDLiBodHRwczovL2FuZ3VsYXIuZGV2L1xuICogTGljZW5zZTogTUlUXG4gKi9cblxuaW1wb3J0IHsgRE9DVU1FTlQsIExvY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCAqIGFzIGkwIGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgybVpc1Byb21pc2UgYXMgX2lzUHJvbWlzZSwgybVSdW50aW1lRXJyb3IgYXMgX1J1bnRpbWVFcnJvciwgY29tcHV0ZWQsIFNlcnZpY2UsIEluamVjdGFibGUsIEluamVjdGlvblRva2VuLCBFdmVudEVtaXR0ZXIsIGlucHV0LCBpbmplY3QsIFZpZXdDb250YWluZXJSZWYsIENoYW5nZURldGVjdG9yUmVmLCBPdXRwdXQsIElucHV0LCBEaXJlY3RpdmUsIHJlZmxlY3RDb21wb25lbnRUeXBlLCBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBydW5JbkluamVjdGlvbkNvbnRleHQsIMm1aXNJbmplY3RhYmxlIGFzIF9pc0luamVjdGFibGUsIMm1aXNOZ01vZHVsZSBhcyBfaXNOZ01vZHVsZSwgaXNTdGFuZGFsb25lLCBjcmVhdGVFbnZpcm9ubWVudEluamVjdG9yLCBDb21waWxlciwgybVtYXliZVVud3JhcERlZmF1bHRFeHBvcnQgYXMgX21heWJlVW53cmFwRGVmYXVsdEV4cG9ydCwgTmdNb2R1bGVGYWN0b3J5LCDJtXJlc29sdmVDb21wb25lbnRSZXNvdXJjZXMgYXMgX3Jlc29sdmVDb21wb25lbnRSZXNvdXJjZXMsIGFmdGVyTmV4dFJlbmRlciwgc2lnbmFsLCBFbnZpcm9ubWVudEluamVjdG9yLCBEZXN0cm95UmVmLCB1bnRyYWNrZWQsIMm1Q29uc29sZSBhcyBfQ29uc29sZSwgybVQZW5kaW5nVGFza3NJbnRlcm5hbCBhcyBfUGVuZGluZ1Rhc2tzSW50ZXJuYWwsIMm1SU5URVJOQUxfQVBQTElDQVRJT05fRVJST1JfSEFORExFUiBhcyBfSU5URVJOQUxfQVBQTElDQVRJT05fRVJST1JfSEFORExFUiwgybVmb3JtYXRSdW50aW1lRXJyb3IgYXMgX2Zvcm1hdFJ1bnRpbWVFcnJvciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgaXNPYnNlcnZhYmxlLCBmcm9tLCBvZiwgQmVoYXZpb3JTdWJqZWN0LCBjb21iaW5lTGF0ZXN0LCBFbXB0eUVycm9yLCBPYnNlcnZhYmxlLCBjb25jYXQsIGRlZmVyLCBwaXBlLCBFTVBUWSwgdGhyb3dFcnJvciwgU3ViamVjdCwgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBmaXJzdCwgbWFwLCBzd2l0Y2hNYXAsIHRha2UsIHN0YXJ0V2l0aCwgZmlsdGVyLCB0YWtlVW50aWwsIG1lcmdlTWFwLCBjb25jYXRNYXAsIHRhcCwgdGFrZUxhc3QsIGNhdGNoRXJyb3IsIGZpbmFsaXplIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0ICogYXMgaTEgZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XG5jb25zdCBQUklNQVJZX09VVExFVCA9ICdwcmltYXJ5JztcbmNvbnN0IFJvdXRlVGl0bGVLZXkgPSAvKiBAX19QVVJFX18gKi9TeW1ib2woJ1JvdXRlVGl0bGUnKTtcbmNsYXNzIFBhcmFtc0FzTWFwIHtcbiAgcGFyYW1zO1xuICBjb25zdHJ1Y3RvcihwYXJhbXMpIHtcbiAgICB0aGlzLnBhcmFtcyA9IHBhcmFtcyB8fCB7fTtcbiAgfVxuICBoYXMobmFtZSkge1xuICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodGhpcy5wYXJhbXMsIG5hbWUpO1xuICB9XG4gIGdldChuYW1lKSB7XG4gICAgaWYgKHRoaXMuaGFzKG5hbWUpKSB7XG4gICAgICBjb25zdCB2ID0gdGhpcy5wYXJhbXNbbmFtZV07XG4gICAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh2KSA/IHZbMF0gOiB2O1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBnZXRBbGwobmFtZSkge1xuICAgIGlmICh0aGlzLmhhcyhuYW1lKSkge1xuICAgICAgY29uc3QgdiA9IHRoaXMucGFyYW1zW25hbWVdO1xuICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgPyB2IDogW3ZdO1xuICAgIH1cbiAgICByZXR1cm4gW107XG4gIH1cbiAgZ2V0IGtleXMoKSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaXMucGFyYW1zKTtcbiAgfVxufVxuZnVuY3Rpb24gY29udmVydFRvUGFyYW1NYXAocGFyYW1zKSB7XG4gIHJldHVybiBuZXcgUGFyYW1zQXNNYXAocGFyYW1zKTtcbn1cbmZ1bmN0aW9uIG1hdGNoUGFydHMocm91dGVQYXJ0cywgdXJsU2VnbWVudHMsIHBvc1BhcmFtcykge1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHJvdXRlUGFydHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBwYXJ0ID0gcm91dGVQYXJ0c1tpXTtcbiAgICBjb25zdCBzZWdtZW50ID0gdXJsU2VnbWVudHNbaV07XG4gICAgY29uc3QgaXNQYXJhbWV0ZXIgPSBwYXJ0WzBdID09PSAnOic7XG4gICAgaWYgKGlzUGFyYW1ldGVyKSB7XG4gICAgICBwb3NQYXJhbXNbcGFydC5zdWJzdHJpbmcoMSldID0gc2VnbWVudDtcbiAgICB9IGVsc2UgaWYgKHBhcnQgIT09IHNlZ21lbnQucGF0aCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRVcmxNYXRjaGVyKHNlZ21lbnRzLCBzZWdtZW50R3JvdXAsIHJvdXRlKSB7XG4gIGNvbnN0IHBhcnRzID0gcm91dGUucGF0aC5zcGxpdCgnLycpO1xuICBjb25zdCB3aWxkY2FyZEluZGV4ID0gcGFydHMuaW5kZXhPZignKionKTtcbiAgaWYgKHdpbGRjYXJkSW5kZXggPT09IC0xKSB7XG4gICAgaWYgKHBhcnRzLmxlbmd0aCA+IHNlZ21lbnRzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmIChyb3V0ZS5wYXRoTWF0Y2ggPT09ICdmdWxsJyAmJiAoc2VnbWVudEdyb3VwLmhhc0NoaWxkcmVuKCkgfHwgcGFydHMubGVuZ3RoIDwgc2VnbWVudHMubGVuZ3RoKSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IHBvc1BhcmFtcyA9IHt9O1xuICAgIGNvbnN0IGNvbnN1bWVkID0gc2VnbWVudHMuc2xpY2UoMCwgcGFydHMubGVuZ3RoKTtcbiAgICBpZiAoIW1hdGNoUGFydHMocGFydHMsIGNvbnN1bWVkLCBwb3NQYXJhbXMpKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbnN1bWVkLFxuICAgICAgcG9zUGFyYW1zXG4gICAgfTtcbiAgfVxuICBpZiAod2lsZGNhcmRJbmRleCAhPT0gcGFydHMubGFzdEluZGV4T2YoJyoqJykpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBwcmUgPSBwYXJ0cy5zbGljZSgwLCB3aWxkY2FyZEluZGV4KTtcbiAgY29uc3QgcG9zdCA9IHBhcnRzLnNsaWNlKHdpbGRjYXJkSW5kZXggKyAxKTtcbiAgaWYgKHByZS5sZW5ndGggKyBwb3N0Lmxlbmd0aCA+IHNlZ21lbnRzLmxlbmd0aCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChyb3V0ZS5wYXRoTWF0Y2ggPT09ICdmdWxsJyAmJiBzZWdtZW50R3JvdXAuaGFzQ2hpbGRyZW4oKSAmJiByb3V0ZS5wYXRoICE9PSAnKionKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgcG9zUGFyYW1zID0ge307XG4gIGlmICghbWF0Y2hQYXJ0cyhwcmUsIHNlZ21lbnRzLnNsaWNlKDAsIHByZS5sZW5ndGgpLCBwb3NQYXJhbXMpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKCFtYXRjaFBhcnRzKHBvc3QsIHNlZ21lbnRzLnNsaWNlKHNlZ21lbnRzLmxlbmd0aCAtIHBvc3QubGVuZ3RoKSwgcG9zUGFyYW1zKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiB7XG4gICAgY29uc3VtZWQ6IHNlZ21lbnRzLFxuICAgIHBvc1BhcmFtc1xuICB9O1xufVxuZnVuY3Rpb24gZmlyc3RWYWx1ZUZyb20oc291cmNlKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgc291cmNlLnBpcGUoZmlyc3QoKSkuc3Vic2NyaWJlKHtcbiAgICAgIG5leHQ6IHZhbHVlID0+IHJlc29sdmUodmFsdWUpLFxuICAgICAgZXJyb3I6IGVyciA9PiByZWplY3QoZXJyKVxuICAgIH0pO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHNoYWxsb3dFcXVhbEFycmF5cyhhLCBiKSB7XG4gIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBhLmxlbmd0aDsgKytpKSB7XG4gICAgaWYgKCFzaGFsbG93RXF1YWwoYVtpXSwgYltpXSkpIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHNoYWxsb3dFcXVhbChhLCBiKSB7XG4gIGNvbnN0IGsxID0gYSA/IGdldERhdGFLZXlzKGEpIDogdW5kZWZpbmVkO1xuICBjb25zdCBrMiA9IGIgPyBnZXREYXRhS2V5cyhiKSA6IHVuZGVmaW5lZDtcbiAgaWYgKCFrMSB8fCAhazIgfHwgazEubGVuZ3RoICE9IGsyLmxlbmd0aCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBsZXQga2V5O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGsxLmxlbmd0aDsgaSsrKSB7XG4gICAga2V5ID0gazFbaV07XG4gICAgaWYgKCFlcXVhbEFycmF5c09yU3RyaW5nKGFba2V5XSwgYltrZXldKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGdldERhdGFLZXlzKG9iaikge1xuICByZXR1cm4gWy4uLk9iamVjdC5rZXlzKG9iaiksIC4uLk9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMob2JqKV07XG59XG5mdW5jdGlvbiBlcXVhbEFycmF5c09yU3RyaW5nKGEsIGIpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYSkgJiYgQXJyYXkuaXNBcnJheShiKSkge1xuICAgIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBhU29ydGVkID0gWy4uLmFdLnNvcnQoKTtcbiAgICBjb25zdCBiU29ydGVkID0gWy4uLmJdLnNvcnQoKTtcbiAgICByZXR1cm4gYVNvcnRlZC5ldmVyeSgodmFsLCBpbmRleCkgPT4gYlNvcnRlZFtpbmRleF0gPT09IHZhbCk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGEgPT09IGI7XG4gIH1cbn1cbmZ1bmN0aW9uIGxhc3QoYSkge1xuICByZXR1cm4gYS5sZW5ndGggPiAwID8gYVthLmxlbmd0aCAtIDFdIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHdyYXBJbnRvT2JzZXJ2YWJsZSh2YWx1ZSkge1xuICBpZiAoaXNPYnNlcnZhYmxlKHZhbHVlKSkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICBpZiAoX2lzUHJvbWlzZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gZnJvbShQcm9taXNlLnJlc29sdmUodmFsdWUpKTtcbiAgfVxuICByZXR1cm4gb2YodmFsdWUpO1xufVxuZnVuY3Rpb24gd3JhcEludG9Qcm9taXNlKHZhbHVlKSB7XG4gIGlmIChpc09ic2VydmFibGUodmFsdWUpKSB7XG4gICAgcmV0dXJuIGZpcnN0VmFsdWVGcm9tKHZhbHVlKTtcbiAgfVxuICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHZhbHVlKTtcbn1cbmNvbnN0IHBhdGhDb21wYXJlTWFwID0ge1xuICAnZXhhY3QnOiBlcXVhbFNlZ21lbnRHcm91cHMsXG4gICdzdWJzZXQnOiBjb250YWluc1NlZ21lbnRHcm91cFxufTtcbmNvbnN0IHBhcmFtQ29tcGFyZU1hcCA9IHtcbiAgJ2V4YWN0JzogZXF1YWxQYXJhbXMsXG4gICdzdWJzZXQnOiBjb250YWluc1BhcmFtcyxcbiAgJ2lnbm9yZWQnOiAoKSA9PiB0cnVlXG59O1xuY29uc3QgZXhhY3RNYXRjaE9wdGlvbnMgPSB7XG4gIHBhdGhzOiAnZXhhY3QnLFxuICBmcmFnbWVudDogJ2lnbm9yZWQnLFxuICBtYXRyaXhQYXJhbXM6ICdpZ25vcmVkJyxcbiAgcXVlcnlQYXJhbXM6ICdleGFjdCdcbn07XG5jb25zdCBzdWJzZXRNYXRjaE9wdGlvbnMgPSB7XG4gIHBhdGhzOiAnc3Vic2V0JyxcbiAgZnJhZ21lbnQ6ICdpZ25vcmVkJyxcbiAgbWF0cml4UGFyYW1zOiAnaWdub3JlZCcsXG4gIHF1ZXJ5UGFyYW1zOiAnc3Vic2V0J1xufTtcbmZ1bmN0aW9uIGlzQWN0aXZlKHVybCwgcm91dGVyLCBtYXRjaE9wdGlvbnMpIHtcbiAgY29uc3QgdXJsVHJlZSA9IHVybCBpbnN0YW5jZW9mIFVybFRyZWUgPyB1cmwgOiByb3V0ZXIucGFyc2VVcmwodXJsKTtcbiAgcmV0dXJuIGNvbXB1dGVkKCgpID0+IGNvbnRhaW5zVHJlZShyb3V0ZXIubGFzdFN1Y2Nlc3NmdWxOYXZpZ2F0aW9uKCk/LmZpbmFsVXJsID8/IG5ldyBVcmxUcmVlKCksIHVybFRyZWUsIHtcbiAgICAuLi5zdWJzZXRNYXRjaE9wdGlvbnMsXG4gICAgLi4ubWF0Y2hPcHRpb25zXG4gIH0pKTtcbn1cbmZ1bmN0aW9uIGNvbnRhaW5zVHJlZShjb250YWluZXIsIGNvbnRhaW5lZSwgb3B0aW9ucykge1xuICByZXR1cm4gcGF0aENvbXBhcmVNYXBbb3B0aW9ucy5wYXRoc10oY29udGFpbmVyLnJvb3QsIGNvbnRhaW5lZS5yb290LCBvcHRpb25zLm1hdHJpeFBhcmFtcykgJiYgcGFyYW1Db21wYXJlTWFwW29wdGlvbnMucXVlcnlQYXJhbXNdKGNvbnRhaW5lci5xdWVyeVBhcmFtcywgY29udGFpbmVlLnF1ZXJ5UGFyYW1zKSAmJiAhKG9wdGlvbnMuZnJhZ21lbnQgPT09ICdleGFjdCcgJiYgY29udGFpbmVyLmZyYWdtZW50ICE9PSBjb250YWluZWUuZnJhZ21lbnQpO1xufVxuZnVuY3Rpb24gZXF1YWxQYXJhbXMoY29udGFpbmVyLCBjb250YWluZWUpIHtcbiAgcmV0dXJuIHNoYWxsb3dFcXVhbChjb250YWluZXIsIGNvbnRhaW5lZSk7XG59XG5mdW5jdGlvbiBlcXVhbFNlZ21lbnRHcm91cHMoY29udGFpbmVyLCBjb250YWluZWUsIG1hdHJpeFBhcmFtcykge1xuICBpZiAoIWVxdWFsUGF0aChjb250YWluZXIuc2VnbWVudHMsIGNvbnRhaW5lZS5zZWdtZW50cykpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFtYXRyaXhQYXJhbXNNYXRjaChjb250YWluZXIuc2VnbWVudHMsIGNvbnRhaW5lZS5zZWdtZW50cywgbWF0cml4UGFyYW1zKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoY29udGFpbmVyLm51bWJlck9mQ2hpbGRyZW4gIT09IGNvbnRhaW5lZS5udW1iZXJPZkNoaWxkcmVuKSByZXR1cm4gZmFsc2U7XG4gIGZvciAoY29uc3QgYyBpbiBjb250YWluZWUuY2hpbGRyZW4pIHtcbiAgICBpZiAoIWNvbnRhaW5lci5jaGlsZHJlbltjXSkgcmV0dXJuIGZhbHNlO1xuICAgIGlmICghZXF1YWxTZWdtZW50R3JvdXBzKGNvbnRhaW5lci5jaGlsZHJlbltjXSwgY29udGFpbmVlLmNoaWxkcmVuW2NdLCBtYXRyaXhQYXJhbXMpKSByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBjb250YWluc1BhcmFtcyhjb250YWluZXIsIGNvbnRhaW5lZSkge1xuICByZXR1cm4gT2JqZWN0LmtleXMoY29udGFpbmVlKS5sZW5ndGggPD0gT2JqZWN0LmtleXMoY29udGFpbmVyKS5sZW5ndGggJiYgT2JqZWN0LmtleXMoY29udGFpbmVlKS5ldmVyeShrZXkgPT4gZXF1YWxBcnJheXNPclN0cmluZyhjb250YWluZXJba2V5XSwgY29udGFpbmVlW2tleV0pKTtcbn1cbmZ1bmN0aW9uIGNvbnRhaW5zU2VnbWVudEdyb3VwKGNvbnRhaW5lciwgY29udGFpbmVlLCBtYXRyaXhQYXJhbXMpIHtcbiAgcmV0dXJuIGNvbnRhaW5zU2VnbWVudEdyb3VwSGVscGVyKGNvbnRhaW5lciwgY29udGFpbmVlLCBjb250YWluZWUuc2VnbWVudHMsIG1hdHJpeFBhcmFtcyk7XG59XG5mdW5jdGlvbiBjb250YWluc1NlZ21lbnRHcm91cEhlbHBlcihjb250YWluZXIsIGNvbnRhaW5lZSwgY29udGFpbmVlUGF0aHMsIG1hdHJpeFBhcmFtcykge1xuICBpZiAoY29udGFpbmVyLnNlZ21lbnRzLmxlbmd0aCA+IGNvbnRhaW5lZVBhdGhzLmxlbmd0aCkge1xuICAgIGNvbnN0IGN1cnJlbnQgPSBjb250YWluZXIuc2VnbWVudHMuc2xpY2UoMCwgY29udGFpbmVlUGF0aHMubGVuZ3RoKTtcbiAgICBpZiAoIWVxdWFsUGF0aChjdXJyZW50LCBjb250YWluZWVQYXRocykpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoY29udGFpbmVlLmhhc0NoaWxkcmVuKCkpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoIW1hdHJpeFBhcmFtc01hdGNoKGN1cnJlbnQsIGNvbnRhaW5lZVBhdGhzLCBtYXRyaXhQYXJhbXMpKSByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gZWxzZSBpZiAoY29udGFpbmVyLnNlZ21lbnRzLmxlbmd0aCA9PT0gY29udGFpbmVlUGF0aHMubGVuZ3RoKSB7XG4gICAgaWYgKCFlcXVhbFBhdGgoY29udGFpbmVyLnNlZ21lbnRzLCBjb250YWluZWVQYXRocykpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoIW1hdHJpeFBhcmFtc01hdGNoKGNvbnRhaW5lci5zZWdtZW50cywgY29udGFpbmVlUGF0aHMsIG1hdHJpeFBhcmFtcykpIHJldHVybiBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGMgaW4gY29udGFpbmVlLmNoaWxkcmVuKSB7XG4gICAgICBpZiAoIWNvbnRhaW5lci5jaGlsZHJlbltjXSkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKCFjb250YWluc1NlZ21lbnRHcm91cChjb250YWluZXIuY2hpbGRyZW5bY10sIGNvbnRhaW5lZS5jaGlsZHJlbltjXSwgbWF0cml4UGFyYW1zKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGN1cnJlbnQgPSBjb250YWluZWVQYXRocy5zbGljZSgwLCBjb250YWluZXIuc2VnbWVudHMubGVuZ3RoKTtcbiAgICBjb25zdCBuZXh0ID0gY29udGFpbmVlUGF0aHMuc2xpY2UoY29udGFpbmVyLnNlZ21lbnRzLmxlbmd0aCk7XG4gICAgaWYgKCFlcXVhbFBhdGgoY29udGFpbmVyLnNlZ21lbnRzLCBjdXJyZW50KSkgcmV0dXJuIGZhbHNlO1xuICAgIGlmICghbWF0cml4UGFyYW1zTWF0Y2goY29udGFpbmVyLnNlZ21lbnRzLCBjdXJyZW50LCBtYXRyaXhQYXJhbXMpKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKCFjb250YWluZXIuY2hpbGRyZW5bUFJJTUFSWV9PVVRMRVRdKSByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIGNvbnRhaW5zU2VnbWVudEdyb3VwSGVscGVyKGNvbnRhaW5lci5jaGlsZHJlbltQUklNQVJZX09VVExFVF0sIGNvbnRhaW5lZSwgbmV4dCwgbWF0cml4UGFyYW1zKTtcbiAgfVxufVxuZnVuY3Rpb24gbWF0cml4UGFyYW1zTWF0Y2goY29udGFpbmVyUGF0aHMsIGNvbnRhaW5lZVBhdGhzLCBvcHRpb25zKSB7XG4gIHJldHVybiBjb250YWluZWVQYXRocy5ldmVyeSgoY29udGFpbmVlU2VnbWVudCwgaSkgPT4ge1xuICAgIHJldHVybiBwYXJhbUNvbXBhcmVNYXBbb3B0aW9uc10oY29udGFpbmVyUGF0aHNbaV0ucGFyYW1ldGVycywgY29udGFpbmVlU2VnbWVudC5wYXJhbWV0ZXJzKTtcbiAgfSk7XG59XG5jbGFzcyBVcmxUcmVlIHtcbiAgcm9vdDtcbiAgcXVlcnlQYXJhbXM7XG4gIGZyYWdtZW50O1xuICBfcXVlcnlQYXJhbU1hcDtcbiAgY29uc3RydWN0b3Iocm9vdCA9IG5ldyBVcmxTZWdtZW50R3JvdXAoW10sIHt9KSwgcXVlcnlQYXJhbXMgPSB7fSwgZnJhZ21lbnQgPSBudWxsKSB7XG4gICAgdGhpcy5yb290ID0gcm9vdDtcbiAgICB0aGlzLnF1ZXJ5UGFyYW1zID0gcXVlcnlQYXJhbXM7XG4gICAgdGhpcy5mcmFnbWVudCA9IGZyYWdtZW50O1xuICAgIGlmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpIHtcbiAgICAgIGlmIChyb290LnNlZ21lbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxNSwgJ1RoZSByb290IGBVcmxTZWdtZW50R3JvdXBgIHNob3VsZCBub3QgY29udGFpbiBgc2VnbWVudHNgLiAnICsgJ0luc3RlYWQsIHRoZXNlIHNlZ21lbnRzIGJlbG9uZyBpbiB0aGUgYGNoaWxkcmVuYCBzbyB0aGV5IGNhbiBiZSBhc3NvY2lhdGVkIHdpdGggYSBuYW1lZCBvdXRsZXQuJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGdldCBxdWVyeVBhcmFtTWFwKCkge1xuICAgIHRoaXMuX3F1ZXJ5UGFyYW1NYXAgPz89IGNvbnZlcnRUb1BhcmFtTWFwKHRoaXMucXVlcnlQYXJhbXMpO1xuICAgIHJldHVybiB0aGlzLl9xdWVyeVBhcmFtTWFwO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBERUZBVUxUX1NFUklBTElaRVIuc2VyaWFsaXplKHRoaXMpO1xuICB9XG59XG5jbGFzcyBVcmxTZWdtZW50R3JvdXAge1xuICBzZWdtZW50cztcbiAgY2hpbGRyZW47XG4gIHBhcmVudCA9IG51bGw7XG4gIGNvbnN0cnVjdG9yKHNlZ21lbnRzLCBjaGlsZHJlbikge1xuICAgIHRoaXMuc2VnbWVudHMgPSBzZWdtZW50cztcbiAgICB0aGlzLmNoaWxkcmVuID0gY2hpbGRyZW47XG4gICAgT2JqZWN0LnZhbHVlcyhjaGlsZHJlbikuZm9yRWFjaCh2ID0+IHYucGFyZW50ID0gdGhpcyk7XG4gIH1cbiAgaGFzQ2hpbGRyZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMubnVtYmVyT2ZDaGlsZHJlbiA+IDA7XG4gIH1cbiAgZ2V0IG51bWJlck9mQ2hpbGRyZW4oKSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuY2hpbGRyZW4pLmxlbmd0aDtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gc2VyaWFsaXplUGF0aHModGhpcyk7XG4gIH1cbn1cbmNsYXNzIFVybFNlZ21lbnQge1xuICBwYXRoO1xuICBwYXJhbWV0ZXJzO1xuICBfcGFyYW1ldGVyTWFwO1xuICBjb25zdHJ1Y3RvcihwYXRoLCBwYXJhbWV0ZXJzKSB7XG4gICAgdGhpcy5wYXRoID0gcGF0aDtcbiAgICB0aGlzLnBhcmFtZXRlcnMgPSBwYXJhbWV0ZXJzO1xuICB9XG4gIGdldCBwYXJhbWV0ZXJNYXAoKSB7XG4gICAgdGhpcy5fcGFyYW1ldGVyTWFwID8/PSBjb252ZXJ0VG9QYXJhbU1hcCh0aGlzLnBhcmFtZXRlcnMpO1xuICAgIHJldHVybiB0aGlzLl9wYXJhbWV0ZXJNYXA7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZVBhdGgodGhpcyk7XG4gIH1cbn1cbmZ1bmN0aW9uIGVxdWFsU2VnbWVudHMoYXMsIGJzKSB7XG4gIHJldHVybiBlcXVhbFBhdGgoYXMsIGJzKSAmJiBhcy5ldmVyeSgoYSwgaSkgPT4gc2hhbGxvd0VxdWFsKGEucGFyYW1ldGVycywgYnNbaV0ucGFyYW1ldGVycykpO1xufVxuZnVuY3Rpb24gZXF1YWxQYXRoKGFzLCBicykge1xuICBpZiAoYXMubGVuZ3RoICE9PSBicy5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIGFzLmV2ZXJ5KChhLCBpKSA9PiBhLnBhdGggPT09IGJzW2ldLnBhdGgpO1xufVxuZnVuY3Rpb24gbWFwQ2hpbGRyZW5JbnRvQXJyYXkoc2VnbWVudCwgZm4pIHtcbiAgbGV0IHJlcyA9IFtdO1xuICBPYmplY3QuZW50cmllcyhzZWdtZW50LmNoaWxkcmVuKS5mb3JFYWNoKChbY2hpbGRPdXRsZXQsIGNoaWxkXSkgPT4ge1xuICAgIGlmIChjaGlsZE91dGxldCA9PT0gUFJJTUFSWV9PVVRMRVQpIHtcbiAgICAgIHJlcyA9IHJlcy5jb25jYXQoZm4oY2hpbGQsIGNoaWxkT3V0bGV0KSk7XG4gICAgfVxuICB9KTtcbiAgT2JqZWN0LmVudHJpZXMoc2VnbWVudC5jaGlsZHJlbikuZm9yRWFjaCgoW2NoaWxkT3V0bGV0LCBjaGlsZF0pID0+IHtcbiAgICBpZiAoY2hpbGRPdXRsZXQgIT09IFBSSU1BUllfT1VUTEVUKSB7XG4gICAgICByZXMgPSByZXMuY29uY2F0KGZuKGNoaWxkLCBjaGlsZE91dGxldCkpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiByZXM7XG59XG5jbGFzcyBVcmxTZXJpYWxpemVyIHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gVXJsU2VyaWFsaXplcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgVXJsU2VyaWFsaXplcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogVXJsU2VyaWFsaXplcixcbiAgICBmYWN0b3J5OiAoKSA9PiAoKCkgPT4gbmV3IERlZmF1bHRVcmxTZXJpYWxpemVyKCkpKClcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShVcmxTZXJpYWxpemVyLCBbe1xuICAgIHR5cGU6IFNlcnZpY2UsXG4gICAgYXJnczogW3tcbiAgICAgIGZhY3Rvcnk6ICgpID0+IG5ldyBEZWZhdWx0VXJsU2VyaWFsaXplcigpXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIERlZmF1bHRVcmxTZXJpYWxpemVyIHtcbiAgcGFyc2UodXJsKSB7XG4gICAgY29uc3QgcCA9IG5ldyBVcmxQYXJzZXIodXJsKTtcbiAgICByZXR1cm4gbmV3IFVybFRyZWUocC5wYXJzZVJvb3RTZWdtZW50KCksIHAucGFyc2VRdWVyeVBhcmFtcygpLCBwLnBhcnNlRnJhZ21lbnQoKSk7XG4gIH1cbiAgc2VyaWFsaXplKHRyZWUpIHtcbiAgICBjb25zdCBzZWdtZW50ID0gYC8ke3NlcmlhbGl6ZVNlZ21lbnQodHJlZS5yb290LCB0cnVlKX1gO1xuICAgIGlmIChzZWdtZW50LnN0YXJ0c1dpdGgoJy8vJykpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTksICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICdDYW5ub3Qgc2VyaWFsaXplIGEgVXJsVHJlZSB0aGF0IHdvdWxkIHByb2R1Y2UgYSBwcm90b2NvbC1yZWxhdGl2ZSBVUkwuJyk7XG4gICAgfVxuICAgIGNvbnN0IHF1ZXJ5ID0gc2VyaWFsaXplUXVlcnlQYXJhbXModHJlZS5xdWVyeVBhcmFtcyk7XG4gICAgY29uc3QgZnJhZ21lbnQgPSB0eXBlb2YgdHJlZS5mcmFnbWVudCA9PT0gYHN0cmluZ2AgPyBgIyR7ZW5jb2RlVXJpRnJhZ21lbnQodHJlZS5mcmFnbWVudCl9YCA6ICcnO1xuICAgIHJldHVybiBgJHtzZWdtZW50fSR7cXVlcnl9JHtmcmFnbWVudH1gO1xuICB9XG59XG5jb25zdCBERUZBVUxUX1NFUklBTElaRVIgPSBuZXcgRGVmYXVsdFVybFNlcmlhbGl6ZXIoKTtcbmZ1bmN0aW9uIHNlcmlhbGl6ZVBhdGhzKHNlZ21lbnQpIHtcbiAgcmV0dXJuIHNlZ21lbnQuc2VnbWVudHMubWFwKHAgPT4gc2VyaWFsaXplUGF0aChwKSkuam9pbignLycpO1xufVxuZnVuY3Rpb24gc2VyaWFsaXplU2VnbWVudChzZWdtZW50LCByb290KSB7XG4gIGlmICghc2VnbWVudC5oYXNDaGlsZHJlbigpKSB7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZVBhdGhzKHNlZ21lbnQpO1xuICB9XG4gIGlmIChyb290KSB7XG4gICAgY29uc3QgcHJpbWFyeSA9IHNlZ21lbnQuY2hpbGRyZW5bUFJJTUFSWV9PVVRMRVRdID8gc2VyaWFsaXplU2VnbWVudChzZWdtZW50LmNoaWxkcmVuW1BSSU1BUllfT1VUTEVUXSwgZmFsc2UpIDogJyc7XG4gICAgY29uc3QgY2hpbGRyZW4gPSBbXTtcbiAgICBPYmplY3QuZW50cmllcyhzZWdtZW50LmNoaWxkcmVuKS5mb3JFYWNoKChbaywgdl0pID0+IHtcbiAgICAgIGlmIChrICE9PSBQUklNQVJZX09VVExFVCkge1xuICAgICAgICBjaGlsZHJlbi5wdXNoKGAke2t9OiR7c2VyaWFsaXplU2VnbWVudCh2LCBmYWxzZSl9YCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGNoaWxkcmVuLmxlbmd0aCA+IDAgPyBgJHtwcmltYXJ5fSgke2NoaWxkcmVuLmpvaW4oJy8vJyl9KWAgOiBwcmltYXJ5O1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGNoaWxkcmVuID0gbWFwQ2hpbGRyZW5JbnRvQXJyYXkoc2VnbWVudCwgKHYsIGspID0+IHtcbiAgICAgIGlmIChrID09PSBQUklNQVJZX09VVExFVCkge1xuICAgICAgICByZXR1cm4gW3NlcmlhbGl6ZVNlZ21lbnQoc2VnbWVudC5jaGlsZHJlbltQUklNQVJZX09VVExFVF0sIGZhbHNlKV07XG4gICAgICB9XG4gICAgICByZXR1cm4gW2Ake2t9OiR7c2VyaWFsaXplU2VnbWVudCh2LCBmYWxzZSl9YF07XG4gICAgfSk7XG4gICAgaWYgKE9iamVjdC5rZXlzKHNlZ21lbnQuY2hpbGRyZW4pLmxlbmd0aCA9PT0gMSAmJiBzZWdtZW50LmNoaWxkcmVuW1BSSU1BUllfT1VUTEVUXSAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gYCR7c2VyaWFsaXplUGF0aHMoc2VnbWVudCl9LyR7Y2hpbGRyZW5bMF19YDtcbiAgICB9XG4gICAgcmV0dXJuIGAke3NlcmlhbGl6ZVBhdGhzKHNlZ21lbnQpfS8oJHtjaGlsZHJlbi5qb2luKCcvLycpfSlgO1xuICB9XG59XG5mdW5jdGlvbiBlbmNvZGVVcmlTdHJpbmcocykge1xuICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHMpLnJlcGxhY2UoLyU0MC9nLCAnQCcpLnJlcGxhY2UoLyUzQS9naSwgJzonKS5yZXBsYWNlKC8lMjQvZywgJyQnKS5yZXBsYWNlKC8lMkMvZ2ksICcsJyk7XG59XG5mdW5jdGlvbiBlbmNvZGVVcmlRdWVyeShzKSB7XG4gIHJldHVybiBlbmNvZGVVcmlTdHJpbmcocykucmVwbGFjZSgvJTNCL2dpLCAnOycpO1xufVxuZnVuY3Rpb24gZW5jb2RlVXJpRnJhZ21lbnQocykge1xuICByZXR1cm4gZW5jb2RlVVJJKHMpO1xufVxuZnVuY3Rpb24gZW5jb2RlVXJpU2VnbWVudChzKSB7XG4gIHJldHVybiBlbmNvZGVVcmlTdHJpbmcocykucmVwbGFjZSgvXFwoL2csICclMjgnKS5yZXBsYWNlKC9cXCkvZywgJyUyOScpLnJlcGxhY2UoLyUyNi9naSwgJyYnKTtcbn1cbmZ1bmN0aW9uIGRlY29kZShzKSB7XG4gIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQocyk7XG59XG5mdW5jdGlvbiBkZWNvZGVRdWVyeShzKSB7XG4gIHJldHVybiBkZWNvZGUocy5yZXBsYWNlKC9cXCsvZywgJyUyMCcpKTtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZVBhdGgocGF0aCkge1xuICByZXR1cm4gYCR7ZW5jb2RlVXJpU2VnbWVudChwYXRoLnBhdGgpfSR7c2VyaWFsaXplTWF0cml4UGFyYW1zKHBhdGgucGFyYW1ldGVycyl9YDtcbn1cbmZ1bmN0aW9uIHNlcmlhbGl6ZU1hdHJpeFBhcmFtcyhwYXJhbXMpIHtcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHBhcmFtcykubWFwKChba2V5LCB2YWx1ZV0pID0+IGA7JHtlbmNvZGVVcmlTZWdtZW50KGtleSl9PSR7ZW5jb2RlVXJpU2VnbWVudCh2YWx1ZSl9YCkuam9pbignJyk7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVRdWVyeVBhcmFtcyhwYXJhbXMpIHtcbiAgY29uc3Qgc3RyUGFyYW1zID0gT2JqZWN0LmVudHJpZXMocGFyYW1zKS5tYXAoKFtuYW1lLCB2YWx1ZV0pID0+IHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAodiA9PiBgJHtlbmNvZGVVcmlRdWVyeShuYW1lKX09JHtlbmNvZGVVcmlRdWVyeSh2KX1gKS5qb2luKCcmJykgOiBgJHtlbmNvZGVVcmlRdWVyeShuYW1lKX09JHtlbmNvZGVVcmlRdWVyeSh2YWx1ZSl9YDtcbiAgfSkuZmlsdGVyKHMgPT4gcyk7XG4gIHJldHVybiBzdHJQYXJhbXMubGVuZ3RoID8gYD8ke3N0clBhcmFtcy5qb2luKCcmJyl9YCA6ICcnO1xufVxuY29uc3QgU0VHTUVOVF9SRSA9IC9eW15cXC8oKT87I10rLztcbmZ1bmN0aW9uIG1hdGNoU2VnbWVudHMoc3RyKSB7XG4gIGNvbnN0IG1hdGNoID0gc3RyLm1hdGNoKFNFR01FTlRfUkUpO1xuICByZXR1cm4gbWF0Y2ggPyBtYXRjaFswXSA6ICcnO1xufVxuY29uc3QgTUFUUklYX1BBUkFNX1NFR01FTlRfUkUgPSAvXlteXFwvKCk/Oz0jXSsvO1xuZnVuY3Rpb24gbWF0Y2hNYXRyaXhLZXlTZWdtZW50cyhzdHIpIHtcbiAgY29uc3QgbWF0Y2ggPSBzdHIubWF0Y2goTUFUUklYX1BBUkFNX1NFR01FTlRfUkUpO1xuICByZXR1cm4gbWF0Y2ggPyBtYXRjaFswXSA6ICcnO1xufVxuY29uc3QgUVVFUllfUEFSQU1fUkUgPSAvXltePT8mI10rLztcbmZ1bmN0aW9uIG1hdGNoUXVlcnlQYXJhbXMoc3RyKSB7XG4gIGNvbnN0IG1hdGNoID0gc3RyLm1hdGNoKFFVRVJZX1BBUkFNX1JFKTtcbiAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMF0gOiAnJztcbn1cbmNvbnN0IFFVRVJZX1BBUkFNX1ZBTFVFX1JFID0gL15bXiYjXSsvO1xuZnVuY3Rpb24gbWF0Y2hVcmxRdWVyeVBhcmFtVmFsdWUoc3RyKSB7XG4gIGNvbnN0IG1hdGNoID0gc3RyLm1hdGNoKFFVRVJZX1BBUkFNX1ZBTFVFX1JFKTtcbiAgcmV0dXJuIG1hdGNoID8gbWF0Y2hbMF0gOiAnJztcbn1cbmNsYXNzIFVybFBhcnNlciB7XG4gIHVybDtcbiAgcmVtYWluaW5nO1xuICBjb25zdHJ1Y3Rvcih1cmwpIHtcbiAgICB0aGlzLnVybCA9IHVybDtcbiAgICB0aGlzLnJlbWFpbmluZyA9IHVybDtcbiAgfVxuICBwYXJzZVJvb3RTZWdtZW50KCkge1xuICAgIHdoaWxlICh0aGlzLmNvbnN1bWVPcHRpb25hbCgnLycpKSB7fVxuICAgIGlmICh0aGlzLnJlbWFpbmluZyA9PT0gJycgfHwgdGhpcy5wZWVrU3RhcnRzV2l0aCgnPycpIHx8IHRoaXMucGVla1N0YXJ0c1dpdGgoJyMnKSkge1xuICAgICAgcmV0dXJuIG5ldyBVcmxTZWdtZW50R3JvdXAoW10sIHt9KTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBVcmxTZWdtZW50R3JvdXAoW10sIHRoaXMucGFyc2VDaGlsZHJlbigpKTtcbiAgfVxuICBwYXJzZVF1ZXJ5UGFyYW1zKCkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xuICAgIGlmICh0aGlzLmNvbnN1bWVPcHRpb25hbCgnPycpKSB7XG4gICAgICBkbyB7XG4gICAgICAgIHRoaXMucGFyc2VRdWVyeVBhcmFtKHBhcmFtcyk7XG4gICAgICB9IHdoaWxlICh0aGlzLmNvbnN1bWVPcHRpb25hbCgnJicpKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcmFtcztcbiAgfVxuICBwYXJzZUZyYWdtZW50KCkge1xuICAgIHJldHVybiB0aGlzLmNvbnN1bWVPcHRpb25hbCgnIycpID8gZGVjb2RlVVJJQ29tcG9uZW50KHRoaXMucmVtYWluaW5nKSA6IG51bGw7XG4gIH1cbiAgcGFyc2VDaGlsZHJlbihkZXB0aCA9IDApIHtcbiAgICBpZiAoZGVwdGggPiA1MCkge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxMCwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgJ1VSTCBpcyB0b28gZGVlcCcpO1xuICAgIH1cbiAgICBpZiAodGhpcy5yZW1haW5pbmcgPT09ICcnKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICAgIHRoaXMuY29uc3VtZU9wdGlvbmFsKCcvJyk7XG4gICAgY29uc3Qgc2VnbWVudHMgPSBbXTtcbiAgICBpZiAoIXRoaXMucGVla1N0YXJ0c1dpdGgoJygnKSkge1xuICAgICAgc2VnbWVudHMucHVzaCh0aGlzLnBhcnNlU2VnbWVudCgpKTtcbiAgICB9XG4gICAgd2hpbGUgKHRoaXMucGVla1N0YXJ0c1dpdGgoJy8nKSAmJiAhdGhpcy5wZWVrU3RhcnRzV2l0aCgnLy8nKSAmJiAhdGhpcy5wZWVrU3RhcnRzV2l0aCgnLygnKSkge1xuICAgICAgdGhpcy5jYXB0dXJlKCcvJyk7XG4gICAgICBzZWdtZW50cy5wdXNoKHRoaXMucGFyc2VTZWdtZW50KCkpO1xuICAgIH1cbiAgICBsZXQgY2hpbGRyZW4gPSB7fTtcbiAgICBpZiAodGhpcy5wZWVrU3RhcnRzV2l0aCgnLygnKSkge1xuICAgICAgdGhpcy5jYXB0dXJlKCcvJyk7XG4gICAgICBjaGlsZHJlbiA9IHRoaXMucGFyc2VQYXJlbnModHJ1ZSwgZGVwdGgpO1xuICAgIH1cbiAgICBsZXQgcmVzID0ge307XG4gICAgaWYgKHRoaXMucGVla1N0YXJ0c1dpdGgoJygnKSkge1xuICAgICAgcmVzID0gdGhpcy5wYXJzZVBhcmVucyhmYWxzZSwgZGVwdGgpO1xuICAgIH1cbiAgICBpZiAoc2VnbWVudHMubGVuZ3RoID4gMCB8fCBPYmplY3Qua2V5cyhjaGlsZHJlbikubGVuZ3RoID4gMCkge1xuICAgICAgcmVzW1BSSU1BUllfT1VUTEVUXSA9IG5ldyBVcmxTZWdtZW50R3JvdXAoc2VnbWVudHMsIGNoaWxkcmVuKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuICBwYXJzZVNlZ21lbnQoKSB7XG4gICAgY29uc3QgcGF0aCA9IG1hdGNoU2VnbWVudHModGhpcy5yZW1haW5pbmcpO1xuICAgIGlmIChwYXRoID09PSAnJyAmJiB0aGlzLnBlZWtTdGFydHNXaXRoKCc7JykpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMDksICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGBFbXB0eSBwYXRoIHVybCBzZWdtZW50IGNhbm5vdCBoYXZlIHBhcmFtZXRlcnM6ICcke3RoaXMucmVtYWluaW5nfScuYCk7XG4gICAgfVxuICAgIHRoaXMuY2FwdHVyZShwYXRoKTtcbiAgICByZXR1cm4gbmV3IFVybFNlZ21lbnQoZGVjb2RlKHBhdGgpLCB0aGlzLnBhcnNlTWF0cml4UGFyYW1zKCkpO1xuICB9XG4gIHBhcnNlTWF0cml4UGFyYW1zKCkge1xuICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xuICAgIHdoaWxlICh0aGlzLmNvbnN1bWVPcHRpb25hbCgnOycpKSB7XG4gICAgICB0aGlzLnBhcnNlUGFyYW0ocGFyYW1zKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcmFtcztcbiAgfVxuICBwYXJzZVBhcmFtKHBhcmFtcykge1xuICAgIGNvbnN0IGtleSA9IG1hdGNoTWF0cml4S2V5U2VnbWVudHModGhpcy5yZW1haW5pbmcpO1xuICAgIGlmICgha2V5KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuY2FwdHVyZShrZXkpO1xuICAgIGxldCB2YWx1ZSA9ICcnO1xuICAgIGlmICh0aGlzLmNvbnN1bWVPcHRpb25hbCgnPScpKSB7XG4gICAgICBjb25zdCB2YWx1ZU1hdGNoID0gbWF0Y2hTZWdtZW50cyh0aGlzLnJlbWFpbmluZyk7XG4gICAgICBpZiAodmFsdWVNYXRjaCkge1xuICAgICAgICB2YWx1ZSA9IHZhbHVlTWF0Y2g7XG4gICAgICAgIHRoaXMuY2FwdHVyZSh2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHBhcmFtc1tkZWNvZGUoa2V5KV0gPSBkZWNvZGUodmFsdWUpO1xuICB9XG4gIHBhcnNlUXVlcnlQYXJhbShwYXJhbXMpIHtcbiAgICBjb25zdCBrZXkgPSBtYXRjaFF1ZXJ5UGFyYW1zKHRoaXMucmVtYWluaW5nKTtcbiAgICBpZiAoIWtleSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmNhcHR1cmUoa2V5KTtcbiAgICBsZXQgdmFsdWUgPSAnJztcbiAgICBpZiAodGhpcy5jb25zdW1lT3B0aW9uYWwoJz0nKSkge1xuICAgICAgY29uc3QgdmFsdWVNYXRjaCA9IG1hdGNoVXJsUXVlcnlQYXJhbVZhbHVlKHRoaXMucmVtYWluaW5nKTtcbiAgICAgIGlmICh2YWx1ZU1hdGNoKSB7XG4gICAgICAgIHZhbHVlID0gdmFsdWVNYXRjaDtcbiAgICAgICAgdGhpcy5jYXB0dXJlKHZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZGVjb2RlZEtleSA9IGRlY29kZVF1ZXJ5KGtleSk7XG4gICAgY29uc3QgZGVjb2RlZFZhbCA9IGRlY29kZVF1ZXJ5KHZhbHVlKTtcbiAgICBpZiAoT2JqZWN0Lmhhc093bihwYXJhbXMsIGRlY29kZWRLZXkpKSB7XG4gICAgICBsZXQgY3VycmVudFZhbCA9IHBhcmFtc1tkZWNvZGVkS2V5XTtcbiAgICAgIGlmICghQXJyYXkuaXNBcnJheShjdXJyZW50VmFsKSkge1xuICAgICAgICBjdXJyZW50VmFsID0gW2N1cnJlbnRWYWxdO1xuICAgICAgICBwYXJhbXNbZGVjb2RlZEtleV0gPSBjdXJyZW50VmFsO1xuICAgICAgfVxuICAgICAgY3VycmVudFZhbC5wdXNoKGRlY29kZWRWYWwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwYXJhbXNbZGVjb2RlZEtleV0gPSBkZWNvZGVkVmFsO1xuICAgIH1cbiAgfVxuICBwYXJzZVBhcmVucyhhbGxvd1ByaW1hcnksIGRlcHRoKSB7XG4gICAgY29uc3Qgc2VnbWVudHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHRoaXMuY2FwdHVyZSgnKCcpO1xuICAgIHdoaWxlICghdGhpcy5jb25zdW1lT3B0aW9uYWwoJyknKSAmJiB0aGlzLnJlbWFpbmluZy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBwYXRoID0gbWF0Y2hTZWdtZW50cyh0aGlzLnJlbWFpbmluZyk7XG4gICAgICBjb25zdCBuZXh0ID0gdGhpcy5yZW1haW5pbmdbcGF0aC5sZW5ndGhdO1xuICAgICAgaWYgKG5leHQgIT09ICcvJyAmJiBuZXh0ICE9PSAnKScgJiYgbmV4dCAhPT0gJzsnKSB7XG4gICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTAsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGBDYW5ub3QgcGFyc2UgdXJsICcke3RoaXMudXJsfSdgKTtcbiAgICAgIH1cbiAgICAgIGxldCBvdXRsZXROYW1lO1xuICAgICAgaWYgKHBhdGguaW5kZXhPZignOicpID4gLTEpIHtcbiAgICAgICAgb3V0bGV0TmFtZSA9IHBhdGguc2xpY2UoMCwgcGF0aC5pbmRleE9mKCc6JykpO1xuICAgICAgICB0aGlzLmNhcHR1cmUob3V0bGV0TmFtZSk7XG4gICAgICAgIHRoaXMuY2FwdHVyZSgnOicpO1xuICAgICAgfSBlbHNlIGlmIChhbGxvd1ByaW1hcnkpIHtcbiAgICAgICAgb3V0bGV0TmFtZSA9IFBSSU1BUllfT1VUTEVUO1xuICAgICAgfVxuICAgICAgY29uc3QgY2hpbGRyZW4gPSB0aGlzLnBhcnNlQ2hpbGRyZW4oZGVwdGggKyAxKTtcbiAgICAgIHNlZ21lbnRzW291dGxldE5hbWUgPz8gUFJJTUFSWV9PVVRMRVRdID0gT2JqZWN0LmtleXMoY2hpbGRyZW4pLmxlbmd0aCA9PT0gMSAmJiBjaGlsZHJlbltQUklNQVJZX09VVExFVF0gPyBjaGlsZHJlbltQUklNQVJZX09VVExFVF0gOiBuZXcgVXJsU2VnbWVudEdyb3VwKFtdLCBjaGlsZHJlbik7XG4gICAgICB0aGlzLmNvbnN1bWVPcHRpb25hbCgnLy8nKTtcbiAgICB9XG4gICAgcmV0dXJuIHNlZ21lbnRzO1xuICB9XG4gIHBlZWtTdGFydHNXaXRoKHN0cikge1xuICAgIHJldHVybiB0aGlzLnJlbWFpbmluZy5zdGFydHNXaXRoKHN0cik7XG4gIH1cbiAgY29uc3VtZU9wdGlvbmFsKHN0cikge1xuICAgIGlmICh0aGlzLnBlZWtTdGFydHNXaXRoKHN0cikpIHtcbiAgICAgIHRoaXMucmVtYWluaW5nID0gdGhpcy5yZW1haW5pbmcuc3Vic3RyaW5nKHN0ci5sZW5ndGgpO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjYXB0dXJlKHN0cikge1xuICAgIGlmICghdGhpcy5jb25zdW1lT3B0aW9uYWwoc3RyKSkge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxMSwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgYEV4cGVjdGVkIFwiJHtzdHJ9XCIuYCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBjcmVhdGVSb290KHJvb3RDYW5kaWRhdGUpIHtcbiAgcmV0dXJuIHJvb3RDYW5kaWRhdGUuc2VnbWVudHMubGVuZ3RoID4gMCA/IG5ldyBVcmxTZWdtZW50R3JvdXAoW10sIHtcbiAgICBbUFJJTUFSWV9PVVRMRVRdOiByb290Q2FuZGlkYXRlXG4gIH0pIDogcm9vdENhbmRpZGF0ZTtcbn1cbmZ1bmN0aW9uIHNxdWFzaFNlZ21lbnRHcm91cChzZWdtZW50R3JvdXApIHtcbiAgY29uc3QgbmV3Q2hpbGRyZW4gPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmb3IgKGNvbnN0IFtjaGlsZE91dGxldCwgY2hpbGRdIG9mIE9iamVjdC5lbnRyaWVzKHNlZ21lbnRHcm91cC5jaGlsZHJlbikpIHtcbiAgICBjb25zdCBjaGlsZENhbmRpZGF0ZSA9IHNxdWFzaFNlZ21lbnRHcm91cChjaGlsZCk7XG4gICAgaWYgKGNoaWxkT3V0bGV0ID09PSBQUklNQVJZX09VVExFVCAmJiBjaGlsZENhbmRpZGF0ZS5zZWdtZW50cy5sZW5ndGggPT09IDAgJiYgY2hpbGRDYW5kaWRhdGUuaGFzQ2hpbGRyZW4oKSkge1xuICAgICAgZm9yIChjb25zdCBbZ3JhbmRDaGlsZE91dGxldCwgZ3JhbmRDaGlsZF0gb2YgT2JqZWN0LmVudHJpZXMoY2hpbGRDYW5kaWRhdGUuY2hpbGRyZW4pKSB7XG4gICAgICAgIG5ld0NoaWxkcmVuW2dyYW5kQ2hpbGRPdXRsZXRdID0gZ3JhbmRDaGlsZDtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNoaWxkQ2FuZGlkYXRlLnNlZ21lbnRzLmxlbmd0aCA+IDAgfHwgY2hpbGRDYW5kaWRhdGUuaGFzQ2hpbGRyZW4oKSkge1xuICAgICAgbmV3Q2hpbGRyZW5bY2hpbGRPdXRsZXRdID0gY2hpbGRDYW5kaWRhdGU7XG4gICAgfVxuICB9XG4gIGNvbnN0IHMgPSBuZXcgVXJsU2VnbWVudEdyb3VwKHNlZ21lbnRHcm91cC5zZWdtZW50cywgbmV3Q2hpbGRyZW4pO1xuICByZXR1cm4gbWVyZ2VUcml2aWFsQ2hpbGRyZW4ocyk7XG59XG5mdW5jdGlvbiBtZXJnZVRyaXZpYWxDaGlsZHJlbihzKSB7XG4gIGlmIChzLm51bWJlck9mQ2hpbGRyZW4gPT09IDEgJiYgcy5jaGlsZHJlbltQUklNQVJZX09VVExFVF0pIHtcbiAgICBjb25zdCBjID0gcy5jaGlsZHJlbltQUklNQVJZX09VVExFVF07XG4gICAgcmV0dXJuIG5ldyBVcmxTZWdtZW50R3JvdXAocy5zZWdtZW50cy5jb25jYXQoYy5zZWdtZW50cyksIGMuY2hpbGRyZW4pO1xuICB9XG4gIHJldHVybiBzO1xufVxuZnVuY3Rpb24gaXNVcmxUcmVlKHYpIHtcbiAgcmV0dXJuIHYgaW5zdGFuY2VvZiBVcmxUcmVlO1xufVxuZnVuY3Rpb24gY3JlYXRlVXJsVHJlZUZyb21TbmFwc2hvdChyZWxhdGl2ZVRvLCBjb21tYW5kcywgcXVlcnlQYXJhbXMgPSBudWxsLCBmcmFnbWVudCA9IG51bGwsIHVybFNlcmlhbGl6ZXIgPSBuZXcgRGVmYXVsdFVybFNlcmlhbGl6ZXIoKSkge1xuICBjb25zdCByZWxhdGl2ZVRvVXJsU2VnbWVudEdyb3VwID0gY3JlYXRlU2VnbWVudEdyb3VwRnJvbVJvdXRlKHJlbGF0aXZlVG8pO1xuICByZXR1cm4gY3JlYXRlVXJsVHJlZUZyb21TZWdtZW50R3JvdXAocmVsYXRpdmVUb1VybFNlZ21lbnRHcm91cCwgY29tbWFuZHMsIHF1ZXJ5UGFyYW1zLCBmcmFnbWVudCwgdXJsU2VyaWFsaXplcik7XG59XG5mdW5jdGlvbiBjcmVhdGVTZWdtZW50R3JvdXBGcm9tUm91dGUocm91dGUpIHtcbiAgbGV0IHRhcmdldEdyb3VwO1xuICBmdW5jdGlvbiBjcmVhdGVTZWdtZW50R3JvdXBGcm9tUm91dGVSZWN1cnNpdmUoY3VycmVudFJvdXRlKSB7XG4gICAgY29uc3QgY2hpbGRPdXRsZXRzID0ge307XG4gICAgZm9yIChjb25zdCBjaGlsZFNuYXBzaG90IG9mIGN1cnJlbnRSb3V0ZS5jaGlsZHJlbikge1xuICAgICAgY29uc3Qgcm9vdCA9IGNyZWF0ZVNlZ21lbnRHcm91cEZyb21Sb3V0ZVJlY3Vyc2l2ZShjaGlsZFNuYXBzaG90KTtcbiAgICAgIGNoaWxkT3V0bGV0c1tjaGlsZFNuYXBzaG90Lm91dGxldF0gPSByb290O1xuICAgIH1cbiAgICBjb25zdCBzZWdtZW50R3JvdXAgPSBuZXcgVXJsU2VnbWVudEdyb3VwKGN1cnJlbnRSb3V0ZS51cmwsIGNoaWxkT3V0bGV0cyk7XG4gICAgaWYgKGN1cnJlbnRSb3V0ZSA9PT0gcm91dGUpIHtcbiAgICAgIHRhcmdldEdyb3VwID0gc2VnbWVudEdyb3VwO1xuICAgIH1cbiAgICByZXR1cm4gc2VnbWVudEdyb3VwO1xuICB9XG4gIGNvbnN0IHJvb3RDYW5kaWRhdGUgPSBjcmVhdGVTZWdtZW50R3JvdXBGcm9tUm91dGVSZWN1cnNpdmUocm91dGUucm9vdCk7XG4gIGNvbnN0IHJvb3RTZWdtZW50R3JvdXAgPSBjcmVhdGVSb290KHJvb3RDYW5kaWRhdGUpO1xuICByZXR1cm4gdGFyZ2V0R3JvdXAgPz8gcm9vdFNlZ21lbnRHcm91cDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVVybFRyZWVGcm9tU2VnbWVudEdyb3VwKHJlbGF0aXZlVG8sIGNvbW1hbmRzLCBxdWVyeVBhcmFtcywgZnJhZ21lbnQsIHVybFNlcmlhbGl6ZXIpIHtcbiAgbGV0IHJvb3QgPSByZWxhdGl2ZVRvO1xuICB3aGlsZSAocm9vdC5wYXJlbnQpIHtcbiAgICByb290ID0gcm9vdC5wYXJlbnQ7XG4gIH1cbiAgaWYgKGNvbW1hbmRzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiB0cmVlKHJvb3QsIHJvb3QsIHJvb3QsIHF1ZXJ5UGFyYW1zLCBmcmFnbWVudCwgdXJsU2VyaWFsaXplcik7XG4gIH1cbiAgY29uc3QgbmF2ID0gY29tcHV0ZU5hdmlnYXRpb24oY29tbWFuZHMpO1xuICBpZiAobmF2LnRvUm9vdCgpKSB7XG4gICAgcmV0dXJuIHRyZWUocm9vdCwgcm9vdCwgbmV3IFVybFNlZ21lbnRHcm91cChbXSwge30pLCBxdWVyeVBhcmFtcywgZnJhZ21lbnQsIHVybFNlcmlhbGl6ZXIpO1xuICB9XG4gIGNvbnN0IHBvc2l0aW9uID0gZmluZFN0YXJ0aW5nUG9zaXRpb25Gb3JUYXJnZXRHcm91cChuYXYsIHJvb3QsIHJlbGF0aXZlVG8pO1xuICBjb25zdCBuZXdTZWdtZW50R3JvdXAgPSBwb3NpdGlvbi5wcm9jZXNzQ2hpbGRyZW4gPyB1cGRhdGVTZWdtZW50R3JvdXBDaGlsZHJlbihwb3NpdGlvbi5zZWdtZW50R3JvdXAsIHBvc2l0aW9uLmluZGV4LCBuYXYuY29tbWFuZHMpIDogdXBkYXRlU2VnbWVudEdyb3VwKHBvc2l0aW9uLnNlZ21lbnRHcm91cCwgcG9zaXRpb24uaW5kZXgsIG5hdi5jb21tYW5kcyk7XG4gIHJldHVybiB0cmVlKHJvb3QsIHBvc2l0aW9uLnNlZ21lbnRHcm91cCwgbmV3U2VnbWVudEdyb3VwLCBxdWVyeVBhcmFtcywgZnJhZ21lbnQsIHVybFNlcmlhbGl6ZXIpO1xufVxuZnVuY3Rpb24gaXNNYXRyaXhQYXJhbXMoY29tbWFuZCkge1xuICByZXR1cm4gdHlwZW9mIGNvbW1hbmQgPT09ICdvYmplY3QnICYmIGNvbW1hbmQgIT0gbnVsbCAmJiAhY29tbWFuZC5vdXRsZXRzICYmICFjb21tYW5kLnNlZ21lbnRQYXRoO1xufVxuZnVuY3Rpb24gaXNDb21tYW5kV2l0aE91dGxldHMoY29tbWFuZCkge1xuICByZXR1cm4gdHlwZW9mIGNvbW1hbmQgPT09ICdvYmplY3QnICYmIGNvbW1hbmQgIT0gbnVsbCAmJiBjb21tYW5kLm91dGxldHM7XG59XG5mdW5jdGlvbiBub3JtYWxpemVRdWVyeVBhcmFtcyhrLCB2LCB1cmxTZXJpYWxpemVyKSB7XG4gIGsgfHw9ICfJtSc7XG4gIGNvbnN0IHRyZWUgPSBuZXcgVXJsVHJlZSgpO1xuICB0cmVlLnF1ZXJ5UGFyYW1zID0ge1xuICAgIFtrXTogdlxuICB9O1xuICByZXR1cm4gdXJsU2VyaWFsaXplci5wYXJzZSh1cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0cmVlKSkucXVlcnlQYXJhbXNba107XG59XG5mdW5jdGlvbiB0cmVlKG9sZFJvb3QsIG9sZFNlZ21lbnRHcm91cCwgbmV3U2VnbWVudEdyb3VwLCBxdWVyeVBhcmFtcywgZnJhZ21lbnQsIHVybFNlcmlhbGl6ZXIpIHtcbiAgY29uc3QgcXAgPSB7fTtcbiAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMocXVlcnlQYXJhbXMgPz8ge30pKSB7XG4gICAgcXBba2V5XSA9IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKHYgPT4gbm9ybWFsaXplUXVlcnlQYXJhbXMoa2V5LCB2LCB1cmxTZXJpYWxpemVyKSkgOiBub3JtYWxpemVRdWVyeVBhcmFtcyhrZXksIHZhbHVlLCB1cmxTZXJpYWxpemVyKTtcbiAgfVxuICBsZXQgcm9vdENhbmRpZGF0ZTtcbiAgaWYgKG9sZFJvb3QgPT09IG9sZFNlZ21lbnRHcm91cCkge1xuICAgIHJvb3RDYW5kaWRhdGUgPSBuZXdTZWdtZW50R3JvdXA7XG4gIH0gZWxzZSB7XG4gICAgcm9vdENhbmRpZGF0ZSA9IHJlcGxhY2VTZWdtZW50KG9sZFJvb3QsIG9sZFNlZ21lbnRHcm91cCwgbmV3U2VnbWVudEdyb3VwKTtcbiAgfVxuICBjb25zdCBuZXdSb290ID0gY3JlYXRlUm9vdChzcXVhc2hTZWdtZW50R3JvdXAocm9vdENhbmRpZGF0ZSkpO1xuICByZXR1cm4gbmV3IFVybFRyZWUobmV3Um9vdCwgcXAsIGZyYWdtZW50KTtcbn1cbmZ1bmN0aW9uIHJlcGxhY2VTZWdtZW50KGN1cnJlbnQsIG9sZFNlZ21lbnQsIG5ld1NlZ21lbnQpIHtcbiAgY29uc3QgY2hpbGRyZW4gPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBPYmplY3QuZW50cmllcyhjdXJyZW50LmNoaWxkcmVuKS5mb3JFYWNoKChbb3V0bGV0TmFtZSwgY10pID0+IHtcbiAgICBpZiAoYyA9PT0gb2xkU2VnbWVudCkge1xuICAgICAgY2hpbGRyZW5bb3V0bGV0TmFtZV0gPSBuZXdTZWdtZW50O1xuICAgIH0gZWxzZSB7XG4gICAgICBjaGlsZHJlbltvdXRsZXROYW1lXSA9IHJlcGxhY2VTZWdtZW50KGMsIG9sZFNlZ21lbnQsIG5ld1NlZ21lbnQpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBuZXcgVXJsU2VnbWVudEdyb3VwKGN1cnJlbnQuc2VnbWVudHMsIGNoaWxkcmVuKTtcbn1cbmNsYXNzIE5hdmlnYXRpb24ge1xuICBpc0Fic29sdXRlO1xuICBudW1iZXJPZkRvdWJsZURvdHM7XG4gIGNvbW1hbmRzO1xuICBjb25zdHJ1Y3Rvcihpc0Fic29sdXRlLCBudW1iZXJPZkRvdWJsZURvdHMsIGNvbW1hbmRzKSB7XG4gICAgdGhpcy5pc0Fic29sdXRlID0gaXNBYnNvbHV0ZTtcbiAgICB0aGlzLm51bWJlck9mRG91YmxlRG90cyA9IG51bWJlck9mRG91YmxlRG90cztcbiAgICB0aGlzLmNvbW1hbmRzID0gY29tbWFuZHM7XG4gICAgaWYgKGlzQWJzb2x1dGUgJiYgY29tbWFuZHMubGVuZ3RoID4gMCAmJiBpc01hdHJpeFBhcmFtcyhjb21tYW5kc1swXSkpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMDMsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICdSb290IHNlZ21lbnQgY2Fubm90IGhhdmUgbWF0cml4IHBhcmFtZXRlcnMnKTtcbiAgICB9XG4gICAgY29uc3QgY21kV2l0aE91dGxldCA9IGNvbW1hbmRzLmZpbmQoaXNDb21tYW5kV2l0aE91dGxldHMpO1xuICAgIGlmIChjbWRXaXRoT3V0bGV0ICYmIGNtZFdpdGhPdXRsZXQgIT09IGxhc3QoY29tbWFuZHMpKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDA0LCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiAne291dGxldHM6e319IGhhcyB0byBiZSB0aGUgbGFzdCBjb21tYW5kJyk7XG4gICAgfVxuICB9XG4gIHRvUm9vdCgpIHtcbiAgICByZXR1cm4gdGhpcy5pc0Fic29sdXRlICYmIHRoaXMuY29tbWFuZHMubGVuZ3RoID09PSAxICYmIHRoaXMuY29tbWFuZHNbMF0gPT0gJy8nO1xuICB9XG59XG5mdW5jdGlvbiBjb21wdXRlTmF2aWdhdGlvbihjb21tYW5kcykge1xuICBpZiAodHlwZW9mIGNvbW1hbmRzWzBdID09PSAnc3RyaW5nJyAmJiBjb21tYW5kcy5sZW5ndGggPT09IDEgJiYgY29tbWFuZHNbMF0gPT09ICcvJykge1xuICAgIHJldHVybiBuZXcgTmF2aWdhdGlvbih0cnVlLCAwLCBjb21tYW5kcyk7XG4gIH1cbiAgbGV0IG51bWJlck9mRG91YmxlRG90cyA9IDA7XG4gIGxldCBpc0Fic29sdXRlID0gZmFsc2U7XG4gIGNvbnN0IHJlcyA9IGNvbW1hbmRzLnJlZHVjZSgocmVzLCBjbWQsIGNtZElkeCkgPT4ge1xuICAgIGlmICh0eXBlb2YgY21kID09PSAnb2JqZWN0JyAmJiBjbWQgIT0gbnVsbCkge1xuICAgICAgaWYgKGNtZC5vdXRsZXRzKSB7XG4gICAgICAgIGNvbnN0IG91dGxldHMgPSB7fTtcbiAgICAgICAgT2JqZWN0LmVudHJpZXMoY21kLm91dGxldHMpLmZvckVhY2goKFtuYW1lLCBjb21tYW5kc10pID0+IHtcbiAgICAgICAgICBvdXRsZXRzW25hbWVdID0gdHlwZW9mIGNvbW1hbmRzID09PSAnc3RyaW5nJyA/IGNvbW1hbmRzLnNwbGl0KCcvJykgOiBjb21tYW5kcztcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBbLi4ucmVzLCB7XG4gICAgICAgICAgb3V0bGV0c1xuICAgICAgICB9XTtcbiAgICAgIH1cbiAgICAgIGlmIChjbWQuc2VnbWVudFBhdGgpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5yZXMsIGNtZC5zZWdtZW50UGF0aF07XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghKHR5cGVvZiBjbWQgPT09ICdzdHJpbmcnKSkge1xuICAgICAgcmV0dXJuIFsuLi5yZXMsIGNtZF07XG4gICAgfVxuICAgIGlmIChjbWRJZHggPT09IDApIHtcbiAgICAgIGNtZC5zcGxpdCgnLycpLmZvckVhY2goKHVybFBhcnQsIHBhcnRJbmRleCkgPT4ge1xuICAgICAgICBpZiAocGFydEluZGV4ID09IDAgJiYgdXJsUGFydCA9PT0gJy4nKSA7ZWxzZSBpZiAocGFydEluZGV4ID09IDAgJiYgdXJsUGFydCA9PT0gJycpIHtcbiAgICAgICAgICBpc0Fic29sdXRlID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmICh1cmxQYXJ0ID09PSAnLi4nKSB7XG4gICAgICAgICAgbnVtYmVyT2ZEb3VibGVEb3RzKys7XG4gICAgICAgIH0gZWxzZSBpZiAodXJsUGFydCAhPSAnJykge1xuICAgICAgICAgIHJlcy5wdXNoKHVybFBhcnQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXM7XG4gICAgfVxuICAgIHJldHVybiBbLi4ucmVzLCBjbWRdO1xuICB9LCBbXSk7XG4gIHJldHVybiBuZXcgTmF2aWdhdGlvbihpc0Fic29sdXRlLCBudW1iZXJPZkRvdWJsZURvdHMsIHJlcyk7XG59XG5jbGFzcyBQb3NpdGlvbiB7XG4gIHNlZ21lbnRHcm91cDtcbiAgcHJvY2Vzc0NoaWxkcmVuO1xuICBpbmRleDtcbiAgY29uc3RydWN0b3Ioc2VnbWVudEdyb3VwLCBwcm9jZXNzQ2hpbGRyZW4sIGluZGV4KSB7XG4gICAgdGhpcy5zZWdtZW50R3JvdXAgPSBzZWdtZW50R3JvdXA7XG4gICAgdGhpcy5wcm9jZXNzQ2hpbGRyZW4gPSBwcm9jZXNzQ2hpbGRyZW47XG4gICAgdGhpcy5pbmRleCA9IGluZGV4O1xuICB9XG59XG5mdW5jdGlvbiBmaW5kU3RhcnRpbmdQb3NpdGlvbkZvclRhcmdldEdyb3VwKG5hdiwgcm9vdCwgdGFyZ2V0KSB7XG4gIGlmIChuYXYuaXNBYnNvbHV0ZSkge1xuICAgIHJldHVybiBuZXcgUG9zaXRpb24ocm9vdCwgdHJ1ZSwgMCk7XG4gIH1cbiAgaWYgKCF0YXJnZXQpIHtcbiAgICByZXR1cm4gbmV3IFBvc2l0aW9uKHJvb3QsIGZhbHNlLCBOYU4pO1xuICB9XG4gIGlmICh0YXJnZXQucGFyZW50ID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG5ldyBQb3NpdGlvbih0YXJnZXQsIHRydWUsIDApO1xuICB9XG4gIGNvbnN0IG1vZGlmaWVyID0gaXNNYXRyaXhQYXJhbXMobmF2LmNvbW1hbmRzWzBdKSA/IDAgOiAxO1xuICBjb25zdCBpbmRleCA9IHRhcmdldC5zZWdtZW50cy5sZW5ndGggLSAxICsgbW9kaWZpZXI7XG4gIHJldHVybiBjcmVhdGVQb3NpdGlvbkFwcGx5aW5nRG91YmxlRG90cyh0YXJnZXQsIGluZGV4LCBuYXYubnVtYmVyT2ZEb3VibGVEb3RzKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVBvc2l0aW9uQXBwbHlpbmdEb3VibGVEb3RzKGdyb3VwLCBpbmRleCwgbnVtYmVyT2ZEb3VibGVEb3RzKSB7XG4gIGxldCBnID0gZ3JvdXA7XG4gIGxldCBjaSA9IGluZGV4O1xuICBsZXQgZGQgPSBudW1iZXJPZkRvdWJsZURvdHM7XG4gIHdoaWxlIChkZCA+IGNpKSB7XG4gICAgZGQgLT0gY2k7XG4gICAgZyA9IGcucGFyZW50O1xuICAgIGlmICghZykge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAwNSwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgXCJJbnZhbGlkIG51bWJlciBvZiAnLi4vJ1wiKTtcbiAgICB9XG4gICAgY2kgPSBnLnNlZ21lbnRzLmxlbmd0aDtcbiAgfVxuICByZXR1cm4gbmV3IFBvc2l0aW9uKGcsIGZhbHNlLCBjaSAtIGRkKTtcbn1cbmZ1bmN0aW9uIGdldE91dGxldHMoY29tbWFuZHMpIHtcbiAgaWYgKGlzQ29tbWFuZFdpdGhPdXRsZXRzKGNvbW1hbmRzWzBdKSkge1xuICAgIHJldHVybiBjb21tYW5kc1swXS5vdXRsZXRzO1xuICB9XG4gIHJldHVybiB7XG4gICAgW1BSSU1BUllfT1VUTEVUXTogY29tbWFuZHNcbiAgfTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZVNlZ21lbnRHcm91cChzZWdtZW50R3JvdXAsIHN0YXJ0SW5kZXgsIGNvbW1hbmRzKSB7XG4gIHNlZ21lbnRHcm91cCA/Pz0gbmV3IFVybFNlZ21lbnRHcm91cChbXSwge30pO1xuICBpZiAoc2VnbWVudEdyb3VwLnNlZ21lbnRzLmxlbmd0aCA9PT0gMCAmJiBzZWdtZW50R3JvdXAuaGFzQ2hpbGRyZW4oKSkge1xuICAgIHJldHVybiB1cGRhdGVTZWdtZW50R3JvdXBDaGlsZHJlbihzZWdtZW50R3JvdXAsIHN0YXJ0SW5kZXgsIGNvbW1hbmRzKTtcbiAgfVxuICBjb25zdCBtID0gcHJlZml4ZWRXaXRoKHNlZ21lbnRHcm91cCwgc3RhcnRJbmRleCwgY29tbWFuZHMpO1xuICBjb25zdCBzbGljZWRDb21tYW5kcyA9IGNvbW1hbmRzLnNsaWNlKG0uY29tbWFuZEluZGV4KTtcbiAgaWYgKG0ubWF0Y2ggJiYgbS5wYXRoSW5kZXggPCBzZWdtZW50R3JvdXAuc2VnbWVudHMubGVuZ3RoKSB7XG4gICAgY29uc3QgZyA9IG5ldyBVcmxTZWdtZW50R3JvdXAoc2VnbWVudEdyb3VwLnNlZ21lbnRzLnNsaWNlKDAsIG0ucGF0aEluZGV4KSwge30pO1xuICAgIGcuY2hpbGRyZW5bUFJJTUFSWV9PVVRMRVRdID0gbmV3IFVybFNlZ21lbnRHcm91cChzZWdtZW50R3JvdXAuc2VnbWVudHMuc2xpY2UobS5wYXRoSW5kZXgpLCBzZWdtZW50R3JvdXAuY2hpbGRyZW4pO1xuICAgIHJldHVybiB1cGRhdGVTZWdtZW50R3JvdXBDaGlsZHJlbihnLCAwLCBzbGljZWRDb21tYW5kcyk7XG4gIH0gZWxzZSBpZiAobS5tYXRjaCAmJiBzbGljZWRDb21tYW5kcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gbmV3IFVybFNlZ21lbnRHcm91cChzZWdtZW50R3JvdXAuc2VnbWVudHMsIHt9KTtcbiAgfSBlbHNlIGlmIChtLm1hdGNoICYmICFzZWdtZW50R3JvdXAuaGFzQ2hpbGRyZW4oKSkge1xuICAgIHJldHVybiBjcmVhdGVOZXdTZWdtZW50R3JvdXAoc2VnbWVudEdyb3VwLCBzdGFydEluZGV4LCBjb21tYW5kcyk7XG4gIH0gZWxzZSBpZiAobS5tYXRjaCkge1xuICAgIHJldHVybiB1cGRhdGVTZWdtZW50R3JvdXBDaGlsZHJlbihzZWdtZW50R3JvdXAsIDAsIHNsaWNlZENvbW1hbmRzKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY3JlYXRlTmV3U2VnbWVudEdyb3VwKHNlZ21lbnRHcm91cCwgc3RhcnRJbmRleCwgY29tbWFuZHMpO1xuICB9XG59XG5mdW5jdGlvbiB1cGRhdGVTZWdtZW50R3JvdXBDaGlsZHJlbihzZWdtZW50R3JvdXAsIHN0YXJ0SW5kZXgsIGNvbW1hbmRzKSB7XG4gIGlmIChjb21tYW5kcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gbmV3IFVybFNlZ21lbnRHcm91cChzZWdtZW50R3JvdXAuc2VnbWVudHMsIHt9KTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCBvdXRsZXRzID0gZ2V0T3V0bGV0cyhjb21tYW5kcyk7XG4gICAgY29uc3QgY2hpbGRyZW4gPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIGlmIChPYmplY3Qua2V5cyhvdXRsZXRzKS5zb21lKG8gPT4gbyAhPT0gUFJJTUFSWV9PVVRMRVQpICYmIHNlZ21lbnRHcm91cC5jaGlsZHJlbltQUklNQVJZX09VVExFVF0gJiYgc2VnbWVudEdyb3VwLm51bWJlck9mQ2hpbGRyZW4gPT09IDEgJiYgc2VnbWVudEdyb3VwLmNoaWxkcmVuW1BSSU1BUllfT1VUTEVUXS5zZWdtZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuT2ZFbXB0eUNoaWxkID0gdXBkYXRlU2VnbWVudEdyb3VwQ2hpbGRyZW4oc2VnbWVudEdyb3VwLmNoaWxkcmVuW1BSSU1BUllfT1VUTEVUXSwgc3RhcnRJbmRleCwgY29tbWFuZHMpO1xuICAgICAgcmV0dXJuIG5ldyBVcmxTZWdtZW50R3JvdXAoc2VnbWVudEdyb3VwLnNlZ21lbnRzLCBjaGlsZHJlbk9mRW1wdHlDaGlsZC5jaGlsZHJlbik7XG4gICAgfVxuICAgIE9iamVjdC5lbnRyaWVzKG91dGxldHMpLmZvckVhY2goKFtvdXRsZXQsIGNvbW1hbmRzXSkgPT4ge1xuICAgICAgaWYgKHR5cGVvZiBjb21tYW5kcyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgY29tbWFuZHMgPSBbY29tbWFuZHNdO1xuICAgICAgfVxuICAgICAgaWYgKGNvbW1hbmRzICE9PSBudWxsKSB7XG4gICAgICAgIGNoaWxkcmVuW291dGxldF0gPSB1cGRhdGVTZWdtZW50R3JvdXAoc2VnbWVudEdyb3VwLmNoaWxkcmVuW291dGxldF0sIHN0YXJ0SW5kZXgsIGNvbW1hbmRzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBPYmplY3QuZW50cmllcyhzZWdtZW50R3JvdXAuY2hpbGRyZW4pLmZvckVhY2goKFtjaGlsZE91dGxldCwgY2hpbGRdKSA9PiB7XG4gICAgICBpZiAob3V0bGV0c1tjaGlsZE91dGxldF0gPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBjaGlsZHJlbltjaGlsZE91dGxldF0gPSBjaGlsZDtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gbmV3IFVybFNlZ21lbnRHcm91cChzZWdtZW50R3JvdXAuc2VnbWVudHMsIGNoaWxkcmVuKTtcbiAgfVxufVxuZnVuY3Rpb24gcHJlZml4ZWRXaXRoKHNlZ21lbnRHcm91cCwgc3RhcnRJbmRleCwgY29tbWFuZHMpIHtcbiAgbGV0IGN1cnJlbnRDb21tYW5kSW5kZXggPSAwO1xuICBsZXQgY3VycmVudFBhdGhJbmRleCA9IHN0YXJ0SW5kZXg7XG4gIGNvbnN0IG5vTWF0Y2ggPSB7XG4gICAgbWF0Y2g6IGZhbHNlLFxuICAgIHBhdGhJbmRleDogMCxcbiAgICBjb21tYW5kSW5kZXg6IDBcbiAgfTtcbiAgd2hpbGUgKGN1cnJlbnRQYXRoSW5kZXggPCBzZWdtZW50R3JvdXAuc2VnbWVudHMubGVuZ3RoKSB7XG4gICAgaWYgKGN1cnJlbnRDb21tYW5kSW5kZXggPj0gY29tbWFuZHMubGVuZ3RoKSByZXR1cm4gbm9NYXRjaDtcbiAgICBjb25zdCBwYXRoID0gc2VnbWVudEdyb3VwLnNlZ21lbnRzW2N1cnJlbnRQYXRoSW5kZXhdO1xuICAgIGNvbnN0IGNvbW1hbmQgPSBjb21tYW5kc1tjdXJyZW50Q29tbWFuZEluZGV4XTtcbiAgICBpZiAoaXNDb21tYW5kV2l0aE91dGxldHMoY29tbWFuZCkpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjb25zdCBjdXJyID0gYCR7Y29tbWFuZH1gO1xuICAgIGNvbnN0IG5leHQgPSBjdXJyZW50Q29tbWFuZEluZGV4IDwgY29tbWFuZHMubGVuZ3RoIC0gMSA/IGNvbW1hbmRzW2N1cnJlbnRDb21tYW5kSW5kZXggKyAxXSA6IG51bGw7XG4gICAgaWYgKGN1cnJlbnRQYXRoSW5kZXggPiAwICYmIGN1cnIgPT09IHVuZGVmaW5lZCkgYnJlYWs7XG4gICAgaWYgKGN1cnIgJiYgbmV4dCAmJiB0eXBlb2YgbmV4dCA9PT0gJ29iamVjdCcgJiYgbmV4dC5vdXRsZXRzID09PSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICghY29tcGFyZShjdXJyLCBuZXh0LCBwYXRoKSkgcmV0dXJuIG5vTWF0Y2g7XG4gICAgICBjdXJyZW50Q29tbWFuZEluZGV4ICs9IDI7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghY29tcGFyZShjdXJyLCB7fSwgcGF0aCkpIHJldHVybiBub01hdGNoO1xuICAgICAgY3VycmVudENvbW1hbmRJbmRleCsrO1xuICAgIH1cbiAgICBjdXJyZW50UGF0aEluZGV4Kys7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBtYXRjaDogdHJ1ZSxcbiAgICBwYXRoSW5kZXg6IGN1cnJlbnRQYXRoSW5kZXgsXG4gICAgY29tbWFuZEluZGV4OiBjdXJyZW50Q29tbWFuZEluZGV4XG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVOZXdTZWdtZW50R3JvdXAoc2VnbWVudEdyb3VwLCBzdGFydEluZGV4LCBjb21tYW5kcykge1xuICBjb25zdCBwYXRocyA9IHNlZ21lbnRHcm91cC5zZWdtZW50cy5zbGljZSgwLCBzdGFydEluZGV4KTtcbiAgbGV0IGkgPSAwO1xuICB3aGlsZSAoaSA8IGNvbW1hbmRzLmxlbmd0aCkge1xuICAgIGNvbnN0IGNvbW1hbmQgPSBjb21tYW5kc1tpXTtcbiAgICBpZiAoaXNDb21tYW5kV2l0aE91dGxldHMoY29tbWFuZCkpIHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuID0gY3JlYXRlTmV3U2VnbWVudENoaWxkcmVuKGNvbW1hbmQub3V0bGV0cyk7XG4gICAgICByZXR1cm4gbmV3IFVybFNlZ21lbnRHcm91cChwYXRocywgY2hpbGRyZW4pO1xuICAgIH1cbiAgICBpZiAoaSA9PT0gMCAmJiBpc01hdHJpeFBhcmFtcyhjb21tYW5kc1swXSkpIHtcbiAgICAgIGNvbnN0IHAgPSBzZWdtZW50R3JvdXAuc2VnbWVudHNbc3RhcnRJbmRleF07XG4gICAgICBwYXRocy5wdXNoKG5ldyBVcmxTZWdtZW50KHAucGF0aCwgc3RyaW5naWZ5KGNvbW1hbmRzWzBdKSkpO1xuICAgICAgaSsrO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGN1cnIgPSBpc0NvbW1hbmRXaXRoT3V0bGV0cyhjb21tYW5kKSA/IGNvbW1hbmQub3V0bGV0c1tQUklNQVJZX09VVExFVF0gOiBgJHtjb21tYW5kfWA7XG4gICAgY29uc3QgbmV4dCA9IGkgPCBjb21tYW5kcy5sZW5ndGggLSAxID8gY29tbWFuZHNbaSArIDFdIDogbnVsbDtcbiAgICBpZiAoY3VyciAmJiBuZXh0ICYmIGlzTWF0cml4UGFyYW1zKG5leHQpKSB7XG4gICAgICBwYXRocy5wdXNoKG5ldyBVcmxTZWdtZW50KGN1cnIsIHN0cmluZ2lmeShuZXh0KSkpO1xuICAgICAgaSArPSAyO1xuICAgIH0gZWxzZSB7XG4gICAgICBwYXRocy5wdXNoKG5ldyBVcmxTZWdtZW50KGN1cnIsIHt9KSk7XG4gICAgICBpKys7XG4gICAgfVxuICB9XG4gIHJldHVybiBuZXcgVXJsU2VnbWVudEdyb3VwKHBhdGhzLCB7fSk7XG59XG5mdW5jdGlvbiBjcmVhdGVOZXdTZWdtZW50Q2hpbGRyZW4ob3V0bGV0cykge1xuICBjb25zdCBjaGlsZHJlbiA9IHt9O1xuICBPYmplY3QuZW50cmllcyhvdXRsZXRzKS5mb3JFYWNoKChbb3V0bGV0LCBjb21tYW5kc10pID0+IHtcbiAgICBpZiAodHlwZW9mIGNvbW1hbmRzID09PSAnc3RyaW5nJykge1xuICAgICAgY29tbWFuZHMgPSBbY29tbWFuZHNdO1xuICAgIH1cbiAgICBpZiAoY29tbWFuZHMgIT09IG51bGwpIHtcbiAgICAgIGNoaWxkcmVuW291dGxldF0gPSBjcmVhdGVOZXdTZWdtZW50R3JvdXAobmV3IFVybFNlZ21lbnRHcm91cChbXSwge30pLCAwLCBjb21tYW5kcyk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGNoaWxkcmVuO1xufVxuZnVuY3Rpb24gc3RyaW5naWZ5KHBhcmFtcykge1xuICBjb25zdCByZXMgPSB7fTtcbiAgT2JqZWN0LmVudHJpZXMocGFyYW1zKS5mb3JFYWNoKChbaywgdl0pID0+IHJlc1trXSA9IGAke3Z9YCk7XG4gIHJldHVybiByZXM7XG59XG5mdW5jdGlvbiBjb21wYXJlKHBhdGgsIHBhcmFtcywgc2VnbWVudCkge1xuICByZXR1cm4gcGF0aCA9PSBzZWdtZW50LnBhdGggJiYgc2hhbGxvd0VxdWFsKHBhcmFtcywgc2VnbWVudC5wYXJhbWV0ZXJzKTtcbn1cbmNvbnN0IElNUEVSQVRJVkVfTkFWSUdBVElPTiA9ICdpbXBlcmF0aXZlJztcbnZhciBFdmVudFR5cGU7XG4oZnVuY3Rpb24gKEV2ZW50VHlwZSkge1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiTmF2aWdhdGlvblN0YXJ0XCJdID0gMF0gPSBcIk5hdmlnYXRpb25TdGFydFwiO1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiTmF2aWdhdGlvbkVuZFwiXSA9IDFdID0gXCJOYXZpZ2F0aW9uRW5kXCI7XG4gIEV2ZW50VHlwZVtFdmVudFR5cGVbXCJOYXZpZ2F0aW9uQ2FuY2VsXCJdID0gMl0gPSBcIk5hdmlnYXRpb25DYW5jZWxcIjtcbiAgRXZlbnRUeXBlW0V2ZW50VHlwZVtcIk5hdmlnYXRpb25FcnJvclwiXSA9IDNdID0gXCJOYXZpZ2F0aW9uRXJyb3JcIjtcbiAgRXZlbnRUeXBlW0V2ZW50VHlwZVtcIlJvdXRlc1JlY29nbml6ZWRcIl0gPSA0XSA9IFwiUm91dGVzUmVjb2duaXplZFwiO1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiUmVzb2x2ZVN0YXJ0XCJdID0gNV0gPSBcIlJlc29sdmVTdGFydFwiO1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiUmVzb2x2ZUVuZFwiXSA9IDZdID0gXCJSZXNvbHZlRW5kXCI7XG4gIEV2ZW50VHlwZVtFdmVudFR5cGVbXCJHdWFyZHNDaGVja1N0YXJ0XCJdID0gN10gPSBcIkd1YXJkc0NoZWNrU3RhcnRcIjtcbiAgRXZlbnRUeXBlW0V2ZW50VHlwZVtcIkd1YXJkc0NoZWNrRW5kXCJdID0gOF0gPSBcIkd1YXJkc0NoZWNrRW5kXCI7XG4gIEV2ZW50VHlwZVtFdmVudFR5cGVbXCJSb3V0ZUNvbmZpZ0xvYWRTdGFydFwiXSA9IDldID0gXCJSb3V0ZUNvbmZpZ0xvYWRTdGFydFwiO1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiUm91dGVDb25maWdMb2FkRW5kXCJdID0gMTBdID0gXCJSb3V0ZUNvbmZpZ0xvYWRFbmRcIjtcbiAgRXZlbnRUeXBlW0V2ZW50VHlwZVtcIkNoaWxkQWN0aXZhdGlvblN0YXJ0XCJdID0gMTFdID0gXCJDaGlsZEFjdGl2YXRpb25TdGFydFwiO1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiQ2hpbGRBY3RpdmF0aW9uRW5kXCJdID0gMTJdID0gXCJDaGlsZEFjdGl2YXRpb25FbmRcIjtcbiAgRXZlbnRUeXBlW0V2ZW50VHlwZVtcIkFjdGl2YXRpb25TdGFydFwiXSA9IDEzXSA9IFwiQWN0aXZhdGlvblN0YXJ0XCI7XG4gIEV2ZW50VHlwZVtFdmVudFR5cGVbXCJBY3RpdmF0aW9uRW5kXCJdID0gMTRdID0gXCJBY3RpdmF0aW9uRW5kXCI7XG4gIEV2ZW50VHlwZVtFdmVudFR5cGVbXCJTY3JvbGxcIl0gPSAxNV0gPSBcIlNjcm9sbFwiO1xuICBFdmVudFR5cGVbRXZlbnRUeXBlW1wiTmF2aWdhdGlvblNraXBwZWRcIl0gPSAxNl0gPSBcIk5hdmlnYXRpb25Ta2lwcGVkXCI7XG59KShFdmVudFR5cGUgfHwgKEV2ZW50VHlwZSA9IHt9KSk7XG5jbGFzcyBSb3V0ZXJFdmVudCB7XG4gIGlkO1xuICB1cmw7XG4gIGNvbnN0cnVjdG9yKGlkLCB1cmwpIHtcbiAgICB0aGlzLmlkID0gaWQ7XG4gICAgdGhpcy51cmwgPSB1cmw7XG4gIH1cbn1cbmNsYXNzIE5hdmlnYXRpb25TdGFydCBleHRlbmRzIFJvdXRlckV2ZW50IHtcbiAgdHlwZSA9IEV2ZW50VHlwZS5OYXZpZ2F0aW9uU3RhcnQ7XG4gIG5hdmlnYXRpb25UcmlnZ2VyO1xuICByZXN0b3JlZFN0YXRlO1xuICBjb25zdHJ1Y3RvcihpZCwgdXJsLCBuYXZpZ2F0aW9uVHJpZ2dlciA9ICdpbXBlcmF0aXZlJywgcmVzdG9yZWRTdGF0ZSA9IG51bGwpIHtcbiAgICBzdXBlcihpZCwgdXJsKTtcbiAgICB0aGlzLm5hdmlnYXRpb25UcmlnZ2VyID0gbmF2aWdhdGlvblRyaWdnZXI7XG4gICAgdGhpcy5yZXN0b3JlZFN0YXRlID0gcmVzdG9yZWRTdGF0ZTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYE5hdmlnYXRpb25TdGFydChpZDogJHt0aGlzLmlkfSwgdXJsOiAnJHt0aGlzLnVybH0nKWA7XG4gIH1cbn1cbmNsYXNzIE5hdmlnYXRpb25FbmQgZXh0ZW5kcyBSb3V0ZXJFdmVudCB7XG4gIHVybEFmdGVyUmVkaXJlY3RzO1xuICB0eXBlID0gRXZlbnRUeXBlLk5hdmlnYXRpb25FbmQ7XG4gIGNvbnN0cnVjdG9yKGlkLCB1cmwsIHVybEFmdGVyUmVkaXJlY3RzKSB7XG4gICAgc3VwZXIoaWQsIHVybCk7XG4gICAgdGhpcy51cmxBZnRlclJlZGlyZWN0cyA9IHVybEFmdGVyUmVkaXJlY3RzO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgTmF2aWdhdGlvbkVuZChpZDogJHt0aGlzLmlkfSwgdXJsOiAnJHt0aGlzLnVybH0nLCB1cmxBZnRlclJlZGlyZWN0czogJyR7dGhpcy51cmxBZnRlclJlZGlyZWN0c30nKWA7XG4gIH1cbn1cbnZhciBOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZTtcbihmdW5jdGlvbiAoTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGUpIHtcbiAgTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGVbTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGVbXCJSZWRpcmVjdFwiXSA9IDBdID0gXCJSZWRpcmVjdFwiO1xuICBOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZVtOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZVtcIlN1cGVyc2VkZWRCeU5ld05hdmlnYXRpb25cIl0gPSAxXSA9IFwiU3VwZXJzZWRlZEJ5TmV3TmF2aWdhdGlvblwiO1xuICBOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZVtOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZVtcIk5vRGF0YUZyb21SZXNvbHZlclwiXSA9IDJdID0gXCJOb0RhdGFGcm9tUmVzb2x2ZXJcIjtcbiAgTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGVbTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGVbXCJHdWFyZFJlamVjdGVkXCJdID0gM10gPSBcIkd1YXJkUmVqZWN0ZWRcIjtcbiAgTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGVbTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGVbXCJBYm9ydGVkXCJdID0gNF0gPSBcIkFib3J0ZWRcIjtcbn0pKE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlIHx8IChOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZSA9IHt9KSk7XG52YXIgTmF2aWdhdGlvblNraXBwZWRDb2RlO1xuKGZ1bmN0aW9uIChOYXZpZ2F0aW9uU2tpcHBlZENvZGUpIHtcbiAgTmF2aWdhdGlvblNraXBwZWRDb2RlW05hdmlnYXRpb25Ta2lwcGVkQ29kZVtcIklnbm9yZWRTYW1lVXJsTmF2aWdhdGlvblwiXSA9IDBdID0gXCJJZ25vcmVkU2FtZVVybE5hdmlnYXRpb25cIjtcbiAgTmF2aWdhdGlvblNraXBwZWRDb2RlW05hdmlnYXRpb25Ta2lwcGVkQ29kZVtcIklnbm9yZWRCeVVybEhhbmRsaW5nU3RyYXRlZ3lcIl0gPSAxXSA9IFwiSWdub3JlZEJ5VXJsSGFuZGxpbmdTdHJhdGVneVwiO1xufSkoTmF2aWdhdGlvblNraXBwZWRDb2RlIHx8IChOYXZpZ2F0aW9uU2tpcHBlZENvZGUgPSB7fSkpO1xuY2xhc3MgTmF2aWdhdGlvbkNhbmNlbCBleHRlbmRzIFJvdXRlckV2ZW50IHtcbiAgcmVhc29uO1xuICBjb2RlO1xuICB0eXBlID0gRXZlbnRUeXBlLk5hdmlnYXRpb25DYW5jZWw7XG4gIGNvbnN0cnVjdG9yKGlkLCB1cmwsIHJlYXNvbiwgY29kZSkge1xuICAgIHN1cGVyKGlkLCB1cmwpO1xuICAgIHRoaXMucmVhc29uID0gcmVhc29uO1xuICAgIHRoaXMuY29kZSA9IGNvZGU7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIGBOYXZpZ2F0aW9uQ2FuY2VsKGlkOiAke3RoaXMuaWR9LCB1cmw6ICcke3RoaXMudXJsfScpYDtcbiAgfVxufVxuZnVuY3Rpb24gaXNSZWRpcmVjdGluZ0V2ZW50KGV2ZW50KSB7XG4gIHJldHVybiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25DYW5jZWwgJiYgKGV2ZW50LmNvZGUgPT09IE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLlJlZGlyZWN0IHx8IGV2ZW50LmNvZGUgPT09IE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLlN1cGVyc2VkZWRCeU5ld05hdmlnYXRpb24pO1xufVxuY2xhc3MgTmF2aWdhdGlvblNraXBwZWQgZXh0ZW5kcyBSb3V0ZXJFdmVudCB7XG4gIHJlYXNvbjtcbiAgY29kZTtcbiAgdHlwZSA9IEV2ZW50VHlwZS5OYXZpZ2F0aW9uU2tpcHBlZDtcbiAgY29uc3RydWN0b3IoaWQsIHVybCwgcmVhc29uLCBjb2RlKSB7XG4gICAgc3VwZXIoaWQsIHVybCk7XG4gICAgdGhpcy5yZWFzb24gPSByZWFzb247XG4gICAgdGhpcy5jb2RlID0gY29kZTtcbiAgfVxufVxuY2xhc3MgTmF2aWdhdGlvbkVycm9yIGV4dGVuZHMgUm91dGVyRXZlbnQge1xuICBlcnJvcjtcbiAgdGFyZ2V0O1xuICB0eXBlID0gRXZlbnRUeXBlLk5hdmlnYXRpb25FcnJvcjtcbiAgY29uc3RydWN0b3IoaWQsIHVybCwgZXJyb3IsIHRhcmdldCkge1xuICAgIHN1cGVyKGlkLCB1cmwpO1xuICAgIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgICB0aGlzLnRhcmdldCA9IHRhcmdldDtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYE5hdmlnYXRpb25FcnJvcihpZDogJHt0aGlzLmlkfSwgdXJsOiAnJHt0aGlzLnVybH0nLCBlcnJvcjogJHt0aGlzLmVycm9yfSlgO1xuICB9XG59XG5jbGFzcyBSb3V0ZXNSZWNvZ25pemVkIGV4dGVuZHMgUm91dGVyRXZlbnQge1xuICB1cmxBZnRlclJlZGlyZWN0cztcbiAgc3RhdGU7XG4gIHR5cGUgPSBFdmVudFR5cGUuUm91dGVzUmVjb2duaXplZDtcbiAgY29uc3RydWN0b3IoaWQsIHVybCwgdXJsQWZ0ZXJSZWRpcmVjdHMsIHN0YXRlKSB7XG4gICAgc3VwZXIoaWQsIHVybCk7XG4gICAgdGhpcy51cmxBZnRlclJlZGlyZWN0cyA9IHVybEFmdGVyUmVkaXJlY3RzO1xuICAgIHRoaXMuc3RhdGUgPSBzdGF0ZTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFJvdXRlc1JlY29nbml6ZWQoaWQ6ICR7dGhpcy5pZH0sIHVybDogJyR7dGhpcy51cmx9JywgdXJsQWZ0ZXJSZWRpcmVjdHM6ICcke3RoaXMudXJsQWZ0ZXJSZWRpcmVjdHN9Jywgc3RhdGU6ICR7dGhpcy5zdGF0ZX0pYDtcbiAgfVxufVxuY2xhc3MgR3VhcmRzQ2hlY2tTdGFydCBleHRlbmRzIFJvdXRlckV2ZW50IHtcbiAgdXJsQWZ0ZXJSZWRpcmVjdHM7XG4gIHN0YXRlO1xuICB0eXBlID0gRXZlbnRUeXBlLkd1YXJkc0NoZWNrU3RhcnQ7XG4gIGNvbnN0cnVjdG9yKGlkLCB1cmwsIHVybEFmdGVyUmVkaXJlY3RzLCBzdGF0ZSkge1xuICAgIHN1cGVyKGlkLCB1cmwpO1xuICAgIHRoaXMudXJsQWZ0ZXJSZWRpcmVjdHMgPSB1cmxBZnRlclJlZGlyZWN0cztcbiAgICB0aGlzLnN0YXRlID0gc3RhdGU7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIGBHdWFyZHNDaGVja1N0YXJ0KGlkOiAke3RoaXMuaWR9LCB1cmw6ICcke3RoaXMudXJsfScsIHVybEFmdGVyUmVkaXJlY3RzOiAnJHt0aGlzLnVybEFmdGVyUmVkaXJlY3RzfScsIHN0YXRlOiAke3RoaXMuc3RhdGV9KWA7XG4gIH1cbn1cbmNsYXNzIEd1YXJkc0NoZWNrRW5kIGV4dGVuZHMgUm91dGVyRXZlbnQge1xuICB1cmxBZnRlclJlZGlyZWN0cztcbiAgc3RhdGU7XG4gIHNob3VsZEFjdGl2YXRlO1xuICB0eXBlID0gRXZlbnRUeXBlLkd1YXJkc0NoZWNrRW5kO1xuICBjb25zdHJ1Y3RvcihpZCwgdXJsLCB1cmxBZnRlclJlZGlyZWN0cywgc3RhdGUsIHNob3VsZEFjdGl2YXRlKSB7XG4gICAgc3VwZXIoaWQsIHVybCk7XG4gICAgdGhpcy51cmxBZnRlclJlZGlyZWN0cyA9IHVybEFmdGVyUmVkaXJlY3RzO1xuICAgIHRoaXMuc3RhdGUgPSBzdGF0ZTtcbiAgICB0aGlzLnNob3VsZEFjdGl2YXRlID0gc2hvdWxkQWN0aXZhdGU7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIGBHdWFyZHNDaGVja0VuZChpZDogJHt0aGlzLmlkfSwgdXJsOiAnJHt0aGlzLnVybH0nLCB1cmxBZnRlclJlZGlyZWN0czogJyR7dGhpcy51cmxBZnRlclJlZGlyZWN0c30nLCBzdGF0ZTogJHt0aGlzLnN0YXRlfSwgc2hvdWxkQWN0aXZhdGU6ICR7dGhpcy5zaG91bGRBY3RpdmF0ZX0pYDtcbiAgfVxufVxuY2xhc3MgUmVzb2x2ZVN0YXJ0IGV4dGVuZHMgUm91dGVyRXZlbnQge1xuICB1cmxBZnRlclJlZGlyZWN0cztcbiAgc3RhdGU7XG4gIHR5cGUgPSBFdmVudFR5cGUuUmVzb2x2ZVN0YXJ0O1xuICBjb25zdHJ1Y3RvcihpZCwgdXJsLCB1cmxBZnRlclJlZGlyZWN0cywgc3RhdGUpIHtcbiAgICBzdXBlcihpZCwgdXJsKTtcbiAgICB0aGlzLnVybEFmdGVyUmVkaXJlY3RzID0gdXJsQWZ0ZXJSZWRpcmVjdHM7XG4gICAgdGhpcy5zdGF0ZSA9IHN0YXRlO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgUmVzb2x2ZVN0YXJ0KGlkOiAke3RoaXMuaWR9LCB1cmw6ICcke3RoaXMudXJsfScsIHVybEFmdGVyUmVkaXJlY3RzOiAnJHt0aGlzLnVybEFmdGVyUmVkaXJlY3RzfScsIHN0YXRlOiAke3RoaXMuc3RhdGV9KWA7XG4gIH1cbn1cbmNsYXNzIFJlc29sdmVFbmQgZXh0ZW5kcyBSb3V0ZXJFdmVudCB7XG4gIHVybEFmdGVyUmVkaXJlY3RzO1xuICBzdGF0ZTtcbiAgdHlwZSA9IEV2ZW50VHlwZS5SZXNvbHZlRW5kO1xuICBjb25zdHJ1Y3RvcihpZCwgdXJsLCB1cmxBZnRlclJlZGlyZWN0cywgc3RhdGUpIHtcbiAgICBzdXBlcihpZCwgdXJsKTtcbiAgICB0aGlzLnVybEFmdGVyUmVkaXJlY3RzID0gdXJsQWZ0ZXJSZWRpcmVjdHM7XG4gICAgdGhpcy5zdGF0ZSA9IHN0YXRlO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgUmVzb2x2ZUVuZChpZDogJHt0aGlzLmlkfSwgdXJsOiAnJHt0aGlzLnVybH0nLCB1cmxBZnRlclJlZGlyZWN0czogJyR7dGhpcy51cmxBZnRlclJlZGlyZWN0c30nLCBzdGF0ZTogJHt0aGlzLnN0YXRlfSlgO1xuICB9XG59XG5jbGFzcyBSb3V0ZUNvbmZpZ0xvYWRTdGFydCB7XG4gIHJvdXRlO1xuICB0eXBlID0gRXZlbnRUeXBlLlJvdXRlQ29uZmlnTG9hZFN0YXJ0O1xuICBjb25zdHJ1Y3Rvcihyb3V0ZSkge1xuICAgIHRoaXMucm91dGUgPSByb3V0ZTtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gYFJvdXRlQ29uZmlnTG9hZFN0YXJ0KHBhdGg6ICR7dGhpcy5yb3V0ZS5wYXRofSlgO1xuICB9XG59XG5jbGFzcyBSb3V0ZUNvbmZpZ0xvYWRFbmQge1xuICByb3V0ZTtcbiAgdHlwZSA9IEV2ZW50VHlwZS5Sb3V0ZUNvbmZpZ0xvYWRFbmQ7XG4gIGNvbnN0cnVjdG9yKHJvdXRlKSB7XG4gICAgdGhpcy5yb3V0ZSA9IHJvdXRlO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgUm91dGVDb25maWdMb2FkRW5kKHBhdGg6ICR7dGhpcy5yb3V0ZS5wYXRofSlgO1xuICB9XG59XG5jbGFzcyBDaGlsZEFjdGl2YXRpb25TdGFydCB7XG4gIHNuYXBzaG90O1xuICB0eXBlID0gRXZlbnRUeXBlLkNoaWxkQWN0aXZhdGlvblN0YXJ0O1xuICBjb25zdHJ1Y3RvcihzbmFwc2hvdCkge1xuICAgIHRoaXMuc25hcHNob3QgPSBzbmFwc2hvdDtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICBjb25zdCBwYXRoID0gdGhpcy5zbmFwc2hvdC5yb3V0ZUNvbmZpZyAmJiB0aGlzLnNuYXBzaG90LnJvdXRlQ29uZmlnLnBhdGggfHwgJyc7XG4gICAgcmV0dXJuIGBDaGlsZEFjdGl2YXRpb25TdGFydChwYXRoOiAnJHtwYXRofScpYDtcbiAgfVxufVxuY2xhc3MgQ2hpbGRBY3RpdmF0aW9uRW5kIHtcbiAgc25hcHNob3Q7XG4gIHR5cGUgPSBFdmVudFR5cGUuQ2hpbGRBY3RpdmF0aW9uRW5kO1xuICBjb25zdHJ1Y3RvcihzbmFwc2hvdCkge1xuICAgIHRoaXMuc25hcHNob3QgPSBzbmFwc2hvdDtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICBjb25zdCBwYXRoID0gdGhpcy5zbmFwc2hvdC5yb3V0ZUNvbmZpZyAmJiB0aGlzLnNuYXBzaG90LnJvdXRlQ29uZmlnLnBhdGggfHwgJyc7XG4gICAgcmV0dXJuIGBDaGlsZEFjdGl2YXRpb25FbmQocGF0aDogJyR7cGF0aH0nKWA7XG4gIH1cbn1cbmNsYXNzIEFjdGl2YXRpb25TdGFydCB7XG4gIHNuYXBzaG90O1xuICB0eXBlID0gRXZlbnRUeXBlLkFjdGl2YXRpb25TdGFydDtcbiAgY29uc3RydWN0b3Ioc25hcHNob3QpIHtcbiAgICB0aGlzLnNuYXBzaG90ID0gc25hcHNob3Q7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgY29uc3QgcGF0aCA9IHRoaXMuc25hcHNob3Qucm91dGVDb25maWcgJiYgdGhpcy5zbmFwc2hvdC5yb3V0ZUNvbmZpZy5wYXRoIHx8ICcnO1xuICAgIHJldHVybiBgQWN0aXZhdGlvblN0YXJ0KHBhdGg6ICcke3BhdGh9JylgO1xuICB9XG59XG5jbGFzcyBBY3RpdmF0aW9uRW5kIHtcbiAgc25hcHNob3Q7XG4gIHR5cGUgPSBFdmVudFR5cGUuQWN0aXZhdGlvbkVuZDtcbiAgY29uc3RydWN0b3Ioc25hcHNob3QpIHtcbiAgICB0aGlzLnNuYXBzaG90ID0gc25hcHNob3Q7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgY29uc3QgcGF0aCA9IHRoaXMuc25hcHNob3Qucm91dGVDb25maWcgJiYgdGhpcy5zbmFwc2hvdC5yb3V0ZUNvbmZpZy5wYXRoIHx8ICcnO1xuICAgIHJldHVybiBgQWN0aXZhdGlvbkVuZChwYXRoOiAnJHtwYXRofScpYDtcbiAgfVxufVxuY2xhc3MgU2Nyb2xsIHtcbiAgcm91dGVyRXZlbnQ7XG4gIHBvc2l0aW9uO1xuICBhbmNob3I7XG4gIHNjcm9sbEJlaGF2aW9yO1xuICB0eXBlID0gRXZlbnRUeXBlLlNjcm9sbDtcbiAgY29uc3RydWN0b3Iocm91dGVyRXZlbnQsIHBvc2l0aW9uLCBhbmNob3IsIHNjcm9sbEJlaGF2aW9yKSB7XG4gICAgdGhpcy5yb3V0ZXJFdmVudCA9IHJvdXRlckV2ZW50O1xuICAgIHRoaXMucG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgICB0aGlzLmFuY2hvciA9IGFuY2hvcjtcbiAgICB0aGlzLnNjcm9sbEJlaGF2aW9yID0gc2Nyb2xsQmVoYXZpb3I7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgY29uc3QgcG9zID0gdGhpcy5wb3NpdGlvbiA/IGAke3RoaXMucG9zaXRpb25bMF19LCAke3RoaXMucG9zaXRpb25bMV19YCA6IG51bGw7XG4gICAgcmV0dXJuIGBTY3JvbGwoYW5jaG9yOiAnJHt0aGlzLmFuY2hvcn0nLCBwb3NpdGlvbjogJyR7cG9zfScpYDtcbiAgfVxufVxuY2xhc3MgQmVmb3JlQWN0aXZhdGVSb3V0ZXMge31cbmNsYXNzIEJlZm9yZVJvdXRlc1JlY29nbml6ZWQge31cbmNsYXNzIFJlZGlyZWN0UmVxdWVzdCB7XG4gIHVybDtcbiAgbmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucztcbiAgY29uc3RydWN0b3IodXJsLCBuYXZpZ2F0aW9uQmVoYXZpb3JPcHRpb25zKSB7XG4gICAgdGhpcy51cmwgPSB1cmw7XG4gICAgdGhpcy5uYXZpZ2F0aW9uQmVoYXZpb3JPcHRpb25zID0gbmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucztcbiAgfVxufVxuZnVuY3Rpb24gaXNQdWJsaWNSb3V0ZXJFdmVudChlKSB7XG4gIHJldHVybiAhKGUgaW5zdGFuY2VvZiBCZWZvcmVBY3RpdmF0ZVJvdXRlcykgJiYgIShlIGluc3RhbmNlb2YgUmVkaXJlY3RSZXF1ZXN0KSAmJiAhKGUgaW5zdGFuY2VvZiBCZWZvcmVSb3V0ZXNSZWNvZ25pemVkKTtcbn1cbmZ1bmN0aW9uIHN0cmluZ2lmeUV2ZW50KHJvdXRlckV2ZW50KSB7XG4gIHN3aXRjaCAocm91dGVyRXZlbnQudHlwZSkge1xuICAgIGNhc2UgRXZlbnRUeXBlLkFjdGl2YXRpb25FbmQ6XG4gICAgICByZXR1cm4gYEFjdGl2YXRpb25FbmQocGF0aDogJyR7cm91dGVyRXZlbnQuc25hcHNob3Qucm91dGVDb25maWc/LnBhdGggfHwgJyd9JylgO1xuICAgIGNhc2UgRXZlbnRUeXBlLkFjdGl2YXRpb25TdGFydDpcbiAgICAgIHJldHVybiBgQWN0aXZhdGlvblN0YXJ0KHBhdGg6ICcke3JvdXRlckV2ZW50LnNuYXBzaG90LnJvdXRlQ29uZmlnPy5wYXRoIHx8ICcnfScpYDtcbiAgICBjYXNlIEV2ZW50VHlwZS5DaGlsZEFjdGl2YXRpb25FbmQ6XG4gICAgICByZXR1cm4gYENoaWxkQWN0aXZhdGlvbkVuZChwYXRoOiAnJHtyb3V0ZXJFdmVudC5zbmFwc2hvdC5yb3V0ZUNvbmZpZz8ucGF0aCB8fCAnJ30nKWA7XG4gICAgY2FzZSBFdmVudFR5cGUuQ2hpbGRBY3RpdmF0aW9uU3RhcnQ6XG4gICAgICByZXR1cm4gYENoaWxkQWN0aXZhdGlvblN0YXJ0KHBhdGg6ICcke3JvdXRlckV2ZW50LnNuYXBzaG90LnJvdXRlQ29uZmlnPy5wYXRoIHx8ICcnfScpYDtcbiAgICBjYXNlIEV2ZW50VHlwZS5HdWFyZHNDaGVja0VuZDpcbiAgICAgIHJldHVybiBgR3VhcmRzQ2hlY2tFbmQoaWQ6ICR7cm91dGVyRXZlbnQuaWR9LCB1cmw6ICcke3JvdXRlckV2ZW50LnVybH0nLCB1cmxBZnRlclJlZGlyZWN0czogJyR7cm91dGVyRXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHN9Jywgc3RhdGU6ICR7cm91dGVyRXZlbnQuc3RhdGV9LCBzaG91bGRBY3RpdmF0ZTogJHtyb3V0ZXJFdmVudC5zaG91bGRBY3RpdmF0ZX0pYDtcbiAgICBjYXNlIEV2ZW50VHlwZS5HdWFyZHNDaGVja1N0YXJ0OlxuICAgICAgcmV0dXJuIGBHdWFyZHNDaGVja1N0YXJ0KGlkOiAke3JvdXRlckV2ZW50LmlkfSwgdXJsOiAnJHtyb3V0ZXJFdmVudC51cmx9JywgdXJsQWZ0ZXJSZWRpcmVjdHM6ICcke3JvdXRlckV2ZW50LnVybEFmdGVyUmVkaXJlY3RzfScsIHN0YXRlOiAke3JvdXRlckV2ZW50LnN0YXRlfSlgO1xuICAgIGNhc2UgRXZlbnRUeXBlLk5hdmlnYXRpb25DYW5jZWw6XG4gICAgICByZXR1cm4gYE5hdmlnYXRpb25DYW5jZWwoaWQ6ICR7cm91dGVyRXZlbnQuaWR9LCB1cmw6ICcke3JvdXRlckV2ZW50LnVybH0nKWA7XG4gICAgY2FzZSBFdmVudFR5cGUuTmF2aWdhdGlvblNraXBwZWQ6XG4gICAgICByZXR1cm4gYE5hdmlnYXRpb25Ta2lwcGVkKGlkOiAke3JvdXRlckV2ZW50LmlkfSwgdXJsOiAnJHtyb3V0ZXJFdmVudC51cmx9JylgO1xuICAgIGNhc2UgRXZlbnRUeXBlLk5hdmlnYXRpb25FbmQ6XG4gICAgICByZXR1cm4gYE5hdmlnYXRpb25FbmQoaWQ6ICR7cm91dGVyRXZlbnQuaWR9LCB1cmw6ICcke3JvdXRlckV2ZW50LnVybH0nLCB1cmxBZnRlclJlZGlyZWN0czogJyR7cm91dGVyRXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHN9JylgO1xuICAgIGNhc2UgRXZlbnRUeXBlLk5hdmlnYXRpb25FcnJvcjpcbiAgICAgIHJldHVybiBgTmF2aWdhdGlvbkVycm9yKGlkOiAke3JvdXRlckV2ZW50LmlkfSwgdXJsOiAnJHtyb3V0ZXJFdmVudC51cmx9JywgZXJyb3I6ICR7cm91dGVyRXZlbnQuZXJyb3J9KWA7XG4gICAgY2FzZSBFdmVudFR5cGUuTmF2aWdhdGlvblN0YXJ0OlxuICAgICAgcmV0dXJuIGBOYXZpZ2F0aW9uU3RhcnQoaWQ6ICR7cm91dGVyRXZlbnQuaWR9LCB1cmw6ICcke3JvdXRlckV2ZW50LnVybH0nKWA7XG4gICAgY2FzZSBFdmVudFR5cGUuUmVzb2x2ZUVuZDpcbiAgICAgIHJldHVybiBgUmVzb2x2ZUVuZChpZDogJHtyb3V0ZXJFdmVudC5pZH0sIHVybDogJyR7cm91dGVyRXZlbnQudXJsfScsIHVybEFmdGVyUmVkaXJlY3RzOiAnJHtyb3V0ZXJFdmVudC51cmxBZnRlclJlZGlyZWN0c30nLCBzdGF0ZTogJHtyb3V0ZXJFdmVudC5zdGF0ZX0pYDtcbiAgICBjYXNlIEV2ZW50VHlwZS5SZXNvbHZlU3RhcnQ6XG4gICAgICByZXR1cm4gYFJlc29sdmVTdGFydChpZDogJHtyb3V0ZXJFdmVudC5pZH0sIHVybDogJyR7cm91dGVyRXZlbnQudXJsfScsIHVybEFmdGVyUmVkaXJlY3RzOiAnJHtyb3V0ZXJFdmVudC51cmxBZnRlclJlZGlyZWN0c30nLCBzdGF0ZTogJHtyb3V0ZXJFdmVudC5zdGF0ZX0pYDtcbiAgICBjYXNlIEV2ZW50VHlwZS5Sb3V0ZUNvbmZpZ0xvYWRFbmQ6XG4gICAgICByZXR1cm4gYFJvdXRlQ29uZmlnTG9hZEVuZChwYXRoOiAke3JvdXRlckV2ZW50LnJvdXRlLnBhdGh9KWA7XG4gICAgY2FzZSBFdmVudFR5cGUuUm91dGVDb25maWdMb2FkU3RhcnQ6XG4gICAgICByZXR1cm4gYFJvdXRlQ29uZmlnTG9hZFN0YXJ0KHBhdGg6ICR7cm91dGVyRXZlbnQucm91dGUucGF0aH0pYDtcbiAgICBjYXNlIEV2ZW50VHlwZS5Sb3V0ZXNSZWNvZ25pemVkOlxuICAgICAgcmV0dXJuIGBSb3V0ZXNSZWNvZ25pemVkKGlkOiAke3JvdXRlckV2ZW50LmlkfSwgdXJsOiAnJHtyb3V0ZXJFdmVudC51cmx9JywgdXJsQWZ0ZXJSZWRpcmVjdHM6ICcke3JvdXRlckV2ZW50LnVybEFmdGVyUmVkaXJlY3RzfScsIHN0YXRlOiAke3JvdXRlckV2ZW50LnN0YXRlfSlgO1xuICAgIGNhc2UgRXZlbnRUeXBlLlNjcm9sbDpcbiAgICAgIGNvbnN0IHBvcyA9IHJvdXRlckV2ZW50LnBvc2l0aW9uID8gYCR7cm91dGVyRXZlbnQucG9zaXRpb25bMF19LCAke3JvdXRlckV2ZW50LnBvc2l0aW9uWzFdfWAgOiBudWxsO1xuICAgICAgcmV0dXJuIGBTY3JvbGwoYW5jaG9yOiAnJHtyb3V0ZXJFdmVudC5hbmNob3J9JywgcG9zaXRpb246ICcke3Bvc30nKWA7XG4gIH1cbn1cbmNsYXNzIE91dGxldENvbnRleHQge1xuICByb290SW5qZWN0b3I7XG4gIG91dGxldCA9IG51bGw7XG4gIHJvdXRlID0gbnVsbDtcbiAgY2hpbGRyZW47XG4gIGF0dGFjaFJlZiA9IG51bGw7XG4gIGdldCBpbmplY3RvcigpIHtcbiAgICByZXR1cm4gdGhpcy5yb3V0ZT8uc25hcHNob3QuX2Vudmlyb25tZW50SW5qZWN0b3IgPz8gdGhpcy5yb290SW5qZWN0b3I7XG4gIH1cbiAgY29uc3RydWN0b3Iocm9vdEluamVjdG9yKSB7XG4gICAgdGhpcy5yb290SW5qZWN0b3IgPSByb290SW5qZWN0b3I7XG4gICAgdGhpcy5jaGlsZHJlbiA9IG5ldyBDaGlsZHJlbk91dGxldENvbnRleHRzKHRoaXMucm9vdEluamVjdG9yKTtcbiAgfVxufVxuY2xhc3MgQ2hpbGRyZW5PdXRsZXRDb250ZXh0cyB7XG4gIHJvb3RJbmplY3RvcjtcbiAgY29udGV4dHMgPSBuZXcgTWFwKCk7XG4gIGNvbnN0cnVjdG9yKHJvb3RJbmplY3Rvcikge1xuICAgIHRoaXMucm9vdEluamVjdG9yID0gcm9vdEluamVjdG9yO1xuICB9XG4gIG9uQ2hpbGRPdXRsZXRDcmVhdGVkKGNoaWxkTmFtZSwgb3V0bGV0KSB7XG4gICAgY29uc3QgY29udGV4dCA9IHRoaXMuZ2V0T3JDcmVhdGVDb250ZXh0KGNoaWxkTmFtZSk7XG4gICAgY29udGV4dC5vdXRsZXQgPSBvdXRsZXQ7XG4gICAgdGhpcy5jb250ZXh0cy5zZXQoY2hpbGROYW1lLCBjb250ZXh0KTtcbiAgfVxuICBvbkNoaWxkT3V0bGV0RGVzdHJveWVkKGNoaWxkTmFtZSkge1xuICAgIGNvbnN0IGNvbnRleHQgPSB0aGlzLmdldENvbnRleHQoY2hpbGROYW1lKTtcbiAgICBpZiAoY29udGV4dCkge1xuICAgICAgY29udGV4dC5vdXRsZXQgPSBudWxsO1xuICAgICAgY29udGV4dC5hdHRhY2hSZWYgPSBudWxsO1xuICAgIH1cbiAgfVxuICBvbk91dGxldERlYWN0aXZhdGVkKCkge1xuICAgIGNvbnN0IGNvbnRleHRzID0gdGhpcy5jb250ZXh0cztcbiAgICB0aGlzLmNvbnRleHRzID0gbmV3IE1hcCgpO1xuICAgIHJldHVybiBjb250ZXh0cztcbiAgfVxuICBvbk91dGxldFJlQXR0YWNoZWQoY29udGV4dHMpIHtcbiAgICB0aGlzLmNvbnRleHRzID0gY29udGV4dHM7XG4gIH1cbiAgZ2V0T3JDcmVhdGVDb250ZXh0KGNoaWxkTmFtZSkge1xuICAgIGxldCBjb250ZXh0ID0gdGhpcy5nZXRDb250ZXh0KGNoaWxkTmFtZSk7XG4gICAgaWYgKCFjb250ZXh0KSB7XG4gICAgICBjb250ZXh0ID0gbmV3IE91dGxldENvbnRleHQodGhpcy5yb290SW5qZWN0b3IpO1xuICAgICAgdGhpcy5jb250ZXh0cy5zZXQoY2hpbGROYW1lLCBjb250ZXh0KTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbnRleHQ7XG4gIH1cbiAgZ2V0Q29udGV4dChjaGlsZE5hbWUpIHtcbiAgICByZXR1cm4gdGhpcy5jb250ZXh0cy5nZXQoY2hpbGROYW1lKSB8fCBudWxsO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIENoaWxkcmVuT3V0bGV0Q29udGV4dHNfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBDaGlsZHJlbk91dGxldENvbnRleHRzKShpMC7Jtcm1aW5qZWN0KGkwLkVudmlyb25tZW50SW5qZWN0b3IpKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHtcbiAgICB0b2tlbjogQ2hpbGRyZW5PdXRsZXRDb250ZXh0cyxcbiAgICBmYWN0b3J5OiBDaGlsZHJlbk91dGxldENvbnRleHRzLsm1ZmFjLFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKENoaWxkcmVuT3V0bGV0Q29udGV4dHMsIFt7XG4gICAgdHlwZTogSW5qZWN0YWJsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgcHJvdmlkZWRJbjogJ3Jvb3QnXG4gICAgfV1cbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogaTAuRW52aXJvbm1lbnRJbmplY3RvclxuICB9XSwgbnVsbCk7XG59KSgpO1xuY2xhc3MgVHJlZSB7XG4gIF9yb290O1xuICBjb25zdHJ1Y3Rvcihyb290KSB7XG4gICAgdGhpcy5fcm9vdCA9IHJvb3Q7XG4gIH1cbiAgZ2V0IHJvb3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3Jvb3QudmFsdWU7XG4gIH1cbiAgcGFyZW50KHQpIHtcbiAgICBjb25zdCBwID0gdGhpcy5wYXRoRnJvbVJvb3QodCk7XG4gICAgcmV0dXJuIHAubGVuZ3RoID4gMSA/IHBbcC5sZW5ndGggLSAyXSA6IG51bGw7XG4gIH1cbiAgY2hpbGRyZW4odCkge1xuICAgIGNvbnN0IG4gPSBmaW5kTm9kZSh0LCB0aGlzLl9yb290KTtcbiAgICByZXR1cm4gbiA/IG4uY2hpbGRyZW4ubWFwKHQgPT4gdC52YWx1ZSkgOiBbXTtcbiAgfVxuICBmaXJzdENoaWxkKHQpIHtcbiAgICBjb25zdCBuID0gZmluZE5vZGUodCwgdGhpcy5fcm9vdCk7XG4gICAgcmV0dXJuIG4gJiYgbi5jaGlsZHJlbi5sZW5ndGggPiAwID8gbi5jaGlsZHJlblswXS52YWx1ZSA6IG51bGw7XG4gIH1cbiAgc2libGluZ3ModCkge1xuICAgIGNvbnN0IHAgPSBmaW5kUGF0aCh0LCB0aGlzLl9yb290KTtcbiAgICBpZiAocC5sZW5ndGggPCAyKSByZXR1cm4gW107XG4gICAgY29uc3QgYyA9IHBbcC5sZW5ndGggLSAyXS5jaGlsZHJlbi5tYXAoYyA9PiBjLnZhbHVlKTtcbiAgICByZXR1cm4gYy5maWx0ZXIoY2MgPT4gY2MgIT09IHQpO1xuICB9XG4gIHBhdGhGcm9tUm9vdCh0KSB7XG4gICAgcmV0dXJuIGZpbmRQYXRoKHQsIHRoaXMuX3Jvb3QpLm1hcChzID0+IHMudmFsdWUpO1xuICB9XG59XG5mdW5jdGlvbiBmaW5kTm9kZSh2YWx1ZSwgbm9kZSkge1xuICBpZiAodmFsdWUgPT09IG5vZGUudmFsdWUpIHJldHVybiBub2RlO1xuICBmb3IgKGNvbnN0IGNoaWxkIG9mIG5vZGUuY2hpbGRyZW4pIHtcbiAgICBjb25zdCBub2RlID0gZmluZE5vZGUodmFsdWUsIGNoaWxkKTtcbiAgICBpZiAobm9kZSkgcmV0dXJuIG5vZGU7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBmaW5kUGF0aCh2YWx1ZSwgbm9kZSkge1xuICBpZiAodmFsdWUgPT09IG5vZGUudmFsdWUpIHJldHVybiBbbm9kZV07XG4gIGZvciAoY29uc3QgY2hpbGQgb2Ygbm9kZS5jaGlsZHJlbikge1xuICAgIGNvbnN0IHBhdGggPSBmaW5kUGF0aCh2YWx1ZSwgY2hpbGQpO1xuICAgIGlmIChwYXRoLmxlbmd0aCkge1xuICAgICAgcGF0aC51bnNoaWZ0KG5vZGUpO1xuICAgICAgcmV0dXJuIHBhdGg7XG4gICAgfVxuICB9XG4gIHJldHVybiBbXTtcbn1cbmNsYXNzIFRyZWVOb2RlIHtcbiAgdmFsdWU7XG4gIGNoaWxkcmVuO1xuICBjb25zdHJ1Y3Rvcih2YWx1ZSwgY2hpbGRyZW4pIHtcbiAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgdGhpcy5jaGlsZHJlbiA9IGNoaWxkcmVuO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiBgVHJlZU5vZGUoJHt0aGlzLnZhbHVlfSlgO1xuICB9XG59XG5mdW5jdGlvbiBub2RlQ2hpbGRyZW5Bc01hcChub2RlKSB7XG4gIGNvbnN0IG1hcCA9IHt9O1xuICBpZiAobm9kZSkge1xuICAgIG5vZGUuY2hpbGRyZW4uZm9yRWFjaChjaGlsZCA9PiBtYXBbY2hpbGQudmFsdWUub3V0bGV0XSA9IGNoaWxkKTtcbiAgfVxuICByZXR1cm4gbWFwO1xufVxuY2xhc3MgUm91dGVyU3RhdGUgZXh0ZW5kcyBUcmVlIHtcbiAgc25hcHNob3Q7XG4gIGNvbnN0cnVjdG9yKHJvb3QsIHNuYXBzaG90KSB7XG4gICAgc3VwZXIocm9vdCk7XG4gICAgdGhpcy5zbmFwc2hvdCA9IHNuYXBzaG90O1xuICAgIHNldFJvdXRlclN0YXRlKHRoaXMsIHJvb3QpO1xuICB9XG4gIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLnNuYXBzaG90LnRvU3RyaW5nKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZUVtcHR5U3RhdGUocm9vdENvbXBvbmVudCwgaW5qZWN0b3IpIHtcbiAgY29uc3Qgc25hcHNob3QgPSBjcmVhdGVFbXB0eVN0YXRlU25hcHNob3Qocm9vdENvbXBvbmVudCwgaW5qZWN0b3IpO1xuICBjb25zdCBlbXB0eVVybCA9IG5ldyBCZWhhdmlvclN1YmplY3QoW25ldyBVcmxTZWdtZW50KCcnLCB7fSldKTtcbiAgY29uc3QgZW1wdHlQYXJhbXMgPSBuZXcgQmVoYXZpb3JTdWJqZWN0KHt9KTtcbiAgY29uc3QgZW1wdHlEYXRhID0gbmV3IEJlaGF2aW9yU3ViamVjdCh7fSk7XG4gIGNvbnN0IGVtcHR5UXVlcnlQYXJhbXMgPSBuZXcgQmVoYXZpb3JTdWJqZWN0KHt9KTtcbiAgY29uc3QgZnJhZ21lbnQgPSBuZXcgQmVoYXZpb3JTdWJqZWN0KCcnKTtcbiAgY29uc3QgYWN0aXZhdGVkID0gbmV3IEFjdGl2YXRlZFJvdXRlKGVtcHR5VXJsLCBlbXB0eVBhcmFtcywgZW1wdHlRdWVyeVBhcmFtcywgZnJhZ21lbnQsIGVtcHR5RGF0YSwgUFJJTUFSWV9PVVRMRVQsIHJvb3RDb21wb25lbnQsIHNuYXBzaG90LnJvb3QpO1xuICBhY3RpdmF0ZWQuc25hcHNob3QgPSBzbmFwc2hvdC5yb290O1xuICByZXR1cm4gbmV3IFJvdXRlclN0YXRlKG5ldyBUcmVlTm9kZShhY3RpdmF0ZWQsIFtdKSwgc25hcHNob3QpO1xufVxuZnVuY3Rpb24gY3JlYXRlRW1wdHlTdGF0ZVNuYXBzaG90KHJvb3RDb21wb25lbnQsIGluamVjdG9yKSB7XG4gIGNvbnN0IGVtcHR5UGFyYW1zID0ge307XG4gIGNvbnN0IGVtcHR5RGF0YSA9IHt9O1xuICBjb25zdCBlbXB0eVF1ZXJ5UGFyYW1zID0ge307XG4gIGNvbnN0IGZyYWdtZW50ID0gJyc7XG4gIGNvbnN0IGFjdGl2YXRlZCA9IG5ldyBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90KFtdLCBlbXB0eVBhcmFtcywgZW1wdHlRdWVyeVBhcmFtcywgZnJhZ21lbnQsIGVtcHR5RGF0YSwgUFJJTUFSWV9PVVRMRVQsIHJvb3RDb21wb25lbnQsIG51bGwsIHt9LCBpbmplY3Rvcik7XG4gIHJldHVybiBuZXcgUm91dGVyU3RhdGVTbmFwc2hvdCgnJywgbmV3IFRyZWVOb2RlKGFjdGl2YXRlZCwgW10pKTtcbn1cbmNsYXNzIEFjdGl2YXRlZFJvdXRlIHtcbiAgdXJsU3ViamVjdDtcbiAgcGFyYW1zU3ViamVjdDtcbiAgcXVlcnlQYXJhbXNTdWJqZWN0O1xuICBmcmFnbWVudFN1YmplY3Q7XG4gIGRhdGFTdWJqZWN0O1xuICBvdXRsZXQ7XG4gIGNvbXBvbmVudDtcbiAgc25hcHNob3Q7XG4gIF9mdXR1cmVTbmFwc2hvdDtcbiAgX3JvdXRlclN0YXRlO1xuICBfcGFyYW1NYXA7XG4gIF9xdWVyeVBhcmFtTWFwO1xuICB0aXRsZTtcbiAgdXJsO1xuICBwYXJhbXM7XG4gIHF1ZXJ5UGFyYW1zO1xuICBmcmFnbWVudDtcbiAgZGF0YTtcbiAgX2xvY2FsSW5qZWN0b3I7XG4gIGNvbnN0cnVjdG9yKHVybFN1YmplY3QsIHBhcmFtc1N1YmplY3QsIHF1ZXJ5UGFyYW1zU3ViamVjdCwgZnJhZ21lbnRTdWJqZWN0LCBkYXRhU3ViamVjdCwgb3V0bGV0LCBjb21wb25lbnQsIGZ1dHVyZVNuYXBzaG90KSB7XG4gICAgdGhpcy51cmxTdWJqZWN0ID0gdXJsU3ViamVjdDtcbiAgICB0aGlzLnBhcmFtc1N1YmplY3QgPSBwYXJhbXNTdWJqZWN0O1xuICAgIHRoaXMucXVlcnlQYXJhbXNTdWJqZWN0ID0gcXVlcnlQYXJhbXNTdWJqZWN0O1xuICAgIHRoaXMuZnJhZ21lbnRTdWJqZWN0ID0gZnJhZ21lbnRTdWJqZWN0O1xuICAgIHRoaXMuZGF0YVN1YmplY3QgPSBkYXRhU3ViamVjdDtcbiAgICB0aGlzLm91dGxldCA9IG91dGxldDtcbiAgICB0aGlzLmNvbXBvbmVudCA9IGNvbXBvbmVudDtcbiAgICB0aGlzLl9mdXR1cmVTbmFwc2hvdCA9IGZ1dHVyZVNuYXBzaG90O1xuICAgIHRoaXMudGl0bGUgPSB0aGlzLmRhdGFTdWJqZWN0Py5waXBlKG1hcChkID0+IGRbUm91dGVUaXRsZUtleV0pKSA/PyBvZih1bmRlZmluZWQpO1xuICAgIHRoaXMudXJsID0gdXJsU3ViamVjdDtcbiAgICB0aGlzLnBhcmFtcyA9IHBhcmFtc1N1YmplY3Q7XG4gICAgdGhpcy5xdWVyeVBhcmFtcyA9IHF1ZXJ5UGFyYW1zU3ViamVjdDtcbiAgICB0aGlzLmZyYWdtZW50ID0gZnJhZ21lbnRTdWJqZWN0O1xuICAgIHRoaXMuZGF0YSA9IGRhdGFTdWJqZWN0O1xuICB9XG4gIGdldCByb3V0ZUNvbmZpZygpIHtcbiAgICByZXR1cm4gdGhpcy5fZnV0dXJlU25hcHNob3Qucm91dGVDb25maWc7XG4gIH1cbiAgZ2V0IHJvb3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JvdXRlclN0YXRlLnJvb3Q7XG4gIH1cbiAgZ2V0IHBhcmVudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcm91dGVyU3RhdGUucGFyZW50KHRoaXMpO1xuICB9XG4gIGdldCBmaXJzdENoaWxkKCkge1xuICAgIHJldHVybiB0aGlzLl9yb3V0ZXJTdGF0ZS5maXJzdENoaWxkKHRoaXMpO1xuICB9XG4gIGdldCBjaGlsZHJlbigpIHtcbiAgICByZXR1cm4gdGhpcy5fcm91dGVyU3RhdGUuY2hpbGRyZW4odGhpcyk7XG4gIH1cbiAgZ2V0IHBhdGhGcm9tUm9vdCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcm91dGVyU3RhdGUucGF0aEZyb21Sb290KHRoaXMpO1xuICB9XG4gIGdldCBwYXJhbU1hcCgpIHtcbiAgICB0aGlzLl9wYXJhbU1hcCA/Pz0gdGhpcy5wYXJhbXMucGlwZShtYXAocCA9PiBjb252ZXJ0VG9QYXJhbU1hcChwKSkpO1xuICAgIHJldHVybiB0aGlzLl9wYXJhbU1hcDtcbiAgfVxuICBnZXQgcXVlcnlQYXJhbU1hcCgpIHtcbiAgICB0aGlzLl9xdWVyeVBhcmFtTWFwID8/PSB0aGlzLnF1ZXJ5UGFyYW1zLnBpcGUobWFwKHAgPT4gY29udmVydFRvUGFyYW1NYXAocCkpKTtcbiAgICByZXR1cm4gdGhpcy5fcXVlcnlQYXJhbU1hcDtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICByZXR1cm4gdGhpcy5zbmFwc2hvdCA/IHRoaXMuc25hcHNob3QudG9TdHJpbmcoKSA6IGBGdXR1cmUoJHt0aGlzLl9mdXR1cmVTbmFwc2hvdH0pYDtcbiAgfVxufVxuY29uc3QgREVGQVVMVF9QQVJBTVNfSU5IRVJJVEFOQ0VfU1RSQVRFR1kgPSAnYWx3YXlzJztcbmZ1bmN0aW9uIGdldEluaGVyaXRlZChyb3V0ZSwgcGFyZW50LCBwYXJhbXNJbmhlcml0YW5jZVN0cmF0ZWd5KSB7XG4gIGxldCBpbmhlcml0ZWQ7XG4gIGNvbnN0IHtcbiAgICByb3V0ZUNvbmZpZ1xuICB9ID0gcm91dGU7XG4gIGlmIChwYXJlbnQgIT09IG51bGwgJiYgKHBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3kgPT09ICdhbHdheXMnIHx8IHJvdXRlQ29uZmlnPy5wYXRoID09PSAnJyB8fCAhcGFyZW50LmNvbXBvbmVudCAmJiAhcGFyZW50LnJvdXRlQ29uZmlnPy5sb2FkQ29tcG9uZW50KSkge1xuICAgIGluaGVyaXRlZCA9IHtcbiAgICAgIHBhcmFtczoge1xuICAgICAgICAuLi5wYXJlbnQucGFyYW1zLFxuICAgICAgICAuLi5yb3V0ZS5wYXJhbXNcbiAgICAgIH0sXG4gICAgICBkYXRhOiB7XG4gICAgICAgIC4uLnBhcmVudC5kYXRhLFxuICAgICAgICAuLi5yb3V0ZS5kYXRhXG4gICAgICB9LFxuICAgICAgcmVzb2x2ZToge1xuICAgICAgICAuLi5yb3V0ZS5kYXRhLFxuICAgICAgICAuLi5wYXJlbnQuZGF0YSxcbiAgICAgICAgLi4ucm91dGVDb25maWc/LmRhdGEsXG4gICAgICAgIC4uLnJvdXRlLl9yZXNvbHZlZERhdGFcbiAgICAgIH1cbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIGluaGVyaXRlZCA9IHtcbiAgICAgIHBhcmFtczoge1xuICAgICAgICAuLi5yb3V0ZS5wYXJhbXNcbiAgICAgIH0sXG4gICAgICBkYXRhOiB7XG4gICAgICAgIC4uLnJvdXRlLmRhdGFcbiAgICAgIH0sXG4gICAgICByZXNvbHZlOiB7XG4gICAgICAgIC4uLnJvdXRlLmRhdGEsXG4gICAgICAgIC4uLihyb3V0ZS5fcmVzb2x2ZWREYXRhID8/IHt9KVxuICAgICAgfVxuICAgIH07XG4gIH1cbiAgaWYgKHJvdXRlQ29uZmlnICYmIGhhc1N0YXRpY1RpdGxlKHJvdXRlQ29uZmlnKSkge1xuICAgIGluaGVyaXRlZC5yZXNvbHZlW1JvdXRlVGl0bGVLZXldID0gcm91dGVDb25maWcudGl0bGU7XG4gIH1cbiAgcmV0dXJuIGluaGVyaXRlZDtcbn1cbmNsYXNzIEFjdGl2YXRlZFJvdXRlU25hcHNob3Qge1xuICB1cmw7XG4gIHBhcmFtcztcbiAgcXVlcnlQYXJhbXM7XG4gIGZyYWdtZW50O1xuICBkYXRhO1xuICBvdXRsZXQ7XG4gIGNvbXBvbmVudDtcbiAgcm91dGVDb25maWc7XG4gIF9yZXNvbHZlO1xuICBfcmVzb2x2ZWREYXRhO1xuICBfcm91dGVyU3RhdGU7XG4gIF9wYXJhbU1hcDtcbiAgX3F1ZXJ5UGFyYW1NYXA7XG4gIF9lbnZpcm9ubWVudEluamVjdG9yO1xuICBnZXQgdGl0bGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGF0YT8uW1JvdXRlVGl0bGVLZXldO1xuICB9XG4gIGNvbnN0cnVjdG9yKHVybCwgcGFyYW1zLCBxdWVyeVBhcmFtcywgZnJhZ21lbnQsIGRhdGEsIG91dGxldCwgY29tcG9uZW50LCByb3V0ZUNvbmZpZywgcmVzb2x2ZSwgZW52aXJvbm1lbnRJbmplY3Rvcikge1xuICAgIHRoaXMudXJsID0gdXJsO1xuICAgIHRoaXMucGFyYW1zID0gcGFyYW1zO1xuICAgIHRoaXMucXVlcnlQYXJhbXMgPSBxdWVyeVBhcmFtcztcbiAgICB0aGlzLmZyYWdtZW50ID0gZnJhZ21lbnQ7XG4gICAgdGhpcy5kYXRhID0gZGF0YTtcbiAgICB0aGlzLm91dGxldCA9IG91dGxldDtcbiAgICB0aGlzLmNvbXBvbmVudCA9IGNvbXBvbmVudDtcbiAgICB0aGlzLnJvdXRlQ29uZmlnID0gcm91dGVDb25maWc7XG4gICAgdGhpcy5fcmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgdGhpcy5fZW52aXJvbm1lbnRJbmplY3RvciA9IGVudmlyb25tZW50SW5qZWN0b3I7XG4gIH1cbiAgZ2V0IHJvb3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JvdXRlclN0YXRlLnJvb3Q7XG4gIH1cbiAgZ2V0IHBhcmVudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcm91dGVyU3RhdGUucGFyZW50KHRoaXMpO1xuICB9XG4gIGdldCBmaXJzdENoaWxkKCkge1xuICAgIHJldHVybiB0aGlzLl9yb3V0ZXJTdGF0ZS5maXJzdENoaWxkKHRoaXMpO1xuICB9XG4gIGdldCBjaGlsZHJlbigpIHtcbiAgICByZXR1cm4gdGhpcy5fcm91dGVyU3RhdGUuY2hpbGRyZW4odGhpcyk7XG4gIH1cbiAgZ2V0IHBhdGhGcm9tUm9vdCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcm91dGVyU3RhdGUucGF0aEZyb21Sb290KHRoaXMpO1xuICB9XG4gIGdldCBwYXJhbU1hcCgpIHtcbiAgICB0aGlzLl9wYXJhbU1hcCA/Pz0gY29udmVydFRvUGFyYW1NYXAodGhpcy5wYXJhbXMpO1xuICAgIHJldHVybiB0aGlzLl9wYXJhbU1hcDtcbiAgfVxuICBnZXQgcXVlcnlQYXJhbU1hcCgpIHtcbiAgICB0aGlzLl9xdWVyeVBhcmFtTWFwID8/PSBjb252ZXJ0VG9QYXJhbU1hcCh0aGlzLnF1ZXJ5UGFyYW1zKTtcbiAgICByZXR1cm4gdGhpcy5fcXVlcnlQYXJhbU1hcDtcbiAgfVxuICB0b1N0cmluZygpIHtcbiAgICBjb25zdCB1cmwgPSB0aGlzLnVybC5tYXAoc2VnbWVudCA9PiBzZWdtZW50LnRvU3RyaW5nKCkpLmpvaW4oJy8nKTtcbiAgICBjb25zdCBtYXRjaGVkID0gdGhpcy5yb3V0ZUNvbmZpZyA/IHRoaXMucm91dGVDb25maWcucGF0aCA6ICcnO1xuICAgIHJldHVybiBgUm91dGUodXJsOicke3VybH0nLCBwYXRoOicke21hdGNoZWR9JylgO1xuICB9XG59XG5jbGFzcyBSb3V0ZXJTdGF0ZVNuYXBzaG90IGV4dGVuZHMgVHJlZSB7XG4gIHVybDtcbiAgY29uc3RydWN0b3IodXJsLCByb290KSB7XG4gICAgc3VwZXIocm9vdCk7XG4gICAgdGhpcy51cmwgPSB1cmw7XG4gICAgc2V0Um91dGVyU3RhdGUodGhpcywgcm9vdCk7XG4gIH1cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZU5vZGUodGhpcy5fcm9vdCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHNldFJvdXRlclN0YXRlKHN0YXRlLCBub2RlKSB7XG4gIG5vZGUudmFsdWUuX3JvdXRlclN0YXRlID0gc3RhdGU7XG4gIG5vZGUuY2hpbGRyZW4uZm9yRWFjaChjID0+IHNldFJvdXRlclN0YXRlKHN0YXRlLCBjKSk7XG59XG5mdW5jdGlvbiBzZXJpYWxpemVOb2RlKG5vZGUpIHtcbiAgY29uc3QgYyA9IG5vZGUuY2hpbGRyZW4ubGVuZ3RoID4gMCA/IGAgeyAke25vZGUuY2hpbGRyZW4ubWFwKHNlcmlhbGl6ZU5vZGUpLmpvaW4oJywgJyl9IH0gYCA6ICcnO1xuICByZXR1cm4gYCR7bm9kZS52YWx1ZX0ke2N9YDtcbn1cbmZ1bmN0aW9uIGFkdmFuY2VBY3RpdmF0ZWRSb3V0ZShyb3V0ZSkge1xuICBpZiAocm91dGUuc25hcHNob3QpIHtcbiAgICBjb25zdCBjdXJyZW50U25hcHNob3QgPSByb3V0ZS5zbmFwc2hvdDtcbiAgICBjb25zdCBuZXh0U25hcHNob3QgPSByb3V0ZS5fZnV0dXJlU25hcHNob3Q7XG4gICAgcm91dGUuc25hcHNob3QgPSBuZXh0U25hcHNob3Q7XG4gICAgaWYgKCFzaGFsbG93RXF1YWwoY3VycmVudFNuYXBzaG90LnF1ZXJ5UGFyYW1zLCBuZXh0U25hcHNob3QucXVlcnlQYXJhbXMpKSB7XG4gICAgICByb3V0ZS5xdWVyeVBhcmFtc1N1YmplY3QubmV4dChuZXh0U25hcHNob3QucXVlcnlQYXJhbXMpO1xuICAgIH1cbiAgICBpZiAoY3VycmVudFNuYXBzaG90LmZyYWdtZW50ICE9PSBuZXh0U25hcHNob3QuZnJhZ21lbnQpIHtcbiAgICAgIHJvdXRlLmZyYWdtZW50U3ViamVjdC5uZXh0KG5leHRTbmFwc2hvdC5mcmFnbWVudCk7XG4gICAgfVxuICAgIGlmICghc2hhbGxvd0VxdWFsKGN1cnJlbnRTbmFwc2hvdC5wYXJhbXMsIG5leHRTbmFwc2hvdC5wYXJhbXMpKSB7XG4gICAgICByb3V0ZS5wYXJhbXNTdWJqZWN0Lm5leHQobmV4dFNuYXBzaG90LnBhcmFtcyk7XG4gICAgfVxuICAgIGlmICghc2hhbGxvd0VxdWFsQXJyYXlzKGN1cnJlbnRTbmFwc2hvdC51cmwsIG5leHRTbmFwc2hvdC51cmwpKSB7XG4gICAgICByb3V0ZS51cmxTdWJqZWN0Lm5leHQobmV4dFNuYXBzaG90LnVybCk7XG4gICAgfVxuICAgIGlmICghc2hhbGxvd0VxdWFsKGN1cnJlbnRTbmFwc2hvdC5kYXRhLCBuZXh0U25hcHNob3QuZGF0YSkpIHtcbiAgICAgIHJvdXRlLmRhdGFTdWJqZWN0Lm5leHQobmV4dFNuYXBzaG90LmRhdGEpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByb3V0ZS5zbmFwc2hvdCA9IHJvdXRlLl9mdXR1cmVTbmFwc2hvdDtcbiAgICByb3V0ZS5kYXRhU3ViamVjdC5uZXh0KHJvdXRlLl9mdXR1cmVTbmFwc2hvdC5kYXRhKTtcbiAgfVxufVxuZnVuY3Rpb24gZXF1YWxQYXJhbXNBbmRVcmxTZWdtZW50cyhhLCBiKSB7XG4gIGNvbnN0IGVxdWFsVXJsUGFyYW1zID0gc2hhbGxvd0VxdWFsKGEucGFyYW1zLCBiLnBhcmFtcykgJiYgZXF1YWxTZWdtZW50cyhhLnVybCwgYi51cmwpO1xuICBjb25zdCBwYXJlbnRzTWlzbWF0Y2ggPSAhYS5wYXJlbnQgIT09ICFiLnBhcmVudDtcbiAgcmV0dXJuIGVxdWFsVXJsUGFyYW1zICYmICFwYXJlbnRzTWlzbWF0Y2ggJiYgKCFhLnBhcmVudCB8fCBlcXVhbFBhcmFtc0FuZFVybFNlZ21lbnRzKGEucGFyZW50LCBiLnBhcmVudCkpO1xufVxuZnVuY3Rpb24gaGFzU3RhdGljVGl0bGUoY29uZmlnKSB7XG4gIHJldHVybiB0eXBlb2YgY29uZmlnLnRpdGxlID09PSAnc3RyaW5nJyB8fCBjb25maWcudGl0bGUgPT09IG51bGw7XG59XG5jb25zdCBST1VURVJfT1VUTEVUX0RBVEEgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ1JvdXRlck91dGxldCBkYXRhJyA6ICcnKTtcbmNsYXNzIFJvdXRlck91dGxldCB7XG4gIGFjdGl2YXRlZCA9IG51bGw7XG4gIGdldCBhY3RpdmF0ZWRDb21wb25lbnRSZWYoKSB7XG4gICAgcmV0dXJuIHRoaXMuYWN0aXZhdGVkO1xuICB9XG4gIF9hY3RpdmF0ZWRSb3V0ZSA9IG51bGw7XG4gIG5hbWUgPSBQUklNQVJZX09VVExFVDtcbiAgYWN0aXZhdGVFdmVudHMgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIGRlYWN0aXZhdGVFdmVudHMgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIGF0dGFjaEV2ZW50cyA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgZGV0YWNoRXZlbnRzID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICByb3V0ZXJPdXRsZXREYXRhID0gaW5wdXQoLi4uKG5nRGV2TW9kZSA/IFt1bmRlZmluZWQsIHtcbiAgICBkZWJ1Z05hbWU6IFwicm91dGVyT3V0bGV0RGF0YVwiXG4gIH1dIDogW10pKTtcbiAgcGFyZW50Q29udGV4dHMgPSBpbmplY3QoQ2hpbGRyZW5PdXRsZXRDb250ZXh0cyk7XG4gIGxvY2F0aW9uID0gaW5qZWN0KFZpZXdDb250YWluZXJSZWYpO1xuICBjaGFuZ2VEZXRlY3RvciA9IGluamVjdChDaGFuZ2VEZXRlY3RvclJlZik7XG4gIGlucHV0QmluZGVyID0gaW5qZWN0KElOUFVUX0JJTkRFUiwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICBzdXBwb3J0c0JpbmRpbmdUb0NvbXBvbmVudElucHV0cyA9IHRydWU7XG4gIG5nT25DaGFuZ2VzKGNoYW5nZXMpIHtcbiAgICBpZiAoY2hhbmdlc1snbmFtZSddKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIGZpcnN0Q2hhbmdlLFxuICAgICAgICBwcmV2aW91c1ZhbHVlXG4gICAgICB9ID0gY2hhbmdlc1snbmFtZSddO1xuICAgICAgaWYgKGZpcnN0Q2hhbmdlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLmlzVHJhY2tlZEluUGFyZW50Q29udGV4dHMocHJldmlvdXNWYWx1ZSkpIHtcbiAgICAgICAgdGhpcy5kZWFjdGl2YXRlKCk7XG4gICAgICAgIHRoaXMucGFyZW50Q29udGV4dHMub25DaGlsZE91dGxldERlc3Ryb3llZChwcmV2aW91c1ZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuaW5pdGlhbGl6ZU91dGxldFdpdGhOYW1lKCk7XG4gICAgfVxuICB9XG4gIG5nT25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLmlzVHJhY2tlZEluUGFyZW50Q29udGV4dHModGhpcy5uYW1lKSkge1xuICAgICAgdGhpcy5wYXJlbnRDb250ZXh0cy5vbkNoaWxkT3V0bGV0RGVzdHJveWVkKHRoaXMubmFtZSk7XG4gICAgfVxuICAgIHRoaXMuaW5wdXRCaW5kZXI/LnVuc3Vic2NyaWJlRnJvbVJvdXRlRGF0YSh0aGlzKTtcbiAgfVxuICBpc1RyYWNrZWRJblBhcmVudENvbnRleHRzKG91dGxldE5hbWUpIHtcbiAgICByZXR1cm4gdGhpcy5wYXJlbnRDb250ZXh0cy5nZXRDb250ZXh0KG91dGxldE5hbWUpPy5vdXRsZXQgPT09IHRoaXM7XG4gIH1cbiAgbmdPbkluaXQoKSB7XG4gICAgdGhpcy5pbml0aWFsaXplT3V0bGV0V2l0aE5hbWUoKTtcbiAgfVxuICBpbml0aWFsaXplT3V0bGV0V2l0aE5hbWUoKSB7XG4gICAgdGhpcy5wYXJlbnRDb250ZXh0cy5vbkNoaWxkT3V0bGV0Q3JlYXRlZCh0aGlzLm5hbWUsIHRoaXMpO1xuICAgIGlmICh0aGlzLmFjdGl2YXRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb250ZXh0ID0gdGhpcy5wYXJlbnRDb250ZXh0cy5nZXRDb250ZXh0KHRoaXMubmFtZSk7XG4gICAgaWYgKGNvbnRleHQ/LnJvdXRlKSB7XG4gICAgICBpZiAoY29udGV4dC5hdHRhY2hSZWYpIHtcbiAgICAgICAgdGhpcy5hdHRhY2goY29udGV4dC5hdHRhY2hSZWYsIGNvbnRleHQucm91dGUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5hY3RpdmF0ZVdpdGgoY29udGV4dC5yb3V0ZSwgY29udGV4dC5pbmplY3Rvcik7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGdldCBpc0FjdGl2YXRlZCgpIHtcbiAgICByZXR1cm4gISF0aGlzLmFjdGl2YXRlZDtcbiAgfVxuICBnZXQgY29tcG9uZW50KCkge1xuICAgIGlmICghdGhpcy5hY3RpdmF0ZWQpIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTIsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICdPdXRsZXQgaXMgbm90IGFjdGl2YXRlZCcpO1xuICAgIHJldHVybiB0aGlzLmFjdGl2YXRlZC5pbnN0YW5jZTtcbiAgfVxuICBnZXQgYWN0aXZhdGVkUm91dGUoKSB7XG4gICAgaWYgKCF0aGlzLmFjdGl2YXRlZCkgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxMiwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgJ091dGxldCBpcyBub3QgYWN0aXZhdGVkJyk7XG4gICAgcmV0dXJuIHRoaXMuX2FjdGl2YXRlZFJvdXRlO1xuICB9XG4gIGdldCBhY3RpdmF0ZWRSb3V0ZURhdGEoKSB7XG4gICAgaWYgKHRoaXMuX2FjdGl2YXRlZFJvdXRlKSB7XG4gICAgICByZXR1cm4gdGhpcy5fYWN0aXZhdGVkUm91dGUuc25hcHNob3QuZGF0YTtcbiAgICB9XG4gICAgcmV0dXJuIHt9O1xuICB9XG4gIGRldGFjaCgpIHtcbiAgICBpZiAoIXRoaXMuYWN0aXZhdGVkKSB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDEyLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiAnT3V0bGV0IGlzIG5vdCBhY3RpdmF0ZWQnKTtcbiAgICB0aGlzLmxvY2F0aW9uLmRldGFjaCgpO1xuICAgIGNvbnN0IGNtcCA9IHRoaXMuYWN0aXZhdGVkO1xuICAgIHRoaXMuYWN0aXZhdGVkID0gbnVsbDtcbiAgICB0aGlzLl9hY3RpdmF0ZWRSb3V0ZSA9IG51bGw7XG4gICAgdGhpcy5kZXRhY2hFdmVudHMuZW1pdChjbXAuaW5zdGFuY2UpO1xuICAgIHJldHVybiBjbXA7XG4gIH1cbiAgYXR0YWNoKHJlZiwgYWN0aXZhdGVkUm91dGUpIHtcbiAgICB0aGlzLmFjdGl2YXRlZCA9IHJlZjtcbiAgICB0aGlzLl9hY3RpdmF0ZWRSb3V0ZSA9IGFjdGl2YXRlZFJvdXRlO1xuICAgIHRoaXMubG9jYXRpb24uaW5zZXJ0KHJlZi5ob3N0Vmlldyk7XG4gICAgdGhpcy5pbnB1dEJpbmRlcj8uYmluZEFjdGl2YXRlZFJvdXRlVG9PdXRsZXRDb21wb25lbnQodGhpcyk7XG4gICAgdGhpcy5hdHRhY2hFdmVudHMuZW1pdChyZWYuaW5zdGFuY2UpO1xuICB9XG4gIGRlYWN0aXZhdGUoKSB7XG4gICAgaWYgKHRoaXMuYWN0aXZhdGVkKSB7XG4gICAgICBjb25zdCBjID0gdGhpcy5jb21wb25lbnQ7XG4gICAgICB0aGlzLmFjdGl2YXRlZC5kZXN0cm95KCk7XG4gICAgICB0aGlzLmFjdGl2YXRlZCA9IG51bGw7XG4gICAgICB0aGlzLl9hY3RpdmF0ZWRSb3V0ZSA9IG51bGw7XG4gICAgICB0aGlzLmRlYWN0aXZhdGVFdmVudHMuZW1pdChjKTtcbiAgICB9XG4gIH1cbiAgYWN0aXZhdGVXaXRoKGFjdGl2YXRlZFJvdXRlLCBlbnZpcm9ubWVudEluamVjdG9yKSB7XG4gICAgaWYgKHRoaXMuaXNBY3RpdmF0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTMsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmICdDYW5ub3QgYWN0aXZhdGUgYW4gYWxyZWFkeSBhY3RpdmF0ZWQgb3V0bGV0Jyk7XG4gICAgfVxuICAgIHRoaXMuX2FjdGl2YXRlZFJvdXRlID0gYWN0aXZhdGVkUm91dGU7XG4gICAgY29uc3QgbG9jYXRpb24gPSB0aGlzLmxvY2F0aW9uO1xuICAgIGNvbnN0IHNuYXBzaG90ID0gYWN0aXZhdGVkUm91dGUuc25hcHNob3Q7XG4gICAgY29uc3QgY29tcG9uZW50ID0gc25hcHNob3QuY29tcG9uZW50O1xuICAgIGNvbnN0IGNoaWxkQ29udGV4dHMgPSB0aGlzLnBhcmVudENvbnRleHRzLmdldE9yQ3JlYXRlQ29udGV4dCh0aGlzLm5hbWUpLmNoaWxkcmVuO1xuICAgIGNvbnN0IGluamVjdG9yID0gbmV3IE91dGxldEluamVjdG9yKGFjdGl2YXRlZFJvdXRlLCBjaGlsZENvbnRleHRzLCBsb2NhdGlvbi5pbmplY3RvciwgdGhpcy5yb3V0ZXJPdXRsZXREYXRhKTtcbiAgICB0aGlzLmFjdGl2YXRlZCA9IGxvY2F0aW9uLmNyZWF0ZUNvbXBvbmVudChjb21wb25lbnQsIHtcbiAgICAgIGluZGV4OiBsb2NhdGlvbi5sZW5ndGgsXG4gICAgICBpbmplY3RvcixcbiAgICAgIGVudmlyb25tZW50SW5qZWN0b3I6IGVudmlyb25tZW50SW5qZWN0b3JcbiAgICB9KTtcbiAgICB0aGlzLmNoYW5nZURldGVjdG9yLm1hcmtGb3JDaGVjaygpO1xuICAgIHRoaXMuaW5wdXRCaW5kZXI/LmJpbmRBY3RpdmF0ZWRSb3V0ZVRvT3V0bGV0Q29tcG9uZW50KHRoaXMpO1xuICAgIHRoaXMuYWN0aXZhdGVFdmVudHMuZW1pdCh0aGlzLmFjdGl2YXRlZC5pbnN0YW5jZSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVyT3V0bGV0X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSb3V0ZXJPdXRsZXQpKCk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IFJvdXRlck91dGxldCxcbiAgICBzZWxlY3RvcnM6IFtbXCJyb3V0ZXItb3V0bGV0XCJdXSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIG5hbWU6IFwibmFtZVwiLFxuICAgICAgcm91dGVyT3V0bGV0RGF0YTogWzEsIFwicm91dGVyT3V0bGV0RGF0YVwiXVxuICAgIH0sXG4gICAgb3V0cHV0czoge1xuICAgICAgYWN0aXZhdGVFdmVudHM6IFwiYWN0aXZhdGVcIixcbiAgICAgIGRlYWN0aXZhdGVFdmVudHM6IFwiZGVhY3RpdmF0ZVwiLFxuICAgICAgYXR0YWNoRXZlbnRzOiBcImF0dGFjaFwiLFxuICAgICAgZGV0YWNoRXZlbnRzOiBcImRldGFjaFwiXG4gICAgfSxcbiAgICBleHBvcnRBczogW1wib3V0bGV0XCJdLFxuICAgIGZlYXR1cmVzOiBbaTAuybXJtU5nT25DaGFuZ2VzRmVhdHVyZV1cbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShSb3V0ZXJPdXRsZXQsIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ3JvdXRlci1vdXRsZXQnLFxuICAgICAgZXhwb3J0QXM6ICdvdXRsZXQnXG4gICAgfV1cbiAgfV0sIG51bGwsIHtcbiAgICBuYW1lOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBhY3RpdmF0ZUV2ZW50czogW3tcbiAgICAgIHR5cGU6IE91dHB1dCxcbiAgICAgIGFyZ3M6IFsnYWN0aXZhdGUnXVxuICAgIH1dLFxuICAgIGRlYWN0aXZhdGVFdmVudHM6IFt7XG4gICAgICB0eXBlOiBPdXRwdXQsXG4gICAgICBhcmdzOiBbJ2RlYWN0aXZhdGUnXVxuICAgIH1dLFxuICAgIGF0dGFjaEV2ZW50czogW3tcbiAgICAgIHR5cGU6IE91dHB1dCxcbiAgICAgIGFyZ3M6IFsnYXR0YWNoJ11cbiAgICB9XSxcbiAgICBkZXRhY2hFdmVudHM6IFt7XG4gICAgICB0eXBlOiBPdXRwdXQsXG4gICAgICBhcmdzOiBbJ2RldGFjaCddXG4gICAgfV0sXG4gICAgcm91dGVyT3V0bGV0RGF0YTogW3tcbiAgICAgIHR5cGU6IGkwLklucHV0LFxuICAgICAgYXJnczogW3tcbiAgICAgICAgaXNTaWduYWw6IHRydWUsXG4gICAgICAgIGFsaWFzOiBcInJvdXRlck91dGxldERhdGFcIixcbiAgICAgICAgcmVxdWlyZWQ6IGZhbHNlXG4gICAgICB9XVxuICAgIH1dXG4gIH0pO1xufSkoKTtcbmNsYXNzIE91dGxldEluamVjdG9yIHtcbiAgcm91dGU7XG4gIGNoaWxkQ29udGV4dHM7XG4gIHBhcmVudDtcbiAgb3V0bGV0RGF0YTtcbiAgY29uc3RydWN0b3Iocm91dGUsIGNoaWxkQ29udGV4dHMsIHBhcmVudCwgb3V0bGV0RGF0YSkge1xuICAgIHRoaXMucm91dGUgPSByb3V0ZTtcbiAgICB0aGlzLmNoaWxkQ29udGV4dHMgPSBjaGlsZENvbnRleHRzO1xuICAgIHRoaXMucGFyZW50ID0gcGFyZW50O1xuICAgIHRoaXMub3V0bGV0RGF0YSA9IG91dGxldERhdGE7XG4gIH1cbiAgZ2V0KHRva2VuLCBub3RGb3VuZFZhbHVlKSB7XG4gICAgaWYgKHRva2VuID09PSBBY3RpdmF0ZWRSb3V0ZSkge1xuICAgICAgcmV0dXJuIHRoaXMucm91dGU7XG4gICAgfVxuICAgIGlmICh0b2tlbiA9PT0gQ2hpbGRyZW5PdXRsZXRDb250ZXh0cykge1xuICAgICAgcmV0dXJuIHRoaXMuY2hpbGRDb250ZXh0cztcbiAgICB9XG4gICAgaWYgKHRva2VuID09PSBST1VURVJfT1VUTEVUX0RBVEEpIHtcbiAgICAgIHJldHVybiB0aGlzLm91dGxldERhdGE7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnBhcmVudC5nZXQodG9rZW4sIG5vdEZvdW5kVmFsdWUpO1xuICB9XG59XG5jb25zdCBJTlBVVF9CSU5ERVIgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ1JvdXRlciBJbnB1dCBCaW5kZXInIDogJycpO1xuY2xhc3MgUm91dGVkQ29tcG9uZW50SW5wdXRCaW5kZXIge1xuICBvcHRpb25zO1xuICBvdXRsZXREYXRhU3Vic2NyaXB0aW9ucyA9IG5ldyBNYXAoKTtcbiAgb3V0bGV0U2VlbktleXMgPSBuZXcgTWFwKCk7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMub3B0aW9ucy5xdWVyeVBhcmFtcyA/Pz0gdHJ1ZTtcbiAgfVxuICBiaW5kQWN0aXZhdGVkUm91dGVUb091dGxldENvbXBvbmVudChvdXRsZXQpIHtcbiAgICB0aGlzLnVuc3Vic2NyaWJlRnJvbVJvdXRlRGF0YShvdXRsZXQpO1xuICAgIHRoaXMuc3Vic2NyaWJlVG9Sb3V0ZURhdGEob3V0bGV0KTtcbiAgfVxuICB1bnN1YnNjcmliZUZyb21Sb3V0ZURhdGEob3V0bGV0KSB7XG4gICAgdGhpcy5vdXRsZXREYXRhU3Vic2NyaXB0aW9ucy5nZXQob3V0bGV0KT8udW5zdWJzY3JpYmUoKTtcbiAgICB0aGlzLm91dGxldERhdGFTdWJzY3JpcHRpb25zLmRlbGV0ZShvdXRsZXQpO1xuICAgIHRoaXMub3V0bGV0U2VlbktleXMuZGVsZXRlKG91dGxldCk7XG4gIH1cbiAgc3Vic2NyaWJlVG9Sb3V0ZURhdGEob3V0bGV0KSB7XG4gICAgY29uc3Qge1xuICAgICAgYWN0aXZhdGVkUm91dGVcbiAgICB9ID0gb3V0bGV0O1xuICAgIGNvbnN0IGRhdGFTdWJzY3JpcHRpb24gPSBjb21iaW5lTGF0ZXN0KFt0aGlzLm9wdGlvbnMucXVlcnlQYXJhbXMgPyBhY3RpdmF0ZWRSb3V0ZS5xdWVyeVBhcmFtcyA6IG9mKHt9KSwgYWN0aXZhdGVkUm91dGUucGFyYW1zLCBhY3RpdmF0ZWRSb3V0ZS5kYXRhXSkucGlwZShzd2l0Y2hNYXAoKFtxdWVyeVBhcmFtcywgcGFyYW1zLCBkYXRhXSwgaW5kZXgpID0+IHtcbiAgICAgIGRhdGEgPSB7XG4gICAgICAgIC4uLnF1ZXJ5UGFyYW1zLFxuICAgICAgICAuLi5wYXJhbXMsXG4gICAgICAgIC4uLmRhdGFcbiAgICAgIH07XG4gICAgICBpZiAoaW5kZXggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIG9mKGRhdGEpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShkYXRhKTtcbiAgICB9KSkuc3Vic2NyaWJlKGRhdGEgPT4ge1xuICAgICAgaWYgKCFvdXRsZXQuaXNBY3RpdmF0ZWQgfHwgIW91dGxldC5hY3RpdmF0ZWRDb21wb25lbnRSZWYgfHwgb3V0bGV0LmFjdGl2YXRlZFJvdXRlICE9PSBhY3RpdmF0ZWRSb3V0ZSB8fCBhY3RpdmF0ZWRSb3V0ZS5jb21wb25lbnQgPT09IG51bGwpIHtcbiAgICAgICAgdGhpcy51bnN1YnNjcmliZUZyb21Sb3V0ZURhdGEob3V0bGV0KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgbWlycm9yID0gcmVmbGVjdENvbXBvbmVudFR5cGUoYWN0aXZhdGVkUm91dGUuY29tcG9uZW50KTtcbiAgICAgIGlmICghbWlycm9yKSB7XG4gICAgICAgIHRoaXMudW5zdWJzY3JpYmVGcm9tUm91dGVEYXRhKG91dGxldCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGxldCBzZWVuS2V5cyA9IHRoaXMub3V0bGV0U2VlbktleXMuZ2V0KG91dGxldCk7XG4gICAgICBpZiAoIXNlZW5LZXlzKSB7XG4gICAgICAgIHNlZW5LZXlzID0gbmV3IFNldCgpO1xuICAgICAgICB0aGlzLm91dGxldFNlZW5LZXlzLnNldChvdXRsZXQsIHNlZW5LZXlzKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XG4gICAgICAgIHNlZW5LZXlzLmFkZChrZXkpO1xuICAgICAgfVxuICAgICAgY29uc3QgYmVoYXZpb3IgPSB0aGlzLm9wdGlvbnMudW5tYXRjaGVkSW5wdXRCZWhhdmlvciA/PyAnYWx3YXlzVW5kZWZpbmVkJztcbiAgICAgIGZvciAoY29uc3Qge1xuICAgICAgICB0ZW1wbGF0ZU5hbWVcbiAgICAgIH0gb2YgbWlycm9yLmlucHV0cykge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFbdGVtcGxhdGVOYW1lXTtcbiAgICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQgfHwgYmVoYXZpb3IgPT09ICdhbHdheXNVbmRlZmluZWQnIHx8IHNlZW5LZXlzLmhhcyh0ZW1wbGF0ZU5hbWUpKSB7XG4gICAgICAgICAgb3V0bGV0LmFjdGl2YXRlZENvbXBvbmVudFJlZi5zZXRJbnB1dCh0ZW1wbGF0ZU5hbWUsIHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMub3V0bGV0RGF0YVN1YnNjcmlwdGlvbnMuc2V0KG91dGxldCwgZGF0YVN1YnNjcmlwdGlvbik7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVkQ29tcG9uZW50SW5wdXRCaW5kZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIGkwLsm1ybVpbnZhbGlkRmFjdG9yeSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBSb3V0ZWRDb21wb25lbnRJbnB1dEJpbmRlcixcbiAgICBmYWN0b3J5OiBSb3V0ZWRDb21wb25lbnRJbnB1dEJpbmRlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJvdXRlZENvbXBvbmVudElucHV0QmluZGVyLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jbGFzcyDJtUVtcHR5T3V0bGV0Q29tcG9uZW50IHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gybVFbXB0eU91dGxldENvbXBvbmVudF9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgybVFbXB0eU91dGxldENvbXBvbmVudCkoKTtcbiAgfTtcbiAgc3RhdGljIMm1Y21wID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUNvbXBvbmVudCh7XG4gICAgdHlwZTogybVFbXB0eU91dGxldENvbXBvbmVudCxcbiAgICBzZWxlY3RvcnM6IFtbXCJuZy1jb21wb25lbnRcIl1dLFxuICAgIGV4cG9ydEFzOiBbXCJlbXB0eVJvdXRlck91dGxldFwiXSxcbiAgICBkZWNsczogMSxcbiAgICB2YXJzOiAwLFxuICAgIHRlbXBsYXRlOiBmdW5jdGlvbiBfRW1wdHlPdXRsZXRDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkge1xuICAgICAgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgwLCBcInJvdXRlci1vdXRsZXRcIik7XG4gICAgICB9XG4gICAgfSxcbiAgICBkZXBlbmRlbmNpZXM6IFtSb3V0ZXJPdXRsZXRdLFxuICAgIGVuY2Fwc3VsYXRpb246IDIsXG4gICAgY2hhbmdlRGV0ZWN0aW9uOiAxXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoybVFbXB0eU91dGxldENvbXBvbmVudCwgW3tcbiAgICB0eXBlOiBDb21wb25lbnQsXG4gICAgYXJnczogW3tcbiAgICAgIHRlbXBsYXRlOiBgPHJvdXRlci1vdXRsZXQgLz5gLFxuICAgICAgaW1wb3J0czogW1JvdXRlck91dGxldF0sXG4gICAgICBleHBvcnRBczogJ2VtcHR5Um91dGVyT3V0bGV0JyxcbiAgICAgIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuRWFnZXJcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gc3RhbmRhcmRpemVDb25maWcocikge1xuICBjb25zdCBjaGlsZHJlbiA9IHIuY2hpbGRyZW4gJiYgci5jaGlsZHJlbi5tYXAoc3RhbmRhcmRpemVDb25maWcpO1xuICBjb25zdCBjID0gY2hpbGRyZW4gPyB7XG4gICAgLi4ucixcbiAgICBjaGlsZHJlblxuICB9IDoge1xuICAgIC4uLnJcbiAgfTtcbiAgaWYgKCFjLmNvbXBvbmVudCAmJiAhYy5sb2FkQ29tcG9uZW50ICYmIChjaGlsZHJlbiB8fCBjLmxvYWRDaGlsZHJlbikgJiYgYy5vdXRsZXQgJiYgYy5vdXRsZXQgIT09IFBSSU1BUllfT1VUTEVUKSB7XG4gICAgYy5jb21wb25lbnQgPSDJtUVtcHR5T3V0bGV0Q29tcG9uZW50O1xuICB9XG4gIHJldHVybiBjO1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVyU3RhdGUocm91dGVSZXVzZVN0cmF0ZWd5LCBjdXJyLCBwcmV2U3RhdGUpIHtcbiAgY29uc3QgbmV3bHlDcmVhdGVkUm91dGVzID0gbmV3IFNldCgpO1xuICBjb25zdCByb290ID0gY3JlYXRlTm9kZShyb3V0ZVJldXNlU3RyYXRlZ3ksIGN1cnIuX3Jvb3QsIHByZXZTdGF0ZSA/IHByZXZTdGF0ZS5fcm9vdCA6IHVuZGVmaW5lZCwgbmV3bHlDcmVhdGVkUm91dGVzKTtcbiAgcmV0dXJuIHtcbiAgICBuZXdseUNyZWF0ZWRSb3V0ZXMsXG4gICAgc3RhdGU6IG5ldyBSb3V0ZXJTdGF0ZShyb290LCBjdXJyKVxuICB9O1xufVxuZnVuY3Rpb24gY3JlYXRlTm9kZShyb3V0ZVJldXNlU3RyYXRlZ3ksIGN1cnIsIHByZXZTdGF0ZSwgbmV3bHlDcmVhdGVkUm91dGVzKSB7XG4gIGlmIChwcmV2U3RhdGUgJiYgcm91dGVSZXVzZVN0cmF0ZWd5LnNob3VsZFJldXNlUm91dGUoY3Vyci52YWx1ZSwgcHJldlN0YXRlLnZhbHVlLnNuYXBzaG90KSkge1xuICAgIGNvbnN0IHZhbHVlID0gcHJldlN0YXRlLnZhbHVlO1xuICAgIHZhbHVlLl9mdXR1cmVTbmFwc2hvdCA9IGN1cnIudmFsdWU7XG4gICAgY29uc3QgY2hpbGRyZW4gPSBjcmVhdGVPclJldXNlQ2hpbGRyZW4ocm91dGVSZXVzZVN0cmF0ZWd5LCBjdXJyLCBwcmV2U3RhdGUsIG5ld2x5Q3JlYXRlZFJvdXRlcyk7XG4gICAgcmV0dXJuIG5ldyBUcmVlTm9kZSh2YWx1ZSwgY2hpbGRyZW4pO1xuICB9IGVsc2Uge1xuICAgIGlmIChyb3V0ZVJldXNlU3RyYXRlZ3kuc2hvdWxkQXR0YWNoKGN1cnIudmFsdWUpKSB7XG4gICAgICBjb25zdCBkZXRhY2hlZFJvdXRlSGFuZGxlID0gcm91dGVSZXVzZVN0cmF0ZWd5LnJldHJpZXZlKGN1cnIudmFsdWUpO1xuICAgICAgaWYgKGRldGFjaGVkUm91dGVIYW5kbGUgIT09IG51bGwpIHtcbiAgICAgICAgY29uc3QgdHJlZSA9IGRldGFjaGVkUm91dGVIYW5kbGUucm91dGU7XG4gICAgICAgIHRyZWUudmFsdWUuX2Z1dHVyZVNuYXBzaG90ID0gY3Vyci52YWx1ZTtcbiAgICAgICAgdHJlZS5jaGlsZHJlbiA9IGN1cnIuY2hpbGRyZW4ubWFwKGMgPT4gY3JlYXRlTm9kZShyb3V0ZVJldXNlU3RyYXRlZ3ksIGMsIHVuZGVmaW5lZCwgbmV3bHlDcmVhdGVkUm91dGVzKSk7XG4gICAgICAgIHJldHVybiB0cmVlO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCB2YWx1ZSA9IGNyZWF0ZUFjdGl2YXRlZFJvdXRlKGN1cnIudmFsdWUpO1xuICAgIG5ld2x5Q3JlYXRlZFJvdXRlcy5hZGQodmFsdWUpO1xuICAgIGNvbnN0IGNoaWxkcmVuID0gY3Vyci5jaGlsZHJlbi5tYXAoYyA9PiBjcmVhdGVOb2RlKHJvdXRlUmV1c2VTdHJhdGVneSwgYywgdW5kZWZpbmVkLCBuZXdseUNyZWF0ZWRSb3V0ZXMpKTtcbiAgICByZXR1cm4gbmV3IFRyZWVOb2RlKHZhbHVlLCBjaGlsZHJlbik7XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZU9yUmV1c2VDaGlsZHJlbihyb3V0ZVJldXNlU3RyYXRlZ3ksIGN1cnIsIHByZXZTdGF0ZSwgbmV3bHlDcmVhdGVkUm91dGVzKSB7XG4gIHJldHVybiBjdXJyLmNoaWxkcmVuLm1hcChjaGlsZCA9PiB7XG4gICAgZm9yIChjb25zdCBwIG9mIHByZXZTdGF0ZS5jaGlsZHJlbikge1xuICAgICAgaWYgKHJvdXRlUmV1c2VTdHJhdGVneS5zaG91bGRSZXVzZVJvdXRlKGNoaWxkLnZhbHVlLCBwLnZhbHVlLnNuYXBzaG90KSkge1xuICAgICAgICByZXR1cm4gY3JlYXRlTm9kZShyb3V0ZVJldXNlU3RyYXRlZ3ksIGNoaWxkLCBwLCBuZXdseUNyZWF0ZWRSb3V0ZXMpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlTm9kZShyb3V0ZVJldXNlU3RyYXRlZ3ksIGNoaWxkLCB1bmRlZmluZWQsIG5ld2x5Q3JlYXRlZFJvdXRlcyk7XG4gIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlQWN0aXZhdGVkUm91dGUoYykge1xuICByZXR1cm4gbmV3IEFjdGl2YXRlZFJvdXRlKG5ldyBCZWhhdmlvclN1YmplY3QoYy51cmwpLCBuZXcgQmVoYXZpb3JTdWJqZWN0KGMucGFyYW1zKSwgbmV3IEJlaGF2aW9yU3ViamVjdChjLnF1ZXJ5UGFyYW1zKSwgbmV3IEJlaGF2aW9yU3ViamVjdChjLmZyYWdtZW50KSwgbmV3IEJlaGF2aW9yU3ViamVjdChjLmRhdGEpLCBjLm91dGxldCwgYy5jb21wb25lbnQsIGMpO1xufVxuY2xhc3MgUmVkaXJlY3RDb21tYW5kIHtcbiAgcmVkaXJlY3RUbztcbiAgbmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucztcbiAgY29uc3RydWN0b3IocmVkaXJlY3RUbywgbmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucykge1xuICAgIHRoaXMucmVkaXJlY3RUbyA9IHJlZGlyZWN0VG87XG4gICAgdGhpcy5uYXZpZ2F0aW9uQmVoYXZpb3JPcHRpb25zID0gbmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucztcbiAgfVxufVxuY29uc3QgTkFWSUdBVElPTl9DQU5DRUxJTkdfRVJST1IgPSAnbmdOYXZpZ2F0aW9uQ2FuY2VsaW5nRXJyb3InO1xuZnVuY3Rpb24gcmVkaXJlY3RpbmdOYXZpZ2F0aW9uRXJyb3IodXJsU2VyaWFsaXplciwgcmVkaXJlY3QpIHtcbiAgY29uc3Qge1xuICAgIHJlZGlyZWN0VG8sXG4gICAgbmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9uc1xuICB9ID0gaXNVcmxUcmVlKHJlZGlyZWN0KSA/IHtcbiAgICByZWRpcmVjdFRvOiByZWRpcmVjdCxcbiAgICBuYXZpZ2F0aW9uQmVoYXZpb3JPcHRpb25zOiB1bmRlZmluZWRcbiAgfSA6IHJlZGlyZWN0O1xuICBjb25zdCBlcnJvciA9IG5hdmlnYXRpb25DYW5jZWxpbmdFcnJvcihuZ0Rldk1vZGUgJiYgYFJlZGlyZWN0aW5nIHRvIFwiJHt1cmxTZXJpYWxpemVyLnNlcmlhbGl6ZShyZWRpcmVjdFRvKX1cImAsIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLlJlZGlyZWN0KTtcbiAgZXJyb3IudXJsID0gcmVkaXJlY3RUbztcbiAgZXJyb3IubmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucyA9IG5hdmlnYXRpb25CZWhhdmlvck9wdGlvbnM7XG4gIHJldHVybiBlcnJvcjtcbn1cbmZ1bmN0aW9uIG5hdmlnYXRpb25DYW5jZWxpbmdFcnJvcihtZXNzYWdlLCBjb2RlKSB7XG4gIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKGBOYXZpZ2F0aW9uQ2FuY2VsaW5nRXJyb3I6ICR7bWVzc2FnZSB8fCAnJ31gKTtcbiAgZXJyb3JbTkFWSUdBVElPTl9DQU5DRUxJTkdfRVJST1JdID0gdHJ1ZTtcbiAgZXJyb3IuY2FuY2VsbGF0aW9uQ29kZSA9IGNvZGU7XG4gIHJldHVybiBlcnJvcjtcbn1cbmZ1bmN0aW9uIGlzUmVkaXJlY3RpbmdOYXZpZ2F0aW9uQ2FuY2VsaW5nRXJyb3IoZXJyb3IpIHtcbiAgcmV0dXJuIGlzTmF2aWdhdGlvbkNhbmNlbGluZ0Vycm9yKGVycm9yKSAmJiBpc1VybFRyZWUoZXJyb3IudXJsKTtcbn1cbmZ1bmN0aW9uIGlzTmF2aWdhdGlvbkNhbmNlbGluZ0Vycm9yKGVycm9yKSB7XG4gIHJldHVybiAhIWVycm9yICYmIGVycm9yW05BVklHQVRJT05fQ0FOQ0VMSU5HX0VSUk9SXTtcbn1cbmxldCB3YXJuZWRBYm91dFVuc3VwcG9ydGVkSW5wdXRCaW5kaW5nID0gZmFsc2U7XG5jbGFzcyBBY3RpdmF0ZVJvdXRlcyB7XG4gIHJvdXRlUmV1c2VTdHJhdGVneTtcbiAgZnV0dXJlU3RhdGU7XG4gIGN1cnJTdGF0ZTtcbiAgZm9yd2FyZEV2ZW50O1xuICBpbnB1dEJpbmRpbmdFbmFibGVkO1xuICBjb25zdHJ1Y3Rvcihyb3V0ZVJldXNlU3RyYXRlZ3ksIGZ1dHVyZVN0YXRlLCBjdXJyU3RhdGUsIGZvcndhcmRFdmVudCwgaW5wdXRCaW5kaW5nRW5hYmxlZCkge1xuICAgIHRoaXMucm91dGVSZXVzZVN0cmF0ZWd5ID0gcm91dGVSZXVzZVN0cmF0ZWd5O1xuICAgIHRoaXMuZnV0dXJlU3RhdGUgPSBmdXR1cmVTdGF0ZTtcbiAgICB0aGlzLmN1cnJTdGF0ZSA9IGN1cnJTdGF0ZTtcbiAgICB0aGlzLmZvcndhcmRFdmVudCA9IGZvcndhcmRFdmVudDtcbiAgICB0aGlzLmlucHV0QmluZGluZ0VuYWJsZWQgPSBpbnB1dEJpbmRpbmdFbmFibGVkO1xuICB9XG4gIGFjdGl2YXRlKHBhcmVudENvbnRleHRzKSB7XG4gICAgY29uc3QgZnV0dXJlUm9vdCA9IHRoaXMuZnV0dXJlU3RhdGUuX3Jvb3Q7XG4gICAgY29uc3QgY3VyclJvb3QgPSB0aGlzLmN1cnJTdGF0ZSA/IHRoaXMuY3VyclN0YXRlLl9yb290IDogbnVsbDtcbiAgICB0aGlzLmRlYWN0aXZhdGVDaGlsZFJvdXRlcyhmdXR1cmVSb290LCBjdXJyUm9vdCwgcGFyZW50Q29udGV4dHMpO1xuICAgIGFkdmFuY2VBY3RpdmF0ZWRSb3V0ZSh0aGlzLmZ1dHVyZVN0YXRlLnJvb3QpO1xuICAgIHRoaXMuYWN0aXZhdGVDaGlsZFJvdXRlcyhmdXR1cmVSb290LCBjdXJyUm9vdCwgcGFyZW50Q29udGV4dHMpO1xuICB9XG4gIGRlYWN0aXZhdGVDaGlsZFJvdXRlcyhmdXR1cmVOb2RlLCBjdXJyTm9kZSwgY29udGV4dHMpIHtcbiAgICBjb25zdCBjaGlsZHJlbiA9IG5vZGVDaGlsZHJlbkFzTWFwKGN1cnJOb2RlKTtcbiAgICBmdXR1cmVOb2RlLmNoaWxkcmVuLmZvckVhY2goZnV0dXJlQ2hpbGQgPT4ge1xuICAgICAgY29uc3QgY2hpbGRPdXRsZXROYW1lID0gZnV0dXJlQ2hpbGQudmFsdWUub3V0bGV0O1xuICAgICAgdGhpcy5kZWFjdGl2YXRlUm91dGVzKGZ1dHVyZUNoaWxkLCBjaGlsZHJlbltjaGlsZE91dGxldE5hbWVdLCBjb250ZXh0cyk7XG4gICAgICBkZWxldGUgY2hpbGRyZW5bY2hpbGRPdXRsZXROYW1lXTtcbiAgICB9KTtcbiAgICBPYmplY3QudmFsdWVzKGNoaWxkcmVuKS5mb3JFYWNoKHYgPT4ge1xuICAgICAgdGhpcy5kZWFjdGl2YXRlUm91dGVBbmRJdHNDaGlsZHJlbih2LCBjb250ZXh0cyk7XG4gICAgfSk7XG4gIH1cbiAgZGVhY3RpdmF0ZVJvdXRlcyhmdXR1cmVOb2RlLCBjdXJyTm9kZSwgcGFyZW50Q29udGV4dCkge1xuICAgIGNvbnN0IGZ1dHVyZSA9IGZ1dHVyZU5vZGUudmFsdWU7XG4gICAgY29uc3QgY3VyciA9IGN1cnJOb2RlID8gY3Vyck5vZGUudmFsdWUgOiBudWxsO1xuICAgIGlmIChmdXR1cmUgPT09IGN1cnIpIHtcbiAgICAgIGlmIChmdXR1cmUuY29tcG9uZW50KSB7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0LmdldENvbnRleHQoZnV0dXJlLm91dGxldCk7XG4gICAgICAgIGlmIChjb250ZXh0KSB7XG4gICAgICAgICAgdGhpcy5kZWFjdGl2YXRlQ2hpbGRSb3V0ZXMoZnV0dXJlTm9kZSwgY3Vyck5vZGUsIGNvbnRleHQuY2hpbGRyZW4pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmRlYWN0aXZhdGVDaGlsZFJvdXRlcyhmdXR1cmVOb2RlLCBjdXJyTm9kZSwgcGFyZW50Q29udGV4dCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChjdXJyKSB7XG4gICAgICAgIHRoaXMuZGVhY3RpdmF0ZVJvdXRlQW5kSXRzQ2hpbGRyZW4oY3Vyck5vZGUsIHBhcmVudENvbnRleHQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBkZWFjdGl2YXRlUm91dGVBbmRJdHNDaGlsZHJlbihyb3V0ZSwgcGFyZW50Q29udGV4dHMpIHtcbiAgICBpZiAocm91dGUudmFsdWUuY29tcG9uZW50ICYmIHRoaXMucm91dGVSZXVzZVN0cmF0ZWd5LnNob3VsZERldGFjaChyb3V0ZS52YWx1ZS5zbmFwc2hvdCkpIHtcbiAgICAgIHRoaXMuZGV0YWNoQW5kU3RvcmVSb3V0ZVN1YnRyZWUocm91dGUsIHBhcmVudENvbnRleHRzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kZWFjdGl2YXRlUm91dGVBbmRPdXRsZXQocm91dGUsIHBhcmVudENvbnRleHRzKTtcbiAgICB9XG4gIH1cbiAgZGV0YWNoQW5kU3RvcmVSb3V0ZVN1YnRyZWUocm91dGUsIHBhcmVudENvbnRleHRzKSB7XG4gICAgY29uc3QgY29udGV4dCA9IHBhcmVudENvbnRleHRzLmdldENvbnRleHQocm91dGUudmFsdWUub3V0bGV0KTtcbiAgICBjb25zdCBjb250ZXh0cyA9IGNvbnRleHQgJiYgcm91dGUudmFsdWUuY29tcG9uZW50ID8gY29udGV4dC5jaGlsZHJlbiA6IHBhcmVudENvbnRleHRzO1xuICAgIGNvbnN0IGNoaWxkcmVuID0gbm9kZUNoaWxkcmVuQXNNYXAocm91dGUpO1xuICAgIGZvciAoY29uc3QgdHJlZU5vZGUgb2YgT2JqZWN0LnZhbHVlcyhjaGlsZHJlbikpIHtcbiAgICAgIHRoaXMuZGVhY3RpdmF0ZVJvdXRlQW5kSXRzQ2hpbGRyZW4odHJlZU5vZGUsIGNvbnRleHRzKTtcbiAgICB9XG4gICAgaWYgKGNvbnRleHQgJiYgY29udGV4dC5vdXRsZXQpIHtcbiAgICAgIGNvbnN0IGNvbXBvbmVudFJlZiA9IGNvbnRleHQub3V0bGV0LmRldGFjaCgpO1xuICAgICAgY29uc3QgY29udGV4dHMgPSBjb250ZXh0LmNoaWxkcmVuLm9uT3V0bGV0RGVhY3RpdmF0ZWQoKTtcbiAgICAgIHRoaXMucm91dGVSZXVzZVN0cmF0ZWd5LnN0b3JlKHJvdXRlLnZhbHVlLnNuYXBzaG90LCB7XG4gICAgICAgIGNvbXBvbmVudFJlZixcbiAgICAgICAgcm91dGUsXG4gICAgICAgIGNvbnRleHRzXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgZGVhY3RpdmF0ZVJvdXRlQW5kT3V0bGV0KHJvdXRlLCBwYXJlbnRDb250ZXh0cykge1xuICAgIGNvbnN0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0cy5nZXRDb250ZXh0KHJvdXRlLnZhbHVlLm91dGxldCk7XG4gICAgY29uc3QgY29udGV4dHMgPSBjb250ZXh0ICYmIHJvdXRlLnZhbHVlLmNvbXBvbmVudCA/IGNvbnRleHQuY2hpbGRyZW4gOiBwYXJlbnRDb250ZXh0cztcbiAgICBjb25zdCBjaGlsZHJlbiA9IG5vZGVDaGlsZHJlbkFzTWFwKHJvdXRlKTtcbiAgICBmb3IgKGNvbnN0IHRyZWVOb2RlIG9mIE9iamVjdC52YWx1ZXMoY2hpbGRyZW4pKSB7XG4gICAgICB0aGlzLmRlYWN0aXZhdGVSb3V0ZUFuZEl0c0NoaWxkcmVuKHRyZWVOb2RlLCBjb250ZXh0cyk7XG4gICAgfVxuICAgIGlmIChjb250ZXh0KSB7XG4gICAgICBpZiAoY29udGV4dC5vdXRsZXQpIHtcbiAgICAgICAgY29udGV4dC5vdXRsZXQuZGVhY3RpdmF0ZSgpO1xuICAgICAgICBjb250ZXh0LmNoaWxkcmVuLm9uT3V0bGV0RGVhY3RpdmF0ZWQoKTtcbiAgICAgIH1cbiAgICAgIGNvbnRleHQuYXR0YWNoUmVmID0gbnVsbDtcbiAgICAgIGNvbnRleHQucm91dGUgPSBudWxsO1xuICAgIH1cbiAgICByb3V0ZS52YWx1ZS5fbG9jYWxJbmplY3Rvcj8uZGVzdHJveSgpO1xuICB9XG4gIGFjdGl2YXRlQ2hpbGRSb3V0ZXMoZnV0dXJlTm9kZSwgY3Vyck5vZGUsIGNvbnRleHRzKSB7XG4gICAgY29uc3QgY2hpbGRyZW4gPSBub2RlQ2hpbGRyZW5Bc01hcChjdXJyTm9kZSk7XG4gICAgZnV0dXJlTm9kZS5jaGlsZHJlbi5mb3JFYWNoKGMgPT4ge1xuICAgICAgdGhpcy5hY3RpdmF0ZVJvdXRlcyhjLCBjaGlsZHJlbltjLnZhbHVlLm91dGxldF0sIGNvbnRleHRzKTtcbiAgICAgIHRoaXMuZm9yd2FyZEV2ZW50KG5ldyBBY3RpdmF0aW9uRW5kKGMudmFsdWUuc25hcHNob3QpKTtcbiAgICB9KTtcbiAgICBpZiAoZnV0dXJlTm9kZS5jaGlsZHJlbi5sZW5ndGgpIHtcbiAgICAgIHRoaXMuZm9yd2FyZEV2ZW50KG5ldyBDaGlsZEFjdGl2YXRpb25FbmQoZnV0dXJlTm9kZS52YWx1ZS5zbmFwc2hvdCkpO1xuICAgIH1cbiAgfVxuICBhY3RpdmF0ZVJvdXRlcyhmdXR1cmVOb2RlLCBjdXJyTm9kZSwgcGFyZW50Q29udGV4dHMpIHtcbiAgICBjb25zdCBmdXR1cmUgPSBmdXR1cmVOb2RlLnZhbHVlO1xuICAgIGNvbnN0IGN1cnIgPSBjdXJyTm9kZSA/IGN1cnJOb2RlLnZhbHVlIDogbnVsbDtcbiAgICBhZHZhbmNlQWN0aXZhdGVkUm91dGUoZnV0dXJlKTtcbiAgICBpZiAoZnV0dXJlID09PSBjdXJyKSB7XG4gICAgICBpZiAoZnV0dXJlLmNvbXBvbmVudCkge1xuICAgICAgICBjb25zdCBjb250ZXh0ID0gcGFyZW50Q29udGV4dHMuZ2V0T3JDcmVhdGVDb250ZXh0KGZ1dHVyZS5vdXRsZXQpO1xuICAgICAgICB0aGlzLmFjdGl2YXRlQ2hpbGRSb3V0ZXMoZnV0dXJlTm9kZSwgY3Vyck5vZGUsIGNvbnRleHQuY2hpbGRyZW4pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5hY3RpdmF0ZUNoaWxkUm91dGVzKGZ1dHVyZU5vZGUsIGN1cnJOb2RlLCBwYXJlbnRDb250ZXh0cyk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChmdXR1cmUuY29tcG9uZW50KSB7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0cy5nZXRPckNyZWF0ZUNvbnRleHQoZnV0dXJlLm91dGxldCk7XG4gICAgICAgIGlmICh0aGlzLnJvdXRlUmV1c2VTdHJhdGVneS5zaG91bGRBdHRhY2goZnV0dXJlLnNuYXBzaG90KSkge1xuICAgICAgICAgIGNvbnN0IHN0b3JlZCA9IHRoaXMucm91dGVSZXVzZVN0cmF0ZWd5LnJldHJpZXZlKGZ1dHVyZS5zbmFwc2hvdCk7XG4gICAgICAgICAgdGhpcy5yb3V0ZVJldXNlU3RyYXRlZ3kuc3RvcmUoZnV0dXJlLnNuYXBzaG90LCBudWxsKTtcbiAgICAgICAgICBjb250ZXh0LmNoaWxkcmVuLm9uT3V0bGV0UmVBdHRhY2hlZChzdG9yZWQuY29udGV4dHMpO1xuICAgICAgICAgIGNvbnRleHQuYXR0YWNoUmVmID0gc3RvcmVkLmNvbXBvbmVudFJlZjtcbiAgICAgICAgICBjb250ZXh0LnJvdXRlID0gc3RvcmVkLnJvdXRlLnZhbHVlO1xuICAgICAgICAgIGlmIChjb250ZXh0Lm91dGxldCkge1xuICAgICAgICAgICAgY29udGV4dC5vdXRsZXQuYXR0YWNoKHN0b3JlZC5jb21wb25lbnRSZWYsIHN0b3JlZC5yb3V0ZS52YWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGFkdmFuY2VBY3RpdmF0ZWRSb3V0ZShzdG9yZWQucm91dGUudmFsdWUpO1xuICAgICAgICAgIHRoaXMuYWN0aXZhdGVDaGlsZFJvdXRlcyhmdXR1cmVOb2RlLCBudWxsLCBjb250ZXh0LmNoaWxkcmVuKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb250ZXh0LmF0dGFjaFJlZiA9IG51bGw7XG4gICAgICAgICAgY29udGV4dC5yb3V0ZSA9IGZ1dHVyZTtcbiAgICAgICAgICBpZiAoY29udGV4dC5vdXRsZXQpIHtcbiAgICAgICAgICAgIGNvbnRleHQub3V0bGV0LmFjdGl2YXRlV2l0aChmdXR1cmUsIGNvbnRleHQuaW5qZWN0b3IpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLmFjdGl2YXRlQ2hpbGRSb3V0ZXMoZnV0dXJlTm9kZSwgbnVsbCwgY29udGV4dC5jaGlsZHJlbik7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuYWN0aXZhdGVDaGlsZFJvdXRlcyhmdXR1cmVOb2RlLCBudWxsLCBwYXJlbnRDb250ZXh0cyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpIHtcbiAgICAgIGNvbnN0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0cy5nZXRPckNyZWF0ZUNvbnRleHQoZnV0dXJlLm91dGxldCk7XG4gICAgICBjb25zdCBvdXRsZXQgPSBjb250ZXh0Lm91dGxldDtcbiAgICAgIGlmIChvdXRsZXQgJiYgdGhpcy5pbnB1dEJpbmRpbmdFbmFibGVkICYmICFvdXRsZXQuc3VwcG9ydHNCaW5kaW5nVG9Db21wb25lbnRJbnB1dHMgJiYgIXdhcm5lZEFib3V0VW5zdXBwb3J0ZWRJbnB1dEJpbmRpbmcpIHtcbiAgICAgICAgY29uc29sZS53YXJuKGAnd2l0aENvbXBvbmVudElucHV0QmluZGluZycgZmVhdHVyZSBpcyBlbmFibGVkIGJ1dCBgICsgYHRoaXMgYXBwbGljYXRpb24gaXMgdXNpbmcgYW4gb3V0bGV0IHRoYXQgbWF5IG5vdCBzdXBwb3J0IGJpbmRpbmcgdG8gY29tcG9uZW50IGlucHV0cy5gKTtcbiAgICAgICAgd2FybmVkQWJvdXRVbnN1cHBvcnRlZElucHV0QmluZGluZyA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5jbGFzcyBDYW5BY3RpdmF0ZSB7XG4gIHBhdGg7XG4gIHJvdXRlO1xuICBjb25zdHJ1Y3RvcihwYXRoKSB7XG4gICAgdGhpcy5wYXRoID0gcGF0aDtcbiAgICB0aGlzLnJvdXRlID0gdGhpcy5wYXRoW3RoaXMucGF0aC5sZW5ndGggLSAxXTtcbiAgfVxufVxuY2xhc3MgQ2FuRGVhY3RpdmF0ZSB7XG4gIGNvbXBvbmVudDtcbiAgcm91dGU7XG4gIGNvbnN0cnVjdG9yKGNvbXBvbmVudCwgcm91dGUpIHtcbiAgICB0aGlzLmNvbXBvbmVudCA9IGNvbXBvbmVudDtcbiAgICB0aGlzLnJvdXRlID0gcm91dGU7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldEFsbFJvdXRlR3VhcmRzKGZ1dHVyZSwgY3VyciwgcGFyZW50Q29udGV4dHMpIHtcbiAgY29uc3QgZnV0dXJlUm9vdCA9IGZ1dHVyZS5fcm9vdDtcbiAgY29uc3QgY3VyclJvb3QgPSBjdXJyID8gY3Vyci5fcm9vdCA6IG51bGw7XG4gIHJldHVybiBnZXRDaGlsZFJvdXRlR3VhcmRzKGZ1dHVyZVJvb3QsIGN1cnJSb290LCBwYXJlbnRDb250ZXh0cywgW2Z1dHVyZVJvb3QudmFsdWVdKTtcbn1cbmZ1bmN0aW9uIGdldENhbkFjdGl2YXRlQ2hpbGQocCkge1xuICBjb25zdCBjYW5BY3RpdmF0ZUNoaWxkID0gcC5yb3V0ZUNvbmZpZyA/IHAucm91dGVDb25maWcuY2FuQWN0aXZhdGVDaGlsZCA6IG51bGw7XG4gIGlmICghY2FuQWN0aXZhdGVDaGlsZCB8fCBjYW5BY3RpdmF0ZUNoaWxkLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbm9kZTogcCxcbiAgICBndWFyZHM6IGNhbkFjdGl2YXRlQ2hpbGRcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldFRva2VuT3JGdW5jdGlvbklkZW50aXR5KHRva2VuT3JGdW5jdGlvbiwgaW5qZWN0b3IpIHtcbiAgY29uc3QgTk9UX0ZPVU5EID0gU3ltYm9sKCk7XG4gIGNvbnN0IHJlc3VsdCA9IGluamVjdG9yLmdldCh0b2tlbk9yRnVuY3Rpb24sIE5PVF9GT1VORCk7XG4gIGlmIChyZXN1bHQgPT09IE5PVF9GT1VORCkge1xuICAgIGlmICh0eXBlb2YgdG9rZW5PckZ1bmN0aW9uID09PSAnZnVuY3Rpb24nICYmICFfaXNJbmplY3RhYmxlKHRva2VuT3JGdW5jdGlvbikpIHtcbiAgICAgIHJldHVybiB0b2tlbk9yRnVuY3Rpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBpbmplY3Rvci5nZXQodG9rZW5PckZ1bmN0aW9uKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGdldENoaWxkUm91dGVHdWFyZHMoZnV0dXJlTm9kZSwgY3Vyck5vZGUsIGNvbnRleHRzLCBmdXR1cmVQYXRoLCBjaGVja3MgPSB7XG4gIGNhbkRlYWN0aXZhdGVDaGVja3M6IFtdLFxuICBjYW5BY3RpdmF0ZUNoZWNrczogW11cbn0pIHtcbiAgY29uc3QgcHJldkNoaWxkcmVuID0gbm9kZUNoaWxkcmVuQXNNYXAoY3Vyck5vZGUpO1xuICBmdXR1cmVOb2RlLmNoaWxkcmVuLmZvckVhY2goYyA9PiB7XG4gICAgZ2V0Um91dGVHdWFyZHMoYywgcHJldkNoaWxkcmVuW2MudmFsdWUub3V0bGV0XSwgY29udGV4dHMsIGZ1dHVyZVBhdGguY29uY2F0KFtjLnZhbHVlXSksIGNoZWNrcyk7XG4gICAgZGVsZXRlIHByZXZDaGlsZHJlbltjLnZhbHVlLm91dGxldF07XG4gIH0pO1xuICBPYmplY3QuZW50cmllcyhwcmV2Q2hpbGRyZW4pLmZvckVhY2goKFtrLCB2XSkgPT4gZGVhY3RpdmF0ZVJvdXRlQW5kSXRzQ2hpbGRyZW4odiwgY29udGV4dHMuZ2V0Q29udGV4dChrKSwgY2hlY2tzKSk7XG4gIHJldHVybiBjaGVja3M7XG59XG5mdW5jdGlvbiBnZXRSb3V0ZUd1YXJkcyhmdXR1cmVOb2RlLCBjdXJyTm9kZSwgcGFyZW50Q29udGV4dHMsIGZ1dHVyZVBhdGgsIGNoZWNrcyA9IHtcbiAgY2FuRGVhY3RpdmF0ZUNoZWNrczogW10sXG4gIGNhbkFjdGl2YXRlQ2hlY2tzOiBbXVxufSkge1xuICBjb25zdCBmdXR1cmUgPSBmdXR1cmVOb2RlLnZhbHVlO1xuICBjb25zdCBjdXJyID0gY3Vyck5vZGUgPyBjdXJyTm9kZS52YWx1ZSA6IG51bGw7XG4gIGNvbnN0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0cyA/IHBhcmVudENvbnRleHRzLmdldENvbnRleHQoZnV0dXJlTm9kZS52YWx1ZS5vdXRsZXQpIDogbnVsbDtcbiAgaWYgKGN1cnIgJiYgZnV0dXJlLnJvdXRlQ29uZmlnID09PSBjdXJyLnJvdXRlQ29uZmlnKSB7XG4gICAgY29uc3Qgc2hvdWxkUnVuID0gc2hvdWxkUnVuR3VhcmRzQW5kUmVzb2x2ZXJzKGN1cnIsIGZ1dHVyZSwgZnV0dXJlLnJvdXRlQ29uZmlnLnJ1bkd1YXJkc0FuZFJlc29sdmVycyk7XG4gICAgaWYgKHNob3VsZFJ1bikge1xuICAgICAgY2hlY2tzLmNhbkFjdGl2YXRlQ2hlY2tzLnB1c2gobmV3IENhbkFjdGl2YXRlKGZ1dHVyZVBhdGgpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZnV0dXJlLmRhdGEgPSBjdXJyLmRhdGE7XG4gICAgICBmdXR1cmUuX3Jlc29sdmVkRGF0YSA9IGN1cnIuX3Jlc29sdmVkRGF0YTtcbiAgICB9XG4gICAgaWYgKGZ1dHVyZS5jb21wb25lbnQpIHtcbiAgICAgIGdldENoaWxkUm91dGVHdWFyZHMoZnV0dXJlTm9kZSwgY3Vyck5vZGUsIGNvbnRleHQgPyBjb250ZXh0LmNoaWxkcmVuIDogbnVsbCwgZnV0dXJlUGF0aCwgY2hlY2tzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ2V0Q2hpbGRSb3V0ZUd1YXJkcyhmdXR1cmVOb2RlLCBjdXJyTm9kZSwgcGFyZW50Q29udGV4dHMsIGZ1dHVyZVBhdGgsIGNoZWNrcyk7XG4gICAgfVxuICAgIGlmIChzaG91bGRSdW4gJiYgY29udGV4dCAmJiBjb250ZXh0Lm91dGxldCAmJiBjb250ZXh0Lm91dGxldC5pc0FjdGl2YXRlZCkge1xuICAgICAgY2hlY2tzLmNhbkRlYWN0aXZhdGVDaGVja3MucHVzaChuZXcgQ2FuRGVhY3RpdmF0ZShjb250ZXh0Lm91dGxldC5jb21wb25lbnQsIGN1cnIpKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKGN1cnIpIHtcbiAgICAgIGRlYWN0aXZhdGVSb3V0ZUFuZEl0c0NoaWxkcmVuKGN1cnJOb2RlLCBjb250ZXh0LCBjaGVja3MpO1xuICAgIH1cbiAgICBjaGVja3MuY2FuQWN0aXZhdGVDaGVja3MucHVzaChuZXcgQ2FuQWN0aXZhdGUoZnV0dXJlUGF0aCkpO1xuICAgIGlmIChmdXR1cmUuY29tcG9uZW50KSB7XG4gICAgICBnZXRDaGlsZFJvdXRlR3VhcmRzKGZ1dHVyZU5vZGUsIG51bGwsIGNvbnRleHQgPyBjb250ZXh0LmNoaWxkcmVuIDogbnVsbCwgZnV0dXJlUGF0aCwgY2hlY2tzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ2V0Q2hpbGRSb3V0ZUd1YXJkcyhmdXR1cmVOb2RlLCBudWxsLCBwYXJlbnRDb250ZXh0cywgZnV0dXJlUGF0aCwgY2hlY2tzKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGNoZWNrcztcbn1cbmZ1bmN0aW9uIHNob3VsZFJ1bkd1YXJkc0FuZFJlc29sdmVycyhjdXJyLCBmdXR1cmUsIG1vZGUpIHtcbiAgaWYgKHR5cGVvZiBtb2RlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIHJ1bkluSW5qZWN0aW9uQ29udGV4dChmdXR1cmUuX2Vudmlyb25tZW50SW5qZWN0b3IsICgpID0+IG1vZGUoY3VyciwgZnV0dXJlKSk7XG4gIH1cbiAgc3dpdGNoIChtb2RlKSB7XG4gICAgY2FzZSAncGF0aFBhcmFtc0NoYW5nZSc6XG4gICAgICByZXR1cm4gIWVxdWFsUGF0aChjdXJyLnVybCwgZnV0dXJlLnVybCk7XG4gICAgY2FzZSAncGF0aFBhcmFtc09yUXVlcnlQYXJhbXNDaGFuZ2UnOlxuICAgICAgcmV0dXJuICFlcXVhbFBhdGgoY3Vyci51cmwsIGZ1dHVyZS51cmwpIHx8ICFzaGFsbG93RXF1YWwoY3Vyci5xdWVyeVBhcmFtcywgZnV0dXJlLnF1ZXJ5UGFyYW1zKTtcbiAgICBjYXNlICdhbHdheXMnOlxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgY2FzZSAncGFyYW1zT3JRdWVyeVBhcmFtc0NoYW5nZSc6XG4gICAgICByZXR1cm4gIWVxdWFsUGFyYW1zQW5kVXJsU2VnbWVudHMoY3VyciwgZnV0dXJlKSB8fCAhc2hhbGxvd0VxdWFsKGN1cnIucXVlcnlQYXJhbXMsIGZ1dHVyZS5xdWVyeVBhcmFtcyk7XG4gICAgY2FzZSAncGFyYW1zQ2hhbmdlJzpcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuICFlcXVhbFBhcmFtc0FuZFVybFNlZ21lbnRzKGN1cnIsIGZ1dHVyZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGRlYWN0aXZhdGVSb3V0ZUFuZEl0c0NoaWxkcmVuKHJvdXRlLCBjb250ZXh0LCBjaGVja3MpIHtcbiAgY29uc3QgY2hpbGRyZW4gPSBub2RlQ2hpbGRyZW5Bc01hcChyb3V0ZSk7XG4gIGNvbnN0IHIgPSByb3V0ZS52YWx1ZTtcbiAgT2JqZWN0LmVudHJpZXMoY2hpbGRyZW4pLmZvckVhY2goKFtjaGlsZE5hbWUsIG5vZGVdKSA9PiB7XG4gICAgaWYgKCFyLmNvbXBvbmVudCkge1xuICAgICAgZGVhY3RpdmF0ZVJvdXRlQW5kSXRzQ2hpbGRyZW4obm9kZSwgY29udGV4dCwgY2hlY2tzKTtcbiAgICB9IGVsc2UgaWYgKGNvbnRleHQpIHtcbiAgICAgIGRlYWN0aXZhdGVSb3V0ZUFuZEl0c0NoaWxkcmVuKG5vZGUsIGNvbnRleHQuY2hpbGRyZW4uZ2V0Q29udGV4dChjaGlsZE5hbWUpLCBjaGVja3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICBkZWFjdGl2YXRlUm91dGVBbmRJdHNDaGlsZHJlbihub2RlLCBudWxsLCBjaGVja3MpO1xuICAgIH1cbiAgfSk7XG4gIGlmICghci5jb21wb25lbnQpIHtcbiAgICBjaGVja3MuY2FuRGVhY3RpdmF0ZUNoZWNrcy5wdXNoKG5ldyBDYW5EZWFjdGl2YXRlKG51bGwsIHIpKTtcbiAgfSBlbHNlIGlmIChjb250ZXh0ICYmIGNvbnRleHQub3V0bGV0ICYmIGNvbnRleHQub3V0bGV0LmlzQWN0aXZhdGVkKSB7XG4gICAgY2hlY2tzLmNhbkRlYWN0aXZhdGVDaGVja3MucHVzaChuZXcgQ2FuRGVhY3RpdmF0ZShjb250ZXh0Lm91dGxldC5jb21wb25lbnQsIHIpKTtcbiAgfSBlbHNlIHtcbiAgICBjaGVja3MuY2FuRGVhY3RpdmF0ZUNoZWNrcy5wdXNoKG5ldyBDYW5EZWFjdGl2YXRlKG51bGwsIHIpKTtcbiAgfVxufVxuZnVuY3Rpb24gaXNGdW5jdGlvbih2KSB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Z1bmN0aW9uJztcbn1cbmZ1bmN0aW9uIGlzQm9vbGVhbih2KSB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nO1xufVxuZnVuY3Rpb24gaXNDYW5Mb2FkKGd1YXJkKSB7XG4gIHJldHVybiBndWFyZCAmJiBpc0Z1bmN0aW9uKGd1YXJkLmNhbkxvYWQpO1xufVxuZnVuY3Rpb24gaXNDYW5BY3RpdmF0ZShndWFyZCkge1xuICByZXR1cm4gZ3VhcmQgJiYgaXNGdW5jdGlvbihndWFyZC5jYW5BY3RpdmF0ZSk7XG59XG5mdW5jdGlvbiBpc0NhbkFjdGl2YXRlQ2hpbGQoZ3VhcmQpIHtcbiAgcmV0dXJuIGd1YXJkICYmIGlzRnVuY3Rpb24oZ3VhcmQuY2FuQWN0aXZhdGVDaGlsZCk7XG59XG5mdW5jdGlvbiBpc0NhbkRlYWN0aXZhdGUoZ3VhcmQpIHtcbiAgcmV0dXJuIGd1YXJkICYmIGlzRnVuY3Rpb24oZ3VhcmQuY2FuRGVhY3RpdmF0ZSk7XG59XG5mdW5jdGlvbiBpc0Nhbk1hdGNoKGd1YXJkKSB7XG4gIHJldHVybiBndWFyZCAmJiBpc0Z1bmN0aW9uKGd1YXJkLmNhbk1hdGNoKTtcbn1cbmZ1bmN0aW9uIGlzRW1wdHlFcnJvcihlKSB7XG4gIHJldHVybiBlIGluc3RhbmNlb2YgRW1wdHlFcnJvciB8fCBlPy5uYW1lID09PSAnRW1wdHlFcnJvcic7XG59XG5jb25zdCBJTklUSUFMX1ZBTFVFID0gLyogQF9fUFVSRV9fICovU3ltYm9sKCdJTklUSUFMX1ZBTFVFJyk7XG5mdW5jdGlvbiBwcmlvcml0aXplZEd1YXJkVmFsdWUoKSB7XG4gIHJldHVybiBzd2l0Y2hNYXAob2JzID0+IHtcbiAgICByZXR1cm4gY29tYmluZUxhdGVzdChvYnMubWFwKG8gPT4gby5waXBlKHRha2UoMSksIHN0YXJ0V2l0aChJTklUSUFMX1ZBTFVFKSkpKS5waXBlKG1hcChyZXN1bHRzID0+IHtcbiAgICAgIGZvciAoY29uc3QgcmVzdWx0IG9mIHJlc3VsdHMpIHtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gdHJ1ZSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9IGVsc2UgaWYgKHJlc3VsdCA9PT0gSU5JVElBTF9WQUxVRSkge1xuICAgICAgICAgIHJldHVybiBJTklUSUFMX1ZBTFVFO1xuICAgICAgICB9IGVsc2UgaWYgKHJlc3VsdCA9PT0gZmFsc2UgfHwgaXNSZWRpcmVjdChyZXN1bHQpKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSksIGZpbHRlcihpdGVtID0+IGl0ZW0gIT09IElOSVRJQUxfVkFMVUUpLCB0YWtlKDEpKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBpc1JlZGlyZWN0KHZhbCkge1xuICByZXR1cm4gaXNVcmxUcmVlKHZhbCkgfHwgdmFsIGluc3RhbmNlb2YgUmVkaXJlY3RDb21tYW5kO1xufVxuZnVuY3Rpb24gYWJvcnRTaWduYWxUb09ic2VydmFibGUoc2lnbmFsKSB7XG4gIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgIHJldHVybiBvZih1bmRlZmluZWQpLnBpcGUodGFrZSgxKSk7XG4gIH1cbiAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKHN1YnNjcmliZXIgPT4ge1xuICAgIGNvbnN0IGhhbmRsZXIgPSAoKSA9PiB7XG4gICAgICBzdWJzY3JpYmVyLm5leHQoKTtcbiAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICB9O1xuICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIGhhbmRsZXIpO1xuICAgIHJldHVybiAoKSA9PiBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBoYW5kbGVyKTtcbiAgfSk7XG59XG5mdW5jdGlvbiB0YWtlVW50aWxBYm9ydChzaWduYWwpIHtcbiAgcmV0dXJuIHRha2VVbnRpbChhYm9ydFNpZ25hbFRvT2JzZXJ2YWJsZShzaWduYWwpKTtcbn1cbmZ1bmN0aW9uIGNoZWNrR3VhcmRzKGZvcndhcmRFdmVudCkge1xuICByZXR1cm4gbWVyZ2VNYXAodCA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgdGFyZ2V0U25hcHNob3QsXG4gICAgICBjdXJyZW50U25hcHNob3QsXG4gICAgICBndWFyZHM6IHtcbiAgICAgICAgY2FuQWN0aXZhdGVDaGVja3MsXG4gICAgICAgIGNhbkRlYWN0aXZhdGVDaGVja3NcbiAgICAgIH1cbiAgICB9ID0gdDtcbiAgICBpZiAoY2FuRGVhY3RpdmF0ZUNoZWNrcy5sZW5ndGggPT09IDAgJiYgY2FuQWN0aXZhdGVDaGVja3MubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gb2Yoe1xuICAgICAgICAuLi50LFxuICAgICAgICBndWFyZHNSZXN1bHQ6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcnVuQ2FuRGVhY3RpdmF0ZUNoZWNrcyhjYW5EZWFjdGl2YXRlQ2hlY2tzLCB0YXJnZXRTbmFwc2hvdCwgY3VycmVudFNuYXBzaG90KS5waXBlKG1lcmdlTWFwKGNhbkRlYWN0aXZhdGUgPT4ge1xuICAgICAgcmV0dXJuIGNhbkRlYWN0aXZhdGUgJiYgaXNCb29sZWFuKGNhbkRlYWN0aXZhdGUpID8gcnVuQ2FuQWN0aXZhdGVDaGVja3ModGFyZ2V0U25hcHNob3QsIGNhbkFjdGl2YXRlQ2hlY2tzLCBmb3J3YXJkRXZlbnQpIDogb2YoY2FuRGVhY3RpdmF0ZSk7XG4gICAgfSksIG1hcChndWFyZHNSZXN1bHQgPT4gKHtcbiAgICAgIC4uLnQsXG4gICAgICBndWFyZHNSZXN1bHRcbiAgICB9KSkpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHJ1bkNhbkRlYWN0aXZhdGVDaGVja3MoY2hlY2tzLCBmdXR1cmVSU1MsIGN1cnJSU1MpIHtcbiAgcmV0dXJuIGZyb20oY2hlY2tzKS5waXBlKG1lcmdlTWFwKGNoZWNrID0+IHJ1bkNhbkRlYWN0aXZhdGUoY2hlY2suY29tcG9uZW50LCBjaGVjay5yb3V0ZSwgY3VyclJTUywgZnV0dXJlUlNTKSksIGZpcnN0KHJlc3VsdCA9PiB7XG4gICAgcmV0dXJuIHJlc3VsdCAhPT0gdHJ1ZTtcbiAgfSwgdHJ1ZSkpO1xufVxuZnVuY3Rpb24gcnVuQ2FuQWN0aXZhdGVDaGVja3MoZnV0dXJlU25hcHNob3QsIGNoZWNrcywgZm9yd2FyZEV2ZW50KSB7XG4gIHJldHVybiBmcm9tKGNoZWNrcykucGlwZShjb25jYXRNYXAoY2hlY2sgPT4ge1xuICAgIHJldHVybiBjb25jYXQoZmlyZUNoaWxkQWN0aXZhdGlvblN0YXJ0KGNoZWNrLnJvdXRlLnBhcmVudCwgZm9yd2FyZEV2ZW50KSwgZmlyZUFjdGl2YXRpb25TdGFydChjaGVjay5yb3V0ZSwgZm9yd2FyZEV2ZW50KSwgcnVuQ2FuQWN0aXZhdGVDaGlsZChmdXR1cmVTbmFwc2hvdCwgY2hlY2sucGF0aCksIHJ1bkNhbkFjdGl2YXRlKGZ1dHVyZVNuYXBzaG90LCBjaGVjay5yb3V0ZSkpO1xuICB9KSwgZmlyc3QocmVzdWx0ID0+IHtcbiAgICByZXR1cm4gcmVzdWx0ICE9PSB0cnVlO1xuICB9LCB0cnVlKSk7XG59XG5mdW5jdGlvbiBmaXJlQWN0aXZhdGlvblN0YXJ0KHNuYXBzaG90LCBmb3J3YXJkRXZlbnQpIHtcbiAgaWYgKHNuYXBzaG90ICE9PSBudWxsICYmIGZvcndhcmRFdmVudCkge1xuICAgIGZvcndhcmRFdmVudChuZXcgQWN0aXZhdGlvblN0YXJ0KHNuYXBzaG90KSk7XG4gIH1cbiAgcmV0dXJuIG9mKHRydWUpO1xufVxuZnVuY3Rpb24gZmlyZUNoaWxkQWN0aXZhdGlvblN0YXJ0KHNuYXBzaG90LCBmb3J3YXJkRXZlbnQpIHtcbiAgaWYgKHNuYXBzaG90ICE9PSBudWxsICYmIGZvcndhcmRFdmVudCkge1xuICAgIGZvcndhcmRFdmVudChuZXcgQ2hpbGRBY3RpdmF0aW9uU3RhcnQoc25hcHNob3QpKTtcbiAgfVxuICByZXR1cm4gb2YodHJ1ZSk7XG59XG5mdW5jdGlvbiBydW5DYW5BY3RpdmF0ZShmdXR1cmVSU1MsIGZ1dHVyZUFSUykge1xuICBjb25zdCBjYW5BY3RpdmF0ZSA9IGZ1dHVyZUFSUy5yb3V0ZUNvbmZpZyA/IGZ1dHVyZUFSUy5yb3V0ZUNvbmZpZy5jYW5BY3RpdmF0ZSA6IG51bGw7XG4gIGlmICghY2FuQWN0aXZhdGUgfHwgY2FuQWN0aXZhdGUubGVuZ3RoID09PSAwKSByZXR1cm4gb2YodHJ1ZSk7XG4gIGNvbnN0IGNhbkFjdGl2YXRlT2JzZXJ2YWJsZXMgPSBjYW5BY3RpdmF0ZS5tYXAoY2FuQWN0aXZhdGUgPT4ge1xuICAgIHJldHVybiBkZWZlcigoKSA9PiB7XG4gICAgICBjb25zdCBjbG9zZXN0SW5qZWN0b3IgPSBmdXR1cmVBUlMuX2Vudmlyb25tZW50SW5qZWN0b3I7XG4gICAgICBjb25zdCBndWFyZCA9IGdldFRva2VuT3JGdW5jdGlvbklkZW50aXR5KGNhbkFjdGl2YXRlLCBjbG9zZXN0SW5qZWN0b3IpO1xuICAgICAgY29uc3QgZ3VhcmRWYWwgPSBpc0NhbkFjdGl2YXRlKGd1YXJkKSA/IGd1YXJkLmNhbkFjdGl2YXRlKGZ1dHVyZUFSUywgZnV0dXJlUlNTKSA6IHJ1bkluSW5qZWN0aW9uQ29udGV4dChjbG9zZXN0SW5qZWN0b3IsICgpID0+IGd1YXJkKGZ1dHVyZUFSUywgZnV0dXJlUlNTKSk7XG4gICAgICByZXR1cm4gd3JhcEludG9PYnNlcnZhYmxlKGd1YXJkVmFsKS5waXBlKGZpcnN0KCkpO1xuICAgIH0pO1xuICB9KTtcbiAgcmV0dXJuIG9mKGNhbkFjdGl2YXRlT2JzZXJ2YWJsZXMpLnBpcGUocHJpb3JpdGl6ZWRHdWFyZFZhbHVlKCkpO1xufVxuZnVuY3Rpb24gcnVuQ2FuQWN0aXZhdGVDaGlsZChmdXR1cmVSU1MsIHBhdGgpIHtcbiAgY29uc3QgZnV0dXJlQVJTID0gcGF0aFtwYXRoLmxlbmd0aCAtIDFdO1xuICBjb25zdCBjYW5BY3RpdmF0ZUNoaWxkR3VhcmRzID0gcGF0aC5zbGljZSgwLCBwYXRoLmxlbmd0aCAtIDEpLnJldmVyc2UoKS5tYXAocCA9PiBnZXRDYW5BY3RpdmF0ZUNoaWxkKHApKS5maWx0ZXIoXyA9PiBfICE9PSBudWxsKTtcbiAgY29uc3QgY2FuQWN0aXZhdGVDaGlsZEd1YXJkc01hcHBlZCA9IGNhbkFjdGl2YXRlQ2hpbGRHdWFyZHMubWFwKGQgPT4ge1xuICAgIHJldHVybiBkZWZlcigoKSA9PiB7XG4gICAgICBjb25zdCBndWFyZHNNYXBwZWQgPSBkLmd1YXJkcy5tYXAoY2FuQWN0aXZhdGVDaGlsZCA9PiB7XG4gICAgICAgIGNvbnN0IGNsb3Nlc3RJbmplY3RvciA9IGQubm9kZS5fZW52aXJvbm1lbnRJbmplY3RvcjtcbiAgICAgICAgY29uc3QgZ3VhcmQgPSBnZXRUb2tlbk9yRnVuY3Rpb25JZGVudGl0eShjYW5BY3RpdmF0ZUNoaWxkLCBjbG9zZXN0SW5qZWN0b3IpO1xuICAgICAgICBjb25zdCBndWFyZFZhbCA9IGlzQ2FuQWN0aXZhdGVDaGlsZChndWFyZCkgPyBndWFyZC5jYW5BY3RpdmF0ZUNoaWxkKGZ1dHVyZUFSUywgZnV0dXJlUlNTKSA6IHJ1bkluSW5qZWN0aW9uQ29udGV4dChjbG9zZXN0SW5qZWN0b3IsICgpID0+IGd1YXJkKGZ1dHVyZUFSUywgZnV0dXJlUlNTKSk7XG4gICAgICAgIHJldHVybiB3cmFwSW50b09ic2VydmFibGUoZ3VhcmRWYWwpLnBpcGUoZmlyc3QoKSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBvZihndWFyZHNNYXBwZWQpLnBpcGUocHJpb3JpdGl6ZWRHdWFyZFZhbHVlKCkpO1xuICAgIH0pO1xuICB9KTtcbiAgcmV0dXJuIG9mKGNhbkFjdGl2YXRlQ2hpbGRHdWFyZHNNYXBwZWQpLnBpcGUocHJpb3JpdGl6ZWRHdWFyZFZhbHVlKCkpO1xufVxuZnVuY3Rpb24gcnVuQ2FuRGVhY3RpdmF0ZShjb21wb25lbnQsIGN1cnJBUlMsIGN1cnJSU1MsIGZ1dHVyZVJTUykge1xuICBjb25zdCBjYW5EZWFjdGl2YXRlID0gY3VyckFSUyAmJiBjdXJyQVJTLnJvdXRlQ29uZmlnID8gY3VyckFSUy5yb3V0ZUNvbmZpZy5jYW5EZWFjdGl2YXRlIDogbnVsbDtcbiAgaWYgKCFjYW5EZWFjdGl2YXRlIHx8IGNhbkRlYWN0aXZhdGUubGVuZ3RoID09PSAwKSByZXR1cm4gb2YodHJ1ZSk7XG4gIGNvbnN0IGNhbkRlYWN0aXZhdGVPYnNlcnZhYmxlcyA9IGNhbkRlYWN0aXZhdGUubWFwKGMgPT4ge1xuICAgIGNvbnN0IGNsb3Nlc3RJbmplY3RvciA9IGN1cnJBUlMuX2Vudmlyb25tZW50SW5qZWN0b3I7XG4gICAgY29uc3QgZ3VhcmQgPSBnZXRUb2tlbk9yRnVuY3Rpb25JZGVudGl0eShjLCBjbG9zZXN0SW5qZWN0b3IpO1xuICAgIGNvbnN0IGd1YXJkVmFsID0gaXNDYW5EZWFjdGl2YXRlKGd1YXJkKSA/IGd1YXJkLmNhbkRlYWN0aXZhdGUoY29tcG9uZW50LCBjdXJyQVJTLCBjdXJyUlNTLCBmdXR1cmVSU1MpIDogcnVuSW5JbmplY3Rpb25Db250ZXh0KGNsb3Nlc3RJbmplY3RvciwgKCkgPT4gZ3VhcmQoY29tcG9uZW50LCBjdXJyQVJTLCBjdXJyUlNTLCBmdXR1cmVSU1MpKTtcbiAgICByZXR1cm4gd3JhcEludG9PYnNlcnZhYmxlKGd1YXJkVmFsKS5waXBlKGZpcnN0KCkpO1xuICB9KTtcbiAgcmV0dXJuIG9mKGNhbkRlYWN0aXZhdGVPYnNlcnZhYmxlcykucGlwZShwcmlvcml0aXplZEd1YXJkVmFsdWUoKSk7XG59XG5mdW5jdGlvbiBydW5DYW5Mb2FkR3VhcmRzKGluamVjdG9yLCByb3V0ZSwgc2VnbWVudHMsIHVybFNlcmlhbGl6ZXIsIGFib3J0U2lnbmFsKSB7XG4gIGNvbnN0IGNhbkxvYWQgPSByb3V0ZS5jYW5Mb2FkO1xuICBpZiAoY2FuTG9hZCA9PT0gdW5kZWZpbmVkIHx8IGNhbkxvYWQubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIG9mKHRydWUpO1xuICB9XG4gIGNvbnN0IGNhbkxvYWRPYnNlcnZhYmxlcyA9IGNhbkxvYWQubWFwKGluamVjdGlvblRva2VuID0+IHtcbiAgICBjb25zdCBndWFyZCA9IGdldFRva2VuT3JGdW5jdGlvbklkZW50aXR5KGluamVjdGlvblRva2VuLCBpbmplY3Rvcik7XG4gICAgY29uc3QgZ3VhcmRWYWwgPSBpc0NhbkxvYWQoZ3VhcmQpID8gZ3VhcmQuY2FuTG9hZChyb3V0ZSwgc2VnbWVudHMpIDogcnVuSW5JbmplY3Rpb25Db250ZXh0KGluamVjdG9yLCAoKSA9PiBndWFyZChyb3V0ZSwgc2VnbWVudHMpKTtcbiAgICBjb25zdCBvYnMkID0gd3JhcEludG9PYnNlcnZhYmxlKGd1YXJkVmFsKTtcbiAgICByZXR1cm4gYWJvcnRTaWduYWwgPyBvYnMkLnBpcGUodGFrZVVudGlsQWJvcnQoYWJvcnRTaWduYWwpKSA6IG9icyQ7XG4gIH0pO1xuICByZXR1cm4gb2YoY2FuTG9hZE9ic2VydmFibGVzKS5waXBlKHByaW9yaXRpemVkR3VhcmRWYWx1ZSgpLCByZWRpcmVjdElmVXJsVHJlZSh1cmxTZXJpYWxpemVyKSk7XG59XG5mdW5jdGlvbiByZWRpcmVjdElmVXJsVHJlZSh1cmxTZXJpYWxpemVyKSB7XG4gIHJldHVybiBwaXBlKHRhcChyZXN1bHQgPT4ge1xuICAgIGlmICh0eXBlb2YgcmVzdWx0ID09PSAnYm9vbGVhbicpIHJldHVybjtcbiAgICB0aHJvdyByZWRpcmVjdGluZ05hdmlnYXRpb25FcnJvcih1cmxTZXJpYWxpemVyLCByZXN1bHQpO1xuICB9KSwgbWFwKHJlc3VsdCA9PiByZXN1bHQgPT09IHRydWUpKTtcbn1cbmZ1bmN0aW9uIHJ1bkNhbk1hdGNoR3VhcmRzKGluamVjdG9yLCByb3V0ZSwgc2VnbWVudHMsIHVybFNlcmlhbGl6ZXIsIGN1cnJlbnRTbmFwc2hvdCwgYWJvcnRTaWduYWwpIHtcbiAgY29uc3QgY2FuTWF0Y2ggPSByb3V0ZS5jYW5NYXRjaDtcbiAgaWYgKCFjYW5NYXRjaCB8fCBjYW5NYXRjaC5sZW5ndGggPT09IDApIHJldHVybiBvZih0cnVlKTtcbiAgY29uc3QgY2FuTWF0Y2hPYnNlcnZhYmxlcyA9IGNhbk1hdGNoLm1hcChpbmplY3Rpb25Ub2tlbiA9PiB7XG4gICAgY29uc3QgZ3VhcmQgPSBnZXRUb2tlbk9yRnVuY3Rpb25JZGVudGl0eShpbmplY3Rpb25Ub2tlbiwgaW5qZWN0b3IpO1xuICAgIGNvbnN0IGd1YXJkVmFsID0gaXNDYW5NYXRjaChndWFyZCkgPyBndWFyZC5jYW5NYXRjaChyb3V0ZSwgc2VnbWVudHMsIGN1cnJlbnRTbmFwc2hvdCkgOiBydW5JbkluamVjdGlvbkNvbnRleHQoaW5qZWN0b3IsICgpID0+IGd1YXJkKHJvdXRlLCBzZWdtZW50cywgY3VycmVudFNuYXBzaG90KSk7XG4gICAgcmV0dXJuIHdyYXBJbnRvT2JzZXJ2YWJsZShndWFyZFZhbCkucGlwZSh0YWtlVW50aWxBYm9ydChhYm9ydFNpZ25hbCkpO1xuICB9KTtcbiAgcmV0dXJuIG9mKGNhbk1hdGNoT2JzZXJ2YWJsZXMpLnBpcGUocHJpb3JpdGl6ZWRHdWFyZFZhbHVlKCksIHJlZGlyZWN0SWZVcmxUcmVlKHVybFNlcmlhbGl6ZXIpKTtcbn1cbmNsYXNzIE5vTWF0Y2ggZXh0ZW5kcyBFcnJvciB7XG4gIHNlZ21lbnRHcm91cDtcbiAgY29uc3RydWN0b3Ioc2VnbWVudEdyb3VwKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLnNlZ21lbnRHcm91cCA9IHNlZ21lbnRHcm91cCB8fCBudWxsO1xuICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZih0aGlzLCBOb01hdGNoLnByb3RvdHlwZSk7XG4gIH1cbn1cbmNsYXNzIEFic29sdXRlUmVkaXJlY3QgZXh0ZW5kcyBFcnJvciB7XG4gIHVybFRyZWU7XG4gIGNvbnN0cnVjdG9yKHVybFRyZWUpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMudXJsVHJlZSA9IHVybFRyZWU7XG4gICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKHRoaXMsIEFic29sdXRlUmVkaXJlY3QucHJvdG90eXBlKTtcbiAgfVxufVxuZnVuY3Rpb24gbmFtZWRPdXRsZXRzUmVkaXJlY3QocmVkaXJlY3RUbykge1xuICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDAwLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBgT25seSBhYnNvbHV0ZSByZWRpcmVjdHMgY2FuIGhhdmUgbmFtZWQgb3V0bGV0cy4gcmVkaXJlY3RUbzogJyR7cmVkaXJlY3RUb30nYCk7XG59XG5mdW5jdGlvbiBjYW5Mb2FkRmFpbHMocm91dGUpIHtcbiAgdGhyb3cgbmF2aWdhdGlvbkNhbmNlbGluZ0Vycm9yKCh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGBDYW5ub3QgbG9hZCBjaGlsZHJlbiBiZWNhdXNlIHRoZSBndWFyZCBvZiB0aGUgcm91dGUgXCJwYXRoOiAnJHtyb3V0ZS5wYXRofSdcIiByZXR1cm5lZCBmYWxzZWAsIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLkd1YXJkUmVqZWN0ZWQpO1xufVxuY2xhc3MgQXBwbHlSZWRpcmVjdHMge1xuICB1cmxTZXJpYWxpemVyO1xuICB1cmxUcmVlO1xuICBjb25zdHJ1Y3Rvcih1cmxTZXJpYWxpemVyLCB1cmxUcmVlKSB7XG4gICAgdGhpcy51cmxTZXJpYWxpemVyID0gdXJsU2VyaWFsaXplcjtcbiAgICB0aGlzLnVybFRyZWUgPSB1cmxUcmVlO1xuICB9XG4gIGFzeW5jIGxpbmVyYWxpemVTZWdtZW50cyhyb3V0ZSwgdXJsVHJlZSkge1xuICAgIGxldCByZXMgPSBbXTtcbiAgICBsZXQgYyA9IHVybFRyZWUucm9vdDtcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgcmVzID0gcmVzLmNvbmNhdChjLnNlZ21lbnRzKTtcbiAgICAgIGlmIChjLm51bWJlck9mQ2hpbGRyZW4gPT09IDApIHtcbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgIH1cbiAgICAgIGlmIChjLm51bWJlck9mQ2hpbGRyZW4gPiAxIHx8ICFjLmNoaWxkcmVuW1BSSU1BUllfT1VUTEVUXSkge1xuICAgICAgICB0aHJvdyBuYW1lZE91dGxldHNSZWRpcmVjdChgJHtyb3V0ZS5yZWRpcmVjdFRvfWApO1xuICAgICAgfVxuICAgICAgYyA9IGMuY2hpbGRyZW5bUFJJTUFSWV9PVVRMRVRdO1xuICAgIH1cbiAgfVxuICBhc3luYyBhcHBseVJlZGlyZWN0Q29tbWFuZHMoc2VnbWVudHMsIHJlZGlyZWN0VG8sIHBvc1BhcmFtcywgY3VycmVudFNuYXBzaG90LCBpbmplY3Rvcikge1xuICAgIGNvbnN0IHJlZGlyZWN0ID0gYXdhaXQgZ2V0UmVkaXJlY3RSZXN1bHQocmVkaXJlY3RUbywgY3VycmVudFNuYXBzaG90LCBpbmplY3Rvcik7XG4gICAgaWYgKHJlZGlyZWN0IGluc3RhbmNlb2YgVXJsVHJlZSkge1xuICAgICAgdGhyb3cgbmV3IEFic29sdXRlUmVkaXJlY3QocmVkaXJlY3QpO1xuICAgIH1cbiAgICBjb25zdCBuZXdUcmVlID0gdGhpcy5hcHBseVJlZGlyZWN0Q3JlYXRlVXJsVHJlZShyZWRpcmVjdCwgdGhpcy51cmxTZXJpYWxpemVyLnBhcnNlKHJlZGlyZWN0KSwgc2VnbWVudHMsIHBvc1BhcmFtcyk7XG4gICAgaWYgKHJlZGlyZWN0WzBdID09PSAnLycpIHtcbiAgICAgIHRocm93IG5ldyBBYnNvbHV0ZVJlZGlyZWN0KG5ld1RyZWUpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3VHJlZTtcbiAgfVxuICBhcHBseVJlZGlyZWN0Q3JlYXRlVXJsVHJlZShyZWRpcmVjdFRvLCB1cmxUcmVlLCBzZWdtZW50cywgcG9zUGFyYW1zKSB7XG4gICAgY29uc3QgbmV3Um9vdCA9IHRoaXMuY3JlYXRlU2VnbWVudEdyb3VwKHJlZGlyZWN0VG8sIHVybFRyZWUucm9vdCwgc2VnbWVudHMsIHBvc1BhcmFtcyk7XG4gICAgcmV0dXJuIG5ldyBVcmxUcmVlKG5ld1Jvb3QsIHRoaXMuY3JlYXRlUXVlcnlQYXJhbXModXJsVHJlZS5xdWVyeVBhcmFtcywgdGhpcy51cmxUcmVlLnF1ZXJ5UGFyYW1zKSwgdXJsVHJlZS5mcmFnbWVudCk7XG4gIH1cbiAgY3JlYXRlUXVlcnlQYXJhbXMocmVkaXJlY3RUb1BhcmFtcywgYWN0dWFsUGFyYW1zKSB7XG4gICAgY29uc3QgcmVzID0ge307XG4gICAgT2JqZWN0LmVudHJpZXMocmVkaXJlY3RUb1BhcmFtcykuZm9yRWFjaCgoW2ssIHZdKSA9PiB7XG4gICAgICBjb25zdCBjb3B5U291cmNlVmFsdWUgPSB0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdlswXSA9PT0gJzonO1xuICAgICAgaWYgKGNvcHlTb3VyY2VWYWx1ZSkge1xuICAgICAgICBjb25zdCBzb3VyY2VOYW1lID0gdi5zdWJzdHJpbmcoMSk7XG4gICAgICAgIHJlc1trXSA9IGFjdHVhbFBhcmFtc1tzb3VyY2VOYW1lXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc1trXSA9IHY7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuICBjcmVhdGVTZWdtZW50R3JvdXAocmVkaXJlY3RUbywgZ3JvdXAsIHNlZ21lbnRzLCBwb3NQYXJhbXMpIHtcbiAgICBjb25zdCB1cGRhdGVkU2VnbWVudHMgPSB0aGlzLmNyZWF0ZVNlZ21lbnRzKHJlZGlyZWN0VG8sIGdyb3VwLnNlZ21lbnRzLCBzZWdtZW50cywgcG9zUGFyYW1zKTtcbiAgICBsZXQgY2hpbGRyZW4gPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIE9iamVjdC5lbnRyaWVzKGdyb3VwLmNoaWxkcmVuKS5mb3JFYWNoKChbbmFtZSwgY2hpbGRdKSA9PiB7XG4gICAgICBjaGlsZHJlbltuYW1lXSA9IHRoaXMuY3JlYXRlU2VnbWVudEdyb3VwKHJlZGlyZWN0VG8sIGNoaWxkLCBzZWdtZW50cywgcG9zUGFyYW1zKTtcbiAgICB9KTtcbiAgICByZXR1cm4gbmV3IFVybFNlZ21lbnRHcm91cCh1cGRhdGVkU2VnbWVudHMsIGNoaWxkcmVuKTtcbiAgfVxuICBjcmVhdGVTZWdtZW50cyhyZWRpcmVjdFRvLCByZWRpcmVjdFRvU2VnbWVudHMsIGFjdHVhbFNlZ21lbnRzLCBwb3NQYXJhbXMpIHtcbiAgICByZXR1cm4gcmVkaXJlY3RUb1NlZ21lbnRzLm1hcChzID0+IHMucGF0aFswXSA9PT0gJzonID8gdGhpcy5maW5kUG9zUGFyYW0ocmVkaXJlY3RUbywgcywgcG9zUGFyYW1zKSA6IHRoaXMuZmluZE9yUmV0dXJuKHMsIGFjdHVhbFNlZ21lbnRzKSk7XG4gIH1cbiAgZmluZFBvc1BhcmFtKHJlZGlyZWN0VG8sIHJlZGlyZWN0VG9VcmxTZWdtZW50LCBwb3NQYXJhbXMpIHtcbiAgICBjb25zdCBwb3MgPSBwb3NQYXJhbXNbcmVkaXJlY3RUb1VybFNlZ21lbnQucGF0aC5zdWJzdHJpbmcoMSldO1xuICAgIGlmICghcG9zKSB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDAxLCAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiBgQ2Fubm90IHJlZGlyZWN0IHRvICcke3JlZGlyZWN0VG99Jy4gQ2Fubm90IGZpbmQgJyR7cmVkaXJlY3RUb1VybFNlZ21lbnQucGF0aH0nLmApO1xuICAgIHJldHVybiBwb3M7XG4gIH1cbiAgZmluZE9yUmV0dXJuKHJlZGlyZWN0VG9VcmxTZWdtZW50LCBhY3R1YWxTZWdtZW50cykge1xuICAgIGxldCBpZHggPSAwO1xuICAgIGZvciAoY29uc3QgcyBvZiBhY3R1YWxTZWdtZW50cykge1xuICAgICAgaWYgKHMucGF0aCA9PT0gcmVkaXJlY3RUb1VybFNlZ21lbnQucGF0aCkge1xuICAgICAgICBhY3R1YWxTZWdtZW50cy5zcGxpY2UoaWR4KTtcbiAgICAgICAgcmV0dXJuIHM7XG4gICAgICB9XG4gICAgICBpZHgrKztcbiAgICB9XG4gICAgcmV0dXJuIHJlZGlyZWN0VG9VcmxTZWdtZW50O1xuICB9XG59XG5mdW5jdGlvbiBnZXRSZWRpcmVjdFJlc3VsdChyZWRpcmVjdFRvLCBjdXJyZW50U25hcHNob3QsIGluamVjdG9yKSB7XG4gIGlmICh0eXBlb2YgcmVkaXJlY3RUbyA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHJlZGlyZWN0VG8pO1xuICB9XG4gIGNvbnN0IHJlZGlyZWN0VG9GbiA9IHJlZGlyZWN0VG87XG4gIHJldHVybiBmaXJzdFZhbHVlRnJvbSh3cmFwSW50b09ic2VydmFibGUocnVuSW5JbmplY3Rpb25Db250ZXh0KGluamVjdG9yLCAoKSA9PiByZWRpcmVjdFRvRm4oY3VycmVudFNuYXBzaG90KSkpKTtcbn1cbmZ1bmN0aW9uIGdldE9yQ3JlYXRlUm91dGVJbmplY3RvcklmTmVlZGVkKHJvdXRlLCBjdXJyZW50SW5qZWN0b3IpIHtcbiAgaWYgKHJvdXRlLnByb3ZpZGVycyAmJiAhcm91dGUuX2luamVjdG9yKSB7XG4gICAgcm91dGUuX2luamVjdG9yID0gY3JlYXRlRW52aXJvbm1lbnRJbmplY3Rvcihyb3V0ZS5wcm92aWRlcnMsIGN1cnJlbnRJbmplY3RvciwgYFJvdXRlOiAke3JvdXRlLnBhdGh9YCk7XG4gIH1cbiAgcmV0dXJuIHJvdXRlLl9pbmplY3RvciA/PyBjdXJyZW50SW5qZWN0b3I7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZUNvbmZpZyhjb25maWcsIHBhcmVudFBhdGggPSAnJywgcmVxdWlyZVN0YW5kYWxvbmVDb21wb25lbnRzID0gZmFsc2UpIHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb25maWcubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCByb3V0ZSA9IGNvbmZpZ1tpXTtcbiAgICBjb25zdCBmdWxsUGF0aCA9IGdldEZ1bGxQYXRoKHBhcmVudFBhdGgsIHJvdXRlKTtcbiAgICB2YWxpZGF0ZU5vZGUocm91dGUsIGZ1bGxQYXRoLCByZXF1aXJlU3RhbmRhbG9uZUNvbXBvbmVudHMpO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRTdGFuZGFsb25lKGZ1bGxQYXRoLCBjb21wb25lbnQpIHtcbiAgaWYgKGNvbXBvbmVudCAmJiBfaXNOZ01vZHVsZShjb21wb25lbnQpKSB7XG4gICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxNCwgYEludmFsaWQgY29uZmlndXJhdGlvbiBvZiByb3V0ZSAnJHtmdWxsUGF0aH0nLiBZb3UgYXJlIHVzaW5nICdsb2FkQ29tcG9uZW50JyB3aXRoIGEgbW9kdWxlLCBgICsgYGJ1dCBpdCBtdXN0IGJlIHVzZWQgd2l0aCBzdGFuZGFsb25lIGNvbXBvbmVudHMuIFVzZSAnbG9hZENoaWxkcmVuJyBpbnN0ZWFkLmApO1xuICB9IGVsc2UgaWYgKGNvbXBvbmVudCAmJiAhaXNTdGFuZGFsb25lKGNvbXBvbmVudCkpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDE0LCBgSW52YWxpZCBjb25maWd1cmF0aW9uIG9mIHJvdXRlICcke2Z1bGxQYXRofScuIFRoZSBjb21wb25lbnQgbXVzdCBiZSBzdGFuZGFsb25lLmApO1xuICB9XG59XG5mdW5jdGlvbiB2YWxpZGF0ZU5vZGUocm91dGUsIGZ1bGxQYXRoLCByZXF1aXJlU3RhbmRhbG9uZUNvbXBvbmVudHMpIHtcbiAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgIGlmICghcm91dGUpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBcbiAgICAgIEludmFsaWQgY29uZmlndXJhdGlvbiBvZiByb3V0ZSAnJHtmdWxsUGF0aH0nOiBFbmNvdW50ZXJlZCB1bmRlZmluZWQgcm91dGUuXG4gICAgICBUaGUgcmVhc29uIG1pZ2h0IGJlIGFuIGV4dHJhIGNvbW1hLlxuXG4gICAgICBFeGFtcGxlOlxuICAgICAgY29uc3Qgcm91dGVzOiBSb3V0ZXMgPSBbXG4gICAgICAgIHsgcGF0aDogJycsIHJlZGlyZWN0VG86ICcvZGFzaGJvYXJkJywgcGF0aE1hdGNoOiAnZnVsbCcgfSxcbiAgICAgICAgeyBwYXRoOiAnZGFzaGJvYXJkJywgIGNvbXBvbmVudDogRGFzaGJvYXJkQ29tcG9uZW50IH0sLCA8PCB0d28gY29tbWFzXG4gICAgICAgIHsgcGF0aDogJ2RldGFpbC86aWQnLCBjb21wb25lbnQ6IEhlcm9EZXRhaWxDb21wb25lbnQgfVxuICAgICAgXTtcbiAgICBgKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocm91dGUpKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDE0LCBgSW52YWxpZCBjb25maWd1cmF0aW9uIG9mIHJvdXRlICcke2Z1bGxQYXRofSc6IEFycmF5IGNhbm5vdCBiZSBzcGVjaWZpZWRgKTtcbiAgICB9XG4gICAgaWYgKCFyb3V0ZS5yZWRpcmVjdFRvICYmICFyb3V0ZS5jb21wb25lbnQgJiYgIXJvdXRlLmxvYWRDb21wb25lbnQgJiYgIXJvdXRlLmNoaWxkcmVuICYmICFyb3V0ZS5sb2FkQ2hpbGRyZW4gJiYgcm91dGUub3V0bGV0ICYmIHJvdXRlLm91dGxldCAhPT0gUFJJTUFSWV9PVVRMRVQpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9JzogYSBjb21wb25lbnRsZXNzIHJvdXRlIHdpdGhvdXQgY2hpbGRyZW4gb3IgbG9hZENoaWxkcmVuIGNhbm5vdCBoYXZlIGEgbmFtZWQgb3V0bGV0IHNldGApO1xuICAgIH1cbiAgICBpZiAocm91dGUucmVkaXJlY3RUbyAmJiByb3V0ZS5jaGlsZHJlbikge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxNCwgYEludmFsaWQgY29uZmlndXJhdGlvbiBvZiByb3V0ZSAnJHtmdWxsUGF0aH0nOiByZWRpcmVjdFRvIGFuZCBjaGlsZHJlbiBjYW5ub3QgYmUgdXNlZCB0b2dldGhlcmApO1xuICAgIH1cbiAgICBpZiAocm91dGUucmVkaXJlY3RUbyAmJiByb3V0ZS5sb2FkQ2hpbGRyZW4pIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9JzogcmVkaXJlY3RUbyBhbmQgbG9hZENoaWxkcmVuIGNhbm5vdCBiZSB1c2VkIHRvZ2V0aGVyYCk7XG4gICAgfVxuICAgIGlmIChyb3V0ZS5jaGlsZHJlbiAmJiByb3V0ZS5sb2FkQ2hpbGRyZW4pIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9JzogY2hpbGRyZW4gYW5kIGxvYWRDaGlsZHJlbiBjYW5ub3QgYmUgdXNlZCB0b2dldGhlcmApO1xuICAgIH1cbiAgICBpZiAocm91dGUuY29tcG9uZW50ICYmIHJvdXRlLmxvYWRDb21wb25lbnQpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9JzogY29tcG9uZW50IGFuZCBsb2FkQ29tcG9uZW50IGNhbm5vdCBiZSB1c2VkIHRvZ2V0aGVyYCk7XG4gICAgfVxuICAgIGlmIChyb3V0ZS5yZWRpcmVjdFRvKSB7XG4gICAgICBpZiAocm91dGUuY29tcG9uZW50IHx8IHJvdXRlLmxvYWRDb21wb25lbnQpIHtcbiAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxNCwgYEludmFsaWQgY29uZmlndXJhdGlvbiBvZiByb3V0ZSAnJHtmdWxsUGF0aH0nOiByZWRpcmVjdFRvIGFuZCBjb21wb25lbnQvbG9hZENvbXBvbmVudCBjYW5ub3QgYmUgdXNlZCB0b2dldGhlcmApO1xuICAgICAgfVxuICAgICAgaWYgKHJvdXRlLmNhbk1hdGNoIHx8IHJvdXRlLmNhbkFjdGl2YXRlKSB7XG4gICAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9JzogcmVkaXJlY3RUbyBhbmQgJHtyb3V0ZS5jYW5NYXRjaCA/ICdjYW5NYXRjaCcgOiAnY2FuQWN0aXZhdGUnfSBjYW5ub3QgYmUgdXNlZCB0b2dldGhlci5gICsgYFJlZGlyZWN0cyBoYXBwZW4gYmVmb3JlIGd1YXJkcyBhcmUgZXhlY3V0ZWQuYCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChyb3V0ZS5wYXRoICYmIHJvdXRlLm1hdGNoZXIpIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9JzogcGF0aCBhbmQgbWF0Y2hlciBjYW5ub3QgYmUgdXNlZCB0b2dldGhlcmApO1xuICAgIH1cbiAgICBpZiAocm91dGUucmVkaXJlY3RUbyA9PT0gdm9pZCAwICYmICFyb3V0ZS5jb21wb25lbnQgJiYgIXJvdXRlLmxvYWRDb21wb25lbnQgJiYgIXJvdXRlLmNoaWxkcmVuICYmICFyb3V0ZS5sb2FkQ2hpbGRyZW4pIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9Jy4gT25lIG9mIHRoZSBmb2xsb3dpbmcgbXVzdCBiZSBwcm92aWRlZDogY29tcG9uZW50LCBsb2FkQ29tcG9uZW50LCByZWRpcmVjdFRvLCBjaGlsZHJlbiBvciBsb2FkQ2hpbGRyZW5gKTtcbiAgICB9XG4gICAgaWYgKHJvdXRlLnBhdGggPT09IHZvaWQgMCAmJiByb3V0ZS5tYXRjaGVyID09PSB2b2lkIDApIHtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJyR7ZnVsbFBhdGh9Jzogcm91dGVzIG11c3QgaGF2ZSBlaXRoZXIgYSBwYXRoIG9yIGEgbWF0Y2hlciBzcGVjaWZpZWRgKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiByb3V0ZS5wYXRoID09PSAnc3RyaW5nJyAmJiByb3V0ZS5wYXRoLmNoYXJBdCgwKSA9PT0gJy8nKSB7XG4gICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDE0LCBgSW52YWxpZCBjb25maWd1cmF0aW9uIG9mIHJvdXRlICcke2Z1bGxQYXRofSc6IHBhdGggY2Fubm90IHN0YXJ0IHdpdGggYSBzbGFzaGApO1xuICAgIH1cbiAgICBpZiAocm91dGUucGF0aCA9PT0gJycgJiYgcm91dGUucmVkaXJlY3RUbyAhPT0gdm9pZCAwICYmIHJvdXRlLnBhdGhNYXRjaCA9PT0gdm9pZCAwKSB7XG4gICAgICBjb25zdCBleHAgPSBgVGhlIGRlZmF1bHQgdmFsdWUgb2YgJ3BhdGhNYXRjaCcgaXMgJ3ByZWZpeCcsIGJ1dCBvZnRlbiB0aGUgaW50ZW50IGlzIHRvIHVzZSAnZnVsbCcuYDtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMTQsIGBJbnZhbGlkIGNvbmZpZ3VyYXRpb24gb2Ygcm91dGUgJ3twYXRoOiBcIiR7ZnVsbFBhdGh9XCIsIHJlZGlyZWN0VG86IFwiJHtyb3V0ZS5yZWRpcmVjdFRvfVwifSc6IHBsZWFzZSBwcm92aWRlICdwYXRoTWF0Y2gnLiAke2V4cH1gKTtcbiAgICB9XG4gICAgaWYgKHJlcXVpcmVTdGFuZGFsb25lQ29tcG9uZW50cykge1xuICAgICAgYXNzZXJ0U3RhbmRhbG9uZShmdWxsUGF0aCwgcm91dGUuY29tcG9uZW50KTtcbiAgICB9XG4gIH1cbiAgaWYgKHJvdXRlLmNoaWxkcmVuKSB7XG4gICAgdmFsaWRhdGVDb25maWcocm91dGUuY2hpbGRyZW4sIGZ1bGxQYXRoLCByZXF1aXJlU3RhbmRhbG9uZUNvbXBvbmVudHMpO1xuICB9XG59XG5mdW5jdGlvbiBnZXRGdWxsUGF0aChwYXJlbnRQYXRoLCBjdXJyZW50Um91dGUpIHtcbiAgaWYgKCFjdXJyZW50Um91dGUpIHtcbiAgICByZXR1cm4gcGFyZW50UGF0aDtcbiAgfVxuICBpZiAoIXBhcmVudFBhdGggJiYgIWN1cnJlbnRSb3V0ZS5wYXRoKSB7XG4gICAgcmV0dXJuICcnO1xuICB9IGVsc2UgaWYgKHBhcmVudFBhdGggJiYgIWN1cnJlbnRSb3V0ZS5wYXRoKSB7XG4gICAgcmV0dXJuIGAke3BhcmVudFBhdGh9L2A7XG4gIH0gZWxzZSBpZiAoIXBhcmVudFBhdGggJiYgY3VycmVudFJvdXRlLnBhdGgpIHtcbiAgICByZXR1cm4gY3VycmVudFJvdXRlLnBhdGg7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGAke3BhcmVudFBhdGh9LyR7Y3VycmVudFJvdXRlLnBhdGh9YDtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0T3V0bGV0KHJvdXRlKSB7XG4gIHJldHVybiByb3V0ZS5vdXRsZXQgfHwgUFJJTUFSWV9PVVRMRVQ7XG59XG5mdW5jdGlvbiBzb3J0QnlNYXRjaGluZ091dGxldHMocm91dGVzLCBvdXRsZXROYW1lKSB7XG4gIGNvbnN0IHNvcnRlZENvbmZpZyA9IHJvdXRlcy5maWx0ZXIociA9PiBnZXRPdXRsZXQocikgPT09IG91dGxldE5hbWUpO1xuICBzb3J0ZWRDb25maWcucHVzaCguLi5yb3V0ZXMuZmlsdGVyKHIgPT4gZ2V0T3V0bGV0KHIpICE9PSBvdXRsZXROYW1lKSk7XG4gIHJldHVybiBzb3J0ZWRDb25maWc7XG59XG5jb25zdCBub01hdGNoID0ge1xuICBtYXRjaGVkOiBmYWxzZSxcbiAgY29uc3VtZWRTZWdtZW50czogW10sXG4gIHJlbWFpbmluZ1NlZ21lbnRzOiBbXSxcbiAgcGFyYW1ldGVyczoge30sXG4gIHBvc2l0aW9uYWxQYXJhbVNlZ21lbnRzOiB7fVxufTtcbmZ1bmN0aW9uIGNyZWF0ZVByZU1hdGNoUm91dGVTbmFwc2hvdChzbmFwc2hvdCkge1xuICByZXR1cm4ge1xuICAgIHJvdXRlQ29uZmlnOiBzbmFwc2hvdC5yb3V0ZUNvbmZpZyxcbiAgICB1cmw6IHNuYXBzaG90LnVybCxcbiAgICBwYXJhbXM6IHNuYXBzaG90LnBhcmFtcyxcbiAgICBxdWVyeVBhcmFtczogc25hcHNob3QucXVlcnlQYXJhbXMsXG4gICAgZnJhZ21lbnQ6IHNuYXBzaG90LmZyYWdtZW50LFxuICAgIGRhdGE6IHNuYXBzaG90LmRhdGEsXG4gICAgb3V0bGV0OiBzbmFwc2hvdC5vdXRsZXQsXG4gICAgdGl0bGU6IHNuYXBzaG90LnRpdGxlLFxuICAgIHBhcmFtTWFwOiBzbmFwc2hvdC5wYXJhbU1hcCxcbiAgICBxdWVyeVBhcmFtTWFwOiBzbmFwc2hvdC5xdWVyeVBhcmFtTWFwXG4gIH07XG59XG5mdW5jdGlvbiBtYXRjaFdpdGhDaGVja3Moc2VnbWVudEdyb3VwLCByb3V0ZSwgc2VnbWVudHMsIGluamVjdG9yLCB1cmxTZXJpYWxpemVyLCBjcmVhdGVTbmFwc2hvdCwgYWJvcnRTaWduYWwpIHtcbiAgY29uc3QgcmVzdWx0ID0gbWF0Y2goc2VnbWVudEdyb3VwLCByb3V0ZSwgc2VnbWVudHMpO1xuICBpZiAoIXJlc3VsdC5tYXRjaGVkKSB7XG4gICAgcmV0dXJuIG9mKHJlc3VsdCk7XG4gIH1cbiAgY29uc3QgY3VycmVudFNuYXBzaG90ID0gY3JlYXRlUHJlTWF0Y2hSb3V0ZVNuYXBzaG90KGNyZWF0ZVNuYXBzaG90KHJlc3VsdCkpO1xuICBpbmplY3RvciA9IGdldE9yQ3JlYXRlUm91dGVJbmplY3RvcklmTmVlZGVkKHJvdXRlLCBpbmplY3Rvcik7XG4gIHJldHVybiBydW5DYW5NYXRjaEd1YXJkcyhpbmplY3Rvciwgcm91dGUsIHNlZ21lbnRzLCB1cmxTZXJpYWxpemVyLCBjdXJyZW50U25hcHNob3QsIGFib3J0U2lnbmFsKS5waXBlKG1hcCh2ID0+IHYgPT09IHRydWUgPyByZXN1bHQgOiB7XG4gICAgLi4ubm9NYXRjaFxuICB9KSk7XG59XG5mdW5jdGlvbiBtYXRjaChzZWdtZW50R3JvdXAsIHJvdXRlLCBzZWdtZW50cykge1xuICBpZiAocm91dGUucGF0aCA9PT0gJycpIHtcbiAgICBpZiAocm91dGUucGF0aE1hdGNoID09PSAnZnVsbCcgJiYgKHNlZ21lbnRHcm91cC5oYXNDaGlsZHJlbigpIHx8IHNlZ21lbnRzLmxlbmd0aCA+IDApKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5ub01hdGNoXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgbWF0Y2hlZDogdHJ1ZSxcbiAgICAgIGNvbnN1bWVkU2VnbWVudHM6IFtdLFxuICAgICAgcmVtYWluaW5nU2VnbWVudHM6IHNlZ21lbnRzLFxuICAgICAgcGFyYW1ldGVyczoge30sXG4gICAgICBwb3NpdGlvbmFsUGFyYW1TZWdtZW50czoge31cbiAgICB9O1xuICB9XG4gIGNvbnN0IG1hdGNoZXIgPSByb3V0ZS5tYXRjaGVyIHx8IGRlZmF1bHRVcmxNYXRjaGVyO1xuICBjb25zdCByZXMgPSBtYXRjaGVyKHNlZ21lbnRzLCBzZWdtZW50R3JvdXAsIHJvdXRlKTtcbiAgaWYgKCFyZXMpIHJldHVybiB7XG4gICAgLi4ubm9NYXRjaFxuICB9O1xuICBjb25zdCBwb3NQYXJhbXMgPSB7fTtcbiAgT2JqZWN0LmVudHJpZXMocmVzLnBvc1BhcmFtcyA/PyB7fSkuZm9yRWFjaCgoW2ssIHZdKSA9PiB7XG4gICAgcG9zUGFyYW1zW2tdID0gdi5wYXRoO1xuICB9KTtcbiAgY29uc3QgcGFyYW1ldGVycyA9IHJlcy5jb25zdW1lZC5sZW5ndGggPiAwID8ge1xuICAgIC4uLnBvc1BhcmFtcyxcbiAgICAuLi5yZXMuY29uc3VtZWRbcmVzLmNvbnN1bWVkLmxlbmd0aCAtIDFdLnBhcmFtZXRlcnNcbiAgfSA6IHBvc1BhcmFtcztcbiAgcmV0dXJuIHtcbiAgICBtYXRjaGVkOiB0cnVlLFxuICAgIGNvbnN1bWVkU2VnbWVudHM6IHJlcy5jb25zdW1lZCxcbiAgICByZW1haW5pbmdTZWdtZW50czogc2VnbWVudHMuc2xpY2UocmVzLmNvbnN1bWVkLmxlbmd0aCksXG4gICAgcGFyYW1ldGVycyxcbiAgICBwb3NpdGlvbmFsUGFyYW1TZWdtZW50czogcmVzLnBvc1BhcmFtcyA/PyB7fVxuICB9O1xufVxuZnVuY3Rpb24gc3BsaXQoc2VnbWVudEdyb3VwLCBjb25zdW1lZFNlZ21lbnRzLCBzbGljZWRTZWdtZW50cywgY29uZmlnLCBvdXRsZXQpIHtcbiAgaWYgKHNsaWNlZFNlZ21lbnRzLmxlbmd0aCA+IDAgJiYgY29udGFpbnNFbXB0eVBhdGhNYXRjaGVzV2l0aE5hbWVkT3V0bGV0cyhzZWdtZW50R3JvdXAsIHNsaWNlZFNlZ21lbnRzLCBjb25maWcsIG91dGxldCkpIHtcbiAgICBjb25zdCBzID0gbmV3IFVybFNlZ21lbnRHcm91cChjb25zdW1lZFNlZ21lbnRzLCBjcmVhdGVDaGlsZHJlbkZvckVtcHR5UGF0aHMoY29uZmlnLCBuZXcgVXJsU2VnbWVudEdyb3VwKHNsaWNlZFNlZ21lbnRzLCBzZWdtZW50R3JvdXAuY2hpbGRyZW4pKSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHNlZ21lbnRHcm91cDogcyxcbiAgICAgIHNsaWNlZFNlZ21lbnRzOiBbXVxuICAgIH07XG4gIH1cbiAgaWYgKHNsaWNlZFNlZ21lbnRzLmxlbmd0aCA9PT0gMCAmJiBjb250YWluc0VtcHR5UGF0aE1hdGNoZXMoc2VnbWVudEdyb3VwLCBzbGljZWRTZWdtZW50cywgY29uZmlnKSkge1xuICAgIGNvbnN0IHMgPSBuZXcgVXJsU2VnbWVudEdyb3VwKHNlZ21lbnRHcm91cC5zZWdtZW50cywgYWRkRW1wdHlQYXRoc1RvQ2hpbGRyZW5JZk5lZWRlZChzZWdtZW50R3JvdXAsIHNsaWNlZFNlZ21lbnRzLCBjb25maWcsIHNlZ21lbnRHcm91cC5jaGlsZHJlbikpO1xuICAgIHJldHVybiB7XG4gICAgICBzZWdtZW50R3JvdXA6IHMsXG4gICAgICBzbGljZWRTZWdtZW50c1xuICAgIH07XG4gIH1cbiAgY29uc3QgcyA9IG5ldyBVcmxTZWdtZW50R3JvdXAoc2VnbWVudEdyb3VwLnNlZ21lbnRzLCBzZWdtZW50R3JvdXAuY2hpbGRyZW4pO1xuICByZXR1cm4ge1xuICAgIHNlZ21lbnRHcm91cDogcyxcbiAgICBzbGljZWRTZWdtZW50c1xuICB9O1xufVxuZnVuY3Rpb24gYWRkRW1wdHlQYXRoc1RvQ2hpbGRyZW5JZk5lZWRlZChzZWdtZW50R3JvdXAsIHNsaWNlZFNlZ21lbnRzLCByb3V0ZXMsIGNoaWxkcmVuKSB7XG4gIGNvbnN0IHJlcyA9IHt9O1xuICBmb3IgKGNvbnN0IHIgb2Ygcm91dGVzKSB7XG4gICAgaWYgKGVtcHR5UGF0aE1hdGNoKHNlZ21lbnRHcm91cCwgc2xpY2VkU2VnbWVudHMsIHIpICYmICFjaGlsZHJlbltnZXRPdXRsZXQocildKSB7XG4gICAgICBjb25zdCBzID0gbmV3IFVybFNlZ21lbnRHcm91cChbXSwge30pO1xuICAgICAgcmVzW2dldE91dGxldChyKV0gPSBzO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIC4uLmNoaWxkcmVuLFxuICAgIC4uLnJlc1xuICB9O1xufVxuZnVuY3Rpb24gY3JlYXRlQ2hpbGRyZW5Gb3JFbXB0eVBhdGhzKHJvdXRlcywgcHJpbWFyeVNlZ21lbnQpIHtcbiAgY29uc3QgcmVzID0ge307XG4gIHJlc1tQUklNQVJZX09VVExFVF0gPSBwcmltYXJ5U2VnbWVudDtcbiAgZm9yIChjb25zdCByIG9mIHJvdXRlcykge1xuICAgIGlmIChyLnBhdGggPT09ICcnICYmIGdldE91dGxldChyKSAhPT0gUFJJTUFSWV9PVVRMRVQpIHtcbiAgICAgIGNvbnN0IHMgPSBuZXcgVXJsU2VnbWVudEdyb3VwKFtdLCB7fSk7XG4gICAgICByZXNbZ2V0T3V0bGV0KHIpXSA9IHM7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXM7XG59XG5mdW5jdGlvbiBjb250YWluc0VtcHR5UGF0aE1hdGNoZXNXaXRoTmFtZWRPdXRsZXRzKHNlZ21lbnRHcm91cCwgc2xpY2VkU2VnbWVudHMsIHJvdXRlcywgb3V0bGV0KSB7XG4gIHJldHVybiByb3V0ZXMuc29tZShyID0+IHtcbiAgICBjb25zdCBtYXRjaGVzRW1wdHkgPSBlbXB0eVBhdGhNYXRjaChzZWdtZW50R3JvdXAsIHNsaWNlZFNlZ21lbnRzLCByKTtcbiAgICBpZiAoIW1hdGNoZXNFbXB0eSkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlzTmFtZWRPdXRsZXQgPSBnZXRPdXRsZXQocikgIT09IFBSSU1BUllfT1VUTEVUO1xuICAgIGlmICghaXNOYW1lZE91dGxldCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlzU2VsZkV2YWx1YXRpbmcgPSBvdXRsZXQgIT09IHVuZGVmaW5lZCAmJiBnZXRPdXRsZXQocikgPT09IG91dGxldDtcbiAgICByZXR1cm4gIWlzU2VsZkV2YWx1YXRpbmc7XG4gIH0pO1xufVxuZnVuY3Rpb24gY29udGFpbnNFbXB0eVBhdGhNYXRjaGVzKHNlZ21lbnRHcm91cCwgc2xpY2VkU2VnbWVudHMsIHJvdXRlcykge1xuICByZXR1cm4gcm91dGVzLnNvbWUociA9PiBlbXB0eVBhdGhNYXRjaChzZWdtZW50R3JvdXAsIHNsaWNlZFNlZ21lbnRzLCByKSk7XG59XG5mdW5jdGlvbiBlbXB0eVBhdGhNYXRjaChzZWdtZW50R3JvdXAsIHNsaWNlZFNlZ21lbnRzLCByKSB7XG4gIGlmICgoc2VnbWVudEdyb3VwLmhhc0NoaWxkcmVuKCkgfHwgc2xpY2VkU2VnbWVudHMubGVuZ3RoID4gMCkgJiYgci5wYXRoTWF0Y2ggPT09ICdmdWxsJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gci5wYXRoID09PSAnJztcbn1cbmZ1bmN0aW9uIG5vTGVmdG92ZXJzSW5Vcmwoc2VnbWVudEdyb3VwLCBzZWdtZW50cywgb3V0bGV0KSB7XG4gIHJldHVybiBzZWdtZW50cy5sZW5ndGggPT09IDAgJiYgIXNlZ21lbnRHcm91cC5jaGlsZHJlbltvdXRsZXRdO1xufVxuY2xhc3MgTm9MZWZ0b3ZlcnNJblVybCB7fVxuYXN5bmMgZnVuY3Rpb24gcmVjb2duaXplJDEoaW5qZWN0b3IsIGNvbmZpZ0xvYWRlciwgcm9vdENvbXBvbmVudFR5cGUsIGNvbmZpZywgdXJsVHJlZSwgdXJsU2VyaWFsaXplciwgcGFyYW1zSW5oZXJpdGFuY2VTdHJhdGVneSwgYWJvcnRTaWduYWwpIHtcbiAgcmV0dXJuIG5ldyBSZWNvZ25pemVyKGluamVjdG9yLCBjb25maWdMb2FkZXIsIHJvb3RDb21wb25lbnRUeXBlLCBjb25maWcsIHVybFRyZWUsIHBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3ksIHVybFNlcmlhbGl6ZXIsIGFib3J0U2lnbmFsKS5yZWNvZ25pemUoKTtcbn1cbmNvbnN0IE1BWF9BTExPV0VEX1JFRElSRUNUUyA9IDMxO1xuY2xhc3MgUmVjb2duaXplciB7XG4gIGluamVjdG9yO1xuICBjb25maWdMb2FkZXI7XG4gIHJvb3RDb21wb25lbnRUeXBlO1xuICBjb25maWc7XG4gIHVybFRyZWU7XG4gIHBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3k7XG4gIHVybFNlcmlhbGl6ZXI7XG4gIGFib3J0U2lnbmFsO1xuICBhcHBseVJlZGlyZWN0cztcbiAgYWJzb2x1dGVSZWRpcmVjdENvdW50ID0gMDtcbiAgYWxsb3dSZWRpcmVjdHMgPSB0cnVlO1xuICBjb25zdHJ1Y3RvcihpbmplY3RvciwgY29uZmlnTG9hZGVyLCByb290Q29tcG9uZW50VHlwZSwgY29uZmlnLCB1cmxUcmVlLCBwYXJhbXNJbmhlcml0YW5jZVN0cmF0ZWd5LCB1cmxTZXJpYWxpemVyLCBhYm9ydFNpZ25hbCkge1xuICAgIHRoaXMuaW5qZWN0b3IgPSBpbmplY3RvcjtcbiAgICB0aGlzLmNvbmZpZ0xvYWRlciA9IGNvbmZpZ0xvYWRlcjtcbiAgICB0aGlzLnJvb3RDb21wb25lbnRUeXBlID0gcm9vdENvbXBvbmVudFR5cGU7XG4gICAgdGhpcy5jb25maWcgPSBjb25maWc7XG4gICAgdGhpcy51cmxUcmVlID0gdXJsVHJlZTtcbiAgICB0aGlzLnBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3kgPSBwYXJhbXNJbmhlcml0YW5jZVN0cmF0ZWd5O1xuICAgIHRoaXMudXJsU2VyaWFsaXplciA9IHVybFNlcmlhbGl6ZXI7XG4gICAgdGhpcy5hYm9ydFNpZ25hbCA9IGFib3J0U2lnbmFsO1xuICAgIHRoaXMuYXBwbHlSZWRpcmVjdHMgPSBuZXcgQXBwbHlSZWRpcmVjdHModGhpcy51cmxTZXJpYWxpemVyLCB0aGlzLnVybFRyZWUpO1xuICB9XG4gIG5vTWF0Y2hFcnJvcihlKSB7XG4gICAgcmV0dXJuIG5ldyBfUnVudGltZUVycm9yKDQwMDIsIHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IGBDYW5ub3QgbWF0Y2ggYW55IHJvdXRlcy4gVVJMIFNlZ21lbnQ6ICcke2Uuc2VnbWVudEdyb3VwfSdgIDogYCcke2Uuc2VnbWVudEdyb3VwfSdgKTtcbiAgfVxuICBhc3luYyByZWNvZ25pemUoKSB7XG4gICAgY29uc3Qgcm9vdFNlZ21lbnRHcm91cCA9IHNwbGl0KHRoaXMudXJsVHJlZS5yb290LCBbXSwgW10sIHRoaXMuY29uZmlnKS5zZWdtZW50R3JvdXA7XG4gICAgY29uc3Qge1xuICAgICAgY2hpbGRyZW4sXG4gICAgICByb290U25hcHNob3RcbiAgICB9ID0gYXdhaXQgdGhpcy5tYXRjaChyb290U2VnbWVudEdyb3VwKTtcbiAgICBjb25zdCByb290Tm9kZSA9IG5ldyBUcmVlTm9kZShyb290U25hcHNob3QsIGNoaWxkcmVuKTtcbiAgICBjb25zdCByb3V0ZVN0YXRlID0gbmV3IFJvdXRlclN0YXRlU25hcHNob3QoJycsIHJvb3ROb2RlKTtcbiAgICBjb25zdCB0cmVlID0gY3JlYXRlVXJsVHJlZUZyb21TbmFwc2hvdChyb290U25hcHNob3QsIFtdLCB0aGlzLnVybFRyZWUucXVlcnlQYXJhbXMsIHRoaXMudXJsVHJlZS5mcmFnbWVudCk7XG4gICAgdHJlZS5xdWVyeVBhcmFtcyA9IHRoaXMudXJsVHJlZS5xdWVyeVBhcmFtcztcbiAgICByb3V0ZVN0YXRlLnVybCA9IHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodHJlZSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN0YXRlOiByb3V0ZVN0YXRlLFxuICAgICAgdHJlZVxuICAgIH07XG4gIH1cbiAgYXN5bmMgbWF0Y2gocm9vdFNlZ21lbnRHcm91cCkge1xuICAgIGNvbnN0IHJvb3RTbmFwc2hvdCA9IG5ldyBBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90KFtdLCBPYmplY3QuZnJlZXplKHt9KSwgT2JqZWN0LmZyZWV6ZSh7XG4gICAgICAuLi50aGlzLnVybFRyZWUucXVlcnlQYXJhbXNcbiAgICB9KSwgdGhpcy51cmxUcmVlLmZyYWdtZW50LCBPYmplY3QuZnJlZXplKHt9KSwgUFJJTUFSWV9PVVRMRVQsIHRoaXMucm9vdENvbXBvbmVudFR5cGUsIG51bGwsIHt9LCB0aGlzLmluamVjdG9yKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY2hpbGRyZW4gPSBhd2FpdCB0aGlzLnByb2Nlc3NTZWdtZW50R3JvdXAodGhpcy5pbmplY3RvciwgdGhpcy5jb25maWcsIHJvb3RTZWdtZW50R3JvdXAsIFBSSU1BUllfT1VUTEVULCByb290U25hcHNob3QpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY2hpbGRyZW4sXG4gICAgICAgIHJvb3RTbmFwc2hvdFxuICAgICAgfTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoZSBpbnN0YW5jZW9mIEFic29sdXRlUmVkaXJlY3QpIHtcbiAgICAgICAgdGhpcy51cmxUcmVlID0gZS51cmxUcmVlO1xuICAgICAgICByZXR1cm4gdGhpcy5tYXRjaChlLnVybFRyZWUucm9vdCk7XG4gICAgICB9XG4gICAgICBpZiAoZSBpbnN0YW5jZW9mIE5vTWF0Y2gpIHtcbiAgICAgICAgdGhyb3cgdGhpcy5ub01hdGNoRXJyb3IoZSk7XG4gICAgICB9XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfVxuICBhc3luYyBwcm9jZXNzU2VnbWVudEdyb3VwKGluamVjdG9yLCBjb25maWcsIHNlZ21lbnRHcm91cCwgb3V0bGV0LCBwYXJlbnRSb3V0ZSkge1xuICAgIGlmIChzZWdtZW50R3JvdXAuc2VnbWVudHMubGVuZ3RoID09PSAwICYmIHNlZ21lbnRHcm91cC5oYXNDaGlsZHJlbigpKSB7XG4gICAgICByZXR1cm4gdGhpcy5wcm9jZXNzQ2hpbGRyZW4oaW5qZWN0b3IsIGNvbmZpZywgc2VnbWVudEdyb3VwLCBwYXJlbnRSb3V0ZSk7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkID0gYXdhaXQgdGhpcy5wcm9jZXNzU2VnbWVudChpbmplY3RvciwgY29uZmlnLCBzZWdtZW50R3JvdXAsIHNlZ21lbnRHcm91cC5zZWdtZW50cywgb3V0bGV0LCB0cnVlLCBwYXJlbnRSb3V0ZSk7XG4gICAgcmV0dXJuIGNoaWxkIGluc3RhbmNlb2YgVHJlZU5vZGUgPyBbY2hpbGRdIDogW107XG4gIH1cbiAgYXN5bmMgcHJvY2Vzc0NoaWxkcmVuKGluamVjdG9yLCBjb25maWcsIHNlZ21lbnRHcm91cCwgcGFyZW50Um91dGUpIHtcbiAgICBjb25zdCBjaGlsZE91dGxldHMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIE9iamVjdC5rZXlzKHNlZ21lbnRHcm91cC5jaGlsZHJlbikpIHtcbiAgICAgIGlmIChjaGlsZCA9PT0gJ3ByaW1hcnknKSB7XG4gICAgICAgIGNoaWxkT3V0bGV0cy51bnNoaWZ0KGNoaWxkKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNoaWxkT3V0bGV0cy5wdXNoKGNoaWxkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IGNoaWxkcmVuID0gW107XG4gICAgZm9yIChjb25zdCBjaGlsZE91dGxldCBvZiBjaGlsZE91dGxldHMpIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gc2VnbWVudEdyb3VwLmNoaWxkcmVuW2NoaWxkT3V0bGV0XTtcbiAgICAgIGNvbnN0IHNvcnRlZENvbmZpZyA9IHNvcnRCeU1hdGNoaW5nT3V0bGV0cyhjb25maWcsIGNoaWxkT3V0bGV0KTtcbiAgICAgIGNvbnN0IG91dGxldENoaWxkcmVuID0gYXdhaXQgdGhpcy5wcm9jZXNzU2VnbWVudEdyb3VwKGluamVjdG9yLCBzb3J0ZWRDb25maWcsIGNoaWxkLCBjaGlsZE91dGxldCwgcGFyZW50Um91dGUpO1xuICAgICAgY2hpbGRyZW4ucHVzaCguLi5vdXRsZXRDaGlsZHJlbik7XG4gICAgfVxuICAgIGNvbnN0IG1lcmdlZENoaWxkcmVuID0gbWVyZ2VFbXB0eVBhdGhNYXRjaGVzKGNoaWxkcmVuKTtcbiAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgICBjaGVja091dGxldE5hbWVVbmlxdWVuZXNzKG1lcmdlZENoaWxkcmVuKTtcbiAgICB9XG4gICAgc29ydEFjdGl2YXRlZFJvdXRlU25hcHNob3RzKG1lcmdlZENoaWxkcmVuKTtcbiAgICByZXR1cm4gbWVyZ2VkQ2hpbGRyZW47XG4gIH1cbiAgYXN5bmMgcHJvY2Vzc1NlZ21lbnQoaW5qZWN0b3IsIHJvdXRlcywgc2VnbWVudEdyb3VwLCBzZWdtZW50cywgb3V0bGV0LCBhbGxvd1JlZGlyZWN0cywgcGFyZW50Um91dGUpIHtcbiAgICBmb3IgKGNvbnN0IHIgb2Ygcm91dGVzKSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5wcm9jZXNzU2VnbWVudEFnYWluc3RSb3V0ZShyLl9pbmplY3RvciA/PyBpbmplY3Rvciwgcm91dGVzLCByLCBzZWdtZW50R3JvdXAsIHNlZ21lbnRzLCBvdXRsZXQsIGFsbG93UmVkaXJlY3RzLCBwYXJlbnRSb3V0ZSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgTm9NYXRjaCB8fCBpc0VtcHR5RXJyb3IoZSkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobm9MZWZ0b3ZlcnNJblVybChzZWdtZW50R3JvdXAsIHNlZ21lbnRzLCBvdXRsZXQpKSB7XG4gICAgICByZXR1cm4gbmV3IE5vTGVmdG92ZXJzSW5VcmwoKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IE5vTWF0Y2goc2VnbWVudEdyb3VwKTtcbiAgfVxuICBhc3luYyBwcm9jZXNzU2VnbWVudEFnYWluc3RSb3V0ZShpbmplY3Rvciwgcm91dGVzLCByb3V0ZSwgcmF3U2VnbWVudCwgc2VnbWVudHMsIG91dGxldCwgYWxsb3dSZWRpcmVjdHMsIHBhcmVudFJvdXRlKSB7XG4gICAgaWYgKGdldE91dGxldChyb3V0ZSkgIT09IG91dGxldCAmJiAob3V0bGV0ID09PSBQUklNQVJZX09VVExFVCB8fCAhZW1wdHlQYXRoTWF0Y2gocmF3U2VnbWVudCwgc2VnbWVudHMsIHJvdXRlKSkpIHtcbiAgICAgIHRocm93IG5ldyBOb01hdGNoKHJhd1NlZ21lbnQpO1xuICAgIH1cbiAgICBpZiAocm91dGUucmVkaXJlY3RUbyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gdGhpcy5tYXRjaFNlZ21lbnRBZ2FpbnN0Um91dGUoaW5qZWN0b3IsIHJhd1NlZ21lbnQsIHJvdXRlLCBzZWdtZW50cywgb3V0bGV0LCBwYXJlbnRSb3V0ZSk7XG4gICAgfVxuICAgIGlmICh0aGlzLmFsbG93UmVkaXJlY3RzICYmIGFsbG93UmVkaXJlY3RzKSB7XG4gICAgICByZXR1cm4gdGhpcy5leHBhbmRTZWdtZW50QWdhaW5zdFJvdXRlVXNpbmdSZWRpcmVjdChpbmplY3RvciwgcmF3U2VnbWVudCwgcm91dGVzLCByb3V0ZSwgc2VnbWVudHMsIG91dGxldCwgcGFyZW50Um91dGUpO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgTm9NYXRjaChyYXdTZWdtZW50KTtcbiAgfVxuICBhc3luYyBleHBhbmRTZWdtZW50QWdhaW5zdFJvdXRlVXNpbmdSZWRpcmVjdChpbmplY3Rvciwgc2VnbWVudEdyb3VwLCByb3V0ZXMsIHJvdXRlLCBzZWdtZW50cywgb3V0bGV0LCBwYXJlbnRSb3V0ZSkge1xuICAgIGNvbnN0IHtcbiAgICAgIG1hdGNoZWQsXG4gICAgICBwYXJhbWV0ZXJzLFxuICAgICAgY29uc3VtZWRTZWdtZW50cyxcbiAgICAgIHBvc2l0aW9uYWxQYXJhbVNlZ21lbnRzLFxuICAgICAgcmVtYWluaW5nU2VnbWVudHNcbiAgICB9ID0gbWF0Y2goc2VnbWVudEdyb3VwLCByb3V0ZSwgc2VnbWVudHMpO1xuICAgIGlmICghbWF0Y2hlZCkgdGhyb3cgbmV3IE5vTWF0Y2goc2VnbWVudEdyb3VwKTtcbiAgICBpZiAodHlwZW9mIHJvdXRlLnJlZGlyZWN0VG8gPT09ICdzdHJpbmcnICYmIHJvdXRlLnJlZGlyZWN0VG9bMF0gPT09ICcvJykge1xuICAgICAgdGhpcy5hYnNvbHV0ZVJlZGlyZWN0Q291bnQrKztcbiAgICAgIGlmICh0aGlzLmFic29sdXRlUmVkaXJlY3RDb3VudCA+IE1BWF9BTExPV0VEX1JFRElSRUNUUykge1xuICAgICAgICBpZiAobmdEZXZNb2RlKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAxNiwgYERldGVjdGVkIHBvc3NpYmxlIGluZmluaXRlIHJlZGlyZWN0IHdoZW4gcmVkaXJlY3RpbmcgZnJvbSAnJHt0aGlzLnVybFRyZWV9JyB0byAnJHtyb3V0ZS5yZWRpcmVjdFRvfScuXFxuYCArIGBUaGlzIGlzIGN1cnJlbnRseSBhIGRldiBtb2RlIG9ubHkgZXJyb3IgYnV0IHdpbGwgYmVjb21lIGFgICsgYCBjYWxsIHN0YWNrIHNpemUgZXhjZWVkZWQgZXJyb3IgaW4gcHJvZHVjdGlvbiBpbiBhIGZ1dHVyZSBtYWpvciB2ZXJzaW9uLmApO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYWxsb3dSZWRpcmVjdHMgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgY3VycmVudFNuYXBzaG90ID0gdGhpcy5jcmVhdGVTbmFwc2hvdChpbmplY3Rvciwgcm91dGUsIHNlZ21lbnRzLCBwYXJhbWV0ZXJzLCBwYXJlbnRSb3V0ZSk7XG4gICAgaWYgKHRoaXMuYWJvcnRTaWduYWwuYWJvcnRlZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHRoaXMuYWJvcnRTaWduYWwucmVhc29uKTtcbiAgICB9XG4gICAgY29uc3QgbmV3VHJlZSA9IGF3YWl0IHRoaXMuYXBwbHlSZWRpcmVjdHMuYXBwbHlSZWRpcmVjdENvbW1hbmRzKGNvbnN1bWVkU2VnbWVudHMsIHJvdXRlLnJlZGlyZWN0VG8sIHBvc2l0aW9uYWxQYXJhbVNlZ21lbnRzLCBjcmVhdGVQcmVNYXRjaFJvdXRlU25hcHNob3QoY3VycmVudFNuYXBzaG90KSwgaW5qZWN0b3IpO1xuICAgIGNvbnN0IG5ld1NlZ21lbnRzID0gYXdhaXQgdGhpcy5hcHBseVJlZGlyZWN0cy5saW5lcmFsaXplU2VnbWVudHMocm91dGUsIG5ld1RyZWUpO1xuICAgIHJldHVybiB0aGlzLnByb2Nlc3NTZWdtZW50KGluamVjdG9yLCByb3V0ZXMsIHNlZ21lbnRHcm91cCwgbmV3U2VnbWVudHMuY29uY2F0KHJlbWFpbmluZ1NlZ21lbnRzKSwgb3V0bGV0LCBmYWxzZSwgcGFyZW50Um91dGUpO1xuICB9XG4gIGNyZWF0ZVNuYXBzaG90KGluamVjdG9yLCByb3V0ZSwgc2VnbWVudHMsIHBhcmFtZXRlcnMsIHBhcmVudFJvdXRlKSB7XG4gICAgY29uc3Qgc25hcHNob3QgPSBuZXcgQWN0aXZhdGVkUm91dGVTbmFwc2hvdChzZWdtZW50cywgcGFyYW1ldGVycywgT2JqZWN0LmZyZWV6ZSh7XG4gICAgICAuLi50aGlzLnVybFRyZWUucXVlcnlQYXJhbXNcbiAgICB9KSwgdGhpcy51cmxUcmVlLmZyYWdtZW50LCBnZXREYXRhKHJvdXRlKSwgZ2V0T3V0bGV0KHJvdXRlKSwgcm91dGUuY29tcG9uZW50ID8/IHJvdXRlLl9sb2FkZWRDb21wb25lbnQgPz8gbnVsbCwgcm91dGUsIGdldFJlc29sdmUocm91dGUpLCBpbmplY3Rvcik7XG4gICAgY29uc3QgaW5oZXJpdGVkID0gZ2V0SW5oZXJpdGVkKHNuYXBzaG90LCBwYXJlbnRSb3V0ZSwgdGhpcy5wYXJhbXNJbmhlcml0YW5jZVN0cmF0ZWd5KTtcbiAgICBzbmFwc2hvdC5wYXJhbXMgPSBPYmplY3QuZnJlZXplKGluaGVyaXRlZC5wYXJhbXMpO1xuICAgIHNuYXBzaG90LmRhdGEgPSBPYmplY3QuZnJlZXplKGluaGVyaXRlZC5kYXRhKTtcbiAgICByZXR1cm4gc25hcHNob3Q7XG4gIH1cbiAgYXN5bmMgbWF0Y2hTZWdtZW50QWdhaW5zdFJvdXRlKGluamVjdG9yLCByYXdTZWdtZW50LCByb3V0ZSwgc2VnbWVudHMsIG91dGxldCwgcGFyZW50Um91dGUpIHtcbiAgICBpZiAodGhpcy5hYm9ydFNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IodGhpcy5hYm9ydFNpZ25hbC5yZWFzb24pO1xuICAgIH1cbiAgICBjb25zdCBjcmVhdGVTbmFwc2hvdCA9IHJlc3VsdCA9PiB0aGlzLmNyZWF0ZVNuYXBzaG90KGluamVjdG9yLCByb3V0ZSwgcmVzdWx0LmNvbnN1bWVkU2VnbWVudHMsIHJlc3VsdC5wYXJhbWV0ZXJzLCBwYXJlbnRSb3V0ZSk7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZmlyc3RWYWx1ZUZyb20obWF0Y2hXaXRoQ2hlY2tzKHJhd1NlZ21lbnQsIHJvdXRlLCBzZWdtZW50cywgaW5qZWN0b3IsIHRoaXMudXJsU2VyaWFsaXplciwgY3JlYXRlU25hcHNob3QsIHRoaXMuYWJvcnRTaWduYWwpKTtcbiAgICBpZiAocm91dGUucGF0aCA9PT0gJyoqJykge1xuICAgICAgcmF3U2VnbWVudC5jaGlsZHJlbiA9IHt9O1xuICAgIH1cbiAgICBpZiAoIXJlc3VsdD8ubWF0Y2hlZCkge1xuICAgICAgdGhyb3cgbmV3IE5vTWF0Y2gocmF3U2VnbWVudCk7XG4gICAgfVxuICAgIGluamVjdG9yID0gcm91dGUuX2luamVjdG9yID8/IGluamVjdG9yO1xuICAgIGNvbnN0IHtcbiAgICAgIHJvdXRlczogY2hpbGRDb25maWdcbiAgICB9ID0gYXdhaXQgdGhpcy5nZXRDaGlsZENvbmZpZyhpbmplY3Rvciwgcm91dGUsIHNlZ21lbnRzKTtcbiAgICBjb25zdCBjaGlsZEluamVjdG9yID0gcm91dGUuX2xvYWRlZEluamVjdG9yID8/IGluamVjdG9yO1xuICAgIGNvbnN0IHtcbiAgICAgIHBhcmFtZXRlcnMsXG4gICAgICBjb25zdW1lZFNlZ21lbnRzLFxuICAgICAgcmVtYWluaW5nU2VnbWVudHNcbiAgICB9ID0gcmVzdWx0O1xuICAgIGNvbnN0IHNuYXBzaG90ID0gdGhpcy5jcmVhdGVTbmFwc2hvdChpbmplY3Rvciwgcm91dGUsIGNvbnN1bWVkU2VnbWVudHMsIHBhcmFtZXRlcnMsIHBhcmVudFJvdXRlKTtcbiAgICBjb25zdCB7XG4gICAgICBzZWdtZW50R3JvdXAsXG4gICAgICBzbGljZWRTZWdtZW50c1xuICAgIH0gPSBzcGxpdChyYXdTZWdtZW50LCBjb25zdW1lZFNlZ21lbnRzLCByZW1haW5pbmdTZWdtZW50cywgY2hpbGRDb25maWcsIG91dGxldCk7XG4gICAgaWYgKHNsaWNlZFNlZ21lbnRzLmxlbmd0aCA9PT0gMCAmJiBzZWdtZW50R3JvdXAuaGFzQ2hpbGRyZW4oKSkge1xuICAgICAgY29uc3QgY2hpbGRyZW4gPSBhd2FpdCB0aGlzLnByb2Nlc3NDaGlsZHJlbihjaGlsZEluamVjdG9yLCBjaGlsZENvbmZpZywgc2VnbWVudEdyb3VwLCBzbmFwc2hvdCk7XG4gICAgICByZXR1cm4gbmV3IFRyZWVOb2RlKHNuYXBzaG90LCBjaGlsZHJlbik7XG4gICAgfVxuICAgIGlmIChjaGlsZENvbmZpZy5sZW5ndGggPT09IDAgJiYgc2xpY2VkU2VnbWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gbmV3IFRyZWVOb2RlKHNuYXBzaG90LCBbXSk7XG4gICAgfVxuICAgIGNvbnN0IG1hdGNoZWRPbk91dGxldCA9IGdldE91dGxldChyb3V0ZSkgPT09IG91dGxldDtcbiAgICBjb25zdCBjaGlsZCA9IGF3YWl0IHRoaXMucHJvY2Vzc1NlZ21lbnQoY2hpbGRJbmplY3RvciwgY2hpbGRDb25maWcsIHNlZ21lbnRHcm91cCwgc2xpY2VkU2VnbWVudHMsIG1hdGNoZWRPbk91dGxldCA/IFBSSU1BUllfT1VUTEVUIDogb3V0bGV0LCB0cnVlLCBzbmFwc2hvdCk7XG4gICAgcmV0dXJuIG5ldyBUcmVlTm9kZShzbmFwc2hvdCwgY2hpbGQgaW5zdGFuY2VvZiBUcmVlTm9kZSA/IFtjaGlsZF0gOiBbXSk7XG4gIH1cbiAgYXN5bmMgZ2V0Q2hpbGRDb25maWcoaW5qZWN0b3IsIHJvdXRlLCBzZWdtZW50cykge1xuICAgIGlmIChyb3V0ZS5jaGlsZHJlbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcm91dGVzOiByb3V0ZS5jaGlsZHJlbixcbiAgICAgICAgaW5qZWN0b3JcbiAgICAgIH07XG4gICAgfVxuICAgIGlmIChyb3V0ZS5sb2FkQ2hpbGRyZW4pIHtcbiAgICAgIGlmIChyb3V0ZS5fbG9hZGVkUm91dGVzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY29uc3QgbmdNb2R1bGVGYWN0b3J5ID0gcm91dGUuX2xvYWRlZE5nTW9kdWxlRmFjdG9yeTtcbiAgICAgICAgaWYgKG5nTW9kdWxlRmFjdG9yeSAmJiAhcm91dGUuX2xvYWRlZEluamVjdG9yKSB7XG4gICAgICAgICAgcm91dGUuX2xvYWRlZEluamVjdG9yID0gbmdNb2R1bGVGYWN0b3J5LmNyZWF0ZShpbmplY3RvcikuaW5qZWN0b3I7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICByb3V0ZXM6IHJvdXRlLl9sb2FkZWRSb3V0ZXMsXG4gICAgICAgICAgaW5qZWN0b3I6IHJvdXRlLl9sb2FkZWRJbmplY3RvclxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuYWJvcnRTaWduYWwuYWJvcnRlZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IodGhpcy5hYm9ydFNpZ25hbC5yZWFzb24pO1xuICAgICAgfVxuICAgICAgY29uc3Qgc2hvdWxkTG9hZFJlc3VsdCA9IGF3YWl0IGZpcnN0VmFsdWVGcm9tKHJ1bkNhbkxvYWRHdWFyZHMoaW5qZWN0b3IsIHJvdXRlLCBzZWdtZW50cywgdGhpcy51cmxTZXJpYWxpemVyLCB0aGlzLmFib3J0U2lnbmFsKSk7XG4gICAgICBpZiAoc2hvdWxkTG9hZFJlc3VsdCkge1xuICAgICAgICBjb25zdCBjZmcgPSBhd2FpdCB0aGlzLmNvbmZpZ0xvYWRlci5sb2FkQ2hpbGRyZW4oaW5qZWN0b3IsIHJvdXRlKTtcbiAgICAgICAgcm91dGUuX2xvYWRlZFJvdXRlcyA9IGNmZy5yb3V0ZXM7XG4gICAgICAgIHJvdXRlLl9sb2FkZWRJbmplY3RvciA9IGNmZy5pbmplY3RvcjtcbiAgICAgICAgcm91dGUuX2xvYWRlZE5nTW9kdWxlRmFjdG9yeSA9IGNmZy5mYWN0b3J5O1xuICAgICAgICByZXR1cm4gY2ZnO1xuICAgICAgfVxuICAgICAgdGhyb3cgY2FuTG9hZEZhaWxzKHJvdXRlKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIHJvdXRlczogW10sXG4gICAgICBpbmplY3RvclxuICAgIH07XG4gIH1cbn1cbmZ1bmN0aW9uIHNvcnRBY3RpdmF0ZWRSb3V0ZVNuYXBzaG90cyhub2Rlcykge1xuICBub2Rlcy5zb3J0KChhLCBiKSA9PiB7XG4gICAgaWYgKGEudmFsdWUub3V0bGV0ID09PSBQUklNQVJZX09VVExFVCkgcmV0dXJuIC0xO1xuICAgIGlmIChiLnZhbHVlLm91dGxldCA9PT0gUFJJTUFSWV9PVVRMRVQpIHJldHVybiAxO1xuICAgIHJldHVybiBhLnZhbHVlLm91dGxldC5sb2NhbGVDb21wYXJlKGIudmFsdWUub3V0bGV0KTtcbiAgfSk7XG59XG5mdW5jdGlvbiBoYXNFbXB0eVBhdGhDb25maWcobm9kZSkge1xuICBjb25zdCBjb25maWcgPSBub2RlLnZhbHVlLnJvdXRlQ29uZmlnO1xuICByZXR1cm4gY29uZmlnICYmIGNvbmZpZy5wYXRoID09PSAnJztcbn1cbmZ1bmN0aW9uIG1lcmdlRW1wdHlQYXRoTWF0Y2hlcyhub2Rlcykge1xuICBjb25zdCByZXN1bHQgPSBbXTtcbiAgY29uc3QgbWVyZ2VkTm9kZXMgPSBuZXcgU2V0KCk7XG4gIGZvciAoY29uc3Qgbm9kZSBvZiBub2Rlcykge1xuICAgIGlmICghaGFzRW1wdHlQYXRoQ29uZmlnKG5vZGUpKSB7XG4gICAgICByZXN1bHQucHVzaChub2RlKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBkdXBsaWNhdGVFbXB0eVBhdGhOb2RlID0gcmVzdWx0LmZpbmQocmVzdWx0Tm9kZSA9PiBub2RlLnZhbHVlLnJvdXRlQ29uZmlnID09PSByZXN1bHROb2RlLnZhbHVlLnJvdXRlQ29uZmlnKTtcbiAgICBpZiAoZHVwbGljYXRlRW1wdHlQYXRoTm9kZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBkdXBsaWNhdGVFbXB0eVBhdGhOb2RlLmNoaWxkcmVuLnB1c2goLi4ubm9kZS5jaGlsZHJlbik7XG4gICAgICBtZXJnZWROb2Rlcy5hZGQoZHVwbGljYXRlRW1wdHlQYXRoTm9kZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdC5wdXNoKG5vZGUpO1xuICAgIH1cbiAgfVxuICBmb3IgKGNvbnN0IG1lcmdlZE5vZGUgb2YgbWVyZ2VkTm9kZXMpIHtcbiAgICBjb25zdCBtZXJnZWRDaGlsZHJlbiA9IG1lcmdlRW1wdHlQYXRoTWF0Y2hlcyhtZXJnZWROb2RlLmNoaWxkcmVuKTtcbiAgICByZXN1bHQucHVzaChuZXcgVHJlZU5vZGUobWVyZ2VkTm9kZS52YWx1ZSwgbWVyZ2VkQ2hpbGRyZW4pKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0LmZpbHRlcihuID0+ICFtZXJnZWROb2Rlcy5oYXMobikpO1xufVxuZnVuY3Rpb24gY2hlY2tPdXRsZXROYW1lVW5pcXVlbmVzcyhub2Rlcykge1xuICBjb25zdCBuYW1lcyA9IHt9O1xuICBub2Rlcy5mb3JFYWNoKG4gPT4ge1xuICAgIGNvbnN0IHJvdXRlV2l0aFNhbWVPdXRsZXROYW1lID0gbmFtZXNbbi52YWx1ZS5vdXRsZXRdO1xuICAgIGlmIChyb3V0ZVdpdGhTYW1lT3V0bGV0TmFtZSkge1xuICAgICAgY29uc3QgcCA9IHJvdXRlV2l0aFNhbWVPdXRsZXROYW1lLnVybC5tYXAocyA9PiBzLnRvU3RyaW5nKCkpLmpvaW4oJy8nKTtcbiAgICAgIGNvbnN0IGMgPSBuLnZhbHVlLnVybC5tYXAocyA9PiBzLnRvU3RyaW5nKCkpLmpvaW4oJy8nKTtcbiAgICAgIHRocm93IG5ldyBfUnVudGltZUVycm9yKDQwMDYsICh0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUpICYmIGBUd28gc2VnbWVudHMgY2Fubm90IGhhdmUgdGhlIHNhbWUgb3V0bGV0IG5hbWU6ICcke3B9JyBhbmQgJyR7Y30nLmApO1xuICAgIH1cbiAgICBuYW1lc1tuLnZhbHVlLm91dGxldF0gPSBuLnZhbHVlO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGdldERhdGEocm91dGUpIHtcbiAgcmV0dXJuIHJvdXRlLmRhdGEgfHwge307XG59XG5mdW5jdGlvbiBnZXRSZXNvbHZlKHJvdXRlKSB7XG4gIHJldHVybiByb3V0ZS5yZXNvbHZlIHx8IHt9O1xufVxuZnVuY3Rpb24gcmVjb2duaXplKGluamVjdG9yLCBjb25maWdMb2FkZXIsIHJvb3RDb21wb25lbnRUeXBlLCBjb25maWcsIHNlcmlhbGl6ZXIsIHBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3ksIGFib3J0U2lnbmFsKSB7XG4gIHJldHVybiBtZXJnZU1hcChhc3luYyB0ID0+IHtcbiAgICBjb25zdCB7XG4gICAgICBzdGF0ZTogdGFyZ2V0U25hcHNob3QsXG4gICAgICB0cmVlOiB1cmxBZnRlclJlZGlyZWN0c1xuICAgIH0gPSBhd2FpdCByZWNvZ25pemUkMShpbmplY3RvciwgY29uZmlnTG9hZGVyLCByb290Q29tcG9uZW50VHlwZSwgY29uZmlnLCB0LmV4dHJhY3RlZFVybCwgc2VyaWFsaXplciwgcGFyYW1zSW5oZXJpdGFuY2VTdHJhdGVneSwgYWJvcnRTaWduYWwpO1xuICAgIHJldHVybiB7XG4gICAgICAuLi50LFxuICAgICAgdGFyZ2V0U25hcHNob3QsXG4gICAgICB1cmxBZnRlclJlZGlyZWN0c1xuICAgIH07XG4gIH0pO1xufVxuZnVuY3Rpb24gcmVzb2x2ZURhdGEocGFyYW1zSW5oZXJpdGFuY2VTdHJhdGVneSkge1xuICByZXR1cm4gbWVyZ2VNYXAodCA9PiB7XG4gICAgY29uc3Qge1xuICAgICAgdGFyZ2V0U25hcHNob3QsXG4gICAgICBndWFyZHM6IHtcbiAgICAgICAgY2FuQWN0aXZhdGVDaGVja3NcbiAgICAgIH1cbiAgICB9ID0gdDtcbiAgICBpZiAoIWNhbkFjdGl2YXRlQ2hlY2tzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIG9mKHQpO1xuICAgIH1cbiAgICBjb25zdCByb3V0ZXNXaXRoUmVzb2x2ZXJzVG9SdW4gPSBuZXcgU2V0KGNhbkFjdGl2YXRlQ2hlY2tzLm1hcChjaGVjayA9PiBjaGVjay5yb3V0ZSkpO1xuICAgIGNvbnN0IHJvdXRlc05lZWRpbmdEYXRhVXBkYXRlcyA9IG5ldyBTZXQoKTtcbiAgICBmb3IgKGNvbnN0IHJvdXRlIG9mIHJvdXRlc1dpdGhSZXNvbHZlcnNUb1J1bikge1xuICAgICAgaWYgKHJvdXRlc05lZWRpbmdEYXRhVXBkYXRlcy5oYXMocm91dGUpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCBuZXdSb3V0ZSBvZiBmbGF0dGVuUm91dGVUcmVlKHJvdXRlKSkge1xuICAgICAgICByb3V0ZXNOZWVkaW5nRGF0YVVwZGF0ZXMuYWRkKG5ld1JvdXRlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IHJvdXRlc1Byb2Nlc3NlZCA9IDA7XG4gICAgcmV0dXJuIGZyb20ocm91dGVzTmVlZGluZ0RhdGFVcGRhdGVzKS5waXBlKGNvbmNhdE1hcChyb3V0ZSA9PiB7XG4gICAgICBpZiAocm91dGVzV2l0aFJlc29sdmVyc1RvUnVuLmhhcyhyb3V0ZSkpIHtcbiAgICAgICAgcmV0dXJuIHJ1blJlc29sdmUocm91dGUsIHRhcmdldFNuYXBzaG90LCBwYXJhbXNJbmhlcml0YW5jZVN0cmF0ZWd5KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJvdXRlLmRhdGEgPSBnZXRJbmhlcml0ZWQocm91dGUsIHJvdXRlLnBhcmVudCwgcGFyYW1zSW5oZXJpdGFuY2VTdHJhdGVneSkucmVzb2x2ZTtcbiAgICAgICAgcmV0dXJuIG9mKHZvaWQgMCk7XG4gICAgICB9XG4gICAgfSksIHRhcCgoKSA9PiByb3V0ZXNQcm9jZXNzZWQrKyksIHRha2VMYXN0KDEpLCBtZXJnZU1hcChfID0+IHJvdXRlc1Byb2Nlc3NlZCA9PT0gcm91dGVzTmVlZGluZ0RhdGFVcGRhdGVzLnNpemUgPyBvZih0KSA6IEVNUFRZKSk7XG4gIH0pO1xufVxuZnVuY3Rpb24gZmxhdHRlblJvdXRlVHJlZShyb3V0ZSkge1xuICBjb25zdCBkZXNjZW5kYW50cyA9IHJvdXRlLmNoaWxkcmVuLm1hcChjaGlsZCA9PiBmbGF0dGVuUm91dGVUcmVlKGNoaWxkKSkuZmxhdCgpO1xuICByZXR1cm4gW3JvdXRlLCAuLi5kZXNjZW5kYW50c107XG59XG5mdW5jdGlvbiBydW5SZXNvbHZlKGZ1dHVyZUFSUywgZnV0dXJlUlNTLCBwYXJhbXNJbmhlcml0YW5jZVN0cmF0ZWd5KSB7XG4gIGNvbnN0IGNvbmZpZyA9IGZ1dHVyZUFSUy5yb3V0ZUNvbmZpZztcbiAgY29uc3QgcmVzb2x2ZSA9IGZ1dHVyZUFSUy5fcmVzb2x2ZTtcbiAgaWYgKGNvbmZpZz8udGl0bGUgIT09IHVuZGVmaW5lZCAmJiAhaGFzU3RhdGljVGl0bGUoY29uZmlnKSkge1xuICAgIHJlc29sdmVbUm91dGVUaXRsZUtleV0gPSBjb25maWcudGl0bGU7XG4gIH1cbiAgcmV0dXJuIGRlZmVyKCgpID0+IHtcbiAgICBmdXR1cmVBUlMuZGF0YSA9IGdldEluaGVyaXRlZChmdXR1cmVBUlMsIGZ1dHVyZUFSUy5wYXJlbnQsIHBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3kpLnJlc29sdmU7XG4gICAgcmV0dXJuIHJlc29sdmVOb2RlKHJlc29sdmUsIGZ1dHVyZUFSUywgZnV0dXJlUlNTKS5waXBlKG1hcChyZXNvbHZlZERhdGEgPT4ge1xuICAgICAgZnV0dXJlQVJTLl9yZXNvbHZlZERhdGEgPSByZXNvbHZlZERhdGE7XG4gICAgICBmdXR1cmVBUlMuZGF0YSA9IHtcbiAgICAgICAgLi4uZnV0dXJlQVJTLmRhdGEsXG4gICAgICAgIC4uLnJlc29sdmVkRGF0YVxuICAgICAgfTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0pKTtcbiAgfSk7XG59XG5mdW5jdGlvbiByZXNvbHZlTm9kZShyZXNvbHZlLCBmdXR1cmVBUlMsIGZ1dHVyZVJTUykge1xuICBjb25zdCBrZXlzID0gZ2V0RGF0YUtleXMocmVzb2x2ZSk7XG4gIGlmIChrZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBvZih7fSk7XG4gIH1cbiAgY29uc3QgZGF0YSA9IHt9O1xuICByZXR1cm4gZnJvbShrZXlzKS5waXBlKG1lcmdlTWFwKGtleSA9PiBnZXRSZXNvbHZlcihyZXNvbHZlW2tleV0sIGZ1dHVyZUFSUywgZnV0dXJlUlNTKS5waXBlKGZpcnN0KCksIHRhcCh2YWx1ZSA9PiB7XG4gICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgUmVkaXJlY3RDb21tYW5kKSB7XG4gICAgICB0aHJvdyByZWRpcmVjdGluZ05hdmlnYXRpb25FcnJvcihuZXcgRGVmYXVsdFVybFNlcmlhbGl6ZXIoKSwgdmFsdWUpO1xuICAgIH1cbiAgICBkYXRhW2tleV0gPSB2YWx1ZTtcbiAgfSkpKSwgdGFrZUxhc3QoMSksIG1hcCgoKSA9PiBkYXRhKSwgY2F0Y2hFcnJvcihlID0+IGlzRW1wdHlFcnJvcihlKSA/IEVNUFRZIDogdGhyb3dFcnJvcihlKSkpO1xufVxuZnVuY3Rpb24gZ2V0UmVzb2x2ZXIoaW5qZWN0aW9uVG9rZW4sIGZ1dHVyZUFSUywgZnV0dXJlUlNTKSB7XG4gIGNvbnN0IGNsb3Nlc3RJbmplY3RvciA9IGZ1dHVyZUFSUy5fZW52aXJvbm1lbnRJbmplY3RvcjtcbiAgY29uc3QgcmVzb2x2ZXIgPSBnZXRUb2tlbk9yRnVuY3Rpb25JZGVudGl0eShpbmplY3Rpb25Ub2tlbiwgY2xvc2VzdEluamVjdG9yKTtcbiAgY29uc3QgcmVzb2x2ZXJWYWx1ZSA9IHJlc29sdmVyLnJlc29sdmUgPyByZXNvbHZlci5yZXNvbHZlKGZ1dHVyZUFSUywgZnV0dXJlUlNTKSA6IHJ1bkluSW5qZWN0aW9uQ29udGV4dChjbG9zZXN0SW5qZWN0b3IsICgpID0+IHJlc29sdmVyKGZ1dHVyZUFSUywgZnV0dXJlUlNTKSk7XG4gIHJldHVybiB3cmFwSW50b09ic2VydmFibGUocmVzb2x2ZXJWYWx1ZSk7XG59XG5mdW5jdGlvbiBzd2l0Y2hUYXAobmV4dCkge1xuICByZXR1cm4gc3dpdGNoTWFwKHYgPT4ge1xuICAgIGNvbnN0IG5leHRSZXN1bHQgPSBuZXh0KHYpO1xuICAgIGlmIChuZXh0UmVzdWx0KSB7XG4gICAgICByZXR1cm4gZnJvbShuZXh0UmVzdWx0KS5waXBlKG1hcCgoKSA9PiB2KSk7XG4gICAgfVxuICAgIHJldHVybiBvZih2KTtcbiAgfSk7XG59XG5jbGFzcyBUaXRsZVN0cmF0ZWd5IHtcbiAgYnVpbGRUaXRsZShzbmFwc2hvdCkge1xuICAgIGxldCBwYWdlVGl0bGU7XG4gICAgbGV0IHJvdXRlID0gc25hcHNob3Qucm9vdDtcbiAgICB3aGlsZSAocm91dGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgcGFnZVRpdGxlID0gdGhpcy5nZXRSZXNvbHZlZFRpdGxlRm9yUm91dGUocm91dGUpID8/IHBhZ2VUaXRsZTtcbiAgICAgIHJvdXRlID0gcm91dGUuY2hpbGRyZW4uZmluZChjaGlsZCA9PiBjaGlsZC5vdXRsZXQgPT09IFBSSU1BUllfT1VUTEVUKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhZ2VUaXRsZTtcbiAgfVxuICBnZXRSZXNvbHZlZFRpdGxlRm9yUm91dGUoc25hcHNob3QpIHtcbiAgICByZXR1cm4gc25hcHNob3QuZGF0YVtSb3V0ZVRpdGxlS2V5XTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBUaXRsZVN0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBUaXRsZVN0cmF0ZWd5KSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBUaXRsZVN0cmF0ZWd5LFxuICAgIGZhY3Rvcnk6ICgpID0+ICgoKSA9PiBpbmplY3QoRGVmYXVsdFRpdGxlU3RyYXRlZ3kpKSgpXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoVGl0bGVTdHJhdGVneSwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBmYWN0b3J5OiAoKSA9PiBpbmplY3QoRGVmYXVsdFRpdGxlU3RyYXRlZ3kpXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIERlZmF1bHRUaXRsZVN0cmF0ZWd5IGV4dGVuZHMgVGl0bGVTdHJhdGVneSB7XG4gIHRpdGxlO1xuICBjb25zdHJ1Y3Rvcih0aXRsZSkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy50aXRsZSA9IHRpdGxlO1xuICB9XG4gIHVwZGF0ZVRpdGxlKHNuYXBzaG90KSB7XG4gICAgY29uc3QgdGl0bGUgPSB0aGlzLmJ1aWxkVGl0bGUoc25hcHNob3QpO1xuICAgIGlmICh0aXRsZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLnRpdGxlLnNldFRpdGxlKHRpdGxlKTtcbiAgICB9XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gRGVmYXVsdFRpdGxlU3RyYXRlZ3lfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBEZWZhdWx0VGl0bGVTdHJhdGVneSkoaTAuybXJtWluamVjdChpMS5UaXRsZSkpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBEZWZhdWx0VGl0bGVTdHJhdGVneSxcbiAgICBmYWN0b3J5OiBEZWZhdWx0VGl0bGVTdHJhdGVneS7JtWZhYyxcbiAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShEZWZhdWx0VGl0bGVTdHJhdGVneSwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBpMS5UaXRsZVxuICB9XSwgbnVsbCk7XG59KSgpO1xuY29uc3QgUk9VVEVSX0NPTkZJR1VSQVRJT04gPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ3JvdXRlciBjb25maWcnIDogJycsIHtcbiAgZmFjdG9yeTogKCkgPT4gKHt9KVxufSk7XG5jb25zdCBST1VURVMgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ1JPVVRFUycgOiAnJyk7XG5jbGFzcyBSb3V0ZXJDb25maWdMb2FkZXIge1xuICBjb21wb25lbnRMb2FkZXJzID0gbmV3IFdlYWtNYXAoKTtcbiAgY2hpbGRyZW5Mb2FkZXJzID0gbmV3IFdlYWtNYXAoKTtcbiAgb25Mb2FkU3RhcnRMaXN0ZW5lcjtcbiAgb25Mb2FkRW5kTGlzdGVuZXI7XG4gIGNvbXBpbGVyID0gaW5qZWN0KENvbXBpbGVyKTtcbiAgYXN5bmMgbG9hZENvbXBvbmVudChpbmplY3Rvciwgcm91dGUpIHtcbiAgICBpZiAodGhpcy5jb21wb25lbnRMb2FkZXJzLmdldChyb3V0ZSkpIHtcbiAgICAgIHJldHVybiB0aGlzLmNvbXBvbmVudExvYWRlcnMuZ2V0KHJvdXRlKTtcbiAgICB9IGVsc2UgaWYgKHJvdXRlLl9sb2FkZWRDb21wb25lbnQpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUocm91dGUuX2xvYWRlZENvbXBvbmVudCk7XG4gICAgfVxuICAgIGlmICh0aGlzLm9uTG9hZFN0YXJ0TGlzdGVuZXIpIHtcbiAgICAgIHRoaXMub25Mb2FkU3RhcnRMaXN0ZW5lcihyb3V0ZSk7XG4gICAgfVxuICAgIGNvbnN0IGxvYWRlciA9IChhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBsb2FkZWQgPSBhd2FpdCB3cmFwSW50b1Byb21pc2UocnVuSW5JbmplY3Rpb25Db250ZXh0KGluamVjdG9yLCAoKSA9PiByb3V0ZS5sb2FkQ29tcG9uZW50KCkpKTtcbiAgICAgICAgY29uc3QgY29tcG9uZW50ID0gYXdhaXQgbWF5YmVSZXNvbHZlUmVzb3VyY2VzKF9tYXliZVVud3JhcERlZmF1bHRFeHBvcnQobG9hZGVkKSk7XG4gICAgICAgIGlmICh0aGlzLm9uTG9hZEVuZExpc3RlbmVyKSB7XG4gICAgICAgICAgdGhpcy5vbkxvYWRFbmRMaXN0ZW5lcihyb3V0ZSk7XG4gICAgICAgIH1cbiAgICAgICAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgYXNzZXJ0U3RhbmRhbG9uZShyb3V0ZS5wYXRoID8/ICcnLCBjb21wb25lbnQpO1xuICAgICAgICByb3V0ZS5fbG9hZGVkQ29tcG9uZW50ID0gY29tcG9uZW50O1xuICAgICAgICByZXR1cm4gY29tcG9uZW50O1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgdGhpcy5jb21wb25lbnRMb2FkZXJzLmRlbGV0ZShyb3V0ZSk7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICB0aGlzLmNvbXBvbmVudExvYWRlcnMuc2V0KHJvdXRlLCBsb2FkZXIpO1xuICAgIHJldHVybiBsb2FkZXI7XG4gIH1cbiAgbG9hZENoaWxkcmVuKHBhcmVudEluamVjdG9yLCByb3V0ZSkge1xuICAgIGlmICh0aGlzLmNoaWxkcmVuTG9hZGVycy5nZXQocm91dGUpKSB7XG4gICAgICByZXR1cm4gdGhpcy5jaGlsZHJlbkxvYWRlcnMuZ2V0KHJvdXRlKTtcbiAgICB9IGVsc2UgaWYgKHJvdXRlLl9sb2FkZWRSb3V0ZXMpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICByb3V0ZXM6IHJvdXRlLl9sb2FkZWRSb3V0ZXMsXG4gICAgICAgIGluamVjdG9yOiByb3V0ZS5fbG9hZGVkSW5qZWN0b3JcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAodGhpcy5vbkxvYWRTdGFydExpc3RlbmVyKSB7XG4gICAgICB0aGlzLm9uTG9hZFN0YXJ0TGlzdGVuZXIocm91dGUpO1xuICAgIH1cbiAgICBjb25zdCBsb2FkZXIgPSAoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgbG9hZENoaWxkcmVuKHJvdXRlLCB0aGlzLmNvbXBpbGVyLCBwYXJlbnRJbmplY3RvciwgdGhpcy5vbkxvYWRFbmRMaXN0ZW5lcik7XG4gICAgICAgIHJvdXRlLl9sb2FkZWRSb3V0ZXMgPSByZXN1bHQucm91dGVzO1xuICAgICAgICByb3V0ZS5fbG9hZGVkSW5qZWN0b3IgPSByZXN1bHQuaW5qZWN0b3I7XG4gICAgICAgIHJvdXRlLl9sb2FkZWROZ01vZHVsZUZhY3RvcnkgPSByZXN1bHQuZmFjdG9yeTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHRoaXMuY2hpbGRyZW5Mb2FkZXJzLmRlbGV0ZShyb3V0ZSk7XG4gICAgICB9XG4gICAgfSkoKTtcbiAgICB0aGlzLmNoaWxkcmVuTG9hZGVycy5zZXQocm91dGUsIGxvYWRlcik7XG4gICAgcmV0dXJuIGxvYWRlcjtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBSb3V0ZXJDb25maWdMb2FkZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFJvdXRlckNvbmZpZ0xvYWRlcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogUm91dGVyQ29uZmlnTG9hZGVyLFxuICAgIGZhY3Rvcnk6IFJvdXRlckNvbmZpZ0xvYWRlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJvdXRlckNvbmZpZ0xvYWRlciwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5hc3luYyBmdW5jdGlvbiBsb2FkQ2hpbGRyZW4ocm91dGUsIGNvbXBpbGVyLCBwYXJlbnRJbmplY3Rvciwgb25Mb2FkRW5kTGlzdGVuZXIpIHtcbiAgY29uc3QgbG9hZGVkID0gYXdhaXQgd3JhcEludG9Qcm9taXNlKHJ1bkluSW5qZWN0aW9uQ29udGV4dChwYXJlbnRJbmplY3RvciwgKCkgPT4gcm91dGUubG9hZENoaWxkcmVuKCkpKTtcbiAgY29uc3QgdCA9IGF3YWl0IG1heWJlUmVzb2x2ZVJlc291cmNlcyhfbWF5YmVVbndyYXBEZWZhdWx0RXhwb3J0KGxvYWRlZCkpO1xuICBsZXQgZmFjdG9yeU9yUm91dGVzO1xuICBpZiAodCBpbnN0YW5jZW9mIE5nTW9kdWxlRmFjdG9yeSB8fCBBcnJheS5pc0FycmF5KHQpKSB7XG4gICAgZmFjdG9yeU9yUm91dGVzID0gdDtcbiAgfSBlbHNlIHtcbiAgICBmYWN0b3J5T3JSb3V0ZXMgPSBhd2FpdCBjb21waWxlci5jb21waWxlTW9kdWxlQXN5bmModCk7XG4gIH1cbiAgaWYgKG9uTG9hZEVuZExpc3RlbmVyKSB7XG4gICAgb25Mb2FkRW5kTGlzdGVuZXIocm91dGUpO1xuICB9XG4gIGxldCBpbmplY3RvcjtcbiAgbGV0IHJhd1JvdXRlcztcbiAgbGV0IHJlcXVpcmVTdGFuZGFsb25lQ29tcG9uZW50cyA9IGZhbHNlO1xuICBsZXQgZmFjdG9yeSA9IHVuZGVmaW5lZDtcbiAgaWYgKEFycmF5LmlzQXJyYXkoZmFjdG9yeU9yUm91dGVzKSkge1xuICAgIHJhd1JvdXRlcyA9IGZhY3RvcnlPclJvdXRlcztcbiAgICByZXF1aXJlU3RhbmRhbG9uZUNvbXBvbmVudHMgPSB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGluamVjdG9yID0gZmFjdG9yeU9yUm91dGVzLmNyZWF0ZShwYXJlbnRJbmplY3RvcikuaW5qZWN0b3I7XG4gICAgZmFjdG9yeSA9IGZhY3RvcnlPclJvdXRlcztcbiAgICByYXdSb3V0ZXMgPSBpbmplY3Rvci5nZXQoUk9VVEVTLCBbXSwge1xuICAgICAgb3B0aW9uYWw6IHRydWUsXG4gICAgICBzZWxmOiB0cnVlXG4gICAgfSkuZmxhdCgpO1xuICB9XG4gIGNvbnN0IHJvdXRlcyA9IHJhd1JvdXRlcy5tYXAoc3RhbmRhcmRpemVDb25maWcpO1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiB2YWxpZGF0ZUNvbmZpZyhyb3V0ZXMsIHJvdXRlLnBhdGgsIHJlcXVpcmVTdGFuZGFsb25lQ29tcG9uZW50cyk7XG4gIHJldHVybiB7XG4gICAgcm91dGVzLFxuICAgIGluamVjdG9yLFxuICAgIGZhY3RvcnlcbiAgfTtcbn1cbmFzeW5jIGZ1bmN0aW9uIG1heWJlUmVzb2x2ZVJlc291cmNlcyh2YWx1ZSkge1xuICBpZiAoKHR5cGVvZiBuZ0ppdE1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nSml0TW9kZSkgJiYgdHlwZW9mIGZldGNoID09PSAnZnVuY3Rpb24nKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IF9yZXNvbHZlQ29tcG9uZW50UmVzb3VyY2VzKGZldGNoKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgfVxuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cbmNsYXNzIFVybEhhbmRsaW5nU3RyYXRlZ3kge1xuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBVcmxIYW5kbGluZ1N0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBVcmxIYW5kbGluZ1N0cmF0ZWd5KSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBVcmxIYW5kbGluZ1N0cmF0ZWd5LFxuICAgIGZhY3Rvcnk6ICgpID0+ICgoKSA9PiBpbmplY3QoRGVmYXVsdFVybEhhbmRsaW5nU3RyYXRlZ3kpKSgpXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoVXJsSGFuZGxpbmdTdHJhdGVneSwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBmYWN0b3J5OiAoKSA9PiBpbmplY3QoRGVmYXVsdFVybEhhbmRsaW5nU3RyYXRlZ3kpXG4gICAgfV1cbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIERlZmF1bHRVcmxIYW5kbGluZ1N0cmF0ZWd5IHtcbiAgc2hvdWxkUHJvY2Vzc1VybCh1cmwpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBleHRyYWN0KHVybCkge1xuICAgIHJldHVybiB1cmw7XG4gIH1cbiAgbWVyZ2UobmV3VXJsUGFydCwgd2hvbGVVcmwpIHtcbiAgICByZXR1cm4gbmV3VXJsUGFydDtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBEZWZhdWx0VXJsSGFuZGxpbmdTdHJhdGVneV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgRGVmYXVsdFVybEhhbmRsaW5nU3RyYXRlZ3kpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lU2VydmljZSh7XG4gICAgdG9rZW46IERlZmF1bHRVcmxIYW5kbGluZ1N0cmF0ZWd5LFxuICAgIGZhY3Rvcnk6IERlZmF1bHRVcmxIYW5kbGluZ1N0cmF0ZWd5Lsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoRGVmYXVsdFVybEhhbmRsaW5nU3RyYXRlZ3ksIFt7XG4gICAgdHlwZTogU2VydmljZVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY29uc3QgQ1JFQVRFX1ZJRVdfVFJBTlNJVElPTiA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAndmlldyB0cmFuc2l0aW9uIGhlbHBlcicgOiAnJyk7XG5jb25zdCBWSUVXX1RSQU5TSVRJT05fT1BUSU9OUyA9IG5ldyBJbmplY3Rpb25Ub2tlbih0eXBlb2YgbmdEZXZNb2RlICE9PSAndW5kZWZpbmVkJyAmJiBuZ0Rldk1vZGUgPyAndmlldyB0cmFuc2l0aW9uIG9wdGlvbnMnIDogJycpO1xuZnVuY3Rpb24gY3JlYXRlVmlld1RyYW5zaXRpb24oaW5qZWN0b3IsIGZyb20sIHRvKSB7XG4gIGNvbnN0IHRyYW5zaXRpb25PcHRpb25zID0gaW5qZWN0b3IuZ2V0KFZJRVdfVFJBTlNJVElPTl9PUFRJT05TKTtcbiAgY29uc3QgZG9jdW1lbnQgPSBpbmplY3Rvci5nZXQoRE9DVU1FTlQpO1xuICBpZiAoIWRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24gfHwgdHJhbnNpdGlvbk9wdGlvbnMuc2tpcE5leHRUcmFuc2l0aW9uKSB7XG4gICAgdHJhbnNpdGlvbk9wdGlvbnMuc2tpcE5leHRUcmFuc2l0aW9uID0gZmFsc2U7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlKSk7XG4gIH1cbiAgbGV0IHJlc29sdmVWaWV3VHJhbnNpdGlvblN0YXJ0ZWQ7XG4gIGNvbnN0IHZpZXdUcmFuc2l0aW9uU3RhcnRlZCA9IG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgIHJlc29sdmVWaWV3VHJhbnNpdGlvblN0YXJ0ZWQgPSByZXNvbHZlO1xuICB9KTtcbiAgY29uc3QgdHJhbnNpdGlvbiA9IGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oKCkgPT4ge1xuICAgIHJlc29sdmVWaWV3VHJhbnNpdGlvblN0YXJ0ZWQoKTtcbiAgICByZXR1cm4gY3JlYXRlUmVuZGVyUHJvbWlzZShpbmplY3Rvcik7XG4gIH0pO1xuICB0cmFuc2l0aW9uLnVwZGF0ZUNhbGxiYWNrRG9uZS5jYXRjaChlcnJvciA9PiB7XG4gICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgfVxuICB9KTtcbiAgdHJhbnNpdGlvbi5yZWFkeS5jYXRjaChlcnJvciA9PiB7XG4gICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgfVxuICB9KTtcbiAgdHJhbnNpdGlvbi5maW5pc2hlZC5jYXRjaChlcnJvciA9PiB7XG4gICAgaWYgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XG4gICAgfVxuICB9KTtcbiAgY29uc3Qge1xuICAgIG9uVmlld1RyYW5zaXRpb25DcmVhdGVkXG4gIH0gPSB0cmFuc2l0aW9uT3B0aW9ucztcbiAgaWYgKG9uVmlld1RyYW5zaXRpb25DcmVhdGVkKSB7XG4gICAgcnVuSW5JbmplY3Rpb25Db250ZXh0KGluamVjdG9yLCAoKSA9PiBvblZpZXdUcmFuc2l0aW9uQ3JlYXRlZCh7XG4gICAgICB0cmFuc2l0aW9uLFxuICAgICAgZnJvbSxcbiAgICAgIHRvXG4gICAgfSkpO1xuICB9XG4gIHJldHVybiB2aWV3VHJhbnNpdGlvblN0YXJ0ZWQ7XG59XG5mdW5jdGlvbiBjcmVhdGVSZW5kZXJQcm9taXNlKGluamVjdG9yKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICBhZnRlck5leHRSZW5kZXIoe1xuICAgICAgcmVhZDogKCkgPT4gc2V0VGltZW91dChyZXNvbHZlKVxuICAgIH0sIHtcbiAgICAgIGluamVjdG9yXG4gICAgfSk7XG4gIH0pO1xufVxuY29uc3QgQUNUSVZBVEVEX1JPVVRFX0lOSkVDVE9SX0ZFQVRVUkUgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ0FjdGl2YXRlZFJvdXRlIGluamVjdG9yIGZlYXR1cmUnIDogJycpO1xuY29uc3Qgbm9vcCA9ICgpID0+IHt9O1xuY29uc3QgTkFWSUdBVElPTl9FUlJPUl9IQU5ETEVSID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/ICduYXZpZ2F0aW9uIGVycm9yIGhhbmRsZXInIDogJycpO1xuY2xhc3MgTmF2aWdhdGlvblRyYW5zaXRpb25zIHtcbiAgY3VycmVudE5hdmlnYXRpb24gPSBzaWduYWwobnVsbCwge1xuICAgIC4uLihuZ0Rldk1vZGUgPyB7XG4gICAgICBkZWJ1Z05hbWU6IFwiY3VycmVudE5hdmlnYXRpb25cIlxuICAgIH0gOiB7fSksXG4gICAgZXF1YWw6ICgpID0+IGZhbHNlXG4gIH0pO1xuICBjdXJyZW50VHJhbnNpdGlvbiA9IG51bGw7XG4gIGxhc3RTdWNjZXNzZnVsTmF2aWdhdGlvbiA9IHNpZ25hbChudWxsLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwibGFzdFN1Y2Nlc3NmdWxOYXZpZ2F0aW9uXCJcbiAgfV0gOiBbXSkpO1xuICBldmVudHMgPSBuZXcgU3ViamVjdCgpO1xuICB0cmFuc2l0aW9uQWJvcnRXaXRoRXJyb3JTdWJqZWN0ID0gbmV3IFN1YmplY3QoKTtcbiAgY29uZmlnTG9hZGVyID0gaW5qZWN0KFJvdXRlckNvbmZpZ0xvYWRlcik7XG4gIGVudmlyb25tZW50SW5qZWN0b3IgPSBpbmplY3QoRW52aXJvbm1lbnRJbmplY3Rvcik7XG4gIGRlc3Ryb3lSZWYgPSBpbmplY3QoRGVzdHJveVJlZik7XG4gIHVybFNlcmlhbGl6ZXIgPSBpbmplY3QoVXJsU2VyaWFsaXplcik7XG4gIHJvb3RDb250ZXh0cyA9IGluamVjdChDaGlsZHJlbk91dGxldENvbnRleHRzKTtcbiAgbG9jYXRpb24gPSBpbmplY3QoTG9jYXRpb24pO1xuICBpbnB1dEJpbmRpbmdFbmFibGVkID0gaW5qZWN0KElOUFVUX0JJTkRFUiwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pICE9PSBudWxsO1xuICB0aXRsZVN0cmF0ZWd5ID0gaW5qZWN0KFRpdGxlU3RyYXRlZ3kpO1xuICBvcHRpb25zID0gaW5qZWN0KFJPVVRFUl9DT05GSUdVUkFUSU9OLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSkgfHwge307XG4gIHBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3kgPSB0aGlzLm9wdGlvbnMucGFyYW1zSW5oZXJpdGFuY2VTdHJhdGVneSB8fCBERUZBVUxUX1BBUkFNU19JTkhFUklUQU5DRV9TVFJBVEVHWTtcbiAgdXJsSGFuZGxpbmdTdHJhdGVneSA9IGluamVjdChVcmxIYW5kbGluZ1N0cmF0ZWd5KTtcbiAgY3JlYXRlVmlld1RyYW5zaXRpb24gPSBpbmplY3QoQ1JFQVRFX1ZJRVdfVFJBTlNJVElPTiwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICBuYXZpZ2F0aW9uRXJyb3JIYW5kbGVyID0gaW5qZWN0KE5BVklHQVRJT05fRVJST1JfSEFORExFUiwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICBhY3RpdmF0ZWRSb3V0ZUluamVjdG9yRmVhdHVyZSA9IGluamVjdChBQ1RJVkFURURfUk9VVEVfSU5KRUNUT1JfRkVBVFVSRSwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICBuYXZpZ2F0aW9uSWQgPSAwO1xuICBnZXQgaGFzUmVxdWVzdGVkTmF2aWdhdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5uYXZpZ2F0aW9uSWQgIT09IDA7XG4gIH1cbiAgdHJhbnNpdGlvbnM7XG4gIGFmdGVyUHJlYWN0aXZhdGlvbiA9ICgpID0+IG9mKHZvaWQgMCk7XG4gIHJvb3RDb21wb25lbnRUeXBlID0gbnVsbDtcbiAgZGVzdHJveWVkID0gZmFsc2U7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIGNvbnN0IG9uTG9hZFN0YXJ0ID0gciA9PiB0aGlzLmV2ZW50cy5uZXh0KG5ldyBSb3V0ZUNvbmZpZ0xvYWRTdGFydChyKSk7XG4gICAgY29uc3Qgb25Mb2FkRW5kID0gciA9PiB0aGlzLmV2ZW50cy5uZXh0KG5ldyBSb3V0ZUNvbmZpZ0xvYWRFbmQocikpO1xuICAgIHRoaXMuY29uZmlnTG9hZGVyLm9uTG9hZEVuZExpc3RlbmVyID0gb25Mb2FkRW5kO1xuICAgIHRoaXMuY29uZmlnTG9hZGVyLm9uTG9hZFN0YXJ0TGlzdGVuZXIgPSBvbkxvYWRTdGFydDtcbiAgICB0aGlzLmRlc3Ryb3lSZWYub25EZXN0cm95KCgpID0+IHtcbiAgICAgIHRoaXMuZGVzdHJveWVkID0gdHJ1ZTtcbiAgICB9KTtcbiAgfVxuICBjb21wbGV0ZSgpIHtcbiAgICB0aGlzLnRyYW5zaXRpb25zPy5jb21wbGV0ZSgpO1xuICB9XG4gIGhhbmRsZU5hdmlnYXRpb25SZXF1ZXN0KHJlcXVlc3QpIHtcbiAgICBjb25zdCBpZCA9ICsrdGhpcy5uYXZpZ2F0aW9uSWQ7XG4gICAgdW50cmFja2VkKCgpID0+IHtcbiAgICAgIHRoaXMudHJhbnNpdGlvbnM/Lm5leHQoe1xuICAgICAgICAuLi5yZXF1ZXN0LFxuICAgICAgICBleHRyYWN0ZWRVcmw6IHRoaXMudXJsSGFuZGxpbmdTdHJhdGVneS5leHRyYWN0KHJlcXVlc3QucmF3VXJsKSxcbiAgICAgICAgdGFyZ2V0U25hcHNob3Q6IG51bGwsXG4gICAgICAgIHRhcmdldFJvdXRlclN0YXRlOiBudWxsLFxuICAgICAgICBndWFyZHM6IHtcbiAgICAgICAgICBjYW5BY3RpdmF0ZUNoZWNrczogW10sXG4gICAgICAgICAgY2FuRGVhY3RpdmF0ZUNoZWNrczogW11cbiAgICAgICAgfSxcbiAgICAgICAgZ3VhcmRzUmVzdWx0OiBudWxsLFxuICAgICAgICBpZCxcbiAgICAgICAgcm91dGVzUmVjb2duaXplSGFuZGxlcjoge30sXG4gICAgICAgIGJlZm9yZUFjdGl2YXRlSGFuZGxlcjoge31cbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG4gIHNldHVwTmF2aWdhdGlvbnMocm91dGVyKSB7XG4gICAgdGhpcy50cmFuc2l0aW9ucyA9IG5ldyBCZWhhdmlvclN1YmplY3QobnVsbCk7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNpdGlvbnMucGlwZShmaWx0ZXIodCA9PiB0ICE9PSBudWxsKSwgc3dpdGNoTWFwKG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUgPT4ge1xuICAgICAgbGV0IGFib3J0YWJsZSA9IHRydWU7XG4gICAgICBsZXQgY29tcGxldGVkT3JBYm9ydGVkID0gZmFsc2U7XG4gICAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICBjb25zdCBzaG91bGRDb250aW51ZU5hdmlnYXRpb24gPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiAhY29tcGxldGVkT3JBYm9ydGVkICYmIHRoaXMuY3VycmVudFRyYW5zaXRpb24/LmlkID09PSBvdmVyYWxsVHJhbnNpdGlvblN0YXRlLmlkO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBvZihvdmVyYWxsVHJhbnNpdGlvblN0YXRlKS5waXBlKHN3aXRjaE1hcCh0ID0+IHtcbiAgICAgICAgaWYgKHRoaXMubmF2aWdhdGlvbklkID4gb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5pZCkge1xuICAgICAgICAgIGNvbnN0IGNhbmNlbGxhdGlvblJlYXNvbiA9IHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IGBOYXZpZ2F0aW9uIElEICR7b3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5pZH0gaXMgbm90IGVxdWFsIHRvIHRoZSBjdXJyZW50IG5hdmlnYXRpb24gaWQgJHt0aGlzLm5hdmlnYXRpb25JZH1gIDogJyc7XG4gICAgICAgICAgdGhpcy5jYW5jZWxOYXZpZ2F0aW9uVHJhbnNpdGlvbihvdmVyYWxsVHJhbnNpdGlvblN0YXRlLCBjYW5jZWxsYXRpb25SZWFzb24sIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLlN1cGVyc2VkZWRCeU5ld05hdmlnYXRpb24pO1xuICAgICAgICAgIHJldHVybiBFTVBUWTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmN1cnJlbnRUcmFuc2l0aW9uID0gb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZTtcbiAgICAgICAgY29uc3QgbGFzdFN1Y2Nlc3NmdWxOYXZpZ2F0aW9uID0gdGhpcy5sYXN0U3VjY2Vzc2Z1bE5hdmlnYXRpb24oKTtcbiAgICAgICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbi5zZXQoe1xuICAgICAgICAgIGlkOiB0LmlkLFxuICAgICAgICAgIGluaXRpYWxVcmw6IHQucmF3VXJsLFxuICAgICAgICAgIGV4dHJhY3RlZFVybDogdC5leHRyYWN0ZWRVcmwsXG4gICAgICAgICAgdGFyZ2V0QnJvd3NlclVybDogdHlwZW9mIHQuZXh0cmFzLmJyb3dzZXJVcmwgPT09ICdzdHJpbmcnID8gdGhpcy51cmxTZXJpYWxpemVyLnBhcnNlKHQuZXh0cmFzLmJyb3dzZXJVcmwpIDogdC5leHRyYXMuYnJvd3NlclVybCxcbiAgICAgICAgICB0cmlnZ2VyOiB0LnNvdXJjZSxcbiAgICAgICAgICBleHRyYXM6IHQuZXh0cmFzLFxuICAgICAgICAgIHByZXZpb3VzTmF2aWdhdGlvbjogIWxhc3RTdWNjZXNzZnVsTmF2aWdhdGlvbiA/IG51bGwgOiB7XG4gICAgICAgICAgICAuLi5sYXN0U3VjY2Vzc2Z1bE5hdmlnYXRpb24sXG4gICAgICAgICAgICBwcmV2aW91c05hdmlnYXRpb246IG51bGxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGFib3J0OiAoKSA9PiBhYm9ydENvbnRyb2xsZXIuYWJvcnQoKSxcbiAgICAgICAgICByb3V0ZXNSZWNvZ25pemVIYW5kbGVyOiB0LnJvdXRlc1JlY29nbml6ZUhhbmRsZXIsXG4gICAgICAgICAgYmVmb3JlQWN0aXZhdGVIYW5kbGVyOiB0LmJlZm9yZUFjdGl2YXRlSGFuZGxlclxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3QgdXJsVHJhbnNpdGlvbiA9ICFyb3V0ZXIubmF2aWdhdGVkIHx8IHRoaXMuaXNVcGRhdGluZ0ludGVybmFsU3RhdGUoKSB8fCB0aGlzLmlzVXBkYXRlZEJyb3dzZXJVcmwoKTtcbiAgICAgICAgY29uc3Qgb25TYW1lVXJsTmF2aWdhdGlvbiA9IHQuZXh0cmFzLm9uU2FtZVVybE5hdmlnYXRpb24gPz8gcm91dGVyLm9uU2FtZVVybE5hdmlnYXRpb247XG4gICAgICAgIGlmICghdXJsVHJhbnNpdGlvbiAmJiBvblNhbWVVcmxOYXZpZ2F0aW9uICE9PSAncmVsb2FkJykge1xuICAgICAgICAgIGNvbnN0IHJlYXNvbiA9IHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IGBOYXZpZ2F0aW9uIHRvICR7dC5yYXdVcmx9IHdhcyBpZ25vcmVkIGJlY2F1c2UgaXQgaXMgdGhlIHNhbWUgYXMgdGhlIGN1cnJlbnQgUm91dGVyIFVSTC5gIDogJyc7XG4gICAgICAgICAgdGhpcy5ldmVudHMubmV4dChuZXcgTmF2aWdhdGlvblNraXBwZWQodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LnJhd1VybCksIHJlYXNvbiwgTmF2aWdhdGlvblNraXBwZWRDb2RlLklnbm9yZWRTYW1lVXJsTmF2aWdhdGlvbikpO1xuICAgICAgICAgIHQucmVzb2x2ZShmYWxzZSk7XG4gICAgICAgICAgcmV0dXJuIEVNUFRZO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLnVybEhhbmRsaW5nU3RyYXRlZ3kuc2hvdWxkUHJvY2Vzc1VybCh0LnJhd1VybCkpIHtcbiAgICAgICAgICByZXR1cm4gb2YodCkucGlwZShzd2l0Y2hNYXAodCA9PiB7XG4gICAgICAgICAgICB0aGlzLmV2ZW50cy5uZXh0KG5ldyBOYXZpZ2F0aW9uU3RhcnQodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LmV4dHJhY3RlZFVybCksIHQuc291cmNlLCB0LnJlc3RvcmVkU3RhdGUpKTtcbiAgICAgICAgICAgIGlmICh0LmlkICE9PSB0aGlzLm5hdmlnYXRpb25JZCkge1xuICAgICAgICAgICAgICByZXR1cm4gRU1QVFk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHQpO1xuICAgICAgICAgIH0pLCByZWNvZ25pemUodGhpcy5lbnZpcm9ubWVudEluamVjdG9yLCB0aGlzLmNvbmZpZ0xvYWRlciwgdGhpcy5yb290Q29tcG9uZW50VHlwZSwgcm91dGVyLmNvbmZpZywgdGhpcy51cmxTZXJpYWxpemVyLCB0aGlzLnBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3ksIGFib3J0Q29udHJvbGxlci5zaWduYWwpLCB0YXAodCA9PiB7XG4gICAgICAgICAgICBvdmVyYWxsVHJhbnNpdGlvblN0YXRlLnRhcmdldFNuYXBzaG90ID0gdC50YXJnZXRTbmFwc2hvdDtcbiAgICAgICAgICAgIG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUudXJsQWZ0ZXJSZWRpcmVjdHMgPSB0LnVybEFmdGVyUmVkaXJlY3RzO1xuICAgICAgICAgICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbi51cGRhdGUobmF2ID0+IHtcbiAgICAgICAgICAgICAgbmF2LmZpbmFsVXJsID0gdC51cmxBZnRlclJlZGlyZWN0cztcbiAgICAgICAgICAgICAgcmV0dXJuIG5hdjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5ldmVudHMubmV4dChuZXcgQmVmb3JlUm91dGVzUmVjb2duaXplZCgpKTtcbiAgICAgICAgICB9KSwgc3dpdGNoTWFwKHZhbHVlID0+IGZyb20ob3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5yb3V0ZXNSZWNvZ25pemVIYW5kbGVyLmRlZmVycmVkSGFuZGxlID8/IG9mKHZvaWQgMCkpLnBpcGUobWFwKCgpID0+IHZhbHVlKSkpLCB0YXAoKCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgcm91dGVzUmVjb2duaXplZCA9IG5ldyBSb3V0ZXNSZWNvZ25pemVkKHQuaWQsIHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodC5leHRyYWN0ZWRVcmwpLCB0aGlzLnVybFNlcmlhbGl6ZXIuc2VyaWFsaXplKHQudXJsQWZ0ZXJSZWRpcmVjdHMpLCB0LnRhcmdldFNuYXBzaG90KTtcbiAgICAgICAgICAgIHRoaXMuZXZlbnRzLm5leHQocm91dGVzUmVjb2duaXplZCk7XG4gICAgICAgICAgfSkpO1xuICAgICAgICB9IGVsc2UgaWYgKHVybFRyYW5zaXRpb24gJiYgdGhpcy51cmxIYW5kbGluZ1N0cmF0ZWd5LnNob3VsZFByb2Nlc3NVcmwodC5jdXJyZW50UmF3VXJsKSkge1xuICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgZXh0cmFjdGVkVXJsLFxuICAgICAgICAgICAgc291cmNlLFxuICAgICAgICAgICAgcmVzdG9yZWRTdGF0ZSxcbiAgICAgICAgICAgIGV4dHJhc1xuICAgICAgICAgIH0gPSB0O1xuICAgICAgICAgIGNvbnN0IG5hdlN0YXJ0ID0gbmV3IE5hdmlnYXRpb25TdGFydChpZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZShleHRyYWN0ZWRVcmwpLCBzb3VyY2UsIHJlc3RvcmVkU3RhdGUpO1xuICAgICAgICAgIHRoaXMuZXZlbnRzLm5leHQobmF2U3RhcnQpO1xuICAgICAgICAgIGNvbnN0IHRhcmdldFNuYXBzaG90ID0gY3JlYXRlRW1wdHlTdGF0ZSh0aGlzLnJvb3RDb21wb25lbnRUeXBlLCB0aGlzLmVudmlyb25tZW50SW5qZWN0b3IpLnNuYXBzaG90O1xuICAgICAgICAgIHRoaXMuY3VycmVudFRyYW5zaXRpb24gPSBvdmVyYWxsVHJhbnNpdGlvblN0YXRlID0ge1xuICAgICAgICAgICAgLi4udCxcbiAgICAgICAgICAgIHRhcmdldFNuYXBzaG90LFxuICAgICAgICAgICAgdXJsQWZ0ZXJSZWRpcmVjdHM6IGV4dHJhY3RlZFVybCxcbiAgICAgICAgICAgIGV4dHJhczoge1xuICAgICAgICAgICAgICAuLi5leHRyYXMsXG4gICAgICAgICAgICAgIHNraXBMb2NhdGlvbkNoYW5nZTogZmFsc2UsXG4gICAgICAgICAgICAgIHJlcGxhY2VVcmw6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnVwZGF0ZShuYXYgPT4ge1xuICAgICAgICAgICAgbmF2LmZpbmFsVXJsID0gZXh0cmFjdGVkVXJsO1xuICAgICAgICAgICAgcmV0dXJuIG5hdjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4gb2Yob3ZlcmFsbFRyYW5zaXRpb25TdGF0ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgcmVhc29uID0gdHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gYE5hdmlnYXRpb24gd2FzIGlnbm9yZWQgYmVjYXVzZSB0aGUgVXJsSGFuZGxpbmdTdHJhdGVneWAgKyBgIGluZGljYXRlZCBuZWl0aGVyIHRoZSBjdXJyZW50IFVSTCAke3QuY3VycmVudFJhd1VybH0gbm9yIHRhcmdldCBVUkwgJHt0LnJhd1VybH0gc2hvdWxkIGJlIHByb2Nlc3NlZC5gIDogJyc7XG4gICAgICAgICAgdGhpcy5ldmVudHMubmV4dChuZXcgTmF2aWdhdGlvblNraXBwZWQodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LmV4dHJhY3RlZFVybCksIHJlYXNvbiwgTmF2aWdhdGlvblNraXBwZWRDb2RlLklnbm9yZWRCeVVybEhhbmRsaW5nU3RyYXRlZ3kpKTtcbiAgICAgICAgICB0LnJlc29sdmUoZmFsc2UpO1xuICAgICAgICAgIHJldHVybiBFTVBUWTtcbiAgICAgICAgfVxuICAgICAgfSksIG1hcCh0ID0+IHtcbiAgICAgICAgY29uc3QgZ3VhcmRzU3RhcnQgPSBuZXcgR3VhcmRzQ2hlY2tTdGFydCh0LmlkLCB0aGlzLnVybFNlcmlhbGl6ZXIuc2VyaWFsaXplKHQuZXh0cmFjdGVkVXJsKSwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LnVybEFmdGVyUmVkaXJlY3RzKSwgdC50YXJnZXRTbmFwc2hvdCk7XG4gICAgICAgIHRoaXMuZXZlbnRzLm5leHQoZ3VhcmRzU3RhcnQpO1xuICAgICAgICB0aGlzLmN1cnJlbnRUcmFuc2l0aW9uID0gb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZSA9IHtcbiAgICAgICAgICAuLi50LFxuICAgICAgICAgIGd1YXJkczogZ2V0QWxsUm91dGVHdWFyZHModC50YXJnZXRTbmFwc2hvdCwgdC5jdXJyZW50U25hcHNob3QsIHRoaXMucm9vdENvbnRleHRzKVxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZTtcbiAgICAgIH0pLCBjaGVja0d1YXJkcyhldnQgPT4gdGhpcy5ldmVudHMubmV4dChldnQpKSwgc3dpdGNoTWFwKHQgPT4ge1xuICAgICAgICBvdmVyYWxsVHJhbnNpdGlvblN0YXRlLmd1YXJkc1Jlc3VsdCA9IHQuZ3VhcmRzUmVzdWx0O1xuICAgICAgICBpZiAodC5ndWFyZHNSZXN1bHQgJiYgdHlwZW9mIHQuZ3VhcmRzUmVzdWx0ICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICB0aHJvdyByZWRpcmVjdGluZ05hdmlnYXRpb25FcnJvcih0aGlzLnVybFNlcmlhbGl6ZXIsIHQuZ3VhcmRzUmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBndWFyZHNFbmQgPSBuZXcgR3VhcmRzQ2hlY2tFbmQodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LmV4dHJhY3RlZFVybCksIHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodC51cmxBZnRlclJlZGlyZWN0cyksIHQudGFyZ2V0U25hcHNob3QsICEhdC5ndWFyZHNSZXN1bHQpO1xuICAgICAgICB0aGlzLmV2ZW50cy5uZXh0KGd1YXJkc0VuZCk7XG4gICAgICAgIGlmICghc2hvdWxkQ29udGludWVOYXZpZ2F0aW9uKCkpIHtcbiAgICAgICAgICByZXR1cm4gRU1QVFk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0Lmd1YXJkc1Jlc3VsdCkge1xuICAgICAgICAgIHRoaXMuY2FuY2VsTmF2aWdhdGlvblRyYW5zaXRpb24odCwgJycsIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLkd1YXJkUmVqZWN0ZWQpO1xuICAgICAgICAgIHJldHVybiBFTVBUWTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodC5ndWFyZHMuY2FuQWN0aXZhdGVDaGVja3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIG9mKHQpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc29sdmVTdGFydCA9IG5ldyBSZXNvbHZlU3RhcnQodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LmV4dHJhY3RlZFVybCksIHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodC51cmxBZnRlclJlZGlyZWN0cyksIHQudGFyZ2V0U25hcHNob3QpO1xuICAgICAgICB0aGlzLmV2ZW50cy5uZXh0KHJlc29sdmVTdGFydCk7XG4gICAgICAgIGlmICghc2hvdWxkQ29udGludWVOYXZpZ2F0aW9uKCkpIHtcbiAgICAgICAgICByZXR1cm4gRU1QVFk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGRhdGFSZXNvbHZlZCA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gb2YodCkucGlwZShyZXNvbHZlRGF0YSh0aGlzLnBhcmFtc0luaGVyaXRhbmNlU3RyYXRlZ3kpLCB0YXAoe1xuICAgICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICAgIGRhdGFSZXNvbHZlZCA9IHRydWU7XG4gICAgICAgICAgICBjb25zdCByZXNvbHZlRW5kID0gbmV3IFJlc29sdmVFbmQodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LmV4dHJhY3RlZFVybCksIHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodC51cmxBZnRlclJlZGlyZWN0cyksIHQudGFyZ2V0U25hcHNob3QpO1xuICAgICAgICAgICAgdGhpcy5ldmVudHMubmV4dChyZXNvbHZlRW5kKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNvbXBsZXRlOiAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoIWRhdGFSZXNvbHZlZCkge1xuICAgICAgICAgICAgICB0aGlzLmNhbmNlbE5hdmlnYXRpb25UcmFuc2l0aW9uKHQsIHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IGBBdCBsZWFzdCBvbmUgcm91dGUgcmVzb2x2ZXIgZGlkbid0IGVtaXQgYW55IHZhbHVlLmAgOiAnJywgTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGUuTm9EYXRhRnJvbVJlc29sdmVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICAgIH0pLCBzd2l0Y2hUYXAodCA9PiB7XG4gICAgICAgIGNvbnN0IGxvYWRDb21wb25lbnRzID0gcm91dGUgPT4ge1xuICAgICAgICAgIGNvbnN0IGxvYWRlcnMgPSBbXTtcbiAgICAgICAgICBpZiAocm91dGUucm91dGVDb25maWc/Ll9sb2FkZWRDb21wb25lbnQpIHtcbiAgICAgICAgICAgIHJvdXRlLmNvbXBvbmVudCA9IHJvdXRlLnJvdXRlQ29uZmlnPy5fbG9hZGVkQ29tcG9uZW50O1xuICAgICAgICAgIH0gZWxzZSBpZiAocm91dGUucm91dGVDb25maWc/LmxvYWRDb21wb25lbnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGluamVjdG9yID0gcm91dGUuX2Vudmlyb25tZW50SW5qZWN0b3I7XG4gICAgICAgICAgICBsb2FkZXJzLnB1c2godGhpcy5jb25maWdMb2FkZXIubG9hZENvbXBvbmVudChpbmplY3Rvciwgcm91dGUucm91dGVDb25maWcpLnRoZW4obG9hZGVkQ29tcG9uZW50ID0+IHtcbiAgICAgICAgICAgICAgcm91dGUuY29tcG9uZW50ID0gbG9hZGVkQ29tcG9uZW50O1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIHJvdXRlLmNoaWxkcmVuKSB7XG4gICAgICAgICAgICBsb2FkZXJzLnB1c2goLi4ubG9hZENvbXBvbmVudHMoY2hpbGQpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGxvYWRlcnM7XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IGxvYWRlcnMgPSBsb2FkQ29tcG9uZW50cyh0LnRhcmdldFNuYXBzaG90LnJvb3QpO1xuICAgICAgICByZXR1cm4gbG9hZGVycy5sZW5ndGggPT09IDAgPyBvZih0KSA6IGZyb20oUHJvbWlzZS5hbGwobG9hZGVycykudGhlbigoKSA9PiB0KSk7XG4gICAgICB9KSwgc3dpdGNoTWFwKHQgPT4ge1xuICAgICAgICBjb25zdCB7XG4gICAgICAgICAgbmV3bHlDcmVhdGVkUm91dGVzLFxuICAgICAgICAgIHN0YXRlXG4gICAgICAgIH0gPSBjcmVhdGVSb3V0ZXJTdGF0ZShyb3V0ZXIucm91dGVSZXVzZVN0cmF0ZWd5LCB0LnRhcmdldFNuYXBzaG90LCB0LmN1cnJlbnRSb3V0ZXJTdGF0ZSk7XG4gICAgICAgIHRoaXMuY3VycmVudFRyYW5zaXRpb24gPSBvdmVyYWxsVHJhbnNpdGlvblN0YXRlID0gdCA9IHtcbiAgICAgICAgICAuLi50LFxuICAgICAgICAgIHRhcmdldFJvdXRlclN0YXRlOiBzdGF0ZSxcbiAgICAgICAgICBuZXdseUNyZWF0ZWRSb3V0ZXNcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbi51cGRhdGUobmF2ID0+IHtcbiAgICAgICAgICBuYXYudGFyZ2V0Um91dGVyU3RhdGUgPSBzdGF0ZTtcbiAgICAgICAgICByZXR1cm4gbmF2O1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG9mKHQpO1xuICAgICAgfSksIHRoaXMuYWN0aXZhdGVkUm91dGVJbmplY3RvckZlYXR1cmU/Lm9wZXJhdG9yKCkgPz8gKHQgPT4gdCksIHN3aXRjaFRhcCgoKSA9PiB0aGlzLmFmdGVyUHJlYWN0aXZhdGlvbigpKSwgc3dpdGNoTWFwKCgpID0+IHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGN1cnJlbnRTbmFwc2hvdCxcbiAgICAgICAgICB0YXJnZXRTbmFwc2hvdFxuICAgICAgICB9ID0gb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZTtcbiAgICAgICAgY29uc3Qgdmlld1RyYW5zaXRpb25TdGFydGVkID0gdGhpcy5jcmVhdGVWaWV3VHJhbnNpdGlvbj8uKHRoaXMuZW52aXJvbm1lbnRJbmplY3RvciwgY3VycmVudFNuYXBzaG90LnJvb3QsIHRhcmdldFNuYXBzaG90LnJvb3QpO1xuICAgICAgICByZXR1cm4gdmlld1RyYW5zaXRpb25TdGFydGVkID8gZnJvbSh2aWV3VHJhbnNpdGlvblN0YXJ0ZWQpLnBpcGUobWFwKCgpID0+IG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUpKSA6IG9mKG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUpO1xuICAgICAgfSksIHRha2UoMSksIHN3aXRjaE1hcCh0ID0+IHtcbiAgICAgICAgYWJvcnRhYmxlID0gZmFsc2U7XG4gICAgICAgIHRoaXMuZXZlbnRzLm5leHQobmV3IEJlZm9yZUFjdGl2YXRlUm91dGVzKCkpO1xuICAgICAgICBjb25zdCBkZWZlcnJlZCA9IG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUuYmVmb3JlQWN0aXZhdGVIYW5kbGVyLmRlZmVycmVkSGFuZGxlO1xuICAgICAgICByZXR1cm4gZGVmZXJyZWQgPyBmcm9tKGRlZmVycmVkLnRoZW4oKCkgPT4gdCkpIDogb2YodCk7XG4gICAgICB9KSwgdGFwKHQgPT4ge1xuICAgICAgICBuZXcgQWN0aXZhdGVSb3V0ZXMocm91dGVyLnJvdXRlUmV1c2VTdHJhdGVneSwgb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS50YXJnZXRSb3V0ZXJTdGF0ZSwgb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5jdXJyZW50Um91dGVyU3RhdGUsIGV2dCA9PiB0aGlzLmV2ZW50cy5uZXh0KGV2dCksIHRoaXMuaW5wdXRCaW5kaW5nRW5hYmxlZCkuYWN0aXZhdGUodGhpcy5yb290Q29udGV4dHMpO1xuICAgICAgICB0Lm5ld2x5Q3JlYXRlZFJvdXRlcz8uY2xlYXIoKTtcbiAgICAgICAgaWYgKCFzaG91bGRDb250aW51ZU5hdmlnYXRpb24oKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb21wbGV0ZWRPckFib3J0ZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnVwZGF0ZShuYXYgPT4ge1xuICAgICAgICAgIG5hdi5hYm9ydCA9IG5vb3A7XG4gICAgICAgICAgcmV0dXJuIG5hdjtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMubGFzdFN1Y2Nlc3NmdWxOYXZpZ2F0aW9uLnNldCh1bnRyYWNrZWQodGhpcy5jdXJyZW50TmF2aWdhdGlvbikpO1xuICAgICAgICB0aGlzLmV2ZW50cy5uZXh0KG5ldyBOYXZpZ2F0aW9uRW5kKHQuaWQsIHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodC5leHRyYWN0ZWRVcmwpLCB0aGlzLnVybFNlcmlhbGl6ZXIuc2VyaWFsaXplKHQudXJsQWZ0ZXJSZWRpcmVjdHMpKSk7XG4gICAgICAgIHRoaXMudGl0bGVTdHJhdGVneT8udXBkYXRlVGl0bGUodC50YXJnZXRSb3V0ZXJTdGF0ZS5zbmFwc2hvdCk7XG4gICAgICAgIHQucmVzb2x2ZSh0cnVlKTtcbiAgICAgIH0pLCB0YWtlVW50aWwoYWJvcnRTaWduYWxUb09ic2VydmFibGUoYWJvcnRDb250cm9sbGVyLnNpZ25hbCkucGlwZShmaWx0ZXIoKCkgPT4gIWNvbXBsZXRlZE9yQWJvcnRlZCAmJiBhYm9ydGFibGUpLCB0YXAoKCkgPT4ge1xuICAgICAgICB0aGlzLmNhbmNlbE5hdmlnYXRpb25UcmFuc2l0aW9uKG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUsIGFib3J0Q29udHJvbGxlci5zaWduYWwucmVhc29uICsgJycsIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLkFib3J0ZWQpO1xuICAgICAgfSkpKSwgdGFwKHtcbiAgICAgICAgY29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgICBjb21wbGV0ZWRPckFib3J0ZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9KSwgdGFrZVVudGlsKHRoaXMudHJhbnNpdGlvbkFib3J0V2l0aEVycm9yU3ViamVjdC5waXBlKHRhcChlcnIgPT4ge1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9KSkpLCBmaW5hbGl6ZSgoKSA9PiB7XG4gICAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgICBpZiAoIWNvbXBsZXRlZE9yQWJvcnRlZCkge1xuICAgICAgICAgIGNvbnN0IGNhbmNlbGF0aW9uUmVhc29uID0gdHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gYE5hdmlnYXRpb24gSUQgJHtvdmVyYWxsVHJhbnNpdGlvblN0YXRlLmlkfSBpcyBub3QgZXF1YWwgdG8gdGhlIGN1cnJlbnQgbmF2aWdhdGlvbiBpZCAke3RoaXMubmF2aWdhdGlvbklkfWAgOiAnJztcbiAgICAgICAgICB0aGlzLmNhbmNlbE5hdmlnYXRpb25UcmFuc2l0aW9uKG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUsIGNhbmNlbGF0aW9uUmVhc29uLCBOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZS5TdXBlcnNlZGVkQnlOZXdOYXZpZ2F0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5jdXJyZW50VHJhbnNpdGlvbj8uaWQgPT09IG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUuaWQpIHtcbiAgICAgICAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnNldChudWxsKTtcbiAgICAgICAgICB0aGlzLmN1cnJlbnRUcmFuc2l0aW9uID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfSksIGNhdGNoRXJyb3IoZSA9PiB7XG4gICAgICAgIGNvbXBsZXRlZE9yQWJvcnRlZCA9IHRydWU7XG4gICAgICAgIGRpc2NhcmROZXdBY3RpdmF0ZWRSb3V0ZXMob3ZlcmFsbFRyYW5zaXRpb25TdGF0ZSk7XG4gICAgICAgIGlmICh0aGlzLmRlc3Ryb3llZCkge1xuICAgICAgICAgIG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUucmVzb2x2ZShmYWxzZSk7XG4gICAgICAgICAgcmV0dXJuIEVNUFRZO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc05hdmlnYXRpb25DYW5jZWxpbmdFcnJvcihlKSkge1xuICAgICAgICAgIHRoaXMuZXZlbnRzLm5leHQobmV3IE5hdmlnYXRpb25DYW5jZWwob3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZShvdmVyYWxsVHJhbnNpdGlvblN0YXRlLmV4dHJhY3RlZFVybCksIGUubWVzc2FnZSwgZS5jYW5jZWxsYXRpb25Db2RlKSk7XG4gICAgICAgICAgaWYgKCFpc1JlZGlyZWN0aW5nTmF2aWdhdGlvbkNhbmNlbGluZ0Vycm9yKGUpKSB7XG4gICAgICAgICAgICBvdmVyYWxsVHJhbnNpdGlvblN0YXRlLnJlc29sdmUoZmFsc2UpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmV2ZW50cy5uZXh0KG5ldyBSZWRpcmVjdFJlcXVlc3QoZS51cmwsIGUubmF2aWdhdGlvbkJlaGF2aW9yT3B0aW9ucykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBuYXZpZ2F0aW9uRXJyb3IgPSBuZXcgTmF2aWdhdGlvbkVycm9yKG92ZXJhbGxUcmFuc2l0aW9uU3RhdGUuaWQsIHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUob3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5leHRyYWN0ZWRVcmwpLCBlLCBvdmVyYWxsVHJhbnNpdGlvblN0YXRlLnRhcmdldFNuYXBzaG90ID8/IHVuZGVmaW5lZCk7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IG5hdmlnYXRpb25FcnJvckhhbmRsZXJSZXN1bHQgPSBydW5JbkluamVjdGlvbkNvbnRleHQodGhpcy5lbnZpcm9ubWVudEluamVjdG9yLCAoKSA9PiB0aGlzLm5hdmlnYXRpb25FcnJvckhhbmRsZXI/LihuYXZpZ2F0aW9uRXJyb3IpKTtcbiAgICAgICAgICAgIGlmIChuYXZpZ2F0aW9uRXJyb3JIYW5kbGVyUmVzdWx0IGluc3RhbmNlb2YgUmVkaXJlY3RDb21tYW5kKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHtcbiAgICAgICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgICAgIGNhbmNlbGxhdGlvbkNvZGVcbiAgICAgICAgICAgICAgfSA9IHJlZGlyZWN0aW5nTmF2aWdhdGlvbkVycm9yKHRoaXMudXJsU2VyaWFsaXplciwgbmF2aWdhdGlvbkVycm9ySGFuZGxlclJlc3VsdCk7XG4gICAgICAgICAgICAgIHRoaXMuZXZlbnRzLm5leHQobmV3IE5hdmlnYXRpb25DYW5jZWwob3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZShvdmVyYWxsVHJhbnNpdGlvblN0YXRlLmV4dHJhY3RlZFVybCksIG1lc3NhZ2UsIGNhbmNlbGxhdGlvbkNvZGUpKTtcbiAgICAgICAgICAgICAgdGhpcy5ldmVudHMubmV4dChuZXcgUmVkaXJlY3RSZXF1ZXN0KG5hdmlnYXRpb25FcnJvckhhbmRsZXJSZXN1bHQucmVkaXJlY3RUbywgbmF2aWdhdGlvbkVycm9ySGFuZGxlclJlc3VsdC5uYXZpZ2F0aW9uQmVoYXZpb3JPcHRpb25zKSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0aGlzLmV2ZW50cy5uZXh0KG5hdmlnYXRpb25FcnJvcik7XG4gICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZWUpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLm9wdGlvbnMucmVzb2x2ZU5hdmlnYXRpb25Qcm9taXNlT25FcnJvcikge1xuICAgICAgICAgICAgICBvdmVyYWxsVHJhbnNpdGlvblN0YXRlLnJlc29sdmUoZmFsc2UpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgb3ZlcmFsbFRyYW5zaXRpb25TdGF0ZS5yZWplY3QoZWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gRU1QVFk7XG4gICAgICB9KSk7XG4gICAgfSkpO1xuICB9XG4gIGNhbmNlbE5hdmlnYXRpb25UcmFuc2l0aW9uKHQsIHJlYXNvbiwgY29kZSkge1xuICAgIGRpc2NhcmROZXdBY3RpdmF0ZWRSb3V0ZXModCk7XG4gICAgY29uc3QgbmF2Q2FuY2VsID0gbmV3IE5hdmlnYXRpb25DYW5jZWwodC5pZCwgdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0LmV4dHJhY3RlZFVybCksIHJlYXNvbiwgY29kZSk7XG4gICAgdGhpcy5ldmVudHMubmV4dChuYXZDYW5jZWwpO1xuICAgIHQucmVzb2x2ZShmYWxzZSk7XG4gIH1cbiAgaXNVcGRhdGluZ0ludGVybmFsU3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuY3VycmVudFRyYW5zaXRpb24/LmV4dHJhY3RlZFVybC50b1N0cmluZygpICE9PSB0aGlzLmN1cnJlbnRUcmFuc2l0aW9uPy5jdXJyZW50VXJsVHJlZS50b1N0cmluZygpO1xuICB9XG4gIGlzVXBkYXRlZEJyb3dzZXJVcmwoKSB7XG4gICAgY29uc3QgY3VycmVudEJyb3dzZXJVcmwgPSB0aGlzLnVybEhhbmRsaW5nU3RyYXRlZ3kuZXh0cmFjdCh0aGlzLnVybFNlcmlhbGl6ZXIucGFyc2UodGhpcy5sb2NhdGlvbi5wYXRoKHRydWUpKSk7XG4gICAgY29uc3QgY3VycmVudE5hdmlnYXRpb24gPSB1bnRyYWNrZWQodGhpcy5jdXJyZW50TmF2aWdhdGlvbik7XG4gICAgY29uc3QgdGFyZ2V0QnJvd3NlclVybCA9IGN1cnJlbnROYXZpZ2F0aW9uPy50YXJnZXRCcm93c2VyVXJsID8/IGN1cnJlbnROYXZpZ2F0aW9uPy5leHRyYWN0ZWRVcmw7XG4gICAgcmV0dXJuIGN1cnJlbnRCcm93c2VyVXJsLnRvU3RyaW5nKCkgIT09IHRhcmdldEJyb3dzZXJVcmw/LnRvU3RyaW5nKCkgJiYgIWN1cnJlbnROYXZpZ2F0aW9uPy5leHRyYXMuc2tpcExvY2F0aW9uQ2hhbmdlO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIE5hdmlnYXRpb25UcmFuc2l0aW9uc19GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmF2aWdhdGlvblRyYW5zaXRpb25zKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBOYXZpZ2F0aW9uVHJhbnNpdGlvbnMsXG4gICAgZmFjdG9yeTogTmF2aWdhdGlvblRyYW5zaXRpb25zLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmF2aWdhdGlvblRyYW5zaXRpb25zLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sICgpID0+IFtdLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBpc0Jyb3dzZXJUcmlnZ2VyZWROYXZpZ2F0aW9uKHNvdXJjZSkge1xuICByZXR1cm4gc291cmNlICE9PSBJTVBFUkFUSVZFX05BVklHQVRJT047XG59XG5mdW5jdGlvbiBkaXNjYXJkTmV3QWN0aXZhdGVkUm91dGVzKHQpIHtcbiAgaWYgKCF0Lm5ld2x5Q3JlYXRlZFJvdXRlcykge1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IHIgb2YgdC5uZXdseUNyZWF0ZWRSb3V0ZXMpIHtcbiAgICByLl9sb2NhbEluamVjdG9yPy5kZXN0cm95KCk7XG4gIH1cbn1cbmNvbnN0IFJPVVRFX0lOSkVDVE9SX0NMRUFOVVAgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ1JvdXRlSW5qZWN0b3JDbGVhbnVwJyA6ICcnKTtcbmZ1bmN0aW9uIHJvdXRlSW5qZWN0b3JDbGVhbnVwKHJvdXRlUmV1c2VTdHJhdGVneSwgcm91dGVyU3RhdGUsIGNvbmZpZykge1xuICBjb25zdCBhY3RpdmVSb3V0ZXMgPSBuZXcgU2V0KCk7XG4gIGlmIChyb3V0ZXJTdGF0ZS5zbmFwc2hvdC5yb290KSB7XG4gICAgY29sbGVjdERlc2NlbmRhbnRzKHJvdXRlclN0YXRlLnNuYXBzaG90LnJvb3QsIGFjdGl2ZVJvdXRlcyk7XG4gIH1cbiAgY29uc3Qgc3RvcmVkSGFuZGxlcyA9IHJvdXRlUmV1c2VTdHJhdGVneS5yZXRyaWV2ZVN0b3JlZFJvdXRlSGFuZGxlcz8uKCkgfHwgW107XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIHN0b3JlZEhhbmRsZXMpIHtcbiAgICBjb25zdCBpbnRlcm5hbEhhbmRsZSA9IGhhbmRsZTtcbiAgICBpZiAoaW50ZXJuYWxIYW5kbGU/LnJvdXRlPy52YWx1ZT8uc25hcHNob3QpIHtcbiAgICAgIGZvciAoY29uc3Qgc25hcHNob3Qgb2YgaW50ZXJuYWxIYW5kbGUucm91dGUudmFsdWUuc25hcHNob3QucGF0aEZyb21Sb290KSB7XG4gICAgICAgIGlmIChzbmFwc2hvdC5yb3V0ZUNvbmZpZykge1xuICAgICAgICAgIGFjdGl2ZVJvdXRlcy5hZGQoc25hcHNob3Qucm91dGVDb25maWcpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGRlc3Ryb3lVbnVzZWRJbmplY3RvcnMoY29uZmlnLCBhY3RpdmVSb3V0ZXMsIHJvdXRlUmV1c2VTdHJhdGVneSwgZmFsc2UpO1xufVxuZnVuY3Rpb24gY29sbGVjdERlc2NlbmRhbnRzKHNuYXBzaG90LCBhY3RpdmVSb3V0ZXMpIHtcbiAgaWYgKHNuYXBzaG90LnJvdXRlQ29uZmlnKSB7XG4gICAgYWN0aXZlUm91dGVzLmFkZChzbmFwc2hvdC5yb3V0ZUNvbmZpZyk7XG4gIH1cbiAgZm9yIChjb25zdCBjaGlsZCBvZiBzbmFwc2hvdC5jaGlsZHJlbikge1xuICAgIGNvbGxlY3REZXNjZW5kYW50cyhjaGlsZCwgYWN0aXZlUm91dGVzKTtcbiAgfVxufVxuZnVuY3Rpb24gZGVzdHJveVVudXNlZEluamVjdG9ycyhyb3V0ZXMsIGFjdGl2ZVJvdXRlcywgc3RyYXRlZ3ksIGluaGVyaXRlZEZvcmNlRGVzdHJveSkge1xuICBmb3IgKGNvbnN0IHJvdXRlIG9mIHJvdXRlcykge1xuICAgIGNvbnN0IHNob3VsZERlc3Ryb3lDdXJyZW50Um91dGUgPSBpbmhlcml0ZWRGb3JjZURlc3Ryb3kgfHwgISEoKHJvdXRlLl9pbmplY3RvciB8fCByb3V0ZS5fbG9hZGVkSW5qZWN0b3IpICYmICFhY3RpdmVSb3V0ZXMuaGFzKHJvdXRlKSAmJiAoc3RyYXRlZ3kuc2hvdWxkRGVzdHJveUluamVjdG9yPy4ocm91dGUpID8/IGZhbHNlKSk7XG4gICAgaWYgKHJvdXRlLmNoaWxkcmVuKSB7XG4gICAgICBkZXN0cm95VW51c2VkSW5qZWN0b3JzKHJvdXRlLmNoaWxkcmVuLCBhY3RpdmVSb3V0ZXMsIHN0cmF0ZWd5LCBzaG91bGREZXN0cm95Q3VycmVudFJvdXRlKTtcbiAgICB9XG4gICAgaWYgKHJvdXRlLmxvYWRDaGlsZHJlbiAmJiByb3V0ZS5fbG9hZGVkUm91dGVzKSB7XG4gICAgICBkZXN0cm95VW51c2VkSW5qZWN0b3JzKHJvdXRlLl9sb2FkZWRSb3V0ZXMsIGFjdGl2ZVJvdXRlcywgc3RyYXRlZ3ksIHNob3VsZERlc3Ryb3lDdXJyZW50Um91dGUpO1xuICAgIH1cbiAgICBpZiAoc2hvdWxkRGVzdHJveUN1cnJlbnRSb3V0ZSkge1xuICAgICAgaWYgKHJvdXRlLl9pbmplY3Rvcikge1xuICAgICAgICByb3V0ZS5faW5qZWN0b3IuZGVzdHJveSgpO1xuICAgICAgICByb3V0ZS5faW5qZWN0b3IgPSB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICBpZiAocm91dGUuX2xvYWRlZEluamVjdG9yKSB7XG4gICAgICAgIHJvdXRlLl9sb2FkZWRJbmplY3Rvci5kZXN0cm95KCk7XG4gICAgICAgIHJvdXRlLl9sb2FkZWRJbmplY3RvciA9IHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGRlc3Ryb3lEZXRhY2hlZFJvdXRlSGFuZGxlKGhhbmRsZSkge1xuICBjb25zdCBpbnRlcm5hbEhhbmRsZSA9IGhhbmRsZTtcbiAgaWYgKGludGVybmFsSGFuZGxlICYmIGludGVybmFsSGFuZGxlLmNvbXBvbmVudFJlZikge1xuICAgIGludGVybmFsSGFuZGxlLmNvbXBvbmVudFJlZi5kZXN0cm95KCk7XG4gICAgaW50ZXJuYWxIYW5kbGUucm91dGUudmFsdWUuX2xvY2FsSW5qZWN0b3I/LmRlc3Ryb3koKTtcbiAgfVxufVxuY2xhc3MgUm91dGVSZXVzZVN0cmF0ZWd5IHtcbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVSZXVzZVN0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSb3V0ZVJldXNlU3RyYXRlZ3kpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lU2VydmljZSh7XG4gICAgdG9rZW46IFJvdXRlUmV1c2VTdHJhdGVneSxcbiAgICBmYWN0b3J5OiAoKSA9PiAoKCkgPT4gaW5qZWN0KERlZmF1bHRSb3V0ZVJldXNlU3RyYXRlZ3kpKSgpXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUm91dGVSZXVzZVN0cmF0ZWd5LCBbe1xuICAgIHR5cGU6IFNlcnZpY2UsXG4gICAgYXJnczogW3tcbiAgICAgIGZhY3Rvcnk6ICgpID0+IGluamVjdChEZWZhdWx0Um91dGVSZXVzZVN0cmF0ZWd5KVxuICAgIH1dXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBCYXNlUm91dGVSZXVzZVN0cmF0ZWd5IHtcbiAgc2hvdWxkRGV0YWNoKHJvdXRlKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHN0b3JlKHJvdXRlLCBkZXRhY2hlZFRyZWUpIHt9XG4gIHNob3VsZEF0dGFjaChyb3V0ZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXRyaWV2ZShyb3V0ZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHNob3VsZFJldXNlUm91dGUoZnV0dXJlLCBjdXJyKSB7XG4gICAgcmV0dXJuIGZ1dHVyZS5yb3V0ZUNvbmZpZyA9PT0gY3Vyci5yb3V0ZUNvbmZpZztcbiAgfVxuICBzaG91bGREZXN0cm95SW5qZWN0b3Iocm91dGUpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxufVxuY2xhc3MgRGVmYXVsdFJvdXRlUmV1c2VTdHJhdGVneSBleHRlbmRzIEJhc2VSb3V0ZVJldXNlU3RyYXRlZ3kge1xuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBEZWZhdWx0Um91dGVSZXVzZVN0cmF0ZWd5X0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBEZWZhdWx0Um91dGVSZXVzZVN0cmF0ZWd5KSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBEZWZhdWx0Um91dGVSZXVzZVN0cmF0ZWd5LFxuICAgIGZhY3Rvcnk6IERlZmF1bHRSb3V0ZVJldXNlU3RyYXRlZ3kuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShEZWZhdWx0Um91dGVSZXVzZVN0cmF0ZWd5LCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sIG51bGwsIG51bGwpO1xufSkoKTtcbmNsYXNzIFN0YXRlTWFuYWdlciB7XG4gIHVybFNlcmlhbGl6ZXIgPSBpbmplY3QoVXJsU2VyaWFsaXplcik7XG4gIG9wdGlvbnMgPSBpbmplY3QoUk9VVEVSX0NPTkZJR1VSQVRJT04sIHtcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9KSB8fCB7fTtcbiAgY2FuY2VsZWROYXZpZ2F0aW9uUmVzb2x1dGlvbiA9IHRoaXMub3B0aW9ucy5jYW5jZWxlZE5hdmlnYXRpb25SZXNvbHV0aW9uIHx8ICdyZXBsYWNlJztcbiAgbG9jYXRpb24gPSBpbmplY3QoTG9jYXRpb24pO1xuICB1cmxIYW5kbGluZ1N0cmF0ZWd5ID0gaW5qZWN0KFVybEhhbmRsaW5nU3RyYXRlZ3kpO1xuICB1cmxVcGRhdGVTdHJhdGVneSA9IHRoaXMub3B0aW9ucy51cmxVcGRhdGVTdHJhdGVneSB8fCAnZGVmZXJyZWQnO1xuICBjdXJyZW50VXJsVHJlZSA9IG5ldyBVcmxUcmVlKCk7XG4gIGdldEN1cnJlbnRVcmxUcmVlKCkge1xuICAgIHJldHVybiB0aGlzLmN1cnJlbnRVcmxUcmVlO1xuICB9XG4gIHJhd1VybFRyZWUgPSB0aGlzLmN1cnJlbnRVcmxUcmVlO1xuICBnZXRSYXdVcmxUcmVlKCkge1xuICAgIHJldHVybiB0aGlzLnJhd1VybFRyZWU7XG4gIH1cbiAgY3JlYXRlQnJvd3NlclBhdGgoe1xuICAgIGZpbmFsVXJsLFxuICAgIGluaXRpYWxVcmwsXG4gICAgdGFyZ2V0QnJvd3NlclVybFxuICB9KSB7XG4gICAgY29uc3QgcmF3VXJsID0gZmluYWxVcmwgIT09IHVuZGVmaW5lZCA/IHRoaXMudXJsSGFuZGxpbmdTdHJhdGVneS5tZXJnZShmaW5hbFVybCwgaW5pdGlhbFVybCkgOiBpbml0aWFsVXJsO1xuICAgIGNvbnN0IHVybCA9IHRhcmdldEJyb3dzZXJVcmwgPz8gcmF3VXJsO1xuICAgIGNvbnN0IHBhdGggPSB1cmwgaW5zdGFuY2VvZiBVcmxUcmVlID8gdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh1cmwpIDogdXJsO1xuICAgIHJldHVybiBwYXRoO1xuICB9XG4gIHJvdXRlclVybFN0YXRlKG5hdmlnYXRpb24pIHtcbiAgICBpZiAobmF2aWdhdGlvbj8udGFyZ2V0QnJvd3NlclVybCA9PT0gdW5kZWZpbmVkIHx8IG5hdmlnYXRpb24/LmZpbmFsVXJsID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIMm1cm91dGVyVXJsOiB0aGlzLnVybFNlcmlhbGl6ZXIuc2VyaWFsaXplKG5hdmlnYXRpb24uZmluYWxVcmwpXG4gICAgfTtcbiAgfVxuICBjb21taXRUcmFuc2l0aW9uKHtcbiAgICB0YXJnZXRSb3V0ZXJTdGF0ZSxcbiAgICBmaW5hbFVybCxcbiAgICBpbml0aWFsVXJsXG4gIH0pIHtcbiAgICBpZiAoZmluYWxVcmwgJiYgdGFyZ2V0Um91dGVyU3RhdGUpIHtcbiAgICAgIHRoaXMuY3VycmVudFVybFRyZWUgPSBmaW5hbFVybDtcbiAgICAgIHRoaXMucmF3VXJsVHJlZSA9IHRoaXMudXJsSGFuZGxpbmdTdHJhdGVneS5tZXJnZShmaW5hbFVybCwgaW5pdGlhbFVybCk7XG4gICAgICB0aGlzLnJvdXRlclN0YXRlID0gdGFyZ2V0Um91dGVyU3RhdGU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucmF3VXJsVHJlZSA9IGluaXRpYWxVcmw7XG4gICAgfVxuICB9XG4gIHJvdXRlclN0YXRlID0gY3JlYXRlRW1wdHlTdGF0ZShudWxsLCBpbmplY3QoRW52aXJvbm1lbnRJbmplY3RvcikpO1xuICBnZXRSb3V0ZXJTdGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5yb3V0ZXJTdGF0ZTtcbiAgfVxuICBfc3RhdGVNZW1lbnRvID0gdGhpcy5jcmVhdGVTdGF0ZU1lbWVudG8oKTtcbiAgZ2V0IHN0YXRlTWVtZW50bygpIHtcbiAgICByZXR1cm4gdGhpcy5fc3RhdGVNZW1lbnRvO1xuICB9XG4gIHVwZGF0ZVN0YXRlTWVtZW50bygpIHtcbiAgICB0aGlzLl9zdGF0ZU1lbWVudG8gPSB0aGlzLmNyZWF0ZVN0YXRlTWVtZW50bygpO1xuICB9XG4gIGNyZWF0ZVN0YXRlTWVtZW50bygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgcmF3VXJsVHJlZTogdGhpcy5yYXdVcmxUcmVlLFxuICAgICAgY3VycmVudFVybFRyZWU6IHRoaXMuY3VycmVudFVybFRyZWUsXG4gICAgICByb3V0ZXJTdGF0ZTogdGhpcy5yb3V0ZXJTdGF0ZVxuICAgIH07XG4gIH1cbiAgcmVzdG9yZWRTdGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5sb2NhdGlvbi5nZXRTdGF0ZSgpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFN0YXRlTWFuYWdlcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgU3RhdGVNYW5hZ2VyKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBTdGF0ZU1hbmFnZXIsXG4gICAgZmFjdG9yeTogKCkgPT4gKCgpID0+IGluamVjdChIaXN0b3J5U3RhdGVNYW5hZ2VyKSkoKVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFN0YXRlTWFuYWdlciwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBmYWN0b3J5OiAoKSA9PiBpbmplY3QoSGlzdG9yeVN0YXRlTWFuYWdlcilcbiAgICB9XVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuY2xhc3MgSGlzdG9yeVN0YXRlTWFuYWdlciBleHRlbmRzIFN0YXRlTWFuYWdlciB7XG4gIGN1cnJlbnRQYWdlSWQgPSAwO1xuICBsYXN0U3VjY2Vzc2Z1bElkID0gLTE7XG4gIGdldCBicm93c2VyUGFnZUlkKCkge1xuICAgIGlmICh0aGlzLmNhbmNlbGVkTmF2aWdhdGlvblJlc29sdXRpb24gIT09ICdjb21wdXRlZCcpIHtcbiAgICAgIHJldHVybiB0aGlzLmN1cnJlbnRQYWdlSWQ7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlc3RvcmVkU3RhdGUoKT8uybVyb3V0ZXJQYWdlSWQgPz8gdGhpcy5jdXJyZW50UGFnZUlkO1xuICB9XG4gIHJlZ2lzdGVyTm9uUm91dGVyQ3VycmVudEVudHJ5Q2hhbmdlTGlzdGVuZXIobGlzdGVuZXIpIHtcbiAgICByZXR1cm4gdGhpcy5sb2NhdGlvbi5zdWJzY3JpYmUoZXZlbnQgPT4ge1xuICAgICAgaWYgKGV2ZW50Wyd0eXBlJ10gPT09ICdwb3BzdGF0ZScpIHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgbGlzdGVuZXIoZXZlbnRbJ3VybCddLCBldmVudC5zdGF0ZSwgJ3BvcHN0YXRlJywge1xuICAgICAgICAgICAgcmVwbGFjZVVybDogdHJ1ZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBoYW5kbGVSb3V0ZXJFdmVudChlLCBjdXJyZW50VHJhbnNpdGlvbikge1xuICAgIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvblN0YXJ0KSB7XG4gICAgICB0aGlzLnVwZGF0ZVN0YXRlTWVtZW50bygpO1xuICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25Ta2lwcGVkKSB7XG4gICAgICB0aGlzLmNvbW1pdFRyYW5zaXRpb24oY3VycmVudFRyYW5zaXRpb24pO1xuICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIFJvdXRlc1JlY29nbml6ZWQpIHtcbiAgICAgIGlmICh0aGlzLnVybFVwZGF0ZVN0cmF0ZWd5ID09PSAnZWFnZXInKSB7XG4gICAgICAgIGlmICghY3VycmVudFRyYW5zaXRpb24uZXh0cmFzLnNraXBMb2NhdGlvbkNoYW5nZSkge1xuICAgICAgICAgIHRoaXMuc2V0QnJvd3NlclVybCh0aGlzLmNyZWF0ZUJyb3dzZXJQYXRoKGN1cnJlbnRUcmFuc2l0aW9uKSwgY3VycmVudFRyYW5zaXRpb24pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgQmVmb3JlQWN0aXZhdGVSb3V0ZXMpIHtcbiAgICAgIHRoaXMuY29tbWl0VHJhbnNpdGlvbihjdXJyZW50VHJhbnNpdGlvbik7XG4gICAgICBpZiAodGhpcy51cmxVcGRhdGVTdHJhdGVneSA9PT0gJ2RlZmVycmVkJyAmJiAhY3VycmVudFRyYW5zaXRpb24uZXh0cmFzLnNraXBMb2NhdGlvbkNoYW5nZSkge1xuICAgICAgICB0aGlzLnNldEJyb3dzZXJVcmwodGhpcy5jcmVhdGVCcm93c2VyUGF0aChjdXJyZW50VHJhbnNpdGlvbiksIGN1cnJlbnRUcmFuc2l0aW9uKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uQ2FuY2VsICYmICFpc1JlZGlyZWN0aW5nRXZlbnQoZSkpIHtcbiAgICAgIHRoaXMucmVzdG9yZUhpc3RvcnkoY3VycmVudFRyYW5zaXRpb24pO1xuICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FcnJvcikge1xuICAgICAgdGhpcy5yZXN0b3JlSGlzdG9yeShjdXJyZW50VHJhbnNpdGlvbiwgdHJ1ZSk7XG4gICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xuICAgICAgdGhpcy5sYXN0U3VjY2Vzc2Z1bElkID0gZS5pZDtcbiAgICAgIHRoaXMuY3VycmVudFBhZ2VJZCA9IHRoaXMuYnJvd3NlclBhZ2VJZDtcbiAgICB9XG4gIH1cbiAgc2V0QnJvd3NlclVybChwYXRoLCBuYXZpZ2F0aW9uKSB7XG4gICAgY29uc3Qge1xuICAgICAgZXh0cmFzLFxuICAgICAgaWRcbiAgICB9ID0gbmF2aWdhdGlvbjtcbiAgICBjb25zdCB7XG4gICAgICByZXBsYWNlVXJsLFxuICAgICAgc3RhdGVcbiAgICB9ID0gZXh0cmFzO1xuICAgIGlmICh0aGlzLmxvY2F0aW9uLmlzQ3VycmVudFBhdGhFcXVhbFRvKHBhdGgpIHx8ICEhcmVwbGFjZVVybCkge1xuICAgICAgY29uc3QgY3VycmVudEJyb3dzZXJQYWdlSWQgPSB0aGlzLmJyb3dzZXJQYWdlSWQ7XG4gICAgICBjb25zdCBuZXdTdGF0ZSA9IHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIC4uLnRoaXMuZ2VuZXJhdGVOZ1JvdXRlclN0YXRlKGlkLCBjdXJyZW50QnJvd3NlclBhZ2VJZCwgbmF2aWdhdGlvbilcbiAgICAgIH07XG4gICAgICB0aGlzLmxvY2F0aW9uLnJlcGxhY2VTdGF0ZShwYXRoLCAnJywgbmV3U3RhdGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBuZXdTdGF0ZSA9IHtcbiAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgIC4uLnRoaXMuZ2VuZXJhdGVOZ1JvdXRlclN0YXRlKGlkLCB0aGlzLmJyb3dzZXJQYWdlSWQgKyAxLCBuYXZpZ2F0aW9uKVxuICAgICAgfTtcbiAgICAgIHRoaXMubG9jYXRpb24uZ28ocGF0aCwgJycsIG5ld1N0YXRlKTtcbiAgICB9XG4gIH1cbiAgcmVzdG9yZUhpc3RvcnkobmF2aWdhdGlvbiwgcmVzdG9yaW5nRnJvbUNhdWdodEVycm9yID0gZmFsc2UpIHtcbiAgICBpZiAodGhpcy5jYW5jZWxlZE5hdmlnYXRpb25SZXNvbHV0aW9uID09PSAnY29tcHV0ZWQnKSB7XG4gICAgICBjb25zdCBjdXJyZW50QnJvd3NlclBhZ2VJZCA9IHRoaXMuYnJvd3NlclBhZ2VJZDtcbiAgICAgIGNvbnN0IHRhcmdldFBhZ2VQb3NpdGlvbiA9IHRoaXMuY3VycmVudFBhZ2VJZCAtIGN1cnJlbnRCcm93c2VyUGFnZUlkO1xuICAgICAgaWYgKHRhcmdldFBhZ2VQb3NpdGlvbiAhPT0gMCkge1xuICAgICAgICB0aGlzLmxvY2F0aW9uLmhpc3RvcnlHbyh0YXJnZXRQYWdlUG9zaXRpb24pO1xuICAgICAgfSBlbHNlIGlmICh0aGlzLmdldEN1cnJlbnRVcmxUcmVlKCkgPT09IG5hdmlnYXRpb24uZmluYWxVcmwgJiYgdGFyZ2V0UGFnZVBvc2l0aW9uID09PSAwKSB7XG4gICAgICAgIHRoaXMucmVzZXRJbnRlcm5hbFN0YXRlKG5hdmlnYXRpb24pO1xuICAgICAgICB0aGlzLnJlc2V0VXJsVG9DdXJyZW50VXJsVHJlZSgpO1xuICAgICAgfSBlbHNlIDtcbiAgICB9IGVsc2UgaWYgKHRoaXMuY2FuY2VsZWROYXZpZ2F0aW9uUmVzb2x1dGlvbiA9PT0gJ3JlcGxhY2UnKSB7XG4gICAgICBpZiAocmVzdG9yaW5nRnJvbUNhdWdodEVycm9yKSB7XG4gICAgICAgIHRoaXMucmVzZXRJbnRlcm5hbFN0YXRlKG5hdmlnYXRpb24pO1xuICAgICAgfVxuICAgICAgdGhpcy5yZXNldFVybFRvQ3VycmVudFVybFRyZWUoKTtcbiAgICB9XG4gIH1cbiAgcmVzZXRJbnRlcm5hbFN0YXRlKHtcbiAgICBmaW5hbFVybFxuICB9KSB7XG4gICAgdGhpcy5yb3V0ZXJTdGF0ZSA9IHRoaXMuc3RhdGVNZW1lbnRvLnJvdXRlclN0YXRlO1xuICAgIHRoaXMuY3VycmVudFVybFRyZWUgPSB0aGlzLnN0YXRlTWVtZW50by5jdXJyZW50VXJsVHJlZTtcbiAgICB0aGlzLnJhd1VybFRyZWUgPSB0aGlzLnVybEhhbmRsaW5nU3RyYXRlZ3kubWVyZ2UodGhpcy5jdXJyZW50VXJsVHJlZSwgZmluYWxVcmwgPz8gdGhpcy5yYXdVcmxUcmVlKTtcbiAgfVxuICByZXNldFVybFRvQ3VycmVudFVybFRyZWUoKSB7XG4gICAgdGhpcy5sb2NhdGlvbi5yZXBsYWNlU3RhdGUodGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh0aGlzLmdldFJhd1VybFRyZWUoKSksICcnLCB0aGlzLmdlbmVyYXRlTmdSb3V0ZXJTdGF0ZSh0aGlzLmxhc3RTdWNjZXNzZnVsSWQsIHRoaXMuY3VycmVudFBhZ2VJZCkpO1xuICB9XG4gIGdlbmVyYXRlTmdSb3V0ZXJTdGF0ZShuYXZpZ2F0aW9uSWQsIHJvdXRlclBhZ2VJZCwgbmF2aWdhdGlvbikge1xuICAgIGlmICh0aGlzLmNhbmNlbGVkTmF2aWdhdGlvblJlc29sdXRpb24gPT09ICdjb21wdXRlZCcpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG5hdmlnYXRpb25JZCxcbiAgICAgICAgybVyb3V0ZXJQYWdlSWQ6IHJvdXRlclBhZ2VJZCxcbiAgICAgICAgLi4udGhpcy5yb3V0ZXJVcmxTdGF0ZShuYXZpZ2F0aW9uKVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG5hdmlnYXRpb25JZCxcbiAgICAgIC4uLnRoaXMucm91dGVyVXJsU3RhdGUobmF2aWdhdGlvbilcbiAgICB9O1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIEhpc3RvcnlTdGF0ZU1hbmFnZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IEhpc3RvcnlTdGF0ZU1hbmFnZXIpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lU2VydmljZSh7XG4gICAgdG9rZW46IEhpc3RvcnlTdGF0ZU1hbmFnZXIsXG4gICAgZmFjdG9yeTogSGlzdG9yeVN0YXRlTWFuYWdlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKEhpc3RvcnlTdGF0ZU1hbmFnZXIsIFt7XG4gICAgdHlwZTogU2VydmljZVxuICB9XSwgbnVsbCwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gYWZ0ZXJOZXh0TmF2aWdhdGlvbihyb3V0ZXIsIGFjdGlvbikge1xuICByb3V0ZXIuZXZlbnRzLnBpcGUoZmlsdGVyKGUgPT4gZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQgfHwgZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25DYW5jZWwgfHwgZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FcnJvciB8fCBlIGluc3RhbmNlb2YgTmF2aWdhdGlvblNraXBwZWQpLCBtYXAoZSA9PiB7XG4gICAgaWYgKGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRW5kIHx8IGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uU2tpcHBlZCkge1xuICAgICAgcmV0dXJuIDA7XG4gICAgfVxuICAgIGNvbnN0IHJlZGlyZWN0aW5nID0gZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25DYW5jZWwgPyBlLmNvZGUgPT09IE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLlJlZGlyZWN0IHx8IGUuY29kZSA9PT0gTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGUuU3VwZXJzZWRlZEJ5TmV3TmF2aWdhdGlvbiA6IGZhbHNlO1xuICAgIHJldHVybiByZWRpcmVjdGluZyA/IDIgOiAxO1xuICB9KSwgZmlsdGVyKHJlc3VsdCA9PiByZXN1bHQgIT09IDIpLCB0YWtlKDEpKS5zdWJzY3JpYmUoKCkgPT4ge1xuICAgIGFjdGlvbigpO1xuICB9KTtcbn1cbmNsYXNzIFJvdXRlciB7XG4gIGdldCBjdXJyZW50VXJsVHJlZSgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZU1hbmFnZXIuZ2V0Q3VycmVudFVybFRyZWUoKTtcbiAgfVxuICBnZXQgcmF3VXJsVHJlZSgpIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZU1hbmFnZXIuZ2V0UmF3VXJsVHJlZSgpO1xuICB9XG4gIGRpc3Bvc2VkID0gZmFsc2U7XG4gIG5vblJvdXRlckN1cnJlbnRFbnRyeUNoYW5nZVN1YnNjcmlwdGlvbjtcbiAgY29uc29sZSA9IGluamVjdChfQ29uc29sZSk7XG4gIHN0YXRlTWFuYWdlciA9IGluamVjdChTdGF0ZU1hbmFnZXIpO1xuICBvcHRpb25zID0gaW5qZWN0KFJPVVRFUl9DT05GSUdVUkFUSU9OLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSkgfHwge307XG4gIHBlbmRpbmdUYXNrcyA9IGluamVjdChfUGVuZGluZ1Rhc2tzSW50ZXJuYWwpO1xuICB1cmxVcGRhdGVTdHJhdGVneSA9IHRoaXMub3B0aW9ucy51cmxVcGRhdGVTdHJhdGVneSB8fCAnZGVmZXJyZWQnO1xuICBuYXZpZ2F0aW9uVHJhbnNpdGlvbnMgPSBpbmplY3QoTmF2aWdhdGlvblRyYW5zaXRpb25zKTtcbiAgdXJsU2VyaWFsaXplciA9IGluamVjdChVcmxTZXJpYWxpemVyKTtcbiAgbG9jYXRpb24gPSBpbmplY3QoTG9jYXRpb24pO1xuICB1cmxIYW5kbGluZ1N0cmF0ZWd5ID0gaW5qZWN0KFVybEhhbmRsaW5nU3RyYXRlZ3kpO1xuICBpbmplY3RvciA9IGluamVjdChFbnZpcm9ubWVudEluamVjdG9yKTtcbiAgX2V2ZW50cyA9IG5ldyBTdWJqZWN0KCk7XG4gIGdldCBldmVudHMoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2V2ZW50cztcbiAgfVxuICBnZXQgcm91dGVyU3RhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGVNYW5hZ2VyLmdldFJvdXRlclN0YXRlKCk7XG4gIH1cbiAgbmF2aWdhdGVkID0gZmFsc2U7XG4gIHJvdXRlUmV1c2VTdHJhdGVneSA9IGluamVjdChSb3V0ZVJldXNlU3RyYXRlZ3kpO1xuICBpbmplY3RvckNsZWFudXAgPSBpbmplY3QoUk9VVEVfSU5KRUNUT1JfQ0xFQU5VUCwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICBvblNhbWVVcmxOYXZpZ2F0aW9uID0gdGhpcy5vcHRpb25zLm9uU2FtZVVybE5hdmlnYXRpb24gfHwgJ2lnbm9yZSc7XG4gIGNvbmZpZyA9IGluamVjdChST1VURVMsIHtcbiAgICBvcHRpb25hbDogdHJ1ZVxuICB9KT8uZmxhdCgpID8/IFtdO1xuICBjb21wb25lbnRJbnB1dEJpbmRpbmdFbmFibGVkID0gISFpbmplY3QoSU5QVVRfQklOREVSLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSk7XG4gIGN1cnJlbnROYXZpZ2F0aW9uID0gdGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMuY3VycmVudE5hdmlnYXRpb24uYXNSZWFkb25seSgpO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnJlc2V0Q29uZmlnKHRoaXMuY29uZmlnKTtcbiAgICB0aGlzLm5hdmlnYXRpb25UcmFuc2l0aW9ucy5zZXR1cE5hdmlnYXRpb25zKHRoaXMpLnN1YnNjcmliZSh7XG4gICAgICBlcnJvcjogZSA9PiB7fVxuICAgIH0pO1xuICAgIHRoaXMuc3Vic2NyaWJlVG9OYXZpZ2F0aW9uRXZlbnRzKCk7XG4gIH1cbiAgZXZlbnRzU3Vic2NyaXB0aW9uID0gbmV3IFN1YnNjcmlwdGlvbigpO1xuICBzdWJzY3JpYmVUb05hdmlnYXRpb25FdmVudHMoKSB7XG4gICAgY29uc3Qgc3Vic2NyaXB0aW9uID0gdGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMuZXZlbnRzLnN1YnNjcmliZShlID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRUcmFuc2l0aW9uID0gdGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMuY3VycmVudFRyYW5zaXRpb247XG4gICAgICAgIGNvbnN0IGN1cnJlbnROYXZpZ2F0aW9uID0gdW50cmFja2VkKHRoaXMubmF2aWdhdGlvblRyYW5zaXRpb25zLmN1cnJlbnROYXZpZ2F0aW9uKTtcbiAgICAgICAgaWYgKGN1cnJlbnRUcmFuc2l0aW9uICE9PSBudWxsICYmIGN1cnJlbnROYXZpZ2F0aW9uICE9PSBudWxsKSB7XG4gICAgICAgICAgdGhpcy5zdGF0ZU1hbmFnZXIuaGFuZGxlUm91dGVyRXZlbnQoZSwgY3VycmVudE5hdmlnYXRpb24pO1xuICAgICAgICAgIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvbkNhbmNlbCAmJiBlLmNvZGUgIT09IE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLlJlZGlyZWN0ICYmIGUuY29kZSAhPT0gTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGUuU3VwZXJzZWRlZEJ5TmV3TmF2aWdhdGlvbikge1xuICAgICAgICAgICAgdGhpcy5uYXZpZ2F0ZWQgPSB0cnVlO1xuICAgICAgICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcbiAgICAgICAgICAgIHRoaXMubmF2aWdhdGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuaW5qZWN0b3JDbGVhbnVwPy4odGhpcy5yb3V0ZVJldXNlU3RyYXRlZ3ksIHRoaXMucm91dGVyU3RhdGUsIHRoaXMuY29uZmlnKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBSZWRpcmVjdFJlcXVlc3QpIHtcbiAgICAgICAgICAgIGNvbnN0IG9wdHMgPSBlLm5hdmlnYXRpb25CZWhhdmlvck9wdGlvbnM7XG4gICAgICAgICAgICBjb25zdCBtZXJnZWRUcmVlID0gdGhpcy51cmxIYW5kbGluZ1N0cmF0ZWd5Lm1lcmdlKGUudXJsLCBjdXJyZW50VHJhbnNpdGlvbi5jdXJyZW50UmF3VXJsKTtcbiAgICAgICAgICAgIGNvbnN0IGV4dHJhcyA9IHtcbiAgICAgICAgICAgICAgc2Nyb2xsOiBjdXJyZW50VHJhbnNpdGlvbi5leHRyYXMuc2Nyb2xsLFxuICAgICAgICAgICAgICBicm93c2VyVXJsOiBjdXJyZW50VHJhbnNpdGlvbi5leHRyYXMuYnJvd3NlclVybCxcbiAgICAgICAgICAgICAgaW5mbzogY3VycmVudFRyYW5zaXRpb24uZXh0cmFzLmluZm8sXG4gICAgICAgICAgICAgIHNraXBMb2NhdGlvbkNoYW5nZTogY3VycmVudFRyYW5zaXRpb24uZXh0cmFzLnNraXBMb2NhdGlvbkNoYW5nZSxcbiAgICAgICAgICAgICAgcmVwbGFjZVVybDogY3VycmVudFRyYW5zaXRpb24uZXh0cmFzLnJlcGxhY2VVcmwgfHwgdGhpcy51cmxVcGRhdGVTdHJhdGVneSA9PT0gJ2VhZ2VyJyB8fCBpc0Jyb3dzZXJUcmlnZ2VyZWROYXZpZ2F0aW9uKGN1cnJlbnRUcmFuc2l0aW9uLnNvdXJjZSksXG4gICAgICAgICAgICAgIC4uLm9wdHNcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlTmF2aWdhdGlvbihtZXJnZWRUcmVlLCBJTVBFUkFUSVZFX05BVklHQVRJT04sIG51bGwsIGV4dHJhcywge1xuICAgICAgICAgICAgICByZXNvbHZlOiBjdXJyZW50VHJhbnNpdGlvbi5yZXNvbHZlLFxuICAgICAgICAgICAgICByZWplY3Q6IGN1cnJlbnRUcmFuc2l0aW9uLnJlamVjdCxcbiAgICAgICAgICAgICAgcHJvbWlzZTogY3VycmVudFRyYW5zaXRpb24ucHJvbWlzZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChpc1B1YmxpY1JvdXRlckV2ZW50KGUpKSB7XG4gICAgICAgICAgdGhpcy5fZXZlbnRzLm5leHQoZSk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMudHJhbnNpdGlvbkFib3J0V2l0aEVycm9yU3ViamVjdC5uZXh0KGUpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMuZXZlbnRzU3Vic2NyaXB0aW9uLmFkZChzdWJzY3JpcHRpb24pO1xuICB9XG4gIHJlc2V0Um9vdENvbXBvbmVudFR5cGUocm9vdENvbXBvbmVudFR5cGUpIHtcbiAgICB0aGlzLnJvdXRlclN0YXRlLnJvb3QuY29tcG9uZW50ID0gcm9vdENvbXBvbmVudFR5cGU7XG4gICAgdGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMucm9vdENvbXBvbmVudFR5cGUgPSByb290Q29tcG9uZW50VHlwZTtcbiAgfVxuICBpbml0aWFsTmF2aWdhdGlvbigpIHtcbiAgICB0aGlzLnNldFVwTG9jYXRpb25DaGFuZ2VMaXN0ZW5lcigpO1xuICAgIGlmICghdGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMuaGFzUmVxdWVzdGVkTmF2aWdhdGlvbikge1xuICAgICAgdGhpcy5uYXZpZ2F0ZVRvU3luY1dpdGhCcm93c2VyKHRoaXMubG9jYXRpb24ucGF0aCh0cnVlKSwgSU1QRVJBVElWRV9OQVZJR0FUSU9OLCB0aGlzLnN0YXRlTWFuYWdlci5yZXN0b3JlZFN0YXRlKCksIHtcbiAgICAgICAgcmVwbGFjZVVybDogdHJ1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHNldFVwTG9jYXRpb25DaGFuZ2VMaXN0ZW5lcigpIHtcbiAgICB0aGlzLm5vblJvdXRlckN1cnJlbnRFbnRyeUNoYW5nZVN1YnNjcmlwdGlvbiA/Pz0gdGhpcy5zdGF0ZU1hbmFnZXIucmVnaXN0ZXJOb25Sb3V0ZXJDdXJyZW50RW50cnlDaGFuZ2VMaXN0ZW5lcigodXJsLCBzdGF0ZSwgc291cmNlLCBleHRyYXMpID0+IHtcbiAgICAgIHRoaXMubmF2aWdhdGVUb1N5bmNXaXRoQnJvd3Nlcih1cmwsIHNvdXJjZSwgc3RhdGUsIGV4dHJhcyk7XG4gICAgfSk7XG4gIH1cbiAgbmF2aWdhdGVUb1N5bmNXaXRoQnJvd3Nlcih1cmwsIHNvdXJjZSwgc3RhdGUsIGV4dHJhcykge1xuICAgIGNvbnN0IHJlc3RvcmVkU3RhdGUgPSBzdGF0ZT8ubmF2aWdhdGlvbklkID8gc3RhdGUgOiBudWxsO1xuICAgIGNvbnN0IHJvdXRlclVybCA9IHN0YXRlPy7JtXJvdXRlclVybCA/PyB1cmw7XG4gICAgaWYgKHN0YXRlPy7JtXJvdXRlclVybCkge1xuICAgICAgZXh0cmFzID0ge1xuICAgICAgICAuLi5leHRyYXMsXG4gICAgICAgIGJyb3dzZXJVcmw6IHVybFxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHN0YXRlKSB7XG4gICAgICBjb25zdCBzdGF0ZUNvcHkgPSB7XG4gICAgICAgIC4uLnN0YXRlXG4gICAgICB9O1xuICAgICAgZGVsZXRlIHN0YXRlQ29weS5uYXZpZ2F0aW9uSWQ7XG4gICAgICBkZWxldGUgc3RhdGVDb3B5Lsm1cm91dGVyUGFnZUlkO1xuICAgICAgZGVsZXRlIHN0YXRlQ29weS7JtXJvdXRlclVybDtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhzdGF0ZUNvcHkpLmxlbmd0aCAhPT0gMCkge1xuICAgICAgICBleHRyYXMuc3RhdGUgPSBzdGF0ZUNvcHk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHVybFRyZWUgPSB0aGlzLnBhcnNlVXJsKHJvdXRlclVybCk7XG4gICAgdGhpcy5zY2hlZHVsZU5hdmlnYXRpb24odXJsVHJlZSwgc291cmNlLCByZXN0b3JlZFN0YXRlLCBleHRyYXMpLmNhdGNoKGUgPT4ge1xuICAgICAgaWYgKHRoaXMuZGlzcG9zZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdGhpcy5pbmplY3Rvci5nZXQoX0lOVEVSTkFMX0FQUExJQ0FUSU9OX0VSUk9SX0hBTkRMRVIpKGUpO1xuICAgIH0pO1xuICB9XG4gIGdldCB1cmwoKSB7XG4gICAgcmV0dXJuIHRoaXMuc2VyaWFsaXplVXJsKHRoaXMuY3VycmVudFVybFRyZWUpO1xuICB9XG4gIGdldEN1cnJlbnROYXZpZ2F0aW9uKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5uYXZpZ2F0aW9uVHJhbnNpdGlvbnMuY3VycmVudE5hdmlnYXRpb24pO1xuICB9XG4gIGdldCBsYXN0U3VjY2Vzc2Z1bE5hdmlnYXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMubmF2aWdhdGlvblRyYW5zaXRpb25zLmxhc3RTdWNjZXNzZnVsTmF2aWdhdGlvbjtcbiAgfVxuICByZXNldENvbmZpZyhjb25maWcpIHtcbiAgICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSAmJiB2YWxpZGF0ZUNvbmZpZyhjb25maWcpO1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnLm1hcChzdGFuZGFyZGl6ZUNvbmZpZyk7XG4gICAgdGhpcy5uYXZpZ2F0ZWQgPSBmYWxzZTtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLmRpc3Bvc2UoKTtcbiAgfVxuICBkaXNwb3NlKCkge1xuICAgIHRoaXMuX2V2ZW50cy51bnN1YnNjcmliZSgpO1xuICAgIHRoaXMubmF2aWdhdGlvblRyYW5zaXRpb25zLmNvbXBsZXRlKCk7XG4gICAgdGhpcy5ub25Sb3V0ZXJDdXJyZW50RW50cnlDaGFuZ2VTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgdGhpcy5ub25Sb3V0ZXJDdXJyZW50RW50cnlDaGFuZ2VTdWJzY3JpcHRpb24gPSB1bmRlZmluZWQ7XG4gICAgdGhpcy5kaXNwb3NlZCA9IHRydWU7XG4gICAgdGhpcy5ldmVudHNTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgfVxuICBjcmVhdGVVcmxUcmVlKGNvbW1hbmRzLCBuYXZpZ2F0aW9uRXh0cmFzID0ge30pIHtcbiAgICBjb25zdCB7XG4gICAgICByZWxhdGl2ZVRvLFxuICAgICAgcXVlcnlQYXJhbXMsXG4gICAgICBmcmFnbWVudCxcbiAgICAgIHF1ZXJ5UGFyYW1zSGFuZGxpbmcsXG4gICAgICBwcmVzZXJ2ZUZyYWdtZW50XG4gICAgfSA9IG5hdmlnYXRpb25FeHRyYXM7XG4gICAgY29uc3QgZiA9IHByZXNlcnZlRnJhZ21lbnQgPyB0aGlzLmN1cnJlbnRVcmxUcmVlLmZyYWdtZW50IDogZnJhZ21lbnQ7XG4gICAgbGV0IHEgPSBudWxsO1xuICAgIHN3aXRjaCAocXVlcnlQYXJhbXNIYW5kbGluZyA/PyB0aGlzLm9wdGlvbnMuZGVmYXVsdFF1ZXJ5UGFyYW1zSGFuZGxpbmcpIHtcbiAgICAgIGNhc2UgJ21lcmdlJzpcbiAgICAgICAgcSA9IHtcbiAgICAgICAgICAuLi50aGlzLmN1cnJlbnRVcmxUcmVlLnF1ZXJ5UGFyYW1zLFxuICAgICAgICAgIC4uLnF1ZXJ5UGFyYW1zXG4gICAgICAgIH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAncHJlc2VydmUnOlxuICAgICAgICBxID0gdGhpcy5jdXJyZW50VXJsVHJlZS5xdWVyeVBhcmFtcztcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBxID0gcXVlcnlQYXJhbXMgfHwgbnVsbDtcbiAgICB9XG4gICAgaWYgKHEgIT09IG51bGwpIHtcbiAgICAgIHEgPSB0aGlzLnJlbW92ZUVtcHR5UHJvcHMocSk7XG4gICAgfVxuICAgIGxldCByZWxhdGl2ZVRvVXJsU2VnbWVudEdyb3VwO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZWxhdGl2ZVRvU25hcHNob3QgPSByZWxhdGl2ZVRvID8gcmVsYXRpdmVUby5zbmFwc2hvdCA6IHRoaXMucm91dGVyU3RhdGUuc25hcHNob3Qucm9vdDtcbiAgICAgIHJlbGF0aXZlVG9VcmxTZWdtZW50R3JvdXAgPSBjcmVhdGVTZWdtZW50R3JvdXBGcm9tUm91dGUocmVsYXRpdmVUb1NuYXBzaG90KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAodHlwZW9mIGNvbW1hbmRzWzBdICE9PSAnc3RyaW5nJyB8fCBjb21tYW5kc1swXVswXSAhPT0gJy8nKSB7XG4gICAgICAgIGNvbW1hbmRzID0gW107XG4gICAgICB9XG4gICAgICByZWxhdGl2ZVRvVXJsU2VnbWVudEdyb3VwID0gdGhpcy5jdXJyZW50VXJsVHJlZS5yb290O1xuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlVXJsVHJlZUZyb21TZWdtZW50R3JvdXAocmVsYXRpdmVUb1VybFNlZ21lbnRHcm91cCwgY29tbWFuZHMsIHEsIGYgPz8gbnVsbCwgdGhpcy51cmxTZXJpYWxpemVyKTtcbiAgfVxuICBuYXZpZ2F0ZUJ5VXJsKHVybCwgZXh0cmFzID0ge1xuICAgIHNraXBMb2NhdGlvbkNoYW5nZTogZmFsc2VcbiAgfSkge1xuICAgIGNvbnN0IHVybFRyZWUgPSBpc1VybFRyZWUodXJsKSA/IHVybCA6IHRoaXMucGFyc2VVcmwodXJsKTtcbiAgICBjb25zdCBtZXJnZWRUcmVlID0gdGhpcy51cmxIYW5kbGluZ1N0cmF0ZWd5Lm1lcmdlKHVybFRyZWUsIHRoaXMucmF3VXJsVHJlZSk7XG4gICAgcmV0dXJuIHRoaXMuc2NoZWR1bGVOYXZpZ2F0aW9uKG1lcmdlZFRyZWUsIElNUEVSQVRJVkVfTkFWSUdBVElPTiwgbnVsbCwgZXh0cmFzKTtcbiAgfVxuICBuYXZpZ2F0ZShjb21tYW5kcywgZXh0cmFzID0ge1xuICAgIHNraXBMb2NhdGlvbkNoYW5nZTogZmFsc2VcbiAgfSkge1xuICAgIHZhbGlkYXRlQ29tbWFuZHMoY29tbWFuZHMpO1xuICAgIHJldHVybiB0aGlzLm5hdmlnYXRlQnlVcmwodGhpcy5jcmVhdGVVcmxUcmVlKGNvbW1hbmRzLCBleHRyYXMpLCBleHRyYXMpO1xuICB9XG4gIHNlcmlhbGl6ZVVybCh1cmwpIHtcbiAgICByZXR1cm4gdGhpcy51cmxTZXJpYWxpemVyLnNlcmlhbGl6ZSh1cmwpO1xuICB9XG4gIHBhcnNlVXJsKHVybCkge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gdGhpcy51cmxTZXJpYWxpemVyLnBhcnNlKHVybCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhpcy5jb25zb2xlLndhcm4oX2Zvcm1hdFJ1bnRpbWVFcnJvcig0MDE4LCBuZ0Rldk1vZGUgJiYgYEVycm9yIHBhcnNpbmcgVVJMICR7dXJsfS4gRmFsbGluZyBiYWNrIHRvICcvJyBpbnN0ZWFkLiBcXG5gICsgZSkpO1xuICAgICAgcmV0dXJuIHRoaXMudXJsU2VyaWFsaXplci5wYXJzZSgnLycpO1xuICAgIH1cbiAgfVxuICBpc0FjdGl2ZSh1cmwsIG1hdGNoT3B0aW9ucykge1xuICAgIGxldCBvcHRpb25zO1xuICAgIGlmIChtYXRjaE9wdGlvbnMgPT09IHRydWUpIHtcbiAgICAgIG9wdGlvbnMgPSB7XG4gICAgICAgIC4uLmV4YWN0TWF0Y2hPcHRpb25zXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAobWF0Y2hPcHRpb25zID09PSBmYWxzZSkge1xuICAgICAgb3B0aW9ucyA9IHtcbiAgICAgICAgLi4uc3Vic2V0TWF0Y2hPcHRpb25zXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBvcHRpb25zID0ge1xuICAgICAgICAuLi5zdWJzZXRNYXRjaE9wdGlvbnMsXG4gICAgICAgIC4uLm1hdGNoT3B0aW9uc1xuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKGlzVXJsVHJlZSh1cmwpKSB7XG4gICAgICByZXR1cm4gY29udGFpbnNUcmVlKHRoaXMuY3VycmVudFVybFRyZWUsIHVybCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGNvbnN0IHVybFRyZWUgPSB0aGlzLnBhcnNlVXJsKHVybCk7XG4gICAgcmV0dXJuIGNvbnRhaW5zVHJlZSh0aGlzLmN1cnJlbnRVcmxUcmVlLCB1cmxUcmVlLCBvcHRpb25zKTtcbiAgfVxuICByZW1vdmVFbXB0eVByb3BzKHBhcmFtcykge1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyhwYXJhbXMpLnJlZHVjZSgocmVzdWx0LCBba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlc3VsdFtrZXldID0gdmFsdWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0sIHt9KTtcbiAgfVxuICBzY2hlZHVsZU5hdmlnYXRpb24ocmF3VXJsLCBzb3VyY2UsIHJlc3RvcmVkU3RhdGUsIGV4dHJhcywgcHJpb3JQcm9taXNlKSB7XG4gICAgaWYgKHRoaXMuZGlzcG9zZWQpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmFsc2UpO1xuICAgIH1cbiAgICBsZXQgcmVzb2x2ZTtcbiAgICBsZXQgcmVqZWN0O1xuICAgIGxldCBwcm9taXNlO1xuICAgIGlmIChwcmlvclByb21pc2UpIHtcbiAgICAgIHJlc29sdmUgPSBwcmlvclByb21pc2UucmVzb2x2ZTtcbiAgICAgIHJlamVjdCA9IHByaW9yUHJvbWlzZS5yZWplY3Q7XG4gICAgICBwcm9taXNlID0gcHJpb3JQcm9taXNlLnByb21pc2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIHByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzLCByZWopID0+IHtcbiAgICAgICAgcmVzb2x2ZSA9IHJlcztcbiAgICAgICAgcmVqZWN0ID0gcmVqO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IHRhc2tJZCA9IHRoaXMucGVuZGluZ1Rhc2tzLmFkZCgpO1xuICAgIGFmdGVyTmV4dE5hdmlnYXRpb24odGhpcywgKCkgPT4ge1xuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4gdGhpcy5wZW5kaW5nVGFza3MucmVtb3ZlKHRhc2tJZCkpO1xuICAgIH0pO1xuICAgIHRoaXMubmF2aWdhdGlvblRyYW5zaXRpb25zLmhhbmRsZU5hdmlnYXRpb25SZXF1ZXN0KHtcbiAgICAgIHNvdXJjZSxcbiAgICAgIHJlc3RvcmVkU3RhdGUsXG4gICAgICBjdXJyZW50VXJsVHJlZTogdGhpcy5jdXJyZW50VXJsVHJlZSxcbiAgICAgIGN1cnJlbnRSYXdVcmw6IHRoaXMuY3VycmVudFVybFRyZWUsXG4gICAgICByYXdVcmwsXG4gICAgICBleHRyYXMsXG4gICAgICByZXNvbHZlOiByZXNvbHZlLFxuICAgICAgcmVqZWN0OiByZWplY3QsXG4gICAgICBwcm9taXNlLFxuICAgICAgY3VycmVudFNuYXBzaG90OiB0aGlzLnJvdXRlclN0YXRlLnNuYXBzaG90LFxuICAgICAgY3VycmVudFJvdXRlclN0YXRlOiB0aGlzLnJvdXRlclN0YXRlXG4gICAgfSk7XG4gICAgcmV0dXJuIHByb21pc2UuY2F0Y2goUHJvbWlzZS5yZWplY3QuYmluZChQcm9taXNlKSk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVyX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSb3V0ZXIpKCk7XG4gIH07XG4gIHN0YXRpYyDJtXByb3YgPSAvKiBAX19QVVJFX18gKi9pMC7Jtcm1ZGVmaW5lU2VydmljZSh7XG4gICAgdG9rZW46IFJvdXRlcixcbiAgICBmYWN0b3J5OiBSb3V0ZXIuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShSb3V0ZXIsIFt7XG4gICAgdHlwZTogU2VydmljZVxuICB9XSwgKCkgPT4gW10sIG51bGwpO1xufSkoKTtcbmZ1bmN0aW9uIHZhbGlkYXRlQ29tbWFuZHMoY29tbWFuZHMpIHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb21tYW5kcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNtZCA9IGNvbW1hbmRzW2ldO1xuICAgIGlmIChjbWQgPT0gbnVsbCkge1xuICAgICAgdGhyb3cgbmV3IF9SdW50aW1lRXJyb3IoNDAwOCwgKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSkgJiYgYFRoZSByZXF1ZXN0ZWQgcGF0aCBjb250YWlucyAke2NtZH0gc2VnbWVudCBhdCBpbmRleCAke2l9YCk7XG4gICAgfVxuICB9XG59XG5leHBvcnQgeyBBQ1RJVkFURURfUk9VVEVfSU5KRUNUT1JfRkVBVFVSRSwgQWN0aXZhdGVkUm91dGUsIEFjdGl2YXRlZFJvdXRlU25hcHNob3QsIEFjdGl2YXRpb25FbmQsIEFjdGl2YXRpb25TdGFydCwgQmFzZVJvdXRlUmV1c2VTdHJhdGVneSwgQmVmb3JlQWN0aXZhdGVSb3V0ZXMsIEJlZm9yZVJvdXRlc1JlY29nbml6ZWQsIENSRUFURV9WSUVXX1RSQU5TSVRJT04sIENoaWxkQWN0aXZhdGlvbkVuZCwgQ2hpbGRBY3RpdmF0aW9uU3RhcnQsIENoaWxkcmVuT3V0bGV0Q29udGV4dHMsIERlZmF1bHRUaXRsZVN0cmF0ZWd5LCBEZWZhdWx0VXJsU2VyaWFsaXplciwgRXZlbnRUeXBlLCBHdWFyZHNDaGVja0VuZCwgR3VhcmRzQ2hlY2tTdGFydCwgSU1QRVJBVElWRV9OQVZJR0FUSU9OLCBJTlBVVF9CSU5ERVIsIE5BVklHQVRJT05fRVJST1JfSEFORExFUiwgTmF2aWdhdGlvbkNhbmNlbCwgTmF2aWdhdGlvbkNhbmNlbGxhdGlvbkNvZGUsIE5hdmlnYXRpb25FbmQsIE5hdmlnYXRpb25FcnJvciwgTmF2aWdhdGlvblNraXBwZWQsIE5hdmlnYXRpb25Ta2lwcGVkQ29kZSwgTmF2aWdhdGlvblN0YXJ0LCBOYXZpZ2F0aW9uVHJhbnNpdGlvbnMsIE91dGxldENvbnRleHQsIFBSSU1BUllfT1VUTEVULCBST1VURVJfQ09ORklHVVJBVElPTiwgUk9VVEVSX09VVExFVF9EQVRBLCBST1VURVMsIFJPVVRFX0lOSkVDVE9SX0NMRUFOVVAsIFJlZGlyZWN0Q29tbWFuZCwgUmVzb2x2ZUVuZCwgUmVzb2x2ZVN0YXJ0LCBSb3V0ZUNvbmZpZ0xvYWRFbmQsIFJvdXRlQ29uZmlnTG9hZFN0YXJ0LCBSb3V0ZVJldXNlU3RyYXRlZ3ksIFJvdXRlZENvbXBvbmVudElucHV0QmluZGVyLCBSb3V0ZXIsIFJvdXRlckNvbmZpZ0xvYWRlciwgUm91dGVyRXZlbnQsIFJvdXRlck91dGxldCwgUm91dGVyU3RhdGUsIFJvdXRlclN0YXRlU25hcHNob3QsIFJvdXRlc1JlY29nbml6ZWQsIFNjcm9sbCwgU3RhdGVNYW5hZ2VyLCBUaXRsZVN0cmF0ZWd5LCBVcmxIYW5kbGluZ1N0cmF0ZWd5LCBVcmxTZWdtZW50LCBVcmxTZWdtZW50R3JvdXAsIFVybFNlcmlhbGl6ZXIsIFVybFRyZWUsIFZJRVdfVFJBTlNJVElPTl9PUFRJT05TLCBhZnRlck5leHROYXZpZ2F0aW9uLCBjb252ZXJ0VG9QYXJhbU1hcCwgY3JlYXRlVXJsVHJlZUZyb21TbmFwc2hvdCwgY3JlYXRlVmlld1RyYW5zaXRpb24sIGRlZmF1bHRVcmxNYXRjaGVyLCBkZXN0cm95RGV0YWNoZWRSb3V0ZUhhbmRsZSwgZXhhY3RNYXRjaE9wdGlvbnMsIGlzQWN0aXZlLCBpc1JlZGlyZWN0aW5nRXZlbnQsIGlzVXJsVHJlZSwgbG9hZENoaWxkcmVuLCByb3V0ZUluamVjdG9yQ2xlYW51cCwgc3RyaW5naWZ5RXZlbnQsIHN1YnNldE1hdGNoT3B0aW9ucywgybVFbXB0eU91dGxldENvbXBvbmVudCB9O1xuIiwiLyoqXG4gKiBAbGljZW5zZSBBbmd1bGFyIHYyMi4xLjJcbiAqIChjKSAyMDEwLTIwMjYgR29vZ2xlIExMQy4gaHR0cHM6Ly9hbmd1bGFyLmRldi9cbiAqIExpY2Vuc2U6IE1JVFxuICovXG5cbmltcG9ydCAqIGFzIGkzIGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBWaWV3cG9ydFNjcm9sbGVyLCBQbGF0Zm9ybU5hdmlnYXRpb24sIFBsYXRmb3JtTG9jYXRpb24sIMm1UFJFQ09NTUlUX0hBTkRMRVJfU1VQUE9SVEVEIGFzIF9QUkVDT01NSVRfSEFORExFUl9TVVBQT1JURUQsIExvY2F0aW9uLCBMT0NBVElPTl9JTklUSUFMSVpFRCwgybVOYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uIGFzIF9OYXZpZ2F0aW9uQWRhcHRlckZvckxvY2F0aW9uLCBIYXNoTG9jYXRpb25TdHJhdGVneSwgTG9jYXRpb25TdHJhdGVneSwgUGF0aExvY2F0aW9uU3RyYXRlZ3kgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0ICogYXMgaTAgZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBpbmplY3QsIEhvc3RBdHRyaWJ1dGVUb2tlbiwgbGlua2VkU2lnbmFsLCB1bnRyYWNrZWQsIHNpZ25hbCwgaW5wdXQsIMm1SU5URVJOQUxfQVBQTElDQVRJT05fRVJST1JfSEFORExFUiBhcyBfSU5URVJOQUxfQVBQTElDQVRJT05fRVJST1JfSEFORExFUiwgZWZmZWN0LCDJtVJ1bnRpbWVFcnJvciBhcyBfUnVudGltZUVycm9yLCBjb21wdXRlZCwgYm9vbGVhbkF0dHJpYnV0ZSwgU2VydmljZSwgSG9zdExpc3RlbmVyLCBJbnB1dCwgQXR0cmlidXRlLCBEaXJlY3RpdmUsIEV2ZW50RW1pdHRlciwgT3V0cHV0LCBDb250ZW50Q2hpbGRyZW4sIGNyZWF0ZUVudmlyb25tZW50SW5qZWN0b3IsIEluamVjdGFibGUsIEluamVjdGlvblRva2VuLCDJtUlTX0hZRFJBVElPTl9ET01fUkVVU0VfRU5BQkxFRCBhcyBfSVNfSFlEUkFUSU9OX0RPTV9SRVVTRV9FTkFCTEVELCBOZ1pvbmUsIEFwcGxpY2F0aW9uUmVmLCBFbnZpcm9ubWVudEluamVjdG9yLCBEZXN0cm95UmVmLCBhZnRlck5leHRSZW5kZXIsIMm1cHJvbWlzZVdpdGhSZXNvbHZlcnMgYXMgX3Byb21pc2VXaXRoUmVzb2x2ZXJzLCDJtXB1Ymxpc2hOb25Db3JlR2xvYmFsVXRpbCBhcyBfcHVibGlzaE5vbkNvcmVHbG9iYWxVdGlsLCBtYWtlRW52aXJvbm1lbnRQcm92aWRlcnMsIEFQUF9CT09UU1RSQVBfTElTVEVORVIsIHByb3ZpZGVBcHBJbml0aWFsaXplciwgybVJU19FTkFCTEVEX0JMT0NLSU5HX0lOSVRJQUxfTkFWSUdBVElPTiBhcyBfSVNfRU5BQkxFRF9CTE9DS0lOR19JTklUSUFMX05BVklHQVRJT04sIEluamVjdG9yLCBwcm92aWRlRW52aXJvbm1lbnRJbml0aWFsaXplciwgybVwZXJmb3JtYW5jZU1hcmtGZWF0dXJlIGFzIF9wZXJmb3JtYW5jZU1hcmtGZWF0dXJlLCBFTlZJUk9OTUVOVF9JTklUSUFMSVpFUiwgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJPVVRFUl9DT05GSUdVUkFUSU9OLCBpc1VybFRyZWUsIFJvdXRlciwgQWN0aXZhdGVkUm91dGUsIFN0YXRlTWFuYWdlciwgVXJsU2VyaWFsaXplciwgTmF2aWdhdGlvbkVuZCwgVXJsVHJlZSwgaXNBY3RpdmUsIHN1YnNldE1hdGNoT3B0aW9ucywgZXhhY3RNYXRjaE9wdGlvbnMsIFJvdXRlckNvbmZpZ0xvYWRlciwgSU1QRVJBVElWRV9OQVZJR0FUSU9OLCBOYXZpZ2F0aW9uVHJhbnNpdGlvbnMsIE5hdmlnYXRpb25TdGFydCwgTmF2aWdhdGlvblNraXBwZWQsIE5hdmlnYXRpb25Ta2lwcGVkQ29kZSwgU2Nyb2xsLCBCZWZvcmVSb3V0ZXNSZWNvZ25pemVkLCBCZWZvcmVBY3RpdmF0ZVJvdXRlcywgTmF2aWdhdGlvbkNhbmNlbCwgTmF2aWdhdGlvbkVycm9yLCBpc1JlZGlyZWN0aW5nRXZlbnQsIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLCBST1VURVMsIGFmdGVyTmV4dE5hdmlnYXRpb24sIE5BVklHQVRJT05fRVJST1JfSEFORExFUiwgcm91dGVJbmplY3RvckNsZWFudXAsIFJPVVRFX0lOSkVDVE9SX0NMRUFOVVAsIFJvdXRlZENvbXBvbmVudElucHV0QmluZGVyLCBJTlBVVF9CSU5ERVIsIGNyZWF0ZVZpZXdUcmFuc2l0aW9uLCBDUkVBVEVfVklFV19UUkFOU0lUSU9OLCBWSUVXX1RSQU5TSVRJT05fT1BUSU9OUywgQUNUSVZBVEVEX1JPVVRFX0lOSkVDVE9SX0ZFQVRVUkUsIHN0cmluZ2lmeUV2ZW50LCBEZWZhdWx0VXJsU2VyaWFsaXplciwgQ2hpbGRyZW5PdXRsZXRDb250ZXh0cywgUm91dGVyT3V0bGV0LCDJtUVtcHR5T3V0bGV0Q29tcG9uZW50IGFzIF9FbXB0eU91dGxldENvbXBvbmVudCB9IGZyb20gJy4vX3JvdXRlci1jaHVuay5tanMnO1xuaW1wb3J0IHsgU3ViamVjdCwgb2YsIGZyb20gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IG1lcmdlQWxsLCBjYXRjaEVycm9yLCBmaWx0ZXIsIGNvbmNhdE1hcCwgbWVyZ2VNYXAsIHRhcCB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcbmNsYXNzIFJlYWN0aXZlUm91dGVyU3RhdGUge1xuICByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcbiAgc3RhdGVNYW5hZ2VyID0gaW5qZWN0KFN0YXRlTWFuYWdlcik7XG4gIGZyYWdtZW50ID0gc2lnbmFsKCcnLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwiZnJhZ21lbnRcIlxuICB9XSA6IFtdKSk7XG4gIHF1ZXJ5UGFyYW1zID0gc2lnbmFsKHt9LCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwicXVlcnlQYXJhbXNcIlxuICB9XSA6IFtdKSk7XG4gIHBhdGggPSBzaWduYWwoJycsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJwYXRoXCJcbiAgfV0gOiBbXSkpO1xuICBzZXJpYWxpemVyID0gaW5qZWN0KFVybFNlcmlhbGl6ZXIpO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnVwZGF0ZVN0YXRlKCk7XG4gICAgdGhpcy5yb3V0ZXIuZXZlbnRzPy5zdWJzY3JpYmUoZSA9PiB7XG4gICAgICBpZiAoZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcbiAgICAgICAgdGhpcy51cGRhdGVTdGF0ZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHVwZGF0ZVN0YXRlKCkge1xuICAgIGNvbnN0IHtcbiAgICAgIGZyYWdtZW50LFxuICAgICAgcm9vdCxcbiAgICAgIHF1ZXJ5UGFyYW1zXG4gICAgfSA9IHRoaXMuc3RhdGVNYW5hZ2VyLmdldEN1cnJlbnRVcmxUcmVlKCk7XG4gICAgdGhpcy5mcmFnbWVudC5zZXQoZnJhZ21lbnQpO1xuICAgIHRoaXMucXVlcnlQYXJhbXMuc2V0KHF1ZXJ5UGFyYW1zKTtcbiAgICB0aGlzLnBhdGguc2V0KHRoaXMuc2VyaWFsaXplci5zZXJpYWxpemUobmV3IFVybFRyZWUocm9vdCkpKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBSZWFjdGl2ZVJvdXRlclN0YXRlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSZWFjdGl2ZVJvdXRlclN0YXRlKSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZVNlcnZpY2Uoe1xuICAgIHRva2VuOiBSZWFjdGl2ZVJvdXRlclN0YXRlLFxuICAgIGZhY3Rvcnk6IFJlYWN0aXZlUm91dGVyU3RhdGUuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShSZWFjdGl2ZVJvdXRlclN0YXRlLCBbe1xuICAgIHR5cGU6IFNlcnZpY2VcbiAgfV0sICgpID0+IFtdLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBSb3V0ZXJMaW5rIHtcbiAgcm91dGVyO1xuICByb3V0ZTtcbiAgdGFiSW5kZXhBdHRyaWJ1dGU7XG4gIHJlbmRlcmVyO1xuICBlbDtcbiAgbG9jYXRpb25TdHJhdGVneTtcbiAgaHJlZkF0dHJpYnV0ZVZhbHVlID0gaW5qZWN0KG5ldyBIb3N0QXR0cmlidXRlVG9rZW4oJ2hyZWYnKSwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICByZWFjdGl2ZUhyZWYgPSBsaW5rZWRTaWduYWwoKCkgPT4ge1xuICAgIGlmICghdGhpcy5pc0FuY2hvckVsZW1lbnQpIHtcbiAgICAgIHJldHVybiB0aGlzLmhyZWZBdHRyaWJ1dGVWYWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuY29tcHV0ZUhyZWYodGhpcy5fdXJsVHJlZSgpKTtcbiAgfSwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgZGVidWdOYW1lOiBcInJlYWN0aXZlSHJlZlwiXG4gIH1dIDogW10pKTtcbiAgZ2V0IGhyZWYoKSB7XG4gICAgcmV0dXJuIHVudHJhY2tlZCh0aGlzLnJlYWN0aXZlSHJlZik7XG4gIH1cbiAgc2V0IGhyZWYodmFsdWUpIHtcbiAgICB0aGlzLnJlYWN0aXZlSHJlZi5zZXQodmFsdWUpO1xuICB9XG4gIHNldCB0YXJnZXQodmFsdWUpIHtcbiAgICB0aGlzLl90YXJnZXQuc2V0KHZhbHVlKTtcbiAgfVxuICBnZXQgdGFyZ2V0KCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fdGFyZ2V0KTtcbiAgfVxuICBfdGFyZ2V0ID0gc2lnbmFsKHVuZGVmaW5lZCwgLi4uKG5nRGV2TW9kZSA/IFt7XG4gICAgZGVidWdOYW1lOiBcIl90YXJnZXRcIlxuICB9XSA6IFtdKSk7XG4gIHNldCBxdWVyeVBhcmFtcyh2YWx1ZSkge1xuICAgIHRoaXMuX3F1ZXJ5UGFyYW1zLnNldCh2YWx1ZSk7XG4gIH1cbiAgZ2V0IHF1ZXJ5UGFyYW1zKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fcXVlcnlQYXJhbXMpO1xuICB9XG4gIF9xdWVyeVBhcmFtcyA9IHNpZ25hbCh1bmRlZmluZWQsIHtcbiAgICAuLi4obmdEZXZNb2RlID8ge1xuICAgICAgZGVidWdOYW1lOiBcIl9xdWVyeVBhcmFtc1wiXG4gICAgfSA6IHt9KSxcbiAgICBlcXVhbDogKCkgPT4gZmFsc2VcbiAgfSk7XG4gIHNldCBmcmFnbWVudCh2YWx1ZSkge1xuICAgIHRoaXMuX2ZyYWdtZW50LnNldCh2YWx1ZSk7XG4gIH1cbiAgZ2V0IGZyYWdtZW50KCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fZnJhZ21lbnQpO1xuICB9XG4gIF9mcmFnbWVudCA9IHNpZ25hbCh1bmRlZmluZWQsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJfZnJhZ21lbnRcIlxuICB9XSA6IFtdKSk7XG4gIHNldCBxdWVyeVBhcmFtc0hhbmRsaW5nKHZhbHVlKSB7XG4gICAgdGhpcy5fcXVlcnlQYXJhbXNIYW5kbGluZy5zZXQodmFsdWUpO1xuICB9XG4gIGdldCBxdWVyeVBhcmFtc0hhbmRsaW5nKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fcXVlcnlQYXJhbXNIYW5kbGluZyk7XG4gIH1cbiAgX3F1ZXJ5UGFyYW1zSGFuZGxpbmcgPSBzaWduYWwodW5kZWZpbmVkLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwiX3F1ZXJ5UGFyYW1zSGFuZGxpbmdcIlxuICB9XSA6IFtdKSk7XG4gIHNldCBzdGF0ZSh2YWx1ZSkge1xuICAgIHRoaXMuX3N0YXRlLnNldCh2YWx1ZSk7XG4gIH1cbiAgZ2V0IHN0YXRlKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fc3RhdGUpO1xuICB9XG4gIF9zdGF0ZSA9IHNpZ25hbCh1bmRlZmluZWQsIHtcbiAgICAuLi4obmdEZXZNb2RlID8ge1xuICAgICAgZGVidWdOYW1lOiBcIl9zdGF0ZVwiXG4gICAgfSA6IHt9KSxcbiAgICBlcXVhbDogKCkgPT4gZmFsc2VcbiAgfSk7XG4gIHNldCBpbmZvKHZhbHVlKSB7XG4gICAgdGhpcy5faW5mby5zZXQodmFsdWUpO1xuICB9XG4gIGdldCBpbmZvKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5faW5mbyk7XG4gIH1cbiAgX2luZm8gPSBzaWduYWwodW5kZWZpbmVkLCB7XG4gICAgLi4uKG5nRGV2TW9kZSA/IHtcbiAgICAgIGRlYnVnTmFtZTogXCJfaW5mb1wiXG4gICAgfSA6IHt9KSxcbiAgICBlcXVhbDogKCkgPT4gZmFsc2VcbiAgfSk7XG4gIHNldCByZWxhdGl2ZVRvKHZhbHVlKSB7XG4gICAgdGhpcy5fcmVsYXRpdmVUby5zZXQodmFsdWUpO1xuICB9XG4gIGdldCByZWxhdGl2ZVRvKCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fcmVsYXRpdmVUbyk7XG4gIH1cbiAgX3JlbGF0aXZlVG8gPSBzaWduYWwodW5kZWZpbmVkLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwiX3JlbGF0aXZlVG9cIlxuICB9XSA6IFtdKSk7XG4gIHNldCBwcmVzZXJ2ZUZyYWdtZW50KHZhbHVlKSB7XG4gICAgdGhpcy5fcHJlc2VydmVGcmFnbWVudC5zZXQodmFsdWUpO1xuICB9XG4gIGdldCBwcmVzZXJ2ZUZyYWdtZW50KCkge1xuICAgIHJldHVybiB1bnRyYWNrZWQodGhpcy5fcHJlc2VydmVGcmFnbWVudCk7XG4gIH1cbiAgX3ByZXNlcnZlRnJhZ21lbnQgPSBzaWduYWwoZmFsc2UsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJfcHJlc2VydmVGcmFnbWVudFwiXG4gIH1dIDogW10pKTtcbiAgc2V0IHNraXBMb2NhdGlvbkNoYW5nZSh2YWx1ZSkge1xuICAgIHRoaXMuX3NraXBMb2NhdGlvbkNoYW5nZS5zZXQodmFsdWUpO1xuICB9XG4gIGdldCBza2lwTG9jYXRpb25DaGFuZ2UoKSB7XG4gICAgcmV0dXJuIHVudHJhY2tlZCh0aGlzLl9za2lwTG9jYXRpb25DaGFuZ2UpO1xuICB9XG4gIF9za2lwTG9jYXRpb25DaGFuZ2UgPSBzaWduYWwoZmFsc2UsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJfc2tpcExvY2F0aW9uQ2hhbmdlXCJcbiAgfV0gOiBbXSkpO1xuICBzZXQgcmVwbGFjZVVybCh2YWx1ZSkge1xuICAgIHRoaXMuX3JlcGxhY2VVcmwuc2V0KHZhbHVlKTtcbiAgfVxuICBnZXQgcmVwbGFjZVVybCgpIHtcbiAgICByZXR1cm4gdW50cmFja2VkKHRoaXMuX3JlcGxhY2VVcmwpO1xuICB9XG4gIF9yZXBsYWNlVXJsID0gc2lnbmFsKGZhbHNlLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwiX3JlcGxhY2VVcmxcIlxuICB9XSA6IFtdKSk7XG4gIGJyb3dzZXJVcmwgPSBpbnB1dCh1bmRlZmluZWQsIC4uLihuZ0Rldk1vZGUgPyBbe1xuICAgIGRlYnVnTmFtZTogXCJicm93c2VyVXJsXCJcbiAgfV0gOiBbXSkpO1xuICBpc0FuY2hvckVsZW1lbnQ7XG4gIG9uQ2hhbmdlcyA9IG5ldyBTdWJqZWN0KCk7XG4gIGFwcGxpY2F0aW9uRXJyb3JIYW5kbGVyID0gaW5qZWN0KF9JTlRFUk5BTF9BUFBMSUNBVElPTl9FUlJPUl9IQU5ETEVSKTtcbiAgb3B0aW9ucyA9IGluamVjdChST1VURVJfQ09ORklHVVJBVElPTiwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xuICByZWFjdGl2ZVJvdXRlclN0YXRlID0gaW5qZWN0KFJlYWN0aXZlUm91dGVyU3RhdGUpO1xuICBjb25zdHJ1Y3Rvcihyb3V0ZXIsIHJvdXRlLCB0YWJJbmRleEF0dHJpYnV0ZSwgcmVuZGVyZXIsIGVsLCBsb2NhdGlvblN0cmF0ZWd5KSB7XG4gICAgdGhpcy5yb3V0ZXIgPSByb3V0ZXI7XG4gICAgdGhpcy5yb3V0ZSA9IHJvdXRlO1xuICAgIHRoaXMudGFiSW5kZXhBdHRyaWJ1dGUgPSB0YWJJbmRleEF0dHJpYnV0ZTtcbiAgICB0aGlzLnJlbmRlcmVyID0gcmVuZGVyZXI7XG4gICAgdGhpcy5lbCA9IGVsO1xuICAgIHRoaXMubG9jYXRpb25TdHJhdGVneSA9IGxvY2F0aW9uU3RyYXRlZ3k7XG4gICAgY29uc3QgdGFnTmFtZSA9IGVsLm5hdGl2ZUVsZW1lbnQudGFnTmFtZT8udG9Mb3dlckNhc2UoKTtcbiAgICB0aGlzLmlzQW5jaG9yRWxlbWVudCA9IHRhZ05hbWUgPT09ICdhJyB8fCB0YWdOYW1lID09PSAnYXJlYScgfHwgISEodHlwZW9mIGN1c3RvbUVsZW1lbnRzID09PSAnb2JqZWN0JyAmJiBjdXN0b21FbGVtZW50cy5nZXQodGFnTmFtZSk/Lm9ic2VydmVkQXR0cmlidXRlcz8uaW5jbHVkZXM/LignaHJlZicpKTtcbiAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlKSB7XG4gICAgICBlZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoaXNVcmxUcmVlKHRoaXMucm91dGVyTGlua0lucHV0KCkpICYmICh0aGlzLl9mcmFnbWVudCgpICE9PSB1bmRlZmluZWQgfHwgdGhpcy5fcXVlcnlQYXJhbXMoKSB8fCB0aGlzLl9xdWVyeVBhcmFtc0hhbmRsaW5nKCkgfHwgdGhpcy5fcHJlc2VydmVGcmFnbWVudCgpIHx8IHRoaXMuX3JlbGF0aXZlVG8oKSkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDE3LCAnQ2Fubm90IGNvbmZpZ3VyZSBxdWVyeVBhcmFtcyBvciBmcmFnbWVudCB3aGVuIHVzaW5nIGEgVXJsVHJlZSBhcyB0aGUgcm91dGVyTGluayBpbnB1dCB2YWx1ZS4nKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHNldFRhYkluZGV4SWZOb3RPbk5hdGl2ZUVsKG5ld1RhYkluZGV4KSB7XG4gICAgaWYgKHRoaXMudGFiSW5kZXhBdHRyaWJ1dGUgIT0gbnVsbCB8fCB0aGlzLmlzQW5jaG9yRWxlbWVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmFwcGx5QXR0cmlidXRlVmFsdWUoJ3RhYmluZGV4JywgbmV3VGFiSW5kZXgpO1xuICB9XG4gIG5nT25DaGFuZ2VzKGNoYW5nZXMpIHtcbiAgICB0aGlzLm9uQ2hhbmdlcy5uZXh0KHRoaXMpO1xuICB9XG4gIHJvdXRlckxpbmtJbnB1dCA9IHNpZ25hbChudWxsLCAuLi4obmdEZXZNb2RlID8gW3tcbiAgICBkZWJ1Z05hbWU6IFwicm91dGVyTGlua0lucHV0XCJcbiAgfV0gOiBbXSkpO1xuICBzZXQgcm91dGVyTGluayhjb21tYW5kc09yVXJsVHJlZSkge1xuICAgIGlmIChjb21tYW5kc09yVXJsVHJlZSA9PSBudWxsKSB7XG4gICAgICB0aGlzLnJvdXRlckxpbmtJbnB1dC5zZXQobnVsbCk7XG4gICAgICB0aGlzLnNldFRhYkluZGV4SWZOb3RPbk5hdGl2ZUVsKG51bGwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoaXNVcmxUcmVlKGNvbW1hbmRzT3JVcmxUcmVlKSkge1xuICAgICAgICB0aGlzLnJvdXRlckxpbmtJbnB1dC5zZXQoY29tbWFuZHNPclVybFRyZWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5yb3V0ZXJMaW5rSW5wdXQuc2V0KEFycmF5LmlzQXJyYXkoY29tbWFuZHNPclVybFRyZWUpID8gY29tbWFuZHNPclVybFRyZWUgOiBbY29tbWFuZHNPclVybFRyZWVdKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuc2V0VGFiSW5kZXhJZk5vdE9uTmF0aXZlRWwoJzAnKTtcbiAgICB9XG4gIH1cbiAgb25DbGljayhidXR0b24sIGN0cmxLZXksIHNoaWZ0S2V5LCBhbHRLZXksIG1ldGFLZXkpIHtcbiAgICBjb25zdCB1cmxUcmVlID0gdGhpcy5fdXJsVHJlZSgpO1xuICAgIGlmICh1cmxUcmVlID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuaXNBbmNob3JFbGVtZW50KSB7XG4gICAgICBpZiAoYnV0dG9uICE9PSAwIHx8IGN0cmxLZXkgfHwgc2hpZnRLZXkgfHwgYWx0S2V5IHx8IG1ldGFLZXkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHRoaXMudGFyZ2V0ID09PSAnc3RyaW5nJyAmJiB0aGlzLnRhcmdldCAhPSAnX3NlbGYnKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBicm93c2VyVXJsID0gdGhpcy5icm93c2VyVXJsKCk7XG4gICAgY29uc3QgZXh0cmFzID0ge1xuICAgICAgc2tpcExvY2F0aW9uQ2hhbmdlOiB0aGlzLnNraXBMb2NhdGlvbkNoYW5nZSxcbiAgICAgIHJlcGxhY2VVcmw6IHRoaXMucmVwbGFjZVVybCxcbiAgICAgIHN0YXRlOiB0aGlzLnN0YXRlLFxuICAgICAgaW5mbzogdGhpcy5pbmZvLFxuICAgICAgLi4uKGJyb3dzZXJVcmwgIT09IHVuZGVmaW5lZCAmJiB7XG4gICAgICAgIGJyb3dzZXJVcmxcbiAgICAgIH0pXG4gICAgfTtcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZUJ5VXJsKHVybFRyZWUsIGV4dHJhcyk/LmNhdGNoKGUgPT4ge1xuICAgICAgdGhpcy5hcHBsaWNhdGlvbkVycm9ySGFuZGxlcihlKTtcbiAgICB9KTtcbiAgICByZXR1cm4gIXRoaXMuaXNBbmNob3JFbGVtZW50O1xuICB9XG4gIG5nT25EZXN0cm95KCkge31cbiAgYXBwbHlBdHRyaWJ1dGVWYWx1ZShhdHRyTmFtZSwgYXR0clZhbHVlKSB7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLnJlbmRlcmVyO1xuICAgIGNvbnN0IG5hdGl2ZUVsZW1lbnQgPSB0aGlzLmVsLm5hdGl2ZUVsZW1lbnQ7XG4gICAgaWYgKGF0dHJWYWx1ZSAhPT0gbnVsbCkge1xuICAgICAgcmVuZGVyZXIuc2V0QXR0cmlidXRlKG5hdGl2ZUVsZW1lbnQsIGF0dHJOYW1lLCBhdHRyVmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZW5kZXJlci5yZW1vdmVBdHRyaWJ1dGUobmF0aXZlRWxlbWVudCwgYXR0ck5hbWUpO1xuICAgIH1cbiAgfVxuICBfdXJsVHJlZSA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICB0aGlzLnJlYWN0aXZlUm91dGVyU3RhdGUucGF0aCgpO1xuICAgIGlmICh0aGlzLl9wcmVzZXJ2ZUZyYWdtZW50KCkpIHtcbiAgICAgIHRoaXMucmVhY3RpdmVSb3V0ZXJTdGF0ZS5mcmFnbWVudCgpO1xuICAgIH1cbiAgICBjb25zdCBzaG91bGRUcmFja1BhcmFtcyA9IGhhbmRsaW5nID0+IGhhbmRsaW5nID09PSAncHJlc2VydmUnIHx8IGhhbmRsaW5nID09PSAnbWVyZ2UnO1xuICAgIGlmIChzaG91bGRUcmFja1BhcmFtcyh0aGlzLl9xdWVyeVBhcmFtc0hhbmRsaW5nKCkpIHx8IHNob3VsZFRyYWNrUGFyYW1zKHRoaXMub3B0aW9ucz8uZGVmYXVsdFF1ZXJ5UGFyYW1zSGFuZGxpbmcpKSB7XG4gICAgICB0aGlzLnJlYWN0aXZlUm91dGVyU3RhdGUucXVlcnlQYXJhbXMoKTtcbiAgICB9XG4gICAgY29uc3Qgcm91dGVyTGlua0lucHV0ID0gdGhpcy5yb3V0ZXJMaW5rSW5wdXQoKTtcbiAgICBpZiAocm91dGVyTGlua0lucHV0ID09PSBudWxsIHx8ICF0aGlzLnJvdXRlci5jcmVhdGVVcmxUcmVlKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9IGVsc2UgaWYgKGlzVXJsVHJlZShyb3V0ZXJMaW5rSW5wdXQpKSB7XG4gICAgICByZXR1cm4gcm91dGVyTGlua0lucHV0O1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yb3V0ZXIuY3JlYXRlVXJsVHJlZShyb3V0ZXJMaW5rSW5wdXQsIHtcbiAgICAgIHJlbGF0aXZlVG86IHRoaXMuX3JlbGF0aXZlVG8oKSAhPT0gdW5kZWZpbmVkID8gdGhpcy5fcmVsYXRpdmVUbygpIDogdGhpcy5yb3V0ZSxcbiAgICAgIHF1ZXJ5UGFyYW1zOiB0aGlzLl9xdWVyeVBhcmFtcygpLFxuICAgICAgZnJhZ21lbnQ6IHRoaXMuX2ZyYWdtZW50KCksXG4gICAgICBxdWVyeVBhcmFtc0hhbmRsaW5nOiB0aGlzLl9xdWVyeVBhcmFtc0hhbmRsaW5nKCksXG4gICAgICBwcmVzZXJ2ZUZyYWdtZW50OiB0aGlzLl9wcmVzZXJ2ZUZyYWdtZW50KClcbiAgICB9KTtcbiAgfSwge1xuICAgIC4uLihuZ0Rldk1vZGUgPyB7XG4gICAgICBkZWJ1Z05hbWU6IFwiX3VybFRyZWVcIlxuICAgIH0gOiB7fSksXG4gICAgZXF1YWw6IChhLCBiKSA9PiB0aGlzLmNvbXB1dGVIcmVmKGEpID09PSB0aGlzLmNvbXB1dGVIcmVmKGIpXG4gIH0pO1xuICBnZXQgdXJsVHJlZSgpIHtcbiAgICByZXR1cm4gdW50cmFja2VkKHRoaXMuX3VybFRyZWUpO1xuICB9XG4gIGNvbXB1dGVIcmVmKHVybFRyZWUpIHtcbiAgICByZXR1cm4gdXJsVHJlZSAhPT0gbnVsbCAmJiB0aGlzLmxvY2F0aW9uU3RyYXRlZ3kgPyB0aGlzLmxvY2F0aW9uU3RyYXRlZ3k/LnByZXBhcmVFeHRlcm5hbFVybCh0aGlzLnJvdXRlci5zZXJpYWxpemVVcmwodXJsVHJlZSkpID8/ICcnIDogbnVsbDtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBSb3V0ZXJMaW5rX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICAvKiBAdHMtaWdub3JlICovXG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgUm91dGVyTGluaykoaTAuybXJtWRpcmVjdGl2ZUluamVjdChSb3V0ZXIpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KEFjdGl2YXRlZFJvdXRlKSwgaTAuybXJtWluamVjdEF0dHJpYnV0ZSgndGFiaW5kZXgnKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5SZW5kZXJlcjIpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLkVsZW1lbnRSZWYpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkzLkxvY2F0aW9uU3RyYXRlZ3kpKTtcbiAgfTtcbiAgc3RhdGljIMm1ZGlyID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZURpcmVjdGl2ZSh7XG4gICAgdHlwZTogUm91dGVyTGluayxcbiAgICBzZWxlY3RvcnM6IFtbXCJcIiwgXCJyb3V0ZXJMaW5rXCIsIFwiXCJdXSxcbiAgICBob3N0VmFyczogMixcbiAgICBob3N0QmluZGluZ3M6IGZ1bmN0aW9uIFJvdXRlckxpbmtfSG9zdEJpbmRpbmdzKHJmLCBjdHgpIHtcbiAgICAgIGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gUm91dGVyTGlua19jbGlja19Ib3N0QmluZGluZ0hhbmRsZXIoJGV2ZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGN0eC5vbkNsaWNrKCRldmVudC5idXR0b24sICRldmVudC5jdHJsS2V5LCAkZXZlbnQuc2hpZnRLZXksICRldmVudC5hbHRLZXksICRldmVudC5tZXRhS2V5KTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAocmYgJiAyKSB7XG4gICAgICAgIGkwLsm1ybVhdHRyaWJ1dGUoXCJocmVmXCIsIGN0eC5yZWFjdGl2ZUhyZWYoKSwgaTAuybXJtXNhbml0aXplVXJsT3JSZXNvdXJjZVVybCkoXCJ0YXJnZXRcIiwgY3R4Ll90YXJnZXQoKSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBpbnB1dHM6IHtcbiAgICAgIHRhcmdldDogXCJ0YXJnZXRcIixcbiAgICAgIHF1ZXJ5UGFyYW1zOiBcInF1ZXJ5UGFyYW1zXCIsXG4gICAgICBmcmFnbWVudDogXCJmcmFnbWVudFwiLFxuICAgICAgcXVlcnlQYXJhbXNIYW5kbGluZzogXCJxdWVyeVBhcmFtc0hhbmRsaW5nXCIsXG4gICAgICBzdGF0ZTogXCJzdGF0ZVwiLFxuICAgICAgaW5mbzogXCJpbmZvXCIsXG4gICAgICByZWxhdGl2ZVRvOiBcInJlbGF0aXZlVG9cIixcbiAgICAgIHByZXNlcnZlRnJhZ21lbnQ6IFsyLCBcInByZXNlcnZlRnJhZ21lbnRcIiwgXCJwcmVzZXJ2ZUZyYWdtZW50XCIsIGJvb2xlYW5BdHRyaWJ1dGVdLFxuICAgICAgc2tpcExvY2F0aW9uQ2hhbmdlOiBbMiwgXCJza2lwTG9jYXRpb25DaGFuZ2VcIiwgXCJza2lwTG9jYXRpb25DaGFuZ2VcIiwgYm9vbGVhbkF0dHJpYnV0ZV0sXG4gICAgICByZXBsYWNlVXJsOiBbMiwgXCJyZXBsYWNlVXJsXCIsIFwicmVwbGFjZVVybFwiLCBib29sZWFuQXR0cmlidXRlXSxcbiAgICAgIGJyb3dzZXJVcmw6IFsxLCBcImJyb3dzZXJVcmxcIl0sXG4gICAgICByb3V0ZXJMaW5rOiBcInJvdXRlckxpbmtcIlxuICAgIH0sXG4gICAgZmVhdHVyZXM6IFtpMC7Jtcm1TmdPbkNoYW5nZXNGZWF0dXJlXVxuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJvdXRlckxpbmssIFt7XG4gICAgdHlwZTogRGlyZWN0aXZlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBzZWxlY3RvcjogJ1tyb3V0ZXJMaW5rXScsXG4gICAgICBob3N0OiB7XG4gICAgICAgICdbYXR0ci5ocmVmXSc6ICdyZWFjdGl2ZUhyZWYoKScsXG4gICAgICAgICdbYXR0ci50YXJnZXRdJzogJ190YXJnZXQoKSdcbiAgICAgIH1cbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBSb3V0ZXJcbiAgfSwge1xuICAgIHR5cGU6IEFjdGl2YXRlZFJvdXRlXG4gIH0sIHtcbiAgICB0eXBlOiB1bmRlZmluZWQsXG4gICAgZGVjb3JhdG9yczogW3tcbiAgICAgIHR5cGU6IEF0dHJpYnV0ZSxcbiAgICAgIGFyZ3M6IFsndGFiaW5kZXgnXVxuICAgIH1dXG4gIH0sIHtcbiAgICB0eXBlOiBpMC5SZW5kZXJlcjJcbiAgfSwge1xuICAgIHR5cGU6IGkwLkVsZW1lbnRSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkzLkxvY2F0aW9uU3RyYXRlZ3lcbiAgfV0sIHtcbiAgICB0YXJnZXQ6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIHF1ZXJ5UGFyYW1zOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBmcmFnbWVudDogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV0sXG4gICAgcXVlcnlQYXJhbXNIYW5kbGluZzogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV0sXG4gICAgc3RhdGU6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIGluZm86IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIHJlbGF0aXZlVG86IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIHByZXNlcnZlRnJhZ21lbnQ6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFt7XG4gICAgICAgIHRyYW5zZm9ybTogYm9vbGVhbkF0dHJpYnV0ZVxuICAgICAgfV1cbiAgICB9XSxcbiAgICBza2lwTG9jYXRpb25DaGFuZ2U6IFt7XG4gICAgICB0eXBlOiBJbnB1dCxcbiAgICAgIGFyZ3M6IFt7XG4gICAgICAgIHRyYW5zZm9ybTogYm9vbGVhbkF0dHJpYnV0ZVxuICAgICAgfV1cbiAgICB9XSxcbiAgICByZXBsYWNlVXJsOiBbe1xuICAgICAgdHlwZTogSW5wdXQsXG4gICAgICBhcmdzOiBbe1xuICAgICAgICB0cmFuc2Zvcm06IGJvb2xlYW5BdHRyaWJ1dGVcbiAgICAgIH1dXG4gICAgfV0sXG4gICAgYnJvd3NlclVybDogW3tcbiAgICAgIHR5cGU6IGkwLklucHV0LFxuICAgICAgYXJnczogW3tcbiAgICAgICAgaXNTaWduYWw6IHRydWUsXG4gICAgICAgIGFsaWFzOiBcImJyb3dzZXJVcmxcIixcbiAgICAgICAgcmVxdWlyZWQ6IGZhbHNlXG4gICAgICB9XVxuICAgIH1dLFxuICAgIHJvdXRlckxpbms6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIG9uQ2xpY2s6IFt7XG4gICAgICB0eXBlOiBIb3N0TGlzdGVuZXIsXG4gICAgICBhcmdzOiBbJ2NsaWNrJywgWyckZXZlbnQuYnV0dG9uJywgJyRldmVudC5jdHJsS2V5JywgJyRldmVudC5zaGlmdEtleScsICckZXZlbnQuYWx0S2V5JywgJyRldmVudC5tZXRhS2V5J11dXG4gICAgfV1cbiAgfSk7XG59KSgpO1xuY2xhc3MgUm91dGVyTGlua0FjdGl2ZSB7XG4gIHJvdXRlcjtcbiAgZWxlbWVudDtcbiAgcmVuZGVyZXI7XG4gIGNkcjtcbiAgbGlua3M7XG4gIGNsYXNzZXMgPSBbXTtcbiAgcm91dGVyRXZlbnRzU3Vic2NyaXB0aW9uO1xuICBsaW5rSW5wdXRDaGFuZ2VzU3Vic2NyaXB0aW9uO1xuICBfaXNBY3RpdmUgPSBmYWxzZTtcbiAgZ2V0IGlzQWN0aXZlKCkge1xuICAgIHJldHVybiB0aGlzLl9pc0FjdGl2ZTtcbiAgfVxuICByb3V0ZXJMaW5rQWN0aXZlT3B0aW9ucyA9IHtcbiAgICBleGFjdDogZmFsc2VcbiAgfTtcbiAgYXJpYUN1cnJlbnRXaGVuQWN0aXZlO1xuICBpc0FjdGl2ZUNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgbGluayA9IGluamVjdChSb3V0ZXJMaW5rLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSk7XG4gIGNvbnN0cnVjdG9yKHJvdXRlciwgZWxlbWVudCwgcmVuZGVyZXIsIGNkcikge1xuICAgIHRoaXMucm91dGVyID0gcm91dGVyO1xuICAgIHRoaXMuZWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5yZW5kZXJlciA9IHJlbmRlcmVyO1xuICAgIHRoaXMuY2RyID0gY2RyO1xuICAgIHRoaXMucm91dGVyRXZlbnRzU3Vic2NyaXB0aW9uID0gcm91dGVyLmV2ZW50cy5zdWJzY3JpYmUocyA9PiB7XG4gICAgICBpZiAocyBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcbiAgICAgICAgdGhpcy51cGRhdGUoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBuZ0FmdGVyQ29udGVudEluaXQoKSB7XG4gICAgb2YodGhpcy5saW5rcy5jaGFuZ2VzLCBvZihudWxsKSkucGlwZShtZXJnZUFsbCgpKS5zdWJzY3JpYmUoXyA9PiB7XG4gICAgICB0aGlzLnVwZGF0ZSgpO1xuICAgICAgdGhpcy5zdWJzY3JpYmVUb0VhY2hMaW5rT25DaGFuZ2VzKCk7XG4gICAgfSk7XG4gIH1cbiAgc3Vic2NyaWJlVG9FYWNoTGlua09uQ2hhbmdlcygpIHtcbiAgICB0aGlzLmxpbmtJbnB1dENoYW5nZXNTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgY29uc3QgYWxsTGlua0NoYW5nZXMgPSBbLi4udGhpcy5saW5rcy50b0FycmF5KCksIHRoaXMubGlua10uZmlsdGVyKGxpbmsgPT4gISFsaW5rKS5tYXAobGluayA9PiBsaW5rLm9uQ2hhbmdlcyk7XG4gICAgdGhpcy5saW5rSW5wdXRDaGFuZ2VzU3Vic2NyaXB0aW9uID0gZnJvbShhbGxMaW5rQ2hhbmdlcykucGlwZShtZXJnZUFsbCgpKS5zdWJzY3JpYmUobGluayA9PiB7XG4gICAgICBpZiAodGhpcy5faXNBY3RpdmUgIT09IHRoaXMuaXNMaW5rQWN0aXZlKHRoaXMucm91dGVyKShsaW5rKSkge1xuICAgICAgICB0aGlzLnVwZGF0ZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHNldCByb3V0ZXJMaW5rQWN0aXZlKGRhdGEpIHtcbiAgICBpZiAoZGF0YSA9PSBudWxsKSB7XG4gICAgICB0aGlzLmNsYXNzZXMgPSBbXTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY2xhc3NlcyA9IEFycmF5LmlzQXJyYXkoZGF0YSkgPyBkYXRhIDogZGF0YS5zcGxpdCgnICcpO1xuICAgIHRoaXMuY2xhc3NlcyA9IGNsYXNzZXMuZmlsdGVyKGMgPT4gISFjKTtcbiAgfVxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzKSB7XG4gICAgdGhpcy51cGRhdGUoKTtcbiAgfVxuICBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLnJvdXRlckV2ZW50c1N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgIHRoaXMubGlua0lucHV0Q2hhbmdlc1N1YnNjcmlwdGlvbj8udW5zdWJzY3JpYmUoKTtcbiAgfVxuICB1cGRhdGUoKSB7XG4gICAgaWYgKCF0aGlzLmxpbmtzIHx8ICF0aGlzLnJvdXRlci5uYXZpZ2F0ZWQpIHJldHVybjtcbiAgICBpZiAodGhpcy5yb3V0ZXJMaW5rQWN0aXZlT3B0aW9ucyA9PT0gbnVsbCAmJiAhdGhpcy5faXNBY3RpdmUpIHJldHVybjtcbiAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICBjb25zdCBoYXNBY3RpdmVMaW5rcyA9IHRoaXMuaGFzQWN0aXZlTGlua3MoKTtcbiAgICAgIHRoaXMuY2xhc3Nlcy5mb3JFYWNoKGMgPT4ge1xuICAgICAgICBpZiAoaGFzQWN0aXZlTGlua3MpIHtcbiAgICAgICAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRoaXMuZWxlbWVudC5uYXRpdmVFbGVtZW50LCBjKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLnJlbmRlcmVyLnJlbW92ZUNsYXNzKHRoaXMuZWxlbWVudC5uYXRpdmVFbGVtZW50LCBjKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoaGFzQWN0aXZlTGlua3MgJiYgdGhpcy5hcmlhQ3VycmVudFdoZW5BY3RpdmUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZSh0aGlzLmVsZW1lbnQubmF0aXZlRWxlbWVudCwgJ2FyaWEtY3VycmVudCcsIHRoaXMuYXJpYUN1cnJlbnRXaGVuQWN0aXZlLnRvU3RyaW5nKCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5yZW1vdmVBdHRyaWJ1dGUodGhpcy5lbGVtZW50Lm5hdGl2ZUVsZW1lbnQsICdhcmlhLWN1cnJlbnQnKTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLl9pc0FjdGl2ZSAhPT0gaGFzQWN0aXZlTGlua3MpIHtcbiAgICAgICAgdGhpcy5faXNBY3RpdmUgPSBoYXNBY3RpdmVMaW5rcztcbiAgICAgICAgdGhpcy5jZHIubWFya0ZvckNoZWNrKCk7XG4gICAgICAgIHRoaXMuaXNBY3RpdmVDaGFuZ2UuZW1pdChoYXNBY3RpdmVMaW5rcyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgaXNMaW5rQWN0aXZlKHJvdXRlcikge1xuICAgIGNvbnN0IG9wdHMgPSB0aGlzLnJvdXRlckxpbmtBY3RpdmVPcHRpb25zO1xuICAgIGlmIChvcHRzID09PSBudWxsKSB7XG4gICAgICByZXR1cm4gKCkgPT4gZmFsc2U7XG4gICAgfVxuICAgIGxldCBvcHRpb25zO1xuICAgIGlmIChvcHRzID09PSB1bmRlZmluZWQpIHtcbiAgICAgIG9wdGlvbnMgPSB7XG4gICAgICAgIC4uLnN1YnNldE1hdGNoT3B0aW9uc1xuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKGlzQWN0aXZlTWF0Y2hPcHRpb25zKG9wdHMpKSB7XG4gICAgICBvcHRpb25zID0gb3B0cztcbiAgICB9IGVsc2UgaWYgKG9wdHMuZXhhY3QgPz8gZmFsc2UpIHtcbiAgICAgIG9wdGlvbnMgPSB7XG4gICAgICAgIC4uLmV4YWN0TWF0Y2hPcHRpb25zXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBvcHRpb25zID0ge1xuICAgICAgICAuLi5zdWJzZXRNYXRjaE9wdGlvbnNcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBsaW5rID0+IHtcbiAgICAgIGNvbnN0IHVybFRyZWUgPSBsaW5rLnVybFRyZWU7XG4gICAgICByZXR1cm4gdXJsVHJlZSA/IHVudHJhY2tlZChpc0FjdGl2ZSh1cmxUcmVlLCByb3V0ZXIsIG9wdGlvbnMpKSA6IGZhbHNlO1xuICAgIH07XG4gIH1cbiAgaGFzQWN0aXZlTGlua3MoKSB7XG4gICAgY29uc3QgaXNBY3RpdmVDaGVja0ZuID0gdGhpcy5pc0xpbmtBY3RpdmUodGhpcy5yb3V0ZXIpO1xuICAgIHJldHVybiB0aGlzLmxpbmsgJiYgaXNBY3RpdmVDaGVja0ZuKHRoaXMubGluaykgfHwgdGhpcy5saW5rcy5zb21lKGlzQWN0aXZlQ2hlY2tGbik7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVyTGlua0FjdGl2ZV9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgLyogQHRzLWlnbm9yZSAqL1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IFJvdXRlckxpbmtBY3RpdmUpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoUm91dGVyKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5FbGVtZW50UmVmKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMC5SZW5kZXJlcjIpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkwLkNoYW5nZURldGVjdG9yUmVmKSk7XG4gIH07XG4gIHN0YXRpYyDJtWRpciA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVEaXJlY3RpdmUoe1xuICAgIHR5cGU6IFJvdXRlckxpbmtBY3RpdmUsXG4gICAgc2VsZWN0b3JzOiBbW1wiXCIsIFwicm91dGVyTGlua0FjdGl2ZVwiLCBcIlwiXV0sXG4gICAgY29udGVudFF1ZXJpZXM6IGZ1bmN0aW9uIFJvdXRlckxpbmtBY3RpdmVfQ29udGVudFF1ZXJpZXMocmYsIGN0eCwgZGlySW5kZXgpIHtcbiAgICAgIGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWNvbnRlbnRRdWVyeShkaXJJbmRleCwgUm91dGVyTGluaywgNSk7XG4gICAgICB9XG4gICAgICBpZiAocmYgJiAyKSB7XG4gICAgICAgIGxldCBfdDtcbiAgICAgICAgaTAuybXJtXF1ZXJ5UmVmcmVzaChfdCA9IGkwLsm1ybVsb2FkUXVlcnkoKSkgJiYgKGN0eC5saW5rcyA9IF90KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGlucHV0czoge1xuICAgICAgcm91dGVyTGlua0FjdGl2ZU9wdGlvbnM6IFwicm91dGVyTGlua0FjdGl2ZU9wdGlvbnNcIixcbiAgICAgIGFyaWFDdXJyZW50V2hlbkFjdGl2ZTogXCJhcmlhQ3VycmVudFdoZW5BY3RpdmVcIixcbiAgICAgIHJvdXRlckxpbmtBY3RpdmU6IFwicm91dGVyTGlua0FjdGl2ZVwiXG4gICAgfSxcbiAgICBvdXRwdXRzOiB7XG4gICAgICBpc0FjdGl2ZUNoYW5nZTogXCJpc0FjdGl2ZUNoYW5nZVwiXG4gICAgfSxcbiAgICBleHBvcnRBczogW1wicm91dGVyTGlua0FjdGl2ZVwiXSxcbiAgICBmZWF0dXJlczogW2kwLsm1ybVOZ09uQ2hhbmdlc0ZlYXR1cmVdXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoUm91dGVyTGlua0FjdGl2ZSwgW3tcbiAgICB0eXBlOiBEaXJlY3RpdmUsXG4gICAgYXJnczogW3tcbiAgICAgIHNlbGVjdG9yOiAnW3JvdXRlckxpbmtBY3RpdmVdJyxcbiAgICAgIGV4cG9ydEFzOiAncm91dGVyTGlua0FjdGl2ZSdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBSb3V0ZXJcbiAgfSwge1xuICAgIHR5cGU6IGkwLkVsZW1lbnRSZWZcbiAgfSwge1xuICAgIHR5cGU6IGkwLlJlbmRlcmVyMlxuICB9LCB7XG4gICAgdHlwZTogaTAuQ2hhbmdlRGV0ZWN0b3JSZWZcbiAgfV0sIHtcbiAgICBsaW5rczogW3tcbiAgICAgIHR5cGU6IENvbnRlbnRDaGlsZHJlbixcbiAgICAgIGFyZ3M6IFtSb3V0ZXJMaW5rLCB7XG4gICAgICAgIGRlc2NlbmRhbnRzOiB0cnVlXG4gICAgICB9XVxuICAgIH1dLFxuICAgIHJvdXRlckxpbmtBY3RpdmVPcHRpb25zOiBbe1xuICAgICAgdHlwZTogSW5wdXRcbiAgICB9XSxcbiAgICBhcmlhQ3VycmVudFdoZW5BY3RpdmU6IFt7XG4gICAgICB0eXBlOiBJbnB1dFxuICAgIH1dLFxuICAgIGlzQWN0aXZlQ2hhbmdlOiBbe1xuICAgICAgdHlwZTogT3V0cHV0XG4gICAgfV0sXG4gICAgcm91dGVyTGlua0FjdGl2ZTogW3tcbiAgICAgIHR5cGU6IElucHV0XG4gICAgfV1cbiAgfSk7XG59KSgpO1xuZnVuY3Rpb24gaXNBY3RpdmVNYXRjaE9wdGlvbnMob3B0aW9ucykge1xuICBjb25zdCBvID0gb3B0aW9ucztcbiAgcmV0dXJuICEhKG8ucGF0aHMgfHwgby5tYXRyaXhQYXJhbXMgfHwgby5xdWVyeVBhcmFtcyB8fCBvLmZyYWdtZW50KTtcbn1cbmNsYXNzIFByZWxvYWRpbmdTdHJhdGVneSB7fVxuY2xhc3MgUHJlbG9hZEFsbE1vZHVsZXMge1xuICBwcmVsb2FkKHJvdXRlLCBmbikge1xuICAgIHJldHVybiBmbigpLnBpcGUoY2F0Y2hFcnJvcigoKSA9PiBvZihudWxsKSkpO1xuICB9XG4gIHN0YXRpYyDJtWZhYyA9IGZ1bmN0aW9uIFByZWxvYWRBbGxNb2R1bGVzX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBQcmVsb2FkQWxsTW9kdWxlcykoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogUHJlbG9hZEFsbE1vZHVsZXMsXG4gICAgZmFjdG9yeTogUHJlbG9hZEFsbE1vZHVsZXMuybVmYWNcbiAgfSk7XG59XG4oKCkgPT4ge1xuICAodHlwZW9mIG5nRGV2TW9kZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCBuZ0Rldk1vZGUpICYmIGkwLsm1c2V0Q2xhc3NNZXRhZGF0YShQcmVsb2FkQWxsTW9kdWxlcywgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBOb1ByZWxvYWRpbmcge1xuICBwcmVsb2FkKHJvdXRlLCBmbikge1xuICAgIHJldHVybiBvZihudWxsKTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBOb1ByZWxvYWRpbmdfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIHJldHVybiBuZXcgKF9fbmdGYWN0b3J5VHlwZV9fIHx8IE5vUHJlbG9hZGluZykoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogTm9QcmVsb2FkaW5nLFxuICAgIGZhY3Rvcnk6IE5vUHJlbG9hZGluZy7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKE5vUHJlbG9hZGluZywgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCBudWxsLCBudWxsKTtcbn0pKCk7XG5jbGFzcyBSb3V0ZXJQcmVsb2FkZXIge1xuICByb3V0ZXI7XG4gIGluamVjdG9yO1xuICBwcmVsb2FkaW5nU3RyYXRlZ3k7XG4gIGxvYWRlcjtcbiAgc3Vic2NyaXB0aW9uO1xuICBjb25zdHJ1Y3Rvcihyb3V0ZXIsIGluamVjdG9yLCBwcmVsb2FkaW5nU3RyYXRlZ3ksIGxvYWRlcikge1xuICAgIHRoaXMucm91dGVyID0gcm91dGVyO1xuICAgIHRoaXMuaW5qZWN0b3IgPSBpbmplY3RvcjtcbiAgICB0aGlzLnByZWxvYWRpbmdTdHJhdGVneSA9IHByZWxvYWRpbmdTdHJhdGVneTtcbiAgICB0aGlzLmxvYWRlciA9IGxvYWRlcjtcbiAgfVxuICBzZXRVcFByZWxvYWRpbmcoKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24gPSB0aGlzLnJvdXRlci5ldmVudHMucGlwZShmaWx0ZXIoZSA9PiBlIGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCksIGNvbmNhdE1hcCgoKSA9PiB0aGlzLnByZWxvYWQoKSkpLnN1YnNjcmliZSgoKSA9PiB7fSk7XG4gIH1cbiAgcHJlbG9hZCgpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9jZXNzUm91dGVzKHRoaXMuaW5qZWN0b3IsIHRoaXMucm91dGVyLmNvbmZpZyk7XG4gIH1cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gIH1cbiAgcHJvY2Vzc1JvdXRlcyhpbmplY3Rvciwgcm91dGVzKSB7XG4gICAgY29uc3QgcmVzID0gW107XG4gICAgZm9yIChjb25zdCByb3V0ZSBvZiByb3V0ZXMpIHtcbiAgICAgIGlmIChyb3V0ZS5wcm92aWRlcnMgJiYgIXJvdXRlLl9pbmplY3Rvcikge1xuICAgICAgICByb3V0ZS5faW5qZWN0b3IgPSBjcmVhdGVFbnZpcm9ubWVudEluamVjdG9yKHJvdXRlLnByb3ZpZGVycywgaW5qZWN0b3IsIHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/IGBSb3V0ZTogJHtyb3V0ZS5wYXRofWAgOiAnJyk7XG4gICAgICB9XG4gICAgICBjb25zdCBpbmplY3RvckZvckN1cnJlbnRSb3V0ZSA9IHJvdXRlLl9pbmplY3RvciA/PyBpbmplY3RvcjtcbiAgICAgIGlmIChyb3V0ZS5fbG9hZGVkTmdNb2R1bGVGYWN0b3J5ICYmICFyb3V0ZS5fbG9hZGVkSW5qZWN0b3IpIHtcbiAgICAgICAgcm91dGUuX2xvYWRlZEluamVjdG9yID0gcm91dGUuX2xvYWRlZE5nTW9kdWxlRmFjdG9yeS5jcmVhdGUoaW5qZWN0b3JGb3JDdXJyZW50Um91dGUpLmluamVjdG9yO1xuICAgICAgfVxuICAgICAgY29uc3QgaW5qZWN0b3JGb3JDaGlsZHJlbiA9IHJvdXRlLl9sb2FkZWRJbmplY3RvciA/PyBpbmplY3RvckZvckN1cnJlbnRSb3V0ZTtcbiAgICAgIGlmIChyb3V0ZS5sb2FkQ2hpbGRyZW4gJiYgIXJvdXRlLl9sb2FkZWRSb3V0ZXMgJiYgcm91dGUuY2FuTG9hZCA9PT0gdW5kZWZpbmVkIHx8IHJvdXRlLmxvYWRDb21wb25lbnQgJiYgIXJvdXRlLl9sb2FkZWRDb21wb25lbnQpIHtcbiAgICAgICAgcmVzLnB1c2godGhpcy5wcmVsb2FkQ29uZmlnKGluamVjdG9yRm9yQ3VycmVudFJvdXRlLCByb3V0ZSkpO1xuICAgICAgfVxuICAgICAgaWYgKHJvdXRlLmNoaWxkcmVuIHx8IHJvdXRlLl9sb2FkZWRSb3V0ZXMpIHtcbiAgICAgICAgcmVzLnB1c2godGhpcy5wcm9jZXNzUm91dGVzKGluamVjdG9yRm9yQ2hpbGRyZW4sIHJvdXRlLmNoaWxkcmVuID8/IHJvdXRlLl9sb2FkZWRSb3V0ZXMpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZyb20ocmVzKS5waXBlKG1lcmdlQWxsKCkpO1xuICB9XG4gIHByZWxvYWRDb25maWcoaW5qZWN0b3IsIHJvdXRlKSB7XG4gICAgcmV0dXJuIHRoaXMucHJlbG9hZGluZ1N0cmF0ZWd5LnByZWxvYWQocm91dGUsICgpID0+IHtcbiAgICAgIGlmIChpbmplY3Rvci5kZXN0cm95ZWQpIHtcbiAgICAgICAgcmV0dXJuIG9mKG51bGwpO1xuICAgICAgfVxuICAgICAgbGV0IGxvYWRlZENoaWxkcmVuJDtcbiAgICAgIGlmIChyb3V0ZS5sb2FkQ2hpbGRyZW4gJiYgcm91dGUuY2FuTG9hZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGxvYWRlZENoaWxkcmVuJCA9IGZyb20odGhpcy5sb2FkZXIubG9hZENoaWxkcmVuKGluamVjdG9yLCByb3V0ZSkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbG9hZGVkQ2hpbGRyZW4kID0gb2YobnVsbCk7XG4gICAgICB9XG4gICAgICBjb25zdCByZWN1cnNpdmVMb2FkQ2hpbGRyZW4kID0gbG9hZGVkQ2hpbGRyZW4kLnBpcGUobWVyZ2VNYXAoY29uZmlnID0+IHtcbiAgICAgICAgaWYgKGNvbmZpZyA9PT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybiBvZih2b2lkIDApO1xuICAgICAgICB9XG4gICAgICAgIHJvdXRlLl9sb2FkZWRSb3V0ZXMgPSBjb25maWcucm91dGVzO1xuICAgICAgICByb3V0ZS5fbG9hZGVkSW5qZWN0b3IgPSBjb25maWcuaW5qZWN0b3I7XG4gICAgICAgIHJvdXRlLl9sb2FkZWROZ01vZHVsZUZhY3RvcnkgPSBjb25maWcuZmFjdG9yeTtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvY2Vzc1JvdXRlcyhjb25maWcuaW5qZWN0b3IgPz8gaW5qZWN0b3IsIGNvbmZpZy5yb3V0ZXMpO1xuICAgICAgfSkpO1xuICAgICAgaWYgKHJvdXRlLmxvYWRDb21wb25lbnQgJiYgIXJvdXRlLl9sb2FkZWRDb21wb25lbnQpIHtcbiAgICAgICAgY29uc3QgbG9hZENvbXBvbmVudCQgPSB0aGlzLmxvYWRlci5sb2FkQ29tcG9uZW50KGluamVjdG9yLCByb3V0ZSk7XG4gICAgICAgIHJldHVybiBmcm9tKFtyZWN1cnNpdmVMb2FkQ2hpbGRyZW4kLCBsb2FkQ29tcG9uZW50JF0pLnBpcGUobWVyZ2VBbGwoKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gcmVjdXJzaXZlTG9hZENoaWxkcmVuJDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBzdGF0aWMgybVmYWMgPSBmdW5jdGlvbiBSb3V0ZXJQcmVsb2FkZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIC8qIEB0cy1pZ25vcmUgKi9cbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSb3V0ZXJQcmVsb2FkZXIpKGkwLsm1ybVpbmplY3QoUm91dGVyKSwgaTAuybXJtWluamVjdChpMC5FbnZpcm9ubWVudEluamVjdG9yKSwgaTAuybXJtWluamVjdChQcmVsb2FkaW5nU3RyYXRlZ3kpLCBpMC7Jtcm1aW5qZWN0KFJvdXRlckNvbmZpZ0xvYWRlcikpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBSb3V0ZXJQcmVsb2FkZXIsXG4gICAgZmFjdG9yeTogUm91dGVyUHJlbG9hZGVyLsm1ZmFjLFxuICAgIHByb3ZpZGVkSW46ICdyb290J1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJvdXRlclByZWxvYWRlciwgW3tcbiAgICB0eXBlOiBJbmplY3RhYmxlLFxuICAgIGFyZ3M6IFt7XG4gICAgICBwcm92aWRlZEluOiAncm9vdCdcbiAgICB9XVxuICB9XSwgKCkgPT4gW3tcbiAgICB0eXBlOiBSb3V0ZXJcbiAgfSwge1xuICAgIHR5cGU6IGkwLkVudmlyb25tZW50SW5qZWN0b3JcbiAgfSwge1xuICAgIHR5cGU6IFByZWxvYWRpbmdTdHJhdGVneVxuICB9LCB7XG4gICAgdHlwZTogUm91dGVyQ29uZmlnTG9hZGVyXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5jb25zdCBST1VURVJfU0NST0xMRVIgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSAhPT0gJ3VuZGVmaW5lZCcgJiYgbmdEZXZNb2RlID8gJ1JvdXRlciBTY3JvbGxlcicgOiAnJyk7XG5jbGFzcyBSb3V0ZXJTY3JvbGxlciB7XG4gIG9wdGlvbnM7XG4gIHJvdXRlckV2ZW50c1N1YnNjcmlwdGlvbjtcbiAgc2Nyb2xsRXZlbnRzU3Vic2NyaXB0aW9uO1xuICBsYXN0SWQgPSAwO1xuICBsYXN0U291cmNlID0gSU1QRVJBVElWRV9OQVZJR0FUSU9OO1xuICByZXN0b3JlZElkID0gMDtcbiAgc3RvcmUgPSB7fTtcbiAgaXNIeWRyYXRpbmcgPSBpbmplY3QoX0lTX0hZRFJBVElPTl9ET01fUkVVU0VfRU5BQkxFRCwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pID8/IGZhbHNlO1xuICB1cmxTZXJpYWxpemVyID0gaW5qZWN0KFVybFNlcmlhbGl6ZXIpO1xuICB6b25lID0gaW5qZWN0KE5nWm9uZSk7XG4gIHZpZXdwb3J0U2Nyb2xsZXIgPSBpbmplY3QoVmlld3BvcnRTY3JvbGxlcik7XG4gIHRyYW5zaXRpb25zID0gaW5qZWN0KE5hdmlnYXRpb25UcmFuc2l0aW9ucyk7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMub3B0aW9ucy5zY3JvbGxQb3NpdGlvblJlc3RvcmF0aW9uIHx8PSAnZGlzYWJsZWQnO1xuICAgIHRoaXMub3B0aW9ucy5hbmNob3JTY3JvbGxpbmcgfHw9ICdkaXNhYmxlZCc7XG4gICAgaWYgKHRoaXMuaXNIeWRyYXRpbmcpIHtcbiAgICAgIGluamVjdChBcHBsaWNhdGlvblJlZikud2hlblN0YWJsZSgpLnRoZW4oKCkgPT4ge1xuICAgICAgICB0aGlzLmlzSHlkcmF0aW5nID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgaW5pdCgpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLnNjcm9sbFBvc2l0aW9uUmVzdG9yYXRpb24gIT09ICdkaXNhYmxlZCcpIHtcbiAgICAgIHRoaXMudmlld3BvcnRTY3JvbGxlci5zZXRIaXN0b3J5U2Nyb2xsUmVzdG9yYXRpb24oJ21hbnVhbCcpO1xuICAgIH1cbiAgICB0aGlzLnJvdXRlckV2ZW50c1N1YnNjcmlwdGlvbiA9IHRoaXMuY3JlYXRlU2Nyb2xsRXZlbnRzKCk7XG4gICAgdGhpcy5zY3JvbGxFdmVudHNTdWJzY3JpcHRpb24gPSB0aGlzLmNvbnN1bWVTY3JvbGxFdmVudHMoKTtcbiAgfVxuICBjcmVhdGVTY3JvbGxFdmVudHMoKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNpdGlvbnMuZXZlbnRzLnN1YnNjcmliZShlID0+IHtcbiAgICAgIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvblN0YXJ0KSB7XG4gICAgICAgIHRoaXMuc3RvcmVbdGhpcy5sYXN0SWRdID0gdGhpcy52aWV3cG9ydFNjcm9sbGVyLmdldFNjcm9sbFBvc2l0aW9uKCk7XG4gICAgICAgIHRoaXMubGFzdFNvdXJjZSA9IGUubmF2aWdhdGlvblRyaWdnZXI7XG4gICAgICAgIHRoaXMucmVzdG9yZWRJZCA9IGUucmVzdG9yZWRTdGF0ZSA/IGUucmVzdG9yZWRTdGF0ZS5uYXZpZ2F0aW9uSWQgOiAwO1xuICAgICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xuICAgICAgICB0aGlzLmxhc3RJZCA9IGUuaWQ7XG4gICAgICAgIHRoaXMuc2NoZWR1bGVTY3JvbGxFdmVudChlLCB0aGlzLnVybFNlcmlhbGl6ZXIucGFyc2UoZS51cmxBZnRlclJlZGlyZWN0cykuZnJhZ21lbnQpO1xuICAgICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvblNraXBwZWQgJiYgZS5jb2RlID09PSBOYXZpZ2F0aW9uU2tpcHBlZENvZGUuSWdub3JlZFNhbWVVcmxOYXZpZ2F0aW9uKSB7XG4gICAgICAgIHRoaXMubGFzdFNvdXJjZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5yZXN0b3JlZElkID0gMDtcbiAgICAgICAgdGhpcy5zY2hlZHVsZVNjcm9sbEV2ZW50KGUsIHRoaXMudXJsU2VyaWFsaXplci5wYXJzZShlLnVybCkuZnJhZ21lbnQpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGNvbnN1bWVTY3JvbGxFdmVudHMoKSB7XG4gICAgcmV0dXJuIHRoaXMudHJhbnNpdGlvbnMuZXZlbnRzLnN1YnNjcmliZShlID0+IHtcbiAgICAgIGlmICghKGUgaW5zdGFuY2VvZiBTY3JvbGwpIHx8IGUuc2Nyb2xsQmVoYXZpb3IgPT09ICdtYW51YWwnKSByZXR1cm47XG4gICAgICBjb25zdCBpbnN0YW50U2Nyb2xsID0ge1xuICAgICAgICBiZWhhdmlvcjogJ2luc3RhbnQnXG4gICAgICB9O1xuICAgICAgaWYgKGUucG9zaXRpb24pIHtcbiAgICAgICAgaWYgKHRoaXMub3B0aW9ucy5zY3JvbGxQb3NpdGlvblJlc3RvcmF0aW9uID09PSAndG9wJykge1xuICAgICAgICAgIHRoaXMudmlld3BvcnRTY3JvbGxlci5zY3JvbGxUb1Bvc2l0aW9uKFswLCAwXSwgaW5zdGFudFNjcm9sbCk7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5vcHRpb25zLnNjcm9sbFBvc2l0aW9uUmVzdG9yYXRpb24gPT09ICdlbmFibGVkJykge1xuICAgICAgICAgIHRoaXMudmlld3BvcnRTY3JvbGxlci5zY3JvbGxUb1Bvc2l0aW9uKGUucG9zaXRpb24sIGluc3RhbnRTY3JvbGwpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoZS5hbmNob3IgJiYgdGhpcy5vcHRpb25zLmFuY2hvclNjcm9sbGluZyA9PT0gJ2VuYWJsZWQnKSB7XG4gICAgICAgICAgdGhpcy52aWV3cG9ydFNjcm9sbGVyLnNjcm9sbFRvQW5jaG9yKGUuYW5jaG9yKTtcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLm9wdGlvbnMuc2Nyb2xsUG9zaXRpb25SZXN0b3JhdGlvbiAhPT0gJ2Rpc2FibGVkJykge1xuICAgICAgICAgIHRoaXMudmlld3BvcnRTY3JvbGxlci5zY3JvbGxUb1Bvc2l0aW9uKFswLCAwXSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBzY2hlZHVsZVNjcm9sbEV2ZW50KHJvdXRlckV2ZW50LCBhbmNob3IpIHtcbiAgICBpZiAodGhpcy5pc0h5ZHJhdGluZykgcmV0dXJuO1xuICAgIGNvbnN0IHNjcm9sbCA9IHVudHJhY2tlZCh0aGlzLnRyYW5zaXRpb25zLmN1cnJlbnROYXZpZ2F0aW9uKT8uZXh0cmFzLnNjcm9sbDtcbiAgICB0aGlzLnpvbmUucnVuT3V0c2lkZUFuZ3VsYXIoYXN5bmMgKCkgPT4ge1xuICAgICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgIHNldFRpbWVvdXQocmVzb2x2ZSk7XG4gICAgICAgIGlmICh0eXBlb2YgcmVxdWVzdEFuaW1hdGlvbkZyYW1lICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZShyZXNvbHZlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICB0aGlzLnpvbmUucnVuKCgpID0+IHtcbiAgICAgICAgdGhpcy50cmFuc2l0aW9ucy5ldmVudHMubmV4dChuZXcgU2Nyb2xsKHJvdXRlckV2ZW50LCB0aGlzLmxhc3RTb3VyY2UgPT09ICdwb3BzdGF0ZScgPyB0aGlzLnN0b3JlW3RoaXMucmVzdG9yZWRJZF0gOiBudWxsLCBhbmNob3IsIHNjcm9sbCkpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbiAgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5yb3V0ZXJFdmVudHNTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gICAgdGhpcy5zY3JvbGxFdmVudHNTdWJzY3JpcHRpb24/LnVuc3Vic2NyaWJlKCk7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVyU2Nyb2xsZXJfRmFjdG9yeShfX25nRmFjdG9yeVR5cGVfXykge1xuICAgIGkwLsm1ybVpbnZhbGlkRmFjdG9yeSgpO1xuICB9O1xuICBzdGF0aWMgybVwcm92ID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdGFibGUoe1xuICAgIHRva2VuOiBSb3V0ZXJTY3JvbGxlcixcbiAgICBmYWN0b3J5OiBSb3V0ZXJTY3JvbGxlci7JtWZhY1xuICB9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJvdXRlclNjcm9sbGVyLCBbe1xuICAgIHR5cGU6IEluamVjdGFibGVcbiAgfV0sICgpID0+IFt7XG4gICAgdHlwZTogdW5kZWZpbmVkXG4gIH1dLCBudWxsKTtcbn0pKCk7XG5mdW5jdGlvbiBnZXRMb2FkZWRSb3V0ZXMocm91dGUpIHtcbiAgcmV0dXJuIHJvdXRlLl9sb2FkZWRSb3V0ZXM7XG59XG5mdW5jdGlvbiBnZXRSb3V0ZXJJbnN0YW5jZShpbmplY3Rvcikge1xuICByZXR1cm4gaW5qZWN0b3IuZ2V0KFJvdXRlciwgbnVsbCwge1xuICAgIG9wdGlvbmFsOiB0cnVlXG4gIH0pO1xufVxuZnVuY3Rpb24gbmF2aWdhdGVCeVVybChyb3V0ZXIsIHVybCkge1xuICBpZiAoIShyb3V0ZXIgaW5zdGFuY2VvZiBSb3V0ZXIpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdUaGUgcHJvdmlkZWQgcm91dGVyIGlzIG5vdCBhbiBBbmd1bGFyIFJvdXRlci4nKTtcbiAgfVxuICByZXR1cm4gcm91dGVyLm5hdmlnYXRlQnlVcmwodXJsKTtcbn1cbmNsYXNzIE5hdmlnYXRpb25TdGF0ZU1hbmFnZXIgZXh0ZW5kcyBTdGF0ZU1hbmFnZXIge1xuICBpbmplY3RvciA9IGluamVjdChFbnZpcm9ubWVudEluamVjdG9yKTtcbiAgbmF2aWdhdGlvbiA9IGluamVjdChQbGF0Zm9ybU5hdmlnYXRpb24pO1xuICBpbk1lbW9yeVNjcm9sbGluZ0VuYWJsZWQgPSBpbmplY3QoUk9VVEVSX1NDUk9MTEVSLCB7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSkgIT09IG51bGw7XG4gIGJhc2UgPSBuZXcgVVJMKGluamVjdChQbGF0Zm9ybUxvY2F0aW9uKS5ocmVmKS5vcmlnaW47XG4gIGFwcFJvb3RVcmwgPSBuZXcgVVJMKHRoaXMubG9jYXRpb24ucHJlcGFyZUV4dGVybmFsVXJsPy4oJy8nKSA/PyAnLycsIHRoaXMuYmFzZSk7XG4gIHByZWNvbW1pdEhhbmRsZXJTdXBwb3J0ZWQgPSBpbmplY3QoX1BSRUNPTU1JVF9IQU5ETEVSX1NVUFBPUlRFRCk7XG4gIGFjdGl2ZUhpc3RvcnlFbnRyeSA9IHRoaXMubmF2aWdhdGlvbi5jdXJyZW50RW50cnk7XG4gIGN1cnJlbnROYXZpZ2F0aW9uID0ge307XG4gIG5vblJvdXRlckN1cnJlbnRFbnRyeUNoYW5nZVN1YmplY3QgPSBuZXcgU3ViamVjdCgpO1xuICBub25Sb3V0ZXJFbnRyeUNoYW5nZUxpc3RlbmVyO1xuICBnZXQgcmVnaXN0ZXJlZCgpIHtcbiAgICByZXR1cm4gdGhpcy5ub25Sb3V0ZXJFbnRyeUNoYW5nZUxpc3RlbmVyICE9PSB1bmRlZmluZWQgJiYgIXRoaXMubm9uUm91dGVyRW50cnlDaGFuZ2VMaXN0ZW5lci5jbG9zZWQ7XG4gIH1cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgICBjb25zdCBuYXZpZ2F0ZUxpc3RlbmVyID0gZXZlbnQgPT4ge1xuICAgICAgdGhpcy5oYW5kbGVOYXZpZ2F0ZShldmVudCk7XG4gICAgfTtcbiAgICB0aGlzLm5hdmlnYXRpb24uYWRkRXZlbnRMaXN0ZW5lcignbmF2aWdhdGUnLCBuYXZpZ2F0ZUxpc3RlbmVyKTtcbiAgICBpbmplY3QoRGVzdHJveVJlZikub25EZXN0cm95KCgpID0+IHRoaXMubmF2aWdhdGlvbi5yZW1vdmVFdmVudExpc3RlbmVyKCduYXZpZ2F0ZScsIG5hdmlnYXRlTGlzdGVuZXIpKTtcbiAgfVxuICByZWdpc3Rlck5vblJvdXRlckN1cnJlbnRFbnRyeUNoYW5nZUxpc3RlbmVyKGxpc3RlbmVyKSB7XG4gICAgdGhpcy5hY3RpdmVIaXN0b3J5RW50cnkgPSB0aGlzLm5hdmlnYXRpb24uY3VycmVudEVudHJ5O1xuICAgIHRoaXMubm9uUm91dGVyRW50cnlDaGFuZ2VMaXN0ZW5lciA9IHRoaXMubm9uUm91dGVyQ3VycmVudEVudHJ5Q2hhbmdlU3ViamVjdC5zdWJzY3JpYmUoKHtcbiAgICAgIHBhdGgsXG4gICAgICBzdGF0ZVxuICAgIH0pID0+IHtcbiAgICAgIGxpc3RlbmVyKHBhdGgsIHN0YXRlLCAncG9wc3RhdGUnLCAhdGhpcy5wcmVjb21taXRIYW5kbGVyU3VwcG9ydGVkID8ge1xuICAgICAgICByZXBsYWNlVXJsOiB0cnVlXG4gICAgICB9IDoge30pO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzLm5vblJvdXRlckVudHJ5Q2hhbmdlTGlzdGVuZXI7XG4gIH1cbiAgYXN5bmMgaGFuZGxlUm91dGVyRXZlbnQoZSwgdHJhbnNpdGlvbikge1xuICAgIHRoaXMuY3VycmVudE5hdmlnYXRpb24gPSB7XG4gICAgICAuLi50aGlzLmN1cnJlbnROYXZpZ2F0aW9uLFxuICAgICAgcm91dGVyVHJhbnNpdGlvbjogdHJhbnNpdGlvblxuICAgIH07XG4gICAgaWYgKGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uU3RhcnQpIHtcbiAgICAgIHRoaXMudXBkYXRlU3RhdGVNZW1lbnRvKCk7XG4gICAgICBpZiAodGhpcy5wcmVjb21taXRIYW5kbGVyU3VwcG9ydGVkKSB7XG4gICAgICAgIHRoaXMubWF5YmVDcmVhdGVOYXZpZ2F0aW9uRm9yVHJhbnNpdGlvbih0cmFuc2l0aW9uKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uU2tpcHBlZCkge1xuICAgICAgdGhpcy5maW5pc2hOYXZpZ2F0aW9uKCk7XG4gICAgICB0aGlzLmNvbW1pdFRyYW5zaXRpb24odHJhbnNpdGlvbik7XG4gICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgQmVmb3JlUm91dGVzUmVjb2duaXplZCkge1xuICAgICAgdHJhbnNpdGlvbi5yb3V0ZXNSZWNvZ25pemVIYW5kbGVyLmRlZmVycmVkSGFuZGxlID0gbmV3IFByb21pc2UoYXN5bmMgcmVzb2x2ZSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnVybFVwZGF0ZVN0cmF0ZWd5ID09PSAnZWFnZXInKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMubWF5YmVDcmVhdGVOYXZpZ2F0aW9uRm9yVHJhbnNpdGlvbih0cmFuc2l0aW9uKTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuY3VycmVudE5hdmlnYXRpb24uY29tbWl0VXJsPy4oKTtcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgQmVmb3JlQWN0aXZhdGVSb3V0ZXMpIHtcbiAgICAgIHRyYW5zaXRpb24uYmVmb3JlQWN0aXZhdGVIYW5kbGVyLmRlZmVycmVkSGFuZGxlID0gbmV3IFByb21pc2UoYXN5bmMgcmVzb2x2ZSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnVybFVwZGF0ZVN0cmF0ZWd5ID09PSAnZGVmZXJyZWQnKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMubWF5YmVDcmVhdGVOYXZpZ2F0aW9uRm9yVHJhbnNpdGlvbih0cmFuc2l0aW9uKTtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuY3VycmVudE5hdmlnYXRpb24uY29tbWl0VXJsPy4oKTtcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jb21taXRUcmFuc2l0aW9uKHRyYW5zaXRpb24pO1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uQ2FuY2VsIHx8IGUgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uRXJyb3IpIHtcbiAgICAgIGNvbnN0IHJlZGlyZWN0aW5nQmVmb3JlVXJsQ29tbWl0ID0gZSBpbnN0YW5jZW9mIE5hdmlnYXRpb25DYW5jZWwgJiYgZS5jb2RlID09PSBOYXZpZ2F0aW9uQ2FuY2VsbGF0aW9uQ29kZS5SZWRpcmVjdCAmJiAhIXRoaXMuY3VycmVudE5hdmlnYXRpb24uY29tbWl0VXJsO1xuICAgICAgaWYgKHJlZGlyZWN0aW5nQmVmb3JlVXJsQ29tbWl0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHZvaWQgdGhpcy5jYW5jZWwodHJhbnNpdGlvbiwgZSk7XG4gICAgfSBlbHNlIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkge1xuICAgICAgY29uc3Qge1xuICAgICAgICByZXNvbHZlSGFuZGxlcixcbiAgICAgICAgcmVtb3ZlQWJvcnRMaXN0ZW5lclxuICAgICAgfSA9IHRoaXMuY3VycmVudE5hdmlnYXRpb247XG4gICAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uID0ge307XG4gICAgICByZW1vdmVBYm9ydExpc3RlbmVyPy4oKTtcbiAgICAgIHRoaXMuYWN0aXZlSGlzdG9yeUVudHJ5ID0gdGhpcy5uYXZpZ2F0aW9uLmN1cnJlbnRFbnRyeTtcbiAgICAgIGFmdGVyTmV4dFJlbmRlcih7XG4gICAgICAgIHJlYWQ6ICgpID0+IHJlc29sdmVIYW5kbGVyPy4oKVxuICAgICAgfSwge1xuICAgICAgICBpbmplY3RvcjogdGhpcy5pbmplY3RvclxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIG1heWJlQ3JlYXRlTmF2aWdhdGlvbkZvclRyYW5zaXRpb24odHJhbnNpdGlvbikge1xuICAgIGNvbnN0IHtcbiAgICAgIG5hdmlnYXRpb25FdmVudCxcbiAgICAgIGNvbW1pdFVybFxuICAgIH0gPSB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uO1xuICAgIGlmIChjb21taXRVcmwgfHwgbmF2aWdhdGlvbkV2ZW50ICYmIG5hdmlnYXRpb25FdmVudC5uYXZpZ2F0aW9uVHlwZSA9PT0gJ3RyYXZlcnNlJyAmJiB0aGlzLmV2ZW50QW5kUm91dGVyRGVzdGluYXRpb25zTWF0Y2gobmF2aWdhdGlvbkV2ZW50LCB0cmFuc2l0aW9uKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnJlbW92ZUFib3J0TGlzdGVuZXI/LigpO1xuICAgIGNvbnN0IHBhdGggPSB0aGlzLmNyZWF0ZUJyb3dzZXJQYXRoKHRyYW5zaXRpb24pO1xuICAgIHRoaXMubmF2aWdhdGUocGF0aCwgdHJhbnNpdGlvbik7XG4gIH1cbiAgbmF2aWdhdGUoaW50ZXJuYWxQYXRoLCB0cmFuc2l0aW9uKSB7XG4gICAgY29uc3QgcGF0aCA9IHRyYW5zaXRpb24uZXh0cmFzLnNraXBMb2NhdGlvbkNoYW5nZSA/IHRoaXMubmF2aWdhdGlvbi5jdXJyZW50RW50cnkudXJsIDogdGhpcy5sb2NhdGlvbi5wcmVwYXJlRXh0ZXJuYWxVcmwoaW50ZXJuYWxQYXRoKTtcbiAgICBjb25zdCBzdGF0ZSA9IHtcbiAgICAgIC4uLnRyYW5zaXRpb24uZXh0cmFzLnN0YXRlLFxuICAgICAgLi4udGhpcy5nZW5lcmF0ZU5nUm91dGVyU3RhdGUodHJhbnNpdGlvbilcbiAgICB9O1xuICAgIGNvbnN0IGluZm8gPSB7XG4gICAgICDJtXJvdXRlckluZm86IHtcbiAgICAgICAgaW50ZXJjZXB0OiB0cnVlXG4gICAgICB9XG4gICAgfTtcbiAgICBpZiAoIXRoaXMubmF2aWdhdGlvbi50cmFuc2l0aW9uICYmIHRoaXMuY3VycmVudE5hdmlnYXRpb24ubmF2aWdhdGlvbkV2ZW50KSB7XG4gICAgICB0cmFuc2l0aW9uLmV4dHJhcy5yZXBsYWNlVXJsID0gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IGhpc3RvcnkgPSB0aGlzLmxvY2F0aW9uLmlzQ3VycmVudFBhdGhFcXVhbFRvKHBhdGgpIHx8IHRyYW5zaXRpb24uZXh0cmFzLnJlcGxhY2VVcmwgfHwgdHJhbnNpdGlvbi5leHRyYXMuc2tpcExvY2F0aW9uQ2hhbmdlID8gJ3JlcGxhY2UnIDogJ3B1c2gnO1xuICAgIGhhbmRsZVJlc3VsdFJlamVjdGlvbnModGhpcy5uYXZpZ2F0aW9uLm5hdmlnYXRlKHBhdGgsIHtcbiAgICAgIHN0YXRlLFxuICAgICAgaGlzdG9yeSxcbiAgICAgIGluZm9cbiAgICB9KSk7XG4gIH1cbiAgZmluaXNoTmF2aWdhdGlvbigpIHtcbiAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLmNvbW1pdFVybD8uKCk7XG4gICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbj8ucmVzb2x2ZUhhbmRsZXI/LigpO1xuICAgIHRoaXMuY3VycmVudE5hdmlnYXRpb24gPSB7fTtcbiAgfVxuICBhc3luYyBjYW5jZWwodHJhbnNpdGlvbiwgY2F1c2UpIHtcbiAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnJlamVjdE5hdmlnYXRlRXZlbnQ/LigpO1xuICAgIGNvbnN0IGNsZWFyZWRTdGF0ZSA9IHt9O1xuICAgIHRoaXMuY3VycmVudE5hdmlnYXRpb24gPSBjbGVhcmVkU3RhdGU7XG4gICAgaWYgKGlzUmVkaXJlY3RpbmdFdmVudChjYXVzZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaXNUcmF2ZXJzYWxSZXNldCA9IHRoaXMuY2FuY2VsZWROYXZpZ2F0aW9uUmVzb2x1dGlvbiA9PT0gJ2NvbXB1dGVkJyAmJiB0aGlzLm5hdmlnYXRpb24uY3VycmVudEVudHJ5LmtleSAhPT0gdGhpcy5hY3RpdmVIaXN0b3J5RW50cnkua2V5O1xuICAgIHRoaXMucmVzZXRJbnRlcm5hbFN0YXRlKHRyYW5zaXRpb24uZmluYWxVcmwsIGlzVHJhdmVyc2FsUmVzZXQpO1xuICAgIGlmICh0aGlzLm5hdmlnYXRpb24uY3VycmVudEVudHJ5LmlkID09PSB0aGlzLmFjdGl2ZUhpc3RvcnlFbnRyeS5pZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY2F1c2UgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uQ2FuY2VsICYmIGNhdXNlLmNvZGUgPT09IE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLkFib3J0ZWQpIHtcbiAgICAgIGF3YWl0IFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgaWYgKHRoaXMuY3VycmVudE5hdmlnYXRpb24gIT09IGNsZWFyZWRTdGF0ZSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpc1RyYXZlcnNhbFJlc2V0KSB7XG4gICAgICBoYW5kbGVSZXN1bHRSZWplY3Rpb25zKHRoaXMubmF2aWdhdGlvbi50cmF2ZXJzZVRvKHRoaXMuYWN0aXZlSGlzdG9yeUVudHJ5LmtleSwge1xuICAgICAgICBpbmZvOiB7XG4gICAgICAgICAgybVyb3V0ZXJJbmZvOiB7XG4gICAgICAgICAgICBpbnRlcmNlcHQ6IGZhbHNlXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGludGVybmFsUGF0aCA9IHRoaXMudXJsU2VyaWFsaXplci5zZXJpYWxpemUodGhpcy5nZXRDdXJyZW50VXJsVHJlZSgpKTtcbiAgICAgIGNvbnN0IHBhdGhPclVybCA9IHRoaXMubG9jYXRpb24ucHJlcGFyZUV4dGVybmFsVXJsKGludGVybmFsUGF0aCk7XG4gICAgICBoYW5kbGVSZXN1bHRSZWplY3Rpb25zKHRoaXMubmF2aWdhdGlvbi5uYXZpZ2F0ZShwYXRoT3JVcmwsIHtcbiAgICAgICAgc3RhdGU6IHRoaXMuYWN0aXZlSGlzdG9yeUVudHJ5LmdldFN0YXRlKCksXG4gICAgICAgIGhpc3Rvcnk6ICdyZXBsYWNlJyxcbiAgICAgICAgaW5mbzoge1xuICAgICAgICAgIMm1cm91dGVySW5mbzoge1xuICAgICAgICAgICAgaW50ZXJjZXB0OiBmYWxzZVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSkpO1xuICAgIH1cbiAgfVxuICByZXNldEludGVybmFsU3RhdGUoZmluYWxVcmwsIHRyYXZlcnNhbFJlc2V0KSB7XG4gICAgdGhpcy5yb3V0ZXJTdGF0ZSA9IHRoaXMuc3RhdGVNZW1lbnRvLnJvdXRlclN0YXRlO1xuICAgIHRoaXMuY3VycmVudFVybFRyZWUgPSB0aGlzLnN0YXRlTWVtZW50by5jdXJyZW50VXJsVHJlZTtcbiAgICB0aGlzLnJhd1VybFRyZWUgPSB0cmF2ZXJzYWxSZXNldCA/IHRoaXMuc3RhdGVNZW1lbnRvLnJhd1VybFRyZWUgOiB0aGlzLnVybEhhbmRsaW5nU3RyYXRlZ3kubWVyZ2UodGhpcy5jdXJyZW50VXJsVHJlZSwgZmluYWxVcmwgPz8gdGhpcy5yYXdVcmxUcmVlKTtcbiAgfVxuICBoYW5kbGVOYXZpZ2F0ZShldmVudCkge1xuICAgIGlmICghZXZlbnQuY2FuSW50ZXJjZXB0IHx8IGV2ZW50Lm5hdmlnYXRpb25UeXBlID09PSAncmVsb2FkJykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCByb3V0ZXJJbmZvID0gZXZlbnQ/LmluZm8/Lsm1cm91dGVySW5mbztcbiAgICBpZiAocm91dGVySW5mbyAmJiAhcm91dGVySW5mby5pbnRlcmNlcHQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaXNUcmlnZ2VyZWRCeVJvdXRlclRyYW5zaXRpb24gPSAhIXJvdXRlckluZm87XG4gICAgaWYgKCFpc1RyaWdnZXJlZEJ5Um91dGVyVHJhbnNpdGlvbikge1xuICAgICAgY29uc3Qge1xuICAgICAgICBwYXRobmFtZTogZGVzdFBhdGhuYW1lLFxuICAgICAgICBvcmlnaW46IGRlc3RPcmlnaW5cbiAgICAgIH0gPSBuZXcgVVJMKGV2ZW50LmRlc3RpbmF0aW9uLnVybCk7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHBhdGhuYW1lOiByb290UGF0aG5hbWUsXG4gICAgICAgIG9yaWdpbjogYXBwT3JpZ2luXG4gICAgICB9ID0gdGhpcy5hcHBSb290VXJsO1xuICAgICAgY29uc3Qgcm9vdFBhdGggPSByb290UGF0aG5hbWUuZW5kc1dpdGgoJy8nKSA/IHJvb3RQYXRobmFtZSA6IHJvb3RQYXRobmFtZSArICcvJztcbiAgICAgIGlmIChkZXN0T3JpZ2luICE9PSBhcHBPcmlnaW4gfHwgZGVzdFBhdGhuYW1lICE9PSByb290UGF0aG5hbWUgJiYgIWRlc3RQYXRobmFtZS5zdGFydHNXaXRoKHJvb3RQYXRoKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnJvdXRlclRyYW5zaXRpb24/LmFib3J0KCk7XG4gICAgICBpZiAoIXRoaXMucmVnaXN0ZXJlZCkge1xuICAgICAgICB0aGlzLmZpbmlzaE5hdmlnYXRpb24oKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uID0ge1xuICAgICAgLi4udGhpcy5jdXJyZW50TmF2aWdhdGlvblxuICAgIH07XG4gICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbi5uYXZpZ2F0aW9uRXZlbnQgPSBldmVudDtcbiAgICBjb25zdCBhYm9ydEhhbmRsZXIgPSAoKSA9PiB7XG4gICAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnJvdXRlclRyYW5zaXRpb24/LmFib3J0KCk7XG4gICAgfTtcbiAgICBldmVudC5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydEhhbmRsZXIpO1xuICAgIHRoaXMuY3VycmVudE5hdmlnYXRpb24ucmVtb3ZlQWJvcnRMaXN0ZW5lciA9ICgpID0+IGV2ZW50LnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGFib3J0SGFuZGxlcik7XG4gICAgbGV0IHNjcm9sbCA9IHRoaXMuaW5NZW1vcnlTY3JvbGxpbmdFbmFibGVkID8gJ21hbnVhbCcgOiB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnJvdXRlclRyYW5zaXRpb24/LmV4dHJhcy5zY3JvbGwgPz8gJ2FmdGVyLXRyYW5zaXRpb24nO1xuICAgIGNvbnN0IGludGVyY2VwdE9wdGlvbnMgPSB7XG4gICAgICBzY3JvbGxcbiAgICB9O1xuICAgIGNvbnN0IHtcbiAgICAgIHByb21pc2U6IGhhbmRsZXJQcm9taXNlLFxuICAgICAgcmVzb2x2ZTogcmVzb2x2ZUhhbmRsZXIsXG4gICAgICByZWplY3Q6IHJlamVjdEhhbmRsZXJcbiAgICB9ID0gX3Byb21pc2VXaXRoUmVzb2x2ZXJzKCk7XG4gICAgY29uc3Qge1xuICAgICAgcHJvbWlzZTogcHJlY29tbWl0SGFuZGxlclByb21pc2UsXG4gICAgICByZXNvbHZlOiByZXNvbHZlUHJlY29tbWl0SGFuZGxlcixcbiAgICAgIHJlamVjdDogcmVqZWN0UHJlY29tbWl0SGFuZGxlclxuICAgIH0gPSBfcHJvbWlzZVdpdGhSZXNvbHZlcnMoKTtcbiAgICB0aGlzLmN1cnJlbnROYXZpZ2F0aW9uLnJlamVjdE5hdmlnYXRlRXZlbnQgPSAoKSA9PiB7XG4gICAgICBldmVudC5zaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydEhhbmRsZXIpO1xuICAgICAgcmVqZWN0UHJlY29tbWl0SGFuZGxlcigpO1xuICAgICAgcmVqZWN0SGFuZGxlcigpO1xuICAgIH07XG4gICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbi5yZXNvbHZlSGFuZGxlciA9ICgpID0+IHtcbiAgICAgIHRoaXMuY3VycmVudE5hdmlnYXRpb24ucmVtb3ZlQWJvcnRMaXN0ZW5lcj8uKCk7XG4gICAgICByZXNvbHZlSGFuZGxlcigpO1xuICAgIH07XG4gICAgaGFuZGxlclByb21pc2UuY2F0Y2goKCkgPT4ge30pO1xuICAgIHByZWNvbW1pdEhhbmRsZXJQcm9taXNlLmNhdGNoKCgpID0+IHt9KTtcbiAgICBpbnRlcmNlcHRPcHRpb25zLmhhbmRsZXIgPSAoKSA9PiBoYW5kbGVyUHJvbWlzZTtcbiAgICBpZiAodGhpcy5kZWZlcnJlZENvbW1pdFN1cHBvcnRlZChldmVudCkpIHtcbiAgICAgIGNvbnN0IHJlZGlyZWN0ID0gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgIGludGVyY2VwdE9wdGlvbnMucHJlY29tbWl0SGFuZGxlciA9IGNvbnRyb2xsZXIgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLm5hdmlnYXRpb24udHJhbnNpdGlvbj8ubmF2aWdhdGlvblR5cGUgPT09ICd0cmF2ZXJzZScpIHtcbiAgICAgICAgICAgIHJlc29sdmUoKCkgPT4ge30pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKGNvbnRyb2xsZXIucmVkaXJlY3QuYmluZChjb250cm9sbGVyKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBwcmVjb21taXRIYW5kbGVyUHJvbWlzZTtcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy5jdXJyZW50TmF2aWdhdGlvbi5jb21taXRVcmwgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHRoaXMuY3VycmVudE5hdmlnYXRpb24uY29tbWl0VXJsID0gdW5kZWZpbmVkO1xuICAgICAgICBjb25zdCB0cmFuc2l0aW9uID0gdGhpcy5jdXJyZW50TmF2aWdhdGlvbi5yb3V0ZXJUcmFuc2l0aW9uO1xuICAgICAgICBpZiAodHJhbnNpdGlvbiAmJiAhdHJhbnNpdGlvbi5leHRyYXMuc2tpcExvY2F0aW9uQ2hhbmdlKSB7XG4gICAgICAgICAgY29uc3QgaW50ZXJuYWxQYXRoID0gdGhpcy5jcmVhdGVCcm93c2VyUGF0aCh0cmFuc2l0aW9uKTtcbiAgICAgICAgICBjb25zdCBoaXN0b3J5ID0gdGhpcy5sb2NhdGlvbi5pc0N1cnJlbnRQYXRoRXF1YWxUbyhpbnRlcm5hbFBhdGgpIHx8ICEhdHJhbnNpdGlvbi5leHRyYXMucmVwbGFjZVVybCA/ICdyZXBsYWNlJyA6ICdwdXNoJztcbiAgICAgICAgICBjb25zdCBzdGF0ZSA9IHtcbiAgICAgICAgICAgIC4uLnRyYW5zaXRpb24uZXh0cmFzLnN0YXRlLFxuICAgICAgICAgICAgLi4udGhpcy5nZW5lcmF0ZU5nUm91dGVyU3RhdGUodHJhbnNpdGlvbilcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHBhdGhPclVybCA9IHRoaXMubG9jYXRpb24ucHJlcGFyZUV4dGVybmFsVXJsKGludGVybmFsUGF0aCk7XG4gICAgICAgICAgKGF3YWl0IHJlZGlyZWN0KShwYXRoT3JVcmwsIHtcbiAgICAgICAgICAgIHN0YXRlLFxuICAgICAgICAgICAgaGlzdG9yeVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJlc29sdmVQcmVjb21taXRIYW5kbGVyKCk7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm5hdmlnYXRpb24udHJhbnNpdGlvbj8uY29tbWl0dGVkO1xuICAgICAgfTtcbiAgICB9XG4gICAgZXZlbnQuaW50ZXJjZXB0KGludGVyY2VwdE9wdGlvbnMpO1xuICAgIGlmICghaXNUcmlnZ2VyZWRCeVJvdXRlclRyYW5zaXRpb24pIHtcbiAgICAgIHRoaXMuaGFuZGxlTmF2aWdhdGVFdmVudFRyaWdnZXJlZE91dHNpZGVSb3V0ZXJBUElzKGV2ZW50KTtcbiAgICB9XG4gIH1cbiAgaGFuZGxlTmF2aWdhdGVFdmVudFRyaWdnZXJlZE91dHNpZGVSb3V0ZXJBUElzKGV2ZW50KSB7XG4gICAgY29uc3QgcGF0aCA9IGV2ZW50LmRlc3RpbmF0aW9uLnVybC5zdWJzdHJpbmcodGhpcy5hcHBSb290VXJsLmhyZWYubGVuZ3RoIC0gMSk7XG4gICAgY29uc3Qgc3RhdGUgPSBldmVudC5kZXN0aW5hdGlvbi5nZXRTdGF0ZSgpO1xuICAgIHRoaXMubm9uUm91dGVyQ3VycmVudEVudHJ5Q2hhbmdlU3ViamVjdC5uZXh0KHtcbiAgICAgIHBhdGgsXG4gICAgICBzdGF0ZVxuICAgIH0pO1xuICB9XG4gIGV2ZW50QW5kUm91dGVyRGVzdGluYXRpb25zTWF0Y2gobmF2aWdhdGVFdmVudCwgdHJhbnNpdGlvbikge1xuICAgIGNvbnN0IGludGVybmFsUGF0aCA9IHRoaXMuY3JlYXRlQnJvd3NlclBhdGgodHJhbnNpdGlvbik7XG4gICAgY29uc3QgZXZlbnREZXN0aW5hdGlvbiA9IG5ldyBVUkwobmF2aWdhdGVFdmVudC5kZXN0aW5hdGlvbi51cmwpO1xuICAgIGNvbnN0IHJvdXRlckRlc3RpbmF0aW9uID0gbmV3IFVSTCh0aGlzLmxvY2F0aW9uLnByZXBhcmVFeHRlcm5hbFVybChpbnRlcm5hbFBhdGgpLCBldmVudERlc3RpbmF0aW9uLm9yaWdpbik7XG4gICAgZXZlbnREZXN0aW5hdGlvbi5zZWFyY2hQYXJhbXMuc29ydCgpO1xuICAgIHJvdXRlckRlc3RpbmF0aW9uLnNlYXJjaFBhcmFtcy5zb3J0KCk7XG4gICAgY29uc3Qge1xuICAgICAgcGF0aG5hbWU6IGRlc3RQYXRobmFtZSxcbiAgICAgIHNlYXJjaDogZGVzdFNlYXJjaCxcbiAgICAgIGhhc2g6IGhhc2hEZXN0XG4gICAgfSA9IHJvdXRlckRlc3RpbmF0aW9uO1xuICAgIGNvbnN0IHtcbiAgICAgIHBhdGhuYW1lOiBldmVudERlc3RQYXRobmFtZSxcbiAgICAgIHNlYXJjaDogZXZlbnREZXN0U2VhcmNoLFxuICAgICAgaGFzaDogZXZlbnREZXN0SGFzaFxuICAgIH0gPSBldmVudERlc3RpbmF0aW9uO1xuICAgIHJldHVybiBkZXN0U2VhcmNoID09PSBldmVudERlc3RTZWFyY2ggJiYgaGFzaERlc3QgPT09IGV2ZW50RGVzdEhhc2ggJiYgTG9jYXRpb24uc3RyaXBUcmFpbGluZ1NsYXNoKGRlc3RQYXRobmFtZSkgPT09IExvY2F0aW9uLnN0cmlwVHJhaWxpbmdTbGFzaChldmVudERlc3RQYXRobmFtZSk7XG4gIH1cbiAgZ2VuZXJhdGVOZ1JvdXRlclN0YXRlKHRyYW5zaXRpb24pIHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4udGhpcy5yb3V0ZXJVcmxTdGF0ZSh0cmFuc2l0aW9uKSxcbiAgICAgIG5hdmlnYXRpb25JZDogdHJhbnNpdGlvbi5pZFxuICAgIH07XG4gIH1cbiAgZGVmZXJyZWRDb21taXRTdXBwb3J0ZWQoZXZlbnQpIHtcbiAgICByZXR1cm4gdGhpcy5wcmVjb21taXRIYW5kbGVyU3VwcG9ydGVkICYmIGV2ZW50LmNhbmNlbGFibGU7XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gTmF2aWdhdGlvblN0YXRlTWFuYWdlcl9GYWN0b3J5KF9fbmdGYWN0b3J5VHlwZV9fKSB7XG4gICAgcmV0dXJuIG5ldyAoX19uZ0ZhY3RvcnlUeXBlX18gfHwgTmF2aWdhdGlvblN0YXRlTWFuYWdlcikoKTtcbiAgfTtcbiAgc3RhdGljIMm1cHJvdiA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVTZXJ2aWNlKHtcbiAgICB0b2tlbjogTmF2aWdhdGlvblN0YXRlTWFuYWdlcixcbiAgICBmYWN0b3J5OiBOYXZpZ2F0aW9uU3RhdGVNYW5hZ2VyLsm1ZmFjXG4gIH0pO1xufVxuKCgpID0+IHtcbiAgKHR5cGVvZiBuZ0Rldk1vZGUgPT09IFwidW5kZWZpbmVkXCIgfHwgbmdEZXZNb2RlKSAmJiBpMC7JtXNldENsYXNzTWV0YWRhdGEoTmF2aWdhdGlvblN0YXRlTWFuYWdlciwgW3tcbiAgICB0eXBlOiBTZXJ2aWNlXG4gIH1dLCAoKSA9PiBbXSwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gaGFuZGxlUmVzdWx0UmVqZWN0aW9ucyhyZXN1bHQpIHtcbiAgcmVzdWx0LmZpbmlzaGVkPy5jYXRjaCgoKSA9PiB7fSk7XG4gIHJlc3VsdC5jb21taXR0ZWQ/LmNhdGNoKCgpID0+IHt9KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHNldHVwQWN0aXZhdGVkUm91dGVJbmplY3RvcnMoKSB7XG4gIHJldHVybiB0YXAoKHtcbiAgICBuZXdseUNyZWF0ZWRSb3V0ZXMsXG4gICAgdGFyZ2V0Um91dGVyU3RhdGVcbiAgfSkgPT4ge1xuICAgIGlmICghbmV3bHlDcmVhdGVkUm91dGVzIHx8ICF0YXJnZXRSb3V0ZXJTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0cmF2ZXJzZSA9IHN0YXRlTm9kZSA9PiB7XG4gICAgICBjb25zdCByb3V0ZSA9IHN0YXRlTm9kZS52YWx1ZTtcbiAgICAgIGlmIChyb3V0ZSkge1xuICAgICAgICBwcm9jZXNzUm91dGUocm91dGUsIG5ld2x5Q3JlYXRlZFJvdXRlcyk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGNoaWxkU3RhdGUgb2Ygc3RhdGVOb2RlLmNoaWxkcmVuKSB7XG4gICAgICAgIHRyYXZlcnNlKGNoaWxkU3RhdGUpO1xuICAgICAgfVxuICAgIH07XG4gICAgdHJhdmVyc2UodGFyZ2V0Um91dGVyU3RhdGUuX3Jvb3QpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NSb3V0ZShyb3V0ZSwgbmV3bHlDcmVhdGVkUm91dGVzKSB7XG4gIGNvbnN0IHVzZUFjdGl2YXRlZFJvdXRlSW5qZWN0b3IgPSByb3V0ZT8ucm91dGVDb25maWc/Lsm1VXNlQWN0aXZhdGVkUm91dGVJbmplY3RvcjtcbiAgaWYgKCF1c2VBY3RpdmF0ZWRSb3V0ZUluamVjdG9yKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChuZXdseUNyZWF0ZWRSb3V0ZXMuaGFzKHJvdXRlKSkge1xuICAgIHNldHVwTmV3QWN0aXZhdGVkUm91dGVJbmplY3Rvcihyb3V0ZS5fZnV0dXJlU25hcHNob3QsIHJvdXRlKTtcbiAgfVxufVxuZnVuY3Rpb24gc2V0dXBOZXdBY3RpdmF0ZWRSb3V0ZUluamVjdG9yKHNuYXBzaG90LCByb3V0ZSkge1xuICBpZiAobmdEZXZNb2RlICYmICEhcm91dGUuX2xvY2FsSW5qZWN0b3IpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgc3RhdGU6IF9sb2NhbEluamVjdG9yIHNob3VsZCBub3QgZXhpc3Qgb24gbmV3bHkgY3JlYXRlZCBBY3RpdmF0ZWRSb3V0ZSB5ZXQnKTtcbiAgfVxuICByb3V0ZS5fbG9jYWxJbmplY3RvciA9IGNyZWF0ZUVudmlyb25tZW50SW5qZWN0b3IoW10sIHNuYXBzaG90Ll9lbnZpcm9ubWVudEluamVjdG9yKTtcbn1cbmZ1bmN0aW9uIHByb3ZpZGVSb3V0ZXIocm91dGVzLCAuLi5mZWF0dXJlcykge1xuICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgX3B1Ymxpc2hOb25Db3JlR2xvYmFsVXRpbCgnybVnZXRMb2FkZWRSb3V0ZXMnLCBnZXRMb2FkZWRSb3V0ZXMpO1xuICAgIF9wdWJsaXNoTm9uQ29yZUdsb2JhbFV0aWwoJ8m1Z2V0Um91dGVySW5zdGFuY2UnLCBnZXRSb3V0ZXJJbnN0YW5jZSk7XG4gICAgX3B1Ymxpc2hOb25Db3JlR2xvYmFsVXRpbCgnybVuYXZpZ2F0ZUJ5VXJsJywgbmF2aWdhdGVCeVVybCk7XG4gIH1cbiAgcmV0dXJuIG1ha2VFbnZpcm9ubWVudFByb3ZpZGVycyhbe1xuICAgIHByb3ZpZGU6IFJPVVRFUyxcbiAgICBtdWx0aTogdHJ1ZSxcbiAgICB1c2VWYWx1ZTogcm91dGVzXG4gIH0sIHtcbiAgICBwcm92aWRlOiBBY3RpdmF0ZWRSb3V0ZSxcbiAgICB1c2VGYWN0b3J5OiByb290Um91dGVcbiAgfSwge1xuICAgIHByb3ZpZGU6IEFQUF9CT09UU1RSQVBfTElTVEVORVIsXG4gICAgbXVsdGk6IHRydWUsXG4gICAgdXNlRmFjdG9yeTogZ2V0Qm9vdHN0cmFwTGlzdGVuZXJcbiAgfSwgZmVhdHVyZXMubWFwKGZlYXR1cmUgPT4gZmVhdHVyZS7JtXByb3ZpZGVycyldKTtcbn1cbmZ1bmN0aW9uIHJvb3RSb3V0ZSgpIHtcbiAgcmV0dXJuIGluamVjdChSb3V0ZXIpLnJvdXRlclN0YXRlLnJvb3Q7XG59XG5mdW5jdGlvbiByb3V0ZXJGZWF0dXJlKGtpbmQsIHByb3ZpZGVycykge1xuICByZXR1cm4ge1xuICAgIMm1a2luZDoga2luZCxcbiAgICDJtXByb3ZpZGVyczogcHJvdmlkZXJzXG4gIH07XG59XG5mdW5jdGlvbiB3aXRoSW5NZW1vcnlTY3JvbGxpbmcob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHByb3ZpZGVycyA9IFt7XG4gICAgcHJvdmlkZTogUk9VVEVSX1NDUk9MTEVSLFxuICAgIHVzZUZhY3Rvcnk6ICgpID0+IG5ldyBSb3V0ZXJTY3JvbGxlcihvcHRpb25zKVxuICB9XTtcbiAgcmV0dXJuIHJvdXRlckZlYXR1cmUoNCwgcHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhFeHBlcmltZW50YWxQbGF0Zm9ybU5hdmlnYXRpb24oKSB7XG4gIGNvbnN0IGRldk1vZGVMb2NhdGlvbkNoZWNrID0gdHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gW3Byb3ZpZGVFbnZpcm9ubWVudEluaXRpYWxpemVyKCgpID0+IHtcbiAgICBjb25zdCBsb2NhdGlvbkluc3RhbmNlID0gaW5qZWN0KExvY2F0aW9uKTtcbiAgICBpZiAoIShsb2NhdGlvbkluc3RhbmNlIGluc3RhbmNlb2YgX05hdmlnYXRpb25BZGFwdGVyRm9yTG9jYXRpb24pKSB7XG4gICAgICBjb25zdCBsb2NhdGlvbkNvbnN0cnVjdG9yTmFtZSA9IGxvY2F0aW9uSW5zdGFuY2UuY29uc3RydWN0b3IubmFtZTtcbiAgICAgIGxldCBtZXNzYWdlID0gYCd3aXRoRXhwZXJpbWVudGFsUGxhdGZvcm1OYXZpZ2F0aW9uJyBwcm92aWRlcyBhICdMb2NhdGlvbicgaW1wbGVtZW50YXRpb24gdGhhdCBlbnN1cmVzIG5hdmlnYXRpb24gQVBJcyBhcmUgY29uc2lzdGVudGx5IHVzZWQuYCArIGAgQW4gaW5zdGFuY2Ugb2YgJHtsb2NhdGlvbkNvbnN0cnVjdG9yTmFtZX0gd2FzIGZvdW5kIGluc3RlYWQuYDtcbiAgICAgIGlmIChsb2NhdGlvbkNvbnN0cnVjdG9yTmFtZSA9PT0gJ1NweUxvY2F0aW9uJykge1xuICAgICAgICBtZXNzYWdlICs9IGAgT25lIG9mICdSb3V0ZXJUZXN0aW5nTW9kdWxlJyBvciAncHJvdmlkZUxvY2F0aW9uTW9ja3MnIHdhcyBsaWtlbHkgdXNlZC4gJ3dpdGhFeHBlcmltZW50YWxQbGF0Zm9ybU5hdmlnYXRpb24nIGRvZXMgbm90IHdvcmsgd2l0aCB0aGVzZSBiZWNhdXNlIHRoZXkgb3ZlcnJpZGUgdGhlIExvY2F0aW9uIGltcGxlbWVudGF0aW9uLmA7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgfVxuICB9KV0gOiBbXTtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICBwcm92aWRlOiBTdGF0ZU1hbmFnZXIsXG4gICAgdXNlRXhpc3Rpbmc6IE5hdmlnYXRpb25TdGF0ZU1hbmFnZXJcbiAgfSwge1xuICAgIHByb3ZpZGU6IExvY2F0aW9uLFxuICAgIHVzZUNsYXNzOiBfTmF2aWdhdGlvbkFkYXB0ZXJGb3JMb2NhdGlvblxuICB9LCBkZXZNb2RlTG9jYXRpb25DaGVja107XG4gIHJldHVybiByb3V0ZXJGZWF0dXJlKDExLCBwcm92aWRlcnMpO1xufVxuZnVuY3Rpb24gZ2V0Qm9vdHN0cmFwTGlzdGVuZXIoKSB7XG4gIGNvbnN0IGluamVjdG9yID0gaW5qZWN0KEluamVjdG9yKTtcbiAgcmV0dXJuIGJvb3RzdHJhcHBlZENvbXBvbmVudFJlZiA9PiB7XG4gICAgY29uc3QgcmVmID0gaW5qZWN0b3IuZ2V0KEFwcGxpY2F0aW9uUmVmKTtcbiAgICBpZiAoYm9vdHN0cmFwcGVkQ29tcG9uZW50UmVmICE9PSByZWYuY29tcG9uZW50c1swXSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCByb3V0ZXIgPSBpbmplY3Rvci5nZXQoUm91dGVyKTtcbiAgICBjb25zdCBib290c3RyYXBEb25lID0gaW5qZWN0b3IuZ2V0KEJPT1RTVFJBUF9ET05FKTtcbiAgICBpZiAoaW5qZWN0b3IuZ2V0KElOSVRJQUxfTkFWSUdBVElPTikgPT09IDEpIHtcbiAgICAgIHJvdXRlci5pbml0aWFsTmF2aWdhdGlvbigpO1xuICAgIH1cbiAgICBpbmplY3Rvci5nZXQoUk9VVEVSX1BSRUxPQURFUiwgbnVsbCwge1xuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9KT8uc2V0VXBQcmVsb2FkaW5nKCk7XG4gICAgaW5qZWN0b3IuZ2V0KFJPVVRFUl9TQ1JPTExFUiwgbnVsbCwge1xuICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICB9KT8uaW5pdCgpO1xuICAgIHJvdXRlci5yZXNldFJvb3RDb21wb25lbnRUeXBlKHJlZi5jb21wb25lbnRUeXBlc1swXSk7XG4gICAgaWYgKCFib290c3RyYXBEb25lLmNsb3NlZCkge1xuICAgICAgYm9vdHN0cmFwRG9uZS5uZXh0KCk7XG4gICAgICBib290c3RyYXBEb25lLmNvbXBsZXRlKCk7XG4gICAgICBib290c3RyYXBEb25lLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuICB9O1xufVxuY29uc3QgQk9PVFNUUkFQX0RPTkUgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ2Jvb3RzdHJhcCBkb25lIGluZGljYXRvcicgOiAnJywge1xuICBmYWN0b3J5OiAoKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBTdWJqZWN0KCk7XG4gIH1cbn0pO1xuY29uc3QgSU5JVElBTF9OQVZJR0FUSU9OID0gbmV3IEluamVjdGlvblRva2VuKHR5cGVvZiBuZ0Rldk1vZGUgPT09ICd1bmRlZmluZWQnIHx8IG5nRGV2TW9kZSA/ICdpbml0aWFsIG5hdmlnYXRpb24nIDogJycsIHtcbiAgZmFjdG9yeTogKCkgPT4gMVxufSk7XG5mdW5jdGlvbiB3aXRoRW5hYmxlZEJsb2NraW5nSW5pdGlhbE5hdmlnYXRpb24oKSB7XG4gIGNvbnN0IHByb3ZpZGVycyA9IFt7XG4gICAgcHJvdmlkZTogX0lTX0VOQUJMRURfQkxPQ0tJTkdfSU5JVElBTF9OQVZJR0FUSU9OLFxuICAgIHVzZVZhbHVlOiB0cnVlXG4gIH0sIHtcbiAgICBwcm92aWRlOiBJTklUSUFMX05BVklHQVRJT04sXG4gICAgdXNlVmFsdWU6IDBcbiAgfSwgcHJvdmlkZUFwcEluaXRpYWxpemVyKCgpID0+IHtcbiAgICBjb25zdCBpbmplY3RvciA9IGluamVjdChJbmplY3Rvcik7XG4gICAgY29uc3QgbG9jYXRpb25Jbml0aWFsaXplZCA9IGluamVjdG9yLmdldChMT0NBVElPTl9JTklUSUFMSVpFRCwgUHJvbWlzZS5yZXNvbHZlKCkpO1xuICAgIHJldHVybiBsb2NhdGlvbkluaXRpYWxpemVkLnRoZW4oKCkgPT4ge1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICBjb25zdCByb3V0ZXIgPSBpbmplY3Rvci5nZXQoUm91dGVyKTtcbiAgICAgICAgY29uc3QgYm9vdHN0cmFwRG9uZSA9IGluamVjdG9yLmdldChCT09UU1RSQVBfRE9ORSk7XG4gICAgICAgIGFmdGVyTmV4dE5hdmlnYXRpb24ocm91dGVyLCAoKSA9PiB7XG4gICAgICAgICAgcmVzb2x2ZSh0cnVlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGluamVjdG9yLmdldChOYXZpZ2F0aW9uVHJhbnNpdGlvbnMpLmFmdGVyUHJlYWN0aXZhdGlvbiA9ICgpID0+IHtcbiAgICAgICAgICByZXNvbHZlKHRydWUpO1xuICAgICAgICAgIHJldHVybiBib290c3RyYXBEb25lLmNsb3NlZCA/IG9mKHZvaWQgMCkgOiBib290c3RyYXBEb25lO1xuICAgICAgICB9O1xuICAgICAgICByb3V0ZXIuaW5pdGlhbE5hdmlnYXRpb24oKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9KV07XG4gIHJldHVybiByb3V0ZXJGZWF0dXJlKDIsIHByb3ZpZGVycyk7XG59XG5mdW5jdGlvbiB3aXRoRGlzYWJsZWRJbml0aWFsTmF2aWdhdGlvbigpIHtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3Byb3ZpZGVBcHBJbml0aWFsaXplcigoKSA9PiB7XG4gICAgaW5qZWN0KFJvdXRlcikuc2V0VXBMb2NhdGlvbkNoYW5nZUxpc3RlbmVyKCk7XG4gIH0pLCB7XG4gICAgcHJvdmlkZTogSU5JVElBTF9OQVZJR0FUSU9OLFxuICAgIHVzZVZhbHVlOiAyXG4gIH1dO1xuICByZXR1cm4gcm91dGVyRmVhdHVyZSgzLCBwcm92aWRlcnMpO1xufVxuZnVuY3Rpb24gd2l0aERlYnVnVHJhY2luZygpIHtcbiAgbGV0IHByb3ZpZGVycyA9IFtdO1xuICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgcHJvdmlkZXJzID0gW3tcbiAgICAgIHByb3ZpZGU6IEVOVklST05NRU5UX0lOSVRJQUxJWkVSLFxuICAgICAgbXVsdGk6IHRydWUsXG4gICAgICB1c2VGYWN0b3J5OiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xuICAgICAgICByZXR1cm4gKCkgPT4gcm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoZSA9PiB7XG4gICAgICAgICAgY29uc29sZS5ncm91cD8uKGBSb3V0ZXIgRXZlbnQ6ICR7ZS5jb25zdHJ1Y3Rvci5uYW1lfWApO1xuICAgICAgICAgIGNvbnNvbGUubG9nKHN0cmluZ2lmeUV2ZW50KGUpKTtcbiAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICBjb25zb2xlLmdyb3VwRW5kPy4oKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfV07XG4gIH0gZWxzZSB7XG4gICAgcHJvdmlkZXJzID0gW107XG4gIH1cbiAgcmV0dXJuIHJvdXRlckZlYXR1cmUoMSwgcHJvdmlkZXJzKTtcbn1cbmNvbnN0IFJPVVRFUl9QUkVMT0FERVIgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ3JvdXRlciBwcmVsb2FkZXInIDogJycpO1xuZnVuY3Rpb24gd2l0aFByZWxvYWRpbmcocHJlbG9hZGluZ1N0cmF0ZWd5KSB7XG4gIGNvbnN0IHByb3ZpZGVycyA9IFt7XG4gICAgcHJvdmlkZTogUk9VVEVSX1BSRUxPQURFUixcbiAgICB1c2VFeGlzdGluZzogUm91dGVyUHJlbG9hZGVyXG4gIH0sIHtcbiAgICBwcm92aWRlOiBQcmVsb2FkaW5nU3RyYXRlZ3ksXG4gICAgdXNlRXhpc3Rpbmc6IHByZWxvYWRpbmdTdHJhdGVneVxuICB9XTtcbiAgcmV0dXJuIHJvdXRlckZlYXR1cmUoMCwgcHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhSb3V0ZXJDb25maWcob3B0aW9ucykge1xuICBjb25zdCBwcm92aWRlcnMgPSBbe1xuICAgIHByb3ZpZGU6IFJPVVRFUl9DT05GSUdVUkFUSU9OLFxuICAgIHVzZVZhbHVlOiBvcHRpb25zXG4gIH1dO1xuICByZXR1cm4gcm91dGVyRmVhdHVyZSg1LCBwcm92aWRlcnMpO1xufVxuZnVuY3Rpb24gd2l0aEhhc2hMb2NhdGlvbigpIHtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICBwcm92aWRlOiBMb2NhdGlvblN0cmF0ZWd5LFxuICAgIHVzZUNsYXNzOiBIYXNoTG9jYXRpb25TdHJhdGVneVxuICB9XTtcbiAgcmV0dXJuIHJvdXRlckZlYXR1cmUoNiwgcHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhOYXZpZ2F0aW9uRXJyb3JIYW5kbGVyKGhhbmRsZXIpIHtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICBwcm92aWRlOiBOQVZJR0FUSU9OX0VSUk9SX0hBTkRMRVIsXG4gICAgdXNlVmFsdWU6IGhhbmRsZXJcbiAgfV07XG4gIHJldHVybiByb3V0ZXJGZWF0dXJlKDcsIHByb3ZpZGVycyk7XG59XG5mdW5jdGlvbiB3aXRoRXhwZXJpbWVudGFsQXV0b0NsZWFudXBJbmplY3RvcnMoKSB7XG4gIHJldHVybiByb3V0ZXJGZWF0dXJlKDEwLCBbe1xuICAgIHByb3ZpZGU6IFJPVVRFX0lOSkVDVE9SX0NMRUFOVVAsXG4gICAgdXNlVmFsdWU6IHJvdXRlSW5qZWN0b3JDbGVhbnVwXG4gIH1dKTtcbn1cbmZ1bmN0aW9uIHdpdGhDb21wb25lbnRJbnB1dEJpbmRpbmcob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHByb3ZpZGVycyA9IFt7XG4gICAgcHJvdmlkZTogSU5QVVRfQklOREVSLFxuICAgIHVzZUZhY3Rvcnk6ICgpID0+IG5ldyBSb3V0ZWRDb21wb25lbnRJbnB1dEJpbmRlcihvcHRpb25zKVxuICB9XTtcbiAgcmV0dXJuIHJvdXRlckZlYXR1cmUoOCwgcHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhWaWV3VHJhbnNpdGlvbnMob3B0aW9ucykge1xuICBfcGVyZm9ybWFuY2VNYXJrRmVhdHVyZSgnTmdSb3V0ZXJWaWV3VHJhbnNpdGlvbnMnKTtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICBwcm92aWRlOiBDUkVBVEVfVklFV19UUkFOU0lUSU9OLFxuICAgIHVzZVZhbHVlOiBjcmVhdGVWaWV3VHJhbnNpdGlvblxuICB9LCB7XG4gICAgcHJvdmlkZTogVklFV19UUkFOU0lUSU9OX09QVElPTlMsXG4gICAgdXNlVmFsdWU6IHtcbiAgICAgIHNraXBOZXh0VHJhbnNpdGlvbjogISFvcHRpb25zPy5za2lwSW5pdGlhbFRyYW5zaXRpb24sXG4gICAgICAuLi5vcHRpb25zXG4gICAgfVxuICB9XTtcbiAgcmV0dXJuIHJvdXRlckZlYXR1cmUoOSwgcHJvdmlkZXJzKTtcbn1cbmZ1bmN0aW9uIHdpdGhBY3RpdmF0ZWRSb3V0ZUluamVjdG9ycygpIHtcbiAgY29uc3QgcHJvdmlkZXJzID0gW3tcbiAgICBwcm92aWRlOiBBQ1RJVkFURURfUk9VVEVfSU5KRUNUT1JfRkVBVFVSRSxcbiAgICB1c2VWYWx1ZToge1xuICAgICAgb3BlcmF0b3I6IHNldHVwQWN0aXZhdGVkUm91dGVJbmplY3RvcnNcbiAgICB9XG4gIH1dO1xuICByZXR1cm4gcm91dGVyRmVhdHVyZSg5LCBwcm92aWRlcnMpO1xufVxuY29uc3QgUk9VVEVSX0RJUkVDVElWRVMgPSBbUm91dGVyT3V0bGV0LCBSb3V0ZXJMaW5rLCBSb3V0ZXJMaW5rQWN0aXZlLCBfRW1wdHlPdXRsZXRDb21wb25lbnRdO1xuY29uc3QgUk9VVEVSX0ZPUlJPT1RfR1VBUkQgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ3JvdXRlciBkdXBsaWNhdGUgZm9yUm9vdCBndWFyZCcgOiAnJyk7XG5jb25zdCBST1VURVJfUFJPVklERVJTID0gW0xvY2F0aW9uLCB7XG4gIHByb3ZpZGU6IFVybFNlcmlhbGl6ZXIsXG4gIHVzZUNsYXNzOiBEZWZhdWx0VXJsU2VyaWFsaXplclxufSwgUm91dGVyLCBDaGlsZHJlbk91dGxldENvbnRleHRzLCB7XG4gIHByb3ZpZGU6IEFjdGl2YXRlZFJvdXRlLFxuICB1c2VGYWN0b3J5OiByb290Um91dGVcbn0sIFJvdXRlckNvbmZpZ0xvYWRlcl07XG5jbGFzcyBSb3V0ZXJNb2R1bGUge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBpZiAodHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlKSB7XG4gICAgICBpbmplY3QoUk9VVEVSX0ZPUlJPT1RfR1VBUkQsIHtcbiAgICAgICAgb3B0aW9uYWw6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBzdGF0aWMgZm9yUm9vdChyb3V0ZXMsIGNvbmZpZykge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogUm91dGVyTW9kdWxlLFxuICAgICAgcHJvdmlkZXJzOiBbUk9VVEVSX1BST1ZJREVSUywgdHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gY29uZmlnPy5lbmFibGVUcmFjaW5nID8gd2l0aERlYnVnVHJhY2luZygpLsm1cHJvdmlkZXJzIDogW10gOiBbXSwge1xuICAgICAgICBwcm92aWRlOiBST1VURVMsXG4gICAgICAgIG11bHRpOiB0cnVlLFxuICAgICAgICB1c2VWYWx1ZTogcm91dGVzXG4gICAgICB9LCB0eXBlb2YgbmdEZXZNb2RlID09PSAndW5kZWZpbmVkJyB8fCBuZ0Rldk1vZGUgPyB7XG4gICAgICAgIHByb3ZpZGU6IFJPVVRFUl9GT1JST09UX0dVQVJELFxuICAgICAgICB1c2VGYWN0b3J5OiBwcm92aWRlRm9yUm9vdEd1YXJkXG4gICAgICB9IDogW10sIGNvbmZpZz8uZXJyb3JIYW5kbGVyID8ge1xuICAgICAgICBwcm92aWRlOiBOQVZJR0FUSU9OX0VSUk9SX0hBTkRMRVIsXG4gICAgICAgIHVzZVZhbHVlOiBjb25maWcuZXJyb3JIYW5kbGVyXG4gICAgICB9IDogW10sIHtcbiAgICAgICAgcHJvdmlkZTogUk9VVEVSX0NPTkZJR1VSQVRJT04sXG4gICAgICAgIHVzZVZhbHVlOiBjb25maWcgPyBjb25maWcgOiB7fVxuICAgICAgfSwgY29uZmlnPy51c2VIYXNoID8gcHJvdmlkZUhhc2hMb2NhdGlvblN0cmF0ZWd5KCkgOiBwcm92aWRlUGF0aExvY2F0aW9uU3RyYXRlZ3koKSwgcHJvdmlkZVJvdXRlclNjcm9sbGVyKCksIGNvbmZpZz8ucHJlbG9hZGluZ1N0cmF0ZWd5ID8gd2l0aFByZWxvYWRpbmcoY29uZmlnLnByZWxvYWRpbmdTdHJhdGVneSkuybVwcm92aWRlcnMgOiBbXSwgY29uZmlnPy5pbml0aWFsTmF2aWdhdGlvbiA/IHByb3ZpZGVJbml0aWFsTmF2aWdhdGlvbihjb25maWcpIDogW10sIGNvbmZpZz8uYmluZFRvQ29tcG9uZW50SW5wdXRzID8gd2l0aENvbXBvbmVudElucHV0QmluZGluZyh0eXBlb2YgY29uZmlnLmJpbmRUb0NvbXBvbmVudElucHV0cyA9PT0gJ29iamVjdCcgPyBjb25maWcuYmluZFRvQ29tcG9uZW50SW5wdXRzIDoge30pLsm1cHJvdmlkZXJzIDogW10sIGNvbmZpZz8uZW5hYmxlVmlld1RyYW5zaXRpb25zID8gd2l0aFZpZXdUcmFuc2l0aW9ucygpLsm1cHJvdmlkZXJzIDogW10sIHByb3ZpZGVSb3V0ZXJJbml0aWFsaXplcigpXVxuICAgIH07XG4gIH1cbiAgc3RhdGljIGZvckNoaWxkKHJvdXRlcykge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogUm91dGVyTW9kdWxlLFxuICAgICAgcHJvdmlkZXJzOiBbe1xuICAgICAgICBwcm92aWRlOiBST1VURVMsXG4gICAgICAgIG11bHRpOiB0cnVlLFxuICAgICAgICB1c2VWYWx1ZTogcm91dGVzXG4gICAgICB9XVxuICAgIH07XG4gIH1cbiAgc3RhdGljIMm1ZmFjID0gZnVuY3Rpb24gUm91dGVyTW9kdWxlX0ZhY3RvcnkoX19uZ0ZhY3RvcnlUeXBlX18pIHtcbiAgICByZXR1cm4gbmV3IChfX25nRmFjdG9yeVR5cGVfXyB8fCBSb3V0ZXJNb2R1bGUpKCk7XG4gIH07XG4gIHN0YXRpYyDJtW1vZCA9IC8qIEBfX1BVUkVfXyAqL2kwLsm1ybVkZWZpbmVOZ01vZHVsZSh7XG4gICAgdHlwZTogUm91dGVyTW9kdWxlLFxuICAgIGltcG9ydHM6IFtSb3V0ZXJPdXRsZXQsIFJvdXRlckxpbmssIFJvdXRlckxpbmtBY3RpdmUsIF9FbXB0eU91dGxldENvbXBvbmVudF0sXG4gICAgZXhwb3J0czogW1JvdXRlck91dGxldCwgUm91dGVyTGluaywgUm91dGVyTGlua0FjdGl2ZSwgX0VtcHR5T3V0bGV0Q29tcG9uZW50XVxuICB9KTtcbiAgc3RhdGljIMm1aW5qID0gLyogQF9fUFVSRV9fICovaTAuybXJtWRlZmluZUluamVjdG9yKHt9KTtcbn1cbigoKSA9PiB7XG4gICh0eXBlb2YgbmdEZXZNb2RlID09PSBcInVuZGVmaW5lZFwiIHx8IG5nRGV2TW9kZSkgJiYgaTAuybVzZXRDbGFzc01ldGFkYXRhKFJvdXRlck1vZHVsZSwgW3tcbiAgICB0eXBlOiBOZ01vZHVsZSxcbiAgICBhcmdzOiBbe1xuICAgICAgaW1wb3J0czogUk9VVEVSX0RJUkVDVElWRVMsXG4gICAgICBleHBvcnRzOiBST1VURVJfRElSRUNUSVZFU1xuICAgIH1dXG4gIH1dLCAoKSA9PiBbXSwgbnVsbCk7XG59KSgpO1xuZnVuY3Rpb24gcHJvdmlkZVJvdXRlclNjcm9sbGVyKCkge1xuICByZXR1cm4ge1xuICAgIHByb3ZpZGU6IFJPVVRFUl9TQ1JPTExFUixcbiAgICB1c2VGYWN0b3J5OiAoKSA9PiB7XG4gICAgICBjb25zdCB2aWV3cG9ydFNjcm9sbGVyID0gaW5qZWN0KFZpZXdwb3J0U2Nyb2xsZXIpO1xuICAgICAgY29uc3QgY29uZmlnID0gaW5qZWN0KFJPVVRFUl9DT05GSUdVUkFUSU9OKTtcbiAgICAgIGlmIChjb25maWcuc2Nyb2xsT2Zmc2V0KSB7XG4gICAgICAgIHZpZXdwb3J0U2Nyb2xsZXIuc2V0T2Zmc2V0KGNvbmZpZy5zY3JvbGxPZmZzZXQpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5ldyBSb3V0ZXJTY3JvbGxlcihjb25maWcpO1xuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIHByb3ZpZGVIYXNoTG9jYXRpb25TdHJhdGVneSgpIHtcbiAgcmV0dXJuIHtcbiAgICBwcm92aWRlOiBMb2NhdGlvblN0cmF0ZWd5LFxuICAgIHVzZUNsYXNzOiBIYXNoTG9jYXRpb25TdHJhdGVneVxuICB9O1xufVxuZnVuY3Rpb24gcHJvdmlkZVBhdGhMb2NhdGlvblN0cmF0ZWd5KCkge1xuICByZXR1cm4ge1xuICAgIHByb3ZpZGU6IExvY2F0aW9uU3RyYXRlZ3ksXG4gICAgdXNlQ2xhc3M6IFBhdGhMb2NhdGlvblN0cmF0ZWd5XG4gIH07XG59XG5mdW5jdGlvbiBwcm92aWRlRm9yUm9vdEd1YXJkKCkge1xuICBjb25zdCByb3V0ZXIgPSBpbmplY3QoUm91dGVyLCB7XG4gICAgb3B0aW9uYWw6IHRydWUsXG4gICAgc2tpcFNlbGY6IHRydWVcbiAgfSk7XG4gIGlmIChyb3V0ZXIpIHtcbiAgICB0aHJvdyBuZXcgX1J1bnRpbWVFcnJvcig0MDA3LCBgVGhlIFJvdXRlciB3YXMgcHJvdmlkZWQgbW9yZSB0aGFuIG9uY2UuIFRoaXMgY2FuIGhhcHBlbiBpZiAnZm9yUm9vdCcgaXMgdXNlZCBvdXRzaWRlIG9mIHRoZSByb290IGluamVjdG9yLmAgKyBgIExhenkgbG9hZGVkIG1vZHVsZXMgc2hvdWxkIHVzZSBSb3V0ZXJNb2R1bGUuZm9yQ2hpbGQoKSBpbnN0ZWFkLmApO1xuICB9XG4gIHJldHVybiAnZ3VhcmRlZCc7XG59XG5mdW5jdGlvbiBwcm92aWRlSW5pdGlhbE5hdmlnYXRpb24oY29uZmlnKSB7XG4gIHJldHVybiBbY29uZmlnLmluaXRpYWxOYXZpZ2F0aW9uID09PSAnZGlzYWJsZWQnID8gd2l0aERpc2FibGVkSW5pdGlhbE5hdmlnYXRpb24oKS7JtXByb3ZpZGVycyA6IFtdLCBjb25maWcuaW5pdGlhbE5hdmlnYXRpb24gPT09ICdlbmFibGVkQmxvY2tpbmcnID8gd2l0aEVuYWJsZWRCbG9ja2luZ0luaXRpYWxOYXZpZ2F0aW9uKCkuybVwcm92aWRlcnMgOiBbXV07XG59XG5jb25zdCBST1VURVJfSU5JVElBTElaRVIgPSBuZXcgSW5qZWN0aW9uVG9rZW4odHlwZW9mIG5nRGV2TW9kZSA9PT0gJ3VuZGVmaW5lZCcgfHwgbmdEZXZNb2RlID8gJ1JvdXRlciBJbml0aWFsaXplcicgOiAnJyk7XG5mdW5jdGlvbiBwcm92aWRlUm91dGVySW5pdGlhbGl6ZXIoKSB7XG4gIHJldHVybiBbe1xuICAgIHByb3ZpZGU6IFJPVVRFUl9JTklUSUFMSVpFUixcbiAgICB1c2VGYWN0b3J5OiBnZXRCb290c3RyYXBMaXN0ZW5lclxuICB9LCB7XG4gICAgcHJvdmlkZTogQVBQX0JPT1RTVFJBUF9MSVNURU5FUixcbiAgICBtdWx0aTogdHJ1ZSxcbiAgICB1c2VFeGlzdGluZzogUk9VVEVSX0lOSVRJQUxJWkVSXG4gIH1dO1xufVxuZXhwb3J0IHsgTm9QcmVsb2FkaW5nLCBQcmVsb2FkQWxsTW9kdWxlcywgUHJlbG9hZGluZ1N0cmF0ZWd5LCBST1VURVJfSU5JVElBTElaRVIsIFJPVVRFUl9QUk9WSURFUlMsIFJvdXRlckxpbmssIFJvdXRlckxpbmtBY3RpdmUsIFJvdXRlck1vZHVsZSwgUm91dGVyUHJlbG9hZGVyLCBwcm92aWRlUm91dGVyLCB3aXRoQWN0aXZhdGVkUm91dGVJbmplY3RvcnMsIHdpdGhDb21wb25lbnRJbnB1dEJpbmRpbmcsIHdpdGhEZWJ1Z1RyYWNpbmcsIHdpdGhEaXNhYmxlZEluaXRpYWxOYXZpZ2F0aW9uLCB3aXRoRW5hYmxlZEJsb2NraW5nSW5pdGlhbE5hdmlnYXRpb24sIHdpdGhFeHBlcmltZW50YWxBdXRvQ2xlYW51cEluamVjdG9ycywgd2l0aEV4cGVyaW1lbnRhbFBsYXRmb3JtTmF2aWdhdGlvbiwgd2l0aEhhc2hMb2NhdGlvbiwgd2l0aEluTWVtb3J5U2Nyb2xsaW5nLCB3aXRoTmF2aWdhdGlvbkVycm9ySGFuZGxlciwgd2l0aFByZWxvYWRpbmcsIHdpdGhSb3V0ZXJDb25maWcsIHdpdGhWaWV3VHJhbnNpdGlvbnMgfTtcbiIsIi8qKlxuICogQGxpY2Vuc2UgQW5ndWxhciB2MjIuMS4yXG4gKiAoYykgMjAxMC0yMDI2IEdvb2dsZSBMTEMuIGh0dHBzOi8vYW5ndWxhci5kZXYvXG4gKiBMaWNlbnNlOiBNSVRcbiAqL1xuXG5leHBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgQWN0aXZhdGVkUm91dGVTbmFwc2hvdCwgQWN0aXZhdGlvbkVuZCwgQWN0aXZhdGlvblN0YXJ0LCBCYXNlUm91dGVSZXVzZVN0cmF0ZWd5LCBDaGlsZEFjdGl2YXRpb25FbmQsIENoaWxkQWN0aXZhdGlvblN0YXJ0LCBDaGlsZHJlbk91dGxldENvbnRleHRzLCBEZWZhdWx0VGl0bGVTdHJhdGVneSwgRGVmYXVsdFVybFNlcmlhbGl6ZXIsIEV2ZW50VHlwZSwgR3VhcmRzQ2hlY2tFbmQsIEd1YXJkc0NoZWNrU3RhcnQsIE5hdmlnYXRpb25DYW5jZWwsIE5hdmlnYXRpb25DYW5jZWxsYXRpb25Db2RlLCBOYXZpZ2F0aW9uRW5kLCBOYXZpZ2F0aW9uRXJyb3IsIE5hdmlnYXRpb25Ta2lwcGVkLCBOYXZpZ2F0aW9uU2tpcHBlZENvZGUsIE5hdmlnYXRpb25TdGFydCwgT3V0bGV0Q29udGV4dCwgUFJJTUFSWV9PVVRMRVQsIFJPVVRFUl9DT05GSUdVUkFUSU9OLCBST1VURVJfT1VUTEVUX0RBVEEsIFJPVVRFUywgUmVkaXJlY3RDb21tYW5kLCBSZXNvbHZlRW5kLCBSZXNvbHZlU3RhcnQsIFJvdXRlQ29uZmlnTG9hZEVuZCwgUm91dGVDb25maWdMb2FkU3RhcnQsIFJvdXRlUmV1c2VTdHJhdGVneSwgUm91dGVyLCBSb3V0ZXJFdmVudCwgUm91dGVyT3V0bGV0LCBSb3V0ZXJTdGF0ZSwgUm91dGVyU3RhdGVTbmFwc2hvdCwgUm91dGVzUmVjb2duaXplZCwgU2Nyb2xsLCBUaXRsZVN0cmF0ZWd5LCBVcmxIYW5kbGluZ1N0cmF0ZWd5LCBVcmxTZWdtZW50LCBVcmxTZWdtZW50R3JvdXAsIFVybFNlcmlhbGl6ZXIsIFVybFRyZWUsIGNvbnZlcnRUb1BhcmFtTWFwLCBjcmVhdGVVcmxUcmVlRnJvbVNuYXBzaG90LCBkZWZhdWx0VXJsTWF0Y2hlciwgZGVzdHJveURldGFjaGVkUm91dGVIYW5kbGUsIGlzQWN0aXZlLCDJtUVtcHR5T3V0bGV0Q29tcG9uZW50LCBhZnRlck5leHROYXZpZ2F0aW9uIGFzIMm1YWZ0ZXJOZXh0TmF2aWdhdGlvbiwgbG9hZENoaWxkcmVuIGFzIMm1bG9hZENoaWxkcmVuIH0gZnJvbSAnLi9fcm91dGVyLWNodW5rLm1qcyc7XG5leHBvcnQgeyBOb1ByZWxvYWRpbmcsIFByZWxvYWRBbGxNb2R1bGVzLCBQcmVsb2FkaW5nU3RyYXRlZ3ksIFJPVVRFUl9JTklUSUFMSVpFUiwgUm91dGVyTGluaywgUm91dGVyTGlua0FjdGl2ZSwgUm91dGVyTGluayBhcyBSb3V0ZXJMaW5rV2l0aEhyZWYsIFJvdXRlck1vZHVsZSwgUm91dGVyUHJlbG9hZGVyLCBwcm92aWRlUm91dGVyLCB3aXRoQ29tcG9uZW50SW5wdXRCaW5kaW5nLCB3aXRoRGVidWdUcmFjaW5nLCB3aXRoRGlzYWJsZWRJbml0aWFsTmF2aWdhdGlvbiwgd2l0aEVuYWJsZWRCbG9ja2luZ0luaXRpYWxOYXZpZ2F0aW9uLCB3aXRoRXhwZXJpbWVudGFsQXV0b0NsZWFudXBJbmplY3RvcnMsIHdpdGhFeHBlcmltZW50YWxQbGF0Zm9ybU5hdmlnYXRpb24sIHdpdGhIYXNoTG9jYXRpb24sIHdpdGhJbk1lbW9yeVNjcm9sbGluZywgd2l0aE5hdmlnYXRpb25FcnJvckhhbmRsZXIsIHdpdGhQcmVsb2FkaW5nLCB3aXRoUm91dGVyQ29uZmlnLCB3aXRoVmlld1RyYW5zaXRpb25zLCBST1VURVJfUFJPVklERVJTIGFzIMm1Uk9VVEVSX1BST1ZJREVSUywgd2l0aEFjdGl2YXRlZFJvdXRlSW5qZWN0b3JzIGFzIMm1d2l0aEFjdGl2YXRlZFJvdXRlSW5qZWN0b3JzIH0gZnJvbSAnLi9fcm91dGVyX21vZHVsZS1jaHVuay5tanMnO1xuaW1wb3J0IHsgaW5qZWN0LCBWZXJzaW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgJ3J4anMnO1xuaW1wb3J0ICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuXG5mdW5jdGlvbiBtYXBUb0Nhbk1hdGNoKHByb3ZpZGVycykge1xuICByZXR1cm4gcHJvdmlkZXJzLm1hcChwcm92aWRlciA9PiAoLi4ucGFyYW1zKSA9PiBpbmplY3QocHJvdmlkZXIpLmNhbk1hdGNoKC4uLnBhcmFtcykpO1xufVxuZnVuY3Rpb24gbWFwVG9DYW5BY3RpdmF0ZShwcm92aWRlcnMpIHtcbiAgcmV0dXJuIHByb3ZpZGVycy5tYXAocHJvdmlkZXIgPT4gKC4uLnBhcmFtcykgPT4gaW5qZWN0KHByb3ZpZGVyKS5jYW5BY3RpdmF0ZSguLi5wYXJhbXMpKTtcbn1cbmZ1bmN0aW9uIG1hcFRvQ2FuQWN0aXZhdGVDaGlsZChwcm92aWRlcnMpIHtcbiAgcmV0dXJuIHByb3ZpZGVycy5tYXAocHJvdmlkZXIgPT4gKC4uLnBhcmFtcykgPT4gaW5qZWN0KHByb3ZpZGVyKS5jYW5BY3RpdmF0ZUNoaWxkKC4uLnBhcmFtcykpO1xufVxuZnVuY3Rpb24gbWFwVG9DYW5EZWFjdGl2YXRlKHByb3ZpZGVycykge1xuICByZXR1cm4gcHJvdmlkZXJzLm1hcChwcm92aWRlciA9PiAoLi4ucGFyYW1zKSA9PiBpbmplY3QocHJvdmlkZXIpLmNhbkRlYWN0aXZhdGUoLi4ucGFyYW1zKSk7XG59XG5mdW5jdGlvbiBtYXBUb1Jlc29sdmUocHJvdmlkZXIpIHtcbiAgcmV0dXJuICguLi5wYXJhbXMpID0+IGluamVjdChwcm92aWRlcikucmVzb2x2ZSguLi5wYXJhbXMpO1xufVxuXG5jb25zdCBWRVJTSU9OID0gLyogQF9fUFVSRV9fICovbmV3IFZlcnNpb24oJzIyLjEuMicpO1xuXG5leHBvcnQgeyBWRVJTSU9OLCBtYXBUb0NhbkFjdGl2YXRlLCBtYXBUb0NhbkFjdGl2YXRlQ2hpbGQsIG1hcFRvQ2FuRGVhY3RpdmF0ZSwgbWFwVG9DYW5NYXRjaCwgbWFwVG9SZXNvbHZlIH07XG5cbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVlBLElBQU0saUJBQWlCO0FBQ3ZCLElBQU0sZ0JBQStCLHVCQUFPLFlBQVk7QUFDeEQsSUFBTSxjQUFOLE1BQWtCO0NBRWhCLFlBQVksUUFBUTt3QkFEcEIsVUFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLFNBQVMsVUFBVSxDQUFDO0NBQzNCO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsT0FBTyxPQUFPLFVBQVUsZUFBZSxLQUFLLEtBQUssUUFBUSxJQUFJO0NBQy9EO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHO0dBQ2xCLE1BQU0sSUFBSSxLQUFLLE9BQU87R0FDdEIsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSztFQUNuQztFQUNBLE9BQU87Q0FDVDtDQUNBLE9BQU8sTUFBTTtFQUNYLElBQUksS0FBSyxJQUFJLElBQUksR0FBRztHQUNsQixNQUFNLElBQUksS0FBSyxPQUFPO0dBQ3RCLE9BQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQztFQUNsQztFQUNBLE9BQU8sQ0FBQztDQUNWO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsT0FBTyxPQUFPLEtBQUssS0FBSyxNQUFNO0NBQ2hDO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2pDLE9BQU8sSUFBSSxZQUFZLE1BQU07QUFDL0I7QUFDQSxTQUFTLFdBQVcsWUFBWSxhQUFhLFdBQVc7Q0FDdEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUFLO0VBQzFDLE1BQU0sT0FBTyxXQUFXO0VBQ3hCLE1BQU0sVUFBVSxZQUFZO0VBRTVCLElBRG9CLEtBQUssT0FBTyxLQUU5QixVQUFVLEtBQUssVUFBVSxDQUFDLEtBQUs7T0FDMUIsSUFBSSxTQUFTLFFBQVEsTUFDMUIsT0FBTztDQUVYO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxjQUFjLE9BQU87Q0FDeEQsTUFBTSxRQUFRLE1BQU0sS0FBSyxNQUFNLEdBQUc7Q0FDbEMsTUFBTSxnQkFBZ0IsTUFBTSxRQUFRLElBQUk7Q0FDeEMsSUFBSSxrQkFBa0IsSUFBSTtFQUN4QixJQUFJLE1BQU0sU0FBUyxTQUFTLFFBQzFCLE9BQU87RUFFVCxJQUFJLE1BQU0sY0FBYyxXQUFXLGFBQWEsWUFBWSxLQUFLLE1BQU0sU0FBUyxTQUFTLFNBQ3ZGLE9BQU87RUFFVCxNQUFNLFlBQVksQ0FBQztFQUNuQixNQUFNLFdBQVcsU0FBUyxNQUFNLEdBQUcsTUFBTSxNQUFNO0VBQy9DLElBQUksQ0FBQyxXQUFXLE9BQU8sVUFBVSxTQUFTLEdBQ3hDLE9BQU87RUFFVCxPQUFPO0dBQ0w7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLGtCQUFrQixNQUFNLFlBQVksSUFBSSxHQUMxQyxPQUFPO0NBRVQsTUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLGFBQWE7Q0FDeEMsTUFBTSxPQUFPLE1BQU0sTUFBTSxnQkFBZ0IsQ0FBQztDQUMxQyxJQUFJLElBQUksU0FBUyxLQUFLLFNBQVMsU0FBUyxRQUN0QyxPQUFPO0NBRVQsSUFBSSxNQUFNLGNBQWMsVUFBVSxhQUFhLFlBQVksS0FBSyxNQUFNLFNBQVMsTUFDN0UsT0FBTztDQUVULE1BQU0sWUFBWSxDQUFDO0NBQ25CLElBQUksQ0FBQyxXQUFXLEtBQUssU0FBUyxNQUFNLEdBQUcsSUFBSSxNQUFNLEdBQUcsU0FBUyxHQUMzRCxPQUFPO0NBRVQsSUFBSSxDQUFDLFdBQVcsTUFBTSxTQUFTLE1BQU0sU0FBUyxTQUFTLEtBQUssTUFBTSxHQUFHLFNBQVMsR0FDNUUsT0FBTztDQUVULE9BQU87RUFDTCxVQUFVO0VBQ1Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxlQUFlLFFBQVE7Q0FDOUIsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVU7R0FDN0IsT0FBTSxVQUFTLFFBQVEsS0FBSztHQUM1QixRQUFPLFFBQU8sT0FBTyxHQUFHO0VBQzFCLENBQUM7Q0FDSCxDQUFDO0FBQ0g7QUFDQSxTQUFTLG1CQUFtQixHQUFHLEdBQUc7Q0FDaEMsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLE9BQU87Q0FDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQzlCLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FBRyxPQUFPO0NBRXhDLE9BQU87QUFDVDtBQUNBLFNBQVMsYUFBYSxHQUFHLEdBQUc7Q0FDMUIsTUFBTSxLQUFLLElBQUksWUFBWSxDQUFDLElBQUksS0FBQTtDQUNoQyxNQUFNLEtBQUssSUFBSSxZQUFZLENBQUMsSUFBSSxLQUFBO0NBQ2hDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLFVBQVUsR0FBRyxRQUNoQyxPQUFPO0NBRVQsSUFBSTtDQUNKLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsS0FBSztFQUNsQyxNQUFNLEdBQUc7RUFDVCxJQUFJLENBQUMsb0JBQW9CLEVBQUUsTUFBTSxFQUFFLElBQUksR0FDckMsT0FBTztDQUVYO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLEtBQUs7Q0FDeEIsT0FBTyxDQUFDLEdBQUcsT0FBTyxLQUFLLEdBQUcsR0FBRyxHQUFHLE9BQU8sc0JBQXNCLEdBQUcsQ0FBQztBQUNuRTtBQUNBLFNBQVMsb0JBQW9CLEdBQUcsR0FBRztDQUNqQyxJQUFJLE1BQU0sUUFBUSxDQUFDLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRztFQUN4QyxJQUFJLEVBQUUsV0FBVyxFQUFFLFFBQVEsT0FBTztFQUNsQyxNQUFNLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFDNUIsTUFBTSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLO0VBQzVCLE9BQU8sUUFBUSxPQUFPLEtBQUssVUFBVSxRQUFRLFdBQVcsR0FBRztDQUM3RCxPQUNFLE9BQU8sTUFBTTtBQUVqQjtBQUNBLFNBQVMsS0FBSyxHQUFHO0NBQ2YsT0FBTyxFQUFFLFNBQVMsSUFBSSxFQUFFLEVBQUUsU0FBUyxLQUFLO0FBQzFDO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxJQUFJLGFBQWEsS0FBSyxHQUNwQixPQUFPO0NBRVQsSUFBSUEsVUFBVyxLQUFLLEdBQ2xCLE9BQU8sS0FBSyxRQUFRLFFBQVEsS0FBSyxDQUFDO0NBRXBDLE9BQU8sR0FBRyxLQUFLO0FBQ2pCO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixJQUFJLGFBQWEsS0FBSyxHQUNwQixPQUFPLGVBQWUsS0FBSztDQUU3QixPQUFPLFFBQVEsUUFBUSxLQUFLO0FBQzlCO0FBQ0EsSUFBTSxpQkFBaUI7Q0FDckIsU0FBUztDQUNULFVBQVU7QUFDWjtBQUNBLElBQU0sa0JBQWtCO0NBQ3RCLFNBQVM7Q0FDVCxVQUFVO0NBQ1YsaUJBQWlCO0FBQ25CO0FBQ0EsSUFBTSxvQkFBb0I7Q0FDeEIsT0FBTztDQUNQLFVBQVU7Q0FDVixjQUFjO0NBQ2QsYUFBYTtBQUNmO0FBQ0EsSUFBTSxxQkFBcUI7Q0FDekIsT0FBTztDQUNQLFVBQVU7Q0FDVixjQUFjO0NBQ2QsYUFBYTtBQUNmO0FBQ0EsU0FBUyxTQUFTLEtBQUssUUFBUSxjQUFjO0NBQzNDLE1BQU0sVUFBVSxlQUFlLFVBQVUsTUFBTSxPQUFPLFNBQVMsR0FBRztDQUNsRSxPQUFPLGVBQWU7O3lFQUFhLE9BQU8seUJBQXlCLE9BQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHVCQUFHLGNBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQVksSUFBSSxRQUFRLEdBQUcsU0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUM1RixrQkFBQSxHQUNBLFlBQ0wsQ0FBQztFQUFDO0FBQ0o7QUFDQSxTQUFTLGFBQWEsV0FBVyxXQUFXLFNBQVM7Q0FDbkQsT0FBTyxlQUFlLFFBQVEsTUFBTSxDQUFDLFVBQVUsTUFBTSxVQUFVLE1BQU0sUUFBUSxZQUFZLEtBQUssZ0JBQWdCLFFBQVEsWUFBWSxDQUFDLFVBQVUsYUFBYSxVQUFVLFdBQVcsS0FBSyxFQUFFLFFBQVEsYUFBYSxXQUFXLFVBQVUsYUFBYSxVQUFVO0FBQ3pQO0FBQ0EsU0FBUyxZQUFZLFdBQVcsV0FBVztDQUN6QyxPQUFPLGFBQWEsV0FBVyxTQUFTO0FBQzFDO0FBQ0EsU0FBUyxtQkFBbUIsV0FBVyxXQUFXLGNBQWM7Q0FDOUQsSUFBSSxDQUFDLFVBQVUsVUFBVSxVQUFVLFVBQVUsUUFBUSxHQUFHLE9BQU87Q0FDL0QsSUFBSSxDQUFDLGtCQUFrQixVQUFVLFVBQVUsVUFBVSxVQUFVLFlBQVksR0FDekUsT0FBTztDQUVULElBQUksVUFBVSxxQkFBcUIsVUFBVSxrQkFBa0IsT0FBTztDQUN0RSxLQUFLLE1BQU0sS0FBSyxVQUFVLFVBQVU7RUFDbEMsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLE9BQU87RUFDbkMsSUFBSSxDQUFDLG1CQUFtQixVQUFVLFNBQVMsSUFBSSxVQUFVLFNBQVMsSUFBSSxZQUFZLEdBQUcsT0FBTztDQUM5RjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxXQUFXLFdBQVc7Q0FDNUMsT0FBTyxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsVUFBVSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsVUFBVSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsT0FBTSxRQUFPLG9CQUFvQixVQUFVLE1BQU0sVUFBVSxJQUFJLENBQUM7QUFDbEs7QUFDQSxTQUFTLHFCQUFxQixXQUFXLFdBQVcsY0FBYztDQUNoRSxPQUFPLDJCQUEyQixXQUFXLFdBQVcsVUFBVSxVQUFVLFlBQVk7QUFDMUY7QUFDQSxTQUFTLDJCQUEyQixXQUFXLFdBQVcsZ0JBQWdCLGNBQWM7Q0FDdEYsSUFBSSxVQUFVLFNBQVMsU0FBUyxlQUFlLFFBQVE7RUFDckQsTUFBTSxVQUFVLFVBQVUsU0FBUyxNQUFNLEdBQUcsZUFBZSxNQUFNO0VBQ2pFLElBQUksQ0FBQyxVQUFVLFNBQVMsY0FBYyxHQUFHLE9BQU87RUFDaEQsSUFBSSxVQUFVLFlBQVksR0FBRyxPQUFPO0VBQ3BDLElBQUksQ0FBQyxrQkFBa0IsU0FBUyxnQkFBZ0IsWUFBWSxHQUFHLE9BQU87RUFDdEUsT0FBTztDQUNULE9BQU8sSUFBSSxVQUFVLFNBQVMsV0FBVyxlQUFlLFFBQVE7RUFDOUQsSUFBSSxDQUFDLFVBQVUsVUFBVSxVQUFVLGNBQWMsR0FBRyxPQUFPO0VBQzNELElBQUksQ0FBQyxrQkFBa0IsVUFBVSxVQUFVLGdCQUFnQixZQUFZLEdBQUcsT0FBTztFQUNqRixLQUFLLE1BQU0sS0FBSyxVQUFVLFVBQVU7R0FDbEMsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLE9BQU87R0FDbkMsSUFBSSxDQUFDLHFCQUFxQixVQUFVLFNBQVMsSUFBSSxVQUFVLFNBQVMsSUFBSSxZQUFZLEdBQ2xGLE9BQU87RUFFWDtFQUNBLE9BQU87Q0FDVCxPQUFPO0VBQ0wsTUFBTSxVQUFVLGVBQWUsTUFBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0VBQ2pFLE1BQU0sT0FBTyxlQUFlLE1BQU0sVUFBVSxTQUFTLE1BQU07RUFDM0QsSUFBSSxDQUFDLFVBQVUsVUFBVSxVQUFVLE9BQU8sR0FBRyxPQUFPO0VBQ3BELElBQUksQ0FBQyxrQkFBa0IsVUFBVSxVQUFVLFNBQVMsWUFBWSxHQUFHLE9BQU87RUFDMUUsSUFBSSxDQUFDLFVBQVUsU0FBQSxZQUEwQixPQUFPO0VBQ2hELE9BQU8sMkJBQTJCLFVBQVUsU0FBUyxpQkFBaUIsV0FBVyxNQUFNLFlBQVk7Q0FDckc7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLGdCQUFnQixnQkFBZ0IsU0FBUztDQUNsRSxPQUFPLGVBQWUsT0FBTyxrQkFBa0IsTUFBTTtFQUNuRCxPQUFPLGdCQUFnQixRQUFRLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBWSxpQkFBaUIsVUFBVTtDQUMzRixDQUFDO0FBQ0g7QUFDQSxJQUFNLFVBQU4sTUFBYztDQUtaLFlBQVksT0FBTyxJQUFJLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsY0FBYyxDQUFDLEdBQUcsV0FBVyxNQUFNO3dCQUpuRixRQUFBLEtBQUEsQ0FBQTt3QkFDQSxlQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLE9BQU87RUFDWixLQUFLLGNBQWM7RUFDbkIsS0FBSyxXQUFXO0VBQ2hCLElBQUksT0FBTyxjQUFjLGVBQWU7T0FDbEMsS0FBSyxTQUFTLFNBQVMsR0FDekIsTUFBTSxJQUFJQyxhQUFjLE1BQU0sMkpBQWdLO0VBQUE7Q0FHcE07Q0FDQSxJQUFJLGdCQUFnQjs7RUFDbEIsQ0FBQSx1QkFBQSxLQUFLLG9CQUFBLFFBQUEseUJBQUEsS0FBQSxNQUFMLEtBQUssaUJBQW1CLGtCQUFrQixLQUFLLFdBQVc7RUFDMUQsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxtQkFBbUIsVUFBVSxJQUFJO0NBQzFDO0FBQ0Y7QUFDQSxJQUFNLGtCQUFOLE1BQXNCO0NBSXBCLFlBQVksVUFBVSxVQUFVO3dCQUhoQyxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFTLElBQUE7RUFFUCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXO0VBQ2hCLE9BQU8sT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFRLE1BQUssRUFBRSxTQUFTLElBQUk7Q0FDdEQ7Q0FDQSxjQUFjO0VBQ1osT0FBTyxLQUFLLG1CQUFtQjtDQUNqQztDQUNBLElBQUksbUJBQW1CO0VBQ3JCLE9BQU8sT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUM7Q0FDcEM7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxlQUFlLElBQUk7Q0FDNUI7QUFDRjtBQUNBLElBQU0sYUFBTixNQUFpQjtDQUlmLFlBQVksTUFBTSxZQUFZO3dCQUg5QixRQUFBLEtBQUEsQ0FBQTt3QkFDQSxjQUFBLEtBQUEsQ0FBQTt3QkFDQSxpQkFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLE9BQU87RUFDWixLQUFLLGFBQWE7Q0FDcEI7Q0FDQSxJQUFJLGVBQWU7O0VBQ2pCLENBQUEsc0JBQUEsS0FBSyxtQkFBQSxRQUFBLHdCQUFBLEtBQUEsTUFBTCxLQUFLLGdCQUFrQixrQkFBa0IsS0FBSyxVQUFVO0VBQ3hELE9BQU8sS0FBSztDQUNkO0NBQ0EsV0FBVztFQUNULE9BQU8sY0FBYyxJQUFJO0NBQzNCO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsSUFBSSxJQUFJO0NBQzdCLE9BQU8sVUFBVSxJQUFJLEVBQUUsS0FBSyxHQUFHLE9BQU8sR0FBRyxNQUFNLGFBQWEsRUFBRSxZQUFZLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQztBQUM3RjtBQUNBLFNBQVMsVUFBVSxJQUFJLElBQUk7Q0FDekIsSUFBSSxHQUFHLFdBQVcsR0FBRyxRQUFRLE9BQU87Q0FDcEMsT0FBTyxHQUFHLE9BQU8sR0FBRyxNQUFNLEVBQUUsU0FBUyxHQUFHLEVBQUUsQ0FBQyxJQUFJO0FBQ2pEO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxJQUFJO0NBQ3pDLElBQUksTUFBTSxDQUFDO0NBQ1gsT0FBTyxRQUFRLFFBQVEsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsV0FBVztFQUNqRSxJQUFJLGdCQUFBLFdBQ0YsTUFBTSxJQUFJLE9BQU8sR0FBRyxPQUFPLFdBQVcsQ0FBQztDQUUzQyxDQUFDO0NBQ0QsT0FBTyxRQUFRLFFBQVEsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsV0FBVztFQUNqRSxJQUFJLGdCQUFBLFdBQ0YsTUFBTSxJQUFJLE9BQU8sR0FBRyxPQUFPLFdBQVcsQ0FBQztDQUUzQyxDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsSUFBTSxnQkFBTixNQUFvQixDQVFwQjs7K0JBUFMsUUFBTyxTQUFTLHNCQUFzQixtQkFBbUI7Q0FDOUQsT0FBTyxLQUFLLHFCQUFxQkMsZ0JBQWU7QUFDbEQsQ0FBQTsrQkFDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxzQkFBc0IsSUFBSSxxQkFBcUIsRUFBQSxDQUFHO0FBQ3BELENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjQyxpQkFBcUIsZUFBZSxDQUFDO0VBQ3RGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxlQUFlLElBQUkscUJBQXFCLEVBQzFDLENBQUM7Q0FDSCxDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sdUJBQU4sTUFBMkI7Q0FDekIsTUFBTSxLQUFLO0VBQ1QsTUFBTSxJQUFJLElBQUksVUFBVSxHQUFHO0VBQzNCLE9BQU8sSUFBSSxRQUFRLEVBQUUsaUJBQWlCLEdBQUcsRUFBRSxpQkFBaUIsR0FBRyxFQUFFLGNBQWMsQ0FBQztDQUNsRjtDQUNBLFVBQVUsTUFBTTtFQUNkLE1BQU0sVUFBVSxJQUFJLGlCQUFpQixLQUFLLE1BQU0sSUFBSTtFQUNwRCxJQUFJLFFBQVEsV0FBVyxJQUFJLEdBQ3pCLE1BQU0sSUFBSUYsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsd0VBQXdFO0VBSTNKLE9BQU8sR0FBRyxVQUZJLHFCQUFxQixLQUFLLFdBRWhCLElBRFAsT0FBTyxLQUFLLGFBQWEsV0FBVyxJQUFJLGtCQUFrQixLQUFLLFFBQVEsTUFBTTtDQUVoRztBQUNGO0FBQ0EsSUFBTSxxQkFBcUIsSUFBSSxxQkFBcUI7QUFDcEQsU0FBUyxlQUFlLFNBQVM7Q0FDL0IsT0FBTyxRQUFRLFNBQVMsS0FBSSxNQUFLLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7QUFDN0Q7QUFDQSxTQUFTLGlCQUFpQixTQUFTLE1BQU07Q0FDdkMsSUFBSSxDQUFDLFFBQVEsWUFBWSxHQUN2QixPQUFPLGVBQWUsT0FBTztDQUUvQixJQUFJLE1BQU07RUFDUixNQUFNLFVBQVUsUUFBUSxTQUFBLGFBQTJCLGlCQUFpQixRQUFRLFNBQVMsaUJBQWlCLEtBQUssSUFBSTtFQUMvRyxNQUFNLFdBQVcsQ0FBQztFQUNsQixPQUFPLFFBQVEsUUFBUSxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPO0dBQ25ELElBQUksTUFBQSxXQUNGLFNBQVMsS0FBSyxHQUFHLEVBQUUsR0FBRyxpQkFBaUIsR0FBRyxLQUFLLEdBQUc7RUFFdEQsQ0FBQztFQUNELE9BQU8sU0FBUyxTQUFTLElBQUksR0FBRyxRQUFRLEdBQUcsU0FBUyxLQUFLLElBQUksRUFBRSxLQUFLO0NBQ3RFLE9BQU87RUFDTCxNQUFNLFdBQVcscUJBQXFCLFVBQVUsR0FBRyxNQUFNO0dBQ3ZELElBQUksTUFBQSxXQUNGLE9BQU8sQ0FBQyxpQkFBaUIsUUFBUSxTQUFTLGlCQUFpQixLQUFLLENBQUM7R0FFbkUsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLGlCQUFpQixHQUFHLEtBQUssR0FBRztFQUM5QyxDQUFDO0VBQ0QsSUFBSSxPQUFPLEtBQUssUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLEtBQUssUUFBUSxTQUFBLGNBQTRCLE1BQ3BGLE9BQU8sR0FBRyxlQUFlLE9BQU8sRUFBRSxHQUFHLFNBQVM7RUFFaEQsT0FBTyxHQUFHLGVBQWUsT0FBTyxFQUFFLElBQUksU0FBUyxLQUFLLElBQUksRUFBRTtDQUM1RDtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsR0FBRztDQUMxQixPQUFPLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRyxDQUFDLENBQUMsUUFBUSxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRztBQUNuSDtBQUNBLFNBQVMsZUFBZSxHQUFHO0NBQ3pCLE9BQU8sZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxHQUFHO0FBQ2hEO0FBQ0EsU0FBUyxrQkFBa0IsR0FBRztDQUM1QixPQUFPLFVBQVUsQ0FBQztBQUNwQjtBQUNBLFNBQVMsaUJBQWlCLEdBQUc7Q0FDM0IsT0FBTyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUSxPQUFPLEtBQUssQ0FBQyxDQUFDLFFBQVEsT0FBTyxLQUFLLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRztBQUM1RjtBQUNBLFNBQVMsT0FBTyxHQUFHO0NBQ2pCLE9BQU8sbUJBQW1CLENBQUM7QUFDN0I7QUFDQSxTQUFTLFlBQVksR0FBRztDQUN0QixPQUFPLE9BQU8sRUFBRSxRQUFRLE9BQU8sS0FBSyxDQUFDO0FBQ3ZDO0FBQ0EsU0FBUyxjQUFjLE1BQU07Q0FDM0IsT0FBTyxHQUFHLGlCQUFpQixLQUFLLElBQUksSUFBSSxzQkFBc0IsS0FBSyxVQUFVO0FBQy9FO0FBQ0EsU0FBUyxzQkFBc0IsUUFBUTtDQUNyQyxPQUFPLE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXLElBQUksaUJBQWlCLEdBQUcsRUFBRSxHQUFHLGlCQUFpQixLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRTtBQUNySDtBQUNBLFNBQVMscUJBQXFCLFFBQVE7Q0FDcEMsTUFBTSxZQUFZLE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxXQUFXO0VBQzlELE9BQU8sTUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUksTUFBSyxHQUFHLGVBQWUsSUFBSSxFQUFFLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLEdBQUcsZUFBZSxJQUFJLEVBQUUsR0FBRyxlQUFlLEtBQUs7Q0FDMUosQ0FBQyxDQUFDLENBQUMsUUFBTyxNQUFLLENBQUM7Q0FDaEIsT0FBTyxVQUFVLFNBQVMsSUFBSSxVQUFVLEtBQUssR0FBRyxNQUFNO0FBQ3hEO0FBQ0EsSUFBTSxhQUFhO0FBQ25CLFNBQVMsY0FBYyxLQUFLO0NBQzFCLE1BQU0sUUFBUSxJQUFJLE1BQU0sVUFBVTtDQUNsQyxPQUFPLFFBQVEsTUFBTSxLQUFLO0FBQzVCO0FBQ0EsSUFBTSwwQkFBMEI7QUFDaEMsU0FBUyx1QkFBdUIsS0FBSztDQUNuQyxNQUFNLFFBQVEsSUFBSSxNQUFNLHVCQUF1QjtDQUMvQyxPQUFPLFFBQVEsTUFBTSxLQUFLO0FBQzVCO0FBQ0EsSUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxpQkFBaUIsS0FBSztDQUM3QixNQUFNLFFBQVEsSUFBSSxNQUFNLGNBQWM7Q0FDdEMsT0FBTyxRQUFRLE1BQU0sS0FBSztBQUM1QjtBQUNBLElBQU0sdUJBQXVCO0FBQzdCLFNBQVMsd0JBQXdCLEtBQUs7Q0FDcEMsTUFBTSxRQUFRLElBQUksTUFBTSxvQkFBb0I7Q0FDNUMsT0FBTyxRQUFRLE1BQU0sS0FBSztBQUM1QjtBQUNBLElBQU0sWUFBTixNQUFnQjtDQUdkLFlBQVksS0FBSzt3QkFGakIsT0FBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7RUFFRSxLQUFLLE1BQU07RUFDWCxLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTyxLQUFLLGdCQUFnQixHQUFHO0VBQy9CLElBQUksS0FBSyxjQUFjLE1BQU0sS0FBSyxlQUFlLEdBQUcsS0FBSyxLQUFLLGVBQWUsR0FBRyxHQUM5RSxPQUFPLElBQUksZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUM7RUFFbkMsT0FBTyxJQUFJLGdCQUFnQixDQUFDLEdBQUcsS0FBSyxjQUFjLENBQUM7Q0FDckQ7Q0FDQSxtQkFBbUI7RUFDakIsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxLQUFLLGdCQUFnQixHQUFHLEdBQzFCO0dBQ0UsS0FBSyxnQkFBZ0IsTUFBTTtTQUNwQixLQUFLLGdCQUFnQixHQUFHO0VBRW5DLE9BQU87Q0FDVDtDQUNBLGdCQUFnQjtFQUNkLE9BQU8sS0FBSyxnQkFBZ0IsR0FBRyxJQUFJLG1CQUFtQixLQUFLLFNBQVMsSUFBSTtDQUMxRTtDQUNBLGNBQWMsUUFBUSxHQUFHO0VBQ3ZCLElBQUksUUFBUSxJQUNWLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsaUJBQWlCO0VBRXBHLElBQUksS0FBSyxjQUFjLElBQ3JCLE9BQU8sQ0FBQztFQUVWLEtBQUssZ0JBQWdCLEdBQUc7RUFDeEIsTUFBTSxXQUFXLENBQUM7RUFDbEIsSUFBSSxDQUFDLEtBQUssZUFBZSxHQUFHLEdBQzFCLFNBQVMsS0FBSyxLQUFLLGFBQWEsQ0FBQztFQUVuQyxPQUFPLEtBQUssZUFBZSxHQUFHLEtBQUssQ0FBQyxLQUFLLGVBQWUsSUFBSSxLQUFLLENBQUMsS0FBSyxlQUFlLElBQUksR0FBRztHQUMzRixLQUFLLFFBQVEsR0FBRztHQUNoQixTQUFTLEtBQUssS0FBSyxhQUFhLENBQUM7RUFDbkM7RUFDQSxJQUFJLFdBQVcsQ0FBQztFQUNoQixJQUFJLEtBQUssZUFBZSxJQUFJLEdBQUc7R0FDN0IsS0FBSyxRQUFRLEdBQUc7R0FDaEIsV0FBVyxLQUFLLFlBQVksTUFBTSxLQUFLO0VBQ3pDO0VBQ0EsSUFBSSxNQUFNLENBQUM7RUFDWCxJQUFJLEtBQUssZUFBZSxHQUFHLEdBQ3pCLE1BQU0sS0FBSyxZQUFZLE9BQU8sS0FBSztFQUVyQyxJQUFJLFNBQVMsU0FBUyxLQUFLLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFTLEdBQ3hELElBQUksa0JBQWtCLElBQUksZ0JBQWdCLFVBQVUsUUFBUTtFQUU5RCxPQUFPO0NBQ1Q7Q0FDQSxlQUFlO0VBQ2IsTUFBTSxPQUFPLGNBQWMsS0FBSyxTQUFTO0VBQ3pDLElBQUksU0FBUyxNQUFNLEtBQUssZUFBZSxHQUFHLEdBQ3hDLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsbURBQW1ELEtBQUssVUFBVSxHQUFHO0VBRXhKLEtBQUssUUFBUSxJQUFJO0VBQ2pCLE9BQU8sSUFBSSxXQUFXLE9BQU8sSUFBSSxHQUFHLEtBQUssa0JBQWtCLENBQUM7Q0FDOUQ7Q0FDQSxvQkFBb0I7RUFDbEIsTUFBTSxTQUFTLENBQUM7RUFDaEIsT0FBTyxLQUFLLGdCQUFnQixHQUFHLEdBQzdCLEtBQUssV0FBVyxNQUFNO0VBRXhCLE9BQU87Q0FDVDtDQUNBLFdBQVcsUUFBUTtFQUNqQixNQUFNLE1BQU0sdUJBQXVCLEtBQUssU0FBUztFQUNqRCxJQUFJLENBQUMsS0FDSDtFQUVGLEtBQUssUUFBUSxHQUFHO0VBQ2hCLElBQUksUUFBUTtFQUNaLElBQUksS0FBSyxnQkFBZ0IsR0FBRyxHQUFHO0dBQzdCLE1BQU0sYUFBYSxjQUFjLEtBQUssU0FBUztHQUMvQyxJQUFJLFlBQVk7SUFDZCxRQUFRO0lBQ1IsS0FBSyxRQUFRLEtBQUs7R0FDcEI7RUFDRjtFQUNBLE9BQU8sT0FBTyxHQUFHLEtBQUssT0FBTyxLQUFLO0NBQ3BDO0NBQ0EsZ0JBQWdCLFFBQVE7RUFDdEIsTUFBTSxNQUFNLGlCQUFpQixLQUFLLFNBQVM7RUFDM0MsSUFBSSxDQUFDLEtBQ0g7RUFFRixLQUFLLFFBQVEsR0FBRztFQUNoQixJQUFJLFFBQVE7RUFDWixJQUFJLEtBQUssZ0JBQWdCLEdBQUcsR0FBRztHQUM3QixNQUFNLGFBQWEsd0JBQXdCLEtBQUssU0FBUztHQUN6RCxJQUFJLFlBQVk7SUFDZCxRQUFRO0lBQ1IsS0FBSyxRQUFRLEtBQUs7R0FDcEI7RUFDRjtFQUNBLE1BQU0sYUFBYSxZQUFZLEdBQUc7RUFDbEMsTUFBTSxhQUFhLFlBQVksS0FBSztFQUNwQyxJQUFJLE9BQU8sT0FBTyxRQUFRLFVBQVUsR0FBRztHQUNyQyxJQUFJLGFBQWEsT0FBTztHQUN4QixJQUFJLENBQUMsTUFBTSxRQUFRLFVBQVUsR0FBRztJQUM5QixhQUFhLENBQUMsVUFBVTtJQUN4QixPQUFPLGNBQWM7R0FDdkI7R0FDQSxXQUFXLEtBQUssVUFBVTtFQUM1QixPQUNFLE9BQU8sY0FBYztDQUV6QjtDQUNBLFlBQVksY0FBYyxPQUFPO0VBQy9CLE1BQU0sV0FBVyxPQUFPLE9BQU8sSUFBSTtFQUNuQyxLQUFLLFFBQVEsR0FBRztFQUNoQixPQUFPLENBQUMsS0FBSyxnQkFBZ0IsR0FBRyxLQUFLLEtBQUssVUFBVSxTQUFTLEdBQUc7O0dBQzlELE1BQU0sT0FBTyxjQUFjLEtBQUssU0FBUztHQUN6QyxNQUFNLE9BQU8sS0FBSyxVQUFVLEtBQUs7R0FDakMsSUFBSSxTQUFTLE9BQU8sU0FBUyxPQUFPLFNBQVMsS0FDM0MsTUFBTSxJQUFJQSxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyxxQkFBcUIsS0FBSyxJQUFJLEVBQUU7R0FFbkgsSUFBSTtHQUNKLElBQUksS0FBSyxRQUFRLEdBQUcsSUFBSSxJQUFJO0lBQzFCLGFBQWEsS0FBSyxNQUFNLEdBQUcsS0FBSyxRQUFRLEdBQUcsQ0FBQztJQUM1QyxLQUFLLFFBQVEsVUFBVTtJQUN2QixLQUFLLFFBQVEsR0FBRztHQUNsQixPQUFPLElBQUksY0FDVCxhQUFhO0dBRWYsTUFBTSxXQUFXLEtBQUssY0FBYyxRQUFRLENBQUM7R0FDN0MsVUFBQSxjQUFTLGdCQUFBLFFBQUEsZ0JBQUEsS0FBQSxJQUFBLGNBQWMsa0JBQWtCLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxXQUFXLEtBQUssU0FBQSxhQUEyQixTQUFTLGtCQUFrQixJQUFJLGdCQUFnQixDQUFDLEdBQUcsUUFBUTtHQUNySyxLQUFLLGdCQUFnQixJQUFJO0VBQzNCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsZUFBZSxLQUFLO0VBQ2xCLE9BQU8sS0FBSyxVQUFVLFdBQVcsR0FBRztDQUN0QztDQUNBLGdCQUFnQixLQUFLO0VBQ25CLElBQUksS0FBSyxlQUFlLEdBQUcsR0FBRztHQUM1QixLQUFLLFlBQVksS0FBSyxVQUFVLFVBQVUsSUFBSSxNQUFNO0dBQ3BELE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVDtDQUNBLFFBQVEsS0FBSztFQUNYLElBQUksQ0FBQyxLQUFLLGdCQUFnQixHQUFHLEdBQzNCLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsYUFBYSxJQUFJLEdBQUc7Q0FFekc7QUFDRjtBQUNBLFNBQVMsV0FBVyxlQUFlO0NBQ2pDLE9BQU8sY0FBYyxTQUFTLFNBQVMsSUFBSSxJQUFJLGdCQUFnQixDQUFDLEdBQUcsR0FDaEUsaUJBQWlCLGNBQ3BCLENBQUMsSUFBSTtBQUNQO0FBQ0EsU0FBUyxtQkFBbUIsY0FBYztDQUN4QyxNQUFNLGNBQWMsT0FBTyxPQUFPLElBQUk7Q0FDdEMsS0FBSyxNQUFNLENBQUMsYUFBYSxVQUFVLE9BQU8sUUFBUSxhQUFhLFFBQVEsR0FBRztFQUN4RSxNQUFNLGlCQUFpQixtQkFBbUIsS0FBSztFQUMvQyxJQUFJLGdCQUFBLGFBQWtDLGVBQWUsU0FBUyxXQUFXLEtBQUssZUFBZSxZQUFZLEdBQ3ZHLEtBQUssTUFBTSxDQUFDLGtCQUFrQixlQUFlLE9BQU8sUUFBUSxlQUFlLFFBQVEsR0FDakYsWUFBWSxvQkFBb0I7T0FFN0IsSUFBSSxlQUFlLFNBQVMsU0FBUyxLQUFLLGVBQWUsWUFBWSxHQUMxRSxZQUFZLGVBQWU7Q0FFL0I7Q0FFQSxPQUFPLHFCQUFxQixJQURkLGdCQUFnQixhQUFhLFVBQVUsV0FDekIsQ0FBQztBQUMvQjtBQUNBLFNBQVMscUJBQXFCLEdBQUc7Q0FDL0IsSUFBSSxFQUFFLHFCQUFxQixLQUFLLEVBQUUsU0FBQSxZQUEwQjtFQUMxRCxNQUFNLElBQUksRUFBRSxTQUFTO0VBQ3JCLE9BQU8sSUFBSSxnQkFBZ0IsRUFBRSxTQUFTLE9BQU8sRUFBRSxRQUFRLEdBQUcsRUFBRSxRQUFRO0NBQ3RFO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQUc7Q0FDcEIsT0FBTyxhQUFhO0FBQ3RCO0FBQ0EsU0FBUywwQkFBMEIsWUFBWSxVQUFVLGNBQWMsTUFBTSxXQUFXLE1BQU0sZ0JBQWdCLElBQUkscUJBQXFCLEdBQUc7Q0FFeEksT0FBTyw4QkFEMkIsNEJBQTRCLFVBQ0QsR0FBRyxVQUFVLGFBQWEsVUFBVSxhQUFhO0FBQ2hIO0FBQ0EsU0FBUyw0QkFBNEIsT0FBTzs7Q0FDMUMsSUFBSTtDQUNKLFNBQVMscUNBQXFDLGNBQWM7RUFDMUQsTUFBTSxlQUFlLENBQUM7RUFDdEIsS0FBSyxNQUFNLGlCQUFpQixhQUFhLFVBQVU7R0FDakQsTUFBTSxPQUFPLHFDQUFxQyxhQUFhO0dBQy9ELGFBQWEsY0FBYyxVQUFVO0VBQ3ZDO0VBQ0EsTUFBTSxlQUFlLElBQUksZ0JBQWdCLGFBQWEsS0FBSyxZQUFZO0VBQ3ZFLElBQUksaUJBQWlCLE9BQ25CLGNBQWM7RUFFaEIsT0FBTztDQUNUO0NBRUEsTUFBTSxtQkFBbUIsV0FESCxxQ0FBcUMsTUFBTSxJQUNqQixDQUFDO0NBQ2pELFFBQUEsZUFBTyxpQkFBQSxRQUFBLGlCQUFBLEtBQUEsSUFBQSxlQUFlO0FBQ3hCO0FBQ0EsU0FBUyw4QkFBOEIsWUFBWSxVQUFVLGFBQWEsVUFBVSxlQUFlO0NBQ2pHLElBQUksT0FBTztDQUNYLE9BQU8sS0FBSyxRQUNWLE9BQU8sS0FBSztDQUVkLElBQUksU0FBUyxXQUFXLEdBQ3RCLE9BQU8sS0FBSyxNQUFNLE1BQU0sTUFBTSxhQUFhLFVBQVUsYUFBYTtDQUVwRSxNQUFNLE1BQU0sa0JBQWtCLFFBQVE7Q0FDdEMsSUFBSSxJQUFJLE9BQU8sR0FDYixPQUFPLEtBQUssTUFBTSxNQUFNLElBQUksZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxhQUFhLFVBQVUsYUFBYTtDQUUzRixNQUFNLFdBQVcsbUNBQW1DLEtBQUssTUFBTSxVQUFVO0NBQ3pFLE1BQU0sa0JBQWtCLFNBQVMsa0JBQWtCLDJCQUEyQixTQUFTLGNBQWMsU0FBUyxPQUFPLElBQUksUUFBUSxJQUFJLG1CQUFtQixTQUFTLGNBQWMsU0FBUyxPQUFPLElBQUksUUFBUTtDQUMzTSxPQUFPLEtBQUssTUFBTSxTQUFTLGNBQWMsaUJBQWlCLGFBQWEsVUFBVSxhQUFhO0FBQ2hHO0FBQ0EsU0FBUyxlQUFlLFNBQVM7Q0FDL0IsT0FBTyxPQUFPLFlBQVksWUFBWSxXQUFXLFFBQVEsQ0FBQyxRQUFRLFdBQVcsQ0FBQyxRQUFRO0FBQ3hGO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxPQUFPLE9BQU8sWUFBWSxZQUFZLFdBQVcsUUFBUSxRQUFRO0FBQ25FO0FBQ0EsU0FBUyxxQkFBcUIsR0FBRyxHQUFHLGVBQWU7Q0FDakQsTUFBQSxJQUFNO0NBQ04sTUFBTSxPQUFPLElBQUksUUFBUTtDQUN6QixLQUFLLGNBQWMsR0FDaEIsSUFBSSxFQUNQO0NBQ0EsT0FBTyxjQUFjLE1BQU0sY0FBYyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUN4RTtBQUNBLFNBQVMsS0FBSyxTQUFTLGlCQUFpQixpQkFBaUIsYUFBYSxVQUFVLGVBQWU7Q0FDN0YsTUFBTSxLQUFLLENBQUM7Q0FDWixLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLGdCQUFBLFFBQUEsZ0JBQUEsS0FBQSxJQUFBLGNBQWUsQ0FBQyxDQUFDLEdBQ3pELEdBQUcsT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSSxNQUFLLHFCQUFxQixLQUFLLEdBQUcsYUFBYSxDQUFDLElBQUkscUJBQXFCLEtBQUssT0FBTyxhQUFhO0NBRS9JLElBQUk7Q0FDSixJQUFJLFlBQVksaUJBQ2QsZ0JBQWdCO01BRWhCLGdCQUFnQixlQUFlLFNBQVMsaUJBQWlCLGVBQWU7Q0FHMUUsT0FBTyxJQUFJLFFBREssV0FBVyxtQkFBbUIsYUFBYSxDQUN4QyxHQUFTLElBQUksUUFBUTtBQUMxQztBQUNBLFNBQVMsZUFBZSxTQUFTLFlBQVksWUFBWTtDQUN2RCxNQUFNLFdBQVcsT0FBTyxPQUFPLElBQUk7Q0FDbkMsT0FBTyxRQUFRLFFBQVEsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLFlBQVksT0FBTztFQUM1RCxJQUFJLE1BQU0sWUFDUixTQUFTLGNBQWM7T0FFdkIsU0FBUyxjQUFjLGVBQWUsR0FBRyxZQUFZLFVBQVU7Q0FFbkUsQ0FBQztDQUNELE9BQU8sSUFBSSxnQkFBZ0IsUUFBUSxVQUFVLFFBQVE7QUFDdkQ7QUFDQSxJQUFNLGFBQU4sTUFBaUI7Q0FJZixZQUFZLFlBQVksb0JBQW9CLFVBQVU7d0JBSHRELGNBQUEsS0FBQSxDQUFBO3dCQUNBLHNCQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssYUFBYTtFQUNsQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLFdBQVc7RUFDaEIsSUFBSSxjQUFjLFNBQVMsU0FBUyxLQUFLLGVBQWUsU0FBUyxFQUFFLEdBQ2pFLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsNENBQTRDO0VBRS9ILE1BQU0sZ0JBQWdCLFNBQVMsS0FBSyxvQkFBb0I7RUFDeEQsSUFBSSxpQkFBaUIsa0JBQWtCLEtBQUssUUFBUSxHQUNsRCxNQUFNLElBQUlBLGFBQWMsT0FBTyxPQUFPLGNBQWMsZUFBZSxjQUFjLHlDQUF5QztDQUU5SDtDQUNBLFNBQVM7RUFDUCxPQUFPLEtBQUssY0FBYyxLQUFLLFNBQVMsV0FBVyxLQUFLLEtBQUssU0FBUyxNQUFNO0NBQzlFO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixVQUFVO0NBQ25DLElBQUksT0FBTyxTQUFTLE9BQU8sWUFBWSxTQUFTLFdBQVcsS0FBSyxTQUFTLE9BQU8sS0FDOUUsT0FBTyxJQUFJLFdBQVcsTUFBTSxHQUFHLFFBQVE7Q0FFekMsSUFBSSxxQkFBcUI7Q0FDekIsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sTUFBTSxTQUFTLFFBQVEsS0FBSyxLQUFLLFdBQVc7RUFDaEQsSUFBSSxPQUFPLFFBQVEsWUFBWSxPQUFPLE1BQU07R0FDMUMsSUFBSSxJQUFJLFNBQVM7SUFDZixNQUFNLFVBQVUsQ0FBQztJQUNqQixPQUFPLFFBQVEsSUFBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxjQUFjO0tBQ3hELFFBQVEsUUFBUSxPQUFPLGFBQWEsV0FBVyxTQUFTLE1BQU0sR0FBRyxJQUFJO0lBQ3ZFLENBQUM7SUFDRCxPQUFPLENBQUMsR0FBRyxLQUFLLEVBQ2QsUUFDRixDQUFDO0dBQ0g7R0FDQSxJQUFJLElBQUksYUFDTixPQUFPLENBQUMsR0FBRyxLQUFLLElBQUksV0FBVztFQUVuQztFQUNBLElBQUksRUFBRSxPQUFPLFFBQVEsV0FDbkIsT0FBTyxDQUFDLEdBQUcsS0FBSyxHQUFHO0VBRXJCLElBQUksV0FBVyxHQUFHO0dBQ2hCLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxTQUFTLFNBQVMsY0FBYztJQUM3QyxJQUFJLGFBQWEsS0FBSyxZQUFZO1NBQVcsSUFBSSxhQUFhLEtBQUssWUFBWSxJQUM3RSxhQUFhO1NBQ1IsSUFBSSxZQUFZLE1BQ3JCO1NBQ0ssSUFBSSxXQUFXLElBQ3BCLElBQUksS0FBSyxPQUFPO0dBRXBCLENBQUM7R0FDRCxPQUFPO0VBQ1Q7RUFDQSxPQUFPLENBQUMsR0FBRyxLQUFLLEdBQUc7Q0FDckIsR0FBRyxDQUFDLENBQUM7Q0FDTCxPQUFPLElBQUksV0FBVyxZQUFZLG9CQUFvQixHQUFHO0FBQzNEO0FBQ0EsSUFBTSxXQUFOLE1BQWU7Q0FJYixZQUFZLGNBQWMsaUJBQWlCLE9BQU87d0JBSGxELGdCQUFBLEtBQUEsQ0FBQTt3QkFDQSxtQkFBQSxLQUFBLENBQUE7d0JBQ0EsU0FBQSxLQUFBLENBQUE7RUFFRSxLQUFLLGVBQWU7RUFDcEIsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxRQUFRO0NBQ2Y7QUFDRjtBQUNBLFNBQVMsbUNBQW1DLEtBQUssTUFBTSxRQUFRO0NBQzdELElBQUksSUFBSSxZQUNOLE9BQU8sSUFBSSxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBRW5DLElBQUksQ0FBQyxRQUNILE9BQU8sSUFBSSxTQUFTLE1BQU0sT0FBTyxHQUFHO0NBRXRDLElBQUksT0FBTyxXQUFXLE1BQ3BCLE9BQU8sSUFBSSxTQUFTLFFBQVEsTUFBTSxDQUFDO0NBRXJDLE1BQU0sV0FBVyxlQUFlLElBQUksU0FBUyxFQUFFLElBQUksSUFBSTtDQUV2RCxPQUFPLGlDQUFpQyxRQUQxQixPQUFPLFNBQVMsU0FBUyxJQUFJLFVBQ1ksSUFBSSxrQkFBa0I7QUFDL0U7QUFDQSxTQUFTLGlDQUFpQyxPQUFPLE9BQU8sb0JBQW9CO0NBQzFFLElBQUksSUFBSTtDQUNSLElBQUksS0FBSztDQUNULElBQUksS0FBSztDQUNULE9BQU8sS0FBSyxJQUFJO0VBQ2QsTUFBTTtFQUNOLElBQUksRUFBRTtFQUNOLElBQUksQ0FBQyxHQUNILE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMseUJBQXlCO0VBRTVHLEtBQUssRUFBRSxTQUFTO0NBQ2xCO0NBQ0EsT0FBTyxJQUFJLFNBQVMsR0FBRyxPQUFPLEtBQUssRUFBRTtBQUN2QztBQUNBLFNBQVMsV0FBVyxVQUFVO0NBQzVCLElBQUkscUJBQXFCLFNBQVMsRUFBRSxHQUNsQyxPQUFPLFNBQVMsRUFBRSxDQUFDO0NBRXJCLE9BQU8sR0FDSixpQkFBaUIsU0FDcEI7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLGNBQWMsWUFBWSxVQUFVOztDQUM5RCxDQUFBLGdCQUFBLGtCQUFBLFFBQUEsa0JBQUEsS0FBQSxNQUFBLGVBQWlCLElBQUksZ0JBQWdCLENBQUMsR0FBRyxDQUFDLENBQUM7Q0FDM0MsSUFBSSxhQUFhLFNBQVMsV0FBVyxLQUFLLGFBQWEsWUFBWSxHQUNqRSxPQUFPLDJCQUEyQixjQUFjLFlBQVksUUFBUTtDQUV0RSxNQUFNLElBQUksYUFBYSxjQUFjLFlBQVksUUFBUTtDQUN6RCxNQUFNLGlCQUFpQixTQUFTLE1BQU0sRUFBRSxZQUFZO0NBQ3BELElBQUksRUFBRSxTQUFTLEVBQUUsWUFBWSxhQUFhLFNBQVMsUUFBUTtFQUN6RCxNQUFNLElBQUksSUFBSSxnQkFBZ0IsYUFBYSxTQUFTLE1BQU0sR0FBRyxFQUFFLFNBQVMsR0FBRyxDQUFDLENBQUM7RUFDN0UsRUFBRSxTQUFTLGtCQUFrQixJQUFJLGdCQUFnQixhQUFhLFNBQVMsTUFBTSxFQUFFLFNBQVMsR0FBRyxhQUFhLFFBQVE7RUFDaEgsT0FBTywyQkFBMkIsR0FBRyxHQUFHLGNBQWM7Q0FDeEQsT0FBTyxJQUFJLEVBQUUsU0FBUyxlQUFlLFdBQVcsR0FDOUMsT0FBTyxJQUFJLGdCQUFnQixhQUFhLFVBQVUsQ0FBQyxDQUFDO01BQy9DLElBQUksRUFBRSxTQUFTLENBQUMsYUFBYSxZQUFZLEdBQzlDLE9BQU8sc0JBQXNCLGNBQWMsWUFBWSxRQUFRO01BQzFELElBQUksRUFBRSxPQUNYLE9BQU8sMkJBQTJCLGNBQWMsR0FBRyxjQUFjO01BRWpFLE9BQU8sc0JBQXNCLGNBQWMsWUFBWSxRQUFRO0FBRW5FO0FBQ0EsU0FBUywyQkFBMkIsY0FBYyxZQUFZLFVBQVU7Q0FDdEUsSUFBSSxTQUFTLFdBQVcsR0FDdEIsT0FBTyxJQUFJLGdCQUFnQixhQUFhLFVBQVUsQ0FBQyxDQUFDO01BQy9DO0VBQ0wsTUFBTSxVQUFVLFdBQVcsUUFBUTtFQUNuQyxNQUFNLFdBQVcsT0FBTyxPQUFPLElBQUk7RUFDbkMsSUFBSSxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBSyxNQUFLLE1BQUEsU0FBb0IsS0FBSyxhQUFhLFNBQUEsY0FBNEIsYUFBYSxxQkFBcUIsS0FBSyxhQUFhLFNBQUEsVUFBd0IsQ0FBQyxTQUFTLFdBQVcsR0FBRztHQUN2TSxNQUFNLHVCQUF1QiwyQkFBMkIsYUFBYSxTQUFTLGlCQUFpQixZQUFZLFFBQVE7R0FDbkgsT0FBTyxJQUFJLGdCQUFnQixhQUFhLFVBQVUscUJBQXFCLFFBQVE7RUFDakY7RUFDQSxPQUFPLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsY0FBYztHQUN0RCxJQUFJLE9BQU8sYUFBYSxVQUN0QixXQUFXLENBQUMsUUFBUTtHQUV0QixJQUFJLGFBQWEsTUFDZixTQUFTLFVBQVUsbUJBQW1CLGFBQWEsU0FBUyxTQUFTLFlBQVksUUFBUTtFQUU3RixDQUFDO0VBQ0QsT0FBTyxRQUFRLGFBQWEsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsV0FBVztHQUN0RSxJQUFJLFFBQVEsaUJBQWlCLEtBQUEsR0FDM0IsU0FBUyxlQUFlO0VBRTVCLENBQUM7RUFDRCxPQUFPLElBQUksZ0JBQWdCLGFBQWEsVUFBVSxRQUFRO0NBQzVEO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsY0FBYyxZQUFZLFVBQVU7Q0FDeEQsSUFBSSxzQkFBc0I7Q0FDMUIsSUFBSSxtQkFBbUI7Q0FDdkIsTUFBTSxVQUFVO0VBQ2QsT0FBTztFQUNQLFdBQVc7RUFDWCxjQUFjO0NBQ2hCO0NBQ0EsT0FBTyxtQkFBbUIsYUFBYSxTQUFTLFFBQVE7RUFDdEQsSUFBSSx1QkFBdUIsU0FBUyxRQUFRLE9BQU87RUFDbkQsTUFBTSxPQUFPLGFBQWEsU0FBUztFQUNuQyxNQUFNLFVBQVUsU0FBUztFQUN6QixJQUFJLHFCQUFxQixPQUFPLEdBQzlCO0VBRUYsTUFBTSxPQUFPLEdBQUc7RUFDaEIsTUFBTSxPQUFPLHNCQUFzQixTQUFTLFNBQVMsSUFBSSxTQUFTLHNCQUFzQixLQUFLO0VBQzdGLElBQUksbUJBQW1CLEtBQUssU0FBUyxLQUFBLEdBQVc7RUFDaEQsSUFBSSxRQUFRLFFBQVEsT0FBTyxTQUFTLFlBQVksS0FBSyxZQUFZLEtBQUEsR0FBVztHQUMxRSxJQUFJLENBQUMsUUFBUSxNQUFNLE1BQU0sSUFBSSxHQUFHLE9BQU87R0FDdkMsdUJBQXVCO0VBQ3pCLE9BQU87R0FDTCxJQUFJLENBQUMsUUFBUSxNQUFNLENBQUMsR0FBRyxJQUFJLEdBQUcsT0FBTztHQUNyQztFQUNGO0VBQ0E7Q0FDRjtDQUNBLE9BQU87RUFDTCxPQUFPO0VBQ1AsV0FBVztFQUNYLGNBQWM7Q0FDaEI7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLGNBQWMsWUFBWSxVQUFVO0NBQ2pFLE1BQU0sUUFBUSxhQUFhLFNBQVMsTUFBTSxHQUFHLFVBQVU7Q0FDdkQsSUFBSSxJQUFJO0NBQ1IsT0FBTyxJQUFJLFNBQVMsUUFBUTtFQUMxQixNQUFNLFVBQVUsU0FBUztFQUN6QixJQUFJLHFCQUFxQixPQUFPLEdBRTlCLE9BQU8sSUFBSSxnQkFBZ0IsT0FEVix5QkFBeUIsUUFBUSxPQUNoQixDQUFRO0VBRTVDLElBQUksTUFBTSxLQUFLLGVBQWUsU0FBUyxFQUFFLEdBQUc7R0FDMUMsTUFBTSxJQUFJLGFBQWEsU0FBUztHQUNoQyxNQUFNLEtBQUssSUFBSSxXQUFXLEVBQUUsTUFBTSxVQUFVLFNBQVMsRUFBRSxDQUFDLENBQUM7R0FDekQ7R0FDQTtFQUNGO0VBQ0EsTUFBTSxPQUFPLHFCQUFxQixPQUFPLElBQUksUUFBUSxRQUFRLGtCQUFrQixHQUFHO0VBQ2xGLE1BQU0sT0FBTyxJQUFJLFNBQVMsU0FBUyxJQUFJLFNBQVMsSUFBSSxLQUFLO0VBQ3pELElBQUksUUFBUSxRQUFRLGVBQWUsSUFBSSxHQUFHO0dBQ3hDLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxVQUFVLElBQUksQ0FBQyxDQUFDO0dBQ2hELEtBQUs7RUFDUCxPQUFPO0dBQ0wsTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsQ0FBQyxDQUFDO0dBQ25DO0VBQ0Y7Q0FDRjtDQUNBLE9BQU8sSUFBSSxnQkFBZ0IsT0FBTyxDQUFDLENBQUM7QUFDdEM7QUFDQSxTQUFTLHlCQUF5QixTQUFTO0NBQ3pDLE1BQU0sV0FBVyxDQUFDO0NBQ2xCLE9BQU8sUUFBUSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxjQUFjO0VBQ3RELElBQUksT0FBTyxhQUFhLFVBQ3RCLFdBQVcsQ0FBQyxRQUFRO0VBRXRCLElBQUksYUFBYSxNQUNmLFNBQVMsVUFBVSxzQkFBc0IsSUFBSSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsUUFBUTtDQUVyRixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLFFBQVE7Q0FDekIsTUFBTSxNQUFNLENBQUM7Q0FDYixPQUFPLFFBQVEsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyxJQUFJLEtBQUssR0FBRyxHQUFHO0NBQzFELE9BQU87QUFDVDtBQUNBLFNBQVMsUUFBUSxNQUFNLFFBQVEsU0FBUztDQUN0QyxPQUFPLFFBQVEsUUFBUSxRQUFRLGFBQWEsUUFBUSxRQUFRLFVBQVU7QUFDeEU7QUFDQSxJQUFNLHdCQUF3QjtBQUM5QixJQUFJO0NBQ0gsU0FBVSxXQUFXO0NBQ3BCLFVBQVUsVUFBVSxxQkFBcUIsS0FBSztDQUM5QyxVQUFVLFVBQVUsbUJBQW1CLEtBQUs7Q0FDNUMsVUFBVSxVQUFVLHNCQUFzQixLQUFLO0NBQy9DLFVBQVUsVUFBVSxxQkFBcUIsS0FBSztDQUM5QyxVQUFVLFVBQVUsc0JBQXNCLEtBQUs7Q0FDL0MsVUFBVSxVQUFVLGtCQUFrQixLQUFLO0NBQzNDLFVBQVUsVUFBVSxnQkFBZ0IsS0FBSztDQUN6QyxVQUFVLFVBQVUsc0JBQXNCLEtBQUs7Q0FDL0MsVUFBVSxVQUFVLG9CQUFvQixLQUFLO0NBQzdDLFVBQVUsVUFBVSwwQkFBMEIsS0FBSztDQUNuRCxVQUFVLFVBQVUsd0JBQXdCLE1BQU07Q0FDbEQsVUFBVSxVQUFVLDBCQUEwQixNQUFNO0NBQ3BELFVBQVUsVUFBVSx3QkFBd0IsTUFBTTtDQUNsRCxVQUFVLFVBQVUscUJBQXFCLE1BQU07Q0FDL0MsVUFBVSxVQUFVLG1CQUFtQixNQUFNO0NBQzdDLFVBQVUsVUFBVSxZQUFZLE1BQU07Q0FDdEMsVUFBVSxVQUFVLHVCQUF1QixNQUFNO0FBQ25ELEVBQUEsQ0FBRyxjQUFjLFlBQVksQ0FBQyxFQUFFO0FBQ2hDLElBQU0sY0FBTixNQUFrQjtDQUdoQixZQUFZLElBQUksS0FBSzt3QkFGckIsTUFBQSxLQUFBLENBQUE7d0JBQ0EsT0FBQSxLQUFBLENBQUE7RUFFRSxLQUFLLEtBQUs7RUFDVixLQUFLLE1BQU07Q0FDYjtBQUNGO0FBQ0EsSUFBTSxrQkFBTixjQUE4QixZQUFZO0NBSXhDLFlBQVksSUFBSSxLQUFLLG9CQUFvQixjQUFjLGdCQUFnQixNQUFNO0VBQzNFLE1BQU0sSUFBSSxHQUFHO3dCQUpmLFFBQU8sVUFBVSxlQUFBO3dCQUNqQixxQkFBQSxLQUFBLENBQUE7d0JBQ0EsaUJBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxnQkFBZ0I7Q0FDdkI7Q0FDQSxXQUFXO0VBQ1QsT0FBTyx1QkFBdUIsS0FBSyxHQUFHLFVBQVUsS0FBSyxJQUFJO0NBQzNEO0FBQ0Y7QUFDQSxJQUFNLGdCQUFOLGNBQTRCLFlBQVk7Q0FHdEMsWUFBWSxJQUFJLEtBQUssbUJBQW1CO0VBQ3RDLE1BQU0sSUFBSSxHQUFHO3dCQUhmLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsYUFBQTtFQUdmLEtBQUssb0JBQW9CO0NBQzNCO0NBQ0EsV0FBVztFQUNULE9BQU8scUJBQXFCLEtBQUssR0FBRyxVQUFVLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxrQkFBa0I7Q0FDekc7QUFDRjtBQUNBLElBQUk7Q0FDSCxTQUFVLDRCQUE0QjtDQUNyQywyQkFBMkIsMkJBQTJCLGNBQWMsS0FBSztDQUN6RSwyQkFBMkIsMkJBQTJCLCtCQUErQixLQUFLO0NBQzFGLDJCQUEyQiwyQkFBMkIsd0JBQXdCLEtBQUs7Q0FDbkYsMkJBQTJCLDJCQUEyQixtQkFBbUIsS0FBSztDQUM5RSwyQkFBMkIsMkJBQTJCLGFBQWEsS0FBSztBQUMxRSxFQUFBLENBQUcsK0JBQStCLDZCQUE2QixDQUFDLEVBQUU7QUFDbEUsSUFBSTtDQUNILFNBQVUsdUJBQXVCO0NBQ2hDLHNCQUFzQixzQkFBc0IsOEJBQThCLEtBQUs7Q0FDL0Usc0JBQXNCLHNCQUFzQixrQ0FBa0MsS0FBSztBQUNyRixFQUFBLENBQUcsMEJBQTBCLHdCQUF3QixDQUFDLEVBQUU7QUFDeEQsSUFBTSxtQkFBTixjQUErQixZQUFZO0NBSXpDLFlBQVksSUFBSSxLQUFLLFFBQVEsTUFBTTtFQUNqQyxNQUFNLElBQUksR0FBRzt3QkFKZixVQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsZ0JBQUE7RUFHZixLQUFLLFNBQVM7RUFDZCxLQUFLLE9BQU87Q0FDZDtDQUNBLFdBQVc7RUFDVCxPQUFPLHdCQUF3QixLQUFLLEdBQUcsVUFBVSxLQUFLLElBQUk7Q0FDNUQ7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLE9BQU87Q0FDakMsT0FBTyxpQkFBaUIscUJBQXFCLE1BQU0sU0FBUywyQkFBMkIsWUFBWSxNQUFNLFNBQVMsMkJBQTJCO0FBQy9JO0FBQ0EsSUFBTSxvQkFBTixjQUFnQyxZQUFZO0NBSTFDLFlBQVksSUFBSSxLQUFLLFFBQVEsTUFBTTtFQUNqQyxNQUFNLElBQUksR0FBRzt3QkFKZixVQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsaUJBQUE7RUFHZixLQUFLLFNBQVM7RUFDZCxLQUFLLE9BQU87Q0FDZDtBQUNGO0FBQ0EsSUFBTSxrQkFBTixjQUE4QixZQUFZO0NBSXhDLFlBQVksSUFBSSxLQUFLLE9BQU8sUUFBUTtFQUNsQyxNQUFNLElBQUksR0FBRzt3QkFKZixTQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsZUFBQTtFQUdmLEtBQUssUUFBUTtFQUNiLEtBQUssU0FBUztDQUNoQjtDQUNBLFdBQVc7RUFDVCxPQUFPLHVCQUF1QixLQUFLLEdBQUcsVUFBVSxLQUFLLElBQUksWUFBWSxLQUFLLE1BQU07Q0FDbEY7QUFDRjtBQUNBLElBQU0sbUJBQU4sY0FBK0IsWUFBWTtDQUl6QyxZQUFZLElBQUksS0FBSyxtQkFBbUIsT0FBTztFQUM3QyxNQUFNLElBQUksR0FBRzt3QkFKZixxQkFBQSxLQUFBLENBQUE7d0JBQ0EsU0FBQSxLQUFBLENBQUE7d0JBQ0EsUUFBTyxVQUFVLGdCQUFBO0VBR2YsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxRQUFRO0NBQ2Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTyx3QkFBd0IsS0FBSyxHQUFHLFVBQVUsS0FBSyxJQUFJLHlCQUF5QixLQUFLLGtCQUFrQixZQUFZLEtBQUssTUFBTTtDQUNuSTtBQUNGO0FBQ0EsSUFBTSxtQkFBTixjQUErQixZQUFZO0NBSXpDLFlBQVksSUFBSSxLQUFLLG1CQUFtQixPQUFPO0VBQzdDLE1BQU0sSUFBSSxHQUFHO3dCQUpmLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsZ0JBQUE7RUFHZixLQUFLLG9CQUFvQjtFQUN6QixLQUFLLFFBQVE7Q0FDZjtDQUNBLFdBQVc7RUFDVCxPQUFPLHdCQUF3QixLQUFLLEdBQUcsVUFBVSxLQUFLLElBQUkseUJBQXlCLEtBQUssa0JBQWtCLFlBQVksS0FBSyxNQUFNO0NBQ25JO0FBQ0Y7QUFDQSxJQUFNLGlCQUFOLGNBQTZCLFlBQVk7Q0FLdkMsWUFBWSxJQUFJLEtBQUssbUJBQW1CLE9BQU8sZ0JBQWdCO0VBQzdELE1BQU0sSUFBSSxHQUFHO3dCQUxmLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBQSxLQUFBLENBQUE7d0JBQ0EsUUFBTyxVQUFVLGNBQUE7RUFHZixLQUFLLG9CQUFvQjtFQUN6QixLQUFLLFFBQVE7RUFDYixLQUFLLGlCQUFpQjtDQUN4QjtDQUNBLFdBQVc7RUFDVCxPQUFPLHNCQUFzQixLQUFLLEdBQUcsVUFBVSxLQUFLLElBQUkseUJBQXlCLEtBQUssa0JBQWtCLFlBQVksS0FBSyxNQUFNLG9CQUFvQixLQUFLLGVBQWU7Q0FDeks7QUFDRjtBQUNBLElBQU0sZUFBTixjQUEyQixZQUFZO0NBSXJDLFlBQVksSUFBSSxLQUFLLG1CQUFtQixPQUFPO0VBQzdDLE1BQU0sSUFBSSxHQUFHO3dCQUpmLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsWUFBQTtFQUdmLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssUUFBUTtDQUNmO0NBQ0EsV0FBVztFQUNULE9BQU8sb0JBQW9CLEtBQUssR0FBRyxVQUFVLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxrQkFBa0IsWUFBWSxLQUFLLE1BQU07Q0FDL0g7QUFDRjtBQUNBLElBQU0sYUFBTixjQUF5QixZQUFZO0NBSW5DLFlBQVksSUFBSSxLQUFLLG1CQUFtQixPQUFPO0VBQzdDLE1BQU0sSUFBSSxHQUFHO3dCQUpmLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsVUFBQTtFQUdmLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssUUFBUTtDQUNmO0NBQ0EsV0FBVztFQUNULE9BQU8sa0JBQWtCLEtBQUssR0FBRyxVQUFVLEtBQUssSUFBSSx5QkFBeUIsS0FBSyxrQkFBa0IsWUFBWSxLQUFLLE1BQU07Q0FDN0g7QUFDRjtBQUNBLElBQU0sdUJBQU4sTUFBMkI7Q0FHekIsWUFBWSxPQUFPO3dCQUZuQixTQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsb0JBQUE7RUFFZixLQUFLLFFBQVE7Q0FDZjtDQUNBLFdBQVc7RUFDVCxPQUFPLDhCQUE4QixLQUFLLE1BQU0sS0FBSztDQUN2RDtBQUNGO0FBQ0EsSUFBTSxxQkFBTixNQUF5QjtDQUd2QixZQUFZLE9BQU87d0JBRm5CLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQU8sVUFBVSxrQkFBQTtFQUVmLEtBQUssUUFBUTtDQUNmO0NBQ0EsV0FBVztFQUNULE9BQU8sNEJBQTRCLEtBQUssTUFBTSxLQUFLO0NBQ3JEO0FBQ0Y7QUFDQSxJQUFNLHVCQUFOLE1BQTJCO0NBR3pCLFlBQVksVUFBVTt3QkFGdEIsWUFBQSxLQUFBLENBQUE7d0JBQ0EsUUFBTyxVQUFVLG9CQUFBO0VBRWYsS0FBSyxXQUFXO0NBQ2xCO0NBQ0EsV0FBVztFQUVULE9BQU8sK0JBRE0sS0FBSyxTQUFTLGVBQWUsS0FBSyxTQUFTLFlBQVksUUFBUSxHQUNqQztDQUM3QztBQUNGO0FBQ0EsSUFBTSxxQkFBTixNQUF5QjtDQUd2QixZQUFZLFVBQVU7d0JBRnRCLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQU8sVUFBVSxrQkFBQTtFQUVmLEtBQUssV0FBVztDQUNsQjtDQUNBLFdBQVc7RUFFVCxPQUFPLDZCQURNLEtBQUssU0FBUyxlQUFlLEtBQUssU0FBUyxZQUFZLFFBQVEsR0FDbkM7Q0FDM0M7QUFDRjtBQUNBLElBQU0sa0JBQU4sTUFBc0I7Q0FHcEIsWUFBWSxVQUFVO3dCQUZ0QixZQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsZUFBQTtFQUVmLEtBQUssV0FBVztDQUNsQjtDQUNBLFdBQVc7RUFFVCxPQUFPLDBCQURNLEtBQUssU0FBUyxlQUFlLEtBQUssU0FBUyxZQUFZLFFBQVEsR0FDdEM7Q0FDeEM7QUFDRjtBQUNBLElBQU0sZ0JBQU4sTUFBb0I7Q0FHbEIsWUFBWSxVQUFVO3dCQUZ0QixZQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsYUFBQTtFQUVmLEtBQUssV0FBVztDQUNsQjtDQUNBLFdBQVc7RUFFVCxPQUFPLHdCQURNLEtBQUssU0FBUyxlQUFlLEtBQUssU0FBUyxZQUFZLFFBQVEsR0FDeEM7Q0FDdEM7QUFDRjtBQUNBLElBQU0sU0FBTixNQUFhO0NBTVgsWUFBWSxhQUFhLFVBQVUsUUFBUSxnQkFBZ0I7d0JBTDNELGVBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGtCQUFBLEtBQUEsQ0FBQTt3QkFDQSxRQUFPLFVBQVUsTUFBQTtFQUVmLEtBQUssY0FBYztFQUNuQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxpQkFBaUI7Q0FDeEI7Q0FDQSxXQUFXO0VBQ1QsTUFBTSxNQUFNLEtBQUssV0FBVyxHQUFHLEtBQUssU0FBUyxHQUFHLElBQUksS0FBSyxTQUFTLE9BQU87RUFDekUsT0FBTyxtQkFBbUIsS0FBSyxPQUFPLGdCQUFnQixJQUFJO0NBQzVEO0FBQ0Y7QUFDQSxJQUFNLHVCQUFOLE1BQTJCLENBQUM7QUFDNUIsSUFBTSx5QkFBTixNQUE2QixDQUFDO0FBQzlCLElBQU0sa0JBQU4sTUFBc0I7Q0FHcEIsWUFBWSxLQUFLLDJCQUEyQjt3QkFGNUMsT0FBQSxLQUFBLENBQUE7d0JBQ0EsNkJBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxNQUFNO0VBQ1gsS0FBSyw0QkFBNEI7Q0FDbkM7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLEdBQUc7Q0FDOUIsT0FBTyxFQUFFLGFBQWEseUJBQXlCLEVBQUUsYUFBYSxvQkFBb0IsRUFBRSxhQUFhO0FBQ25HO0FBQ0EsU0FBUyxlQUFlLGFBQWE7Q0FDbkMsUUFBUSxZQUFZLE1BQXBCO0VBQ0UsS0FBSyxVQUFVOztHQUNiLE9BQU8sMEJBQUEsd0JBQXdCLFlBQVksU0FBUyxpQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQWEsU0FBUSxHQUFHO0VBQzlFLEtBQUssVUFBVTs7R0FDYixPQUFPLDRCQUFBLHlCQUEwQixZQUFZLFNBQVMsaUJBQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHVCQUFhLFNBQVEsR0FBRztFQUNoRixLQUFLLFVBQVU7O0dBQ2IsT0FBTywrQkFBQSx5QkFBNkIsWUFBWSxTQUFTLGlCQUFBLFFBQUEsMkJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSx1QkFBYSxTQUFRLEdBQUc7RUFDbkYsS0FBSyxVQUFVOztHQUNiLE9BQU8saUNBQUEseUJBQStCLFlBQVksU0FBUyxpQkFBQSxRQUFBLDJCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsdUJBQWEsU0FBUSxHQUFHO0VBQ3JGLEtBQUssVUFBVSxnQkFDYixPQUFPLHNCQUFzQixZQUFZLEdBQUcsVUFBVSxZQUFZLElBQUkseUJBQXlCLFlBQVksa0JBQWtCLFlBQVksWUFBWSxNQUFNLG9CQUFvQixZQUFZLGVBQWU7RUFDNU0sS0FBSyxVQUFVLGtCQUNiLE9BQU8sd0JBQXdCLFlBQVksR0FBRyxVQUFVLFlBQVksSUFBSSx5QkFBeUIsWUFBWSxrQkFBa0IsWUFBWSxZQUFZLE1BQU07RUFDL0osS0FBSyxVQUFVLGtCQUNiLE9BQU8sd0JBQXdCLFlBQVksR0FBRyxVQUFVLFlBQVksSUFBSTtFQUMxRSxLQUFLLFVBQVUsbUJBQ2IsT0FBTyx5QkFBeUIsWUFBWSxHQUFHLFVBQVUsWUFBWSxJQUFJO0VBQzNFLEtBQUssVUFBVSxlQUNiLE9BQU8scUJBQXFCLFlBQVksR0FBRyxVQUFVLFlBQVksSUFBSSx5QkFBeUIsWUFBWSxrQkFBa0I7RUFDOUgsS0FBSyxVQUFVLGlCQUNiLE9BQU8sdUJBQXVCLFlBQVksR0FBRyxVQUFVLFlBQVksSUFBSSxZQUFZLFlBQVksTUFBTTtFQUN2RyxLQUFLLFVBQVUsaUJBQ2IsT0FBTyx1QkFBdUIsWUFBWSxHQUFHLFVBQVUsWUFBWSxJQUFJO0VBQ3pFLEtBQUssVUFBVSxZQUNiLE9BQU8sa0JBQWtCLFlBQVksR0FBRyxVQUFVLFlBQVksSUFBSSx5QkFBeUIsWUFBWSxrQkFBa0IsWUFBWSxZQUFZLE1BQU07RUFDekosS0FBSyxVQUFVLGNBQ2IsT0FBTyxvQkFBb0IsWUFBWSxHQUFHLFVBQVUsWUFBWSxJQUFJLHlCQUF5QixZQUFZLGtCQUFrQixZQUFZLFlBQVksTUFBTTtFQUMzSixLQUFLLFVBQVUsb0JBQ2IsT0FBTyw0QkFBNEIsWUFBWSxNQUFNLEtBQUs7RUFDNUQsS0FBSyxVQUFVLHNCQUNiLE9BQU8sOEJBQThCLFlBQVksTUFBTSxLQUFLO0VBQzlELEtBQUssVUFBVSxrQkFDYixPQUFPLHdCQUF3QixZQUFZLEdBQUcsVUFBVSxZQUFZLElBQUkseUJBQXlCLFlBQVksa0JBQWtCLFlBQVksWUFBWSxNQUFNO0VBQy9KLEtBQUssVUFBVTtHQUNiLE1BQU0sTUFBTSxZQUFZLFdBQVcsR0FBRyxZQUFZLFNBQVMsR0FBRyxJQUFJLFlBQVksU0FBUyxPQUFPO0dBQzlGLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxnQkFBZ0IsSUFBSTtDQUNyRTtBQUNGO0FBQ0EsSUFBTSxnQkFBTixNQUFvQjtDQU1sQixJQUFJLFdBQVc7O0VBQ2IsUUFBQSx5QkFBQSxjQUFPLEtBQUssV0FBQSxRQUFBLGdCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsWUFBTyxTQUFTLDBCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUF3QixLQUFLO0NBQzNEO0NBQ0EsWUFBWSxjQUFjO3dCQVIxQixnQkFBQSxLQUFBLENBQUE7d0JBQ0EsVUFBUyxJQUFBO3dCQUNULFNBQVEsSUFBQTt3QkFDUixZQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFZLElBQUE7RUFLVixLQUFLLGVBQWU7RUFDcEIsS0FBSyxXQUFXLElBQUksdUJBQXVCLEtBQUssWUFBWTtDQUM5RDtBQUNGO0FBQ0EsSUFBTSx5QkFBTixNQUE2QjtDQUczQixZQUFZLGNBQWM7d0JBRjFCLGdCQUFBLEtBQUEsQ0FBQTt3QkFDQSw0QkFBVyxJQUFJLElBQUksQ0FBQTtFQUVqQixLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxxQkFBcUIsV0FBVyxRQUFRO0VBQ3RDLE1BQU0sVUFBVSxLQUFLLG1CQUFtQixTQUFTO0VBQ2pELFFBQVEsU0FBUztFQUNqQixLQUFLLFNBQVMsSUFBSSxXQUFXLE9BQU87Q0FDdEM7Q0FDQSx1QkFBdUIsV0FBVztFQUNoQyxNQUFNLFVBQVUsS0FBSyxXQUFXLFNBQVM7RUFDekMsSUFBSSxTQUFTO0dBQ1gsUUFBUSxTQUFTO0dBQ2pCLFFBQVEsWUFBWTtFQUN0QjtDQUNGO0NBQ0Esc0JBQXNCO0VBQ3BCLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLEtBQUssMkJBQVcsSUFBSSxJQUFJO0VBQ3hCLE9BQU87Q0FDVDtDQUNBLG1CQUFtQixVQUFVO0VBQzNCLEtBQUssV0FBVztDQUNsQjtDQUNBLG1CQUFtQixXQUFXO0VBQzVCLElBQUksVUFBVSxLQUFLLFdBQVcsU0FBUztFQUN2QyxJQUFJLENBQUMsU0FBUztHQUNaLFVBQVUsSUFBSSxjQUFjLEtBQUssWUFBWTtHQUM3QyxLQUFLLFNBQVMsSUFBSSxXQUFXLE9BQU87RUFDdEM7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxXQUFXLFdBQVc7RUFDcEIsT0FBTyxLQUFLLFNBQVMsSUFBSSxTQUFTLEtBQUs7Q0FDekM7QUFVRjs7d0NBVFMsUUFBTyxTQUFTLCtCQUErQixtQkFBbUI7Q0FFdkUsT0FBTyxLQUFLLHFCQUFxQkcseUJBQXdCQyxTQUFZQyxtQkFBc0IsQ0FBQztBQUM5RixDQUFBO3dDQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPRjtDQUNQLFNBQVNBLHdCQUF1QjtDQUNoQyxZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNELGlCQUFxQix3QkFBd0IsQ0FBQztFQUMvRixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsWUFBWSxPQUNkLENBQUM7Q0FDSCxDQUFDLFNBQVMsQ0FBQyxFQUNULE1BQU1HLG9CQUNSLENBQUMsR0FBRyxJQUFJO0FBQ1YsRUFBQSxDQUFHO0FBQ0gsSUFBTSxPQUFOLE1BQVc7Q0FFVCxZQUFZLE1BQU07d0JBRGxCLFNBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxRQUFRO0NBQ2Y7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssTUFBTTtDQUNwQjtDQUNBLE9BQU8sR0FBRztFQUNSLE1BQU0sSUFBSSxLQUFLLGFBQWEsQ0FBQztFQUM3QixPQUFPLEVBQUUsU0FBUyxJQUFJLEVBQUUsRUFBRSxTQUFTLEtBQUs7Q0FDMUM7Q0FDQSxTQUFTLEdBQUc7RUFDVixNQUFNLElBQUksU0FBUyxHQUFHLEtBQUssS0FBSztFQUNoQyxPQUFPLElBQUksRUFBRSxTQUFTLEtBQUksTUFBSyxFQUFFLEtBQUssSUFBSSxDQUFDO0NBQzdDO0NBQ0EsV0FBVyxHQUFHO0VBQ1osTUFBTSxJQUFJLFNBQVMsR0FBRyxLQUFLLEtBQUs7RUFDaEMsT0FBTyxLQUFLLEVBQUUsU0FBUyxTQUFTLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxRQUFRO0NBQzVEO0NBQ0EsU0FBUyxHQUFHO0VBQ1YsTUFBTSxJQUFJLFNBQVMsR0FBRyxLQUFLLEtBQUs7RUFDaEMsSUFBSSxFQUFFLFNBQVMsR0FBRyxPQUFPLENBQUM7RUFFMUIsT0FEVSxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsU0FBUyxLQUFJLE1BQUssRUFBRSxLQUN2QyxDQUFDLENBQUMsUUFBTyxPQUFNLE9BQU8sQ0FBQztDQUNoQztDQUNBLGFBQWEsR0FBRztFQUNkLE9BQU8sU0FBUyxHQUFHLEtBQUssS0FBSyxDQUFDLENBQUMsS0FBSSxNQUFLLEVBQUUsS0FBSztDQUNqRDtBQUNGO0FBQ0EsU0FBUyxTQUFTLE9BQU8sTUFBTTtDQUM3QixJQUFJLFVBQVUsS0FBSyxPQUFPLE9BQU87Q0FDakMsS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVO0VBQ2pDLE1BQU0sT0FBTyxTQUFTLE9BQU8sS0FBSztFQUNsQyxJQUFJLE1BQU0sT0FBTztDQUNuQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsU0FBUyxPQUFPLE1BQU07Q0FDN0IsSUFBSSxVQUFVLEtBQUssT0FBTyxPQUFPLENBQUMsSUFBSTtDQUN0QyxLQUFLLE1BQU0sU0FBUyxLQUFLLFVBQVU7RUFDakMsTUFBTSxPQUFPLFNBQVMsT0FBTyxLQUFLO0VBQ2xDLElBQUksS0FBSyxRQUFRO0dBQ2YsS0FBSyxRQUFRLElBQUk7R0FDakIsT0FBTztFQUNUO0NBQ0Y7Q0FDQSxPQUFPLENBQUM7QUFDVjtBQUNBLElBQU0sV0FBTixNQUFlO0NBR2IsWUFBWSxPQUFPLFVBQVU7d0JBRjdCLFNBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO0VBRUUsS0FBSyxRQUFRO0VBQ2IsS0FBSyxXQUFXO0NBQ2xCO0NBQ0EsV0FBVztFQUNULE9BQU8sWUFBWSxLQUFLLE1BQU07Q0FDaEM7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLE1BQU07Q0FDL0IsTUFBTSxNQUFNLENBQUM7Q0FDYixJQUFJLE1BQ0YsS0FBSyxTQUFTLFNBQVEsVUFBUyxJQUFJLE1BQU0sTUFBTSxVQUFVLEtBQUs7Q0FFaEUsT0FBTztBQUNUO0FBQ0EsSUFBTSxjQUFOLGNBQTBCLEtBQUs7Q0FFN0IsWUFBWSxNQUFNLFVBQVU7RUFDMUIsTUFBTSxJQUFJO3dCQUZaLFlBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxXQUFXO0VBQ2hCLGVBQWUsTUFBTSxJQUFJO0NBQzNCO0NBQ0EsV0FBVztFQUNULE9BQU8sS0FBSyxTQUFTLFNBQVM7Q0FDaEM7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLGVBQWUsVUFBVTtDQUNqRCxNQUFNLFdBQVcseUJBQXlCLGVBQWUsUUFBUTtDQUNqRSxNQUFNLFdBQVcsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLFdBQVcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQzdELE1BQU0sY0FBYyxJQUFJLGdCQUFnQixDQUFDLENBQUM7Q0FDMUMsTUFBTSxZQUFZLElBQUksZ0JBQWdCLENBQUMsQ0FBQztDQUd4QyxNQUFNLFlBQVksSUFBSSxlQUFlLFVBQVUsYUFBYSxJQUYvQixnQkFBZ0IsQ0FBQyxDQUVjLEdBQWtCLElBRHpELGdCQUFnQixFQUN5QyxHQUFVLFdBQVcsZ0JBQWdCLGVBQWUsU0FBUyxJQUFJO0NBQy9JLFVBQVUsV0FBVyxTQUFTO0NBQzlCLE9BQU8sSUFBSSxZQUFZLElBQUksU0FBUyxXQUFXLENBQUMsQ0FBQyxHQUFHLFFBQVE7QUFDOUQ7QUFDQSxTQUFTLHlCQUF5QixlQUFlLFVBQVU7Q0FNekQsT0FBTyxJQUFJLG9CQUFvQixJQUFJLElBQUksU0FBUyxJQUQxQix1QkFBdUIsQ0FBQyxHQUFHLENBQVUsR0FBRyxDQUFlLEdBQUcsSUFBVSxDQUFRLEdBQUcsZ0JBQWdCLGVBQWUsTUFBTSxDQUFDLEdBQUcsUUFDOUYsR0FBVyxDQUFDLENBQUMsQ0FBQztBQUNoRTtBQUNBLElBQU0saUJBQU4sTUFBcUI7Q0FvQm5CLFlBQVksWUFBWSxlQUFlLG9CQUFvQixpQkFBaUIsYUFBYSxRQUFRLFdBQVcsZ0JBQWdCOzt3QkFuQjVILGNBQUEsS0FBQSxDQUFBO3dCQUNBLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxzQkFBQSxLQUFBLENBQUE7d0JBQ0EsbUJBQUEsS0FBQSxDQUFBO3dCQUNBLGVBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLG1CQUFBLEtBQUEsQ0FBQTt3QkFDQSxnQkFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7d0JBQ0Esa0JBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLE9BQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGVBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQUEsS0FBQSxDQUFBO3dCQUNBLGtCQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssYUFBYTtFQUNsQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLGNBQWM7RUFDbkIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxZQUFZO0VBQ2pCLEtBQUssa0JBQWtCO0VBQ3ZCLEtBQUssU0FBQSx5QkFBQSxvQkFBUSxLQUFLLGlCQUFBLFFBQUEsc0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxrQkFBYSxLQUFLLEtBQUksTUFBSyxFQUFFLGNBQWMsQ0FBQyxPQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFLLEdBQUcsS0FBQSxDQUFTO0VBQy9FLEtBQUssTUFBTTtFQUNYLEtBQUssU0FBUztFQUNkLEtBQUssY0FBYztFQUNuQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxPQUFPO0NBQ2Q7Q0FDQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxLQUFLLGdCQUFnQjtDQUM5QjtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSyxhQUFhO0NBQzNCO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLGFBQWEsT0FBTyxJQUFJO0NBQ3RDO0NBQ0EsSUFBSSxhQUFhO0VBQ2YsT0FBTyxLQUFLLGFBQWEsV0FBVyxJQUFJO0NBQzFDO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLLGFBQWEsU0FBUyxJQUFJO0NBQ3hDO0NBQ0EsSUFBSSxlQUFlO0VBQ2pCLE9BQU8sS0FBSyxhQUFhLGFBQWEsSUFBSTtDQUM1QztDQUNBLElBQUksV0FBVzs7RUFDYixDQUFBLGtCQUFBLEtBQUssZUFBQSxRQUFBLG9CQUFBLEtBQUEsTUFBTCxLQUFLLFlBQWMsS0FBSyxPQUFPLEtBQUssS0FBSSxNQUFLLGtCQUFrQixDQUFDLENBQUMsQ0FBQztFQUNsRSxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksZ0JBQWdCOztFQUNsQixDQUFBLHdCQUFBLEtBQUssb0JBQUEsUUFBQSwwQkFBQSxLQUFBLE1BQUwsS0FBSyxpQkFBbUIsS0FBSyxZQUFZLEtBQUssS0FBSSxNQUFLLGtCQUFrQixDQUFDLENBQUMsQ0FBQztFQUM1RSxPQUFPLEtBQUs7Q0FDZDtDQUNBLFdBQVc7RUFDVCxPQUFPLEtBQUssV0FBVyxLQUFLLFNBQVMsU0FBUyxJQUFJLFVBQVUsS0FBSyxnQkFBZ0I7Q0FDbkY7QUFDRjtBQUNBLElBQU0sc0NBQXNDO0FBQzVDLFNBQVMsYUFBYSxPQUFPLFFBQVEsMkJBQTJCOztDQUM5RCxJQUFJO0NBQ0osTUFBTSxFQUNKLGdCQUNFO0NBQ0osSUFBSSxXQUFXLFNBQVMsOEJBQThCLGFBQUEsZ0JBQUEsUUFBQSxnQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFZLFlBQWEsVUFBUyxNQUFNLENBQUMsT0FBTyxhQUFhLEdBQUEsc0JBQUMsT0FBTyxpQkFBQSxRQUFBLHdCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsb0JBQWEsaUJBQ3RJLFlBQVk7RUFDVixRQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0ssT0FBTyxNQUFBLEdBQ1AsTUFBTSxNQUNYO0VBQ0EsTUFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNLLE9BQU8sSUFBQSxHQUNQLE1BQU0sSUFDWDtFQUNBLFNBQUEsZUFBQSxlQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0ssTUFBTSxJQUFBLEdBQ04sT0FBTyxJQUFBLEdBQUEsZ0JBQUEsUUFBQSxnQkFBQSxLQUFBLElBQUEsS0FBQSxJQUNQLFlBQWEsSUFBQSxHQUNiLE1BQU0sYUFDWDtDQUNGO01BQ0s7O0VBQ0wsWUFBWTtHQUNWLFFBQUEsZUFBQSxDQUFBLEdBQ0ssTUFBTSxNQUNYO0dBQ0EsTUFBQSxlQUFBLENBQUEsR0FDSyxNQUFNLElBQ1g7R0FDQSxTQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0ssTUFBTSxJQUFBLElBQUEsdUJBQ0wsTUFBTSxtQkFBQSxRQUFBLHlCQUFBLEtBQUEsSUFBQSx1QkFBaUIsQ0FBQyxDQUM5QjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLGVBQWUsZUFBZSxXQUFXLEdBQzNDLFVBQVUsUUFBUSxpQkFBaUIsWUFBWTtDQUVqRCxPQUFPO0FBQ1Q7QUFDQSxJQUFNLHlCQUFOLE1BQTZCO0NBZTNCLElBQUksUUFBUTs7RUFDVixRQUFBLGFBQU8sS0FBSyxVQUFBLFFBQUEsZUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFdBQU87Q0FDckI7Q0FDQSxZQUFZLEtBQUssUUFBUSxhQUFhLFVBQVUsTUFBTSxRQUFRLFdBQVcsYUFBYSxTQUFTLHFCQUFxQjt3QkFqQnBILE9BQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGVBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLFFBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQUEsS0FBQSxDQUFBO3dCQUNBLGVBQUEsS0FBQSxDQUFBO3dCQUNBLFlBQUEsS0FBQSxDQUFBO3dCQUNBLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxnQkFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7d0JBQ0Esa0JBQUEsS0FBQSxDQUFBO3dCQUNBLHdCQUFBLEtBQUEsQ0FBQTtFQUtFLEtBQUssTUFBTTtFQUNYLEtBQUssU0FBUztFQUNkLEtBQUssY0FBYztFQUNuQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxPQUFPO0VBQ1osS0FBSyxTQUFTO0VBQ2QsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztFQUNuQixLQUFLLFdBQVc7RUFDaEIsS0FBSyx1QkFBdUI7Q0FDOUI7Q0FDQSxJQUFJLE9BQU87RUFDVCxPQUFPLEtBQUssYUFBYTtDQUMzQjtDQUNBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxhQUFhLE9BQU8sSUFBSTtDQUN0QztDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxhQUFhLFdBQVcsSUFBSTtDQUMxQztDQUNBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSyxhQUFhLFNBQVMsSUFBSTtDQUN4QztDQUNBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUssYUFBYSxhQUFhLElBQUk7Q0FDNUM7Q0FDQSxJQUFJLFdBQVc7O0VBQ2IsQ0FBQSxtQkFBQSxLQUFLLGVBQUEsUUFBQSxxQkFBQSxLQUFBLE1BQUwsS0FBSyxZQUFjLGtCQUFrQixLQUFLLE1BQU07RUFDaEQsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLGdCQUFnQjs7RUFDbEIsQ0FBQSx3QkFBQSxLQUFLLG9CQUFBLFFBQUEsMEJBQUEsS0FBQSxNQUFMLEtBQUssaUJBQW1CLGtCQUFrQixLQUFLLFdBQVc7RUFDMUQsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxXQUFXO0VBR1QsT0FBTyxjQUZLLEtBQUssSUFBSSxLQUFJLFlBQVcsUUFBUSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FFdEMsRUFBRSxXQURULEtBQUssY0FBYyxLQUFLLFlBQVksT0FBTyxHQUNmO0NBQzlDO0FBQ0Y7QUFDQSxJQUFNLHNCQUFOLGNBQWtDLEtBQUs7Q0FFckMsWUFBWSxLQUFLLE1BQU07RUFDckIsTUFBTSxJQUFJO3dCQUZaLE9BQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxNQUFNO0VBQ1gsZUFBZSxNQUFNLElBQUk7Q0FDM0I7Q0FDQSxXQUFXO0VBQ1QsT0FBTyxjQUFjLEtBQUssS0FBSztDQUNqQztBQUNGO0FBQ0EsU0FBUyxlQUFlLE9BQU8sTUFBTTtDQUNuQyxLQUFLLE1BQU0sZUFBZTtDQUMxQixLQUFLLFNBQVMsU0FBUSxNQUFLLGVBQWUsT0FBTyxDQUFDLENBQUM7QUFDckQ7QUFDQSxTQUFTLGNBQWMsTUFBTTtDQUMzQixNQUFNLElBQUksS0FBSyxTQUFTLFNBQVMsSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLGFBQWEsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLE9BQU87Q0FDOUYsT0FBTyxHQUFHLEtBQUssUUFBUTtBQUN6QjtBQUNBLFNBQVMsc0JBQXNCLE9BQU87Q0FDcEMsSUFBSSxNQUFNLFVBQVU7RUFDbEIsTUFBTSxrQkFBa0IsTUFBTTtFQUM5QixNQUFNLGVBQWUsTUFBTTtFQUMzQixNQUFNLFdBQVc7RUFDakIsSUFBSSxDQUFDLGFBQWEsZ0JBQWdCLGFBQWEsYUFBYSxXQUFXLEdBQ3JFLE1BQU0sbUJBQW1CLEtBQUssYUFBYSxXQUFXO0VBRXhELElBQUksZ0JBQWdCLGFBQWEsYUFBYSxVQUM1QyxNQUFNLGdCQUFnQixLQUFLLGFBQWEsUUFBUTtFQUVsRCxJQUFJLENBQUMsYUFBYSxnQkFBZ0IsUUFBUSxhQUFhLE1BQU0sR0FDM0QsTUFBTSxjQUFjLEtBQUssYUFBYSxNQUFNO0VBRTlDLElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLEtBQUssYUFBYSxHQUFHLEdBQzNELE1BQU0sV0FBVyxLQUFLLGFBQWEsR0FBRztFQUV4QyxJQUFJLENBQUMsYUFBYSxnQkFBZ0IsTUFBTSxhQUFhLElBQUksR0FDdkQsTUFBTSxZQUFZLEtBQUssYUFBYSxJQUFJO0NBRTVDLE9BQU87RUFDTCxNQUFNLFdBQVcsTUFBTTtFQUN2QixNQUFNLFlBQVksS0FBSyxNQUFNLGdCQUFnQixJQUFJO0NBQ25EO0FBQ0Y7QUFDQSxTQUFTLDBCQUEwQixHQUFHLEdBQUc7Q0FDdkMsTUFBTSxpQkFBaUIsYUFBYSxFQUFFLFFBQVEsRUFBRSxNQUFNLEtBQUssY0FBYyxFQUFFLEtBQUssRUFBRSxHQUFHO0NBQ3JGLE1BQU0sa0JBQWtCLENBQUMsRUFBRSxXQUFXLENBQUMsRUFBRTtDQUN6QyxPQUFPLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLEVBQUUsVUFBVSwwQkFBMEIsRUFBRSxRQUFRLEVBQUUsTUFBTTtBQUN6RztBQUNBLFNBQVMsZUFBZSxRQUFRO0NBQzlCLE9BQU8sT0FBTyxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVU7QUFDOUQ7QUFDQSxJQUFNLHFCQUFxQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxzQkFBc0IsRUFBRTtBQUN0SCxJQUFNLGVBQU4sTUFBbUI7O3dCQUNqQixhQUFZLElBQUE7d0JBSVosbUJBQWtCLElBQUE7d0JBQ2xCLFFBQU8sY0FBQTt3QkFDUCxrQkFBaUIsSUFBSSxhQUFhLENBQUE7d0JBQ2xDLG9CQUFtQixJQUFJLGFBQWEsQ0FBQTt3QkFDcEMsZ0JBQWUsSUFBSSxhQUFhLENBQUE7d0JBQ2hDLGdCQUFlLElBQUksYUFBYSxDQUFBO3dCQUNoQyxvQkFBbUIsTUFBTSxHQUFJLFlBQVksQ0FBQyxLQUFBLEdBQVcsRUFDbkQsV0FBVyxtQkFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1Isa0JBQWlCLE9BQU8sc0JBQXNCLENBQUE7d0JBQzlDLFlBQVcsT0FBTyxnQkFBZ0IsQ0FBQTt3QkFDbEMsa0JBQWlCLE9BQU8saUJBQWlCLENBQUE7d0JBQ3pDLGVBQWMsT0FBTyxjQUFjLEVBQ2pDLFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0Qsb0NBQW1DLElBQUE7O0NBbEJuQyxJQUFJLHdCQUF3QjtFQUMxQixPQUFPLEtBQUs7Q0FDZDtDQWlCQSxZQUFZLFNBQVM7RUFDbkIsSUFBSSxRQUFRLFNBQVM7R0FDbkIsTUFBTSxFQUNKLGFBQ0Esa0JBQ0UsUUFBUTtHQUNaLElBQUksYUFDRjtHQUVGLElBQUksS0FBSywwQkFBMEIsYUFBYSxHQUFHO0lBQ2pELEtBQUssV0FBVztJQUNoQixLQUFLLGVBQWUsdUJBQXVCLGFBQWE7R0FDMUQ7R0FDQSxLQUFLLHlCQUF5QjtFQUNoQztDQUNGO0NBQ0EsY0FBYzs7RUFDWixJQUFJLEtBQUssMEJBQTBCLEtBQUssSUFBSSxHQUMxQyxLQUFLLGVBQWUsdUJBQXVCLEtBQUssSUFBSTtFQUV0RCxDQUFBLG9CQUFBLEtBQUssaUJBQUEsUUFBQSxzQkFBQSxLQUFBLEtBQUEsa0JBQWEseUJBQXlCLElBQUk7Q0FDakQ7Q0FDQSwwQkFBMEIsWUFBWTs7RUFDcEMsU0FBQSx3QkFBTyxLQUFLLGVBQWUsV0FBVyxVQUFVLE9BQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFHLFlBQVc7Q0FDaEU7Q0FDQSxXQUFXO0VBQ1QsS0FBSyx5QkFBeUI7Q0FDaEM7Q0FDQSwyQkFBMkI7RUFDekIsS0FBSyxlQUFlLHFCQUFxQixLQUFLLE1BQU0sSUFBSTtFQUN4RCxJQUFJLEtBQUssV0FDUDtFQUVGLE1BQU0sVUFBVSxLQUFLLGVBQWUsV0FBVyxLQUFLLElBQUk7RUFDeEQsSUFBQSxZQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFJLFFBQVMsT0FDWCxJQUFJLFFBQVEsV0FDVixLQUFLLE9BQU8sUUFBUSxXQUFXLFFBQVEsS0FBSztPQUU1QyxLQUFLLGFBQWEsUUFBUSxPQUFPLFFBQVEsUUFBUTtDQUd2RDtDQUNBLElBQUksY0FBYztFQUNoQixPQUFPLENBQUMsQ0FBQyxLQUFLO0NBQ2hCO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsSUFBSSxDQUFDLEtBQUssV0FBVyxNQUFNLElBQUlMLGFBQWMsT0FBTyxPQUFPLGNBQWMsZUFBZSxjQUFjLHlCQUF5QjtFQUMvSCxPQUFPLEtBQUssVUFBVTtDQUN4QjtDQUNBLElBQUksaUJBQWlCO0VBQ25CLElBQUksQ0FBQyxLQUFLLFdBQVcsTUFBTSxJQUFJQSxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyx5QkFBeUI7RUFDL0gsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLHFCQUFxQjtFQUN2QixJQUFJLEtBQUssaUJBQ1AsT0FBTyxLQUFLLGdCQUFnQixTQUFTO0VBRXZDLE9BQU8sQ0FBQztDQUNWO0NBQ0EsU0FBUztFQUNQLElBQUksQ0FBQyxLQUFLLFdBQVcsTUFBTSxJQUFJQSxhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyx5QkFBeUI7RUFDL0gsS0FBSyxTQUFTLE9BQU87RUFDckIsTUFBTSxNQUFNLEtBQUs7RUFDakIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssa0JBQWtCO0VBQ3ZCLEtBQUssYUFBYSxLQUFLLElBQUksUUFBUTtFQUNuQyxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLEtBQUssZ0JBQWdCOztFQUMxQixLQUFLLFlBQVk7RUFDakIsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxTQUFTLE9BQU8sSUFBSSxRQUFRO0VBQ2pDLENBQUEscUJBQUEsS0FBSyxpQkFBQSxRQUFBLHVCQUFBLEtBQUEsS0FBQSxtQkFBYSxvQ0FBb0MsSUFBSTtFQUMxRCxLQUFLLGFBQWEsS0FBSyxJQUFJLFFBQVE7Q0FDckM7Q0FDQSxhQUFhO0VBQ1gsSUFBSSxLQUFLLFdBQVc7R0FDbEIsTUFBTSxJQUFJLEtBQUs7R0FDZixLQUFLLFVBQVUsUUFBUTtHQUN2QixLQUFLLFlBQVk7R0FDakIsS0FBSyxrQkFBa0I7R0FDdkIsS0FBSyxpQkFBaUIsS0FBSyxDQUFDO0VBQzlCO0NBQ0Y7Q0FDQSxhQUFhLGdCQUFnQixxQkFBcUI7O0VBQ2hELElBQUksS0FBSyxhQUNQLE1BQU0sSUFBSUEsYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsNkNBQTZDO0VBRWhJLEtBQUssa0JBQWtCO0VBQ3ZCLE1BQU0sV0FBVyxLQUFLO0VBRXRCLE1BQU0sWUFEVyxlQUFlLFNBQ0w7RUFDM0IsTUFBTSxnQkFBZ0IsS0FBSyxlQUFlLG1CQUFtQixLQUFLLElBQUksQ0FBQyxDQUFDO0VBQ3hFLE1BQU0sV0FBVyxJQUFJLGVBQWUsZ0JBQWdCLGVBQWUsU0FBUyxVQUFVLEtBQUssZ0JBQWdCO0VBQzNHLEtBQUssWUFBWSxTQUFTLGdCQUFnQixXQUFXO0dBQ25ELE9BQU8sU0FBUztHQUNoQjtHQUNxQjtFQUN2QixDQUFDO0VBQ0QsS0FBSyxlQUFlLGFBQWE7RUFDakMsQ0FBQSxxQkFBQSxLQUFLLGlCQUFBLFFBQUEsdUJBQUEsS0FBQSxLQUFBLG1CQUFhLG9DQUFvQyxJQUFJO0VBQzFELEtBQUssZUFBZSxLQUFLLEtBQUssVUFBVSxRQUFRO0NBQ2xEO0FBb0JGOzs4QkFuQlMsUUFBTyxTQUFTLHFCQUFxQixtQkFBbUI7Q0FDN0QsT0FBTyxLQUFLLHFCQUFxQk0sZUFBYztBQUNqRCxDQUFBOzhCQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVcsQ0FBQyxDQUFDLGVBQWUsQ0FBQztDQUM3QixRQUFRO0VBQ04sTUFBTTtFQUNOLGtCQUFrQixDQUFDLEdBQUcsa0JBQWtCO0NBQzFDO0NBQ0EsU0FBUztFQUNQLGdCQUFnQjtFQUNoQixrQkFBa0I7RUFDbEIsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxVQUFVLENBQUMsUUFBUTtDQUNuQixVQUFVLENBQUNDLG9CQUF1QjtBQUNwQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY0wsaUJBQXFCLGNBQWMsQ0FBQztFQUNyRixNQUFNO0VBQ04sTUFBTSxDQUFDO0dBQ0wsVUFBVTtHQUNWLFVBQVU7RUFDWixDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU07RUFDUixNQUFNLENBQUMsRUFDTCxNQUFNLE1BQ1IsQ0FBQztFQUNELGdCQUFnQixDQUFDO0dBQ2YsTUFBTTtHQUNOLE1BQU0sQ0FBQyxVQUFVO0VBQ25CLENBQUM7RUFDRCxrQkFBa0IsQ0FBQztHQUNqQixNQUFNO0dBQ04sTUFBTSxDQUFDLFlBQVk7RUFDckIsQ0FBQztFQUNELGNBQWMsQ0FBQztHQUNiLE1BQU07R0FDTixNQUFNLENBQUMsUUFBUTtFQUNqQixDQUFDO0VBQ0QsY0FBYyxDQUFDO0dBQ2IsTUFBTTtHQUNOLE1BQU0sQ0FBQyxRQUFRO0VBQ2pCLENBQUM7RUFDRCxrQkFBa0IsQ0FBQztHQUNqQixNQUFNTTtHQUNOLE1BQU0sQ0FBQztJQUNMLFVBQVU7SUFDVixPQUFPO0lBQ1AsVUFBVTtHQUNaLENBQUM7RUFDSCxDQUFDO0NBQ0gsQ0FBQztBQUNILEVBQUEsQ0FBRztBQUNILElBQU0saUJBQU4sTUFBcUI7Q0FLbkIsWUFBWSxPQUFPLGVBQWUsUUFBUSxZQUFZO3dCQUp0RCxTQUFBLEtBQUEsQ0FBQTt3QkFDQSxpQkFBQSxLQUFBLENBQUE7d0JBQ0EsVUFBQSxLQUFBLENBQUE7d0JBQ0EsY0FBQSxLQUFBLENBQUE7RUFFRSxLQUFLLFFBQVE7RUFDYixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLFNBQVM7RUFDZCxLQUFLLGFBQWE7Q0FDcEI7Q0FDQSxJQUFJLE9BQU8sZUFBZTtFQUN4QixJQUFJLFVBQVUsZ0JBQ1osT0FBTyxLQUFLO0VBRWQsSUFBSSxVQUFVLHdCQUNaLE9BQU8sS0FBSztFQUVkLElBQUksVUFBVSxvQkFDWixPQUFPLEtBQUs7RUFFZCxPQUFPLEtBQUssT0FBTyxJQUFJLE9BQU8sYUFBYTtDQUM3QztBQUNGO0FBQ0EsSUFBTSxlQUFlLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHdCQUF3QixFQUFFO0FBQ2xILElBQU0sNkJBQU4sTUFBaUM7Q0FJL0IsWUFBWSxTQUFTOzt3QkFIckIsV0FBQSxLQUFBLENBQUE7d0JBQ0EsMkNBQTBCLElBQUksSUFBSSxDQUFBO3dCQUNsQyxrQ0FBaUIsSUFBSSxJQUFJLENBQUE7RUFFdkIsS0FBSyxVQUFVO0VBQ2YsQ0FBQSx5QkFBQSxnQkFBQSxLQUFLLFFBQUEsQ0FBUSxpQkFBQSxRQUFBLDBCQUFBLEtBQUEsTUFBQSxjQUFBLGNBQWdCO0NBQy9CO0NBQ0Esb0NBQW9DLFFBQVE7RUFDMUMsS0FBSyx5QkFBeUIsTUFBTTtFQUNwQyxLQUFLLHFCQUFxQixNQUFNO0NBQ2xDO0NBQ0EseUJBQXlCLFFBQVE7O0VBQy9CLENBQUEsd0JBQUEsS0FBSyx3QkFBd0IsSUFBSSxNQUFNLE9BQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQUcsWUFBWTtFQUN0RCxLQUFLLHdCQUF3QixPQUFPLE1BQU07RUFDMUMsS0FBSyxlQUFlLE9BQU8sTUFBTTtDQUNuQztDQUNBLHFCQUFxQixRQUFRO0VBQzNCLE1BQU0sRUFDSixtQkFDRTtFQUNKLE1BQU0sbUJBQW1CLGNBQWM7R0FBQyxLQUFLLFFBQVEsY0FBYyxlQUFlLGNBQWMsR0FBRyxDQUFDLENBQUM7R0FBRyxlQUFlO0dBQVEsZUFBZTtFQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDLGFBQWEsUUFBUSxPQUFPLFVBQVU7R0FDMU0sT0FBQSxlQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0ssV0FBQSxHQUNBLE1BQUEsR0FDQSxJQUNMO0dBQ0EsSUFBSSxVQUFVLEdBQ1osT0FBTyxHQUFHLElBQUk7R0FFaEIsT0FBTyxRQUFRLFFBQVEsSUFBSTtFQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVUsU0FBUTs7R0FDcEIsSUFBSSxDQUFDLE9BQU8sZUFBZSxDQUFDLE9BQU8seUJBQXlCLE9BQU8sbUJBQW1CLGtCQUFrQixlQUFlLGNBQWMsTUFBTTtJQUN6SSxLQUFLLHlCQUF5QixNQUFNO0lBQ3BDO0dBQ0Y7R0FDQSxNQUFNLFNBQVMscUJBQXFCLGVBQWUsU0FBUztHQUM1RCxJQUFJLENBQUMsUUFBUTtJQUNYLEtBQUsseUJBQXlCLE1BQU07SUFDcEM7R0FDRjtHQUNBLElBQUksV0FBVyxLQUFLLGVBQWUsSUFBSSxNQUFNO0dBQzdDLElBQUksQ0FBQyxVQUFVO0lBQ2IsMkJBQVcsSUFBSSxJQUFJO0lBQ25CLEtBQUssZUFBZSxJQUFJLFFBQVEsUUFBUTtHQUMxQztHQUNBLEtBQUssTUFBTSxPQUFPLE9BQU8sS0FBSyxJQUFJLEdBQ2hDLFNBQVMsSUFBSSxHQUFHO0dBRWxCLE1BQU0sWUFBQSx3QkFBVyxLQUFLLFFBQVEsNEJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQTBCO0dBQ3hELEtBQUssTUFBTSxFQUNULGtCQUNHLE9BQU8sUUFBUTtJQUNsQixNQUFNLFFBQVEsS0FBSztJQUNuQixJQUFJLFVBQVUsS0FBQSxLQUFhLGFBQWEscUJBQXFCLFNBQVMsSUFBSSxZQUFZLEdBQ3BGLE9BQU8sc0JBQXNCLFNBQVMsY0FBYyxLQUFLO0dBRTdEO0VBQ0YsQ0FBQztFQUNELEtBQUssd0JBQXdCLElBQUksUUFBUSxnQkFBZ0I7Q0FDM0Q7QUFRRjs7NENBUFMsUUFBTyxTQUFTLG1DQUFtQyxtQkFBbUI7Q0FDM0UsaUJBQW9CO0FBQ3RCLENBQUE7NENBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9DO0NBQ1AsU0FBU0EsNEJBQTJCO0FBQ3RDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjUCxpQkFBcUIsNEJBQTRCLENBQUMsRUFDbkcsTUFBTSxXQUNSLENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTSxLQUFBLEVBQ1IsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxJQUFNLHdCQUFOLE1BQTRCLENBbUI1Qjs7dUNBbEJTLFFBQU8sU0FBUyw4QkFBOEIsbUJBQW1CO0NBQ3RFLE9BQU8sS0FBSyxxQkFBcUJRLHdCQUF1QjtBQUMxRCxDQUFBO3VDQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNQTtDQUNOLFdBQVcsQ0FBQyxDQUFDLGNBQWMsQ0FBQztDQUM1QixVQUFVLENBQUMsbUJBQW1CO0NBQzlCLE9BQU87Q0FDUCxNQUFNO0NBQ04sVUFBVSxTQUFTLCtCQUErQixJQUFJLEtBQUs7RUFDekQsSUFBSSxLQUFLLEdBQ1AsVUFBYSxHQUFHLGVBQWU7Q0FFbkM7Q0FDQSxjQUFjLENBQUMsWUFBWTtDQUMzQixlQUFlO0NBQ2YsaUJBQWlCO0FBQ25CLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjUixpQkFBcUIsdUJBQXVCLENBQUM7RUFDOUYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixTQUFTLENBQUMsWUFBWTtHQUN0QixVQUFVO0dBQ1YsaUJBQWlCLHdCQUF3QjtFQUMzQyxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxTQUFTLGtCQUFrQixHQUFHO0NBQzVCLE1BQU0sV0FBVyxFQUFFLFlBQVksRUFBRSxTQUFTLElBQUksaUJBQWlCO0NBQy9ELE1BQU0sSUFBSSxXQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0wsQ0FBQSxHQUFBLENBQUEsR0FBQSxFQUNILFNBQUEsQ0FDRixJQUFBLGVBQUEsQ0FBQSxHQUNLLENBQ0w7Q0FDQSxJQUFJLENBQUMsRUFBRSxhQUFhLENBQUMsRUFBRSxrQkFBa0IsWUFBWSxFQUFFLGlCQUFpQixFQUFFLFVBQVUsRUFBRSxXQUFBLFdBQ3BGLEVBQUUsWUFBWTtDQUVoQixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixvQkFBb0IsTUFBTSxXQUFXO0NBQzlELE1BQU0scUNBQXFCLElBQUksSUFBSTtDQUVuQyxPQUFPO0VBQ0w7RUFDQSxPQUFPLElBQUksWUFIQSxXQUFXLG9CQUFvQixLQUFLLE9BQU8sWUFBWSxVQUFVLFFBQVEsS0FBQSxHQUFXLGtCQUd4RSxHQUFNLElBQUk7Q0FDbkM7QUFDRjtBQUNBLFNBQVMsV0FBVyxvQkFBb0IsTUFBTSxXQUFXLG9CQUFvQjtDQUMzRSxJQUFJLGFBQWEsbUJBQW1CLGlCQUFpQixLQUFLLE9BQU8sVUFBVSxNQUFNLFFBQVEsR0FBRztFQUMxRixNQUFNLFFBQVEsVUFBVTtFQUN4QixNQUFNLGtCQUFrQixLQUFLO0VBRTdCLE9BQU8sSUFBSSxTQUFTLE9BREgsc0JBQXNCLG9CQUFvQixNQUFNLFdBQVcsa0JBQ2pELENBQVE7Q0FDckMsT0FBTztFQUNMLElBQUksbUJBQW1CLGFBQWEsS0FBSyxLQUFLLEdBQUc7R0FDL0MsTUFBTSxzQkFBc0IsbUJBQW1CLFNBQVMsS0FBSyxLQUFLO0dBQ2xFLElBQUksd0JBQXdCLE1BQU07SUFDaEMsTUFBTSxPQUFPLG9CQUFvQjtJQUNqQyxLQUFLLE1BQU0sa0JBQWtCLEtBQUs7SUFDbEMsS0FBSyxXQUFXLEtBQUssU0FBUyxLQUFJLE1BQUssV0FBVyxvQkFBb0IsR0FBRyxLQUFBLEdBQVcsa0JBQWtCLENBQUM7SUFDdkcsT0FBTztHQUNUO0VBQ0Y7RUFDQSxNQUFNLFFBQVEscUJBQXFCLEtBQUssS0FBSztFQUM3QyxtQkFBbUIsSUFBSSxLQUFLO0VBRTVCLE9BQU8sSUFBSSxTQUFTLE9BREgsS0FBSyxTQUFTLEtBQUksTUFBSyxXQUFXLG9CQUFvQixHQUFHLEtBQUEsR0FBVyxrQkFBa0IsQ0FDNUUsQ0FBUTtDQUNyQztBQUNGO0FBQ0EsU0FBUyxzQkFBc0Isb0JBQW9CLE1BQU0sV0FBVyxvQkFBb0I7Q0FDdEYsT0FBTyxLQUFLLFNBQVMsS0FBSSxVQUFTO0VBQ2hDLEtBQUssTUFBTSxLQUFLLFVBQVUsVUFDeEIsSUFBSSxtQkFBbUIsaUJBQWlCLE1BQU0sT0FBTyxFQUFFLE1BQU0sUUFBUSxHQUNuRSxPQUFPLFdBQVcsb0JBQW9CLE9BQU8sR0FBRyxrQkFBa0I7RUFHdEUsT0FBTyxXQUFXLG9CQUFvQixPQUFPLEtBQUEsR0FBVyxrQkFBa0I7Q0FDNUUsQ0FBQztBQUNIO0FBQ0EsU0FBUyxxQkFBcUIsR0FBRztDQUMvQixPQUFPLElBQUksZUFBZSxJQUFJLGdCQUFnQixFQUFFLEdBQUcsR0FBRyxJQUFJLGdCQUFnQixFQUFFLE1BQU0sR0FBRyxJQUFJLGdCQUFnQixFQUFFLFdBQVcsR0FBRyxJQUFJLGdCQUFnQixFQUFFLFFBQVEsR0FBRyxJQUFJLGdCQUFnQixFQUFFLElBQUksR0FBRyxFQUFFLFFBQVEsRUFBRSxXQUFXLENBQUM7QUFDak47QUFDQSxJQUFNLGtCQUFOLE1BQXNCO0NBR3BCLFlBQVksWUFBWSwyQkFBMkI7d0JBRm5ELGNBQUEsS0FBQSxDQUFBO3dCQUNBLDZCQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssYUFBYTtFQUNsQixLQUFLLDRCQUE0QjtDQUNuQztBQUNGO0FBQ0EsSUFBTSw2QkFBNkI7QUFDbkMsU0FBUywyQkFBMkIsZUFBZSxVQUFVO0NBQzNELE1BQU0sRUFDSixZQUNBLDhCQUNFLFVBQVUsUUFBUSxJQUFJO0VBQ3hCLFlBQVk7RUFDWiwyQkFBMkIsS0FBQTtDQUM3QixJQUFJO0NBQ0osTUFBTSxRQUFRLHlCQUF5QixhQUFhLG1CQUFtQixjQUFjLFVBQVUsVUFBVSxFQUFFLElBQUksMkJBQTJCLFFBQVE7Q0FDbEosTUFBTSxNQUFNO0NBQ1osTUFBTSw0QkFBNEI7Q0FDbEMsT0FBTztBQUNUO0FBQ0EsU0FBUyx5QkFBeUIsU0FBUyxNQUFNO0NBQy9DLE1BQU0sd0JBQVEsSUFBSSxNQUFNLDZCQUE2QixXQUFXLElBQUk7Q0FDcEUsTUFBTSw4QkFBOEI7Q0FDcEMsTUFBTSxtQkFBbUI7Q0FDekIsT0FBTztBQUNUO0FBQ0EsU0FBUyxzQ0FBc0MsT0FBTztDQUNwRCxPQUFPLDJCQUEyQixLQUFLLEtBQUssVUFBVSxNQUFNLEdBQUc7QUFDakU7QUFDQSxTQUFTLDJCQUEyQixPQUFPO0NBQ3pDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsTUFBTTtBQUMxQjtBQUNBLElBQUkscUNBQXFDO0FBQ3pDLElBQU0saUJBQU4sTUFBcUI7Q0FNbkIsWUFBWSxvQkFBb0IsYUFBYSxXQUFXLGNBQWMscUJBQXFCO3dCQUwzRixzQkFBQSxLQUFBLENBQUE7d0JBQ0EsZUFBQSxLQUFBLENBQUE7d0JBQ0EsYUFBQSxLQUFBLENBQUE7d0JBQ0EsZ0JBQUEsS0FBQSxDQUFBO3dCQUNBLHVCQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUsscUJBQXFCO0VBQzFCLEtBQUssY0FBYztFQUNuQixLQUFLLFlBQVk7RUFDakIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssc0JBQXNCO0NBQzdCO0NBQ0EsU0FBUyxnQkFBZ0I7RUFDdkIsTUFBTSxhQUFhLEtBQUssWUFBWTtFQUNwQyxNQUFNLFdBQVcsS0FBSyxZQUFZLEtBQUssVUFBVSxRQUFRO0VBQ3pELEtBQUssc0JBQXNCLFlBQVksVUFBVSxjQUFjO0VBQy9ELHNCQUFzQixLQUFLLFlBQVksSUFBSTtFQUMzQyxLQUFLLG9CQUFvQixZQUFZLFVBQVUsY0FBYztDQUMvRDtDQUNBLHNCQUFzQixZQUFZLFVBQVUsVUFBVTtFQUNwRCxNQUFNLFdBQVcsa0JBQWtCLFFBQVE7RUFDM0MsV0FBVyxTQUFTLFNBQVEsZ0JBQWU7R0FDekMsTUFBTSxrQkFBa0IsWUFBWSxNQUFNO0dBQzFDLEtBQUssaUJBQWlCLGFBQWEsU0FBUyxrQkFBa0IsUUFBUTtHQUN0RSxPQUFPLFNBQVM7RUFDbEIsQ0FBQztFQUNELE9BQU8sT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFRLE1BQUs7R0FDbkMsS0FBSyw4QkFBOEIsR0FBRyxRQUFRO0VBQ2hELENBQUM7Q0FDSDtDQUNBLGlCQUFpQixZQUFZLFVBQVUsZUFBZTtFQUNwRCxNQUFNLFNBQVMsV0FBVztFQUMxQixNQUFNLE9BQU8sV0FBVyxTQUFTLFFBQVE7RUFDekMsSUFBSSxXQUFXLE1BQ2IsSUFBSSxPQUFPLFdBQVc7R0FDcEIsTUFBTSxVQUFVLGNBQWMsV0FBVyxPQUFPLE1BQU07R0FDdEQsSUFBSSxTQUNGLEtBQUssc0JBQXNCLFlBQVksVUFBVSxRQUFRLFFBQVE7RUFFckUsT0FDRSxLQUFLLHNCQUFzQixZQUFZLFVBQVUsYUFBYTtPQUdoRSxJQUFJLE1BQ0YsS0FBSyw4QkFBOEIsVUFBVSxhQUFhO0NBR2hFO0NBQ0EsOEJBQThCLE9BQU8sZ0JBQWdCO0VBQ25ELElBQUksTUFBTSxNQUFNLGFBQWEsS0FBSyxtQkFBbUIsYUFBYSxNQUFNLE1BQU0sUUFBUSxHQUNwRixLQUFLLDJCQUEyQixPQUFPLGNBQWM7T0FFckQsS0FBSyx5QkFBeUIsT0FBTyxjQUFjO0NBRXZEO0NBQ0EsMkJBQTJCLE9BQU8sZ0JBQWdCO0VBQ2hELE1BQU0sVUFBVSxlQUFlLFdBQVcsTUFBTSxNQUFNLE1BQU07RUFDNUQsTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFlBQVksUUFBUSxXQUFXO0VBQ3ZFLE1BQU0sV0FBVyxrQkFBa0IsS0FBSztFQUN4QyxLQUFLLE1BQU0sWUFBWSxPQUFPLE9BQU8sUUFBUSxHQUMzQyxLQUFLLDhCQUE4QixVQUFVLFFBQVE7RUFFdkQsSUFBSSxXQUFXLFFBQVEsUUFBUTtHQUM3QixNQUFNLGVBQWUsUUFBUSxPQUFPLE9BQU87R0FDM0MsTUFBTSxXQUFXLFFBQVEsU0FBUyxvQkFBb0I7R0FDdEQsS0FBSyxtQkFBbUIsTUFBTSxNQUFNLE1BQU0sVUFBVTtJQUNsRDtJQUNBO0lBQ0E7R0FDRixDQUFDO0VBQ0g7Q0FDRjtDQUNBLHlCQUF5QixPQUFPLGdCQUFnQjs7RUFDOUMsTUFBTSxVQUFVLGVBQWUsV0FBVyxNQUFNLE1BQU0sTUFBTTtFQUM1RCxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sWUFBWSxRQUFRLFdBQVc7RUFDdkUsTUFBTSxXQUFXLGtCQUFrQixLQUFLO0VBQ3hDLEtBQUssTUFBTSxZQUFZLE9BQU8sT0FBTyxRQUFRLEdBQzNDLEtBQUssOEJBQThCLFVBQVUsUUFBUTtFQUV2RCxJQUFJLFNBQVM7R0FDWCxJQUFJLFFBQVEsUUFBUTtJQUNsQixRQUFRLE9BQU8sV0FBVztJQUMxQixRQUFRLFNBQVMsb0JBQW9CO0dBQ3ZDO0dBQ0EsUUFBUSxZQUFZO0dBQ3BCLFFBQVEsUUFBUTtFQUNsQjtFQUNBLENBQUEsd0JBQUEsTUFBTSxNQUFNLG9CQUFBLFFBQUEsMEJBQUEsS0FBQSxLQUFBLHNCQUFnQixRQUFRO0NBQ3RDO0NBQ0Esb0JBQW9CLFlBQVksVUFBVSxVQUFVO0VBQ2xELE1BQU0sV0FBVyxrQkFBa0IsUUFBUTtFQUMzQyxXQUFXLFNBQVMsU0FBUSxNQUFLO0dBQy9CLEtBQUssZUFBZSxHQUFHLFNBQVMsRUFBRSxNQUFNLFNBQVMsUUFBUTtHQUN6RCxLQUFLLGFBQWEsSUFBSSxjQUFjLEVBQUUsTUFBTSxRQUFRLENBQUM7RUFDdkQsQ0FBQztFQUNELElBQUksV0FBVyxTQUFTLFFBQ3RCLEtBQUssYUFBYSxJQUFJLG1CQUFtQixXQUFXLE1BQU0sUUFBUSxDQUFDO0NBRXZFO0NBQ0EsZUFBZSxZQUFZLFVBQVUsZ0JBQWdCO0VBQ25ELE1BQU0sU0FBUyxXQUFXO0VBQzFCLE1BQU0sT0FBTyxXQUFXLFNBQVMsUUFBUTtFQUN6QyxzQkFBc0IsTUFBTTtFQUM1QixJQUFJLFdBQVcsTUFDYixJQUFJLE9BQU8sV0FBVztHQUNwQixNQUFNLFVBQVUsZUFBZSxtQkFBbUIsT0FBTyxNQUFNO0dBQy9ELEtBQUssb0JBQW9CLFlBQVksVUFBVSxRQUFRLFFBQVE7RUFDakUsT0FDRSxLQUFLLG9CQUFvQixZQUFZLFVBQVUsY0FBYztPQUcvRCxJQUFJLE9BQU8sV0FBVztHQUNwQixNQUFNLFVBQVUsZUFBZSxtQkFBbUIsT0FBTyxNQUFNO0dBQy9ELElBQUksS0FBSyxtQkFBbUIsYUFBYSxPQUFPLFFBQVEsR0FBRztJQUN6RCxNQUFNLFNBQVMsS0FBSyxtQkFBbUIsU0FBUyxPQUFPLFFBQVE7SUFDL0QsS0FBSyxtQkFBbUIsTUFBTSxPQUFPLFVBQVUsSUFBSTtJQUNuRCxRQUFRLFNBQVMsbUJBQW1CLE9BQU8sUUFBUTtJQUNuRCxRQUFRLFlBQVksT0FBTztJQUMzQixRQUFRLFFBQVEsT0FBTyxNQUFNO0lBQzdCLElBQUksUUFBUSxRQUNWLFFBQVEsT0FBTyxPQUFPLE9BQU8sY0FBYyxPQUFPLE1BQU0sS0FBSztJQUUvRCxzQkFBc0IsT0FBTyxNQUFNLEtBQUs7SUFDeEMsS0FBSyxvQkFBb0IsWUFBWSxNQUFNLFFBQVEsUUFBUTtHQUM3RCxPQUFPO0lBQ0wsUUFBUSxZQUFZO0lBQ3BCLFFBQVEsUUFBUTtJQUNoQixJQUFJLFFBQVEsUUFDVixRQUFRLE9BQU8sYUFBYSxRQUFRLFFBQVEsUUFBUTtJQUV0RCxLQUFLLG9CQUFvQixZQUFZLE1BQU0sUUFBUSxRQUFRO0dBQzdEO0VBQ0YsT0FDRSxLQUFLLG9CQUFvQixZQUFZLE1BQU0sY0FBYztFQUc3RCxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQVc7R0FFakQsTUFBTSxTQURVLGVBQWUsbUJBQW1CLE9BQU8sTUFDcEMsQ0FBQyxDQUFDO0dBQ3ZCLElBQUksVUFBVSxLQUFLLHVCQUF1QixDQUFDLE9BQU8sb0NBQW9DLENBQUMsb0NBQW9DO0lBQ3pILFFBQVEsS0FBSywwSUFBK0k7SUFDNUoscUNBQXFDO0dBQ3ZDO0VBQ0Y7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxjQUFOLE1BQWtCO0NBR2hCLFlBQVksTUFBTTt3QkFGbEIsUUFBQSxLQUFBLENBQUE7d0JBQ0EsU0FBQSxLQUFBLENBQUE7RUFFRSxLQUFLLE9BQU87RUFDWixLQUFLLFFBQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxTQUFTO0NBQzVDO0FBQ0Y7QUFDQSxJQUFNLGdCQUFOLE1BQW9CO0NBR2xCLFlBQVksV0FBVyxPQUFPO3dCQUY5QixhQUFBLEtBQUEsQ0FBQTt3QkFDQSxTQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssWUFBWTtFQUNqQixLQUFLLFFBQVE7Q0FDZjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxNQUFNLGdCQUFnQjtDQUN2RCxNQUFNLGFBQWEsT0FBTztDQUUxQixPQUFPLG9CQUFvQixZQURWLE9BQU8sS0FBSyxRQUFRLE1BQ1ksZ0JBQWdCLENBQUMsV0FBVyxLQUFLLENBQUM7QUFDckY7QUFDQSxTQUFTLG9CQUFvQixHQUFHO0NBQzlCLE1BQU0sbUJBQW1CLEVBQUUsY0FBYyxFQUFFLFlBQVksbUJBQW1CO0NBQzFFLElBQUksQ0FBQyxvQkFBb0IsaUJBQWlCLFdBQVcsR0FBRyxPQUFPO0NBQy9ELE9BQU87RUFDTCxNQUFNO0VBQ04sUUFBUTtDQUNWO0FBQ0Y7QUFDQSxTQUFTLDJCQUEyQixpQkFBaUIsVUFBVTtDQUM3RCxNQUFNLFlBQVksT0FBTztDQUN6QixNQUFNLFNBQVMsU0FBUyxJQUFJLGlCQUFpQixTQUFTO0NBQ3RELElBQUksV0FBVyxXQUNiLElBQUksT0FBTyxvQkFBb0IsY0FBYyxDQUFDUyxhQUFjLGVBQWUsR0FDekUsT0FBTztNQUVQLE9BQU8sU0FBUyxJQUFJLGVBQWU7Q0FHdkMsT0FBTztBQUNUO0FBQ0EsU0FBUyxvQkFBb0IsWUFBWSxVQUFVLFVBQVUsWUFBWSxTQUFTO0NBQ2hGLHFCQUFxQixDQUFDO0NBQ3RCLG1CQUFtQixDQUFDO0FBQ3RCLEdBQUc7Q0FDRCxNQUFNLGVBQWUsa0JBQWtCLFFBQVE7Q0FDL0MsV0FBVyxTQUFTLFNBQVEsTUFBSztFQUMvQixlQUFlLEdBQUcsYUFBYSxFQUFFLE1BQU0sU0FBUyxVQUFVLFdBQVcsT0FBTyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTTtFQUM5RixPQUFPLGFBQWEsRUFBRSxNQUFNO0NBQzlCLENBQUM7Q0FDRCxPQUFPLFFBQVEsWUFBWSxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsT0FBTyw4QkFBOEIsR0FBRyxTQUFTLFdBQVcsQ0FBQyxHQUFHLE1BQU0sQ0FBQztDQUNqSCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsWUFBWSxVQUFVLGdCQUFnQixZQUFZLFNBQVM7Q0FDakYscUJBQXFCLENBQUM7Q0FDdEIsbUJBQW1CLENBQUM7QUFDdEIsR0FBRztDQUNELE1BQU0sU0FBUyxXQUFXO0NBQzFCLE1BQU0sT0FBTyxXQUFXLFNBQVMsUUFBUTtDQUN6QyxNQUFNLFVBQVUsaUJBQWlCLGVBQWUsV0FBVyxXQUFXLE1BQU0sTUFBTSxJQUFJO0NBQ3RGLElBQUksUUFBUSxPQUFPLGdCQUFnQixLQUFLLGFBQWE7RUFDbkQsTUFBTSxZQUFZLDRCQUE0QixNQUFNLFFBQVEsT0FBTyxZQUFZLHFCQUFxQjtFQUNwRyxJQUFJLFdBQ0YsT0FBTyxrQkFBa0IsS0FBSyxJQUFJLFlBQVksVUFBVSxDQUFDO09BQ3BEO0dBQ0wsT0FBTyxPQUFPLEtBQUs7R0FDbkIsT0FBTyxnQkFBZ0IsS0FBSztFQUM5QjtFQUNBLElBQUksT0FBTyxXQUNULG9CQUFvQixZQUFZLFVBQVUsVUFBVSxRQUFRLFdBQVcsTUFBTSxZQUFZLE1BQU07T0FFL0Ysb0JBQW9CLFlBQVksVUFBVSxnQkFBZ0IsWUFBWSxNQUFNO0VBRTlFLElBQUksYUFBYSxXQUFXLFFBQVEsVUFBVSxRQUFRLE9BQU8sYUFDM0QsT0FBTyxvQkFBb0IsS0FBSyxJQUFJLGNBQWMsUUFBUSxPQUFPLFdBQVcsSUFBSSxDQUFDO0NBRXJGLE9BQU87RUFDTCxJQUFJLE1BQ0YsOEJBQThCLFVBQVUsU0FBUyxNQUFNO0VBRXpELE9BQU8sa0JBQWtCLEtBQUssSUFBSSxZQUFZLFVBQVUsQ0FBQztFQUN6RCxJQUFJLE9BQU8sV0FDVCxvQkFBb0IsWUFBWSxNQUFNLFVBQVUsUUFBUSxXQUFXLE1BQU0sWUFBWSxNQUFNO09BRTNGLG9CQUFvQixZQUFZLE1BQU0sZ0JBQWdCLFlBQVksTUFBTTtDQUU1RTtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsNEJBQTRCLE1BQU0sUUFBUSxNQUFNO0NBQ3ZELElBQUksT0FBTyxTQUFTLFlBQ2xCLE9BQU8sc0JBQXNCLE9BQU8sNEJBQTRCLEtBQUssTUFBTSxNQUFNLENBQUM7Q0FFcEYsUUFBUSxNQUFSO0VBQ0UsS0FBSyxvQkFDSCxPQUFPLENBQUMsVUFBVSxLQUFLLEtBQUssT0FBTyxHQUFHO0VBQ3hDLEtBQUssaUNBQ0gsT0FBTyxDQUFDLFVBQVUsS0FBSyxLQUFLLE9BQU8sR0FBRyxLQUFLLENBQUMsYUFBYSxLQUFLLGFBQWEsT0FBTyxXQUFXO0VBQy9GLEtBQUssVUFDSCxPQUFPO0VBQ1QsS0FBSyw2QkFDSCxPQUFPLENBQUMsMEJBQTBCLE1BQU0sTUFBTSxLQUFLLENBQUMsYUFBYSxLQUFLLGFBQWEsT0FBTyxXQUFXO0VBRXZHLFNBQ0UsT0FBTyxDQUFDLDBCQUEwQixNQUFNLE1BQU07Q0FDbEQ7QUFDRjtBQUNBLFNBQVMsOEJBQThCLE9BQU8sU0FBUyxRQUFRO0NBQzdELE1BQU0sV0FBVyxrQkFBa0IsS0FBSztDQUN4QyxNQUFNLElBQUksTUFBTTtDQUNoQixPQUFPLFFBQVEsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLFdBQVcsVUFBVTtFQUN0RCxJQUFJLENBQUMsRUFBRSxXQUNMLDhCQUE4QixNQUFNLFNBQVMsTUFBTTtPQUM5QyxJQUFJLFNBQ1QsOEJBQThCLE1BQU0sUUFBUSxTQUFTLFdBQVcsU0FBUyxHQUFHLE1BQU07T0FFbEYsOEJBQThCLE1BQU0sTUFBTSxNQUFNO0NBRXBELENBQUM7Q0FDRCxJQUFJLENBQUMsRUFBRSxXQUNMLE9BQU8sb0JBQW9CLEtBQUssSUFBSSxjQUFjLE1BQU0sQ0FBQyxDQUFDO01BQ3JELElBQUksV0FBVyxRQUFRLFVBQVUsUUFBUSxPQUFPLGFBQ3JELE9BQU8sb0JBQW9CLEtBQUssSUFBSSxjQUFjLFFBQVEsT0FBTyxXQUFXLENBQUMsQ0FBQztNQUU5RSxPQUFPLG9CQUFvQixLQUFLLElBQUksY0FBYyxNQUFNLENBQUMsQ0FBQztBQUU5RDtBQUNBLFNBQVMsV0FBVyxHQUFHO0NBQ3JCLE9BQU8sT0FBTyxNQUFNO0FBQ3RCO0FBQ0EsU0FBUyxVQUFVLEdBQUc7Q0FDcEIsT0FBTyxPQUFPLE1BQU07QUFDdEI7QUFDQSxTQUFTLFVBQVUsT0FBTztDQUN4QixPQUFPLFNBQVMsV0FBVyxNQUFNLE9BQU87QUFDMUM7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUM1QixPQUFPLFNBQVMsV0FBVyxNQUFNLFdBQVc7QUFDOUM7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2pDLE9BQU8sU0FBUyxXQUFXLE1BQU0sZ0JBQWdCO0FBQ25EO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixPQUFPLFNBQVMsV0FBVyxNQUFNLGFBQWE7QUFDaEQ7QUFDQSxTQUFTLFdBQVcsT0FBTztDQUN6QixPQUFPLFNBQVMsV0FBVyxNQUFNLFFBQVE7QUFDM0M7QUFDQSxTQUFTLGFBQWEsR0FBRztDQUN2QixPQUFPLGFBQWEsZUFBQSxNQUFBLFFBQUEsTUFBQSxLQUFBLElBQUEsS0FBQSxJQUFjLEVBQUcsVUFBUztBQUNoRDtBQUNBLElBQU0sZ0JBQStCLHVCQUFPLGVBQWU7QUFDM0QsU0FBUyx3QkFBd0I7Q0FDL0IsT0FBTyxXQUFVLFFBQU87RUFDdEIsT0FBTyxjQUFjLElBQUksS0FBSSxNQUFLLEVBQUUsS0FBSyxLQUFLLENBQUMsR0FBRyxVQUFVLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSSxZQUFXO0dBQ2hHLEtBQUssTUFBTSxVQUFVLFNBQ25CLElBQUksV0FBVyxNQUNiO1FBQ0ssSUFBSSxXQUFXLGVBQ3BCLE9BQU87UUFDRixJQUFJLFdBQVcsU0FBUyxXQUFXLE1BQU0sR0FDOUMsT0FBTztHQUdYLE9BQU87RUFDVCxDQUFDLEdBQUcsUUFBTyxTQUFRLFNBQVMsYUFBYSxHQUFHLEtBQUssQ0FBQyxDQUFDO0NBQ3JELENBQUM7QUFDSDtBQUNBLFNBQVMsV0FBVyxLQUFLO0NBQ3ZCLE9BQU8sVUFBVSxHQUFHLEtBQUssZUFBZTtBQUMxQztBQUNBLFNBQVMsd0JBQXdCLFFBQVE7Q0FDdkMsSUFBSSxPQUFPLFNBQ1QsT0FBTyxHQUFHLEtBQUEsQ0FBUyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsQ0FBQztDQUVuQyxPQUFPLElBQUksWUFBVyxlQUFjO0VBQ2xDLE1BQU0sZ0JBQWdCO0dBQ3BCLFdBQVcsS0FBSztHQUNoQixXQUFXLFNBQVM7RUFDdEI7RUFDQSxPQUFPLGlCQUFpQixTQUFTLE9BQU87RUFDeEMsYUFBYSxPQUFPLG9CQUFvQixTQUFTLE9BQU87Q0FDMUQsQ0FBQztBQUNIO0FBQ0EsU0FBUyxlQUFlLFFBQVE7Q0FDOUIsT0FBTyxVQUFVLHdCQUF3QixNQUFNLENBQUM7QUFDbEQ7QUFDQSxTQUFTLFlBQVksY0FBYztDQUNqQyxPQUFPLFVBQVMsTUFBSztFQUNuQixNQUFNLEVBQ0osZ0JBQ0EsaUJBQ0EsUUFBUSxFQUNOLG1CQUNBLDBCQUVBO0VBQ0osSUFBSSxvQkFBb0IsV0FBVyxLQUFLLGtCQUFrQixXQUFXLEdBQ25FLE9BQU8sR0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNGLENBQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCxjQUFjLEtBQUEsQ0FDaEIsQ0FBQztFQUVILE9BQU8sdUJBQXVCLHFCQUFxQixnQkFBZ0IsZUFBZSxDQUFDLENBQUMsS0FBSyxVQUFTLGtCQUFpQjtHQUNqSCxPQUFPLGlCQUFpQixVQUFVLGFBQWEsSUFBSSxxQkFBcUIsZ0JBQWdCLG1CQUFtQixZQUFZLElBQUksR0FBRyxhQUFhO0VBQzdJLENBQUMsR0FBRyxLQUFJLGlCQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0gsQ0FBQSxHQUFBLENBQUEsR0FBQSxFQUNILGFBQUEsQ0FDRixDQUFFLENBQUM7Q0FDTCxDQUFDO0FBQ0g7QUFDQSxTQUFTLHVCQUF1QixRQUFRLFdBQVcsU0FBUztDQUMxRCxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxVQUFTLFVBQVMsaUJBQWlCLE1BQU0sV0FBVyxNQUFNLE9BQU8sU0FBUyxTQUFTLENBQUMsR0FBRyxPQUFNLFdBQVU7RUFDOUgsT0FBTyxXQUFXO0NBQ3BCLEdBQUcsSUFBSSxDQUFDO0FBQ1Y7QUFDQSxTQUFTLHFCQUFxQixnQkFBZ0IsUUFBUSxjQUFjO0NBQ2xFLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFdBQVUsVUFBUztFQUMxQyxPQUFPLE9BQU8seUJBQXlCLE1BQU0sTUFBTSxRQUFRLFlBQVksR0FBRyxvQkFBb0IsTUFBTSxPQUFPLFlBQVksR0FBRyxvQkFBb0IsZ0JBQWdCLE1BQU0sSUFBSSxHQUFHLGVBQWUsZ0JBQWdCLE1BQU0sS0FBSyxDQUFDO0NBQ3hOLENBQUMsR0FBRyxPQUFNLFdBQVU7RUFDbEIsT0FBTyxXQUFXO0NBQ3BCLEdBQUcsSUFBSSxDQUFDO0FBQ1Y7QUFDQSxTQUFTLG9CQUFvQixVQUFVLGNBQWM7Q0FDbkQsSUFBSSxhQUFhLFFBQVEsY0FDdkIsYUFBYSxJQUFJLGdCQUFnQixRQUFRLENBQUM7Q0FFNUMsT0FBTyxHQUFHLElBQUk7QUFDaEI7QUFDQSxTQUFTLHlCQUF5QixVQUFVLGNBQWM7Q0FDeEQsSUFBSSxhQUFhLFFBQVEsY0FDdkIsYUFBYSxJQUFJLHFCQUFxQixRQUFRLENBQUM7Q0FFakQsT0FBTyxHQUFHLElBQUk7QUFDaEI7QUFDQSxTQUFTLGVBQWUsV0FBVyxXQUFXO0NBQzVDLE1BQU0sY0FBYyxVQUFVLGNBQWMsVUFBVSxZQUFZLGNBQWM7Q0FDaEYsSUFBSSxDQUFDLGVBQWUsWUFBWSxXQUFXLEdBQUcsT0FBTyxHQUFHLElBQUk7Q0FTNUQsT0FBTyxHQVJ3QixZQUFZLEtBQUksZ0JBQWU7RUFDNUQsT0FBTyxZQUFZO0dBQ2pCLE1BQU0sa0JBQWtCLFVBQVU7R0FDbEMsTUFBTSxRQUFRLDJCQUEyQixhQUFhLGVBQWU7R0FFckUsT0FBTyxtQkFEVSxjQUFjLEtBQUssSUFBSSxNQUFNLFlBQVksV0FBVyxTQUFTLElBQUksc0JBQXNCLHVCQUF1QixNQUFNLFdBQVcsU0FBUyxDQUFDLENBQ3hILENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQztFQUNsRCxDQUFDO0NBQ0gsQ0FDK0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxzQkFBc0IsQ0FBQztBQUNoRTtBQUNBLFNBQVMsb0JBQW9CLFdBQVcsTUFBTTtDQUM1QyxNQUFNLFlBQVksS0FBSyxLQUFLLFNBQVM7Q0FhckMsT0FBTyxHQVp3QixLQUFLLE1BQU0sR0FBRyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSSxNQUFLLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQU8sTUFBSyxNQUFNLElBQ2pFLENBQUMsQ0FBQyxLQUFJLE1BQUs7RUFDbkUsT0FBTyxZQUFZO0dBT2pCLE9BQU8sR0FOYyxFQUFFLE9BQU8sS0FBSSxxQkFBb0I7SUFDcEQsTUFBTSxrQkFBa0IsRUFBRSxLQUFLO0lBQy9CLE1BQU0sUUFBUSwyQkFBMkIsa0JBQWtCLGVBQWU7SUFFMUUsT0FBTyxtQkFEVSxtQkFBbUIsS0FBSyxJQUFJLE1BQU0saUJBQWlCLFdBQVcsU0FBUyxJQUFJLHNCQUFzQix1QkFBdUIsTUFBTSxXQUFXLFNBQVMsQ0FBQyxDQUNsSSxDQUFDLENBQUMsS0FBSyxNQUFNLENBQUM7R0FDbEQsQ0FDcUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxzQkFBc0IsQ0FBQztFQUN0RCxDQUFDO0NBQ0gsQ0FDcUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxzQkFBc0IsQ0FBQztBQUN0RTtBQUNBLFNBQVMsaUJBQWlCLFdBQVcsU0FBUyxTQUFTLFdBQVc7Q0FDaEUsTUFBTSxnQkFBZ0IsV0FBVyxRQUFRLGNBQWMsUUFBUSxZQUFZLGdCQUFnQjtDQUMzRixJQUFJLENBQUMsaUJBQWlCLGNBQWMsV0FBVyxHQUFHLE9BQU8sR0FBRyxJQUFJO0NBT2hFLE9BQU8sR0FOMEIsY0FBYyxLQUFJLE1BQUs7RUFDdEQsTUFBTSxrQkFBa0IsUUFBUTtFQUNoQyxNQUFNLFFBQVEsMkJBQTJCLEdBQUcsZUFBZTtFQUUzRCxPQUFPLG1CQURVLGdCQUFnQixLQUFLLElBQUksTUFBTSxjQUFjLFdBQVcsU0FBUyxTQUFTLFNBQVMsSUFBSSxzQkFBc0IsdUJBQXVCLE1BQU0sV0FBVyxTQUFTLFNBQVMsU0FBUyxDQUFDLENBQ2hLLENBQUMsQ0FBQyxLQUFLLE1BQU0sQ0FBQztDQUNsRCxDQUNpQyxDQUFDLENBQUMsQ0FBQyxLQUFLLHNCQUFzQixDQUFDO0FBQ2xFO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVSxPQUFPLFVBQVUsZUFBZSxhQUFhO0NBQy9FLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLElBQUksWUFBWSxLQUFBLEtBQWEsUUFBUSxXQUFXLEdBQzlDLE9BQU8sR0FBRyxJQUFJO0NBUWhCLE9BQU8sR0FOb0IsUUFBUSxLQUFJLG1CQUFrQjtFQUN2RCxNQUFNLFFBQVEsMkJBQTJCLGdCQUFnQixRQUFRO0VBRWpFLE1BQU0sT0FBTyxtQkFESSxVQUFVLEtBQUssSUFBSSxNQUFNLFFBQVEsT0FBTyxRQUFRLElBQUksc0JBQXNCLGdCQUFnQixNQUFNLE9BQU8sUUFBUSxDQUFDLENBQ3pGO0VBQ3hDLE9BQU8sY0FBYyxLQUFLLEtBQUssZUFBZSxXQUFXLENBQUMsSUFBSTtDQUNoRSxDQUMyQixDQUFDLENBQUMsQ0FBQyxLQUFLLHNCQUFzQixHQUFHLGtCQUFrQixhQUFhLENBQUM7QUFDOUY7QUFDQSxTQUFTLGtCQUFrQixlQUFlO0NBQ3hDLE9BQU8sS0FBSyxLQUFJLFdBQVU7RUFDeEIsSUFBSSxPQUFPLFdBQVcsV0FBVztFQUNqQyxNQUFNLDJCQUEyQixlQUFlLE1BQU07Q0FDeEQsQ0FBQyxHQUFHLEtBQUksV0FBVSxXQUFXLElBQUksQ0FBQztBQUNwQztBQUNBLFNBQVMsa0JBQWtCLFVBQVUsT0FBTyxVQUFVLGVBQWUsaUJBQWlCLGFBQWE7Q0FDakcsTUFBTSxXQUFXLE1BQU07Q0FDdkIsSUFBSSxDQUFDLFlBQVksU0FBUyxXQUFXLEdBQUcsT0FBTyxHQUFHLElBQUk7Q0FNdEQsT0FBTyxHQUxxQixTQUFTLEtBQUksbUJBQWtCO0VBQ3pELE1BQU0sUUFBUSwyQkFBMkIsZ0JBQWdCLFFBQVE7RUFFakUsT0FBTyxtQkFEVSxXQUFXLEtBQUssSUFBSSxNQUFNLFNBQVMsT0FBTyxVQUFVLGVBQWUsSUFBSSxzQkFBc0IsZ0JBQWdCLE1BQU0sT0FBTyxVQUFVLGVBQWUsQ0FBQyxDQUNuSSxDQUFDLENBQUMsS0FBSyxlQUFlLFdBQVcsQ0FBQztDQUN0RSxDQUM0QixDQUFDLENBQUMsQ0FBQyxLQUFLLHNCQUFzQixHQUFHLGtCQUFrQixhQUFhLENBQUM7QUFDL0Y7QUFDQSxJQUFNLFVBQU4sTUFBTSxnQkFBZ0IsTUFBTTtDQUUxQixZQUFZLGNBQWM7RUFDeEIsTUFBTTt3QkFGUixnQkFBQSxLQUFBLENBQUE7RUFHRSxLQUFLLGVBQWUsZ0JBQWdCO0VBQ3BDLE9BQU8sZUFBZSxNQUFNLFFBQVEsU0FBUztDQUMvQztBQUNGO0FBQ0EsSUFBTSxtQkFBTixNQUFNLHlCQUF5QixNQUFNO0NBRW5DLFlBQVksU0FBUztFQUNuQixNQUFNO3dCQUZSLFdBQUEsS0FBQSxDQUFBO0VBR0UsS0FBSyxVQUFVO0VBQ2YsT0FBTyxlQUFlLE1BQU0saUJBQWlCLFNBQVM7Q0FDeEQ7QUFDRjtBQUNBLFNBQVMscUJBQXFCLFlBQVk7Q0FDeEMsTUFBTSxJQUFJWCxhQUFjLE1BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyxnRUFBZ0UsV0FBVyxFQUFFO0FBQ2hLO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDM0IsTUFBTSwwQkFBMEIsT0FBTyxjQUFjLGVBQWUsY0FBYywrREFBK0QsTUFBTSxLQUFLLG9CQUFvQiwyQkFBMkIsYUFBYTtBQUMxTjtBQUNBLElBQU0saUJBQU4sTUFBcUI7Q0FHbkIsWUFBWSxlQUFlLFNBQVM7d0JBRnBDLGlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxXQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssVUFBVTtDQUNqQjtDQUNBLG1CQUF5QixPQUFPLFNBQUE7d0NBQVM7R0FDdkMsSUFBSSxNQUFNLENBQUM7R0FDWCxJQUFJLElBQUksUUFBUTtHQUNoQixPQUFPLE1BQU07SUFDWCxNQUFNLElBQUksT0FBTyxFQUFFLFFBQVE7SUFDM0IsSUFBSSxFQUFFLHFCQUFxQixHQUN6QixPQUFPO0lBRVQsSUFBSSxFQUFFLG1CQUFtQixLQUFLLENBQUMsRUFBRSxTQUFBLFlBQy9CLE1BQU0scUJBQXFCLEdBQUcsTUFBTSxZQUFZO0lBRWxELElBQUksRUFBRSxTQUFTO0dBQ2pCO0VBQ0YsQ0FBQSxDQUFBLENBQUE7O0NBQ0Esc0JBQTRCLFVBQVUsWUFBWSxXQUFXLGlCQUFpQixVQUFBOzt3Q0FBVTtHQUN0RixNQUFNLFdBQVcsTUFBTSxrQkFBa0IsWUFBWSxpQkFBaUIsUUFBUTtHQUM5RSxJQUFJLG9CQUFvQixTQUN0QixNQUFNLElBQUksaUJBQWlCLFFBQVE7R0FFckMsTUFBTSxVQUFVWSxNQUFLLDJCQUEyQixVQUFVQSxNQUFLLGNBQWMsTUFBTSxRQUFRLEdBQUcsVUFBVSxTQUFTO0dBQ2pILElBQUksU0FBUyxPQUFPLEtBQ2xCLE1BQU0sSUFBSSxpQkFBaUIsT0FBTztHQUVwQyxPQUFPO0VBQ1QsQ0FBQSxDQUFBLENBQUE7O0NBQ0EsMkJBQTJCLFlBQVksU0FBUyxVQUFVLFdBQVc7RUFFbkUsT0FBTyxJQUFJLFFBREssS0FBSyxtQkFBbUIsWUFBWSxRQUFRLE1BQU0sVUFBVSxTQUN6RCxHQUFTLEtBQUssa0JBQWtCLFFBQVEsYUFBYSxLQUFLLFFBQVEsV0FBVyxHQUFHLFFBQVEsUUFBUTtDQUNySDtDQUNBLGtCQUFrQixrQkFBa0IsY0FBYztFQUNoRCxNQUFNLE1BQU0sQ0FBQztFQUNiLE9BQU8sUUFBUSxnQkFBZ0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLE9BQU87R0FFbkQsSUFEd0IsT0FBTyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQ3JDO0lBQ25CLE1BQU0sYUFBYSxFQUFFLFVBQVUsQ0FBQztJQUNoQyxJQUFJLEtBQUssYUFBYTtHQUN4QixPQUNFLElBQUksS0FBSztFQUViLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxtQkFBbUIsWUFBWSxPQUFPLFVBQVUsV0FBVztFQUN6RCxNQUFNLGtCQUFrQixLQUFLLGVBQWUsWUFBWSxNQUFNLFVBQVUsVUFBVSxTQUFTO0VBQzNGLElBQUksV0FBVyxPQUFPLE9BQU8sSUFBSTtFQUNqQyxPQUFPLFFBQVEsTUFBTSxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxXQUFXO0dBQ3hELFNBQVMsUUFBUSxLQUFLLG1CQUFtQixZQUFZLE9BQU8sVUFBVSxTQUFTO0VBQ2pGLENBQUM7RUFDRCxPQUFPLElBQUksZ0JBQWdCLGlCQUFpQixRQUFRO0NBQ3REO0NBQ0EsZUFBZSxZQUFZLG9CQUFvQixnQkFBZ0IsV0FBVztFQUN4RSxPQUFPLG1CQUFtQixLQUFJLE1BQUssRUFBRSxLQUFLLE9BQU8sTUFBTSxLQUFLLGFBQWEsWUFBWSxHQUFHLFNBQVMsSUFBSSxLQUFLLGFBQWEsR0FBRyxjQUFjLENBQUM7Q0FDM0k7Q0FDQSxhQUFhLFlBQVksc0JBQXNCLFdBQVc7RUFDeEQsTUFBTSxNQUFNLFVBQVUscUJBQXFCLEtBQUssVUFBVSxDQUFDO0VBQzNELElBQUksQ0FBQyxLQUFLLE1BQU0sSUFBSVosYUFBYyxPQUFPLE9BQU8sY0FBYyxlQUFlLGNBQWMsdUJBQXVCLFdBQVcsa0JBQWtCLHFCQUFxQixLQUFLLEdBQUc7RUFDNUssT0FBTztDQUNUO0NBQ0EsYUFBYSxzQkFBc0IsZ0JBQWdCO0VBQ2pELElBQUksTUFBTTtFQUNWLEtBQUssTUFBTSxLQUFLLGdCQUFnQjtHQUM5QixJQUFJLEVBQUUsU0FBUyxxQkFBcUIsTUFBTTtJQUN4QyxlQUFlLE9BQU8sR0FBRztJQUN6QixPQUFPO0dBQ1Q7R0FDQTtFQUNGO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixZQUFZLGlCQUFpQixVQUFVO0NBQ2hFLElBQUksT0FBTyxlQUFlLFVBQ3hCLE9BQU8sUUFBUSxRQUFRLFVBQVU7Q0FFbkMsTUFBTSxlQUFlO0NBQ3JCLE9BQU8sZUFBZSxtQkFBbUIsc0JBQXNCLGdCQUFnQixhQUFhLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDaEg7QUFDQSxTQUFTLGlDQUFpQyxPQUFPLGlCQUFpQjs7Q0FDaEUsSUFBSSxNQUFNLGFBQWEsQ0FBQyxNQUFNLFdBQzVCLE1BQU0sWUFBWSwwQkFBMEIsTUFBTSxXQUFXLGlCQUFpQixVQUFVLE1BQU0sTUFBTTtDQUV0RyxRQUFBLG1CQUFPLE1BQU0sZUFBQSxRQUFBLHFCQUFBLEtBQUEsSUFBQSxtQkFBYTtBQUM1QjtBQUNBLFNBQVMsZUFBZSxRQUFRLGFBQWEsSUFBSSw4QkFBOEIsT0FBTztDQUNwRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7RUFDdEMsTUFBTSxRQUFRLE9BQU87RUFFckIsYUFBYSxPQURJLFlBQVksWUFBWSxLQUNkLEdBQUcsMkJBQTJCO0NBQzNEO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixVQUFVLFdBQVc7Q0FDN0MsSUFBSSxhQUFhYSxXQUFZLFNBQVMsR0FDcEMsTUFBTSxJQUFJYixhQUFjLE1BQU0sbUNBQW1DLFNBQVMsNEhBQWlJO01BQ3RNLElBQUksYUFBYSxDQUFDLGFBQWEsU0FBUyxHQUM3QyxNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyxxQ0FBcUM7QUFFbkg7QUFDQSxTQUFTLGFBQWEsT0FBTyxVQUFVLDZCQUE2QjtDQUNsRSxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQVc7RUFDakQsSUFBSSxDQUFDLE9BQ0gsTUFBTSxJQUFJQSxhQUFjLE1BQU07d0NBQ0ksU0FBUzs7Ozs7Ozs7O0tBUzVDO0VBRUQsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUNyQixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyw2QkFBNkI7RUFFekcsSUFBSSxDQUFDLE1BQU0sY0FBYyxDQUFDLE1BQU0sYUFBYSxDQUFDLE1BQU0saUJBQWlCLENBQUMsTUFBTSxZQUFZLENBQUMsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVLE1BQU0sV0FBQSxXQUNuSSxNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyx5RkFBeUY7RUFFckssSUFBSSxNQUFNLGNBQWMsTUFBTSxVQUM1QixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyxtREFBbUQ7RUFFL0gsSUFBSSxNQUFNLGNBQWMsTUFBTSxjQUM1QixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyx1REFBdUQ7RUFFbkksSUFBSSxNQUFNLFlBQVksTUFBTSxjQUMxQixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyxxREFBcUQ7RUFFakksSUFBSSxNQUFNLGFBQWEsTUFBTSxlQUMzQixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyx1REFBdUQ7RUFFbkksSUFBSSxNQUFNLFlBQVk7R0FDcEIsSUFBSSxNQUFNLGFBQWEsTUFBTSxlQUMzQixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyxrRUFBa0U7R0FFOUksSUFBSSxNQUFNLFlBQVksTUFBTSxhQUMxQixNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyxvQkFBb0IsTUFBTSxXQUFXLGFBQWEsY0FBYyxzRUFBMkU7RUFFek47RUFDQSxJQUFJLE1BQU0sUUFBUSxNQUFNLFNBQ3RCLE1BQU0sSUFBSUEsYUFBYyxNQUFNLG1DQUFtQyxTQUFTLDRDQUE0QztFQUV4SCxJQUFJLE1BQU0sZUFBZSxLQUFLLEtBQUssQ0FBQyxNQUFNLGFBQWEsQ0FBQyxNQUFNLGlCQUFpQixDQUFDLE1BQU0sWUFBWSxDQUFDLE1BQU0sY0FDdkcsTUFBTSxJQUFJQSxhQUFjLE1BQU0sbUNBQW1DLFNBQVMseUdBQXlHO0VBRXJMLElBQUksTUFBTSxTQUFTLEtBQUssS0FBSyxNQUFNLFlBQVksS0FBSyxHQUNsRCxNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyx5REFBeUQ7RUFFckksSUFBSSxPQUFPLE1BQU0sU0FBUyxZQUFZLE1BQU0sS0FBSyxPQUFPLENBQUMsTUFBTSxLQUM3RCxNQUFNLElBQUlBLGFBQWMsTUFBTSxtQ0FBbUMsU0FBUyxrQ0FBa0M7RUFFOUcsSUFBSSxNQUFNLFNBQVMsTUFBTSxNQUFNLGVBQWUsS0FBSyxLQUFLLE1BQU0sY0FBYyxLQUFLLEdBRS9FLE1BQU0sSUFBSUEsYUFBYyxNQUFNLDJDQUEyQyxTQUFTLGtCQUFrQixNQUFNLFdBQVcsc0hBQXdDO0VBRS9KLElBQUksNkJBQ0YsaUJBQWlCLFVBQVUsTUFBTSxTQUFTO0NBRTlDO0NBQ0EsSUFBSSxNQUFNLFVBQ1IsZUFBZSxNQUFNLFVBQVUsVUFBVSwyQkFBMkI7QUFFeEU7QUFDQSxTQUFTLFlBQVksWUFBWSxjQUFjO0NBQzdDLElBQUksQ0FBQyxjQUNILE9BQU87Q0FFVCxJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsTUFDL0IsT0FBTztNQUNGLElBQUksY0FBYyxDQUFDLGFBQWEsTUFDckMsT0FBTyxHQUFHLFdBQVc7TUFDaEIsSUFBSSxDQUFDLGNBQWMsYUFBYSxNQUNyQyxPQUFPLGFBQWE7TUFFcEIsT0FBTyxHQUFHLFdBQVcsR0FBRyxhQUFhO0FBRXpDO0FBQ0EsU0FBUyxVQUFVLE9BQU87Q0FDeEIsT0FBTyxNQUFNLFVBQUE7QUFDZjtBQUNBLFNBQVMsc0JBQXNCLFFBQVEsWUFBWTtDQUNqRCxNQUFNLGVBQWUsT0FBTyxRQUFPLE1BQUssVUFBVSxDQUFDLE1BQU0sVUFBVTtDQUNuRSxhQUFhLEtBQUssR0FBRyxPQUFPLFFBQU8sTUFBSyxVQUFVLENBQUMsTUFBTSxVQUFVLENBQUM7Q0FDcEUsT0FBTztBQUNUO0FBQ0EsSUFBTSxVQUFVO0NBQ2QsU0FBUztDQUNULGtCQUFrQixDQUFDO0NBQ25CLG1CQUFtQixDQUFDO0NBQ3BCLFlBQVksQ0FBQztDQUNiLHlCQUF5QixDQUFDO0FBQzVCO0FBQ0EsU0FBUyw0QkFBNEIsVUFBVTtDQUM3QyxPQUFPO0VBQ0wsYUFBYSxTQUFTO0VBQ3RCLEtBQUssU0FBUztFQUNkLFFBQVEsU0FBUztFQUNqQixhQUFhLFNBQVM7RUFDdEIsVUFBVSxTQUFTO0VBQ25CLE1BQU0sU0FBUztFQUNmLFFBQVEsU0FBUztFQUNqQixPQUFPLFNBQVM7RUFDaEIsVUFBVSxTQUFTO0VBQ25CLGVBQWUsU0FBUztDQUMxQjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsY0FBYyxPQUFPLFVBQVUsVUFBVSxlQUFlLGdCQUFnQixhQUFhO0NBQzVHLE1BQU0sU0FBUyxNQUFNLGNBQWMsT0FBTyxRQUFRO0NBQ2xELElBQUksQ0FBQyxPQUFPLFNBQ1YsT0FBTyxHQUFHLE1BQU07Q0FFbEIsTUFBTSxrQkFBa0IsNEJBQTRCLGVBQWUsTUFBTSxDQUFDO0NBQzFFLFdBQVcsaUNBQWlDLE9BQU8sUUFBUTtDQUMzRCxPQUFPLGtCQUFrQixVQUFVLE9BQU8sVUFBVSxlQUFlLGlCQUFpQixXQUFXLENBQUMsQ0FBQyxLQUFLLEtBQUksTUFBSyxNQUFNLE9BQU8sU0FBQSxlQUFBLENBQUEsR0FDdkgsT0FDTCxDQUFDLENBQUM7QUFDSjtBQUNBLFNBQVMsTUFBTSxjQUFjLE9BQU8sVUFBVTs7Q0FDNUMsSUFBSSxNQUFNLFNBQVMsSUFBSTtFQUNyQixJQUFJLE1BQU0sY0FBYyxXQUFXLGFBQWEsWUFBWSxLQUFLLFNBQVMsU0FBUyxJQUNqRixPQUFBLGVBQUEsQ0FBQSxHQUNLLE9BQ0w7RUFFRixPQUFPO0dBQ0wsU0FBUztHQUNULGtCQUFrQixDQUFDO0dBQ25CLG1CQUFtQjtHQUNuQixZQUFZLENBQUM7R0FDYix5QkFBeUIsQ0FBQztFQUM1QjtDQUNGO0NBRUEsTUFBTSxPQURVLE1BQU0sV0FBVyxrQkFBQSxDQUNiLFVBQVUsY0FBYyxLQUFLO0NBQ2pELElBQUksQ0FBQyxLQUFLLE9BQUEsZUFBQSxDQUFBLEdBQ0wsT0FDTDtDQUNBLE1BQU0sWUFBWSxDQUFDO0NBQ25CLE9BQU8sU0FBQSxpQkFBUSxJQUFJLGVBQUEsUUFBQSxtQkFBQSxLQUFBLElBQUEsaUJBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxPQUFPO0VBQ3RELFVBQVUsS0FBSyxFQUFFO0NBQ25CLENBQUM7Q0FDRCxNQUFNLGFBQWEsSUFBSSxTQUFTLFNBQVMsSUFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNwQyxTQUFBLEdBQ0EsSUFBSSxTQUFTLElBQUksU0FBUyxTQUFTLEVBQUUsQ0FBQyxVQUMzQyxJQUFJO0NBQ0osT0FBTztFQUNMLFNBQVM7RUFDVCxrQkFBa0IsSUFBSTtFQUN0QixtQkFBbUIsU0FBUyxNQUFNLElBQUksU0FBUyxNQUFNO0VBQ3JEO0VBQ0EsMEJBQUEsa0JBQXlCLElBQUksZUFBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxrQkFBYSxDQUFDO0NBQzdDO0FBQ0Y7QUFDQSxTQUFTLE1BQU0sY0FBYyxrQkFBa0IsZ0JBQWdCLFFBQVEsUUFBUTtDQUM3RSxJQUFJLGVBQWUsU0FBUyxLQUFLLHlDQUF5QyxjQUFjLGdCQUFnQixRQUFRLE1BQU0sR0FFcEgsT0FBTztFQUNMLGNBQWMsSUFGRixnQkFBZ0Isa0JBQWtCLDRCQUE0QixRQUFRLElBQUksZ0JBQWdCLGdCQUFnQixhQUFhLFFBQVEsQ0FBQyxDQUU5SDtFQUNkLGdCQUFnQixDQUFDO0NBQ25CO0NBRUYsSUFBSSxlQUFlLFdBQVcsS0FBSyx5QkFBeUIsY0FBYyxnQkFBZ0IsTUFBTSxHQUU5RixPQUFPO0VBQ0wsY0FBYyxJQUZGLGdCQUFnQixhQUFhLFVBQVUsZ0NBQWdDLGNBQWMsZ0JBQWdCLFFBQVEsYUFBYSxRQUFRLENBRWhJO0VBQ2Q7Q0FDRjtDQUdGLE9BQU87RUFDTCxjQUFjLElBRkYsZ0JBQWdCLGFBQWEsVUFBVSxhQUFhLFFBRWxEO0VBQ2Q7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxnQ0FBZ0MsY0FBYyxnQkFBZ0IsUUFBUSxVQUFVO0NBQ3ZGLE1BQU0sTUFBTSxDQUFDO0NBQ2IsS0FBSyxNQUFNLEtBQUssUUFDZCxJQUFJLGVBQWUsY0FBYyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsU0FBUyxVQUFVLENBQUMsSUFBSTtFQUM5RSxNQUFNLElBQUksSUFBSSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNwQyxJQUFJLFVBQVUsQ0FBQyxLQUFLO0NBQ3RCO0NBRUYsT0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNLLFFBQUEsR0FDQSxHQUNMO0FBQ0Y7QUFDQSxTQUFTLDRCQUE0QixRQUFRLGdCQUFnQjtDQUMzRCxNQUFNLE1BQU0sQ0FBQztDQUNiLElBQUksa0JBQWtCO0NBQ3RCLEtBQUssTUFBTSxLQUFLLFFBQ2QsSUFBSSxFQUFFLFNBQVMsTUFBTSxVQUFVLENBQUMsTUFBQSxXQUFzQjtFQUNwRCxNQUFNLElBQUksSUFBSSxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNwQyxJQUFJLFVBQVUsQ0FBQyxLQUFLO0NBQ3RCO0NBRUYsT0FBTztBQUNUO0FBQ0EsU0FBUyx5Q0FBeUMsY0FBYyxnQkFBZ0IsUUFBUSxRQUFRO0NBQzlGLE9BQU8sT0FBTyxNQUFLLE1BQUs7RUFFdEIsSUFBSSxDQURpQixlQUFlLGNBQWMsZ0JBQWdCLENBQ2xELEdBQUcsT0FBTztFQUUxQixJQUFJLEVBRGtCLFVBQVUsQ0FBQyxNQUFBLFlBQ2IsT0FBTztFQUUzQixPQUFPLEVBRGtCLFdBQVcsS0FBQSxLQUFhLFVBQVUsQ0FBQyxNQUFNO0NBRXBFLENBQUM7QUFDSDtBQUNBLFNBQVMseUJBQXlCLGNBQWMsZ0JBQWdCLFFBQVE7Q0FDdEUsT0FBTyxPQUFPLE1BQUssTUFBSyxlQUFlLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQztBQUN6RTtBQUNBLFNBQVMsZUFBZSxjQUFjLGdCQUFnQixHQUFHO0NBQ3ZELEtBQUssYUFBYSxZQUFZLEtBQUssZUFBZSxTQUFTLE1BQU0sRUFBRSxjQUFjLFFBQy9FLE9BQU87Q0FFVCxPQUFPLEVBQUUsU0FBUztBQUNwQjtBQUNBLFNBQVMsaUJBQWlCLGNBQWMsVUFBVSxRQUFRO0NBQ3hELE9BQU8sU0FBUyxXQUFXLEtBQUssQ0FBQyxhQUFhLFNBQVM7QUFDekQ7QUFDQSxJQUFNLG1CQUFOLE1BQXVCLENBQUM7QUFDeEIsU0FBZSxZQUFZLElBQVUsS0FBYyxLQUFtQixLQUFRLEtBQVMsS0FBZSxLQUEyQixLQUFBOzs7OzRDQUF0RyxVQUFVLGNBQWMsbUJBQW1CLFFBQVEsU0FBUyxlQUFlLDJCQUEyQixhQUFhO0VBQzVJLE9BQU8sSUFBSSxXQUFXLFVBQVUsY0FBYyxtQkFBbUIsUUFBUSxTQUFTLDJCQUEyQixlQUFlLFdBQVcsQ0FBQyxDQUFDLFVBQVU7Q0FDckosQ0FBQTs7O0FBQ0EsSUFBTSx3QkFBd0I7QUFDOUIsSUFBTSxhQUFOLE1BQWlCO0NBWWYsWUFBWSxVQUFVLGNBQWMsbUJBQW1CLFFBQVEsU0FBUywyQkFBMkIsZUFBZSxhQUFhO3dCQVgvSCxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxnQkFBQSxLQUFBLENBQUE7d0JBQ0EscUJBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLFdBQUEsS0FBQSxDQUFBO3dCQUNBLDZCQUFBLEtBQUEsQ0FBQTt3QkFDQSxpQkFBQSxLQUFBLENBQUE7d0JBQ0EsZUFBQSxLQUFBLENBQUE7d0JBQ0Esa0JBQUEsS0FBQSxDQUFBO3dCQUNBLHlCQUF3QixDQUFBO3dCQUN4QixrQkFBaUIsSUFBQTtFQUVmLEtBQUssV0FBVztFQUNoQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxVQUFVO0VBQ2YsS0FBSyw0QkFBNEI7RUFDakMsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxjQUFjO0VBQ25CLEtBQUssaUJBQWlCLElBQUksZUFBZSxLQUFLLGVBQWUsS0FBSyxPQUFPO0NBQzNFO0NBQ0EsYUFBYSxHQUFHO0VBQ2QsT0FBTyxJQUFJQSxhQUFjLE1BQU0sT0FBTyxjQUFjLGVBQWUsWUFBWSwwQ0FBMEMsRUFBRSxhQUFhLEtBQUssSUFBSSxFQUFFLGFBQWEsRUFBRTtDQUNwSztDQUNBLFlBQU07O3dDQUFZO0dBQ2hCLE1BQU0sbUJBQW1CLE1BQU1ZLE9BQUssUUFBUSxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUdBLE9BQUssTUFBTSxDQUFDLENBQUM7R0FDdkUsTUFBTSxFQUNKLFVBQ0EsaUJBQ0UsTUFBTUEsT0FBSyxNQUFNLGdCQUFnQjtHQUVyQyxNQUFNLGFBQWEsSUFBSSxvQkFBb0IsSUFBSSxJQUQxQixTQUFTLGNBQWMsUUFDRyxDQUFRO0dBQ3ZELE1BQU0sT0FBTywwQkFBMEIsY0FBYyxDQUFDLEdBQUdBLE9BQUssUUFBUSxhQUFhQSxPQUFLLFFBQVEsUUFBUTtHQUN4RyxLQUFLLGNBQWNBLE9BQUssUUFBUTtHQUNoQyxXQUFXLE1BQU1BLE9BQUssY0FBYyxVQUFVLElBQUk7R0FDbEQsT0FBTztJQUNMLE9BQU87SUFDUDtHQUNGO0VBQ0YsQ0FBQSxDQUFBLENBQUE7O0NBQ0EsTUFBWSxrQkFBQTs7d0NBQWtCO0dBQzVCLE1BQU0sZUFBZSxJQUFJLHVCQUF1QixDQUFDLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQyxHQUFHLE9BQU8sT0FBQSxlQUFBLENBQUEsR0FDekVBLE9BQUssUUFBUSxXQUNsQixDQUFDLEdBQUdBLE9BQUssUUFBUSxVQUFVLE9BQU8sT0FBTyxDQUFDLENBQUMsR0FBRyxnQkFBZ0JBLE9BQUssbUJBQW1CLE1BQU0sQ0FBQyxHQUFHQSxPQUFLLFFBQVE7R0FDN0csSUFBSTtJQUVGLE9BQU87S0FDTCxVQUFBLE1BRnFCQSxPQUFLLG9CQUFvQkEsT0FBSyxVQUFVQSxPQUFLLFFBQVEsa0JBQWtCLGdCQUFnQixZQUFZO0tBR3hIO0lBQ0Y7R0FDRixTQUFTLEdBQUc7SUFDVixJQUFJLGFBQWEsa0JBQWtCO0tBQ2pDLE9BQUssVUFBVSxFQUFFO0tBQ2pCLE9BQU9BLE9BQUssTUFBTSxFQUFFLFFBQVEsSUFBSTtJQUNsQztJQUNBLElBQUksYUFBYSxTQUNmLE1BQU1BLE9BQUssYUFBYSxDQUFDO0lBRTNCLE1BQU07R0FDUjtFQUNGLENBQUEsQ0FBQSxDQUFBOztDQUNBLG9CQUEwQixVQUFVLFFBQVEsY0FBYyxRQUFRLGFBQUE7O3dDQUFhO0dBQzdFLElBQUksYUFBYSxTQUFTLFdBQVcsS0FBSyxhQUFhLFlBQVksR0FDakUsT0FBT0EsT0FBSyxnQkFBZ0IsVUFBVSxRQUFRLGNBQWMsV0FBVztHQUV6RSxNQUFNLFFBQVEsTUFBTUEsT0FBSyxlQUFlLFVBQVUsUUFBUSxjQUFjLGFBQWEsVUFBVSxRQUFRLE1BQU0sV0FBVztHQUN4SCxPQUFPLGlCQUFpQixXQUFXLENBQUMsS0FBSyxJQUFJLENBQUM7RUFDaEQsQ0FBQSxDQUFBLENBQUE7O0NBQ0EsZ0JBQXNCLFVBQVUsUUFBUSxjQUFjLGFBQUE7O3dDQUFhO0dBQ2pFLE1BQU0sZUFBZSxDQUFDO0dBQ3RCLEtBQUssTUFBTSxTQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsR0FDbkQsSUFBSSxVQUFVLFdBQ1osYUFBYSxRQUFRLEtBQUs7UUFFMUIsYUFBYSxLQUFLLEtBQUs7R0FHM0IsSUFBSSxXQUFXLENBQUM7R0FDaEIsS0FBSyxNQUFNLGVBQWUsY0FBYztJQUN0QyxNQUFNLFFBQVEsYUFBYSxTQUFTO0lBQ3BDLE1BQU0sZUFBZSxzQkFBc0IsUUFBUSxXQUFXO0lBQzlELE1BQU0saUJBQWlCLE1BQU1BLE9BQUssb0JBQW9CLFVBQVUsY0FBYyxPQUFPLGFBQWEsV0FBVztJQUM3RyxTQUFTLEtBQUssR0FBRyxjQUFjO0dBQ2pDO0dBQ0EsTUFBTSxpQkFBaUIsc0JBQXNCLFFBQVE7R0FDckQsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUN0QywwQkFBMEIsY0FBYztHQUUxQyw0QkFBNEIsY0FBYztHQUMxQyxPQUFPO0VBQ1QsQ0FBQSxDQUFBLENBQUE7O0NBQ0EsZUFBcUIsVUFBVSxRQUFRLGNBQWMsVUFBVSxRQUFRLGdCQUFnQixhQUFBOzt3Q0FBYTtHQUNsRyxLQUFLLE1BQU0sS0FBSyxRQUNkLElBQUk7O0lBQ0YsT0FBTyxNQUFNQSxPQUFLLDRCQUFBLGVBQTJCLEVBQUUsZUFBQSxRQUFBLGlCQUFBLEtBQUEsSUFBQSxlQUFhLFVBQVUsUUFBUSxHQUFHLGNBQWMsVUFBVSxRQUFRLGdCQUFnQixXQUFXO0dBQzlJLFNBQVMsR0FBRztJQUNWLElBQUksYUFBYSxXQUFXLGFBQWEsQ0FBQyxHQUN4QztJQUVGLE1BQU07R0FDUjtHQUVGLElBQUksaUJBQWlCLGNBQWMsVUFBVSxNQUFNLEdBQ2pELE9BQU8sSUFBSSxpQkFBaUI7R0FFOUIsTUFBTSxJQUFJLFFBQVEsWUFBWTtFQUNoQyxDQUFBLENBQUEsQ0FBQTs7Q0FDQSwyQkFBaUMsVUFBVSxRQUFRLE9BQU8sWUFBWSxVQUFVLFFBQVEsZ0JBQWdCLGFBQUE7O3dDQUFhO0dBQ25ILElBQUksVUFBVSxLQUFLLE1BQU0sV0FBVyxXQUFBLGFBQTZCLENBQUMsZUFBZSxZQUFZLFVBQVUsS0FBSyxJQUMxRyxNQUFNLElBQUksUUFBUSxVQUFVO0dBRTlCLElBQUksTUFBTSxlQUFlLEtBQUEsR0FDdkIsT0FBT0EsT0FBSyx5QkFBeUIsVUFBVSxZQUFZLE9BQU8sVUFBVSxRQUFRLFdBQVc7R0FFakcsSUFBSUEsT0FBSyxrQkFBa0IsZ0JBQ3pCLE9BQU9BLE9BQUssdUNBQXVDLFVBQVUsWUFBWSxRQUFRLE9BQU8sVUFBVSxRQUFRLFdBQVc7R0FFdkgsTUFBTSxJQUFJLFFBQVEsVUFBVTtFQUM5QixDQUFBLENBQUEsQ0FBQTs7Q0FDQSx1Q0FBNkMsVUFBVSxjQUFjLFFBQVEsT0FBTyxVQUFVLFFBQVEsYUFBQTs7d0NBQWE7R0FDakgsTUFBTSxFQUNKLFNBQ0EsWUFDQSxrQkFDQSx5QkFDQSxzQkFDRSxNQUFNLGNBQWMsT0FBTyxRQUFRO0dBQ3ZDLElBQUksQ0FBQyxTQUFTLE1BQU0sSUFBSSxRQUFRLFlBQVk7R0FDNUMsSUFBSSxPQUFPLE1BQU0sZUFBZSxZQUFZLE1BQU0sV0FBVyxPQUFPLEtBQUs7SUFDdkUsT0FBSztJQUNMLElBQUlBLE9BQUssd0JBQXdCLHVCQUF1QjtLQUN0RCxJQUFJLFdBQ0YsTUFBTSxJQUFJWixhQUFjLE1BQU0sOERBQThEWSxPQUFLLFFBQVEsUUFBUSxNQUFNLFdBQVcsc0lBQWdKO0tBRXBSLE9BQUssaUJBQWlCO0lBQ3hCO0dBQ0Y7R0FDQSxNQUFNLGtCQUFrQkEsT0FBSyxlQUFlLFVBQVUsT0FBTyxVQUFVLFlBQVksV0FBVztHQUM5RixJQUFJQSxPQUFLLFlBQVksU0FDbkIsTUFBTSxJQUFJLE1BQU1BLE9BQUssWUFBWSxNQUFNO0dBRXpDLE1BQU0sVUFBVSxNQUFNQSxPQUFLLGVBQWUsc0JBQXNCLGtCQUFrQixNQUFNLFlBQVkseUJBQXlCLDRCQUE0QixlQUFlLEdBQUcsUUFBUTtHQUNuTCxNQUFNLGNBQWMsTUFBTUEsT0FBSyxlQUFlLG1CQUFtQixPQUFPLE9BQU87R0FDL0UsT0FBT0EsT0FBSyxlQUFlLFVBQVUsUUFBUSxjQUFjLFlBQVksT0FBTyxpQkFBaUIsR0FBRyxRQUFRLE9BQU8sV0FBVztFQUM5SCxDQUFBLENBQUEsQ0FBQTs7Q0FDQSxlQUFlLFVBQVUsT0FBTyxVQUFVLFlBQVksYUFBYTs7RUFDakUsTUFBTSxXQUFXLElBQUksdUJBQXVCLFVBQVUsWUFBWSxPQUFPLE9BQUEsZUFBQSxDQUFBLEdBQ3BFLEtBQUssUUFBUSxXQUNsQixDQUFDLEdBQUcsS0FBSyxRQUFRLFVBQVUsUUFBUSxLQUFLLEdBQUcsVUFBVSxLQUFLLElBQUEsUUFBQSxtQkFBRyxNQUFNLGVBQUEsUUFBQSxxQkFBQSxLQUFBLElBQUEsbUJBQWEsTUFBTSxzQkFBQSxRQUFBLFNBQUEsS0FBQSxJQUFBLE9BQW9CLE1BQU0sT0FBTyxXQUFXLEtBQUssR0FBRyxRQUFRO0VBQ2xKLE1BQU0sWUFBWSxhQUFhLFVBQVUsYUFBYSxLQUFLLHlCQUF5QjtFQUNwRixTQUFTLFNBQVMsT0FBTyxPQUFPLFVBQVUsTUFBTTtFQUNoRCxTQUFTLE9BQU8sT0FBTyxPQUFPLFVBQVUsSUFBSTtFQUM1QyxPQUFPO0NBQ1Q7Q0FDQSx5QkFBK0IsVUFBVSxZQUFZLE9BQU8sVUFBVSxRQUFRLGFBQUE7O3dDQUFhOztHQUN6RixJQUFJQSxPQUFLLFlBQVksU0FDbkIsTUFBTSxJQUFJLE1BQU1BLE9BQUssWUFBWSxNQUFNO0dBRXpDLE1BQU0sa0JBQWlCLFdBQVVBLE9BQUssZUFBZSxVQUFVLE9BQU8sT0FBTyxrQkFBa0IsT0FBTyxZQUFZLFdBQVc7R0FDN0gsTUFBTSxTQUFTLE1BQU0sZUFBZSxnQkFBZ0IsWUFBWSxPQUFPLFVBQVUsVUFBVUEsT0FBSyxlQUFlLGdCQUFnQkEsT0FBSyxXQUFXLENBQUM7R0FDaEosSUFBSSxNQUFNLFNBQVMsTUFDakIsV0FBVyxXQUFXLENBQUM7R0FFekIsSUFBSSxFQUFBLFdBQUEsUUFBQSxXQUFBLEtBQUEsSUFBQSxLQUFBLElBQUMsT0FBUSxVQUNYLE1BQU0sSUFBSSxRQUFRLFVBQVU7R0FFOUIsWUFBQSxvQkFBVyxNQUFNLGVBQUEsUUFBQSxzQkFBQSxLQUFBLElBQUEsb0JBQWE7R0FDOUIsTUFBTSxFQUNKLFFBQVEsZ0JBQ04sTUFBTUEsT0FBSyxlQUFlLFVBQVUsT0FBTyxRQUFRO0dBQ3ZELE1BQU0saUJBQUEsd0JBQWdCLE1BQU0scUJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQW1CO0dBQy9DLE1BQU0sRUFDSixZQUNBLGtCQUNBLHNCQUNFO0dBQ0osTUFBTSxXQUFXQSxPQUFLLGVBQWUsVUFBVSxPQUFPLGtCQUFrQixZQUFZLFdBQVc7R0FDL0YsTUFBTSxFQUNKLGNBQ0EsbUJBQ0UsTUFBTSxZQUFZLGtCQUFrQixtQkFBbUIsYUFBYSxNQUFNO0dBQzlFLElBQUksZUFBZSxXQUFXLEtBQUssYUFBYSxZQUFZLEdBRTFELE9BQU8sSUFBSSxTQUFTLFVBQVUsTUFEUEEsT0FBSyxnQkFBZ0IsZUFBZSxhQUFhLGNBQWMsUUFBUSxDQUN4RDtHQUV4QyxJQUFJLFlBQVksV0FBVyxLQUFLLGVBQWUsV0FBVyxHQUN4RCxPQUFPLElBQUksU0FBUyxVQUFVLENBQUMsQ0FBQztHQUVsQyxNQUFNLGtCQUFrQixVQUFVLEtBQUssTUFBTTtHQUM3QyxNQUFNLFFBQVEsTUFBTUEsT0FBSyxlQUFlLGVBQWUsYUFBYSxjQUFjLGdCQUFnQixrQkFBa0IsaUJBQWlCLFFBQVEsTUFBTSxRQUFRO0dBQzNKLE9BQU8sSUFBSSxTQUFTLFVBQVUsaUJBQWlCLFdBQVcsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDO0VBQ3hFLENBQUEsQ0FBQSxDQUFBOztDQUNBLGVBQXFCLFVBQVUsT0FBTyxVQUFBOzt3Q0FBVTtHQUM5QyxJQUFJLE1BQU0sVUFDUixPQUFPO0lBQ0wsUUFBUSxNQUFNO0lBQ2Q7R0FDRjtHQUVGLElBQUksTUFBTSxjQUFjO0lBQ3RCLElBQUksTUFBTSxrQkFBa0IsS0FBQSxHQUFXO0tBQ3JDLE1BQU0sa0JBQWtCLE1BQU07S0FDOUIsSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLGlCQUM1QixNQUFNLGtCQUFrQixnQkFBZ0IsT0FBTyxRQUFRLENBQUMsQ0FBQztLQUUzRCxPQUFPO01BQ0wsUUFBUSxNQUFNO01BQ2QsVUFBVSxNQUFNO0tBQ2xCO0lBQ0Y7SUFDQSxJQUFJQSxRQUFLLFlBQVksU0FDbkIsTUFBTSxJQUFJLE1BQU1BLFFBQUssWUFBWSxNQUFNO0lBR3pDLElBQUksTUFEMkIsZUFBZSxpQkFBaUIsVUFBVSxPQUFPLFVBQVVBLFFBQUssZUFBZUEsUUFBSyxXQUFXLENBQUMsR0FDekc7S0FDcEIsTUFBTSxNQUFNLE1BQU1BLFFBQUssYUFBYSxhQUFhLFVBQVUsS0FBSztLQUNoRSxNQUFNLGdCQUFnQixJQUFJO0tBQzFCLE1BQU0sa0JBQWtCLElBQUk7S0FDNUIsTUFBTSx5QkFBeUIsSUFBSTtLQUNuQyxPQUFPO0lBQ1Q7SUFDQSxNQUFNLGFBQWEsS0FBSztHQUMxQjtHQUNBLE9BQU87SUFDTCxRQUFRLENBQUM7SUFDVDtHQUNGO0VBQ0YsQ0FBQSxDQUFBLENBQUE7O0FBQ0Y7QUFDQSxTQUFTLDRCQUE0QixPQUFPO0NBQzFDLE1BQU0sTUFBTSxHQUFHLE1BQU07RUFDbkIsSUFBSSxFQUFFLE1BQU0sV0FBQSxXQUEyQixPQUFPO0VBQzlDLElBQUksRUFBRSxNQUFNLFdBQUEsV0FBMkIsT0FBTztFQUM5QyxPQUFPLEVBQUUsTUFBTSxPQUFPLGNBQWMsRUFBRSxNQUFNLE1BQU07Q0FDcEQsQ0FBQztBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsTUFBTTtDQUNoQyxNQUFNLFNBQVMsS0FBSyxNQUFNO0NBQzFCLE9BQU8sVUFBVSxPQUFPLFNBQVM7QUFDbkM7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3BDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE1BQU0sOEJBQWMsSUFBSSxJQUFJO0NBQzVCLEtBQUssTUFBTSxRQUFRLE9BQU87RUFDeEIsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQUc7R0FDN0IsT0FBTyxLQUFLLElBQUk7R0FDaEI7RUFDRjtFQUNBLE1BQU0seUJBQXlCLE9BQU8sTUFBSyxlQUFjLEtBQUssTUFBTSxnQkFBZ0IsV0FBVyxNQUFNLFdBQVc7RUFDaEgsSUFBSSwyQkFBMkIsS0FBQSxHQUFXO0dBQ3hDLHVCQUF1QixTQUFTLEtBQUssR0FBRyxLQUFLLFFBQVE7R0FDckQsWUFBWSxJQUFJLHNCQUFzQjtFQUN4QyxPQUNFLE9BQU8sS0FBSyxJQUFJO0NBRXBCO0NBQ0EsS0FBSyxNQUFNLGNBQWMsYUFBYTtFQUNwQyxNQUFNLGlCQUFpQixzQkFBc0IsV0FBVyxRQUFRO0VBQ2hFLE9BQU8sS0FBSyxJQUFJLFNBQVMsV0FBVyxPQUFPLGNBQWMsQ0FBQztDQUM1RDtDQUNBLE9BQU8sT0FBTyxRQUFPLE1BQUssQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDO0FBQy9DO0FBQ0EsU0FBUywwQkFBMEIsT0FBTztDQUN4QyxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sU0FBUSxNQUFLO0VBQ2pCLE1BQU0sMEJBQTBCLE1BQU0sRUFBRSxNQUFNO0VBQzlDLElBQUkseUJBQXlCO0dBQzNCLE1BQU0sSUFBSSx3QkFBd0IsSUFBSSxLQUFJLE1BQUssRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRztHQUNyRSxNQUFNLElBQUksRUFBRSxNQUFNLElBQUksS0FBSSxNQUFLLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDckQsTUFBTSxJQUFJWixhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYyxtREFBbUQsRUFBRSxTQUFTLEVBQUUsR0FBRztFQUN0SjtFQUNBLE1BQU0sRUFBRSxNQUFNLFVBQVUsRUFBRTtDQUM1QixDQUFDO0FBQ0g7QUFDQSxTQUFTLFFBQVEsT0FBTztDQUN0QixPQUFPLE1BQU0sUUFBUSxDQUFDO0FBQ3hCO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDekIsT0FBTyxNQUFNLFdBQVcsQ0FBQztBQUMzQjtBQUNBLFNBQVMsVUFBVSxVQUFVLGNBQWMsbUJBQW1CLFFBQVEsWUFBWSwyQkFBMkIsYUFBYTtDQUN4SCxPQUFPLFNBQUEsV0FBQTsyQ0FBZSxHQUFLO0dBQ3pCLE1BQU0sRUFDSixPQUFPLGdCQUNQLE1BQU0sc0JBQ0osTUFBTSxZQUFZLFVBQVUsY0FBYyxtQkFBbUIsUUFBUSxFQUFFLGNBQWMsWUFBWSwyQkFBMkIsV0FBVztHQUMzSSxPQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0ssQ0FBQSxHQUFBLENBQUEsR0FBQTtJQUNIO0lBQ0E7SUFDRjtFQUNGLENBQUE7a0JBVnNCLEtBQUE7OztHQVV0QixDQUFDO0FBQ0g7QUFDQSxTQUFTLFlBQVksMkJBQTJCO0NBQzlDLE9BQU8sVUFBUyxNQUFLO0VBQ25CLE1BQU0sRUFDSixnQkFDQSxRQUFRLEVBQ04sd0JBRUE7RUFDSixJQUFJLENBQUMsa0JBQWtCLFFBQ3JCLE9BQU8sR0FBRyxDQUFDO0VBRWIsTUFBTSwyQkFBMkIsSUFBSSxJQUFJLGtCQUFrQixLQUFJLFVBQVMsTUFBTSxLQUFLLENBQUM7RUFDcEYsTUFBTSwyQ0FBMkIsSUFBSSxJQUFJO0VBQ3pDLEtBQUssTUFBTSxTQUFTLDBCQUEwQjtHQUM1QyxJQUFJLHlCQUF5QixJQUFJLEtBQUssR0FDcEM7R0FFRixLQUFLLE1BQU0sWUFBWSxpQkFBaUIsS0FBSyxHQUMzQyx5QkFBeUIsSUFBSSxRQUFRO0VBRXpDO0VBQ0EsSUFBSSxrQkFBa0I7RUFDdEIsT0FBTyxLQUFLLHdCQUF3QixDQUFDLENBQUMsS0FBSyxXQUFVLFVBQVM7R0FDNUQsSUFBSSx5QkFBeUIsSUFBSSxLQUFLLEdBQ3BDLE9BQU8sV0FBVyxPQUFPLGdCQUFnQix5QkFBeUI7UUFDN0Q7SUFDTCxNQUFNLE9BQU8sYUFBYSxPQUFPLE1BQU0sUUFBUSx5QkFBeUIsQ0FBQyxDQUFDO0lBQzFFLE9BQU8sR0FBRyxLQUFLLENBQUM7R0FDbEI7RUFDRixDQUFDLEdBQUcsVUFBVSxpQkFBaUIsR0FBRyxTQUFTLENBQUMsR0FBRyxVQUFTLE1BQUssb0JBQW9CLHlCQUF5QixPQUFPLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQztDQUNqSSxDQUFDO0FBQ0g7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBRS9CLE9BQU8sQ0FBQyxPQUFPLEdBREssTUFBTSxTQUFTLEtBQUksVUFBUyxpQkFBaUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUM3QyxDQUFDO0FBQy9CO0FBQ0EsU0FBUyxXQUFXLFdBQVcsV0FBVywyQkFBMkI7Q0FDbkUsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxVQUFVLFVBQVU7Q0FDMUIsS0FBQSxXQUFBLFFBQUEsV0FBQSxLQUFBLElBQUEsS0FBQSxJQUFJLE9BQVEsV0FBVSxLQUFBLEtBQWEsQ0FBQyxlQUFlLE1BQU0sR0FDdkQsUUFBUSxpQkFBaUIsT0FBTztDQUVsQyxPQUFPLFlBQVk7RUFDakIsVUFBVSxPQUFPLGFBQWEsV0FBVyxVQUFVLFFBQVEseUJBQXlCLENBQUMsQ0FBQztFQUN0RixPQUFPLFlBQVksU0FBUyxXQUFXLFNBQVMsQ0FBQyxDQUFDLEtBQUssS0FBSSxpQkFBZ0I7R0FDekUsVUFBVSxnQkFBZ0I7R0FDMUIsVUFBVSxPQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0wsVUFBVSxJQUFBLEdBQ1YsWUFDTDtHQUNBLE9BQU87RUFDVCxDQUFDLENBQUM7Q0FDSixDQUFDO0FBQ0g7QUFDQSxTQUFTLFlBQVksU0FBUyxXQUFXLFdBQVc7Q0FDbEQsTUFBTSxPQUFPLFlBQVksT0FBTztDQUNoQyxJQUFJLEtBQUssV0FBVyxHQUNsQixPQUFPLEdBQUcsQ0FBQyxDQUFDO0NBRWQsTUFBTSxPQUFPLENBQUM7Q0FDZCxPQUFPLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxVQUFTLFFBQU8sWUFBWSxRQUFRLE1BQU0sV0FBVyxTQUFTLENBQUMsQ0FBQyxLQUFLLE1BQU0sR0FBRyxLQUFJLFVBQVM7RUFDaEgsSUFBSSxpQkFBaUIsaUJBQ25CLE1BQU0sMkJBQTJCLElBQUkscUJBQXFCLEdBQUcsS0FBSztFQUVwRSxLQUFLLE9BQU87Q0FDZCxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxHQUFHLFVBQVUsSUFBSSxHQUFHLFlBQVcsTUFBSyxhQUFhLENBQUMsSUFBSSxRQUFRLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDOUY7QUFDQSxTQUFTLFlBQVksZ0JBQWdCLFdBQVcsV0FBVztDQUN6RCxNQUFNLGtCQUFrQixVQUFVO0NBQ2xDLE1BQU0sV0FBVywyQkFBMkIsZ0JBQWdCLGVBQWU7Q0FFM0UsT0FBTyxtQkFEZSxTQUFTLFVBQVUsU0FBUyxRQUFRLFdBQVcsU0FBUyxJQUFJLHNCQUFzQix1QkFBdUIsU0FBUyxXQUFXLFNBQVMsQ0FBQyxDQUN0SDtBQUN6QztBQUNBLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLE9BQU8sV0FBVSxNQUFLO0VBQ3BCLE1BQU0sYUFBYSxLQUFLLENBQUM7RUFDekIsSUFBSSxZQUNGLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxLQUFLLFVBQVUsQ0FBQyxDQUFDO0VBRTNDLE9BQU8sR0FBRyxDQUFDO0NBQ2IsQ0FBQztBQUNIO0FBQ0EsSUFBTSxnQkFBTixNQUFvQjtDQUNsQixXQUFXLFVBQVU7RUFDbkIsSUFBSTtFQUNKLElBQUksUUFBUSxTQUFTO0VBQ3JCLE9BQU8sVUFBVSxLQUFBLEdBQVc7O0dBQzFCLGFBQUEsd0JBQVksS0FBSyx5QkFBeUIsS0FBSyxPQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFLO0dBQ3BELFFBQVEsTUFBTSxTQUFTLE1BQUssVUFBUyxNQUFNLFdBQVcsY0FBYztFQUN0RTtFQUNBLE9BQU87Q0FDVDtDQUNBLHlCQUF5QixVQUFVO0VBQ2pDLE9BQU8sU0FBUyxLQUFLO0NBQ3ZCO0FBUUY7OytCQVBTLFFBQU8sU0FBUyxzQkFBc0IsbUJBQW1CO0NBQzlELE9BQU8sS0FBSyxxQkFBcUJjLGdCQUFlO0FBQ2xELENBQUE7K0JBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1Asc0JBQXNCLE9BQU8sb0JBQW9CLEVBQUEsQ0FBRztBQUN0RCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1osaUJBQXFCLGVBQWUsQ0FBQztFQUN0RixNQUFNO0VBQ04sTUFBTSxDQUFDLEVBQ0wsZUFBZSxPQUFPLG9CQUFvQixFQUM1QyxDQUFDO0NBQ0gsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLHVCQUFOLGNBQW1DLGNBQWM7Q0FFL0MsWUFBWSxPQUFPO0VBQ2pCLE1BQU07d0JBRlIsU0FBQSxLQUFBLENBQUE7RUFHRSxLQUFLLFFBQVE7Q0FDZjtDQUNBLFlBQVksVUFBVTtFQUNwQixNQUFNLFFBQVEsS0FBSyxXQUFXLFFBQVE7RUFDdEMsSUFBSSxVQUFVLEtBQUEsR0FDWixLQUFLLE1BQU0sU0FBUyxLQUFLO0NBRTdCO0FBVUY7O3NDQVRTLFFBQU8sU0FBUyw2QkFBNkIsbUJBQW1CO0NBRXJFLE9BQU8sS0FBSyxxQkFBcUJhLHVCQUFzQlgsU0FBWVksS0FBUSxDQUFDO0FBQzlFLENBQUE7c0NBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9EO0NBQ1AsU0FBU0Esc0JBQXFCO0NBQzlCLFlBQVk7QUFDZCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2IsaUJBQXFCLHNCQUFzQixDQUFDO0VBQzdGLE1BQU07RUFDTixNQUFNLENBQUMsRUFDTCxZQUFZLE9BQ2QsQ0FBQztDQUNILENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTWMsTUFDUixDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sdUJBQXVCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLGtCQUFrQixJQUFJLEVBQ3BILGdCQUFnQixDQUFDLEdBQ25CLENBQUM7QUFDRCxJQUFNLFNBQVMsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksV0FBVyxFQUFFO0FBQy9GLElBQU0scUJBQU4sTUFBeUI7O3dCQUN2QixvQ0FBbUIsSUFBSSxRQUFRLENBQUE7d0JBQy9CLG1DQUFrQixJQUFJLFFBQVEsQ0FBQTt3QkFDOUIsdUJBQUEsS0FBQSxDQUFBO3dCQUNBLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFXLE9BQU8sUUFBUSxDQUFBOztDQUMxQixjQUFvQixVQUFVLE9BQUE7O3dDQUFPO0dBQ25DLElBQUlKLFFBQUssaUJBQWlCLElBQUksS0FBSyxHQUNqQyxPQUFPQSxRQUFLLGlCQUFpQixJQUFJLEtBQUs7UUFDakMsSUFBSSxNQUFNLGtCQUNmLE9BQU8sUUFBUSxRQUFRLE1BQU0sZ0JBQWdCO0dBRS9DLElBQUlBLFFBQUsscUJBQ1AsUUFBSyxvQkFBb0IsS0FBSztHQUVoQyxNQUFNLFNBQUEsa0JBQUEsYUFBc0I7SUFDMUIsSUFBSTs7S0FFRixNQUFNLFlBQVksTUFBTSxzQkFBc0JLLHlCQUEwQixNQURuRCxnQkFBZ0Isc0JBQXNCLGdCQUFnQixNQUFNLGNBQWMsQ0FBQyxDQUFDLENBQ25CLENBQUM7S0FDL0UsSUFBSUwsUUFBSyxtQkFDUCxRQUFLLGtCQUFrQixLQUFLO0tBRTlCLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYyxrQkFBQSxjQUFpQixNQUFNLFVBQUEsUUFBQSxnQkFBQSxLQUFBLElBQUEsY0FBUSxJQUFJLFNBQVM7S0FDL0YsTUFBTSxtQkFBbUI7S0FDekIsT0FBTztJQUNULFVBQVU7S0FDUixRQUFLLGlCQUFpQixPQUFPLEtBQUs7SUFDcEM7R0FDRixDQUFBLENBQUEsQ0FBRztHQUNILFFBQUssaUJBQWlCLElBQUksT0FBTyxNQUFNO0dBQ3ZDLE9BQU87RUFDVCxDQUFBLENBQUEsQ0FBQTs7Q0FDQSxhQUFhLGdCQUFnQixPQUFPOztFQUNsQyxJQUFJLEtBQUssZ0JBQWdCLElBQUksS0FBSyxHQUNoQyxPQUFPLEtBQUssZ0JBQWdCLElBQUksS0FBSztPQUNoQyxJQUFJLE1BQU0sZUFDZixPQUFPLFFBQVEsUUFBUTtHQUNyQixRQUFRLE1BQU07R0FDZCxVQUFVLE1BQU07RUFDbEIsQ0FBQztFQUVILElBQUksS0FBSyxxQkFDUCxLQUFLLG9CQUFvQixLQUFLO0VBRWhDLE1BQU0sU0FBQSxrQkFBQSxhQUFzQjtHQUMxQixJQUFJO0lBQ0YsTUFBTSxTQUFTLE1BQU0sYUFBYSxPQUFPQSxRQUFLLFVBQVUsZ0JBQWdCQSxRQUFLLGlCQUFpQjtJQUM5RixNQUFNLGdCQUFnQixPQUFPO0lBQzdCLE1BQU0sa0JBQWtCLE9BQU87SUFDL0IsTUFBTSx5QkFBeUIsT0FBTztJQUN0QyxPQUFPO0dBQ1QsVUFBVTtJQUNSLFFBQUssZ0JBQWdCLE9BQU8sS0FBSztHQUNuQztFQUNGLENBQUEsQ0FBQSxDQUFHO0VBQ0gsS0FBSyxnQkFBZ0IsSUFBSSxPQUFPLE1BQU07RUFDdEMsT0FBTztDQUNUO0FBUUY7O29DQVBTLFFBQU8sU0FBUywyQkFBMkIsbUJBQW1CO0NBQ25FLE9BQU8sS0FBSyxxQkFBcUJNLHFCQUFvQjtBQUN2RCxDQUFBO29DQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLG9CQUFtQjtBQUM5QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2hCLGlCQUFxQixvQkFBb0IsQ0FBQyxFQUMzRixNQUFNLFFBQ1IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxTQUFlLGFBQWEsTUFBTyxNQUFVLE1BQWdCLE1BQUE7Ozs7OENBQWpDLE9BQU8sVUFBVSxnQkFBZ0IsbUJBQW1CO0VBRTlFLE1BQU0sSUFBSSxNQUFNLHNCQUFzQmUseUJBQTBCLE1BRDNDLGdCQUFnQixzQkFBc0Isc0JBQXNCLE1BQU0sYUFBYSxDQUFDLENBQUMsQ0FDaEMsQ0FBQztFQUN2RSxJQUFJO0VBQ0osSUFBSSxhQUFhRSxxQkFBbUIsTUFBTSxRQUFRLENBQUMsR0FDakQsa0JBQWtCO09BRWxCLGtCQUFrQixNQUFNLFNBQVMsbUJBQW1CLENBQUM7RUFFdkQsSUFBSSxtQkFDRixrQkFBa0IsS0FBSztFQUV6QixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUksOEJBQThCO0VBQ2xDLElBQUksVUFBVSxLQUFBO0VBQ2QsSUFBSSxNQUFNLFFBQVEsZUFBZSxHQUFHO0dBQ2xDLFlBQVk7R0FDWiw4QkFBOEI7RUFDaEMsT0FBTztHQUNMLFdBQVcsZ0JBQWdCLE9BQU8sY0FBYyxDQUFDLENBQUM7R0FDbEQsVUFBVTtHQUNWLFlBQVksU0FBUyxJQUFJLFFBQVEsQ0FBQyxHQUFHO0lBQ25DLFVBQVU7SUFDVixNQUFNO0dBQ1IsQ0FBQyxDQUFDLENBQUMsS0FBSztFQUNWO0VBQ0EsTUFBTSxTQUFTLFVBQVUsSUFBSSxpQkFBaUI7RUFDOUMsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjLGVBQWUsUUFBUSxNQUFNLE1BQU0sMkJBQTJCO0VBQ2pILE9BQU87R0FDTDtHQUNBO0dBQ0E7RUFDRjtDQUNGLENBQUE7OztBQUNBLFNBQWUsc0JBQXNCLE1BQUE7Ozs7OERBQU87RUFRMUMsT0FBTztDQUNULENBQUE7OztBQUNBLElBQU0sc0JBQU4sTUFBMEIsQ0FRMUI7O3FDQVBTLFFBQU8sU0FBUyw0QkFBNEIsbUJBQW1CO0NBQ3BFLE9BQU8sS0FBSyxxQkFBcUJDLHNCQUFxQjtBQUN4RCxDQUFBO3FDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLHNCQUFzQixPQUFPLDBCQUEwQixFQUFBLENBQUc7QUFDNUQsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNsQixpQkFBcUIscUJBQXFCLENBQUM7RUFDNUYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLGVBQWUsT0FBTywwQkFBMEIsRUFDbEQsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSw2QkFBTixNQUFpQztDQUMvQixpQkFBaUIsS0FBSztFQUNwQixPQUFPO0NBQ1Q7Q0FDQSxRQUFRLEtBQUs7RUFDWCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLFlBQVksVUFBVTtFQUMxQixPQUFPO0NBQ1Q7QUFRRjs7NENBUFMsUUFBTyxTQUFTLG1DQUFtQyxtQkFBbUI7Q0FDM0UsT0FBTyxLQUFLLHFCQUFxQm1CLDZCQUE0QjtBQUMvRCxDQUFBOzRDQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLDRCQUEyQjtBQUN0QyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY25CLGlCQUFxQiw0QkFBNEIsQ0FBQyxFQUNuRyxNQUFNLFFBQ1IsQ0FBQyxHQUFHLE1BQU0sSUFBSTtBQUNoQixFQUFBLENBQUc7QUFDSCxJQUFNLHlCQUF5QixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSwyQkFBMkIsRUFBRTtBQUMvSCxJQUFNLDBCQUEwQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSw0QkFBNEIsRUFBRTtBQUNqSSxTQUFTLHFCQUFxQixVQUFVLE1BQU0sSUFBSTtDQUNoRCxNQUFNLG9CQUFvQixTQUFTLElBQUksdUJBQXVCO0NBQzlELE1BQU0sV0FBVyxTQUFTLElBQUksUUFBUTtDQUN0QyxJQUFJLENBQUMsU0FBUyx1QkFBdUIsa0JBQWtCLG9CQUFvQjtFQUN6RSxrQkFBa0IscUJBQXFCO0VBQ3ZDLE9BQU8sSUFBSSxTQUFRLFlBQVcsV0FBVyxPQUFPLENBQUM7Q0FDbkQ7Q0FDQSxJQUFJO0NBQ0osTUFBTSx3QkFBd0IsSUFBSSxTQUFRLFlBQVc7RUFDbkQsK0JBQStCO0NBQ2pDLENBQUM7Q0FDRCxNQUFNLGFBQWEsU0FBUywwQkFBMEI7RUFDcEQsNkJBQTZCO0VBQzdCLE9BQU8sb0JBQW9CLFFBQVE7Q0FDckMsQ0FBQztDQUNELFdBQVcsbUJBQW1CLE9BQU0sVUFBUztFQUMzQyxJQUFJLE9BQU8sY0FBYyxlQUFlLFdBQ3RDLFFBQVEsTUFBTSxLQUFLO0NBRXZCLENBQUM7Q0FDRCxXQUFXLE1BQU0sT0FBTSxVQUFTO0VBQzlCLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsUUFBUSxNQUFNLEtBQUs7Q0FFdkIsQ0FBQztDQUNELFdBQVcsU0FBUyxPQUFNLFVBQVM7RUFDakMsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUN0QyxRQUFRLE1BQU0sS0FBSztDQUV2QixDQUFDO0NBQ0QsTUFBTSxFQUNKLDRCQUNFO0NBQ0osSUFBSSx5QkFDRixzQkFBc0IsZ0JBQWdCLHdCQUF3QjtFQUM1RDtFQUNBO0VBQ0E7Q0FDRixDQUFDLENBQUM7Q0FFSixPQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixVQUFVO0NBQ3JDLE9BQU8sSUFBSSxTQUFRLFlBQVc7RUFDNUIsZ0JBQWdCLEVBQ2QsWUFBWSxXQUFXLE9BQU8sRUFDaEMsR0FBRyxFQUNELFNBQ0YsQ0FBQztDQUNILENBQUM7QUFDSDtBQUNBLElBQU0sbUNBQW1DLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLG9DQUFvQyxFQUFFO0FBQ2xKLElBQU0sYUFBYSxDQUFDO0FBQ3BCLElBQU0sMkJBQTJCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLDZCQUE2QixFQUFFO0FBQ25JLElBQU0sd0JBQU4sTUFBNEI7Q0FzQzFCLElBQUkseUJBQXlCO0VBQzNCLE9BQU8sS0FBSyxpQkFBaUI7Q0FDL0I7Q0FLQSxjQUFjO3dCQTVDZCxxQkFBb0IsT0FBTyxNQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ3JCLFlBQVksRUFDZCxXQUFXLG9CQUNiLElBQUksQ0FBQyxDQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ0wsYUFBYSxNQUFBLENBQ2YsQ0FBQyxDQUFBO3dCQUNELHFCQUFvQixJQUFBO3dCQUNwQiw0QkFBMkIsT0FBTyxNQUFNLEdBQUksWUFBWSxDQUFDLEVBQ3ZELFdBQVcsMkJBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQUNSLFVBQVMsSUFBSSxRQUFRLENBQUE7d0JBQ3JCLG1DQUFrQyxJQUFJLFFBQVEsQ0FBQTt3QkFDOUMsZ0JBQWUsT0FBTyxrQkFBa0IsQ0FBQTt3QkFDeEMsdUJBQXNCLE9BQU8sbUJBQW1CLENBQUE7d0JBQ2hELGNBQWEsT0FBTyxVQUFVLENBQUE7d0JBQzlCLGlCQUFnQixPQUFPLGFBQWEsQ0FBQTt3QkFDcEMsZ0JBQWUsT0FBTyxzQkFBc0IsQ0FBQTt3QkFDNUMsWUFBVyxPQUFPLFFBQVEsQ0FBQTt3QkFDMUIsdUJBQXNCLE9BQU8sY0FBYyxFQUN6QyxVQUFVLEtBQ1osQ0FBQyxNQUFNLElBQUE7d0JBQ1AsaUJBQWdCLE9BQU8sYUFBYSxDQUFBO3dCQUNwQyxXQUFVLE9BQU8sc0JBQXNCLEVBQ3JDLFVBQVUsS0FDWixDQUFDLEtBQUssQ0FBQyxDQUFBO3dCQUNQLDZCQUE0QixLQUFLLFFBQVEsNkJBQTZCLG1DQUFBO3dCQUN0RSx1QkFBc0IsT0FBTyxtQkFBbUIsQ0FBQTt3QkFDaEQsd0JBQXVCLE9BQU8sd0JBQXdCLEVBQ3BELFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0QsMEJBQXlCLE9BQU8sMEJBQTBCLEVBQ3hELFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0QsaUNBQWdDLE9BQU8sa0NBQWtDLEVBQ3ZFLFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0QsZ0JBQWUsQ0FBQTt3QkFJZixlQUFBLEtBQUEsQ0FBQTt3QkFDQSw0QkFBMkIsR0FBRyxLQUFLLENBQUMsQ0FBQTt3QkFDcEMscUJBQW9CLElBQUE7d0JBQ3BCLGFBQVksS0FBQTtFQUVWLE1BQU0sZUFBYyxNQUFLLEtBQUssT0FBTyxLQUFLLElBQUkscUJBQXFCLENBQUMsQ0FBQztFQUNyRSxNQUFNLGFBQVksTUFBSyxLQUFLLE9BQU8sS0FBSyxJQUFJLG1CQUFtQixDQUFDLENBQUM7RUFDakUsS0FBSyxhQUFhLG9CQUFvQjtFQUN0QyxLQUFLLGFBQWEsc0JBQXNCO0VBQ3hDLEtBQUssV0FBVyxnQkFBZ0I7R0FDOUIsS0FBSyxZQUFZO0VBQ25CLENBQUM7Q0FDSDtDQUNBLFdBQVc7O0VBQ1QsQ0FBQSxvQkFBQSxLQUFLLGlCQUFBLFFBQUEsc0JBQUEsS0FBQSxLQUFBLGtCQUFhLFNBQVM7Q0FDN0I7Q0FDQSx3QkFBd0IsU0FBUztFQUMvQixNQUFNLEtBQUssRUFBRSxLQUFLO0VBQ2xCLGdCQUFnQjs7R0FDZCxDQUFBLHFCQUFBLEtBQUssaUJBQUEsUUFBQSx1QkFBQSxLQUFBLEtBQUEsbUJBQWEsS0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNiLE9BQUEsR0FBQSxDQUFBLEdBQUE7SUFDSCxjQUFjLEtBQUssb0JBQW9CLFFBQVEsUUFBUSxNQUFNO0lBQzdELGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsUUFBUTtLQUNOLG1CQUFtQixDQUFDO0tBQ3BCLHFCQUFxQixDQUFDO0lBQ3hCO0lBQ0EsY0FBYztJQUNkO0lBQ0Esd0JBQXdCLENBQUM7SUFDekIsdUJBQXVCLENBQUM7SUFDMUIsQ0FBQztFQUNILENBQUM7Q0FDSDtDQUNBLGlCQUFpQixRQUFRO0VBQ3ZCLEtBQUssY0FBYyxJQUFJLGdCQUFnQixJQUFJO0VBQzNDLE9BQU8sS0FBSyxZQUFZLEtBQUssUUFBTyxNQUFLLE1BQU0sSUFBSSxHQUFHLFdBQVUsMkJBQTBCOztHQUN4RixJQUFJLFlBQVk7R0FDaEIsSUFBSSxxQkFBcUI7R0FDekIsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7R0FDNUMsTUFBTSxpQ0FBaUM7O0lBQ3JDLE9BQU8sQ0FBQyx3QkFBQSx3QkFBc0IsS0FBSyx1QkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQW1CLFFBQU8sdUJBQXVCO0dBQ3RGO0dBQ0EsT0FBTyxHQUFHLHNCQUFzQixDQUFDLENBQUMsS0FBSyxXQUFVLE1BQUs7O0lBQ3BELElBQUksS0FBSyxlQUFlLHVCQUF1QixJQUFJO0tBQ2pELE1BQU0scUJBQXFCLE9BQU8sY0FBYyxlQUFlLFlBQVksaUJBQWlCLHVCQUF1QixHQUFHLDZDQUE2QyxLQUFLLGlCQUFpQjtLQUN6TCxLQUFLLDJCQUEyQix3QkFBd0Isb0JBQW9CLDJCQUEyQix5QkFBeUI7S0FDaEksT0FBTztJQUNUO0lBQ0EsS0FBSyxvQkFBb0I7SUFDekIsTUFBTSwyQkFBMkIsS0FBSyx5QkFBeUI7SUFDL0QsS0FBSyxrQkFBa0IsSUFBSTtLQUN6QixJQUFJLEVBQUU7S0FDTixZQUFZLEVBQUU7S0FDZCxjQUFjLEVBQUU7S0FDaEIsa0JBQWtCLE9BQU8sRUFBRSxPQUFPLGVBQWUsV0FBVyxLQUFLLGNBQWMsTUFBTSxFQUFFLE9BQU8sVUFBVSxJQUFJLEVBQUUsT0FBTztLQUNySCxTQUFTLEVBQUU7S0FDWCxRQUFRLEVBQUU7S0FDVixvQkFBb0IsQ0FBQywyQkFBMkIsT0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUMzQyx3QkFBQSxHQUFBLENBQUEsR0FBQSxFQUNILG9CQUFvQixLQUFBLENBQ3RCO0tBQ0EsYUFBYSxnQkFBZ0IsTUFBTTtLQUNuQyx3QkFBd0IsRUFBRTtLQUMxQix1QkFBdUIsRUFBRTtJQUMzQixDQUFDO0lBQ0QsTUFBTSxnQkFBZ0IsQ0FBQyxPQUFPLGFBQWEsS0FBSyx3QkFBd0IsS0FBSyxLQUFLLG9CQUFvQjtJQUN0RyxNQUFNLHVCQUFBLHdCQUFzQixFQUFFLE9BQU8seUJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQXVCLE9BQU87SUFDbkUsSUFBSSxDQUFDLGlCQUFpQix3QkFBd0IsVUFBVTtLQUN0RCxNQUFNLFNBQVMsT0FBTyxjQUFjLGVBQWUsWUFBWSxpQkFBaUIsRUFBRSxPQUFPLGtFQUFrRTtLQUMzSixLQUFLLE9BQU8sS0FBSyxJQUFJLGtCQUFrQixFQUFFLElBQUksS0FBSyxjQUFjLFVBQVUsRUFBRSxNQUFNLEdBQUcsUUFBUSxzQkFBc0Isd0JBQXdCLENBQUM7S0FDNUksRUFBRSxRQUFRLEtBQUs7S0FDZixPQUFPO0lBQ1Q7SUFDQSxJQUFJLEtBQUssb0JBQW9CLGlCQUFpQixFQUFFLE1BQU0sR0FDcEQsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVSxNQUFLO0tBQy9CLEtBQUssT0FBTyxLQUFLLElBQUksZ0JBQWdCLEVBQUUsSUFBSSxLQUFLLGNBQWMsVUFBVSxFQUFFLFlBQVksR0FBRyxFQUFFLFFBQVEsRUFBRSxhQUFhLENBQUM7S0FDbkgsSUFBSSxFQUFFLE9BQU8sS0FBSyxjQUNoQixPQUFPO0tBRVQsT0FBTyxRQUFRLFFBQVEsQ0FBQztJQUMxQixDQUFDLEdBQUcsVUFBVSxLQUFLLHFCQUFxQixLQUFLLGNBQWMsS0FBSyxtQkFBbUIsT0FBTyxRQUFRLEtBQUssZUFBZSxLQUFLLDJCQUEyQixnQkFBZ0IsTUFBTSxHQUFHLEtBQUksTUFBSztLQUN0TCx1QkFBdUIsaUJBQWlCLEVBQUU7S0FDMUMsdUJBQXVCLG9CQUFvQixFQUFFO0tBQzdDLEtBQUssa0JBQWtCLFFBQU8sUUFBTztNQUNuQyxJQUFJLFdBQVcsRUFBRTtNQUNqQixPQUFPO0tBQ1QsQ0FBQztLQUNELEtBQUssT0FBTyxLQUFLLElBQUksdUJBQXVCLENBQUM7SUFDL0MsQ0FBQyxHQUFHLFdBQVUsVUFBUzs7MENBQUssdUJBQXVCLHVCQUF1QixvQkFBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBa0IsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLEtBQUssQ0FBQztLQUFDLEdBQUcsVUFBVTtLQUN6SSxNQUFNLG1CQUFtQixJQUFJLGlCQUFpQixFQUFFLElBQUksS0FBSyxjQUFjLFVBQVUsRUFBRSxZQUFZLEdBQUcsS0FBSyxjQUFjLFVBQVUsRUFBRSxpQkFBaUIsR0FBRyxFQUFFLGNBQWM7S0FDckssS0FBSyxPQUFPLEtBQUssZ0JBQWdCO0lBQ25DLENBQUMsQ0FBQztTQUNHLElBQUksaUJBQWlCLEtBQUssb0JBQW9CLGlCQUFpQixFQUFFLGFBQWEsR0FBRztLQUN0RixNQUFNLEVBQ0osSUFDQSxjQUNBLFFBQ0EsZUFDQSxXQUNFO0tBQ0osTUFBTSxXQUFXLElBQUksZ0JBQWdCLElBQUksS0FBSyxjQUFjLFVBQVUsWUFBWSxHQUFHLFFBQVEsYUFBYTtLQUMxRyxLQUFLLE9BQU8sS0FBSyxRQUFRO0tBQ3pCLE1BQU0saUJBQWlCLGlCQUFpQixLQUFLLG1CQUFtQixLQUFLLG1CQUFtQixDQUFDLENBQUM7S0FDMUYsS0FBSyxvQkFBb0IseUJBQUEsZUFBQSxlQUFBLENBQUEsR0FDcEIsQ0FBQSxHQUFBLENBQUEsR0FBQTtNQUNIO01BQ0EsbUJBQW1CO01BQ25CLFFBQUEsZUFBQSxlQUFBLENBQUEsR0FDSyxNQUFBLEdBQUEsQ0FBQSxHQUFBO09BQ0gsb0JBQW9CO09BQ3BCLFlBQVk7T0FDZDtNQUNGO0tBQ0EsS0FBSyxrQkFBa0IsUUFBTyxRQUFPO01BQ25DLElBQUksV0FBVztNQUNmLE9BQU87S0FDVCxDQUFDO0tBQ0QsT0FBTyxHQUFHLHNCQUFzQjtJQUNsQyxPQUFPO0tBQ0wsTUFBTSxTQUFTLE9BQU8sY0FBYyxlQUFlLFlBQVksNEZBQWlHLEVBQUUsY0FBYyxrQkFBa0IsRUFBRSxPQUFPLHlCQUF5QjtLQUNwTyxLQUFLLE9BQU8sS0FBSyxJQUFJLGtCQUFrQixFQUFFLElBQUksS0FBSyxjQUFjLFVBQVUsRUFBRSxZQUFZLEdBQUcsUUFBUSxzQkFBc0IsNEJBQTRCLENBQUM7S0FDdEosRUFBRSxRQUFRLEtBQUs7S0FDZixPQUFPO0lBQ1Q7R0FDRixDQUFDLEdBQUcsS0FBSSxNQUFLO0lBQ1gsTUFBTSxjQUFjLElBQUksaUJBQWlCLEVBQUUsSUFBSSxLQUFLLGNBQWMsVUFBVSxFQUFFLFlBQVksR0FBRyxLQUFLLGNBQWMsVUFBVSxFQUFFLGlCQUFpQixHQUFHLEVBQUUsY0FBYztJQUNoSyxLQUFLLE9BQU8sS0FBSyxXQUFXO0lBQzVCLEtBQUssb0JBQW9CLHlCQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ3BCLENBQUEsR0FBQSxDQUFBLEdBQUEsRUFDSCxRQUFRLGtCQUFrQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixLQUFLLFlBQVksRUFBQSxDQUNsRjtJQUNBLE9BQU87R0FDVCxDQUFDLEdBQUcsYUFBWSxRQUFPLEtBQUssT0FBTyxLQUFLLEdBQUcsQ0FBQyxHQUFHLFdBQVUsTUFBSztJQUM1RCx1QkFBdUIsZUFBZSxFQUFFO0lBQ3hDLElBQUksRUFBRSxnQkFBZ0IsT0FBTyxFQUFFLGlCQUFpQixXQUM5QyxNQUFNLDJCQUEyQixLQUFLLGVBQWUsRUFBRSxZQUFZO0lBRXJFLE1BQU0sWUFBWSxJQUFJLGVBQWUsRUFBRSxJQUFJLEtBQUssY0FBYyxVQUFVLEVBQUUsWUFBWSxHQUFHLEtBQUssY0FBYyxVQUFVLEVBQUUsaUJBQWlCLEdBQUcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsWUFBWTtJQUM5SyxLQUFLLE9BQU8sS0FBSyxTQUFTO0lBQzFCLElBQUksQ0FBQyx5QkFBeUIsR0FDNUIsT0FBTztJQUVULElBQUksQ0FBQyxFQUFFLGNBQWM7S0FDbkIsS0FBSywyQkFBMkIsR0FBRyxJQUFJLDJCQUEyQixhQUFhO0tBQy9FLE9BQU87SUFDVDtJQUNBLElBQUksRUFBRSxPQUFPLGtCQUFrQixXQUFXLEdBQ3hDLE9BQU8sR0FBRyxDQUFDO0lBRWIsTUFBTSxlQUFlLElBQUksYUFBYSxFQUFFLElBQUksS0FBSyxjQUFjLFVBQVUsRUFBRSxZQUFZLEdBQUcsS0FBSyxjQUFjLFVBQVUsRUFBRSxpQkFBaUIsR0FBRyxFQUFFLGNBQWM7SUFDN0osS0FBSyxPQUFPLEtBQUssWUFBWTtJQUM3QixJQUFJLENBQUMseUJBQXlCLEdBQzVCLE9BQU87SUFFVCxJQUFJLGVBQWU7SUFDbkIsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSxLQUFLLHlCQUF5QixHQUFHLElBQUk7S0FDakUsWUFBWTtNQUNWLGVBQWU7TUFDZixNQUFNLGFBQWEsSUFBSSxXQUFXLEVBQUUsSUFBSSxLQUFLLGNBQWMsVUFBVSxFQUFFLFlBQVksR0FBRyxLQUFLLGNBQWMsVUFBVSxFQUFFLGlCQUFpQixHQUFHLEVBQUUsY0FBYztNQUN6SixLQUFLLE9BQU8sS0FBSyxVQUFVO0tBQzdCO0tBQ0EsZ0JBQWdCO01BQ2QsSUFBSSxDQUFDLGNBQ0gsS0FBSywyQkFBMkIsR0FBRyxPQUFPLGNBQWMsZUFBZSxZQUFZLHVEQUF1RCxJQUFJLDJCQUEyQixrQkFBa0I7S0FFL0w7SUFDRixDQUFDLENBQUM7R0FDSixDQUFDLEdBQUcsV0FBVSxNQUFLO0lBQ2pCLE1BQU0sa0JBQWlCLFVBQVM7O0tBQzlCLE1BQU0sVUFBVSxDQUFDO0tBQ2pCLEtBQUEscUJBQUksTUFBTSxpQkFBQSxRQUFBLHVCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsbUJBQWEsa0JBQWtCOztNQUN2QyxNQUFNLGFBQUEsc0JBQVksTUFBTSxpQkFBQSxRQUFBLHdCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsb0JBQWE7S0FDdkMsT0FBTyxLQUFBLHNCQUFJLE1BQU0saUJBQUEsUUFBQSx3QkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLG9CQUFhLGVBQWU7TUFDM0MsTUFBTSxXQUFXLE1BQU07TUFDdkIsUUFBUSxLQUFLLEtBQUssYUFBYSxjQUFjLFVBQVUsTUFBTSxXQUFXLENBQUMsQ0FBQyxNQUFLLG9CQUFtQjtPQUNoRyxNQUFNLFlBQVk7TUFDcEIsQ0FBQyxDQUFDO0tBQ0o7S0FDQSxLQUFLLE1BQU0sU0FBUyxNQUFNLFVBQ3hCLFFBQVEsS0FBSyxHQUFHLGVBQWUsS0FBSyxDQUFDO0tBRXZDLE9BQU87SUFDVDtJQUNBLE1BQU0sVUFBVSxlQUFlLEVBQUUsZUFBZSxJQUFJO0lBQ3BELE9BQU8sUUFBUSxXQUFXLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxRQUFRLElBQUksT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7R0FDL0UsQ0FBQyxHQUFHLFdBQVUsTUFBSztJQUNqQixNQUFNLEVBQ0osb0JBQ0EsVUFDRSxrQkFBa0IsT0FBTyxvQkFBb0IsRUFBRSxnQkFBZ0IsRUFBRSxrQkFBa0I7SUFDdkYsS0FBSyxvQkFBb0IseUJBQXlCLElBQUEsZUFBQSxlQUFBLENBQUEsR0FDN0MsQ0FBQSxHQUFBLENBQUEsR0FBQTtLQUNILG1CQUFtQjtLQUNuQjtLQUNGO0lBQ0EsS0FBSyxrQkFBa0IsUUFBTyxRQUFPO0tBQ25DLElBQUksb0JBQW9CO0tBQ3hCLE9BQU87SUFDVCxDQUFDO0lBQ0QsT0FBTyxHQUFHLENBQUM7R0FDYixDQUFDLElBQUEseUJBQUEseUJBQUcsS0FBSyxtQ0FBQSxRQUFBLDJCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsdUJBQStCLFNBQVMsT0FBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSwwQkFBTSxNQUFLLElBQUksZ0JBQWdCLEtBQUssbUJBQW1CLENBQUMsR0FBRyxnQkFBZ0I7O0lBQzFILE1BQU0sRUFDSixpQkFDQSxtQkFDRTtJQUNKLE1BQU0seUJBQUEsd0JBQXdCLEtBQUssMEJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFBLEtBQUEsTUFBdUIsS0FBSyxxQkFBcUIsZ0JBQWdCLE1BQU0sZUFBZSxJQUFJO0lBQzdILE9BQU8sd0JBQXdCLEtBQUsscUJBQXFCLENBQUMsQ0FBQyxLQUFLLFVBQVUsc0JBQXNCLENBQUMsSUFBSSxHQUFHLHNCQUFzQjtHQUNoSSxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUcsV0FBVSxNQUFLO0lBQzFCLFlBQVk7SUFDWixLQUFLLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixDQUFDO0lBQzNDLE1BQU0sV0FBVyx1QkFBdUIsc0JBQXNCO0lBQzlELE9BQU8sV0FBVyxLQUFLLFNBQVMsV0FBVyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUM7R0FDdkQsQ0FBQyxHQUFHLEtBQUksTUFBSzs7SUFDWCxJQUFJLGVBQWUsT0FBTyxvQkFBb0IsdUJBQXVCLG1CQUFtQix1QkFBdUIscUJBQW9CLFFBQU8sS0FBSyxPQUFPLEtBQUssR0FBRyxHQUFHLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxTQUFTLEtBQUssWUFBWTtJQUNyTixDQUFBLHdCQUFBLEVBQUUsd0JBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQW9CLE1BQU07SUFDNUIsSUFBSSxDQUFDLHlCQUF5QixHQUM1QjtJQUVGLHFCQUFxQjtJQUNyQixLQUFLLGtCQUFrQixRQUFPLFFBQU87S0FDbkMsSUFBSSxRQUFRO0tBQ1osT0FBTztJQUNULENBQUM7SUFDRCxLQUFLLHlCQUF5QixJQUFJLFVBQVUsS0FBSyxpQkFBaUIsQ0FBQztJQUNuRSxLQUFLLE9BQU8sS0FBSyxJQUFJLGNBQWMsRUFBRSxJQUFJLEtBQUssY0FBYyxVQUFVLEVBQUUsWUFBWSxHQUFHLEtBQUssY0FBYyxVQUFVLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztJQUN6SSxDQUFBLHNCQUFBLEtBQUssbUJBQUEsUUFBQSx3QkFBQSxLQUFBLEtBQUEsb0JBQWUsWUFBWSxFQUFFLGtCQUFrQixRQUFRO0lBQzVELEVBQUUsUUFBUSxJQUFJO0dBQ2hCLENBQUMsR0FBRyxVQUFVLHdCQUF3QixnQkFBZ0IsTUFBTSxDQUFDLENBQUMsS0FBSyxhQUFhLENBQUMsc0JBQXNCLFNBQVMsR0FBRyxVQUFVO0lBQzNILEtBQUssMkJBQTJCLHdCQUF3QixnQkFBZ0IsT0FBTyxTQUFTLElBQUksMkJBQTJCLE9BQU87R0FDaEksQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQ1IsZ0JBQWdCO0lBQ2QscUJBQXFCO0dBQ3ZCLEVBQ0YsQ0FBQyxHQUFHLFVBQVUsS0FBSyxnQ0FBZ0MsS0FBSyxLQUFJLFFBQU87SUFDakUsTUFBTTtHQUNSLENBQUMsQ0FBQyxDQUFDLEdBQUcsZUFBZTs7SUFDbkIsZ0JBQWdCLE1BQU07SUFDdEIsSUFBSSxDQUFDLG9CQUFvQjtLQUN2QixNQUFNLG9CQUFvQixPQUFPLGNBQWMsZUFBZSxZQUFZLGlCQUFpQix1QkFBdUIsR0FBRyw2Q0FBNkMsS0FBSyxpQkFBaUI7S0FDeEwsS0FBSywyQkFBMkIsd0JBQXdCLG1CQUFtQiwyQkFBMkIseUJBQXlCO0lBQ2pJO0lBQ0EsTUFBQSx5QkFBSSxLQUFLLHVCQUFBLFFBQUEsMkJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSx1QkFBbUIsUUFBTyx1QkFBdUIsSUFBSTtLQUM1RCxLQUFLLGtCQUFrQixJQUFJLElBQUk7S0FDL0IsS0FBSyxvQkFBb0I7SUFDM0I7R0FDRixDQUFDLEdBQUcsWUFBVyxNQUFLO0lBQ2xCLHFCQUFxQjtJQUNyQiwwQkFBMEIsc0JBQXNCO0lBQ2hELElBQUksS0FBSyxXQUFXO0tBQ2xCLHVCQUF1QixRQUFRLEtBQUs7S0FDcEMsT0FBTztJQUNUO0lBQ0EsSUFBSSwyQkFBMkIsQ0FBQyxHQUFHO0tBQ2pDLEtBQUssT0FBTyxLQUFLLElBQUksaUJBQWlCLHVCQUF1QixJQUFJLEtBQUssY0FBYyxVQUFVLHVCQUF1QixZQUFZLEdBQUcsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLENBQUM7S0FDbEssSUFBSSxDQUFDLHNDQUFzQyxDQUFDLEdBQzFDLHVCQUF1QixRQUFRLEtBQUs7VUFFcEMsS0FBSyxPQUFPLEtBQUssSUFBSSxnQkFBZ0IsRUFBRSxLQUFLLEVBQUUseUJBQXlCLENBQUM7SUFFNUUsT0FBTzs7S0FDTCxNQUFNLGtCQUFrQixJQUFJLGdCQUFnQix1QkFBdUIsSUFBSSxLQUFLLGNBQWMsVUFBVSx1QkFBdUIsWUFBWSxHQUFHLElBQUEseUJBQUcsdUJBQXVCLG9CQUFBLFFBQUEsMkJBQUEsS0FBQSxJQUFBLHlCQUFrQixLQUFBLENBQVM7S0FDL0wsSUFBSTtNQUNGLE1BQU0sK0JBQStCLHNCQUFzQixLQUFLLDJCQUEyQjs7NENBQUssNEJBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFBLEtBQUEsTUFBeUIsZUFBZTtPQUFDO01BQ3pJLElBQUksd0NBQXdDLGlCQUFpQjtPQUMzRCxNQUFNLEVBQ0osU0FDQSxxQkFDRSwyQkFBMkIsS0FBSyxlQUFlLDRCQUE0QjtPQUMvRSxLQUFLLE9BQU8sS0FBSyxJQUFJLGlCQUFpQix1QkFBdUIsSUFBSSxLQUFLLGNBQWMsVUFBVSx1QkFBdUIsWUFBWSxHQUFHLFNBQVMsZ0JBQWdCLENBQUM7T0FDOUosS0FBSyxPQUFPLEtBQUssSUFBSSxnQkFBZ0IsNkJBQTZCLFlBQVksNkJBQTZCLHlCQUF5QixDQUFDO01BQ3ZJLE9BQU87T0FDTCxLQUFLLE9BQU8sS0FBSyxlQUFlO09BQ2hDLE1BQU07TUFDUjtLQUNGLFNBQVMsSUFBSTtNQUNYLElBQUksS0FBSyxRQUFRLGlDQUNmLHVCQUF1QixRQUFRLEtBQUs7V0FFcEMsdUJBQXVCLE9BQU8sRUFBRTtLQUVwQztJQUNGO0lBQ0EsT0FBTztHQUNULENBQUMsQ0FBQztFQUNKLENBQUMsQ0FBQztDQUNKO0NBQ0EsMkJBQTJCLEdBQUcsUUFBUSxNQUFNO0VBQzFDLDBCQUEwQixDQUFDO0VBQzNCLE1BQU0sWUFBWSxJQUFJLGlCQUFpQixFQUFFLElBQUksS0FBSyxjQUFjLFVBQVUsRUFBRSxZQUFZLEdBQUcsUUFBUSxJQUFJO0VBQ3ZHLEtBQUssT0FBTyxLQUFLLFNBQVM7RUFDMUIsRUFBRSxRQUFRLEtBQUs7Q0FDakI7Q0FDQSwwQkFBMEI7O0VBQ3hCLFNBQUEseUJBQU8sS0FBSyx1QkFBQSxRQUFBLDJCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsdUJBQW1CLGFBQWEsU0FBUyxTQUFBLHlCQUFNLEtBQUssdUJBQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHVCQUFtQixlQUFlLFNBQVM7Q0FDN0c7Q0FDQSxzQkFBc0I7O0VBQ3BCLE1BQU0sb0JBQW9CLEtBQUssb0JBQW9CLFFBQVEsS0FBSyxjQUFjLE1BQU0sS0FBSyxTQUFTLEtBQUssSUFBSSxDQUFDLENBQUM7RUFDN0csTUFBTSxvQkFBb0IsVUFBVSxLQUFLLGlCQUFpQjtFQUMxRCxNQUFNLG9CQUFBLHdCQUFBLHNCQUFBLFFBQUEsc0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBbUIsa0JBQW1CLHNCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFBLHNCQUFBLFFBQUEsc0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBb0Isa0JBQW1CO0VBQ25GLE9BQU8sa0JBQWtCLFNBQVMsT0FBQSxxQkFBQSxRQUFBLHFCQUFBLEtBQUEsSUFBQSxLQUFBLElBQU0saUJBQWtCLFNBQVMsTUFBSyxFQUFBLHNCQUFBLFFBQUEsc0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQyxrQkFBbUIsT0FBTztDQUNyRztBQVFGOzt1Q0FQUyxRQUFPLFNBQVMsOEJBQThCLG1CQUFtQjtDQUN0RSxPQUFPLEtBQUsscUJBQXFCb0Isd0JBQXVCO0FBQzFELENBQUE7dUNBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0EsdUJBQXNCO0FBQ2pDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjcEIsaUJBQXFCLHVCQUF1QixDQUFDLEVBQzlGLE1BQU0sUUFDUixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFDcEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyw2QkFBNkIsUUFBUTtDQUM1QyxPQUFPLFdBQVc7QUFDcEI7QUFDQSxTQUFTLDBCQUEwQixHQUFHO0NBQ3BDLElBQUksQ0FBQyxFQUFFLG9CQUNMO0NBRUYsS0FBSyxNQUFNLEtBQUssRUFBRSxvQkFBb0I7O0VBQ3BDLENBQUEsb0JBQUEsRUFBRSxvQkFBQSxRQUFBLHNCQUFBLEtBQUEsS0FBQSxrQkFBZ0IsUUFBUTtDQUM1QjtBQUNGO0FBQ0EsSUFBTSx5QkFBeUIsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVkseUJBQXlCLEVBQUU7QUFDN0gsU0FBUyxxQkFBcUIsb0JBQW9CLGFBQWEsUUFBUTs7Q0FDckUsTUFBTSwrQkFBZSxJQUFJLElBQUk7Q0FDN0IsSUFBSSxZQUFZLFNBQVMsTUFDdkIsbUJBQW1CLFlBQVksU0FBUyxNQUFNLFlBQVk7Q0FFNUQsTUFBTSxrQkFBQSx3QkFBZ0IsbUJBQW1CLGdDQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxzQkFBQSxLQUFBLGtCQUE2QixNQUFLLENBQUM7Q0FDNUUsS0FBSyxNQUFNLFVBQVUsZUFBZTs7RUFDbEMsTUFBTSxpQkFBaUI7RUFDdkIsSUFBQSxtQkFBQSxRQUFBLG1CQUFBLEtBQUEsTUFBQSx3QkFBSSxlQUFnQixXQUFBLFFBQUEsMEJBQUEsS0FBQSxNQUFBLHdCQUFBLHNCQUFPLFdBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFPO1FBQzNCLE1BQU0sWUFBWSxlQUFlLE1BQU0sTUFBTSxTQUFTLGNBQ3pELElBQUksU0FBUyxhQUNYLGFBQWEsSUFBSSxTQUFTLFdBQVc7RUFBQTtDQUk3QztDQUNBLHVCQUF1QixRQUFRLGNBQWMsb0JBQW9CLEtBQUs7QUFDeEU7QUFDQSxTQUFTLG1CQUFtQixVQUFVLGNBQWM7Q0FDbEQsSUFBSSxTQUFTLGFBQ1gsYUFBYSxJQUFJLFNBQVMsV0FBVztDQUV2QyxLQUFLLE1BQU0sU0FBUyxTQUFTLFVBQzNCLG1CQUFtQixPQUFPLFlBQVk7QUFFMUM7QUFDQSxTQUFTLHVCQUF1QixRQUFRLGNBQWMsVUFBVSx1QkFBdUI7Q0FDckYsS0FBSyxNQUFNLFNBQVMsUUFBUTs7RUFDMUIsTUFBTSw0QkFBNEIseUJBQXlCLENBQUMsR0FBRyxNQUFNLGFBQWEsTUFBTSxvQkFBb0IsQ0FBQyxhQUFhLElBQUksS0FBSyxPQUFBLHlCQUFBLHlCQUFNLFNBQVMsMkJBQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHVCQUFBLEtBQUEsVUFBd0IsS0FBSyxPQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFLO0VBQ3BMLElBQUksTUFBTSxVQUNSLHVCQUF1QixNQUFNLFVBQVUsY0FBYyxVQUFVLHlCQUF5QjtFQUUxRixJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sZUFDOUIsdUJBQXVCLE1BQU0sZUFBZSxjQUFjLFVBQVUseUJBQXlCO0VBRS9GLElBQUksMkJBQTJCO0dBQzdCLElBQUksTUFBTSxXQUFXO0lBQ25CLE1BQU0sVUFBVSxRQUFRO0lBQ3hCLE1BQU0sWUFBWSxLQUFBO0dBQ3BCO0dBQ0EsSUFBSSxNQUFNLGlCQUFpQjtJQUN6QixNQUFNLGdCQUFnQixRQUFRO0lBQzlCLE1BQU0sa0JBQWtCLEtBQUE7R0FDMUI7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLDJCQUEyQixRQUFRO0NBQzFDLE1BQU0saUJBQWlCO0NBQ3ZCLElBQUksa0JBQWtCLGVBQWUsY0FBYzs7RUFDakQsZUFBZSxhQUFhLFFBQVE7RUFDcEMsQ0FBQSx5QkFBQSxlQUFlLE1BQU0sTUFBTSxvQkFBQSxRQUFBLDJCQUFBLEtBQUEsS0FBQSx1QkFBZ0IsUUFBUTtDQUNyRDtBQUNGO0FBQ0EsSUFBTSxxQkFBTixNQUF5QixDQVF6Qjs7b0NBUFMsUUFBTyxTQUFTLDJCQUEyQixtQkFBbUI7Q0FDbkUsT0FBTyxLQUFLLHFCQUFxQnFCLHFCQUFvQjtBQUN2RCxDQUFBO29DQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLHNCQUFzQixPQUFPLHlCQUF5QixFQUFBLENBQUc7QUFDM0QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNyQixpQkFBcUIsb0JBQW9CLENBQUM7RUFDM0YsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLGVBQWUsT0FBTyx5QkFBeUIsRUFDakQsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSx5QkFBTixNQUE2QjtDQUMzQixhQUFhLE9BQU87RUFDbEIsT0FBTztDQUNUO0NBQ0EsTUFBTSxPQUFPLGNBQWMsQ0FBQztDQUM1QixhQUFhLE9BQU87RUFDbEIsT0FBTztDQUNUO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsT0FBTztDQUNUO0NBQ0EsaUJBQWlCLFFBQVEsTUFBTTtFQUM3QixPQUFPLE9BQU8sZ0JBQWdCLEtBQUs7Q0FDckM7Q0FDQSxzQkFBc0IsT0FBTztFQUMzQixPQUFPO0NBQ1Q7QUFDRjtBQUNBLElBQU0sNEJBQU4sY0FBd0MsdUJBQXVCLENBUS9EOzsyQ0FQUyxRQUFPLFNBQVMsa0NBQWtDLG1CQUFtQjtDQUMxRSxPQUFPLEtBQUsscUJBQXFCc0IsNEJBQTJCO0FBQzlELENBQUE7MkNBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0EsMkJBQTBCO0FBQ3JDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjdEIsaUJBQXFCLDJCQUEyQixDQUFDLEVBQ2xHLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILElBQU0sZUFBTixNQUFtQjs7d0JBQ2pCLGlCQUFnQixPQUFPLGFBQWEsQ0FBQTt3QkFDcEMsV0FBVSxPQUFPLHNCQUFzQixFQUNyQyxVQUFVLEtBQ1osQ0FBQyxLQUFLLENBQUMsQ0FBQTt3QkFDUCxnQ0FBK0IsS0FBSyxRQUFRLGdDQUFnQyxTQUFBO3dCQUM1RSxZQUFXLE9BQU8sUUFBUSxDQUFBO3dCQUMxQix1QkFBc0IsT0FBTyxtQkFBbUIsQ0FBQTt3QkFDaEQscUJBQW9CLEtBQUssUUFBUSxxQkFBcUIsVUFBQTt3QkFDdEQsa0JBQWlCLElBQUksUUFBUSxDQUFBO3dCQUk3QixjQUFhLEtBQUssY0FBQTt3QkFtQ2xCLGVBQWMsaUJBQWlCLE1BQU0sT0FBTyxtQkFBbUIsQ0FBQyxDQUFBO3dCQUloRSxpQkFBZ0IsS0FBSyxtQkFBbUIsQ0FBQTs7Q0ExQ3hDLG9CQUFvQjtFQUNsQixPQUFPLEtBQUs7Q0FDZDtDQUVBLGdCQUFnQjtFQUNkLE9BQU8sS0FBSztDQUNkO0NBQ0Esa0JBQWtCLEVBQ2hCLFVBQ0EsWUFDQSxvQkFDQztFQUNELE1BQU0sU0FBUyxhQUFhLEtBQUEsSUFBWSxLQUFLLG9CQUFvQixNQUFNLFVBQVUsVUFBVSxJQUFJO0VBQy9GLE1BQU0sTUFBTSxxQkFBQSxRQUFBLHFCQUFBLEtBQUEsSUFBQSxtQkFBb0I7RUFFaEMsT0FEYSxlQUFlLFVBQVUsS0FBSyxjQUFjLFVBQVUsR0FBRyxJQUFJO0NBRTVFO0NBQ0EsZUFBZSxZQUFZO0VBQ3pCLEtBQUEsZUFBQSxRQUFBLGVBQUEsS0FBQSxJQUFBLEtBQUEsSUFBSSxXQUFZLHNCQUFxQixLQUFBLE1BQUEsZUFBQSxRQUFBLGVBQUEsS0FBQSxJQUFBLEtBQUEsSUFBYSxXQUFZLGNBQWEsS0FBQSxHQUN6RSxPQUFPLENBQUM7RUFFVixPQUFPLEVBQ0wsWUFBWSxLQUFLLGNBQWMsVUFBVSxXQUFXLFFBQVEsRUFDOUQ7Q0FDRjtDQUNBLGlCQUFpQixFQUNmLG1CQUNBLFVBQ0EsY0FDQztFQUNELElBQUksWUFBWSxtQkFBbUI7R0FDakMsS0FBSyxpQkFBaUI7R0FDdEIsS0FBSyxhQUFhLEtBQUssb0JBQW9CLE1BQU0sVUFBVSxVQUFVO0dBQ3JFLEtBQUssY0FBYztFQUNyQixPQUNFLEtBQUssYUFBYTtDQUV0QjtDQUVBLGlCQUFpQjtFQUNmLE9BQU8sS0FBSztDQUNkO0NBRUEsSUFBSSxlQUFlO0VBQ2pCLE9BQU8sS0FBSztDQUNkO0NBQ0EscUJBQXFCO0VBQ25CLEtBQUssZ0JBQWdCLEtBQUssbUJBQW1CO0NBQy9DO0NBQ0EscUJBQXFCO0VBQ25CLE9BQU87R0FDTCxZQUFZLEtBQUs7R0FDakIsZ0JBQWdCLEtBQUs7R0FDckIsYUFBYSxLQUFLO0VBQ3BCO0NBQ0Y7Q0FDQSxnQkFBZ0I7RUFDZCxPQUFPLEtBQUssU0FBUyxTQUFTO0NBQ2hDO0FBUUY7OzhCQVBTLFFBQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0NBQzdELE9BQU8sS0FBSyxxQkFBcUJ1QixlQUFjO0FBQ2pELENBQUE7OEJBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1Asc0JBQXNCLE9BQU8sbUJBQW1CLEVBQUEsQ0FBRztBQUNyRCxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY3ZCLGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLGVBQWUsT0FBTyxtQkFBbUIsRUFDM0MsQ0FBQztDQUNILENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxzQkFBTixjQUFrQyxhQUFhOzs7d0JBQzdDLGlCQUFnQixDQUFBO3dCQUNoQixvQkFBbUIsRUFBQTs7Q0FDbkIsSUFBSSxnQkFBZ0I7O0VBQ2xCLElBQUksS0FBSyxpQ0FBaUMsWUFDeEMsT0FBTyxLQUFLO0VBRWQsUUFBQSx3QkFBQSxzQkFBTyxLQUFLLGNBQWMsT0FBQSxRQUFBLHdCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsb0JBQUcsbUJBQUEsUUFBQSx5QkFBQSxLQUFBLElBQUEsdUJBQWlCLEtBQUs7Q0FDckQ7Q0FDQSw0Q0FBNEMsVUFBVTtFQUNwRCxPQUFPLEtBQUssU0FBUyxXQUFVLFVBQVM7R0FDdEMsSUFBSSxNQUFNLFlBQVksWUFDcEIsaUJBQWlCO0lBQ2YsU0FBUyxNQUFNLFFBQVEsTUFBTSxPQUFPLFlBQVksRUFDOUMsWUFBWSxLQUNkLENBQUM7R0FDSCxDQUFDO0VBRUwsQ0FBQztDQUNIO0NBQ0Esa0JBQWtCLEdBQUcsbUJBQW1CO0VBQ3RDLElBQUksYUFBYSxpQkFDZixLQUFLLG1CQUFtQjtPQUNuQixJQUFJLGFBQWEsbUJBQ3RCLEtBQUssaUJBQWlCLGlCQUFpQjtPQUNsQyxJQUFJLGFBQWE7T0FDbEIsS0FBSyxzQkFBc0I7UUFDekIsQ0FBQyxrQkFBa0IsT0FBTyxvQkFDNUIsS0FBSyxjQUFjLEtBQUssa0JBQWtCLGlCQUFpQixHQUFHLGlCQUFpQjtHQUFBO0VBQ2pGLE9BRUcsSUFBSSxhQUFhLHNCQUFzQjtHQUM1QyxLQUFLLGlCQUFpQixpQkFBaUI7R0FDdkMsSUFBSSxLQUFLLHNCQUFzQixjQUFjLENBQUMsa0JBQWtCLE9BQU8sb0JBQ3JFLEtBQUssY0FBYyxLQUFLLGtCQUFrQixpQkFBaUIsR0FBRyxpQkFBaUI7RUFFbkYsT0FBTyxJQUFJLGFBQWEsb0JBQW9CLENBQUMsbUJBQW1CLENBQUMsR0FDL0QsS0FBSyxlQUFlLGlCQUFpQjtPQUNoQyxJQUFJLGFBQWEsaUJBQ3RCLEtBQUssZUFBZSxtQkFBbUIsSUFBSTtPQUN0QyxJQUFJLGFBQWEsZUFBZTtHQUNyQyxLQUFLLG1CQUFtQixFQUFFO0dBQzFCLEtBQUssZ0JBQWdCLEtBQUs7RUFDNUI7Q0FDRjtDQUNBLGNBQWMsTUFBTSxZQUFZO0VBQzlCLE1BQU0sRUFDSixRQUNBLE9BQ0U7RUFDSixNQUFNLEVBQ0osWUFDQSxVQUNFO0VBQ0osSUFBSSxLQUFLLFNBQVMscUJBQXFCLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUM1RCxNQUFNLHVCQUF1QixLQUFLO0dBQ2xDLE1BQU0sV0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNELEtBQUEsR0FDQSxLQUFLLHNCQUFzQixJQUFJLHNCQUFzQixVQUFVLENBQ3BFO0dBQ0EsS0FBSyxTQUFTLGFBQWEsTUFBTSxJQUFJLFFBQVE7RUFDL0MsT0FBTztHQUNMLE1BQU0sV0FBQSxlQUFBLGVBQUEsQ0FBQSxHQUNELEtBQUEsR0FDQSxLQUFLLHNCQUFzQixJQUFJLEtBQUssZ0JBQWdCLEdBQUcsVUFBVSxDQUN0RTtHQUNBLEtBQUssU0FBUyxHQUFHLE1BQU0sSUFBSSxRQUFRO0VBQ3JDO0NBQ0Y7Q0FDQSxlQUFlLFlBQVksMkJBQTJCLE9BQU87RUFDM0QsSUFBSSxLQUFLLGlDQUFpQyxZQUFZO0dBQ3BELE1BQU0sdUJBQXVCLEtBQUs7R0FDbEMsTUFBTSxxQkFBcUIsS0FBSyxnQkFBZ0I7R0FDaEQsSUFBSSx1QkFBdUIsR0FDekIsS0FBSyxTQUFTLFVBQVUsa0JBQWtCO1FBQ3JDLElBQUksS0FBSyxrQkFBa0IsTUFBTSxXQUFXLFlBQVksdUJBQXVCLEdBQUc7SUFDdkYsS0FBSyxtQkFBbUIsVUFBVTtJQUNsQyxLQUFLLHlCQUF5QjtHQUNoQztFQUNGLE9BQU8sSUFBSSxLQUFLLGlDQUFpQyxXQUFXO0dBQzFELElBQUksMEJBQ0YsS0FBSyxtQkFBbUIsVUFBVTtHQUVwQyxLQUFLLHlCQUF5QjtFQUNoQztDQUNGO0NBQ0EsbUJBQW1CLEVBQ2pCLFlBQ0M7RUFDRCxLQUFLLGNBQWMsS0FBSyxhQUFhO0VBQ3JDLEtBQUssaUJBQWlCLEtBQUssYUFBYTtFQUN4QyxLQUFLLGFBQWEsS0FBSyxvQkFBb0IsTUFBTSxLQUFLLGdCQUFnQixhQUFBLFFBQUEsYUFBQSxLQUFBLElBQUEsV0FBWSxLQUFLLFVBQVU7Q0FDbkc7Q0FDQSwyQkFBMkI7RUFDekIsS0FBSyxTQUFTLGFBQWEsS0FBSyxjQUFjLFVBQVUsS0FBSyxjQUFjLENBQUMsR0FBRyxJQUFJLEtBQUssc0JBQXNCLEtBQUssa0JBQWtCLEtBQUssYUFBYSxDQUFDO0NBQzFKO0NBQ0Esc0JBQXNCLGNBQWMsY0FBYyxZQUFZO0VBQzVELElBQUksS0FBSyxpQ0FBaUMsWUFDeEMsT0FBQSxlQUFBO0dBQ0U7R0FDQSxlQUFlO0tBQ1osS0FBSyxlQUFlLFVBQVUsQ0FDbkM7RUFFRixPQUFBLGVBQUEsRUFDRSxhQUFBLEdBQ0csS0FBSyxlQUFlLFVBQVUsQ0FDbkM7Q0FDRjtBQVFGOztxQ0FQUyxRQUFPLFNBQVMsNEJBQTRCLG1CQUFtQjtDQUNwRSxPQUFPLEtBQUsscUJBQXFCd0Isc0JBQXFCO0FBQ3hELENBQUE7cUNBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0EscUJBQW9CO0FBQy9CLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjeEIsaUJBQXFCLHFCQUFxQixDQUFDLEVBQzVGLE1BQU0sUUFDUixDQUFDLEdBQUcsTUFBTSxJQUFJO0FBQ2hCLEVBQUEsQ0FBRztBQUNILFNBQVMsb0JBQW9CLFFBQVEsUUFBUTtDQUMzQyxPQUFPLE9BQU8sS0FBSyxRQUFPLE1BQUssYUFBYSxpQkFBaUIsYUFBYSxvQkFBb0IsYUFBYSxtQkFBbUIsYUFBYSxpQkFBaUIsR0FBRyxLQUFJLE1BQUs7RUFDdEssSUFBSSxhQUFhLGlCQUFpQixhQUFhLG1CQUM3QyxPQUFPO0VBR1QsUUFEb0IsYUFBYSxtQkFBbUIsRUFBRSxTQUFTLDJCQUEyQixZQUFZLEVBQUUsU0FBUywyQkFBMkIsNEJBQTRCLFNBQ25KLElBQUk7Q0FDM0IsQ0FBQyxHQUFHLFFBQU8sV0FBVSxXQUFXLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0VBQzNELE9BQU87Q0FDVCxDQUFDO0FBQ0g7QUFDQSxJQUFNLFNBQU4sTUFBYTtDQUNYLElBQUksaUJBQWlCO0VBQ25CLE9BQU8sS0FBSyxhQUFhLGtCQUFrQjtDQUM3QztDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxhQUFhLGNBQWM7Q0FDekM7Q0FnQkEsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLGNBQWM7RUFDaEIsT0FBTyxLQUFLLGFBQWEsZUFBZTtDQUMxQztDQWNBLGNBQWM7O3dCQWxDZCxZQUFXLEtBQUE7d0JBQ1gsMkNBQUEsS0FBQSxDQUFBO3dCQUNBLFdBQVUsT0FBT3lCLE9BQVEsQ0FBQTt3QkFDekIsZ0JBQWUsT0FBTyxZQUFZLENBQUE7d0JBQ2xDLFdBQVUsT0FBTyxzQkFBc0IsRUFDckMsVUFBVSxLQUNaLENBQUMsS0FBSyxDQUFDLENBQUE7d0JBQ1AsZ0JBQWUsT0FBT0Msb0JBQXFCLENBQUE7d0JBQzNDLHFCQUFvQixLQUFLLFFBQVEscUJBQXFCLFVBQUE7d0JBQ3RELHlCQUF3QixPQUFPLHFCQUFxQixDQUFBO3dCQUNwRCxpQkFBZ0IsT0FBTyxhQUFhLENBQUE7d0JBQ3BDLFlBQVcsT0FBTyxRQUFRLENBQUE7d0JBQzFCLHVCQUFzQixPQUFPLG1CQUFtQixDQUFBO3dCQUNoRCxZQUFXLE9BQU8sbUJBQW1CLENBQUE7d0JBQ3JDLFdBQVUsSUFBSSxRQUFRLENBQUE7d0JBT3RCLGFBQVksS0FBQTt3QkFDWixzQkFBcUIsT0FBTyxrQkFBa0IsQ0FBQTt3QkFDOUMsbUJBQWtCLE9BQU8sd0JBQXdCLEVBQy9DLFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0QsdUJBQXNCLEtBQUssUUFBUSx1QkFBdUIsUUFBQTt3QkFDMUQsV0FBQSxnQkFBQSxVQUFTLE9BQU8sUUFBUSxFQUN0QixVQUFVLEtBQ1osQ0FBQyxPQUFBLFFBQUEsWUFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLFFBQUcsS0FBSyxPQUFBLFFBQUEsaUJBQUEsS0FBQSxJQUFBLGVBQUssQ0FBQyxDQUFBO3dCQUNmLGdDQUErQixDQUFDLENBQUMsT0FBTyxjQUFjLEVBQ3BELFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0QscUJBQW9CLEtBQUssc0JBQXNCLGtCQUFrQixXQUFXLENBQUE7d0JBUTVFLHNCQUFxQixJQUFJLGFBQWEsQ0FBQTtFQU5wQyxLQUFLLFlBQVksS0FBSyxNQUFNO0VBQzVCLEtBQUssc0JBQXNCLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQzFELFFBQU8sTUFBSyxDQUFDLEVBQ2YsQ0FBQztFQUNELEtBQUssNEJBQTRCO0NBQ25DO0NBRUEsOEJBQThCO0VBQzVCLE1BQU0sZUFBZSxLQUFLLHNCQUFzQixPQUFPLFdBQVUsTUFBSztHQUNwRSxJQUFJO0lBQ0YsTUFBTSxvQkFBb0IsS0FBSyxzQkFBc0I7SUFDckQsTUFBTSxvQkFBb0IsVUFBVSxLQUFLLHNCQUFzQixpQkFBaUI7SUFDaEYsSUFBSSxzQkFBc0IsUUFBUSxzQkFBc0IsTUFBTTtLQUM1RCxLQUFLLGFBQWEsa0JBQWtCLEdBQUcsaUJBQWlCO0tBQ3hELElBQUksYUFBYSxvQkFBb0IsRUFBRSxTQUFTLDJCQUEyQixZQUFZLEVBQUUsU0FBUywyQkFBMkIsMkJBQzNILEtBQUssWUFBWTtVQUNaLElBQUksYUFBYSxlQUFlOztNQUNyQyxLQUFLLFlBQVk7TUFDakIsQ0FBQSx3QkFBQSxLQUFLLHFCQUFBLFFBQUEsMEJBQUEsS0FBQSxLQUFBLHNCQUFBLEtBQUEsTUFBa0IsS0FBSyxvQkFBb0IsS0FBSyxhQUFhLEtBQUssTUFBTTtLQUMvRSxPQUFPLElBQUksYUFBYSxpQkFBaUI7TUFDdkMsTUFBTSxPQUFPLEVBQUU7TUFDZixNQUFNLGFBQWEsS0FBSyxvQkFBb0IsTUFBTSxFQUFFLEtBQUssa0JBQWtCLGFBQWE7TUFDeEYsTUFBTSxTQUFBLGVBQUE7T0FDSixRQUFRLGtCQUFrQixPQUFPO09BQ2pDLFlBQVksa0JBQWtCLE9BQU87T0FDckMsTUFBTSxrQkFBa0IsT0FBTztPQUMvQixvQkFBb0Isa0JBQWtCLE9BQU87T0FDN0MsWUFBWSxrQkFBa0IsT0FBTyxjQUFjLEtBQUssc0JBQXNCLFdBQVcsNkJBQTZCLGtCQUFrQixNQUFNO1NBQzNJLElBQ0w7TUFDQSxLQUFLLG1CQUFtQixZQUFZLHVCQUF1QixNQUFNLFFBQVE7T0FDdkUsU0FBUyxrQkFBa0I7T0FDM0IsUUFBUSxrQkFBa0I7T0FDMUIsU0FBUyxrQkFBa0I7TUFDN0IsQ0FBQztLQUNIO0lBQ0Y7SUFDQSxJQUFJLG9CQUFvQixDQUFDLEdBQ3ZCLEtBQUssUUFBUSxLQUFLLENBQUM7R0FFdkIsU0FBUyxHQUFHO0lBQ1YsS0FBSyxzQkFBc0IsZ0NBQWdDLEtBQUssQ0FBQztHQUNuRTtFQUNGLENBQUM7RUFDRCxLQUFLLG1CQUFtQixJQUFJLFlBQVk7Q0FDMUM7Q0FDQSx1QkFBdUIsbUJBQW1CO0VBQ3hDLEtBQUssWUFBWSxLQUFLLFlBQVk7RUFDbEMsS0FBSyxzQkFBc0Isb0JBQW9CO0NBQ2pEO0NBQ0Esb0JBQW9CO0VBQ2xCLEtBQUssNEJBQTRCO0VBQ2pDLElBQUksQ0FBQyxLQUFLLHNCQUFzQix3QkFDOUIsS0FBSywwQkFBMEIsS0FBSyxTQUFTLEtBQUssSUFBSSxHQUFHLHVCQUF1QixLQUFLLGFBQWEsY0FBYyxHQUFHLEVBQ2pILFlBQVksS0FDZCxDQUFDO0NBRUw7Q0FDQSw4QkFBOEI7O0VBQzVCLENBQUEsd0JBQUEsS0FBSyw2Q0FBQSxRQUFBLDBCQUFBLEtBQUEsTUFBTCxLQUFLLDBDQUE0QyxLQUFLLGFBQWEsNkNBQTZDLEtBQUssT0FBTyxRQUFRLFdBQVc7R0FDN0ksS0FBSywwQkFBMEIsS0FBSyxRQUFRLE9BQU8sTUFBTTtFQUMzRCxDQUFDO0NBQ0g7Q0FDQSwwQkFBMEIsS0FBSyxRQUFRLE9BQU8sUUFBUTs7RUFDcEQsTUFBTSxpQkFBQSxVQUFBLFFBQUEsVUFBQSxLQUFBLElBQUEsS0FBQSxJQUFnQixNQUFPLGdCQUFlLFFBQVE7RUFDcEQsTUFBTSxhQUFBLG9CQUFBLFVBQUEsUUFBQSxVQUFBLEtBQUEsSUFBQSxLQUFBLElBQVksTUFBTyxnQkFBQSxRQUFBLHNCQUFBLEtBQUEsSUFBQSxvQkFBYztFQUN2QyxJQUFBLFVBQUEsUUFBQSxVQUFBLEtBQUEsSUFBQSxLQUFBLElBQUksTUFBTyxZQUNULFNBQUEsZUFBQSxlQUFBLENBQUEsR0FDSyxNQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ0gsWUFBWSxJQUFBLENBQ2Q7RUFFRixJQUFJLE9BQU87R0FDVCxNQUFNLFlBQUEsZUFBQSxDQUFBLEdBQ0QsS0FDTDtHQUNBLE9BQU8sVUFBVTtHQUNqQixPQUFPLFVBQVU7R0FDakIsT0FBTyxVQUFVO0dBQ2pCLElBQUksT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFdBQVcsR0FDcEMsT0FBTyxRQUFRO0VBRW5CO0VBQ0EsTUFBTSxVQUFVLEtBQUssU0FBUyxTQUFTO0VBQ3ZDLEtBQUssbUJBQW1CLFNBQVMsUUFBUSxlQUFlLE1BQU0sQ0FBQyxDQUFDLE9BQU0sTUFBSztHQUN6RSxJQUFJLEtBQUssVUFDUDtHQUVGLEtBQUssU0FBUyxJQUFJQyxrQ0FBbUMsQ0FBQyxDQUFDLENBQUM7RUFDMUQsQ0FBQztDQUNIO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsT0FBTyxLQUFLLGFBQWEsS0FBSyxjQUFjO0NBQzlDO0NBQ0EsdUJBQXVCO0VBQ3JCLE9BQU8sVUFBVSxLQUFLLHNCQUFzQixpQkFBaUI7Q0FDL0Q7Q0FDQSxJQUFJLDJCQUEyQjtFQUM3QixPQUFPLEtBQUssc0JBQXNCO0NBQ3BDO0NBQ0EsWUFBWSxRQUFRO0VBQ2xCLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYyxlQUFlLE1BQU07RUFDeEUsS0FBSyxTQUFTLE9BQU8sSUFBSSxpQkFBaUI7RUFDMUMsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsY0FBYztFQUNaLEtBQUssUUFBUTtDQUNmO0NBQ0EsVUFBVTs7RUFDUixLQUFLLFFBQVEsWUFBWTtFQUN6QixLQUFLLHNCQUFzQixTQUFTO0VBQ3BDLENBQUEseUJBQUEsS0FBSyw2Q0FBQSxRQUFBLDJCQUFBLEtBQUEsS0FBQSx1QkFBeUMsWUFBWTtFQUMxRCxLQUFLLDBDQUEwQyxLQUFBO0VBQy9DLEtBQUssV0FBVztFQUNoQixLQUFLLG1CQUFtQixZQUFZO0NBQ3RDO0NBQ0EsY0FBYyxVQUFVLG1CQUFtQixDQUFDLEdBQUc7RUFDN0MsTUFBTSxFQUNKLFlBQ0EsYUFDQSxVQUNBLHFCQUNBLHFCQUNFO0VBQ0osTUFBTSxJQUFJLG1CQUFtQixLQUFLLGVBQWUsV0FBVztFQUM1RCxJQUFJLElBQUk7RUFDUixRQUFRLHdCQUFBLFFBQUEsd0JBQUEsS0FBQSxJQUFBLHNCQUF1QixLQUFLLFFBQVEsNEJBQTVDO0dBQ0UsS0FBSztJQUNILElBQUEsZUFBQSxlQUFBLENBQUEsR0FDSyxLQUFLLGVBQWUsV0FBQSxHQUNwQixXQUNMO0lBQ0E7R0FDRixLQUFLO0lBQ0gsSUFBSSxLQUFLLGVBQWU7SUFDeEI7R0FDRixTQUNFLElBQUksZUFBZTtFQUN2QjtFQUNBLElBQUksTUFBTSxNQUNSLElBQUksS0FBSyxpQkFBaUIsQ0FBQztFQUU3QixJQUFJO0VBQ0osSUFBSTtHQUVGLDRCQUE0Qiw0QkFERCxhQUFhLFdBQVcsV0FBVyxLQUFLLFlBQVksU0FBUyxJQUNkO0VBQzVFLFNBQVMsR0FBRztHQUNWLElBQUksT0FBTyxTQUFTLE9BQU8sWUFBWSxTQUFTLEVBQUUsQ0FBQyxPQUFPLEtBQ3hELFdBQVcsQ0FBQztHQUVkLDRCQUE0QixLQUFLLGVBQWU7RUFDbEQ7RUFDQSxPQUFPLDhCQUE4QiwyQkFBMkIsVUFBVSxHQUFHLE1BQUEsUUFBQSxNQUFBLEtBQUEsSUFBQSxJQUFLLE1BQU0sS0FBSyxhQUFhO0NBQzVHO0NBQ0EsY0FBYyxLQUFLLFNBQVMsRUFDMUIsb0JBQW9CLE1BQ3RCLEdBQUc7RUFDRCxNQUFNLFVBQVUsVUFBVSxHQUFHLElBQUksTUFBTSxLQUFLLFNBQVMsR0FBRztFQUN4RCxNQUFNLGFBQWEsS0FBSyxvQkFBb0IsTUFBTSxTQUFTLEtBQUssVUFBVTtFQUMxRSxPQUFPLEtBQUssbUJBQW1CLFlBQVksdUJBQXVCLE1BQU0sTUFBTTtDQUNoRjtDQUNBLFNBQVMsVUFBVSxTQUFTLEVBQzFCLG9CQUFvQixNQUN0QixHQUFHO0VBQ0QsaUJBQWlCLFFBQVE7RUFDekIsT0FBTyxLQUFLLGNBQWMsS0FBSyxjQUFjLFVBQVUsTUFBTSxHQUFHLE1BQU07Q0FDeEU7Q0FDQSxhQUFhLEtBQUs7RUFDaEIsT0FBTyxLQUFLLGNBQWMsVUFBVSxHQUFHO0NBQ3pDO0NBQ0EsU0FBUyxLQUFLO0VBQ1osSUFBSTtHQUNGLE9BQU8sS0FBSyxjQUFjLE1BQU0sR0FBRztFQUNyQyxTQUFTLEdBQUc7R0FDVixLQUFLLFFBQVEsS0FBS0MsbUJBQW9CLE1BQU0sYUFBYSxxQkFBcUIsSUFBSSxxQ0FBcUMsQ0FBQyxDQUFDO0dBQ3pILE9BQU8sS0FBSyxjQUFjLE1BQU0sR0FBRztFQUNyQztDQUNGO0NBQ0EsU0FBUyxLQUFLLGNBQWM7RUFDMUIsSUFBSTtFQUNKLElBQUksaUJBQWlCLE1BQ25CLFVBQUEsZUFBQSxDQUFBLEdBQ0ssaUJBQ0w7T0FDSyxJQUFJLGlCQUFpQixPQUMxQixVQUFBLGVBQUEsQ0FBQSxHQUNLLGtCQUNMO09BRUEsVUFBQSxlQUFBLGVBQUEsQ0FBQSxHQUNLLGtCQUFBLEdBQ0EsWUFDTDtFQUVGLElBQUksVUFBVSxHQUFHLEdBQ2YsT0FBTyxhQUFhLEtBQUssZ0JBQWdCLEtBQUssT0FBTztFQUV2RCxNQUFNLFVBQVUsS0FBSyxTQUFTLEdBQUc7RUFDakMsT0FBTyxhQUFhLEtBQUssZ0JBQWdCLFNBQVMsT0FBTztDQUMzRDtDQUNBLGlCQUFpQixRQUFRO0VBQ3ZCLE9BQU8sT0FBTyxRQUFRLE1BQU0sQ0FBQyxDQUFDLFFBQVEsUUFBUSxDQUFDLEtBQUssV0FBVztHQUM3RCxJQUFJLFVBQVUsUUFBUSxVQUFVLEtBQUEsR0FDOUIsT0FBTyxPQUFPO0dBRWhCLE9BQU87RUFDVCxHQUFHLENBQUMsQ0FBQztDQUNQO0NBQ0EsbUJBQW1CLFFBQVEsUUFBUSxlQUFlLFFBQVEsY0FBYztFQUN0RSxJQUFJLEtBQUssVUFDUCxPQUFPLFFBQVEsUUFBUSxLQUFLO0VBRTlCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUksY0FBYztHQUNoQixVQUFVLGFBQWE7R0FDdkIsU0FBUyxhQUFhO0dBQ3RCLFVBQVUsYUFBYTtFQUN6QixPQUNFLFVBQVUsSUFBSSxTQUFTLEtBQUssUUFBUTtHQUNsQyxVQUFVO0dBQ1YsU0FBUztFQUNYLENBQUM7RUFFSCxNQUFNLFNBQVMsS0FBSyxhQUFhLElBQUk7RUFDckMsb0JBQW9CLFlBQVk7R0FDOUIscUJBQXFCLEtBQUssYUFBYSxPQUFPLE1BQU0sQ0FBQztFQUN2RCxDQUFDO0VBQ0QsS0FBSyxzQkFBc0Isd0JBQXdCO0dBQ2pEO0dBQ0E7R0FDQSxnQkFBZ0IsS0FBSztHQUNyQixlQUFlLEtBQUs7R0FDcEI7R0FDQTtHQUNTO0dBQ0Q7R0FDUjtHQUNBLGlCQUFpQixLQUFLLFlBQVk7R0FDbEMsb0JBQW9CLEtBQUs7RUFDM0IsQ0FBQztFQUNELE9BQU8sUUFBUSxNQUFNLFFBQVEsT0FBTyxLQUFLLE9BQU8sQ0FBQztDQUNuRDtBQVFGOzt3QkFQUyxRQUFPLFNBQVMsZUFBZSxtQkFBbUI7Q0FDdkQsT0FBTyxLQUFLLHFCQUFxQkMsU0FBUTtBQUMzQyxDQUFBO3dCQUNPLFNBQXVCLGdDQUFtQjtDQUMvQyxPQUFPQTtDQUNQLFNBQVNBLFFBQU87QUFDbEIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWM3QixpQkFBcUIsUUFBUSxDQUFDLEVBQy9FLE1BQU0sUUFDUixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFDcEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyxpQkFBaUIsVUFBVTtDQUNsQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7RUFDeEMsTUFBTSxNQUFNLFNBQVM7RUFDckIsSUFBSSxPQUFPLE1BQ1QsTUFBTSxJQUFJRixhQUFjLE9BQU8sT0FBTyxjQUFjLGVBQWUsY0FBYywrQkFBK0IsSUFBSSxvQkFBb0IsR0FBRztDQUUvSTtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2ozSUEsSUFBTSxzQkFBTixNQUEwQjtDQWF4QixjQUFjOzt3QkFaZCxVQUFTLE9BQU8sTUFBTSxDQUFBO3dCQUN0QixnQkFBZSxPQUFPLFlBQVksQ0FBQTt3QkFDbEMsWUFBVyxPQUFPLElBQUksR0FBSSxZQUFZLENBQUMsRUFDckMsV0FBVyxXQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFDUixlQUFjLE9BQU8sQ0FBQyxHQUFHLEdBQUksWUFBWSxDQUFDLEVBQ3hDLFdBQVcsY0FDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1IsUUFBTyxPQUFPLElBQUksR0FBSSxZQUFZLENBQUMsRUFDakMsV0FBVyxPQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFDUixjQUFhLE9BQU8sYUFBYSxDQUFBO0VBRS9CLEtBQUssWUFBWTtFQUNqQixDQUFBLHNCQUFBLEtBQUssT0FBTyxZQUFBLFFBQUEsd0JBQUEsS0FBQSxLQUFBLG9CQUFRLFdBQVUsTUFBSztHQUNqQyxJQUFJLGFBQWEsZUFDZixLQUFLLFlBQVk7RUFFckIsQ0FBQztDQUNIO0NBQ0EsY0FBYztFQUNaLE1BQU0sRUFDSixVQUNBLE1BQ0EsZ0JBQ0UsS0FBSyxhQUFhLGtCQUFrQjtFQUN4QyxLQUFLLFNBQVMsSUFBSSxRQUFRO0VBQzFCLEtBQUssWUFBWSxJQUFJLFdBQVc7RUFDaEMsS0FBSyxLQUFLLElBQUksS0FBSyxXQUFXLFVBQVUsSUFBSSxRQUFRLElBQUksQ0FBQyxDQUFDO0NBQzVEO0FBUUY7O3FDQVBTLFFBQU8sU0FBUyw0QkFBNEIsbUJBQW1CO0NBQ3BFLE9BQU8sS0FBSyxxQkFBcUJnQyxzQkFBcUI7QUFDeEQsQ0FBQTtxQ0FDTyxTQUF1QixnQ0FBbUI7Q0FDL0MsT0FBT0E7Q0FDUCxTQUFTQSxxQkFBb0I7QUFDL0IsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNDLGlCQUFxQixxQkFBcUIsQ0FBQyxFQUM1RixNQUFNLFFBQ1IsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJO0FBQ3BCLEVBQUEsQ0FBRztBQUNILElBQU0sYUFBTixNQUFpQjtDQWtCZixJQUFJLE9BQU87RUFDVCxPQUFPLFVBQVUsS0FBSyxZQUFZO0NBQ3BDO0NBQ0EsSUFBSSxLQUFLLE9BQU87RUFDZCxLQUFLLGFBQWEsSUFBSSxLQUFLO0NBQzdCO0NBQ0EsSUFBSSxPQUFPLE9BQU87RUFDaEIsS0FBSyxRQUFRLElBQUksS0FBSztDQUN4QjtDQUNBLElBQUksU0FBUztFQUNYLE9BQU8sVUFBVSxLQUFLLE9BQU87Q0FDL0I7Q0FJQSxJQUFJLFlBQVksT0FBTztFQUNyQixLQUFLLGFBQWEsSUFBSSxLQUFLO0NBQzdCO0NBQ0EsSUFBSSxjQUFjO0VBQ2hCLE9BQU8sVUFBVSxLQUFLLFlBQVk7Q0FDcEM7Q0FPQSxJQUFJLFNBQVMsT0FBTztFQUNsQixLQUFLLFVBQVUsSUFBSSxLQUFLO0NBQzFCO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxVQUFVLEtBQUssU0FBUztDQUNqQztDQUlBLElBQUksb0JBQW9CLE9BQU87RUFDN0IsS0FBSyxxQkFBcUIsSUFBSSxLQUFLO0NBQ3JDO0NBQ0EsSUFBSSxzQkFBc0I7RUFDeEIsT0FBTyxVQUFVLEtBQUssb0JBQW9CO0NBQzVDO0NBSUEsSUFBSSxNQUFNLE9BQU87RUFDZixLQUFLLE9BQU8sSUFBSSxLQUFLO0NBQ3ZCO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxVQUFVLEtBQUssTUFBTTtDQUM5QjtDQU9BLElBQUksS0FBSyxPQUFPO0VBQ2QsS0FBSyxNQUFNLElBQUksS0FBSztDQUN0QjtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sVUFBVSxLQUFLLEtBQUs7Q0FDN0I7Q0FPQSxJQUFJLFdBQVcsT0FBTztFQUNwQixLQUFLLFlBQVksSUFBSSxLQUFLO0NBQzVCO0NBQ0EsSUFBSSxhQUFhO0VBQ2YsT0FBTyxVQUFVLEtBQUssV0FBVztDQUNuQztDQUlBLElBQUksaUJBQWlCLE9BQU87RUFDMUIsS0FBSyxrQkFBa0IsSUFBSSxLQUFLO0NBQ2xDO0NBQ0EsSUFBSSxtQkFBbUI7RUFDckIsT0FBTyxVQUFVLEtBQUssaUJBQWlCO0NBQ3pDO0NBSUEsSUFBSSxtQkFBbUIsT0FBTztFQUM1QixLQUFLLG9CQUFvQixJQUFJLEtBQUs7Q0FDcEM7Q0FDQSxJQUFJLHFCQUFxQjtFQUN2QixPQUFPLFVBQVUsS0FBSyxtQkFBbUI7Q0FDM0M7Q0FJQSxJQUFJLFdBQVcsT0FBTztFQUNwQixLQUFLLFlBQVksSUFBSSxLQUFLO0NBQzVCO0NBQ0EsSUFBSSxhQUFhO0VBQ2YsT0FBTyxVQUFVLEtBQUssV0FBVztDQUNuQztDQWNBLFlBQVksUUFBUSxPQUFPLG1CQUFtQixVQUFVLElBQUksa0JBQWtCOzt3QkFwSTlFLFVBQUEsS0FBQSxDQUFBO3dCQUNBLFNBQUEsS0FBQSxDQUFBO3dCQUNBLHFCQUFBLEtBQUEsQ0FBQTt3QkFDQSxZQUFBLEtBQUEsQ0FBQTt3QkFDQSxNQUFBLEtBQUEsQ0FBQTt3QkFDQSxvQkFBQSxLQUFBLENBQUE7d0JBQ0Esc0JBQXFCLE9BQU8sSUFBSSxtQkFBbUIsTUFBTSxHQUFHLEVBQzFELFVBQVUsS0FDWixDQUFDLENBQUE7d0JBQ0QsZ0JBQWUsbUJBQW1CO0dBQ2hDLElBQUksQ0FBQyxLQUFLLGlCQUNSLE9BQU8sS0FBSztHQUVkLE9BQU8sS0FBSyxZQUFZLEtBQUssU0FBUyxDQUFDO0VBQ3pDLEdBQUcsR0FBSSxZQUFZLENBQUMsRUFDbEIsV0FBVyxlQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFhUixXQUFVLE9BQU8sS0FBQSxHQUFXLEdBQUksWUFBWSxDQUFDLEVBQzNDLFdBQVcsVUFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBT1IsZ0JBQWUsT0FBTyxLQUFBLEdBQUEsZUFBQSxlQUFBLENBQUEsR0FDaEIsWUFBWSxFQUNkLFdBQVcsZUFDYixJQUFJLENBQUMsQ0FBQSxHQUFBLENBQUEsR0FBQSxFQUNMLGFBQWEsTUFBQSxDQUNmLENBQUMsQ0FBQTt3QkFPRCxhQUFZLE9BQU8sS0FBQSxHQUFXLEdBQUksWUFBWSxDQUFDLEVBQzdDLFdBQVcsWUFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBT1Isd0JBQXVCLE9BQU8sS0FBQSxHQUFXLEdBQUksWUFBWSxDQUFDLEVBQ3hELFdBQVcsdUJBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQU9SLFVBQVMsT0FBTyxLQUFBLEdBQUEsZUFBQSxlQUFBLENBQUEsR0FDVixZQUFZLEVBQ2QsV0FBVyxTQUNiLElBQUksQ0FBQyxDQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ0wsYUFBYSxNQUFBLENBQ2YsQ0FBQyxDQUFBO3dCQU9ELFNBQVEsT0FBTyxLQUFBLEdBQUEsZUFBQSxlQUFBLENBQUEsR0FDVCxZQUFZLEVBQ2QsV0FBVyxRQUNiLElBQUksQ0FBQyxDQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ0wsYUFBYSxNQUFBLENBQ2YsQ0FBQyxDQUFBO3dCQU9ELGVBQWMsT0FBTyxLQUFBLEdBQVcsR0FBSSxZQUFZLENBQUMsRUFDL0MsV0FBVyxjQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFPUixxQkFBb0IsT0FBTyxPQUFPLEdBQUksWUFBWSxDQUFDLEVBQ2pELFdBQVcsb0JBQ2IsQ0FBQyxJQUFJLENBQUMsQ0FBRSxDQUFBO3dCQU9SLHVCQUFzQixPQUFPLE9BQU8sR0FBSSxZQUFZLENBQUMsRUFDbkQsV0FBVyxzQkFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBT1IsZUFBYyxPQUFPLE9BQU8sR0FBSSxZQUFZLENBQUMsRUFDM0MsV0FBVyxjQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFDUixjQUFhLE1BQU0sS0FBQSxHQUFXLEdBQUksWUFBWSxDQUFDLEVBQzdDLFdBQVcsYUFDYixDQUFDLElBQUksQ0FBQyxDQUFFLENBQUE7d0JBQ1IsbUJBQUEsS0FBQSxDQUFBO3dCQUNBLGFBQVksSUFBSSxRQUFRLENBQUE7d0JBQ3hCLDJCQUEwQixPQUFPQyxrQ0FBbUMsQ0FBQTt3QkFDcEUsV0FBVSxPQUFPLHNCQUFzQixFQUNyQyxVQUFVLEtBQ1osQ0FBQyxDQUFBO3dCQUNELHVCQUFzQixPQUFPLG1CQUFtQixDQUFBO3dCQTJCaEQsbUJBQWtCLE9BQU8sTUFBTSxHQUFJLFlBQVksQ0FBQyxFQUM5QyxXQUFXLGtCQUNiLENBQUMsSUFBSSxDQUFDLENBQUUsQ0FBQTt3QkFvRFIsWUFBVyxlQUFlOztHQUN4QixLQUFLLG9CQUFvQixLQUFLO0dBQzlCLElBQUksS0FBSyxrQkFBa0IsR0FDekIsS0FBSyxvQkFBb0IsU0FBUztHQUVwQyxNQUFNLHFCQUFvQixhQUFZLGFBQWEsY0FBYyxhQUFhO0dBQzlFLElBQUksa0JBQWtCLEtBQUsscUJBQXFCLENBQUMsS0FBSyxtQkFBQSxnQkFBa0IsS0FBSyxhQUFBLFFBQUEsa0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxjQUFTLDBCQUEwQixHQUM5RyxLQUFLLG9CQUFvQixZQUFZO0dBRXZDLE1BQU0sa0JBQWtCLEtBQUssZ0JBQWdCO0dBQzdDLElBQUksb0JBQW9CLFFBQVEsQ0FBQyxLQUFLLE9BQU8sZUFDM0MsT0FBTztRQUNGLElBQUksVUFBVSxlQUFlLEdBQ2xDLE9BQU87R0FFVCxPQUFPLEtBQUssT0FBTyxjQUFjLGlCQUFpQjtJQUNoRCxZQUFZLEtBQUssWUFBWSxNQUFNLEtBQUEsSUFBWSxLQUFLLFlBQVksSUFBSSxLQUFLO0lBQ3pFLGFBQWEsS0FBSyxhQUFhO0lBQy9CLFVBQVUsS0FBSyxVQUFVO0lBQ3pCLHFCQUFxQixLQUFLLHFCQUFxQjtJQUMvQyxrQkFBa0IsS0FBSyxrQkFBa0I7R0FDM0MsQ0FBQztFQUNILEdBQUEsZUFBQSxlQUFBLENBQUEsR0FDTSxZQUFZLEVBQ2QsV0FBVyxXQUNiLElBQUksQ0FBQyxDQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ0wsUUFBUSxHQUFHLE1BQU0sS0FBSyxZQUFZLENBQUMsTUFBTSxLQUFLLFlBQVksQ0FBQyxFQUFBLENBQzdELENBQUMsQ0FBQTtFQTFHQyxLQUFLLFNBQVM7RUFDZCxLQUFLLFFBQVE7RUFDYixLQUFLLG9CQUFvQjtFQUN6QixLQUFLLFdBQVc7RUFDaEIsS0FBSyxLQUFLO0VBQ1YsS0FBSyxtQkFBbUI7RUFDeEIsTUFBTSxXQUFBLHdCQUFVLEdBQUcsY0FBYyxhQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxzQkFBUyxZQUFZO0VBQ3RELEtBQUssa0JBQWtCLFlBQVksT0FBTyxZQUFZLFVBQVUsQ0FBQyxFQUFFLE9BQU8sbUJBQW1CLGNBQUEsc0JBQVksZUFBZSxJQUFJLE9BQU8sT0FBQSxRQUFBLHdCQUFBLEtBQUEsTUFBQSxzQkFBQSxvQkFBRyx3QkFBQSxRQUFBLHdCQUFBLEtBQUEsTUFBQSx3QkFBQSxvQkFBb0IsY0FBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsc0JBQUEsS0FBQSxxQkFBVyxNQUFNO0VBQzNLLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsYUFBYTtHQUNYLElBQUksVUFBVSxLQUFLLGdCQUFnQixDQUFDLE1BQU0sS0FBSyxVQUFVLE1BQU0sS0FBQSxLQUFhLEtBQUssYUFBYSxLQUFLLEtBQUsscUJBQXFCLEtBQUssS0FBSyxrQkFBa0IsS0FBSyxLQUFLLFlBQVksSUFDN0ssTUFBTSxJQUFJQyxhQUFjLE1BQU0sOEZBQThGO0VBRWhJLENBQUM7Q0FFTDtDQUNBLDJCQUEyQixhQUFhO0VBQ3RDLElBQUksS0FBSyxxQkFBcUIsUUFBUSxLQUFLLGlCQUN6QztFQUVGLEtBQUssb0JBQW9CLFlBQVksV0FBVztDQUNsRDtDQUNBLFlBQVksU0FBUztFQUNuQixLQUFLLFVBQVUsS0FBSyxJQUFJO0NBQzFCO0NBSUEsSUFBSSxXQUFXLG1CQUFtQjtFQUNoQyxJQUFJLHFCQUFxQixNQUFNO0dBQzdCLEtBQUssZ0JBQWdCLElBQUksSUFBSTtHQUM3QixLQUFLLDJCQUEyQixJQUFJO0VBQ3RDLE9BQU87R0FDTCxJQUFJLFVBQVUsaUJBQWlCLEdBQzdCLEtBQUssZ0JBQWdCLElBQUksaUJBQWlCO1FBRTFDLEtBQUssZ0JBQWdCLElBQUksTUFBTSxRQUFRLGlCQUFpQixJQUFJLG9CQUFvQixDQUFDLGlCQUFpQixDQUFDO0dBRXJHLEtBQUssMkJBQTJCLEdBQUc7RUFDckM7Q0FDRjtDQUNBLFFBQVEsUUFBUSxTQUFTLFVBQVUsUUFBUSxTQUFTOztFQUNsRCxNQUFNLFVBQVUsS0FBSyxTQUFTO0VBQzlCLElBQUksWUFBWSxNQUNkLE9BQU87RUFFVCxJQUFJLEtBQUssaUJBQWlCO0dBQ3hCLElBQUksV0FBVyxLQUFLLFdBQVcsWUFBWSxVQUFVLFNBQ25ELE9BQU87R0FFVCxJQUFJLE9BQU8sS0FBSyxXQUFXLFlBQVksS0FBSyxVQUFVLFNBQ3BELE9BQU87RUFFWDtFQUNBLE1BQU0sYUFBYSxLQUFLLFdBQVc7RUFDbkMsTUFBTSxTQUFBLGVBQUE7R0FDSixvQkFBb0IsS0FBSztHQUN6QixZQUFZLEtBQUs7R0FDakIsT0FBTyxLQUFLO0dBQ1osTUFBTSxLQUFLO0tBQ1AsZUFBZSxLQUFBLEtBQWEsRUFDOUIsV0FDRixDQUNGO0VBQ0EsQ0FBQSx3QkFBQSxLQUFLLE9BQU8sY0FBYyxTQUFTLE1BQU0sT0FBQSxRQUFBLDBCQUFBLEtBQUEsS0FBQSxzQkFBRyxPQUFNLE1BQUs7R0FDckQsS0FBSyx3QkFBd0IsQ0FBQztFQUNoQyxDQUFDO0VBQ0QsT0FBTyxDQUFDLEtBQUs7Q0FDZjtDQUNBLGNBQWMsQ0FBQztDQUNmLG9CQUFvQixVQUFVLFdBQVc7RUFDdkMsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxnQkFBZ0IsS0FBSyxHQUFHO0VBQzlCLElBQUksY0FBYyxNQUNoQixTQUFTLGFBQWEsZUFBZSxVQUFVLFNBQVM7T0FFeEQsU0FBUyxnQkFBZ0IsZUFBZSxRQUFRO0NBRXBEO0NBNkJBLElBQUksVUFBVTtFQUNaLE9BQU8sVUFBVSxLQUFLLFFBQVE7Q0FDaEM7Q0FDQSxZQUFZLFNBQVM7O0VBQ25CLE9BQU8sWUFBWSxRQUFRLEtBQUssb0JBQUEseUJBQUEseUJBQW1CLEtBQUssc0JBQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHVCQUFrQixtQkFBbUIsS0FBSyxPQUFPLGFBQWEsT0FBTyxDQUFDLE9BQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsd0JBQUssS0FBSztDQUMxSTtBQW1DRjs7NEJBbENTLFFBQU8sU0FBUyxtQkFBbUIsbUJBQW1CO0NBRTNELE9BQU8sS0FBSyxxQkFBcUJDLGFBQVlDLGtCQUFxQixNQUFNLEdBQUdBLGtCQUFxQixjQUFjLEdBQUdDLGtCQUFxQixVQUFVLEdBQUdELGtCQUFxQkUsU0FBWSxHQUFHRixrQkFBcUJHLFVBQWEsR0FBR0gsa0JBQXFCSSxnQkFBbUIsQ0FBQztBQUN2USxDQUFBOzRCQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNTDtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQUk7RUFBYztDQUFFLENBQUM7Q0FDbEMsVUFBVTtDQUNWLGNBQWMsU0FBUyx3QkFBd0IsSUFBSSxLQUFLO0VBQ3RELElBQUksS0FBSyxHQUNQLFdBQWMsU0FBUyxTQUFTLG9DQUFvQyxRQUFRO0dBQzFFLE9BQU8sSUFBSSxRQUFRLE9BQU8sUUFBUSxPQUFPLFNBQVMsT0FBTyxVQUFVLE9BQU8sUUFBUSxPQUFPLE9BQU87RUFDbEcsQ0FBQztFQUVILElBQUksS0FBSyxHQUNQLFlBQWUsUUFBUSxJQUFJLGFBQWEsR0FBR00sMEJBQTZCLENBQUMsQ0FBQyxVQUFVLElBQUksUUFBUSxDQUFDO0NBRXJHO0NBQ0EsUUFBUTtFQUNOLFFBQVE7RUFDUixhQUFhO0VBQ2IsVUFBVTtFQUNWLHFCQUFxQjtFQUNyQixPQUFPO0VBQ1AsTUFBTTtFQUNOLFlBQVk7RUFDWixrQkFBa0I7R0FBQztHQUFHO0dBQW9CO0dBQW9CO0VBQWdCO0VBQzlFLG9CQUFvQjtHQUFDO0dBQUc7R0FBc0I7R0FBc0I7RUFBZ0I7RUFDcEYsWUFBWTtHQUFDO0dBQUc7R0FBYztHQUFjO0VBQWdCO0VBQzVELFlBQVksQ0FBQyxHQUFHLFlBQVk7RUFDNUIsWUFBWTtDQUNkO0NBQ0EsVUFBVSxDQUFDQyxvQkFBdUI7QUFDcEMsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNWLGlCQUFxQixZQUFZLENBQUM7RUFDbkYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFVBQVU7R0FDVixNQUFNO0lBQ0osZUFBZTtJQUNmLGlCQUFpQjtHQUNuQjtFQUNGLENBQUM7Q0FDSCxDQUFDLFNBQVM7RUFBQyxFQUNULE1BQU0sT0FDUjtFQUFHLEVBQ0QsTUFBTSxlQUNSO0VBQUc7R0FDRCxNQUFNLEtBQUE7R0FDTixZQUFZLENBQUM7SUFDWCxNQUFNO0lBQ04sTUFBTSxDQUFDLFVBQVU7R0FDbkIsQ0FBQztFQUNIO0VBQUcsRUFDRCxNQUFNTSxVQUNSO0VBQUcsRUFDRCxNQUFNQyxXQUNSO0VBQUcsRUFDRCxNQUFNQyxpQkFDUjtDQUFDLEdBQUc7RUFDRixRQUFRLENBQUMsRUFDUCxNQUFNLE1BQ1IsQ0FBQztFQUNELGFBQWEsQ0FBQyxFQUNaLE1BQU0sTUFDUixDQUFDO0VBQ0QsVUFBVSxDQUFDLEVBQ1QsTUFBTSxNQUNSLENBQUM7RUFDRCxxQkFBcUIsQ0FBQyxFQUNwQixNQUFNLE1BQ1IsQ0FBQztFQUNELE9BQU8sQ0FBQyxFQUNOLE1BQU0sTUFDUixDQUFDO0VBQ0QsTUFBTSxDQUFDLEVBQ0wsTUFBTSxNQUNSLENBQUM7RUFDRCxZQUFZLENBQUMsRUFDWCxNQUFNLE1BQ1IsQ0FBQztFQUNELGtCQUFrQixDQUFDO0dBQ2pCLE1BQU07R0FDTixNQUFNLENBQUMsRUFDTCxXQUFXLGlCQUNiLENBQUM7RUFDSCxDQUFDO0VBQ0Qsb0JBQW9CLENBQUM7R0FDbkIsTUFBTTtHQUNOLE1BQU0sQ0FBQyxFQUNMLFdBQVcsaUJBQ2IsQ0FBQztFQUNILENBQUM7RUFDRCxZQUFZLENBQUM7R0FDWCxNQUFNO0dBQ04sTUFBTSxDQUFDLEVBQ0wsV0FBVyxpQkFDYixDQUFDO0VBQ0gsQ0FBQztFQUNELFlBQVksQ0FBQztHQUNYLE1BQU1HO0dBQ04sTUFBTSxDQUFDO0lBQ0wsVUFBVTtJQUNWLE9BQU87SUFDUCxVQUFVO0dBQ1osQ0FBQztFQUNILENBQUM7RUFDRCxZQUFZLENBQUMsRUFDWCxNQUFNLE1BQ1IsQ0FBQztFQUNELFNBQVMsQ0FBQztHQUNSLE1BQU07R0FDTixNQUFNLENBQUMsU0FBUztJQUFDO0lBQWlCO0lBQWtCO0lBQW1CO0lBQWlCO0dBQWdCLENBQUM7RUFDM0csQ0FBQztDQUNILENBQUM7QUFDSCxFQUFBLENBQUc7QUFDSCxJQUFNLG1CQUFOLE1BQXVCO0NBVXJCLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSztDQUNkO0NBU0EsWUFBWSxRQUFRLFNBQVMsVUFBVSxLQUFLO3dCQXBCNUMsVUFBQSxLQUFBLENBQUE7d0JBQ0EsV0FBQSxLQUFBLENBQUE7d0JBQ0EsWUFBQSxLQUFBLENBQUE7d0JBQ0EsT0FBQSxLQUFBLENBQUE7d0JBQ0EsU0FBQSxLQUFBLENBQUE7d0JBQ0EsV0FBVSxDQUFDLENBQUE7d0JBQ1gsNEJBQUEsS0FBQSxDQUFBO3dCQUNBLGdDQUFBLEtBQUEsQ0FBQTt3QkFDQSxhQUFZLEtBQUE7d0JBSVosMkJBQTBCLEVBQ3hCLE9BQU8sTUFDVCxDQUFBO3dCQUNBLHlCQUFBLEtBQUEsQ0FBQTt3QkFDQSxrQkFBaUIsSUFBSSxhQUFhLENBQUE7d0JBQ2xDLFFBQU8sT0FBTyxZQUFZLEVBQ3hCLFVBQVUsS0FDWixDQUFDLENBQUE7RUFFQyxLQUFLLFNBQVM7RUFDZCxLQUFLLFVBQVU7RUFDZixLQUFLLFdBQVc7RUFDaEIsS0FBSyxNQUFNO0VBQ1gsS0FBSywyQkFBMkIsT0FBTyxPQUFPLFdBQVUsTUFBSztHQUMzRCxJQUFJLGFBQWEsZUFDZixLQUFLLE9BQU87RUFFaEIsQ0FBQztDQUNIO0NBQ0EscUJBQXFCO0VBQ25CLEdBQUcsS0FBSyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxXQUFVLE1BQUs7R0FDL0QsS0FBSyxPQUFPO0dBQ1osS0FBSyw2QkFBNkI7RUFDcEMsQ0FBQztDQUNIO0NBQ0EsK0JBQStCOztFQUM3QixDQUFBLHdCQUFBLEtBQUssa0NBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQThCLFlBQVk7RUFDL0MsTUFBTSxpQkFBaUIsQ0FBQyxHQUFHLEtBQUssTUFBTSxRQUFRLEdBQUcsS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUFPLFNBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUksU0FBUSxLQUFLLFNBQVM7RUFDN0csS0FBSywrQkFBK0IsS0FBSyxjQUFjLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVSxTQUFRO0dBQzFGLElBQUksS0FBSyxjQUFjLEtBQUssYUFBYSxLQUFLLE1BQU0sQ0FBQyxDQUFDLElBQUksR0FDeEQsS0FBSyxPQUFPO0VBRWhCLENBQUM7Q0FDSDtDQUNBLElBQUksaUJBQWlCLE1BQU07RUFDekIsSUFBSSxRQUFRLE1BQU07R0FDaEIsS0FBSyxVQUFVLENBQUM7R0FDaEI7RUFDRjtFQUNBLE1BQU0sVUFBVSxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sS0FBSyxNQUFNLEdBQUc7RUFDM0QsS0FBSyxVQUFVLFFBQVEsUUFBTyxNQUFLLENBQUMsQ0FBQyxDQUFDO0NBQ3hDO0NBQ0EsWUFBWSxTQUFTO0VBQ25CLEtBQUssT0FBTztDQUNkO0NBQ0EsY0FBYzs7RUFDWixLQUFLLHlCQUF5QixZQUFZO0VBQzFDLENBQUEseUJBQUEsS0FBSyxrQ0FBQSxRQUFBLDJCQUFBLEtBQUEsS0FBQSx1QkFBOEIsWUFBWTtDQUNqRDtDQUNBLFNBQVM7RUFDUCxJQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsS0FBSyxPQUFPLFdBQVc7RUFDM0MsSUFBSSxLQUFLLDRCQUE0QixRQUFRLENBQUMsS0FBSyxXQUFXO0VBQzlELHFCQUFxQjtHQUNuQixNQUFNLGlCQUFpQixLQUFLLGVBQWU7R0FDM0MsS0FBSyxRQUFRLFNBQVEsTUFBSztJQUN4QixJQUFJLGdCQUNGLEtBQUssU0FBUyxTQUFTLEtBQUssUUFBUSxlQUFlLENBQUM7U0FFcEQsS0FBSyxTQUFTLFlBQVksS0FBSyxRQUFRLGVBQWUsQ0FBQztHQUUzRCxDQUFDO0dBQ0QsSUFBSSxrQkFBa0IsS0FBSywwQkFBMEIsS0FBQSxHQUNuRCxLQUFLLFNBQVMsYUFBYSxLQUFLLFFBQVEsZUFBZSxnQkFBZ0IsS0FBSyxzQkFBc0IsU0FBUyxDQUFDO1FBRTVHLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLGVBQWUsY0FBYztHQUUxRSxJQUFJLEtBQUssY0FBYyxnQkFBZ0I7SUFDckMsS0FBSyxZQUFZO0lBQ2pCLEtBQUssSUFBSSxhQUFhO0lBQ3RCLEtBQUssZUFBZSxLQUFLLGNBQWM7R0FDekM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxhQUFhLFFBQVE7O0VBQ25CLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLElBQUksU0FBUyxNQUNYLGFBQWE7RUFFZixJQUFJO0VBQ0osSUFBSSxTQUFTLEtBQUEsR0FDWCxVQUFBLGVBQUEsQ0FBQSxHQUNLLGtCQUNMO09BQ0ssSUFBSSxxQkFBcUIsSUFBSSxHQUNsQyxVQUFVO09BQ0wsS0FBQSxjQUFJLEtBQUssV0FBQSxRQUFBLGdCQUFBLEtBQUEsSUFBQSxjQUFTLE9BQ3ZCLFVBQUEsZUFBQSxDQUFBLEdBQ0ssaUJBQ0w7T0FFQSxVQUFBLGVBQUEsQ0FBQSxHQUNLLGtCQUNMO0VBRUYsUUFBTyxTQUFRO0dBQ2IsTUFBTSxVQUFVLEtBQUs7R0FDckIsT0FBTyxVQUFVLFVBQVUsU0FBUyxTQUFTLFFBQVEsT0FBTyxDQUFDLElBQUk7RUFDbkU7Q0FDRjtDQUNBLGlCQUFpQjtFQUNmLE1BQU0sa0JBQWtCLEtBQUssYUFBYSxLQUFLLE1BQU07RUFDckQsT0FBTyxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLGVBQWU7Q0FDbkY7QUE0QkY7O2tDQTNCUyxRQUFPLFNBQVMseUJBQXlCLG1CQUFtQjtDQUVqRSxPQUFPLEtBQUsscUJBQXFCQyxtQkFBa0JSLGtCQUFxQixNQUFNLEdBQUdBLGtCQUFxQkcsVUFBYSxHQUFHSCxrQkFBcUJFLFNBQVksR0FBR0Ysa0JBQXFCUyxpQkFBb0IsQ0FBQztBQUN0TSxDQUFBO2tDQUNPLFFBQXNCLGtDQUFxQjtDQUNoRCxNQUFNRDtDQUNOLFdBQVcsQ0FBQztFQUFDO0VBQUk7RUFBb0I7Q0FBRSxDQUFDO0NBQ3hDLGdCQUFnQixTQUFTLGdDQUFnQyxJQUFJLEtBQUssVUFBVTtFQUMxRSxJQUFJLEtBQUssR0FDUCxlQUFrQixVQUFVLFlBQVksQ0FBQztFQUUzQyxJQUFJLEtBQUssR0FBRztHQUNWLElBQUk7R0FDSixlQUFrQixLQUFLRSxZQUFlLENBQUMsTUFBTSxJQUFJLFFBQVE7RUFDM0Q7Q0FDRjtDQUNBLFFBQVE7RUFDTix5QkFBeUI7RUFDekIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtDQUNwQjtDQUNBLFNBQVMsRUFDUCxnQkFBZ0IsaUJBQ2xCO0NBQ0EsVUFBVSxDQUFDLGtCQUFrQjtDQUM3QixVQUFVLENBQUNKLG9CQUF1QjtBQUNwQyxDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY1YsaUJBQXFCLGtCQUFrQixDQUFDO0VBQ3pGLE1BQU07RUFDTixNQUFNLENBQUM7R0FDTCxVQUFVO0dBQ1YsVUFBVTtFQUNaLENBQUM7Q0FDSCxDQUFDLFNBQVM7RUFBQyxFQUNULE1BQU0sT0FDUjtFQUFHLEVBQ0QsTUFBTU8sV0FDUjtFQUFHLEVBQ0QsTUFBTUQsVUFDUjtFQUFHLEVBQ0QsTUFBTU8sa0JBQ1I7Q0FBQyxHQUFHO0VBQ0YsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLE1BQU0sQ0FBQyxZQUFZLEVBQ2pCLGFBQWEsS0FDZixDQUFDO0VBQ0gsQ0FBQztFQUNELHlCQUF5QixDQUFDLEVBQ3hCLE1BQU0sTUFDUixDQUFDO0VBQ0QsdUJBQXVCLENBQUMsRUFDdEIsTUFBTSxNQUNSLENBQUM7RUFDRCxnQkFBZ0IsQ0FBQyxFQUNmLE1BQU0sT0FDUixDQUFDO0VBQ0Qsa0JBQWtCLENBQUMsRUFDakIsTUFBTSxNQUNSLENBQUM7Q0FDSCxDQUFDO0FBQ0gsRUFBQSxDQUFHO0FBQ0gsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxNQUFNLElBQUk7Q0FDVixPQUFPLENBQUMsRUFBRSxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxlQUFlLEVBQUU7QUFDNUQ7QUFDQSxJQUFNLHFCQUFOLE1BQXlCLENBQUM7QUFDMUIsSUFBTSxvQkFBTixNQUF3QjtDQUN0QixRQUFRLE9BQU8sSUFBSTtFQUNqQixPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssaUJBQWlCLEdBQUcsSUFBSSxDQUFDLENBQUM7Q0FDN0M7QUFRRjs7bUNBUFMsUUFBTyxTQUFTLDBCQUEwQixtQkFBbUI7Q0FDbEUsT0FBTyxLQUFLLHFCQUFxQkUsb0JBQW1CO0FBQ3RELENBQUE7bUNBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0EsbUJBQWtCO0FBQzdCLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjZixpQkFBcUIsbUJBQW1CLENBQUMsRUFDMUYsTUFBTSxRQUNSLENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxlQUFOLE1BQW1CO0NBQ2pCLFFBQVEsT0FBTyxJQUFJO0VBQ2pCLE9BQU8sR0FBRyxJQUFJO0NBQ2hCO0FBUUY7OzhCQVBTLFFBQU8sU0FBUyxxQkFBcUIsbUJBQW1CO0NBQzdELE9BQU8sS0FBSyxxQkFBcUJnQixlQUFjO0FBQ2pELENBQUE7OEJBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0EsY0FBYTtBQUN4QixDQUFDLENBQUE7T0FFSTtDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBY2hCLGlCQUFxQixjQUFjLENBQUMsRUFDckYsTUFBTSxRQUNSLENBQUMsR0FBRyxNQUFNLElBQUk7QUFDaEIsRUFBQSxDQUFHO0FBQ0gsSUFBTSxrQkFBTixNQUFzQjtDQU1wQixZQUFZLFFBQVEsVUFBVSxvQkFBb0IsUUFBUTt3QkFMMUQsVUFBQSxLQUFBLENBQUE7d0JBQ0EsWUFBQSxLQUFBLENBQUE7d0JBQ0Esc0JBQUEsS0FBQSxDQUFBO3dCQUNBLFVBQUEsS0FBQSxDQUFBO3dCQUNBLGdCQUFBLEtBQUEsQ0FBQTtFQUVFLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztFQUNoQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLFNBQVM7Q0FDaEI7Q0FDQSxrQkFBa0I7RUFDaEIsS0FBSyxlQUFlLEtBQUssT0FBTyxPQUFPLEtBQUssUUFBTyxNQUFLLGFBQWEsYUFBYSxHQUFHLGdCQUFnQixLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0NBQzFJO0NBQ0EsVUFBVTtFQUNSLE9BQU8sS0FBSyxjQUFjLEtBQUssVUFBVSxLQUFLLE9BQU8sTUFBTTtDQUM3RDtDQUNBLGNBQWM7O0VBQ1osQ0FBQSxxQkFBQSxLQUFLLGtCQUFBLFFBQUEsdUJBQUEsS0FBQSxLQUFBLG1CQUFjLFlBQVk7Q0FDakM7Q0FDQSxjQUFjLFVBQVUsUUFBUTtFQUM5QixNQUFNLE1BQU0sQ0FBQztFQUNiLEtBQUssTUFBTSxTQUFTLFFBQVE7O0dBQzFCLElBQUksTUFBTSxhQUFhLENBQUMsTUFBTSxXQUM1QixNQUFNLFlBQVksMEJBQTBCLE1BQU0sV0FBVyxVQUFVLE9BQU8sY0FBYyxlQUFlLFlBQVksVUFBVSxNQUFNLFNBQVMsRUFBRTtHQUVwSixNQUFNLDJCQUFBLG1CQUEwQixNQUFNLGVBQUEsUUFBQSxxQkFBQSxLQUFBLElBQUEsbUJBQWE7R0FDbkQsSUFBSSxNQUFNLDBCQUEwQixDQUFDLE1BQU0saUJBQ3pDLE1BQU0sa0JBQWtCLE1BQU0sdUJBQXVCLE9BQU8sdUJBQXVCLENBQUMsQ0FBQztHQUV2RixNQUFNLHVCQUFBLHdCQUFzQixNQUFNLHFCQUFBLFFBQUEsMEJBQUEsS0FBQSxJQUFBLHdCQUFtQjtHQUNyRCxJQUFJLE1BQU0sZ0JBQWdCLENBQUMsTUFBTSxpQkFBaUIsTUFBTSxZQUFZLEtBQUEsS0FBYSxNQUFNLGlCQUFpQixDQUFDLE1BQU0sa0JBQzdHLElBQUksS0FBSyxLQUFLLGNBQWMseUJBQXlCLEtBQUssQ0FBQztHQUU3RCxJQUFJLE1BQU0sWUFBWSxNQUFNLGVBQWU7O0lBQ3pDLElBQUksS0FBSyxLQUFLLGNBQWMsc0JBQUEsa0JBQXFCLE1BQU0sY0FBQSxRQUFBLG9CQUFBLEtBQUEsSUFBQSxrQkFBWSxNQUFNLGFBQWEsQ0FBQztHQUN6RjtFQUNGO0VBQ0EsT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDO0NBQ2xDO0NBQ0EsY0FBYyxVQUFVLE9BQU87RUFDN0IsT0FBTyxLQUFLLG1CQUFtQixRQUFRLGFBQWE7R0FDbEQsSUFBSSxTQUFTLFdBQ1gsT0FBTyxHQUFHLElBQUk7R0FFaEIsSUFBSTtHQUNKLElBQUksTUFBTSxnQkFBZ0IsTUFBTSxZQUFZLEtBQUEsR0FDMUMsa0JBQWtCLEtBQUssS0FBSyxPQUFPLGFBQWEsVUFBVSxLQUFLLENBQUM7UUFFaEUsa0JBQWtCLEdBQUcsSUFBSTtHQUUzQixNQUFNLHlCQUF5QixnQkFBZ0IsS0FBSyxVQUFTLFdBQVU7O0lBQ3JFLElBQUksV0FBVyxNQUNiLE9BQU8sR0FBRyxLQUFLLENBQUM7SUFFbEIsTUFBTSxnQkFBZ0IsT0FBTztJQUM3QixNQUFNLGtCQUFrQixPQUFPO0lBQy9CLE1BQU0seUJBQXlCLE9BQU87SUFDdEMsT0FBTyxLQUFLLGVBQUEsbUJBQWMsT0FBTyxjQUFBLFFBQUEscUJBQUEsS0FBQSxJQUFBLG1CQUFZLFVBQVUsT0FBTyxNQUFNO0dBQ3RFLENBQUMsQ0FBQztHQUNGLElBQUksTUFBTSxpQkFBaUIsQ0FBQyxNQUFNLGtCQUVoQyxPQUFPLEtBQUssQ0FBQyx3QkFEVSxLQUFLLE9BQU8sY0FBYyxVQUFVLEtBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQztRQUVyRSxPQUFPO0VBRVgsQ0FBQztDQUNIO0FBVUY7O2lDQVRTLFFBQU8sU0FBUyx3QkFBd0IsbUJBQW1CO0NBRWhFLE9BQU8sS0FBSyxxQkFBcUJpQixrQkFBaUJDLFNBQVksTUFBTSxHQUFHQSxTQUFZQyxtQkFBc0IsR0FBR0QsU0FBWSxrQkFBa0IsR0FBR0EsU0FBWSxrQkFBa0IsQ0FBQztBQUM5SyxDQUFBO2lDQUNPLFNBQXVCLG1DQUFzQjtDQUNsRCxPQUFPRDtDQUNQLFNBQVNBLGlCQUFnQjtDQUN6QixZQUFZO0FBQ2QsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWNqQixpQkFBcUIsaUJBQWlCLENBQUM7RUFDeEYsTUFBTTtFQUNOLE1BQU0sQ0FBQyxFQUNMLFlBQVksT0FDZCxDQUFDO0NBQ0gsQ0FBQyxTQUFTO0VBQUMsRUFDVCxNQUFNLE9BQ1I7RUFBRyxFQUNELE1BQU1tQixvQkFDUjtFQUFHLEVBQ0QsTUFBTSxtQkFDUjtFQUFHLEVBQ0QsTUFBTSxtQkFDUjtDQUFDLEdBQUcsSUFBSTtBQUNWLEVBQUEsQ0FBRztBQUNILElBQU0sa0JBQWtCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLG9CQUFvQixFQUFFO0FBQ2pILElBQU0saUJBQU4sTUFBcUI7Q0FlbkIsWUFBWSxTQUFTOzt3QkFkckIsV0FBQSxLQUFBLENBQUE7d0JBQ0EsNEJBQUEsS0FBQSxDQUFBO3dCQUNBLDRCQUFBLEtBQUEsQ0FBQTt3QkFDQSxVQUFTLENBQUE7d0JBQ1QsY0FBYSxxQkFBQTt3QkFDYixjQUFhLENBQUE7d0JBQ2IsU0FBUSxDQUFDLENBQUE7d0JBQ1QsZ0JBQUEsVUFBYyxPQUFPQyxnQ0FBaUMsRUFDcEQsVUFBVSxLQUNaLENBQUMsT0FBQSxRQUFBLFlBQUEsS0FBQSxJQUFBLFVBQUssS0FBQTt3QkFDTixpQkFBZ0IsT0FBTyxhQUFhLENBQUE7d0JBQ3BDLFFBQU8sT0FBTyxNQUFNLENBQUE7d0JBQ3BCLG9CQUFtQixPQUFPLGdCQUFnQixDQUFBO3dCQUMxQyxlQUFjLE9BQU8scUJBQXFCLENBQUE7RUFFeEMsS0FBSyxVQUFVO0VBQ2YsQ0FBQSxpQkFBQSxLQUFLLFFBQUEsQ0FBUSw4QkFBQSxlQUFBLDRCQUE4QjtFQUMzQyxDQUFBLGlCQUFBLEtBQUssUUFBQSxDQUFRLG9CQUFBLGVBQUEsa0JBQW9CO0VBQ2pDLElBQUksS0FBSyxhQUNQLE9BQU8sY0FBYyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVztHQUM3QyxLQUFLLGNBQWM7RUFDckIsQ0FBQztDQUVMO0NBQ0EsT0FBTztFQUNMLElBQUksS0FBSyxRQUFRLDhCQUE4QixZQUM3QyxLQUFLLGlCQUFpQiw0QkFBNEIsUUFBUTtFQUU1RCxLQUFLLDJCQUEyQixLQUFLLG1CQUFtQjtFQUN4RCxLQUFLLDJCQUEyQixLQUFLLG9CQUFvQjtDQUMzRDtDQUNBLHFCQUFxQjtFQUNuQixPQUFPLEtBQUssWUFBWSxPQUFPLFdBQVUsTUFBSztHQUM1QyxJQUFJLGFBQWEsaUJBQWlCO0lBQ2hDLEtBQUssTUFBTSxLQUFLLFVBQVUsS0FBSyxpQkFBaUIsa0JBQWtCO0lBQ2xFLEtBQUssYUFBYSxFQUFFO0lBQ3BCLEtBQUssYUFBYSxFQUFFLGdCQUFnQixFQUFFLGNBQWMsZUFBZTtHQUNyRSxPQUFPLElBQUksYUFBYSxlQUFlO0lBQ3JDLEtBQUssU0FBUyxFQUFFO0lBQ2hCLEtBQUssb0JBQW9CLEdBQUcsS0FBSyxjQUFjLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLFFBQVE7R0FDcEYsT0FBTyxJQUFJLGFBQWEscUJBQXFCLEVBQUUsU0FBUyxzQkFBc0IsMEJBQTBCO0lBQ3RHLEtBQUssYUFBYSxLQUFBO0lBQ2xCLEtBQUssYUFBYTtJQUNsQixLQUFLLG9CQUFvQixHQUFHLEtBQUssY0FBYyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsUUFBUTtHQUN0RTtFQUNGLENBQUM7Q0FDSDtDQUNBLHNCQUFzQjtFQUNwQixPQUFPLEtBQUssWUFBWSxPQUFPLFdBQVUsTUFBSztHQUM1QyxJQUFJLEVBQUUsYUFBYSxXQUFXLEVBQUUsbUJBQW1CLFVBQVU7R0FDN0QsTUFBTSxnQkFBZ0IsRUFDcEIsVUFBVSxVQUNaO0dBQ0EsSUFBSSxFQUFFO1FBQ0EsS0FBSyxRQUFRLDhCQUE4QixPQUM3QyxLQUFLLGlCQUFpQixpQkFBaUIsQ0FBQyxHQUFHLENBQUMsR0FBRyxhQUFhO1NBQ3ZELElBQUksS0FBSyxRQUFRLDhCQUE4QixXQUNwRCxLQUFLLGlCQUFpQixpQkFBaUIsRUFBRSxVQUFVLGFBQWE7R0FBQSxPQUdsRSxJQUFJLEVBQUUsVUFBVSxLQUFLLFFBQVEsb0JBQW9CLFdBQy9DLEtBQUssaUJBQWlCLGVBQWUsRUFBRSxNQUFNO1FBQ3hDLElBQUksS0FBSyxRQUFRLDhCQUE4QixZQUNwRCxLQUFLLGlCQUFpQixpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUduRCxDQUFDO0NBQ0g7Q0FDQSxvQkFBb0IsYUFBYSxRQUFROzs7RUFDdkMsSUFBSSxLQUFLLGFBQWE7RUFDdEIsTUFBTSxVQUFBLGFBQVMsVUFBVSxLQUFLLFlBQVksaUJBQWlCLE9BQUEsUUFBQSxlQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsV0FBRyxPQUFPO0VBQ3JFLEtBQUssS0FBSyxrQkFBQSxrQkFBQSxhQUE4QjtHQUN0QyxNQUFNLElBQUksU0FBUSxZQUFXO0lBQzNCLFdBQVcsT0FBTztJQUNsQixJQUFJLE9BQU8sMEJBQTBCLGFBQ25DLHNCQUFzQixPQUFPO0dBRWpDLENBQUM7R0FDRCxNQUFLLEtBQUssVUFBVTtJQUNsQixNQUFLLFlBQVksT0FBTyxLQUFLLElBQUksT0FBTyxhQUFhQyxNQUFLLGVBQWUsYUFBYUEsTUFBSyxNQUFNQSxNQUFLLGNBQWMsTUFBTSxRQUFRLE1BQU0sQ0FBQztHQUMzSSxDQUFDO0VBQ0gsQ0FBQSxDQUFDO0NBQ0g7Q0FDQSxjQUFjOztFQUNaLENBQUEsd0JBQUEsS0FBSyw4QkFBQSxRQUFBLDBCQUFBLEtBQUEsS0FBQSxzQkFBMEIsWUFBWTtFQUMzQyxDQUFBLHdCQUFBLEtBQUssOEJBQUEsUUFBQSwwQkFBQSxLQUFBLEtBQUEsc0JBQTBCLFlBQVk7Q0FDN0M7QUFRRjs7Z0NBUFMsUUFBTyxTQUFTLHVCQUF1QixtQkFBbUI7Q0FDL0QsaUJBQW9CO0FBQ3RCLENBQUE7Z0NBQ08sU0FBdUIsbUNBQXNCO0NBQ2xELE9BQU9DO0NBQ1AsU0FBU0EsZ0JBQWU7QUFDMUIsQ0FBQyxDQUFBO09BRUk7Q0FDTCxDQUFDLE9BQU8sY0FBYyxlQUFlLGNBQWN0QixpQkFBcUIsZ0JBQWdCLENBQUMsRUFDdkYsTUFBTSxXQUNSLENBQUMsU0FBUyxDQUFDLEVBQ1QsTUFBTSxLQUFBLEVBQ1IsQ0FBQyxHQUFHLElBQUk7QUFDVixFQUFBLENBQUc7QUFDSCxTQUFTLGdCQUFnQixPQUFPO0NBQzlCLE9BQU8sTUFBTTtBQUNmO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtDQUNuQyxPQUFPLFNBQVMsSUFBSSxRQUFRLE1BQU0sRUFDaEMsVUFBVSxLQUNaLENBQUM7QUFDSDtBQUNBLFNBQVMsY0FBYyxRQUFRLEtBQUs7Q0FDbEMsSUFBSSxFQUFFLGtCQUFrQixTQUN0QixNQUFNLElBQUksTUFBTSwrQ0FBK0M7Q0FFakUsT0FBTyxPQUFPLGNBQWMsR0FBRztBQUNqQztBQUNBLElBQU0seUJBQU4sY0FBcUMsYUFBYTtDQWFoRCxJQUFJLGFBQWE7RUFDZixPQUFPLEtBQUssaUNBQWlDLEtBQUEsS0FBYSxDQUFDLEtBQUssNkJBQTZCO0NBQy9GO0NBQ0EsY0FBYzs7RUFDWixNQUFNO3dCQWhCUixZQUFXLE9BQU8sbUJBQW1CLENBQUE7d0JBQ3JDLGNBQWEsT0FBTyxrQkFBa0IsQ0FBQTt3QkFDdEMsNEJBQTJCLE9BQU8saUJBQWlCLEVBQ2pELFVBQVUsS0FDWixDQUFDLE1BQU0sSUFBQTt3QkFDUCxRQUFPLElBQUksSUFBSSxPQUFPLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBQTt3QkFDOUMsY0FBYSxJQUFJLEtBQUEseUJBQUEsMEJBQUEsaUJBQUksS0FBSyxTQUFBLENBQVMsd0JBQUEsUUFBQSwyQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHVCQUFBLEtBQUEsZ0JBQXFCLEdBQUcsT0FBQSxRQUFBLDBCQUFBLEtBQUEsSUFBQSx3QkFBSyxLQUFLLEtBQUssSUFBSSxDQUFBO3dCQUM5RSw2QkFBNEIsT0FBT3VCLDJCQUE0QixDQUFBO3dCQUMvRCxzQkFBcUIsS0FBSyxXQUFXLFlBQUE7d0JBQ3JDLHFCQUFvQixDQUFDLENBQUE7d0JBQ3JCLHNDQUFxQyxJQUFJLFFBQVEsQ0FBQTt3QkFDakQsZ0NBQUEsS0FBQSxDQUFBO0VBTUUsTUFBTSxvQkFBbUIsVUFBUztHQUNoQyxLQUFLLGVBQWUsS0FBSztFQUMzQjtFQUNBLEtBQUssV0FBVyxpQkFBaUIsWUFBWSxnQkFBZ0I7RUFDN0QsT0FBTyxVQUFVLENBQUMsQ0FBQyxnQkFBZ0IsS0FBSyxXQUFXLG9CQUFvQixZQUFZLGdCQUFnQixDQUFDO0NBQ3RHO0NBQ0EsNENBQTRDLFVBQVU7RUFDcEQsS0FBSyxxQkFBcUIsS0FBSyxXQUFXO0VBQzFDLEtBQUssK0JBQStCLEtBQUssbUNBQW1DLFdBQVcsRUFDckYsTUFDQSxZQUNJO0dBQ0osU0FBUyxNQUFNLE9BQU8sWUFBWSxDQUFDLEtBQUssNEJBQTRCLEVBQ2xFLFlBQVksS0FDZCxJQUFJLENBQUMsQ0FBQztFQUNSLENBQUM7RUFDRCxPQUFPLEtBQUs7Q0FDZDtDQUNBLGtCQUF3QixHQUFHLFlBQUE7O3dDQUFZO0dBQ3JDLE9BQUssb0JBQUEsZUFBQSxlQUFBLENBQUEsR0FDQUYsT0FBSyxpQkFBQSxHQUFBLENBQUEsR0FBQSxFQUNSLGtCQUFrQixXQUFBLENBQ3BCO0dBQ0EsSUFBSSxhQUFhLGlCQUFpQjtJQUNoQyxPQUFLLG1CQUFtQjtJQUN4QixJQUFJQSxPQUFLLDJCQUNQLE9BQUssbUNBQW1DLFVBQVU7R0FFdEQsT0FBTyxJQUFJLGFBQWEsbUJBQW1CO0lBQ3pDLE9BQUssaUJBQWlCO0lBQ3RCLE9BQUssaUJBQWlCLFVBQVU7R0FDbEMsT0FBTyxJQUFJLGFBQWEsd0JBQ3RCLFdBQVcsdUJBQXVCLGlCQUFpQixJQUFJLFFBQUEsV0FBQTs0Q0FBYyxTQUFXO0tBQzlFLElBQUlBLE9BQUssc0JBQXNCLFNBQzdCLElBQUk7O01BQ0YsT0FBSyxtQ0FBbUMsVUFBVTtNQUNsRCxPQUFBLHlCQUFBLHlCQUFNQSxPQUFLLGtCQUFBLENBQWtCLGVBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFBLEtBQUEsc0JBQVk7S0FDM0MsU0FBQSxTQUFRO01BQ047S0FDRjtLQUVGLFFBQVE7SUFDVixDQUFBO29CQVZxRSxJQUFBOzs7S0FVckUsQ0FBQztRQUNJLElBQUksYUFBYSxzQkFDdEIsV0FBVyxzQkFBc0IsaUJBQWlCLElBQUksUUFBQSxXQUFBOzZDQUFjLFNBQVc7S0FDN0UsSUFBSUEsT0FBSyxzQkFBc0IsWUFDN0IsSUFBSTs7TUFDRixPQUFLLG1DQUFtQyxVQUFVO01BQ2xELE9BQUEsMEJBQUEseUJBQU1BLE9BQUssa0JBQUEsQ0FBa0IsZUFBQSxRQUFBLDJCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsdUJBQUEsS0FBQSxzQkFBWTtLQUMzQyxTQUFBLFVBQVE7TUFDTjtLQUNGO0tBRUYsT0FBSyxpQkFBaUIsVUFBVTtLQUNoQyxRQUFRO0lBQ1YsQ0FBQTtvQkFYb0UsS0FBQTs7O0tBV3BFLENBQUM7UUFDSSxJQUFJLGFBQWEsb0JBQW9CLGFBQWEsaUJBQWlCO0lBRXhFLElBRG1DLGFBQWEsb0JBQW9CLEVBQUUsU0FBUywyQkFBMkIsWUFBWSxDQUFDLENBQUNBLE9BQUssa0JBQWtCLFdBRTdJO0lBRUYsT0FBVSxPQUFPLFlBQVksQ0FBQztHQUNoQyxPQUFPLElBQUksYUFBYSxlQUFlO0lBQ3JDLE1BQU0sRUFDSixnQkFDQSx3QkFDRUEsT0FBSztJQUNULE9BQUssb0JBQW9CLENBQUM7SUFDMUIsd0JBQUEsUUFBQSx3QkFBQSxLQUFBLEtBQUEsb0JBQXNCO0lBQ3RCLE9BQUsscUJBQXFCQSxPQUFLLFdBQVc7SUFDMUMsZ0JBQWdCLEVBQ2QsWUFBQSxtQkFBQSxRQUFBLG1CQUFBLEtBQUEsSUFBQSxLQUFBLElBQVksZUFBaUIsRUFDL0IsR0FBRyxFQUNELFVBQVVBLE9BQUssU0FDakIsQ0FBQztHQUNIO0VBQ0YsQ0FBQSxDQUFBLENBQUE7O0NBQ0EsbUNBQW1DLFlBQVk7O0VBQzdDLE1BQU0sRUFDSixpQkFDQSxjQUNFLEtBQUs7RUFDVCxJQUFJLGFBQWEsbUJBQW1CLGdCQUFnQixtQkFBbUIsY0FBYyxLQUFLLGdDQUFnQyxpQkFBaUIsVUFBVSxHQUNuSjtFQUVGLENBQUEsMEJBQUEseUJBQUEsS0FBSyxrQkFBQSxDQUFrQix5QkFBQSxRQUFBLDJCQUFBLEtBQUEsS0FBQSx1QkFBQSxLQUFBLHNCQUFzQjtFQUM3QyxNQUFNLE9BQU8sS0FBSyxrQkFBa0IsVUFBVTtFQUM5QyxLQUFLLFNBQVMsTUFBTSxVQUFVO0NBQ2hDO0NBQ0EsU0FBUyxjQUFjLFlBQVk7RUFDakMsTUFBTSxPQUFPLFdBQVcsT0FBTyxxQkFBcUIsS0FBSyxXQUFXLGFBQWEsTUFBTSxLQUFLLFNBQVMsbUJBQW1CLFlBQVk7RUFDcEksTUFBTSxRQUFBLGVBQUEsZUFBQSxDQUFBLEdBQ0QsV0FBVyxPQUFPLEtBQUEsR0FDbEIsS0FBSyxzQkFBc0IsVUFBVSxDQUMxQztFQUNBLE1BQU0sT0FBTyxFQUNYLGFBQWEsRUFDWCxXQUFXLEtBQ2IsRUFDRjtFQUNBLElBQUksQ0FBQyxLQUFLLFdBQVcsY0FBYyxLQUFLLGtCQUFrQixpQkFDeEQsV0FBVyxPQUFPLGFBQWE7RUFFakMsTUFBTSxVQUFVLEtBQUssU0FBUyxxQkFBcUIsSUFBSSxLQUFLLFdBQVcsT0FBTyxjQUFjLFdBQVcsT0FBTyxxQkFBcUIsWUFBWTtFQUMvSSx1QkFBdUIsS0FBSyxXQUFXLFNBQVMsTUFBTTtHQUNwRDtHQUNBO0dBQ0E7RUFDRixDQUFDLENBQUM7Q0FDSjtDQUNBLG1CQUFtQjs7RUFDakIsQ0FBQSwwQkFBQSx5QkFBQSxLQUFLLGtCQUFBLENBQWtCLGVBQUEsUUFBQSwyQkFBQSxLQUFBLEtBQUEsdUJBQUEsS0FBQSxzQkFBWTtFQUNuQyxDQUFBLHlCQUFBLEtBQUssdUJBQUEsUUFBQSwyQkFBQSxLQUFBLE1BQUEsMEJBQUEsdUJBQW1CLG9CQUFBLFFBQUEsNEJBQUEsS0FBQSxLQUFBLHdCQUFBLEtBQUEsc0JBQWlCO0VBQ3pDLEtBQUssb0JBQW9CLENBQUM7Q0FDNUI7Q0FDQSxPQUFhLFlBQVksT0FBQTs7d0NBQU87O0dBQzlCLENBQUEsMkJBQUEsMEJBQUEsT0FBSyxrQkFBQSxDQUFrQix5QkFBQSxRQUFBLDRCQUFBLEtBQUEsS0FBQSx3QkFBQSxLQUFBLHVCQUFzQjtHQUM3QyxNQUFNLGVBQWUsQ0FBQztHQUN0QixPQUFLLG9CQUFvQjtHQUN6QixJQUFJLG1CQUFtQixLQUFLLEdBQzFCO0dBRUYsTUFBTSxtQkFBbUJBLE9BQUssaUNBQWlDLGNBQWNBLE9BQUssV0FBVyxhQUFhLFFBQVFBLE9BQUssbUJBQW1CO0dBQzFJLE9BQUssbUJBQW1CLFdBQVcsVUFBVSxnQkFBZ0I7R0FDN0QsSUFBSUEsT0FBSyxXQUFXLGFBQWEsT0FBT0EsT0FBSyxtQkFBbUIsSUFDOUQ7R0FFRixJQUFJLGlCQUFpQixvQkFBb0IsTUFBTSxTQUFTLDJCQUEyQixTQUFTO0lBQzFGLE1BQU0sUUFBUSxRQUFRO0lBQ3RCLElBQUlBLE9BQUssc0JBQXNCLGNBQzdCO0dBRUo7R0FDQSxJQUFJLGtCQUNGLHVCQUF1QkEsT0FBSyxXQUFXLFdBQVdBLE9BQUssbUJBQW1CLEtBQUssRUFDN0UsTUFBTSxFQUNKLGFBQWEsRUFDWCxXQUFXLE1BQ2IsRUFDRixFQUNGLENBQUMsQ0FBQztRQUNHO0lBQ0wsTUFBTSxlQUFlQSxPQUFLLGNBQWMsVUFBVUEsT0FBSyxrQkFBa0IsQ0FBQztJQUMxRSxNQUFNLFlBQVlBLE9BQUssU0FBUyxtQkFBbUIsWUFBWTtJQUMvRCx1QkFBdUJBLE9BQUssV0FBVyxTQUFTLFdBQVc7S0FDekQsT0FBT0EsT0FBSyxtQkFBbUIsU0FBUztLQUN4QyxTQUFTO0tBQ1QsTUFBTSxFQUNKLGFBQWEsRUFDWCxXQUFXLE1BQ2IsRUFDRjtJQUNGLENBQUMsQ0FBQztHQUNKO0VBQ0YsQ0FBQSxDQUFBLENBQUE7O0NBQ0EsbUJBQW1CLFVBQVUsZ0JBQWdCO0VBQzNDLEtBQUssY0FBYyxLQUFLLGFBQWE7RUFDckMsS0FBSyxpQkFBaUIsS0FBSyxhQUFhO0VBQ3hDLEtBQUssYUFBYSxpQkFBaUIsS0FBSyxhQUFhLGFBQWEsS0FBSyxvQkFBb0IsTUFBTSxLQUFLLGdCQUFnQixhQUFBLFFBQUEsYUFBQSxLQUFBLElBQUEsV0FBWSxLQUFLLFVBQVU7Q0FDbko7Q0FDQSxlQUFlLE9BQU87OztFQUNwQixJQUFJLENBQUMsTUFBTSxnQkFBZ0IsTUFBTSxtQkFBbUIsVUFDbEQ7RUFFRixNQUFNLGFBQUEsVUFBQSxRQUFBLFVBQUEsS0FBQSxNQUFBLGNBQWEsTUFBTyxVQUFBLFFBQUEsZ0JBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSxZQUFNO0VBQ2hDLElBQUksY0FBYyxDQUFDLFdBQVcsV0FDNUI7RUFFRixNQUFNLGdDQUFnQyxDQUFDLENBQUM7RUFDeEMsSUFBSSxDQUFDLCtCQUErQjs7R0FDbEMsTUFBTSxFQUNKLFVBQVUsY0FDVixRQUFRLGVBQ04sSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHO0dBQ2pDLE1BQU0sRUFDSixVQUFVLGNBQ1YsUUFBUSxjQUNOLEtBQUs7R0FDVCxNQUFNLFdBQVcsYUFBYSxTQUFTLEdBQUcsSUFBSSxlQUFlLGVBQWU7R0FDNUUsSUFBSSxlQUFlLGFBQWEsaUJBQWlCLGdCQUFnQixDQUFDLGFBQWEsV0FBVyxRQUFRLEdBQ2hHO0dBRUYsQ0FBQSwwQkFBQSxLQUFLLGtCQUFrQixzQkFBQSxRQUFBLDRCQUFBLEtBQUEsS0FBQSx3QkFBa0IsTUFBTTtHQUMvQyxJQUFJLENBQUMsS0FBSyxZQUFZO0lBQ3BCLEtBQUssaUJBQWlCO0lBQ3RCO0dBQ0Y7RUFDRjtFQUNBLEtBQUssb0JBQUEsZUFBQSxDQUFBLEdBQ0EsS0FBSyxpQkFDVjtFQUNBLEtBQUssa0JBQWtCLGtCQUFrQjtFQUN6QyxNQUFNLHFCQUFxQjs7R0FDekIsQ0FBQSwwQkFBQSxLQUFLLGtCQUFrQixzQkFBQSxRQUFBLDRCQUFBLEtBQUEsS0FBQSx3QkFBa0IsTUFBTTtFQUNqRDtFQUNBLE1BQU0sT0FBTyxpQkFBaUIsU0FBUyxZQUFZO0VBQ25ELEtBQUssa0JBQWtCLDRCQUE0QixNQUFNLE9BQU8sb0JBQW9CLFNBQVMsWUFBWTtFQUV6RyxNQUFNLG1CQUFtQixFQUN2QixRQUZXLEtBQUssMkJBQTJCLFlBQUEsMkJBQUEsMEJBQVcsS0FBSyxrQkFBa0Isc0JBQUEsUUFBQSw0QkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHdCQUFrQixPQUFPLFlBQUEsUUFBQSw0QkFBQSxLQUFBLElBQUEsMEJBQVUsbUJBR2xIO0VBQ0EsTUFBTSxFQUNKLFNBQVMsZ0JBQ1QsU0FBUyxnQkFDVCxRQUFRLGtCQUNORyxxQkFBc0I7RUFDMUIsTUFBTSxFQUNKLFNBQVMseUJBQ1QsU0FBUyx5QkFDVCxRQUFRLDJCQUNOQSxxQkFBc0I7RUFDMUIsS0FBSyxrQkFBa0IsNEJBQTRCO0dBQ2pELE1BQU0sT0FBTyxvQkFBb0IsU0FBUyxZQUFZO0dBQ3RELHVCQUF1QjtHQUN2QixjQUFjO0VBQ2hCO0VBQ0EsS0FBSyxrQkFBa0IsdUJBQXVCOztHQUM1QyxDQUFBLDJCQUFBLDBCQUFBLEtBQUssa0JBQUEsQ0FBa0IseUJBQUEsUUFBQSw0QkFBQSxLQUFBLEtBQUEsd0JBQUEsS0FBQSx1QkFBc0I7R0FDN0MsZUFBZTtFQUNqQjtFQUNBLGVBQWUsWUFBWSxDQUFDLENBQUM7RUFDN0Isd0JBQXdCLFlBQVksQ0FBQyxDQUFDO0VBQ3RDLGlCQUFpQixnQkFBZ0I7RUFDakMsSUFBSSxLQUFLLHdCQUF3QixLQUFLLEdBQUc7R0FDdkMsTUFBTSxXQUFXLElBQUksU0FBUSxZQUFXO0lBQ3RDLGlCQUFpQixvQkFBbUIsZUFBYzs7S0FDaEQsTUFBQSx3QkFBSSxLQUFLLFdBQVcsZ0JBQUEsUUFBQSwwQkFBQSxLQUFBLElBQUEsS0FBQSxJQUFBLHNCQUFZLG9CQUFtQixZQUNqRCxjQUFjLENBQUMsQ0FBQztVQUVoQixRQUFRLFdBQVcsU0FBUyxLQUFLLFVBQVUsQ0FBQztLQUU5QyxPQUFPO0lBQ1Q7R0FDRixDQUFDO0dBQ0QsS0FBSyxrQkFBa0IsWUFBQSxrQkFBQSxhQUF3Qjs7SUFDN0MsT0FBSyxrQkFBa0IsWUFBWSxLQUFBO0lBQ25DLE1BQU0sYUFBYUgsT0FBSyxrQkFBa0I7SUFDMUMsSUFBSSxjQUFjLENBQUMsV0FBVyxPQUFPLG9CQUFvQjtLQUN2RCxNQUFNLGVBQWVBLE9BQUssa0JBQWtCLFVBQVU7S0FDdEQsTUFBTSxVQUFVQSxPQUFLLFNBQVMscUJBQXFCLFlBQVksS0FBSyxDQUFDLENBQUMsV0FBVyxPQUFPLGFBQWEsWUFBWTtLQUNqSCxNQUFNLFFBQUEsZUFBQSxlQUFBLENBQUEsR0FDRCxXQUFXLE9BQU8sS0FBQSxHQUNsQkEsT0FBSyxzQkFBc0IsVUFBVSxDQUMxQztLQUNBLE1BQU0sWUFBWUEsT0FBSyxTQUFTLG1CQUFtQixZQUFZO0tBQy9ELENBQUMsTUFBTSxTQUFBLENBQVUsV0FBVztNQUMxQjtNQUNBO0tBQ0YsQ0FBQztJQUNIO0lBQ0Esd0JBQXdCO0lBQ3hCLE9BQU8sT0FBQSx5QkFBTUEsT0FBSyxXQUFXLGdCQUFBLFFBQUEsMkJBQUEsS0FBQSxJQUFBLEtBQUEsSUFBQSx1QkFBWTtHQUMzQyxDQUFBO0VBQ0Y7RUFDQSxNQUFNLFVBQVUsZ0JBQWdCO0VBQ2hDLElBQUksQ0FBQywrQkFDSCxLQUFLLDhDQUE4QyxLQUFLO0NBRTVEO0NBQ0EsOENBQThDLE9BQU87RUFDbkQsTUFBTSxPQUFPLE1BQU0sWUFBWSxJQUFJLFVBQVUsS0FBSyxXQUFXLEtBQUssU0FBUyxDQUFDO0VBQzVFLE1BQU0sUUFBUSxNQUFNLFlBQVksU0FBUztFQUN6QyxLQUFLLG1DQUFtQyxLQUFLO0dBQzNDO0dBQ0E7RUFDRixDQUFDO0NBQ0g7Q0FDQSxnQ0FBZ0MsZUFBZSxZQUFZO0VBQ3pELE1BQU0sZUFBZSxLQUFLLGtCQUFrQixVQUFVO0VBQ3RELE1BQU0sbUJBQW1CLElBQUksSUFBSSxjQUFjLFlBQVksR0FBRztFQUM5RCxNQUFNLG9CQUFvQixJQUFJLElBQUksS0FBSyxTQUFTLG1CQUFtQixZQUFZLEdBQUcsaUJBQWlCLE1BQU07RUFDekcsaUJBQWlCLGFBQWEsS0FBSztFQUNuQyxrQkFBa0IsYUFBYSxLQUFLO0VBQ3BDLE1BQU0sRUFDSixVQUFVLGNBQ1YsUUFBUSxZQUNSLE1BQU0sYUFDSjtFQUNKLE1BQU0sRUFDSixVQUFVLG1CQUNWLFFBQVEsaUJBQ1IsTUFBTSxrQkFDSjtFQUNKLE9BQU8sZUFBZSxtQkFBbUIsYUFBYSxpQkFBaUIsU0FBUyxtQkFBbUIsWUFBWSxNQUFNLFNBQVMsbUJBQW1CLGlCQUFpQjtDQUNwSztDQUNBLHNCQUFzQixZQUFZO0VBQ2hDLE9BQUEsZUFBQSxlQUFBLENBQUEsR0FDSyxLQUFLLGVBQWUsVUFBVSxDQUFBLEdBQUEsQ0FBQSxHQUFBLEVBQ2pDLGNBQWMsV0FBVyxHQUFBLENBQzNCO0NBQ0Y7Q0FDQSx3QkFBd0IsT0FBTztFQUM3QixPQUFPLEtBQUssNkJBQTZCLE1BQU07Q0FDakQ7QUFRRjs7d0NBUFMsUUFBTyxTQUFTLCtCQUErQixtQkFBbUI7Q0FDdkUsT0FBTyxLQUFLLHFCQUFxQkkseUJBQXdCO0FBQzNELENBQUE7d0NBQ08sU0FBdUIsZ0NBQW1CO0NBQy9DLE9BQU9BO0NBQ1AsU0FBU0Esd0JBQXVCO0FBQ2xDLENBQUMsQ0FBQTtPQUVJO0NBQ0wsQ0FBQyxPQUFPLGNBQWMsZUFBZSxjQUFjekIsaUJBQXFCLHdCQUF3QixDQUFDLEVBQy9GLE1BQU0sUUFDUixDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFDcEIsRUFBQSxDQUFHO0FBQ0gsU0FBUyx1QkFBdUIsUUFBUTs7Q0FDdEMsQ0FBQSxtQkFBQSxPQUFPLGNBQUEsUUFBQSxxQkFBQSxLQUFBLEtBQUEsaUJBQVUsWUFBWSxDQUFDLENBQUM7Q0FDL0IsQ0FBQSxvQkFBQSxPQUFPLGVBQUEsUUFBQSxzQkFBQSxLQUFBLEtBQUEsa0JBQVcsWUFBWSxDQUFDLENBQUM7Q0FDaEMsT0FBTztBQUNUO0FBQ0EsU0FBUywrQkFBK0I7Q0FDdEMsT0FBTyxLQUFLLEVBQ1Ysb0JBQ0Esd0JBQ0k7RUFDSixJQUFJLENBQUMsc0JBQXNCLENBQUMsbUJBQzFCO0VBRUYsTUFBTSxZQUFXLGNBQWE7R0FDNUIsTUFBTSxRQUFRLFVBQVU7R0FDeEIsSUFBSSxPQUNGLGFBQWEsT0FBTyxrQkFBa0I7R0FFeEMsS0FBSyxNQUFNLGNBQWMsVUFBVSxVQUNqQyxTQUFTLFVBQVU7RUFFdkI7RUFDQSxTQUFTLGtCQUFrQixLQUFLO0NBQ2xDLENBQUM7QUFDSDtBQUNBLFNBQVMsYUFBYSxPQUFPLG9CQUFvQjs7Q0FFL0MsSUFBSSxFQUFBLFVBQUEsUUFBQSxVQUFBLEtBQUEsTUFBQSxxQkFEOEIsTUFBTyxpQkFBQSxRQUFBLHVCQUFBLEtBQUEsSUFBQSxLQUFBLElBQUEsbUJBQWEsNkJBRXBEO0NBRUYsSUFBSSxtQkFBbUIsSUFBSSxLQUFLLEdBQzlCLCtCQUErQixNQUFNLGlCQUFpQixLQUFLO0FBRS9EO0FBQ0EsU0FBUywrQkFBK0IsVUFBVSxPQUFPO0NBQ3ZELElBQUksYUFBYSxDQUFDLENBQUMsTUFBTSxnQkFDdkIsTUFBTSxJQUFJLE1BQU0sb0ZBQW9GO0NBRXRHLE1BQU0saUJBQWlCLDBCQUEwQixDQUFDLEdBQUcsU0FBUyxvQkFBb0I7QUFDcEY7QUFDQSxTQUFTLGNBQWMsUUFBUSxHQUFHLFVBQVU7Q0FDMUMsSUFBSSxPQUFPLGNBQWMsZUFBZSxXQUFXO0VBQ2pELHlCQUEwQixvQkFBb0IsZUFBZTtFQUM3RCx5QkFBMEIsc0JBQXNCLGlCQUFpQjtFQUNqRSx5QkFBMEIsa0JBQWtCLGFBQWE7Q0FDM0Q7Q0FDQSxPQUFPLHlCQUF5QjtFQUFDO0dBQy9CLFNBQVM7R0FDVCxPQUFPO0dBQ1AsVUFBVTtFQUNaO0VBQUc7R0FDRCxTQUFTO0dBQ1QsWUFBWTtFQUNkO0VBQUc7R0FDRCxTQUFTO0dBQ1QsT0FBTztHQUNQLFlBQVk7RUFDZDtFQUFHLFNBQVMsS0FBSSxZQUFXLFFBQVEsVUFBVTtDQUFDLENBQUM7QUFDakQ7QUFDQSxTQUFTLFlBQVk7Q0FDbkIsT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDLFlBQVk7QUFDcEM7QUFDQSxTQUFTLGNBQWMsTUFBTSxXQUFXO0NBQ3RDLE9BQU87RUFDTCxPQUFPO0VBQ1AsWUFBWTtDQUNkO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQixVQUFVLENBQUMsR0FBRztDQUszQyxPQUFPLGNBQWMsR0FBRyxDQUpMO0VBQ2pCLFNBQVM7RUFDVCxrQkFBa0IsSUFBSSxlQUFlLE9BQU87Q0FDOUMsQ0FDZ0MsQ0FBQztBQUNuQztBQUNBLFNBQVMscUNBQXFDO0NBQzVDLE1BQU0sdUJBQXVCLE9BQU8sY0FBYyxlQUFlLFlBQVksQ0FBQyxvQ0FBb0M7RUFDaEgsTUFBTSxtQkFBbUIsT0FBTyxRQUFRO0VBQ3hDLElBQUksRUFBRSw0QkFBNEIwQiwrQkFBZ0M7R0FDaEUsTUFBTSwwQkFBMEIsaUJBQWlCLFlBQVk7R0FDN0QsSUFBSSxVQUFVLGdKQUFxSix3QkFBd0I7R0FDM0wsSUFBSSw0QkFBNEIsZUFDOUIsV0FBVztHQUViLE1BQU0sSUFBSSxNQUFNLE9BQU87RUFDekI7Q0FDRixDQUFDLENBQUMsSUFBSSxDQUFDO0NBUVAsT0FBTyxjQUFjLElBQUk7RUFQTjtHQUNqQixTQUFTO0dBQ1QsYUFBYTtFQUNmO0VBQUc7R0FDRCxTQUFTO0dBQ1QsVUFBVUE7RUFDWjtFQUFHO0NBQzhCLENBQUM7QUFDcEM7QUFDQSxTQUFTLHVCQUF1QjtDQUM5QixNQUFNLFdBQVcsT0FBTyxRQUFRO0NBQ2hDLFFBQU8sNkJBQTRCOztFQUNqQyxNQUFNLE1BQU0sU0FBUyxJQUFJLGNBQWM7RUFDdkMsSUFBSSw2QkFBNkIsSUFBSSxXQUFXLElBQzlDO0VBRUYsTUFBTSxTQUFTLFNBQVMsSUFBSSxNQUFNO0VBQ2xDLE1BQU0sZ0JBQWdCLFNBQVMsSUFBSSxjQUFjO0VBQ2pELElBQUksU0FBUyxJQUFJLGtCQUFrQixNQUFNLEdBQ3ZDLE9BQU8sa0JBQWtCO0VBRTNCLENBQUEsZ0JBQUEsU0FBUyxJQUFJLGtCQUFrQixNQUFNLEVBQ25DLFVBQVUsS0FDWixDQUFDLE9BQUEsUUFBQSxrQkFBQSxLQUFBLEtBQUEsY0FBRyxnQkFBZ0I7RUFDcEIsQ0FBQSxpQkFBQSxTQUFTLElBQUksaUJBQWlCLE1BQU0sRUFDbEMsVUFBVSxLQUNaLENBQUMsT0FBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFHLEtBQUs7RUFDVCxPQUFPLHVCQUF1QixJQUFJLGVBQWUsRUFBRTtFQUNuRCxJQUFJLENBQUMsY0FBYyxRQUFRO0dBQ3pCLGNBQWMsS0FBSztHQUNuQixjQUFjLFNBQVM7R0FDdkIsY0FBYyxZQUFZO0VBQzVCO0NBQ0Y7QUFDRjtBQUNBLElBQU0saUJBQWlCLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLDZCQUE2QixJQUFJLEVBQ3pILGVBQWU7Q0FDYixPQUFPLElBQUksUUFBUTtBQUNyQixFQUNGLENBQUM7QUFDRCxJQUFNLHFCQUFxQixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSx1QkFBdUIsSUFBSSxFQUN2SCxlQUFlLEVBQ2pCLENBQUM7QUFDRCxTQUFTLHVDQUF1QztDQXlCOUMsT0FBTyxjQUFjLEdBQUc7RUF4Qkw7R0FDakIsU0FBU0M7R0FDVCxVQUFVO0VBQ1o7RUFBRztHQUNELFNBQVM7R0FDVCxVQUFVO0VBQ1o7RUFBRyw0QkFBNEI7R0FDN0IsTUFBTSxXQUFXLE9BQU8sUUFBUTtHQUVoQyxPQUQ0QixTQUFTLElBQUksc0JBQXNCLFFBQVEsUUFBUSxDQUN0RCxDQUFDLENBQUMsV0FBVztJQUNwQyxPQUFPLElBQUksU0FBUSxZQUFXO0tBQzVCLE1BQU0sU0FBUyxTQUFTLElBQUksTUFBTTtLQUNsQyxNQUFNLGdCQUFnQixTQUFTLElBQUksY0FBYztLQUNqRCxvQkFBb0IsY0FBYztNQUNoQyxRQUFRLElBQUk7S0FDZCxDQUFDO0tBQ0QsU0FBUyxJQUFJLHFCQUFxQixDQUFDLENBQUMsMkJBQTJCO01BQzdELFFBQVEsSUFBSTtNQUNaLE9BQU8sY0FBYyxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUk7S0FDN0M7S0FDQSxPQUFPLGtCQUFrQjtJQUMzQixDQUFDO0dBQ0gsQ0FBQztFQUNILENBQUM7Q0FDK0IsQ0FBQztBQUNuQztBQUNBLFNBQVMsZ0NBQWdDO0NBT3ZDLE9BQU8sY0FBYyxHQUFHLENBTkwsNEJBQTRCO0VBQzdDLE9BQU8sTUFBTSxDQUFDLENBQUMsNEJBQTRCO0NBQzdDLENBQUMsR0FBRztFQUNGLFNBQVM7RUFDVCxVQUFVO0NBQ1osQ0FDZ0MsQ0FBQztBQUNuQztBQUNBLFNBQVMsbUJBQW1CO0NBQzFCLElBQUksWUFBWSxDQUFDO0NBQ2pCLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsWUFBWSxDQUFDO0VBQ1gsU0FBUztFQUNULE9BQU87RUFDUCxrQkFBa0I7R0FDaEIsTUFBTSxTQUFTLE9BQU8sTUFBTTtHQUM1QixhQUFhLE9BQU8sT0FBTyxXQUFVLE1BQUs7O0lBQ3hDLENBQUEsa0JBQUEsV0FBQSxRQUFBLENBQVEsV0FBQSxRQUFBLG1CQUFBLEtBQUEsS0FBQSxlQUFBLEtBQUEsVUFBUSxpQkFBaUIsRUFBRSxZQUFZLE1BQU07SUFDckQsUUFBUSxJQUFJLGVBQWUsQ0FBQyxDQUFDO0lBQzdCLFFBQVEsSUFBSSxDQUFDO0lBQ2IsQ0FBQSxxQkFBQSxZQUFBLFFBQUEsQ0FBUSxjQUFBLFFBQUEsc0JBQUEsS0FBQSxLQUFBLGtCQUFBLEtBQUEsU0FBVztHQUNyQixDQUFDO0VBQ0g7Q0FDRixDQUFDO01BRUQsWUFBWSxDQUFDO0NBRWYsT0FBTyxjQUFjLEdBQUcsU0FBUztBQUNuQztBQUNBLElBQU0sbUJBQW1CLElBQUksZUFBZSxPQUFPLGNBQWMsZUFBZSxZQUFZLHFCQUFxQixFQUFFO0FBQ25ILFNBQVMsZUFBZSxvQkFBb0I7Q0FRMUMsT0FBTyxjQUFjLEdBQUcsQ0FQTDtFQUNqQixTQUFTO0VBQ1QsYUFBYTtDQUNmLEdBQUc7RUFDRCxTQUFTO0VBQ1QsYUFBYTtDQUNmLENBQ2dDLENBQUM7QUFDbkM7QUFDQSxTQUFTLGlCQUFpQixTQUFTO0NBS2pDLE9BQU8sY0FBYyxHQUFHLENBSkw7RUFDakIsU0FBUztFQUNULFVBQVU7Q0FDWixDQUNnQyxDQUFDO0FBQ25DO0FBQ0EsU0FBUyxtQkFBbUI7Q0FLMUIsT0FBTyxjQUFjLEdBQUcsQ0FKTDtFQUNqQixTQUFTO0VBQ1QsVUFBVTtDQUNaLENBQ2dDLENBQUM7QUFDbkM7QUFDQSxTQUFTLDJCQUEyQixTQUFTO0NBSzNDLE9BQU8sY0FBYyxHQUFHLENBSkw7RUFDakIsU0FBUztFQUNULFVBQVU7Q0FDWixDQUNnQyxDQUFDO0FBQ25DO0FBQ0EsU0FBUyx1Q0FBdUM7Q0FDOUMsT0FBTyxjQUFjLElBQUksQ0FBQztFQUN4QixTQUFTO0VBQ1QsVUFBVTtDQUNaLENBQUMsQ0FBQztBQUNKO0FBQ0EsU0FBUywwQkFBMEIsVUFBVSxDQUFDLEdBQUc7Q0FLL0MsT0FBTyxjQUFjLEdBQUcsQ0FKTDtFQUNqQixTQUFTO0VBQ1Qsa0JBQWtCLElBQUksMkJBQTJCLE9BQU87Q0FDMUQsQ0FDZ0MsQ0FBQztBQUNuQztBQUNBLFNBQVMsb0JBQW9CLFNBQVM7Q0FDcEMsdUJBQXdCLHlCQUF5QjtDQVdqRCxPQUFPLGNBQWMsR0FBRyxDQVZMO0VBQ2pCLFNBQVM7RUFDVCxVQUFVO0NBQ1osR0FBRztFQUNELFNBQVM7RUFDVCxVQUFBLGVBQUEsRUFDRSxvQkFBb0IsQ0FBQyxFQUFBLFlBQUEsUUFBQSxZQUFBLEtBQUEsSUFBQSxLQUFBLElBQUMsUUFBUyx1QkFBQSxHQUM1QixPQUNMO0NBQ0YsQ0FDZ0MsQ0FBQztBQUNuQztBQUNBLFNBQVMsOEJBQThCO0NBT3JDLE9BQU8sY0FBYyxHQUFHLENBTkw7RUFDakIsU0FBUztFQUNULFVBQVUsRUFDUixVQUFVLDZCQUNaO0NBQ0YsQ0FDZ0MsQ0FBQztBQUNuQztBQUNBLElBQU0sb0JBQW9CO0NBQUM7Q0FBYztDQUFZO0NBQWtCQztBQUFxQjtBQUM1RixJQUFNLHVCQUF1QixJQUFJLGVBQWUsT0FBTyxjQUFjLGVBQWUsWUFBWSxtQ0FBbUMsRUFBRTtBQUNySSxJQUFNLG1CQUFtQjtDQUFDO0NBQVU7RUFDbEMsU0FBUztFQUNULFVBQVU7Q0FDWjtDQUFHO0NBQVE7Q0FBd0I7RUFDakMsU0FBUztFQUNULFlBQVk7Q0FDZDtDQUFHO0FBQWtCO0FBQ3JCLElBQU0sZUFBTixNQUFNLGFBQWE7Q0FDakIsY0FBYztFQUNaLElBQUksT0FBTyxjQUFjLGVBQWUsV0FDdEMsT0FBTyxzQkFBc0IsRUFDM0IsVUFBVSxLQUNaLENBQUM7Q0FFTDtDQUNBLE9BQU8sUUFBUSxRQUFRLFFBQVE7RUFDN0IsT0FBTztHQUNMLFVBQVU7R0FDVixXQUFXO0lBQUM7SUFBa0IsT0FBTyxjQUFjLGVBQWUsYUFBQSxXQUFBLFFBQUEsV0FBQSxLQUFBLElBQUEsS0FBQSxJQUFZLE9BQVEsaUJBQWdCLGlCQUFpQixDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztJQUFHO0tBQzdJLFNBQVM7S0FDVCxPQUFPO0tBQ1AsVUFBVTtJQUNaO0lBQUcsT0FBTyxjQUFjLGVBQWUsWUFBWTtLQUNqRCxTQUFTO0tBQ1QsWUFBWTtJQUNkLElBQUksQ0FBQztxREFBRyxPQUFRLGdCQUFlO0tBQzdCLFNBQVM7S0FDVCxVQUFVLE9BQU87SUFDbkIsSUFBSSxDQUFDO0lBQUc7S0FDTixTQUFTO0tBQ1QsVUFBVSxTQUFTLFNBQVMsQ0FBQztJQUMvQjtxREFBRyxPQUFRLFdBQVUsNEJBQTRCLElBQUksNEJBQTRCO0lBQUcsc0JBQXNCO3FEQUFHLE9BQVEsc0JBQXFCLGVBQWUsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLGFBQWEsQ0FBQztxREFBRyxPQUFRLHFCQUFvQix5QkFBeUIsTUFBTSxJQUFJLENBQUM7cURBQUcsT0FBUSx5QkFBd0IsMEJBQTBCLE9BQU8sT0FBTywwQkFBMEIsV0FBVyxPQUFPLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztxREFBRyxPQUFRLHlCQUF3QixvQkFBb0IsQ0FBQyxDQUFDLGFBQWEsQ0FBQztJQUFHLHlCQUF5QjtHQUFDO0VBQzVnQjtDQUNGO0NBQ0EsT0FBTyxTQUFTLFFBQVE7RUFDdEIsT0FBTztHQUNMLFVBQVU7R0FDVixXQUFXLENBQUM7SUFDVixTQUFTO0lBQ1QsT0FBTztJQUNQLFVBQVU7R0FDWixDQUFDO0VBQ0g7Q0FDRjtBQVVGOzs4QkFUUyxRQUFPLFNBQVMscUJBQXFCLG1CQUFtQjtDQUM3RCxPQUFPLEtBQUsscUJBQXFCQyxlQUFjO0FBQ2pELENBQUE7OEJBQ08sUUFBc0IsaUNBQW9CO0NBQy9DLE1BQU1BO0NBQ04sU0FBUztFQUFDO0VBQWM7RUFBWTtFQUFrQkQ7Q0FBcUI7Q0FDM0UsU0FBUztFQUFDO0VBQWM7RUFBWTtFQUFrQkE7Q0FBcUI7QUFDN0UsQ0FBQyxDQUFBOzhCQUNNLFFBQXNCLGlDQUFvQixDQUFDLENBQUMsQ0FBQTtPQUU5QztDQUNMLENBQUMsT0FBTyxjQUFjLGVBQWUsY0FBYzVCLGlCQUFxQixjQUFjLENBQUM7RUFDckYsTUFBTTtFQUNOLE1BQU0sQ0FBQztHQUNMLFNBQVM7R0FDVCxTQUFTO0VBQ1gsQ0FBQztDQUNILENBQUMsU0FBUyxDQUFDLEdBQUcsSUFBSTtBQUNwQixFQUFBLENBQUc7QUFDSCxTQUFTLHdCQUF3QjtDQUMvQixPQUFPO0VBQ0wsU0FBUztFQUNULGtCQUFrQjtHQUNoQixNQUFNLG1CQUFtQixPQUFPLGdCQUFnQjtHQUNoRCxNQUFNLFNBQVMsT0FBTyxvQkFBb0I7R0FDMUMsSUFBSSxPQUFPLGNBQ1QsaUJBQWlCLFVBQVUsT0FBTyxZQUFZO0dBRWhELE9BQU8sSUFBSSxlQUFlLE1BQU07RUFDbEM7Q0FDRjtBQUNGO0FBQ0EsU0FBUyw4QkFBOEI7Q0FDckMsT0FBTztFQUNMLFNBQVM7RUFDVCxVQUFVO0NBQ1o7QUFDRjtBQUNBLFNBQVMsOEJBQThCO0NBQ3JDLE9BQU87RUFDTCxTQUFTO0VBQ1QsVUFBVTtDQUNaO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQjtDQUs3QixJQUplLE9BQU8sUUFBUTtFQUM1QixVQUFVO0VBQ1YsVUFBVTtDQUNaLENBQ1MsR0FDUCxNQUFNLElBQUlFLGFBQWMsTUFBTSw0S0FBaUw7Q0FFak4sT0FBTztBQUNUO0FBQ0EsU0FBUyx5QkFBeUIsUUFBUTtDQUN4QyxPQUFPLENBQUMsT0FBTyxzQkFBc0IsYUFBYSw4QkFBOEIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxHQUFHLE9BQU8sc0JBQXNCLG9CQUFvQixxQ0FBcUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzVNO0FBQ0EsSUFBTSxxQkFBcUIsSUFBSSxlQUFlLE9BQU8sY0FBYyxlQUFlLFlBQVksdUJBQXVCLEVBQUU7QUFDdkgsU0FBUywyQkFBMkI7Q0FDbEMsT0FBTyxDQUFDO0VBQ04sU0FBUztFQUNULFlBQVk7Q0FDZCxHQUFHO0VBQ0QsU0FBUztFQUNULE9BQU87RUFDUCxhQUFhO0NBQ2YsQ0FBQztBQUNIOzs7Ozs7OztBQzcvQ0EsU0FBUyxjQUFjLFdBQVc7Q0FDaEMsT0FBTyxVQUFVLEtBQUksY0FBYSxHQUFHLFdBQVcsT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO0FBQ3RGO0FBQ0EsU0FBUyxpQkFBaUIsV0FBVztDQUNuQyxPQUFPLFVBQVUsS0FBSSxjQUFhLEdBQUcsV0FBVyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7QUFDekY7QUFDQSxTQUFTLHNCQUFzQixXQUFXO0NBQ3hDLE9BQU8sVUFBVSxLQUFJLGNBQWEsR0FBRyxXQUFXLE9BQU8sUUFBUSxDQUFDLENBQUMsaUJBQWlCLEdBQUcsTUFBTSxDQUFDO0FBQzlGO0FBQ0EsU0FBUyxtQkFBbUIsV0FBVztDQUNyQyxPQUFPLFVBQVUsS0FBSSxjQUFhLEdBQUcsV0FBVyxPQUFPLFFBQVEsQ0FBQyxDQUFDLGNBQWMsR0FBRyxNQUFNLENBQUM7QUFDM0Y7QUFDQSxTQUFTLGFBQWEsVUFBVTtDQUM5QixRQUFRLEdBQUcsV0FBVyxPQUFPLFFBQVEsQ0FBQyxDQUFDLFFBQVEsR0FBRyxNQUFNO0FBQzFEO0FBRUEsSUFBTSwwQkFBeUIsSUFBSSxRQUFRLFFBQVEifQ==