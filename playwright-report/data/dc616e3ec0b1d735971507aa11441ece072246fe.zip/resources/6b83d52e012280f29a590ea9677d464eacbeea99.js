import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-ER42ASSE.js");const QRCode = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport7_qrcode, 0);import {
  EncryptionEngine,
  SocketService,
  UrService,
  WidgetDispatcherService,
  socket_service_exports,
  src_exports,
  ur_service_exports,
  widget_dispatcher_service_exports
} from "/chunk-2GVOWOPG.js";
import {
  ConfigService,
  __async,
  __spreadProps,
  __spreadValues,
  config_service_exports
} from "/chunk-PZ54WRVW.js";

// apps/client/src/app/pages/room/room.component.ts
import { Component, signal, computed, effect, Inject, PLATFORM_ID, HostListener } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { CommonModule, isPlatformBrowser } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import { RouterModule } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
import { FormsModule } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_forms.js?v=cf17c1b4";
import { LucideShield, LucideUsers, LucideCheckCircle, LucideLoader2, LucideCopy, LucideClock, LucideArrowRight, LucideHash, LucideCrown, LucideUploadCloud, LucideDownloadCloud, LucideDownload, LucideExternalLink, LucideCheck, LucideZap, LucideAlertTriangle, LucidePower, LucideX, LucideLock, LucideUnlock, LucideKey, LucideRefreshCw, LucideAlertOctagon, LucideFileKey, LucideFileCheck, LucideEdit2, LucideTag, LucideBell, LucideQrCode, LucideEye, LucideEyeOff, LucideSearch, LucideNetwork, LucideShieldAlert, LucideShieldCheck, LucideShieldOff, LucideUser } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@lucide_angular.js?v=cf17c1b4";
import __vite__cjsImport7_qrcode from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/qrcode.js?v=cf17c1b4";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/html5-qrcode.js?v=cf17c1b4";
import { base64, hex } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_base.js?v=cf17c1b4";
import * as i0 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i1 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_router.js?v=cf17c1b4";
import * as i3 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_platform-browser.js?v=cf17c1b4";
import * as i8 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import * as i9 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_forms.js?v=cf17c1b4";
var _forTrack0 = ($index, $item) => $item.fingerprint;
var _forTrack1 = ($index, $item) => $item.id;
function RoomComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 0);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 130);
    i0.\u0275\u0275text(2, " Connection lost... Reconnecting... ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 1)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 133);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Download Unsigned PSBT");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_1_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showPsbtModal.set(false));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 138);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 139);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "p", 140)(13, "strong");
    i0.\u0275\u0275text(14, "Privacy Warning:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, " This file contains unencrypted metadata about your wallet balances, UTXOs, and destination addresses. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(16, "p", 141);
    i0.\u0275\u0275text(17, " You are downloading this to transfer to a Coldcard or air-gapped hardware wallet. Because this file is plaintext, please ensure it is securely handled, archived, or wiped after use according to your security procedures. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "div", 142)(19, "button", 143);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_1_Template_button_click_19_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showPsbtModal.set(false));
    });
    i0.\u0275\u0275text(20, " Cancel ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(21, "button", 144);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_1_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.executePsbtDownload());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(22, "svg", 145);
    i0.\u0275\u0275text(23, " Download PSBT ");
    i0.\u0275\u0275elementEnd()()()()();
  }
}
function RoomComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 2)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 146);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Download Audit Log");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_2_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showAuditModal.set(false));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 138);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 139);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "p", 140)(13, "strong");
    i0.\u0275\u0275text(14, "Confidential Data:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, " This PDF contains a complete, unencrypted record of the ceremony, including transaction details, participant identities, and action timestamps. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(16, "p", 141);
    i0.\u0275\u0275text(17, " Please ensure it is stored securely and only shared with authorized participants or trusted third parties. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "div", 142)(19, "button", 143);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_2_Template_button_click_19_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showAuditModal.set(false));
    });
    i0.\u0275\u0275text(20, " Cancel ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(21, "button", 144);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_2_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.executeAuditDownload());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(22, "svg", 145);
    i0.\u0275\u0275text(23, " Download PDF ");
    i0.\u0275\u0275elementEnd()()()()();
  }
}
function RoomComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 3)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 147);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Download CSV Data");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_3_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showCsvModal.set(false));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 148);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 149);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "p", 150)(13, "strong");
    i0.\u0275\u0275text(14, "Confidential Data:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, " This spreadsheet contains unencrypted settlement data and participant metadata. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(16, "p", 141);
    i0.\u0275\u0275text(17, " Please ensure it is stored securely and only shared with authorized participants or trusted third parties. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "div", 142)(19, "button", 143);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_3_Template_button_click_19_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showCsvModal.set(false));
    });
    i0.\u0275\u0275text(20, " Cancel ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(21, "button", 151);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_3_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.executeCsvDownload());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(22, "svg", 145);
    i0.\u0275\u0275text(23, " Download CSV ");
    i0.\u0275\u0275elementEnd()()()()();
  }
}
function RoomComponent_Conditional_4_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_4_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 66);
  }
}
function RoomComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 4)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 152);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Room Identifier");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_4_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeRoomIdModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 138);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 153);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "p", 154)(13, "strong");
    i0.\u0275\u0275text(14, "Public Routing Data:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, " This ID directs signers to the correct room, but it ");
    i0.\u0275\u0275elementStart(16, "em");
    i0.\u0275\u0275text(17, "cannot");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(18, " decrypt the transaction data without the private Decryption Key. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(19, "p", 141);
    i0.\u0275\u0275text(20, " If you are practicing strict Operational Security (OpSec), send this Room ID to your signers first. Send the Decryption Key later via a separate, secure channel (e.g., Signal vs Email). ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(21, "button", 155);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_4_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.copyRoomId());
    });
    i0.\u0275\u0275conditionalCreate(22, RoomComponent_Conditional_4_Conditional_22_Template, 1, 0, ":svg:svg", 62)(23, RoomComponent_Conditional_4_Conditional_23_Template, 1, 0, ":svg:svg", 66);
    i0.\u0275\u0275text(24);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(22);
    i0.\u0275\u0275conditional(ctx_r1.roomIdCopied() ? 22 : 23);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.roomIdCopied() ? "Room ID Copied!" : "Copy Room ID", " ");
  }
}
function RoomComponent_Conditional_5_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 167);
  }
}
function RoomComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 5)(1, "div", 156)(2, "div", 157)(3, "h3", 158);
    i0.\u0275\u0275text(4, "Label Signer");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "button", 159);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_5_Template_button_click_5_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeLabelModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(6, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(7, "div", 160)(8, "div", 161);
    i0.\u0275\u0275text(9, "Fingerprint");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "div", 162);
    i0.\u0275\u0275text(11);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(12, "div", 160)(13, "label", 163);
    i0.\u0275\u0275text(14, "Label Name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(15, "input", 164);
    i0.\u0275\u0275listener("ngModelChange", function RoomComponent_Conditional_5_Template_input_ngModelChange_15_listener($event) {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.editingLabel.set($event));
    })("keyup.enter", function RoomComponent_Conditional_5_Template_input_keyup_enter_15_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.saveLabel());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(16, "div", 165);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_5_Template_div_click_16_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.saveToBook.set(!ctx_r1.saveToBook()));
    });
    i0.\u0275\u0275elementStart(17, "div", 166);
    i0.\u0275\u0275conditionalCreate(18, RoomComponent_Conditional_5_Conditional_18_Template, 1, 0, ":svg:svg", 167);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(19, "div", 168);
    i0.\u0275\u0275text(20, "Save to Address Book");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(21, "button", 169);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_5_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.saveLabel());
    });
    i0.\u0275\u0275text(22, " Save Label ");
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.editingFingerprint(), " ");
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275property("ngModel", ctx_r1.editingLabel());
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("bg-brand-accent", ctx_r1.saveToBook())("border-brand-accent", ctx_r1.saveToBook())("border-brand-card-border", !ctx_r1.saveToBook());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.saveToBook() ? 18 : -1);
  }
}
function RoomComponent_Conditional_6_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 175);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 176);
    i0.\u0275\u0275text(2, " Create New Room ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 6)(1, "div", 170)(2, "div", 171);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 172);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "h2", 173);
    i0.\u0275\u0275text(5, "Room Not Found");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p", 174);
    i0.\u0275\u0275text(7, " This room does not exist or has expired.");
    i0.\u0275\u0275element(8, "br");
    i0.\u0275\u0275text(9, " Please check the URL or create a new signing session. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(10, RoomComponent_Conditional_6_Conditional_10_Template, 3, 0, "a", 175);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275conditional(!ctx_r1.isEmbedded ? 10 : -1);
  }
}
function RoomComponent_Conditional_7_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 181);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 182);
    i0.\u0275\u0275text(2, " Return Home ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 7)(1, "div", 177)(2, "div", 178);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 179);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "h2", 173);
    i0.\u0275\u0275text(5, "Room Full");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p", 180);
    i0.\u0275\u0275text(7, "This room has reached its maximum connection limit.");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(8, RoomComponent_Conditional_7_Conditional_8_Template, 3, 0, "a", 181);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275conditional(!ctx_r1.isEmbedded ? 8 : -1);
  }
}
function RoomComponent_Conditional_8_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 181);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 182);
    i0.\u0275\u0275text(2, " Return Home ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 8)(1, "div", 183);
    i0.\u0275\u0275element(2, "div", 184);
    i0.\u0275\u0275elementStart(3, "div", 185);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 186);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h2", 173);
    i0.\u0275\u0275text(6, "Access Denied");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(7, "p", 174);
    i0.\u0275\u0275text(8, " The Coordinator has locked this room.");
    i0.\u0275\u0275element(9, "br");
    i0.\u0275\u0275text(10, " No new guests can join the session at this time. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(11, RoomComponent_Conditional_8_Conditional_11_Template, 3, 0, "a", 181);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275conditional(!ctx_r1.isEmbedded ? 11 : -1);
  }
}
function RoomComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 9)(1, "div", 187)(2, "div", 188);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 186);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "h2", 173);
    i0.\u0275\u0275text(5, "Decryption Key Required");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p", 189);
    i0.\u0275\u0275text(7, "Your link is missing the private decryption key. Please enter it below to join the room.");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "div", 190)(9, "input", 191);
    i0.\u0275\u0275twoWayListener("ngModelChange", function RoomComponent_Conditional_9_Template_input_ngModelChange_9_listener($event) {
      i0.\u0275\u0275restoreView(_r7);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.manualKey, $event) || (ctx_r1.manualKey = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "button", 192);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_9_Template_button_click_10_listener() {
      i0.\u0275\u0275restoreView(_r7);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.submitKey());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 193);
    i0.\u0275\u0275text(12, " Decrypt Room ");
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(9);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.manualKey);
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("disabled", !ctx_r1.manualKey);
  }
}
function RoomComponent_Conditional_10_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 202);
    i0.\u0275\u0275text(1, " Maximum length reached. ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 10)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 194);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Rename Room");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_10_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeRenameModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 195)(10, "p", 196);
    i0.\u0275\u0275text(11, " Give this room a label to make it easier to identify. This name is visible to all participants. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(12, "div", 197)(13, "div", 198)(14, "label", 199);
    i0.\u0275\u0275text(15, "Room Name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(16, "span", 200);
    i0.\u0275\u0275text(17);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(18, "input", 201);
    i0.\u0275\u0275listener("ngModelChange", function RoomComponent_Conditional_10_Template_input_ngModelChange_18_listener($event) {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.newRoomName.set($event));
    })("keyup.enter", function RoomComponent_Conditional_10_Template_input_keyup_enter_18_listener() {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.saveRoomName());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275conditionalCreate(19, RoomComponent_Conditional_10_Conditional_19_Template, 2, 0, "p", 202);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(20, "div", 203)(21, "button", 204);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_10_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeRenameModal());
    });
    i0.\u0275\u0275text(22, " Cancel ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(23, "button", 205);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_10_Template_button_click_23_listener() {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.saveRoomName());
    });
    i0.\u0275\u0275text(24, " Save Name ");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(16);
    i0.\u0275\u0275classProp("text-red-400", ctx_r1.newRoomName().length > 64)("text-brand-text-muted", ctx_r1.newRoomName().length <= 64);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.newRoomName().length, " / 64 ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("ngModel", ctx_r1.newRoomName());
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.newRoomName().length >= 64 ? 19 : -1);
  }
}
function RoomComponent_Conditional_11_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 213);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 224);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "p", 225)(3, "strong");
    i0.\u0275\u0275text(4, "Contains Decryption Key:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, " Anyone who scans this can join the room and view data. Treat it like a password. ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_11_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 214);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 153);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "p", 154)(3, "strong");
    i0.\u0275\u0275text(4, "Maximum Security:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, " Key is excluded. You must send the ");
    i0.\u0275\u0275elementStart(6, "em");
    i0.\u0275\u0275text(7, "Link Key");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8, " via a separate secure channel. ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_11_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "img", 217);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275property("src", ctx_r1.qrDataUrl(), i0.\u0275\u0275sanitizeUrl);
  }
}
function RoomComponent_Conditional_11_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 218);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 226);
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_11_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 219)(1, "div", 227);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 228);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(3, "span", 229);
    i0.\u0275\u0275text(4, "Click to Reveal");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 11)(1, "div", 206)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 207);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Room QR Code");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_11_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeQr());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 208)(10, "div", 108)(11, "button", 209);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_11_Template_button_click_11_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.toggleQrKey(false));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(12, "svg", 210);
    i0.\u0275\u0275text(13, " Link Only ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(14, "button", 211);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_11_Template_button_click_14_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.toggleQrKey(true));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(15, "svg", 212);
    i0.\u0275\u0275text(16, " Full (Link + Key) ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(17, RoomComponent_Conditional_11_Conditional_17_Template, 6, 0, "div", 213)(18, RoomComponent_Conditional_11_Conditional_18_Template, 9, 0, "div", 214);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(19, "div", 215);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_11_Template_div_click_19_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.toggleQrReveal());
    });
    i0.\u0275\u0275elementStart(20, "div", 216);
    i0.\u0275\u0275conditionalCreate(21, RoomComponent_Conditional_11_Conditional_21_Template, 1, 1, "img", 217)(22, RoomComponent_Conditional_11_Conditional_22_Template, 2, 0, "div", 218);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(23, RoomComponent_Conditional_11_Conditional_23_Template, 5, 0, "div", 219);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(24, "p", 220);
    i0.\u0275\u0275text(25, " Scan with a mobile wallet or camera to join. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(26, "div", 221)(27, "button", 222);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_11_Template_button_click_27_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.downloadQr());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(28, "svg", 145);
    i0.\u0275\u0275text(29, " Download Image ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(30, "button", 223);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_11_Template_button_click_30_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeQr());
    });
    i0.\u0275\u0275text(31, " Close ");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275classProp("bg-brand-card-border", !ctx_r1.qrIncludesKey())("text-brand-accent", !ctx_r1.qrIncludesKey())("text-brand-text-muted", ctx_r1.qrIncludesKey());
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275classProp("bg-brand-card-border", ctx_r1.qrIncludesKey())("text-amber-400", ctx_r1.qrIncludesKey())("text-brand-text-muted", !ctx_r1.qrIncludesKey());
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(ctx_r1.qrIncludesKey() ? 17 : 18);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275classProp("blur-md", !ctx_r1.isQrRevealed())("opacity-50", !ctx_r1.isQrRevealed());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.qrDataUrl() ? 21 : 22);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(!ctx_r1.isQrRevealed() ? 23 : -1);
  }
}
function RoomComponent_Conditional_12_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_12_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 66);
  }
}
function RoomComponent_Conditional_12_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_12_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 66);
  }
}
function RoomComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 12)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 230);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Share Room Securely");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_12_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r10);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeShareModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 231)(11, "div", 232)(12, "div")(13, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(14, "svg", 233);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(15, "h4", 234);
    i0.\u0275\u0275text(16, "Maximum Security (Split)");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(17, "p", 235);
    i0.\u0275\u0275text(18, " Copies the room URL ");
    i0.\u0275\u0275elementStart(19, "strong");
    i0.\u0275\u0275text(20, "without");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21, " the decryption key. Send this link, then use the ");
    i0.\u0275\u0275elementStart(22, "em");
    i0.\u0275\u0275text(23, '"Link Key"');
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(24, " action to send the key via a separate, secure channel (e.g., Signal vs Email). ");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(25, "button", 236);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_12_Template_button_click_25_listener() {
      i0.\u0275\u0275restoreView(_r10);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.copySecureLink());
    });
    i0.\u0275\u0275conditionalCreate(26, RoomComponent_Conditional_12_Conditional_26_Template, 1, 0, ":svg:svg", 62)(27, RoomComponent_Conditional_12_Conditional_27_Template, 1, 0, ":svg:svg", 66);
    i0.\u0275\u0275text(28);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(29, "div", 237)(30, "div", 238)(31, "div")(32, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(33, "svg", 239);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(34, "h4", 234);
    i0.\u0275\u0275text(35, "Standard (Combined)");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(36, "p", 235);
    i0.\u0275\u0275text(37, " Copies the full URL including the decryption key (");
    i0.\u0275\u0275elementStart(38, "code");
    i0.\u0275\u0275text(39, "#key");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(40, "). Convenient for quick sharing, but if this single link is intercepted, the room is compromised. ");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(41, "button", 240);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_12_Template_button_click_41_listener() {
      i0.\u0275\u0275restoreView(_r10);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.copyFullLink());
    });
    i0.\u0275\u0275conditionalCreate(42, RoomComponent_Conditional_12_Conditional_42_Template, 1, 0, ":svg:svg", 62)(43, RoomComponent_Conditional_12_Conditional_43_Template, 1, 0, ":svg:svg", 66);
    i0.\u0275\u0275text(44);
    i0.\u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(26);
    i0.\u0275\u0275conditional(ctx_r1.secureLinkCopied() ? 26 : 27);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.secureLinkCopied() ? "Secure Link Copied!" : "Copy Link Only (No Key)", " ");
    i0.\u0275\u0275advance(14);
    i0.\u0275\u0275conditional(ctx_r1.fullLinkCopied() ? 42 : 43);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.fullLinkCopied() ? "Full Link Copied!" : "Copy Full Link (Link + Key)", " ");
  }
}
function RoomComponent_Conditional_13_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_13_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 66);
  }
}
function RoomComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 13)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 241);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Room Decryption Key");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_13_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r11);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeKeyModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 242);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 243);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "p", 244)(13, "strong");
    i0.\u0275\u0275text(14, "Sensitive Data:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, " This is the private encryption key for the room. Anyone with this key can decrypt and view the transaction details if they also have the room link. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(16, "p", 141);
    i0.\u0275\u0275text(17, " For maximum operational security, send this key to signers using a different communication channel than the one used for the room link (e.g., Signal vs. Email). ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "button", 245);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_13_Template_button_click_18_listener() {
      i0.\u0275\u0275restoreView(_r11);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.copyKey());
    });
    i0.\u0275\u0275conditionalCreate(19, RoomComponent_Conditional_13_Conditional_19_Template, 1, 0, ":svg:svg", 62)(20, RoomComponent_Conditional_13_Conditional_20_Template, 1, 0, ":svg:svg", 66);
    i0.\u0275\u0275text(21);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(19);
    i0.\u0275\u0275conditional(ctx_r1.keyCopied() ? 19 : 20);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.keyCopied() ? "Key Copied!" : "Copy Decryption Key", " ");
  }
}
function RoomComponent_Conditional_14_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_14_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 66);
  }
}
function RoomComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 14)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 246);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Backup Admin Token");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_14_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r12);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeAdminModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 137)(10, "div", 247);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 248);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "p", 249)(13, "strong");
    i0.\u0275\u0275text(14, "High Privilege:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(15, ' This token allows any guest in the room to claim the "Coordinator" role. ');
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(16, "p", 141);
    i0.\u0275\u0275text(17, " Coordinators have the authority to manage whitelists, lock the room, verify inputs, and broadcast the final transaction. Only share this with trusted co-administrators. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "button", 250);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_14_Template_button_click_18_listener() {
      i0.\u0275\u0275restoreView(_r12);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.copyAdminToken());
    });
    i0.\u0275\u0275conditionalCreate(19, RoomComponent_Conditional_14_Conditional_19_Template, 1, 0, ":svg:svg", 62)(20, RoomComponent_Conditional_14_Conditional_20_Template, 1, 0, ":svg:svg", 66);
    i0.\u0275\u0275text(21);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(19);
    i0.\u0275\u0275conditional(ctx_r1.adminCopied() ? 19 : 20);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.adminCopied() ? "Admin Token Copied!" : "Copy Admin Token", " ");
  }
}
function RoomComponent_Conditional_15_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 214);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 153);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "p", 154)(3, "strong");
    i0.\u0275\u0275text(4, "Standard Protocol:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, " Optimized for Keystone, Passport, and standard hardware wallets. Adjust the speed slider for compatibility and performance. ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_15_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 213);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 261);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "p", 225)(3, "strong");
    i0.\u0275\u0275text(4, "Coldcard Protocol:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(5, " Optimized for Coinkite Coldcard devices. Adjust the speed slider for compatibility and performance. ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_15_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 219)(1, "div", 227);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 228);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(3, "span", 229);
    i0.\u0275\u0275text(4, "Click to Reveal");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_15_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 259)(1, "div", 262)(2, "span", 263);
    i0.\u0275\u0275text(3, "Frame Delay");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "span", 264);
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "input", 265);
    i0.\u0275\u0275listener("ngModelChange", function RoomComponent_Conditional_15_Conditional_23_Template_input_ngModelChange_6_listener($event) {
      i0.\u0275\u0275restoreView(_r14);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.updateFountainSpeed($event));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(7, "div", 266)(8, "span");
    i0.\u0275\u0275text(9, "Fast (Drops frames)");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "span");
    i0.\u0275\u0275text(11, "Slow (More reliable)");
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate1("", ctx_r1.fountainSpeed(), "ms");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("ngModel", ctx_r1.fountainSpeed());
    i0.\u0275\u0275control();
  }
}
function RoomComponent_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 15)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 251);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Air-Gapped Export PSBT");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_15_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r13);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeFountainModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 208)(10, "div", 252)(11, "button", 253);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_15_Template_button_click_11_listener() {
      i0.\u0275\u0275restoreView(_r13);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.setExportFormat("ur"));
    });
    i0.\u0275\u0275text(12, " Universal (UR) ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(13, "button", 254);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_15_Template_button_click_13_listener() {
      i0.\u0275\u0275restoreView(_r13);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.setExportFormat("bbqr"));
    });
    i0.\u0275\u0275text(14, " Coldcard (BBQr) ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(15, RoomComponent_Conditional_15_Conditional_15_Template, 6, 0, "div", 214)(16, RoomComponent_Conditional_15_Conditional_16_Template, 6, 0, "div", 213);
    i0.\u0275\u0275elementStart(17, "div", 255);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_15_Template_div_click_17_listener() {
      i0.\u0275\u0275restoreView(_r13);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.toggleFountainReveal());
    });
    i0.\u0275\u0275elementStart(18, "div", 256);
    i0.\u0275\u0275element(19, "canvas", 257);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(20, RoomComponent_Conditional_15_Conditional_20_Template, 5, 0, "div", 219);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(21, "p", 258);
    i0.\u0275\u0275text(22, " Ensure no cameras are observing your screen before revealing. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(23, RoomComponent_Conditional_15_Conditional_23_Template, 12, 2, "div", 259);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(24, "div", 203)(25, "button", 260);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_15_Template_button_click_25_listener() {
      i0.\u0275\u0275restoreView(_r13);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeFountainModal());
    });
    i0.\u0275\u0275text(26, " Close ");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(11);
    i0.\u0275\u0275classProp("bg-brand-card-border", ctx_r1.exportFormat() === "ur")("text-brand-accent", ctx_r1.exportFormat() === "ur")("text-brand-text-muted", ctx_r1.exportFormat() !== "ur");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("bg-brand-card-border", ctx_r1.exportFormat() === "bbqr")("text-amber-400", ctx_r1.exportFormat() === "bbqr")("text-brand-text-muted", ctx_r1.exportFormat() !== "bbqr");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.exportFormat() === "ur" ? 15 : 16);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275classProp("blur-md", !ctx_r1.isFountainRevealed())("opacity-50", !ctx_r1.isFountainRevealed());
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(!ctx_r1.isFountainRevealed() ? 20 : -1);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(ctx_r1.isFountainRevealed() ? 23 : -1);
  }
}
function RoomComponent_Conditional_16_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 275);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 287);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "span", 288);
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(ctx_r1.urService.scanError());
  }
}
function RoomComponent_Conditional_16_Conditional_38_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 285)(1, "div", 289)(2, "span");
    i0.\u0275\u0275text(3, "RECONSTRUCTING SIGNATURE...");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "span");
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "div", 290);
    i0.\u0275\u0275element(7, "div", 291);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate1("", (ctx_r1.urService.scanProgress() * 100).toFixed(0), "%");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275styleProp("width", ctx_r1.urService.scanProgress() * 100, "%");
  }
}
function RoomComponent_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 16)(1, "div", 131)(2, "div", 132)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 207);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Air-Gapped Import PSBT");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_16_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.stopScanner());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 208)(10, "div", 267);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(11, "svg", 268);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(12, "div", 269)(13, "p")(14, "strong");
    i0.\u0275\u0275text(15, "Secure Scanner:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(16, " Hold your hardware wallet diplaying PSBT QR Code up to the camera. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(17, "p", 270);
    i0.\u0275\u0275text(18, " \u{1F4A1} ");
    i0.\u0275\u0275elementStart(19, "strong");
    i0.\u0275\u0275text(20, "Tip:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(21);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(22, "div", 271)(23, "div", 272)(24, "span", 273);
    i0.\u0275\u0275text(25, "Raw Optical Feed");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(26, "span", 274);
    i0.\u0275\u0275text(27);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(28, RoomComponent_Conditional_16_Conditional_28_Template, 4, 1, "div", 275);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(29, "div", 276);
    i0.\u0275\u0275element(30, "div", 277);
    i0.\u0275\u0275elementStart(31, "div", 278)(32, "div", 279);
    i0.\u0275\u0275element(33, "div", 280)(34, "div", 281)(35, "div", 282)(36, "div", 283)(37, "div", 284);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(38, RoomComponent_Conditional_16_Conditional_38_Template, 8, 3, "div", 285);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(39, "div", 203)(40, "button", 286);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_16_Template_button_click_40_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.stopScanner());
    });
    i0.\u0275\u0275text(41, " Cancel & Close ");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(21);
    i0.\u0275\u0275textInterpolate1(" Sometimes QR codes are too small for webcams to read off a harware device. You can use a mobile companion application to scan the hardware wallet, and then export the Signed PSBT to ", ctx_r1.configService.config().brandName, " through this reader. ");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275property("title", ctx_r1.urService.lastScannedText());
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.urService.lastScannedText() || "Waiting for QR...", " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.urService.scanError() ? 28 : -1);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275conditional(ctx_r1.urService.scanProgress() > 0 ? 38 : -1);
  }
}
function RoomComponent_Conditional_17_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 299);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_17_Conditional_8_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.closeConfirmModal());
    });
    i0.\u0275\u0275text(1, " Cancel ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 17)(1, "div", 292);
    i0.\u0275\u0275element(2, "div", 293);
    i0.\u0275\u0275elementStart(3, "h3", 294);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "p", 295);
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(7, "div", 296);
    i0.\u0275\u0275conditionalCreate(8, RoomComponent_Conditional_17_Conditional_8_Template, 2, 0, "button", 297);
    i0.\u0275\u0275elementStart(9, "button", 298);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_17_Template_button_click_9_listener() {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.executeConfirmAction());
    });
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("bg-rose-500", ctx_r1.confirmData().isDestructive)("bg-brand-accent", !ctx_r1.confirmData().isDestructive);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r1.confirmData().title);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("", ctx_r1.confirmData().message, " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classProp("grid-cols-2", ctx_r1.confirmData().type === "confirm")("grid-cols-1", ctx_r1.confirmData().type === "alert");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.confirmData().type === "confirm" ? 8 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classProp("bg-rose-600", ctx_r1.confirmData().isDestructive)("hover:bg-rose-500", ctx_r1.confirmData().isDestructive)("text-white", ctx_r1.confirmData().isDestructive)("bg-brand-accent", !ctx_r1.confirmData().isDestructive)("hover:bg-brand-accent-hover", !ctx_r1.confirmData().isDestructive);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.confirmData().type === "confirm" ? "Confirm" : "OK", " ");
  }
}
function RoomComponent_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 26);
  }
}
function RoomComponent_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 27);
  }
}
function RoomComponent_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "span", 31);
  }
}
function RoomComponent_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "span", 32);
  }
}
function RoomComponent_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "span", 33);
  }
}
function RoomComponent_Conditional_37_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 300);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_37_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r18);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.openRenameModal());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 301);
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_41_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 39);
  }
}
function RoomComponent_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 40);
  }
}
function RoomComponent_Conditional_55_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "div", 43);
    i0.\u0275\u0275elementStart(1, "div", 37)(2, "div", 302);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 303);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "span", 46);
    i0.\u0275\u0275text(5, "Coordinator");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "div", 47);
    i0.\u0275\u0275text(7, " You have admin privileges ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_69_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 54);
    i0.\u0275\u0275text(1, "Expired");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_70_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 55);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate(ctx_r1.timeRemaining());
  }
}
function RoomComponent_Conditional_73_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 57)(1, "button", 304);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_73_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r19);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.togglePrivacyBlur("transaction-overview"));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 305);
    i0.\u0275\u0275text(3, " Hidden for Privacy ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_78_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 37)(1, "button", 306);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_78_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r20);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.promptAuditLogDownload());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 307);
    i0.\u0275\u0275text(3, " Audit Log ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275element(4, "div", 64);
    i0.\u0275\u0275elementStart(5, "div", 37)(6, "button", 308);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_78_Template_button_click_6_listener() {
      i0.\u0275\u0275restoreView(_r20);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.promptCsvDownload());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(7, "svg", 145);
    i0.\u0275\u0275text(8, " CSV ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275element(9, "div", 64);
  }
}
function RoomComponent_Conditional_81_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_82_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 63);
  }
}
function RoomComponent_Conditional_85_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 62);
  }
}
function RoomComponent_Conditional_85_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 310);
  }
}
function RoomComponent_Conditional_85_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 37)(1, "button", 309);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_85_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.openAdminModal());
    });
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_85_Conditional_2_Template, 1, 0, ":svg:svg", 62)(3, RoomComponent_Conditional_85_Conditional_3_Template, 1, 0, ":svg:svg", 310);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275element(5, "div", 64);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.adminCopied() ? 2 : 3);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.adminCopied() ? "Copied" : "Backup Admin", " ");
  }
}
function RoomComponent_Conditional_96_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 312);
  }
}
function RoomComponent_Conditional_96_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 313);
  }
}
function RoomComponent_Conditional_96_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275element(0, "div", 64);
    i0.\u0275\u0275elementStart(1, "div", 37)(2, "button", 311);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_96_Template_button_click_2_listener() {
      i0.\u0275\u0275restoreView(_r22);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.toggleLock());
    });
    i0.\u0275\u0275conditionalCreate(3, RoomComponent_Conditional_96_Conditional_3_Template, 1, 0, ":svg:svg", 312)(4, RoomComponent_Conditional_96_Conditional_4_Template, 1, 0, ":svg:svg", 313);
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("text-rose-400", ctx_r1.socket.roomState()?.isLocked)("bg-rose-950\\/30", ctx_r1.socket.roomState()?.isLocked)("text-brand-text-muted", !ctx_r1.socket.roomState()?.isLocked)("hover:bg-brand-card-border", !ctx_r1.socket.roomState()?.isLocked);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.socket.roomState()?.isLocked ? 3 : 4);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.socket.roomState()?.isLocked ? "Locked" : "Lock Room", " ");
  }
}
function RoomComponent_Conditional_97_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275element(0, "div", 64);
    i0.\u0275\u0275elementStart(1, "div", 37)(2, "button", 314);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_97_Template_button_click_2_listener() {
      i0.\u0275\u0275restoreView(_r23);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closeRoom());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 315);
    i0.\u0275\u0275text(4, " Close ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_98_For_20_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 330);
  }
}
function RoomComponent_Conditional_98_For_20_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 331);
  }
}
function RoomComponent_Conditional_98_For_20_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 334);
    i0.\u0275\u0275text(1, "You");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_98_For_20_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 337);
  }
}
function RoomComponent_Conditional_98_For_20_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 338);
  }
}
function RoomComponent_Conditional_98_For_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r25 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 327)(1, "div", 328)(2, "div", 329);
    i0.\u0275\u0275conditionalCreate(3, RoomComponent_Conditional_98_For_20_Conditional_3_Template, 1, 0, ":svg:svg", 330)(4, RoomComponent_Conditional_98_For_20_Conditional_4_Template, 1, 0, ":svg:svg", 331);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "div", 332)(6, "div", 49)(7, "span", 333);
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(9, RoomComponent_Conditional_98_For_20_Conditional_9_Template, 2, 0, "span", 334);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "div", 335);
    i0.\u0275\u0275text(11);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(12, "button", 336);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_98_For_20_Template_button_click_12_listener() {
      const session_r26 = i0.\u0275\u0275restoreView(_r25).$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.copySessionId(session_r26.id, session_r26.displayName));
    });
    i0.\u0275\u0275conditionalCreate(13, RoomComponent_Conditional_98_For_20_Conditional_13_Template, 1, 0, ":svg:svg", 337)(14, RoomComponent_Conditional_98_For_20_Conditional_14_Template, 1, 0, ":svg:svg", 338);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const session_r26 = ctx.$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classProp("bg-brand-accent_10", session_r26.id === ctx_r1.socket.currentSessionId())("border-brand-accent_30", session_r26.id === ctx_r1.socket.currentSessionId())("bg-brand-bg", session_r26.id !== ctx_r1.socket.currentSessionId())("border-brand-card-border", session_r26.id !== ctx_r1.socket.currentSessionId());
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("bg-indigo-500_10", session_r26.role === "admin")("bg-brand-card-border", session_r26.role !== "admin");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(session_r26.role === "admin" ? 3 : 4);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275classProp("italic", !session_r26.displayName);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", session_r26.displayName || "Anonymous Guest", " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(session_r26.id === ctx_r1.socket.currentSessionId() ? 9 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" Session: ", session_r26.id, " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classProp("text-brand-accent", ctx_r1.copiedSessionId() === session_r26.id)("text-brand-text-muted", ctx_r1.copiedSessionId() !== session_r26.id)("hover:text-brand-text", ctx_r1.copiedSessionId() !== session_r26.id);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.copiedSessionId() === session_r26.id ? 13 : 14);
  }
}
function RoomComponent_Conditional_98_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 326);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 339);
    i0.\u0275\u0275text(2, " Syncing sessions... ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_98_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 70)(1, "div", 316)(2, "div", 317)(3, "div", 49);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 318);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 134);
    i0.\u0275\u0275text(6, "Active Sessions");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "button", 135);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_98_Template_button_click_7_listener() {
      i0.\u0275\u0275restoreView(_r24);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.showSessionsModal.set(false));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(8, "svg", 136);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(9, "div", 319)(10, "label", 163);
    i0.\u0275\u0275text(11, "My Display Name");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(12, "div", 320)(13, "input", 321);
    i0.\u0275\u0275listener("ngModelChange", function RoomComponent_Conditional_98_Template_input_ngModelChange_13_listener($event) {
      i0.\u0275\u0275restoreView(_r24);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.personalDisplayName.set($event));
    })("keyup.enter", function RoomComponent_Conditional_98_Template_input_keyup_enter_13_listener() {
      i0.\u0275\u0275restoreView(_r24);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.savePersonalName());
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(14, "button", 322);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_98_Template_button_click_14_listener() {
      i0.\u0275\u0275restoreView(_r24);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.savePersonalName());
    });
    i0.\u0275\u0275text(15, " Save ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(16, "p", 323);
    i0.\u0275\u0275text(17, "Your name is end-to-end encrypted and only visible to people currently in this room.");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(18, "div", 324);
    i0.\u0275\u0275repeaterCreate(19, RoomComponent_Conditional_98_For_20_Template, 15, 25, "div", 325, _forTrack1);
    i0.\u0275\u0275conditionalCreate(21, RoomComponent_Conditional_98_Conditional_21_Template, 3, 0, "div", 326);
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(13);
    i0.\u0275\u0275property("ngModel", ctx_r1.personalDisplayName());
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275repeater(ctx_r1.socket.activeSessions());
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.socket.activeSessions().length === 0 ? 21 : -1);
  }
}
function RoomComponent_Conditional_99_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Signing Room\xAE Closed ");
  }
}
function RoomComponent_Conditional_99_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Closed ");
  }
}
function RoomComponent_Conditional_99_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 341);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 176);
    i0.\u0275\u0275text(2, " Start New Signing ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_99_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 71)(1, "div", 177)(2, "div", 171);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 340);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "h2", 173);
    i0.\u0275\u0275conditionalCreate(5, RoomComponent_Conditional_99_Conditional_5_Template, 1, 0)(6, RoomComponent_Conditional_99_Conditional_6_Template, 1, 0);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(7, "p", 180);
    i0.\u0275\u0275text(8, "The coordinator has ended this signing session. All data has been securely wiped.");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(9, RoomComponent_Conditional_99_Conditional_9_Template, 3, 0, "a", 341);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275conditional(ctx_r1.configService.config().useTradeMark ? 5 : 6);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(!ctx_r1.isEmbedded ? 9 : -1);
  }
}
function RoomComponent_Conditional_100_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 344);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 176);
    i0.\u0275\u0275text(2, " Start New Signing ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_100_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 72)(1, "div", 177)(2, "div", 342);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 343);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "h2", 173);
    i0.\u0275\u0275text(5, "Room Expired");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p", 180);
    i0.\u0275\u0275text(7, "This session has timed out. All ephemeral data has been wiped.");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(8, RoomComponent_Conditional_100_Conditional_8_Template, 3, 0, "a", 344);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275conditional(!ctx_r1.isEmbedded ? 8 : -1);
  }
}
function RoomComponent_Conditional_101_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 73)(1, "div", 345);
    i0.\u0275\u0275element(2, "div", 346);
    i0.\u0275\u0275elementStart(3, "div", 347);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 348);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(5, "h3", 349);
    i0.\u0275\u0275text(6, "OpSec Warning");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "p", 350);
    i0.\u0275\u0275text(8, " You are about to reveal sensitive transaction details. Before proceeding, please ensure: ");
    i0.\u0275\u0275element(9, "br")(10, "br");
    i0.\u0275\u0275elementStart(11, "span", 351);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(12, "svg", 352);
    i0.\u0275\u0275text(13, " No one is looking over your shoulder. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(14, "span", 353);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(15, "svg", 352);
    i0.\u0275\u0275text(16, " You are not sharing your screen. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(17, "span", 353);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(18, "svg", 352);
    i0.\u0275\u0275text(19, " There are no cameras recording your screen. ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(20, "div", 354)(21, "button", 355);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_101_Template_button_click_21_listener() {
      i0.\u0275\u0275restoreView(_r27);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.closePrivacyWarning());
    });
    i0.\u0275\u0275text(22, " Keep Blurred ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(23, "button", 356);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_101_Template_button_click_23_listener() {
      i0.\u0275\u0275restoreView(_r27);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.confirmUnblurAll());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(24, "svg", 357);
    i0.\u0275\u0275text(25, " Reveal All ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(26, "button", 358);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_101_Template_button_click_26_listener() {
      i0.\u0275\u0275restoreView(_r27);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.confirmUnblur());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(27, "svg", 357);
    i0.\u0275\u0275text(28, " Reveal Section ");
    i0.\u0275\u0275elementEnd()()()();
  }
}
function RoomComponent_Conditional_111_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 26);
  }
}
function RoomComponent_Conditional_112_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 27);
  }
}
function RoomComponent_Conditional_129_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 89)(1, "button", 359);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_129_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r28);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.togglePrivacyBlur("transaction-proposal"));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 305);
    i0.\u0275\u0275text(3, " Hidden for Privacy ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_155_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 363)(1, "div", 365)(2, "span");
    i0.\u0275\u0275text(3, "Ingesting Signature...");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "span");
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "div", 366);
    i0.\u0275\u0275element(7, "div", 291);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate1("", (ctx_r1.urService.scanProgress() * 100).toFixed(0), "%");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275styleProp("width", ctx_r1.urService.scanProgress() * 100, "%");
  }
}
function RoomComponent_Conditional_155_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 104);
    i0.\u0275\u0275element(1, "div", 277);
    i0.\u0275\u0275elementStart(2, "div", 278)(3, "div", 360)(4, "span", 361);
    i0.\u0275\u0275element(5, "div", 362);
    i0.\u0275\u0275text(6, " Scan Signature Sequence ");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(7, "div", 279);
    i0.\u0275\u0275element(8, "div", 280)(9, "div", 281)(10, "div", 282)(11, "div", 283)(12, "div", 284);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(13, RoomComponent_Conditional_155_Conditional_13_Template, 8, 3, "div", 363);
    i0.\u0275\u0275elementStart(14, "button", 364);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_155_Template_button_click_14_listener() {
      i0.\u0275\u0275restoreView(_r29);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.stopScanner());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(15, "svg", 136);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(13);
    i0.\u0275\u0275conditional(ctx_r1.urService.scanProgress() > 0 ? 13 : -1);
  }
}
function RoomComponent_Conditional_161_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 26);
  }
}
function RoomComponent_Conditional_162_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 27);
  }
}
function RoomComponent_Conditional_170_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 112);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 367);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "input", 368);
    i0.\u0275\u0275listener("ngModelChange", function RoomComponent_Conditional_170_Template_input_ngModelChange_2_listener($event) {
      i0.\u0275\u0275restoreView(_r30);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.updateSearchQuery("inputs", $event));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(3, "div", 369);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("ngModel", ctx_r1.inputSearchQuery());
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.filteredInputs().length, " ");
  }
}
function RoomComponent_Conditional_171_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 112);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 367);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "input", 370);
    i0.\u0275\u0275listener("ngModelChange", function RoomComponent_Conditional_171_Template_input_ngModelChange_2_listener($event) {
      i0.\u0275\u0275restoreView(_r31);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.updateSearchQuery("outputs", $event));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(3, "div", 369);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("ngModel", ctx_r1.outputSearchQuery());
    i0.\u0275\u0275control();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.filteredOutputs().length, " ");
  }
}
function RoomComponent_Conditional_172_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 373);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_172_Conditional_1_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r32);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.verifyAllInputs());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 374);
    i0.\u0275\u0275text(2, " Verify All Inputs ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_172_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 375);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_172_Conditional_2_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r33);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.verifyAllOutputs());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 374);
    i0.\u0275\u0275text(2, " Verify All Outputs ");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_172_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 113);
    i0.\u0275\u0275conditionalCreate(1, RoomComponent_Conditional_172_Conditional_1_Template, 3, 0, "button", 371);
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_172_Conditional_2_Template, 3, 0, "button", 372);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.viewMode() === "inputs" ? 1 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.viewMode() === "outputs" ? 2 : -1);
  }
}
function RoomComponent_Conditional_174_For_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 394);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(1, "span", 395);
    i0.\u0275\u0275text(2, "Verified Input");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_174_For_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 396);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(1, "span", 397);
    i0.\u0275\u0275text(2, "UnVerified Input");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_174_For_1_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 383);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const input_r35 = i0.\u0275\u0275nextContext().$implicit;
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate2("", input_r35.txId, ":", input_r35.vout);
  }
}
function RoomComponent_Conditional_174_For_1_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 387);
  }
}
function RoomComponent_Conditional_174_For_1_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 388);
  }
}
function RoomComponent_Conditional_174_For_1_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r36 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 398);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_174_For_1_Conditional_24_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r36);
      const input_r35 = i0.\u0275\u0275nextContext().$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.toggleWhitelist(input_r35.address));
    });
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const input_r35 = i0.\u0275\u0275nextContext().$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classMap(ctx_r1.isWhitelisted(input_r35.address) ? "bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20 hover:border-rose-500/50" : "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 hover:border-emerald-500/50");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.isWhitelisted(input_r35.address) ? "Revoke" : "Verify", " ");
  }
}
function RoomComponent_Conditional_174_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 378)(1, "div", 379);
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_174_For_1_Conditional_2_Template, 3, 0)(3, RoomComponent_Conditional_174_For_1_Conditional_3_Template, 3, 0);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "div", 380)(5, "div", 381)(6, "div", 49)(7, "span", 382);
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(9, RoomComponent_Conditional_174_For_1_Conditional_9_Template, 2, 2, "span", 383);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "div", 384)(11, "span", 385);
    i0.\u0275\u0275text(12);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(13, "button", 386);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_174_For_1_Template_button_click_13_listener() {
      const input_r35 = i0.\u0275\u0275restoreView(_r34).$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.copyAddress(input_r35.address));
    });
    i0.\u0275\u0275conditionalCreate(14, RoomComponent_Conditional_174_For_1_Conditional_14_Template, 1, 0, ":svg:svg", 387)(15, RoomComponent_Conditional_174_For_1_Conditional_15_Template, 1, 0, ":svg:svg", 388);
    i0.\u0275\u0275elementStart(16, "div", 389);
    i0.\u0275\u0275text(17);
    i0.\u0275\u0275elementEnd()()()();
    i0.\u0275\u0275elementStart(18, "div", 390)(19, "div", 391);
    i0.\u0275\u0275text(20);
    i0.\u0275\u0275pipe(21, "number");
    i0.\u0275\u0275elementStart(22, "span", 392);
    i0.\u0275\u0275text(23, "BTC");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(24, RoomComponent_Conditional_174_For_1_Conditional_24_Template, 2, 3, "button", 393);
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const input_r35 = ctx.$implicit;
    const $index_r37 = ctx.$index;
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classProp("border-emerald-500", ctx_r1.isWhitelisted(input_r35.address))("border-brand-card-border", !ctx_r1.isWhitelisted(input_r35.address));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.isWhitelisted(input_r35.address) ? 2 : 3);
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate1(" Input #", $index_r37, " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(input_r35.txId && input_r35.txId !== "????" ? 9 : -1);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(input_r35.address);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.copiedAddress() === input_r35.address ? 14 : 15);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.copiedAddress() === input_r35.address ? "Copied!" : "Copy Address", " ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind2(21, 12, input_r35.amount / 1e8, "1.8-8"), " ");
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(ctx_r1.socket.isCoordinator() ? 24 : -1);
  }
}
function RoomComponent_Conditional_174_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 377);
    i0.\u0275\u0275text(1, "No input data available.");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_174_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 377);
    i0.\u0275\u0275text(1, "No inputs match your search.");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_174_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275repeaterCreate(0, RoomComponent_Conditional_174_For_1_Template, 25, 15, "div", 376, i0.\u0275\u0275repeaterTrackByIndex);
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_174_Conditional_2_Template, 2, 0, "div", 377)(3, RoomComponent_Conditional_174_Conditional_3_Template, 2, 0, "div", 377);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275repeater(ctx_r1.filteredInputs());
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional((ctx_r1.socket.txDetails()?.inputsList?.length || 0) === 0 ? 2 : ctx_r1.filteredInputs().length === 0 ? 3 : -1);
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 401);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(1, "span", 402);
    i0.\u0275\u0275text(2, "Change Output");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 394);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(1, "span", 395);
    i0.\u0275\u0275text(2, "Verified Output");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 403);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(1, "span", 404);
    i0.\u0275\u0275text(2, "Unverified Output");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 396);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(1, "span", 397);
    i0.\u0275\u0275text(2, "Unverified Output");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 387);
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 388);
  }
}
function RoomComponent_Conditional_175_For_1_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 398);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_175_For_1_Conditional_25_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r40);
      const out_r39 = i0.\u0275\u0275nextContext().$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.toggleWhitelist(out_r39.address));
    });
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const out_r39 = i0.\u0275\u0275nextContext().$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classMap(ctx_r1.isWhitelisted(out_r39.address) ? "bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20 hover:border-rose-500/50" : "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 hover:border-emerald-500/50");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.isWhitelisted(out_r39.address) ? "Revoke" : "Verify", " ");
  }
}
function RoomComponent_Conditional_175_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 378)(1, "div", 379);
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_175_For_1_Conditional_2_Template, 3, 0)(3, RoomComponent_Conditional_175_For_1_Conditional_3_Template, 3, 0)(4, RoomComponent_Conditional_175_For_1_Conditional_4_Template, 3, 0)(5, RoomComponent_Conditional_175_For_1_Conditional_5_Template, 3, 0);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "div", 380)(7, "div", 381)(8, "div", 49)(9, "span", 382);
    i0.\u0275\u0275text(10);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(11, "div", 384)(12, "span", 385);
    i0.\u0275\u0275text(13);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(14, "button", 386);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_175_For_1_Template_button_click_14_listener() {
      const out_r39 = i0.\u0275\u0275restoreView(_r38).$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.copyAddress(out_r39.address));
    });
    i0.\u0275\u0275conditionalCreate(15, RoomComponent_Conditional_175_For_1_Conditional_15_Template, 1, 0, ":svg:svg", 387)(16, RoomComponent_Conditional_175_For_1_Conditional_16_Template, 1, 0, ":svg:svg", 388);
    i0.\u0275\u0275elementStart(17, "div", 389);
    i0.\u0275\u0275text(18);
    i0.\u0275\u0275elementEnd()()()();
    i0.\u0275\u0275elementStart(19, "div", 390)(20, "div", 391);
    i0.\u0275\u0275text(21);
    i0.\u0275\u0275pipe(22, "number");
    i0.\u0275\u0275elementStart(23, "span", 392);
    i0.\u0275\u0275text(24, "BTC");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(25, RoomComponent_Conditional_175_For_1_Conditional_25_Template, 2, 3, "button", 393);
    i0.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const out_r39 = ctx.$implicit;
    const $index_r41 = ctx.$index;
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classProp("border-emerald-500", ctx_r1.isWhitelisted(out_r39.address))("border-amber-500", out_r39.isChange)("border-rose-900", !out_r39.isChange && !ctx_r1.isWhitelisted(out_r39.address) && (ctx_r1.socket.roomState()?.whitelist?.length || 0) > 0)("border-brand-card-border", !out_r39.isChange && !ctx_r1.isWhitelisted(out_r39.address) && (!ctx_r1.socket.roomState()?.whitelist || ctx_r1.socket.roomState()?.whitelist?.length === 0));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(out_r39.isChange ? 2 : ctx_r1.isWhitelisted(out_r39.address) ? 3 : (ctx_r1.socket.roomState()?.whitelist?.length || 0) > 0 ? 4 : 5);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate1(" Output #", $index_r41, " ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(out_r39.address);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.copiedAddress() === out_r39.address ? 15 : 16);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.copiedAddress() === out_r39.address ? "Copied!" : "Copy Address", " ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind2(22, 15, out_r39.amount / 1e8, "1.8-8"), " ");
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275conditional(ctx_r1.socket.isCoordinator() ? 25 : -1);
  }
}
function RoomComponent_Conditional_175_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 400);
    i0.\u0275\u0275text(1, "Parsing transaction data...");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_175_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 377);
    i0.\u0275\u0275text(1, "No outputs match your search.");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_175_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275repeaterCreate(0, RoomComponent_Conditional_175_For_1_Template, 26, 18, "div", 399, i0.\u0275\u0275repeaterTrackByIndex);
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_175_Conditional_2_Template, 2, 0, "div", 400)(3, RoomComponent_Conditional_175_Conditional_3_Template, 2, 0, "div", 377);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275repeater(ctx_r1.filteredOutputs());
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(!ctx_r1.socket.txDetails() ? 2 : ctx_r1.filteredOutputs().length === 0 && (ctx_r1.socket.txDetails()?.outputs?.length || 0) > 0 ? 3 : -1);
  }
}
function RoomComponent_Conditional_176_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 115)(1, "button", 304);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_176_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r42);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.togglePrivacyBlur("transaction-details"));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 305);
    i0.\u0275\u0275text(3, " Hidden for Privacy ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_186_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 26);
  }
}
function RoomComponent_Conditional_187_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 27);
  }
}
function RoomComponent_For_192_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 407);
  }
}
function RoomComponent_For_192_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 408);
  }
}
function RoomComponent_For_192_Conditional_6_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 158);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "span", 415);
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 416);
  }
  if (rf & 2) {
    const signer_r44 = i0.\u0275\u0275nextContext(2).$implicit;
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate(ctx);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("(", signer_r44.fingerprint, ")");
  }
}
function RoomComponent_For_192_Conditional_6_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 417);
    i0.\u0275\u0275text(1, "Add Label");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "span", 415);
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(4, "svg", 418);
  }
  if (rf & 2) {
    const signer_r44 = i0.\u0275\u0275nextContext(2).$implicit;
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1("(", signer_r44.fingerprint, ")");
  }
}
function RoomComponent_For_192_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r43 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 414);
    i0.\u0275\u0275listener("click", function RoomComponent_For_192_Conditional_6_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r43);
      const signer_r44 = i0.\u0275\u0275nextContext().$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.openLabelModal(signer_r44.fingerprint));
    });
    i0.\u0275\u0275conditionalCreate(1, RoomComponent_For_192_Conditional_6_Conditional_1_Template, 5, 2)(2, RoomComponent_For_192_Conditional_6_Conditional_2_Template, 5, 1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_11_0;
    const signer_r44 = i0.\u0275\u0275nextContext().$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional((tmp_11_0 = ctx_r1.getLabel(signer_r44.fingerprint)) ? 1 : 2, tmp_11_0);
  }
}
function RoomComponent_For_192_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 410);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const signer_r44 = i0.\u0275\u0275nextContext().$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.getSignerLabel(signer_r44.fingerprint), " ");
  }
}
function RoomComponent_For_192_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 419);
    i0.\u0275\u0275listener("click", function RoomComponent_For_192_Conditional_13_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r45);
      const signer_r44 = i0.\u0275\u0275nextContext().$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.nudgeSigner(signer_r44.fingerprint));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 420);
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_For_192_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 413);
  }
}
function RoomComponent_For_192_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 405)(1, "div", 30)(2, "div", 406);
    i0.\u0275\u0275conditionalCreate(3, RoomComponent_For_192_Conditional_3_Template, 1, 0, ":svg:svg", 407)(4, RoomComponent_For_192_Conditional_4_Template, 1, 0, ":svg:svg", 408);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "div");
    i0.\u0275\u0275conditionalCreate(6, RoomComponent_For_192_Conditional_6_Template, 3, 1, "button", 409)(7, RoomComponent_For_192_Conditional_7_Template, 2, 1, "div", 410);
    i0.\u0275\u0275elementStart(8, "div", 30)(9, "div")(10, "div", 49)(11, "div", 411);
    i0.\u0275\u0275text(12);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(13, RoomComponent_For_192_Conditional_13_Template, 2, 0, "button", 412);
    i0.\u0275\u0275elementEnd()()()()();
    i0.\u0275\u0275conditionalCreate(14, RoomComponent_For_192_Conditional_14_Template, 1, 0, ":svg:svg", 413);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const signer_r44 = ctx.$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275classProp("bg-emerald-500/10", signer_r44.signed)("border-emerald-500/30", signer_r44.signed)("bg-brand-bg", !signer_r44.signed)("border-brand-card-border", !signer_r44.signed);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classProp("bg-emerald-500/20", signer_r44.signed)("text-emerald-400", signer_r44.signed)("bg-brand-card", !signer_r44.signed)("text-brand-text-muted", !signer_r44.signed);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(signer_r44.signed ? 3 : 4);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(ctx_r1.socket.isCoordinator() ? 6 : 7);
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275classProp("text-emerald-400", signer_r44.signed)("text-brand-text-muted", !signer_r44.signed);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", signer_r44.signed ? "Signed" : "Waiting...", " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.socket.isCoordinator() && !signer_r44.signed ? 13 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(!signer_r44.signed ? 14 : -1);
  }
}
function RoomComponent_Conditional_193_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 125);
    i0.\u0275\u0275text(1, "Loading Signers...");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_194_Template(rf, ctx) {
  if (rf & 1) {
    const _r46 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 89)(1, "button", 421);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_194_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r46);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.togglePrivacyBlur("signers"));
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 305);
    i0.\u0275\u0275text(3, " Hidden for Privacy ");
    i0.\u0275\u0275elementEnd()();
  }
}
function RoomComponent_Conditional_196_Conditional_9_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 428);
  }
}
function RoomComponent_Conditional_196_Conditional_9_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(0, "svg", 429);
  }
}
function RoomComponent_Conditional_196_Conditional_9_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 431);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_196_Conditional_9_Conditional_5_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r48);
      const ctx_r1 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r1.broadcastAndCopy());
    });
    i0.\u0275\u0275text(1, " Broadcast ");
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(2, "svg", 432);
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_196_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 296)(1, "button", 427);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_196_Conditional_9_Template_button_click_1_listener() {
      i0.\u0275\u0275restoreView(_r47);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.copyHex());
    });
    i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_196_Conditional_9_Conditional_2_Template, 1, 0, ":svg:svg", 428)(3, RoomComponent_Conditional_196_Conditional_9_Conditional_3_Template, 1, 0, ":svg:svg", 429);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(5, RoomComponent_Conditional_196_Conditional_9_Conditional_5_Template, 3, 0, "button", 430);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275classProp("grid-cols-2", !ctx_r1.isEmbedded)("grid-cols-1", ctx_r1.isEmbedded);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.copied() ? 2 : 3);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.copied() ? "Copied" : "Copy Hex", " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(!ctx_r1.isEmbedded ? 5 : -1);
  }
}
function RoomComponent_Conditional_196_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 127)(1, "div", 422)(2, "div", 423);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(3, "svg", 424);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(4, "div")(5, "h4", 234);
    i0.\u0275\u0275text(6, "Transaction Signed");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(7, "p", 425);
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275conditionalCreate(9, RoomComponent_Conditional_196_Conditional_9_Template, 6, 7, "div", 426);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.socket.isCoordinator() ? "Ready to broadcast" : "Awaiting Coordinator broadcast", " ");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.socket.isCoordinator() ? 9 : -1);
  }
}
function RoomComponent_Conditional_197_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 435);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_197_Conditional_0_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r49);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.finalize());
    });
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 436);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate2(" Finalize Transaction (", ctx_r1.socket.signerCount(), "/", ctx_r1.socket.signerThreshold(), ") ");
  }
}
function RoomComponent_Conditional_197_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 434);
    i0.\u0275\u0275text(1, "Only the Coordinator can finalize.");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_197_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275conditionalCreate(0, RoomComponent_Conditional_197_Conditional_0_Template, 3, 2, "button", 433)(1, RoomComponent_Conditional_197_Conditional_1_Template, 2, 0, "p", 434);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275conditional(ctx_r1.socket.isCoordinator() ? 0 : 1);
  }
}
function RoomComponent_Conditional_198_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "button", 128);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275element(1, "svg", 437);
    i0.\u0275\u0275namespaceHTML();
    i0.\u0275\u0275elementStart(2, "span");
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate2("Waiting for Signatures (", ctx_r1.socket.signerCount(), " / ", ctx_r1.socket.signerThreshold(), ")");
  }
}
function RoomComponent_Conditional_199_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r50 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 442);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_199_Conditional_5_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r50);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.showClaimInput.set(true));
    });
    i0.\u0275\u0275text(1, "Have the Admin Key? Claim Coordinator Role");
    i0.\u0275\u0275elementEnd();
  }
}
function RoomComponent_Conditional_199_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r51 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 441)(1, "input", 443);
    i0.\u0275\u0275twoWayListener("ngModelChange", function RoomComponent_Conditional_199_Conditional_6_Template_input_ngModelChange_1_listener($event) {
      i0.\u0275\u0275restoreView(_r51);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.claimPassword, $event) || (ctx_r1.claimPassword = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275controlCreate();
    i0.\u0275\u0275elementStart(2, "button", 444);
    i0.\u0275\u0275listener("click", function RoomComponent_Conditional_199_Conditional_6_Template_button_click_2_listener() {
      i0.\u0275\u0275restoreView(_r51);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.claimRole());
    });
    i0.\u0275\u0275text(3, "Claim");
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.claimPassword);
    i0.\u0275\u0275control();
  }
}
function RoomComponent_Conditional_199_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 129)(1, "p", 438);
    i0.\u0275\u0275text(2, "Waiting for Finalization");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(3, "p", 439);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(5, RoomComponent_Conditional_199_Conditional_5_Template, 2, 0, "button", 440)(6, RoomComponent_Conditional_199_Conditional_6_Template, 4, 1, "div", 441);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate1("", ctx_r1.Math.max(0, ctx_r1.socket.signerThreshold() - (ctx_r1.socket.signerCount() || 0)), " more signatures required");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(!ctx_r1.showClaimInput() ? 5 : 6);
  }
}
var RoomComponent = class _RoomComponent {
  constructor(route, socket, router, titleService, urService, platformId, dispatcher, encryptionEngine, configService) {
    this.route = route;
    this.socket = socket;
    this.router = router;
    this.titleService = titleService;
    this.urService = urService;
    this.platformId = platformId;
    this.dispatcher = dispatcher;
    this.encryptionEngine = encryptionEngine;
    this.configService = configService;
    effect(() => {
      const status = this.socket.status();
      const currentFragment = this.route.snapshot.fragment;
      if (status === "connected" && currentFragment) {
        this.router.navigate([], {
          relativeTo: this.route,
          fragment: void 0,
          replaceUrl: true
        });
      }
    });
    effect(() => {
      if (!isPlatformBrowser(this.platformId))
        return;
      const state = this.socket.roomState();
      if (this.socket.isLockedOut() || this.socket.roomNotFound() || this.socket.decryptionError() || this.socket.isRoomFull()) {
        return;
      }
      if (state) {
        if (state.createdAt)
          this.startTimer(state.expiresAt);
      }
      if (this.socket.isClosed()) {
        if (!this.isEmbedded) {
          this.generateAuditLog();
        }
      }
    });
    effect(() => {
      if (this.socket.isCoordinator()) {
        const _ = this.socket.signers();
        this.socket.checkAndApplyLocalLabels();
      }
    });
    effect(() => {
      const state = this.socket.roomState();
      const signers = this.socket.signers();
      const signedCount = signers.filter((s) => s.signed).length;
      const threshold = this.requiredSignatures;
      const remaining = Math.max(0, threshold - signedCount);
      const config = this.configService.config();
      const brandName = config.brandName + (config.brandSuffix || "");
      if (this.finalHex()) {
        this.titleService.setTitle(`\u2705 Ready to Broadcast | ${brandName}`);
      } else if (signedCount >= threshold) {
        this.titleService.setTitle(`\u{1F7E0} Ready to Finalize | ${brandName}`);
      } else if (state?.isLocked) {
        this.titleService.setTitle(`\u{1F512} Room Locked | ${brandName}`);
      } else {
        this.titleService.setTitle(`\u{1F534} ${remaining} Needed | ${brandName}`);
      }
    });
    effect(() => {
      const currentSessions = this.socket.activeSessions();
      if (this.socket.status() === "connected") {
        const joined = currentSessions.filter((cs) => !this.previousSessions.some((ps) => ps.id === cs.id));
        const left = this.previousSessions.filter((ps) => !currentSessions.some((cs) => cs.id === ps.id));
        const nameChanged = currentSessions.filter((cs) => {
          const prev = this.previousSessions.find((ps) => ps.id === cs.id);
          return prev && prev.displayName !== cs.displayName;
        });
        joined.forEach((p) => this.dispatcher.emitParticipantPresence("joined", p.id, p.role, p.displayName));
        left.forEach((p) => this.dispatcher.emitParticipantPresence("left", p.id, p.role, p.displayName));
        nameChanged.forEach((p) => {
          if (p.id !== this.socket.currentSessionId()) {
            this.dispatcher.emitParticipantLabelled("participant", p.displayName || "Anonymous", void 0, p.id);
          }
        });
      }
      this.previousSessions = currentSessions;
    });
    this.socket.networkSignatureReceived$.subscribe((data) => {
      const sessions = this.socket.activeSessions();
      const uploaderSession = sessions.find((s) => s.id === data.sessionId);
      const label = this.socket.roomState()?.signerLabels?.[data.fingerprint];
      this.dispatcher.emitSignatureReceived(data.fingerprint, label, data.sessionId, uploaderSession?.displayName);
    });
    this.socket.securityAlert$.subscribe((event) => {
      const severity = event.count >= 3 ? "high" : "medium";
      this.dispatcher.emitSecurityAlert(event.type, severity, `Failed decryption attempt ${event.count}/3`);
    });
  }
  route;
  socket;
  router;
  titleService;
  urService;
  platformId;
  dispatcher;
  encryptionEngine;
  configService;
  unloadNotification($event) {
    if (this.socket.status() === "connected" && !this.finalHex() && !this.socket.isClosed()) {
      $event.returnValue = true;
    }
  }
  onBeforeUnload() {
    this.socket.disconnect();
  }
  // Math is still required for template calculations
  Math = Math;
  roomId = signal(
    null,
    ...ngDevMode ? [{ debugName: "roomId" }] : (
      /* istanbul ignore next */
      []
    )
  );
  viewMode = signal(
    "outputs",
    ...ngDevMode ? [{ debugName: "viewMode" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isUploading = signal(
    false,
    ...ngDevMode ? [{ debugName: "isUploading" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showRenameModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showRenameModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  newRoomName = signal(
    "",
    ...ngDevMode ? [{ debugName: "newRoomName" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showQrModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showQrModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showSessionsModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showSessionsModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showKeyModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showKeyModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showAdminModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showAdminModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showRoomIdModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showRoomIdModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showAuditModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showAuditModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showCsvModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showCsvModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showPsbtModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showPsbtModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  personalDisplayName = signal(
    "",
    ...ngDevMode ? [{ debugName: "personalDisplayName" }] : (
      /* istanbul ignore next */
      []
    )
  );
  copiedSessionId = signal(
    null,
    ...ngDevMode ? [{ debugName: "copiedSessionId" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isQrRevealed = signal(
    false,
    ...ngDevMode ? [{ debugName: "isQrRevealed" }] : (
      /* istanbul ignore next */
      []
    )
  );
  qrDataUrl = signal(
    null,
    ...ngDevMode ? [{ debugName: "qrDataUrl" }] : (
      /* istanbul ignore next */
      []
    )
  );
  qrIncludesKey = signal(
    false,
    ...ngDevMode ? [{ debugName: "qrIncludesKey" }] : (
      /* istanbul ignore next */
      []
    )
  );
  timeRemaining = signal(
    "Loading...",
    ...ngDevMode ? [{ debugName: "timeRemaining" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isExpired = signal(
    false,
    ...ngDevMode ? [{ debugName: "isExpired" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isLowTime = signal(
    false,
    ...ngDevMode ? [{ debugName: "isLowTime" }] : (
      /* istanbul ignore next */
      []
    )
  );
  timerInterval;
  inputSearchQuery = signal(
    "",
    ...ngDevMode ? [{ debugName: "inputSearchQuery" }] : (
      /* istanbul ignore next */
      []
    )
  );
  outputSearchQuery = signal(
    "",
    ...ngDevMode ? [{ debugName: "outputSearchQuery" }] : (
      /* istanbul ignore next */
      []
    )
  );
  filteredInputs = computed(
    () => {
      const inputs = this.socket.txDetails()?.inputsList || [];
      const query = this.inputSearchQuery().toLowerCase().trim();
      if (!query)
        return inputs;
      return inputs.filter((input) => input.address.toLowerCase().includes(query));
    },
    ...ngDevMode ? [{ debugName: "filteredInputs" }] : (
      /* istanbul ignore next */
      []
    )
  );
  filteredOutputs = computed(
    () => {
      const outputs = this.socket.txDetails()?.outputs || [];
      const query = this.outputSearchQuery().toLowerCase().trim();
      if (!query)
        return outputs;
      return outputs.filter((output) => output.address.toLowerCase().includes(query));
    },
    ...ngDevMode ? [{ debugName: "filteredOutputs" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showLabelModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showLabelModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showClaimInput = signal(
    false,
    ...ngDevMode ? [{ debugName: "showClaimInput" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showConfirmModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showConfirmModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  confirmData = signal(
    {
      title: "",
      message: "",
      action: () => {
      },
      isDestructive: false,
      type: "confirm"
    },
    ...ngDevMode ? [{ debugName: "confirmData" }] : (
      /* istanbul ignore next */
      []
    )
  );
  finalHex = computed(
    () => this.socket.roomState()?.finalTxHex || null,
    ...ngDevMode ? [{ debugName: "finalHex" }] : (
      /* istanbul ignore next */
      []
    )
  );
  copied = signal(
    false,
    ...ngDevMode ? [{ debugName: "copied" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showShareModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showShareModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  secureLinkCopied = signal(
    false,
    ...ngDevMode ? [{ debugName: "secureLinkCopied" }] : (
      /* istanbul ignore next */
      []
    )
  );
  fullLinkCopied = signal(
    false,
    ...ngDevMode ? [{ debugName: "fullLinkCopied" }] : (
      /* istanbul ignore next */
      []
    )
  );
  keyCopied = signal(
    false,
    ...ngDevMode ? [{ debugName: "keyCopied" }] : (
      /* istanbul ignore next */
      []
    )
  );
  adminCopied = signal(
    false,
    ...ngDevMode ? [{ debugName: "adminCopied" }] : (
      /* istanbul ignore next */
      []
    )
  );
  roomIdCopied = signal(
    false,
    ...ngDevMode ? [{ debugName: "roomIdCopied" }] : (
      /* istanbul ignore next */
      []
    )
  );
  claimPassword = "";
  manualKey = "";
  previousSessions = [];
  editingFingerprint = signal(
    null,
    ...ngDevMode ? [{ debugName: "editingFingerprint" }] : (
      /* istanbul ignore next */
      []
    )
  );
  editingLabel = signal(
    "",
    ...ngDevMode ? [{ debugName: "editingLabel" }] : (
      /* istanbul ignore next */
      []
    )
  );
  saveToBook = signal(
    true,
    ...ngDevMode ? [{ debugName: "saveToBook" }] : (
      /* istanbul ignore next */
      []
    )
  );
  hasEmittedFinalized = false;
  expectedHost = "";
  html5QrCode = null;
  isScanningSigned = signal(
    false,
    ...ngDevMode ? [{ debugName: "isScanningSigned" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showFountainModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showFountainModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isFountainRevealed = signal(
    false,
    ...ngDevMode ? [{ debugName: "isFountainRevealed" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showScannerModal = signal(
    false,
    ...ngDevMode ? [{ debugName: "showScannerModal" }] : (
      /* istanbul ignore next */
      []
    )
  );
  copiedAddress = signal(
    null,
    ...ngDevMode ? [{ debugName: "copiedAddress" }] : (
      /* istanbul ignore next */
      []
    )
  );
  exportFormat = signal(
    "ur",
    ...ngDevMode ? [{ debugName: "exportFormat" }] : (
      /* istanbul ignore next */
      []
    )
  );
  activeFountainFrames = [];
  currentFrameIndex = signal(
    0,
    ...ngDevMode ? [{ debugName: "currentFrameIndex" }] : (
      /* istanbul ignore next */
      []
    )
  );
  fountainInterval;
  fountainSpeed = signal(
    400,
    ...ngDevMode ? [{ debugName: "fountainSpeed" }] : (
      /* istanbul ignore next */
      []
    )
  );
  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.route.paramMap.subscribe((params) => __async(this, null, function* () {
        const id = params.get("id");
        const fragmentKey = this.route.snapshot.fragment;
        const hostParam = this.route.snapshot.queryParamMap.get("host");
        if (hostParam) {
          this.expectedHost = decodeURIComponent(hostParam);
          this.dispatcher.setTargetOrigin(this.expectedHost);
        } else if (typeof window !== "undefined") {
          this.expectedHost = window.location.origin;
        }
        if (!id)
          return;
        this.roomId.set(id);
        const isAlreadyConnected = this.socket.status() === "connected";
        const isCorrectRoom = this.socket.sdk.store.getState()?.roomId === id;
        if (isAlreadyConnected && isCorrectRoom) {
          return;
        }
        if (fragmentKey) {
          this.socket.setRoomKey(fragmentKey);
          yield this.socket.connect(id, fragmentKey);
        } else {
          this.socket.decryptionError.set("Missing decryption key");
        }
      }));
    }
  }
  ngOnDestroy() {
    if (isPlatformBrowser(this.platformId)) {
      this.socket.disconnect();
      this.socket.reset();
      if (this.timerInterval)
        clearInterval(this.timerInterval);
    }
  }
  get requiredSignatures() {
    const psbt = this.socket.roomState()?.psbt;
    return psbt ? this.socket.getThreshold(psbt) : 0;
  }
  get canFinalize() {
    const state = this.socket.roomState();
    if (!state)
      return false;
    const signedCount = state.signatures.length;
    const threshold = this.requiredSignatures;
    return threshold > 0 && signedCount >= threshold;
  }
  get isEmbedded() {
    return this.dispatcher.isEmbedded;
  }
  isWhitelisted(address) {
    return this.socket.roomState()?.whitelist?.includes(address) || false;
  }
  getSignerLabel(fingerprint) {
    const labels = this.socket.roomState()?.signerLabels || {};
    const name = labels[fingerprint];
    return name ? `${name} (${fingerprint})` : fingerprint;
  }
  getLabel(fingerprint) {
    return this.socket.roomState()?.signerLabels?.[fingerprint];
  }
  isSaved(fingerprint) {
    return !!this.socket.getLocalLabel(fingerprint);
  }
  onFileSelected(event) {
    return __async(this, null, function* () {
      const file = event.target.files[0];
      if (!file)
        return;
      const validExtensions = [".psbt", ".txt", ".hex", ".base64"];
      const fileName = file.name.toLowerCase();
      if (!validExtensions.some((ext) => fileName.endsWith(ext))) {
        this.openAlert("Invalid File Type", "Please upload a .psbt, .txt, or .hex file.");
        event.target.value = "";
        return;
      }
      if (file.size > 2 * 1024 * 1024) {
        this.openAlert("File Too Large", "File exceeds 2MB limit. PSBTs are usually much smaller.");
        event.target.value = "";
        return;
      }
      this.isUploading.set(true);
      try {
        const psbtContent = yield this.socket.sdk.parsePsbtFile(file);
        yield this.socket.uploadSignature(psbtContent);
        this.dispatcher.emitPsbtImported("upload");
        event.target.value = "";
      } catch (e) {
        console.error(e);
        this.openAlert("Read Error", "Failed to read file.");
      } finally {
        this.isUploading.set(false);
      }
    });
  }
  promptPsbtDownload() {
    this.showPsbtModal.set(true);
  }
  executePsbtDownload() {
    return __async(this, null, function* () {
      this.showPsbtModal.set(false);
      yield this.socket.logAction("PSBT Downloaded", "Unsigned file exported");
      this.downloadUnsignedPsbt();
    });
  }
  downloadUnsignedPsbt() {
    this.socket.logAction("PSBT Downloaded", "Unsigned file exported");
    const psbt = this.socket.roomState()?.psbt;
    if (!psbt)
      return;
    const blob = new Blob([psbt], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `unsigned_tx_${this.roomId()?.slice(0, 8)}.psbt`;
    a.click();
    window.URL.revokeObjectURL(url);
    this.dispatcher.emitDownloadTriggered("unsigned-psbt");
  }
  claimRole() {
    return __async(this, null, function* () {
      if (this.claimPassword) {
        const cleanToken = this.claimPassword.trim();
        this.socket.claimCoordinator(cleanToken);
        const encryptedToken = yield this.encryptionEngine.encrypt(cleanToken, this.socket.getRoomKey() || "");
        sessionStorage.setItem(`admin_token_${this.roomId()}`, encryptedToken);
        this.showClaimInput.set(false);
        this.claimPassword = "";
      }
    });
  }
  closeRoom() {
    this.dispatcher.emitModalView("Close Room Warning");
    this.openConfirm("Close Room", "Are you sure you want to close this room? This action cannot be undone and will delete all data immediately.", () => {
      if (!this.isEmbedded) {
        this.generateAuditLog();
      }
      this.dispatcher.emitRoomStateChanged("closed");
      setTimeout(() => {
        this.socket.closeRoom();
        if (!this.isEmbedded) {
          this.router.navigate(["/"]);
        }
      }, 300);
    }, true);
  }
  openRenameModal() {
    const currentRoomName = this.socket.roomState()?.roomName;
    this.newRoomName.set(currentRoomName || "");
    this.showRenameModal.set(true);
    this.dispatcher.emitModalView("Rename Room");
  }
  closeRenameModal() {
    this.showRenameModal.set(false);
  }
  saveRoomName() {
    let name = this.newRoomName().trim();
    const MAX_LENGTH = 64;
    if (name.length > MAX_LENGTH) {
      name = name.slice(0, MAX_LENGTH);
    }
    if (!name) {
      return;
    }
    this.socket.renameRoom(name);
    this.dispatcher.emitRoomRenamed(name);
    this.closeRenameModal();
  }
  toggleLock() {
    const current = this.socket.roomState()?.isLocked;
    const action = current ? "Unlock" : "LOCK";
    this.dispatcher.emitModalView(`${action} Room Warning`);
    this.openConfirm(`${action} Room`, `Are you sure you want to ${action} this room? ${current ? "New users will be able to join." : "No new users will be able to connect."}`, () => {
      this.socket.toggleLock(!current);
      this.dispatcher.emitRoomStateChanged(!current ? "locked" : "unlocked");
    }, !current);
  }
  openLabelModal(fingerprint) {
    const current = this.socket.roomState()?.signerLabels?.[fingerprint] || "";
    const saved = this.socket.getLocalLabel(fingerprint);
    this.editingFingerprint.set(fingerprint);
    this.editingLabel.set(current || saved || "");
    this.saveToBook.set(true);
    this.showLabelModal.set(true);
  }
  saveLabel() {
    const fp = this.editingFingerprint();
    const label = this.editingLabel().trim();
    if (fp) {
      this.socket.updateSignerLabel(fp, label);
      if (this.saveToBook() && label) {
        this.socket.saveToAddressBook(fp, label);
      } else {
        this.socket.removeFromAddressBook(fp);
      }
      this.dispatcher.emitParticipantLabelled("signer", label, fp);
    }
    this.closeLabelModal();
  }
  closeLabelModal() {
    this.showLabelModal.set(false);
    this.editingFingerprint.set(null);
    this.editingLabel.set("");
  }
  toggleWhitelist(address) {
    const isPresent = this.isWhitelisted(address);
    this.openConfirm("Update Whitelist", `${isPresent ? "Remove" : "Add"} the following address ${isPresent ? "from" : "to"} the whitelist?

${address}`, () => {
      this.socket.updateWhitelist([address], isPresent);
      this.dispatcher.emitDestinationVerified(this.viewMode(), address, !isPresent);
    }, false);
  }
  copyAddress(address) {
    if (!address)
      return;
    navigator.clipboard.writeText(address).then(() => {
      this.copiedAddress.set(address);
      const shortAddress = `${address.slice(0, 6)}...${address.slice(-6)}`;
      this.socket.logAction("Address Copied", `${shortAddress}`);
      this.dispatcher.emitAddressCopied(address);
      setTimeout(() => {
        if (this.copiedAddress() === address) {
          this.copiedAddress.set(null);
        }
      }, 2e3);
    }).catch((err) => {
      console.error("Failed to copy address: ", err);
    });
  }
  openSessionsModal() {
    if (typeof localStorage !== "undefined") {
      const savedName = localStorage.getItem(`display_name_${this.roomId()}`);
      this.personalDisplayName.set(savedName || "");
    }
    this.showSessionsModal.set(true);
    this.dispatcher.emitModalView("Active Sessions");
  }
  savePersonalName() {
    const name = this.personalDisplayName().trim();
    this.socket.setDisplayName(name);
    this.dispatcher.emitParticipantLabelled("self", name);
    this.showSessionsModal.set(false);
  }
  copySessionId(id, displayName) {
    const name = displayName || "Anonymous Guest";
    const textToCopy = `${name} (Session: ${id})`;
    navigator.clipboard.writeText(textToCopy);
    this.copiedSessionId.set(id);
    this.dispatcher.emitDataCopied("session-id");
    setTimeout(() => this.copiedSessionId.set(null), 2e3);
  }
  verifyAllInputs() {
    const inputs = this.socket.txDetails()?.inputsList || [];
    if (inputs.length === 0)
      return;
    const toAdd = inputs.map((i) => i.address).filter((addr) => !this.isWhitelisted(addr));
    if (toAdd.length > 0) {
      this.socket.updateWhitelist(toAdd, false);
      this.dispatcher.emitDestinationVerified("inputs", "batch", true);
    }
  }
  verifyAllOutputs() {
    const outputs = this.socket.txDetails()?.outputs || [];
    if (outputs.length === 0)
      return;
    this.openConfirm("Batch Verify Outputs", `Are you sure you want to verify all ${outputs.length} outputs?`, () => {
      const toAdd = outputs.map((o) => o.address).filter((addr) => !this.isWhitelisted(addr));
      if (toAdd.length > 0) {
        this.socket.updateWhitelist(toAdd, false);
        this.dispatcher.emitDestinationVerified("outputs", "batch", true);
      }
    }, false);
  }
  setViewMode(mode) {
    this.viewMode.set(mode);
    this.dispatcher.emitTransactionViewChanged(mode);
  }
  updateSearchQuery(view, query) {
    if (view === "inputs") {
      this.inputSearchQuery.set(query);
    } else {
      this.outputSearchQuery.set(query);
    }
  }
  finalize() {
    return __async(this, null, function* () {
      if (this.isExpired())
        return;
      const initialState = this.socket.roomState();
      const doFinalize = () => __async(this, null, function* () {
        try {
          const finalized = yield this.socket.finalizeTransaction();
          if (finalized) {
            const freshState = this.socket.roomState();
            if (freshState && freshState.finalTxId && freshState.finalTxHex && this.isEmbedded && this.socket.isCoordinator() && !this.hasEmittedFinalized) {
              this.hasEmittedFinalized = true;
              const sanitizedState = __spreadValues({}, freshState);
              delete sanitizedState.expectedPass;
              const pdfData = yield this.getPdfDocument();
              const pdfBase64 = pdfData ? pdfData.doc.output("datauristring") : null;
              this.dispatcher.emitTransactionFinalized({
                txId: freshState.finalTxId,
                txHex: freshState.finalTxHex,
                roomState: sanitizedState,
                auditLogCsv: this.socket.getAuditLogCsv(),
                settlementCsv: this.socket.getSettlementCsvData(),
                auditPdfUri: pdfBase64
              });
            }
            this.triggerConfetti();
          }
        } catch (e) {
          console.error("Failed to finalize transaction", e);
        }
      });
      if (initialState?.whitelist && initialState.whitelist.length > 0) {
        const outputs = this.socket.txDetails()?.outputs || [];
        const unverified = outputs.filter((out) => {
          if (out.isChange)
            return false;
          if (initialState.whitelist.includes(out.address))
            return false;
          return true;
        });
        if (unverified.length > 0) {
          this.openConfirm("Security Warning", `You are sending funds to ${unverified.length} unverified address(es). Are you sure you want to proceed?`, () => doFinalize(), true);
          return;
        }
      }
      yield doFinalize();
    });
  }
  broadcastAndCopy() {
    if (this.finalHex()) {
      navigator.clipboard.writeText(this.finalHex());
      const rawNet = this.socket.roomState()?.network;
      const allowed = ["bitcoin", "testnet", "signet"];
      const net = allowed.includes(rawNet || "") ? rawNet : "bitcoin";
      const baseUrl = net === "bitcoin" ? "https://mempool.space" : net === "testnet" ? "https://mempool.space/testnet" : "https://mempool.space/signet";
      window.open(`${baseUrl}/tx/push`, "_blank");
    }
  }
  openConfirm(title, message, action, isDestructive = false) {
    this.confirmData.set({ title, message, action, isDestructive, type: "confirm" });
    this.showConfirmModal.set(true);
  }
  openAlert(title, message) {
    this.confirmData.set({ title, message, action: () => {
    }, isDestructive: false, type: "alert" });
    this.showConfirmModal.set(true);
  }
  executeConfirmAction() {
    this.confirmData().action();
    this.closeConfirmModal();
  }
  closeConfirmModal() {
    this.showConfirmModal.set(false);
    this.confirmData.set({
      title: "",
      message: "",
      action: () => {
      },
      isDestructive: false,
      type: "confirm"
    });
  }
  openQr() {
    return __async(this, null, function* () {
      this.showQrModal.set(true);
      this.isQrRevealed.set(false);
      this.qrIncludesKey.set(false);
      this.dispatcher.emitModalView("Room QR Code");
      this.dispatcher.emitQrStateChanged(false, false);
      yield this.generateQrData();
    });
  }
  toggleQrKey(includesKey) {
    return __async(this, null, function* () {
      this.qrIncludesKey.set(includesKey);
      this.isQrRevealed.set(false);
      this.dispatcher.emitQrStateChanged(includesKey, false);
      yield this.generateQrData();
    });
  }
  generateQrData() {
    return __async(this, null, function* () {
      try {
        const link = this.qrIncludesKey() ? this.getFullShareLink() : window.location.href.split("#")[0];
        const dataUrl = yield QRCode.toDataURL(link, {
          width: 400,
          margin: 2,
          color: {
            dark: "#000000",
            light: "#ffffff"
          },
          errorCorrectionLevel: "M"
        });
        this.qrDataUrl.set(dataUrl);
      } catch (err) {
        console.error("QR Generation failed", err);
      }
    });
  }
  closeQr() {
    this.showQrModal.set(false);
    this.qrDataUrl.set(null);
  }
  toggleQrReveal() {
    const isRevealing = !this.isQrRevealed();
    this.isQrRevealed.update((v) => !v);
    this.dispatcher.emitQrStateChanged(this.qrIncludesKey(), isRevealing);
    if (isRevealing) {
      const qrType = this.qrIncludesKey() ? "Full (Link + Key)" : "Link Only (No Key)";
      this.socket.logAction("QR Code Revealed", `${qrType} QR Code on screen`);
    }
  }
  downloadQr() {
    const url = this.qrDataUrl();
    if (!url)
      return;
    const qrType = this.qrIncludesKey() ? "Full (Link + Key)" : "Link Only (No Key)";
    this.socket.logAction("QR Code Downloaded", `${qrType} QR Code to their device`);
    this.dispatcher.emitDownloadTriggered("qr-code-image");
    const safeId = this.roomId() ?? "unknown-room";
    const a = document.createElement("a");
    a.href = url;
    a.download = `signingroom-qr-${safeId.slice(0, 8)}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
  submitKey() {
    if (!this.manualKey)
      return;
    let key = this.manualKey.trim();
    if (key.includes("#"))
      key = key.split("#")[1];
    this.socket.decryptionError.set("");
    this.socket.connect(this.roomId(), key);
    this.manualKey = "";
  }
  promptAuditLogDownload() {
    this.showAuditModal.set(true);
    this.dispatcher.emitModalView("Download Audit Log");
  }
  executeAuditDownload() {
    return __async(this, null, function* () {
      this.showAuditModal.set(false);
      this.dispatcher.emitDownloadTriggered("audit-log");
      yield this.delay(1e3);
      this.generateAuditLog();
    });
  }
  promptCsvDownload() {
    this.showCsvModal.set(true);
    this.dispatcher.emitModalView("Download CSV Data");
  }
  executeCsvDownload() {
    return __async(this, null, function* () {
      this.showCsvModal.set(false);
      this.dispatcher.emitDownloadTriggered("csv");
      yield this.delay(1e3);
      this.downloadCsv();
    });
  }
  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  downloadCsv() {
    const csvContent = this.socket.getSettlementCsvData();
    if (!csvContent)
      return;
    const roomId = this.socket.roomState()?.roomId || "unknown";
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `settlement_${roomId}_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }
  hexToRgb(hex2) {
    const cleanHex = hex2.replace("#", "").trim();
    if (cleanHex.length === 6) {
      return [
        parseInt(cleanHex.substring(0, 2), 16),
        parseInt(cleanHex.substring(2, 4), 16),
        parseInt(cleanHex.substring(4, 6), 16)
      ];
    }
    return [16, 185, 129];
  }
  getBase64Logo(url) {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "Anonymous";
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const width = img.width || 550;
        const height = img.height || 160;
        canvas.width = width * 3;
        canvas.height = height * 3;
        const ctx = canvas.getContext("2d");
        if (!ctx)
          return resolve(null);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/png"));
      };
      img.onerror = () => resolve(null);
      img.src = url;
    });
  }
  generateAuditLog() {
    return __async(this, null, function* () {
      const config = this.configService.config();
      const reportHeading = config.brandName;
      const rgbColor = this.hexToRgb(config.brandColorHex || "#10b981");
      const base64Logo = yield this.getBase64Logo(config.logoUrl);
      const { doc, filename } = yield this.socket.getAuditLogPdf({
        brandName: reportHeading,
        brandColor: rgbColor,
        logoDataUrl: base64Logo || void 0,
        isWhitelabel: config.whitelabel
      });
      yield doc.save(filename);
    });
  }
  getPdfDocument() {
    return this.socket.getAuditLogPdf();
  }
  startTimer(expiryTime) {
    if (this.timerInterval)
      clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      const now = Date.now();
      const diff = expiryTime - now;
      if (diff <= 0) {
        this.timeRemaining.set("00 hrs 00 m 00 s");
        this.isExpired.set(true);
        clearInterval(this.timerInterval);
        this.socket.disconnect();
      } else {
        const hours = Math.floor(diff / (1e3 * 60 * 60));
        const minutes = Math.floor(diff % (1e3 * 60 * 60) / (1e3 * 60));
        const seconds = Math.floor(diff % (1e3 * 60) / 1e3);
        const pad = (n) => n.toString().padStart(2, "0");
        this.timeRemaining.set(`${pad(hours)} hrs ${pad(minutes)} m ${pad(seconds)} s`);
        this.isLowTime.set(diff < 12e4);
      }
    }, 1e3);
  }
  triggerConfetti() {
    import("/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/canvas-confetti.js?v=cf17c1b4").then((c) => c.default());
  }
  copyHex() {
    this.doCopy(this.finalHex() || "", this.copied);
    this.dispatcher.emitDataCopied("final-hex");
  }
  doCopy(text, signalToToggle) {
    navigator.clipboard.writeText(text);
    if (signalToToggle) {
      signalToToggle.set(true);
      setTimeout(() => signalToToggle.set(false), 2e3);
    }
  }
  getFullShareLink() {
    return this.socket.getRoomLink(window.location.origin, true);
  }
  nudgeSigner(fingerprint) {
    const label = this.getSignerLabel(fingerprint);
    const msg = `Signature needed from: ${label}
${this.getFullShareLink()}`;
    navigator.clipboard.writeText(msg).then(() => {
      this.openAlert("Nudge Message Copied", `Nudge message for ${label} copied! Paste it in your chat app.`);
    });
    this.socket.logAction("Nudge Sent", `Reminder sent to ${label}`);
  }
  openShareModal() {
    this.showShareModal.set(true);
    this.dispatcher.emitModalView("Share Room Securely");
  }
  closeShareModal() {
    this.showShareModal.set(false);
  }
  copySecureLink() {
    const baseUrl = window.location.href.split("#")[0];
    this.doCopy(baseUrl, this.secureLinkCopied);
    this.socket.logAction("Link Copied (No Key)", "User copied room link");
    this.dispatcher.emitDataCopied("share-link");
    this.closeShareModal();
  }
  copyFullLink() {
    this.doCopy(this.getFullShareLink(), this.fullLinkCopied);
    this.socket.logAction("Link Copied (With Key)", "User copied room link");
    this.dispatcher.emitDataCopied("share-link-full");
    this.closeShareModal();
  }
  openKeyModal() {
    this.showKeyModal.set(true);
    this.dispatcher.emitModalView("Room Decryption Key");
  }
  closeKeyModal() {
    this.showKeyModal.set(false);
  }
  openAdminModal() {
    this.showAdminModal.set(true);
    this.dispatcher.emitModalView("Backup Admin Token");
  }
  closeAdminModal() {
    this.showAdminModal.set(false);
  }
  openRoomIdModal() {
    this.showRoomIdModal.set(true);
    this.dispatcher.emitModalView("Room ID");
  }
  closeRoomIdModal() {
    this.showRoomIdModal.set(false);
  }
  copyKey() {
    this.doCopy(this.socket.getRoomKey() || "", this.keyCopied);
    this.socket.logAction("Key Copied", "Copied room decryption key");
    this.dispatcher.emitDataCopied("decryption-key");
    this.closeKeyModal();
  }
  copyAdminToken() {
    return __async(this, null, function* () {
      const encryptedToken = sessionStorage.getItem(`admin_token_${this.roomId()}`);
      const roomKey = this.socket.getRoomKey();
      if (encryptedToken && roomKey) {
        try {
          const plainToken = yield this.encryptionEngine.decrypt(encryptedToken, roomKey);
          if (plainToken) {
            this.doCopy(plainToken, this.adminCopied);
            this.socket.logAction("Admin Token Copied", "Backed up the admin token");
            this.dispatcher.emitDataCopied("admin-token");
          }
        } catch (e) {
          console.error("Failed to decrypt admin token for clipboard", e);
        }
      }
      this.closeAdminModal();
    });
  }
  copyRoomId() {
    if (this.roomId()) {
      this.doCopy(this.roomId(), this.roomIdCopied);
      this.socket.logAction("Room ID Copied", "Copied the room identifier");
      this.dispatcher.emitDataCopied("room-id");
      this.closeRoomIdModal();
    }
  }
  blurStates = signal(
    {
      "transaction-overview": true,
      "transaction-proposal": true,
      "transaction-details": true,
      signers: true
    },
    ...ngDevMode ? [{ debugName: "blurStates" }] : (
      /* istanbul ignore next */
      []
    )
  );
  showPrivacyWarning = signal(
    false,
    ...ngDevMode ? [{ debugName: "showPrivacyWarning" }] : (
      /* istanbul ignore next */
      []
    )
  );
  pendingUnblurSection = signal(
    null,
    ...ngDevMode ? [{ debugName: "pendingUnblurSection" }] : (
      /* istanbul ignore next */
      []
    )
  );
  /**
   * Handles the click of the Eye icon for any section.
   */
  togglePrivacyBlur(section) {
    if (this.blurStates()[section]) {
      this.pendingUnblurSection.set(section);
      this.showPrivacyWarning.set(true);
      this.dispatcher.emitModalView("Toggle Privacy Warning", section);
    } else {
      this.blurStates.update((s) => __spreadProps(__spreadValues({}, s), { [section]: true }));
      this.socket.logAction("Privacy Toggle", `Re-blurred ${section} section`);
      this.dispatcher.emitPrivacyToggle(section, "hidden");
    }
  }
  /**
   * Called when the user clicks "Acknowledge & Reveal" on the modal.
   */
  confirmUnblur() {
    const section = this.pendingUnblurSection();
    if (section) {
      this.blurStates.update((s) => __spreadProps(__spreadValues({}, s), { [section]: false }));
      this.socket.logAction("Privacy Toggle", `Revealed ${section} section`);
      this.dispatcher.emitPrivacyToggle(section, "reveal-section");
    }
    this.showPrivacyWarning.set(false);
    this.pendingUnblurSection.set(null);
  }
  /**
   * Called when the user clicks "Reveal All" on the modal.
   */
  confirmUnblurAll() {
    this.blurStates.set({
      "transaction-overview": false,
      "transaction-proposal": false,
      "transaction-details": false,
      signers: false
    });
    this.socket.logAction("Privacy Toggle", `Revealed all sections`);
    this.dispatcher.emitPrivacyToggle("all", "reveal-all");
    this.showPrivacyWarning.set(false);
    this.pendingUnblurSection.set(null);
  }
  /**
   * Closes the privacy warning modal without revealing.
   */
  closePrivacyWarning() {
    const section = this.pendingUnblurSection();
    if (section) {
      this.dispatcher.emitPrivacyToggle(section, "blurred");
    }
    this.showPrivacyWarning.set(false);
    this.pendingUnblurSection.set(null);
  }
  openFountainModal() {
    this.regenerateFrames();
    this.showFountainModal.set(true);
    this.isFountainRevealed.set(false);
    this.dispatcher.emitModalView("Export PSBT (Air-Gapped)");
  }
  setExportFormat(format) {
    this.exportFormat.set(format);
    this.dispatcher.emitFountainFormatChanged(format);
    if (this.showFountainModal()) {
      this.regenerateFrames();
      if (this.isFountainRevealed()) {
        this.startFountainAnimation();
      }
    }
  }
  regenerateFrames() {
    const psbtData = this.socket.roomState()?.psbt;
    if (!psbtData)
      return;
    try {
      if (this.exportFormat() === "ur") {
        this.activeFountainFrames = this.urService.generateFrames(psbtData);
      } else {
        this.activeFountainFrames = this.urService.generateBBQrFrames(psbtData);
      }
      this.currentFrameIndex.set(0);
    } catch (e) {
      console.error("Failed to prepare frames", e);
    }
  }
  toggleFountainReveal() {
    const nextState = !this.isFountainRevealed();
    this.isFountainRevealed.set(nextState);
    this.dispatcher.emitFountainStateChanged(nextState, this.exportFormat());
    if (nextState) {
      this.socket.logAction("Privacy Toggle", `Revealed ${this.exportFormat().toUpperCase()} PSBT QR`);
      this.startFountainAnimation();
    } else {
      this.socket.logAction("Privacy Toggle", `Blurred ${this.exportFormat().toUpperCase()} PSBT QR`);
      this.stopFountainAnimation();
    }
  }
  startFountainAnimation() {
    if (this.fountainInterval)
      clearInterval(this.fountainInterval);
    this.fountainInterval = setInterval(() => {
      this.currentFrameIndex.update((i) => (i + 1) % this.activeFountainFrames.length);
      this.renderFountainFrame();
    }, this.fountainSpeed());
    setTimeout(() => this.renderFountainFrame(), 0);
  }
  stopFountainAnimation() {
    if (this.fountainInterval)
      clearInterval(this.fountainInterval);
  }
  closeFountainModal() {
    this.showFountainModal.set(false);
    this.isFountainRevealed.set(false);
    this.stopFountainAnimation();
  }
  renderFountainFrame() {
    return __async(this, null, function* () {
      if (!this.isFountainRevealed())
        return;
      const canvas = document.getElementById("fountain-psbt-canvas");
      if (canvas && this.activeFountainFrames.length > 0) {
        const frame = this.activeFountainFrames[this.currentFrameIndex()];
        yield QRCode.toCanvas(canvas, frame, {
          width: 320,
          margin: 2,
          color: { dark: "#000000", light: "#ffffff" }
        });
      }
    });
  }
  startScanner() {
    this.showScannerModal.set(true);
    this.isScanningSigned.set(true);
    this.urService.resetDecoder();
    this.dispatcher.emitModalView("Import PSBT (Scanner)");
    setTimeout(() => __async(this, null, function* () {
      this.html5QrCode = new Html5Qrcode("signer-reader", {
        formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE],
        verbose: false,
        experimentalFeatures: {
          useBarCodeDetectorIfSupported: true
        }
      });
      let frameCount = 0;
      try {
        yield this.html5QrCode.start({ facingMode: "environment" }, {
          fps: 10,
          disableFlip: true,
          qrbox: { width: 350, height: 350 },
          videoConstraints: {
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        }, (decodedText) => this.handleScanResult(decodedText), (errorMessage) => {
          frameCount++;
          if (frameCount % 60 === 0) {
            console.warn(`[Optical Debug] Frame ${frameCount} - Engine failing to lock:`, errorMessage.split("\n")[0]);
          }
        });
      } catch (err) {
        console.warn("High-res camera start failed. Falling back to standard resolution...", err);
        try {
          yield this.html5QrCode.start({ facingMode: "environment" }, { fps: 10, disableFlip: false }, (decodedText) => this.handleScanResult(decodedText), () => {
            console.error("Fallback camera failed to start.");
          });
        } catch (fallbackErr) {
          console.error("Fallback camera start also failed:", fallbackErr);
          this.stopScanner();
        }
      }
    }), 100);
  }
  handleScanResult(decodedText) {
    console.log("Scanned fragment:", decodedText.substring(0, 80) + "...");
    const fullHex = this.urService.processFragment(decodedText);
    if (fullHex) {
      console.log("Full PSBT decoded, length:", fullHex.length);
      this.stopScanner();
      this.processScannedSignature(fullHex);
    }
  }
  stopScanner() {
    if (this.html5QrCode) {
      try {
        if (this.html5QrCode.getState() === 2) {
          this.html5QrCode.stop().then(() => {
            this.html5QrCode?.clear();
            this.isScanningSigned.set(false);
            this.showScannerModal.set(false);
          }).catch(() => {
            this.html5QrCode?.clear();
            this.isScanningSigned.set(false);
            this.showScannerModal.set(false);
          });
        } else {
          this.html5QrCode.clear();
          this.isScanningSigned.set(false);
          this.showScannerModal.set(false);
        }
      } catch (e) {
        this.html5QrCode.clear();
        this.isScanningSigned.set(false);
        this.showScannerModal.set(false);
      }
    } else {
      this.isScanningSigned.set(false);
      this.showScannerModal.set(false);
    }
  }
  processScannedSignature(data) {
    return __async(this, null, function* () {
      try {
        const clean = data.replace(/\s+/g, "");
        const psbtBytes = /^[0-9a-fA-F]+$/.test(clean) ? hex.decode(clean) : base64.decode(clean);
        const normalizedBase64 = base64.encode(psbtBytes);
        yield this.socket.uploadSignature(normalizedBase64);
        console.log("Successfully ingested signed PSBT via optics!");
        this.dispatcher.emitPsbtImported("scan");
      } catch (e) {
        console.error("Failed to parse signed PSBT from scanner", e);
      }
    });
  }
  updateFountainSpeed(newSpeed) {
    this.fountainSpeed.set(Number(newSpeed));
    if (this.isFountainRevealed() && this.showFountainModal()) {
      this.startFountainAnimation();
    }
  }
  static \u0275fac = function RoomComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RoomComponent)(i0.\u0275\u0275directiveInject(i1.ActivatedRoute), i0.\u0275\u0275directiveInject(SocketService), i0.\u0275\u0275directiveInject(i1.Router), i0.\u0275\u0275directiveInject(i3.Title), i0.\u0275\u0275directiveInject(UrService), i0.\u0275\u0275directiveInject(PLATFORM_ID), i0.\u0275\u0275directiveInject(WidgetDispatcherService), i0.\u0275\u0275directiveInject(EncryptionEngine), i0.\u0275\u0275directiveInject(ConfigService));
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _RoomComponent, selectors: [["app-room"]], hostBindings: function RoomComponent_HostBindings(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275listener("beforeunload", function RoomComponent_beforeunload_HostBindingHandler() {
        return ctx.onBeforeUnload();
      }, i0.\u0275\u0275resolveWindow);
    }
  }, features: [i0.\u0275\u0275ProvidersFeature([EncryptionEngine])], decls: 200, vars: 160, consts: [["id", "banner-reconnecting", 1, "w-full", "bg-amber-500/90", "text-brand-bg", "text-center", "text-xs", "font-bold", "py-1.5", "fixed", "top-0", "z-[200]", "flex", "items-center", "justify-center", "gap-2", "animate-pulse"], ["id", "modal-download-psbt", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-download-audit", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-download-csv", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-room-id", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-label-signer", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "animate-fade-in"], ["id", "modal-error-not-found", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/90", "backdrop-blur-xl", "animate-fade-in"], ["id", "modal-error-room-full", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/90", "backdrop-blur-xl", "animate-fade-in"], ["id", "modal-error-access-denied", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/90", "backdrop-blur-xl", "animate-fade-in"], ["id", "modal-decryption-entry", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/95", "backdrop-blur-md", "rounded-3xl", "border", "border-brand-card-border", "animate-fade-in-up"], ["id", "modal-rename-room", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-qr-code", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-share-room", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-view-key", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-backup-admin", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-export-fountain", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-import-scanner", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "p-4", "animate-in", "fade-in", "duration-200"], ["id", "modal-confirm-action", 1, "fixed", "inset-0", "z-[250]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "animate-fade-in"], ["id", "container-room-dashboard", 1, "max-w-7xl", "mx-auto", "px-6", "py-8", "relative", "min-h-[80vh]"], [1, "absolute", "top-0", "left-1/2", "-translate-x-1/2", "w-[800px]", "h-[500px]", "bg-brand-accent/10", "rounded-full", "blur-[120px]", "pointer-events-none"], ["id", "card-room-overview", 1, "bg-brand-card/80", "backdrop-blur-sm", "border", "border-brand-card-border/50", "rounded-xl", "p-6", "mb-8", "relative", "z-10", "shadow-xl", "flex", "flex-col", "gap-6", "overflow-hidden"], [1, "absolute", "top-10", "right-4", "md:top-10", "md:right-6", "opacity-10", "pointer-events-none", "select-none", "mix-blend-plus-lighter"], ["alt", "Brand Watermark", 1, "w-24", "h-24", "md:w-32", "md:h-32", "object-contain", "filter", 3, "src"], [1, "flex", "justify-between", "items-center", "relative", "z-20"], [1, "text-lg", "font-semibold", "text-brand-text", "flex", "items-center", "gap-2"], ["id", "btn-reveal-overview", 1, "p-2", "rounded-lg", "hover:bg-brand-card-border/50", "transition-colors", "flex", "items-center", "gap-2", "cursor-pointer", 3, "click", "title"], ["lucideEyeOff", "", 1, "w-5", "h-5"], ["lucideEye", "", 1, "w-5", "h-5"], [1, "relative", "overflow-hidden", "rounded-lg"], [1, "transition-all", "duration-300", "relative", "z-10", "flex", "flex-col", "gap-6"], [1, "flex", "items-center", "gap-3"], ["title", "Room Expired", 1, "w-3", "h-3", "rounded-full", "bg-rose-600", "shrink-0", "shadow-[0_0_10px_#e11d48]"], ["title", "Room Locked", 1, "w-3", "h-3", "rounded-full", "bg-amber-500", "animate-pulse", "shadow-[0_0_10px_#f59e0b]", "shrink-0"], ["title", "Room Active", 1, "w-3", "h-3", "rounded-full", "bg-brand-accent", "animate-pulse", "shadow-[0_0_10px_var(--wl-accent)]", "shrink-0"], [1, "text-2xl", "font-bold", "text-brand-text", "truncate"], ["id", "btn-edit-room-name", "title", "Rename Room", 1, "p-2", "-ml-1", "rounded-lg", "hover:bg-brand-card-border/50", "text-brand-text-muted", "hover:text-brand-text", "transition", "cursor-pointer"], [1, "flex", "flex-wrap", "items-center", "gap-3", "sm:gap-4", "text-sm", "text-brand-text-muted", "bg-brand-bg", "w-fit", "px-4", "py-2", "rounded-xl", "border", "border-brand-card-border"], [1, "relative", "group"], ["id", "btn-copy-room-id", 1, "flex", "items-center", "gap-2", "hover:bg-brand-card-border/50", "p-1.5", "-m-1.5", "rounded-lg", "transition", "border", "border-transparent", "hover:border-brand-card-border", "cursor-pointer", 3, "click"], ["lucideCheck", "", 1, "w-4", "h-4", "transition-colors", "text-brand-accent"], ["lucideHash", "", 1, "w-4", "h-4", "transition-colors", "text-brand-text-muted"], [1, "font-mono", "transition", "font-bold"], [1, "absolute", "-top-9", "left-1/2", "-translate-x-1/2", "bg-brand-card-border", "text-brand-text", "text-[10px]", "font-bold", "px-2.5", "py-1", "rounded", "opacity-0", "group-hover:opacity-100", "transition", "pointer-events-none", "whitespace-nowrap", "border", "border-brand-card-border", "shadow-xl", "z-[100]"], [1, "w-px", "h-4", "bg-brand-card-border"], [1, "flex", "items-center", "gap-1.5", "cursor-help"], ["lucideNetwork", "", 1, "w-4", "h-4"], [1, "font-bold", "text-xs", "uppercase", "tracking-wide"], [1, "absolute", "-top-10", "left-1/2", "-translate-x-1/2", "bg-brand-card-border", "text-brand-text", "text-[10px]", "font-bold", "px-3", "py-1.5", "rounded", "opacity-0", "group-hover:opacity-100", "transition-opacity", "pointer-events-none", "whitespace-nowrap", "border", "border-brand-card-border", "shadow-xl", "z-[100]"], ["id", "btn-view-sessions", 1, "relative", "group", "cursor-pointer", "hover:bg-brand-card-border/50", "p-1.5", "-m-1.5", "rounded-lg", "transition", "border", "border-transparent", "hover:border-brand-card-border", 3, "click"], [1, "flex", "items-center", "gap-2"], ["lucideUsers", "", 1, "w-4", "h-4"], [1, "font-bold"], [1, "relative", "group", "cursor-help"], ["lucideClock", "", 1, "w-4", "h-4"], [1, "font-bold", "text-xs", "uppercase"], [1, "font-mono", "font-bold"], [1, "absolute", "-top-10", "right-0", "md:left-1/2", "md:-translate-x-1/2", "md:right-auto", "bg-brand-card-border", "text-brand-text", "text-[10px]", "font-bold", "px-3", "py-1.5", "rounded", "opacity-0", "group-hover:opacity-100", "transition-opacity", "pointer-events-none", "whitespace-nowrap", "border", "border-brand-card-border", "shadow-xl", "z-[100]"], [1, "absolute", "inset-0", "flex", "items-center", "justify-center", "z-20"], [1, "pt-4", "border-t", "border-brand-card-border/50", "flex", "flex-col", "items-start", "gap-2", "relative", "z-30"], [1, "text-[10px]", "uppercase", "tracking-widest", "text-brand-text-muted", "font-bold", "ml-1"], [1, "flex", "flex-wrap", "items-center", "p-1.5", "bg-brand-bg", "border", "border-brand-card-border", "rounded-xl", "gap-2", "shadow-sm", "w-full", "sm:w-auto"], ["id", "btn-action-link-key", 1, "px-3", "py-2", "text-cyan-400", "hover:bg-cyan-950/30", "hover:text-cyan-300", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "hover:border-cyan-500/20", "cursor-pointer", 3, "click"], ["lucideCheck", "", 1, "w-4", "h-4"], ["lucideKey", "", 1, "w-4", "h-4"], [1, "hidden", "sm:block", "w-px", "h-6", "bg-brand-card-border", "mx-1"], ["id", "btn-action-share", 1, "px-3", "py-2", "text-brand-text", "hover:bg-brand-card-border", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "hover:border-brand-card-border", "cursor-pointer", 3, "click"], ["lucideCopy", "", 1, "w-4", "h-4"], ["id", "btn-action-qr", 1, "px-3", "py-2", "text-brand-text", "hover:bg-brand-card-border", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "hover:border-brand-card-border", "cursor-pointer", 3, "click"], ["lucideQrCode", "", 1, "w-4", "h-4"], [1, "hidden", "sm:inline"], ["id", "modal-active-sessions", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/80", "backdrop-blur-sm", "animate-fade-in", "p-4"], ["id", "modal-status-closed", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/90", "backdrop-blur-xl", "animate-fade-in"], ["id", "modal-status-expired", 1, "fixed", "inset-0", "z-[200]", "flex", "items-center", "justify-center", "bg-brand-bg/90", "backdrop-blur-xl", "animate-fade-in"], ["id", "modal-opsec-warning", 1, "fixed", "inset-0", "z-[100]", "flex", "items-center", "justify-center", "p-4", "bg-black/80", "backdrop-blur-md", "transition-all"], [1, "grid", "lg:grid-cols-3", "gap-8", "transition-all", "duration-500", "relative", "z-10"], [1, "lg:col-span-2", "space-y-6"], ["id", "card-tx-proposal", 1, "bg-brand-card", "border", "border-brand-card-border", "rounded-xl", "p-6", "relative", "overflow-hidden"], [1, "absolute", "top-10", "right-0", "p-4", "opacity-10", "pointer-events-none"], ["alt", "Brand Watermark", 1, "w-24", "h-24", "object-contain", 3, "src"], [1, "flex", "justify-between", "items-center", "mb-4", "relative", "z-20"], ["id", "btn-reveal-proposal", 1, "p-2", "rounded-lg", "hover:bg-brand-card-border/50", "transition-colors", "flex", "items-center", "gap-2", "cursor-pointer", 3, "click", "title"], [1, "transition-all", "duration-300", "relative", "z-10"], [1, "flex", "justify-between", "items-end"], [1, "text-4xl", "font-bold", "text-brand-text", "mb-1"], [1, "text-brand-text-muted", "text-xl"], [1, "text-brand-accent", "text-sm", "font-mono", "font-medium"], [1, "text-right"], [1, "text-brand-text-muted", "text-sm"], [1, "text-brand-text", "font-mono"], [1, "absolute", "inset-0", "flex", "items-center", "justify-center", "z-10"], ["id", "card-signer-actions", 1, "bg-brand-card", "border", "border-brand-card-border", "rounded-xl", "p-6", "mb-6"], [1, "text-lg", "font-semibold", "text-brand-text", "flex", "items-center", "gap-2", "mb-4"], [1, "grid", "grid-cols-1", "md:grid-cols-2", "gap-6"], [1, "flex", "flex-col", "gap-2"], [1, "text-xs", "text-brand-text-muted", "mb-1"], [1, "grid", "grid-cols-2", "gap-2"], ["id", "btn-export-show-qr", 1, "flex", "items-center", "justify-center", "p-3", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "hover:border-brand-accent/50", "hover:bg-brand-accent/5", "transition-all", "text-sm", "font-medium", "text-brand-text", "group", "cursor-pointer", 3, "click"], ["lucideQrCode", "", 1, "mr-2", "text-brand-text-muted", "group-hover:text-brand-accent", "transition-colors", "w-[18px]", "h-[18px]"], ["id", "btn-export-download-file", 1, "flex", "items-center", "justify-center", "p-3", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "hover:border-purple-500/50", "hover:bg-purple-500/5", "transition-all", "text-sm", "font-medium", "text-brand-text", "group", "cursor-pointer", 3, "click"], ["lucideDownloadCloud", "", 1, "mr-2", "text-brand-text-muted", "group-hover:text-purple-400", "transition-colors", "w-[18px]", "h-[18px]"], ["id", "btn-import-scan-qr", 1, "flex", "items-center", "justify-center", "p-3", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "hover:border-brand-accent/50", "hover:bg-brand-accent/5", "transition-all", "text-sm", "font-medium", "text-brand-text", "group", "disabled:opacity-50", "disabled:cursor-not-allowed", "cursor-pointer", 3, "click", "disabled"], ["id", "btn-import-upload-file", 1, "relative", "group", "cursor-pointer", "flex", "items-center", "justify-center", "p-3", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "hover:border-purple-500/50", "hover:bg-purple-500/5", "transition-all", "text-sm", "font-medium", "text-brand-text", "disabled:opacity-50"], ["type", "file", "accept", ".psbt,.txt,.hex", 1, "absolute", "inset-0", "opacity-0", "cursor-pointer", "z-10", 3, "change", "disabled"], ["lucideUploadCloud", "", 1, "mr-2", "text-brand-text-muted", "group-hover:text-purple-400", "transition-colors", "w-[18px]", "h-[18px]"], [1, "relative", "bg-black", "rounded-xl", "overflow-hidden", "border", "border-brand-accent/30", "mt-6", "shadow-[0_0_15px_var(--wl-accent)]", "animate-in", "fade-in", "slide-in-from-top-4", "duration-300"], ["id", "card-tx-details", 1, "relative", "bg-brand-card", "border", "border-brand-card-border", "rounded-xl", "p-5", "min-h-[400px]", "overflow-hidden"], ["id", "btn-reveal-details", 1, "p-2", "rounded-lg", "hover:bg-brand-card-border/50", "transition-colors", "flex", "items-center", "gap-2", "cursor-pointer", 3, "click", "title"], [1, "transition-all", "duration-300"], [1, "w-full", "flex", "bg-brand-bg", "p-1", "rounded-lg", "border", "border-brand-card-border", "mb-4"], ["id", "btn-tab-inputs", 1, "flex-1", "py-1.5", "text-xs", "font-bold", "rounded-md", "transition-all", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["id", "btn-tab-outputs", 1, "flex-1", "py-1.5", "text-xs", "font-bold", "rounded-md", "transition-all", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], [1, "mb-4", "relative"], [1, "relative", "flex", "items-center"], [1, "flex", "justify-end", "mb-2"], [1, "space-y-3", "flex-grow", "overflow-y-auto", "max-h-[400px]", "pr-2", "custom-scrollbar"], [1, "absolute", "inset-0", "flex", "items-center", "justify-center", "z-10", "mt-10"], [1, "lg:col-span-1"], ["id", "card-signers-list", 1, "bg-brand-card", "border", "border-brand-card-border", "rounded-xl", "p-6", "h-full", "flex", "flex-col", "relative", "overflow-hidden"], ["lucideUsers", "", 1, "w-5", "h-5", "text-brand-text-muted"], [1, "text-brand-text-muted", "text-sm", "font-medium"], ["id", "btn-reveal-signers", 1, "p-2", "rounded-lg", "hover:bg-brand-card-border/50", "transition-colors", "flex", "items-center", "gap-2", "cursor-pointer", 3, "click", "title"], [1, "relative", "flex-grow", "flex", "flex-col"], [1, "transition-all", "duration-300", "flex-grow"], [1, "space-y-4"], [1, "p-4", "rounded-xl", "flex", "items-center", "justify-between", "border", "transition-all", 3, "bg-emerald-500/10", "border-emerald-500/30", "bg-brand-bg", "border-brand-card-border"], [1, "text-center", "p-4", "text-brand-text-muted", "text-sm"], ["id", "card-finalization-status", 1, "mt-8", "pt-6", "border-t", "border-brand-card-border", "relative", "z-20"], [1, "bg-brand-accent/10", "border", "border-brand-accent/30", "rounded-xl", "p-4", "animate-fade-in-up"], ["disabled", "", 1, "w-full", "py-3.5", "bg-brand-card-border", "text-brand-text-muted", "font-bold", "rounded-xl", "border", "border-brand-card-border", "cursor-not-allowed", "flex", "items-center", "justify-center", "gap-2"], [1, "text-center", "p-4"], ["lucideLoader2", "", 1, "w-3", "h-3", "animate-spin"], [1, "bg-brand-card", "border", "border-brand-card-border", "rounded-2xl", "shadow-2xl", "max-w-md", "w-full", "overflow-hidden", "relative"], [1, "p-4", "border-b", "border-brand-card-border", "flex", "items-center", "justify-between"], ["lucideDownloadCloud", "", 1, "w-5", "h-5", "text-brand-accent"], [1, "font-bold", "text-brand-text"], ["id", "btn-modal-close", 1, "text-brand-text-muted", "hover:text-brand-text", "transition", "cursor-pointer", 3, "click"], ["lucideX", "", 1, "w-5", "h-5"], [1, "p-6", "flex", "flex-col", "gap-4"], [1, "w-full", "bg-brand-accent/10", "border", "border-brand-accent/20", "rounded-lg", "p-3", "flex", "items-start", "gap-3"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-brand-accent", "shrink-0", "mt-0.5"], [1, "text-xs", "text-brand-accent", "leading-relaxed"], [1, "text-xs", "text-brand-text-muted", "leading-relaxed"], [1, "flex", "gap-3", "mt-2"], ["id", "btn-cancel-download", 1, "flex-1", "py-2.5", "rounded-lg", "border", "border-brand-card-border", "text-brand-text-muted", "hover:text-brand-text", "hover:bg-brand-card-border/50", "transition", "font-bold", "text-xs", "cursor-pointer", 3, "click"], ["id", "btn-confirm-download", 1, "flex-1", "py-2.5", "bg-brand-accent/20", "hover:bg-brand-accent/30", "text-brand-accent", "text-xs", "font-bold", "rounded-lg", "border", "border-brand-accent/20", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideDownload", "", 1, "w-4", "h-4"], ["lucideFileCheck", "", 1, "w-5", "h-5", "text-brand-accent"], ["lucideDownload", "", 1, "w-5", "h-5", "text-blue-400"], [1, "w-full", "bg-blue-500/10", "border", "border-blue-500/20", "rounded-lg", "p-3", "flex", "items-start", "gap-3"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-blue-400", "shrink-0", "mt-0.5"], [1, "text-xs", "text-blue-200", "leading-relaxed"], ["id", "btn-confirm-download", 1, "flex-1", "py-2.5", "bg-blue-500/20", "hover:bg-blue-500/30", "text-blue-400", "text-xs", "font-bold", "rounded-lg", "border", "border-blue-500/20", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideHash", "", 1, "w-5", "h-5", "text-brand-accent"], ["lucideShield", "", 1, "w-5", "h-5", "text-brand-accent", "shrink-0"], [1, "text-xs", "text-brand-accent/80", "leading-relaxed"], ["id", "btn-copy-room-id-modal", 1, "mt-2", "w-full", "py-2.5", "bg-brand-accent/20", "hover:bg-brand-accent/30", "text-brand-accent", "text-xs", "font-bold", "rounded-lg", "border", "border-brand-accent/20", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], [1, "bg-brand-card", "border", "border-brand-card-border", "p-6", "rounded-2xl", "shadow-2xl", "max-w-sm", "w-full"], [1, "flex", "justify-between", "items-center", "mb-4"], [1, "text-brand-text", "font-bold"], ["id", "btn-modal-close", 1, "text-brand-text-muted", "hover:text-brand-text", "cursor-pointer", 3, "click"], [1, "mb-4"], [1, "text-xs", "text-brand-text-muted", "font-mono", "mb-1"], [1, "text-sm", "text-brand-text", "font-mono", "bg-brand-bg", "p-2", "rounded", "border", "border-brand-card-border"], [1, "block", "text-xs", "font-bold", "text-brand-text-muted", "uppercase", "tracking-wider", "mb-2"], ["type", "text", "placeholder", "e.g. Alice (Ledger)", "autofocus", "", 1, "w-full", "bg-brand-bg", "border", "border-brand-card-border", "text-brand-text", "text-sm", "rounded-xl", "block", "p-3", "outline-none", "focus:border-brand-accent", "transition", 3, "ngModelChange", "keyup.enter", "ngModel"], [1, "mb-6", "flex", "items-center", "gap-3", "cursor-pointer", "select-none", 3, "click"], [1, "w-5", "h-5", "rounded", "border", "flex", "items-center", "justify-center", "transition-colors"], ["lucideCheck", "", 1, "w-3.5", "h-3.5", "text-brand-bg"], [1, "text-sm", "text-brand-text"], [1, "w-full", "py-3", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition", "cursor-pointer", 3, "click"], [1, "bg-brand-card", "border", "border-brand-card-border", "p-8", "rounded-2xl", "shadow-2xl", "max-w-md", "w-full", "text-center"], [1, "w-16", "h-16", "bg-brand-card-border/50", "rounded-full", "flex", "items-center", "justify-center", "mx-auto", "mb-6"], ["lucideAlertOctagon", "", 1, "w-8", "h-8", "text-brand-text-muted"], [1, "text-2xl", "font-bold", "text-brand-text", "mb-2"], [1, "text-brand-text-muted", "mb-8", "text-sm"], ["routerLink", "/create", 1, "w-full", "py-3", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer"], ["lucideZap", "", 1, "w-4", "h-4"], [1, "bg-brand-card", "border", "border-brand-card-border", "p-8", "rounded-2xl", "shadow-2xl", "max-w-md", "w-full", "text-center", "mx-4"], [1, "w-16", "h-16", "bg-amber-500/10", "rounded-full", "flex", "items-center", "justify-center", "mx-auto", "mb-6"], ["lucideUsers", "", 1, "w-8", "h-8", "text-amber-500"], [1, "text-brand-text-muted", "mb-8"], ["routerLink", "/", 1, "w-full", "py-3", "bg-brand-card-border/50", "hover:bg-brand-card-border", "text-brand-text", "font-bold", "rounded-xl", "transition", "flex", "items-center", "justify-center", "gap-2", "border", "border-brand-card-border", "decoration-0", "cursor-pointer"], ["lucideArrowRight", "", 1, "w-4", "h-4", "rotate-180"], [1, "bg-brand-card", "border", "border-rose-900/50", "p-8", "rounded-2xl", "shadow-2xl", "max-w-md", "w-full", "text-center", "relative", "overflow-hidden"], [1, "absolute", "top-0", "left-0", "w-full", "h-1", "bg-gradient-to-r", "from-rose-500", "via-orange-500", "to-rose-500"], [1, "w-16", "h-16", "bg-brand-bg", "rounded-full", "flex", "items-center", "justify-center", "mx-auto", "mb-6", "ring-1", "ring-rose-500/50"], ["lucideLock", "", 1, "w-8", "h-8", "text-rose-500"], [1, "max-w-md", "w-full", "p-8", "text-center"], [1, "w-16", "h-16", "bg-rose-500/10", "rounded-full", "flex", "items-center", "justify-center", "mx-auto", "mb-6", "ring-1", "ring-rose-500/30"], [1, "text-brand-text-muted", "mb-6", "text-sm"], [1, "flex", "gap-2", "mb-4"], ["type", "text", "placeholder", "Enter decryption key...", 1, "w-full", "bg-brand-card", "border", "border-brand-card-border", "text-brand-text", "text-sm", "rounded-lg", "block", "p-2.5", "outline-none", 3, "ngModelChange", "ngModel"], [1, "w-full", "py-3", "bg-rose-500", "hover:bg-rose-400", "disabled:opacity-50", "text-white", "font-bold", "rounded-xl", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click", "disabled"], ["lucideRefreshCw", "", 1, "w-4", "h-4"], ["lucideTag", "", 1, "w-5", "h-5", "text-brand-accent"], [1, "p-6"], [1, "text-sm", "text-brand-text-muted", "mb-4"], [1, "space-y-2"], [1, "flex", "justify-between"], [1, "text-xs", "font-bold", "text-brand-text-muted", "uppercase", "tracking-wider"], [1, "text-xs", "font-mono"], ["type", "text", "maxlength", "64", "placeholder", "e.g. Q1 Treasury Board Vote", "autofocus", "", 1, "w-full", "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "px-4", "py-3", "text-brand-text", "placeholder:text-brand-text-muted", "focus:outline-none", "focus:border-brand-accent/50", "transition", 3, "ngModelChange", "keyup.enter", "ngModel"], [1, "text-xs", "text-red-400", "animate-pulse"], [1, "p-4", "bg-brand-bg/50", "border-t", "border-brand-card-border", "flex", "justify-end", "gap-3"], ["id", "btn-cancel-download", 1, "px-4", "py-2", "rounded-lg", "text-brand-text-muted", "hover:text-brand-text", "hover:bg-brand-card-border/50", "transition", "text-sm", "font-medium", "cursor-pointer", 3, "click"], [1, "px-6", "py-2", "rounded-lg", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "text-sm", "transition", "shadow-lg", "shadow-brand-accent/20", "cursor-pointer", 3, "click"], [1, "bg-brand-card", "border", "border-brand-card-border", "rounded-2xl", "shadow-2xl", "max-w-sm", "w-full", "overflow-hidden", "relative"], ["lucideQrCode", "", 1, "w-5", "h-5", "text-brand-accent"], [1, "p-6", "flex", "flex-col", "items-center"], ["id", "btn-toggle-qr-link-only", 1, "flex-1", "py-1.5", "text-xs", "font-bold", "rounded-md", "transition-all", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideShield", "", 1, "w-3", "h-3"], ["id", "btn-toggle-qr-full", 1, "flex-1", "py-1.5", "text-xs", "font-bold", "rounded-md", "transition-all", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideKey", "", 1, "w-3", "h-3"], [1, "w-full", "bg-amber-500/10", "border", "border-amber-500/20", "rounded-lg", "p-3", "mb-6", "flex", "items-start", "gap-3", "animate-in", "fade-in", "zoom-in-95", "duration-200"], [1, "w-full", "bg-brand-accent/10", "border", "border-brand-accent/20", "rounded-lg", "p-3", "mb-6", "flex", "items-start", "gap-3", "animate-in", "fade-in", "zoom-in-95", "duration-200"], [1, "relative", "group", "cursor-pointer", 3, "click"], [1, "bg-white", "p-2", "rounded-lg", "transition-all", "duration-300"], ["alt", "Room QR Code", 1, "w-48", "h-48", "sm:w-56", "sm:h-56", 3, "src"], [1, "w-48", "h-48", "flex", "items-center", "justify-center"], [1, "absolute", "inset-0", "flex", "flex-col", "items-center", "justify-center", "z-10"], [1, "text-xs", "text-brand-text-muted", "mt-4", "text-center"], [1, "p-4", "bg-brand-bg/50", "border-t", "border-brand-card-border", "flex", "gap-3"], ["id", "btn-download-qr-image", 1, "flex-1", "py-2.5", "rounded-lg", "bg-brand-card-border", "hover:bg-brand-card-border/80", "text-brand-text", "font-medium", "text-sm", "transition", "flex", "items-center", "justify-center", "gap-2", "border", "border-brand-card-border", "cursor-pointer", 3, "click"], [1, "px-4", "py-2.5", "rounded-lg", "bg-brand-card", "hover:bg-brand-card-border", "text-brand-text-muted", "hover:text-brand-text", "font-medium", "text-sm", "transition", "border", "border-transparent", "hover:border-brand-card-border", "cursor-pointer", 3, "click"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-amber-50", "shrink-0"], [1, "text-xs", "text-amber-200/80", "leading-relaxed"], ["lucideLoader2", "", 1, "w-8", "h-8", "text-brand-bg", "animate-spin"], [1, "bg-brand-card/90", "p-3", "rounded-full", "border", "border-brand-card-border", "shadow-xl", "mb-2"], ["lucideEye", "", 1, "w-6", "h-6", "text-brand-text"], [1, "text-xs", "font-bold", "text-brand-bg", "bg-white/90", "px-2", "py-1", "rounded", "shadow-sm"], ["lucideCopy", "", 1, "w-5", "h-5", "text-brand-text"], [1, "border", "border-brand-accent/30", "bg-brand-accent/5", "rounded-xl", "p-4", "relative", "overflow-hidden", "group"], [1, "flex", "justify-between", "items-start", "mb-2", "relative", "z-10"], ["lucideShield", "", 1, "w-4", "h-4", "text-brand-accent"], [1, "text-brand-text", "font-bold", "text-sm"], [1, "text-xs", "text-brand-text-muted", "mt-1", "leading-relaxed"], ["id", "btn-copy-secure-link", 1, "mt-3", "w-full", "py-2.5", "bg-brand-accent/20", "hover:bg-brand-accent/30", "text-brand-accent", "text-xs", "font-bold", "rounded-lg", "border", "border-brand-accent/20", "transition", "flex", "items-center", "justify-center", "gap-2", "relative", "z-10", "cursor-pointer", 3, "click"], [1, "border", "border-brand-card-border", "bg-brand-bg/50", "rounded-xl", "p-4"], [1, "flex", "justify-between", "items-start", "mb-2"], ["lucideAlertTriangle", "", 1, "w-4", "h-4", "text-amber-500"], ["id", "btn-copy-full-link", 1, "mt-3", "w-full", "py-2.5", "bg-brand-card-border/50", "hover:bg-brand-card-border", "text-brand-text", "text-xs", "font-bold", "rounded-lg", "border", "border-brand-card-border", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideKey", "", 1, "w-5", "h-5", "text-cyan-400"], [1, "w-full", "bg-cyan-500/10", "border", "border-cyan-500/20", "rounded-lg", "p-3", "flex", "items-start", "gap-3"], ["lucideAlertTriangle", "", 1, "w-5", "h-5", "text-cyan-400", "shrink-0"], [1, "text-xs", "text-cyan-200", "leading-relaxed"], [1, "mt-2", "w-full", "py-2.5", "bg-cyan-500/20", "hover:bg-cyan-500/30", "text-cyan-400", "text-xs", "font-bold", "rounded-lg", "border", "border-cyan-500/20", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideFileKey", "", 1, "w-5", "h-5", "text-purple-400"], [1, "w-full", "bg-purple-500/10", "border", "border-purple-500/20", "rounded-lg", "p-3", "flex", "items-start", "gap-3"], ["lucideAlertOctagon", "", 1, "w-5", "h-5", "text-purple-400", "shrink-0"], [1, "text-xs", "text-purple-200", "leading-relaxed"], [1, "mt-2", "w-full", "py-2.5", "bg-purple-500/20", "hover:bg-purple-500/30", "text-purple-400", "text-xs", "font-bold", "rounded-lg", "border", "border-purple-500/20", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideShield", "", 1, "w-5", "h-5", "text-brand-accent"], [1, "w-full", "flex", "bg-brand-bg", "p-1", "rounded-lg", "border", "border-brand-card-border", "mb-6"], ["id", "btn-format-ur", 1, "flex-1", "py-1.5", "text-xs", "font-bold", "rounded-md", "transition-all", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["id", "btn-format-bbqr", 1, "flex-1", "py-1.5", "text-xs", "font-bold", "rounded-md", "transition-all", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], [1, "relative", "group", "cursor-pointer", "inline-flex", "flex-col", "items-center", 3, "click"], [1, "bg-white", "p-2", "rounded-xl", "transition-all", "duration-300", "relative"], ["id", "fountain-psbt-canvas", 1, "w-64", "h-64", "sm:w-72", "sm:h-72", "block"], [1, "text-xs", "text-brand-text-muted", "mt-6", "text-center", "max-w-[320px]"], [1, "w-full", "mt-6", "bg-brand-bg", "p-4", "rounded-xl", "border", "border-brand-card-border", "animate-in", "fade-in", "slide-in-from-bottom-2", "duration-300"], ["id", "btn-cancel-download", 1, "px-4", "py-2.5", "rounded-lg", "bg-brand-card", "hover:bg-brand-card-border", "text-brand-text-muted", "hover:text-brand-text", "font-medium", "text-sm", "transition", "border", "border-transparent", "hover:border-brand-card-border", "w-full", "cursor-pointer", 3, "click"], ["lucideShield", "", 1, "w-5", "h-5", "text-amber-500", "shrink-0"], [1, "flex", "justify-between", "items-center", "mb-2"], [1, "text-[10px]", "font-bold", "text-brand-text-muted", "uppercase", "tracking-wider"], [1, "text-xs", "font-mono", "text-brand-accent", "font-bold"], ["type", "range", "min", "100", "max", "1000", "step", "50", 1, "w-full", "h-1.5", "bg-brand-card-border", "rounded-lg", "appearance-none", "cursor-pointer", "accent-brand-accent", "transition-all", "hover:accent-brand-accent-hover", 3, "ngModelChange", "ngModel"], [1, "flex", "justify-between", "text-[9px]", "text-brand-text-muted", "font-bold", "uppercase", "mt-1"], [1, "w-full", "bg-brand-accent/10", "border", "border-brand-accent/20", "rounded-lg", "p-3", "mb-6", "flex", "items-start", "gap-3"], ["lucideShield", "", 1, "w-5", "h-5", "text-brand-accent", "shrink-0", "mt-0.5"], [1, "text-xs", "text-brand-accent/80", "leading-relaxed", "space-y-2"], [1, "text-[11px]", "text-brand-accent/90", "font-medium", "bg-brand-accent/10", "p-2", "rounded", "border", "border-brand-accent/20"], [1, "w-full", "mb-4", "space-y-2"], [1, "bg-brand-bg", "border", "border-brand-card-border", "rounded-lg", "p-2.5", "flex", "items-center", "justify-between"], [1, "text-[10px]", "text-brand-text-muted", "font-bold", "uppercase", "tracking-wider"], [1, "text-[10px]", "text-brand-accent", "font-mono", "truncate", "max-w-[200px]", 3, "title"], [1, "bg-rose-500/10", "border", "border-rose-500/30", "rounded-lg", "p-2.5", "flex", "items-start", "gap-2", "animate-in", "fade-in", "zoom-in-95", "duration-200"], [1, "relative", "bg-black", "w-full", "rounded-xl", "overflow-hidden", "border", "border-brand-accent/30", "shadow-[0_0_15px_var(--wl-accent)]"], ["id", "signer-reader", 1, "w-full", "h-72", "object-cover"], [1, "absolute", "inset-0", "pointer-events-none", "z-10", "flex", "flex-col", "items-center", "justify-center", "overflow-hidden"], [1, "relative", "w-56", "h-56", "rounded-xl", "shadow-[0_0_0_9999px_rgba(var(--wl-bg),0.7)]", "border", "border-brand-accent/30"], [1, "absolute", "top-0", "left-0", "w-6", "h-6", "border-t-2", "border-l-2", "border-brand-accent", "rounded-tl-xl"], [1, "absolute", "top-0", "right-0", "w-6", "h-6", "border-t-2", "border-r-2", "border-brand-accent", "rounded-tr-xl"], [1, "absolute", "bottom-0", "left-0", "w-6", "h-6", "border-b-2", "border-l-2", "border-brand-accent", "rounded-bl-xl"], [1, "absolute", "bottom-0", "right-0", "w-6", "h-6", "border-b-2", "border-r-2", "border-brand-accent", "rounded-br-xl"], [1, "absolute", "left-0", "right-0", "h-[2px]", "bg-brand-accent", "shadow-[0_0_8px_2px_var(--wl-accent)]", "scanner-laser"], [1, "absolute", "bottom-0", "left-0", "right-0", "bg-brand-card/95", "backdrop-blur-sm", "p-3", "border-t", "border-brand-accent/30", "z-20"], ["id", "btn-stop-scanner", 1, "px-4", "py-2.5", "rounded-lg", "bg-brand-card", "hover:bg-brand-card-border", "text-brand-text-muted", "hover:text-brand-text", "font-medium", "text-sm", "transition", "border", "border-transparent", "hover:border-brand-card-border", "w-full", "cursor-pointer", 3, "click"], ["lucideAlertTriangle", "", 1, "w-4", "h-4", "text-rose-400", "shrink-0"], [1, "text-xs", "text-rose-300"], [1, "flex", "justify-between", "text-xs", "text-brand-accent", "font-bold", "mb-2", "tracking-wider"], [1, "w-full", "bg-brand-bg", "rounded-full", "h-1.5", "overflow-hidden"], [1, "bg-brand-accent", "h-1.5", "rounded-full", "transition-all", "duration-200", "ease-out"], [1, "bg-brand-card", "border", "border-brand-card-border", "p-6", "rounded-2xl", "shadow-2xl", "max-w-sm", "w-full", "mx-4", "relative", "overflow-hidden"], [1, "absolute", "top-0", "left-0", "w-full", "h-1"], [1, "text-brand-text", "font-bold", "text-lg", "mb-2"], [1, "text-brand-text-muted", "text-sm", "mb-6", "leading-relaxed", "whitespace-pre-wrap", "break-words"], [1, "grid", "gap-3"], [1, "px-4", "py-2.5", "rounded-xl", "border", "border-brand-card-border", "text-brand-text-muted", "hover:text-brand-text", "hover:bg-brand-card-border/50", "transition", "font-bold", "text-sm", "cursor-pointer"], [1, "px-4", "py-2.5", "rounded-xl", "font-bold", "text-sm", "text-brand-bg", "transition", "shadow-lg", "cursor-pointer", 3, "click"], [1, "px-4", "py-2.5", "rounded-xl", "border", "border-brand-card-border", "text-brand-text-muted", "hover:text-brand-text", "hover:bg-brand-card-border/50", "transition", "font-bold", "text-sm", "cursor-pointer", 3, "click"], ["id", "btn-edit-room-name", "title", "Rename Room", 1, "p-2", "-ml-1", "rounded-lg", "hover:bg-brand-card-border/50", "text-brand-text-muted", "hover:text-brand-text", "transition", "cursor-pointer", 3, "click"], ["lucideEdit2", "", 1, "w-4", "h-4"], [1, "flex", "items-center", "gap-1.5", "text-indigo-400", "cursor-help"], ["lucideCrown", "", 1, "w-4", "h-4"], [1, "bg-brand-card-border/90", "text-brand-text", "hover:bg-brand-card-border", "px-4", "py-1.5", "rounded-full", "text-sm", "font-medium", "flex", "items-center", "gap-2", "border", "border-brand-card-border", "shadow-xl", "backdrop-blur-sm", "transition-colors", "cursor-pointer", 3, "click"], ["lucideEyeOff", "", 1, "w-3.5", "h-3.5"], ["id", "btn-action-audit", 1, "px-3", "py-2", "text-brand-accent", "hover:bg-brand-accent/10", "hover:text-brand-accent-hover", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "hover:border-brand-accent/20", "cursor-pointer", 3, "click"], ["lucideFileCheck", "", 1, "w-4", "h-4"], ["id", "btn-action-csv", 1, "px-3", "py-2", "text-blue-400", "hover:bg-blue-950/30", "hover:text-blue-300", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "hover:border-blue-500/20", "cursor-pointer", 3, "click"], ["id", "btn-action-backup-admin", 1, "px-3", "py-2", "text-purple-400", "hover:bg-purple-950/30", "hover:text-purple-300", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "hover:border-purple-500/20", "cursor-pointer", 3, "click"], ["lucideFileKey", "", 1, "w-4", "h-4"], ["id", "btn-action-lock-room", 1, "px-3", "py-2", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "border", "border-transparent", "cursor-pointer", 3, "click"], ["lucideLock", "", 1, "w-4", "h-4"], ["lucideUnlock", "", 1, "w-4", "h-4"], ["id", "btn-action-close-room", 1, "px-3", "py-2", "bg-rose-950/30", "text-rose-400", "border", "border-rose-900/50", "hover:bg-rose-900/50", "hover:border-rose-500", "hover:text-white", "rounded-lg", "transition", "text-xs", "font-bold", "flex", "items-center", "gap-2", "cursor-pointer", 3, "click"], ["lucidePower", "", 1, "w-4", "h-4"], [1, "bg-brand-card", "border", "border-brand-card-border", "rounded-2xl", "shadow-2xl", "max-w-md", "w-full", "overflow-hidden", "flex", "flex-col", "max-h-[80vh]"], [1, "p-4", "border-b", "border-brand-card-border", "flex", "items-center", "justify-between", "bg-brand-card", "z-10", "shrink-0"], ["lucideUsers", "", 1, "w-5", "h-5", "text-brand-accent"], [1, "p-4", "border-b", "border-brand-card-border", "bg-brand-bg", "shrink-0"], [1, "flex", "gap-2"], ["type", "text", "placeholder", "e.g. Auditor Bob", "maxlength", "32", 1, "w-full", "bg-brand-card", "border", "border-brand-card-border", "text-brand-text", "text-sm", "rounded-lg", "block", "p-2.5", "outline-none", "focus:border-brand-accent", "transition", 3, "ngModelChange", "keyup.enter", "ngModel"], [1, "px-5", "py-2.5", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-lg", "transition", "text-sm", "cursor-pointer", 3, "click"], [1, "text-[10px]", "text-brand-text-muted", "mt-2"], [1, "p-4", "overflow-y-auto", "custom-scrollbar", "flex-grow", "space-y-2"], [1, "flex", "items-center", "justify-between", "p-3", "rounded-xl", "border", "transition-all", 3, "bg-brand-accent_10", "border-brand-accent_30", "bg-brand-bg", "border-brand-card-border"], [1, "text-center", "py-6", "text-brand-text-muted", "text-sm", "flex", "flex-col", "items-center", "gap-2"], [1, "flex", "items-center", "justify-between", "p-3", "rounded-xl", "border", "transition-all"], [1, "flex", "items-center", "gap-3", "overflow-hidden"], [1, "w-10", "h-10", "rounded-full", "flex", "items-center", "justify-center", "shrink-0"], ["lucideCrown", "", 1, "w-5", "h-5", "text-indigo-400"], ["lucideUser", "", 1, "w-5", "h-5", "text-brand-text-muted"], [1, "min-w-0"], [1, "text-brand-text", "font-bold", "text-sm", "truncate"], [1, "text-[9px]", "uppercase", "tracking-wider", "font-bold", "bg-brand-accent/20", "border", "border-brand-accent/20", "text-brand-accent", "px-1.5", "py-0.5", "rounded"], [1, "text-brand-text-muted", "text-[10px]", "font-mono", "mt-0.5"], ["title", "Copy Session Details", 1, "transition", "p-2", "cursor-pointer", 3, "click"], ["lucideCheck", "", 1, "w-3.5", "h-3.5"], ["lucideCopy", "", 1, "w-3.5", "h-3.5"], ["lucideLoader2", "", 1, "w-5", "h-5", "animate-spin"], ["lucidePower", "", 1, "w-8", "h-8", "text-brand-text-muted"], ["routerLink", "/create", 1, "w-full", "py-3", "bg-brand-card-border/50", "hover:bg-brand-card-border", "text-brand-text", "font-bold", "rounded-xl", "transition", "flex", "items-center", "justify-center", "gap-2", "border", "border-brand-card-border", "decoration-0"], [1, "w-16", "h-16", "bg-rose-500/10", "rounded-full", "flex", "items-center", "justify-center", "mx-auto", "mb-6"], ["lucideAlertTriangle", "", 1, "w-8", "h-8", "text-rose-500"], ["routerLink", "/create", 1, "w-full", "py-3", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition", "flex", "items-center", "justify-center", "gap-2", "decoration-0"], [1, "bg-brand-card", "border", "border-amber-500/30", "rounded-xl", "max-w-xl", "w-full", "p-6", "shadow-2xl", "relative", "overflow-hidden"], [1, "absolute", "top-0", "left-0", "w-full", "h-1", "bg-amber-500"], [1, "flex", "items-center", "gap-3", "text-amber-500", "mb-4"], ["lucideEye", "", 1, "w-7", "h-7", "animate-pulse"], [1, "text-xl", "font-bold", "text-brand-text"], [1, "text-brand-text", "mb-6", "leading-relaxed"], [1, "flex", "items-center", "gap-2", "text-sm", "text-brand-text-muted"], ["lucideCheckCircle", "", 1, "w-4", "h-4", "text-brand-accent"], [1, "flex", "items-center", "gap-2", "text-sm", "text-brand-text-muted", "mt-2"], [1, "flex", "flex-wrap", "sm:flex-nowrap", "gap-3", "justify-end", "mt-8"], ["id", "btn-privacy-keep-blurred", 1, "w-full", "sm:w-auto", "px-5", "py-2.5", "rounded-lg", "border", "border-brand-card-border", "text-brand-text", "hover:bg-brand-card-border/50", "transition-colors", "font-medium", "cursor-pointer", 3, "click"], ["id", "btn-privacy-reveal-all", 1, "w-full", "sm:w-auto", "px-5", "py-2.5", "rounded-lg", "bg-amber-500/10", "text-amber-500", "font-bold", "hover:bg-amber-500/20", "border", "border-amber-500/30", "transition-colors", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideEye", "", 1, "w-[18px]", "h-[18px]"], ["id", "btn-privacy-reveal-section", 1, "w-full", "sm:w-auto", "px-5", "py-2.5", "rounded-lg", "bg-amber-500", "text-brand-bg", "font-bold", "hover:bg-amber-400", "transition-colors", "flex", "items-center", "justify-center", "gap-2", "shadow-lg", "shadow-amber-500/20", "cursor-pointer", 3, "click"], [1, "bg-brand-card-border/90", "text-brand-text", "hover:bg-brand-card-border", "px-4", "py-1.5", "rounded-full", "text-sm", "font-medium", "flex", "items-center", "gap-2", "border", "border-brand-card-border", "shadow-xl", "backdrop-blur-sm", "mt-8", "transition-colors", "cursor-pointer", 3, "click"], [1, "absolute", "top-6", "left-1/2", "-translate-x-1/2", "z-20", "bg-brand-bg/80", "border", "border-brand-accent/20", "backdrop-blur-md", "px-4", "py-1.5", "rounded-full", "whitespace-nowrap", "shadow-lg"], [1, "text-xs", "font-medium", "text-brand-accent", "uppercase", "tracking-widest", "flex", "items-center", "gap-2"], [1, "w-2", "h-2", "rounded-full", "bg-brand-accent", "animate-pulse"], [1, "absolute", "bottom-0", "left-0", "right-0", "bg-brand-card/95", "backdrop-blur-sm", "p-3", "border-t", "border-brand-card-border", "z-20"], [1, "absolute", "top-4", "right-4", "z-20", "text-brand-text-muted", "bg-brand-card/80", "hover:text-brand-text", "hover:bg-red-500/90", "p-2.5", "rounded-full", "transition-all", "backdrop-blur-sm", "border", "border-brand-card-border", "hover:border-red-500", "cursor-pointer", 3, "click"], [1, "flex", "justify-between", "text-xs", "text-brand-text-muted", "mb-2"], [1, "w-full", "bg-brand-card-border", "rounded-full", "h-1.5", "overflow-hidden"], ["lucideSearch", "", 1, "w-4", "h-4", "text-brand-text-muted", "absolute", "left-2", "top-1/2", "-translate-y-1/2", "pointer-events-none"], ["type", "text", "placeholder", "Search input address...", 1, "w-full", "bg-brand-bg", "border", "border-brand-card-border", "text-brand-text", "text-xs", "rounded-lg", "block", "py-2.5", "pr-20", "pl-10", "outline-none", "focus:border-brand-accent/50", "transition", 3, "ngModelChange", "ngModel"], ["title", "Filtered Results", 1, "absolute", "right-3", "top-1/2", "-translate-y-1/2", "text-[10px]", "font-mono", "font-bold", "text-brand-text-muted", "bg-brand-card", "px-2", "py-0.5", "rounded", "border", "border-brand-card-border", "pointer-events-none"], ["type", "text", "placeholder", "Search output address...", 1, "w-full", "bg-brand-bg", "border", "border-brand-card-border", "text-brand-text", "text-xs", "rounded-lg", "block", "py-2.5", "pr-20", "pl-10", "outline-none", "focus:border-brand-accent/50", "transition", 3, "ngModelChange", "ngModel"], ["id", "btn-verify-all-inputs", 1, "text-[10px]", "font-bold", "text-emerald-400", "hover:text-emerald-300", "hover:bg-emerald-500/10", "px-2", "py-1", "rounded", "transition", "border", "border-transparent", "hover:border-emerald-500/20", "flex", "items-center", "gap-1", "cursor-pointer"], ["id", "btn-verify-all-outputs", 1, "text-[10px]", "font-bold", "text-emerald-400", "hover:text-emerald-300", "hover:bg-emerald-500/10", "px-2", "py-1", "rounded", "transition", "border", "border-transparent", "hover:border-emerald-500/20", "flex", "items-center", "gap-1", "cursor-pointer"], ["id", "btn-verify-all-inputs", 1, "text-[10px]", "font-bold", "text-emerald-400", "hover:text-emerald-300", "hover:bg-emerald-500/10", "px-2", "py-1", "rounded", "transition", "border", "border-transparent", "hover:border-emerald-500/20", "flex", "items-center", "gap-1", "cursor-pointer", 3, "click"], ["lucideCheckCircle", "", 1, "w-3", "h-3"], ["id", "btn-verify-all-outputs", 1, "text-[10px]", "font-bold", "text-emerald-400", "hover:text-emerald-300", "hover:bg-emerald-500/10", "px-2", "py-1", "rounded", "transition", "border", "border-transparent", "hover:border-emerald-500/20", "flex", "items-center", "gap-1", "cursor-pointer", 3, "click"], [1, "flex", "flex-col", "sm:flex-row", "items-stretch", "bg-brand-bg", "rounded-xl", "border", "transition-all", "overflow-hidden", "address-card", 3, "border-emerald-500", "border-brand-card-border"], [1, "text-center", "py-8", "text-brand-text-muted", "text-sm"], [1, "flex", "flex-col", "sm:flex-row", "items-stretch", "bg-brand-bg", "rounded-xl", "border", "transition-all", "overflow-hidden", "address-card"], [1, "verification-badge", "flex", "sm:flex-col", "items-center", "justify-center", "p-3", "w-full", "sm:w-28", "shrink-0", "border-b", "sm:border-b-0", "sm:border-r", "border-brand-card-border/80", "gap-2", "sm:gap-0"], [1, "flex", "flex-1", "items-center", "justify-between", "p-3", "gap-4"], [1, "flex", "flex-col", "gap-2", "flex-1", "min-w-0"], [1, "text-xs", "text-brand-text", "bg-brand-card", "px-3", "py-1", "rounded", "border", "border-brand-card-border", "font-medium", "shadow-sm"], ["title", "TxID:Vout", 1, "font-mono", "text-[10px]", "text-brand-text-muted", "truncate", "max-w-[120px]"], [1, "flex", "items-center", "justify-between", "bg-brand-card", "border", "border-brand-card-border", "rounded-lg", "pl-3", "pr-3", "py-2", "group"], [1, "font-mono", "text-xs", "text-brand-text-muted", "break-all", "select-all", "mr-2"], [1, "relative", "group/tooltip", "shrink-0", "focus:outline-none", "cursor-pointer", 3, "click"], ["lucideCheck", "", 1, "w-4", "h-4", "transition-all", "duration-300", "text-brand-accent", "scale-110"], ["lucideCopy", "", 1, "w-4", "h-4", "transition-all", "duration-300", "text-brand-text-muted", "group-hover:text-brand-text"], [1, "absolute", "-top-9", "left-1/2", "-translate-x-1/2", "bg-brand-card-border", "text-brand-text", "text-[10px]", "font-bold", "px-2.5", "py-1", "rounded", "opacity-0", "group-hover/tooltip:opacity-100", "transition-opacity", "pointer-events-none", "whitespace-nowrap", "border", "border-brand-card-border", "shadow-xl", "z-[100]"], [1, "flex", "flex-col", "items-end", "justify-between", "gap-3", "shrink-0", "min-w-[130px]"], [1, "text-brand-text", "font-medium", "text-sm", "text-right"], [1, "text-brand-text-muted"], [1, "w-full", "py-1.5", "px-4", "rounded-lg", "transition-all", "text-xs", "font-bold", "text-center", "shadow-sm", "border", "cursor-pointer", 3, "class"], ["lucideShieldCheck", "", 1, "w-5", "h-5", "text-emerald-500", "sm:mb-1.5"], [1, "text-[9px]", "font-bold", "text-emerald-500", "uppercase", "tracking-wider", "text-center"], ["lucideShieldAlert", "", 1, "w-5", "h-5", "text-brand-text-muted", "sm:mb-1.5"], [1, "text-[9px]", "font-bold", "text-brand-text-muted", "uppercase", "tracking-wider", "text-center"], [1, "w-full", "py-1.5", "px-4", "rounded-lg", "transition-all", "text-xs", "font-bold", "text-center", "shadow-sm", "border", "cursor-pointer", 3, "click"], [1, "flex", "flex-col", "sm:flex-row", "items-stretch", "bg-brand-bg", "rounded-xl", "border", "transition-all", "overflow-hidden", "address-card", 3, "border-emerald-500", "border-amber-500", "border-rose-900", "border-brand-card-border"], [1, "text-brand-text-muted", "text-sm", "text-center"], ["lucideShieldOff", "", 1, "w-5", "h-5", "text-amber-500", "sm:mb-1.5"], [1, "text-[9px]", "font-bold", "text-amber-500", "uppercase", "tracking-wider", "text-center"], ["lucideShieldAlert", "", 1, "w-5", "h-5", "text-rose-500", "sm:mb-1.5"], [1, "text-[9px]", "font-bold", "text-rose-500", "uppercase", "tracking-wider", "text-center"], [1, "p-4", "rounded-xl", "flex", "items-center", "justify-between", "border", "transition-all"], [1, "w-10", "h-10", "rounded-full", "flex", "items-center", "justify-center"], ["lucideCheckCircle", "", 1, "w-5", "h-5"], ["lucideUser", "", 1, "w-5", "h-5"], [1, "text-sm", "font-mono", "flex", "items-center", "gap-2", "hover:bg-brand-card-border/50", "-ml-1", "px-1", "py-0.5", "rounded", "transition", "group/label", "text-left", "cursor-pointer"], [1, "text-brand-text", "font-medium", "text-sm", "font-mono"], [1, "text-xs", "font-medium"], ["title", "Copy Nudge Message", 1, "p-1", "text-brand-text-muted", "hover:text-amber-400", "transition", "cursor-pointer"], ["lucideLoader2", "", 1, "w-4", "h-4", "text-brand-text-muted", "animate-spin"], [1, "text-sm", "font-mono", "flex", "items-center", "gap-2", "hover:bg-brand-card-border/50", "-ml-1", "px-1", "py-0.5", "rounded", "transition", "group/label", "text-left", "cursor-pointer", 3, "click"], [1, "text-brand-text-muted", "text-xs"], ["lucideEdit2", "", 1, "w-3", "h-3", "text-brand-text-muted", "group-hover/label:text-brand-accent", "opacity-0", "group-hover/label:opacity-100", "transition"], [1, "text-brand-accent/90", "italic"], ["lucideTag", "", 1, "w-3", "h-3", "text-brand-accent/50", "group-hover/label:text-brand-accent"], ["title", "Copy Nudge Message", 1, "p-1", "text-brand-text-muted", "hover:text-amber-400", "transition", "cursor-pointer", 3, "click"], ["lucideBell", "", 1, "w-3", "h-3"], [1, "bg-brand-card-border/90", "text-brand-text", "hover:bg-brand-card-border", "px-4", "py-1.5", "rounded-full", "text-sm", "font-medium", "flex", "items-center", "gap-2", "border", "border-brand-card-border", "shadow-xl", "backdrop-blur-sm", "-mt-10", "transition-colors", "cursor-pointer", 3, "click"], [1, "flex", "items-center", "gap-3", "mb-4"], [1, "w-10", "h-10", "rounded-full", "bg-brand-accent", "flex", "items-center", "justify-center", "text-brand-bg", "shadow-lg", "shadow-brand-accent/20"], ["lucideShield", "", 1, "w-5", "h-5"], [1, "text-brand-accent", "text-xs"], [1, "grid", "gap-3", 3, "grid-cols-2", "grid-cols-1"], ["id", "btn-copy-final-hex", 1, "py-2", "px-3", "bg-brand-card-border/50", "hover:bg-brand-card-border", "text-brand-text", "text-xs", "font-bold", "rounded-lg", "border", "border-brand-card-border", "transition", "flex", "items-center", "justify-center", "gap-2", "cursor-pointer", 3, "click"], ["lucideCheck", "", 1, "w-3", "h-3"], ["lucideCopy", "", 1, "w-3", "h-3"], ["id", "btn-broadcast-transaction", 1, "py-2", "px-3", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "text-xs", "font-bold", "rounded-lg", "transition", "flex", "items-center", "justify-center", "gap-2", "text-center", "decoration-0", "cursor-pointer"], ["id", "btn-broadcast-transaction", 1, "py-2", "px-3", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "text-xs", "font-bold", "rounded-lg", "transition", "flex", "items-center", "justify-center", "gap-2", "text-center", "decoration-0", "cursor-pointer", 3, "click"], ["lucideExternalLink", "", 1, "w-3", "h-3"], ["id", "btn-finalize-transaction", 1, "w-full", "py-3.5", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition-all", "flex", "items-center", "justify-center", "gap-2", "shadow-lg", "shadow-brand-accent/20", "cursor-pointer"], [1, "text-xs", "text-center", "text-brand-text-muted"], ["id", "btn-finalize-transaction", 1, "w-full", "py-3.5", "bg-brand-accent", "hover:bg-brand-accent-hover", "text-brand-bg", "font-bold", "rounded-xl", "transition-all", "flex", "items-center", "justify-center", "gap-2", "shadow-lg", "shadow-brand-accent/20", "cursor-pointer", 3, "click"], ["lucideShield", "", 1, "w-4", "h-4"], ["lucideLoader2", "", 1, "w-4", "h-4", "animate-spin"], [1, "text-sm", "text-brand-text-muted", "font-medium", "mb-1"], [1, "text-xs", "text-brand-text-muted", "mb-4"], ["id", "btn-claim-coordinator", 1, "text-xs", "text-brand-text-muted", "hover:text-brand-accent", "underline", "transition", "cursor-pointer"], [1, "flex", "gap-2", "justify-center", "mt-2", "animate-fade-in-up"], ["id", "btn-claim-coordinator", 1, "text-xs", "text-brand-text-muted", "hover:text-brand-accent", "underline", "transition", "cursor-pointer", 3, "click"], ["type", "password", "placeholder", "Paste Admin Key here...", 1, "bg-brand-bg", "border", "border-brand-card-border", "rounded", "px-2", "py-1", "text-xs", "text-brand-text", "focus:border-brand-accent", "outline-none", "w-48", "font-mono", 3, "ngModelChange", "ngModel"], [1, "px-3", "py-1", "bg-brand-accent/20", "text-brand-accent", "text-xs", "rounded", "hover:bg-brand-accent/30", "transition", "border", "border-brand-accent/20", "cursor-pointer", 3, "click"]], template: function RoomComponent_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275conditionalCreate(0, RoomComponent_Conditional_0_Template, 3, 0, "div", 0);
      i0.\u0275\u0275conditionalCreate(1, RoomComponent_Conditional_1_Template, 24, 0, "div", 1);
      i0.\u0275\u0275conditionalCreate(2, RoomComponent_Conditional_2_Template, 24, 0, "div", 2);
      i0.\u0275\u0275conditionalCreate(3, RoomComponent_Conditional_3_Template, 24, 0, "div", 3);
      i0.\u0275\u0275conditionalCreate(4, RoomComponent_Conditional_4_Template, 25, 2, "div", 4);
      i0.\u0275\u0275conditionalCreate(5, RoomComponent_Conditional_5_Template, 23, 9, "div", 5);
      i0.\u0275\u0275conditionalCreate(6, RoomComponent_Conditional_6_Template, 11, 1, "div", 6)(7, RoomComponent_Conditional_7_Template, 9, 1, "div", 7)(8, RoomComponent_Conditional_8_Template, 12, 1, "div", 8)(9, RoomComponent_Conditional_9_Template, 13, 2, "div", 9);
      i0.\u0275\u0275conditionalCreate(10, RoomComponent_Conditional_10_Template, 25, 7, "div", 10);
      i0.\u0275\u0275conditionalCreate(11, RoomComponent_Conditional_11_Template, 32, 19, "div", 11);
      i0.\u0275\u0275conditionalCreate(12, RoomComponent_Conditional_12_Template, 45, 4, "div", 12);
      i0.\u0275\u0275conditionalCreate(13, RoomComponent_Conditional_13_Template, 22, 2, "div", 13);
      i0.\u0275\u0275conditionalCreate(14, RoomComponent_Conditional_14_Template, 22, 2, "div", 14);
      i0.\u0275\u0275conditionalCreate(15, RoomComponent_Conditional_15_Template, 27, 19, "div", 15);
      i0.\u0275\u0275conditionalCreate(16, RoomComponent_Conditional_16_Template, 42, 5, "div", 16);
      i0.\u0275\u0275conditionalCreate(17, RoomComponent_Conditional_17_Template, 11, 22, "div", 17);
      i0.\u0275\u0275elementStart(18, "div", 18);
      i0.\u0275\u0275element(19, "div", 19);
      i0.\u0275\u0275elementStart(20, "div", 20)(21, "div", 21);
      i0.\u0275\u0275element(22, "img", 22);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(23, "div", 23)(24, "h2", 24);
      i0.\u0275\u0275text(25, " Room Overview ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(26, "button", 25);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_26_listener() {
        return ctx.togglePrivacyBlur("transaction-overview");
      });
      i0.\u0275\u0275conditionalCreate(27, RoomComponent_Conditional_27_Template, 1, 0, ":svg:svg", 26)(28, RoomComponent_Conditional_28_Template, 1, 0, ":svg:svg", 27);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(29, "div", 28)(30, "div", 29)(31, "div", 30);
      i0.\u0275\u0275conditionalCreate(32, RoomComponent_Conditional_32_Template, 1, 0, "span", 31)(33, RoomComponent_Conditional_33_Template, 1, 0, "span", 32)(34, RoomComponent_Conditional_34_Template, 1, 0, "span", 33);
      i0.\u0275\u0275elementStart(35, "h1", 34);
      i0.\u0275\u0275text(36);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(37, RoomComponent_Conditional_37_Template, 2, 0, "button", 35);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(38, "div", 36)(39, "div", 37)(40, "button", 38);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_40_listener() {
        return ctx.openRoomIdModal();
      });
      i0.\u0275\u0275conditionalCreate(41, RoomComponent_Conditional_41_Template, 1, 0, ":svg:svg", 39)(42, RoomComponent_Conditional_42_Template, 1, 0, ":svg:svg", 40);
      i0.\u0275\u0275elementStart(43, "span", 41);
      i0.\u0275\u0275text(44);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(45, "div", 42);
      i0.\u0275\u0275text(46);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(47, "div", 43);
      i0.\u0275\u0275elementStart(48, "div", 37)(49, "div", 44);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(50, "svg", 45);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(51, "span", 46);
      i0.\u0275\u0275text(52);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(53, "div", 47);
      i0.\u0275\u0275text(54);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275conditionalCreate(55, RoomComponent_Conditional_55_Template, 8, 0);
      i0.\u0275\u0275element(56, "div", 43);
      i0.\u0275\u0275elementStart(57, "div", 37)(58, "button", 48);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_58_listener() {
        return ctx.openSessionsModal();
      });
      i0.\u0275\u0275elementStart(59, "div", 49);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(60, "svg", 50);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(61, "span", 51);
      i0.\u0275\u0275text(62);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(63, "div", 47);
      i0.\u0275\u0275text(64, " View Active Sessions ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(65, "div", 43);
      i0.\u0275\u0275elementStart(66, "div", 52)(67, "div", 49);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(68, "svg", 53);
      i0.\u0275\u0275conditionalCreate(69, RoomComponent_Conditional_69_Template, 2, 0, "span", 54)(70, RoomComponent_Conditional_70_Template, 2, 1, "span", 55);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(71, "div", 56);
      i0.\u0275\u0275text(72, " Room auto-expires & securely wipes data ");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275conditionalCreate(73, RoomComponent_Conditional_73_Template, 4, 0, "div", 57);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(74, "div", 58)(75, "div", 59);
      i0.\u0275\u0275text(76, "Room Actions");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(77, "div", 60);
      i0.\u0275\u0275conditionalCreate(78, RoomComponent_Conditional_78_Template, 10, 0);
      i0.\u0275\u0275elementStart(79, "div", 37)(80, "button", 61);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_80_listener() {
        return ctx.openKeyModal();
      });
      i0.\u0275\u0275conditionalCreate(81, RoomComponent_Conditional_81_Template, 1, 0, ":svg:svg", 62)(82, RoomComponent_Conditional_82_Template, 1, 0, ":svg:svg", 63);
      i0.\u0275\u0275text(83);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275element(84, "div", 64);
      i0.\u0275\u0275conditionalCreate(85, RoomComponent_Conditional_85_Template, 6, 2);
      i0.\u0275\u0275elementStart(86, "div", 37)(87, "button", 65);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_87_listener() {
        return ctx.openShareModal();
      });
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(88, "svg", 66);
      i0.\u0275\u0275text(89, " Share Link ");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275element(90, "div", 64);
      i0.\u0275\u0275elementStart(91, "div", 37)(92, "button", 67);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_92_listener() {
        return ctx.openQr();
      });
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(93, "svg", 68);
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(94, "span", 69);
      i0.\u0275\u0275text(95, "QR Code");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275conditionalCreate(96, RoomComponent_Conditional_96_Template, 6, 10);
      i0.\u0275\u0275conditionalCreate(97, RoomComponent_Conditional_97_Template, 5, 0);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275conditionalCreate(98, RoomComponent_Conditional_98_Template, 22, 2, "div", 70);
      i0.\u0275\u0275conditionalCreate(99, RoomComponent_Conditional_99_Template, 10, 2, "div", 71);
      i0.\u0275\u0275conditionalCreate(100, RoomComponent_Conditional_100_Template, 9, 1, "div", 72);
      i0.\u0275\u0275conditionalCreate(101, RoomComponent_Conditional_101_Template, 29, 0, "div", 73);
      i0.\u0275\u0275elementStart(102, "div", 74)(103, "div", 75)(104, "div", 76)(105, "div", 77);
      i0.\u0275\u0275element(106, "img", 78);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(107, "div", 79)(108, "h2", 24);
      i0.\u0275\u0275text(109, " Transaction Proposal ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(110, "button", 80);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_110_listener() {
        return ctx.togglePrivacyBlur("transaction-proposal");
      });
      i0.\u0275\u0275conditionalCreate(111, RoomComponent_Conditional_111_Template, 1, 0, ":svg:svg", 26)(112, RoomComponent_Conditional_112_Template, 1, 0, ":svg:svg", 27);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(113, "div", 81)(114, "div", 82)(115, "div")(116, "div", 83);
      i0.\u0275\u0275text(117);
      i0.\u0275\u0275pipe(118, "number");
      i0.\u0275\u0275elementStart(119, "span", 84);
      i0.\u0275\u0275text(120, "BTC");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(121, "div", 85);
      i0.\u0275\u0275text(122);
      i0.\u0275\u0275pipe(123, "number");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(124, "div", 86)(125, "div", 87);
      i0.\u0275\u0275text(126, "Network Fee");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(127, "div", 88);
      i0.\u0275\u0275text(128);
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275conditionalCreate(129, RoomComponent_Conditional_129_Template, 4, 0, "div", 89);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(130, "div", 90)(131, "h2", 91);
      i0.\u0275\u0275text(132, "Signer Actions");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(133, "div", 92)(134, "div", 93)(135, "div", 94);
      i0.\u0275\u0275text(136, "1. Export Unsigned Transaction");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(137, "div", 95)(138, "button", 96);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_138_listener() {
        return ctx.openFountainModal();
      });
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(139, "svg", 97);
      i0.\u0275\u0275text(140, " Show QR ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(141, "button", 98);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_141_listener() {
        return ctx.promptPsbtDownload();
      });
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(142, "svg", 99);
      i0.\u0275\u0275text(143, " Download File ");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(144, "div", 93)(145, "div", 94);
      i0.\u0275\u0275text(146, "2. Import Signed Transaction");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(147, "div", 95)(148, "button", 100);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_148_listener() {
        return ctx.startScanner();
      });
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(149, "svg", 97);
      i0.\u0275\u0275text(150, " Scan QR ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(151, "label", 101)(152, "input", 102);
      i0.\u0275\u0275listener("change", function RoomComponent_Template_input_change_152_listener($event) {
        return ctx.onFileSelected($event);
      });
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(153, "svg", 103);
      i0.\u0275\u0275text(154, " Upload File ");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275conditionalCreate(155, RoomComponent_Conditional_155_Template, 16, 1, "div", 104);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(156, "div", 105)(157, "div", 79)(158, "h2", 24);
      i0.\u0275\u0275text(159, " Transaction Details ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(160, "button", 106);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_160_listener() {
        return ctx.togglePrivacyBlur("transaction-details");
      });
      i0.\u0275\u0275conditionalCreate(161, RoomComponent_Conditional_161_Template, 1, 0, ":svg:svg", 26)(162, RoomComponent_Conditional_162_Template, 1, 0, ":svg:svg", 27);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(163, "div", 107)(164, "div", 108)(165, "button", 109);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_165_listener() {
        return ctx.setViewMode("inputs");
      });
      i0.\u0275\u0275text(166);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(167, "button", 110);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_167_listener() {
        return ctx.setViewMode("outputs");
      });
      i0.\u0275\u0275text(168);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(169, "div", 111);
      i0.\u0275\u0275conditionalCreate(170, RoomComponent_Conditional_170_Template, 5, 2, "div", 112)(171, RoomComponent_Conditional_171_Template, 5, 2, "div", 112);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(172, RoomComponent_Conditional_172_Template, 3, 2, "div", 113);
      i0.\u0275\u0275elementStart(173, "div", 114);
      i0.\u0275\u0275conditionalCreate(174, RoomComponent_Conditional_174_Template, 4, 1);
      i0.\u0275\u0275conditionalCreate(175, RoomComponent_Conditional_175_Template, 4, 1);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275conditionalCreate(176, RoomComponent_Conditional_176_Template, 4, 0, "div", 115);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(177, "div", 116)(178, "div", 117)(179, "div", 79)(180, "h2", 24);
      i0.\u0275\u0275namespaceSVG();
      i0.\u0275\u0275element(181, "svg", 118);
      i0.\u0275\u0275text(182, " Signers ");
      i0.\u0275\u0275namespaceHTML();
      i0.\u0275\u0275elementStart(183, "span", 119);
      i0.\u0275\u0275text(184);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(185, "button", 120);
      i0.\u0275\u0275listener("click", function RoomComponent_Template_button_click_185_listener() {
        return ctx.togglePrivacyBlur("signers");
      });
      i0.\u0275\u0275conditionalCreate(186, RoomComponent_Conditional_186_Template, 1, 0, ":svg:svg", 26)(187, RoomComponent_Conditional_187_Template, 1, 0, ":svg:svg", 27);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(188, "div", 121)(189, "div", 122)(190, "div", 123);
      i0.\u0275\u0275repeaterCreate(191, RoomComponent_For_192_Template, 15, 25, "div", 124, _forTrack0);
      i0.\u0275\u0275conditionalCreate(193, RoomComponent_Conditional_193_Template, 2, 0, "div", 125);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275conditionalCreate(194, RoomComponent_Conditional_194_Template, 4, 0, "div", 89);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(195, "div", 126);
      i0.\u0275\u0275conditionalCreate(196, RoomComponent_Conditional_196_Template, 10, 2, "div", 127)(197, RoomComponent_Conditional_197_Template, 2, 1)(198, RoomComponent_Conditional_198_Template, 4, 2, "button", 128)(199, RoomComponent_Conditional_199_Template, 7, 2, "div", 129);
      i0.\u0275\u0275elementEnd()()()()();
    }
    if (rf & 2) {
      i0.\u0275\u0275conditional(ctx.socket.status() !== "connected" && !ctx.socket.isClosed() && !ctx.isExpired() && !ctx.socket.roomNotFound() && !ctx.socket.isLockedOut() && !ctx.socket.isRoomFull() && !ctx.socket.decryptionError() ? 0 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showPsbtModal() ? 1 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showAuditModal() ? 2 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showCsvModal() ? 3 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showRoomIdModal() ? 4 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showLabelModal() ? 5 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.socket.roomNotFound() ? 6 : ctx.socket.isRoomFull() ? 7 : ctx.socket.isLockedOut() ? 8 : ctx.socket.decryptionError() ? 9 : -1);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275conditional(ctx.showRenameModal() ? 10 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showQrModal() ? 11 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showShareModal() ? 12 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showKeyModal() ? 13 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showAdminModal() ? 14 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showFountainModal() ? 15 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showScannerModal() ? 16 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showConfirmModal() ? 17 : -1);
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275property("src", ctx.configService.config().logoUrl, i0.\u0275\u0275sanitizeUrl);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275classProp("text-amber-500", !ctx.blurStates()["transaction-overview"])("text-brand-text-muted", ctx.blurStates()["transaction-overview"]);
      i0.\u0275\u0275property("title", ctx.blurStates()["transaction-overview"] ? "Reveal Header" : "Hide Header");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates()["transaction-overview"] ? 27 : 28);
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275classProp("blur-md", ctx.blurStates()["transaction-overview"])("opacity-30", ctx.blurStates()["transaction-overview"])("select-none", ctx.blurStates()["transaction-overview"])("pointer-events-none", ctx.blurStates()["transaction-overview"]);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.isExpired() ? 32 : ctx.socket.roomState()?.isLocked ? 33 : 34);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275textInterpolate1(" ", ctx.socket.roomState()?.roomName || ctx.configService.config().defaultRoomName, " ");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.socket.isCoordinator() ? 37 : -1);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275conditional(ctx.roomIdCopied() ? 41 : 42);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275classProp("text-brand-accent", ctx.roomIdCopied())("text-brand-text", !ctx.roomIdCopied())("hover:text-brand-text-muted", !ctx.roomIdCopied());
      i0.\u0275\u0275advance();
      i0.\u0275\u0275textInterpolate1(" ", ctx.roomId(), " ");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate1(" ", ctx.roomIdCopied() ? "Copied!" : "View Room ID", " ");
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275classProp("text-brand-accent", !ctx.socket.roomState()?.network || ctx.socket.roomState()?.network === "bitcoin")("text-amber-500", ctx.socket.roomState()?.network === "testnet")("text-purple-400", ctx.socket.roomState()?.network === "signet");
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275textInterpolate1(" ", ctx.socket.roomState()?.network === "bitcoin" ? "Mainnet" : ctx.socket.roomState()?.network || "Mainnet", " ");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate1(" ", !ctx.socket.roomState()?.network || ctx.socket.roomState()?.network === "bitcoin" ? "Real Bitcoin Network (Exercise Caution)" : "Test Network (No real value)", " ");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.socket.isCoordinator() ? 55 : -1);
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275classProp("text-brand-accent", (ctx.socket.roomState()?.connectedCount || 0) > 1)("text-brand-text-muted", (ctx.socket.roomState()?.connectedCount || 0) <= 1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275classProp("text-brand-text", (ctx.socket.roomState()?.connectedCount || 0) > 1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275textInterpolate1(" ", ctx.socket.roomState()?.connectedCount || 1, " ");
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275classProp("text-rose-400", ctx.isLowTime() || ctx.isExpired())("text-brand-text-muted", !ctx.isLowTime() && !ctx.isExpired());
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.isExpired() ? 69 : 70);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275conditional(ctx.blurStates()["transaction-overview"] ? 73 : -1);
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275conditional(!ctx.isExpired() && !ctx.socket.isClosed() ? 78 : -1);
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275conditional(ctx.keyCopied() ? 81 : 82);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate1(" ", ctx.keyCopied() ? "Copied" : "Link Key", " ");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.socket.isCoordinator() ? 85 : -1);
      i0.\u0275\u0275advance(11);
      i0.\u0275\u0275conditional(ctx.socket.isCoordinator() ? 96 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.socket.isCoordinator() && !ctx.isExpired() && !ctx.socket.isClosed() ? 97 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showSessionsModal() ? 98 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.socket.isClosed() ? 99 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.isExpired() && !ctx.socket.isClosed() ? 100 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.showPrivacyWarning() ? 101 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275classProp("opacity-20", ctx.isExpired() || ctx.socket.isClosed())("pointer-events-none", ctx.isExpired() || ctx.socket.isClosed());
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275property("src", ctx.configService.config().logoUrl, i0.\u0275\u0275sanitizeUrl);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275classProp("text-amber-500", !ctx.blurStates()["transaction-proposal"])("text-brand-text-muted", ctx.blurStates()["transaction-proposal"]);
      i0.\u0275\u0275property("title", ctx.blurStates()["transaction-proposal"] ? "Reveal Proposal" : "Hide Proposal");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates()["transaction-proposal"] ? 111 : 112);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275classProp("blur-md", ctx.blurStates()["transaction-proposal"])("opacity-30", ctx.blurStates()["transaction-proposal"])("select-none", ctx.blurStates()["transaction-proposal"])("pointer-events-none", ctx.blurStates()["transaction-proposal"]);
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275textInterpolate1("", i0.\u0275\u0275pipeBind2(118, 155, (ctx.socket.txDetails()?.amount || 0) / 1e8, "1.8-8"), " ");
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275textInterpolate1(" ", i0.\u0275\u0275pipeBind1(123, 158, ctx.socket.txDetails()?.amount || 0), " sats ");
      i0.\u0275\u0275advance(6);
      i0.\u0275\u0275textInterpolate1("", ctx.socket.txDetails()?.feeRate ?? "--", " sats/vB");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates()["transaction-proposal"] ? 129 : -1);
      i0.\u0275\u0275advance(19);
      i0.\u0275\u0275property("disabled", ctx.isScanningSigned());
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275property("disabled", ctx.isScanningSigned());
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275conditional(ctx.isScanningSigned() ? 155 : -1);
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275classProp("text-amber-500", !ctx.blurStates()["transaction-details"])("text-brand-text-muted", ctx.blurStates()["transaction-details"]);
      i0.\u0275\u0275property("title", ctx.blurStates()["transaction-details"] ? "Reveal Details" : "Hide Details");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates()["transaction-details"] ? 161 : 162);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275classProp("blur-md", ctx.blurStates()["transaction-details"])("opacity-30", ctx.blurStates()["transaction-details"])("select-none", ctx.blurStates()["transaction-details"])("pointer-events-none", ctx.blurStates()["transaction-details"]);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275classProp("bg-brand-accent", ctx.viewMode() === "inputs")("text-brand-bg", ctx.viewMode() === "inputs")("text-brand-text-muted", ctx.viewMode() !== "inputs")("hover:text-brand-text", ctx.viewMode() !== "inputs");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275textInterpolate1(" Inputs (", ctx.socket.txDetails()?.inputs || 0, ") ");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275classProp("bg-brand-accent", ctx.viewMode() === "outputs")("text-brand-bg", ctx.viewMode() === "outputs")("text-brand-text-muted", ctx.viewMode() !== "outputs")("hover:text-brand-text", ctx.viewMode() !== "outputs");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275textInterpolate1(" Outputs (", ctx.socket.txDetails()?.outputs?.length || 0, ") ");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.viewMode() === "inputs" ? 170 : 171);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.socket.isCoordinator() ? 172 : -1);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.viewMode() === "inputs" ? 174 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.viewMode() === "outputs" ? 175 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates()["transaction-details"] ? 176 : -1);
      i0.\u0275\u0275advance(8);
      i0.\u0275\u0275textInterpolate1("(", ctx.socket.signerCount(), " Signed)");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275classProp("text-amber-500", !ctx.blurStates().signers)("text-brand-text-muted", ctx.blurStates().signers);
      i0.\u0275\u0275property("title", ctx.blurStates().signers ? "Reveal Signers" : "Hide Signers");
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates().signers ? 186 : 187);
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275classProp("blur-md", ctx.blurStates().signers)("opacity-30", ctx.blurStates().signers)("select-none", ctx.blurStates().signers)("pointer-events-none", ctx.blurStates().signers);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275repeater(ctx.socket.signers());
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.socket.signers().length === 0 ? 193 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.blurStates().signers ? 194 : -1);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.finalHex() ? 196 : ctx.socket.isReadyToBroadcast() ? 197 : ctx.socket.isCoordinator() ? 198 : 199);
    }
  }, dependencies: [
    CommonModule,
    i8.NgClass,
    i8.NgComponentOutlet,
    i8.NgForOf,
    i8.NgIf,
    i8.NgTemplateOutlet,
    i8.NgStyle,
    i8.NgSwitch,
    i8.NgSwitchCase,
    i8.NgSwitchDefault,
    i8.NgPlural,
    i8.NgPluralCase,
    FormsModule,
    i9.\u0275NgNoValidate,
    i9.NgSelectOption,
    i9.\u0275NgSelectMultipleOption,
    i9.DefaultValueAccessor,
    i9.NumberValueAccessor,
    i9.RangeValueAccessor,
    i9.CheckboxControlValueAccessor,
    i9.SelectControlValueAccessor,
    i9.SelectMultipleControlValueAccessor,
    i9.RadioControlValueAccessor,
    i9.NgControlStatus,
    i9.NgControlStatusGroup,
    i9.RequiredValidator,
    i9.MinLengthValidator,
    i9.MaxLengthValidator,
    i9.PatternValidator,
    i9.CheckboxRequiredValidator,
    i9.EmailValidator,
    i9.MinValidator,
    i9.MaxValidator,
    i9.NgModel,
    i9.NgModelGroup,
    i9.NgForm,
    RouterModule,
    i1.RouterOutlet,
    i1.RouterLink,
    i1.RouterLinkActive,
    i1.\u0275EmptyOutletComponent,
    LucideShield,
    LucideUsers,
    LucideCheckCircle,
    LucideLoader2,
    LucideCopy,
    LucideClock,
    LucideArrowRight,
    LucideHash,
    LucideCrown,
    LucideUploadCloud,
    LucideDownloadCloud,
    LucideDownload,
    LucideExternalLink,
    LucideCheck,
    LucideZap,
    LucideAlertTriangle,
    LucidePower,
    LucideX,
    LucideLock,
    LucideUnlock,
    LucideKey,
    LucideRefreshCw,
    LucideAlertOctagon,
    LucideFileKey,
    LucideFileCheck,
    LucideEdit2,
    LucideTag,
    LucideBell,
    LucideQrCode,
    LucideEye,
    LucideEyeOff,
    LucideSearch,
    LucideNetwork,
    LucideShieldAlert,
    LucideShieldCheck,
    LucideShieldOff,
    LucideUser,
    i8.AsyncPipe,
    i8.UpperCasePipe,
    i8.LowerCasePipe,
    i8.JsonPipe,
    i8.SlicePipe,
    i8.DecimalPipe,
    i8.PercentPipe,
    i8.TitleCasePipe,
    i8.CurrencyPipe,
    i8.DatePipe,
    i8.I18nPluralPipe,
    i8.I18nSelectPipe,
    i8.KeyValuePipe
  ], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(RoomComponent, [{
    type: Component,
    args: [{ selector: "app-room", standalone: true, imports: [
      CommonModule,
      FormsModule,
      RouterModule,
      LucideShield,
      LucideUsers,
      LucideCheckCircle,
      LucideLoader2,
      LucideCopy,
      LucideClock,
      LucideArrowRight,
      LucideHash,
      LucideCrown,
      LucideUploadCloud,
      LucideDownloadCloud,
      LucideDownload,
      LucideExternalLink,
      LucideCheck,
      LucideZap,
      LucideAlertTriangle,
      LucidePower,
      LucideX,
      LucideLock,
      LucideUnlock,
      LucideKey,
      LucideRefreshCw,
      LucideAlertOctagon,
      LucideFileKey,
      LucideFileCheck,
      LucideEdit2,
      LucideTag,
      LucideBell,
      LucideQrCode,
      LucideEye,
      LucideEyeOff,
      LucideSearch,
      LucideNetwork,
      LucideShieldAlert,
      LucideShieldCheck,
      LucideShieldOff,
      LucideUser
    ], providers: [EncryptionEngine], template: `@if (socket.status() !== 'connected' && !socket.isClosed() && !isExpired() && !socket.roomNotFound() && !socket.isLockedOut() && !socket.isRoomFull() && !socket.decryptionError()) {\r
    <div id="banner-reconnecting" class="w-full bg-amber-500/90 text-brand-bg text-center text-xs font-bold py-1.5 fixed top-0 z-[200] flex items-center justify-center gap-2 animate-pulse">\r
        <svg lucideLoader2 class="w-3 h-3 animate-spin"></svg>\r
        Connection lost... Reconnecting...\r
    </div>\r
}\r
\r
@if (showPsbtModal()) {\r
<div id="modal-download-psbt" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideDownloadCloud class="w-5 h-5 text-brand-accent"></svg>\r
                <h3 class="font-bold text-brand-text">Download Unsigned PSBT</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="showPsbtModal.set(false)" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
        <div class="p-6 flex flex-col gap-4">\r
            <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 flex items-start gap-3">\r
                <svg lucideAlertTriangle class="w-5 h-5 text-brand-accent shrink-0 mt-0.5"></svg>\r
                <p class="text-xs text-brand-accent leading-relaxed">\r
                    <strong>Privacy Warning:</strong> This file contains unencrypted metadata about your wallet balances, UTXOs, and destination addresses. \r
                </p>\r
            </div>\r
            <p class="text-xs text-brand-text-muted leading-relaxed">\r
                You are downloading this to transfer to a Coldcard or air-gapped hardware wallet. Because this file is plaintext, please ensure it is securely handled, archived, or wiped after use according to your security procedures.\r
            </p>\r
            <div class="flex gap-3 mt-2">\r
                <button id="btn-cancel-download" (click)="showPsbtModal.set(false)" class="flex-1 py-2.5 rounded-lg border border-brand-card-border text-brand-text-muted hover:text-brand-text hover:bg-brand-card-border/50 transition font-bold text-xs cursor-pointer">\r
                    Cancel\r
                </button>\r
                <button id="btn-confirm-download" (click)="executePsbtDownload()" class="flex-1 py-2.5 bg-brand-accent/20 hover:bg-brand-accent/30 text-brand-accent text-xs font-bold rounded-lg border border-brand-accent/20 transition flex items-center justify-center gap-2 cursor-pointer">\r
                    <svg lucideDownload class="w-4 h-4"></svg>\r
                    Download PSBT\r
                </button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
@if (showAuditModal()) {\r
<div id="modal-download-audit" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideFileCheck class="w-5 h-5 text-brand-accent"></svg>\r
                <h3 class="font-bold text-brand-text">Download Audit Log</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="showAuditModal.set(false)" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
        <div class="p-6 flex flex-col gap-4">\r
            <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 flex items-start gap-3">\r
                <svg lucideAlertTriangle class="w-5 h-5 text-brand-accent shrink-0 mt-0.5"></svg>\r
                <p class="text-xs text-brand-accent leading-relaxed">\r
                    <strong>Confidential Data:</strong> This PDF contains a complete, unencrypted record of the ceremony, including transaction details, participant identities, and action timestamps.\r
                </p>\r
            </div>\r
            <p class="text-xs text-brand-text-muted leading-relaxed">\r
                Please ensure it is stored securely and only shared with authorized participants or trusted third parties.\r
            </p>\r
            <div class="flex gap-3 mt-2">\r
                <button id="btn-cancel-download" (click)="showAuditModal.set(false)" class="flex-1 py-2.5 rounded-lg border border-brand-card-border text-brand-text-muted hover:text-brand-text hover:bg-brand-card-border/50 transition font-bold text-xs cursor-pointer">\r
                    Cancel\r
                </button>\r
                <button id="btn-confirm-download" (click)="executeAuditDownload()" class="flex-1 py-2.5 bg-brand-accent/20 hover:bg-brand-accent/30 text-brand-accent text-xs font-bold rounded-lg border border-brand-accent/20 transition flex items-center justify-center gap-2 cursor-pointer">\r
                    <svg lucideDownload class="w-4 h-4"></svg>\r
                    Download PDF\r
                </button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
@if (showCsvModal()) {\r
<div id="modal-download-csv" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideDownload class="w-5 h-5 text-blue-400"></svg>\r
                <h3 class="font-bold text-brand-text">Download CSV Data</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="showCsvModal.set(false)" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
        <div class="p-6 flex flex-col gap-4">\r
            <div class="w-full bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 flex items-start gap-3">\r
                <svg lucideAlertTriangle class="w-5 h-5 text-blue-400 shrink-0 mt-0.5"></svg>\r
                <p class="text-xs text-blue-200 leading-relaxed">\r
                    <strong>Confidential Data:</strong> This spreadsheet contains unencrypted settlement data and participant metadata.\r
                </p>\r
            </div>\r
            <p class="text-xs text-brand-text-muted leading-relaxed">\r
                Please ensure it is stored securely and only shared with authorized participants or trusted third parties.\r
            </p>\r
            <div class="flex gap-3 mt-2">\r
                <button id="btn-cancel-download" (click)="showCsvModal.set(false)" class="flex-1 py-2.5 rounded-lg border border-brand-card-border text-brand-text-muted hover:text-brand-text hover:bg-brand-card-border/50 transition font-bold text-xs cursor-pointer">\r
                    Cancel\r
                </button>\r
                <button id="btn-confirm-download" (click)="executeCsvDownload()" class="flex-1 py-2.5 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 text-xs font-bold rounded-lg border border-blue-500/20 transition flex items-center justify-center gap-2 cursor-pointer">\r
                    <svg lucideDownload class="w-4 h-4"></svg>\r
                    Download CSV\r
                </button>\r
            </div>\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
@if (showRoomIdModal()) {\r
    <div id="modal-room-id" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
        <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
            <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
                <div class="flex items-center gap-2">\r
                    <svg lucideHash class="w-5 h-5 text-brand-accent"></svg>\r
                    <h3 class="font-bold text-brand-text">Room Identifier</h3>\r
                </div>\r
                <button id="btn-modal-close" (click)="closeRoomIdModal()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                    <svg lucideX class="w-5 h-5"></svg>\r
                </button>\r
            </div>\r
            <div class="p-6 flex flex-col gap-4">\r
                <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 flex items-start gap-3">\r
                    <svg lucideShield class="w-5 h-5 text-brand-accent shrink-0"></svg>\r
                    <p class="text-xs text-brand-accent/80 leading-relaxed">\r
                        <strong>Public Routing Data:</strong> This ID directs signers to the correct room, but it <em>cannot</em> decrypt the transaction data without the private Decryption Key.\r
                    </p>\r
                </div>\r
                <p class="text-xs text-brand-text-muted leading-relaxed">\r
                    If you are practicing strict Operational Security (OpSec), send this Room ID to your signers first. Send the Decryption Key later via a separate, secure channel (e.g., Signal vs Email).\r
                </p>\r
                <button id="btn-copy-room-id-modal" (click)="copyRoomId()" class="mt-2 w-full py-2.5 bg-brand-accent/20 hover:bg-brand-accent/30 text-brand-accent text-xs font-bold rounded-lg border border-brand-accent/20 transition flex items-center justify-center gap-2 cursor-pointer">\r
                    @if (roomIdCopied()) {\r
                        <svg lucideCheck class="w-4 h-4"></svg>\r
                    } @else {\r
                        <svg lucideCopy class="w-4 h-4"></svg>\r
                    }\r
                    {{ roomIdCopied() ? 'Room ID Copied!' : 'Copy Room ID' }}\r
                </button>\r
            </div>\r
        </div>\r
    </div>\r
}\r
\r
@if (showLabelModal()) {\r
<div id="modal-label-signer" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm animate-fade-in">\r
    <div class="bg-brand-card border border-brand-card-border p-6 rounded-2xl shadow-2xl max-w-sm w-full">\r
        <div class="flex justify-between items-center mb-4">\r
            <h3 class="text-brand-text font-bold">Label Signer</h3>\r
            <button id="btn-modal-close" (click)="closeLabelModal()" class="text-brand-text-muted hover:text-brand-text cursor-pointer"><svg lucideX class="w-5 h-5"></svg></button>\r
        </div>\r
        \r
        <div class="mb-4">\r
            <div class="text-xs text-brand-text-muted font-mono mb-1">Fingerprint</div>\r
            <div class="text-sm text-brand-text font-mono bg-brand-bg p-2 rounded border border-brand-card-border">\r
                {{ editingFingerprint() }}\r
            </div>\r
        </div>\r
\r
        <div class="mb-4">\r
            <label class="block text-xs font-bold text-brand-text-muted uppercase tracking-wider mb-2">Label Name</label>\r
            <input type="text" [ngModel]="editingLabel()" (ngModelChange)="editingLabel.set($event)" (keyup.enter)="saveLabel()" \r
                placeholder="e.g. Alice (Ledger)" autofocus\r
                class="w-full bg-brand-bg border border-brand-card-border text-brand-text text-sm rounded-xl block p-3 outline-none focus:border-brand-accent transition"/>\r
        </div>\r
\r
        <div class="mb-6 flex items-center gap-3 cursor-pointer select-none" (click)="saveToBook.set(!saveToBook())">\r
            <div class="w-5 h-5 rounded border flex items-center justify-center transition-colors"\r
                    [class.bg-brand-accent]="saveToBook()"\r
                    [class.border-brand-accent]="saveToBook()"\r
                    [class.border-brand-card-border]="!saveToBook()">\r
                @if (saveToBook()) { <svg lucideCheck class="w-3.5 h-3.5 text-brand-bg"></svg> }\r
            </div>\r
            <div class="text-sm text-brand-text">Save to Address Book</div>\r
        </div>\r
\r
        <button (click)="saveLabel()" class="w-full py-3 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition cursor-pointer">\r
            Save Label\r
        </button>\r
    </div>\r
</div>\r
}\r
\r
@if (socket.roomNotFound()) {\r
<div id="modal-error-not-found" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/90 backdrop-blur-xl animate-fade-in">\r
    <div class="bg-brand-card border border-brand-card-border p-8 rounded-2xl shadow-2xl max-w-md w-full text-center">\r
        <div class="w-16 h-16 bg-brand-card-border/50 rounded-full flex items-center justify-center mx-auto mb-6">\r
            <svg lucideAlertOctagon class="w-8 h-8 text-brand-text-muted"></svg>\r
        </div>\r
        <h2 class="text-2xl font-bold text-brand-text mb-2">Room Not Found</h2>\r
        <p class="text-brand-text-muted mb-8 text-sm">\r
            This room does not exist or has expired.<br>\r
            Please check the URL or create a new signing session.\r
        </p>\r
        @if (!isEmbedded) {\r
            <a routerLink="/create" class="w-full py-3 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer">\r
                <svg lucideZap class="w-4 h-4"></svg> Create New Room\r
            </a>\r
        }\r
    </div>\r
</div>\r
} \r
@else if (socket.isRoomFull()) {\r
    <div id="modal-error-room-full" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/90 backdrop-blur-xl animate-fade-in">\r
        <div class="bg-brand-card border border-brand-card-border p-8 rounded-2xl shadow-2xl max-w-md w-full text-center mx-4">\r
            <div class="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center mx-auto mb-6">\r
                <svg lucideUsers class="w-8 h-8 text-amber-500"></svg>\r
            </div>\r
            <h2 class="text-2xl font-bold text-brand-text mb-2">Room Full</h2>\r
            <p class="text-brand-text-muted mb-8">This room has reached its maximum connection limit.</p>\r
            @if (!isEmbedded) {\r
                <a routerLink="/" class="w-full py-3 bg-brand-card-border/50 hover:bg-brand-card-border text-brand-text font-bold rounded-xl transition flex items-center justify-center gap-2 border border-brand-card-border decoration-0 cursor-pointer">\r
                    <svg lucideArrowRight class="w-4 h-4 rotate-180"></svg> Return Home\r
                </a>\r
            }\r
        </div>\r
    </div>\r
}\r
@else if (socket.isLockedOut()) {\r
<div id="modal-error-access-denied" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/90 backdrop-blur-xl animate-fade-in">\r
    <div class="bg-brand-card border border-rose-900/50 p-8 rounded-2xl shadow-2xl max-w-md w-full text-center relative overflow-hidden">\r
        <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500 via-orange-500 to-rose-500"></div>\r
        <div class="w-16 h-16 bg-brand-bg rounded-full flex items-center justify-center mx-auto mb-6 ring-1 ring-rose-500/50">\r
            <svg lucideLock class="w-8 h-8 text-rose-500"></svg>\r
        </div>\r
        <h2 class="text-2xl font-bold text-brand-text mb-2">Access Denied</h2>\r
        <p class="text-brand-text-muted mb-8 text-sm">\r
            The Coordinator has locked this room.<br>\r
            No new guests can join the session at this time.\r
        </p>\r
        @if (!isEmbedded) {\r
            <a routerLink="/" class="w-full py-3 bg-brand-card-border/50 hover:bg-brand-card-border text-brand-text font-bold rounded-xl transition flex items-center justify-center gap-2 border border-brand-card-border decoration-0 cursor-pointer">\r
                <svg lucideArrowRight class="w-4 h-4 rotate-180"></svg> Return Home\r
            </a>\r
        }\r
    </div>\r
</div>\r
}\r
@else if (socket.decryptionError()) {\r
<div id="modal-decryption-entry" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/95 backdrop-blur-md rounded-3xl border border-brand-card-border animate-fade-in-up">\r
    <div class="max-w-md w-full p-8 text-center">\r
        <div class="w-16 h-16 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-6 ring-1 ring-rose-500/30">\r
            <svg lucideLock class="w-8 h-8 text-rose-500"></svg>\r
        </div>\r
        <h2 class="text-2xl font-bold text-brand-text mb-2">Decryption Key Required</h2>\r
        <p class="text-brand-text-muted mb-6 text-sm">Your link is missing the private decryption key. Please enter it below to join the room.</p>\r
        <div class="flex gap-2 mb-4">\r
            <input type="text" [(ngModel)]="manualKey" placeholder="Enter decryption key..." class="w-full bg-brand-card border border-brand-card-border text-brand-text text-sm rounded-lg block p-2.5 outline-none"/>\r
        </div>\r
        <button (click)="submitKey()" [disabled]="!manualKey" class="w-full py-3 bg-rose-500 hover:bg-rose-400 disabled:opacity-50 text-white font-bold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer">\r
            <svg lucideRefreshCw class="w-4 h-4"></svg> Decrypt Room\r
        </button>\r
    </div>\r
</div>\r
}\r
\r
@if (showRenameModal()) {\r
<div id="modal-rename-room" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        \r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideTag class="w-5 h-5 text-brand-accent"></svg>\r
                <h3 class="font-bold text-brand-text">Rename Room</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="closeRenameModal()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
\r
        <div class="p-6">\r
            <p class="text-sm text-brand-text-muted mb-4">\r
                Give this room a label to make it easier to identify. This name is visible to all participants.\r
            </p>\r
\r
            <div class="space-y-2">\r
                <div class="flex justify-between">\r
                    <label class="text-xs font-bold text-brand-text-muted uppercase tracking-wider">Room Name</label>\r
                    <span class="text-xs font-mono" \r
                        [class.text-red-400]="newRoomName().length > 64" \r
                        [class.text-brand-text-muted]="newRoomName().length <= 64">\r
                        {{ newRoomName().length }} / 64\r
                    </span>\r
                </div>\r
                \r
                <input type="text" [ngModel]="newRoomName()" (ngModelChange)="newRoomName.set($event)" (keyup.enter)="saveRoomName()"\r
                    maxlength="64" placeholder="e.g. Q1 Treasury Board Vote"\r
                    class="w-full bg-brand-bg border border-brand-card-border rounded-lg px-4 py-3 text-brand-text placeholder:text-brand-text-muted focus:outline-none focus:border-brand-accent/50 transition" autofocus />\r
                \r
                @if (newRoomName().length >= 64) {\r
                    <p class="text-xs text-red-400 animate-pulse">\r
                        Maximum length reached.\r
                    </p>\r
                }\r
            </div>\r
        </div>\r
\r
        <div class="p-4 bg-brand-bg/50 border-t border-brand-card-border flex justify-end gap-3">\r
            <button id="btn-cancel-download" (click)="closeRenameModal()" class="px-4 py-2 rounded-lg text-brand-text-muted hover:text-brand-text hover:bg-brand-card-border/50 transition text-sm font-medium cursor-pointer">\r
                Cancel\r
            </button>\r
            <button (click)="saveRoomName()" class="px-6 py-2 rounded-lg bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold text-sm transition shadow-lg shadow-brand-accent/20 cursor-pointer">\r
                Save Name\r
            </button>\r
        </div>\r
\r
    </div>\r
</div>\r
}\r
\r
@if (showQrModal()) {\r
<div id="modal-qr-code" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-sm w-full overflow-hidden relative">\r
        \r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideQrCode class="w-5 h-5 text-brand-accent"></svg>\r
                <h3 class="font-bold text-brand-text">Room QR Code</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="closeQr()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
\r
        <div class="p-6 flex flex-col items-center">\r
            \r
            <div class="w-full flex bg-brand-bg p-1 rounded-lg border border-brand-card-border mb-4">\r
                <button id="btn-toggle-qr-link-only" (click)="toggleQrKey(false)" \r
                        class="flex-1 py-1.5 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-2 cursor-pointer"\r
                        [class.bg-brand-card-border]="!qrIncludesKey()"\r
                        [class.text-brand-accent]="!qrIncludesKey()"\r
                        [class.text-brand-text-muted]="qrIncludesKey()">\r
                    <svg lucideShield class="w-3 h-3"></svg>\r
                    Link Only\r
                </button>\r
                <button id="btn-toggle-qr-full" (click)="toggleQrKey(true)" \r
                        class="flex-1 py-1.5 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-2 cursor-pointer"\r
                        [class.bg-brand-card-border]="qrIncludesKey()"\r
                        [class.text-amber-400]="qrIncludesKey()"\r
                        [class.text-brand-text-muted]="!qrIncludesKey()">\r
                    <svg lucideKey class="w-3 h-3"></svg>\r
                    Full (Link + Key)\r
                </button>\r
            </div>\r
\r
            @if (qrIncludesKey()) {\r
                <div class="w-full bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 mb-6 flex items-start gap-3 animate-in fade-in zoom-in-95 duration-200">\r
                    <svg lucideAlertTriangle class="w-5 h-5 text-amber-50 shrink-0"></svg>\r
                    <p class="text-xs text-amber-200/80 leading-relaxed">\r
                        <strong>Contains Decryption Key:</strong> Anyone who scans this can join the room and view data. Treat it like a password.\r
                    </p>\r
                </div>\r
            } @else {\r
                <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 mb-6 flex items-start gap-3 animate-in fade-in zoom-in-95 duration-200">\r
                    <svg lucideShield class="w-5 h-5 text-brand-accent shrink-0"></svg>\r
                    <p class="text-xs text-brand-accent/80 leading-relaxed">\r
                        <strong>Maximum Security:</strong> Key is excluded. You must send the <em>Link Key</em> via a separate secure channel.\r
                    </p>\r
                </div>\r
            }\r
\r
            <div class="relative group cursor-pointer" (click)="toggleQrReveal()">\r
                \r
                <div class="bg-white p-2 rounded-lg transition-all duration-300"\r
                        [class.blur-md]="!isQrRevealed()"\r
                        [class.opacity-50]="!isQrRevealed()">\r
                    @if (qrDataUrl()) {\r
                        <img [src]="qrDataUrl()" alt="Room QR Code" class="w-48 h-48 sm:w-56 sm:h-56">\r
                    } @else {\r
                        <div class="w-48 h-48 flex items-center justify-center">\r
                            <svg lucideLoader2 class="w-8 h-8 text-brand-bg animate-spin"></svg>\r
                        </div>\r
                    }\r
                </div>\r
\r
                @if (!isQrRevealed()) {\r
                    <div class="absolute inset-0 flex flex-col items-center justify-center z-10">\r
                        <div class="bg-brand-card/90 p-3 rounded-full border border-brand-card-border shadow-xl mb-2">\r
                            <svg lucideEye class="w-6 h-6 text-brand-text"></svg>\r
                        </div>\r
                        <span class="text-xs font-bold text-brand-bg bg-white/90 px-2 py-1 rounded shadow-sm">Click to Reveal</span>\r
                    </div>\r
                }\r
            </div>\r
\r
            <p class="text-xs text-brand-text-muted mt-4 text-center">\r
                Scan with a mobile wallet or camera to join.\r
            </p>\r
\r
        </div>\r
\r
        <div class="p-4 bg-brand-bg/50 border-t border-brand-card-border flex gap-3">\r
            <button id="btn-download-qr-image" (click)="downloadQr()" class="flex-1 py-2.5 rounded-lg bg-brand-card-border hover:bg-brand-card-border/80 text-brand-text font-medium text-sm transition flex items-center justify-center gap-2 border border-brand-card-border cursor-pointer">\r
                <svg lucideDownload class="w-4 h-4"></svg>\r
                Download Image\r
            </button>\r
            <button (click)="closeQr()" class="px-4 py-2.5 rounded-lg bg-brand-card hover:bg-brand-card-border text-brand-text-muted hover:text-brand-text font-medium text-sm transition border border-transparent hover:border-brand-card-border cursor-pointer">\r
                Close\r
            </button>\r
        </div>\r
\r
    </div>\r
</div>\r
}\r
\r
@if (showShareModal()) {\r
<div id="modal-share-room" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
\r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideCopy class="w-5 h-5 text-brand-text"></svg>\r
                <h3 class="font-bold text-brand-text">Share Room Securely</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="closeShareModal()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
\r
        <div class="p-6 flex flex-col gap-4">\r
            \r
            <div class="border border-brand-accent/30 bg-brand-accent/5 rounded-xl p-4 relative overflow-hidden group">\r
                <div class="flex justify-between items-start mb-2 relative z-10">\r
                    <div>\r
                        <div class="flex items-center gap-2">\r
                            <svg lucideShield class="w-4 h-4 text-brand-accent"></svg>\r
                            <h4 class="text-brand-text font-bold text-sm">Maximum Security (Split)</h4>\r
                        </div>\r
                        <p class="text-xs text-brand-text-muted mt-1 leading-relaxed">\r
                            Copies the room URL <strong>without</strong> the decryption key. Send this link, then use the <em>"Link Key"</em> action to send the key via a separate, secure channel (e.g., Signal vs Email).\r
                        </p>\r
                    </div>\r
                </div>\r
                <button id="btn-copy-secure-link" (click)="copySecureLink()" class="mt-3 w-full py-2.5 bg-brand-accent/20 hover:bg-brand-accent/30 text-brand-accent text-xs font-bold rounded-lg border border-brand-accent/20 transition flex items-center justify-center gap-2 relative z-10 cursor-pointer">\r
                    @if (secureLinkCopied()) {\r
                        <svg lucideCheck class="w-4 h-4"></svg>\r
                    } @else {\r
                        <svg lucideCopy class="w-4 h-4"></svg>\r
                    }\r
                    {{ secureLinkCopied() ? 'Secure Link Copied!' : 'Copy Link Only (No Key)' }}\r
                </button>\r
            </div>\r
\r
            <div class="border border-brand-card-border bg-brand-bg/50 rounded-xl p-4">\r
                <div class="flex justify-between items-start mb-2">\r
                    <div>\r
                        <div class="flex items-center gap-2">\r
                            <svg lucideAlertTriangle class="w-4 h-4 text-amber-500"></svg>\r
                            <h4 class="text-brand-text font-bold text-sm">Standard (Combined)</h4>\r
                        </div>\r
                        <p class="text-xs text-brand-text-muted mt-1 leading-relaxed">\r
                            Copies the full URL including the decryption key (<code>#key</code>). Convenient for quick sharing, but if this single link is intercepted, the room is compromised.\r
                        </p>\r
                    </div>\r
                </div>\r
                <button id="btn-copy-full-link" (click)="copyFullLink()" class="mt-3 w-full py-2.5 bg-brand-card-border/50 hover:bg-brand-card-border text-brand-text text-xs font-bold rounded-lg border border-brand-card-border transition flex items-center justify-center gap-2 cursor-pointer">\r
                    @if (fullLinkCopied()) {\r
                        <svg lucideCheck class="w-4 h-4"></svg>\r
                    } @else {\r
                        <svg lucideCopy class="w-4 h-4"></svg>\r
                    }\r
                    {{ fullLinkCopied() ? 'Full Link Copied!' : 'Copy Full Link (Link + Key)' }}\r
                </button>\r
            </div>\r
\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
@if (showKeyModal()) {\r
<div id="modal-view-key" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideKey class="w-5 h-5 text-cyan-400"></svg>\r
                <h3 class="font-bold text-brand-text">Room Decryption Key</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="closeKeyModal()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
        <div class="p-6 flex flex-col gap-4">\r
            <div class="w-full bg-cyan-500/10 border border-cyan-500/20 rounded-lg p-3 flex items-start gap-3">\r
                <svg lucideAlertTriangle class="w-5 h-5 text-cyan-400 shrink-0"></svg>\r
                <p class="text-xs text-cyan-200 leading-relaxed">\r
                    <strong>Sensitive Data:</strong> This is the private encryption key for the room. Anyone with this key can decrypt and view the transaction details if they also have the room link.\r
                </p>\r
            </div>\r
            <p class="text-xs text-brand-text-muted leading-relaxed">\r
                For maximum operational security, send this key to signers using a different communication channel than the one used for the room link (e.g., Signal vs. Email).\r
            </p>\r
            <button (click)="copyKey()" class="mt-2 w-full py-2.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 text-xs font-bold rounded-lg border border-cyan-500/20 transition flex items-center justify-center gap-2 cursor-pointer">\r
                @if (keyCopied()) {\r
                    <svg lucideCheck class="w-4 h-4"></svg>\r
                } @else {\r
                    <svg lucideCopy class="w-4 h-4"></svg>\r
                }\r
                {{ keyCopied() ? 'Key Copied!' : 'Copy Decryption Key' }}\r
            </button>\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
@if (showAdminModal()) {\r
<div id="modal-backup-admin" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideFileKey class="w-5 h-5 text-purple-400"></svg>\r
                <h3 class="font-bold text-brand-text">Backup Admin Token</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="closeAdminModal()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
        <div class="p-6 flex flex-col gap-4">\r
            <div class="w-full bg-purple-500/10 border border-purple-500/20 rounded-lg p-3 flex items-start gap-3">\r
                <svg lucideAlertOctagon class="w-5 h-5 text-purple-400 shrink-0"></svg>\r
                <p class="text-xs text-purple-200 leading-relaxed">\r
                    <strong>High Privilege:</strong> This token allows any guest in the room to claim the "Coordinator" role.\r
                </p>\r
            </div>\r
            <p class="text-xs text-brand-text-muted leading-relaxed">\r
                Coordinators have the authority to manage whitelists, lock the room, verify inputs, and broadcast the final transaction. Only share this with trusted co-administrators.\r
            </p>\r
            <button (click)="copyAdminToken()" class="mt-2 w-full py-2.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 text-xs font-bold rounded-lg border border-purple-500/20 transition flex items-center justify-center gap-2 cursor-pointer">\r
                @if (adminCopied()) {\r
                    <svg lucideCheck class="w-4 h-4"></svg>\r
                } @else {\r
                    <svg lucideCopy class="w-4 h-4"></svg>\r
                }\r
                {{ adminCopied() ? 'Admin Token Copied!' : 'Copy Admin Token' }}\r
            </button>\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
@if (showFountainModal()) {\r
<div id="modal-export-fountain" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        \r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideShield class="w-5 h-5 text-brand-accent"></svg>\r
                <h3 class="font-bold text-brand-text">Air-Gapped Export PSBT</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="closeFountainModal()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
\r
        <div class="p-6 flex flex-col items-center">\r
            \r
            <div class="w-full flex bg-brand-bg p-1 rounded-lg border border-brand-card-border mb-6">\r
                <button id="btn-format-ur" (click)="setExportFormat('ur')"\r
                        class="flex-1 py-1.5 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-2 cursor-pointer"\r
                        [class.bg-brand-card-border]="exportFormat() === 'ur'"\r
                        [class.text-brand-accent]="exportFormat() === 'ur'"\r
                        [class.text-brand-text-muted]="exportFormat() !== 'ur'">\r
                    Universal (UR)\r
                </button>\r
                <button id="btn-format-bbqr" (click)="setExportFormat('bbqr')"\r
                        class="flex-1 py-1.5 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-2 cursor-pointer"\r
                        [class.bg-brand-card-border]="exportFormat() === 'bbqr'"\r
                        [class.text-amber-400]="exportFormat() === 'bbqr'"\r
                        [class.text-brand-text-muted]="exportFormat() !== 'bbqr'">\r
                    Coldcard (BBQr)\r
                </button>\r
            </div>\r
\r
            @if (exportFormat() === 'ur') {\r
                <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 mb-6 flex items-start gap-3 animate-in fade-in zoom-in-95 duration-200">\r
                    <svg lucideShield class="w-5 h-5 text-brand-accent shrink-0"></svg>\r
                    <p class="text-xs text-brand-accent/80 leading-relaxed">\r
                        <strong>Standard Protocol:</strong> Optimized for Keystone, Passport, and standard hardware wallets. Adjust the speed slider for compatibility and performance.\r
                    </p>\r
                </div>\r
            } @else {\r
                <div class="w-full bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 mb-6 flex items-start gap-3 animate-in fade-in zoom-in-95 duration-200">\r
                    <svg lucideShield class="w-5 h-5 text-amber-500 shrink-0"></svg>\r
                    <p class="text-xs text-amber-200/80 leading-relaxed">\r
                        <strong>Coldcard Protocol:</strong> Optimized for Coinkite Coldcard devices. Adjust the speed slider for compatibility and performance.\r
                    </p>\r
                </div>\r
            }\r
\r
            <div class="relative group cursor-pointer inline-flex flex-col items-center" (click)="toggleFountainReveal()">\r
                \r
                <div class="bg-white p-2 rounded-xl transition-all duration-300 relative"\r
                        [class.blur-md]="!isFountainRevealed()"\r
                        [class.opacity-50]="!isFountainRevealed()">\r
                        \r
                    <canvas id="fountain-psbt-canvas" class="w-64 h-64 sm:w-72 sm:h-72 block"></canvas>\r
                </div>\r
\r
                @if (!isFountainRevealed()) {\r
                    <div class="absolute inset-0 flex flex-col items-center justify-center z-10">\r
                        <div class="bg-brand-card/90 p-3 rounded-full border border-brand-card-border shadow-xl mb-2">\r
                            <svg lucideEye class="w-6 h-6 text-brand-text"></svg>\r
                        </div>\r
                        <span class="text-xs font-bold text-brand-bg bg-white/90 px-2 py-1 rounded shadow-sm">Click to Reveal</span>\r
                    </div>\r
                }\r
            </div>\r
\r
            <p class="text-xs text-brand-text-muted mt-6 text-center max-w-[320px]">\r
                Ensure no cameras are observing your screen before revealing.\r
            </p>\r
\r
            @if (isFountainRevealed()) {\r
                <div class="w-full mt-6 bg-brand-bg p-4 rounded-xl border border-brand-card-border animate-in fade-in slide-in-from-bottom-2 duration-300">\r
                    <div class="flex justify-between items-center mb-2">\r
                        <span class="text-[10px] font-bold text-brand-text-muted uppercase tracking-wider">Frame Delay</span>\r
                        <span class="text-xs font-mono text-brand-accent font-bold">{{ fountainSpeed() }}ms</span>\r
                    </div>\r
                    <input type="range" \r
                            min="100" max="1000" step="50" \r
                            [ngModel]="fountainSpeed()" \r
                            (ngModelChange)="updateFountainSpeed($event)"\r
                            class="w-full h-1.5 bg-brand-card-border rounded-lg appearance-none cursor-pointer accent-brand-accent transition-all hover:accent-brand-accent-hover" />\r
                    <div class="flex justify-between text-[9px] text-brand-text-muted font-bold uppercase mt-1">\r
                        <span>Fast (Drops frames)</span>\r
                        <span>Slow (More reliable)</span>\r
                    </div>\r
                </div>\r
            }\r
\r
        </div>\r
\r
        <div class="p-4 bg-brand-bg/50 border-t border-brand-card-border flex justify-end gap-3">\r
            <button id="btn-cancel-download" (click)="closeFountainModal()" class="px-4 py-2.5 rounded-lg bg-brand-card hover:bg-brand-card-border text-brand-text-muted hover:text-brand-text font-medium text-sm transition border border-transparent hover:border-brand-card-border w-full cursor-pointer">\r
                Close\r
            </button>\r
        </div>\r
\r
    </div>\r
</div>\r
}\r
\r
@if (showScannerModal()) {\r
<div id="modal-import-scanner" class="fixed inset-0 z-[100] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">\r
    <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden relative">\r
        \r
        <div class="p-4 border-b border-brand-card-border flex items-center justify-between">\r
            <div class="flex items-center gap-2">\r
                <svg lucideQrCode class="w-5 h-5 text-brand-accent"></svg>\r
                <h3 class="font-bold text-brand-text">Air-Gapped Import PSBT</h3>\r
            </div>\r
            <button id="btn-modal-close" (click)="stopScanner()" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                <svg lucideX class="w-5 h-5"></svg>\r
            </button>\r
        </div>\r
\r
        <div class="p-6 flex flex-col items-center">\r
            \r
            <div class="w-full bg-brand-accent/10 border border-brand-accent/20 rounded-lg p-3 mb-6 flex items-start gap-3">\r
            <svg lucideShield class="w-5 h-5 text-brand-accent shrink-0 mt-0.5"></svg>\r
            <div class="text-xs text-brand-accent/80 leading-relaxed space-y-2">\r
                <p>\r
                    <strong>Secure Scanner:</strong> Hold your hardware wallet diplaying PSBT QR Code up to the camera.\r
                </p>\r
                <p class="text-[11px] text-brand-accent/90 font-medium bg-brand-accent/10 p-2 rounded border border-brand-accent/20">\r
                    \u{1F4A1} <strong>Tip:</strong> Sometimes QR codes are too small for webcams to read off a harware device. You can use a mobile companion application to scan the hardware wallet, and then export the Signed PSBT to {{ configService.config().brandName }} through this reader.\r
                </p>\r
            </div>\r
        </div>\r
\r
            <div class="w-full mb-4 space-y-2">\r
                <div class="bg-brand-bg border border-brand-card-border rounded-lg p-2.5 flex items-center justify-between">\r
                    <span class="text-[10px] text-brand-text-muted font-bold uppercase tracking-wider">Raw Optical Feed</span>\r
                    <span class="text-[10px] text-brand-accent font-mono truncate max-w-[200px]" [title]="urService.lastScannedText()">\r
                        {{ urService.lastScannedText() || 'Waiting for QR...' }}\r
                    </span>\r
                </div>\r
                \r
                @if (urService.scanError()) {\r
                    <div class="bg-rose-500/10 border border-rose-500/30 rounded-lg p-2.5 flex items-start gap-2 animate-in fade-in zoom-in-95 duration-200">\r
                        <svg lucideAlertTriangle class="w-4 h-4 text-rose-400 shrink-0"></svg>\r
                        <span class="text-xs text-rose-300">{{ urService.scanError() }}</span>\r
                    </div>\r
                }\r
            </div>\r
\r
            <div class="relative bg-black w-full rounded-xl overflow-hidden border border-brand-accent/30 shadow-[0_0_15px_var(--wl-accent)]">\r
                \r
                <div id="signer-reader" class="w-full h-72 object-cover"></div>\r
                \r
                <div class="absolute inset-0 pointer-events-none z-10 flex flex-col items-center justify-center overflow-hidden">\r
                    <div class="relative w-56 h-56 rounded-xl shadow-[0_0_0_9999px_rgba(var(--wl-bg),0.7)] border border-brand-accent/30">\r
                        <div class="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-brand-accent rounded-tl-xl"></div>\r
                        <div class="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-brand-accent rounded-tr-xl"></div>\r
                        <div class="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-brand-accent rounded-bl-xl"></div>\r
                        <div class="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-brand-accent rounded-br-xl"></div>\r
                        <div class="absolute left-0 right-0 h-[2px] bg-brand-accent shadow-[0_0_8px_2px_var(--wl-accent)] scanner-laser"></div>\r
                    </div>\r
                </div>\r
\r
                @if (urService.scanProgress() > 0) {\r
                    <div class="absolute bottom-0 left-0 right-0 bg-brand-card/95 backdrop-blur-sm p-3 border-t border-brand-accent/30 z-20">\r
                        <div class="flex justify-between text-xs text-brand-accent font-bold mb-2 tracking-wider">\r
                            <span>RECONSTRUCTING SIGNATURE...</span>\r
                            <span>{{ (urService.scanProgress() * 100).toFixed(0) }}%</span>\r
                        </div>\r
                        <div class="w-full bg-brand-bg rounded-full h-1.5 overflow-hidden">\r
                            <div class="bg-brand-accent h-1.5 rounded-full transition-all duration-200 ease-out" \r
                                    [style.width.%]="urService.scanProgress() * 100"></div>\r
                        </div>\r
                    </div>\r
                }\r
            </div>\r
        </div>\r
\r
        <div class="p-4 bg-brand-bg/50 border-t border-brand-card-border flex justify-end gap-3">\r
            <button id="btn-stop-scanner" (click)="stopScanner()" class="px-4 py-2.5 rounded-lg bg-brand-card hover:bg-brand-card-border text-brand-text-muted hover:text-brand-text font-medium text-sm transition border border-transparent hover:border-brand-card-border w-full cursor-pointer">\r
                Cancel & Close\r
            </button>\r
        </div>\r
\r
    </div>\r
</div>\r
}\r
\r
@if (showConfirmModal()) {\r
<div id="modal-confirm-action" class="fixed inset-0 z-[250] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm animate-fade-in">\r
    <div class="bg-brand-card border border-brand-card-border p-6 rounded-2xl shadow-2xl max-w-sm w-full mx-4 relative overflow-hidden">\r
        <div class="absolute top-0 left-0 w-full h-1" \r
                [class.bg-rose-500]="confirmData().isDestructive" \r
                [class.bg-brand-accent]="!confirmData().isDestructive"></div>\r
\r
        <h3 class="text-brand-text font-bold text-lg mb-2">{{ confirmData().title }}</h3>\r
        \r
        <p class="text-brand-text-muted text-sm mb-6 leading-relaxed whitespace-pre-wrap break-words">{{confirmData().message }}\r
        </p>\r
\r
        <div class="grid gap-3" [class.grid-cols-2]="confirmData().type === 'confirm'" [class.grid-cols-1]="confirmData().type === 'alert'">\r
            \r
            @if (confirmData().type === 'confirm') {\r
                <button (click)="closeConfirmModal()" class="px-4 py-2.5 rounded-xl border border-brand-card-border text-brand-text-muted hover:text-brand-text hover:bg-brand-card-border/50 transition font-bold text-sm cursor-pointer">\r
                    Cancel\r
                </button>\r
            }\r
\r
            <button (click)="executeConfirmAction()" \r
                    class="px-4 py-2.5 rounded-xl font-bold text-sm text-brand-bg transition shadow-lg cursor-pointer"\r
                    [class.bg-rose-600]="confirmData().isDestructive"\r
                    [class.hover:bg-rose-500]="confirmData().isDestructive"\r
                    [class.text-white]="confirmData().isDestructive"\r
                    [class.bg-brand-accent]="!confirmData().isDestructive"\r
                    [class.hover:bg-brand-accent-hover]="!confirmData().isDestructive">\r
                {{ confirmData().type === 'confirm' ? 'Confirm' : 'OK' }}\r
            </button>\r
        </div>\r
    </div>\r
</div>\r
}\r
\r
<div id="container-room-dashboard" class="max-w-7xl mx-auto px-6 py-8 relative min-h-[80vh]">\r
    \r
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-brand-accent/10 rounded-full blur-[120px] pointer-events-none"></div>\r
\r
    <div id="card-room-overview" class="bg-brand-card/80 backdrop-blur-sm border border-brand-card-border/50 rounded-xl p-6 mb-8 relative z-10 shadow-xl flex flex-col gap-6 overflow-hidden">\r
        \r
        <!-- Faded Brand Watermark -->\r
        <div class="absolute top-10 right-4 md:top-10 md:right-6 opacity-10 pointer-events-none select-none mix-blend-plus-lighter">\r
            <img [src]="configService.config().logoUrl" class="w-24 h-24 md:w-32 md:h-32 object-contain filter" alt="Brand Watermark" />\r
        </div>\r
\r
        <div class="flex justify-between items-center relative z-20">\r
            <h2 class="text-lg font-semibold text-brand-text flex items-center gap-2">\r
                Room Overview\r
            </h2>\r
            \r
            <button id="btn-reveal-overview"\r
                (click)="togglePrivacyBlur('transaction-overview')" \r
                class="p-2 rounded-lg hover:bg-brand-card-border/50 transition-colors flex items-center gap-2 cursor-pointer"\r
                [class.text-amber-500]="!blurStates()['transaction-overview']"\r
                [class.text-brand-text-muted]="blurStates()['transaction-overview']"\r
                [title]="blurStates()['transaction-overview'] ? 'Reveal Header' : 'Hide Header'">\r
                @if (blurStates()['transaction-overview']) {\r
                    <svg lucideEyeOff class="w-5 h-5"></svg>\r
                } @else {\r
                    <svg lucideEye class="w-5 h-5"></svg>\r
                }\r
            </button>\r
        </div>\r
\r
        <div class="relative overflow-hidden rounded-lg">\r
            <div class="transition-all duration-300 relative z-10 flex flex-col gap-6"\r
                    [class.blur-md]="blurStates()['transaction-overview']"\r
                    [class.opacity-30]="blurStates()['transaction-overview']"\r
                    [class.select-none]="blurStates()['transaction-overview']"\r
                    [class.pointer-events-none]="blurStates()['transaction-overview']">\r
\r
                <div class="flex items-center gap-3">\r
                    @if (isExpired()) {\r
                        <span class="w-3 h-3 rounded-full bg-rose-600 shrink-0 shadow-[0_0_10px_#e11d48]" title="Room Expired"></span>\r
                    } @else if (socket.roomState()?.isLocked) {\r
                        <span class="w-3 h-3 rounded-full bg-amber-500 animate-pulse shadow-[0_0_10px_#f59e0b] shrink-0" title="Room Locked"></span>\r
                    } @else {\r
                        <span class="w-3 h-3 rounded-full bg-brand-accent animate-pulse shadow-[0_0_10px_var(--wl-accent)] shrink-0" title="Room Active"></span>\r
                    }\r
                    \r
                    <h1 class="text-2xl font-bold text-brand-text truncate">\r
                        {{ socket.roomState()?.roomName || configService.config().defaultRoomName }}\r
                    </h1>\r
\r
                    @if (socket.isCoordinator()) {\r
                        <button id="btn-edit-room-name"\r
                            (click)="openRenameModal()" \r
                            class="p-2 -ml-1 rounded-lg hover:bg-brand-card-border/50 text-brand-text-muted hover:text-brand-text transition cursor-pointer"\r
                            title="Rename Room">\r
                            <svg lucideEdit2 class="w-4 h-4"></svg>\r
                        </button>\r
                    }\r
                </div>\r
\r
                <div class="flex flex-wrap items-center gap-3 sm:gap-4 text-sm text-brand-text-muted bg-brand-bg w-fit px-4 py-2 rounded-xl border border-brand-card-border">\r
                    \r
                    <div class="relative group">\r
                        <button id="btn-copy-room-id" (click)="openRoomIdModal()" class="flex items-center gap-2 hover:bg-brand-card-border/50 p-1.5 -m-1.5 rounded-lg transition border border-transparent hover:border-brand-card-border cursor-pointer">\r
                            @if (roomIdCopied()) {\r
                                <svg lucideCheck class="w-4 h-4 transition-colors text-brand-accent"></svg>\r
                            } @else {\r
                                <svg lucideHash class="w-4 h-4 transition-colors text-brand-text-muted"></svg>\r
                            }\r
                            <span class="font-mono transition font-bold" \r
                                [class.text-brand-accent]="roomIdCopied()" \r
                                [class.text-brand-text]="!roomIdCopied()"\r
                                [class.hover:text-brand-text-muted]="!roomIdCopied()">\r
                                {{ roomId() }}\r
                            </span>\r
                        </button>\r
                        \r
                        <div class="absolute -top-9 left-1/2 -translate-x-1/2 bg-brand-card-border text-brand-text text-[10px] font-bold px-2.5 py-1 rounded opacity-0 group-hover:opacity-100 transition pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                            {{ roomIdCopied() ? 'Copied!' : 'View Room ID' }}\r
                        </div>\r
                    </div>\r
\r
                    <div class="w-px h-4 bg-brand-card-border"></div>\r
\r
                    <div class="relative group">\r
                        <div class="flex items-center gap-1.5 cursor-help"\r
                                [class.text-brand-accent]="!socket.roomState()?.network || socket.roomState()?.network === 'bitcoin'"\r
                                [class.text-amber-500]="socket.roomState()?.network === 'testnet'"\r
                                [class.text-purple-400]="socket.roomState()?.network === 'signet'">\r
                            <svg lucideNetwork class="w-4 h-4"></svg>\r
                            <span class="font-bold text-xs uppercase tracking-wide">\r
                                {{ socket.roomState()?.network === 'bitcoin' ? 'Mainnet' : (socket.roomState()?.network || 'Mainnet') }}\r
                            </span>\r
                        </div>\r
                        \r
                        <div class="absolute -top-10 left-1/2 -translate-x-1/2 bg-brand-card-border text-brand-text text-[10px] font-bold px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                            {{ (!socket.roomState()?.network || socket.roomState()?.network === 'bitcoin') ? 'Real Bitcoin Network (Exercise Caution)' : 'Test Network (No real value)' }}\r
                        </div>\r
                    </div>\r
\r
                    @if (socket.isCoordinator()) {\r
                        <div class="w-px h-4 bg-brand-card-border"></div>\r
\r
                        <div class="relative group">\r
                            <div class="flex items-center gap-1.5 text-indigo-400 cursor-help">\r
                                <svg lucideCrown class="w-4 h-4"></svg>\r
                                <span class="font-bold text-xs uppercase tracking-wide">Coordinator</span>\r
                            </div>\r
                            \r
                            <div class="absolute -top-10 left-1/2 -translate-x-1/2 bg-brand-card-border text-brand-text text-[10px] font-bold px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                                You have admin privileges\r
                            </div>\r
                        </div>\r
                    }\r
\r
                    <div class="w-px h-4 bg-brand-card-border"></div>\r
                    \r
                    <div class="relative group">\r
                        <button id="btn-view-sessions" (click)="openSessionsModal()" class="relative group cursor-pointer hover:bg-brand-card-border/50 p-1.5 -m-1.5 rounded-lg transition border border-transparent hover:border-brand-card-border">\r
                            <div class="flex items-center gap-2">\r
                                <svg lucideUsers class="w-4 h-4" \r
                                    [class.text-brand-accent]="(socket.roomState()?.connectedCount || 0) > 1"\r
                                    [class.text-brand-text-muted]="(socket.roomState()?.connectedCount || 0) <= 1">\r
                                </svg>\r
                                <span class="font-bold" [class.text-brand-text]="(socket.roomState()?.connectedCount || 0) > 1">\r
                                    {{ socket.roomState()?.connectedCount || 1 }} \r
                                </span>\r
                            </div>\r
                        </button>\r
                        \r
                        <div class="absolute -top-10 left-1/2 -translate-x-1/2 bg-brand-card-border text-brand-text text-[10px] font-bold px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                            View Active Sessions\r
                        </div>\r
                    </div>\r
\r
                    <div class="w-px h-4 bg-brand-card-border"></div>\r
\r
                    <div class="relative group cursor-help">\r
                        <div class="flex items-center gap-2" [class.text-rose-400]="isLowTime() || isExpired()" [class.text-brand-text-muted]="!isLowTime() && !isExpired()">\r
                            <svg lucideClock class="w-4 h-4"></svg>\r
                            @if (isExpired()) {\r
                                <span class="font-bold text-xs uppercase">Expired</span>\r
                            } @else {\r
                                <span class="font-mono font-bold">{{ timeRemaining() }}</span>\r
                            }\r
                        </div>\r
                        \r
                        <div class="absolute -top-10 right-0 md:left-1/2 md:-translate-x-1/2 md:right-auto bg-brand-card-border text-brand-text text-[10px] font-bold px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                            Room auto-expires & securely wipes data\r
                        </div>\r
                    </div>\r
                </div>\r
            </div>\r
            \r
            @if (blurStates()['transaction-overview']) {\r
                <div class="absolute inset-0 flex items-center justify-center z-20">\r
                    <button (click)="togglePrivacyBlur('transaction-overview')" class="bg-brand-card-border/90 text-brand-text hover:bg-brand-card-border px-4 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 border border-brand-card-border shadow-xl backdrop-blur-sm transition-colors cursor-pointer">\r
                        <svg lucideEyeOff class="w-3.5 h-3.5"></svg>\r
                        Hidden for Privacy\r
                    </button>\r
                </div>\r
            }\r
        </div>\r
\r
        <div class="pt-4 border-t border-brand-card-border/50 flex flex-col items-start gap-2 relative z-30">\r
            <div class="text-[10px] uppercase tracking-widest text-brand-text-muted font-bold ml-1">Room Actions</div>\r
            <div class="flex flex-wrap items-center p-1.5 bg-brand-bg border border-brand-card-border rounded-xl gap-2 shadow-sm w-full sm:w-auto">\r
                \r
                @if (!isExpired() && !socket.isClosed()) {\r
                    <div class="relative group">\r
                        <button id="btn-action-audit" (click)="promptAuditLogDownload()" class="px-3 py-2 text-brand-accent hover:bg-brand-accent/10 hover:text-brand-accent-hover rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent hover:border-brand-accent/20 cursor-pointer">\r
                            <svg lucideFileCheck class="w-4 h-4"></svg>\r
                            Audit Log\r
                        </button>\r
                    </div>\r
\r
                    <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div> \r
\r
                    <div class="relative group">\r
                        <button id="btn-action-csv" (click)="promptCsvDownload()" class="px-3 py-2 text-blue-400 hover:bg-blue-950/30 hover:text-blue-300 rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent hover:border-blue-500/20 cursor-pointer">\r
                            <svg lucideDownload class="w-4 h-4"></svg>\r
                            CSV\r
                        </button>\r
                    </div>\r
                    <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div>\r
                }\r
\r
                <div class="relative group">\r
                    <button id="btn-action-link-key" (click)="openKeyModal()" class="px-3 py-2 text-cyan-400 hover:bg-cyan-950/30 hover:text-cyan-300 rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent hover:border-cyan-500/20 cursor-pointer">\r
                        @if (keyCopied()) {\r
                            <svg lucideCheck class="w-4 h-4"></svg>\r
                        } @else {\r
                            <svg lucideKey class="w-4 h-4"></svg>\r
                        }\r
                        {{ keyCopied() ? 'Copied' : 'Link Key' }}\r
                    </button>\r
                </div>\r
\r
                <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div>\r
\r
                @if (socket.isCoordinator()) {\r
                    <div class="relative group">\r
                        <button id="btn-action-backup-admin" (click)="openAdminModal()" class="px-3 py-2 text-purple-400 hover:bg-purple-950/30 hover:text-purple-300 rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent hover:border-purple-500/20 cursor-pointer">\r
                            @if (adminCopied()) {\r
                                <svg lucideCheck class="w-4 h-4"></svg>\r
                            } @else {\r
                                <svg lucideFileKey class="w-4 h-4"></svg>\r
                            }\r
                            {{ adminCopied() ? 'Copied' : 'Backup Admin' }}\r
                        </button>\r
                    </div>\r
                    \r
                    <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div>\r
                }\r
\r
                <div class="relative group">\r
                    <button id="btn-action-share" (click)="openShareModal()" class="px-3 py-2 text-brand-text hover:bg-brand-card-border rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent hover:border-brand-card-border cursor-pointer">\r
                        <svg lucideCopy class="w-4 h-4"></svg>\r
                        Share Link\r
                    </button>\r
                </div>\r
\r
                <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div>\r
\r
                <div class="relative group">\r
                    <button id="btn-action-qr" (click)="openQr()" class="px-3 py-2 text-brand-text hover:bg-brand-card-border rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent hover:border-brand-card-border cursor-pointer">\r
                        <svg lucideQrCode class="w-4 h-4"></svg>\r
                        <span class="hidden sm:inline">QR Code</span>\r
                    </button>\r
                </div>\r
\r
                @if (socket.isCoordinator()) {\r
                    <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div>\r
                    <div class="relative group">\r
                        <button id="btn-action-lock-room" (click)="toggleLock()" \r
                                class="px-3 py-2 rounded-lg transition text-xs font-bold flex items-center gap-2 border border-transparent cursor-pointer"\r
                                [class.text-rose-400]="socket.roomState()?.isLocked"\r
                                [class.bg-rose-950\\/30]="socket.roomState()?.isLocked"\r
                                [class.text-brand-text-muted]="!socket.roomState()?.isLocked"\r
                                [class.hover:bg-brand-card-border]="!socket.roomState()?.isLocked">\r
                            @if (socket.roomState()?.isLocked) {\r
                                <svg lucideLock class="w-4 h-4"></svg>\r
                            } @else {\r
                                <svg lucideUnlock class="w-4 h-4"></svg>\r
                            }\r
                            {{ socket.roomState()?.isLocked ? 'Locked' : 'Lock Room' }}\r
                        </button>\r
                    </div>\r
                }\r
\r
                @if (socket.isCoordinator() && !isExpired() && !socket.isClosed()) {\r
                    <div class="hidden sm:block w-px h-6 bg-brand-card-border mx-1"></div> \r
                    <div class="relative group">\r
                        <button id="btn-action-close-room" (click)="closeRoom()" class="px-3 py-2 bg-rose-950/30 text-rose-400 border border-rose-900/50 hover:bg-rose-900/50 hover:border-rose-500 hover:text-white rounded-lg transition text-xs font-bold flex items-center gap-2 cursor-pointer">\r
                            <svg lucidePower class="w-4 h-4"></svg>\r
                            Close\r
                        </button>\r
                    </div>\r
                }\r
            </div>\r
        </div>\r
\r
    </div>\r
\r
    @if (showSessionsModal()) {\r
    <div id="modal-active-sessions" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/80 backdrop-blur-sm animate-fade-in p-4">\r
        <div class="bg-brand-card border border-brand-card-border rounded-2xl shadow-2xl max-w-md w-full overflow-hidden flex flex-col max-h-[80vh]">\r
            \r
            <div class="p-4 border-b border-brand-card-border flex items-center justify-between bg-brand-card z-10 shrink-0">\r
                <div class="flex items-center gap-2">\r
                    <svg lucideUsers class="w-5 h-5 text-brand-accent"></svg>\r
                    <h3 class="font-bold text-brand-text">Active Sessions</h3>\r
                </div>\r
                <button id="btn-modal-close" (click)="showSessionsModal.set(false)" class="text-brand-text-muted hover:text-brand-text transition cursor-pointer">\r
                    <svg lucideX class="w-5 h-5"></svg>\r
                </button>\r
            </div>\r
\r
            <div class="p-4 border-b border-brand-card-border bg-brand-bg shrink-0">\r
                <label class="block text-xs font-bold text-brand-text-muted uppercase tracking-wider mb-2">My Display Name</label>\r
                <div class="flex gap-2">\r
                    <input type="text" [ngModel]="personalDisplayName()" (ngModelChange)="personalDisplayName.set($event)" (keyup.enter)="savePersonalName()"\r
                        placeholder="e.g. Auditor Bob" maxlength="32"\r
                        class="w-full bg-brand-card border border-brand-card-border text-brand-text text-sm rounded-lg block p-2.5 outline-none focus:border-brand-accent transition"/>\r
                    <button (click)="savePersonalName()" class="px-5 py-2.5 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-lg transition text-sm cursor-pointer">\r
                        Save\r
                    </button>\r
                </div>\r
                <p class="text-[10px] text-brand-text-muted mt-2">Your name is end-to-end encrypted and only visible to people currently in this room.</p>\r
            </div>\r
\r
            <div class="p-4 overflow-y-auto custom-scrollbar flex-grow space-y-2">\r
                @for (session of socket.activeSessions(); track session.id) {\r
                    <div class="flex items-center justify-between p-3 rounded-xl border transition-all"\r
                        [class.bg-brand-accent_10]="session.id === socket.currentSessionId()"\r
                        [class.border-brand-accent_30]="session.id === socket.currentSessionId()"\r
                        [class.bg-brand-bg]="session.id !== socket.currentSessionId()"\r
                        [class.border-brand-card-border]="session.id !== socket.currentSessionId()">\r
                        \r
                        <div class="flex items-center gap-3 overflow-hidden">\r
                            <div class="w-10 h-10 rounded-full flex items-center justify-center shrink-0"\r
                                [class.bg-indigo-500_10]="session.role === 'admin'"\r
                                [class.bg-brand-card-border]="session.role !== 'admin'">\r
                                @if (session.role === 'admin') {\r
                                    <svg lucideCrown class="w-5 h-5 text-indigo-400"></svg>\r
                                } @else {\r
                                    <svg lucideUser class="w-5 h-5 text-brand-text-muted"></svg>\r
                                }\r
                            </div>\r
                            <div class="min-w-0">\r
                                <div class="flex items-center gap-2">\r
                                    <span class="text-brand-text font-bold text-sm truncate" [class.italic]="!session.displayName">\r
                                        {{ session.displayName || 'Anonymous Guest' }}\r
                                    </span>\r
                                    @if (session.id === socket.currentSessionId()) {\r
                                        <span class="text-[9px] uppercase tracking-wider font-bold bg-brand-accent/20 border border-brand-accent/20 text-brand-accent px-1.5 py-0.5 rounded">You</span>\r
                                    }\r
                                </div>\r
                                <div class="text-brand-text-muted text-[10px] font-mono mt-0.5">\r
                                    Session: {{ session.id }}\r
                                </div>\r
                            </div>\r
                        </div>\r
\r
                        <button class="transition p-2 cursor-pointer" \r
                            [class.text-brand-accent]="copiedSessionId() === session.id"\r
                            [class.text-brand-text-muted]="copiedSessionId() !== session.id"\r
                            [class.hover:text-brand-text]="copiedSessionId() !== session.id"\r
                            title="Copy Session Details" \r
                            (click)="copySessionId(session.id, session.displayName)">\r
                            @if (copiedSessionId() === session.id) {\r
                                <svg lucideCheck class="w-3.5 h-3.5"></svg>\r
                            } @else {\r
                                <svg lucideCopy class="w-3.5 h-3.5"></svg>\r
                            }\r
                        </button>\r
                    </div>\r
                }\r
                \r
                @if (socket.activeSessions().length === 0) {\r
                    <div class="text-center py-6 text-brand-text-muted text-sm flex flex-col items-center gap-2">\r
                        <svg lucideLoader2 class="w-5 h-5 animate-spin"></svg>\r
                        Syncing sessions...\r
                    </div>\r
                }\r
            </div>\r
        </div>\r
    </div>\r
    }\r
\r
    @if (socket.isClosed()) {\r
    <div id="modal-status-closed" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/90 backdrop-blur-xl animate-fade-in">\r
        <div class="bg-brand-card border border-brand-card-border p-8 rounded-2xl shadow-2xl max-w-md w-full text-center mx-4">\r
            <div class="w-16 h-16 bg-brand-card-border/50 rounded-full flex items-center justify-center mx-auto mb-6">\r
                <svg lucidePower class="w-8 h-8 text-brand-text-muted"></svg>\r
            </div>\r
            <h2 class="text-2xl font-bold text-brand-text mb-2">\r
                @if (configService.config().useTradeMark) {\r
                    Signing Room\xAE Closed\r
                } @else {\r
                    Closed\r
                }\r
            </h2>\r
            <p class="text-brand-text-muted mb-8">The coordinator has ended this signing session. All data has been securely wiped.</p>\r
            @if (!isEmbedded) {\r
                <a routerLink="/create" class="w-full py-3 bg-brand-card-border/50 hover:bg-brand-card-border text-brand-text font-bold rounded-xl transition flex items-center justify-center gap-2 border border-brand-card-border decoration-0">\r
                    <svg lucideZap class="w-4 h-4"></svg> Start New Signing\r
                </a>\r
            }\r
        </div>\r
    </div>\r
    }\r
\r
    @if (isExpired() && !socket.isClosed()) {\r
    <div id="modal-status-expired" class="fixed inset-0 z-[200] flex items-center justify-center bg-brand-bg/90 backdrop-blur-xl animate-fade-in">\r
        <div class="bg-brand-card border border-brand-card-border p-8 rounded-2xl shadow-2xl max-w-md w-full text-center mx-4">\r
            <div class="w-16 h-16 bg-rose-500/10 rounded-full flex items-center justify-center mx-auto mb-6">\r
                <svg lucideAlertTriangle class="w-8 h-8 text-rose-500"></svg>\r
            </div>\r
            <h2 class="text-2xl font-bold text-brand-text mb-2">Room Expired</h2>\r
            <p class="text-brand-text-muted mb-8">This session has timed out. All ephemeral data has been wiped.</p>\r
            @if (!isEmbedded) {\r
                <a routerLink="/create" class="w-full py-3 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition flex items-center justify-center gap-2 decoration-0">\r
                    <svg lucideZap class="w-4 h-4"></svg> Start New Signing\r
                </a>\r
            }\r
        </div>\r
    </div>\r
    }\r
\r
    @if (showPrivacyWarning()) {\r
    <div id="modal-opsec-warning" class="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md transition-all">\r
    <div class="bg-brand-card border border-amber-500/30 rounded-xl max-w-xl w-full p-6 shadow-2xl relative overflow-hidden">\r
        \r
        <div class="absolute top-0 left-0 w-full h-1 bg-amber-500"></div>\r
\r
        <div class="flex items-center gap-3 text-amber-500 mb-4">\r
        <svg lucideEye class="w-7 h-7 animate-pulse"></svg>\r
        <h3 class="text-xl font-bold text-brand-text">OpSec Warning</h3>\r
        </div>\r
        \r
        <p class="text-brand-text mb-6 leading-relaxed">\r
        You are about to reveal sensitive transaction details. Before proceeding, please ensure:\r
        <br><br>\r
        <span class="flex items-center gap-2 text-sm text-brand-text-muted">\r
            <svg lucideCheckCircle class="w-4 h-4 text-brand-accent"></svg> No one is looking over your shoulder.\r
        </span>\r
        <span class="flex items-center gap-2 text-sm text-brand-text-muted mt-2">\r
            <svg lucideCheckCircle class="w-4 h-4 text-brand-accent"></svg> You are not sharing your screen.\r
        </span>\r
        <span class="flex items-center gap-2 text-sm text-brand-text-muted mt-2">\r
            <svg lucideCheckCircle class="w-4 h-4 text-brand-accent"></svg> There are no cameras recording your screen.\r
        </span>\r
        </p>\r
\r
        <div class="flex flex-wrap sm:flex-nowrap gap-3 justify-end mt-8">\r
        <button id="btn-privacy-keep-blurred"\r
            (click)="closePrivacyWarning()" \r
            class="w-full sm:w-auto px-5 py-2.5 rounded-lg border border-brand-card-border text-brand-text hover:bg-brand-card-border/50 transition-colors font-medium cursor-pointer">\r
            Keep Blurred\r
        </button>\r
        <button id="btn-privacy-reveal-all"\r
            (click)="confirmUnblurAll()" \r
            class="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-amber-500/10 text-amber-500 font-bold hover:bg-amber-500/20 border border-amber-500/30 transition-colors flex items-center justify-center gap-2 cursor-pointer">\r
            <svg lucideEye class="w-[18px] h-[18px]"></svg>\r
            Reveal All\r
        </button>\r
        <button id="btn-privacy-reveal-section"\r
            (click)="confirmUnblur()" \r
            class="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-amber-500 text-brand-bg font-bold hover:bg-amber-400 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer">\r
            <svg lucideEye class="w-[18px] h-[18px]"></svg>\r
            Reveal Section\r
        </button>\r
        </div>\r
    </div>\r
    </div>\r
}\r
\r
    <div class="grid lg:grid-cols-3 gap-8 transition-all duration-500 relative z-10" \r
        [class.opacity-20]="isExpired() || socket.isClosed()" \r
        [class.pointer-events-none]="isExpired() || socket.isClosed()">\r
    \r
    <div class="lg:col-span-2 space-y-6">\r
        \r
        <div id="card-tx-proposal" class="bg-brand-card border border-brand-card-border rounded-xl p-6 relative overflow-hidden">\r
\r
            <div class="absolute top-10 right-0 p-4 opacity-10 pointer-events-none">\r
                <img [src]="configService.config().logoUrl" class="w-24 h-24 object-contain" alt="Brand Watermark" />\r
            </div>\r
        \r
            <div class="flex justify-between items-center mb-4 relative z-20">\r
                <h2 class="text-lg font-semibold text-brand-text flex items-center gap-2">\r
                    Transaction Proposal\r
                </h2>\r
                \r
                <button id="btn-reveal-proposal"\r
                    (click)="togglePrivacyBlur('transaction-proposal')" \r
                    class="p-2 rounded-lg hover:bg-brand-card-border/50 transition-colors flex items-center gap-2 cursor-pointer"\r
                    [class.text-amber-500]="!blurStates()['transaction-proposal']"\r
                    [class.text-brand-text-muted]="blurStates()['transaction-proposal']"\r
                    [title]="blurStates()['transaction-proposal'] ? 'Reveal Proposal' : 'Hide Proposal'">\r
                    @if (blurStates()['transaction-proposal']) {\r
                        <svg lucideEyeOff class="w-5 h-5"></svg>\r
                    } @else {\r
                        <svg lucideEye class="w-5 h-5"></svg>\r
                    }\r
                </button>\r
            </div>\r
\r
            <div class="transition-all duration-300 relative z-10"\r
                    [class.blur-md]="blurStates()['transaction-proposal']"\r
                    [class.opacity-30]="blurStates()['transaction-proposal']"\r
                    [class.select-none]="blurStates()['transaction-proposal']"\r
                    [class.pointer-events-none]="blurStates()['transaction-proposal']">\r
                \r
                <div class="flex justify-between items-end">\r
                    <div>\r
                        <div class="text-4xl font-bold text-brand-text mb-1">{{ (socket.txDetails()?.amount || 0) / 100000000 | number:'1.8-8' }} <span class="text-brand-text-muted text-xl">BTC</span></div>\r
                        <div class="text-brand-accent text-sm font-mono font-medium">\r
                            {{ socket.txDetails()?.amount || 0 | number }} sats\r
                        </div>\r
                    </div>\r
                    <div class="text-right">\r
                        <div class="text-brand-text-muted text-sm">Network Fee</div>\r
                        <div class="text-brand-text font-mono">{{ socket.txDetails()?.feeRate ?? '--' }} sats/vB</div>\r
                    </div>\r
                </div>\r
            </div>\r
\r
            @if (blurStates()['transaction-proposal']) {\r
                <div class="absolute inset-0 flex items-center justify-center z-10">\r
                    <button (click)="togglePrivacyBlur('transaction-proposal')" class="bg-brand-card-border/90 text-brand-text hover:bg-brand-card-border px-4 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 border border-brand-card-border shadow-xl backdrop-blur-sm mt-8 transition-colors cursor-pointer">\r
                        <svg lucideEyeOff class="w-3.5 h-3.5"></svg>\r
                        Hidden for Privacy\r
                    </button>\r
                </div>\r
            }\r
        </div>\r
\r
        <div id="card-signer-actions" class="bg-brand-card border border-brand-card-border rounded-xl p-6 mb-6">\r
\r
            <h2 class="text-lg font-semibold text-brand-text flex items-center gap-2 mb-4">Signer Actions</h2>\r
\r
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">\r
                \r
                <div class="flex flex-col gap-2">\r
                    <div class="text-xs text-brand-text-muted mb-1">1. Export Unsigned Transaction</div>\r
                    <div class="grid grid-cols-2 gap-2">\r
                        <button id="btn-export-show-qr" (click)="openFountainModal()" class="flex items-center justify-center p-3 bg-brand-bg border border-brand-card-border rounded-lg hover:border-brand-accent/50 hover:bg-brand-accent/5 transition-all text-sm font-medium text-brand-text group cursor-pointer">\r
                            <svg lucideQrCode class="mr-2 text-brand-text-muted group-hover:text-brand-accent transition-colors w-[18px] h-[18px]"></svg>\r
                            Show QR\r
                        </button>\r
                        <button id="btn-export-download-file" (click)="promptPsbtDownload()" class="flex items-center justify-center p-3 bg-brand-bg border border-brand-card-border rounded-lg hover:border-purple-500/50 hover:bg-purple-500/5 transition-all text-sm font-medium text-brand-text group cursor-pointer">\r
                            <svg lucideDownloadCloud class="mr-2 text-brand-text-muted group-hover:text-purple-400 transition-colors w-[18px] h-[18px]"></svg>\r
                            Download File\r
                        </button>\r
                    </div>\r
                </div>\r
\r
                <div class="flex flex-col gap-2">\r
                    <div class="text-xs text-brand-text-muted mb-1">2. Import Signed Transaction</div>\r
                    <div class="grid grid-cols-2 gap-2">\r
                        <button id="btn-import-scan-qr" (click)="startScanner()" [disabled]="isScanningSigned()" class="flex items-center justify-center p-3 bg-brand-bg border border-brand-card-border rounded-lg hover:border-brand-accent/50 hover:bg-brand-accent/5 transition-all text-sm font-medium text-brand-text group disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer">\r
                            <svg lucideQrCode class="mr-2 text-brand-text-muted group-hover:text-brand-accent transition-colors w-[18px] h-[18px]"></svg>\r
                            Scan QR\r
                        </button>\r
                        <label id="btn-import-upload-file" class="relative group cursor-pointer flex items-center justify-center p-3 bg-brand-bg border border-brand-card-border rounded-lg hover:border-purple-500/50 hover:bg-purple-500/5 transition-all text-sm font-medium text-brand-text disabled:opacity-50">\r
                            <input type="file" (change)="onFileSelected($event)" accept=".psbt,.txt,.hex" class="absolute inset-0 opacity-0 cursor-pointer z-10" [disabled]="isScanningSigned()">\r
                            <svg lucideUploadCloud class="mr-2 text-brand-text-muted group-hover:text-purple-400 transition-colors w-[18px] h-[18px]"></svg>\r
                            Upload File\r
                        </label>\r
                    </div>\r
                </div>\r
            </div>\r
\r
            @if (isScanningSigned()) {\r
                <div class="relative bg-black rounded-xl overflow-hidden border border-brand-accent/30 mt-6 shadow-[0_0_15px_var(--wl-accent)] animate-in fade-in slide-in-from-top-4 duration-300">\r
                    <div id="signer-reader" class="w-full h-72 object-cover"></div>\r
                    \r
                    <div class="absolute inset-0 pointer-events-none z-10 flex flex-col items-center justify-center overflow-hidden">\r
                        <div class="absolute top-6 left-1/2 -translate-x-1/2 z-20 bg-brand-bg/80 border border-brand-accent/20 backdrop-blur-md px-4 py-1.5 rounded-full whitespace-nowrap shadow-lg">\r
                            <span class="text-xs font-medium text-brand-accent uppercase tracking-widest flex items-center gap-2">\r
                                <div class="w-2 h-2 rounded-full bg-brand-accent animate-pulse"></div>\r
                                Scan Signature Sequence\r
                            </span>\r
                        </div>\r
\r
                        <div class="relative w-56 h-56 rounded-xl shadow-[0_0_0_9999px_rgba(var(--wl-bg),0.7)] border border-brand-accent/30">\r
                            <div class="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-brand-accent rounded-tl-xl"></div>\r
                            <div class="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-brand-accent rounded-tr-xl"></div>\r
                            <div class="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-brand-accent rounded-bl-xl"></div>\r
                            <div class="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-brand-accent rounded-br-xl"></div>\r
                            <div class="absolute left-0 right-0 h-[2px] bg-brand-accent shadow-[0_0_8px_2px_var(--wl-accent)] scanner-laser"></div>\r
                        </div>\r
                    </div>\r
\r
                    @if (urService.scanProgress() > 0) {\r
                        <div class="absolute bottom-0 left-0 right-0 bg-brand-card/95 backdrop-blur-sm p-3 border-t border-brand-card-border z-20">\r
                            <div class="flex justify-between text-xs text-brand-text-muted mb-2">\r
                                <span>Ingesting Signature...</span>\r
                                <span>{{ (urService.scanProgress() * 100).toFixed(0) }}%</span>\r
                            </div>\r
                            <div class="w-full bg-brand-card-border rounded-full h-1.5 overflow-hidden">\r
                                <div class="bg-brand-accent h-1.5 rounded-full transition-all duration-200 ease-out" [style.width.%]="urService.scanProgress() * 100"></div>\r
                            </div>\r
                        </div>\r
                    }\r
                    \r
                    <button (click)="stopScanner()" class="absolute top-4 right-4 z-20 text-brand-text-muted bg-brand-card/80 hover:text-brand-text hover:bg-red-500/90 p-2.5 rounded-full transition-all backdrop-blur-sm border border-brand-card-border hover:border-red-500 cursor-pointer">\r
                        <svg lucideX class="w-5 h-5"></svg>\r
                    </button>\r
                </div>\r
            }\r
        </div>\r
\r
        <div id="card-tx-details" class="relative bg-brand-card border border-brand-card-border rounded-xl p-5 min-h-[400px] overflow-hidden">\r
\r
            <div class="flex justify-between items-center mb-4 relative z-20">\r
                <h2 class="text-lg font-semibold text-brand-text flex items-center gap-2">\r
                Transaction Details\r
                </h2>\r
                \r
                <button id="btn-reveal-details"\r
                (click)="togglePrivacyBlur('transaction-details')" \r
                class="p-2 rounded-lg hover:bg-brand-card-border/50 transition-colors flex items-center gap-2 cursor-pointer"\r
                [class.text-amber-500]="!blurStates()['transaction-details']"\r
                [class.text-brand-text-muted]="blurStates()['transaction-details']"\r
                [title]="blurStates()['transaction-details'] ? 'Reveal Details' : 'Hide Details'">\r
                @if (blurStates()['transaction-details']) {\r
                    <svg lucideEyeOff class="w-5 h-5"></svg>\r
                } @else {\r
                    <svg lucideEye class="w-5 h-5"></svg>\r
                }\r
                </button>\r
            </div>\r
\r
            <div class="transition-all duration-300"\r
                [class.blur-md]="blurStates()['transaction-details']"\r
                [class.opacity-30]="blurStates()['transaction-details']"\r
                [class.select-none]="blurStates()['transaction-details']"\r
                [class.pointer-events-none]="blurStates()['transaction-details']">\r
                \r
                <div class="w-full flex bg-brand-bg p-1 rounded-lg border border-brand-card-border mb-4">\r
                    <button id="btn-tab-inputs" (click)="setViewMode('inputs')"\r
                            class="flex-1 py-1.5 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-2 cursor-pointer"\r
                            [class.bg-brand-accent]="viewMode() === 'inputs'"\r
                            [class.text-brand-bg]="viewMode() === 'inputs'"\r
                            [class.text-brand-text-muted]="viewMode() !== 'inputs'"\r
                            [class.hover:text-brand-text]="viewMode() !== 'inputs'">\r
                        Inputs ({{ socket.txDetails()?.inputs || 0 }})\r
                    </button>\r
                    <button id="btn-tab-outputs" (click)="setViewMode('outputs')" \r
                            class="flex-1 py-1.5 text-xs font-bold rounded-md transition-all flex items-center justify-center gap-2 cursor-pointer"\r
                            [class.bg-brand-accent]="viewMode() === 'outputs'"\r
                            [class.text-brand-bg]="viewMode() === 'outputs'"\r
                            [class.text-brand-text-muted]="viewMode() !== 'outputs'"\r
                            [class.hover:text-brand-text]="viewMode() !== 'outputs'">\r
                        Outputs ({{ socket.txDetails()?.outputs?.length || 0 }})\r
                    </button>\r
                </div>\r
                <div class="mb-4 relative">\r
                    @if (viewMode() === 'inputs') {\r
                        <div class="relative flex items-center">\r
                            <svg lucideSearch class="w-4 h-4 text-brand-text-muted absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none"></svg>\r
                            <input type="text" [ngModel]="inputSearchQuery()" (ngModelChange)="updateSearchQuery('inputs', $event)" placeholder="Search input address..."\r
                            class="w-full bg-brand-bg border border-brand-card-border text-brand-text text-xs rounded-lg block py-2.5 pr-20 pl-10 outline-none focus:border-brand-accent/50 transition"/>\r
                            <div class="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono font-bold text-brand-text-muted bg-brand-card px-2 py-0.5 rounded border border-brand-card-border pointer-events-none" title="Filtered Results">\r
                                {{ filteredInputs().length }}\r
                            </div>\r
                        </div>\r
                    } @else {\r
                        <div class="relative flex items-center">\r
                            <svg lucideSearch class="w-4 h-4 text-brand-text-muted absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none"></svg>\r
                            <input type="text" [ngModel]="outputSearchQuery()" (ngModelChange)="updateSearchQuery('outputs', $event)" placeholder="Search output address..."\r
                            class="w-full bg-brand-bg border border-brand-card-border text-brand-text text-xs rounded-lg block py-2.5 pr-20 pl-10 outline-none focus:border-brand-accent/50 transition"/>\r
                            <div class="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-mono font-bold text-brand-text-muted bg-brand-card px-2 py-0.5 rounded border border-brand-card-border pointer-events-none" title="Filtered Results">\r
                                {{ filteredOutputs().length }}\r
                            </div>\r
                        </div>\r
                    }\r
                </div>\r
\r
                @if (socket.isCoordinator()) {\r
                <div class="flex justify-end mb-2">\r
                    @if (viewMode() === 'inputs') {\r
                        <button id="btn-verify-all-inputs" (click)="verifyAllInputs()" class="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 px-2 py-1 rounded transition border border-transparent hover:border-emerald-500/20 flex items-center gap-1 cursor-pointer">\r
                            <svg lucideCheckCircle class="w-3 h-3"></svg> Verify All Inputs\r
                        </button>\r
                    }\r
                    @if (viewMode() === 'outputs') {\r
                        <button id="btn-verify-all-outputs" (click)="verifyAllOutputs()" class="text-[10px] font-bold text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 px-2 py-1 rounded transition border border-transparent hover:border-emerald-500/20 flex items-center gap-1 cursor-pointer">\r
                            <svg lucideCheckCircle class="w-3 h-3"></svg> Verify All Outputs\r
                        </button>\r
                    }\r
                </div>\r
                }\r
\r
                <div class="space-y-3 flex-grow overflow-y-auto max-h-[400px] pr-2 custom-scrollbar">\r
                    @if (viewMode() === 'inputs') {\r
                        @for (input of filteredInputs(); track $index) {\r
                            <!-- Input Card Container -->\r
                            <div class="flex flex-col sm:flex-row items-stretch bg-brand-bg rounded-xl border transition-all overflow-hidden address-card" \r
                                [class.border-emerald-500]="isWhitelisted(input.address)" \r
                                [class.border-brand-card-border]="!isWhitelisted(input.address)">\r
                                \r
                                <!-- Left/Top Column: Status -->\r
                                <div class="verification-badge flex sm:flex-col items-center justify-center p-3 w-full sm:w-28 shrink-0 border-b sm:border-b-0 sm:border-r border-brand-card-border/80 gap-2 sm:gap-0">\r
                                    @if (isWhitelisted(input.address)) {\r
                                        <svg lucideShieldCheck class="w-5 h-5 text-emerald-500 sm:mb-1.5"></svg>\r
                                        <span class="text-[9px] font-bold text-emerald-500 uppercase tracking-wider text-center">Verified Input</span>\r
                                    } @else {\r
                                        <svg lucideShieldAlert class="w-5 h-5 text-brand-text-muted sm:mb-1.5"></svg>\r
                                        <span class="text-[9px] font-bold text-brand-text-muted uppercase tracking-wider text-center">UnVerified Input</span>\r
                                    }\r
                                </div>\r
\r
                                <!-- Middle & Right Content Wrapper -->\r
                                <div class="flex flex-1 items-center justify-between p-3 gap-4">\r
                                    \r
                                    <!-- Middle Column: Details -->\r
                                    <div class="flex flex-col gap-2 flex-1 min-w-0">\r
                                        <div class="flex items-center gap-2">\r
                                            <!-- Label Badge -->\r
                                            <span class="text-xs text-brand-text bg-brand-card px-3 py-1 rounded border border-brand-card-border font-medium shadow-sm">\r
                                                Input #{{ $index }}\r
                                            </span>\r
                                            @if (input.txId && input.txId !== '????') {\r
                                                <span class="font-mono text-[10px] text-brand-text-muted truncate max-w-[120px]" title="TxID:Vout">{{ input.txId }}:{{ input.vout }}</span>\r
                                            }\r
                                        </div>\r
                                        \r
                                        <!-- Address Box -->\r
                                        <div class="flex items-center justify-between bg-brand-card border border-brand-card-border rounded-lg pl-3 pr-3 py-2 group">\r
                                            <span class="font-mono text-xs text-brand-text-muted break-all select-all mr-2">{{ input.address }}</span>\r
                                            \r
                                            <button (click)="copyAddress(input.address)" class="relative group/tooltip shrink-0 focus:outline-none cursor-pointer">\r
                                                @if (copiedAddress() === input.address) {\r
                                                    <svg lucideCheck class="w-4 h-4 transition-all duration-300 text-brand-accent scale-110"></svg>\r
                                                } @else {\r
                                                    <svg lucideCopy class="w-4 h-4 transition-all duration-300 text-brand-text-muted group-hover:text-brand-text"></svg>\r
                                                }\r
\r
                                                <!-- Tooltip -->\r
                                                <div class="absolute -top-9 left-1/2 -translate-x-1/2 bg-brand-card-border text-brand-text text-[10px] font-bold px-2.5 py-1 rounded opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                                                    {{ copiedAddress() === input.address ? 'Copied!' : 'Copy Address' }}\r
                                                </div>\r
                                            </button>\r
                                        </div>\r
                                    </div>\r
\r
                                    <!-- Right Column: Amount & Action -->\r
                                    <div class="flex flex-col items-end justify-between gap-3 shrink-0 min-w-[130px]">\r
                                        <div class="text-brand-text font-medium text-sm text-right">\r
                                            {{ input.amount / 100000000 | number:'1.8-8' }} <span class="text-brand-text-muted">BTC</span>\r
                                        </div>\r
                                        \r
                                        @if (socket.isCoordinator()) {\r
                                            <button (click)="toggleWhitelist(input.address)" \r
                                                    class="w-full py-1.5 px-4 rounded-lg transition-all text-xs font-bold text-center shadow-sm border cursor-pointer"\r
                                                    [class]="isWhitelisted(input.address) \r
                                                        ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20 hover:border-rose-500/50' \r
                                                        : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 hover:border-emerald-500/50'">\r
                                                {{ isWhitelisted(input.address) ? 'Revoke' : 'Verify' }}\r
                                            </button>\r
                                        }\r
                                    </div>\r
                                </div>\r
                            </div>\r
                        }\r
                        @if ((socket.txDetails()?.inputsList?.length || 0) === 0) { \r
                            <div class="text-center py-8 text-brand-text-muted text-sm">No input data available.</div> \r
                        } @else if (filteredInputs().length === 0) {\r
                            <div class="text-center py-8 text-brand-text-muted text-sm">No inputs match your search.</div>\r
                        }\r
                    }\r
\r
                    @if (viewMode() === 'outputs') {\r
                        @for (out of filteredOutputs(); track $index) {\r
                        <!-- Output Card Container -->\r
                        <div class="flex flex-col sm:flex-row items-stretch bg-brand-bg rounded-xl border transition-all overflow-hidden address-card" \r
                            [class.border-emerald-500]="isWhitelisted(out.address)" \r
                            [class.border-amber-500]="out.isChange" \r
                            [class.border-rose-900]="!out.isChange && !isWhitelisted(out.address) && (socket.roomState()?.whitelist?.length || 0) > 0" \r
                            [class.border-brand-card-border]="!out.isChange && !isWhitelisted(out.address) && (!socket.roomState()?.whitelist || socket.roomState()?.whitelist?.length === 0)">\r
                            \r
                            <!-- Left/Top Column: Status -->\r
                            <div class="verification-badge flex sm:flex-col items-center justify-center p-3 w-full sm:w-28 shrink-0 border-b sm:border-b-0 sm:border-r border-brand-card-border/80 gap-2 sm:gap-0">\r
                                @if (out.isChange) {\r
                                    <svg lucideShieldOff class="w-5 h-5 text-amber-500 sm:mb-1.5"></svg>\r
                                    <span class="text-[9px] font-bold text-amber-500 uppercase tracking-wider text-center">Change Output</span>\r
                                } @else if (isWhitelisted(out.address)) {\r
                                    <svg lucideShieldCheck class="w-5 h-5 text-emerald-500 sm:mb-1.5"></svg>\r
                                    <span class="text-[9px] font-bold text-emerald-500 uppercase tracking-wider text-center">Verified Output</span>\r
                                } @else if ((socket.roomState()?.whitelist?.length || 0) > 0) {\r
                                    <svg lucideShieldAlert class="w-5 h-5 text-rose-500 sm:mb-1.5"></svg>\r
                                    <span class="text-[9px] font-bold text-rose-500 uppercase tracking-wider text-center">Unverified Output</span>\r
                                } @else {\r
                                    <svg lucideShieldAlert class="w-5 h-5 text-brand-text-muted sm:mb-1.5"></svg>\r
                                    <span class="text-[9px] font-bold text-brand-text-muted uppercase tracking-wider text-center">Unverified Output</span>\r
                                }\r
                            </div>\r
\r
                            <!-- Middle & Right Content Wrapper -->\r
                            <div class="flex flex-1 items-center justify-between p-3 gap-4">\r
                                    \r
                                <!-- Middle Column: Details -->\r
                                <div class="flex flex-col gap-2 flex-1 min-w-0">\r
                                    <div class="flex items-center gap-2">\r
                                        <!-- Label Badge -->\r
                                        <span class="text-xs text-brand-text bg-brand-card px-3 py-1 rounded border border-brand-card-border font-medium shadow-sm">\r
                                            Output #{{ $index }}\r
                                        </span>\r
                                    </div>\r
                                    \r
                                    <!-- Address Box -->\r
                                    <div class="flex items-center justify-between bg-brand-card border border-brand-card-border rounded-lg pl-3 pr-3 py-2 group">\r
                                        <span class="font-mono text-xs text-brand-text-muted break-all select-all mr-2">{{ out.address }}</span>\r
                                        \r
                                        <button (click)="copyAddress(out.address)" class="relative group/tooltip shrink-0 focus:outline-none cursor-pointer">\r
                                            @if (copiedAddress() === out.address) {\r
                                                <svg lucideCheck class="w-4 h-4 transition-all duration-300 text-brand-accent scale-110"></svg>\r
                                            } @else {\r
                                                <svg lucideCopy class="w-4 h-4 transition-all duration-300 text-brand-text-muted group-hover:text-brand-text"></svg>\r
                                            }\r
\r
                                            <!-- Tooltip -->\r
                                            <div class="absolute -top-9 left-1/2 -translate-x-1/2 bg-brand-card-border text-brand-text text-[10px] font-bold px-2.5 py-1 rounded opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-brand-card-border shadow-xl z-[100]">\r
                                                {{ copiedAddress() === out.address ? 'Copied!' : 'Copy Address' }}\r
                                            </div>\r
                                        </button>\r
                                    </div>\r
                                </div>\r
\r
                                <!-- Right Column: Amount & Action -->\r
                                <div class="flex flex-col items-end justify-between gap-3 shrink-0 min-w-[130px]">\r
                                    <div class="text-brand-text font-medium text-sm text-right">\r
                                        {{ out.amount / 100000000 | number:'1.8-8' }} <span class="text-brand-text-muted">BTC</span>\r
                                    </div>\r
                                    \r
                                    @if (socket.isCoordinator()) {\r
                                        <button (click)="toggleWhitelist(out.address)" \r
                                                class="w-full py-1.5 px-4 rounded-lg transition-all text-xs font-bold text-center shadow-sm border cursor-pointer"\r
                                                [class]="isWhitelisted(out.address) \r
                                                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20 hover:border-rose-500/50' \r
                                                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 hover:border-emerald-500/50'">\r
                                            {{ isWhitelisted(out.address) ? 'Revoke' : 'Verify' }}\r
                                        </button>\r
                                    }\r
                                </div>\r
                            </div>\r
                        </div>\r
                        }\r
                        @if (!socket.txDetails()) { \r
                            <div class="text-brand-text-muted text-sm text-center">Parsing transaction data...</div> \r
                        } @else if (filteredOutputs().length === 0 && (socket.txDetails()?.outputs?.length || 0) > 0) {\r
                            <div class="text-center py-8 text-brand-text-muted text-sm">No outputs match your search.</div>\r
                        }\r
                    }\r
                </div>\r
            </div> \r
            @if (blurStates()['transaction-details']) {\r
                <div class="absolute inset-0 flex items-center justify-center z-10 mt-10">\r
                <button (click)="togglePrivacyBlur('transaction-details')" class="bg-brand-card-border/90 text-brand-text hover:bg-brand-card-border px-4 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 border border-brand-card-border shadow-xl backdrop-blur-sm transition-colors cursor-pointer">\r
                    <svg lucideEyeOff class="w-3.5 h-3.5"></svg>\r
                    Hidden for Privacy\r
                </button>\r
                </div>\r
            }\r
        </div>\r
    </div>\r
\r
    <div class="lg:col-span-1">\r
        <div id="card-signers-list" class="bg-brand-card border border-brand-card-border rounded-xl p-6 h-full flex flex-col relative overflow-hidden">\r
            \r
            <div class="flex justify-between items-center mb-4 relative z-20">\r
                <h2 class="text-lg font-semibold text-brand-text flex items-center gap-2">\r
                    <svg lucideUsers class="w-5 h-5 text-brand-text-muted"></svg>\r
                    Signers <span class="text-brand-text-muted text-sm font-medium">({{ socket.signerCount() }} Signed)</span>\r
                </h2>\r
                \r
                <button id="btn-reveal-signers"\r
                    (click)="togglePrivacyBlur('signers')" \r
                    class="p-2 rounded-lg hover:bg-brand-card-border/50 transition-colors flex items-center gap-2 cursor-pointer"\r
                    [class.text-amber-500]="!blurStates().signers"\r
                    [class.text-brand-text-muted]="blurStates().signers"\r
                    [title]="blurStates().signers ? 'Reveal Signers' : 'Hide Signers'">\r
                    @if (blurStates().signers) {\r
                        <svg lucideEyeOff class="w-5 h-5"></svg>\r
                    } @else {\r
                        <svg lucideEye class="w-5 h-5"></svg>\r
                    }\r
                </button>\r
            </div>\r
\r
            <div class="relative flex-grow flex flex-col">\r
                <div class="transition-all duration-300 flex-grow"\r
                        [class.blur-md]="blurStates().signers"\r
                        [class.opacity-30]="blurStates().signers"\r
                        [class.select-none]="blurStates().signers"\r
                        [class.pointer-events-none]="blurStates().signers">\r
                        \r
                    <div class="space-y-4">\r
        @for (signer of socket.signers(); track signer.fingerprint) {\r
            <div class="p-4 rounded-xl flex items-center justify-between border transition-all"\r
                    [class.bg-emerald-500/10]="signer.signed"\r
                    [class.border-emerald-500/30]="signer.signed"\r
                    [class.bg-brand-bg]="!signer.signed"\r
                    [class.border-brand-card-border]="!signer.signed">\r
                    \r
                <div class="flex items-center gap-3">\r
                    <div class="w-10 h-10 rounded-full flex items-center justify-center"\r
                            [class.bg-emerald-500/20]="signer.signed"\r
                            [class.text-emerald-400]="signer.signed"\r
                            [class.bg-brand-card]="!signer.signed"\r
                            [class.text-brand-text-muted]="!signer.signed">\r
                        @if (signer.signed) {\r
                            <svg lucideCheckCircle class="w-5 h-5"></svg>\r
                        } @else {\r
                            <svg lucideUser class="w-5 h-5"></svg>\r
                        }\r
                    </div>\r
                    <div>\r
                        @if (socket.isCoordinator()) {\r
                            <button (click)="openLabelModal(signer.fingerprint)" \r
                                    class="text-sm font-mono flex items-center gap-2 hover:bg-brand-card-border/50 -ml-1 px-1 py-0.5 rounded transition group/label text-left cursor-pointer">\r
                                \r
                                @if (getLabel(signer.fingerprint); as label) {\r
                                    <span class="text-brand-text font-bold">{{ label }}</span>\r
                                    <span class="text-brand-text-muted text-xs">({{ signer.fingerprint }})</span>\r
                                    <svg lucideEdit2 class="w-3 h-3 text-brand-text-muted group-hover/label:text-brand-accent opacity-0 group-hover/label:opacity-100 transition"></svg>\r
                                } @else {\r
                                    <span class="text-brand-accent/90 italic">Add Label</span>\r
                                    <span class="text-brand-text-muted text-xs">({{ signer.fingerprint }})</span>\r
                                    <svg lucideTag class="w-3 h-3 text-brand-accent/50 group-hover/label:text-brand-accent"></svg>\r
                                }\r
                            </button>\r
                        } @else {\r
                            <div class="text-brand-text font-medium text-sm font-mono">\r
                                {{ getSignerLabel(signer.fingerprint) }}\r
                            </div>\r
                        }\r
\r
                        <div class="flex items-center gap-3">\r
                            <div>\r
                            <div class="flex items-center gap-2">\r
                                    <div class="text-xs font-medium" [class.text-emerald-400]="signer.signed" [class.text-brand-text-muted]="!signer.signed">\r
                                        {{ signer.signed ? 'Signed' : 'Waiting...' }}\r
                                    </div>\r
\r
                                    @if (socket.isCoordinator() && !signer.signed) {\r
                                        <button (click)="nudgeSigner(signer.fingerprint)" \r
                                                class="p-1 text-brand-text-muted hover:text-amber-400 transition cursor-pointer" \r
                                                title="Copy Nudge Message">\r
                                            <svg lucideBell class="w-3 h-3"></svg>\r
                                        </button>\r
                                    }\r
                                </div>\r
                            </div>\r
                        </div>\r
                    </div>\r
                </div>\r
                @if (!signer.signed) { <svg lucideLoader2 class="w-4 h-4 text-brand-text-muted animate-spin"></svg> }\r
            </div>\r
        }\r
        @if (socket.signers().length === 0) { <div class="text-center p-4 text-brand-text-muted text-sm">Loading Signers...</div> }\r
    </div>\r
                </div>\r
\r
                @if (blurStates().signers) {\r
                    <div class="absolute inset-0 flex items-center justify-center z-10">\r
                        <button (click)="togglePrivacyBlur('signers')" class="bg-brand-card-border/90 text-brand-text hover:bg-brand-card-border px-4 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 border border-brand-card-border shadow-xl backdrop-blur-sm -mt-10 transition-colors cursor-pointer">\r
                            <svg lucideEyeOff class="w-3.5 h-3.5"></svg>\r
                            Hidden for Privacy\r
                        </button>\r
                    </div>\r
                }\r
            </div>\r
\r
            <div id="card-finalization-status" class="mt-8 pt-6 border-t border-brand-card-border relative z-20">\r
                @if (finalHex()) {\r
                    <div class="bg-brand-accent/10 border border-brand-accent/30 rounded-xl p-4 animate-fade-in-up">\r
                        <div class="flex items-center gap-3 mb-4">\r
                            <div class="w-10 h-10 rounded-full bg-brand-accent flex items-center justify-center text-brand-bg shadow-lg shadow-brand-accent/20">\r
                                <svg lucideShield class="w-5 h-5"></svg>\r
                            </div>\r
                            <div>\r
                                <h4 class="text-brand-text font-bold text-sm">Transaction Signed</h4>\r
                                <p class="text-brand-accent text-xs">\r
                                    {{ socket.isCoordinator() ? 'Ready to broadcast' : 'Awaiting Coordinator broadcast' }}\r
                                </p>\r
                            </div>\r
                        </div>\r
                        \r
                        @if (socket.isCoordinator()) {\r
                            <div class="grid gap-3" [class.grid-cols-2]="!isEmbedded" [class.grid-cols-1]="isEmbedded">\r
                                <button id="btn-copy-final-hex" (click)="copyHex()" class="py-2 px-3 bg-brand-card-border/50 hover:bg-brand-card-border text-brand-text text-xs font-bold rounded-lg border border-brand-card-border transition flex items-center justify-center gap-2 cursor-pointer">\r
                                    @if (copied()) {\r
                                        <svg lucideCheck class="w-3 h-3"></svg>\r
                                    } @else {\r
                                        <svg lucideCopy class="w-3 h-3"></svg>\r
                                    }\r
                                    {{ copied() ? 'Copied' : 'Copy Hex' }}\r
                                </button>\r
                                \r
                                @if (!isEmbedded) {\r
                                    <button id="btn-broadcast-transaction" (click)="broadcastAndCopy()" class="py-2 px-3 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg text-xs font-bold rounded-lg transition flex items-center justify-center gap-2 text-center decoration-0 cursor-pointer">\r
                                        Broadcast <svg lucideExternalLink class="w-3 h-3"></svg>\r
                                    </button>\r
                                }\r
                            </div>\r
                        }\r
                    </div>\r
                } @else if (socket.isReadyToBroadcast()) {  \r
                    @if (socket.isCoordinator()) {\r
                        <button id="btn-finalize-transaction" (click)="finalize()" class="w-full py-3.5 bg-brand-accent hover:bg-brand-accent-hover text-brand-bg font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-accent/20 cursor-pointer">\r
                            <svg lucideShield class="w-4 h-4"></svg> \r
                            Finalize Transaction ({{ socket.signerCount() }}/{{ socket.signerThreshold() }})\r
                        </button>\r
                    } @else { <p class="text-xs text-center text-brand-text-muted">Only the Coordinator can finalize.</p> }\r
                } @else if (socket.isCoordinator()) {\r
                    <button disabled class="w-full py-3.5 bg-brand-card-border text-brand-text-muted font-bold rounded-xl border border-brand-card-border cursor-not-allowed flex items-center justify-center gap-2">\r
                        <svg lucideLoader2 class="w-4 h-4 animate-spin"></svg> \r
                        <span>Waiting for Signatures ({{ socket.signerCount() }} / {{ socket.signerThreshold() }})</span>\r
                    </button>\r
                } @else {\r
                    <div class="text-center p-4">\r
                        <p class="text-sm text-brand-text-muted font-medium mb-1">Waiting for Finalization</p>\r
                        <p class="text-xs text-brand-text-muted mb-4">{{ Math.max(0, socket.signerThreshold() - (socket.signerCount() || 0)) }} more signatures required</p>\r
                        @if (!showClaimInput()) {\r
                            <button id="btn-claim-coordinator" (click)="showClaimInput.set(true)" class="text-xs text-brand-text-muted hover:text-brand-accent underline transition cursor-pointer">Have the Admin Key? Claim Coordinator Role</button>\r
                        } @else {\r
                            <div class="flex gap-2 justify-center mt-2 animate-fade-in-up">\r
                                <input type="password" [(ngModel)]="claimPassword" placeholder="Paste Admin Key here..." class="bg-brand-bg border border-brand-card-border rounded px-2 py-1 text-xs text-brand-text focus:border-brand-accent outline-none w-48 font-mono"/>\r
                                <button (click)="claimRole()" class="px-3 py-1 bg-brand-accent/20 text-brand-accent text-xs rounded hover:bg-brand-accent/30 transition border border-brand-accent/20 cursor-pointer">Claim</button>\r
                            </div>\r
                        }\r
                    </div>\r
                }\r
            </div>\r
        </div>\r
    </div>\r
    </div>\r
</div>` }]
  }], () => [{ type: i1.ActivatedRoute }, { type: SocketService }, { type: i1.Router }, { type: i3.Title }, { type: UrService }, { type: Object, decorators: [{
    type: Inject,
    args: [PLATFORM_ID]
  }] }, { type: WidgetDispatcherService }, { type: EncryptionEngine }, { type: ConfigService }], { unloadNotification: [{
    type: HostListener,
    args: ["window:beforeunload", ["$event"]]
  }], onBeforeUnload: [{
    type: HostListener,
    args: ["window:beforeunload"]
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(RoomComponent, { className: "RoomComponent", filePath: "apps/client/src/app/pages/room/room.component.ts", lineNumber: 122 });
})();
(() => {
  const id = "apps%2Fclient%2Fsrc%2Fapp%2Fpages%2Froom%2Froom.component.ts%40RoomComponent";
  function RoomComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(RoomComponent, m.default, [i0, i8, i9, i1, socket_service_exports, i3, ur_service_exports, widget_dispatcher_service_exports, src_exports, config_service_exports], [EncryptionEngine, CommonModule, FormsModule, RouterModule, LucideShield, LucideUsers, LucideCheckCircle, LucideLoader2, LucideCopy, LucideClock, LucideArrowRight, LucideHash, LucideCrown, LucideUploadCloud, LucideDownloadCloud, LucideDownload, LucideExternalLink, LucideCheck, LucideZap, LucideAlertTriangle, LucidePower, LucideX, LucideLock, LucideUnlock, LucideKey, LucideRefreshCw, LucideAlertOctagon, LucideFileKey, LucideFileCheck, LucideEdit2, LucideTag, LucideBell, LucideQrCode, LucideEye, LucideEyeOff, LucideSearch, LucideNetwork, LucideShieldAlert, LucideShieldCheck, LucideShieldOff, LucideUser, PLATFORM_ID, Component, Inject, HostListener], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && RoomComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && RoomComponent_HmrLoad(d.timestamp)));
})();
export {
  RoomComponent
};
//# debugId=e7f9b917-8890-52f2-8f4d-245bf41c50eb


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcHMvY2xpZW50L3NyYy9hcHAvcGFnZXMvcm9vbS9yb29tLmNvbXBvbmVudC50cyIsImFwcHMvY2xpZW50L3NyYy9hcHAvcGFnZXMvcm9vbS9yb29tLmNvbXBvbmVudC5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIENvcHlyaWdodCAoQykgMjAyNiBTdGF0ZWxlc3MgUmVzZWFyY2ggTHRkXHJcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBHTlUgQWZmZXJvIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgdjMuMFxyXG4gKi9cclxuXHJcbmltcG9ydCB7XHJcbiAgQ29tcG9uZW50LFxyXG4gIE9uSW5pdCxcclxuICBzaWduYWwsXHJcbiAgY29tcHV0ZWQsXHJcbiAgT25EZXN0cm95LFxyXG4gIGVmZmVjdCxcclxuICBJbmplY3QsXHJcbiAgUExBVEZPUk1fSUQsXHJcbiAgSG9zdExpc3RlbmVyLFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUsIGlzUGxhdGZvcm1Ccm93c2VyIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUsIFJvdXRlciwgUm91dGVyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IFRpdGxlIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7XHJcbiAgTHVjaWRlU2hpZWxkLFxyXG4gIEx1Y2lkZVVzZXJzLFxyXG4gIEx1Y2lkZUNoZWNrQ2lyY2xlLFxyXG4gIEx1Y2lkZUxvYWRlcjIsXHJcbiAgTHVjaWRlQ29weSxcclxuICBMdWNpZGVDbG9jayxcclxuICBMdWNpZGVBcnJvd1JpZ2h0LFxyXG4gIEx1Y2lkZUhhc2gsXHJcbiAgTHVjaWRlQ3Jvd24sXHJcbiAgTHVjaWRlVXBsb2FkQ2xvdWQsXHJcbiAgTHVjaWRlRG93bmxvYWRDbG91ZCxcclxuICBMdWNpZGVEb3dubG9hZCxcclxuICBMdWNpZGVFeHRlcm5hbExpbmssXHJcbiAgTHVjaWRlQ2hlY2ssXHJcbiAgTHVjaWRlWmFwLFxyXG4gIEx1Y2lkZUFsZXJ0VHJpYW5nbGUsXHJcbiAgTHVjaWRlUG93ZXIsXHJcbiAgTHVjaWRlWCxcclxuICBMdWNpZGVMb2NrLFxyXG4gIEx1Y2lkZVVubG9jayxcclxuICBMdWNpZGVLZXksXHJcbiAgTHVjaWRlUmVmcmVzaEN3LFxyXG4gIEx1Y2lkZUFsZXJ0T2N0YWdvbixcclxuICBMdWNpZGVGaWxlS2V5LFxyXG4gIEx1Y2lkZUZpbGVDaGVjayxcclxuICBMdWNpZGVFZGl0MixcclxuICBMdWNpZGVUYWcsXHJcbiAgTHVjaWRlQmVsbCxcclxuICBMdWNpZGVJbmZpbml0eSxcclxuICBMdWNpZGVBcnJvd0Rvd24sXHJcbiAgTHVjaWRlQm9vayxcclxuICBMdWNpZGVRckNvZGUsXHJcbiAgTHVjaWRlRXllLFxyXG4gIEx1Y2lkZUV5ZU9mZixcclxuICBMdWNpZGVTZWFyY2gsXHJcbiAgTHVjaWRlRmlsZVRleHQsXHJcbiAgTHVjaWRlTmV0d29yayxcclxuICBMdWNpZGVTaGllbGRBbGVydCxcclxuICBMdWNpZGVTaGllbGRDaGVjayxcclxuICBMdWNpZGVTaGllbGRPZmYsXHJcbiAgTHVjaWRlVXNlcixcclxufSBmcm9tICdAbHVjaWRlL2FuZ3VsYXInO1xyXG5pbXBvcnQgeyBTb2NrZXRTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvc29ja2V0L3NvY2tldC5zZXJ2aWNlJztcclxuaW1wb3J0ICogYXMgUVJDb2RlIGZyb20gJ3FyY29kZSc7XHJcbmltcG9ydCB7IEh0bWw1UXJjb2RlLCBIdG1sNVFyY29kZVN1cHBvcnRlZEZvcm1hdHMgfSBmcm9tICdodG1sNS1xcmNvZGUnO1xyXG5pbXBvcnQgeyBVclNlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy91ci91ci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgYmFzZTY0LCBoZXggfSBmcm9tICdAc2N1cmUvYmFzZSc7XHJcbmltcG9ydCB7IFdpZGdldERpc3BhdGNoZXJTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvd2lkZ2V0LWRpc3BhdGNoZXIvd2lkZ2V0LWRpc3BhdGNoZXIuc2VydmljZSc7XHJcbmltcG9ydCB7IFByaXZhY3lTZWN0aW9uLCBQcml2YWN5U3RhdGUgfSBmcm9tICcuLi8uLi9tb2RlbHMvd2lkZ2V0LWV2ZW50cy5tb2RlbCc7XHJcbmltcG9ydCB7IEVuY3J5cHRpb25FbmdpbmUgfSBmcm9tICdAc2lnbmluZy1yb29tL3Nkayc7XHJcbmltcG9ydCB7IENvbmZpZ1NlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9jb25maWcvY29uZmlnLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcm9vbScsXHJcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcclxuICBpbXBvcnRzOiBbXHJcbiAgICBDb21tb25Nb2R1bGUsXHJcbiAgICBGb3Jtc01vZHVsZSxcclxuICAgIFJvdXRlck1vZHVsZSxcclxuICAgIEx1Y2lkZVNoaWVsZCxcclxuICAgIEx1Y2lkZVVzZXJzLFxyXG4gICAgTHVjaWRlQ2hlY2tDaXJjbGUsXHJcbiAgICBMdWNpZGVMb2FkZXIyLFxyXG4gICAgTHVjaWRlQ29weSxcclxuICAgIEx1Y2lkZUNsb2NrLFxyXG4gICAgTHVjaWRlQXJyb3dSaWdodCxcclxuICAgIEx1Y2lkZUhhc2gsXHJcbiAgICBMdWNpZGVDcm93bixcclxuICAgIEx1Y2lkZVVwbG9hZENsb3VkLFxyXG4gICAgTHVjaWRlRG93bmxvYWRDbG91ZCxcclxuICAgIEx1Y2lkZURvd25sb2FkLFxyXG4gICAgTHVjaWRlRXh0ZXJuYWxMaW5rLFxyXG4gICAgTHVjaWRlQ2hlY2ssXHJcbiAgICBMdWNpZGVaYXAsXHJcbiAgICBMdWNpZGVBbGVydFRyaWFuZ2xlLFxyXG4gICAgTHVjaWRlUG93ZXIsXHJcbiAgICBMdWNpZGVYLFxyXG4gICAgTHVjaWRlTG9jayxcclxuICAgIEx1Y2lkZVVubG9jayxcclxuICAgIEx1Y2lkZUtleSxcclxuICAgIEx1Y2lkZVJlZnJlc2hDdyxcclxuICAgIEx1Y2lkZUFsZXJ0T2N0YWdvbixcclxuICAgIEx1Y2lkZUZpbGVLZXksXHJcbiAgICBMdWNpZGVGaWxlQ2hlY2ssXHJcbiAgICBMdWNpZGVFZGl0MixcclxuICAgIEx1Y2lkZVRhZyxcclxuICAgIEx1Y2lkZUJlbGwsXHJcbiAgICBMdWNpZGVRckNvZGUsXHJcbiAgICBMdWNpZGVFeWUsXHJcbiAgICBMdWNpZGVFeWVPZmYsXHJcbiAgICBMdWNpZGVTZWFyY2gsXHJcbiAgICBMdWNpZGVOZXR3b3JrLFxyXG4gICAgTHVjaWRlU2hpZWxkQWxlcnQsXHJcbiAgICBMdWNpZGVTaGllbGRDaGVjayxcclxuICAgIEx1Y2lkZVNoaWVsZE9mZixcclxuICAgIEx1Y2lkZVVzZXIsXHJcbiAgXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vcm9vbS5jb21wb25lbnQuaHRtbCcsXHJcbiAgcHJvdmlkZXJzOiBbRW5jcnlwdGlvbkVuZ2luZV0sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBSb29tQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkRlc3Ryb3kge1xyXG4gIEBIb3N0TGlzdGVuZXIoJ3dpbmRvdzpiZWZvcmV1bmxvYWQnLCBbJyRldmVudCddKVxyXG4gIHVubG9hZE5vdGlmaWNhdGlvbigkZXZlbnQ6IGFueSkge1xyXG4gICAgaWYgKHRoaXMuc29ja2V0LnN0YXR1cygpID09PSAnY29ubmVjdGVkJyAmJiAhdGhpcy5maW5hbEhleCgpICYmICF0aGlzLnNvY2tldC5pc0Nsb3NlZCgpKSB7XHJcbiAgICAgICRldmVudC5yZXR1cm5WYWx1ZSA9IHRydWU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBASG9zdExpc3RlbmVyKCd3aW5kb3c6YmVmb3JldW5sb2FkJylcclxuICBvbkJlZm9yZVVubG9hZCgpIHtcclxuICAgIHRoaXMuc29ja2V0LmRpc2Nvbm5lY3QoKTtcclxuICB9XHJcblxyXG4gIC8vIE1hdGggaXMgc3RpbGwgcmVxdWlyZWQgZm9yIHRlbXBsYXRlIGNhbGN1bGF0aW9uc1xyXG4gIHJlYWRvbmx5IE1hdGggPSBNYXRoO1xyXG5cclxuICBwdWJsaWMgcm9vbUlkID0gc2lnbmFsPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIHB1YmxpYyB2aWV3TW9kZSA9IHNpZ25hbDwnaW5wdXRzJyB8ICdvdXRwdXRzJz4oJ291dHB1dHMnKTtcclxuICBwdWJsaWMgaXNVcGxvYWRpbmcgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBzaG93UmVuYW1lTW9kYWwgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBuZXdSb29tTmFtZSA9IHNpZ25hbCgnJyk7XHJcblxyXG4gIHB1YmxpYyBzaG93UXJNb2RhbCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIHNob3dTZXNzaW9uc01vZGFsID0gc2lnbmFsKGZhbHNlKTtcclxuICBwdWJsaWMgc2hvd0tleU1vZGFsID0gc2lnbmFsKGZhbHNlKTtcclxuICBwdWJsaWMgc2hvd0FkbWluTW9kYWwgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBzaG93Um9vbUlkTW9kYWwgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBzaG93QXVkaXRNb2RhbCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIHNob3dDc3ZNb2RhbCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIHNob3dQc2J0TW9kYWwgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBwZXJzb25hbERpc3BsYXlOYW1lID0gc2lnbmFsKCcnKTtcclxuICBwdWJsaWMgY29waWVkU2Vzc2lvbklkID0gc2lnbmFsPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIHB1YmxpYyBpc1FyUmV2ZWFsZWQgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBxckRhdGFVcmwgPSBzaWduYWw8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgcHVibGljIHFySW5jbHVkZXNLZXkgPSBzaWduYWwoZmFsc2UpO1xyXG5cclxuICBwdWJsaWMgdGltZVJlbWFpbmluZyA9IHNpZ25hbCgnTG9hZGluZy4uLicpO1xyXG4gIHB1YmxpYyBpc0V4cGlyZWQgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBpc0xvd1RpbWUgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHByaXZhdGUgdGltZXJJbnRlcnZhbDogYW55O1xyXG5cclxuICBwdWJsaWMgaW5wdXRTZWFyY2hRdWVyeSA9IHNpZ25hbCgnJyk7XHJcbiAgcHVibGljIG91dHB1dFNlYXJjaFF1ZXJ5ID0gc2lnbmFsKCcnKTtcclxuXHJcbiAgcHVibGljIGZpbHRlcmVkSW5wdXRzID0gY29tcHV0ZWQoKCkgPT4ge1xyXG4gICAgY29uc3QgaW5wdXRzID0gdGhpcy5zb2NrZXQudHhEZXRhaWxzKCk/LmlucHV0c0xpc3QgfHwgW107XHJcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMuaW5wdXRTZWFyY2hRdWVyeSgpLnRvTG93ZXJDYXNlKCkudHJpbSgpO1xyXG4gICAgaWYgKCFxdWVyeSkgcmV0dXJuIGlucHV0cztcclxuICAgIHJldHVybiBpbnB1dHMuZmlsdGVyKChpbnB1dCkgPT4gaW5wdXQuYWRkcmVzcy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KSk7XHJcbiAgfSk7XHJcblxyXG4gIHB1YmxpYyBmaWx0ZXJlZE91dHB1dHMgPSBjb21wdXRlZCgoKSA9PiB7XHJcbiAgICBjb25zdCBvdXRwdXRzID0gdGhpcy5zb2NrZXQudHhEZXRhaWxzKCk/Lm91dHB1dHMgfHwgW107XHJcbiAgICBjb25zdCBxdWVyeSA9IHRoaXMub3V0cHV0U2VhcmNoUXVlcnkoKS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuICAgIGlmICghcXVlcnkpIHJldHVybiBvdXRwdXRzO1xyXG4gICAgcmV0dXJuIG91dHB1dHMuZmlsdGVyKChvdXRwdXQpID0+IG91dHB1dC5hZGRyZXNzLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkpKTtcclxuICB9KTtcclxuXHJcbiAgcHVibGljIHNob3dMYWJlbE1vZGFsID0gc2lnbmFsKGZhbHNlKTtcclxuICBwdWJsaWMgc2hvd0NsYWltSW5wdXQgPSBzaWduYWwoZmFsc2UpO1xyXG5cclxuICBwdWJsaWMgc2hvd0NvbmZpcm1Nb2RhbCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIGNvbmZpcm1EYXRhID0gc2lnbmFsKHtcclxuICAgIHRpdGxlOiAnJyxcclxuICAgIG1lc3NhZ2U6ICcnLFxyXG4gICAgYWN0aW9uOiAoKSA9PiB7fSxcclxuICAgIGlzRGVzdHJ1Y3RpdmU6IGZhbHNlLFxyXG4gICAgdHlwZTogJ2NvbmZpcm0nIGFzICdjb25maXJtJyB8ICdhbGVydCcsXHJcbiAgfSk7XHJcblxyXG4gIHB1YmxpYyBmaW5hbEhleCA9IGNvbXB1dGVkKCgpID0+IHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpPy5maW5hbFR4SGV4IHx8IG51bGwpO1xyXG4gIHB1YmxpYyBjb3BpZWQgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBzaG93U2hhcmVNb2RhbCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIHNlY3VyZUxpbmtDb3BpZWQgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBmdWxsTGlua0NvcGllZCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIGtleUNvcGllZCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIGFkbWluQ29waWVkID0gc2lnbmFsKGZhbHNlKTtcclxuICBwdWJsaWMgcm9vbUlkQ29waWVkID0gc2lnbmFsKGZhbHNlKTtcclxuXHJcbiAgcHVibGljIGNsYWltUGFzc3dvcmQgPSAnJztcclxuICBwdWJsaWMgbWFudWFsS2V5ID0gJyc7XHJcblxyXG4gIHByaXZhdGUgcHJldmlvdXNTZXNzaW9uczogeyBpZDogc3RyaW5nOyByb2xlOiBzdHJpbmc7IGRpc3BsYXlOYW1lPzogc3RyaW5nIH1bXSA9IFtdO1xyXG5cclxuICBwdWJsaWMgZWRpdGluZ0ZpbmdlcnByaW50ID0gc2lnbmFsPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIHB1YmxpYyBlZGl0aW5nTGFiZWwgPSBzaWduYWwoJycpO1xyXG4gIHB1YmxpYyBzYXZlVG9Cb29rID0gc2lnbmFsKHRydWUpO1xyXG5cclxuICBwcml2YXRlIGhhc0VtaXR0ZWRGaW5hbGl6ZWQgPSBmYWxzZTtcclxuICBwdWJsaWMgZXhwZWN0ZWRIb3N0ID0gJyc7XHJcblxyXG4gIHB1YmxpYyBodG1sNVFyQ29kZTogSHRtbDVRcmNvZGUgfCBudWxsID0gbnVsbDtcclxuICBpc1NjYW5uaW5nU2lnbmVkID0gc2lnbmFsPGJvb2xlYW4+KGZhbHNlKTtcclxuICBzaG93Rm91bnRhaW5Nb2RhbCA9IHNpZ25hbDxib29sZWFuPihmYWxzZSk7XHJcbiAgaXNGb3VudGFpblJldmVhbGVkID0gc2lnbmFsPGJvb2xlYW4+KGZhbHNlKTtcclxuICBzaG93U2Nhbm5lck1vZGFsID0gc2lnbmFsPGJvb2xlYW4+KGZhbHNlKTtcclxuICBjb3BpZWRBZGRyZXNzID0gc2lnbmFsPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGV4cG9ydEZvcm1hdCA9IHNpZ25hbDwndXInIHwgJ2JicXInPigndXInKTtcclxuICBhY3RpdmVGb3VudGFpbkZyYW1lczogc3RyaW5nW10gPSBbXTtcclxuICBjdXJyZW50RnJhbWVJbmRleCA9IHNpZ25hbDxudW1iZXI+KDApO1xyXG4gIGZvdW50YWluSW50ZXJ2YWw6IGFueTtcclxuICBmb3VudGFpblNwZWVkID0gc2lnbmFsPG51bWJlcj4oNDAwKTtcclxuXHJcbiAgY29uc3RydWN0b3IoXHJcbiAgICBwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxcclxuICAgIHB1YmxpYyBzb2NrZXQ6IFNvY2tldFNlcnZpY2UsXHJcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyLFxyXG4gICAgcHJpdmF0ZSB0aXRsZVNlcnZpY2U6IFRpdGxlLFxyXG4gICAgcHVibGljIHVyU2VydmljZTogVXJTZXJ2aWNlLFxyXG4gICAgQEluamVjdChQTEFURk9STV9JRCkgcHJpdmF0ZSBwbGF0Zm9ybUlkOiBPYmplY3QsXHJcbiAgICBwcml2YXRlIGRpc3BhdGNoZXI6IFdpZGdldERpc3BhdGNoZXJTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBlbmNyeXB0aW9uRW5naW5lOiBFbmNyeXB0aW9uRW5naW5lLFxyXG4gICAgcHVibGljIHJlYWRvbmx5IGNvbmZpZ1NlcnZpY2U6IENvbmZpZ1NlcnZpY2UsXHJcbiAgKSB7XHJcbiAgICBlZmZlY3QoKCkgPT4ge1xyXG4gICAgICBjb25zdCBzdGF0dXMgPSB0aGlzLnNvY2tldC5zdGF0dXMoKTtcclxuICAgICAgY29uc3QgY3VycmVudEZyYWdtZW50ID0gdGhpcy5yb3V0ZS5zbmFwc2hvdC5mcmFnbWVudDtcclxuXHJcbiAgICAgIGlmIChzdGF0dXMgPT09ICdjb25uZWN0ZWQnICYmIGN1cnJlbnRGcmFnbWVudCkge1xyXG4gICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFtdLCB7XHJcbiAgICAgICAgICByZWxhdGl2ZVRvOiB0aGlzLnJvdXRlLFxyXG4gICAgICAgICAgZnJhZ21lbnQ6IHVuZGVmaW5lZCxcclxuICAgICAgICAgIHJlcGxhY2VVcmw6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIGVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGlmICghaXNQbGF0Zm9ybUJyb3dzZXIodGhpcy5wbGF0Zm9ybUlkKSkgcmV0dXJuO1xyXG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpO1xyXG5cclxuICAgICAgaWYgKFxyXG4gICAgICAgIHRoaXMuc29ja2V0LmlzTG9ja2VkT3V0KCkgfHxcclxuICAgICAgICB0aGlzLnNvY2tldC5yb29tTm90Rm91bmQoKSB8fFxyXG4gICAgICAgIHRoaXMuc29ja2V0LmRlY3J5cHRpb25FcnJvcigpIHx8XHJcbiAgICAgICAgdGhpcy5zb2NrZXQuaXNSb29tRnVsbCgpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHN0YXRlKSB7XHJcbiAgICAgICAgaWYgKHN0YXRlLmNyZWF0ZWRBdCkgdGhpcy5zdGFydFRpbWVyKHN0YXRlLmV4cGlyZXNBdCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0aGlzLnNvY2tldC5pc0Nsb3NlZCgpKSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzRW1iZWRkZWQpIHtcclxuICAgICAgICAgIHRoaXMuZ2VuZXJhdGVBdWRpdExvZygpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgZWZmZWN0KCgpID0+IHtcclxuICAgICAgaWYgKHRoaXMuc29ja2V0LmlzQ29vcmRpbmF0b3IoKSkge1xyXG4gICAgICAgIGNvbnN0IF8gPSB0aGlzLnNvY2tldC5zaWduZXJzKCk7XHJcbiAgICAgICAgdGhpcy5zb2NrZXQuY2hlY2tBbmRBcHBseUxvY2FsTGFiZWxzKCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIGVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHN0YXRlID0gdGhpcy5zb2NrZXQucm9vbVN0YXRlKCk7XHJcbiAgICAgIGNvbnN0IHNpZ25lcnMgPSB0aGlzLnNvY2tldC5zaWduZXJzKCk7XHJcblxyXG4gICAgICBjb25zdCBzaWduZWRDb3VudCA9IHNpZ25lcnMuZmlsdGVyKChzKSA9PiBzLnNpZ25lZCkubGVuZ3RoO1xyXG4gICAgICBjb25zdCB0aHJlc2hvbGQgPSB0aGlzLnJlcXVpcmVkU2lnbmF0dXJlcztcclxuICAgICAgY29uc3QgcmVtYWluaW5nID0gTWF0aC5tYXgoMCwgdGhyZXNob2xkIC0gc2lnbmVkQ291bnQpO1xyXG5cclxuICAgICAgY29uc3QgY29uZmlnID0gdGhpcy5jb25maWdTZXJ2aWNlLmNvbmZpZygpO1xyXG4gICAgICBjb25zdCBicmFuZE5hbWUgPSBjb25maWcuYnJhbmROYW1lICsgKGNvbmZpZy5icmFuZFN1ZmZpeCB8fCAnJyk7XHJcblxyXG4gICAgICBpZiAodGhpcy5maW5hbEhleCgpKSB7XHJcbiAgICAgICAgdGhpcy50aXRsZVNlcnZpY2Uuc2V0VGl0bGUoYOKchSBSZWFkeSB0byBCcm9hZGNhc3QgfCAke2JyYW5kTmFtZX1gKTtcclxuICAgICAgfSBlbHNlIGlmIChzaWduZWRDb3VudCA+PSB0aHJlc2hvbGQpIHtcclxuICAgICAgICB0aGlzLnRpdGxlU2VydmljZS5zZXRUaXRsZShg8J+foCBSZWFkeSB0byBGaW5hbGl6ZSB8ICR7YnJhbmROYW1lfWApO1xyXG4gICAgICB9IGVsc2UgaWYgKHN0YXRlPy5pc0xvY2tlZCkge1xyXG4gICAgICAgIHRoaXMudGl0bGVTZXJ2aWNlLnNldFRpdGxlKGDwn5SSIFJvb20gTG9ja2VkIHwgJHticmFuZE5hbWV9YCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy50aXRsZVNlcnZpY2Uuc2V0VGl0bGUoYPCflLQgJHtyZW1haW5pbmd9IE5lZWRlZCB8ICR7YnJhbmROYW1lfWApO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyAtLS0gUEFSVElDSVBBTlQgUFJFU0VOQ0UgVFJBQ0tFUiAtLS1cclxuICAgIGVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRTZXNzaW9ucyA9IHRoaXMuc29ja2V0LmFjdGl2ZVNlc3Npb25zKCk7XHJcblxyXG4gICAgICBpZiAodGhpcy5zb2NrZXQuc3RhdHVzKCkgPT09ICdjb25uZWN0ZWQnKSB7XHJcbiAgICAgICAgY29uc3Qgam9pbmVkID0gY3VycmVudFNlc3Npb25zLmZpbHRlcihcclxuICAgICAgICAgIChjcykgPT4gIXRoaXMucHJldmlvdXNTZXNzaW9ucy5zb21lKChwcykgPT4gcHMuaWQgPT09IGNzLmlkKSxcclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGxlZnQgPSB0aGlzLnByZXZpb3VzU2Vzc2lvbnMuZmlsdGVyKFxyXG4gICAgICAgICAgKHBzKSA9PiAhY3VycmVudFNlc3Npb25zLnNvbWUoKGNzKSA9PiBjcy5pZCA9PT0gcHMuaWQpLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIEZpbmQgdXNlcnMgd2hvIGp1c3QgY2hhbmdlZCB0aGVpciBkaXNwbGF5IG5hbWUhXHJcbiAgICAgICAgY29uc3QgbmFtZUNoYW5nZWQgPSBjdXJyZW50U2Vzc2lvbnMuZmlsdGVyKChjcykgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcHJldiA9IHRoaXMucHJldmlvdXNTZXNzaW9ucy5maW5kKChwcykgPT4gcHMuaWQgPT09IGNzLmlkKTtcclxuICAgICAgICAgIHJldHVybiBwcmV2ICYmIHByZXYuZGlzcGxheU5hbWUgIT09IGNzLmRpc3BsYXlOYW1lO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBqb2luZWQuZm9yRWFjaCgocCkgPT5cclxuICAgICAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0UGFydGljaXBhbnRQcmVzZW5jZSgnam9pbmVkJywgcC5pZCwgcC5yb2xlLCBwLmRpc3BsYXlOYW1lKSxcclxuICAgICAgICApO1xyXG4gICAgICAgIGxlZnQuZm9yRWFjaCgocCkgPT5cclxuICAgICAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0UGFydGljaXBhbnRQcmVzZW5jZSgnbGVmdCcsIHAuaWQsIHAucm9sZSwgcC5kaXNwbGF5TmFtZSksXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgbmFtZUNoYW5nZWQuZm9yRWFjaCgocCkgPT4ge1xyXG4gICAgICAgICAgLy8gT25seSBicm9hZGNhc3QgaWYgaXQncyBzb21lb25lIEVMU0UgKG91ciBvd24gbG9jYWwgc2F2ZSBoYW5kbGVzICdzZWxmJylcclxuICAgICAgICAgIGlmIChwLmlkICE9PSB0aGlzLnNvY2tldC5jdXJyZW50U2Vzc2lvbklkKCkpIHtcclxuICAgICAgICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRQYXJ0aWNpcGFudExhYmVsbGVkKFxyXG4gICAgICAgICAgICAgICdwYXJ0aWNpcGFudCcsXHJcbiAgICAgICAgICAgICAgcC5kaXNwbGF5TmFtZSB8fCAnQW5vbnltb3VzJyxcclxuICAgICAgICAgICAgICB1bmRlZmluZWQsXHJcbiAgICAgICAgICAgICAgcC5pZCxcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgdGhpcy5wcmV2aW91c1Nlc3Npb25zID0gY3VycmVudFNlc3Npb25zO1xyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gLS0tIFNJR05BVFVSRSBORVRXT1JLIFRSQUNLRVIgLS0tXHJcbiAgICB0aGlzLnNvY2tldC5uZXR3b3JrU2lnbmF0dXJlUmVjZWl2ZWQkLnN1YnNjcmliZSgoZGF0YSkgPT4ge1xyXG4gICAgICBjb25zdCBzZXNzaW9ucyA9IHRoaXMuc29ja2V0LmFjdGl2ZVNlc3Npb25zKCk7XHJcbiAgICAgIGNvbnN0IHVwbG9hZGVyU2Vzc2lvbiA9IHNlc3Npb25zLmZpbmQoKHMpID0+IHMuaWQgPT09IGRhdGEuc2Vzc2lvbklkKTtcclxuICAgICAgY29uc3QgbGFiZWwgPSB0aGlzLnNvY2tldC5yb29tU3RhdGUoKT8uc2lnbmVyTGFiZWxzPy5bZGF0YS5maW5nZXJwcmludF07XHJcblxyXG4gICAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFNpZ25hdHVyZVJlY2VpdmVkKFxyXG4gICAgICAgIGRhdGEuZmluZ2VycHJpbnQsXHJcbiAgICAgICAgbGFiZWwsXHJcbiAgICAgICAgZGF0YS5zZXNzaW9uSWQsXHJcbiAgICAgICAgdXBsb2FkZXJTZXNzaW9uPy5kaXNwbGF5TmFtZSxcclxuICAgICAgKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMuc29ja2V0LnNlY3VyaXR5QWxlcnQkLnN1YnNjcmliZSgoZXZlbnQpID0+IHtcclxuICAgICAgY29uc3Qgc2V2ZXJpdHkgPSBldmVudC5jb3VudCA+PSAzID8gJ2hpZ2gnIDogJ21lZGl1bSc7XHJcbiAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0U2VjdXJpdHlBbGVydChcclxuICAgICAgICBldmVudC50eXBlLFxyXG4gICAgICAgIHNldmVyaXR5LFxyXG4gICAgICAgIGBGYWlsZWQgZGVjcnlwdGlvbiBhdHRlbXB0ICR7ZXZlbnQuY291bnR9LzNgLFxyXG4gICAgICApO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XHJcbiAgICAgIHRoaXMucm91dGUucGFyYW1NYXAuc3Vic2NyaWJlKGFzeW5jIChwYXJhbXMpID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IHBhcmFtcy5nZXQoJ2lkJyk7XHJcbiAgICAgICAgY29uc3QgZnJhZ21lbnRLZXkgPSB0aGlzLnJvdXRlLnNuYXBzaG90LmZyYWdtZW50O1xyXG4gICAgICAgIGNvbnN0IGhvc3RQYXJhbSA9IHRoaXMucm91dGUuc25hcHNob3QucXVlcnlQYXJhbU1hcC5nZXQoJ2hvc3QnKTtcclxuXHJcbiAgICAgICAgaWYgKGhvc3RQYXJhbSkge1xyXG4gICAgICAgICAgdGhpcy5leHBlY3RlZEhvc3QgPSBkZWNvZGVVUklDb21wb25lbnQoaG9zdFBhcmFtKTtcclxuXHJcbiAgICAgICAgICB0aGlzLmRpc3BhdGNoZXIuc2V0VGFyZ2V0T3JpZ2luKHRoaXMuZXhwZWN0ZWRIb3N0KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICB0aGlzLmV4cGVjdGVkSG9zdCA9IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIWlkKSByZXR1cm47XHJcbiAgICAgICAgdGhpcy5yb29tSWQuc2V0KGlkKTtcclxuXHJcbiAgICAgICAgY29uc3QgaXNBbHJlYWR5Q29ubmVjdGVkID0gdGhpcy5zb2NrZXQuc3RhdHVzKCkgPT09ICdjb25uZWN0ZWQnO1xyXG4gICAgICAgIGNvbnN0IGlzQ29ycmVjdFJvb20gPSB0aGlzLnNvY2tldC5zZGsuc3RvcmUuZ2V0U3RhdGUoKT8ucm9vbUlkID09PSBpZDtcclxuXHJcbiAgICAgICAgLy8gRE8gTk9UIGRpc2Nvbm5lY3QgaWYgd2UgYXJlIGFscmVhZHkgaW4gdGhlIGNvcnJlY3Qgcm9vbSFcclxuICAgICAgICBpZiAoaXNBbHJlYWR5Q29ubmVjdGVkICYmIGlzQ29ycmVjdFJvb20pIHtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChmcmFnbWVudEtleSkge1xyXG4gICAgICAgICAgdGhpcy5zb2NrZXQuc2V0Um9vbUtleShmcmFnbWVudEtleSk7XHJcbiAgICAgICAgICAvLyBXZSBvbmx5IGRpc2Nvbm5lY3QgaWYgd2UgYXJlIHN3aXRjaGluZyByb29tcyBvciBpZiBjb25uZWN0aW9uIGlzIGRlYWRcclxuICAgICAgICAgIGF3YWl0IHRoaXMuc29ja2V0LmNvbm5lY3QoaWQsIGZyYWdtZW50S2V5KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5zb2NrZXQuZGVjcnlwdGlvbkVycm9yLnNldCgnTWlzc2luZyBkZWNyeXB0aW9uIGtleScpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBuZ09uRGVzdHJveSgpIHtcclxuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XHJcbiAgICAgIHRoaXMuc29ja2V0LmRpc2Nvbm5lY3QoKTtcclxuICAgICAgdGhpcy5zb2NrZXQucmVzZXQoKTtcclxuXHJcbiAgICAgIGlmICh0aGlzLnRpbWVySW50ZXJ2YWwpIGNsZWFySW50ZXJ2YWwodGhpcy50aW1lckludGVydmFsKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldCByZXF1aXJlZFNpZ25hdHVyZXMoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IHBzYnQgPSB0aGlzLnNvY2tldC5yb29tU3RhdGUoKT8ucHNidDtcclxuICAgIHJldHVybiBwc2J0ID8gdGhpcy5zb2NrZXQuZ2V0VGhyZXNob2xkKHBzYnQpIDogMDtcclxuICB9XHJcblxyXG4gIGdldCBjYW5GaW5hbGl6ZSgpOiBib29sZWFuIHtcclxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5zb2NrZXQucm9vbVN0YXRlKCk7XHJcbiAgICBpZiAoIXN0YXRlKSByZXR1cm4gZmFsc2U7XHJcbiAgICBjb25zdCBzaWduZWRDb3VudCA9IHN0YXRlLnNpZ25hdHVyZXMubGVuZ3RoO1xyXG4gICAgY29uc3QgdGhyZXNob2xkID0gdGhpcy5yZXF1aXJlZFNpZ25hdHVyZXM7XHJcbiAgICByZXR1cm4gdGhyZXNob2xkID4gMCAmJiBzaWduZWRDb3VudCA+PSB0aHJlc2hvbGQ7XHJcbiAgfVxyXG5cclxuICBnZXQgaXNFbWJlZGRlZCgpOiBib29sZWFuIHtcclxuICAgIHJldHVybiB0aGlzLmRpc3BhdGNoZXIuaXNFbWJlZGRlZDtcclxuICB9XHJcblxyXG4gIGlzV2hpdGVsaXN0ZWQoYWRkcmVzczogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gdGhpcy5zb2NrZXQucm9vbVN0YXRlKCk/LndoaXRlbGlzdD8uaW5jbHVkZXMoYWRkcmVzcykgfHwgZmFsc2U7XHJcbiAgfVxyXG5cclxuICBnZXRTaWduZXJMYWJlbChmaW5nZXJwcmludDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGxhYmVscyA9IHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpPy5zaWduZXJMYWJlbHMgfHwge307XHJcbiAgICBjb25zdCBuYW1lID0gbGFiZWxzW2ZpbmdlcnByaW50XTtcclxuICAgIHJldHVybiBuYW1lID8gYCR7bmFtZX0gKCR7ZmluZ2VycHJpbnR9KWAgOiBmaW5nZXJwcmludDtcclxuICB9XHJcblxyXG4gIGdldExhYmVsKGZpbmdlcnByaW50OiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xyXG4gICAgcmV0dXJuIHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpPy5zaWduZXJMYWJlbHM/LltmaW5nZXJwcmludF07XHJcbiAgfVxyXG5cclxuICBpc1NhdmVkKGZpbmdlcnByaW50OiBzdHJpbmcpOiBib29sZWFuIHtcclxuICAgIHJldHVybiAhIXRoaXMuc29ja2V0LmdldExvY2FsTGFiZWwoZmluZ2VycHJpbnQpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgb25GaWxlU2VsZWN0ZWQoZXZlbnQ6IGFueSkge1xyXG4gICAgY29uc3QgZmlsZSA9IGV2ZW50LnRhcmdldC5maWxlc1swXTtcclxuICAgIGlmICghZmlsZSkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IHZhbGlkRXh0ZW5zaW9ucyA9IFsnLnBzYnQnLCAnLnR4dCcsICcuaGV4JywgJy5iYXNlNjQnXTtcclxuICAgIGNvbnN0IGZpbGVOYW1lID0gZmlsZS5uYW1lLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBpZiAoIXZhbGlkRXh0ZW5zaW9ucy5zb21lKChleHQpID0+IGZpbGVOYW1lLmVuZHNXaXRoKGV4dCkpKSB7XHJcbiAgICAgIHRoaXMub3BlbkFsZXJ0KCdJbnZhbGlkIEZpbGUgVHlwZScsICdQbGVhc2UgdXBsb2FkIGEgLnBzYnQsIC50eHQsIG9yIC5oZXggZmlsZS4nKTtcclxuICAgICAgZXZlbnQudGFyZ2V0LnZhbHVlID0gJyc7IC8vIFJlc2V0IGlucHV0XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZmlsZS5zaXplID4gMiAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgIHRoaXMub3BlbkFsZXJ0KCdGaWxlIFRvbyBMYXJnZScsICdGaWxlIGV4Y2VlZHMgMk1CIGxpbWl0LiBQU0JUcyBhcmUgdXN1YWxseSBtdWNoIHNtYWxsZXIuJyk7XHJcbiAgICAgIGV2ZW50LnRhcmdldC52YWx1ZSA9ICcnO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5pc1VwbG9hZGluZy5zZXQodHJ1ZSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcHNidENvbnRlbnQgPSBhd2FpdCB0aGlzLnNvY2tldC5zZGsucGFyc2VQc2J0RmlsZShmaWxlKTtcclxuICAgICAgYXdhaXQgdGhpcy5zb2NrZXQudXBsb2FkU2lnbmF0dXJlKHBzYnRDb250ZW50KTtcclxuICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRQc2J0SW1wb3J0ZWQoJ3VwbG9hZCcpO1xyXG4gICAgICBldmVudC50YXJnZXQudmFsdWUgPSAnJztcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgdGhpcy5vcGVuQWxlcnQoJ1JlYWQgRXJyb3InLCAnRmFpbGVkIHRvIHJlYWQgZmlsZS4nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHRoaXMuaXNVcGxvYWRpbmcuc2V0KGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByb21wdFBzYnREb3dubG9hZCgpIHtcclxuICAgIHRoaXMuc2hvd1BzYnRNb2RhbC5zZXQodHJ1ZSk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBleGVjdXRlUHNidERvd25sb2FkKCkge1xyXG4gICAgdGhpcy5zaG93UHNidE1vZGFsLnNldChmYWxzZSk7XHJcbiAgICBhd2FpdCB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ1BTQlQgRG93bmxvYWRlZCcsICdVbnNpZ25lZCBmaWxlIGV4cG9ydGVkJyk7XHJcbiAgICB0aGlzLmRvd25sb2FkVW5zaWduZWRQc2J0KCk7XHJcbiAgfVxyXG5cclxuICBkb3dubG9hZFVuc2lnbmVkUHNidCgpIHtcclxuICAgIHRoaXMuc29ja2V0LmxvZ0FjdGlvbignUFNCVCBEb3dubG9hZGVkJywgJ1Vuc2lnbmVkIGZpbGUgZXhwb3J0ZWQnKTtcclxuICAgIGNvbnN0IHBzYnQgPSB0aGlzLnNvY2tldC5yb29tU3RhdGUoKT8ucHNidDtcclxuICAgIGlmICghcHNidCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbcHNidF0sIHsgdHlwZTogJ3RleHQvcGxhaW4nIH0pO1xyXG4gICAgY29uc3QgdXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XHJcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgYS5ocmVmID0gdXJsO1xyXG4gICAgYS5kb3dubG9hZCA9IGB1bnNpZ25lZF90eF8ke3RoaXMucm9vbUlkKCk/LnNsaWNlKDAsIDgpfS5wc2J0YDtcclxuICAgIGEuY2xpY2soKTtcclxuICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XHJcblxyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXREb3dubG9hZFRyaWdnZXJlZCgndW5zaWduZWQtcHNidCcpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgY2xhaW1Sb2xlKCkge1xyXG4gICAgaWYgKHRoaXMuY2xhaW1QYXNzd29yZCkge1xyXG4gICAgICBjb25zdCBjbGVhblRva2VuID0gdGhpcy5jbGFpbVBhc3N3b3JkLnRyaW0oKTtcclxuXHJcbiAgICAgIC8vIFNlbmQgdGhlIGNsZWFyIHRva2VuIHRvIHRoZSByZWxheSB2aWEgV2ViU29ja2V0IHRvIGNsYWltIHRoZSByb29tXHJcbiAgICAgIHRoaXMuc29ja2V0LmNsYWltQ29vcmRpbmF0b3IoY2xlYW5Ub2tlbik7XHJcblxyXG4gICAgICBjb25zdCBlbmNyeXB0ZWRUb2tlbiA9IGF3YWl0IHRoaXMuZW5jcnlwdGlvbkVuZ2luZS5lbmNyeXB0KFxyXG4gICAgICAgIGNsZWFuVG9rZW4sXHJcbiAgICAgICAgdGhpcy5zb2NrZXQuZ2V0Um9vbUtleSgpIHx8ICcnLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShgYWRtaW5fdG9rZW5fJHt0aGlzLnJvb21JZCgpfWAsIGVuY3J5cHRlZFRva2VuKTtcclxuXHJcbiAgICAgIHRoaXMuc2hvd0NsYWltSW5wdXQuc2V0KGZhbHNlKTtcclxuICAgICAgdGhpcy5jbGFpbVBhc3N3b3JkID0gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjbG9zZVJvb20oKSB7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdE1vZGFsVmlldygnQ2xvc2UgUm9vbSBXYXJuaW5nJyk7XHJcbiAgICB0aGlzLm9wZW5Db25maXJtKFxyXG4gICAgICAnQ2xvc2UgUm9vbScsXHJcbiAgICAgICdBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gY2xvc2UgdGhpcyByb29tPyBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lIGFuZCB3aWxsIGRlbGV0ZSBhbGwgZGF0YSBpbW1lZGlhdGVseS4nLFxyXG4gICAgICAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmlzRW1iZWRkZWQpIHtcclxuICAgICAgICAgIHRoaXMuZ2VuZXJhdGVBdWRpdExvZygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRSb29tU3RhdGVDaGFuZ2VkKCdjbG9zZWQnKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgIHRoaXMuc29ja2V0LmNsb3NlUm9vbSgpO1xyXG5cclxuICAgICAgICAgIGlmICghdGhpcy5pc0VtYmVkZGVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnLyddKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCAzMDApO1xyXG4gICAgICB9LFxyXG4gICAgICB0cnVlLFxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIG9wZW5SZW5hbWVNb2RhbCgpIHtcclxuICAgIGNvbnN0IGN1cnJlbnRSb29tTmFtZSA9IHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpPy5yb29tTmFtZTtcclxuICAgIHRoaXMubmV3Um9vbU5hbWUuc2V0KGN1cnJlbnRSb29tTmFtZSB8fCAnJyk7XHJcbiAgICB0aGlzLnNob3dSZW5hbWVNb2RhbC5zZXQodHJ1ZSk7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdE1vZGFsVmlldygnUmVuYW1lIFJvb20nKTtcclxuICB9XHJcblxyXG4gIGNsb3NlUmVuYW1lTW9kYWwoKSB7XHJcbiAgICB0aGlzLnNob3dSZW5hbWVNb2RhbC5zZXQoZmFsc2UpO1xyXG4gIH1cclxuXHJcbiAgc2F2ZVJvb21OYW1lKCkge1xyXG4gICAgbGV0IG5hbWUgPSB0aGlzLm5ld1Jvb21OYW1lKCkudHJpbSgpO1xyXG4gICAgY29uc3QgTUFYX0xFTkdUSCA9IDY0O1xyXG5cclxuICAgIGlmIChuYW1lLmxlbmd0aCA+IE1BWF9MRU5HVEgpIHtcclxuICAgICAgbmFtZSA9IG5hbWUuc2xpY2UoMCwgTUFYX0xFTkdUSCk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFuYW1lKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNvY2tldC5yZW5hbWVSb29tKG5hbWUpO1xyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRSb29tUmVuYW1lZChuYW1lKTtcclxuICAgIHRoaXMuY2xvc2VSZW5hbWVNb2RhbCgpO1xyXG4gIH1cclxuXHJcbiAgdG9nZ2xlTG9jaygpIHtcclxuICAgIGNvbnN0IGN1cnJlbnQgPSB0aGlzLnNvY2tldC5yb29tU3RhdGUoKT8uaXNMb2NrZWQ7XHJcbiAgICBjb25zdCBhY3Rpb24gPSBjdXJyZW50ID8gJ1VubG9jaycgOiAnTE9DSyc7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdE1vZGFsVmlldyhgJHthY3Rpb259IFJvb20gV2FybmluZ2ApO1xyXG4gICAgdGhpcy5vcGVuQ29uZmlybShcclxuICAgICAgYCR7YWN0aW9ufSBSb29tYCxcclxuICAgICAgYEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byAke2FjdGlvbn0gdGhpcyByb29tPyAke2N1cnJlbnQgPyAnTmV3IHVzZXJzIHdpbGwgYmUgYWJsZSB0byBqb2luLicgOiAnTm8gbmV3IHVzZXJzIHdpbGwgYmUgYWJsZSB0byBjb25uZWN0Lid9YCxcclxuICAgICAgKCkgPT4ge1xyXG4gICAgICAgIHRoaXMuc29ja2V0LnRvZ2dsZUxvY2soIWN1cnJlbnQpO1xyXG4gICAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0Um9vbVN0YXRlQ2hhbmdlZCghY3VycmVudCA/ICdsb2NrZWQnIDogJ3VubG9ja2VkJyk7XHJcbiAgICAgIH0sXHJcbiAgICAgICFjdXJyZW50LFxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIG9wZW5MYWJlbE1vZGFsKGZpbmdlcnByaW50OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGN1cnJlbnQgPSB0aGlzLnNvY2tldC5yb29tU3RhdGUoKT8uc2lnbmVyTGFiZWxzPy5bZmluZ2VycHJpbnRdIHx8ICcnO1xyXG4gICAgY29uc3Qgc2F2ZWQgPSB0aGlzLnNvY2tldC5nZXRMb2NhbExhYmVsKGZpbmdlcnByaW50KTtcclxuXHJcbiAgICB0aGlzLmVkaXRpbmdGaW5nZXJwcmludC5zZXQoZmluZ2VycHJpbnQpO1xyXG4gICAgdGhpcy5lZGl0aW5nTGFiZWwuc2V0KGN1cnJlbnQgfHwgc2F2ZWQgfHwgJycpO1xyXG4gICAgdGhpcy5zYXZlVG9Cb29rLnNldCh0cnVlKTtcclxuICAgIHRoaXMuc2hvd0xhYmVsTW9kYWwuc2V0KHRydWUpO1xyXG4gIH1cclxuXHJcbiAgc2F2ZUxhYmVsKCkge1xyXG4gICAgY29uc3QgZnAgPSB0aGlzLmVkaXRpbmdGaW5nZXJwcmludCgpO1xyXG4gICAgY29uc3QgbGFiZWwgPSB0aGlzLmVkaXRpbmdMYWJlbCgpLnRyaW0oKTtcclxuXHJcbiAgICBpZiAoZnApIHtcclxuICAgICAgdGhpcy5zb2NrZXQudXBkYXRlU2lnbmVyTGFiZWwoZnAsIGxhYmVsKTtcclxuXHJcbiAgICAgIGlmICh0aGlzLnNhdmVUb0Jvb2soKSAmJiBsYWJlbCkge1xyXG4gICAgICAgIHRoaXMuc29ja2V0LnNhdmVUb0FkZHJlc3NCb29rKGZwLCBsYWJlbCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5zb2NrZXQucmVtb3ZlRnJvbUFkZHJlc3NCb29rKGZwKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRQYXJ0aWNpcGFudExhYmVsbGVkKCdzaWduZXInLCBsYWJlbCwgZnApO1xyXG4gICAgfVxyXG4gICAgdGhpcy5jbG9zZUxhYmVsTW9kYWwoKTtcclxuICB9XHJcblxyXG4gIGNsb3NlTGFiZWxNb2RhbCgpIHtcclxuICAgIHRoaXMuc2hvd0xhYmVsTW9kYWwuc2V0KGZhbHNlKTtcclxuICAgIHRoaXMuZWRpdGluZ0ZpbmdlcnByaW50LnNldChudWxsKTtcclxuICAgIHRoaXMuZWRpdGluZ0xhYmVsLnNldCgnJyk7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVXaGl0ZWxpc3QoYWRkcmVzczogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBpc1ByZXNlbnQgPSB0aGlzLmlzV2hpdGVsaXN0ZWQoYWRkcmVzcyk7XHJcbiAgICB0aGlzLm9wZW5Db25maXJtKFxyXG4gICAgICAnVXBkYXRlIFdoaXRlbGlzdCcsXHJcbiAgICAgIGAke2lzUHJlc2VudCA/ICdSZW1vdmUnIDogJ0FkZCd9IHRoZSBmb2xsb3dpbmcgYWRkcmVzcyAke2lzUHJlc2VudCA/ICdmcm9tJyA6ICd0byd9IHRoZSB3aGl0ZWxpc3Q/XFxuXFxuJHthZGRyZXNzfWAsXHJcbiAgICAgICgpID0+IHtcclxuICAgICAgICB0aGlzLnNvY2tldC51cGRhdGVXaGl0ZWxpc3QoW2FkZHJlc3NdLCBpc1ByZXNlbnQpO1xyXG4gICAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0RGVzdGluYXRpb25WZXJpZmllZCh0aGlzLnZpZXdNb2RlKCksIGFkZHJlc3MsICFpc1ByZXNlbnQpO1xyXG4gICAgICB9LFxyXG4gICAgICBmYWxzZSxcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBjb3B5QWRkcmVzcyhhZGRyZXNzOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIGlmICghYWRkcmVzcykgcmV0dXJuO1xyXG5cclxuICAgIG5hdmlnYXRvci5jbGlwYm9hcmRcclxuICAgICAgLndyaXRlVGV4dChhZGRyZXNzKVxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgdGhpcy5jb3BpZWRBZGRyZXNzLnNldChhZGRyZXNzKTtcclxuXHJcbiAgICAgICAgY29uc3Qgc2hvcnRBZGRyZXNzID0gYCR7YWRkcmVzcy5zbGljZSgwLCA2KX0uLi4ke2FkZHJlc3Muc2xpY2UoLTYpfWA7XHJcblxyXG4gICAgICAgIHRoaXMuc29ja2V0LmxvZ0FjdGlvbignQWRkcmVzcyBDb3BpZWQnLCBgJHtzaG9ydEFkZHJlc3N9YCk7XHJcblxyXG4gICAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0QWRkcmVzc0NvcGllZChhZGRyZXNzKTtcclxuXHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICBpZiAodGhpcy5jb3BpZWRBZGRyZXNzKCkgPT09IGFkZHJlc3MpIHtcclxuICAgICAgICAgICAgdGhpcy5jb3BpZWRBZGRyZXNzLnNldChudWxsKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCAyMDAwKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gY29weSBhZGRyZXNzOiAnLCBlcnIpO1xyXG4gICAgICB9KTtcclxuICB9XHJcblxyXG4gIG9wZW5TZXNzaW9uc01vZGFsKCkge1xyXG4gICAgaWYgKHR5cGVvZiBsb2NhbFN0b3JhZ2UgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgIGNvbnN0IHNhdmVkTmFtZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKGBkaXNwbGF5X25hbWVfJHt0aGlzLnJvb21JZCgpfWApO1xyXG4gICAgICB0aGlzLnBlcnNvbmFsRGlzcGxheU5hbWUuc2V0KHNhdmVkTmFtZSB8fCAnJyk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnNob3dTZXNzaW9uc01vZGFsLnNldCh0cnVlKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0TW9kYWxWaWV3KCdBY3RpdmUgU2Vzc2lvbnMnKTtcclxuICB9XHJcblxyXG4gIHNhdmVQZXJzb25hbE5hbWUoKSB7XHJcbiAgICBjb25zdCBuYW1lID0gdGhpcy5wZXJzb25hbERpc3BsYXlOYW1lKCkudHJpbSgpO1xyXG4gICAgdGhpcy5zb2NrZXQuc2V0RGlzcGxheU5hbWUobmFtZSk7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFBhcnRpY2lwYW50TGFiZWxsZWQoJ3NlbGYnLCBuYW1lKTtcclxuICAgIHRoaXMuc2hvd1Nlc3Npb25zTW9kYWwuc2V0KGZhbHNlKTtcclxuICB9XHJcblxyXG4gIGNvcHlTZXNzaW9uSWQoaWQ6IHN0cmluZywgZGlzcGxheU5hbWU/OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IG5hbWUgPSBkaXNwbGF5TmFtZSB8fCAnQW5vbnltb3VzIEd1ZXN0JztcclxuICAgIGNvbnN0IHRleHRUb0NvcHkgPSBgJHtuYW1lfSAoU2Vzc2lvbjogJHtpZH0pYDtcclxuXHJcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0VG9Db3B5KTtcclxuICAgIHRoaXMuY29waWVkU2Vzc2lvbklkLnNldChpZCk7XHJcblxyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXREYXRhQ29waWVkKCdzZXNzaW9uLWlkJyk7XHJcblxyXG4gICAgLy8gUmVzZXQgaXQgYWZ0ZXIgMiBzZWNvbmRzXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMuY29waWVkU2Vzc2lvbklkLnNldChudWxsKSwgMjAwMCk7XHJcbiAgfVxyXG5cclxuICB2ZXJpZnlBbGxJbnB1dHMoKSB7XHJcbiAgICBjb25zdCBpbnB1dHMgPSB0aGlzLnNvY2tldC50eERldGFpbHMoKT8uaW5wdXRzTGlzdCB8fCBbXTtcclxuICAgIGlmIChpbnB1dHMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgdG9BZGQgPSBpbnB1dHMubWFwKChpKSA9PiBpLmFkZHJlc3MpLmZpbHRlcigoYWRkcikgPT4gIXRoaXMuaXNXaGl0ZWxpc3RlZChhZGRyKSk7XHJcblxyXG4gICAgaWYgKHRvQWRkLmxlbmd0aCA+IDApIHtcclxuICAgICAgdGhpcy5zb2NrZXQudXBkYXRlV2hpdGVsaXN0KHRvQWRkLCBmYWxzZSk7XHJcbiAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0RGVzdGluYXRpb25WZXJpZmllZCgnaW5wdXRzJywgJ2JhdGNoJywgdHJ1ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB2ZXJpZnlBbGxPdXRwdXRzKCkge1xyXG4gICAgY29uc3Qgb3V0cHV0cyA9IHRoaXMuc29ja2V0LnR4RGV0YWlscygpPy5vdXRwdXRzIHx8IFtdO1xyXG4gICAgaWYgKG91dHB1dHMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgdGhpcy5vcGVuQ29uZmlybShcclxuICAgICAgJ0JhdGNoIFZlcmlmeSBPdXRwdXRzJyxcclxuICAgICAgYEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byB2ZXJpZnkgYWxsICR7b3V0cHV0cy5sZW5ndGh9IG91dHB1dHM/YCxcclxuICAgICAgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRvQWRkID0gb3V0cHV0cy5tYXAoKG8pID0+IG8uYWRkcmVzcykuZmlsdGVyKChhZGRyKSA9PiAhdGhpcy5pc1doaXRlbGlzdGVkKGFkZHIpKTtcclxuXHJcbiAgICAgICAgaWYgKHRvQWRkLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIHRoaXMuc29ja2V0LnVwZGF0ZVdoaXRlbGlzdCh0b0FkZCwgZmFsc2UpO1xyXG4gICAgICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXREZXN0aW5hdGlvblZlcmlmaWVkKCdvdXRwdXRzJywgJ2JhdGNoJywgdHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBmYWxzZSxcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBzZXRWaWV3TW9kZShtb2RlOiAnaW5wdXRzJyB8ICdvdXRwdXRzJykge1xyXG4gICAgdGhpcy52aWV3TW9kZS5zZXQobW9kZSk7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFRyYW5zYWN0aW9uVmlld0NoYW5nZWQobW9kZSk7XHJcbiAgfVxyXG5cclxuICB1cGRhdGVTZWFyY2hRdWVyeSh2aWV3OiAnaW5wdXRzJyB8ICdvdXRwdXRzJywgcXVlcnk6IHN0cmluZykge1xyXG4gICAgaWYgKHZpZXcgPT09ICdpbnB1dHMnKSB7XHJcbiAgICAgIHRoaXMuaW5wdXRTZWFyY2hRdWVyeS5zZXQocXVlcnkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5vdXRwdXRTZWFyY2hRdWVyeS5zZXQocXVlcnkpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZmluYWxpemUoKSB7XHJcbiAgICBpZiAodGhpcy5pc0V4cGlyZWQoKSkgcmV0dXJuO1xyXG5cclxuICAgIC8vIENhcHR1cmUgaW5pdGlhbCBzdGF0ZSBqdXN0IGZvciB0aGUgd2hpdGVsaXN0IGNoZWNrXHJcbiAgICBjb25zdCBpbml0aWFsU3RhdGUgPSB0aGlzLnNvY2tldC5yb29tU3RhdGUoKTtcclxuXHJcbiAgICBjb25zdCBkb0ZpbmFsaXplID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIC8vIEF3YWl0IHRoZSBmaW5hbGl6YXRpb24gRklSU1QuIFRoZSBTREsgcmV0dXJucyB0aGUgaGV4IGFuZCB0eElkLlxyXG4gICAgICAgIGNvbnN0IGZpbmFsaXplZCA9IGF3YWl0IHRoaXMuc29ja2V0LmZpbmFsaXplVHJhbnNhY3Rpb24oKTtcclxuXHJcbiAgICAgICAgaWYgKGZpbmFsaXplZCkge1xyXG4gICAgICAgICAgLy8gRmV0Y2ggdGhlIEZSRVNIIHN0YXRlIG5vdyB0aGF0IGZpbmFsaXphdGlvbiBpcyBjb21wbGV0ZVxyXG4gICAgICAgICAgY29uc3QgZnJlc2hTdGF0ZSA9IHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpO1xyXG5cclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgZnJlc2hTdGF0ZSAmJlxyXG4gICAgICAgICAgICBmcmVzaFN0YXRlLmZpbmFsVHhJZCAmJlxyXG4gICAgICAgICAgICBmcmVzaFN0YXRlLmZpbmFsVHhIZXggJiZcclxuICAgICAgICAgICAgdGhpcy5pc0VtYmVkZGVkICYmXHJcbiAgICAgICAgICAgIHRoaXMuc29ja2V0LmlzQ29vcmRpbmF0b3IoKSAmJlxyXG4gICAgICAgICAgICAhdGhpcy5oYXNFbWl0dGVkRmluYWxpemVkXHJcbiAgICAgICAgICApIHtcclxuICAgICAgICAgICAgdGhpcy5oYXNFbWl0dGVkRmluYWxpemVkID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHNhbml0aXplZFN0YXRlID0geyAuLi5mcmVzaFN0YXRlIH0gYXMgYW55O1xyXG4gICAgICAgICAgICBkZWxldGUgc2FuaXRpemVkU3RhdGUuZXhwZWN0ZWRQYXNzO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgcGRmRGF0YSA9IGF3YWl0IHRoaXMuZ2V0UGRmRG9jdW1lbnQoKTtcclxuICAgICAgICAgICAgY29uc3QgcGRmQmFzZTY0ID0gcGRmRGF0YSA/IHBkZkRhdGEuZG9jLm91dHB1dCgnZGF0YXVyaXN0cmluZycpIDogbnVsbDtcclxuXHJcbiAgICAgICAgICAgIC8vIEVtaXQgdXNpbmcgdGhlIGZyZXNoIHN0YXRlXHJcbiAgICAgICAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0VHJhbnNhY3Rpb25GaW5hbGl6ZWQoe1xyXG4gICAgICAgICAgICAgIHR4SWQ6IGZyZXNoU3RhdGUuZmluYWxUeElkLFxyXG4gICAgICAgICAgICAgIHR4SGV4OiBmcmVzaFN0YXRlLmZpbmFsVHhIZXgsXHJcbiAgICAgICAgICAgICAgcm9vbVN0YXRlOiBzYW5pdGl6ZWRTdGF0ZSxcclxuICAgICAgICAgICAgICBhdWRpdExvZ0NzdjogdGhpcy5zb2NrZXQuZ2V0QXVkaXRMb2dDc3YoKSxcclxuICAgICAgICAgICAgICBzZXR0bGVtZW50Q3N2OiB0aGlzLnNvY2tldC5nZXRTZXR0bGVtZW50Q3N2RGF0YSgpLFxyXG4gICAgICAgICAgICAgIGF1ZGl0UGRmVXJpOiBwZGZCYXNlNjQsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHRoaXMudHJpZ2dlckNvbmZldHRpKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZpbmFsaXplIHRyYW5zYWN0aW9uJywgZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gV2hpdGVsaXN0IGNoZWNrIHVzZXMgdGhlIGluaXRpYWxTdGF0ZSBjYXB0dXJlZCBhdCB0aGUgdG9wXHJcbiAgICBpZiAoaW5pdGlhbFN0YXRlPy53aGl0ZWxpc3QgJiYgaW5pdGlhbFN0YXRlLndoaXRlbGlzdC5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnN0IG91dHB1dHMgPSB0aGlzLnNvY2tldC50eERldGFpbHMoKT8ub3V0cHV0cyB8fCBbXTtcclxuXHJcbiAgICAgIGNvbnN0IHVudmVyaWZpZWQgPSBvdXRwdXRzLmZpbHRlcigob3V0KSA9PiB7XHJcbiAgICAgICAgaWYgKG91dC5pc0NoYW5nZSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIGlmIChpbml0aWFsU3RhdGUud2hpdGVsaXN0LmluY2x1ZGVzKG91dC5hZGRyZXNzKSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmICh1bnZlcmlmaWVkLmxlbmd0aCA+IDApIHtcclxuICAgICAgICB0aGlzLm9wZW5Db25maXJtKFxyXG4gICAgICAgICAgJ1NlY3VyaXR5IFdhcm5pbmcnLFxyXG4gICAgICAgICAgYFlvdSBhcmUgc2VuZGluZyBmdW5kcyB0byAke3VudmVyaWZpZWQubGVuZ3RofSB1bnZlcmlmaWVkIGFkZHJlc3MoZXMpLiBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcHJvY2VlZD9gLFxyXG4gICAgICAgICAgKCkgPT4gZG9GaW5hbGl6ZSgpLFxyXG4gICAgICAgICAgdHJ1ZSxcclxuICAgICAgICApO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IGRvRmluYWxpemUoKTtcclxuICB9XHJcblxyXG4gIGJyb2FkY2FzdEFuZENvcHkoKSB7XHJcbiAgICBpZiAodGhpcy5maW5hbEhleCgpKSB7XHJcbiAgICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHRoaXMuZmluYWxIZXgoKSEpO1xyXG5cclxuICAgICAgY29uc3QgcmF3TmV0ID0gdGhpcy5zb2NrZXQucm9vbVN0YXRlKCk/Lm5ldHdvcms7XHJcbiAgICAgIGNvbnN0IGFsbG93ZWQgPSBbJ2JpdGNvaW4nLCAndGVzdG5ldCcsICdzaWduZXQnXTtcclxuICAgICAgY29uc3QgbmV0ID0gYWxsb3dlZC5pbmNsdWRlcyhyYXdOZXQgfHwgJycpID8gcmF3TmV0IDogJ2JpdGNvaW4nO1xyXG5cclxuICAgICAgY29uc3QgYmFzZVVybCA9XHJcbiAgICAgICAgbmV0ID09PSAnYml0Y29pbidcclxuICAgICAgICAgID8gJ2h0dHBzOi8vbWVtcG9vbC5zcGFjZSdcclxuICAgICAgICAgIDogbmV0ID09PSAndGVzdG5ldCdcclxuICAgICAgICAgICAgPyAnaHR0cHM6Ly9tZW1wb29sLnNwYWNlL3Rlc3RuZXQnXHJcbiAgICAgICAgICAgIDogJ2h0dHBzOi8vbWVtcG9vbC5zcGFjZS9zaWduZXQnO1xyXG5cclxuICAgICAgd2luZG93Lm9wZW4oYCR7YmFzZVVybH0vdHgvcHVzaGAsICdfYmxhbmsnKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIG9wZW5Db25maXJtKHRpdGxlOiBzdHJpbmcsIG1lc3NhZ2U6IHN0cmluZywgYWN0aW9uOiAoKSA9PiB2b2lkLCBpc0Rlc3RydWN0aXZlID0gZmFsc2UpIHtcclxuICAgIHRoaXMuY29uZmlybURhdGEuc2V0KHsgdGl0bGUsIG1lc3NhZ2UsIGFjdGlvbiwgaXNEZXN0cnVjdGl2ZSwgdHlwZTogJ2NvbmZpcm0nIH0pO1xyXG4gICAgdGhpcy5zaG93Q29uZmlybU1vZGFsLnNldCh0cnVlKTtcclxuICB9XHJcblxyXG4gIG9wZW5BbGVydCh0aXRsZTogc3RyaW5nLCBtZXNzYWdlOiBzdHJpbmcpIHtcclxuICAgIHRoaXMuY29uZmlybURhdGEuc2V0KHsgdGl0bGUsIG1lc3NhZ2UsIGFjdGlvbjogKCkgPT4ge30sIGlzRGVzdHJ1Y3RpdmU6IGZhbHNlLCB0eXBlOiAnYWxlcnQnIH0pO1xyXG4gICAgdGhpcy5zaG93Q29uZmlybU1vZGFsLnNldCh0cnVlKTtcclxuICB9XHJcblxyXG4gIGV4ZWN1dGVDb25maXJtQWN0aW9uKCkge1xyXG4gICAgdGhpcy5jb25maXJtRGF0YSgpLmFjdGlvbigpO1xyXG4gICAgdGhpcy5jbG9zZUNvbmZpcm1Nb2RhbCgpO1xyXG4gIH1cclxuXHJcbiAgY2xvc2VDb25maXJtTW9kYWwoKSB7XHJcbiAgICB0aGlzLnNob3dDb25maXJtTW9kYWwuc2V0KGZhbHNlKTtcclxuICAgIC8vIFJlc2V0IHN0YXRlXHJcbiAgICB0aGlzLmNvbmZpcm1EYXRhLnNldCh7XHJcbiAgICAgIHRpdGxlOiAnJyxcclxuICAgICAgbWVzc2FnZTogJycsXHJcbiAgICAgIGFjdGlvbjogKCkgPT4ge30sXHJcbiAgICAgIGlzRGVzdHJ1Y3RpdmU6IGZhbHNlLFxyXG4gICAgICB0eXBlOiAnY29uZmlybScsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGFzeW5jIG9wZW5RcigpIHtcclxuICAgIHRoaXMuc2hvd1FyTW9kYWwuc2V0KHRydWUpO1xyXG4gICAgdGhpcy5pc1FyUmV2ZWFsZWQuc2V0KGZhbHNlKTtcclxuICAgIHRoaXMucXJJbmNsdWRlc0tleS5zZXQoZmFsc2UpO1xyXG5cclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0TW9kYWxWaWV3KCdSb29tIFFSIENvZGUnKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0UXJTdGF0ZUNoYW5nZWQoZmFsc2UsIGZhbHNlKTtcclxuXHJcbiAgICBhd2FpdCB0aGlzLmdlbmVyYXRlUXJEYXRhKCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyB0b2dnbGVRcktleShpbmNsdWRlc0tleTogYm9vbGVhbikge1xyXG4gICAgdGhpcy5xckluY2x1ZGVzS2V5LnNldChpbmNsdWRlc0tleSk7XHJcbiAgICB0aGlzLmlzUXJSZXZlYWxlZC5zZXQoZmFsc2UpO1xyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRRclN0YXRlQ2hhbmdlZChpbmNsdWRlc0tleSwgZmFsc2UpO1xyXG4gICAgYXdhaXQgdGhpcy5nZW5lcmF0ZVFyRGF0YSgpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhc3luYyBnZW5lcmF0ZVFyRGF0YSgpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGxpbmsgPSB0aGlzLnFySW5jbHVkZXNLZXkoKVxyXG4gICAgICAgID8gdGhpcy5nZXRGdWxsU2hhcmVMaW5rKClcclxuICAgICAgICA6IHdpbmRvdy5sb2NhdGlvbi5ocmVmLnNwbGl0KCcjJylbMF07XHJcblxyXG4gICAgICBjb25zdCBkYXRhVXJsID0gYXdhaXQgUVJDb2RlLnRvRGF0YVVSTChsaW5rLCB7XHJcbiAgICAgICAgd2lkdGg6IDQwMCxcclxuICAgICAgICBtYXJnaW46IDIsXHJcbiAgICAgICAgY29sb3I6IHtcclxuICAgICAgICAgIGRhcms6ICcjMDAwMDAwJyxcclxuICAgICAgICAgIGxpZ2h0OiAnI2ZmZmZmZicsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnJvckNvcnJlY3Rpb25MZXZlbDogJ00nLFxyXG4gICAgICB9KTtcclxuICAgICAgdGhpcy5xckRhdGFVcmwuc2V0KGRhdGFVcmwpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1FSIEdlbmVyYXRpb24gZmFpbGVkJywgZXJyKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNsb3NlUXIoKSB7XHJcbiAgICB0aGlzLnNob3dRck1vZGFsLnNldChmYWxzZSk7XHJcbiAgICB0aGlzLnFyRGF0YVVybC5zZXQobnVsbCk7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVRclJldmVhbCgpIHtcclxuICAgIGNvbnN0IGlzUmV2ZWFsaW5nID0gIXRoaXMuaXNRclJldmVhbGVkKCk7XHJcbiAgICB0aGlzLmlzUXJSZXZlYWxlZC51cGRhdGUoKHYpID0+ICF2KTtcclxuXHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFFyU3RhdGVDaGFuZ2VkKHRoaXMucXJJbmNsdWRlc0tleSgpLCBpc1JldmVhbGluZyk7XHJcblxyXG4gICAgaWYgKGlzUmV2ZWFsaW5nKSB7XHJcbiAgICAgIGNvbnN0IHFyVHlwZSA9IHRoaXMucXJJbmNsdWRlc0tleSgpID8gJ0Z1bGwgKExpbmsgKyBLZXkpJyA6ICdMaW5rIE9ubHkgKE5vIEtleSknO1xyXG4gICAgICB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ1FSIENvZGUgUmV2ZWFsZWQnLCBgJHtxclR5cGV9IFFSIENvZGUgb24gc2NyZWVuYCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBkb3dubG9hZFFyKCkge1xyXG4gICAgY29uc3QgdXJsID0gdGhpcy5xckRhdGFVcmwoKTtcclxuICAgIGlmICghdXJsKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgcXJUeXBlID0gdGhpcy5xckluY2x1ZGVzS2V5KCkgPyAnRnVsbCAoTGluayArIEtleSknIDogJ0xpbmsgT25seSAoTm8gS2V5KSc7XHJcbiAgICB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ1FSIENvZGUgRG93bmxvYWRlZCcsIGAke3FyVHlwZX0gUVIgQ29kZSB0byB0aGVpciBkZXZpY2VgKTtcclxuXHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdERvd25sb2FkVHJpZ2dlcmVkKCdxci1jb2RlLWltYWdlJyk7XHJcblxyXG4gICAgY29uc3Qgc2FmZUlkID0gdGhpcy5yb29tSWQoKSA/PyAndW5rbm93bi1yb29tJztcclxuXHJcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgYS5ocmVmID0gdXJsO1xyXG4gICAgYS5kb3dubG9hZCA9IGBzaWduaW5ncm9vbS1xci0ke3NhZmVJZC5zbGljZSgwLCA4KX0ucG5nYDtcclxuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYSk7XHJcbiAgICBhLmNsaWNrKCk7XHJcbiAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGEpO1xyXG4gIH1cclxuXHJcbiAgc3VibWl0S2V5KCkge1xyXG4gICAgaWYgKCF0aGlzLm1hbnVhbEtleSkgcmV0dXJuO1xyXG4gICAgbGV0IGtleSA9IHRoaXMubWFudWFsS2V5LnRyaW0oKTtcclxuICAgIGlmIChrZXkuaW5jbHVkZXMoJyMnKSkga2V5ID0ga2V5LnNwbGl0KCcjJylbMV07XHJcbiAgICB0aGlzLnNvY2tldC5kZWNyeXB0aW9uRXJyb3Iuc2V0KCcnKTtcclxuICAgIHRoaXMuc29ja2V0LmNvbm5lY3QodGhpcy5yb29tSWQoKSEsIGtleSk7XHJcbiAgICB0aGlzLm1hbnVhbEtleSA9ICcnO1xyXG4gIH1cclxuXHJcbiAgcHJvbXB0QXVkaXRMb2dEb3dubG9hZCgpIHtcclxuICAgIHRoaXMuc2hvd0F1ZGl0TW9kYWwuc2V0KHRydWUpO1xyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRNb2RhbFZpZXcoJ0Rvd25sb2FkIEF1ZGl0IExvZycpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZXhlY3V0ZUF1ZGl0RG93bmxvYWQoKSB7XHJcbiAgICB0aGlzLnNob3dBdWRpdE1vZGFsLnNldChmYWxzZSk7XHJcblxyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXREb3dubG9hZFRyaWdnZXJlZCgnYXVkaXQtbG9nJyk7XHJcblxyXG4gICAgYXdhaXQgdGhpcy5kZWxheSgxMDAwKTtcclxuXHJcbiAgICB0aGlzLmdlbmVyYXRlQXVkaXRMb2coKTtcclxuICB9XHJcblxyXG4gIHByb21wdENzdkRvd25sb2FkKCkge1xyXG4gICAgdGhpcy5zaG93Q3N2TW9kYWwuc2V0KHRydWUpO1xyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRNb2RhbFZpZXcoJ0Rvd25sb2FkIENTViBEYXRhJyk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBleGVjdXRlQ3N2RG93bmxvYWQoKSB7XHJcbiAgICB0aGlzLnNob3dDc3ZNb2RhbC5zZXQoZmFsc2UpO1xyXG4gICAgLy9hd2FpdCB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ0NTViBFeHBvcnQnLCAnRG93bmxvYWRlZCBzZXR0bGVtZW50IGRhdGEnKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0RG93bmxvYWRUcmlnZ2VyZWQoJ2NzdicpO1xyXG4gICAgYXdhaXQgdGhpcy5kZWxheSgxMDAwKTtcclxuICAgIHRoaXMuZG93bmxvYWRDc3YoKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZGVsYXkobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIG1zKSk7XHJcbiAgfVxyXG5cclxuICBkb3dubG9hZENzdigpIHtcclxuICAgIGNvbnN0IGNzdkNvbnRlbnQgPSB0aGlzLnNvY2tldC5nZXRTZXR0bGVtZW50Q3N2RGF0YSgpO1xyXG4gICAgaWYgKCFjc3ZDb250ZW50KSByZXR1cm47XHJcblxyXG4gICAgY29uc3Qgcm9vbUlkID0gdGhpcy5zb2NrZXQucm9vbVN0YXRlKCk/LnJvb21JZCB8fCAndW5rbm93bic7XHJcblxyXG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZDb250ZW50XSwgeyB0eXBlOiAndGV4dC9jc3Y7Y2hhcnNldD11dGYtODsnIH0pO1xyXG5cclxuICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG5cclxuICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICBsaW5rLnNldEF0dHJpYnV0ZSgnaHJlZicsIHVybCk7XHJcbiAgICBsaW5rLnNldEF0dHJpYnV0ZShcclxuICAgICAgJ2Rvd25sb2FkJyxcclxuICAgICAgYHNldHRsZW1lbnRfJHtyb29tSWR9XyR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKX0uY3N2YCxcclxuICAgICk7XHJcblxyXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsaW5rKTtcclxuICAgIGxpbmsuY2xpY2soKTtcclxuXHJcbiAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xyXG4gICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgaGV4VG9SZ2IoaGV4OiBzdHJpbmcpOiBbbnVtYmVyLCBudW1iZXIsIG51bWJlcl0ge1xyXG4gICAgY29uc3QgY2xlYW5IZXggPSBoZXgucmVwbGFjZSgnIycsICcnKS50cmltKCk7XHJcbiAgICBpZiAoY2xlYW5IZXgubGVuZ3RoID09PSA2KSB7XHJcbiAgICAgIHJldHVybiBbXHJcbiAgICAgICAgcGFyc2VJbnQoY2xlYW5IZXguc3Vic3RyaW5nKDAsIDIpLCAxNiksXHJcbiAgICAgICAgcGFyc2VJbnQoY2xlYW5IZXguc3Vic3RyaW5nKDIsIDQpLCAxNiksXHJcbiAgICAgICAgcGFyc2VJbnQoY2xlYW5IZXguc3Vic3RyaW5nKDQsIDYpLCAxNiksXHJcbiAgICAgIF07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gWzE2LCAxODUsIDEyOV07XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGdldEJhc2U2NExvZ28odXJsOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xyXG4gICAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcclxuICAgICAgaW1nLmNyb3NzT3JpZ2luID0gJ0Fub255bW91cyc7XHJcblxyXG4gICAgICBpbWcub25sb2FkID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xyXG5cclxuICAgICAgICBjb25zdCB3aWR0aCA9IGltZy53aWR0aCB8fCA1NTA7XHJcbiAgICAgICAgY29uc3QgaGVpZ2h0ID0gaW1nLmhlaWdodCB8fCAxNjA7XHJcblxyXG4gICAgICAgIGNhbnZhcy53aWR0aCA9IHdpZHRoICogMztcclxuICAgICAgICBjYW52YXMuaGVpZ2h0ID0gaGVpZ2h0ICogMztcclxuXHJcbiAgICAgICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XHJcbiAgICAgICAgaWYgKCFjdHgpIHJldHVybiByZXNvbHZlKG51bGwpO1xyXG5cclxuICAgICAgICBjdHguZHJhd0ltYWdlKGltZywgMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcclxuICAgICAgICByZXNvbHZlKGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL3BuZycpKTtcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGltZy5vbmVycm9yID0gKCkgPT4gcmVzb2x2ZShudWxsKTtcclxuICAgICAgaW1nLnNyYyA9IHVybDtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2VuZXJhdGVBdWRpdExvZygpIHtcclxuICAgIGNvbnN0IGNvbmZpZyA9IHRoaXMuY29uZmlnU2VydmljZS5jb25maWcoKTtcclxuICAgIGNvbnN0IHJlcG9ydEhlYWRpbmcgPSBjb25maWcuYnJhbmROYW1lO1xyXG5cclxuICAgIGNvbnN0IHJnYkNvbG9yID0gdGhpcy5oZXhUb1JnYihjb25maWcuYnJhbmRDb2xvckhleCB8fCAnIzEwYjk4MScpO1xyXG4gICAgY29uc3QgYmFzZTY0TG9nbyA9IGF3YWl0IHRoaXMuZ2V0QmFzZTY0TG9nbyhjb25maWcubG9nb1VybCk7XHJcblxyXG4gICAgY29uc3QgeyBkb2MsIGZpbGVuYW1lIH0gPSBhd2FpdCB0aGlzLnNvY2tldC5nZXRBdWRpdExvZ1BkZih7XHJcbiAgICAgIGJyYW5kTmFtZTogcmVwb3J0SGVhZGluZyxcclxuICAgICAgYnJhbmRDb2xvcjogcmdiQ29sb3IsXHJcbiAgICAgIGxvZ29EYXRhVXJsOiBiYXNlNjRMb2dvIHx8IHVuZGVmaW5lZCxcclxuICAgICAgaXNXaGl0ZWxhYmVsOiBjb25maWcud2hpdGVsYWJlbCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgZG9jLnNhdmUoZmlsZW5hbWUpO1xyXG4gIH1cclxuXHJcbiAgZ2V0UGRmRG9jdW1lbnQoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5zb2NrZXQuZ2V0QXVkaXRMb2dQZGYoKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgc3RhcnRUaW1lcihleHBpcnlUaW1lOiBudW1iZXIpIHtcclxuICAgIGlmICh0aGlzLnRpbWVySW50ZXJ2YWwpIGNsZWFySW50ZXJ2YWwodGhpcy50aW1lckludGVydmFsKTtcclxuXHJcbiAgICB0aGlzLnRpbWVySW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XHJcbiAgICAgIGNvbnN0IGRpZmYgPSBleHBpcnlUaW1lIC0gbm93O1xyXG5cclxuICAgICAgaWYgKGRpZmYgPD0gMCkge1xyXG4gICAgICAgIHRoaXMudGltZVJlbWFpbmluZy5zZXQoJzAwIGhycyAwMCBtIDAwIHMnKTtcclxuICAgICAgICB0aGlzLmlzRXhwaXJlZC5zZXQodHJ1ZSk7XHJcbiAgICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLnRpbWVySW50ZXJ2YWwpO1xyXG4gICAgICAgIHRoaXMuc29ja2V0LmRpc2Nvbm5lY3QoKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBob3VycyA9IE1hdGguZmxvb3IoZGlmZiAvICgxMDAwICogNjAgKiA2MCkpO1xyXG4gICAgICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKChkaWZmICUgKDEwMDAgKiA2MCAqIDYwKSkgLyAoMTAwMCAqIDYwKSk7XHJcbiAgICAgICAgY29uc3Qgc2Vjb25kcyA9IE1hdGguZmxvb3IoKGRpZmYgJSAoMTAwMCAqIDYwKSkgLyAxMDAwKTtcclxuICAgICAgICBjb25zdCBwYWQgPSAobjogbnVtYmVyKSA9PiBuLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKTtcclxuXHJcbiAgICAgICAgdGhpcy50aW1lUmVtYWluaW5nLnNldChgJHtwYWQoaG91cnMpfSBocnMgJHtwYWQobWludXRlcyl9IG0gJHtwYWQoc2Vjb25kcyl9IHNgKTtcclxuICAgICAgICB0aGlzLmlzTG93VGltZS5zZXQoZGlmZiA8IDEyMDAwMCk7XHJcbiAgICAgIH1cclxuICAgIH0sIDEwMDApO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIHRyaWdnZXJDb25mZXR0aSgpIHtcclxuICAgIGltcG9ydCgnY2FudmFzLWNvbmZldHRpJykudGhlbigoYykgPT4gYy5kZWZhdWx0KCkpO1xyXG4gIH1cclxuXHJcbiAgY29weUhleCgpIHtcclxuICAgIHRoaXMuZG9Db3B5KHRoaXMuZmluYWxIZXgoKSB8fCAnJywgdGhpcy5jb3BpZWQpO1xyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXREYXRhQ29waWVkKCdmaW5hbC1oZXgnKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZG9Db3B5KHRleHQ6IHN0cmluZywgc2lnbmFsVG9Ub2dnbGU6IGFueSkge1xyXG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQodGV4dCk7XHJcbiAgICBpZiAoc2lnbmFsVG9Ub2dnbGUpIHtcclxuICAgICAgc2lnbmFsVG9Ub2dnbGUuc2V0KHRydWUpO1xyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNpZ25hbFRvVG9nZ2xlLnNldChmYWxzZSksIDIwMDApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldEZ1bGxTaGFyZUxpbmsoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLnNvY2tldC5nZXRSb29tTGluayh3aW5kb3cubG9jYXRpb24ub3JpZ2luLCB0cnVlKTtcclxuICB9XHJcblxyXG4gIG51ZGdlU2lnbmVyKGZpbmdlcnByaW50OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGxhYmVsID0gdGhpcy5nZXRTaWduZXJMYWJlbChmaW5nZXJwcmludCk7XHJcbiAgICBjb25zdCBtc2cgPSBgU2lnbmF0dXJlIG5lZWRlZCBmcm9tOiAke2xhYmVsfVxcbiR7dGhpcy5nZXRGdWxsU2hhcmVMaW5rKCl9YDtcclxuXHJcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChtc2cpLnRoZW4oKCkgPT4ge1xyXG4gICAgICB0aGlzLm9wZW5BbGVydChcclxuICAgICAgICAnTnVkZ2UgTWVzc2FnZSBDb3BpZWQnLFxyXG4gICAgICAgIGBOdWRnZSBtZXNzYWdlIGZvciAke2xhYmVsfSBjb3BpZWQhIFBhc3RlIGl0IGluIHlvdXIgY2hhdCBhcHAuYCxcclxuICAgICAgKTtcclxuICAgIH0pO1xyXG4gICAgdGhpcy5zb2NrZXQubG9nQWN0aW9uKCdOdWRnZSBTZW50JywgYFJlbWluZGVyIHNlbnQgdG8gJHtsYWJlbH1gKTtcclxuICB9XHJcblxyXG4gIG9wZW5TaGFyZU1vZGFsKCkge1xyXG4gICAgdGhpcy5zaG93U2hhcmVNb2RhbC5zZXQodHJ1ZSk7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdE1vZGFsVmlldygnU2hhcmUgUm9vbSBTZWN1cmVseScpO1xyXG4gIH1cclxuXHJcbiAgY2xvc2VTaGFyZU1vZGFsKCkge1xyXG4gICAgdGhpcy5zaG93U2hhcmVNb2RhbC5zZXQoZmFsc2UpO1xyXG4gIH1cclxuXHJcbiAgY29weVNlY3VyZUxpbmsoKSB7XHJcbiAgICBjb25zdCBiYXNlVXJsID0gd2luZG93LmxvY2F0aW9uLmhyZWYuc3BsaXQoJyMnKVswXTtcclxuICAgIHRoaXMuZG9Db3B5KGJhc2VVcmwsIHRoaXMuc2VjdXJlTGlua0NvcGllZCk7XHJcbiAgICB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ0xpbmsgQ29waWVkIChObyBLZXkpJywgJ1VzZXIgY29waWVkIHJvb20gbGluaycpO1xyXG5cclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0RGF0YUNvcGllZCgnc2hhcmUtbGluaycpO1xyXG4gICAgdGhpcy5jbG9zZVNoYXJlTW9kYWwoKTtcclxuICB9XHJcblxyXG4gIGNvcHlGdWxsTGluaygpIHtcclxuICAgIHRoaXMuZG9Db3B5KHRoaXMuZ2V0RnVsbFNoYXJlTGluaygpLCB0aGlzLmZ1bGxMaW5rQ29waWVkKTtcclxuICAgIHRoaXMuc29ja2V0LmxvZ0FjdGlvbignTGluayBDb3BpZWQgKFdpdGggS2V5KScsICdVc2VyIGNvcGllZCByb29tIGxpbmsnKTtcclxuXHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdERhdGFDb3BpZWQoJ3NoYXJlLWxpbmstZnVsbCcpO1xyXG4gICAgdGhpcy5jbG9zZVNoYXJlTW9kYWwoKTtcclxuICB9XHJcblxyXG4gIG9wZW5LZXlNb2RhbCgpIHtcclxuICAgIHRoaXMuc2hvd0tleU1vZGFsLnNldCh0cnVlKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0TW9kYWxWaWV3KCdSb29tIERlY3J5cHRpb24gS2V5Jyk7XHJcbiAgfVxyXG4gIGNsb3NlS2V5TW9kYWwoKSB7XHJcbiAgICB0aGlzLnNob3dLZXlNb2RhbC5zZXQoZmFsc2UpO1xyXG4gIH1cclxuXHJcbiAgb3BlbkFkbWluTW9kYWwoKSB7XHJcbiAgICB0aGlzLnNob3dBZG1pbk1vZGFsLnNldCh0cnVlKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0TW9kYWxWaWV3KCdCYWNrdXAgQWRtaW4gVG9rZW4nKTtcclxuICB9XHJcblxyXG4gIGNsb3NlQWRtaW5Nb2RhbCgpIHtcclxuICAgIHRoaXMuc2hvd0FkbWluTW9kYWwuc2V0KGZhbHNlKTtcclxuICB9XHJcblxyXG4gIG9wZW5Sb29tSWRNb2RhbCgpIHtcclxuICAgIHRoaXMuc2hvd1Jvb21JZE1vZGFsLnNldCh0cnVlKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0TW9kYWxWaWV3KCdSb29tIElEJyk7XHJcbiAgfVxyXG4gIGNsb3NlUm9vbUlkTW9kYWwoKSB7XHJcbiAgICB0aGlzLnNob3dSb29tSWRNb2RhbC5zZXQoZmFsc2UpO1xyXG4gIH1cclxuXHJcbiAgY29weUtleSgpIHtcclxuICAgIHRoaXMuZG9Db3B5KHRoaXMuc29ja2V0LmdldFJvb21LZXkoKSB8fCAnJywgdGhpcy5rZXlDb3BpZWQpO1xyXG4gICAgdGhpcy5zb2NrZXQubG9nQWN0aW9uKCdLZXkgQ29waWVkJywgJ0NvcGllZCByb29tIGRlY3J5cHRpb24ga2V5Jyk7XHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdERhdGFDb3BpZWQoJ2RlY3J5cHRpb24ta2V5Jyk7XHJcbiAgICB0aGlzLmNsb3NlS2V5TW9kYWwoKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvcHlBZG1pblRva2VuKCkge1xyXG4gICAgY29uc3QgZW5jcnlwdGVkVG9rZW4gPSBzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKGBhZG1pbl90b2tlbl8ke3RoaXMucm9vbUlkKCl9YCk7XHJcbiAgICBjb25zdCByb29tS2V5ID0gdGhpcy5zb2NrZXQuZ2V0Um9vbUtleSgpO1xyXG5cclxuICAgIGlmIChlbmNyeXB0ZWRUb2tlbiAmJiByb29tS2V5KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcGxhaW5Ub2tlbiA9IGF3YWl0IHRoaXMuZW5jcnlwdGlvbkVuZ2luZS5kZWNyeXB0KGVuY3J5cHRlZFRva2VuLCByb29tS2V5KTtcclxuXHJcbiAgICAgICAgaWYgKHBsYWluVG9rZW4pIHtcclxuICAgICAgICAgIHRoaXMuZG9Db3B5KHBsYWluVG9rZW4sIHRoaXMuYWRtaW5Db3BpZWQpO1xyXG4gICAgICAgICAgdGhpcy5zb2NrZXQubG9nQWN0aW9uKCdBZG1pbiBUb2tlbiBDb3BpZWQnLCAnQmFja2VkIHVwIHRoZSBhZG1pbiB0b2tlbicpO1xyXG4gICAgICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXREYXRhQ29waWVkKCdhZG1pbi10b2tlbicpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBkZWNyeXB0IGFkbWluIHRva2VuIGZvciBjbGlwYm9hcmQnLCBlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5jbG9zZUFkbWluTW9kYWwoKTtcclxuICB9XHJcblxyXG4gIGNvcHlSb29tSWQoKSB7XHJcbiAgICBpZiAodGhpcy5yb29tSWQoKSkge1xyXG4gICAgICB0aGlzLmRvQ29weSh0aGlzLnJvb21JZCgpISwgdGhpcy5yb29tSWRDb3BpZWQpO1xyXG4gICAgICB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ1Jvb20gSUQgQ29waWVkJywgJ0NvcGllZCB0aGUgcm9vbSBpZGVudGlmaWVyJyk7XHJcbiAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0RGF0YUNvcGllZCgncm9vbS1pZCcpO1xyXG4gICAgICB0aGlzLmNsb3NlUm9vbUlkTW9kYWwoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGJsdXJTdGF0ZXMgPSBzaWduYWw8UmVjb3JkPFByaXZhY3lTZWN0aW9uLCBib29sZWFuPj4oe1xyXG4gICAgJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3JzogdHJ1ZSxcclxuICAgICd0cmFuc2FjdGlvbi1wcm9wb3NhbCc6IHRydWUsXHJcbiAgICAndHJhbnNhY3Rpb24tZGV0YWlscyc6IHRydWUsXHJcbiAgICBzaWduZXJzOiB0cnVlLFxyXG4gIH0pO1xyXG5cclxuICBzaG93UHJpdmFjeVdhcm5pbmcgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHBlbmRpbmdVbmJsdXJTZWN0aW9uID0gc2lnbmFsPFByaXZhY3lTZWN0aW9uIHwgbnVsbD4obnVsbCk7XHJcblxyXG4gIC8qKlxyXG4gICAqIEhhbmRsZXMgdGhlIGNsaWNrIG9mIHRoZSBFeWUgaWNvbiBmb3IgYW55IHNlY3Rpb24uXHJcbiAgICovXHJcbiAgdG9nZ2xlUHJpdmFjeUJsdXIoc2VjdGlvbjogUHJpdmFjeVNlY3Rpb24pIHtcclxuICAgIGlmICh0aGlzLmJsdXJTdGF0ZXMoKVtzZWN0aW9uXSkge1xyXG4gICAgICB0aGlzLnBlbmRpbmdVbmJsdXJTZWN0aW9uLnNldChzZWN0aW9uKTtcclxuICAgICAgdGhpcy5zaG93UHJpdmFjeVdhcm5pbmcuc2V0KHRydWUpO1xyXG5cclxuICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRNb2RhbFZpZXcoJ1RvZ2dsZSBQcml2YWN5IFdhcm5pbmcnLCBzZWN0aW9uKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuYmx1clN0YXRlcy51cGRhdGUoKHMpID0+ICh7IC4uLnMsIFtzZWN0aW9uXTogdHJ1ZSB9KSk7XHJcbiAgICAgIHRoaXMuc29ja2V0LmxvZ0FjdGlvbignUHJpdmFjeSBUb2dnbGUnLCBgUmUtYmx1cnJlZCAke3NlY3Rpb259IHNlY3Rpb25gKTtcclxuXHJcbiAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0UHJpdmFjeVRvZ2dsZShzZWN0aW9uLCAnaGlkZGVuJyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDYWxsZWQgd2hlbiB0aGUgdXNlciBjbGlja3MgXCJBY2tub3dsZWRnZSAmIFJldmVhbFwiIG9uIHRoZSBtb2RhbC5cclxuICAgKi9cclxuICBjb25maXJtVW5ibHVyKCkge1xyXG4gICAgY29uc3Qgc2VjdGlvbiA9IHRoaXMucGVuZGluZ1VuYmx1clNlY3Rpb24oKTtcclxuICAgIGlmIChzZWN0aW9uKSB7XHJcbiAgICAgIHRoaXMuYmx1clN0YXRlcy51cGRhdGUoKHMpID0+ICh7IC4uLnMsIFtzZWN0aW9uXTogZmFsc2UgfSkpO1xyXG4gICAgICB0aGlzLnNvY2tldC5sb2dBY3Rpb24oJ1ByaXZhY3kgVG9nZ2xlJywgYFJldmVhbGVkICR7c2VjdGlvbn0gc2VjdGlvbmApO1xyXG5cclxuICAgICAgLy8gRU1JVDogUmV2ZWFsIFNwZWNpZmljIFNlY3Rpb24gQWN0aW9uXHJcbiAgICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0UHJpdmFjeVRvZ2dsZShzZWN0aW9uLCAncmV2ZWFsLXNlY3Rpb24nKTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNob3dQcml2YWN5V2FybmluZy5zZXQoZmFsc2UpO1xyXG4gICAgdGhpcy5wZW5kaW5nVW5ibHVyU2VjdGlvbi5zZXQobnVsbCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDYWxsZWQgd2hlbiB0aGUgdXNlciBjbGlja3MgXCJSZXZlYWwgQWxsXCIgb24gdGhlIG1vZGFsLlxyXG4gICAqL1xyXG4gIGNvbmZpcm1VbmJsdXJBbGwoKSB7XHJcbiAgICB0aGlzLmJsdXJTdGF0ZXMuc2V0KHtcclxuICAgICAgJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3JzogZmFsc2UsXHJcbiAgICAgICd0cmFuc2FjdGlvbi1wcm9wb3NhbCc6IGZhbHNlLFxyXG4gICAgICAndHJhbnNhY3Rpb24tZGV0YWlscyc6IGZhbHNlLFxyXG4gICAgICBzaWduZXJzOiBmYWxzZSxcclxuICAgIH0pO1xyXG4gICAgdGhpcy5zb2NrZXQubG9nQWN0aW9uKCdQcml2YWN5IFRvZ2dsZScsIGBSZXZlYWxlZCBhbGwgc2VjdGlvbnNgKTtcclxuXHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFByaXZhY3lUb2dnbGUoJ2FsbCcgYXMgYW55LCAncmV2ZWFsLWFsbCcpO1xyXG5cclxuICAgIHRoaXMuc2hvd1ByaXZhY3lXYXJuaW5nLnNldChmYWxzZSk7XHJcbiAgICB0aGlzLnBlbmRpbmdVbmJsdXJTZWN0aW9uLnNldChudWxsKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENsb3NlcyB0aGUgcHJpdmFjeSB3YXJuaW5nIG1vZGFsIHdpdGhvdXQgcmV2ZWFsaW5nLlxyXG4gICAqL1xyXG4gIGNsb3NlUHJpdmFjeVdhcm5pbmcoKSB7XHJcbiAgICBjb25zdCBzZWN0aW9uID0gdGhpcy5wZW5kaW5nVW5ibHVyU2VjdGlvbigpO1xyXG4gICAgaWYgKHNlY3Rpb24pIHtcclxuICAgICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRQcml2YWN5VG9nZ2xlKHNlY3Rpb24sICdibHVycmVkJyk7XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zaG93UHJpdmFjeVdhcm5pbmcuc2V0KGZhbHNlKTtcclxuICAgIHRoaXMucGVuZGluZ1VuYmx1clNlY3Rpb24uc2V0KG51bGwpO1xyXG4gIH1cclxuXHJcbiAgb3BlbkZvdW50YWluTW9kYWwoKSB7XHJcbiAgICB0aGlzLnJlZ2VuZXJhdGVGcmFtZXMoKTtcclxuICAgIHRoaXMuc2hvd0ZvdW50YWluTW9kYWwuc2V0KHRydWUpO1xyXG4gICAgdGhpcy5pc0ZvdW50YWluUmV2ZWFsZWQuc2V0KGZhbHNlKTtcclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0TW9kYWxWaWV3KCdFeHBvcnQgUFNCVCAoQWlyLUdhcHBlZCknKTtcclxuICB9XHJcblxyXG4gIHNldEV4cG9ydEZvcm1hdChmb3JtYXQ6ICd1cicgfCAnYmJxcicpIHtcclxuICAgIHRoaXMuZXhwb3J0Rm9ybWF0LnNldChmb3JtYXQpO1xyXG4gICAgdGhpcy5kaXNwYXRjaGVyLmVtaXRGb3VudGFpbkZvcm1hdENoYW5nZWQoZm9ybWF0KTtcclxuXHJcbiAgICBpZiAodGhpcy5zaG93Rm91bnRhaW5Nb2RhbCgpKSB7XHJcbiAgICAgIHRoaXMucmVnZW5lcmF0ZUZyYW1lcygpO1xyXG5cclxuICAgICAgaWYgKHRoaXMuaXNGb3VudGFpblJldmVhbGVkKCkpIHtcclxuICAgICAgICB0aGlzLnN0YXJ0Rm91bnRhaW5BbmltYXRpb24oKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmVnZW5lcmF0ZUZyYW1lcygpIHtcclxuICAgIGNvbnN0IHBzYnREYXRhID0gdGhpcy5zb2NrZXQucm9vbVN0YXRlKCk/LnBzYnQ7XHJcbiAgICBpZiAoIXBzYnREYXRhKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAodGhpcy5leHBvcnRGb3JtYXQoKSA9PT0gJ3VyJykge1xyXG4gICAgICAgIHRoaXMuYWN0aXZlRm91bnRhaW5GcmFtZXMgPSB0aGlzLnVyU2VydmljZS5nZW5lcmF0ZUZyYW1lcyhwc2J0RGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdGhpcy5hY3RpdmVGb3VudGFpbkZyYW1lcyA9IHRoaXMudXJTZXJ2aWNlLmdlbmVyYXRlQkJRckZyYW1lcyhwc2J0RGF0YSk7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5jdXJyZW50RnJhbWVJbmRleC5zZXQoMCk7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBwcmVwYXJlIGZyYW1lcycsIGUpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdG9nZ2xlRm91bnRhaW5SZXZlYWwoKSB7XHJcbiAgICBjb25zdCBuZXh0U3RhdGUgPSAhdGhpcy5pc0ZvdW50YWluUmV2ZWFsZWQoKTtcclxuICAgIHRoaXMuaXNGb3VudGFpblJldmVhbGVkLnNldChuZXh0U3RhdGUpO1xyXG5cclxuICAgIHRoaXMuZGlzcGF0Y2hlci5lbWl0Rm91bnRhaW5TdGF0ZUNoYW5nZWQobmV4dFN0YXRlLCB0aGlzLmV4cG9ydEZvcm1hdCgpKTtcclxuXHJcbiAgICBpZiAobmV4dFN0YXRlKSB7XHJcbiAgICAgIHRoaXMuc29ja2V0LmxvZ0FjdGlvbihcclxuICAgICAgICAnUHJpdmFjeSBUb2dnbGUnLFxyXG4gICAgICAgIGBSZXZlYWxlZCAke3RoaXMuZXhwb3J0Rm9ybWF0KCkudG9VcHBlckNhc2UoKX0gUFNCVCBRUmAsXHJcbiAgICAgICk7XHJcbiAgICAgIHRoaXMuc3RhcnRGb3VudGFpbkFuaW1hdGlvbigpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5zb2NrZXQubG9nQWN0aW9uKFxyXG4gICAgICAgICdQcml2YWN5IFRvZ2dsZScsXHJcbiAgICAgICAgYEJsdXJyZWQgJHt0aGlzLmV4cG9ydEZvcm1hdCgpLnRvVXBwZXJDYXNlKCl9IFBTQlQgUVJgLFxyXG4gICAgICApO1xyXG4gICAgICB0aGlzLnN0b3BGb3VudGFpbkFuaW1hdGlvbigpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhcnRGb3VudGFpbkFuaW1hdGlvbigpIHtcclxuICAgIGlmICh0aGlzLmZvdW50YWluSW50ZXJ2YWwpIGNsZWFySW50ZXJ2YWwodGhpcy5mb3VudGFpbkludGVydmFsKTtcclxuXHJcbiAgICB0aGlzLmZvdW50YWluSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICAgIHRoaXMuY3VycmVudEZyYW1lSW5kZXgudXBkYXRlKChpKSA9PiAoaSArIDEpICUgdGhpcy5hY3RpdmVGb3VudGFpbkZyYW1lcy5sZW5ndGgpO1xyXG4gICAgICB0aGlzLnJlbmRlckZvdW50YWluRnJhbWUoKTtcclxuICAgIH0sIHRoaXMuZm91bnRhaW5TcGVlZCgpKTtcclxuXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMucmVuZGVyRm91bnRhaW5GcmFtZSgpLCAwKTtcclxuICB9XHJcblxyXG4gIHN0b3BGb3VudGFpbkFuaW1hdGlvbigpIHtcclxuICAgIGlmICh0aGlzLmZvdW50YWluSW50ZXJ2YWwpIGNsZWFySW50ZXJ2YWwodGhpcy5mb3VudGFpbkludGVydmFsKTtcclxuICB9XHJcblxyXG4gIGNsb3NlRm91bnRhaW5Nb2RhbCgpIHtcclxuICAgIHRoaXMuc2hvd0ZvdW50YWluTW9kYWwuc2V0KGZhbHNlKTtcclxuICAgIHRoaXMuaXNGb3VudGFpblJldmVhbGVkLnNldChmYWxzZSk7XHJcbiAgICB0aGlzLnN0b3BGb3VudGFpbkFuaW1hdGlvbigpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcmVuZGVyRm91bnRhaW5GcmFtZSgpIHtcclxuICAgIGlmICghdGhpcy5pc0ZvdW50YWluUmV2ZWFsZWQoKSkgcmV0dXJuO1xyXG4gICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2ZvdW50YWluLXBzYnQtY2FudmFzJykgYXMgSFRNTENhbnZhc0VsZW1lbnQ7XHJcbiAgICBpZiAoY2FudmFzICYmIHRoaXMuYWN0aXZlRm91bnRhaW5GcmFtZXMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb25zdCBmcmFtZSA9IHRoaXMuYWN0aXZlRm91bnRhaW5GcmFtZXNbdGhpcy5jdXJyZW50RnJhbWVJbmRleCgpXTtcclxuXHJcbiAgICAgIGF3YWl0IFFSQ29kZS50b0NhbnZhcyhjYW52YXMsIGZyYW1lLCB7XHJcbiAgICAgICAgd2lkdGg6IDMyMCxcclxuICAgICAgICBtYXJnaW46IDIsXHJcbiAgICAgICAgY29sb3I6IHsgZGFyazogJyMwMDAwMDAnLCBsaWdodDogJyNmZmZmZmYnIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RhcnRTY2FubmVyKCkge1xyXG4gICAgdGhpcy5zaG93U2Nhbm5lck1vZGFsLnNldCh0cnVlKTtcclxuICAgIHRoaXMuaXNTY2FubmluZ1NpZ25lZC5zZXQodHJ1ZSk7XHJcbiAgICB0aGlzLnVyU2VydmljZS5yZXNldERlY29kZXIoKTtcclxuXHJcbiAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdE1vZGFsVmlldygnSW1wb3J0IFBTQlQgKFNjYW5uZXIpJyk7XHJcblxyXG4gICAgc2V0VGltZW91dChhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRoaXMuaHRtbDVRckNvZGUgPSBuZXcgSHRtbDVRcmNvZGUoJ3NpZ25lci1yZWFkZXInLCB7XHJcbiAgICAgICAgZm9ybWF0c1RvU3VwcG9ydDogW0h0bWw1UXJjb2RlU3VwcG9ydGVkRm9ybWF0cy5RUl9DT0RFXSxcclxuICAgICAgICB2ZXJib3NlOiBmYWxzZSxcclxuICAgICAgICBleHBlcmltZW50YWxGZWF0dXJlczoge1xyXG4gICAgICAgICAgdXNlQmFyQ29kZURldGVjdG9ySWZTdXBwb3J0ZWQ6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBsZXQgZnJhbWVDb3VudCA9IDA7XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IHRoaXMuaHRtbDVRckNvZGUuc3RhcnQoXHJcbiAgICAgICAgICB7IGZhY2luZ01vZGU6ICdlbnZpcm9ubWVudCcgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgZnBzOiAxMCxcclxuICAgICAgICAgICAgZGlzYWJsZUZsaXA6IHRydWUsXHJcbiAgICAgICAgICAgIHFyYm94OiB7IHdpZHRoOiAzNTAsIGhlaWdodDogMzUwIH0sXHJcbiAgICAgICAgICAgIHZpZGVvQ29uc3RyYWludHM6IHtcclxuICAgICAgICAgICAgICB3aWR0aDogeyBpZGVhbDogMTI4MCB9LFxyXG4gICAgICAgICAgICAgIGhlaWdodDogeyBpZGVhbDogNzIwIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgKGRlY29kZWRUZXh0KSA9PiB0aGlzLmhhbmRsZVNjYW5SZXN1bHQoZGVjb2RlZFRleHQpLFxyXG4gICAgICAgICAgKGVycm9yTWVzc2FnZSkgPT4ge1xyXG4gICAgICAgICAgICBmcmFtZUNvdW50Kys7XHJcbiAgICAgICAgICAgIGlmIChmcmFtZUNvdW50ICUgNjAgPT09IDApIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLndhcm4oXHJcbiAgICAgICAgICAgICAgICBgW09wdGljYWwgRGVidWddIEZyYW1lICR7ZnJhbWVDb3VudH0gLSBFbmdpbmUgZmFpbGluZyB0byBsb2NrOmAsXHJcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2Uuc3BsaXQoJ1xcbicpWzBdLFxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS53YXJuKCdIaWdoLXJlcyBjYW1lcmEgc3RhcnQgZmFpbGVkLiBGYWxsaW5nIGJhY2sgdG8gc3RhbmRhcmQgcmVzb2x1dGlvbi4uLicsIGVycik7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCB0aGlzLmh0bWw1UXJDb2RlLnN0YXJ0KFxyXG4gICAgICAgICAgICB7IGZhY2luZ01vZGU6ICdlbnZpcm9ubWVudCcgfSxcclxuICAgICAgICAgICAgeyBmcHM6IDEwLCBkaXNhYmxlRmxpcDogZmFsc2UgfSxcclxuICAgICAgICAgICAgKGRlY29kZWRUZXh0KSA9PiB0aGlzLmhhbmRsZVNjYW5SZXN1bHQoZGVjb2RlZFRleHQpLFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignRmFsbGJhY2sgY2FtZXJhIGZhaWxlZCB0byBzdGFydC4nKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSBjYXRjaCAoZmFsbGJhY2tFcnIpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhbGxiYWNrIGNhbWVyYSBzdGFydCBhbHNvIGZhaWxlZDonLCBmYWxsYmFja0Vycik7XHJcbiAgICAgICAgICB0aGlzLnN0b3BTY2FubmVyKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9LCAxMDApO1xyXG4gIH1cclxuXHJcbiAgaGFuZGxlU2NhblJlc3VsdChkZWNvZGVkVGV4dDogc3RyaW5nKSB7XHJcbiAgICBjb25zb2xlLmxvZygnU2Nhbm5lZCBmcmFnbWVudDonLCBkZWNvZGVkVGV4dC5zdWJzdHJpbmcoMCwgODApICsgJy4uLicpO1xyXG5cclxuICAgIGNvbnN0IGZ1bGxIZXggPSB0aGlzLnVyU2VydmljZS5wcm9jZXNzRnJhZ21lbnQoZGVjb2RlZFRleHQpO1xyXG5cclxuICAgIGlmIChmdWxsSGV4KSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKCdGdWxsIFBTQlQgZGVjb2RlZCwgbGVuZ3RoOicsIGZ1bGxIZXgubGVuZ3RoKTtcclxuICAgICAgdGhpcy5zdG9wU2Nhbm5lcigpO1xyXG4gICAgICB0aGlzLnByb2Nlc3NTY2FubmVkU2lnbmF0dXJlKGZ1bGxIZXgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc3RvcFNjYW5uZXIoKSB7XHJcbiAgICBpZiAodGhpcy5odG1sNVFyQ29kZSkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmICh0aGlzLmh0bWw1UXJDb2RlLmdldFN0YXRlKCkgPT09IDIpIHtcclxuICAgICAgICAgIHRoaXMuaHRtbDVRckNvZGVcclxuICAgICAgICAgICAgLnN0b3AoKVxyXG4gICAgICAgICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgdGhpcy5odG1sNVFyQ29kZT8uY2xlYXIoKTtcclxuICAgICAgICAgICAgICB0aGlzLmlzU2Nhbm5pbmdTaWduZWQuc2V0KGZhbHNlKTtcclxuICAgICAgICAgICAgICB0aGlzLnNob3dTY2FubmVyTW9kYWwuc2V0KGZhbHNlKTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICAgICAgICB0aGlzLmh0bWw1UXJDb2RlPy5jbGVhcigpO1xyXG4gICAgICAgICAgICAgIHRoaXMuaXNTY2FubmluZ1NpZ25lZC5zZXQoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIHRoaXMuc2hvd1NjYW5uZXJNb2RhbC5zZXQoZmFsc2UpO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5odG1sNVFyQ29kZS5jbGVhcigpO1xyXG4gICAgICAgICAgdGhpcy5pc1NjYW5uaW5nU2lnbmVkLnNldChmYWxzZSk7XHJcbiAgICAgICAgICB0aGlzLnNob3dTY2FubmVyTW9kYWwuc2V0KGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICB0aGlzLmh0bWw1UXJDb2RlLmNsZWFyKCk7XHJcbiAgICAgICAgdGhpcy5pc1NjYW5uaW5nU2lnbmVkLnNldChmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5zaG93U2Nhbm5lck1vZGFsLnNldChmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuaXNTY2FubmluZ1NpZ25lZC5zZXQoZmFsc2UpO1xyXG4gICAgICB0aGlzLnNob3dTY2FubmVyTW9kYWwuc2V0KGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2Nlc3NTY2FubmVkU2lnbmF0dXJlKGRhdGE6IHN0cmluZykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY2xlYW4gPSBkYXRhLnJlcGxhY2UoL1xccysvZywgJycpO1xyXG4gICAgICBjb25zdCBwc2J0Qnl0ZXMgPSAvXlswLTlhLWZBLUZdKyQvLnRlc3QoY2xlYW4pID8gaGV4LmRlY29kZShjbGVhbikgOiBiYXNlNjQuZGVjb2RlKGNsZWFuKTtcclxuICAgICAgY29uc3Qgbm9ybWFsaXplZEJhc2U2NCA9IGJhc2U2NC5lbmNvZGUocHNidEJ5dGVzKTtcclxuXHJcbiAgICAgIGF3YWl0IHRoaXMuc29ja2V0LnVwbG9hZFNpZ25hdHVyZShub3JtYWxpemVkQmFzZTY0KTtcclxuICAgICAgY29uc29sZS5sb2coJ1N1Y2Nlc3NmdWxseSBpbmdlc3RlZCBzaWduZWQgUFNCVCB2aWEgb3B0aWNzIScpO1xyXG4gICAgICB0aGlzLmRpc3BhdGNoZXIuZW1pdFBzYnRJbXBvcnRlZCgnc2NhbicpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gcGFyc2Ugc2lnbmVkIFBTQlQgZnJvbSBzY2FubmVyJywgZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1cGRhdGVGb3VudGFpblNwZWVkKG5ld1NwZWVkOiBudW1iZXIpIHtcclxuICAgIHRoaXMuZm91bnRhaW5TcGVlZC5zZXQoTnVtYmVyKG5ld1NwZWVkKSk7XHJcblxyXG4gICAgaWYgKHRoaXMuaXNGb3VudGFpblJldmVhbGVkKCkgJiYgdGhpcy5zaG93Rm91bnRhaW5Nb2RhbCgpKSB7XHJcbiAgICAgIHRoaXMuc3RhcnRGb3VudGFpbkFuaW1hdGlvbigpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJAaWYgKHNvY2tldC5zdGF0dXMoKSAhPT0gJ2Nvbm5lY3RlZCcgJiYgIXNvY2tldC5pc0Nsb3NlZCgpICYmICFpc0V4cGlyZWQoKSAmJiAhc29ja2V0LnJvb21Ob3RGb3VuZCgpICYmICFzb2NrZXQuaXNMb2NrZWRPdXQoKSAmJiAhc29ja2V0LmlzUm9vbUZ1bGwoKSAmJiAhc29ja2V0LmRlY3J5cHRpb25FcnJvcigpKSB7XHJcbiAgICA8ZGl2IGlkPVwiYmFubmVyLXJlY29ubmVjdGluZ1wiIGNsYXNzPVwidy1mdWxsIGJnLWFtYmVyLTUwMC85MCB0ZXh0LWJyYW5kLWJnIHRleHQtY2VudGVyIHRleHQteHMgZm9udC1ib2xkIHB5LTEuNSBmaXhlZCB0b3AtMCB6LVsyMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGFuaW1hdGUtcHVsc2VcIj5cclxuICAgICAgICA8c3ZnIGx1Y2lkZUxvYWRlcjIgY2xhc3M9XCJ3LTMgaC0zIGFuaW1hdGUtc3BpblwiPjwvc3ZnPlxyXG4gICAgICAgIENvbm5lY3Rpb24gbG9zdC4uLiBSZWNvbm5lY3RpbmcuLi5cclxuICAgIDwvZGl2PlxyXG59XHJcblxyXG5AaWYgKHNob3dQc2J0TW9kYWwoKSkge1xyXG48ZGl2IGlkPVwibW9kYWwtZG93bmxvYWQtcHNidFwiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJyYW5kLWJnLzgwIGJhY2tkcm9wLWJsdXItc20gcC00IGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVEb3dubG9hZENsb3VkIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLWFjY2VudFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dFwiPkRvd25sb2FkIFVuc2lnbmVkIFBTQlQ8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1tb2RhbC1jbG9zZVwiIChjbGljayk9XCJzaG93UHNidE1vZGFsLnNldChmYWxzZSlcIiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC02IGZsZXggZmxleC1jb2wgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1hY2NlbnQvMTAgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgcm91bmRlZC1sZyBwLTMgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLWFjY2VudCBzaHJpbmstMCBtdC0wLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJyYW5kLWFjY2VudCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlByaXZhY3kgV2FybmluZzo8L3N0cm9uZz4gVGhpcyBmaWxlIGNvbnRhaW5zIHVuZW5jcnlwdGVkIG1ldGFkYXRhIGFib3V0IHlvdXIgd2FsbGV0IGJhbGFuY2VzLCBVVFhPcywgYW5kIGRlc3RpbmF0aW9uIGFkZHJlc3Nlcy4gXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgWW91IGFyZSBkb3dubG9hZGluZyB0aGlzIHRvIHRyYW5zZmVyIHRvIGEgQ29sZGNhcmQgb3IgYWlyLWdhcHBlZCBoYXJkd2FyZSB3YWxsZXQuIEJlY2F1c2UgdGhpcyBmaWxlIGlzIHBsYWludGV4dCwgcGxlYXNlIGVuc3VyZSBpdCBpcyBzZWN1cmVseSBoYW5kbGVkLCBhcmNoaXZlZCwgb3Igd2lwZWQgYWZ0ZXIgdXNlIGFjY29yZGluZyB0byB5b3VyIHNlY3VyaXR5IHByb2NlZHVyZXMuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZ2FwLTMgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1jYW5jZWwtZG93bmxvYWRcIiAoY2xpY2spPVwic2hvd1BzYnRNb2RhbC5zZXQoZmFsc2UpXCIgY2xhc3M9XCJmbGV4LTEgcHktMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyLzUwIHRyYW5zaXRpb24gZm9udC1ib2xkIHRleHQteHMgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1jb25maXJtLWRvd25sb2FkXCIgKGNsaWNrKT1cImV4ZWN1dGVQc2J0RG93bmxvYWQoKVwiIGNsYXNzPVwiZmxleC0xIHB5LTIuNSBiZy1icmFuZC1hY2NlbnQvMjAgaG92ZXI6YmctYnJhbmQtYWNjZW50LzMwIHRleHQtYnJhbmQtYWNjZW50IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRG93bmxvYWQgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgRG93bmxvYWQgUFNCVFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbjwvZGl2PlxyXG59XHJcblxyXG5AaWYgKHNob3dBdWRpdE1vZGFsKCkpIHtcclxuPGRpdiBpZD1cIm1vZGFsLWRvd25sb2FkLWF1ZGl0XCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzEwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvODAgYmFja2Ryb3AtYmx1ci1zbSBwLTQgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcmVsYXRpdmVcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJvcmRlci1iIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUZpbGVDaGVjayBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHRcIj5Eb3dubG9hZCBBdWRpdCBMb2c8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1tb2RhbC1jbG9zZVwiIChjbGljayk9XCJzaG93QXVkaXRNb2RhbC5zZXQoZmFsc2UpXCIgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWCBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNiBmbGV4IGZsZXgtY29sIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LWZ1bGwgYmctYnJhbmQtYWNjZW50LzEwIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzIwIHJvdW5kZWQtbGcgcC0zIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQWxlcnRUcmlhbmdsZSBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC1hY2NlbnQgc2hyaW5rLTAgbXQtMC41XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC1hY2NlbnQgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Db25maWRlbnRpYWwgRGF0YTo8L3N0cm9uZz4gVGhpcyBQREYgY29udGFpbnMgYSBjb21wbGV0ZSwgdW5lbmNyeXB0ZWQgcmVjb3JkIG9mIHRoZSBjZXJlbW9ueSwgaW5jbHVkaW5nIHRyYW5zYWN0aW9uIGRldGFpbHMsIHBhcnRpY2lwYW50IGlkZW50aXRpZXMsIGFuZCBhY3Rpb24gdGltZXN0YW1wcy5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICBQbGVhc2UgZW5zdXJlIGl0IGlzIHN0b3JlZCBzZWN1cmVseSBhbmQgb25seSBzaGFyZWQgd2l0aCBhdXRob3JpemVkIHBhcnRpY2lwYW50cyBvciB0cnVzdGVkIHRoaXJkIHBhcnRpZXMuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZ2FwLTMgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1jYW5jZWwtZG93bmxvYWRcIiAoY2xpY2spPVwic2hvd0F1ZGl0TW9kYWwuc2V0KGZhbHNlKVwiIGNsYXNzPVwiZmxleC0xIHB5LTIuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlci81MCB0cmFuc2l0aW9uIGZvbnQtYm9sZCB0ZXh0LXhzIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY29uZmlybS1kb3dubG9hZFwiIChjbGljayk9XCJleGVjdXRlQXVkaXREb3dubG9hZCgpXCIgY2xhc3M9XCJmbGV4LTEgcHktMi41IGJnLWJyYW5kLWFjY2VudC8yMCBob3ZlcjpiZy1icmFuZC1hY2NlbnQvMzAgdGV4dC1icmFuZC1hY2NlbnQgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8yMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVEb3dubG9hZCBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBQREZcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxufVxyXG5cclxuQGlmIChzaG93Q3N2TW9kYWwoKSkge1xyXG48ZGl2IGlkPVwibW9kYWwtZG93bmxvYWQtY3N2XCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzEwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvODAgYmFja2Ryb3AtYmx1ci1zbSBwLTQgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcmVsYXRpdmVcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJvcmRlci1iIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZURvd25sb2FkIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0XCI+RG93bmxvYWQgQ1NWIERhdGE8L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1tb2RhbC1jbG9zZVwiIChjbGljayk9XCJzaG93Q3N2TW9kYWwuc2V0KGZhbHNlKVwiIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVggY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwLTYgZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIGJnLWJsdWUtNTAwLzEwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMjAgcm91bmRlZC1sZyBwLTMgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwIHNocmluay0wIG10LTAuNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYmx1ZS0yMDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Db25maWRlbnRpYWwgRGF0YTo8L3N0cm9uZz4gVGhpcyBzcHJlYWRzaGVldCBjb250YWlucyB1bmVuY3J5cHRlZCBzZXR0bGVtZW50IGRhdGEgYW5kIHBhcnRpY2lwYW50IG1ldGFkYXRhLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgIFBsZWFzZSBlbnN1cmUgaXQgaXMgc3RvcmVkIHNlY3VyZWx5IGFuZCBvbmx5IHNoYXJlZCB3aXRoIGF1dGhvcml6ZWQgcGFydGljaXBhbnRzIG9yIHRydXN0ZWQgdGhpcmQgcGFydGllcy5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBnYXAtMyBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWNhbmNlbC1kb3dubG9hZFwiIChjbGljayk9XCJzaG93Q3N2TW9kYWwuc2V0KGZhbHNlKVwiIGNsYXNzPVwiZmxleC0xIHB5LTIuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlci81MCB0cmFuc2l0aW9uIGZvbnQtYm9sZCB0ZXh0LXhzIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY29uZmlybS1kb3dubG9hZFwiIChjbGljayk9XCJleGVjdXRlQ3N2RG93bmxvYWQoKVwiIGNsYXNzPVwiZmxleC0xIHB5LTIuNSBiZy1ibHVlLTUwMC8yMCBob3ZlcjpiZy1ibHVlLTUwMC8zMCB0ZXh0LWJsdWUtNDAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8yMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVEb3dubG9hZCBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBDU1ZcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxufVxyXG5cclxuQGlmIChzaG93Um9vbUlkTW9kYWwoKSkge1xyXG4gICAgPGRpdiBpZD1cIm1vZGFsLXJvb20taWRcIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMTAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy84MCBiYWNrZHJvcC1ibHVyLXNtIHAtNCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUhhc2ggY2xhc3M9XCJ3LTUgaC01IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dFwiPlJvb20gSWRlbnRpZmllcjwvaDM+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tbW9kYWwtY2xvc2VcIiAoY2xpY2spPVwiY2xvc2VSb29tSWRNb2RhbCgpXCIgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVggY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTYgZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1hY2NlbnQvMTAgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgcm91bmRlZC1sZyBwLTMgZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLWFjY2VudCBzaHJpbmstMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJyYW5kLWFjY2VudC84MCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5QdWJsaWMgUm91dGluZyBEYXRhOjwvc3Ryb25nPiBUaGlzIElEIGRpcmVjdHMgc2lnbmVycyB0byB0aGUgY29ycmVjdCByb29tLCBidXQgaXQgPGVtPmNhbm5vdDwvZW0+IGRlY3J5cHQgdGhlIHRyYW5zYWN0aW9uIGRhdGEgd2l0aG91dCB0aGUgcHJpdmF0ZSBEZWNyeXB0aW9uIEtleS5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgSWYgeW91IGFyZSBwcmFjdGljaW5nIHN0cmljdCBPcGVyYXRpb25hbCBTZWN1cml0eSAoT3BTZWMpLCBzZW5kIHRoaXMgUm9vbSBJRCB0byB5b3VyIHNpZ25lcnMgZmlyc3QuIFNlbmQgdGhlIERlY3J5cHRpb24gS2V5IGxhdGVyIHZpYSBhIHNlcGFyYXRlLCBzZWN1cmUgY2hhbm5lbCAoZS5nLiwgU2lnbmFsIHZzIEVtYWlsKS5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY29weS1yb29tLWlkLW1vZGFsXCIgKGNsaWNrKT1cImNvcHlSb29tSWQoKVwiIGNsYXNzPVwibXQtMiB3LWZ1bGwgcHktMi41IGJnLWJyYW5kLWFjY2VudC8yMCBob3ZlcjpiZy1icmFuZC1hY2NlbnQvMzAgdGV4dC1icmFuZC1hY2NlbnQgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8yMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQGlmIChyb29tSWRDb3BpZWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNvcHkgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHt7IHJvb21JZENvcGllZCgpID8gJ1Jvb20gSUQgQ29waWVkIScgOiAnQ29weSBSb29tIElEJyB9fVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbn1cclxuXHJcbkBpZiAoc2hvd0xhYmVsTW9kYWwoKSkge1xyXG48ZGl2IGlkPVwibW9kYWwtbGFiZWwtc2lnbmVyXCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzIwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvODAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWZhZGUtaW5cIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcC02IHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgbWF4LXctc20gdy1mdWxsXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzcz1cInRleHQtYnJhbmQtdGV4dCBmb250LWJvbGRcIj5MYWJlbCBTaWduZXI8L2gzPlxyXG4gICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLW1vZGFsLWNsb3NlXCIgKGNsaWNrKT1cImNsb3NlTGFiZWxNb2RhbCgpXCIgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IGN1cnNvci1wb2ludGVyXCI+PHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYi00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBmb250LW1vbm8gbWItMVwiPkZpbmdlcnByaW50PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtYnJhbmQtdGV4dCBmb250LW1vbm8gYmctYnJhbmQtYmcgcC0yIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAge3sgZWRpdGluZ0ZpbmdlcnByaW50KCkgfX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYi00XCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPkxhYmVsIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBbbmdNb2RlbF09XCJlZGl0aW5nTGFiZWwoKVwiIChuZ01vZGVsQ2hhbmdlKT1cImVkaXRpbmdMYWJlbC5zZXQoJGV2ZW50KVwiIChrZXl1cC5lbnRlcik9XCJzYXZlTGFiZWwoKVwiIFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEFsaWNlIChMZWRnZXIpXCIgYXV0b2ZvY3VzXHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dCB0ZXh0LXNtIHJvdW5kZWQteGwgYmxvY2sgcC0zIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtYWNjZW50IHRyYW5zaXRpb25cIi8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYi02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGN1cnNvci1wb2ludGVyIHNlbGVjdC1ub25lXCIgKGNsaWNrKT1cInNhdmVUb0Jvb2suc2V0KCFzYXZlVG9Cb29rKCkpXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTUgaC01IHJvdW5kZWQgYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYWNjZW50XT1cInNhdmVUb0Jvb2soKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJvcmRlci1icmFuZC1hY2NlbnRdPVwic2F2ZVRvQm9vaygpXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyXT1cIiFzYXZlVG9Cb29rKClcIj5cclxuICAgICAgICAgICAgICAgIEBpZiAoc2F2ZVRvQm9vaygpKSB7IDxzdmcgbHVjaWRlQ2hlY2sgY2xhc3M9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJyYW5kLWJnXCI+PC9zdmc+IH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LXNtIHRleHQtYnJhbmQtdGV4dFwiPlNhdmUgdG8gQWRkcmVzcyBCb29rPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxidXR0b24gKGNsaWNrKT1cInNhdmVMYWJlbCgpXCIgY2xhc3M9XCJ3LWZ1bGwgcHktMyBiZy1icmFuZC1hY2NlbnQgaG92ZXI6YmctYnJhbmQtYWNjZW50LWhvdmVyIHRleHQtYnJhbmQtYmcgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICBTYXZlIExhYmVsXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuPC9kaXY+XHJcbn1cclxuXHJcbkBpZiAoc29ja2V0LnJvb21Ob3RGb3VuZCgpKSB7XHJcbjxkaXYgaWQ9XCJtb2RhbC1lcnJvci1ub3QtZm91bmRcIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMjAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy85MCBiYWNrZHJvcC1ibHVyLXhsIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBwLTggcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNiBoLTE2IGJnLWJyYW5kLWNhcmQtYm9yZGVyLzUwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTZcIj5cclxuICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydE9jdGFnb24gY2xhc3M9XCJ3LTggaC04IHRleHQtYnJhbmQtdGV4dC1tdXRlZFwiPjwvc3ZnPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxoMiBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQgbWItMlwiPlJvb20gTm90IEZvdW5kPC9oMj5cclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBtYi04IHRleHQtc21cIj5cclxuICAgICAgICAgICAgVGhpcyByb29tIGRvZXMgbm90IGV4aXN0IG9yIGhhcyBleHBpcmVkLjxicj5cclxuICAgICAgICAgICAgUGxlYXNlIGNoZWNrIHRoZSBVUkwgb3IgY3JlYXRlIGEgbmV3IHNpZ25pbmcgc2Vzc2lvbi5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICAgQGlmICghaXNFbWJlZGRlZCkge1xyXG4gICAgICAgICAgICA8YSByb3V0ZXJMaW5rPVwiL2NyZWF0ZVwiIGNsYXNzPVwidy1mdWxsIHB5LTMgYmctYnJhbmQtYWNjZW50IGhvdmVyOmJnLWJyYW5kLWFjY2VudC1ob3ZlciB0ZXh0LWJyYW5kLWJnIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWmFwIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPiBDcmVhdGUgTmV3IFJvb21cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgIH1cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxufSBcclxuQGVsc2UgaWYgKHNvY2tldC5pc1Jvb21GdWxsKCkpIHtcclxuICAgIDxkaXYgaWQ9XCJtb2RhbC1lcnJvci1yb29tLWZ1bGxcIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMjAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy85MCBiYWNrZHJvcC1ibHVyLXhsIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcC04IHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgbWF4LXctbWQgdy1mdWxsIHRleHQtY2VudGVyIG14LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTYgaC0xNiBiZy1hbWJlci01MDAvMTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVc2VycyBjbGFzcz1cInctOCBoLTggdGV4dC1hbWJlci01MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQgbWItMlwiPlJvb20gRnVsbDwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLThcIj5UaGlzIHJvb20gaGFzIHJlYWNoZWQgaXRzIG1heGltdW0gY29ubmVjdGlvbiBsaW1pdC48L3A+XHJcbiAgICAgICAgICAgIEBpZiAoIWlzRW1iZWRkZWQpIHtcclxuICAgICAgICAgICAgICAgIDxhIHJvdXRlckxpbms9XCIvXCIgY2xhc3M9XCJ3LWZ1bGwgcHktMyBiZy1icmFuZC1jYXJkLWJvcmRlci81MCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQgZm9udC1ib2xkIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGRlY29yYXRpb24tMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQXJyb3dSaWdodCBjbGFzcz1cInctNCBoLTQgcm90YXRlLTE4MFwiPjwvc3ZnPiBSZXR1cm4gSG9tZVxyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxufVxyXG5AZWxzZSBpZiAoc29ja2V0LmlzTG9ja2VkT3V0KCkpIHtcclxuPGRpdiBpZD1cIm1vZGFsLWVycm9yLWFjY2Vzcy1kZW5pZWRcIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMjAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy85MCBiYWNrZHJvcC1ibHVyLXhsIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1yb3NlLTkwMC81MCBwLTggcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgdGV4dC1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIGxlZnQtMCB3LWZ1bGwgaC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1yb3NlLTUwMCB2aWEtb3JhbmdlLTUwMCB0by1yb3NlLTUwMFwiPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJ3LTE2IGgtMTYgYmctYnJhbmQtYmcgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNiByaW5nLTEgcmluZy1yb3NlLTUwMC81MFwiPlxyXG4gICAgICAgICAgICA8c3ZnIGx1Y2lkZUxvY2sgY2xhc3M9XCJ3LTggaC04IHRleHQtcm9zZS01MDBcIj48L3N2Zz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8aDIgY2xhc3M9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0IG1iLTJcIj5BY2Nlc3MgRGVuaWVkPC9oMj5cclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBtYi04IHRleHQtc21cIj5cclxuICAgICAgICAgICAgVGhlIENvb3JkaW5hdG9yIGhhcyBsb2NrZWQgdGhpcyByb29tLjxicj5cclxuICAgICAgICAgICAgTm8gbmV3IGd1ZXN0cyBjYW4gam9pbiB0aGUgc2Vzc2lvbiBhdCB0aGlzIHRpbWUuXHJcbiAgICAgICAgPC9wPlxyXG4gICAgICAgIEBpZiAoIWlzRW1iZWRkZWQpIHtcclxuICAgICAgICAgICAgPGEgcm91dGVyTGluaz1cIi9cIiBjbGFzcz1cInctZnVsbCBweS0zIGJnLWJyYW5kLWNhcmQtYm9yZGVyLzUwIGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dCBmb250LWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZGVjb3JhdGlvbi0wIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUFycm93UmlnaHQgY2xhc3M9XCJ3LTQgaC00IHJvdGF0ZS0xODBcIj48L3N2Zz4gUmV0dXJuIEhvbWVcclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgIH1cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxufVxyXG5AZWxzZSBpZiAoc29ja2V0LmRlY3J5cHRpb25FcnJvcigpKSB7XHJcbjxkaXYgaWQ9XCJtb2RhbC1kZWNyeXB0aW9uLWVudHJ5XCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzIwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvOTUgYmFja2Ryb3AtYmx1ci1tZCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGFuaW1hdGUtZmFkZS1pbi11cFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cIm1heC13LW1kIHctZnVsbCBwLTggdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNiBoLTE2IGJnLXJvc2UtNTAwLzEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTYgcmluZy0xIHJpbmctcm9zZS01MDAvMzBcIj5cclxuICAgICAgICAgICAgPHN2ZyBsdWNpZGVMb2NrIGNsYXNzPVwidy04IGgtOCB0ZXh0LXJvc2UtNTAwXCI+PC9zdmc+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGgyIGNsYXNzPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dCBtYi0yXCI+RGVjcnlwdGlvbiBLZXkgUmVxdWlyZWQ8L2gyPlxyXG4gICAgICAgIDxwIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLTYgdGV4dC1zbVwiPllvdXIgbGluayBpcyBtaXNzaW5nIHRoZSBwcml2YXRlIGRlY3J5cHRpb24ga2V5LiBQbGVhc2UgZW50ZXIgaXQgYmVsb3cgdG8gam9pbiB0aGUgcm9vbS48L3A+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZ2FwLTIgbWItNFwiPlxyXG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBbKG5nTW9kZWwpXT1cIm1hbnVhbEtleVwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgZGVjcnlwdGlvbiBrZXkuLi5cIiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQtc20gcm91bmRlZC1sZyBibG9jayBwLTIuNSBvdXRsaW5lLW5vbmVcIi8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwic3VibWl0S2V5KClcIiBbZGlzYWJsZWRdPVwiIW1hbnVhbEtleVwiIGNsYXNzPVwidy1mdWxsIHB5LTMgYmctcm9zZS01MDAgaG92ZXI6Ymctcm9zZS00MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgPHN2ZyBsdWNpZGVSZWZyZXNoQ3cgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+IERlY3J5cHQgUm9vbVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbjwvZGl2PlxyXG59XHJcblxyXG5AaWYgKHNob3dSZW5hbWVNb2RhbCgpKSB7XHJcbjxkaXYgaWQ9XCJtb2RhbC1yZW5hbWUtcm9vbVwiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJyYW5kLWJnLzgwIGJhY2tkcm9wLWJsdXItc20gcC00IGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVUYWcgY2xhc3M9XCJ3LTUgaC01IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0XCI+UmVuYW1lIFJvb208L2gzPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1tb2RhbC1jbG9zZVwiIChjbGljayk9XCJjbG9zZVJlbmFtZU1vZGFsKClcIiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNlwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtc20gdGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIEdpdmUgdGhpcyByb29tIGEgbGFiZWwgdG8gbWFrZSBpdCBlYXNpZXIgdG8gaWRlbnRpZnkuIFRoaXMgbmFtZSBpcyB2aXNpYmxlIHRvIGFsbCBwYXJ0aWNpcGFudHMuXHJcbiAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Sb29tIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyBmb250LW1vbm9cIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtcmVkLTQwMF09XCJuZXdSb29tTmFtZSgpLmxlbmd0aCA+IDY0XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwibmV3Um9vbU5hbWUoKS5sZW5ndGggPD0gNjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3sgbmV3Um9vbU5hbWUoKS5sZW5ndGggfX0gLyA2NFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBbbmdNb2RlbF09XCJuZXdSb29tTmFtZSgpXCIgKG5nTW9kZWxDaGFuZ2UpPVwibmV3Um9vbU5hbWUuc2V0KCRldmVudClcIiAoa2V5dXAuZW50ZXIpPVwic2F2ZVJvb21OYW1lKClcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1heGxlbmd0aD1cIjY0XCIgcGxhY2Vob2xkZXI9XCJlLmcuIFExIFRyZWFzdXJ5IEJvYXJkIFZvdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIGJnLWJyYW5kLWJnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC1sZyBweC00IHB5LTMgdGV4dC1icmFuZC10ZXh0IHBsYWNlaG9sZGVyOnRleHQtYnJhbmQtdGV4dC1tdXRlZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLWFjY2VudC81MCB0cmFuc2l0aW9uXCIgYXV0b2ZvY3VzIC8+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIEBpZiAobmV3Um9vbU5hbWUoKS5sZW5ndGggPj0gNjQpIHtcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1yZWQtNDAwIGFuaW1hdGUtcHVsc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTWF4aW11bSBsZW5ndGggcmVhY2hlZC5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJnLWJyYW5kLWJnLzUwIGJvcmRlci10IGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY2FuY2VsLWRvd25sb2FkXCIgKGNsaWNrKT1cImNsb3NlUmVuYW1lTW9kYWwoKVwiIGNsYXNzPVwicHgtNCBweS0yIHJvdW5kZWQtbGcgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlci81MCB0cmFuc2l0aW9uIHRleHQtc20gZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwic2F2ZVJvb21OYW1lKClcIiBjbGFzcz1cInB4LTYgcHktMiByb3VuZGVkLWxnIGJnLWJyYW5kLWFjY2VudCBob3ZlcjpiZy1icmFuZC1hY2NlbnQtaG92ZXIgdGV4dC1icmFuZC1iZyBmb250LWJvbGQgdGV4dC1zbSB0cmFuc2l0aW9uIHNoYWRvdy1sZyBzaGFkb3ctYnJhbmQtYWNjZW50LzIwIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICBTYXZlIE5hbWVcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgPC9kaXY+XHJcbjwvZGl2PlxyXG59XHJcblxyXG5AaWYgKHNob3dRck1vZGFsKCkpIHtcclxuPGRpdiBpZD1cIm1vZGFsLXFyLWNvZGVcIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMTAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy84MCBiYWNrZHJvcC1ibHVyLXNtIHAtNCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtY2FyZCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgbWF4LXctc20gdy1mdWxsIG92ZXJmbG93LWhpZGRlbiByZWxhdGl2ZVwiPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlUXJDb2RlIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLWFjY2VudFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dFwiPlJvb20gUVIgQ29kZTwvaDM+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLW1vZGFsLWNsb3NlXCIgKGNsaWNrKT1cImNsb3NlUXIoKVwiIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVggY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC02IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIGZsZXggYmctYnJhbmQtYmcgcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXRvZ2dsZS1xci1saW5rLW9ubHlcIiAoY2xpY2spPVwidG9nZ2xlUXJLZXkoZmFsc2UpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZmxleC0xIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLW1kIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJnLWJyYW5kLWNhcmQtYm9yZGVyXT1cIiFxckluY2x1ZGVzS2V5KClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC1hY2NlbnRdPVwiIXFySW5jbHVkZXNLZXkoKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwicXJJbmNsdWRlc0tleSgpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGQgY2xhc3M9XCJ3LTMgaC0zXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgTGluayBPbmx5XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tdG9nZ2xlLXFyLWZ1bGxcIiAoY2xpY2spPVwidG9nZ2xlUXJLZXkodHJ1ZSlcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmbGV4LTEgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtY2FyZC1ib3JkZXJdPVwicXJJbmNsdWRlc0tleSgpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYW1iZXItNDAwXT1cInFySW5jbHVkZXNLZXkoKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiIXFySW5jbHVkZXNLZXkoKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlS2V5IGNsYXNzPVwidy0zIGgtM1wiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIEZ1bGwgKExpbmsgKyBLZXkpXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICBAaWYgKHFySW5jbHVkZXNLZXkoKSkge1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjAgcm91bmRlZC1sZyBwLTMgbWItNiBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQWxlcnRUcmlhbmdsZSBjbGFzcz1cInctNSBoLTUgdGV4dC1hbWJlci01MCBzaHJpbmstMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWFtYmVyLTIwMC84MCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Db250YWlucyBEZWNyeXB0aW9uIEtleTo8L3N0cm9uZz4gQW55b25lIHdobyBzY2FucyB0aGlzIGNhbiBqb2luIHRoZSByb29tIGFuZCB2aWV3IGRhdGEuIFRyZWF0IGl0IGxpa2UgYSBwYXNzd29yZC5cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIGJnLWJyYW5kLWFjY2VudC8xMCBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8yMCByb3VuZGVkLWxnIHAtMyBtYi02IGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGQgY2xhc3M9XCJ3LTUgaC01IHRleHQtYnJhbmQtYWNjZW50IHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtYWNjZW50LzgwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPk1heGltdW0gU2VjdXJpdHk6PC9zdHJvbmc+IEtleSBpcyBleGNsdWRlZC4gWW91IG11c3Qgc2VuZCB0aGUgPGVtPkxpbmsgS2V5PC9lbT4gdmlhIGEgc2VwYXJhdGUgc2VjdXJlIGNoYW5uZWwuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cCBjdXJzb3ItcG9pbnRlclwiIChjbGljayk9XCJ0b2dnbGVRclJldmVhbCgpXCI+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy13aGl0ZSBwLTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmx1ci1tZF09XCIhaXNRclJldmVhbGVkKClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3Mub3BhY2l0eS01MF09XCIhaXNRclJldmVhbGVkKClcIj5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHFyRGF0YVVybCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgW3NyY109XCJxckRhdGFVcmwoKVwiIGFsdD1cIlJvb20gUVIgQ29kZVwiIGNsYXNzPVwidy00OCBoLTQ4IHNtOnctNTYgc206aC01NlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy00OCBoLTQ4IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUxvYWRlcjIgY2xhc3M9XCJ3LTggaC04IHRleHQtYnJhbmQtYmcgYW5pbWF0ZS1zcGluXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIEBpZiAoIWlzUXJSZXZlYWxlZCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtY2FyZC85MCBwLTMgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgc2hhZG93LXhsIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRXllIGNsYXNzPVwidy02IGgtNiB0ZXh0LWJyYW5kLXRleHRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1icmFuZC1iZyBiZy13aGl0ZS85MCBweC0yIHB5LTEgcm91bmRlZCBzaGFkb3ctc21cIj5DbGljayB0byBSZXZlYWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtdC00IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICBTY2FuIHdpdGggYSBtb2JpbGUgd2FsbGV0IG9yIGNhbWVyYSB0byBqb2luLlxyXG4gICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJnLWJyYW5kLWJnLzUwIGJvcmRlci10IGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tZG93bmxvYWQtcXItaW1hZ2VcIiAoY2xpY2spPVwiZG93bmxvYWRRcigpXCIgY2xhc3M9XCJmbGV4LTEgcHktMi41IHJvdW5kZWQtbGcgYmctYnJhbmQtY2FyZC1ib3JkZXIgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvODAgdGV4dC1icmFuZC10ZXh0IGZvbnQtbWVkaXVtIHRleHQtc20gdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZURvd25sb2FkIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgRG93bmxvYWQgSW1hZ2VcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cImNsb3NlUXIoKVwiIGNsYXNzPVwicHgtNCBweS0yLjUgcm91bmRlZC1sZyBiZy1icmFuZC1jYXJkIGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgZm9udC1tZWRpdW0gdGV4dC1zbSB0cmFuc2l0aW9uIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICA8L2Rpdj5cclxuPC9kaXY+XHJcbn1cclxuXHJcbkBpZiAoc2hvd1NoYXJlTW9kYWwoKSkge1xyXG48ZGl2IGlkPVwibW9kYWwtc2hhcmUtcm9vbVwiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJyYW5kLWJnLzgwIGJhY2tkcm9wLWJsdXItc20gcC00IGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ29weSBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC10ZXh0XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0XCI+U2hhcmUgUm9vbSBTZWN1cmVseTwvaDM+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLW1vZGFsLWNsb3NlXCIgKGNsaWNrKT1cImNsb3NlU2hhcmVNb2RhbCgpXCIgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWCBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwLTYgZmxleCBmbGV4LWNvbCBnYXAtNFwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzMwIGJnLWJyYW5kLWFjY2VudC81IHJvdW5kZWQteGwgcC00IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTIgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGQgY2xhc3M9XCJ3LTQgaC00IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQgZm9udC1ib2xkIHRleHQtc21cIj5NYXhpbXVtIFNlY3VyaXR5IChTcGxpdCk8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtdC0xIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29waWVzIHRoZSByb29tIFVSTCA8c3Ryb25nPndpdGhvdXQ8L3N0cm9uZz4gdGhlIGRlY3J5cHRpb24ga2V5LiBTZW5kIHRoaXMgbGluaywgdGhlbiB1c2UgdGhlIDxlbT5cIkxpbmsgS2V5XCI8L2VtPiBhY3Rpb24gdG8gc2VuZCB0aGUga2V5IHZpYSBhIHNlcGFyYXRlLCBzZWN1cmUgY2hhbm5lbCAoZS5nLiwgU2lnbmFsIHZzIEVtYWlsKS5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWNvcHktc2VjdXJlLWxpbmtcIiAoY2xpY2spPVwiY29weVNlY3VyZUxpbmsoKVwiIGNsYXNzPVwibXQtMyB3LWZ1bGwgcHktMi41IGJnLWJyYW5kLWFjY2VudC8yMCBob3ZlcjpiZy1icmFuZC1hY2NlbnQvMzAgdGV4dC1icmFuZC1hY2NlbnQgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8yMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHJlbGF0aXZlIHotMTAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHNlY3VyZUxpbmtDb3BpZWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNvcHkgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHt7IHNlY3VyZUxpbmtDb3BpZWQoKSA/ICdTZWN1cmUgTGluayBDb3BpZWQhJyA6ICdDb3B5IExpbmsgT25seSAoTm8gS2V5KScgfX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGJnLWJyYW5kLWJnLzUwIHJvdW5kZWQteGwgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVBbGVydFRyaWFuZ2xlIGNsYXNzPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzPVwidGV4dC1icmFuZC10ZXh0IGZvbnQtYm9sZCB0ZXh0LXNtXCI+U3RhbmRhcmQgKENvbWJpbmVkKTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIG10LTEgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb3BpZXMgdGhlIGZ1bGwgVVJMIGluY2x1ZGluZyB0aGUgZGVjcnlwdGlvbiBrZXkgKDxjb2RlPiNrZXk8L2NvZGU+KS4gQ29udmVuaWVudCBmb3IgcXVpY2sgc2hhcmluZywgYnV0IGlmIHRoaXMgc2luZ2xlIGxpbmsgaXMgaW50ZXJjZXB0ZWQsIHRoZSByb29tIGlzIGNvbXByb21pc2VkLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY29weS1mdWxsLWxpbmtcIiAoY2xpY2spPVwiY29weUZ1bGxMaW5rKClcIiBjbGFzcz1cIm10LTMgdy1mdWxsIHB5LTIuNSBiZy1icmFuZC1jYXJkLWJvcmRlci81MCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHRyYW5zaXRpb24gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKGZ1bGxMaW5rQ29waWVkKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVjayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDb3B5IGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB7eyBmdWxsTGlua0NvcGllZCgpID8gJ0Z1bGwgTGluayBDb3BpZWQhJyA6ICdDb3B5IEZ1bGwgTGluayAoTGluayArIEtleSknIH19XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbjwvZGl2PlxyXG59XHJcblxyXG5AaWYgKHNob3dLZXlNb2RhbCgpKSB7XHJcbjxkaXYgaWQ9XCJtb2RhbC12aWV3LWtleVwiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJyYW5kLWJnLzgwIGJhY2tkcm9wLWJsdXItc20gcC00IGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVLZXkgY2xhc3M9XCJ3LTUgaC01IHRleHQtY3lhbi00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHRcIj5Sb29tIERlY3J5cHRpb24gS2V5PC9oMz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tbW9kYWwtY2xvc2VcIiAoY2xpY2spPVwiY2xvc2VLZXlNb2RhbCgpXCIgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWCBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNiBmbGV4IGZsZXgtY29sIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LWZ1bGwgYmctY3lhbi01MDAvMTAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8yMCByb3VuZGVkLWxnIHAtMyBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUFsZXJ0VHJpYW5nbGUgY2xhc3M9XCJ3LTUgaC01IHRleHQtY3lhbi00MDAgc2hyaW5rLTBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWN5YW4tMjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+U2Vuc2l0aXZlIERhdGE6PC9zdHJvbmc+IFRoaXMgaXMgdGhlIHByaXZhdGUgZW5jcnlwdGlvbiBrZXkgZm9yIHRoZSByb29tLiBBbnlvbmUgd2l0aCB0aGlzIGtleSBjYW4gZGVjcnlwdCBhbmQgdmlldyB0aGUgdHJhbnNhY3Rpb24gZGV0YWlscyBpZiB0aGV5IGFsc28gaGF2ZSB0aGUgcm9vbSBsaW5rLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgIEZvciBtYXhpbXVtIG9wZXJhdGlvbmFsIHNlY3VyaXR5LCBzZW5kIHRoaXMga2V5IHRvIHNpZ25lcnMgdXNpbmcgYSBkaWZmZXJlbnQgY29tbXVuaWNhdGlvbiBjaGFubmVsIHRoYW4gdGhlIG9uZSB1c2VkIGZvciB0aGUgcm9vbSBsaW5rIChlLmcuLCBTaWduYWwgdnMuIEVtYWlsKS5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJjb3B5S2V5KClcIiBjbGFzcz1cIm10LTIgdy1mdWxsIHB5LTIuNSBiZy1jeWFuLTUwMC8yMCBob3ZlcjpiZy1jeWFuLTUwMC8zMCB0ZXh0LWN5YW4tNDAwIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC8yMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICBAaWYgKGtleUNvcGllZCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVjayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ29weSBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHt7IGtleUNvcGllZCgpID8gJ0tleSBDb3BpZWQhJyA6ICdDb3B5IERlY3J5cHRpb24gS2V5JyB9fVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxufVxyXG5cclxuQGlmIChzaG93QWRtaW5Nb2RhbCgpKSB7XHJcbjxkaXYgaWQ9XCJtb2RhbC1iYWNrdXAtYWRtaW5cIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMTAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy84MCBiYWNrZHJvcC1ibHVyLXNtIHAtNCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtY2FyZCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgbWF4LXctbWQgdy1mdWxsIG92ZXJmbG93LWhpZGRlbiByZWxhdGl2ZVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRmlsZUtleSBjbGFzcz1cInctNSBoLTUgdGV4dC1wdXJwbGUtNDAwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0XCI+QmFja3VwIEFkbWluIFRva2VuPC9oMz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tbW9kYWwtY2xvc2VcIiAoY2xpY2spPVwiY2xvc2VBZG1pbk1vZGFsKClcIiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC02IGZsZXggZmxleC1jb2wgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1wdXJwbGUtNTAwLzEwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8yMCByb3VuZGVkLWxnIHAtMyBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUFsZXJ0T2N0YWdvbiBjbGFzcz1cInctNSBoLTUgdGV4dC1wdXJwbGUtNDAwIHNocmluay0wXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1wdXJwbGUtMjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+SGlnaCBQcml2aWxlZ2U6PC9zdHJvbmc+IFRoaXMgdG9rZW4gYWxsb3dzIGFueSBndWVzdCBpbiB0aGUgcm9vbSB0byBjbGFpbSB0aGUgXCJDb29yZGluYXRvclwiIHJvbGUuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgQ29vcmRpbmF0b3JzIGhhdmUgdGhlIGF1dGhvcml0eSB0byBtYW5hZ2Ugd2hpdGVsaXN0cywgbG9jayB0aGUgcm9vbSwgdmVyaWZ5IGlucHV0cywgYW5kIGJyb2FkY2FzdCB0aGUgZmluYWwgdHJhbnNhY3Rpb24uIE9ubHkgc2hhcmUgdGhpcyB3aXRoIHRydXN0ZWQgY28tYWRtaW5pc3RyYXRvcnMuXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwiY29weUFkbWluVG9rZW4oKVwiIGNsYXNzPVwibXQtMiB3LWZ1bGwgcHktMi41IGJnLXB1cnBsZS01MDAvMjAgaG92ZXI6YmctcHVycGxlLTUwMC8zMCB0ZXh0LXB1cnBsZS00MDAgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvMjAgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgQGlmIChhZG1pbkNvcGllZCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVjayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ29weSBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHt7IGFkbWluQ29waWVkKCkgPyAnQWRtaW4gVG9rZW4gQ29waWVkIScgOiAnQ29weSBBZG1pbiBUb2tlbicgfX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuPC9kaXY+XHJcbn1cclxuXHJcbkBpZiAoc2hvd0ZvdW50YWluTW9kYWwoKSkge1xyXG48ZGl2IGlkPVwibW9kYWwtZXhwb3J0LWZvdW50YWluXCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzEwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvODAgYmFja2Ryb3AtYmx1ci1zbSBwLTQgYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcmVsYXRpdmVcIj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJvcmRlci1iIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZCBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHRcIj5BaXItR2FwcGVkIEV4cG9ydCBQU0JUPC9oMz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tbW9kYWwtY2xvc2VcIiAoY2xpY2spPVwiY2xvc2VGb3VudGFpbk1vZGFsKClcIiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNiBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBmbGV4IGJnLWJyYW5kLWJnIHAtMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1mb3JtYXQtdXJcIiAoY2xpY2spPVwic2V0RXhwb3J0Rm9ybWF0KCd1cicpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJmbGV4LTEgcHktMS41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtY2FyZC1ib3JkZXJdPVwiZXhwb3J0Rm9ybWF0KCkgPT09ICd1cidcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC1hY2NlbnRdPVwiZXhwb3J0Rm9ybWF0KCkgPT09ICd1cidcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0LW11dGVkXT1cImV4cG9ydEZvcm1hdCgpICE9PSAndXInXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVW5pdmVyc2FsIChVUilcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1mb3JtYXQtYmJxclwiIChjbGljayk9XCJzZXRFeHBvcnRGb3JtYXQoJ2JicXInKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiZmxleC0xIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLW1kIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJnLWJyYW5kLWNhcmQtYm9yZGVyXT1cImV4cG9ydEZvcm1hdCgpID09PSAnYmJxcidcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1hbWJlci00MDBdPVwiZXhwb3J0Rm9ybWF0KCkgPT09ICdiYnFyJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiZXhwb3J0Rm9ybWF0KCkgIT09ICdiYnFyJ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbGRjYXJkIChCQlFyKVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgQGlmIChleHBvcnRGb3JtYXQoKSA9PT0gJ3VyJykge1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1hY2NlbnQvMTAgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgcm91bmRlZC1sZyBwLTMgbWItNiBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLWFjY2VudCBzaHJpbmstMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWJyYW5kLWFjY2VudC84MCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5TdGFuZGFyZCBQcm90b2NvbDo8L3N0cm9uZz4gT3B0aW1pemVkIGZvciBLZXlzdG9uZSwgUGFzc3BvcnQsIGFuZCBzdGFuZGFyZCBoYXJkd2FyZSB3YWxsZXRzLiBBZGp1c3QgdGhlIHNwZWVkIHNsaWRlciBmb3IgY29tcGF0aWJpbGl0eSBhbmQgcGVyZm9ybWFuY2UuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMjAgcm91bmRlZC1sZyBwLTMgbWItNiBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy01IGgtNSB0ZXh0LWFtYmVyLTUwMCBzaHJpbmstMFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWFtYmVyLTIwMC84MCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Db2xkY2FyZCBQcm90b2NvbDo8L3N0cm9uZz4gT3B0aW1pemVkIGZvciBDb2lua2l0ZSBDb2xkY2FyZCBkZXZpY2VzLiBBZGp1c3QgdGhlIHNwZWVkIHNsaWRlciBmb3IgY29tcGF0aWJpbGl0eSBhbmQgcGVyZm9ybWFuY2UuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cCBjdXJzb3ItcG9pbnRlciBpbmxpbmUtZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIiAoY2xpY2spPVwidG9nZ2xlRm91bnRhaW5SZXZlYWwoKVwiPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctd2hpdGUgcC0yIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJsdXItbWRdPVwiIWlzRm91bnRhaW5SZXZlYWxlZCgpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLm9wYWNpdHktNTBdPVwiIWlzRm91bnRhaW5SZXZlYWxlZCgpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxjYW52YXMgaWQ9XCJmb3VudGFpbi1wc2J0LWNhbnZhc1wiIGNsYXNzPVwidy02NCBoLTY0IHNtOnctNzIgc206aC03MiBibG9ja1wiPjwvY2FudmFzPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgQGlmICghaXNGb3VudGFpblJldmVhbGVkKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkLzkwIHAtMyByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBzaGFkb3cteGwgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWUgY2xhc3M9XCJ3LTYgaC02IHRleHQtYnJhbmQtdGV4dFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLWJnIGJnLXdoaXRlLzkwIHB4LTIgcHktMSByb3VuZGVkIHNoYWRvdy1zbVwiPkNsaWNrIHRvIFJldmVhbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIG10LTYgdGV4dC1jZW50ZXIgbWF4LXctWzMyMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgRW5zdXJlIG5vIGNhbWVyYXMgYXJlIG9ic2VydmluZyB5b3VyIHNjcmVlbiBiZWZvcmUgcmV2ZWFsaW5nLlxyXG4gICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICBAaWYgKGlzRm91bnRhaW5SZXZlYWxlZCgpKSB7XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIG10LTYgYmctYnJhbmQtYmcgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBhbmltYXRlLWluIGZhZGUtaW4gc2xpZGUtaW4tZnJvbS1ib3R0b20tMiBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0LW11dGVkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkZyYW1lIERlbGF5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgZm9udC1tb25vIHRleHQtYnJhbmQtYWNjZW50IGZvbnQtYm9sZFwiPnt7IGZvdW50YWluU3BlZWQoKSB9fW1zPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFuZ2VcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjEwMFwiIG1heD1cIjEwMDBcIiBzdGVwPVwiNTBcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtuZ01vZGVsXT1cImZvdW50YWluU3BlZWQoKVwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKG5nTW9kZWxDaGFuZ2UpPVwidXBkYXRlRm91bnRhaW5TcGVlZCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIGgtMS41IGJnLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgYXBwZWFyYW5jZS1ub25lIGN1cnNvci1wb2ludGVyIGFjY2VudC1icmFuZC1hY2NlbnQgdHJhbnNpdGlvbi1hbGwgaG92ZXI6YWNjZW50LWJyYW5kLWFjY2VudC1ob3ZlclwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWzlweF0gdGV4dC1icmFuZC10ZXh0LW11dGVkIGZvbnQtYm9sZCB1cHBlcmNhc2UgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5GYXN0IChEcm9wcyBmcmFtZXMpPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TbG93IChNb3JlIHJlbGlhYmxlKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJnLWJyYW5kLWJnLzUwIGJvcmRlci10IGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY2FuY2VsLWRvd25sb2FkXCIgKGNsaWNrKT1cImNsb3NlRm91bnRhaW5Nb2RhbCgpXCIgY2xhc3M9XCJweC00IHB5LTIuNSByb3VuZGVkLWxnIGJnLWJyYW5kLWNhcmQgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24gYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBob3Zlcjpib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdy1mdWxsIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICA8L2Rpdj5cclxuPC9kaXY+XHJcbn1cclxuXHJcbkBpZiAoc2hvd1NjYW5uZXJNb2RhbCgpKSB7XHJcbjxkaXYgaWQ9XCJtb2RhbC1pbXBvcnQtc2Nhbm5lclwiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJyYW5kLWJnLzgwIGJhY2tkcm9wLWJsdXItc20gcC00IGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVRckNvZGUgY2xhc3M9XCJ3LTUgaC01IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0XCI+QWlyLUdhcHBlZCBJbXBvcnQgUFNCVDwvaDM+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLW1vZGFsLWNsb3NlXCIgKGNsaWNrKT1cInN0b3BTY2FubmVyKClcIiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInAtNiBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1hY2NlbnQvMTAgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgcm91bmRlZC1sZyBwLTMgbWItNiBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlU2hpZWxkIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLWFjY2VudCBzaHJpbmstMCBtdC0wLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC1hY2NlbnQvODAgbGVhZGluZy1yZWxheGVkIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5TZWN1cmUgU2Nhbm5lcjo8L3N0cm9uZz4gSG9sZCB5b3VyIGhhcmR3YXJlIHdhbGxldCBkaXBsYXlpbmcgUFNCVCBRUiBDb2RlIHVwIHRvIHRoZSBjYW1lcmEuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtWzExcHhdIHRleHQtYnJhbmQtYWNjZW50LzkwIGZvbnQtbWVkaXVtIGJnLWJyYW5kLWFjY2VudC8xMCBwLTIgcm91bmRlZCBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIPCfkqEgPHN0cm9uZz5UaXA6PC9zdHJvbmc+IFNvbWV0aW1lcyBRUiBjb2RlcyBhcmUgdG9vIHNtYWxsIGZvciB3ZWJjYW1zIHRvIHJlYWQgb2ZmIGEgaGFyd2FyZSBkZXZpY2UuIFlvdSBjYW4gdXNlIGEgbW9iaWxlIGNvbXBhbmlvbiBhcHBsaWNhdGlvbiB0byBzY2FuIHRoZSBoYXJkd2FyZSB3YWxsZXQsIGFuZCB0aGVuIGV4cG9ydCB0aGUgU2lnbmVkIFBTQlQgdG8ge3sgY29uZmlnU2VydmljZS5jb25maWcoKS5icmFuZE5hbWUgfX0gdGhyb3VnaCB0aGlzIHJlYWRlci5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIG1iLTQgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtYmcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLWxnIHAtMi41IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1bMTBweF0gdGV4dC1icmFuZC10ZXh0LW11dGVkIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5SYXcgT3B0aWNhbCBGZWVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1bMTBweF0gdGV4dC1icmFuZC1hY2NlbnQgZm9udC1tb25vIHRydW5jYXRlIG1heC13LVsyMDBweF1cIiBbdGl0bGVdPVwidXJTZXJ2aWNlLmxhc3RTY2FubmVkVGV4dCgpXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt7IHVyU2VydmljZS5sYXN0U2Nhbm5lZFRleHQoKSB8fCAnV2FpdGluZyBmb3IgUVIuLi4nIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIEBpZiAodXJTZXJ2aWNlLnNjYW5FcnJvcigpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLXJvc2UtNTAwLzEwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgcm91bmRlZC1sZyBwLTIuNSBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUFsZXJ0VHJpYW5nbGUgY2xhc3M9XCJ3LTQgaC00IHRleHQtcm9zZS00MDAgc2hyaW5rLTBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXhzIHRleHQtcm9zZS0zMDBcIj57eyB1clNlcnZpY2Uuc2NhbkVycm9yKCkgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIGJnLWJsYWNrIHctZnVsbCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8zMCBzaGFkb3ctWzBfMF8xNXB4X3ZhcigtLXdsLWFjY2VudCldXCI+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJzaWduZXItcmVhZGVyXCIgY2xhc3M9XCJ3LWZ1bGwgaC03MiBvYmplY3QtY292ZXJcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgcG9pbnRlci1ldmVudHMtbm9uZSB6LTEwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSB3LTU2IGgtNTYgcm91bmRlZC14bCBzaGFkb3ctWzBfMF8wXzk5OTlweF9yZ2JhKHZhcigtLXdsLWJnKSwwLjcpXSBib3JkZXIgYm9yZGVyLWJyYW5kLWFjY2VudC8zMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctNiBoLTYgYm9yZGVyLXQtMiBib3JkZXItbC0yIGJvcmRlci1icmFuZC1hY2NlbnQgcm91bmRlZC10bC14bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTYgaC02IGJvcmRlci10LTIgYm9yZGVyLXItMiBib3JkZXItYnJhbmQtYWNjZW50IHJvdW5kZWQtdHIteGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCB3LTYgaC02IGJvcmRlci1iLTIgYm9yZGVyLWwtMiBib3JkZXItYnJhbmQtYWNjZW50IHJvdW5kZWQtYmwteGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdy02IGgtNiBib3JkZXItYi0yIGJvcmRlci1yLTIgYm9yZGVyLWJyYW5kLWFjY2VudCByb3VuZGVkLWJyLXhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBsZWZ0LTAgcmlnaHQtMCBoLVsycHhdIGJnLWJyYW5kLWFjY2VudCBzaGFkb3ctWzBfMF84cHhfMnB4X3ZhcigtLXdsLWFjY2VudCldIHNjYW5uZXItbGFzZXJcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIEBpZiAodXJTZXJ2aWNlLnNjYW5Qcm9ncmVzcygpID4gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgcmlnaHQtMCBiZy1icmFuZC1jYXJkLzk1IGJhY2tkcm9wLWJsdXItc20gcC0zIGJvcmRlci10IGJvcmRlci1icmFuZC1hY2NlbnQvMzAgei0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LWJyYW5kLWFjY2VudCBmb250LWJvbGQgbWItMiB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UkVDT05TVFJVQ1RJTkcgU0lHTkFUVVJFLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3sgKHVyU2VydmljZS5zY2FuUHJvZ3Jlc3MoKSAqIDEwMCkudG9GaXhlZCgwKSB9fSU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIGJnLWJyYW5kLWJnIHJvdW5kZWQtZnVsbCBoLTEuNSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1hY2NlbnQgaC0xLjUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBlYXNlLW91dFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbc3R5bGUud2lkdGguJV09XCJ1clNlcnZpY2Uuc2NhblByb2dyZXNzKCkgKiAxMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicC00IGJnLWJyYW5kLWJnLzUwIGJvcmRlci10IGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tc3RvcC1zY2FubmVyXCIgKGNsaWNrKT1cInN0b3BTY2FubmVyKClcIiBjbGFzcz1cInB4LTQgcHktMi41IHJvdW5kZWQtbGcgYmctYnJhbmQtY2FyZCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgaG92ZXI6dGV4dC1icmFuZC10ZXh0IGZvbnQtbWVkaXVtIHRleHQtc20gdHJhbnNpdGlvbiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1icmFuZC1jYXJkLWJvcmRlciB3LWZ1bGwgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIENhbmNlbCAmIENsb3NlXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgIDwvZGl2PlxyXG48L2Rpdj5cclxufVxyXG5cclxuQGlmIChzaG93Q29uZmlybU1vZGFsKCkpIHtcclxuPGRpdiBpZD1cIm1vZGFsLWNvbmZpcm0tYWN0aW9uXCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzI1MF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvODAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWZhZGUtaW5cIj5cclxuICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcC02IHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgbWF4LXctc20gdy1mdWxsIG14LTQgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIGxlZnQtMCB3LWZ1bGwgaC0xXCIgXHJcbiAgICAgICAgICAgICAgICBbY2xhc3MuYmctcm9zZS01MDBdPVwiY29uZmlybURhdGEoKS5pc0Rlc3RydWN0aXZlXCIgXHJcbiAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYWNjZW50XT1cIiFjb25maXJtRGF0YSgpLmlzRGVzdHJ1Y3RpdmVcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgPGgzIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0IGZvbnQtYm9sZCB0ZXh0LWxnIG1iLTJcIj57eyBjb25maXJtRGF0YSgpLnRpdGxlIH19PC9oMz5cclxuICAgICAgICBcclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtIG1iLTYgbGVhZGluZy1yZWxheGVkIHdoaXRlc3BhY2UtcHJlLXdyYXAgYnJlYWstd29yZHNcIj57e2NvbmZpcm1EYXRhKCkubWVzc2FnZSB9fVxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ2FwLTNcIiBbY2xhc3MuZ3JpZC1jb2xzLTJdPVwiY29uZmlybURhdGEoKS50eXBlID09PSAnY29uZmlybSdcIiBbY2xhc3MuZ3JpZC1jb2xzLTFdPVwiY29uZmlybURhdGEoKS50eXBlID09PSAnYWxlcnQnXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBAaWYgKGNvbmZpcm1EYXRhKCkudHlwZSA9PT0gJ2NvbmZpcm0nKSB7XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJjbG9zZUNvbmZpcm1Nb2RhbCgpXCIgY2xhc3M9XCJweC00IHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlci81MCB0cmFuc2l0aW9uIGZvbnQtYm9sZCB0ZXh0LXNtIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwiZXhlY3V0ZUNvbmZpcm1BY3Rpb24oKVwiIFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwicHgtNCBweS0yLjUgcm91bmRlZC14bCBmb250LWJvbGQgdGV4dC1zbSB0ZXh0LWJyYW5kLWJnIHRyYW5zaXRpb24gc2hhZG93LWxnIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctcm9zZS02MDBdPVwiY29uZmlybURhdGEoKS5pc0Rlc3RydWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuaG92ZXI6Ymctcm9zZS01MDBdPVwiY29uZmlybURhdGEoKS5pc0Rlc3RydWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC13aGl0ZV09XCJjb25maXJtRGF0YSgpLmlzRGVzdHJ1Y3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5iZy1icmFuZC1hY2NlbnRdPVwiIWNvbmZpcm1EYXRhKCkuaXNEZXN0cnVjdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmhvdmVyOmJnLWJyYW5kLWFjY2VudC1ob3Zlcl09XCIhY29uZmlybURhdGEoKS5pc0Rlc3RydWN0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICB7eyBjb25maXJtRGF0YSgpLnR5cGUgPT09ICdjb25maXJtJyA/ICdDb25maXJtJyA6ICdPSycgfX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuPC9kaXY+XHJcbn1cclxuXHJcbjxkaXYgaWQ9XCJjb250YWluZXItcm9vbS1kYXNoYm9hcmRcIiBjbGFzcz1cIm1heC13LTd4bCBteC1hdXRvIHB4LTYgcHktOCByZWxhdGl2ZSBtaW4taC1bODB2aF1cIj5cclxuICAgIFxyXG4gICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgdy1bODAwcHhdIGgtWzUwMHB4XSBiZy1icmFuZC1hY2NlbnQvMTAgcm91bmRlZC1mdWxsIGJsdXItWzEyMHB4XSBwb2ludGVyLWV2ZW50cy1ub25lXCI+PC9kaXY+XHJcblxyXG4gICAgPGRpdiBpZD1cImNhcmQtcm9vbS1vdmVydmlld1wiIGNsYXNzPVwiYmctYnJhbmQtY2FyZC84MCBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIvNTAgcm91bmRlZC14bCBwLTYgbWItOCByZWxhdGl2ZSB6LTEwIHNoYWRvdy14bCBmbGV4IGZsZXgtY29sIGdhcC02IG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDwhLS0gRmFkZWQgQnJhbmQgV2F0ZXJtYXJrIC0tPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtMTAgcmlnaHQtNCBtZDp0b3AtMTAgbWQ6cmlnaHQtNiBvcGFjaXR5LTEwIHBvaW50ZXItZXZlbnRzLW5vbmUgc2VsZWN0LW5vbmUgbWl4LWJsZW5kLXBsdXMtbGlnaHRlclwiPlxyXG4gICAgICAgICAgICA8aW1nIFtzcmNdPVwiY29uZmlnU2VydmljZS5jb25maWcoKS5sb2dvVXJsXCIgY2xhc3M9XCJ3LTI0IGgtMjQgbWQ6dy0zMiBtZDpoLTMyIG9iamVjdC1jb250YWluIGZpbHRlclwiIGFsdD1cIkJyYW5kIFdhdGVybWFya1wiIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcmVsYXRpdmUgei0yMFwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1icmFuZC10ZXh0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICBSb29tIE92ZXJ2aWV3XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXJldmVhbC1vdmVydmlld1wiXHJcbiAgICAgICAgICAgICAgICAoY2xpY2spPVwidG9nZ2xlUHJpdmFjeUJsdXIoJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3JylcIiBcclxuICAgICAgICAgICAgICAgIGNsYXNzPVwicC0yIHJvdW5kZWQtbGcgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYW1iZXItNTAwXT1cIiFibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3J11cIlxyXG4gICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYnJhbmQtdGV4dC1tdXRlZF09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3J11cIlxyXG4gICAgICAgICAgICAgICAgW3RpdGxlXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tb3ZlcnZpZXcnXSA/ICdSZXZlYWwgSGVhZGVyJyA6ICdIaWRlIEhlYWRlcidcIj5cclxuICAgICAgICAgICAgICAgIEBpZiAoYmx1clN0YXRlcygpWyd0cmFuc2FjdGlvbi1vdmVydmlldyddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWVPZmYgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZSBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHJlbGF0aXZlIHotMTAgZmxleCBmbGV4LWNvbCBnYXAtNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJsdXItbWRdPVwiYmx1clN0YXRlcygpWyd0cmFuc2FjdGlvbi1vdmVydmlldyddXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3Mub3BhY2l0eS0zMF09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3J11cIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5zZWxlY3Qtbm9uZV09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLW92ZXJ2aWV3J11cIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5wb2ludGVyLWV2ZW50cy1ub25lXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tb3ZlcnZpZXcnXVwiPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIEBpZiAoaXNFeHBpcmVkKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ3LTMgaC0zIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTYwMCBzaHJpbmstMCBzaGFkb3ctWzBfMF8xMHB4XyNlMTFkNDhdXCIgdGl0bGU9XCJSb29tIEV4cGlyZWRcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSBpZiAoc29ja2V0LnJvb21TdGF0ZSgpPy5pc0xvY2tlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMyBoLTMgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwMCBhbmltYXRlLXB1bHNlIHNoYWRvdy1bMF8wXzEwcHhfI2Y1OWUwYl0gc2hyaW5rLTBcIiB0aXRsZT1cIlJvb20gTG9ja2VkXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInctMyBoLTMgcm91bmRlZC1mdWxsIGJnLWJyYW5kLWFjY2VudCBhbmltYXRlLXB1bHNlIHNoYWRvdy1bMF8wXzEwcHhfdmFyKC0td2wtYWNjZW50KV0gc2hyaW5rLTBcIiB0aXRsZT1cIlJvb20gQWN0aXZlXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3M9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0IHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt7IHNvY2tldC5yb29tU3RhdGUoKT8ucm9vbU5hbWUgfHwgY29uZmlnU2VydmljZS5jb25maWcoKS5kZWZhdWx0Um9vbU5hbWUgfX1cclxuICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHNvY2tldC5pc0Nvb3JkaW5hdG9yKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1lZGl0LXJvb20tbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwib3BlblJlbmFtZU1vZGFsKClcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwicC0yIC1tbC0xIHJvdW5kZWQtbGcgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgdGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVuYW1lIFJvb21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRWRpdDIgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLTQgdGV4dC1zbSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgYmctYnJhbmQtYmcgdy1maXQgcHgtNCBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWNvcHktcm9vbS1pZFwiIChjbGljayk9XCJvcGVuUm9vbUlkTW9kYWwoKVwiIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgcC0xLjUgLW0tMS41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChyb29tSWRDb3BpZWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ2hlY2sgY2xhc3M9XCJ3LTQgaC00IHRyYW5zaXRpb24tY29sb3JzIHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUhhc2ggY2xhc3M9XCJ3LTQgaC00IHRyYW5zaXRpb24tY29sb3JzIHRleHQtYnJhbmQtdGV4dC1tdXRlZFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LW1vbm8gdHJhbnNpdGlvbiBmb250LWJvbGRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC1hY2NlbnRdPVwicm9vbUlkQ29waWVkKClcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0XT1cIiFyb29tSWRDb3BpZWQoKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmhvdmVyOnRleHQtYnJhbmQtdGV4dC1tdXRlZF09XCIhcm9vbUlkQ29waWVkKClcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyByb29tSWQoKSB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtdG9wLTkgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBiZy1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIuNSBweS0xIHJvdW5kZWQgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24gcG9pbnRlci1ldmVudHMtbm9uZSB3aGl0ZXNwYWNlLW5vd3JhcCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHNoYWRvdy14bCB6LVsxMDBdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyByb29tSWRDb3BpZWQoKSA/ICdDb3BpZWQhJyA6ICdWaWV3IFJvb20gSUQnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1weCBoLTQgYmctYnJhbmQtY2FyZC1ib3JkZXJcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1oZWxwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC1hY2NlbnRdPVwiIXNvY2tldC5yb29tU3RhdGUoKT8ubmV0d29yayB8fCBzb2NrZXQucm9vbVN0YXRlKCk/Lm5ldHdvcmsgPT09ICdiaXRjb2luJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYW1iZXItNTAwXT1cInNvY2tldC5yb29tU3RhdGUoKT8ubmV0d29yayA9PT0gJ3Rlc3RuZXQnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1wdXJwbGUtNDAwXT1cInNvY2tldC5yb29tU3RhdGUoKT8ubmV0d29yayA9PT0gJ3NpZ25ldCdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlTmV0d29yayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBzb2NrZXQucm9vbVN0YXRlKCk/Lm5ldHdvcmsgPT09ICdiaXRjb2luJyA/ICdNYWlubmV0JyA6IChzb2NrZXQucm9vbVN0YXRlKCk/Lm5ldHdvcmsgfHwgJ01haW5uZXQnKSB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtdG9wLTEwIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgYmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0zIHB5LTEuNSByb3VuZGVkIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgcG9pbnRlci1ldmVudHMtbm9uZSB3aGl0ZXNwYWNlLW5vd3JhcCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHNoYWRvdy14bCB6LVsxMDBdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyAoIXNvY2tldC5yb29tU3RhdGUoKT8ubmV0d29yayB8fCBzb2NrZXQucm9vbVN0YXRlKCk/Lm5ldHdvcmsgPT09ICdiaXRjb2luJykgPyAnUmVhbCBCaXRjb2luIE5ldHdvcmsgKEV4ZXJjaXNlIENhdXRpb24pJyA6ICdUZXN0IE5ldHdvcmsgKE5vIHJlYWwgdmFsdWUpJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgQGlmIChzb2NrZXQuaXNDb29yZGluYXRvcigpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LXB4IGgtNCBiZy1icmFuZC1jYXJkLWJvcmRlclwiPjwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWluZGlnby00MDAgY3Vyc29yLWhlbHBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNyb3duIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5Db29yZGluYXRvcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgLXRvcC0xMCBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIGJnLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgcHgtMyBweS0xLjUgcm91bmRlZCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IHBvaW50ZXItZXZlbnRzLW5vbmUgd2hpdGVzcGFjZS1ub3dyYXAgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBzaGFkb3cteGwgei1bMTAwXVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFlvdSBoYXZlIGFkbWluIHByaXZpbGVnZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LXB4IGgtNCBiZy1icmFuZC1jYXJkLWJvcmRlclwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXZpZXctc2Vzc2lvbnNcIiAoY2xpY2spPVwib3BlblNlc3Npb25zTW9kYWwoKVwiIGNsYXNzPVwicmVsYXRpdmUgZ3JvdXAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgcC0xLjUgLW0tMS41IHJvdW5kZWQtbGcgdHJhbnNpdGlvbiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1icmFuZC1jYXJkLWJvcmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVc2VycyBjbGFzcz1cInctNCBoLTRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYnJhbmQtYWNjZW50XT1cIihzb2NrZXQucm9vbVN0YXRlKCk/LmNvbm5lY3RlZENvdW50IHx8IDApID4gMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiKHNvY2tldC5yb29tU3RhdGUoKT8uY29ubmVjdGVkQ291bnQgfHwgMCkgPD0gMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1ib2xkXCIgW2NsYXNzLnRleHQtYnJhbmQtdGV4dF09XCIoc29ja2V0LnJvb21TdGF0ZSgpPy5jb25uZWN0ZWRDb3VudCB8fCAwKSA+IDFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgc29ja2V0LnJvb21TdGF0ZSgpPy5jb25uZWN0ZWRDb3VudCB8fCAxIH19IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtdG9wLTEwIGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgYmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0zIHB5LTEuNSByb3VuZGVkIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgcG9pbnRlci1ldmVudHMtbm9uZSB3aGl0ZXNwYWNlLW5vd3JhcCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHNoYWRvdy14bCB6LVsxMDBdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IEFjdGl2ZSBTZXNzaW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctcHggaC00IGJnLWJyYW5kLWNhcmQtYm9yZGVyXCI+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cCBjdXJzb3ItaGVscFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIiBbY2xhc3MudGV4dC1yb3NlLTQwMF09XCJpc0xvd1RpbWUoKSB8fCBpc0V4cGlyZWQoKVwiIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiIWlzTG93VGltZSgpICYmICFpc0V4cGlyZWQoKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDbG9jayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNFeHBpcmVkKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZVwiPkV4cGlyZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImZvbnQtbW9ubyBmb250LWJvbGRcIj57eyB0aW1lUmVtYWluaW5nKCkgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIC10b3AtMTAgcmlnaHQtMCBtZDpsZWZ0LTEvMiBtZDotdHJhbnNsYXRlLXgtMS8yIG1kOnJpZ2h0LWF1dG8gYmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0zIHB5LTEuNSByb3VuZGVkIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgcG9pbnRlci1ldmVudHMtbm9uZSB3aGl0ZXNwYWNlLW5vd3JhcCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHNoYWRvdy14bCB6LVsxMDBdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBSb29tIGF1dG8tZXhwaXJlcyAmIHNlY3VyZWx5IHdpcGVzIGRhdGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBAaWYgKGJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tb3ZlcnZpZXcnXSkge1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cInRvZ2dsZVByaXZhY3lCbHVyKCd0cmFuc2FjdGlvbi1vdmVydmlldycpXCIgY2xhc3M9XCJiZy1icmFuZC1jYXJkLWJvcmRlci85MCB0ZXh0LWJyYW5kLXRleHQgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIgcHgtNCBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBzaGFkb3cteGwgYmFja2Ryb3AtYmx1ci1zbSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZU9mZiBjbGFzcz1cInctMy41IGgtMy41XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEhpZGRlbiBmb3IgUHJpdmFjeVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyLzUwIGZsZXggZmxleC1jb2wgaXRlbXMtc3RhcnQgZ2FwLTIgcmVsYXRpdmUgei0zMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgZm9udC1ib2xkIG1sLTFcIj5Sb29tIEFjdGlvbnM8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBwLTEuNSBiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQteGwgZ2FwLTIgc2hhZG93LXNtIHctZnVsbCBzbTp3LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgQGlmICghaXNFeHBpcmVkKCkgJiYgIXNvY2tldC5pc0Nsb3NlZCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tYWN0aW9uLWF1ZGl0XCIgKGNsaWNrKT1cInByb21wdEF1ZGl0TG9nRG93bmxvYWQoKVwiIGNsYXNzPVwicHgtMyBweS0yIHRleHQtYnJhbmQtYWNjZW50IGhvdmVyOmJnLWJyYW5kLWFjY2VudC8xMCBob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudC1ob3ZlciByb3VuZGVkLWxnIHRyYW5zaXRpb24gdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBob3Zlcjpib3JkZXItYnJhbmQtYWNjZW50LzIwIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUZpbGVDaGVjayBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF1ZGl0IExvZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImhpZGRlbiBzbTpibG9jayB3LXB4IGgtNiBiZy1icmFuZC1jYXJkLWJvcmRlciBteC0xXCI+PC9kaXY+IFxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1hY3Rpb24tY3N2XCIgKGNsaWNrKT1cInByb21wdENzdkRvd25sb2FkKClcIiBjbGFzcz1cInB4LTMgcHktMiB0ZXh0LWJsdWUtNDAwIGhvdmVyOmJnLWJsdWUtOTUwLzMwIGhvdmVyOnRleHQtYmx1ZS0zMDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLWJsdWUtNTAwLzIwIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZURvd25sb2FkIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ1NWXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWRkZW4gc206YmxvY2sgdy1weCBoLTYgYmctYnJhbmQtY2FyZC1ib3JkZXIgbXgtMVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tYWN0aW9uLWxpbmsta2V5XCIgKGNsaWNrKT1cIm9wZW5LZXlNb2RhbCgpXCIgY2xhc3M9XCJweC0zIHB5LTIgdGV4dC1jeWFuLTQwMCBob3ZlcjpiZy1jeWFuLTk1MC8zMCBob3Zlcjp0ZXh0LWN5YW4tMzAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1jeWFuLTUwMC8yMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGtleUNvcGllZCgpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlS2V5IGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt7IGtleUNvcGllZCgpID8gJ0NvcGllZCcgOiAnTGluayBLZXknIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGlkZGVuIHNtOmJsb2NrIHctcHggaC02IGJnLWJyYW5kLWNhcmQtYm9yZGVyIG14LTFcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICBAaWYgKHNvY2tldC5pc0Nvb3JkaW5hdG9yKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1hY3Rpb24tYmFja3VwLWFkbWluXCIgKGNsaWNrKT1cIm9wZW5BZG1pbk1vZGFsKClcIiBjbGFzcz1cInB4LTMgcHktMiB0ZXh0LXB1cnBsZS00MDAgaG92ZXI6YmctcHVycGxlLTk1MC8zMCBob3Zlcjp0ZXh0LXB1cnBsZS0zMDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLXB1cnBsZS01MDAvMjAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoYWRtaW5Db3BpZWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ2hlY2sgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUZpbGVLZXkgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBhZG1pbkNvcGllZCgpID8gJ0NvcGllZCcgOiAnQmFja3VwIEFkbWluJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiaGlkZGVuIHNtOmJsb2NrIHctcHggaC02IGJnLWJyYW5kLWNhcmQtYm9yZGVyIG14LTFcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWFjdGlvbi1zaGFyZVwiIChjbGljayk9XCJvcGVuU2hhcmVNb2RhbCgpXCIgY2xhc3M9XCJweC0zIHB5LTIgdGV4dC1icmFuZC10ZXh0IGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNvcHkgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNoYXJlIExpbmtcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWRkZW4gc206YmxvY2sgdy1weCBoLTYgYmctYnJhbmQtY2FyZC1ib3JkZXIgbXgtMVwiPjwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tYWN0aW9uLXFyXCIgKGNsaWNrKT1cIm9wZW5RcigpXCIgY2xhc3M9XCJweC0zIHB5LTIgdGV4dC1icmFuZC10ZXh0IGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgdHJhbnNpdGlvbiB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLXRyYW5zcGFyZW50IGhvdmVyOmJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVFyQ29kZSBjbGFzcz1cInctNCBoLTRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJoaWRkZW4gc206aW5saW5lXCI+UVIgQ29kZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIEBpZiAoc29ja2V0LmlzQ29vcmRpbmF0b3IoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWRkZW4gc206YmxvY2sgdy1weCBoLTYgYmctYnJhbmQtY2FyZC1ib3JkZXIgbXgtMVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWFjdGlvbi1sb2NrLXJvb21cIiAoY2xpY2spPVwidG9nZ2xlTG9jaygpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJweC0zIHB5LTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LXJvc2UtNDAwXT1cInNvY2tldC5yb29tU3RhdGUoKT8uaXNMb2NrZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5iZy1yb3NlLTk1MFxcLzMwXT1cInNvY2tldC5yb29tU3RhdGUoKT8uaXNMb2NrZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiIXNvY2tldC5yb29tU3RhdGUoKT8uaXNMb2NrZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlcl09XCIhc29ja2V0LnJvb21TdGF0ZSgpPy5pc0xvY2tlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzb2NrZXQucm9vbVN0YXRlKCk/LmlzTG9ja2VkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVMb2NrIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVbmxvY2sgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBzb2NrZXQucm9vbVN0YXRlKCk/LmlzTG9ja2VkID8gJ0xvY2tlZCcgOiAnTG9jayBSb29tJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBAaWYgKHNvY2tldC5pc0Nvb3JkaW5hdG9yKCkgJiYgIWlzRXhwaXJlZCgpICYmICFzb2NrZXQuaXNDbG9zZWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJoaWRkZW4gc206YmxvY2sgdy1weCBoLTYgYmctYnJhbmQtY2FyZC1ib3JkZXIgbXgtMVwiPjwvZGl2PiBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1hY3Rpb24tY2xvc2Utcm9vbVwiIChjbGljayk9XCJjbG9zZVJvb20oKVwiIGNsYXNzPVwicHgtMyBweS0yIGJnLXJvc2UtOTUwLzMwIHRleHQtcm9zZS00MDAgYm9yZGVyIGJvcmRlci1yb3NlLTkwMC81MCBob3ZlcjpiZy1yb3NlLTkwMC81MCBob3Zlcjpib3JkZXItcm9zZS01MDAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLWxnIHRyYW5zaXRpb24gdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlUG93ZXIgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgQGlmIChzaG93U2Vzc2lvbnNNb2RhbCgpKSB7XHJcbiAgICA8ZGl2IGlkPVwibW9kYWwtYWN0aXZlLXNlc3Npb25zXCIgY2xhc3M9XCJmaXhlZCBpbnNldC0wIHotWzIwMF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYnJhbmQtYmcvODAgYmFja2Ryb3AtYmx1ci1zbSBhbmltYXRlLWZhZGUtaW4gcC00XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIG1heC13LW1kIHctZnVsbCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBtYXgtaC1bODB2aF1cIj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJwLTQgYm9yZGVyLWIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1icmFuZC1jYXJkIHotMTAgc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlVXNlcnMgY2xhc3M9XCJ3LTUgaC01IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dFwiPkFjdGl2ZSBTZXNzaW9uczwvaDM+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tbW9kYWwtY2xvc2VcIiAoY2xpY2spPVwic2hvd1Nlc3Npb25zTW9kYWwuc2V0KGZhbHNlKVwiIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIGhvdmVyOnRleHQtYnJhbmQtdGV4dCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVYIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBib3JkZXItYiBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgYmctYnJhbmQtYmcgc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPk15IERpc3BsYXkgTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIFtuZ01vZGVsXT1cInBlcnNvbmFsRGlzcGxheU5hbWUoKVwiIChuZ01vZGVsQ2hhbmdlKT1cInBlcnNvbmFsRGlzcGxheU5hbWUuc2V0KCRldmVudClcIiAoa2V5dXAuZW50ZXIpPVwic2F2ZVBlcnNvbmFsTmFtZSgpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEF1ZGl0b3IgQm9iXCIgbWF4bGVuZ3RoPVwiMzJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQtc20gcm91bmRlZC1sZyBibG9jayBwLTIuNSBvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cInNhdmVQZXJzb25hbE5hbWUoKVwiIGNsYXNzPVwicHgtNSBweS0yLjUgYmctYnJhbmQtYWNjZW50IGhvdmVyOmJnLWJyYW5kLWFjY2VudC1ob3ZlciB0ZXh0LWJyYW5kLWJnIGZvbnQtYm9sZCByb3VuZGVkLWxnIHRyYW5zaXRpb24gdGV4dC1zbSBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTYXZlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1bMTBweF0gdGV4dC1icmFuZC10ZXh0LW11dGVkIG10LTJcIj5Zb3VyIG5hbWUgaXMgZW5kLXRvLWVuZCBlbmNyeXB0ZWQgYW5kIG9ubHkgdmlzaWJsZSB0byBwZW9wbGUgY3VycmVudGx5IGluIHRoaXMgcm9vbS48L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtNCBvdmVyZmxvdy15LWF1dG8gY3VzdG9tLXNjcm9sbGJhciBmbGV4LWdyb3cgc3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICBAZm9yIChzZXNzaW9uIG9mIHNvY2tldC5hY3RpdmVTZXNzaW9ucygpOyB0cmFjayBzZXNzaW9uLmlkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYWNjZW50XzEwXT1cInNlc3Npb24uaWQgPT09IHNvY2tldC5jdXJyZW50U2Vzc2lvbklkKClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWJyYW5kLWFjY2VudF8zMF09XCJzZXNzaW9uLmlkID09PSBzb2NrZXQuY3VycmVudFNlc3Npb25JZCgpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJnLWJyYW5kLWJnXT1cInNlc3Npb24uaWQgIT09IHNvY2tldC5jdXJyZW50U2Vzc2lvbklkKClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyXT1cInNlc3Npb24uaWQgIT09IHNvY2tldC5jdXJyZW50U2Vzc2lvbklkKClcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNocmluay0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctaW5kaWdvLTUwMF8xMF09XCJzZXNzaW9uLnJvbGUgPT09ICdhZG1pbidcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5iZy1icmFuZC1jYXJkLWJvcmRlcl09XCJzZXNzaW9uLnJvbGUgIT09ICdhZG1pbidcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNlc3Npb24ucm9sZSA9PT0gJ2FkbWluJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNyb3duIGNsYXNzPVwidy01IGgtNSB0ZXh0LWluZGlnby00MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVc2VyIGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0IGZvbnQtYm9sZCB0ZXh0LXNtIHRydW5jYXRlXCIgW2NsYXNzLml0YWxpY109XCIhc2Vzc2lvbi5kaXNwbGF5TmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgc2Vzc2lvbi5kaXNwbGF5TmFtZSB8fCAnQW5vbnltb3VzIEd1ZXN0JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc2Vzc2lvbi5pZCA9PT0gc29ja2V0LmN1cnJlbnRTZXNzaW9uSWQoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LVs5cHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LWJvbGQgYmctYnJhbmQtYWNjZW50LzIwIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzIwIHRleHQtYnJhbmQtYWNjZW50IHB4LTEuNSBweS0wLjUgcm91bmRlZFwiPllvdTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC1bMTBweF0gZm9udC1tb25vIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZXNzaW9uOiB7eyBzZXNzaW9uLmlkIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwidHJhbnNpdGlvbiBwLTIgY3Vyc29yLXBvaW50ZXJcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLWFjY2VudF09XCJjb3BpZWRTZXNzaW9uSWQoKSA9PT0gc2Vzc2lvbi5pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0LW11dGVkXT1cImNvcGllZFNlc3Npb25JZCgpICE9PSBzZXNzaW9uLmlkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ob3Zlcjp0ZXh0LWJyYW5kLXRleHRdPVwiY29waWVkU2Vzc2lvbklkKCkgIT09IHNlc3Npb24uaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDb3B5IFNlc3Npb24gRGV0YWlsc1wiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImNvcHlTZXNzaW9uSWQoc2Vzc2lvbi5pZCwgc2Vzc2lvbi5kaXNwbGF5TmFtZSlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY29waWVkU2Vzc2lvbklkKCkgPT09IHNlc3Npb24uaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrIGNsYXNzPVwidy0zLjUgaC0zLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ29weSBjbGFzcz1cInctMy41IGgtMy41XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBAaWYgKHNvY2tldC5hY3RpdmVTZXNzaW9ucygpLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBweS02IHRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlTG9hZGVyMiBjbGFzcz1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN5bmNpbmcgc2Vzc2lvbnMuLi5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIH1cclxuXHJcbiAgICBAaWYgKHNvY2tldC5pc0Nsb3NlZCgpKSB7XHJcbiAgICA8ZGl2IGlkPVwibW9kYWwtc3RhdHVzLWNsb3NlZFwiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsyMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJyYW5kLWJnLzkwIGJhY2tkcm9wLWJsdXIteGwgYW5pbWF0ZS1mYWRlLWluXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBwLTggcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy1tZCB3LWZ1bGwgdGV4dC1jZW50ZXIgbXgtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy0xNiBoLTE2IGJnLWJyYW5kLWNhcmQtYm9yZGVyLzUwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlUG93ZXIgY2xhc3M9XCJ3LTggaC04IHRleHQtYnJhbmQtdGV4dC1tdXRlZFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBAaWYgKGNvbmZpZ1NlcnZpY2UuY29uZmlnKCkudXNlVHJhZGVNYXJrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgU2lnbmluZyBSb29twq4gQ2xvc2VkXHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBDbG9zZWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgbWItOFwiPlRoZSBjb29yZGluYXRvciBoYXMgZW5kZWQgdGhpcyBzaWduaW5nIHNlc3Npb24uIEFsbCBkYXRhIGhhcyBiZWVuIHNlY3VyZWx5IHdpcGVkLjwvcD5cclxuICAgICAgICAgICAgQGlmICghaXNFbWJlZGRlZCkge1xyXG4gICAgICAgICAgICAgICAgPGEgcm91dGVyTGluaz1cIi9jcmVhdGVcIiBjbGFzcz1cInctZnVsbCBweS0zIGJnLWJyYW5kLWNhcmQtYm9yZGVyLzUwIGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dCBmb250LWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgZGVjb3JhdGlvbi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVaYXAgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+IFN0YXJ0IE5ldyBTaWduaW5nXHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICAgfVxyXG5cclxuICAgIEBpZiAoaXNFeHBpcmVkKCkgJiYgIXNvY2tldC5pc0Nsb3NlZCgpKSB7XHJcbiAgICA8ZGl2IGlkPVwibW9kYWwtc3RhdHVzLWV4cGlyZWRcIiBjbGFzcz1cImZpeGVkIGluc2V0LTAgei1bMjAwXSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1icmFuZC1iZy85MCBiYWNrZHJvcC1ibHVyLXhsIGFuaW1hdGUtZmFkZS1pblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJiZy1icmFuZC1jYXJkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcC04IHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgbWF4LXctbWQgdy1mdWxsIHRleHQtY2VudGVyIG14LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTYgaC0xNiBiZy1yb3NlLTUwMC8xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUFsZXJ0VHJpYW5nbGUgY2xhc3M9XCJ3LTggaC04IHRleHQtcm9zZS01MDBcIj48L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQgbWItMlwiPlJvb20gRXhwaXJlZDwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLThcIj5UaGlzIHNlc3Npb24gaGFzIHRpbWVkIG91dC4gQWxsIGVwaGVtZXJhbCBkYXRhIGhhcyBiZWVuIHdpcGVkLjwvcD5cclxuICAgICAgICAgICAgQGlmICghaXNFbWJlZGRlZCkge1xyXG4gICAgICAgICAgICAgICAgPGEgcm91dGVyTGluaz1cIi9jcmVhdGVcIiBjbGFzcz1cInctZnVsbCBweS0zIGJnLWJyYW5kLWFjY2VudCBob3ZlcjpiZy1icmFuZC1hY2NlbnQtaG92ZXIgdGV4dC1icmFuZC1iZyBmb250LWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGRlY29yYXRpb24tMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWmFwIGNsYXNzPVwidy00IGgtNFwiPjwvc3ZnPiBTdGFydCBOZXcgU2lnbmluZ1xyXG4gICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICAgIH1cclxuXHJcbiAgICBAaWYgKHNob3dQcml2YWN5V2FybmluZygpKSB7XHJcbiAgICA8ZGl2IGlkPVwibW9kYWwtb3BzZWMtd2FybmluZ1wiIGNsYXNzPVwiZml4ZWQgaW5zZXQtMCB6LVsxMDBdIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLW1kIHRyYW5zaXRpb24tYWxsXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtY2FyZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCByb3VuZGVkLXhsIG1heC13LXhsIHctZnVsbCBwLTYgc2hhZG93LTJ4bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctZnVsbCBoLTEgYmctYW1iZXItNTAwXCI+PC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LWFtYmVyLTUwMCBtYi00XCI+XHJcbiAgICAgICAgPHN2ZyBsdWNpZGVFeWUgY2xhc3M9XCJ3LTcgaC03IGFuaW1hdGUtcHVsc2VcIj48L3N2Zz5cclxuICAgICAgICA8aDMgY2xhc3M9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHRcIj5PcFNlYyBXYXJuaW5nPC9oMz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICA8cCBjbGFzcz1cInRleHQtYnJhbmQtdGV4dCBtYi02IGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgIFlvdSBhcmUgYWJvdXQgdG8gcmV2ZWFsIHNlbnNpdGl2ZSB0cmFuc2FjdGlvbiBkZXRhaWxzLiBCZWZvcmUgcHJvY2VlZGluZywgcGxlYXNlIGVuc3VyZTpcclxuICAgICAgICA8YnI+PGJyPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj5cclxuICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVja0NpcmNsZSBjbGFzcz1cInctNCBoLTQgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz4gTm8gb25lIGlzIGxvb2tpbmcgb3ZlciB5b3VyIHNob3VsZGVyLlxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1icmFuZC10ZXh0LW11dGVkIG10LTJcIj5cclxuICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVja0NpcmNsZSBjbGFzcz1cInctNCBoLTQgdGV4dC1icmFuZC1hY2NlbnRcIj48L3N2Zz4gWW91IGFyZSBub3Qgc2hhcmluZyB5b3VyIHNjcmVlbi5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtdC0yXCI+XHJcbiAgICAgICAgICAgIDxzdmcgbHVjaWRlQ2hlY2tDaXJjbGUgY2xhc3M9XCJ3LTQgaC00IHRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+IFRoZXJlIGFyZSBubyBjYW1lcmFzIHJlY29yZGluZyB5b3VyIHNjcmVlbi5cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXdyYXAgc206ZmxleC1ub3dyYXAgZ2FwLTMganVzdGlmeS1lbmQgbXQtOFwiPlxyXG4gICAgICAgIDxidXR0b24gaWQ9XCJidG4tcHJpdmFjeS1rZWVwLWJsdXJyZWRcIlxyXG4gICAgICAgICAgICAoY2xpY2spPVwiY2xvc2VQcml2YWN5V2FybmluZygpXCIgXHJcbiAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIHNtOnctYXV0byBweC01IHB5LTIuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyLzUwIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgIEtlZXAgQmx1cnJlZFxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDxidXR0b24gaWQ9XCJidG4tcHJpdmFjeS1yZXZlYWwtYWxsXCJcclxuICAgICAgICAgICAgKGNsaWNrKT1cImNvbmZpcm1VbmJsdXJBbGwoKVwiIFxyXG4gICAgICAgICAgICBjbGFzcz1cInctZnVsbCBzbTp3LWF1dG8gcHgtNSBweS0yLjUgcm91bmRlZC1sZyBiZy1hbWJlci01MDAvMTAgdGV4dC1hbWJlci01MDAgZm9udC1ib2xkIGhvdmVyOmJnLWFtYmVyLTUwMC8yMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZSBjbGFzcz1cInctWzE4cHhdIGgtWzE4cHhdXCI+PC9zdmc+XHJcbiAgICAgICAgICAgIFJldmVhbCBBbGxcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXByaXZhY3ktcmV2ZWFsLXNlY3Rpb25cIlxyXG4gICAgICAgICAgICAoY2xpY2spPVwiY29uZmlybVVuYmx1cigpXCIgXHJcbiAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIHNtOnctYXV0byBweC01IHB5LTIuNSByb3VuZGVkLWxnIGJnLWFtYmVyLTUwMCB0ZXh0LWJyYW5kLWJnIGZvbnQtYm9sZCBob3ZlcjpiZy1hbWJlci00MDAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2hhZG93LWxnIHNoYWRvdy1hbWJlci01MDAvMjAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWUgY2xhc3M9XCJ3LVsxOHB4XSBoLVsxOHB4XVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICBSZXZlYWwgU2VjdGlvblxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxufVxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJncmlkIGxnOmdyaWQtY29scy0zIGdhcC04IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCByZWxhdGl2ZSB6LTEwXCIgXHJcbiAgICAgICAgW2NsYXNzLm9wYWNpdHktMjBdPVwiaXNFeHBpcmVkKCkgfHwgc29ja2V0LmlzQ2xvc2VkKClcIiBcclxuICAgICAgICBbY2xhc3MucG9pbnRlci1ldmVudHMtbm9uZV09XCJpc0V4cGlyZWQoKSB8fCBzb2NrZXQuaXNDbG9zZWQoKVwiPlxyXG4gICAgXHJcbiAgICA8ZGl2IGNsYXNzPVwibGc6Y29sLXNwYW4tMiBzcGFjZS15LTZcIj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGlkPVwiY2FyZC10eC1wcm9wb3NhbFwiIGNsYXNzPVwiYmctYnJhbmQtY2FyZCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQteGwgcC02IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0xMCByaWdodC0wIHAtNCBvcGFjaXR5LTEwIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgIDxpbWcgW3NyY109XCJjb25maWdTZXJ2aWNlLmNvbmZpZygpLmxvZ29VcmxcIiBjbGFzcz1cInctMjQgaC0yNCBvYmplY3QtY29udGFpblwiIGFsdD1cIkJyYW5kIFdhdGVybWFya1wiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTQgcmVsYXRpdmUgei0yMFwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtYnJhbmQtdGV4dCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIFByb3Bvc2FsXHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXJldmVhbC1wcm9wb3NhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInRvZ2dsZVByaXZhY3lCbHVyKCd0cmFuc2FjdGlvbi1wcm9wb3NhbCcpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJwLTIgcm91bmRlZC1sZyBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlci81MCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYW1iZXItNTAwXT1cIiFibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLXByb3Bvc2FsJ11cIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiYmx1clN0YXRlcygpWyd0cmFuc2FjdGlvbi1wcm9wb3NhbCddXCJcclxuICAgICAgICAgICAgICAgICAgICBbdGl0bGVdPVwiYmx1clN0YXRlcygpWyd0cmFuc2FjdGlvbi1wcm9wb3NhbCddID8gJ1JldmVhbCBQcm9wb3NhbCcgOiAnSGlkZSBQcm9wb3NhbCdcIj5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKGJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tcHJvcG9zYWwnXSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZU9mZiBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWUgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCByZWxhdGl2ZSB6LTEwXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmx1ci1tZF09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLXByb3Bvc2FsJ11cIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5vcGFjaXR5LTMwXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tcHJvcG9zYWwnXVwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnNlbGVjdC1ub25lXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tcHJvcG9zYWwnXVwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnBvaW50ZXItZXZlbnRzLW5vbmVdPVwiYmx1clN0YXRlcygpWyd0cmFuc2FjdGlvbi1wcm9wb3NhbCddXCI+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC00eGwgZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dCBtYi0xXCI+e3sgKHNvY2tldC50eERldGFpbHMoKT8uYW1vdW50IHx8IDApIC8gMTAwMDAwMDAwIHwgbnVtYmVyOicxLjgtOCcgfX0gPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC14bFwiPkJUQzwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtYnJhbmQtYWNjZW50IHRleHQtc20gZm9udC1tb25vIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBzb2NrZXQudHhEZXRhaWxzKCk/LmFtb3VudCB8fCAwIHwgbnVtYmVyIH19IHNhdHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtXCI+TmV0d29yayBGZWU8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dCBmb250LW1vbm9cIj57eyBzb2NrZXQudHhEZXRhaWxzKCk/LmZlZVJhdGUgPz8gJy0tJyB9fSBzYXRzL3ZCPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICBAaWYgKGJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tcHJvcG9zYWwnXSkge1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGluc2V0LTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cInRvZ2dsZVByaXZhY3lCbHVyKCd0cmFuc2FjdGlvbi1wcm9wb3NhbCcpXCIgY2xhc3M9XCJiZy1icmFuZC1jYXJkLWJvcmRlci85MCB0ZXh0LWJyYW5kLXRleHQgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIgcHgtNCBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBzaGFkb3cteGwgYmFja2Ryb3AtYmx1ci1zbSBtdC04IHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRXllT2ZmIGNsYXNzPVwidy0zLjUgaC0zLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgSGlkZGVuIGZvciBQcml2YWN5XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGlkPVwiY2FyZC1zaWduZXItYWN0aW9uc1wiIGNsYXNzPVwiYmctYnJhbmQtY2FyZCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQteGwgcC02IG1iLTZcIj5cclxuXHJcbiAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLXRleHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlNpZ25lciBBY3Rpb25zPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLTFcIj4xLiBFeHBvcnQgVW5zaWduZWQgVHJhbnNhY3Rpb248L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWV4cG9ydC1zaG93LXFyXCIgKGNsaWNrKT1cIm9wZW5Gb3VudGFpbk1vZGFsKClcIiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMyBiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLWJyYW5kLWFjY2VudC81MCBob3ZlcjpiZy1icmFuZC1hY2NlbnQvNSB0cmFuc2l0aW9uLWFsbCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYnJhbmQtdGV4dCBncm91cCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVRckNvZGUgY2xhc3M9XCJtci0yIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uLWNvbG9ycyB3LVsxOHB4XSBoLVsxOHB4XVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2hvdyBRUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1leHBvcnQtZG93bmxvYWQtZmlsZVwiIChjbGljayk9XCJwcm9tcHRQc2J0RG93bmxvYWQoKVwiIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIGJnLWJyYW5kLWJnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC1sZyBob3Zlcjpib3JkZXItcHVycGxlLTUwMC81MCBob3ZlcjpiZy1wdXJwbGUtNTAwLzUgdHJhbnNpdGlvbi1hbGwgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJyYW5kLXRleHQgZ3JvdXAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRG93bmxvYWRDbG91ZCBjbGFzcz1cIm1yLTIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGdyb3VwLWhvdmVyOnRleHQtcHVycGxlLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyB3LVsxOHB4XSBoLVsxOHB4XVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRG93bmxvYWQgRmlsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIG1iLTFcIj4yLiBJbXBvcnQgU2lnbmVkIFRyYW5zYWN0aW9uPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1pbXBvcnQtc2Nhbi1xclwiIChjbGljayk9XCJzdGFydFNjYW5uZXIoKVwiIFtkaXNhYmxlZF09XCJpc1NjYW5uaW5nU2lnbmVkKClcIiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMyBiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLWJyYW5kLWFjY2VudC81MCBob3ZlcjpiZy1icmFuZC1hY2NlbnQvNSB0cmFuc2l0aW9uLWFsbCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYnJhbmQtdGV4dCBncm91cCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVRckNvZGUgY2xhc3M9XCJtci0yIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB0cmFuc2l0aW9uLWNvbG9ycyB3LVsxOHB4XSBoLVsxOHB4XVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2NhbiBRUlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGlkPVwiYnRuLWltcG9ydC11cGxvYWQtZmlsZVwiIGNsYXNzPVwicmVsYXRpdmUgZ3JvdXAgY3Vyc29yLXBvaW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIGJnLWJyYW5kLWJnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZC1sZyBob3Zlcjpib3JkZXItcHVycGxlLTUwMC81MCBob3ZlcjpiZy1wdXJwbGUtNTAwLzUgdHJhbnNpdGlvbi1hbGwgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJyYW5kLXRleHQgZGlzYWJsZWQ6b3BhY2l0eS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgKGNoYW5nZSk9XCJvbkZpbGVTZWxlY3RlZCgkZXZlbnQpXCIgYWNjZXB0PVwiLnBzYnQsLnR4dCwuaGV4XCIgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIG9wYWNpdHktMCBjdXJzb3ItcG9pbnRlciB6LTEwXCIgW2Rpc2FibGVkXT1cImlzU2Nhbm5pbmdTaWduZWQoKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVcGxvYWRDbG91ZCBjbGFzcz1cIm1yLTIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGdyb3VwLWhvdmVyOnRleHQtcHVycGxlLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyB3LVsxOHB4XSBoLVsxOHB4XVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIEZpbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIEBpZiAoaXNTY2FubmluZ1NpZ25lZCgpKSB7XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwicmVsYXRpdmUgYmctYmxhY2sgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMzAgbXQtNiBzaGFkb3ctWzBfMF8xNXB4X3ZhcigtLXdsLWFjY2VudCldIGFuaW1hdGUtaW4gZmFkZS1pbiBzbGlkZS1pbi1mcm9tLXRvcC00IGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJzaWduZXItcmVhZGVyXCIgY2xhc3M9XCJ3LWZ1bGwgaC03MiBvYmplY3QtY292ZXJcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgaW5zZXQtMCBwb2ludGVyLWV2ZW50cy1ub25lIHotMTAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSB0b3AtNiBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotMjAgYmctYnJhbmQtYmcvODAgYm9yZGVyIGJvcmRlci1icmFuZC1hY2NlbnQvMjAgYmFja2Ryb3AtYmx1ci1tZCBweC00IHB5LTEuNSByb3VuZGVkLWZ1bGwgd2hpdGVzcGFjZS1ub3dyYXAgc2hhZG93LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1icmFuZC1hY2NlbnQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1icmFuZC1hY2NlbnQgYW5pbWF0ZS1wdWxzZVwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNjYW4gU2lnbmF0dXJlIFNlcXVlbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIHctNTYgaC01NiByb3VuZGVkLXhsIHNoYWRvdy1bMF8wXzBfOTk5OXB4X3JnYmEodmFyKC0td2wtYmcpLDAuNyldIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctNiBoLTYgYm9yZGVyLXQtMiBib3JkZXItbC0yIGJvcmRlci1icmFuZC1hY2NlbnQgcm91bmRlZC10bC14bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy02IGgtNiBib3JkZXItdC0yIGJvcmRlci1yLTIgYm9yZGVyLWJyYW5kLWFjY2VudCByb3VuZGVkLXRyLXhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHctNiBoLTYgYm9yZGVyLWItMiBib3JkZXItbC0yIGJvcmRlci1icmFuZC1hY2NlbnQgcm91bmRlZC1ibC14bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdy02IGgtNiBib3JkZXItYi0yIGJvcmRlci1yLTIgYm9yZGVyLWJyYW5kLWFjY2VudCByb3VuZGVkLWJyLXhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgbGVmdC0wIHJpZ2h0LTAgaC1bMnB4XSBiZy1icmFuZC1hY2NlbnQgc2hhZG93LVswXzBfOHB4XzJweF92YXIoLS13bC1hY2NlbnQpXSBzY2FubmVyLWxhc2VyXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHVyU2VydmljZS5zY2FuUHJvZ3Jlc3MoKSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCByaWdodC0wIGJnLWJyYW5kLWNhcmQvOTUgYmFja2Ryb3AtYmx1ci1zbSBwLTMgYm9yZGVyLXQgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHotMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+SW5nZXN0aW5nIFNpZ25hdHVyZS4uLjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57eyAodXJTZXJ2aWNlLnNjYW5Qcm9ncmVzcygpICogMTAwKS50b0ZpeGVkKDApIH19JTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLWZ1bGwgaC0xLjUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImJnLWJyYW5kLWFjY2VudCBoLTEuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGVhc2Utb3V0XCIgW3N0eWxlLndpZHRoLiVdPVwidXJTZXJ2aWNlLnNjYW5Qcm9ncmVzcygpICogMTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cInN0b3BTY2FubmVyKClcIiBjbGFzcz1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgei0yMCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgYmctYnJhbmQtY2FyZC84MCBob3Zlcjp0ZXh0LWJyYW5kLXRleHQgaG92ZXI6YmctcmVkLTUwMC85MCBwLTIuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgYmFja2Ryb3AtYmx1ci1zbSBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIGhvdmVyOmJvcmRlci1yZWQtNTAwIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlWCBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgaWQ9XCJjYXJkLXR4LWRldGFpbHNcIiBjbGFzcz1cInJlbGF0aXZlIGJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLXhsIHAtNSBtaW4taC1bNDAwcHhdIG92ZXJmbG93LWhpZGRlblwiPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00IHJlbGF0aXZlIHotMjBcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzcz1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWJyYW5kLXRleHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tcmV2ZWFsLWRldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgKGNsaWNrKT1cInRvZ2dsZVByaXZhY3lCbHVyKCd0cmFuc2FjdGlvbi1kZXRhaWxzJylcIiBcclxuICAgICAgICAgICAgICAgIGNsYXNzPVwicC0yIHJvdW5kZWQtbGcgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYW1iZXItNTAwXT1cIiFibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLWRldGFpbHMnXVwiXHJcbiAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0LW11dGVkXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tZGV0YWlscyddXCJcclxuICAgICAgICAgICAgICAgIFt0aXRsZV09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLWRldGFpbHMnXSA/ICdSZXZlYWwgRGV0YWlscycgOiAnSGlkZSBEZXRhaWxzJ1wiPlxyXG4gICAgICAgICAgICAgICAgQGlmIChibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLWRldGFpbHMnXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRXllT2ZmIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWUgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgIFtjbGFzcy5ibHVyLW1kXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tZGV0YWlscyddXCJcclxuICAgICAgICAgICAgICAgIFtjbGFzcy5vcGFjaXR5LTMwXT1cImJsdXJTdGF0ZXMoKVsndHJhbnNhY3Rpb24tZGV0YWlscyddXCJcclxuICAgICAgICAgICAgICAgIFtjbGFzcy5zZWxlY3Qtbm9uZV09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLWRldGFpbHMnXVwiXHJcbiAgICAgICAgICAgICAgICBbY2xhc3MucG9pbnRlci1ldmVudHMtbm9uZV09XCJibHVyU3RhdGVzKClbJ3RyYW5zYWN0aW9uLWRldGFpbHMnXVwiPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIGZsZXggYmctYnJhbmQtYmcgcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi10YWItaW5wdXRzXCIgKGNsaWNrKT1cInNldFZpZXdNb2RlKCdpbnB1dHMnKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZsZXgtMSBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYWNjZW50XT1cInZpZXdNb2RlKCkgPT09ICdpbnB1dHMnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLWJnXT1cInZpZXdNb2RlKCkgPT09ICdpbnB1dHMnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwidmlld01vZGUoKSAhPT0gJ2lucHV0cydcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmhvdmVyOnRleHQtYnJhbmQtdGV4dF09XCJ2aWV3TW9kZSgpICE9PSAnaW5wdXRzJ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBJbnB1dHMgKHt7IHNvY2tldC50eERldGFpbHMoKT8uaW5wdXRzIHx8IDAgfX0pXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi10YWItb3V0cHV0c1wiIChjbGljayk9XCJzZXRWaWV3TW9kZSgnb3V0cHV0cycpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImZsZXgtMSBweS0xLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtYWNjZW50XT1cInZpZXdNb2RlKCkgPT09ICdvdXRwdXRzJ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC1iZ109XCJ2aWV3TW9kZSgpID09PSAnb3V0cHV0cydcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtYnJhbmQtdGV4dC1tdXRlZF09XCJ2aWV3TW9kZSgpICE9PSAnb3V0cHV0cydcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmhvdmVyOnRleHQtYnJhbmQtdGV4dF09XCJ2aWV3TW9kZSgpICE9PSAnb3V0cHV0cydcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgT3V0cHV0cyAoe3sgc29ja2V0LnR4RGV0YWlscygpPy5vdXRwdXRzPy5sZW5ndGggfHwgMCB9fSlcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1iLTQgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHZpZXdNb2RlKCkgPT09ICdpbnB1dHMnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTZWFyY2ggY2xhc3M9XCJ3LTQgaC00IHRleHQtYnJhbmQtdGV4dC1tdXRlZCBhYnNvbHV0ZSBsZWZ0LTIgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHBvaW50ZXItZXZlbnRzLW5vbmVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIFtuZ01vZGVsXT1cImlucHV0U2VhcmNoUXVlcnkoKVwiIChuZ01vZGVsQ2hhbmdlKT1cInVwZGF0ZVNlYXJjaFF1ZXJ5KCdpbnB1dHMnLCAkZXZlbnQpXCIgcGxhY2Vob2xkZXI9XCJTZWFyY2ggaW5wdXQgYWRkcmVzcy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dCB0ZXh0LXhzIHJvdW5kZWQtbGcgYmxvY2sgcHktMi41IHByLTIwIHBsLTEwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtYWNjZW50LzUwIHRyYW5zaXRpb25cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgcmlnaHQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1bMTBweF0gZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgYmctYnJhbmQtY2FyZCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiIHRpdGxlPVwiRmlsdGVyZWQgUmVzdWx0c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGZpbHRlcmVkSW5wdXRzKCkubGVuZ3RoIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTZWFyY2ggY2xhc3M9XCJ3LTQgaC00IHRleHQtYnJhbmQtdGV4dC1tdXRlZCBhYnNvbHV0ZSBsZWZ0LTIgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHBvaW50ZXItZXZlbnRzLW5vbmVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIFtuZ01vZGVsXT1cIm91dHB1dFNlYXJjaFF1ZXJ5KClcIiAobmdNb2RlbENoYW5nZSk9XCJ1cGRhdGVTZWFyY2hRdWVyeSgnb3V0cHV0cycsICRldmVudClcIiBwbGFjZWhvbGRlcj1cIlNlYXJjaCBvdXRwdXQgYWRkcmVzcy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBiZy1icmFuZC1iZyBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHRleHQtYnJhbmQtdGV4dCB0ZXh0LXhzIHJvdW5kZWQtbGcgYmxvY2sgcHktMi41IHByLTIwIHBsLTEwIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYnJhbmQtYWNjZW50LzUwIHRyYW5zaXRpb25cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgcmlnaHQtMyB0b3AtMS8yIC10cmFuc2xhdGUteS0xLzIgdGV4dC1bMTBweF0gZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgYmctYnJhbmQtY2FyZCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcG9pbnRlci1ldmVudHMtbm9uZVwiIHRpdGxlPVwiRmlsdGVyZWQgUmVzdWx0c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGZpbHRlcmVkT3V0cHV0cygpLmxlbmd0aCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIEBpZiAoc29ja2V0LmlzQ29vcmRpbmF0b3IoKSkge1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1lbmQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEBpZiAodmlld01vZGUoKSA9PT0gJ2lucHV0cycpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi12ZXJpZnktYWxsLWlucHV0c1wiIChjbGljayk9XCJ2ZXJpZnlBbGxJbnB1dHMoKVwiIGNsYXNzPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTMwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8xMCBweC0yIHB5LTEgcm91bmRlZCB0cmFuc2l0aW9uIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrQ2lyY2xlIGNsYXNzPVwidy0zIGgtM1wiPjwvc3ZnPiBWZXJpZnkgQWxsIElucHV0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgQGlmICh2aWV3TW9kZSgpID09PSAnb3V0cHV0cycpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi12ZXJpZnktYWxsLW91dHB1dHNcIiAoY2xpY2spPVwidmVyaWZ5QWxsT3V0cHV0cygpXCIgY2xhc3M9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMCBob3Zlcjp0ZXh0LWVtZXJhbGQtMzAwIGhvdmVyOmJnLWVtZXJhbGQtNTAwLzEwIHB4LTIgcHktMSByb3VuZGVkIHRyYW5zaXRpb24gYm9yZGVyIGJvcmRlci10cmFuc3BhcmVudCBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAvMjAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ2hlY2tDaXJjbGUgY2xhc3M9XCJ3LTMgaC0zXCI+PC9zdmc+IFZlcmlmeSBBbGwgT3V0cHV0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0zIGZsZXgtZ3JvdyBvdmVyZmxvdy15LWF1dG8gbWF4LWgtWzQwMHB4XSBwci0yIGN1c3RvbS1zY3JvbGxiYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHZpZXdNb2RlKCkgPT09ICdpbnB1dHMnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBmb3IgKGlucHV0IG9mIGZpbHRlcmVkSW5wdXRzKCk7IHRyYWNrICRpbmRleCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSBJbnB1dCBDYXJkIENvbnRhaW5lciAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0cmV0Y2ggYmctYnJhbmQtYmcgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgb3ZlcmZsb3ctaGlkZGVuIGFkZHJlc3MtY2FyZFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ib3JkZXItZW1lcmFsZC01MDBdPVwiaXNXaGl0ZWxpc3RlZChpbnB1dC5hZGRyZXNzKVwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ib3JkZXItYnJhbmQtY2FyZC1ib3JkZXJdPVwiIWlzV2hpdGVsaXN0ZWQoaW5wdXQuYWRkcmVzcylcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8IS0tIExlZnQvVG9wIENvbHVtbjogU3RhdHVzIC0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2ZXJpZmljYXRpb24tYmFkZ2UgZmxleCBzbTpmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHctZnVsbCBzbTp3LTI4IHNocmluay0wIGJvcmRlci1iIHNtOmJvcmRlci1iLTAgc206Ym9yZGVyLXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyLzgwIGdhcC0yIHNtOmdhcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoaXNXaGl0ZWxpc3RlZChpbnB1dC5hZGRyZXNzKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGRDaGVjayBjbGFzcz1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTUwMCBzbTptYi0xLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1jZW50ZXJcIj5WZXJpZmllZCBJbnB1dDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZEFsZXJ0IGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgc206bWItMS41XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1jZW50ZXJcIj5VblZlcmlmaWVkIElucHV0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gTWlkZGxlICYgUmlnaHQgQ29udGVudCBXcmFwcGVyIC0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtMSBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSBNaWRkbGUgQ29sdW1uOiBEZXRhaWxzIC0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSBMYWJlbCBCYWRnZSAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0IGJnLWJyYW5kLWNhcmQgcHgtMyBweS0xIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmb250LW1lZGl1bSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5wdXQgI3t7ICRpbmRleCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBAaWYgKGlucHV0LnR4SWQgJiYgaW5wdXQudHhJZCAhPT0gJz8/Pz8nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1tb25vIHRleHQtWzEwcHhdIHRleHQtYnJhbmQtdGV4dC1tdXRlZCB0cnVuY2F0ZSBtYXgtdy1bMTIwcHhdXCIgdGl0bGU9XCJUeElEOlZvdXRcIj57eyBpbnB1dC50eElkIH19Ont7IGlucHV0LnZvdXQgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gQWRkcmVzcyBCb3ggLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLWxnIHBsLTMgcHItMyBweS0yIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmb250LW1vbm8gdGV4dC14cyB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgYnJlYWstYWxsIHNlbGVjdC1hbGwgbXItMlwiPnt7IGlucHV0LmFkZHJlc3MgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwiY29weUFkZHJlc3MoaW5wdXQuYWRkcmVzcylcIiBjbGFzcz1cInJlbGF0aXZlIGdyb3VwL3Rvb2x0aXAgc2hyaW5rLTAgZm9jdXM6b3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY29waWVkQWRkcmVzcygpID09PSBpbnB1dC5hZGRyZXNzKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrIGNsYXNzPVwidy00IGgtNCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdGV4dC1icmFuZC1hY2NlbnQgc2NhbGUtMTEwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDb3B5IGNsYXNzPVwidy00IGgtNCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdGV4dC1icmFuZC10ZXh0LW11dGVkIGdyb3VwLWhvdmVyOnRleHQtYnJhbmQtdGV4dFwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8IS0tIFRvb2x0aXAgLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSAtdG9wLTkgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBiZy1icmFuZC1jYXJkLWJvcmRlciB0ZXh0LWJyYW5kLXRleHQgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIuNSBweS0xIHJvdW5kZWQgb3BhY2l0eS0wIGdyb3VwLWhvdmVyL3Rvb2x0aXA6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IHBvaW50ZXItZXZlbnRzLW5vbmUgd2hpdGVzcGFjZS1ub3dyYXAgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBzaGFkb3cteGwgei1bMTAwXVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgY29waWVkQWRkcmVzcygpID09PSBpbnB1dC5hZGRyZXNzID8gJ0NvcGllZCEnIDogJ0NvcHkgQWRkcmVzcycgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8IS0tIFJpZ2h0IENvbHVtbjogQW1vdW50ICYgQWN0aW9uIC0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1lbmQganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHNocmluay0wIG1pbi13LVsxMzBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQgZm9udC1tZWRpdW0gdGV4dC1zbSB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgaW5wdXQuYW1vdW50IC8gMTAwMDAwMDAwIHwgbnVtYmVyOicxLjgtOCcgfX0gPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj5CVEM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzb2NrZXQuaXNDb29yZGluYXRvcigpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwidG9nZ2xlV2hpdGVsaXN0KGlucHV0LmFkZHJlc3MpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cInctZnVsbCBweS0xLjUgcHgtNCByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIHRleHQteHMgZm9udC1ib2xkIHRleHQtY2VudGVyIHNoYWRvdy1zbSBib3JkZXIgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzXT1cImlzV2hpdGVsaXN0ZWQoaW5wdXQuYWRkcmVzcykgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS01MDAvMTAgYm9yZGVyLXJvc2UtNTAwLzMwIHRleHQtcm9zZS00MDAgaG92ZXI6Ymctcm9zZS01MDAvMjAgaG92ZXI6Ym9yZGVyLXJvc2UtNTAwLzUwJyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTQwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAvNTAnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGlzV2hpdGVsaXN0ZWQoaW5wdXQuYWRkcmVzcykgPyAnUmV2b2tlJyA6ICdWZXJpZnknIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgQGlmICgoc29ja2V0LnR4RGV0YWlscygpPy5pbnB1dHNMaXN0Py5sZW5ndGggfHwgMCkgPT09IDApIHsgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgcHktOCB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC1zbVwiPk5vIGlucHV0IGRhdGEgYXZhaWxhYmxlLjwvZGl2PiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSBpZiAoZmlsdGVyZWRJbnB1dHMoKS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtXCI+Tm8gaW5wdXRzIG1hdGNoIHlvdXIgc2VhcmNoLjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHZpZXdNb2RlKCkgPT09ICdvdXRwdXRzJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBAZm9yIChvdXQgb2YgZmlsdGVyZWRPdXRwdXRzKCk7IHRyYWNrICRpbmRleCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8IS0tIE91dHB1dCBDYXJkIENvbnRhaW5lciAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RyZXRjaCBiZy1icmFuZC1iZyByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBvdmVyZmxvdy1oaWRkZW4gYWRkcmVzcy1jYXJkXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWVtZXJhbGQtNTAwXT1cImlzV2hpdGVsaXN0ZWQob3V0LmFkZHJlc3MpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWFtYmVyLTUwMF09XCJvdXQuaXNDaGFuZ2VcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5ib3JkZXItcm9zZS05MDBdPVwiIW91dC5pc0NoYW5nZSAmJiAhaXNXaGl0ZWxpc3RlZChvdXQuYWRkcmVzcykgJiYgKHNvY2tldC5yb29tU3RhdGUoKT8ud2hpdGVsaXN0Py5sZW5ndGggfHwgMCkgPiAwXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyXT1cIiFvdXQuaXNDaGFuZ2UgJiYgIWlzV2hpdGVsaXN0ZWQob3V0LmFkZHJlc3MpICYmICghc29ja2V0LnJvb21TdGF0ZSgpPy53aGl0ZWxpc3QgfHwgc29ja2V0LnJvb21TdGF0ZSgpPy53aGl0ZWxpc3Q/Lmxlbmd0aCA9PT0gMClcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPCEtLSBMZWZ0L1RvcCBDb2x1bW46IFN0YXR1cyAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2ZXJpZmljYXRpb24tYmFkZ2UgZmxleCBzbTpmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHctZnVsbCBzbTp3LTI4IHNocmluay0wIGJvcmRlci1iIHNtOmJvcmRlci1iLTAgc206Ym9yZGVyLXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyLzgwIGdhcC0yIHNtOmdhcC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChvdXQuaXNDaGFuZ2UpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGRPZmYgY2xhc3M9XCJ3LTUgaC01IHRleHQtYW1iZXItNTAwIHNtOm1iLTEuNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtWzlweF0gZm9udC1ib2xkIHRleHQtYW1iZXItNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWNlbnRlclwiPkNoYW5nZSBPdXRwdXQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSBpZiAoaXNXaGl0ZWxpc3RlZChvdXQuYWRkcmVzcykpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGRDaGVjayBjbGFzcz1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTUwMCBzbTptYi0xLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWNlbnRlclwiPlZlcmlmaWVkIE91dHB1dDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIGlmICgoc29ja2V0LnJvb21TdGF0ZSgpPy53aGl0ZWxpc3Q/Lmxlbmd0aCB8fCAwKSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGRBbGVydCBjbGFzcz1cInctNSBoLTUgdGV4dC1yb3NlLTUwMCBzbTptYi0xLjVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LVs5cHhdIGZvbnQtYm9sZCB0ZXh0LXJvc2UtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWNlbnRlclwiPlVudmVyaWZpZWQgT3V0cHV0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZEFsZXJ0IGNsYXNzPVwidy01IGgtNSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgc206bWItMS41XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1bOXB4XSBmb250LWJvbGQgdGV4dC1icmFuZC10ZXh0LW11dGVkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWNlbnRlclwiPlVudmVyaWZpZWQgT3V0cHV0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gTWlkZGxlICYgUmlnaHQgQ29udGVudCBXcmFwcGVyIC0tPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gTWlkZGxlIENvbHVtbjogRGV0YWlscyAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMiBmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gTGFiZWwgQmFkZ2UgLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQteHMgdGV4dC1icmFuZC10ZXh0IGJnLWJyYW5kLWNhcmQgcHgtMyBweS0xIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciBmb250LW1lZGl1bSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdXRwdXQgI3t7ICRpbmRleCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gQWRkcmVzcyBCb3ggLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctYnJhbmQtY2FyZCBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHJvdW5kZWQtbGcgcGwtMyBwci0zIHB5LTIgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC1icmFuZC10ZXh0LW11dGVkIGJyZWFrLWFsbCBzZWxlY3QtYWxsIG1yLTJcIj57eyBvdXQuYWRkcmVzcyB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwiY29weUFkZHJlc3Mob3V0LmFkZHJlc3MpXCIgY2xhc3M9XCJyZWxhdGl2ZSBncm91cC90b29sdGlwIHNocmluay0wIGZvY3VzOm91dGxpbmUtbm9uZSBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY29waWVkQWRkcmVzcygpID09PSBvdXQuYWRkcmVzcykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUNoZWNrIGNsYXNzPVwidy00IGgtNCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgdGV4dC1icmFuZC1hY2NlbnQgc2NhbGUtMTEwXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ29weSBjbGFzcz1cInctNCBoLTQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBncm91cC1ob3Zlcjp0ZXh0LWJyYW5kLXRleHRcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gVG9vbHRpcCAtLT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYWJzb2x1dGUgLXRvcC05IGxlZnQtMS8yIC10cmFuc2xhdGUteC0xLzIgYmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yLjUgcHktMSByb3VuZGVkIG9wYWNpdHktMCBncm91cC1ob3Zlci90b29sdGlwOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBwb2ludGVyLWV2ZW50cy1ub25lIHdoaXRlc3BhY2Utbm93cmFwIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgc2hhZG93LXhsIHotWzEwMF1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgY29waWVkQWRkcmVzcygpID09PSBvdXQuYWRkcmVzcyA/ICdDb3BpZWQhJyA6ICdDb3B5IEFkZHJlc3MnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwhLS0gUmlnaHQgQ29sdW1uOiBBbW91bnQgJiBBY3Rpb24gLS0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1jb2wgaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBzaHJpbmstMCBtaW4tdy1bMTMwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQgZm9udC1tZWRpdW0gdGV4dC1zbSB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBvdXQuYW1vdW50IC8gMTAwMDAwMDAwIHwgbnVtYmVyOicxLjgtOCcgfX0gPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj5CVEM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzb2NrZXQuaXNDb29yZGluYXRvcigpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJ0b2dnbGVXaGl0ZWxpc3Qob3V0LmFkZHJlc3MpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwidy1mdWxsIHB5LTEuNSBweC00IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1jZW50ZXIgc2hhZG93LXNtIGJvcmRlciBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzc109XCJpc1doaXRlbGlzdGVkKG91dC5hZGRyZXNzKSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJvc2UtNTAwLzEwIGJvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXJvc2UtNDAwIGhvdmVyOmJnLXJvc2UtNTAwLzIwIGhvdmVyOmJvcmRlci1yb3NlLTUwMC81MCcgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTQwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAvNTAnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgaXNXaGl0ZWxpc3RlZChvdXQuYWRkcmVzcykgPyAnUmV2b2tlJyA6ICdWZXJpZnknIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXNvY2tldC50eERldGFpbHMoKSkgeyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC1zbSB0ZXh0LWNlbnRlclwiPlBhcnNpbmcgdHJhbnNhY3Rpb24gZGF0YS4uLjwvZGl2PiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSBpZiAoZmlsdGVyZWRPdXRwdXRzKCkubGVuZ3RoID09PSAwICYmIChzb2NrZXQudHhEZXRhaWxzKCk/Lm91dHB1dHM/Lmxlbmd0aCB8fCAwKSA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtXCI+Tm8gb3V0cHV0cyBtYXRjaCB5b3VyIHNlYXJjaC48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj4gXHJcbiAgICAgICAgICAgIEBpZiAoYmx1clN0YXRlcygpWyd0cmFuc2FjdGlvbi1kZXRhaWxzJ10pIHtcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHotMTAgbXQtMTBcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cInRvZ2dsZVByaXZhY3lCbHVyKCd0cmFuc2FjdGlvbi1kZXRhaWxzJylcIiBjbGFzcz1cImJnLWJyYW5kLWNhcmQtYm9yZGVyLzkwIHRleHQtYnJhbmQtdGV4dCBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlciBweC00IHB5LTEuNSByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgYm9yZGVyLWJyYW5kLWNhcmQtYm9yZGVyIHNoYWRvdy14bCBiYWNrZHJvcC1ibHVyLXNtIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWVPZmYgY2xhc3M9XCJ3LTMuNSBoLTMuNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIEhpZGRlbiBmb3IgUHJpdmFjeVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cImxnOmNvbC1zcGFuLTFcIj5cclxuICAgICAgICA8ZGl2IGlkPVwiY2FyZC1zaWduZXJzLWxpc3RcIiBjbGFzcz1cImJnLWJyYW5kLWNhcmQgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByb3VuZGVkLXhsIHAtNiBoLWZ1bGwgZmxleCBmbGV4LWNvbCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNCByZWxhdGl2ZSB6LTIwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3M9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1icmFuZC10ZXh0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVVc2VycyBjbGFzcz1cInctNSBoLTUgdGV4dC1icmFuZC10ZXh0LW11dGVkXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgU2lnbmVycyA8c3BhbiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+KHt7IHNvY2tldC5zaWduZXJDb3VudCgpIH19IFNpZ25lZCk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLXJldmVhbC1zaWduZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwidG9nZ2xlUHJpdmFjeUJsdXIoJ3NpZ25lcnMnKVwiIFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzPVwicC0yIHJvdW5kZWQtbGcgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWFtYmVyLTUwMF09XCIhYmx1clN0YXRlcygpLnNpZ25lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy50ZXh0LWJyYW5kLXRleHQtbXV0ZWRdPVwiYmx1clN0YXRlcygpLnNpZ25lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIFt0aXRsZV09XCJibHVyU3RhdGVzKCkuc2lnbmVycyA/ICdSZXZlYWwgU2lnbmVycycgOiAnSGlkZSBTaWduZXJzJ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIEBpZiAoYmx1clN0YXRlcygpLnNpZ25lcnMpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVFeWVPZmYgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlRXllIGNsYXNzPVwidy01IGgtNVwiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJyZWxhdGl2ZSBmbGV4LWdyb3cgZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBmbGV4LWdyb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmx1ci1tZF09XCJibHVyU3RhdGVzKCkuc2lnbmVyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5vcGFjaXR5LTMwXT1cImJsdXJTdGF0ZXMoKS5zaWduZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnNlbGVjdC1ub25lXT1cImJsdXJTdGF0ZXMoKS5zaWduZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnBvaW50ZXItZXZlbnRzLW5vbmVdPVwiYmx1clN0YXRlcygpLnNpZ25lcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgIEBmb3IgKHNpZ25lciBvZiBzb2NrZXQuc2lnbmVycygpOyB0cmFjayBzaWduZXIuZmluZ2VycHJpbnQpIHtcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtNCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXIgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5iZy1lbWVyYWxkLTUwMC8xMF09XCJzaWduZXIuc2lnbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYm9yZGVyLWVtZXJhbGQtNTAwLzMwXT1cInNpZ25lci5zaWduZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIFtjbGFzcy5iZy1icmFuZC1iZ109XCIhc2lnbmVyLnNpZ25lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJvcmRlci1icmFuZC1jYXJkLWJvcmRlcl09XCIhc2lnbmVyLnNpZ25lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLmJnLWVtZXJhbGQtNTAwLzIwXT1cInNpZ25lci5zaWduZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW2NsYXNzLnRleHQtZW1lcmFsZC00MDBdPVwic2lnbmVyLnNpZ25lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MuYmctYnJhbmQtY2FyZF09XCIhc2lnbmVyLnNpZ25lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbY2xhc3MudGV4dC1icmFuZC10ZXh0LW11dGVkXT1cIiFzaWduZXIuc2lnbmVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc2lnbmVyLnNpZ25lZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDaGVja0NpcmNsZSBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVVzZXIgY2xhc3M9XCJ3LTUgaC01XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBAaWYgKHNvY2tldC5pc0Nvb3JkaW5hdG9yKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gKGNsaWNrKT1cIm9wZW5MYWJlbE1vZGFsKHNpZ25lci5maW5nZXJwcmludClcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJ0ZXh0LXNtIGZvbnQtbW9ubyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBob3ZlcjpiZy1icmFuZC1jYXJkLWJvcmRlci81MCAtbWwtMSBweC0xIHB5LTAuNSByb3VuZGVkIHRyYW5zaXRpb24gZ3JvdXAvbGFiZWwgdGV4dC1sZWZ0IGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChnZXRMYWJlbChzaWduZXIuZmluZ2VycHJpbnQpOyBhcyBsYWJlbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dCBmb250LWJvbGRcIj57eyBsYWJlbCB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgdGV4dC14c1wiPih7eyBzaWduZXIuZmluZ2VycHJpbnQgfX0pPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUVkaXQyIGNsYXNzPVwidy0zIGgtMyB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgZ3JvdXAtaG92ZXIvbGFiZWw6dGV4dC1icmFuZC1hY2NlbnQgb3BhY2l0eS0wIGdyb3VwLWhvdmVyL2xhYmVsOm9wYWNpdHktMTAwIHRyYW5zaXRpb25cIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LWJyYW5kLWFjY2VudC85MCBpdGFsaWNcIj5BZGQgTGFiZWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGV4dC1icmFuZC10ZXh0LW11dGVkIHRleHQteHNcIj4oe3sgc2lnbmVyLmZpbmdlcnByaW50IH19KTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVUYWcgY2xhc3M9XCJ3LTMgaC0zIHRleHQtYnJhbmQtYWNjZW50LzUwIGdyb3VwLWhvdmVyL2xhYmVsOnRleHQtYnJhbmQtYWNjZW50XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQtYnJhbmQtdGV4dCBmb250LW1lZGl1bSB0ZXh0LXNtIGZvbnQtbW9ub1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGdldFNpZ25lckxhYmVsKHNpZ25lci5maW5nZXJwcmludCkgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInRleHQteHMgZm9udC1tZWRpdW1cIiBbY2xhc3MudGV4dC1lbWVyYWxkLTQwMF09XCJzaWduZXIuc2lnbmVkXCIgW2NsYXNzLnRleHQtYnJhbmQtdGV4dC1tdXRlZF09XCIhc2lnbmVyLnNpZ25lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3sgc2lnbmVyLnNpZ25lZCA/ICdTaWduZWQnIDogJ1dhaXRpbmcuLi4nIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmIChzb2NrZXQuaXNDb29yZGluYXRvcigpICYmICFzaWduZXIuc2lnbmVkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIChjbGljayk9XCJudWRnZVNpZ25lcihzaWduZXIuZmluZ2VycHJpbnQpXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwicC0xIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWFtYmVyLTQwMCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29weSBOdWRnZSBNZXNzYWdlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVCZWxsIGNsYXNzPVwidy0zIGgtM1wiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgQGlmICghc2lnbmVyLnNpZ25lZCkgeyA8c3ZnIGx1Y2lkZUxvYWRlcjIgY2xhc3M9XCJ3LTQgaC00IHRleHQtYnJhbmQtdGV4dC1tdXRlZCBhbmltYXRlLXNwaW5cIj48L3N2Zz4gfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgQGlmIChzb2NrZXQuc2lnbmVycygpLmxlbmd0aCA9PT0gMCkgeyA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgcC00IHRleHQtYnJhbmQtdGV4dC1tdXRlZCB0ZXh0LXNtXCI+TG9hZGluZyBTaWduZXJzLi4uPC9kaXY+IH1cclxuICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgQGlmIChibHVyU3RhdGVzKCkuc2lnbmVycykge1xyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHotMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwidG9nZ2xlUHJpdmFjeUJsdXIoJ3NpZ25lcnMnKVwiIGNsYXNzPVwiYmctYnJhbmQtY2FyZC1ib3JkZXIvOTAgdGV4dC1icmFuZC10ZXh0IGhvdmVyOmJnLWJyYW5kLWNhcmQtYm9yZGVyIHB4LTQgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgc2hhZG93LXhsIGJhY2tkcm9wLWJsdXItc20gLW10LTEwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZUV5ZU9mZiBjbGFzcz1cInctMy41IGgtMy41XCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBIaWRkZW4gZm9yIFByaXZhY3lcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBpZD1cImNhcmQtZmluYWxpemF0aW9uLXN0YXR1c1wiIGNsYXNzPVwibXQtOCBwdC02IGJvcmRlci10IGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciByZWxhdGl2ZSB6LTIwXCI+XHJcbiAgICAgICAgICAgICAgICBAaWYgKGZpbmFsSGV4KCkpIHtcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctYnJhbmQtYWNjZW50LzEwIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzMwIHJvdW5kZWQteGwgcC00IGFuaW1hdGUtZmFkZS1pbi11cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctYnJhbmQtYWNjZW50IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYnJhbmQtYmcgc2hhZG93LWxnIHNoYWRvdy1icmFuZC1hY2NlbnQvMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGx1Y2lkZVNoaWVsZCBjbGFzcz1cInctNSBoLTVcIj48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3M9XCJ0ZXh0LWJyYW5kLXRleHQgZm9udC1ib2xkIHRleHQtc21cIj5UcmFuc2FjdGlvbiBTaWduZWQ8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1icmFuZC1hY2NlbnQgdGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7eyBzb2NrZXQuaXNDb29yZGluYXRvcigpID8gJ1JlYWR5IHRvIGJyb2FkY2FzdCcgOiAnQXdhaXRpbmcgQ29vcmRpbmF0b3IgYnJvYWRjYXN0JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoc29ja2V0LmlzQ29vcmRpbmF0b3IoKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ2FwLTNcIiBbY2xhc3MuZ3JpZC1jb2xzLTJdPVwiIWlzRW1iZWRkZWRcIiBbY2xhc3MuZ3JpZC1jb2xzLTFdPVwiaXNFbWJlZGRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY29weS1maW5hbC1oZXhcIiAoY2xpY2spPVwiY29weUhleCgpXCIgY2xhc3M9XCJweS0yIHB4LTMgYmctYnJhbmQtY2FyZC1ib3JkZXIvNTAgaG92ZXI6YmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1icmFuZC1jYXJkLWJvcmRlciB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoY29waWVkKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlQ2hlY2sgY2xhc3M9XCJ3LTMgaC0zXCI+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVDb3B5IGNsYXNzPVwidy0zIGgtM1wiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt7IGNvcGllZCgpID8gJ0NvcGllZCcgOiAnQ29weSBIZXgnIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQGlmICghaXNFbWJlZGRlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGlkPVwiYnRuLWJyb2FkY2FzdC10cmFuc2FjdGlvblwiIChjbGljayk9XCJicm9hZGNhc3RBbmRDb3B5KClcIiBjbGFzcz1cInB5LTIgcHgtMyBiZy1icmFuZC1hY2NlbnQgaG92ZXI6YmctYnJhbmQtYWNjZW50LWhvdmVyIHRleHQtYnJhbmQtYmcgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1sZyB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRleHQtY2VudGVyIGRlY29yYXRpb24tMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnJvYWRjYXN0IDxzdmcgbHVjaWRlRXh0ZXJuYWxMaW5rIGNsYXNzPVwidy0zIGgtM1wiPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfSBAZWxzZSBpZiAoc29ja2V0LmlzUmVhZHlUb0Jyb2FkY2FzdCgpKSB7ICBcclxuICAgICAgICAgICAgICAgICAgICBAaWYgKHNvY2tldC5pc0Nvb3JkaW5hdG9yKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBpZD1cImJ0bi1maW5hbGl6ZS10cmFuc2FjdGlvblwiIChjbGljayk9XCJmaW5hbGl6ZSgpXCIgY2xhc3M9XCJ3LWZ1bGwgcHktMy41IGJnLWJyYW5kLWFjY2VudCBob3ZlcjpiZy1icmFuZC1hY2NlbnQtaG92ZXIgdGV4dC1icmFuZC1iZyBmb250LWJvbGQgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbGcgc2hhZG93LWJyYW5kLWFjY2VudC8yMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBsdWNpZGVTaGllbGQgY2xhc3M9XCJ3LTQgaC00XCI+PC9zdmc+IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRmluYWxpemUgVHJhbnNhY3Rpb24gKHt7IHNvY2tldC5zaWduZXJDb3VudCgpIH19L3t7IHNvY2tldC5zaWduZXJUaHJlc2hvbGQoKSB9fSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgfSBAZWxzZSB7IDxwIGNsYXNzPVwidGV4dC14cyB0ZXh0LWNlbnRlciB0ZXh0LWJyYW5kLXRleHQtbXV0ZWRcIj5Pbmx5IHRoZSBDb29yZGluYXRvciBjYW4gZmluYWxpemUuPC9wPiB9XHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIGlmIChzb2NrZXQuaXNDb29yZGluYXRvcigpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBkaXNhYmxlZCBjbGFzcz1cInctZnVsbCBweS0zLjUgYmctYnJhbmQtY2FyZC1ib3JkZXIgdGV4dC1icmFuZC10ZXh0LW11dGVkIGZvbnQtYm9sZCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgY3Vyc29yLW5vdC1hbGxvd2VkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgbHVjaWRlTG9hZGVyMiBjbGFzcz1cInctNCBoLTQgYW5pbWF0ZS1zcGluXCI+PC9zdmc+IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5XYWl0aW5nIGZvciBTaWduYXR1cmVzICh7eyBzb2NrZXQuc2lnbmVyQ291bnQoKSB9fSAvIHt7IHNvY2tldC5zaWduZXJUaHJlc2hvbGQoKSB9fSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGV4dC1jZW50ZXIgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwidGV4dC1zbSB0ZXh0LWJyYW5kLXRleHQtbXV0ZWQgZm9udC1tZWRpdW0gbWItMVwiPldhaXRpbmcgZm9yIEZpbmFsaXphdGlvbjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBtYi00XCI+e3sgTWF0aC5tYXgoMCwgc29ja2V0LnNpZ25lclRocmVzaG9sZCgpIC0gKHNvY2tldC5zaWduZXJDb3VudCgpIHx8IDApKSB9fSBtb3JlIHNpZ25hdHVyZXMgcmVxdWlyZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEBpZiAoIXNob3dDbGFpbUlucHV0KCkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gaWQ9XCJidG4tY2xhaW0tY29vcmRpbmF0b3JcIiAoY2xpY2spPVwic2hvd0NsYWltSW5wdXQuc2V0KHRydWUpXCIgY2xhc3M9XCJ0ZXh0LXhzIHRleHQtYnJhbmQtdGV4dC1tdXRlZCBob3Zlcjp0ZXh0LWJyYW5kLWFjY2VudCB1bmRlcmxpbmUgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiPkhhdmUgdGhlIEFkbWluIEtleT8gQ2xhaW0gQ29vcmRpbmF0b3IgUm9sZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0yIGp1c3RpZnktY2VudGVyIG10LTIgYW5pbWF0ZS1mYWRlLWluLXVwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIFsobmdNb2RlbCldPVwiY2xhaW1QYXNzd29yZFwiIHBsYWNlaG9sZGVyPVwiUGFzdGUgQWRtaW4gS2V5IGhlcmUuLi5cIiBjbGFzcz1cImJnLWJyYW5kLWJnIGJvcmRlciBib3JkZXItYnJhbmQtY2FyZC1ib3JkZXIgcm91bmRlZCBweC0yIHB5LTEgdGV4dC14cyB0ZXh0LWJyYW5kLXRleHQgZm9jdXM6Ym9yZGVyLWJyYW5kLWFjY2VudCBvdXRsaW5lLW5vbmUgdy00OCBmb250LW1vbm9cIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiAoY2xpY2spPVwiY2xhaW1Sb2xlKClcIiBjbGFzcz1cInB4LTMgcHktMSBiZy1icmFuZC1hY2NlbnQvMjAgdGV4dC1icmFuZC1hY2NlbnQgdGV4dC14cyByb3VuZGVkIGhvdmVyOmJnLWJyYW5kLWFjY2VudC8zMCB0cmFuc2l0aW9uIGJvcmRlciBib3JkZXItYnJhbmQtYWNjZW50LzIwIGN1cnNvci1wb2ludGVyXCI+Q2xhaW08L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuPC9kaXY+Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS0EsU0FDRSxXQUVBLFFBQ0EsVUFFQSxRQUNBLFFBQ0EsYUFDQSxvQkFDSztBQUNQLFNBQVMsY0FBYyx5QkFBeUI7QUFDaEQsU0FBaUMsb0JBQW9CO0FBQ3JELFNBQVMsbUJBQW1CO0FBRTVCLFNBQ0UsY0FDQSxhQUNBLG1CQUNBLGVBQ0EsWUFDQSxhQUNBLGtCQUNBLFlBQ0EsYUFDQSxtQkFDQSxxQkFDQSxnQkFDQSxvQkFDQSxhQUNBLFdBQ0EscUJBQ0EsYUFDQSxTQUNBLFlBQ0EsY0FDQSxXQUNBLGlCQUNBLG9CQUNBLGVBQ0EsaUJBQ0EsYUFDQSxXQUNBLFlBSUEsY0FDQSxXQUNBLGNBQ0EsY0FFQSxlQUNBLG1CQUNBLG1CQUNBLGlCQUNBLGtCQUNLO0FBRVAsWUFBWSxZQUFZO0FBQ3hCLFNBQVMsYUFBYSxtQ0FBbUM7QUFFekQsU0FBUyxRQUFRLFdBQVc7QTs7Ozs7Ozs7O0FDbEV4QixJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBOztBQUNJLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsc0NBQUE7QUFDSixJQUFBLDBCQUFBOzs7Ozs7QUFJSixJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQWlLLEdBQUEsT0FBQSxHQUFBLEVBQ2xDLEdBQUEsT0FBQSxHQUFBLEVBQ2xDLEdBQUEsT0FBQSxFQUFBOztBQUU3RSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEdBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQXNCLElBQUEsMEJBQUEsRUFBSztBQUVyRSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxHQUFBO0FBQTZCLElBQUEsd0JBQUEsU0FBQSxTQUFBLCtEQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGNBQUEsSUFBa0IsS0FBSyxDQUFDO0lBQUEsQ0FBQTs7QUFDMUQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7QUFFYixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQXFDLElBQUEsT0FBQSxHQUFBOztBQUU3QixJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEdBQUEsRUFBcUQsSUFBQSxRQUFBO0FBQ3pDLElBQUEsb0JBQUEsSUFBQSxrQkFBQTtBQUFnQixJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxJQUFBLHlHQUFBO0FBQ3RDLElBQUEsMEJBQUEsRUFBSTtBQUVSLElBQUEsNEJBQUEsSUFBQSxLQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsK05BQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUE2QixJQUFBLFVBQUEsR0FBQTtBQUNRLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGNBQUEsSUFBa0IsS0FBSyxDQUFDO0lBQUEsQ0FBQTtBQUM5RCxJQUFBLG9CQUFBLElBQUEsVUFBQTtBQUNKLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQWtDLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLG9CQUFBLENBQXFCO0lBQUEsQ0FBQTs7QUFDNUQsSUFBQSx1QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsSUFBQSxpQkFBQTtBQUNKLElBQUEsMEJBQUEsRUFBUyxFQUNQLEVBQ0osRUFDSjs7Ozs7O0FBS1YsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUFrSyxHQUFBLE9BQUEsR0FBQSxFQUNuQyxHQUFBLE9BQUEsR0FBQSxFQUNsQyxHQUFBLE9BQUEsRUFBQTs7QUFFN0UsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxHQUFBO0FBQXNDLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFrQixJQUFBLDBCQUFBLEVBQUs7QUFFakUsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSwrREFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLElBQW1CLEtBQUssQ0FBQztJQUFBLENBQUE7O0FBQzNELElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7O0FBRWIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUFxQyxJQUFBLE9BQUEsR0FBQTs7QUFFN0IsSUFBQSx1QkFBQSxJQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLElBQUEsS0FBQSxHQUFBLEVBQXFELElBQUEsUUFBQTtBQUN6QyxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBa0IsSUFBQSwwQkFBQTtBQUFVLElBQUEsb0JBQUEsSUFBQSxtSkFBQTtBQUN4QyxJQUFBLDBCQUFBLEVBQUk7QUFFUixJQUFBLDRCQUFBLElBQUEsS0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDhHQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBNkIsSUFBQSxVQUFBLEdBQUE7QUFDUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLElBQW1CLEtBQUssQ0FBQztJQUFBLENBQUE7QUFDL0QsSUFBQSxvQkFBQSxJQUFBLFVBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFVBQUEsR0FBQTtBQUFrQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxxQkFBQSxDQUFzQjtJQUFBLENBQUE7O0FBQzdELElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsZ0JBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVMsRUFDUCxFQUNKLEVBQ0o7Ozs7OztBQUtWLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBZ0ssR0FBQSxPQUFBLEdBQUEsRUFDakMsR0FBQSxPQUFBLEdBQUEsRUFDbEMsR0FBQSxPQUFBLEVBQUE7O0FBRTdFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEsbUJBQUE7QUFBaUIsSUFBQSwwQkFBQSxFQUFLO0FBRWhFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0RBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsYUFBQSxJQUFpQixLQUFLLENBQUM7SUFBQSxDQUFBOztBQUN6RCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOztBQUViLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBcUMsSUFBQSxPQUFBLEdBQUE7O0FBRTdCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLEtBQUEsR0FBQSxFQUFpRCxJQUFBLFFBQUE7QUFDckMsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQWtCLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLElBQUEsbUZBQUE7QUFDeEMsSUFBQSwwQkFBQSxFQUFJO0FBRVIsSUFBQSw0QkFBQSxJQUFBLEtBQUEsR0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw4R0FBQTtBQUNKLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQTZCLElBQUEsVUFBQSxHQUFBO0FBQ1EsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsYUFBQSxJQUFpQixLQUFLLENBQUM7SUFBQSxDQUFBO0FBQzdELElBQUEsb0JBQUEsSUFBQSxVQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFBa0MsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsbUJBQUEsQ0FBb0I7SUFBQSxDQUFBOztBQUMzRCxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTLEVBQ1AsRUFDSixFQUNKOzs7Ozs7QUE0QmMsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7Ozs7O0FBRUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7Ozs7O0FBekJwQixJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQTJKLEdBQUEsT0FBQSxHQUFBLEVBQzVCLEdBQUEsT0FBQSxHQUFBLEVBQ2xDLEdBQUEsT0FBQSxFQUFBOztBQUU3RSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEdBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLGlCQUFBO0FBQWUsSUFBQSwwQkFBQSxFQUFLO0FBRTlELElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0RBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsaUJBQUEsQ0FBa0I7SUFBQSxDQUFBOztBQUNwRCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOztBQUViLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBcUMsSUFBQSxPQUFBLEdBQUE7O0FBRTdCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLEtBQUEsR0FBQSxFQUF3RCxJQUFBLFFBQUE7QUFDNUMsSUFBQSxvQkFBQSxJQUFBLHNCQUFBO0FBQW9CLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLElBQUEsdURBQUE7QUFBb0QsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMEJBQUE7QUFBTSxJQUFBLG9CQUFBLElBQUEsb0VBQUE7QUFDOUcsSUFBQSwwQkFBQSxFQUFJO0FBRVIsSUFBQSw0QkFBQSxJQUFBLEtBQUEsR0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSw2TEFBQTtBQUNKLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQW9DLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFdBQUEsQ0FBWTtJQUFBLENBQUE7QUFDckQsSUFBQSxpQ0FBQSxJQUFBLHFEQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBc0IsSUFBQSxxREFBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBS3RCLElBQUEsb0JBQUEsRUFBQTtBQUNKLElBQUEsMEJBQUEsRUFBUyxFQUNQLEVBQ0o7Ozs7QUFSTSxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsYUFBQSxJQUFBLEtBQUEsRUFBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGFBQUEsSUFBQSxvQkFBQSxnQkFBQSxHQUFBOzs7Ozs7QUFrQ2lCLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7OztBQTFCckMsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUE0SSxHQUFBLE9BQUEsR0FBQSxFQUNsQyxHQUFBLE9BQUEsR0FBQSxFQUM5QyxHQUFBLE1BQUEsR0FBQTtBQUNWLElBQUEsb0JBQUEsR0FBQSxjQUFBO0FBQVksSUFBQSwwQkFBQTtBQUNsRCxJQUFBLDRCQUFBLEdBQUEsVUFBQSxHQUFBO0FBQTZCLElBQUEsd0JBQUEsU0FBQSxTQUFBLCtEQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGdCQUFBLENBQWlCO0lBQUEsQ0FBQTs7QUFBcUUsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUFtQyxJQUFBLDBCQUFBLEVBQVM7O0FBRzVLLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBa0IsR0FBQSxPQUFBLEdBQUE7QUFDNEMsSUFBQSxvQkFBQSxHQUFBLGFBQUE7QUFBVyxJQUFBLDBCQUFBO0FBQ3JFLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLEVBQUE7QUFDSixJQUFBLDBCQUFBLEVBQU07QUFHVixJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQWtCLElBQUEsU0FBQSxHQUFBO0FBQzZFLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQVUsSUFBQSwwQkFBQTtBQUNyRyxJQUFBLDRCQUFBLElBQUEsU0FBQSxHQUFBO0FBQThDLElBQUEsd0JBQUEsaUJBQUEsU0FBQSxxRUFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBaUIsT0FBQSxhQUFBLElBQUEsTUFBQSxDQUF3QjtJQUFBLENBQUEsRUFBQyxlQUFBLFNBQUEscUVBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFnQixPQUFBLFVBQUEsQ0FBVztJQUFBLENBQUE7QUFBbkgsSUFBQSwwQkFBQTtBQUFtQixJQUFBLDZCQUFBO0FBR3ZCLElBQUEsMEJBQUE7QUFFQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBQXFFLElBQUEsd0JBQUEsU0FBQSxTQUFBLDZEQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFdBQUEsSUFBQSxDQUFnQixPQUFBLFdBQUEsQ0FBWSxDQUFDO0lBQUEsQ0FBQTtBQUN2RyxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBSUksSUFBQSxpQ0FBQSxJQUFBLHFEQUFBLEdBQUEsR0FBQSxZQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUFxQyxJQUFBLG9CQUFBLElBQUEsc0JBQUE7QUFBb0IsSUFBQSwwQkFBQSxFQUFNO0FBR25FLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxVQUFBLENBQVc7SUFBQSxDQUFBO0FBQ3hCLElBQUEsb0JBQUEsSUFBQSxjQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTLEVBQ1A7Ozs7QUF4Qk0sSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsbUJBQUEsR0FBQSxHQUFBO0FBTWUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLE9BQUEsYUFBQSxDQUFBO0FBQUEsSUFBQSx1QkFBQTtBQU9YLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsbUJBQUEsT0FBQSxXQUFBLENBQUEsRUFBc0MsdUJBQUEsT0FBQSxXQUFBLENBQUEsRUFDSSw0QkFBQSxDQUFBLE9BQUEsV0FBQSxDQUFBO0FBRTlDLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsV0FBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7QUF3QkosSUFBQSw0QkFBQSxHQUFBLEtBQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQXNDLElBQUEsb0JBQUEsR0FBQSxtQkFBQTtBQUMxQyxJQUFBLDBCQUFBOzs7OztBQWJaLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBK0ksR0FBQSxPQUFBLEdBQUEsRUFDekIsR0FBQSxPQUFBLEdBQUE7O0FBRTFHLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEdBQUE7QUFBb0QsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQWMsSUFBQSwwQkFBQTtBQUNsRSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxHQUFBLDJDQUFBO0FBQXdDLElBQUEsdUJBQUEsR0FBQSxJQUFBO0FBQ3hDLElBQUEsb0JBQUEsR0FBQSx5REFBQTtBQUNKLElBQUEsMEJBQUE7QUFDQSxJQUFBLGlDQUFBLElBQUEscURBQUEsR0FBQSxHQUFBLEtBQUEsR0FBQTtBQUtKLElBQUEsMEJBQUEsRUFBTTs7OztBQUxGLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsQ0FBQSxPQUFBLGFBQUEsS0FBQSxFQUFBOzs7OztBQWlCUSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBOztBQUNJLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFBd0QsSUFBQSxvQkFBQSxHQUFBLGVBQUE7QUFDNUQsSUFBQSwwQkFBQTs7Ozs7QUFWWixJQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQStJLEdBQUEsT0FBQSxHQUFBLEVBQ3BCLEdBQUEsT0FBQSxHQUFBOztBQUUvRyxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxHQUFBO0FBQW9ELElBQUEsb0JBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSwwQkFBQTtBQUM3RCxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQXNDLElBQUEsb0JBQUEsR0FBQSxxREFBQTtBQUFtRCxJQUFBLDBCQUFBO0FBQ3pGLElBQUEsaUNBQUEsR0FBQSxvREFBQSxHQUFBLEdBQUEsS0FBQSxHQUFBO0FBS0osSUFBQSwwQkFBQSxFQUFNOzs7O0FBTEYsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBcUJBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUF3RCxJQUFBLG9CQUFBLEdBQUEsZUFBQTtBQUM1RCxJQUFBLDBCQUFBOzs7OztBQWRaLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBbUosR0FBQSxPQUFBLEdBQUE7QUFFM0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFvRCxJQUFBLG9CQUFBLEdBQUEsZUFBQTtBQUFhLElBQUEsMEJBQUE7QUFDakUsSUFBQSw0QkFBQSxHQUFBLEtBQUEsR0FBQTtBQUNJLElBQUEsb0JBQUEsR0FBQSx3Q0FBQTtBQUFxQyxJQUFBLHVCQUFBLEdBQUEsSUFBQTtBQUNyQyxJQUFBLG9CQUFBLElBQUEsb0RBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxpQ0FBQSxJQUFBLHFEQUFBLEdBQUEsR0FBQSxLQUFBLEdBQUE7QUFLSixJQUFBLDBCQUFBLEVBQU07Ozs7QUFMRixJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLDJCQUFBLENBQUEsT0FBQSxhQUFBLEtBQUEsRUFBQTs7Ozs7O0FBU1IsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUErTCxHQUFBLE9BQUEsR0FBQSxFQUM5SSxHQUFBLE9BQUEsR0FBQTs7QUFFckMsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFvRCxJQUFBLG9CQUFBLEdBQUEseUJBQUE7QUFBdUIsSUFBQSwwQkFBQTtBQUMzRSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQThDLElBQUEsb0JBQUEsR0FBQSwwRkFBQTtBQUF3RixJQUFBLDBCQUFBO0FBQ3RJLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBNkIsR0FBQSxTQUFBLEdBQUE7QUFDTixJQUFBLDhCQUFBLGlCQUFBLFNBQUEsb0VBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxXQUFBLE1BQUEsTUFBQSxPQUFBLFlBQUE7QUFBQSxhQUFBLHlCQUFBLE1BQUE7SUFBQSxDQUFBO0FBQW5CLElBQUEsMEJBQUE7QUFBbUIsSUFBQSw2QkFBQTtBQUN2QixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFVBQUEsR0FBQTtBQUFRLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFVBQUEsQ0FBVztJQUFBLENBQUE7O0FBQ3hCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFBNEMsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQ2hELElBQUEsMEJBQUEsRUFBUyxFQUNQOzs7O0FBTHFCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsOEJBQUEsV0FBQSxPQUFBLFNBQUE7QUFBQSxJQUFBLHVCQUFBO0FBRU8sSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsWUFBQSxDQUFBLE9BQUEsU0FBQTs7Ozs7QUF5Q2xCLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsMkJBQUE7QUFDSixJQUFBLDBCQUFBOzs7Ozs7QUFuQ3BCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBK0osR0FBQSxPQUFBLEdBQUEsRUFDaEMsR0FBQSxPQUFBLEdBQUEsRUFFbEMsR0FBQSxPQUFBLEVBQUE7O0FBRTdFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEsYUFBQTtBQUFXLElBQUEsMEJBQUEsRUFBSztBQUUxRCxJQUFBLDRCQUFBLEdBQUEsVUFBQSxHQUFBO0FBQTZCLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGlCQUFBLENBQWtCO0lBQUEsQ0FBQTs7QUFDcEQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7QUFHYixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQWlCLElBQUEsS0FBQSxHQUFBO0FBRVQsSUFBQSxvQkFBQSxJQUFBLG1HQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUVBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBdUIsSUFBQSxPQUFBLEdBQUEsRUFDZSxJQUFBLFNBQUEsR0FBQTtBQUNrRCxJQUFBLG9CQUFBLElBQUEsV0FBQTtBQUFTLElBQUEsMEJBQUE7QUFDekYsSUFBQSw0QkFBQSxJQUFBLFFBQUEsR0FBQTtBQUdJLElBQUEsb0JBQUEsRUFBQTtBQUNKLElBQUEsMEJBQUEsRUFBTztBQUdYLElBQUEsNEJBQUEsSUFBQSxTQUFBLEdBQUE7QUFBNkMsSUFBQSx3QkFBQSxpQkFBQSxTQUFBLHNFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFpQixPQUFBLFlBQUEsSUFBQSxNQUFBLENBQXVCO0lBQUEsQ0FBQSxFQUFDLGVBQUEsU0FBQSxzRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQWdCLE9BQUEsYUFBQSxDQUFjO0lBQUEsQ0FBQTtBQUFwSCxJQUFBLDBCQUFBO0FBQW1CLElBQUEsNkJBQUE7QUFJbkIsSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxLQUFBLEdBQUE7QUFLSixJQUFBLDBCQUFBLEVBQU07QUFHVixJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQXlGLElBQUEsVUFBQSxHQUFBO0FBQ3BELElBQUEsd0JBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGlCQUFBLENBQWtCO0lBQUEsQ0FBQTtBQUN4RCxJQUFBLG9CQUFBLElBQUEsVUFBQTtBQUNKLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsYUFBQSxDQUFjO0lBQUEsQ0FBQTtBQUMzQixJQUFBLG9CQUFBLElBQUEsYUFBQTtBQUNKLElBQUEsMEJBQUEsRUFBUyxFQUNQLEVBRUo7Ozs7QUEzQmMsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSxnQkFBQSxPQUFBLFlBQUEsRUFBQSxTQUFBLEVBQUEsRUFBZ0QseUJBQUEsT0FBQSxZQUFBLEVBQUEsVUFBQSxFQUFBO0FBRWhELElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxZQUFBLEVBQUEsUUFBQSxRQUFBO0FBSVcsSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsV0FBQSxPQUFBLFlBQUEsQ0FBQTtBQUFBLElBQUEsdUJBQUE7QUFJbkIsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxZQUFBLEVBQUEsVUFBQSxLQUFBLEtBQUEsRUFBQTs7Ozs7QUF5REEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUEsRUFBcUQsR0FBQSxRQUFBO0FBQ3pDLElBQUEsb0JBQUEsR0FBQSwwQkFBQTtBQUF3QixJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxHQUFBLG9GQUFBO0FBQzlDLElBQUEsMEJBQUEsRUFBSTs7Ozs7QUFHUixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNJLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLEtBQUEsR0FBQSxFQUF3RCxHQUFBLFFBQUE7QUFDNUMsSUFBQSxvQkFBQSxHQUFBLG1CQUFBO0FBQWlCLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLEdBQUEsc0NBQUE7QUFBbUMsSUFBQSw0QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsMEJBQUE7QUFBTSxJQUFBLG9CQUFBLEdBQUEsa0NBQUE7QUFDNUYsSUFBQSwwQkFBQSxFQUFJOzs7OztBQVVBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7QUFBSyxJQUFBLHdCQUFBLE9BQUEsT0FBQSxVQUFBLEdBQUEsMEJBQUE7Ozs7O0FBRUwsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTs7Ozs7QUFLSixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQTZFLEdBQUEsT0FBQSxHQUFBOztBQUVyRSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQXNGLElBQUEsb0JBQUEsR0FBQSxpQkFBQTtBQUFlLElBQUEsMEJBQUEsRUFBTzs7Ozs7O0FBckVwSSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTJKLEdBQUEsT0FBQSxHQUFBLEVBQzVCLEdBQUEsT0FBQSxHQUFBLEVBRWxDLEdBQUEsT0FBQSxFQUFBOztBQUU3RSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEdBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLGNBQUE7QUFBWSxJQUFBLDBCQUFBLEVBQUs7QUFFM0QsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxRQUFBLENBQVM7SUFBQSxDQUFBOztBQUMzQyxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOztBQUdiLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBNEMsSUFBQSxPQUFBLEdBQUEsRUFFaUQsSUFBQSxVQUFBLEdBQUE7QUFDaEQsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBWSxLQUFLLENBQUM7SUFBQSxDQUFBOztBQUs1RCxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGFBQUE7QUFDSixJQUFBLDBCQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFBZ0MsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBWSxJQUFJLENBQUM7SUFBQSxDQUFBOztBQUt0RCxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLHFCQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTO0FBR2IsSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUEsRUFBdUIsSUFBQSxzREFBQSxHQUFBLEdBQUEsT0FBQSxHQUFBOztBQWdCdkIsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUEyQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSw4REFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUVoRSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBR0ksSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUEsRUFBbUIsSUFBQSxzREFBQSxHQUFBLEdBQUEsT0FBQSxHQUFBO0FBT3ZCLElBQUEsMEJBQUE7QUFFQSxJQUFBLGlDQUFBLElBQUEsc0RBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQTtBQVFKLElBQUEsMEJBQUE7QUFFQSxJQUFBLDRCQUFBLElBQUEsS0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLGdEQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFJO0FBSVIsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUE2RSxJQUFBLFVBQUEsR0FBQTtBQUN0QyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxXQUFBLENBQVk7SUFBQSxDQUFBOztBQUNwRCxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxJQUFBLGtCQUFBO0FBQ0osSUFBQSwwQkFBQTs7QUFDQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsUUFBQSxDQUFTO0lBQUEsQ0FBQTtBQUN0QixJQUFBLG9CQUFBLElBQUEsU0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUyxFQUNQLEVBRUo7Ozs7QUF4RWMsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSx5QkFBQSx3QkFBQSxDQUFBLE9BQUEsY0FBQSxDQUFBLEVBQStDLHFCQUFBLENBQUEsT0FBQSxjQUFBLENBQUEsRUFDSCx5QkFBQSxPQUFBLGNBQUEsQ0FBQTtBQU81QyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLHdCQUFBLE9BQUEsY0FBQSxDQUFBLEVBQThDLGtCQUFBLE9BQUEsY0FBQSxDQUFBLEVBQ04seUJBQUEsQ0FBQSxPQUFBLGNBQUEsQ0FBQTtBQU9wRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsY0FBQSxJQUFBLEtBQUEsRUFBQTtBQW1CWSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFdBQUEsQ0FBQSxPQUFBLGFBQUEsQ0FBQSxFQUFpQyxjQUFBLENBQUEsT0FBQSxhQUFBLENBQUE7QUFFckMsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxVQUFBLElBQUEsS0FBQSxFQUFBO0FBU0osSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7O0FBNERRLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7OztBQUVBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7OztBQW9CQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFyRHhCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBOEosR0FBQSxPQUFBLEdBQUEsRUFDL0IsR0FBQSxPQUFBLEdBQUEsRUFFbEMsR0FBQSxPQUFBLEVBQUE7O0FBRTdFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEscUJBQUE7QUFBbUIsSUFBQSwwQkFBQSxFQUFLO0FBRWxFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsZ0JBQUEsQ0FBaUI7SUFBQSxDQUFBOztBQUNuRCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOztBQUdiLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBcUMsSUFBQSxPQUFBLEdBQUEsRUFFMEUsSUFBQSxPQUFBLEdBQUEsRUFDdEMsSUFBQSxLQUFBLEVBQ3hELElBQUEsT0FBQSxFQUFBOztBQUVHLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLE1BQUEsR0FBQTtBQUE4QyxJQUFBLG9CQUFBLElBQUEsMEJBQUE7QUFBd0IsSUFBQSwwQkFBQSxFQUFLO0FBRS9FLElBQUEsNEJBQUEsSUFBQSxLQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsdUJBQUE7QUFBb0IsSUFBQSw0QkFBQSxJQUFBLFFBQUE7QUFBUSxJQUFBLG9CQUFBLElBQUEsU0FBQTtBQUFPLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLElBQUEsb0RBQUE7QUFBaUQsSUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLG9CQUFBLElBQUEsWUFBQTtBQUFVLElBQUEsMEJBQUE7QUFBTSxJQUFBLG9CQUFBLElBQUEsa0ZBQUE7QUFDdEgsSUFBQSwwQkFBQSxFQUFJLEVBQ0Y7QUFFVixJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQWtDLElBQUEsd0JBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGVBQUEsQ0FBZ0I7SUFBQSxDQUFBO0FBQ3ZELElBQUEsaUNBQUEsSUFBQSxzREFBQSxHQUFBLEdBQUEsWUFBQSxFQUFBLEVBQTBCLElBQUEsc0RBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQTtBQUsxQixJQUFBLG9CQUFBLEVBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7QUFHYixJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQTJFLElBQUEsT0FBQSxHQUFBLEVBQ3BCLElBQUEsS0FBQSxFQUMxQyxJQUFBLE9BQUEsRUFBQTs7QUFFRyxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxNQUFBLEdBQUE7QUFBOEMsSUFBQSxvQkFBQSxJQUFBLHFCQUFBO0FBQW1CLElBQUEsMEJBQUEsRUFBSztBQUUxRSxJQUFBLDRCQUFBLElBQUEsS0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLHFEQUFBO0FBQWtELElBQUEsNEJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxJQUFBLE1BQUE7QUFBSSxJQUFBLDBCQUFBO0FBQU8sSUFBQSxvQkFBQSxJQUFBLG9HQUFBO0FBQ3ZFLElBQUEsMEJBQUEsRUFBSSxFQUNGO0FBRVYsSUFBQSw0QkFBQSxJQUFBLFVBQUEsR0FBQTtBQUFnQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxhQUFBLENBQWM7SUFBQSxDQUFBO0FBQ25ELElBQUEsaUNBQUEsSUFBQSxzREFBQSxHQUFBLEdBQUEsWUFBQSxFQUFBLEVBQXdCLElBQUEsc0RBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQTtBQUt4QixJQUFBLG9CQUFBLEVBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVMsRUFDUCxFQUVKLEVBQ0o7Ozs7QUFoQ1UsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGlCQUFBLElBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsaUJBQUEsSUFBQSx3QkFBQSwyQkFBQSxHQUFBO0FBaUJBLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxlQUFBLElBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsZUFBQSxJQUFBLHNCQUFBLCtCQUFBLEdBQUE7Ozs7OztBQWlDQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUF6QnBCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBNEosR0FBQSxPQUFBLEdBQUEsRUFDN0IsR0FBQSxPQUFBLEdBQUEsRUFDbEMsR0FBQSxPQUFBLEVBQUE7O0FBRTdFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEscUJBQUE7QUFBbUIsSUFBQSwwQkFBQSxFQUFLO0FBRWxFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsY0FBQSxDQUFlO0lBQUEsQ0FBQTs7QUFDakQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7QUFFYixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQXFDLElBQUEsT0FBQSxHQUFBOztBQUU3QixJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEdBQUEsRUFBaUQsSUFBQSxRQUFBO0FBQ3JDLElBQUEsb0JBQUEsSUFBQSxpQkFBQTtBQUFlLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLElBQUEsdUpBQUE7QUFDckMsSUFBQSwwQkFBQSxFQUFJO0FBRVIsSUFBQSw0QkFBQSxJQUFBLEtBQUEsR0FBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSxvS0FBQTtBQUNKLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsUUFBQSxDQUFTO0lBQUEsQ0FBQTtBQUN0QixJQUFBLGlDQUFBLElBQUEsc0RBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQSxFQUFtQixJQUFBLHNEQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUE7QUFLbkIsSUFBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTLEVBQ1AsRUFDSjs7OztBQVJNLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxVQUFBLElBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsVUFBQSxJQUFBLGdCQUFBLHVCQUFBLEdBQUE7Ozs7OztBQStCSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUF6QnBCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBZ0ssR0FBQSxPQUFBLEdBQUEsRUFDakMsR0FBQSxPQUFBLEdBQUEsRUFDbEMsR0FBQSxPQUFBLEVBQUE7O0FBRTdFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSwwQkFBQSxFQUFLO0FBRWpFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsZ0JBQUEsQ0FBaUI7SUFBQSxDQUFBOztBQUNuRCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOztBQUViLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBcUMsSUFBQSxPQUFBLEdBQUE7O0FBRTdCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLEtBQUEsR0FBQSxFQUFtRCxJQUFBLFFBQUE7QUFDdkMsSUFBQSxvQkFBQSxJQUFBLGlCQUFBO0FBQWUsSUFBQSwwQkFBQTtBQUFVLElBQUEsb0JBQUEsSUFBQSw0RUFBQTtBQUNyQyxJQUFBLDBCQUFBLEVBQUk7QUFFUixJQUFBLDRCQUFBLElBQUEsS0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxJQUFBLDRLQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUM3QixJQUFBLGlDQUFBLElBQUEsc0RBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQSxFQUFxQixJQUFBLHNEQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUE7QUFLckIsSUFBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTLEVBQ1AsRUFDSjs7OztBQVJNLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxZQUFBLElBQUEsS0FBQSxFQUFBO0FBS0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsWUFBQSxJQUFBLHdCQUFBLG9CQUFBLEdBQUE7Ozs7O0FBeUNBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBLEVBQXdELEdBQUEsUUFBQTtBQUM1QyxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSwwQkFBQTtBQUFVLElBQUEsb0JBQUEsR0FBQSwrSEFBQTtBQUN4QyxJQUFBLDBCQUFBLEVBQUk7Ozs7O0FBR1IsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUEsRUFBcUQsR0FBQSxRQUFBO0FBQ3pDLElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFrQixJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxHQUFBLHVHQUFBO0FBQ3hDLElBQUEsMEJBQUEsRUFBSTs7Ozs7QUFjSixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQTZFLEdBQUEsT0FBQSxHQUFBOztBQUVyRSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQXNGLElBQUEsb0JBQUEsR0FBQSxpQkFBQTtBQUFlLElBQUEsMEJBQUEsRUFBTzs7Ozs7O0FBVXBILElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBMkksR0FBQSxPQUFBLEdBQUEsRUFDbkYsR0FBQSxRQUFBLEdBQUE7QUFDbUMsSUFBQSxvQkFBQSxHQUFBLGFBQUE7QUFBVyxJQUFBLDBCQUFBO0FBQzlGLElBQUEsNEJBQUEsR0FBQSxRQUFBLEdBQUE7QUFBNEQsSUFBQSxvQkFBQSxDQUFBO0FBQXVCLElBQUEsMEJBQUEsRUFBTztBQUU5RixJQUFBLDRCQUFBLEdBQUEsU0FBQSxHQUFBO0FBR1EsSUFBQSx3QkFBQSxpQkFBQSxTQUFBLG9GQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQWlCLE9BQUEsb0JBQUEsTUFBQSxDQUEyQjtJQUFBLENBQUE7QUFIcEQsSUFBQSwwQkFBQTtBQUVRLElBQUEsNkJBQUE7QUFHUixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQTRGLEdBQUEsTUFBQTtBQUNsRixJQUFBLG9CQUFBLEdBQUEscUJBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUN6QixJQUFBLDRCQUFBLElBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsSUFBQSxzQkFBQTtBQUFvQixJQUFBLDBCQUFBLEVBQU8sRUFDL0I7Ozs7QUFWMEQsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxJQUFBLE9BQUEsY0FBQSxHQUFBLElBQUE7QUFJeEQsSUFBQSx1QkFBQTtBQUFBLElBQUEsd0JBQUEsV0FBQSxPQUFBLGNBQUEsQ0FBQTtBQUFBLElBQUEsdUJBQUE7Ozs7OztBQS9FNUIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFtSyxHQUFBLE9BQUEsR0FBQSxFQUNwQyxHQUFBLE9BQUEsR0FBQSxFQUVsQyxHQUFBLE9BQUEsRUFBQTs7QUFFN0UsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxHQUFBO0FBQXNDLElBQUEsb0JBQUEsR0FBQSx3QkFBQTtBQUFzQixJQUFBLDBCQUFBLEVBQUs7QUFFckUsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxtQkFBQSxDQUFvQjtJQUFBLENBQUE7O0FBQ3RELElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7O0FBR2IsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUE0QyxJQUFBLE9BQUEsR0FBQSxFQUVpRCxJQUFBLFVBQUEsR0FBQTtBQUMxRCxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxnQkFBZ0IsSUFBSSxDQUFDO0lBQUEsQ0FBQTtBQUtyRCxJQUFBLG9CQUFBLElBQUEsa0JBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFVBQUEsR0FBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxnQkFBZ0IsTUFBTSxDQUFDO0lBQUEsQ0FBQTtBQUt6RCxJQUFBLG9CQUFBLElBQUEsbUJBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7QUFHYixJQUFBLGlDQUFBLElBQUEsc0RBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQSxFQUErQixJQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFnQi9CLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUE7QUFBNkUsSUFBQSx3QkFBQSxTQUFBLFNBQUEsOERBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEscUJBQUEsQ0FBc0I7SUFBQSxDQUFBO0FBRXhHLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUE7QUFJSSxJQUFBLHVCQUFBLElBQUEsVUFBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUVBLElBQUEsaUNBQUEsSUFBQSxzREFBQSxHQUFBLEdBQUEsT0FBQSxHQUFBO0FBUUosSUFBQSwwQkFBQTtBQUVBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsaUVBQUE7QUFDSixJQUFBLDBCQUFBO0FBRUEsSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLElBQUEsR0FBQSxPQUFBLEdBQUE7QUFrQkosSUFBQSwwQkFBQTtBQUVBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBeUYsSUFBQSxVQUFBLEdBQUE7QUFDcEQsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsbUJBQUEsQ0FBb0I7SUFBQSxDQUFBO0FBQzFELElBQUEsb0JBQUEsSUFBQSxTQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTLEVBQ1AsRUFFSjs7OztBQS9FYyxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLHlCQUFBLHdCQUFBLE9BQUEsYUFBQSxNQUFBLElBQUEsRUFBc0QscUJBQUEsT0FBQSxhQUFBLE1BQUEsSUFBQSxFQUNILHlCQUFBLE9BQUEsYUFBQSxNQUFBLElBQUE7QUFNbkQsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSx3QkFBQSxPQUFBLGFBQUEsTUFBQSxNQUFBLEVBQXdELGtCQUFBLE9BQUEsYUFBQSxNQUFBLE1BQUEsRUFDTix5QkFBQSxPQUFBLGFBQUEsTUFBQSxNQUFBO0FBTTlELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxhQUFBLE1BQUEsT0FBQSxLQUFBLEVBQUE7QUFtQlksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxXQUFBLENBQUEsT0FBQSxtQkFBQSxDQUFBLEVBQXVDLGNBQUEsQ0FBQSxPQUFBLG1CQUFBLENBQUE7QUFNL0MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsbUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFjSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsbUJBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBbUVRLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQW9DLElBQUEsb0JBQUEsQ0FBQTtBQUEyQixJQUFBLDBCQUFBLEVBQU87Ozs7QUFBbEMsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLFVBQUEsVUFBQSxDQUFBOzs7OztBQW9CeEMsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUF5SCxHQUFBLE9BQUEsR0FBQSxFQUMzQixHQUFBLE1BQUE7QUFDaEYsSUFBQSxvQkFBQSxHQUFBLDZCQUFBO0FBQTJCLElBQUEsMEJBQUE7QUFDakMsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7QUFBa0QsSUFBQSwwQkFBQSxFQUFPO0FBRW5FLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBRUosSUFBQSwwQkFBQSxFQUFNOzs7O0FBTEksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsVUFBQSxhQUFBLElBQUEsS0FBQSxRQUFBLENBQUEsR0FBQSxHQUFBO0FBSUUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxTQUFBLE9BQUEsVUFBQSxhQUFBLElBQUEsS0FBQSxHQUFBOzs7Ozs7QUFqRXBDLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBa0ssR0FBQSxPQUFBLEdBQUEsRUFDbkMsR0FBQSxPQUFBLEdBQUEsRUFFbEMsR0FBQSxPQUFBLEVBQUE7O0FBRTdFLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEsd0JBQUE7QUFBc0IsSUFBQSwwQkFBQSxFQUFLO0FBRXJFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTs7QUFDL0MsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7QUFHYixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQTRDLElBQUEsT0FBQSxHQUFBOztBQUd4QyxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBb0UsSUFBQSxHQUFBLEVBQzdELElBQUEsUUFBQTtBQUNTLElBQUEsb0JBQUEsSUFBQSxpQkFBQTtBQUFlLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLElBQUEsc0VBQUE7QUFDckMsSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxLQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLElBQUEsYUFBQTtBQUFHLElBQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxJQUFBLE1BQUE7QUFBSSxJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxFQUFBO0FBQzdCLElBQUEsMEJBQUEsRUFBSSxFQUNGO0FBR04sSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUFtQyxJQUFBLE9BQUEsR0FBQSxFQUM2RSxJQUFBLFFBQUEsR0FBQTtBQUNyQixJQUFBLG9CQUFBLElBQUEsa0JBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUNuRyxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFPO0FBR1gsSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFNSixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUVJLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFFQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQWlILElBQUEsT0FBQSxHQUFBO0FBRXpHLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBeUcsSUFBQSxPQUFBLEdBQUEsRUFDQyxJQUFBLE9BQUEsR0FBQSxFQUNFLElBQUEsT0FBQSxHQUFBLEVBQ0MsSUFBQSxPQUFBLEdBQUE7QUFFakgsSUFBQSwwQkFBQSxFQUFNO0FBR1YsSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFZSixJQUFBLDBCQUFBLEVBQU07QUFHVixJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQXlGLElBQUEsVUFBQSxHQUFBO0FBQ3ZELElBQUEsd0JBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDaEQsSUFBQSxvQkFBQSxJQUFBLGtCQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTLEVBQ1AsRUFFSjs7OztBQXhEbUMsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSxnQ0FBQSwyTEFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLFdBQUEsd0JBQUE7QUFRb0QsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxTQUFBLE9BQUEsVUFBQSxnQkFBQSxDQUFBO0FBQ3pFLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxVQUFBLGdCQUFBLEtBQUEscUJBQUEsR0FBQTtBQUlSLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsVUFBQSxVQUFBLElBQUEsS0FBQSxFQUFBO0FBc0JBLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxVQUFBLGFBQUEsSUFBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7O0FBd0NBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSw4RUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGtCQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUNoQyxJQUFBLG9CQUFBLEdBQUEsVUFBQTtBQUNKLElBQUEsMEJBQUE7Ozs7OztBQWhCaEIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUE4SSxHQUFBLE9BQUEsR0FBQTtBQUV0SSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBSUEsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFtRCxJQUFBLG9CQUFBLENBQUE7QUFBeUIsSUFBQSwwQkFBQTtBQUU1RSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQThGLElBQUEsb0JBQUEsQ0FBQTtBQUM5RixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUVJLElBQUEsaUNBQUEsR0FBQSxxREFBQSxHQUFBLEdBQUEsVUFBQSxHQUFBO0FBTUEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUFRLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLHFCQUFBLENBQXNCO0lBQUEsQ0FBQTtBQU9uQyxJQUFBLG9CQUFBLEVBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVMsRUFDUCxFQUNKOzs7O0FBMUJNLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsZUFBQSxPQUFBLFlBQUEsRUFBQSxhQUFBLEVBQWlELG1CQUFBLENBQUEsT0FBQSxZQUFBLEVBQUEsYUFBQTtBQUdOLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxZQUFBLEVBQUEsS0FBQTtBQUUyQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLElBQUEsT0FBQSxZQUFBLEVBQUEsU0FBQSxHQUFBO0FBR3RFLElBQUEsdUJBQUE7QUFBQSxJQUFBLHlCQUFBLGVBQUEsT0FBQSxZQUFBLEVBQUEsU0FBQSxTQUFBLEVBQXNELGVBQUEsT0FBQSxZQUFBLEVBQUEsU0FBQSxPQUFBO0FBRTFFLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsWUFBQSxFQUFBLFNBQUEsWUFBQSxJQUFBLEVBQUE7QUFRUSxJQUFBLHVCQUFBO0FBQUEsSUFBQSx5QkFBQSxlQUFBLE9BQUEsWUFBQSxFQUFBLGFBQUEsRUFBaUQscUJBQUEsT0FBQSxZQUFBLEVBQUEsYUFBQSxFQUNNLGNBQUEsT0FBQSxZQUFBLEVBQUEsYUFBQSxFQUNQLG1CQUFBLENBQUEsT0FBQSxZQUFBLEVBQUEsYUFBQSxFQUNNLCtCQUFBLENBQUEsT0FBQSxZQUFBLEVBQUEsYUFBQTtBQUUxRCxJQUFBLHVCQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsWUFBQSxFQUFBLFNBQUEsWUFBQSxZQUFBLE1BQUEsR0FBQTs7Ozs7O0FBOEJJLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7OztBQUVBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7O0FBY0ksSUFBQSx1QkFBQSxHQUFBLFFBQUEsRUFBQTs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsUUFBQSxFQUFBOzs7OztBQUVBLElBQUEsdUJBQUEsR0FBQSxRQUFBLEVBQUE7Ozs7OztBQVFBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFDSSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxnQkFBQSxDQUFpQjtJQUFBLENBQUE7O0FBRzFCLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBOzs7Ozs7QUFTUSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7OztBQWtDUixJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBO0FBRUEsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUE0QixHQUFBLE9BQUEsR0FBQTs7QUFFcEIsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXdELElBQUEsb0JBQUEsR0FBQSxhQUFBO0FBQVcsSUFBQSwwQkFBQSxFQUFPO0FBRzlFLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLEdBQUEsNkJBQUE7QUFDSixJQUFBLDBCQUFBLEVBQU07Ozs7O0FBOEJGLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMEMsSUFBQSxvQkFBQSxHQUFBLFNBQUE7QUFBTyxJQUFBLDBCQUFBOzs7OztBQUVqRCxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWtDLElBQUEsb0JBQUEsQ0FBQTtBQUFxQixJQUFBLDBCQUFBOzs7O0FBQXJCLElBQUEsdUJBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsY0FBQSxDQUFBOzs7Ozs7QUFZbEQsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFvRSxHQUFBLFVBQUEsR0FBQTtBQUN4RCxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxrQkFBa0Isc0JBQXNCLENBQUM7SUFBQSxDQUFBOztBQUN0RCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLHNCQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOzs7Ozs7QUFVVCxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTRCLEdBQUEsVUFBQSxHQUFBO0FBQ00sSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsdUJBQUEsQ0FBd0I7SUFBQSxDQUFBOztBQUMzRCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLGFBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7O0FBR2IsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUVBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBNEIsR0FBQSxVQUFBLEdBQUE7QUFDSSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxrQkFBQSxDQUFtQjtJQUFBLENBQUE7O0FBQ3BELElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsT0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7QUFFYixJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFNUSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFZSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOzs7Ozs7QUFMWixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTRCLEdBQUEsVUFBQSxHQUFBO0FBQ2EsSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsZUFBQSxDQUFnQjtJQUFBLENBQUE7QUFDMUQsSUFBQSxpQ0FBQSxHQUFBLHFEQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBcUIsR0FBQSxxREFBQSxHQUFBLEdBQUEsWUFBQSxHQUFBO0FBS3JCLElBQUEsb0JBQUEsQ0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUztBQUdiLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7QUFUUSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsWUFBQSxJQUFBLElBQUEsQ0FBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLFlBQUEsSUFBQSxXQUFBLGdCQUFBLEdBQUE7Ozs7OztBQWlDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOzs7Ozs7QUFYWixJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUE0QixHQUFBLFVBQUEsR0FBQTtBQUNVLElBQUEsd0JBQUEsU0FBQSxTQUFBLGdFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFdBQUEsQ0FBWTtJQUFBLENBQUE7QUFNbkQsSUFBQSxpQ0FBQSxHQUFBLHFEQUFBLEdBQUEsR0FBQSxZQUFBLEdBQUEsRUFBb0MsR0FBQSxxREFBQSxHQUFBLEdBQUEsWUFBQSxHQUFBO0FBS3BDLElBQUEsb0JBQUEsQ0FBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7OztBQVZELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsaUJBQUEsT0FBQSxPQUFBLFVBQUEsR0FBQSxRQUFBLEVBQW9ELG9CQUFBLE9BQUEsT0FBQSxVQUFBLEdBQUEsUUFBQSxFQUNFLHlCQUFBLENBQUEsT0FBQSxPQUFBLFVBQUEsR0FBQSxRQUFBLEVBQ08sOEJBQUEsQ0FBQSxPQUFBLE9BQUEsVUFBQSxHQUFBLFFBQUE7QUFFakUsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxPQUFBLFVBQUEsR0FBQSxXQUFBLElBQUEsQ0FBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLE9BQUEsVUFBQSxHQUFBLFdBQUEsV0FBQSxhQUFBLEdBQUE7Ozs7OztBQU1SLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTRCLEdBQUEsVUFBQSxHQUFBO0FBQ1csSUFBQSx3QkFBQSxTQUFBLFNBQUEsZ0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsVUFBQSxDQUFXO0lBQUEsQ0FBQTs7QUFDbkQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxTQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOzs7Ozs7QUFnREcsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7Ozs7O0FBRUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7Ozs7QUFTSSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQXFKLElBQUEsb0JBQUEsR0FBQSxLQUFBO0FBQUcsSUFBQSwwQkFBQTs7Ozs7O0FBZ0JoSyxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOzs7Ozs7QUF4Q1osSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUlnRixHQUFBLE9BQUEsR0FBQSxFQUV2QixHQUFBLE9BQUEsR0FBQTtBQUk3QyxJQUFBLGlDQUFBLEdBQUEsNERBQUEsR0FBQSxHQUFBLFlBQUEsR0FBQSxFQUFnQyxHQUFBLDREQUFBLEdBQUEsR0FBQSxZQUFBLEdBQUE7QUFLcEMsSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBcUIsR0FBQSxPQUFBLEVBQUEsRUFDb0IsR0FBQSxRQUFBLEdBQUE7QUFFN0IsSUFBQSxvQkFBQSxDQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUNBLElBQUEsaUNBQUEsR0FBQSw0REFBQSxHQUFBLEdBQUEsUUFBQSxHQUFBO0FBR0osSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLEVBQUE7QUFDSixJQUFBLDBCQUFBLEVBQU0sRUFDSjtBQUdWLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFLSSxJQUFBLHdCQUFBLFNBQUEsU0FBQSx3RUFBQTtBQUFBLFlBQUEsY0FBQSwyQkFBQSxJQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxjQUFBLFlBQUEsSUFBQSxZQUFBLFdBQUEsQ0FBOEM7SUFBQSxDQUFBO0FBQ3ZELElBQUEsaUNBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsWUFBQSxHQUFBLEVBQXdDLElBQUEsNkRBQUEsR0FBQSxHQUFBLFlBQUEsR0FBQTtBQUs1QyxJQUFBLDBCQUFBLEVBQVM7Ozs7O0FBekNULElBQUEseUJBQUEsc0JBQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxpQkFBQSxDQUFBLEVBQXFFLDBCQUFBLFlBQUEsT0FBQSxPQUFBLE9BQUEsaUJBQUEsQ0FBQSxFQUNJLGVBQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxpQkFBQSxDQUFBLEVBQ1gsNEJBQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxpQkFBQSxDQUFBO0FBS3RELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsb0JBQUEsWUFBQSxTQUFBLE9BQUEsRUFBbUQsd0JBQUEsWUFBQSxTQUFBLE9BQUE7QUFFbkQsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsWUFBQSxTQUFBLFVBQUEsSUFBQSxDQUFBO0FBUTZELElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsVUFBQSxDQUFBLFlBQUEsV0FBQTtBQUNyRCxJQUFBLHVCQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLFlBQUEsZUFBQSxtQkFBQSxHQUFBO0FBRUosSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsWUFBQSxPQUFBLE9BQUEsT0FBQSxpQkFBQSxJQUFBLElBQUEsRUFBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsY0FBQSxZQUFBLElBQUEsR0FBQTtBQU1SLElBQUEsdUJBQUE7QUFBQSxJQUFBLHlCQUFBLHFCQUFBLE9BQUEsZ0JBQUEsTUFBQSxZQUFBLEVBQUEsRUFBNEQseUJBQUEsT0FBQSxnQkFBQSxNQUFBLFlBQUEsRUFBQSxFQUNJLHlCQUFBLE9BQUEsZ0JBQUEsTUFBQSxZQUFBLEVBQUE7QUFJaEUsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxnQkFBQSxNQUFBLFlBQUEsS0FBQSxLQUFBLEVBQUE7Ozs7O0FBVVIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0EsSUFBQSxvQkFBQSxHQUFBLHVCQUFBO0FBQ0osSUFBQSwwQkFBQTs7Ozs7O0FBOUVoQixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQW1KLEdBQUEsT0FBQSxHQUFBLEVBQ0YsR0FBQSxPQUFBLEdBQUEsRUFFeEIsR0FBQSxPQUFBLEVBQUE7O0FBRXpHLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEsaUJBQUE7QUFBZSxJQUFBLDBCQUFBLEVBQUs7QUFFOUQsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxrQkFBQSxJQUFzQixLQUFLLENBQUM7SUFBQSxDQUFBOztBQUM5RCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFTOztBQUdiLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBd0UsSUFBQSxTQUFBLEdBQUE7QUFDdUIsSUFBQSxvQkFBQSxJQUFBLGlCQUFBO0FBQWUsSUFBQSwwQkFBQTtBQUMxRyxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBLEVBQXdCLElBQUEsU0FBQSxHQUFBO0FBQ2lDLElBQUEsd0JBQUEsaUJBQUEsU0FBQSxzRUFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBaUIsT0FBQSxvQkFBQSxJQUFBLE1BQUEsQ0FBK0I7SUFBQSxDQUFBLEVBQUMsZUFBQSxTQUFBLHNFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBZ0IsT0FBQSxpQkFBQSxDQUFrQjtJQUFBLENBQUE7QUFBeEksSUFBQSwwQkFBQTtBQUFtQixJQUFBLDZCQUFBO0FBR25CLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxpQkFBQSxDQUFrQjtJQUFBLENBQUE7QUFDL0IsSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7QUFFYixJQUFBLDRCQUFBLElBQUEsS0FBQSxHQUFBO0FBQWtELElBQUEsb0JBQUEsSUFBQSxzRkFBQTtBQUFvRixJQUFBLDBCQUFBLEVBQUk7QUFHOUksSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUNJLElBQUEsOEJBQUEsSUFBQSw4Q0FBQSxJQUFBLElBQUEsT0FBQSxLQUFBLFVBQUE7QUErQ0EsSUFBQSxpQ0FBQSxJQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFNSixJQUFBLDBCQUFBLEVBQU0sRUFDSjs7OztBQWpFeUIsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLE9BQUEsb0JBQUEsQ0FBQTtBQUFBLElBQUEsdUJBQUE7QUFXdkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxPQUFBLE9BQUEsZUFBQSxDQUF1QjtBQStDdkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLE9BQUEsZUFBQSxFQUFBLFdBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7O0FBbUJJLElBQUEsb0JBQUEsR0FBQSwyQkFBQTs7Ozs7QUFFQSxJQUFBLG9CQUFBLEdBQUEsVUFBQTs7Ozs7QUFLSixJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBOztBQUNJLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFBc0MsSUFBQSxvQkFBQSxHQUFBLHFCQUFBO0FBQzFDLElBQUEsMEJBQUE7Ozs7O0FBaEJaLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBNkksR0FBQSxPQUFBLEdBQUEsRUFDbEIsR0FBQSxPQUFBLEdBQUE7O0FBRS9HLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxNQUFBLEdBQUE7QUFDSSxJQUFBLGlDQUFBLEdBQUEscURBQUEsR0FBQSxDQUFBLEVBQTJDLEdBQUEscURBQUEsR0FBQSxDQUFBO0FBSy9DLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQXNDLElBQUEsb0JBQUEsR0FBQSxtRkFBQTtBQUFpRixJQUFBLDBCQUFBO0FBQ3ZILElBQUEsaUNBQUEsR0FBQSxxREFBQSxHQUFBLEdBQUEsS0FBQSxHQUFBO0FBS0osSUFBQSwwQkFBQSxFQUFNOzs7O0FBWkUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGNBQUEsT0FBQSxFQUFBLGVBQUEsSUFBQSxDQUFBO0FBT0osSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxJQUFBLEVBQUE7Ozs7O0FBa0JJLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUFzQyxJQUFBLG9CQUFBLEdBQUEscUJBQUE7QUFDMUMsSUFBQSwwQkFBQTs7Ozs7QUFWWixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQThJLEdBQUEsT0FBQSxHQUFBLEVBQ25CLEdBQUEsT0FBQSxHQUFBOztBQUUvRyxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxHQUFBO0FBQW9ELElBQUEsb0JBQUEsR0FBQSxjQUFBO0FBQVksSUFBQSwwQkFBQTtBQUNoRSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQXNDLElBQUEsb0JBQUEsR0FBQSxnRUFBQTtBQUE4RCxJQUFBLDBCQUFBO0FBQ3BHLElBQUEsaUNBQUEsR0FBQSxzREFBQSxHQUFBLEdBQUEsS0FBQSxHQUFBO0FBS0osSUFBQSwwQkFBQSxFQUFNOzs7O0FBTEYsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsYUFBQSxJQUFBLEVBQUE7Ozs7OztBQVVSLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBNkksR0FBQSxPQUFBLEdBQUE7QUFHekksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUVBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQSxHQUFBO0FBQThDLElBQUEsb0JBQUEsR0FBQSxlQUFBO0FBQWEsSUFBQSwwQkFBQSxFQUFLO0FBR2hFLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsNEZBQUE7QUFDQSxJQUFBLHVCQUFBLEdBQUEsSUFBQSxFQUFJLElBQUEsSUFBQTtBQUNKLElBQUEsNEJBQUEsSUFBQSxRQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxJQUFBLE9BQUEsR0FBQTtBQUFnRSxJQUFBLG9CQUFBLElBQUEseUNBQUE7QUFDcEUsSUFBQSwwQkFBQTs7QUFDQSxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBOztBQUNJLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFBZ0UsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQ3BFLElBQUEsMEJBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFFBQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLElBQUEsT0FBQSxHQUFBO0FBQWdFLElBQUEsb0JBQUEsSUFBQSwrQ0FBQTtBQUNwRSxJQUFBLDBCQUFBLEVBQU87O0FBR1AsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUFrRSxJQUFBLFVBQUEsR0FBQTtBQUU5RCxJQUFBLHdCQUFBLFNBQUEsU0FBQSxrRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxvQkFBQSxDQUFxQjtJQUFBLENBQUE7QUFFOUIsSUFBQSxvQkFBQSxJQUFBLGdCQUFBO0FBQ0osSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxVQUFBLEdBQUE7QUFDSSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxrRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxpQkFBQSxDQUFrQjtJQUFBLENBQUE7O0FBRTNCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsY0FBQTtBQUNKLElBQUEsMEJBQUE7O0FBQ0EsSUFBQSw0QkFBQSxJQUFBLFVBQUEsR0FBQTtBQUNJLElBQUEsd0JBQUEsU0FBQSxTQUFBLGtFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGNBQUEsQ0FBZTtJQUFBLENBQUE7O0FBRXhCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsa0JBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVMsRUFDSCxFQUNKOzs7Ozs7QUE0QmMsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7Ozs7O0FBRUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsRUFBQTs7Ozs7O0FBMEJSLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBb0UsR0FBQSxVQUFBLEdBQUE7QUFDeEQsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsa0JBQWtCLHNCQUFzQixDQUFDO0lBQUEsQ0FBQTs7QUFDdEQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxzQkFBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7Ozs7QUErREwsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUEySCxHQUFBLE9BQUEsR0FBQSxFQUNsRCxHQUFBLE1BQUE7QUFDM0QsSUFBQSxvQkFBQSxHQUFBLHdCQUFBO0FBQXNCLElBQUEsMEJBQUE7QUFDNUIsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7QUFBa0QsSUFBQSwwQkFBQSxFQUFPO0FBRW5FLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFNOzs7O0FBSkksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsVUFBQSxhQUFBLElBQUEsS0FBQSxRQUFBLENBQUEsR0FBQSxHQUFBO0FBRytFLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsU0FBQSxPQUFBLFVBQUEsYUFBQSxJQUFBLEtBQUEsR0FBQTs7Ozs7O0FBM0JyRyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUVBLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBaUgsR0FBQSxPQUFBLEdBQUEsRUFDaUUsR0FBQSxRQUFBLEdBQUE7QUFFdEssSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSwyQkFBQTtBQUNKLElBQUEsMEJBQUEsRUFBTztBQUdYLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQXlHLEdBQUEsT0FBQSxHQUFBLEVBQ0MsSUFBQSxPQUFBLEdBQUEsRUFDRSxJQUFBLE9BQUEsR0FBQSxFQUNDLElBQUEsT0FBQSxHQUFBO0FBRWpILElBQUEsMEJBQUEsRUFBTTtBQUdWLElBQUEsaUNBQUEsSUFBQSx1REFBQSxHQUFBLEdBQUEsT0FBQSxHQUFBO0FBWUEsSUFBQSw0QkFBQSxJQUFBLFVBQUEsR0FBQTtBQUFRLElBQUEsd0JBQUEsU0FBQSxTQUFBLGtFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7O0FBQzFCLElBQUEsdUJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7Ozs7QUFkVCxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsVUFBQSxhQUFBLElBQUEsSUFBQSxLQUFBLEVBQUE7Ozs7OztBQWlDQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUErQkksSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDSSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOztBQUNBLElBQUEsNEJBQUEsR0FBQSxTQUFBLEdBQUE7QUFBa0QsSUFBQSx3QkFBQSxpQkFBQSxTQUFBLHNFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFpQixPQUFBLGtCQUFrQixVQUFRLE1BQUEsQ0FBUztJQUFBLENBQUE7QUFBdEcsSUFBQSwwQkFBQTtBQUFtQixJQUFBLDZCQUFBO0FBRW5CLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBLEVBQU07Ozs7QUFKYSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFdBQUEsT0FBQSxpQkFBQSxDQUFBO0FBQUEsSUFBQSx1QkFBQTtBQUdmLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGVBQUEsRUFBQSxRQUFBLEdBQUE7Ozs7OztBQUlSLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsU0FBQSxHQUFBO0FBQW1ELElBQUEsd0JBQUEsaUJBQUEsU0FBQSxzRUFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBaUIsT0FBQSxrQkFBa0IsV0FBUyxNQUFBLENBQVM7SUFBQSxDQUFBO0FBQXhHLElBQUEsMEJBQUE7QUFBbUIsSUFBQSw2QkFBQTtBQUVuQixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxDQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFNOzs7O0FBSmEsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxXQUFBLE9BQUEsa0JBQUEsQ0FBQTtBQUFBLElBQUEsdUJBQUE7QUFHZixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxnQkFBQSxFQUFBLFFBQUEsR0FBQTs7Ozs7O0FBU1IsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUFtQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSwrRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGdCQUFBLENBQWlCO0lBQUEsQ0FBQTs7QUFDekQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUE4QyxJQUFBLG9CQUFBLEdBQUEscUJBQUE7QUFDbEQsSUFBQSwwQkFBQTs7Ozs7O0FBR0EsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUFvQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSwrRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGlCQUFBLENBQWtCO0lBQUEsQ0FBQTs7QUFDM0QsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUE4QyxJQUFBLG9CQUFBLEdBQUEsc0JBQUE7QUFDbEQsSUFBQSwwQkFBQTs7Ozs7QUFUUixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQ0ksSUFBQSxpQ0FBQSxHQUFBLHNEQUFBLEdBQUEsR0FBQSxVQUFBLEdBQUE7QUFLQSxJQUFBLGlDQUFBLEdBQUEsc0RBQUEsR0FBQSxHQUFBLFVBQUEsR0FBQTtBQUtKLElBQUEsMEJBQUE7Ozs7QUFWSSxJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLFNBQUEsTUFBQSxXQUFBLElBQUEsRUFBQTtBQUtBLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsU0FBQSxNQUFBLFlBQUEsSUFBQSxFQUFBOzs7Ozs7QUFtQm9CLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLFFBQUEsR0FBQTtBQUF5RixJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFBYyxJQUFBLDBCQUFBOzs7Ozs7QUFFdkcsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQThGLElBQUEsb0JBQUEsR0FBQSxrQkFBQTtBQUFnQixJQUFBLDBCQUFBOzs7OztBQWV0RyxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQW1HLElBQUEsb0JBQUEsQ0FBQTtBQUFpQyxJQUFBLDBCQUFBOzs7O0FBQWpDLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLElBQUEsVUFBQSxNQUFBLEtBQUEsVUFBQSxJQUFBOzs7Ozs7QUFVL0YsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7Ozs7O0FBRUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7Ozs7O0FBa0JSLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxzRkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsWUFBQSwyQkFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsZ0JBQUEsVUFBQSxPQUFBLENBQThCO0lBQUEsQ0FBQTtBQUszQyxJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBOzs7OztBQUpRLElBQUEsd0JBQUEsT0FBQSxjQUFBLFVBQUEsT0FBQSxJQUFBLGtHQUFBLDhHQUFBO0FBR0osSUFBQSx1QkFBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGNBQUEsVUFBQSxPQUFBLElBQUEsV0FBQSxVQUFBLEdBQUE7Ozs7OztBQTdEcEIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUVxRSxHQUFBLE9BQUEsR0FBQTtBQUk3RCxJQUFBLGlDQUFBLEdBQUEsNERBQUEsR0FBQSxDQUFBLEVBQW9DLEdBQUEsNERBQUEsR0FBQSxDQUFBO0FBT3hDLElBQUEsMEJBQUE7QUFHQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQWdFLEdBQUEsT0FBQSxHQUFBLEVBR1osR0FBQSxPQUFBLEVBQUEsRUFDUCxHQUFBLFFBQUEsR0FBQTtBQUc3QixJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxpQ0FBQSxHQUFBLDREQUFBLEdBQUEsR0FBQSxRQUFBLEdBQUE7QUFHSixJQUFBLDBCQUFBO0FBR0EsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUE2SCxJQUFBLFFBQUEsR0FBQTtBQUN6QyxJQUFBLG9CQUFBLEVBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUVuRyxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsd0VBQUE7QUFBQSxZQUFBLFlBQUEsMkJBQUEsSUFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxVQUFBLE9BQUEsQ0FBMEI7SUFBQSxDQUFBO0FBQ3ZDLElBQUEsaUNBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsWUFBQSxHQUFBLEVBQXlDLElBQUEsNkRBQUEsR0FBQSxHQUFBLFlBQUEsR0FBQTtBQU96QyxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFNLEVBQ0QsRUFDUDtBQUlWLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBa0YsSUFBQSxPQUFBLEdBQUE7QUFFMUUsSUFBQSxvQkFBQSxFQUFBOztBQUFnRCxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBO0FBQW9DLElBQUEsb0JBQUEsSUFBQSxLQUFBO0FBQUcsSUFBQSwwQkFBQSxFQUFPO0FBR2xHLElBQUEsaUNBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsVUFBQSxHQUFBO0FBU0osSUFBQSwwQkFBQSxFQUFNLEVBQ0o7Ozs7OztBQWhFTixJQUFBLHlCQUFBLHNCQUFBLE9BQUEsY0FBQSxVQUFBLE9BQUEsQ0FBQSxFQUF5RCw0QkFBQSxDQUFBLE9BQUEsY0FBQSxVQUFBLE9BQUEsQ0FBQTtBQUtyRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsY0FBQSxVQUFBLE9BQUEsSUFBQSxJQUFBLENBQUE7QUFpQlksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxZQUFBLFlBQUEsR0FBQTtBQUVKLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLFVBQUEsUUFBQSxVQUFBLFNBQUEsU0FBQSxJQUFBLEVBQUE7QUFPZ0YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxVQUFBLE9BQUE7QUFHNUUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGNBQUEsTUFBQSxVQUFBLFVBQUEsS0FBQSxFQUFBO0FBUUksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsY0FBQSxNQUFBLFVBQUEsVUFBQSxZQUFBLGdCQUFBLEdBQUE7QUFTUixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEseUJBQUEsSUFBQSxJQUFBLFVBQUEsU0FBQSxLQUFBLE9BQUEsR0FBQSxHQUFBO0FBR0osSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLE9BQUEsY0FBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7QUFjWixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQTRELElBQUEsb0JBQUEsR0FBQSwwQkFBQTtBQUF3QixJQUFBLDBCQUFBOzs7OztBQUVwRixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQTRELElBQUEsb0JBQUEsR0FBQSw4QkFBQTtBQUE0QixJQUFBLDBCQUFBOzs7OztBQXpFNUYsSUFBQSw4QkFBQSxHQUFBLDhDQUFBLElBQUEsSUFBQSxPQUFBLEtBQUEsbUNBQUE7QUFzRUEsSUFBQSxpQ0FBQSxHQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUEsRUFBMkQsR0FBQSxzREFBQSxHQUFBLEdBQUEsT0FBQSxHQUFBOzs7O0FBdEUzRCxJQUFBLHdCQUFBLE9BQUEsZUFBQSxDQUFnQjtBQXNFaEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLE9BQUEsVUFBQSxHQUFBLFlBQUEsVUFBQSxPQUFBLElBQUEsSUFBQSxPQUFBLGVBQUEsRUFBQSxXQUFBLElBQUEsSUFBQSxFQUFBOzs7Ozs7QUFtQlksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQXVGLElBQUEsb0JBQUEsR0FBQSxlQUFBO0FBQWEsSUFBQSwwQkFBQTs7Ozs7O0FBRXBHLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLFFBQUEsR0FBQTtBQUF5RixJQUFBLG9CQUFBLEdBQUEsaUJBQUE7QUFBZSxJQUFBLDBCQUFBOzs7Ozs7QUFFeEcsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQXNGLElBQUEsb0JBQUEsR0FBQSxtQkFBQTtBQUFpQixJQUFBLDBCQUFBOzs7Ozs7QUFFdkcsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQThGLElBQUEsb0JBQUEsR0FBQSxtQkFBQTtBQUFpQixJQUFBLDBCQUFBOzs7Ozs7QUFzQm5HLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7OztBQUVBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7OztBQWtCUixJQUFBLDRCQUFBLEdBQUEsVUFBQSxHQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsc0ZBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGdCQUFBLFFBQUEsT0FBQSxDQUE0QjtJQUFBLENBQUE7QUFLekMsSUFBQSxvQkFBQSxDQUFBO0FBQ0osSUFBQSwwQkFBQTs7Ozs7QUFKUSxJQUFBLHdCQUFBLE9BQUEsY0FBQSxRQUFBLE9BQUEsSUFBQSxrR0FBQSw4R0FBQTtBQUdKLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxjQUFBLFFBQUEsT0FBQSxJQUFBLFdBQUEsVUFBQSxHQUFBOzs7Ozs7QUFsRXBCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFJdUssR0FBQSxPQUFBLEdBQUE7QUFJL0osSUFBQSxpQ0FBQSxHQUFBLDREQUFBLEdBQUEsQ0FBQSxFQUFvQixHQUFBLDREQUFBLEdBQUEsQ0FBQSxFQUdxQixHQUFBLDREQUFBLEdBQUEsQ0FBQSxFQUdzQixHQUFBLDREQUFBLEdBQUEsQ0FBQTtBQU9uRSxJQUFBLDBCQUFBO0FBR0EsSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUFnRSxHQUFBLE9BQUEsR0FBQSxFQUdaLEdBQUEsT0FBQSxFQUFBLEVBQ1AsR0FBQSxRQUFBLEdBQUE7QUFHN0IsSUFBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFPO0FBSVgsSUFBQSw0QkFBQSxJQUFBLE9BQUEsR0FBQSxFQUE2SCxJQUFBLFFBQUEsR0FBQTtBQUN6QyxJQUFBLG9CQUFBLEVBQUE7QUFBaUIsSUFBQSwwQkFBQTtBQUVqRyxJQUFBLDRCQUFBLElBQUEsVUFBQSxHQUFBO0FBQVEsSUFBQSx3QkFBQSxTQUFBLFNBQUEsd0VBQUE7QUFBQSxZQUFBLFVBQUEsMkJBQUEsSUFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxRQUFBLE9BQUEsQ0FBd0I7SUFBQSxDQUFBO0FBQ3JDLElBQUEsaUNBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsWUFBQSxHQUFBLEVBQXVDLElBQUEsNkRBQUEsR0FBQSxHQUFBLFlBQUEsR0FBQTtBQU92QyxJQUFBLDRCQUFBLElBQUEsT0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxFQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFNLEVBQ0QsRUFDUDtBQUlWLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUEsRUFBa0YsSUFBQSxPQUFBLEdBQUE7QUFFMUUsSUFBQSxvQkFBQSxFQUFBOztBQUE4QyxJQUFBLDRCQUFBLElBQUEsUUFBQSxHQUFBO0FBQW9DLElBQUEsb0JBQUEsSUFBQSxLQUFBO0FBQUcsSUFBQSwwQkFBQSxFQUFPO0FBR2hHLElBQUEsaUNBQUEsSUFBQSw2REFBQSxHQUFBLEdBQUEsVUFBQSxHQUFBO0FBU0osSUFBQSwwQkFBQSxFQUFNLEVBQ0o7Ozs7OztBQXJFTixJQUFBLHlCQUFBLHNCQUFBLE9BQUEsY0FBQSxRQUFBLE9BQUEsQ0FBQSxFQUF1RCxvQkFBQSxRQUFBLFFBQUEsRUFDaEIsbUJBQUEsQ0FBQSxRQUFBLFlBQUEsQ0FBQSxPQUFBLGNBQUEsUUFBQSxPQUFBLE1BQUEsT0FBQSxPQUFBLFVBQUEsR0FBQSxXQUFBLFVBQUEsS0FBQSxDQUFBLEVBQ21GLDRCQUFBLENBQUEsUUFBQSxZQUFBLENBQUEsT0FBQSxjQUFBLFFBQUEsT0FBQSxNQUFBLENBQUEsT0FBQSxPQUFBLFVBQUEsR0FBQSxhQUFBLE9BQUEsT0FBQSxVQUFBLEdBQUEsV0FBQSxXQUFBLEVBQUE7QUFLdEgsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxRQUFBLFdBQUEsSUFBQSxPQUFBLGNBQUEsUUFBQSxPQUFBLElBQUEsS0FBQSxPQUFBLE9BQUEsVUFBQSxHQUFBLFdBQUEsVUFBQSxLQUFBLElBQUEsSUFBQSxDQUFBO0FBdUJZLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsYUFBQSxZQUFBLEdBQUE7QUFNNEUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLE9BQUE7QUFHNUUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGNBQUEsTUFBQSxRQUFBLFVBQUEsS0FBQSxFQUFBO0FBUUksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsY0FBQSxNQUFBLFFBQUEsVUFBQSxZQUFBLGdCQUFBLEdBQUE7QUFTUixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEseUJBQUEsSUFBQSxJQUFBLFFBQUEsU0FBQSxLQUFBLE9BQUEsR0FBQSxHQUFBO0FBR0osSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLE9BQUEsY0FBQSxJQUFBLEtBQUEsRUFBQTs7Ozs7QUFjUixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQXVELElBQUEsb0JBQUEsR0FBQSw2QkFBQTtBQUEyQixJQUFBLDBCQUFBOzs7OztBQUVsRixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQTRELElBQUEsb0JBQUEsR0FBQSwrQkFBQTtBQUE2QixJQUFBLDBCQUFBOzs7OztBQTlFN0YsSUFBQSw4QkFBQSxHQUFBLDhDQUFBLElBQUEsSUFBQSxPQUFBLEtBQUEsbUNBQUE7QUEyRUEsSUFBQSxpQ0FBQSxHQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUEsRUFBMkIsR0FBQSxzREFBQSxHQUFBLEdBQUEsT0FBQSxHQUFBOzs7O0FBM0UzQixJQUFBLHdCQUFBLE9BQUEsZ0JBQUEsQ0FBaUI7QUEyRWpCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsQ0FBQSxPQUFBLE9BQUEsVUFBQSxJQUFBLElBQUEsT0FBQSxnQkFBQSxFQUFBLFdBQUEsTUFBQSxPQUFBLE9BQUEsVUFBQSxHQUFBLFNBQUEsVUFBQSxLQUFBLElBQUEsSUFBQSxFQUFBOzs7Ozs7QUFTUixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBQTBFLEdBQUEsVUFBQSxHQUFBO0FBQ2xFLElBQUEsd0JBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGtCQUFrQixxQkFBcUIsQ0FBQztJQUFBLENBQUE7O0FBQ3JELElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDQSxJQUFBLG9CQUFBLEdBQUEsc0JBQUE7QUFDSixJQUFBLDBCQUFBLEVBQVM7Ozs7OztBQXNCRCxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUFFQSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxFQUFBOzs7Ozs7QUEyQkksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7Ozs7O0FBRUEsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7Ozs7QUFTUSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQXdDLElBQUEsb0JBQUEsQ0FBQTtBQUFXLElBQUEsMEJBQUE7QUFDbkQsSUFBQSw0QkFBQSxHQUFBLFFBQUEsR0FBQTtBQUE0QyxJQUFBLG9CQUFBLENBQUE7QUFBMEIsSUFBQSwwQkFBQTs7QUFDdEUsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7OztBQUZ3QyxJQUFBLHVCQUFBO0FBQUEsSUFBQSwrQkFBQSxHQUFBO0FBQ0ksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLFdBQUEsYUFBQSxHQUFBOzs7OztBQUc1QyxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQTBDLElBQUEsb0JBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSwwQkFBQTtBQUNuRCxJQUFBLDRCQUFBLEdBQUEsUUFBQSxHQUFBO0FBQTRDLElBQUEsb0JBQUEsQ0FBQTtBQUEwQixJQUFBLDBCQUFBOztBQUN0RSxJQUFBLHVCQUFBLEdBQUEsT0FBQSxHQUFBOzs7O0FBRDRDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxXQUFBLGFBQUEsR0FBQTs7Ozs7O0FBVHBELElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSx1RUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsYUFBQSwyQkFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGVBQUEsV0FBQSxXQUFBLENBQWtDO0lBQUEsQ0FBQTtBQUcvQyxJQUFBLGlDQUFBLEdBQUEsNERBQUEsR0FBQSxDQUFBLEVBQThDLEdBQUEsNERBQUEsR0FBQSxDQUFBO0FBU2xELElBQUEsMEJBQUE7Ozs7OztBQVRJLElBQUEsdUJBQUE7QUFBQSxJQUFBLDRCQUFBLFdBQUEsT0FBQSxTQUFBLFdBQUEsV0FBQSxLQUFBLElBQUEsR0FBQSxRQUFBOzs7OztBQVdKLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBOzs7OztBQURJLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxlQUFBLFdBQUEsV0FBQSxHQUFBLEdBQUE7Ozs7OztBQVlRLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBUSxJQUFBLHdCQUFBLFNBQUEsU0FBQSx3RUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsYUFBQSwyQkFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsV0FBQSxXQUFBLENBQStCO0lBQUEsQ0FBQTs7QUFHNUMsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUE7Ozs7OztBQU9ELElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7O0FBMUQzQixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBLEVBSTBELEdBQUEsT0FBQSxFQUFBLEVBRWpCLEdBQUEsT0FBQSxHQUFBO0FBTTdCLElBQUEsaUNBQUEsR0FBQSw4Q0FBQSxHQUFBLEdBQUEsWUFBQSxHQUFBLEVBQXFCLEdBQUEsOENBQUEsR0FBQSxHQUFBLFlBQUEsR0FBQTtBQUt6QixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLEtBQUE7QUFDSSxJQUFBLGlDQUFBLEdBQUEsOENBQUEsR0FBQSxHQUFBLFVBQUEsR0FBQSxFQUE4QixHQUFBLDhDQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFvQjlCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBcUMsR0FBQSxLQUFBLEVBQzVCLElBQUEsT0FBQSxFQUFBLEVBQ2dDLElBQUEsT0FBQSxHQUFBO0FBRXpCLElBQUEsb0JBQUEsRUFBQTtBQUNKLElBQUEsMEJBQUE7QUFFQSxJQUFBLGlDQUFBLElBQUEsK0NBQUEsR0FBQSxHQUFBLFVBQUEsR0FBQTtBQU9KLElBQUEsMEJBQUEsRUFBTSxFQUNKLEVBQ0osRUFDSjtBQUVWLElBQUEsaUNBQUEsSUFBQSwrQ0FBQSxHQUFBLEdBQUEsWUFBQSxHQUFBO0FBQ0osSUFBQSwwQkFBQTs7Ozs7QUExRFEsSUFBQSx5QkFBQSxxQkFBQSxXQUFBLE1BQUEsRUFBeUMseUJBQUEsV0FBQSxNQUFBLEVBQ0ksZUFBQSxDQUFBLFdBQUEsTUFBQSxFQUNULDRCQUFBLENBQUEsV0FBQSxNQUFBO0FBSzVCLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEscUJBQUEsV0FBQSxNQUFBLEVBQXlDLG9CQUFBLFdBQUEsTUFBQSxFQUNELGlCQUFBLENBQUEsV0FBQSxNQUFBLEVBQ0YseUJBQUEsQ0FBQSxXQUFBLE1BQUE7QUFFMUMsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsV0FBQSxTQUFBLElBQUEsQ0FBQTtBQU9BLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxPQUFBLGNBQUEsSUFBQSxJQUFBLENBQUE7QUF1QjZDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsb0JBQUEsV0FBQSxNQUFBLEVBQXdDLHlCQUFBLENBQUEsV0FBQSxNQUFBO0FBQ3JFLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsV0FBQSxTQUFBLFdBQUEsY0FBQSxHQUFBO0FBR0osSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxPQUFBLGNBQUEsS0FBQSxDQUFBLFdBQUEsU0FBQSxLQUFBLEVBQUE7QUFZcEIsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsQ0FBQSxXQUFBLFNBQUEsS0FBQSxFQUFBOzs7OztBQUc4QixJQUFBLDRCQUFBLEdBQUEsT0FBQSxHQUFBO0FBQTJELElBQUEsb0JBQUEsR0FBQSxvQkFBQTtBQUFrQixJQUFBLDBCQUFBOzs7Ozs7QUFLdkcsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFvRSxHQUFBLFVBQUEsR0FBQTtBQUN4RCxJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxrQkFBa0IsU0FBUyxDQUFDO0lBQUEsQ0FBQTs7QUFDekMsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsR0FBQSxzQkFBQTtBQUNKLElBQUEsMEJBQUEsRUFBUzs7Ozs7O0FBd0JPLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7OztBQUVBLElBQUEsdUJBQUEsR0FBQSxPQUFBLEdBQUE7Ozs7OztBQU1KLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7QUFBdUMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsNkZBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxpQkFBQSxDQUFrQjtJQUFBLENBQUE7QUFDOUQsSUFBQSxvQkFBQSxHQUFBLGFBQUE7O0FBQVUsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNkLElBQUEsMEJBQUE7Ozs7OztBQWJSLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBMkYsR0FBQSxVQUFBLEdBQUE7QUFDdkQsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxRQUFBLENBQVM7SUFBQSxDQUFBO0FBQzlDLElBQUEsaUNBQUEsR0FBQSxvRUFBQSxHQUFBLEdBQUEsWUFBQSxHQUFBLEVBQWdCLEdBQUEsb0VBQUEsR0FBQSxHQUFBLFlBQUEsR0FBQTtBQUtoQixJQUFBLG9CQUFBLENBQUE7QUFDSixJQUFBLDBCQUFBO0FBRUEsSUFBQSxpQ0FBQSxHQUFBLG9FQUFBLEdBQUEsR0FBQSxVQUFBLEdBQUE7QUFLSixJQUFBLDBCQUFBOzs7O0FBZndCLElBQUEseUJBQUEsZUFBQSxDQUFBLE9BQUEsVUFBQSxFQUFpQyxlQUFBLE9BQUEsVUFBQTtBQUVqRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsT0FBQSxJQUFBLElBQUEsQ0FBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLE9BQUEsSUFBQSxXQUFBLFlBQUEsR0FBQTtBQUdKLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLENBQUEsT0FBQSxhQUFBLElBQUEsRUFBQTs7Ozs7QUF4QlosSUFBQSw0QkFBQSxHQUFBLE9BQUEsR0FBQSxFQUFnRyxHQUFBLE9BQUEsR0FBQSxFQUNsRCxHQUFBLE9BQUEsR0FBQTs7QUFFbEMsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLElBQUEsMEJBQUE7O0FBQ0EsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBSyxHQUFBLE1BQUEsR0FBQTtBQUM2QyxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBa0IsSUFBQSwwQkFBQTtBQUNoRSxJQUFBLDRCQUFBLEdBQUEsS0FBQSxHQUFBO0FBQ0ksSUFBQSxvQkFBQSxDQUFBO0FBQ0osSUFBQSwwQkFBQSxFQUFJLEVBQ0Y7QUFHVixJQUFBLGlDQUFBLEdBQUEsc0RBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQTtBQWtCSixJQUFBLDBCQUFBOzs7O0FBdkJnQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxPQUFBLGNBQUEsSUFBQSx1QkFBQSxrQ0FBQSxHQUFBO0FBS1osSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxPQUFBLGNBQUEsSUFBQSxJQUFBLEVBQUE7Ozs7OztBQXFCQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxHQUFBO0FBQXNDLElBQUEsd0JBQUEsU0FBQSxTQUFBLCtFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsU0FBQSxDQUFVO0lBQUEsQ0FBQTs7QUFDckQsSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTtBQUNBLElBQUEsb0JBQUEsQ0FBQTtBQUNKLElBQUEsMEJBQUE7Ozs7QUFESSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLDJCQUFBLE9BQUEsT0FBQSxZQUFBLEdBQUEsS0FBQSxPQUFBLE9BQUEsZ0JBQUEsR0FBQSxJQUFBOzs7OztBQUVFLElBQUEsNEJBQUEsR0FBQSxLQUFBLEdBQUE7QUFBcUQsSUFBQSxvQkFBQSxHQUFBLG9DQUFBO0FBQWtDLElBQUEsMEJBQUE7Ozs7O0FBTGpHLElBQUEsaUNBQUEsR0FBQSxzREFBQSxHQUFBLEdBQUEsVUFBQSxHQUFBLEVBQThCLEdBQUEsc0RBQUEsR0FBQSxHQUFBLEtBQUEsR0FBQTs7OztBQUE5QixJQUFBLDJCQUFBLE9BQUEsT0FBQSxjQUFBLElBQUEsSUFBQSxDQUFBOzs7OztBQU9BLElBQUEsNEJBQUEsR0FBQSxVQUFBLEdBQUE7O0FBQ0ksSUFBQSx1QkFBQSxHQUFBLE9BQUEsR0FBQTs7QUFDQSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTtBQUFvRixJQUFBLDBCQUFBLEVBQU87Ozs7QUFBM0YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSw0QkFBQSxPQUFBLE9BQUEsWUFBQSxHQUFBLE9BQUEsT0FBQSxPQUFBLGdCQUFBLEdBQUEsR0FBQTs7Ozs7O0FBT0YsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUFtQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSwrRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGVBQUEsSUFBbUIsSUFBSSxDQUFDO0lBQUEsQ0FBQTtBQUFvRyxJQUFBLG9CQUFBLEdBQUEsNENBQUE7QUFBMEMsSUFBQSwwQkFBQTs7Ozs7O0FBRWxOLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBK0QsR0FBQSxTQUFBLEdBQUE7QUFDcEMsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLG9GQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxlQUFBLE1BQUEsTUFBQSxPQUFBLGdCQUFBO0FBQUEsYUFBQSx5QkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUF2QixJQUFBLDBCQUFBO0FBQXVCLElBQUEsNkJBQUE7QUFDdkIsSUFBQSw0QkFBQSxHQUFBLFVBQUEsR0FBQTtBQUFRLElBQUEsd0JBQUEsU0FBQSxTQUFBLCtFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsVUFBQSxDQUFXO0lBQUEsQ0FBQTtBQUEwSixJQUFBLG9CQUFBLEdBQUEsT0FBQTtBQUFLLElBQUEsMEJBQUEsRUFBUzs7OztBQUQ3SyxJQUFBLHVCQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsYUFBQTtBQUFBLElBQUEsdUJBQUE7Ozs7O0FBUG5DLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUEsRUFBNkIsR0FBQSxLQUFBLEdBQUE7QUFDaUMsSUFBQSxvQkFBQSxHQUFBLDBCQUFBO0FBQXdCLElBQUEsMEJBQUE7QUFDbEYsSUFBQSw0QkFBQSxHQUFBLEtBQUEsR0FBQTtBQUE4QyxJQUFBLG9CQUFBLENBQUE7QUFBa0csSUFBQSwwQkFBQTtBQUNoSixJQUFBLGlDQUFBLEdBQUEsc0RBQUEsR0FBQSxHQUFBLFVBQUEsR0FBQSxFQUF5QixHQUFBLHNEQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFRN0IsSUFBQSwwQkFBQTs7OztBQVRrRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLElBQUEsT0FBQSxLQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsZ0JBQUEsS0FBQSxPQUFBLE9BQUEsWUFBQSxLQUFBLEVBQUEsR0FBQSwyQkFBQTtBQUM5QyxJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsZUFBQSxJQUFBLElBQUEsQ0FBQTs7O0FEaG1EbEIsSUFBTyxnQkFBUCxNQUFPLGVBQTBDO0VBdUdyRCxZQUNVLE9BQ0QsUUFDQyxRQUNBLGNBQ0QsV0FDc0IsWUFDckIsWUFDQSxrQkFDUSxlQUE0QjtBQVJwQztBQUNEO0FBQ0M7QUFDQTtBQUNEO0FBQ3NCO0FBQ3JCO0FBQ0E7QUFDUTtBQUVoQixXQUFPLE1BQUs7QUFDVixZQUFNLFNBQVMsS0FBSyxPQUFPLE9BQU07QUFDakMsWUFBTSxrQkFBa0IsS0FBSyxNQUFNLFNBQVM7QUFFNUMsVUFBSSxXQUFXLGVBQWUsaUJBQWlCO0FBQzdDLGFBQUssT0FBTyxTQUFTLENBQUEsR0FBSTtVQUN2QixZQUFZLEtBQUs7VUFDakIsVUFBVTtVQUNWLFlBQVk7U0FDYjtNQUNIO0lBQ0YsQ0FBQztBQUVELFdBQU8sTUFBSztBQUNWLFVBQUksQ0FBQyxrQkFBa0IsS0FBSyxVQUFVO0FBQUc7QUFDekMsWUFBTSxRQUFRLEtBQUssT0FBTyxVQUFTO0FBRW5DLFVBQ0UsS0FBSyxPQUFPLFlBQVcsS0FDdkIsS0FBSyxPQUFPLGFBQVksS0FDeEIsS0FBSyxPQUFPLGdCQUFlLEtBQzNCLEtBQUssT0FBTyxXQUFVLEdBQ3RCO0FBQ0E7TUFDRjtBQUVBLFVBQUksT0FBTztBQUNULFlBQUksTUFBTTtBQUFXLGVBQUssV0FBVyxNQUFNLFNBQVM7TUFDdEQ7QUFFQSxVQUFJLEtBQUssT0FBTyxTQUFRLEdBQUk7QUFDMUIsWUFBSSxDQUFDLEtBQUssWUFBWTtBQUNwQixlQUFLLGlCQUFnQjtRQUN2QjtNQUNGO0lBQ0YsQ0FBQztBQUVELFdBQU8sTUFBSztBQUNWLFVBQUksS0FBSyxPQUFPLGNBQWEsR0FBSTtBQUMvQixjQUFNLElBQUksS0FBSyxPQUFPLFFBQU87QUFDN0IsYUFBSyxPQUFPLHlCQUF3QjtNQUN0QztJQUNGLENBQUM7QUFFRCxXQUFPLE1BQUs7QUFDVixZQUFNLFFBQVEsS0FBSyxPQUFPLFVBQVM7QUFDbkMsWUFBTSxVQUFVLEtBQUssT0FBTyxRQUFPO0FBRW5DLFlBQU0sY0FBYyxRQUFRLE9BQU8sQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFO0FBQ3BELFlBQU0sWUFBWSxLQUFLO0FBQ3ZCLFlBQU0sWUFBWSxLQUFLLElBQUksR0FBRyxZQUFZLFdBQVc7QUFFckQsWUFBTSxTQUFTLEtBQUssY0FBYyxPQUFNO0FBQ3hDLFlBQU0sWUFBWSxPQUFPLGFBQWEsT0FBTyxlQUFlO0FBRTVELFVBQUksS0FBSyxTQUFRLEdBQUk7QUFDbkIsYUFBSyxhQUFhLFNBQVMsK0JBQTBCLFNBQVMsRUFBRTtNQUNsRSxXQUFXLGVBQWUsV0FBVztBQUNuQyxhQUFLLGFBQWEsU0FBUyxpQ0FBMEIsU0FBUyxFQUFFO01BQ2xFLFdBQVcsT0FBTyxVQUFVO0FBQzFCLGFBQUssYUFBYSxTQUFTLDJCQUFvQixTQUFTLEVBQUU7TUFDNUQsT0FBTztBQUNMLGFBQUssYUFBYSxTQUFTLGFBQU0sU0FBUyxhQUFhLFNBQVMsRUFBRTtNQUNwRTtJQUNGLENBQUM7QUFHRCxXQUFPLE1BQUs7QUFDVixZQUFNLGtCQUFrQixLQUFLLE9BQU8sZUFBYztBQUVsRCxVQUFJLEtBQUssT0FBTyxPQUFNLE1BQU8sYUFBYTtBQUN4QyxjQUFNLFNBQVMsZ0JBQWdCLE9BQzdCLENBQUMsT0FBTyxDQUFDLEtBQUssaUJBQWlCLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUU5RCxjQUFNLE9BQU8sS0FBSyxpQkFBaUIsT0FDakMsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUl4RCxjQUFNLGNBQWMsZ0JBQWdCLE9BQU8sQ0FBQyxPQUFNO0FBQ2hELGdCQUFNLE9BQU8sS0FBSyxpQkFBaUIsS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLEdBQUcsRUFBRTtBQUMvRCxpQkFBTyxRQUFRLEtBQUssZ0JBQWdCLEdBQUc7UUFDekMsQ0FBQztBQUVELGVBQU8sUUFBUSxDQUFDLE1BQ2QsS0FBSyxXQUFXLHdCQUF3QixVQUFVLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxXQUFXLENBQUM7QUFFaEYsYUFBSyxRQUFRLENBQUMsTUFDWixLQUFLLFdBQVcsd0JBQXdCLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLFdBQVcsQ0FBQztBQUc5RSxvQkFBWSxRQUFRLENBQUMsTUFBSztBQUV4QixjQUFJLEVBQUUsT0FBTyxLQUFLLE9BQU8saUJBQWdCLEdBQUk7QUFDM0MsaUJBQUssV0FBVyx3QkFDZCxlQUNBLEVBQUUsZUFBZSxhQUNqQixRQUNBLEVBQUUsRUFBRTtVQUVSO1FBQ0YsQ0FBQztNQUNIO0FBRUEsV0FBSyxtQkFBbUI7SUFDMUIsQ0FBQztBQUdELFNBQUssT0FBTywwQkFBMEIsVUFBVSxDQUFDLFNBQVE7QUFDdkQsWUFBTSxXQUFXLEtBQUssT0FBTyxlQUFjO0FBQzNDLFlBQU0sa0JBQWtCLFNBQVMsS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEtBQUssU0FBUztBQUNwRSxZQUFNLFFBQVEsS0FBSyxPQUFPLFVBQVMsR0FBSSxlQUFlLEtBQUssV0FBVztBQUV0RSxXQUFLLFdBQVcsc0JBQ2QsS0FBSyxhQUNMLE9BQ0EsS0FBSyxXQUNMLGlCQUFpQixXQUFXO0lBRWhDLENBQUM7QUFFRCxTQUFLLE9BQU8sZUFBZSxVQUFVLENBQUMsVUFBUztBQUM3QyxZQUFNLFdBQVcsTUFBTSxTQUFTLElBQUksU0FBUztBQUM3QyxXQUFLLFdBQVcsa0JBQ2QsTUFBTSxNQUNOLFVBQ0EsNkJBQTZCLE1BQU0sS0FBSyxJQUFJO0lBRWhELENBQUM7RUFDSDtFQTNJVTtFQUNEO0VBQ0M7RUFDQTtFQUNEO0VBQ3NCO0VBQ3JCO0VBQ0E7RUFDUTtFQTlHbEIsbUJBQW1CLFFBQVc7QUFDNUIsUUFBSSxLQUFLLE9BQU8sT0FBTSxNQUFPLGVBQWUsQ0FBQyxLQUFLLFNBQVEsS0FBTSxDQUFDLEtBQUssT0FBTyxTQUFRLEdBQUk7QUFDdkYsYUFBTyxjQUFjO0lBQ3ZCO0VBQ0Y7RUFHQSxpQkFBYztBQUNaLFNBQUssT0FBTyxXQUFVO0VBQ3hCOztFQUdTLE9BQU87RUFFVCxTQUFTO0lBQXNCOzs7Ozs7RUFDL0IsV0FBVztJQUE2Qjs7Ozs7O0VBQ3hDLGNBQWM7SUFBTzs7Ozs7O0VBQ3JCLGtCQUFrQjtJQUFPOzs7Ozs7RUFDekIsY0FBYztJQUFPOzs7Ozs7RUFFckIsY0FBYztJQUFPOzs7Ozs7RUFDckIsb0JBQW9CO0lBQU87Ozs7OztFQUMzQixlQUFlO0lBQU87Ozs7OztFQUN0QixpQkFBaUI7SUFBTzs7Ozs7O0VBQ3hCLGtCQUFrQjtJQUFPOzs7Ozs7RUFDekIsaUJBQWlCO0lBQU87Ozs7OztFQUN4QixlQUFlO0lBQU87Ozs7OztFQUN0QixnQkFBZ0I7SUFBTzs7Ozs7O0VBQ3ZCLHNCQUFzQjtJQUFPOzs7Ozs7RUFDN0Isa0JBQWtCO0lBQXNCOzs7Ozs7RUFDeEMsZUFBZTtJQUFPOzs7Ozs7RUFDdEIsWUFBWTtJQUFzQjs7Ozs7O0VBQ2xDLGdCQUFnQjtJQUFPOzs7Ozs7RUFFdkIsZ0JBQWdCO0lBQU87Ozs7OztFQUN2QixZQUFZO0lBQU87Ozs7OztFQUNuQixZQUFZO0lBQU87Ozs7OztFQUNsQjtFQUVELG1CQUFtQjtJQUFPOzs7Ozs7RUFDMUIsb0JBQW9CO0lBQU87Ozs7OztFQUUzQixpQkFBaUI7SUFBUyxNQUFLO0FBQ3BDLFlBQU0sU0FBUyxLQUFLLE9BQU8sVUFBUyxHQUFJLGNBQWMsQ0FBQTtBQUN0RCxZQUFNLFFBQVEsS0FBSyxpQkFBZ0IsRUFBRyxZQUFXLEVBQUcsS0FBSTtBQUN4RCxVQUFJLENBQUM7QUFBTyxlQUFPO0FBQ25CLGFBQU8sT0FBTyxPQUFPLENBQUMsVUFBVSxNQUFNLFFBQVEsWUFBVyxFQUFHLFNBQVMsS0FBSyxDQUFDO0lBQzdFOzs7Ozs7RUFFTyxrQkFBa0I7SUFBUyxNQUFLO0FBQ3JDLFlBQU0sVUFBVSxLQUFLLE9BQU8sVUFBUyxHQUFJLFdBQVcsQ0FBQTtBQUNwRCxZQUFNLFFBQVEsS0FBSyxrQkFBaUIsRUFBRyxZQUFXLEVBQUcsS0FBSTtBQUN6RCxVQUFJLENBQUM7QUFBTyxlQUFPO0FBQ25CLGFBQU8sUUFBUSxPQUFPLENBQUMsV0FBVyxPQUFPLFFBQVEsWUFBVyxFQUFHLFNBQVMsS0FBSyxDQUFDO0lBQ2hGOzs7Ozs7RUFFTyxpQkFBaUI7SUFBTzs7Ozs7O0VBQ3hCLGlCQUFpQjtJQUFPOzs7Ozs7RUFFeEIsbUJBQW1CO0lBQU87Ozs7OztFQUMxQixjQUFjO0lBQU87TUFDMUIsT0FBTztNQUNQLFNBQVM7TUFDVCxRQUFRLE1BQUs7TUFBRTtNQUNmLGVBQWU7TUFDZixNQUFNOzs7Ozs7O0VBR0QsV0FBVztJQUFTLE1BQU0sS0FBSyxPQUFPLFVBQVMsR0FBSSxjQUFjOzs7Ozs7RUFDakUsU0FBUztJQUFPOzs7Ozs7RUFDaEIsaUJBQWlCO0lBQU87Ozs7OztFQUN4QixtQkFBbUI7SUFBTzs7Ozs7O0VBQzFCLGlCQUFpQjtJQUFPOzs7Ozs7RUFDeEIsWUFBWTtJQUFPOzs7Ozs7RUFDbkIsY0FBYztJQUFPOzs7Ozs7RUFDckIsZUFBZTtJQUFPOzs7Ozs7RUFFdEIsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFFWCxtQkFBeUUsQ0FBQTtFQUUxRSxxQkFBcUI7SUFBc0I7Ozs7OztFQUMzQyxlQUFlO0lBQU87Ozs7OztFQUN0QixhQUFhO0lBQU87Ozs7OztFQUVuQixzQkFBc0I7RUFDdkIsZUFBZTtFQUVmLGNBQWtDO0VBQ3pDLG1CQUFtQjtJQUFnQjs7Ozs7O0VBQ25DLG9CQUFvQjtJQUFnQjs7Ozs7O0VBQ3BDLHFCQUFxQjtJQUFnQjs7Ozs7O0VBQ3JDLG1CQUFtQjtJQUFnQjs7Ozs7O0VBQ25DLGdCQUFnQjtJQUFzQjs7Ozs7O0VBQ3RDLGVBQWU7SUFBc0I7Ozs7OztFQUNyQyx1QkFBaUMsQ0FBQTtFQUNqQyxvQkFBb0I7SUFBZTs7Ozs7O0VBQ25DO0VBQ0EsZ0JBQWdCO0lBQWU7Ozs7OztFQWdKL0IsV0FBUTtBQUNOLFFBQUksa0JBQWtCLEtBQUssVUFBVSxHQUFHO0FBQ3RDLFdBQUssTUFBTSxTQUFTLFVBQVUsQ0FBTyxXQUFVO0FBQzdDLGNBQU0sS0FBSyxPQUFPLElBQUksSUFBSTtBQUMxQixjQUFNLGNBQWMsS0FBSyxNQUFNLFNBQVM7QUFDeEMsY0FBTSxZQUFZLEtBQUssTUFBTSxTQUFTLGNBQWMsSUFBSSxNQUFNO0FBRTlELFlBQUksV0FBVztBQUNiLGVBQUssZUFBZSxtQkFBbUIsU0FBUztBQUVoRCxlQUFLLFdBQVcsZ0JBQWdCLEtBQUssWUFBWTtRQUNuRCxXQUFXLE9BQU8sV0FBVyxhQUFhO0FBQ3hDLGVBQUssZUFBZSxPQUFPLFNBQVM7UUFDdEM7QUFFQSxZQUFJLENBQUM7QUFBSTtBQUNULGFBQUssT0FBTyxJQUFJLEVBQUU7QUFFbEIsY0FBTSxxQkFBcUIsS0FBSyxPQUFPLE9BQU0sTUFBTztBQUNwRCxjQUFNLGdCQUFnQixLQUFLLE9BQU8sSUFBSSxNQUFNLFNBQVEsR0FBSSxXQUFXO0FBR25FLFlBQUksc0JBQXNCLGVBQWU7QUFDdkM7UUFDRjtBQUVBLFlBQUksYUFBYTtBQUNmLGVBQUssT0FBTyxXQUFXLFdBQVc7QUFFbEMsZ0JBQU0sS0FBSyxPQUFPLFFBQVEsSUFBSSxXQUFXO1FBQzNDLE9BQU87QUFDTCxlQUFLLE9BQU8sZ0JBQWdCLElBQUksd0JBQXdCO1FBQzFEO01BQ0YsRUFBQztJQUNIO0VBQ0Y7RUFFQSxjQUFXO0FBQ1QsUUFBSSxrQkFBa0IsS0FBSyxVQUFVLEdBQUc7QUFDdEMsV0FBSyxPQUFPLFdBQVU7QUFDdEIsV0FBSyxPQUFPLE1BQUs7QUFFakIsVUFBSSxLQUFLO0FBQWUsc0JBQWMsS0FBSyxhQUFhO0lBQzFEO0VBQ0Y7RUFFQSxJQUFJLHFCQUE0QjtBQUM5QixVQUFNLE9BQU8sS0FBSyxPQUFPLFVBQVMsR0FBSTtBQUN0QyxXQUFPLE9BQU8sS0FBSyxPQUFPLGFBQWEsSUFBSSxJQUFJO0VBQ2pEO0VBRUEsSUFBSSxjQUFzQjtBQUN4QixVQUFNLFFBQVEsS0FBSyxPQUFPLFVBQVM7QUFDbkMsUUFBSSxDQUFDO0FBQU8sYUFBTztBQUNuQixVQUFNLGNBQWMsTUFBTSxXQUFXO0FBQ3JDLFVBQU0sWUFBWSxLQUFLO0FBQ3ZCLFdBQU8sWUFBWSxLQUFLLGVBQWU7RUFDekM7RUFFQSxJQUFJLGFBQXFCO0FBQ3ZCLFdBQU8sS0FBSyxXQUFXO0VBQ3pCO0VBRUEsY0FBYyxTQUF5QjtBQUNyQyxXQUFPLEtBQUssT0FBTyxVQUFTLEdBQUksV0FBVyxTQUFTLE9BQU8sS0FBSztFQUNsRTtFQUVBLGVBQWUsYUFBNEI7QUFDekMsVUFBTSxTQUFTLEtBQUssT0FBTyxVQUFTLEdBQUksZ0JBQWdCLENBQUE7QUFDeEQsVUFBTSxPQUFPLE9BQU8sV0FBVztBQUMvQixXQUFPLE9BQU8sR0FBRyxJQUFJLEtBQUssV0FBVyxNQUFNO0VBQzdDO0VBRUEsU0FBUyxhQUF3QztBQUMvQyxXQUFPLEtBQUssT0FBTyxVQUFTLEdBQUksZUFBZSxXQUFXO0VBQzVEO0VBRUEsUUFBUSxhQUE2QjtBQUNuQyxXQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sY0FBYyxXQUFXO0VBQ2hEO0VBRU0sZUFBZSxPQUFVOztBQUM3QixZQUFNLE9BQU8sTUFBTSxPQUFPLE1BQU0sQ0FBQztBQUNqQyxVQUFJLENBQUM7QUFBTTtBQUVYLFlBQU0sa0JBQWtCLENBQUMsU0FBUyxRQUFRLFFBQVEsU0FBUztBQUMzRCxZQUFNLFdBQVcsS0FBSyxLQUFLLFlBQVc7QUFDdEMsVUFBSSxDQUFDLGdCQUFnQixLQUFLLENBQUMsUUFBUSxTQUFTLFNBQVMsR0FBRyxDQUFDLEdBQUc7QUFDMUQsYUFBSyxVQUFVLHFCQUFxQiw0Q0FBNEM7QUFDaEYsY0FBTSxPQUFPLFFBQVE7QUFDckI7TUFDRjtBQUVBLFVBQUksS0FBSyxPQUFPLElBQUksT0FBTyxNQUFNO0FBQy9CLGFBQUssVUFBVSxrQkFBa0IseURBQXlEO0FBQzFGLGNBQU0sT0FBTyxRQUFRO0FBQ3JCO01BQ0Y7QUFFQSxXQUFLLFlBQVksSUFBSSxJQUFJO0FBRXpCLFVBQUk7QUFDRixjQUFNLGNBQWMsTUFBTSxLQUFLLE9BQU8sSUFBSSxjQUFjLElBQUk7QUFDNUQsY0FBTSxLQUFLLE9BQU8sZ0JBQWdCLFdBQVc7QUFDN0MsYUFBSyxXQUFXLGlCQUFpQixRQUFRO0FBQ3pDLGNBQU0sT0FBTyxRQUFRO01BQ3ZCLFNBQVMsR0FBRztBQUNWLGdCQUFRLE1BQU0sQ0FBQztBQUNmLGFBQUssVUFBVSxjQUFjLHNCQUFzQjtNQUNyRDtBQUNFLGFBQUssWUFBWSxJQUFJLEtBQUs7TUFDNUI7SUFDRjs7RUFFQSxxQkFBa0I7QUFDaEIsU0FBSyxjQUFjLElBQUksSUFBSTtFQUM3QjtFQUVNLHNCQUFtQjs7QUFDdkIsV0FBSyxjQUFjLElBQUksS0FBSztBQUM1QixZQUFNLEtBQUssT0FBTyxVQUFVLG1CQUFtQix3QkFBd0I7QUFDdkUsV0FBSyxxQkFBb0I7SUFDM0I7O0VBRUEsdUJBQW9CO0FBQ2xCLFNBQUssT0FBTyxVQUFVLG1CQUFtQix3QkFBd0I7QUFDakUsVUFBTSxPQUFPLEtBQUssT0FBTyxVQUFTLEdBQUk7QUFDdEMsUUFBSSxDQUFDO0FBQU07QUFFWCxVQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsSUFBSSxHQUFHLEVBQUUsTUFBTSxhQUFZLENBQUU7QUFDcEQsVUFBTSxNQUFNLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtBQUMzQyxVQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7QUFDcEMsTUFBRSxPQUFPO0FBQ1QsTUFBRSxXQUFXLGVBQWUsS0FBSyxPQUFNLEdBQUksTUFBTSxHQUFHLENBQUMsQ0FBQztBQUN0RCxNQUFFLE1BQUs7QUFDUCxXQUFPLElBQUksZ0JBQWdCLEdBQUc7QUFFOUIsU0FBSyxXQUFXLHNCQUFzQixlQUFlO0VBQ3ZEO0VBRU0sWUFBUzs7QUFDYixVQUFJLEtBQUssZUFBZTtBQUN0QixjQUFNLGFBQWEsS0FBSyxjQUFjLEtBQUk7QUFHMUMsYUFBSyxPQUFPLGlCQUFpQixVQUFVO0FBRXZDLGNBQU0saUJBQWlCLE1BQU0sS0FBSyxpQkFBaUIsUUFDakQsWUFDQSxLQUFLLE9BQU8sV0FBVSxLQUFNLEVBQUU7QUFHaEMsdUJBQWUsUUFBUSxlQUFlLEtBQUssT0FBTSxDQUFFLElBQUksY0FBYztBQUVyRSxhQUFLLGVBQWUsSUFBSSxLQUFLO0FBQzdCLGFBQUssZ0JBQWdCO01BQ3ZCO0lBQ0Y7O0VBRUEsWUFBUztBQUNQLFNBQUssV0FBVyxjQUFjLG9CQUFvQjtBQUNsRCxTQUFLLFlBQ0gsY0FDQSxnSEFDQSxNQUFLO0FBQ0gsVUFBSSxDQUFDLEtBQUssWUFBWTtBQUNwQixhQUFLLGlCQUFnQjtNQUN2QjtBQUVBLFdBQUssV0FBVyxxQkFBcUIsUUFBUTtBQUM3QyxpQkFBVyxNQUFLO0FBQ2QsYUFBSyxPQUFPLFVBQVM7QUFFckIsWUFBSSxDQUFDLEtBQUssWUFBWTtBQUNwQixlQUFLLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQztRQUM1QjtNQUNGLEdBQUcsR0FBRztJQUNSLEdBQ0EsSUFBSTtFQUVSO0VBRUEsa0JBQWU7QUFDYixVQUFNLGtCQUFrQixLQUFLLE9BQU8sVUFBUyxHQUFJO0FBQ2pELFNBQUssWUFBWSxJQUFJLG1CQUFtQixFQUFFO0FBQzFDLFNBQUssZ0JBQWdCLElBQUksSUFBSTtBQUM3QixTQUFLLFdBQVcsY0FBYyxhQUFhO0VBQzdDO0VBRUEsbUJBQWdCO0FBQ2QsU0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0VBQ2hDO0VBRUEsZUFBWTtBQUNWLFFBQUksT0FBTyxLQUFLLFlBQVcsRUFBRyxLQUFJO0FBQ2xDLFVBQU0sYUFBYTtBQUVuQixRQUFJLEtBQUssU0FBUyxZQUFZO0FBQzVCLGFBQU8sS0FBSyxNQUFNLEdBQUcsVUFBVTtJQUNqQztBQUVBLFFBQUksQ0FBQyxNQUFNO0FBQ1Q7SUFDRjtBQUVBLFNBQUssT0FBTyxXQUFXLElBQUk7QUFDM0IsU0FBSyxXQUFXLGdCQUFnQixJQUFJO0FBQ3BDLFNBQUssaUJBQWdCO0VBQ3ZCO0VBRUEsYUFBVTtBQUNSLFVBQU0sVUFBVSxLQUFLLE9BQU8sVUFBUyxHQUFJO0FBQ3pDLFVBQU0sU0FBUyxVQUFVLFdBQVc7QUFDcEMsU0FBSyxXQUFXLGNBQWMsR0FBRyxNQUFNLGVBQWU7QUFDdEQsU0FBSyxZQUNILEdBQUcsTUFBTSxTQUNULDRCQUE0QixNQUFNLGVBQWUsVUFBVSxvQ0FBb0MsdUNBQXVDLElBQ3RJLE1BQUs7QUFDSCxXQUFLLE9BQU8sV0FBVyxDQUFDLE9BQU87QUFDL0IsV0FBSyxXQUFXLHFCQUFxQixDQUFDLFVBQVUsV0FBVyxVQUFVO0lBQ3ZFLEdBQ0EsQ0FBQyxPQUFPO0VBRVo7RUFFQSxlQUFlLGFBQW1CO0FBQ2hDLFVBQU0sVUFBVSxLQUFLLE9BQU8sVUFBUyxHQUFJLGVBQWUsV0FBVyxLQUFLO0FBQ3hFLFVBQU0sUUFBUSxLQUFLLE9BQU8sY0FBYyxXQUFXO0FBRW5ELFNBQUssbUJBQW1CLElBQUksV0FBVztBQUN2QyxTQUFLLGFBQWEsSUFBSSxXQUFXLFNBQVMsRUFBRTtBQUM1QyxTQUFLLFdBQVcsSUFBSSxJQUFJO0FBQ3hCLFNBQUssZUFBZSxJQUFJLElBQUk7RUFDOUI7RUFFQSxZQUFTO0FBQ1AsVUFBTSxLQUFLLEtBQUssbUJBQWtCO0FBQ2xDLFVBQU0sUUFBUSxLQUFLLGFBQVksRUFBRyxLQUFJO0FBRXRDLFFBQUksSUFBSTtBQUNOLFdBQUssT0FBTyxrQkFBa0IsSUFBSSxLQUFLO0FBRXZDLFVBQUksS0FBSyxXQUFVLEtBQU0sT0FBTztBQUM5QixhQUFLLE9BQU8sa0JBQWtCLElBQUksS0FBSztNQUN6QyxPQUFPO0FBQ0wsYUFBSyxPQUFPLHNCQUFzQixFQUFFO01BQ3RDO0FBRUEsV0FBSyxXQUFXLHdCQUF3QixVQUFVLE9BQU8sRUFBRTtJQUM3RDtBQUNBLFNBQUssZ0JBQWU7RUFDdEI7RUFFQSxrQkFBZTtBQUNiLFNBQUssZUFBZSxJQUFJLEtBQUs7QUFDN0IsU0FBSyxtQkFBbUIsSUFBSSxJQUFJO0FBQ2hDLFNBQUssYUFBYSxJQUFJLEVBQUU7RUFDMUI7RUFFQSxnQkFBZ0IsU0FBZTtBQUM3QixVQUFNLFlBQVksS0FBSyxjQUFjLE9BQU87QUFDNUMsU0FBSyxZQUNILG9CQUNBLEdBQUcsWUFBWSxXQUFXLEtBQUssMEJBQTBCLFlBQVksU0FBUyxJQUFJOztFQUFzQixPQUFPLElBQy9HLE1BQUs7QUFDSCxXQUFLLE9BQU8sZ0JBQWdCLENBQUMsT0FBTyxHQUFHLFNBQVM7QUFDaEQsV0FBSyxXQUFXLHdCQUF3QixLQUFLLFNBQVEsR0FBSSxTQUFTLENBQUMsU0FBUztJQUM5RSxHQUNBLEtBQUs7RUFFVDtFQUVBLFlBQVksU0FBc0I7QUFDaEMsUUFBSSxDQUFDO0FBQVM7QUFFZCxjQUFVLFVBQ1AsVUFBVSxPQUFPLEVBQ2pCLEtBQUssTUFBSztBQUNULFdBQUssY0FBYyxJQUFJLE9BQU87QUFFOUIsWUFBTSxlQUFlLEdBQUcsUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sUUFBUSxNQUFNLEVBQUUsQ0FBQztBQUVsRSxXQUFLLE9BQU8sVUFBVSxrQkFBa0IsR0FBRyxZQUFZLEVBQUU7QUFFekQsV0FBSyxXQUFXLGtCQUFrQixPQUFPO0FBRXpDLGlCQUFXLE1BQUs7QUFDZCxZQUFJLEtBQUssY0FBYSxNQUFPLFNBQVM7QUFDcEMsZUFBSyxjQUFjLElBQUksSUFBSTtRQUM3QjtNQUNGLEdBQUcsR0FBSTtJQUNULENBQUMsRUFDQSxNQUFNLENBQUMsUUFBTztBQUNiLGNBQVEsTUFBTSw0QkFBNEIsR0FBRztJQUMvQyxDQUFDO0VBQ0w7RUFFQSxvQkFBaUI7QUFDZixRQUFJLE9BQU8saUJBQWlCLGFBQWE7QUFDdkMsWUFBTSxZQUFZLGFBQWEsUUFBUSxnQkFBZ0IsS0FBSyxPQUFNLENBQUUsRUFBRTtBQUN0RSxXQUFLLG9CQUFvQixJQUFJLGFBQWEsRUFBRTtJQUM5QztBQUNBLFNBQUssa0JBQWtCLElBQUksSUFBSTtBQUMvQixTQUFLLFdBQVcsY0FBYyxpQkFBaUI7RUFDakQ7RUFFQSxtQkFBZ0I7QUFDZCxVQUFNLE9BQU8sS0FBSyxvQkFBbUIsRUFBRyxLQUFJO0FBQzVDLFNBQUssT0FBTyxlQUFlLElBQUk7QUFDL0IsU0FBSyxXQUFXLHdCQUF3QixRQUFRLElBQUk7QUFDcEQsU0FBSyxrQkFBa0IsSUFBSSxLQUFLO0VBQ2xDO0VBRUEsY0FBYyxJQUFZLGFBQW9CO0FBQzVDLFVBQU0sT0FBTyxlQUFlO0FBQzVCLFVBQU0sYUFBYSxHQUFHLElBQUksY0FBYyxFQUFFO0FBRTFDLGNBQVUsVUFBVSxVQUFVLFVBQVU7QUFDeEMsU0FBSyxnQkFBZ0IsSUFBSSxFQUFFO0FBRTNCLFNBQUssV0FBVyxlQUFlLFlBQVk7QUFHM0MsZUFBVyxNQUFNLEtBQUssZ0JBQWdCLElBQUksSUFBSSxHQUFHLEdBQUk7RUFDdkQ7RUFFQSxrQkFBZTtBQUNiLFVBQU0sU0FBUyxLQUFLLE9BQU8sVUFBUyxHQUFJLGNBQWMsQ0FBQTtBQUN0RCxRQUFJLE9BQU8sV0FBVztBQUFHO0FBRXpCLFVBQU0sUUFBUSxPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxjQUFjLElBQUksQ0FBQztBQUVyRixRQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3BCLFdBQUssT0FBTyxnQkFBZ0IsT0FBTyxLQUFLO0FBQ3hDLFdBQUssV0FBVyx3QkFBd0IsVUFBVSxTQUFTLElBQUk7SUFDakU7RUFDRjtFQUVBLG1CQUFnQjtBQUNkLFVBQU0sVUFBVSxLQUFLLE9BQU8sVUFBUyxHQUFJLFdBQVcsQ0FBQTtBQUNwRCxRQUFJLFFBQVEsV0FBVztBQUFHO0FBRTFCLFNBQUssWUFDSCx3QkFDQSx1Q0FBdUMsUUFBUSxNQUFNLGFBQ3JELE1BQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssY0FBYyxJQUFJLENBQUM7QUFFdEYsVUFBSSxNQUFNLFNBQVMsR0FBRztBQUNwQixhQUFLLE9BQU8sZ0JBQWdCLE9BQU8sS0FBSztBQUN4QyxhQUFLLFdBQVcsd0JBQXdCLFdBQVcsU0FBUyxJQUFJO01BQ2xFO0lBQ0YsR0FDQSxLQUFLO0VBRVQ7RUFFQSxZQUFZLE1BQTBCO0FBQ3BDLFNBQUssU0FBUyxJQUFJLElBQUk7QUFDdEIsU0FBSyxXQUFXLDJCQUEyQixJQUFJO0VBQ2pEO0VBRUEsa0JBQWtCLE1BQTRCLE9BQWE7QUFDekQsUUFBSSxTQUFTLFVBQVU7QUFDckIsV0FBSyxpQkFBaUIsSUFBSSxLQUFLO0lBQ2pDLE9BQU87QUFDTCxXQUFLLGtCQUFrQixJQUFJLEtBQUs7SUFDbEM7RUFDRjtFQUVNLFdBQVE7O0FBQ1osVUFBSSxLQUFLLFVBQVM7QUFBSTtBQUd0QixZQUFNLGVBQWUsS0FBSyxPQUFPLFVBQVM7QUFFMUMsWUFBTSxhQUFhLE1BQVc7QUFDNUIsWUFBSTtBQUVGLGdCQUFNLFlBQVksTUFBTSxLQUFLLE9BQU8sb0JBQW1CO0FBRXZELGNBQUksV0FBVztBQUViLGtCQUFNLGFBQWEsS0FBSyxPQUFPLFVBQVM7QUFFeEMsZ0JBQ0UsY0FDQSxXQUFXLGFBQ1gsV0FBVyxjQUNYLEtBQUssY0FDTCxLQUFLLE9BQU8sY0FBYSxLQUN6QixDQUFDLEtBQUsscUJBQ047QUFDQSxtQkFBSyxzQkFBc0I7QUFFM0Isb0JBQU0saUJBQWlCLG1CQUFLO0FBQzVCLHFCQUFPLGVBQWU7QUFFdEIsb0JBQU0sVUFBVSxNQUFNLEtBQUssZUFBYztBQUN6QyxvQkFBTSxZQUFZLFVBQVUsUUFBUSxJQUFJLE9BQU8sZUFBZSxJQUFJO0FBR2xFLG1CQUFLLFdBQVcseUJBQXlCO2dCQUN2QyxNQUFNLFdBQVc7Z0JBQ2pCLE9BQU8sV0FBVztnQkFDbEIsV0FBVztnQkFDWCxhQUFhLEtBQUssT0FBTyxlQUFjO2dCQUN2QyxlQUFlLEtBQUssT0FBTyxxQkFBb0I7Z0JBQy9DLGFBQWE7ZUFDZDtZQUNIO0FBRUEsaUJBQUssZ0JBQWU7VUFDdEI7UUFDRixTQUFTLEdBQUc7QUFDVixrQkFBUSxNQUFNLGtDQUFrQyxDQUFDO1FBQ25EO01BQ0Y7QUFHQSxVQUFJLGNBQWMsYUFBYSxhQUFhLFVBQVUsU0FBUyxHQUFHO0FBQ2hFLGNBQU0sVUFBVSxLQUFLLE9BQU8sVUFBUyxHQUFJLFdBQVcsQ0FBQTtBQUVwRCxjQUFNLGFBQWEsUUFBUSxPQUFPLENBQUMsUUFBTztBQUN4QyxjQUFJLElBQUk7QUFBVSxtQkFBTztBQUN6QixjQUFJLGFBQWEsVUFBVSxTQUFTLElBQUksT0FBTztBQUFHLG1CQUFPO0FBQ3pELGlCQUFPO1FBQ1QsQ0FBQztBQUVELFlBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsZUFBSyxZQUNILG9CQUNBLDRCQUE0QixXQUFXLE1BQU0sOERBQzdDLE1BQU0sV0FBVSxHQUNoQixJQUFJO0FBRU47UUFDRjtNQUNGO0FBRUEsWUFBTSxXQUFVO0lBQ2xCOztFQUVBLG1CQUFnQjtBQUNkLFFBQUksS0FBSyxTQUFRLEdBQUk7QUFDbkIsZ0JBQVUsVUFBVSxVQUFVLEtBQUssU0FBUSxDQUFHO0FBRTlDLFlBQU0sU0FBUyxLQUFLLE9BQU8sVUFBUyxHQUFJO0FBQ3hDLFlBQU0sVUFBVSxDQUFDLFdBQVcsV0FBVyxRQUFRO0FBQy9DLFlBQU0sTUFBTSxRQUFRLFNBQVMsVUFBVSxFQUFFLElBQUksU0FBUztBQUV0RCxZQUFNLFVBQ0osUUFBUSxZQUNKLDBCQUNBLFFBQVEsWUFDTixrQ0FDQTtBQUVSLGFBQU8sS0FBSyxHQUFHLE9BQU8sWUFBWSxRQUFRO0lBQzVDO0VBQ0Y7RUFFQSxZQUFZLE9BQWUsU0FBaUIsUUFBb0IsZ0JBQWdCLE9BQUs7QUFDbkYsU0FBSyxZQUFZLElBQUksRUFBRSxPQUFPLFNBQVMsUUFBUSxlQUFlLE1BQU0sVUFBUyxDQUFFO0FBQy9FLFNBQUssaUJBQWlCLElBQUksSUFBSTtFQUNoQztFQUVBLFVBQVUsT0FBZSxTQUFlO0FBQ3RDLFNBQUssWUFBWSxJQUFJLEVBQUUsT0FBTyxTQUFTLFFBQVEsTUFBSztJQUFFLEdBQUcsZUFBZSxPQUFPLE1BQU0sUUFBTyxDQUFFO0FBQzlGLFNBQUssaUJBQWlCLElBQUksSUFBSTtFQUNoQztFQUVBLHVCQUFvQjtBQUNsQixTQUFLLFlBQVcsRUFBRyxPQUFNO0FBQ3pCLFNBQUssa0JBQWlCO0VBQ3hCO0VBRUEsb0JBQWlCO0FBQ2YsU0FBSyxpQkFBaUIsSUFBSSxLQUFLO0FBRS9CLFNBQUssWUFBWSxJQUFJO01BQ25CLE9BQU87TUFDUCxTQUFTO01BQ1QsUUFBUSxNQUFLO01BQUU7TUFDZixlQUFlO01BQ2YsTUFBTTtLQUNQO0VBQ0g7RUFFTSxTQUFNOztBQUNWLFdBQUssWUFBWSxJQUFJLElBQUk7QUFDekIsV0FBSyxhQUFhLElBQUksS0FBSztBQUMzQixXQUFLLGNBQWMsSUFBSSxLQUFLO0FBRTVCLFdBQUssV0FBVyxjQUFjLGNBQWM7QUFDNUMsV0FBSyxXQUFXLG1CQUFtQixPQUFPLEtBQUs7QUFFL0MsWUFBTSxLQUFLLGVBQWM7SUFDM0I7O0VBRU0sWUFBWSxhQUFvQjs7QUFDcEMsV0FBSyxjQUFjLElBQUksV0FBVztBQUNsQyxXQUFLLGFBQWEsSUFBSSxLQUFLO0FBQzNCLFdBQUssV0FBVyxtQkFBbUIsYUFBYSxLQUFLO0FBQ3JELFlBQU0sS0FBSyxlQUFjO0lBQzNCOztFQUVjLGlCQUFjOztBQUMxQixVQUFJO0FBQ0YsY0FBTSxPQUFPLEtBQUssY0FBYSxJQUMzQixLQUFLLGlCQUFnQixJQUNyQixPQUFPLFNBQVMsS0FBSyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRXJDLGNBQU0sVUFBVSxNQUFhLGlCQUFVLE1BQU07VUFDM0MsT0FBTztVQUNQLFFBQVE7VUFDUixPQUFPO1lBQ0wsTUFBTTtZQUNOLE9BQU87O1VBRVQsc0JBQXNCO1NBQ3ZCO0FBQ0QsYUFBSyxVQUFVLElBQUksT0FBTztNQUM1QixTQUFTLEtBQUs7QUFDWixnQkFBUSxNQUFNLHdCQUF3QixHQUFHO01BQzNDO0lBQ0Y7O0VBRUEsVUFBTztBQUNMLFNBQUssWUFBWSxJQUFJLEtBQUs7QUFDMUIsU0FBSyxVQUFVLElBQUksSUFBSTtFQUN6QjtFQUVBLGlCQUFjO0FBQ1osVUFBTSxjQUFjLENBQUMsS0FBSyxhQUFZO0FBQ3RDLFNBQUssYUFBYSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFFbEMsU0FBSyxXQUFXLG1CQUFtQixLQUFLLGNBQWEsR0FBSSxXQUFXO0FBRXBFLFFBQUksYUFBYTtBQUNmLFlBQU0sU0FBUyxLQUFLLGNBQWEsSUFBSyxzQkFBc0I7QUFDNUQsV0FBSyxPQUFPLFVBQVUsb0JBQW9CLEdBQUcsTUFBTSxvQkFBb0I7SUFDekU7RUFDRjtFQUVBLGFBQVU7QUFDUixVQUFNLE1BQU0sS0FBSyxVQUFTO0FBQzFCLFFBQUksQ0FBQztBQUFLO0FBRVYsVUFBTSxTQUFTLEtBQUssY0FBYSxJQUFLLHNCQUFzQjtBQUM1RCxTQUFLLE9BQU8sVUFBVSxzQkFBc0IsR0FBRyxNQUFNLDBCQUEwQjtBQUUvRSxTQUFLLFdBQVcsc0JBQXNCLGVBQWU7QUFFckQsVUFBTSxTQUFTLEtBQUssT0FBTSxLQUFNO0FBRWhDLFVBQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztBQUNwQyxNQUFFLE9BQU87QUFDVCxNQUFFLFdBQVcsa0JBQWtCLE9BQU8sTUFBTSxHQUFHLENBQUMsQ0FBQztBQUNqRCxhQUFTLEtBQUssWUFBWSxDQUFDO0FBQzNCLE1BQUUsTUFBSztBQUNQLGFBQVMsS0FBSyxZQUFZLENBQUM7RUFDN0I7RUFFQSxZQUFTO0FBQ1AsUUFBSSxDQUFDLEtBQUs7QUFBVztBQUNyQixRQUFJLE1BQU0sS0FBSyxVQUFVLEtBQUk7QUFDN0IsUUFBSSxJQUFJLFNBQVMsR0FBRztBQUFHLFlBQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzdDLFNBQUssT0FBTyxnQkFBZ0IsSUFBSSxFQUFFO0FBQ2xDLFNBQUssT0FBTyxRQUFRLEtBQUssT0FBTSxHQUFLLEdBQUc7QUFDdkMsU0FBSyxZQUFZO0VBQ25CO0VBRUEseUJBQXNCO0FBQ3BCLFNBQUssZUFBZSxJQUFJLElBQUk7QUFDNUIsU0FBSyxXQUFXLGNBQWMsb0JBQW9CO0VBQ3BEO0VBRU0sdUJBQW9COztBQUN4QixXQUFLLGVBQWUsSUFBSSxLQUFLO0FBRTdCLFdBQUssV0FBVyxzQkFBc0IsV0FBVztBQUVqRCxZQUFNLEtBQUssTUFBTSxHQUFJO0FBRXJCLFdBQUssaUJBQWdCO0lBQ3ZCOztFQUVBLG9CQUFpQjtBQUNmLFNBQUssYUFBYSxJQUFJLElBQUk7QUFDMUIsU0FBSyxXQUFXLGNBQWMsbUJBQW1CO0VBQ25EO0VBRU0scUJBQWtCOztBQUN0QixXQUFLLGFBQWEsSUFBSSxLQUFLO0FBRTNCLFdBQUssV0FBVyxzQkFBc0IsS0FBSztBQUMzQyxZQUFNLEtBQUssTUFBTSxHQUFJO0FBQ3JCLFdBQUssWUFBVztJQUNsQjs7RUFFUSxNQUFNLElBQTBCO0FBQ3RDLFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWSxXQUFXLFNBQVMsRUFBRSxDQUFDO0VBQ3pEO0VBRUEsY0FBVztBQUNULFVBQU0sYUFBYSxLQUFLLE9BQU8scUJBQW9CO0FBQ25ELFFBQUksQ0FBQztBQUFZO0FBRWpCLFVBQU0sU0FBUyxLQUFLLE9BQU8sVUFBUyxHQUFJLFVBQVU7QUFFbEQsVUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLFVBQVUsR0FBRyxFQUFFLE1BQU0sMEJBQXlCLENBQUU7QUFFdkUsVUFBTSxNQUFNLE9BQU8sSUFBSSxnQkFBZ0IsSUFBSTtBQUUzQyxVQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7QUFDdkMsU0FBSyxhQUFhLFFBQVEsR0FBRztBQUM3QixTQUFLLGFBQ0gsWUFDQSxjQUFjLE1BQU0sS0FBSSxvQkFBSSxLQUFJLEdBQUcsWUFBVyxFQUFHLE1BQU0sR0FBRyxFQUFFLENBQUMsTUFBTTtBQUdyRSxhQUFTLEtBQUssWUFBWSxJQUFJO0FBQzlCLFNBQUssTUFBSztBQUVWLGFBQVMsS0FBSyxZQUFZLElBQUk7QUFDOUIsV0FBTyxJQUFJLGdCQUFnQixHQUFHO0VBQ2hDO0VBRVEsU0FBU0EsTUFBc0M7QUFDckQsVUFBTSxXQUFXQSxLQUFJLFFBQVEsS0FBSyxFQUFFLEVBQUUsS0FBSTtBQUMxQyxRQUFJLFNBQVMsV0FBVyxHQUFHO0FBQ3pCLGFBQU87UUFDTCxTQUFTLFNBQVMsVUFBVSxHQUFHLENBQUMsR0FBRyxFQUFFO1FBQ3JDLFNBQVMsU0FBUyxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUU7UUFDckMsU0FBUyxTQUFTLFVBQVUsR0FBRyxDQUFDLEdBQUcsRUFBRTs7SUFFekM7QUFDQSxXQUFPLENBQUMsSUFBSSxLQUFLLEdBQUc7RUFDdEI7RUFFUSxjQUFjLEtBQW9DO0FBQ3hELFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBVztBQUM3QixZQUFNLE1BQU0sSUFBSSxNQUFLO0FBQ3JCLFVBQUksY0FBYztBQUVsQixVQUFJLFNBQVMsTUFBSztBQUNoQixjQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFFOUMsY0FBTSxRQUFRLElBQUksU0FBUztBQUMzQixjQUFNLFNBQVMsSUFBSSxVQUFVO0FBRTdCLGVBQU8sUUFBUSxRQUFRO0FBQ3ZCLGVBQU8sU0FBUyxTQUFTO0FBRXpCLGNBQU0sTUFBTSxPQUFPLFdBQVcsSUFBSTtBQUNsQyxZQUFJLENBQUM7QUFBSyxpQkFBTyxRQUFRLElBQUk7QUFFN0IsWUFBSSxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU8sT0FBTyxPQUFPLE1BQU07QUFDcEQsZ0JBQVEsT0FBTyxVQUFVLFdBQVcsQ0FBQztNQUN2QztBQUVBLFVBQUksVUFBVSxNQUFNLFFBQVEsSUFBSTtBQUNoQyxVQUFJLE1BQU07SUFDWixDQUFDO0VBQ0g7RUFFTSxtQkFBZ0I7O0FBQ3BCLFlBQU0sU0FBUyxLQUFLLGNBQWMsT0FBTTtBQUN4QyxZQUFNLGdCQUFnQixPQUFPO0FBRTdCLFlBQU0sV0FBVyxLQUFLLFNBQVMsT0FBTyxpQkFBaUIsU0FBUztBQUNoRSxZQUFNLGFBQWEsTUFBTSxLQUFLLGNBQWMsT0FBTyxPQUFPO0FBRTFELFlBQU0sRUFBRSxLQUFLLFNBQVEsSUFBSyxNQUFNLEtBQUssT0FBTyxlQUFlO1FBQ3pELFdBQVc7UUFDWCxZQUFZO1FBQ1osYUFBYSxjQUFjO1FBQzNCLGNBQWMsT0FBTztPQUN0QjtBQUNELFlBQU0sSUFBSSxLQUFLLFFBQVE7SUFDekI7O0VBRUEsaUJBQWM7QUFDWixXQUFPLEtBQUssT0FBTyxlQUFjO0VBQ25DO0VBRVEsV0FBVyxZQUFrQjtBQUNuQyxRQUFJLEtBQUs7QUFBZSxvQkFBYyxLQUFLLGFBQWE7QUFFeEQsU0FBSyxnQkFBZ0IsWUFBWSxNQUFLO0FBQ3BDLFlBQU0sTUFBTSxLQUFLLElBQUc7QUFDcEIsWUFBTSxPQUFPLGFBQWE7QUFFMUIsVUFBSSxRQUFRLEdBQUc7QUFDYixhQUFLLGNBQWMsSUFBSSxrQkFBa0I7QUFDekMsYUFBSyxVQUFVLElBQUksSUFBSTtBQUN2QixzQkFBYyxLQUFLLGFBQWE7QUFDaEMsYUFBSyxPQUFPLFdBQVU7TUFDeEIsT0FBTztBQUNMLGNBQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxNQUFPLEtBQUssR0FBRztBQUNoRCxjQUFNLFVBQVUsS0FBSyxNQUFPLFFBQVEsTUFBTyxLQUFLLE9BQVEsTUFBTyxHQUFHO0FBQ2xFLGNBQU0sVUFBVSxLQUFLLE1BQU8sUUFBUSxNQUFPLE1BQU8sR0FBSTtBQUN0RCxjQUFNLE1BQU0sQ0FBQyxNQUFjLEVBQUUsU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHO0FBRXZELGFBQUssY0FBYyxJQUFJLEdBQUcsSUFBSSxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksT0FBTyxDQUFDLElBQUk7QUFDOUUsYUFBSyxVQUFVLElBQUksT0FBTyxJQUFNO01BQ2xDO0lBQ0YsR0FBRyxHQUFJO0VBQ1Q7RUFFTyxrQkFBZTtBQUNwQixXQUFPLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBTyxDQUFFO0VBQ25EO0VBRUEsVUFBTztBQUNMLFNBQUssT0FBTyxLQUFLLFNBQVEsS0FBTSxJQUFJLEtBQUssTUFBTTtBQUM5QyxTQUFLLFdBQVcsZUFBZSxXQUFXO0VBQzVDO0VBRVEsT0FBTyxNQUFjLGdCQUFtQjtBQUM5QyxjQUFVLFVBQVUsVUFBVSxJQUFJO0FBQ2xDLFFBQUksZ0JBQWdCO0FBQ2xCLHFCQUFlLElBQUksSUFBSTtBQUN2QixpQkFBVyxNQUFNLGVBQWUsSUFBSSxLQUFLLEdBQUcsR0FBSTtJQUNsRDtFQUNGO0VBRU8sbUJBQTBCO0FBQy9CLFdBQU8sS0FBSyxPQUFPLFlBQVksT0FBTyxTQUFTLFFBQVEsSUFBSTtFQUM3RDtFQUVBLFlBQVksYUFBbUI7QUFDN0IsVUFBTSxRQUFRLEtBQUssZUFBZSxXQUFXO0FBQzdDLFVBQU0sTUFBTSwwQkFBMEIsS0FBSztFQUFLLEtBQUssaUJBQWdCLENBQUU7QUFFdkUsY0FBVSxVQUFVLFVBQVUsR0FBRyxFQUFFLEtBQUssTUFBSztBQUMzQyxXQUFLLFVBQ0gsd0JBQ0EscUJBQXFCLEtBQUsscUNBQXFDO0lBRW5FLENBQUM7QUFDRCxTQUFLLE9BQU8sVUFBVSxjQUFjLG9CQUFvQixLQUFLLEVBQUU7RUFDakU7RUFFQSxpQkFBYztBQUNaLFNBQUssZUFBZSxJQUFJLElBQUk7QUFDNUIsU0FBSyxXQUFXLGNBQWMscUJBQXFCO0VBQ3JEO0VBRUEsa0JBQWU7QUFDYixTQUFLLGVBQWUsSUFBSSxLQUFLO0VBQy9CO0VBRUEsaUJBQWM7QUFDWixVQUFNLFVBQVUsT0FBTyxTQUFTLEtBQUssTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNqRCxTQUFLLE9BQU8sU0FBUyxLQUFLLGdCQUFnQjtBQUMxQyxTQUFLLE9BQU8sVUFBVSx3QkFBd0IsdUJBQXVCO0FBRXJFLFNBQUssV0FBVyxlQUFlLFlBQVk7QUFDM0MsU0FBSyxnQkFBZTtFQUN0QjtFQUVBLGVBQVk7QUFDVixTQUFLLE9BQU8sS0FBSyxpQkFBZ0IsR0FBSSxLQUFLLGNBQWM7QUFDeEQsU0FBSyxPQUFPLFVBQVUsMEJBQTBCLHVCQUF1QjtBQUV2RSxTQUFLLFdBQVcsZUFBZSxpQkFBaUI7QUFDaEQsU0FBSyxnQkFBZTtFQUN0QjtFQUVBLGVBQVk7QUFDVixTQUFLLGFBQWEsSUFBSSxJQUFJO0FBQzFCLFNBQUssV0FBVyxjQUFjLHFCQUFxQjtFQUNyRDtFQUNBLGdCQUFhO0FBQ1gsU0FBSyxhQUFhLElBQUksS0FBSztFQUM3QjtFQUVBLGlCQUFjO0FBQ1osU0FBSyxlQUFlLElBQUksSUFBSTtBQUM1QixTQUFLLFdBQVcsY0FBYyxvQkFBb0I7RUFDcEQ7RUFFQSxrQkFBZTtBQUNiLFNBQUssZUFBZSxJQUFJLEtBQUs7RUFDL0I7RUFFQSxrQkFBZTtBQUNiLFNBQUssZ0JBQWdCLElBQUksSUFBSTtBQUM3QixTQUFLLFdBQVcsY0FBYyxTQUFTO0VBQ3pDO0VBQ0EsbUJBQWdCO0FBQ2QsU0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0VBQ2hDO0VBRUEsVUFBTztBQUNMLFNBQUssT0FBTyxLQUFLLE9BQU8sV0FBVSxLQUFNLElBQUksS0FBSyxTQUFTO0FBQzFELFNBQUssT0FBTyxVQUFVLGNBQWMsNEJBQTRCO0FBQ2hFLFNBQUssV0FBVyxlQUFlLGdCQUFnQjtBQUMvQyxTQUFLLGNBQWE7RUFDcEI7RUFFTSxpQkFBYzs7QUFDbEIsWUFBTSxpQkFBaUIsZUFBZSxRQUFRLGVBQWUsS0FBSyxPQUFNLENBQUUsRUFBRTtBQUM1RSxZQUFNLFVBQVUsS0FBSyxPQUFPLFdBQVU7QUFFdEMsVUFBSSxrQkFBa0IsU0FBUztBQUM3QixZQUFJO0FBQ0YsZ0JBQU0sYUFBYSxNQUFNLEtBQUssaUJBQWlCLFFBQVEsZ0JBQWdCLE9BQU87QUFFOUUsY0FBSSxZQUFZO0FBQ2QsaUJBQUssT0FBTyxZQUFZLEtBQUssV0FBVztBQUN4QyxpQkFBSyxPQUFPLFVBQVUsc0JBQXNCLDJCQUEyQjtBQUN2RSxpQkFBSyxXQUFXLGVBQWUsYUFBYTtVQUM5QztRQUNGLFNBQVMsR0FBRztBQUNWLGtCQUFRLE1BQU0sK0NBQStDLENBQUM7UUFDaEU7TUFDRjtBQUNBLFdBQUssZ0JBQWU7SUFDdEI7O0VBRUEsYUFBVTtBQUNSLFFBQUksS0FBSyxPQUFNLEdBQUk7QUFDakIsV0FBSyxPQUFPLEtBQUssT0FBTSxHQUFLLEtBQUssWUFBWTtBQUM3QyxXQUFLLE9BQU8sVUFBVSxrQkFBa0IsNEJBQTRCO0FBQ3BFLFdBQUssV0FBVyxlQUFlLFNBQVM7QUFDeEMsV0FBSyxpQkFBZ0I7SUFDdkI7RUFDRjtFQUVBLGFBQWE7SUFBd0M7TUFDbkQsd0JBQXdCO01BQ3hCLHdCQUF3QjtNQUN4Qix1QkFBdUI7TUFDdkIsU0FBUzs7Ozs7OztFQUdYLHFCQUFxQjtJQUFPOzs7Ozs7RUFDNUIsdUJBQXVCO0lBQThCOzs7Ozs7Ozs7RUFLckQsa0JBQWtCLFNBQXVCO0FBQ3ZDLFFBQUksS0FBSyxXQUFVLEVBQUcsT0FBTyxHQUFHO0FBQzlCLFdBQUsscUJBQXFCLElBQUksT0FBTztBQUNyQyxXQUFLLG1CQUFtQixJQUFJLElBQUk7QUFFaEMsV0FBSyxXQUFXLGNBQWMsMEJBQTBCLE9BQU87SUFDakUsT0FBTztBQUNMLFdBQUssV0FBVyxPQUFPLENBQUMsTUFBTyxpQ0FBSyxJQUFMLEVBQVEsQ0FBQyxPQUFPLEdBQUcsS0FBSSxFQUFHO0FBQ3pELFdBQUssT0FBTyxVQUFVLGtCQUFrQixjQUFjLE9BQU8sVUFBVTtBQUV2RSxXQUFLLFdBQVcsa0JBQWtCLFNBQVMsUUFBUTtJQUNyRDtFQUNGOzs7O0VBS0EsZ0JBQWE7QUFDWCxVQUFNLFVBQVUsS0FBSyxxQkFBb0I7QUFDekMsUUFBSSxTQUFTO0FBQ1gsV0FBSyxXQUFXLE9BQU8sQ0FBQyxNQUFPLGlDQUFLLElBQUwsRUFBUSxDQUFDLE9BQU8sR0FBRyxNQUFLLEVBQUc7QUFDMUQsV0FBSyxPQUFPLFVBQVUsa0JBQWtCLFlBQVksT0FBTyxVQUFVO0FBR3JFLFdBQUssV0FBVyxrQkFBa0IsU0FBUyxnQkFBZ0I7SUFDN0Q7QUFFQSxTQUFLLG1CQUFtQixJQUFJLEtBQUs7QUFDakMsU0FBSyxxQkFBcUIsSUFBSSxJQUFJO0VBQ3BDOzs7O0VBS0EsbUJBQWdCO0FBQ2QsU0FBSyxXQUFXLElBQUk7TUFDbEIsd0JBQXdCO01BQ3hCLHdCQUF3QjtNQUN4Qix1QkFBdUI7TUFDdkIsU0FBUztLQUNWO0FBQ0QsU0FBSyxPQUFPLFVBQVUsa0JBQWtCLHVCQUF1QjtBQUUvRCxTQUFLLFdBQVcsa0JBQWtCLE9BQWMsWUFBWTtBQUU1RCxTQUFLLG1CQUFtQixJQUFJLEtBQUs7QUFDakMsU0FBSyxxQkFBcUIsSUFBSSxJQUFJO0VBQ3BDOzs7O0VBS0Esc0JBQW1CO0FBQ2pCLFVBQU0sVUFBVSxLQUFLLHFCQUFvQjtBQUN6QyxRQUFJLFNBQVM7QUFDWCxXQUFLLFdBQVcsa0JBQWtCLFNBQVMsU0FBUztJQUN0RDtBQUVBLFNBQUssbUJBQW1CLElBQUksS0FBSztBQUNqQyxTQUFLLHFCQUFxQixJQUFJLElBQUk7RUFDcEM7RUFFQSxvQkFBaUI7QUFDZixTQUFLLGlCQUFnQjtBQUNyQixTQUFLLGtCQUFrQixJQUFJLElBQUk7QUFDL0IsU0FBSyxtQkFBbUIsSUFBSSxLQUFLO0FBQ2pDLFNBQUssV0FBVyxjQUFjLDBCQUEwQjtFQUMxRDtFQUVBLGdCQUFnQixRQUFxQjtBQUNuQyxTQUFLLGFBQWEsSUFBSSxNQUFNO0FBQzVCLFNBQUssV0FBVywwQkFBMEIsTUFBTTtBQUVoRCxRQUFJLEtBQUssa0JBQWlCLEdBQUk7QUFDNUIsV0FBSyxpQkFBZ0I7QUFFckIsVUFBSSxLQUFLLG1CQUFrQixHQUFJO0FBQzdCLGFBQUssdUJBQXNCO01BQzdCO0lBQ0Y7RUFDRjtFQUVBLG1CQUFnQjtBQUNkLFVBQU0sV0FBVyxLQUFLLE9BQU8sVUFBUyxHQUFJO0FBQzFDLFFBQUksQ0FBQztBQUFVO0FBQ2YsUUFBSTtBQUNGLFVBQUksS0FBSyxhQUFZLE1BQU8sTUFBTTtBQUNoQyxhQUFLLHVCQUF1QixLQUFLLFVBQVUsZUFBZSxRQUFRO01BQ3BFLE9BQU87QUFDTCxhQUFLLHVCQUF1QixLQUFLLFVBQVUsbUJBQW1CLFFBQVE7TUFDeEU7QUFDQSxXQUFLLGtCQUFrQixJQUFJLENBQUM7SUFDOUIsU0FBUyxHQUFHO0FBQ1YsY0FBUSxNQUFNLDRCQUE0QixDQUFDO0lBQzdDO0VBQ0Y7RUFFQSx1QkFBb0I7QUFDbEIsVUFBTSxZQUFZLENBQUMsS0FBSyxtQkFBa0I7QUFDMUMsU0FBSyxtQkFBbUIsSUFBSSxTQUFTO0FBRXJDLFNBQUssV0FBVyx5QkFBeUIsV0FBVyxLQUFLLGFBQVksQ0FBRTtBQUV2RSxRQUFJLFdBQVc7QUFDYixXQUFLLE9BQU8sVUFDVixrQkFDQSxZQUFZLEtBQUssYUFBWSxFQUFHLFlBQVcsQ0FBRSxVQUFVO0FBRXpELFdBQUssdUJBQXNCO0lBQzdCLE9BQU87QUFDTCxXQUFLLE9BQU8sVUFDVixrQkFDQSxXQUFXLEtBQUssYUFBWSxFQUFHLFlBQVcsQ0FBRSxVQUFVO0FBRXhELFdBQUssc0JBQXFCO0lBQzVCO0VBQ0Y7RUFFQSx5QkFBc0I7QUFDcEIsUUFBSSxLQUFLO0FBQWtCLG9CQUFjLEtBQUssZ0JBQWdCO0FBRTlELFNBQUssbUJBQW1CLFlBQVksTUFBSztBQUN2QyxXQUFLLGtCQUFrQixPQUFPLENBQUMsT0FBTyxJQUFJLEtBQUssS0FBSyxxQkFBcUIsTUFBTTtBQUMvRSxXQUFLLG9CQUFtQjtJQUMxQixHQUFHLEtBQUssY0FBYSxDQUFFO0FBRXZCLGVBQVcsTUFBTSxLQUFLLG9CQUFtQixHQUFJLENBQUM7RUFDaEQ7RUFFQSx3QkFBcUI7QUFDbkIsUUFBSSxLQUFLO0FBQWtCLG9CQUFjLEtBQUssZ0JBQWdCO0VBQ2hFO0VBRUEscUJBQWtCO0FBQ2hCLFNBQUssa0JBQWtCLElBQUksS0FBSztBQUNoQyxTQUFLLG1CQUFtQixJQUFJLEtBQUs7QUFDakMsU0FBSyxzQkFBcUI7RUFDNUI7RUFFTSxzQkFBbUI7O0FBQ3ZCLFVBQUksQ0FBQyxLQUFLLG1CQUFrQjtBQUFJO0FBQ2hDLFlBQU0sU0FBUyxTQUFTLGVBQWUsc0JBQXNCO0FBQzdELFVBQUksVUFBVSxLQUFLLHFCQUFxQixTQUFTLEdBQUc7QUFDbEQsY0FBTSxRQUFRLEtBQUsscUJBQXFCLEtBQUssa0JBQWlCLENBQUU7QUFFaEUsY0FBYSxnQkFBUyxRQUFRLE9BQU87VUFDbkMsT0FBTztVQUNQLFFBQVE7VUFDUixPQUFPLEVBQUUsTUFBTSxXQUFXLE9BQU8sVUFBUztTQUMzQztNQUNIO0lBQ0Y7O0VBRUEsZUFBWTtBQUNWLFNBQUssaUJBQWlCLElBQUksSUFBSTtBQUM5QixTQUFLLGlCQUFpQixJQUFJLElBQUk7QUFDOUIsU0FBSyxVQUFVLGFBQVk7QUFFM0IsU0FBSyxXQUFXLGNBQWMsdUJBQXVCO0FBRXJELGVBQVcsTUFBVztBQUNwQixXQUFLLGNBQWMsSUFBSSxZQUFZLGlCQUFpQjtRQUNsRCxrQkFBa0IsQ0FBQyw0QkFBNEIsT0FBTztRQUN0RCxTQUFTO1FBQ1Qsc0JBQXNCO1VBQ3BCLCtCQUErQjs7T0FFbEM7QUFFRCxVQUFJLGFBQWE7QUFFakIsVUFBSTtBQUNGLGNBQU0sS0FBSyxZQUFZLE1BQ3JCLEVBQUUsWUFBWSxjQUFhLEdBQzNCO1VBQ0UsS0FBSztVQUNMLGFBQWE7VUFDYixPQUFPLEVBQUUsT0FBTyxLQUFLLFFBQVEsSUFBRztVQUNoQyxrQkFBa0I7WUFDaEIsT0FBTyxFQUFFLE9BQU8sS0FBSTtZQUNwQixRQUFRLEVBQUUsT0FBTyxJQUFHOztXQUd4QixDQUFDLGdCQUFnQixLQUFLLGlCQUFpQixXQUFXLEdBQ2xELENBQUMsaUJBQWdCO0FBQ2Y7QUFDQSxjQUFJLGFBQWEsT0FBTyxHQUFHO0FBQ3pCLG9CQUFRLEtBQ04seUJBQXlCLFVBQVUsOEJBQ25DLGFBQWEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1VBRS9CO1FBQ0YsQ0FBQztNQUVMLFNBQVMsS0FBSztBQUNaLGdCQUFRLEtBQUssd0VBQXdFLEdBQUc7QUFFeEYsWUFBSTtBQUNGLGdCQUFNLEtBQUssWUFBWSxNQUNyQixFQUFFLFlBQVksY0FBYSxHQUMzQixFQUFFLEtBQUssSUFBSSxhQUFhLE1BQUssR0FDN0IsQ0FBQyxnQkFBZ0IsS0FBSyxpQkFBaUIsV0FBVyxHQUNsRCxNQUFLO0FBQ0gsb0JBQVEsTUFBTSxrQ0FBa0M7VUFDbEQsQ0FBQztRQUVMLFNBQVMsYUFBYTtBQUNwQixrQkFBUSxNQUFNLHNDQUFzQyxXQUFXO0FBQy9ELGVBQUssWUFBVztRQUNsQjtNQUNGO0lBQ0YsSUFBRyxHQUFHO0VBQ1I7RUFFQSxpQkFBaUIsYUFBbUI7QUFDbEMsWUFBUSxJQUFJLHFCQUFxQixZQUFZLFVBQVUsR0FBRyxFQUFFLElBQUksS0FBSztBQUVyRSxVQUFNLFVBQVUsS0FBSyxVQUFVLGdCQUFnQixXQUFXO0FBRTFELFFBQUksU0FBUztBQUNYLGNBQVEsSUFBSSw4QkFBOEIsUUFBUSxNQUFNO0FBQ3hELFdBQUssWUFBVztBQUNoQixXQUFLLHdCQUF3QixPQUFPO0lBQ3RDO0VBQ0Y7RUFFQSxjQUFXO0FBQ1QsUUFBSSxLQUFLLGFBQWE7QUFDcEIsVUFBSTtBQUNGLFlBQUksS0FBSyxZQUFZLFNBQVEsTUFBTyxHQUFHO0FBQ3JDLGVBQUssWUFDRixLQUFJLEVBQ0osS0FBSyxNQUFLO0FBQ1QsaUJBQUssYUFBYSxNQUFLO0FBQ3ZCLGlCQUFLLGlCQUFpQixJQUFJLEtBQUs7QUFDL0IsaUJBQUssaUJBQWlCLElBQUksS0FBSztVQUNqQyxDQUFDLEVBQ0EsTUFBTSxNQUFLO0FBQ1YsaUJBQUssYUFBYSxNQUFLO0FBQ3ZCLGlCQUFLLGlCQUFpQixJQUFJLEtBQUs7QUFDL0IsaUJBQUssaUJBQWlCLElBQUksS0FBSztVQUNqQyxDQUFDO1FBQ0wsT0FBTztBQUNMLGVBQUssWUFBWSxNQUFLO0FBQ3RCLGVBQUssaUJBQWlCLElBQUksS0FBSztBQUMvQixlQUFLLGlCQUFpQixJQUFJLEtBQUs7UUFDakM7TUFDRixTQUFTLEdBQUc7QUFDVixhQUFLLFlBQVksTUFBSztBQUN0QixhQUFLLGlCQUFpQixJQUFJLEtBQUs7QUFDL0IsYUFBSyxpQkFBaUIsSUFBSSxLQUFLO01BQ2pDO0lBQ0YsT0FBTztBQUNMLFdBQUssaUJBQWlCLElBQUksS0FBSztBQUMvQixXQUFLLGlCQUFpQixJQUFJLEtBQUs7SUFDakM7RUFDRjtFQUVNLHdCQUF3QixNQUFZOztBQUN4QyxVQUFJO0FBQ0YsY0FBTSxRQUFRLEtBQUssUUFBUSxRQUFRLEVBQUU7QUFDckMsY0FBTSxZQUFZLGlCQUFpQixLQUFLLEtBQUssSUFBSSxJQUFJLE9BQU8sS0FBSyxJQUFJLE9BQU8sT0FBTyxLQUFLO0FBQ3hGLGNBQU0sbUJBQW1CLE9BQU8sT0FBTyxTQUFTO0FBRWhELGNBQU0sS0FBSyxPQUFPLGdCQUFnQixnQkFBZ0I7QUFDbEQsZ0JBQVEsSUFBSSwrQ0FBK0M7QUFDM0QsYUFBSyxXQUFXLGlCQUFpQixNQUFNO01BQ3pDLFNBQVMsR0FBRztBQUNWLGdCQUFRLE1BQU0sNENBQTRDLENBQUM7TUFDN0Q7SUFDRjs7RUFFQSxvQkFBb0IsVUFBZ0I7QUFDbEMsU0FBSyxjQUFjLElBQUksT0FBTyxRQUFRLENBQUM7QUFFdkMsUUFBSSxLQUFLLG1CQUFrQixLQUFNLEtBQUssa0JBQWlCLEdBQUk7QUFDekQsV0FBSyx1QkFBc0I7SUFDN0I7RUFDRjs7cUNBeDFDVyxnQkFBYSwrQkFBQSxpQkFBQSxHQUFBLCtCQUFBLGFBQUEsR0FBQSwrQkFBQSxTQUFBLEdBQUEsK0JBQUEsUUFBQSxHQUFBLCtCQUFBLFNBQUEsR0FBQSwrQkE2R2QsV0FBVyxHQUFBLCtCQUFBLHVCQUFBLEdBQUEsK0JBQUEsZ0JBQUEsR0FBQSwrQkFBQSxhQUFBLENBQUE7RUFBQTs0RUE3R1YsZ0JBQWEsV0FBQSxDQUFBLENBQUEsVUFBQSxDQUFBLEdBQUEsY0FBQSxTQUFBLDJCQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FBQWIsTUFBQSx3QkFBQSxnQkFBQSxTQUFBLGdEQUFBO0FBQUEsZUFBQSxJQUFBLGVBQUE7TUFBZ0IsR0FBQSw0QkFBQTs7Z0RBRmhCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQSxHQUFBLE9BQUEsS0FBQSxNQUFBLEtBQUEsUUFBQSxDQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLFVBQUEsbUJBQUEsaUJBQUEsZUFBQSxXQUFBLGFBQUEsVUFBQSxTQUFBLFNBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsZUFBQSxHQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEseUJBQUEsR0FBQSxTQUFBLFdBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLGtCQUFBLG9CQUFBLGlCQUFBLEdBQUEsQ0FBQSxNQUFBLHlCQUFBLEdBQUEsU0FBQSxXQUFBLFdBQUEsUUFBQSxnQkFBQSxrQkFBQSxrQkFBQSxvQkFBQSxpQkFBQSxHQUFBLENBQUEsTUFBQSw2QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsMEJBQUEsR0FBQSxTQUFBLFdBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLGtCQUFBLG9CQUFBLGVBQUEsVUFBQSw0QkFBQSxvQkFBQSxHQUFBLENBQUEsTUFBQSxxQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxrQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSx5QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsT0FBQSxjQUFBLFdBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsNEJBQUEsR0FBQSxhQUFBLFdBQUEsUUFBQSxRQUFBLFlBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsWUFBQSxvQkFBQSxhQUFBLGFBQUEsc0JBQUEsZ0JBQUEsZ0JBQUEscUJBQUEsR0FBQSxDQUFBLE1BQUEsc0JBQUEsR0FBQSxvQkFBQSxvQkFBQSxVQUFBLCtCQUFBLGNBQUEsT0FBQSxRQUFBLFlBQUEsUUFBQSxhQUFBLFFBQUEsWUFBQSxTQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsVUFBQSxXQUFBLGFBQUEsY0FBQSxjQUFBLHVCQUFBLGVBQUEsd0JBQUEsR0FBQSxDQUFBLE9BQUEsbUJBQUEsR0FBQSxRQUFBLFFBQUEsV0FBQSxXQUFBLGtCQUFBLFVBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsbUJBQUEsZ0JBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsaUJBQUEsbUJBQUEsUUFBQSxnQkFBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLHVCQUFBLEdBQUEsT0FBQSxjQUFBLGlDQUFBLHFCQUFBLFFBQUEsZ0JBQUEsU0FBQSxrQkFBQSxHQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsbUJBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxnQkFBQSxZQUFBLFFBQUEsUUFBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxnQkFBQSxPQUFBLEdBQUEsQ0FBQSxTQUFBLGdCQUFBLEdBQUEsT0FBQSxPQUFBLGdCQUFBLGVBQUEsWUFBQSwyQkFBQSxHQUFBLENBQUEsU0FBQSxlQUFBLEdBQUEsT0FBQSxPQUFBLGdCQUFBLGdCQUFBLGlCQUFBLDZCQUFBLFVBQUEsR0FBQSxDQUFBLFNBQUEsZUFBQSxHQUFBLE9BQUEsT0FBQSxnQkFBQSxtQkFBQSxpQkFBQSxzQ0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxtQkFBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLFNBQUEsZUFBQSxHQUFBLE9BQUEsU0FBQSxjQUFBLGlDQUFBLHlCQUFBLHlCQUFBLGNBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxhQUFBLGdCQUFBLFNBQUEsWUFBQSxXQUFBLHlCQUFBLGVBQUEsU0FBQSxRQUFBLFFBQUEsY0FBQSxVQUFBLDBCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLFFBQUEsZ0JBQUEsU0FBQSxpQ0FBQSxTQUFBLFVBQUEsY0FBQSxjQUFBLFVBQUEsc0JBQUEsa0NBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEscUJBQUEsbUJBQUEsR0FBQSxDQUFBLGNBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxxQkFBQSx1QkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLGNBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsWUFBQSxvQkFBQSx3QkFBQSxtQkFBQSxlQUFBLGFBQUEsVUFBQSxRQUFBLFdBQUEsYUFBQSwyQkFBQSxjQUFBLHVCQUFBLHFCQUFBLFVBQUEsNEJBQUEsYUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsT0FBQSxzQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFdBQUEsYUFBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLFdBQUEsYUFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxZQUFBLG9CQUFBLHdCQUFBLG1CQUFBLGVBQUEsYUFBQSxRQUFBLFVBQUEsV0FBQSxhQUFBLDJCQUFBLHNCQUFBLHVCQUFBLHFCQUFBLFVBQUEsNEJBQUEsYUFBQSxTQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsWUFBQSxTQUFBLGtCQUFBLGlDQUFBLFNBQUEsVUFBQSxjQUFBLGNBQUEsVUFBQSxzQkFBQSxrQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxnQkFBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsYUFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsV0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsV0FBQSxlQUFBLHVCQUFBLGlCQUFBLHdCQUFBLG1CQUFBLGVBQUEsYUFBQSxRQUFBLFVBQUEsV0FBQSxhQUFBLDJCQUFBLHNCQUFBLHVCQUFBLHFCQUFBLFVBQUEsNEJBQUEsYUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLCtCQUFBLFFBQUEsWUFBQSxlQUFBLFNBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsYUFBQSxtQkFBQSx5QkFBQSxhQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxhQUFBLGdCQUFBLFNBQUEsZUFBQSxVQUFBLDRCQUFBLGNBQUEsU0FBQSxhQUFBLFVBQUEsV0FBQSxHQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLFFBQUEsUUFBQSxpQkFBQSx3QkFBQSx1QkFBQSxjQUFBLGNBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLHNCQUFBLDRCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxZQUFBLFFBQUEsT0FBQSx3QkFBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLG9CQUFBLEdBQUEsUUFBQSxRQUFBLG1CQUFBLDhCQUFBLGNBQUEsY0FBQSxXQUFBLGFBQUEsUUFBQSxnQkFBQSxTQUFBLFVBQUEsc0JBQUEsa0NBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLE1BQUEsaUJBQUEsR0FBQSxRQUFBLFFBQUEsbUJBQUEsOEJBQUEsY0FBQSxjQUFBLFdBQUEsYUFBQSxRQUFBLGdCQUFBLFNBQUEsVUFBQSxzQkFBQSxrQ0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxXQUFBLEdBQUEsQ0FBQSxNQUFBLHlCQUFBLEdBQUEsU0FBQSxXQUFBLFdBQUEsUUFBQSxnQkFBQSxrQkFBQSxrQkFBQSxvQkFBQSxtQkFBQSxLQUFBLEdBQUEsQ0FBQSxNQUFBLHVCQUFBLEdBQUEsU0FBQSxXQUFBLFdBQUEsUUFBQSxnQkFBQSxrQkFBQSxrQkFBQSxvQkFBQSxpQkFBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFNBQUEsV0FBQSxXQUFBLFFBQUEsZ0JBQUEsa0JBQUEsa0JBQUEsb0JBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsdUJBQUEsR0FBQSxTQUFBLFdBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLE9BQUEsZUFBQSxvQkFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGtCQUFBLFNBQUEsa0JBQUEsZ0JBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLFdBQUEsR0FBQSxDQUFBLE1BQUEsb0JBQUEsR0FBQSxpQkFBQSxVQUFBLDRCQUFBLGNBQUEsT0FBQSxZQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsVUFBQSxXQUFBLE9BQUEsY0FBQSxxQkFBQSxHQUFBLENBQUEsT0FBQSxtQkFBQSxHQUFBLFFBQUEsUUFBQSxrQkFBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxtQkFBQSxnQkFBQSxRQUFBLFlBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLE9BQUEsY0FBQSxpQ0FBQSxxQkFBQSxRQUFBLGdCQUFBLFNBQUEsa0JBQUEsR0FBQSxTQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsZ0JBQUEsWUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsbUJBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGFBQUEsbUJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSx5QkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLFdBQUEsYUFBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEseUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsdUJBQUEsR0FBQSxpQkFBQSxVQUFBLDRCQUFBLGNBQUEsT0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsaUJBQUEsbUJBQUEsUUFBQSxnQkFBQSxTQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxlQUFBLGtCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSx5QkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsUUFBQSxnQkFBQSxrQkFBQSxPQUFBLGVBQUEsVUFBQSw0QkFBQSxjQUFBLGdDQUFBLDJCQUFBLGtCQUFBLFdBQUEsZUFBQSxtQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLFFBQUEseUJBQUEsaUNBQUEscUJBQUEsWUFBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLDRCQUFBLEdBQUEsUUFBQSxnQkFBQSxrQkFBQSxPQUFBLGVBQUEsVUFBQSw0QkFBQSxjQUFBLDhCQUFBLHlCQUFBLGtCQUFBLFdBQUEsZUFBQSxtQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsdUJBQUEsSUFBQSxHQUFBLFFBQUEseUJBQUEsK0JBQUEscUJBQUEsWUFBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsUUFBQSxnQkFBQSxrQkFBQSxPQUFBLGVBQUEsVUFBQSw0QkFBQSxjQUFBLGdDQUFBLDJCQUFBLGtCQUFBLFdBQUEsZUFBQSxtQkFBQSxTQUFBLHVCQUFBLCtCQUFBLGtCQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLDBCQUFBLEdBQUEsWUFBQSxTQUFBLGtCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsT0FBQSxlQUFBLFVBQUEsNEJBQUEsY0FBQSw4QkFBQSx5QkFBQSxrQkFBQSxXQUFBLGVBQUEsbUJBQUEscUJBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxVQUFBLG1CQUFBLEdBQUEsWUFBQSxXQUFBLGFBQUEsa0JBQUEsUUFBQSxHQUFBLFVBQUEsVUFBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxHQUFBLFFBQUEseUJBQUEsK0JBQUEscUJBQUEsWUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsWUFBQSxjQUFBLG1CQUFBLFVBQUEsMEJBQUEsUUFBQSxzQ0FBQSxjQUFBLFdBQUEsdUJBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxHQUFBLFlBQUEsaUJBQUEsVUFBQSw0QkFBQSxjQUFBLE9BQUEsaUJBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsc0JBQUEsR0FBQSxPQUFBLGNBQUEsaUNBQUEscUJBQUEsUUFBQSxnQkFBQSxTQUFBLGtCQUFBLEdBQUEsU0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxRQUFBLGVBQUEsT0FBQSxjQUFBLFVBQUEsNEJBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxrQkFBQSxHQUFBLFVBQUEsVUFBQSxXQUFBLGFBQUEsY0FBQSxrQkFBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLG1CQUFBLEdBQUEsVUFBQSxVQUFBLFdBQUEsYUFBQSxjQUFBLGtCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsUUFBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsYUFBQSxtQkFBQSxpQkFBQSxRQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxRQUFBLGdCQUFBLGtCQUFBLFFBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxNQUFBLHFCQUFBLEdBQUEsaUJBQUEsVUFBQSw0QkFBQSxjQUFBLE9BQUEsVUFBQSxRQUFBLFlBQUEsWUFBQSxpQkFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLFdBQUEsYUFBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxHQUFBLE9BQUEsY0FBQSxpQ0FBQSxxQkFBQSxRQUFBLGdCQUFBLFNBQUEsa0JBQUEsR0FBQSxTQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxhQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxnQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxjQUFBLFFBQUEsZ0JBQUEsbUJBQUEsVUFBQSxrQkFBQSxHQUFBLHFCQUFBLHlCQUFBLGVBQUEsMEJBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxPQUFBLHlCQUFBLFNBQUEsR0FBQSxDQUFBLE1BQUEsNEJBQUEsR0FBQSxRQUFBLFFBQUEsWUFBQSw0QkFBQSxZQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsc0JBQUEsVUFBQSwwQkFBQSxjQUFBLE9BQUEsb0JBQUEsR0FBQSxDQUFBLFlBQUEsSUFBQSxHQUFBLFVBQUEsVUFBQSx3QkFBQSx5QkFBQSxhQUFBLGNBQUEsVUFBQSw0QkFBQSxzQkFBQSxRQUFBLGdCQUFBLGtCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxLQUFBLEdBQUEsQ0FBQSxpQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsVUFBQSw0QkFBQSxlQUFBLGNBQUEsWUFBQSxVQUFBLG1CQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxZQUFBLDRCQUFBLFFBQUEsZ0JBQUEsaUJBQUEsR0FBQSxDQUFBLHVCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxpQkFBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxHQUFBLHlCQUFBLHlCQUFBLGNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxXQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxRQUFBLFlBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLHNCQUFBLFVBQUEsMEJBQUEsY0FBQSxPQUFBLFFBQUEsZUFBQSxPQUFBLEdBQUEsQ0FBQSx1QkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLHFCQUFBLFlBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHFCQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEseUJBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxTQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsdUJBQUEsR0FBQSxVQUFBLFVBQUEsY0FBQSxVQUFBLDRCQUFBLHlCQUFBLHlCQUFBLGlDQUFBLGNBQUEsYUFBQSxXQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFVBQUEsVUFBQSxzQkFBQSw0QkFBQSxxQkFBQSxXQUFBLGFBQUEsY0FBQSxVQUFBLDBCQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsa0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsbUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxtQkFBQSxHQUFBLENBQUEsa0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsa0JBQUEsVUFBQSxzQkFBQSxjQUFBLE9BQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLHVCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsaUJBQUEsWUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsaUJBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxVQUFBLFVBQUEsa0JBQUEsd0JBQUEsaUJBQUEsV0FBQSxhQUFBLGNBQUEsVUFBQSxzQkFBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGNBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxtQkFBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxxQkFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsd0JBQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsMEJBQUEsR0FBQSxRQUFBLFVBQUEsVUFBQSxzQkFBQSw0QkFBQSxxQkFBQSxXQUFBLGFBQUEsY0FBQSxVQUFBLDBCQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxVQUFBLDRCQUFBLE9BQUEsZUFBQSxjQUFBLFlBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLG1CQUFBLGdCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsV0FBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxHQUFBLHlCQUFBLHlCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEseUJBQUEsYUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsbUJBQUEsYUFBQSxlQUFBLE9BQUEsV0FBQSxVQUFBLDBCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsV0FBQSxhQUFBLHlCQUFBLGFBQUEsa0JBQUEsTUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLGVBQUEsdUJBQUEsYUFBQSxJQUFBLEdBQUEsVUFBQSxlQUFBLFVBQUEsNEJBQUEsbUJBQUEsV0FBQSxjQUFBLFNBQUEsT0FBQSxnQkFBQSw2QkFBQSxjQUFBLEdBQUEsaUJBQUEsZUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxnQkFBQSxTQUFBLGtCQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsT0FBQSxXQUFBLFVBQUEsUUFBQSxnQkFBQSxrQkFBQSxtQkFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsU0FBQSxTQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFFBQUEsbUJBQUEsK0JBQUEsaUJBQUEsYUFBQSxjQUFBLGNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLFVBQUEsNEJBQUEsT0FBQSxlQUFBLGNBQUEsWUFBQSxVQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLDJCQUFBLGdCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsV0FBQSxNQUFBLEdBQUEsQ0FBQSxzQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxtQkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLFFBQUEsU0FBQSxHQUFBLENBQUEsY0FBQSxXQUFBLEdBQUEsVUFBQSxRQUFBLG1CQUFBLCtCQUFBLGlCQUFBLGFBQUEsY0FBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxnQkFBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLFVBQUEsNEJBQUEsT0FBQSxlQUFBLGNBQUEsWUFBQSxVQUFBLGVBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsbUJBQUEsZ0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSx5QkFBQSxNQUFBLEdBQUEsQ0FBQSxjQUFBLEtBQUEsR0FBQSxVQUFBLFFBQUEsMkJBQUEsOEJBQUEsbUJBQUEsYUFBQSxjQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLFVBQUEsNEJBQUEsZ0JBQUEsZ0JBQUEsR0FBQSxDQUFBLG9CQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxVQUFBLHNCQUFBLE9BQUEsZUFBQSxjQUFBLFlBQUEsVUFBQSxlQUFBLFlBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLFVBQUEsVUFBQSxPQUFBLG9CQUFBLGlCQUFBLGtCQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLGVBQUEsZ0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxXQUFBLFFBQUEsVUFBQSxrQkFBQSxHQUFBLENBQUEsY0FBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLE9BQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsa0JBQUEsZ0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxXQUFBLFFBQUEsVUFBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSx5QkFBQSxRQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxTQUFBLE1BQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxlQUFBLDJCQUFBLEdBQUEsVUFBQSxpQkFBQSxVQUFBLDRCQUFBLG1CQUFBLFdBQUEsY0FBQSxTQUFBLFNBQUEsZ0JBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsUUFBQSxlQUFBLHFCQUFBLHVCQUFBLGNBQUEsYUFBQSxjQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLGtCQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxhQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHlCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSx5QkFBQSxhQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsV0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLGFBQUEsTUFBQSxlQUFBLCtCQUFBLGFBQUEsSUFBQSxHQUFBLFVBQUEsZUFBQSxVQUFBLDRCQUFBLGNBQUEsUUFBQSxRQUFBLG1CQUFBLHFDQUFBLHNCQUFBLGdDQUFBLGNBQUEsR0FBQSxpQkFBQSxlQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxnQkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsa0JBQUEsWUFBQSw0QkFBQSxRQUFBLGVBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLFFBQUEsUUFBQSxjQUFBLHlCQUFBLHlCQUFBLGlDQUFBLGNBQUEsV0FBQSxlQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsY0FBQSxtQkFBQSwrQkFBQSxpQkFBQSxhQUFBLFdBQUEsY0FBQSxhQUFBLDBCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxVQUFBLDRCQUFBLGVBQUEsY0FBQSxZQUFBLFVBQUEsbUJBQUEsVUFBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLFFBQUEsWUFBQSxjQUFBLEdBQUEsQ0FBQSxNQUFBLDJCQUFBLEdBQUEsVUFBQSxVQUFBLFdBQUEsYUFBQSxjQUFBLGtCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLE1BQUEsc0JBQUEsR0FBQSxVQUFBLFVBQUEsV0FBQSxhQUFBLGNBQUEsa0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsbUJBQUEsVUFBQSx1QkFBQSxjQUFBLE9BQUEsUUFBQSxRQUFBLGVBQUEsU0FBQSxjQUFBLFdBQUEsY0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsc0JBQUEsVUFBQSwwQkFBQSxjQUFBLE9BQUEsUUFBQSxRQUFBLGVBQUEsU0FBQSxjQUFBLFdBQUEsY0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxPQUFBLGNBQUEsa0JBQUEsY0FBQSxHQUFBLENBQUEsT0FBQSxnQkFBQSxHQUFBLFFBQUEsUUFBQSxXQUFBLFdBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsUUFBQSxRQUFBLGdCQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxRQUFBLFlBQUEsZ0JBQUEsa0JBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHlCQUFBLFFBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLGtCQUFBLFlBQUEsNEJBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxNQUFBLHlCQUFBLEdBQUEsVUFBQSxVQUFBLGNBQUEsd0JBQUEsaUNBQUEsbUJBQUEsZUFBQSxXQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLFVBQUEsNEJBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsVUFBQSxjQUFBLGlCQUFBLDhCQUFBLHlCQUFBLHlCQUFBLGVBQUEsV0FBQSxjQUFBLFVBQUEsc0JBQUEsa0NBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSx1QkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGlCQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxxQkFBQSxpQkFBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLE9BQUEsZ0JBQUEsVUFBQSw0QkFBQSxhQUFBLE1BQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGFBQUEsaUJBQUEsZUFBQSxRQUFBLFFBQUEsV0FBQSxXQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSwwQkFBQSxxQkFBQSxjQUFBLE9BQUEsWUFBQSxtQkFBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsbUJBQUEsZUFBQSxRQUFBLFlBQUEsTUFBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxhQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSx5QkFBQSxRQUFBLGlCQUFBLEdBQUEsQ0FBQSxNQUFBLHdCQUFBLEdBQUEsUUFBQSxVQUFBLFVBQUEsc0JBQUEsNEJBQUEscUJBQUEsV0FBQSxhQUFBLGNBQUEsVUFBQSwwQkFBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxZQUFBLFFBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsNEJBQUEsa0JBQUEsY0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsbUJBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSx1QkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGdCQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsUUFBQSxVQUFBLFVBQUEsMkJBQUEsOEJBQUEsbUJBQUEsV0FBQSxhQUFBLGNBQUEsVUFBQSw0QkFBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsa0JBQUEsVUFBQSxzQkFBQSxjQUFBLE9BQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLHVCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsaUJBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGlCQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsVUFBQSxVQUFBLGtCQUFBLHdCQUFBLGlCQUFBLFdBQUEsYUFBQSxjQUFBLFVBQUEsc0JBQUEsY0FBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxpQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsb0JBQUEsVUFBQSx3QkFBQSxjQUFBLE9BQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLHNCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsbUJBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLG1CQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsVUFBQSxVQUFBLG9CQUFBLDBCQUFBLG1CQUFBLFdBQUEsYUFBQSxjQUFBLFVBQUEsd0JBQUEsY0FBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsUUFBQSxlQUFBLE9BQUEsY0FBQSxVQUFBLDRCQUFBLE1BQUEsR0FBQSxDQUFBLE1BQUEsaUJBQUEsR0FBQSxVQUFBLFVBQUEsV0FBQSxhQUFBLGNBQUEsa0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxHQUFBLFVBQUEsVUFBQSxXQUFBLGFBQUEsY0FBQSxrQkFBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxrQkFBQSxlQUFBLFlBQUEsZ0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsT0FBQSxjQUFBLGtCQUFBLGdCQUFBLFVBQUEsR0FBQSxDQUFBLE1BQUEsd0JBQUEsR0FBQSxRQUFBLFFBQUEsV0FBQSxXQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSx5QkFBQSxRQUFBLGVBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLFFBQUEsZUFBQSxPQUFBLGNBQUEsVUFBQSw0QkFBQSxjQUFBLFdBQUEsMEJBQUEsY0FBQSxHQUFBLENBQUEsTUFBQSx1QkFBQSxHQUFBLFFBQUEsVUFBQSxjQUFBLGlCQUFBLDhCQUFBLHlCQUFBLHlCQUFBLGVBQUEsV0FBQSxjQUFBLFVBQUEsc0JBQUEsa0NBQUEsVUFBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLG1CQUFBLGdCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxhQUFBLHlCQUFBLGFBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxhQUFBLHFCQUFBLFdBQUEsR0FBQSxDQUFBLFFBQUEsU0FBQSxPQUFBLE9BQUEsT0FBQSxRQUFBLFFBQUEsTUFBQSxHQUFBLFVBQUEsU0FBQSx3QkFBQSxjQUFBLG1CQUFBLGtCQUFBLHVCQUFBLGtCQUFBLG1DQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLG1CQUFBLGNBQUEseUJBQUEsYUFBQSxhQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxzQkFBQSxVQUFBLDBCQUFBLGNBQUEsT0FBQSxRQUFBLFFBQUEsZUFBQSxPQUFBLEdBQUEsQ0FBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLHFCQUFBLFlBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLHdCQUFBLG1CQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSx3QkFBQSxlQUFBLHNCQUFBLE9BQUEsV0FBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsUUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsVUFBQSw0QkFBQSxjQUFBLFNBQUEsUUFBQSxnQkFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHlCQUFBLGFBQUEsYUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHFCQUFBLGFBQUEsWUFBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsVUFBQSxzQkFBQSxjQUFBLFNBQUEsUUFBQSxlQUFBLFNBQUEsY0FBQSxXQUFBLGNBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFlBQUEsVUFBQSxjQUFBLG1CQUFBLFVBQUEsMEJBQUEsb0NBQUEsR0FBQSxDQUFBLE1BQUEsaUJBQUEsR0FBQSxVQUFBLFFBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsdUJBQUEsUUFBQSxRQUFBLFlBQUEsZ0JBQUEsa0JBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxRQUFBLFFBQUEsY0FBQSxnREFBQSxVQUFBLHdCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLE9BQUEsT0FBQSxjQUFBLGNBQUEsdUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFNBQUEsV0FBQSxPQUFBLE9BQUEsY0FBQSxjQUFBLHVCQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxZQUFBLFVBQUEsT0FBQSxPQUFBLGNBQUEsY0FBQSx1QkFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsWUFBQSxXQUFBLE9BQUEsT0FBQSxjQUFBLGNBQUEsdUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFVBQUEsV0FBQSxXQUFBLG1CQUFBLHlDQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxZQUFBLFVBQUEsV0FBQSxvQkFBQSxvQkFBQSxPQUFBLFlBQUEsMEJBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLFFBQUEsVUFBQSxjQUFBLGlCQUFBLDhCQUFBLHlCQUFBLHlCQUFBLGVBQUEsV0FBQSxjQUFBLFVBQUEsc0JBQUEsa0NBQUEsVUFBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLHVCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsaUJBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxtQkFBQSxXQUFBLHFCQUFBLGFBQUEsUUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLGVBQUEsZ0JBQUEsU0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxTQUFBLGdCQUFBLGtCQUFBLGdCQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsVUFBQSw0QkFBQSxPQUFBLGVBQUEsY0FBQSxZQUFBLFVBQUEsUUFBQSxZQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxVQUFBLFVBQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxhQUFBLFdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSx5QkFBQSxXQUFBLFFBQUEsbUJBQUEsdUJBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxVQUFBLGNBQUEsVUFBQSw0QkFBQSx5QkFBQSx5QkFBQSxpQ0FBQSxjQUFBLGFBQUEsV0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsY0FBQSxhQUFBLFdBQUEsaUJBQUEsY0FBQSxhQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsY0FBQSxVQUFBLDRCQUFBLHlCQUFBLHlCQUFBLGlDQUFBLGNBQUEsYUFBQSxXQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxzQkFBQSxTQUFBLGVBQUEsR0FBQSxPQUFBLFNBQUEsY0FBQSxpQ0FBQSx5QkFBQSx5QkFBQSxjQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsV0FBQSxtQkFBQSxhQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsMkJBQUEsbUJBQUEsOEJBQUEsUUFBQSxVQUFBLGdCQUFBLFdBQUEsZUFBQSxRQUFBLGdCQUFBLFNBQUEsVUFBQSw0QkFBQSxhQUFBLG9CQUFBLHFCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSxvQkFBQSxHQUFBLFFBQUEsUUFBQSxxQkFBQSw0QkFBQSxpQ0FBQSxjQUFBLGNBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLHNCQUFBLGdDQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsbUJBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsTUFBQSxrQkFBQSxHQUFBLFFBQUEsUUFBQSxpQkFBQSx3QkFBQSx1QkFBQSxjQUFBLGNBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLHNCQUFBLDRCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsTUFBQSwyQkFBQSxHQUFBLFFBQUEsUUFBQSxtQkFBQSwwQkFBQSx5QkFBQSxjQUFBLGNBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLHNCQUFBLDhCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsTUFBQSx3QkFBQSxHQUFBLFFBQUEsUUFBQSxjQUFBLGNBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLHNCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsY0FBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxNQUFBLHlCQUFBLEdBQUEsUUFBQSxRQUFBLGtCQUFBLGlCQUFBLFVBQUEsc0JBQUEsd0JBQUEseUJBQUEsb0JBQUEsY0FBQSxjQUFBLFdBQUEsYUFBQSxRQUFBLGdCQUFBLFNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsVUFBQSw0QkFBQSxlQUFBLGNBQUEsWUFBQSxVQUFBLG1CQUFBLFFBQUEsWUFBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsWUFBQSw0QkFBQSxRQUFBLGdCQUFBLG1CQUFBLGlCQUFBLFFBQUEsVUFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsWUFBQSw0QkFBQSxlQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsZUFBQSxvQkFBQSxhQUFBLE1BQUEsR0FBQSxVQUFBLGlCQUFBLFVBQUEsNEJBQUEsbUJBQUEsV0FBQSxjQUFBLFNBQUEsU0FBQSxnQkFBQSw2QkFBQSxjQUFBLEdBQUEsaUJBQUEsZUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsVUFBQSxtQkFBQSwrQkFBQSxpQkFBQSxhQUFBLGNBQUEsY0FBQSxXQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLHlCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxtQkFBQSxvQkFBQSxhQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxnQkFBQSxtQkFBQSxPQUFBLGNBQUEsVUFBQSxrQkFBQSxHQUFBLHNCQUFBLDBCQUFBLGVBQUEsMEJBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxRQUFBLHlCQUFBLFdBQUEsUUFBQSxZQUFBLGdCQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxnQkFBQSxtQkFBQSxPQUFBLGNBQUEsVUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFNBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLGdCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsVUFBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGlCQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxhQUFBLFdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLGFBQUEsa0JBQUEsYUFBQSxzQkFBQSxVQUFBLDBCQUFBLHFCQUFBLFVBQUEsVUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLGVBQUEsYUFBQSxRQUFBLEdBQUEsQ0FBQSxTQUFBLHdCQUFBLEdBQUEsY0FBQSxPQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsU0FBQSxPQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsR0FBQSxTQUFBLE9BQUEsR0FBQSxDQUFBLGlCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsY0FBQSxHQUFBLENBQUEsZUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLHVCQUFBLEdBQUEsQ0FBQSxjQUFBLFdBQUEsR0FBQSxVQUFBLFFBQUEsMkJBQUEsOEJBQUEsbUJBQUEsYUFBQSxjQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLFVBQUEsNEJBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsa0JBQUEsZ0JBQUEsUUFBQSxnQkFBQSxrQkFBQSxXQUFBLE1BQUEsR0FBQSxDQUFBLHVCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsZUFBQSxHQUFBLENBQUEsY0FBQSxXQUFBLEdBQUEsVUFBQSxRQUFBLG1CQUFBLCtCQUFBLGlCQUFBLGFBQUEsY0FBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLFVBQUEsdUJBQUEsY0FBQSxZQUFBLFVBQUEsT0FBQSxjQUFBLFlBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLFVBQUEsVUFBQSxPQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxnQkFBQSxTQUFBLGtCQUFBLE1BQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxRQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsU0FBQSxXQUFBLHVCQUFBLEdBQUEsQ0FBQSxxQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLG1CQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsU0FBQSxXQUFBLHlCQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxhQUFBLGtCQUFBLFNBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxNQUFBLDRCQUFBLEdBQUEsVUFBQSxhQUFBLFFBQUEsVUFBQSxjQUFBLFVBQUEsNEJBQUEsbUJBQUEsaUNBQUEscUJBQUEsZUFBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLE1BQUEsMEJBQUEsR0FBQSxVQUFBLGFBQUEsUUFBQSxVQUFBLGNBQUEsbUJBQUEsa0JBQUEsYUFBQSx5QkFBQSxVQUFBLHVCQUFBLHFCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGFBQUEsSUFBQSxHQUFBLFlBQUEsVUFBQSxHQUFBLENBQUEsTUFBQSw4QkFBQSxHQUFBLFVBQUEsYUFBQSxRQUFBLFVBQUEsY0FBQSxnQkFBQSxpQkFBQSxhQUFBLHNCQUFBLHFCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxhQUFBLHVCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSwyQkFBQSxtQkFBQSw4QkFBQSxRQUFBLFVBQUEsZ0JBQUEsV0FBQSxlQUFBLFFBQUEsZ0JBQUEsU0FBQSxVQUFBLDRCQUFBLGFBQUEsb0JBQUEsUUFBQSxxQkFBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLFlBQUEsb0JBQUEsUUFBQSxrQkFBQSxVQUFBLDBCQUFBLG9CQUFBLFFBQUEsVUFBQSxnQkFBQSxxQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsZUFBQSxxQkFBQSxhQUFBLG1CQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLE9BQUEsZ0JBQUEsbUJBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFlBQUEsVUFBQSxXQUFBLG9CQUFBLG9CQUFBLE9BQUEsWUFBQSw0QkFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxXQUFBLFFBQUEseUJBQUEsb0JBQUEseUJBQUEsdUJBQUEsU0FBQSxnQkFBQSxrQkFBQSxvQkFBQSxVQUFBLDRCQUFBLHdCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLG1CQUFBLFdBQUEseUJBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLHdCQUFBLGdCQUFBLFNBQUEsaUJBQUEsR0FBQSxDQUFBLGdCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEseUJBQUEsWUFBQSxVQUFBLFdBQUEsb0JBQUEscUJBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxlQUFBLDJCQUFBLEdBQUEsVUFBQSxlQUFBLFVBQUEsNEJBQUEsbUJBQUEsV0FBQSxjQUFBLFNBQUEsVUFBQSxTQUFBLFNBQUEsZ0JBQUEsZ0NBQUEsY0FBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLFNBQUEsb0JBQUEsR0FBQSxZQUFBLFdBQUEsV0FBQSxvQkFBQSxlQUFBLGFBQUEsYUFBQSx5QkFBQSxpQkFBQSxRQUFBLFVBQUEsV0FBQSxVQUFBLDRCQUFBLHFCQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsZUFBQSw0QkFBQSxHQUFBLFVBQUEsZUFBQSxVQUFBLDRCQUFBLG1CQUFBLFdBQUEsY0FBQSxTQUFBLFVBQUEsU0FBQSxTQUFBLGdCQUFBLGdDQUFBLGNBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxNQUFBLHlCQUFBLEdBQUEsZUFBQSxhQUFBLG9CQUFBLDBCQUFBLDJCQUFBLFFBQUEsUUFBQSxXQUFBLGNBQUEsVUFBQSxzQkFBQSwrQkFBQSxRQUFBLGdCQUFBLFNBQUEsZ0JBQUEsR0FBQSxDQUFBLE1BQUEsMEJBQUEsR0FBQSxlQUFBLGFBQUEsb0JBQUEsMEJBQUEsMkJBQUEsUUFBQSxRQUFBLFdBQUEsY0FBQSxVQUFBLHNCQUFBLCtCQUFBLFFBQUEsZ0JBQUEsU0FBQSxnQkFBQSxHQUFBLENBQUEsTUFBQSx5QkFBQSxHQUFBLGVBQUEsYUFBQSxvQkFBQSwwQkFBQSwyQkFBQSxRQUFBLFFBQUEsV0FBQSxjQUFBLFVBQUEsc0JBQUEsK0JBQUEsUUFBQSxnQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsTUFBQSwwQkFBQSxHQUFBLGVBQUEsYUFBQSxvQkFBQSwwQkFBQSwyQkFBQSxRQUFBLFFBQUEsV0FBQSxjQUFBLFVBQUEsc0JBQUEsK0JBQUEsUUFBQSxnQkFBQSxTQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFlBQUEsZUFBQSxpQkFBQSxlQUFBLGNBQUEsVUFBQSxrQkFBQSxtQkFBQSxnQkFBQSxHQUFBLHNCQUFBLDBCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsUUFBQSx5QkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxlQUFBLGlCQUFBLGVBQUEsY0FBQSxVQUFBLGtCQUFBLG1CQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsc0JBQUEsUUFBQSxlQUFBLGdCQUFBLGtCQUFBLE9BQUEsVUFBQSxXQUFBLFlBQUEsWUFBQSxpQkFBQSxlQUFBLCtCQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFVBQUEsZ0JBQUEsbUJBQUEsT0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxTQUFBLFVBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLG1CQUFBLGlCQUFBLFFBQUEsUUFBQSxXQUFBLFVBQUEsNEJBQUEsZUFBQSxXQUFBLEdBQUEsQ0FBQSxTQUFBLGFBQUEsR0FBQSxhQUFBLGVBQUEseUJBQUEsWUFBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsZ0JBQUEsbUJBQUEsaUJBQUEsVUFBQSw0QkFBQSxjQUFBLFFBQUEsUUFBQSxRQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxXQUFBLHlCQUFBLGFBQUEsY0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsaUJBQUEsWUFBQSxzQkFBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxrQkFBQSxnQkFBQSxxQkFBQSxXQUFBLEdBQUEsQ0FBQSxjQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEsa0JBQUEsZ0JBQUEseUJBQUEsNkJBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLFlBQUEsb0JBQUEsd0JBQUEsbUJBQUEsZUFBQSxhQUFBLFVBQUEsUUFBQSxXQUFBLGFBQUEsbUNBQUEsc0JBQUEsdUJBQUEscUJBQUEsVUFBQSw0QkFBQSxhQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxZQUFBLGFBQUEsbUJBQUEsU0FBQSxZQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsZUFBQSxXQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxVQUFBLFFBQUEsY0FBQSxrQkFBQSxXQUFBLGFBQUEsZUFBQSxhQUFBLFVBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxxQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLG9CQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLG9CQUFBLGFBQUEsa0JBQUEsYUFBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSx5QkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsYUFBQSx5QkFBQSxhQUFBLGtCQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxVQUFBLFFBQUEsY0FBQSxrQkFBQSxXQUFBLGFBQUEsZUFBQSxhQUFBLFVBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsWUFBQSxlQUFBLGlCQUFBLGVBQUEsY0FBQSxVQUFBLGtCQUFBLG1CQUFBLGdCQUFBLEdBQUEsc0JBQUEsb0JBQUEsbUJBQUEsMEJBQUEsR0FBQSxDQUFBLEdBQUEseUJBQUEsV0FBQSxhQUFBLEdBQUEsQ0FBQSxtQkFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLGtCQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLGtCQUFBLGFBQUEsa0JBQUEsYUFBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxpQkFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsYUFBQSxpQkFBQSxhQUFBLGtCQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxjQUFBLFFBQUEsZ0JBQUEsbUJBQUEsVUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsZ0JBQUEsUUFBQSxnQkFBQSxnQkFBQSxHQUFBLENBQUEscUJBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsY0FBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsYUFBQSxRQUFBLGdCQUFBLFNBQUEsaUNBQUEsU0FBQSxRQUFBLFVBQUEsV0FBQSxjQUFBLGVBQUEsYUFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxlQUFBLFdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGFBQUEsR0FBQSxDQUFBLFNBQUEsc0JBQUEsR0FBQSxPQUFBLHlCQUFBLHdCQUFBLGNBQUEsZ0JBQUEsR0FBQSxDQUFBLGlCQUFBLElBQUEsR0FBQSxPQUFBLE9BQUEseUJBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGFBQUEsUUFBQSxnQkFBQSxTQUFBLGlDQUFBLFNBQUEsUUFBQSxVQUFBLFdBQUEsY0FBQSxlQUFBLGFBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLFNBQUEsR0FBQSxDQUFBLGVBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSx5QkFBQSx1Q0FBQSxhQUFBLGlDQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsd0JBQUEsUUFBQSxHQUFBLENBQUEsYUFBQSxJQUFBLEdBQUEsT0FBQSxPQUFBLHdCQUFBLHFDQUFBLEdBQUEsQ0FBQSxTQUFBLHNCQUFBLEdBQUEsT0FBQSx5QkFBQSx3QkFBQSxjQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsY0FBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLDJCQUFBLG1CQUFBLDhCQUFBLFFBQUEsVUFBQSxnQkFBQSxXQUFBLGVBQUEsUUFBQSxnQkFBQSxTQUFBLFVBQUEsNEJBQUEsYUFBQSxvQkFBQSxVQUFBLHFCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGdCQUFBLFNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxRQUFBLFFBQUEsZ0JBQUEsbUJBQUEsUUFBQSxnQkFBQSxrQkFBQSxpQkFBQSxhQUFBLHdCQUFBLEdBQUEsQ0FBQSxnQkFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxTQUFBLEdBQUEsZUFBQSxhQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLEdBQUEsUUFBQSxRQUFBLDJCQUFBLDhCQUFBLG1CQUFBLFdBQUEsYUFBQSxjQUFBLFVBQUEsNEJBQUEsY0FBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxlQUFBLElBQUEsR0FBQSxPQUFBLEtBQUEsR0FBQSxDQUFBLGNBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsTUFBQSw2QkFBQSxHQUFBLFFBQUEsUUFBQSxtQkFBQSwrQkFBQSxpQkFBQSxXQUFBLGFBQUEsY0FBQSxjQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxlQUFBLGdCQUFBLGdCQUFBLEdBQUEsQ0FBQSxNQUFBLDZCQUFBLEdBQUEsUUFBQSxRQUFBLG1CQUFBLCtCQUFBLGlCQUFBLFdBQUEsYUFBQSxjQUFBLGNBQUEsUUFBQSxnQkFBQSxrQkFBQSxTQUFBLGVBQUEsZ0JBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxzQkFBQSxJQUFBLEdBQUEsT0FBQSxLQUFBLEdBQUEsQ0FBQSxNQUFBLDRCQUFBLEdBQUEsVUFBQSxVQUFBLG1CQUFBLCtCQUFBLGlCQUFBLGFBQUEsY0FBQSxrQkFBQSxRQUFBLGdCQUFBLGtCQUFBLFNBQUEsYUFBQSwwQkFBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLGVBQUEsdUJBQUEsR0FBQSxDQUFBLE1BQUEsNEJBQUEsR0FBQSxVQUFBLFVBQUEsbUJBQUEsK0JBQUEsaUJBQUEsYUFBQSxjQUFBLGtCQUFBLFFBQUEsZ0JBQUEsa0JBQUEsU0FBQSxhQUFBLDBCQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsZ0JBQUEsSUFBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsaUJBQUEsSUFBQSxHQUFBLE9BQUEsT0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEseUJBQUEsZUFBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEseUJBQUEsTUFBQSxHQUFBLENBQUEsTUFBQSx5QkFBQSxHQUFBLFdBQUEseUJBQUEsMkJBQUEsYUFBQSxjQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsU0FBQSxrQkFBQSxRQUFBLG9CQUFBLEdBQUEsQ0FBQSxNQUFBLHlCQUFBLEdBQUEsV0FBQSx5QkFBQSwyQkFBQSxhQUFBLGNBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsZUFBQSwyQkFBQSxHQUFBLGVBQUEsVUFBQSw0QkFBQSxXQUFBLFFBQUEsUUFBQSxXQUFBLG1CQUFBLDZCQUFBLGdCQUFBLFFBQUEsYUFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxRQUFBLHNCQUFBLHFCQUFBLFdBQUEsV0FBQSw0QkFBQSxjQUFBLFVBQUEsMEJBQUEsa0JBQUEsR0FBQSxPQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsdUJBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUN2SC9CLE1BQUEsaUNBQUEsR0FBQSxzQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBT0EsTUFBQSxpQ0FBQSxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUE7QUFvQ0EsTUFBQSxpQ0FBQSxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUE7QUFvQ0EsTUFBQSxpQ0FBQSxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUE7QUFvQ0EsTUFBQSxpQ0FBQSxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUE7QUFtQ0EsTUFBQSxpQ0FBQSxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUE7QUF1Q0EsTUFBQSxpQ0FBQSxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUEsRUFBNkIsR0FBQSxzQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBLEVBbUJHLEdBQUEsc0NBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQSxFQWdCQyxHQUFBLHNDQUFBLElBQUEsR0FBQSxPQUFBLENBQUE7QUFzQ2pDLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBc0RBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLElBQUEsT0FBQSxFQUFBO0FBK0ZBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBaUVBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBbUNBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBbUNBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLElBQUEsT0FBQSxFQUFBO0FBc0dBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBbUZBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLElBQUEsT0FBQSxFQUFBO0FBa0NBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFFSSxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUEwTCxJQUFBLE9BQUEsRUFBQTtBQUlsTCxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0osTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNkQsSUFBQSxNQUFBLEVBQUE7QUFFckQsTUFBQSxvQkFBQSxJQUFBLGlCQUFBO0FBQ0osTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFDSSxNQUFBLHdCQUFBLFNBQUEsU0FBQSxrREFBQTtBQUFBLGVBQVMsSUFBQSxrQkFBa0Isc0JBQXNCO01BQUMsQ0FBQTtBQUtsRCxNQUFBLGlDQUFBLElBQUEsdUNBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQSxFQUE0QyxJQUFBLHVDQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUE7QUFLaEQsTUFBQSwwQkFBQSxFQUFTO0FBR2IsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFpRCxJQUFBLE9BQUEsRUFBQSxFQUs4QixJQUFBLE9BQUEsRUFBQTtBQUduRSxNQUFBLGlDQUFBLElBQUEsdUNBQUEsR0FBQSxHQUFBLFFBQUEsRUFBQSxFQUFtQixJQUFBLHVDQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUEsRUFFd0IsSUFBQSx1Q0FBQSxHQUFBLEdBQUEsUUFBQSxFQUFBO0FBTTNDLE1BQUEsNEJBQUEsSUFBQSxNQUFBLEVBQUE7QUFDSSxNQUFBLG9CQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBO0FBRUEsTUFBQSxpQ0FBQSxJQUFBLHVDQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUE7QUFRSixNQUFBLDBCQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUE2SixJQUFBLE9BQUEsRUFBQSxFQUU3SCxJQUFBLFVBQUEsRUFBQTtBQUNNLE1BQUEsd0JBQUEsU0FBQSxTQUFBLGtEQUFBO0FBQUEsZUFBUyxJQUFBLGdCQUFBO01BQWlCLENBQUE7QUFDcEQsTUFBQSxpQ0FBQSxJQUFBLHVDQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBc0IsSUFBQSx1Q0FBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBS3RCLE1BQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFJSSxNQUFBLG9CQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBLEVBQU87QUFHWCxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksTUFBQSxvQkFBQSxFQUFBO0FBQ0osTUFBQSwwQkFBQSxFQUFNO0FBR1YsTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNEIsSUFBQSxPQUFBLEVBQUE7O0FBS3BCLE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7O0FBQ0EsTUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUNJLE1BQUEsb0JBQUEsRUFBQTtBQUNKLE1BQUEsMEJBQUEsRUFBTztBQUdYLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDSSxNQUFBLG9CQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBLEVBQU07QUFHVixNQUFBLGlDQUFBLElBQUEsdUNBQUEsR0FBQSxDQUFBO0FBZUEsTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNEIsSUFBQSxVQUFBLEVBQUE7QUFDTyxNQUFBLHdCQUFBLFNBQUEsU0FBQSxrREFBQTtBQUFBLGVBQVMsSUFBQSxrQkFBQTtNQUFtQixDQUFBO0FBQ3ZELE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7O0FBQ0ksTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTs7QUFJQSxNQUFBLDRCQUFBLElBQUEsUUFBQSxFQUFBO0FBQ0ksTUFBQSxvQkFBQSxFQUFBO0FBQ0osTUFBQSwwQkFBQSxFQUFPLEVBQ0w7QUFHVixNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksTUFBQSxvQkFBQSxJQUFBLHdCQUFBO0FBQ0osTUFBQSwwQkFBQSxFQUFNO0FBR1YsTUFBQSx1QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0MsSUFBQSxPQUFBLEVBQUE7O0FBRWhDLE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDQSxNQUFBLGlDQUFBLElBQUEsdUNBQUEsR0FBQSxHQUFBLFFBQUEsRUFBQSxFQUFtQixJQUFBLHVDQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUE7QUFLdkIsTUFBQSwwQkFBQTs7QUFFQSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBO0FBQ0ksTUFBQSxvQkFBQSxJQUFBLDJDQUFBO0FBQ0osTUFBQSwwQkFBQSxFQUFNLEVBQ0osRUFDSjtBQUdWLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxHQUFBLEdBQUEsT0FBQSxFQUFBO0FBUUosTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBcUcsSUFBQSxPQUFBLEVBQUE7QUFDVCxNQUFBLG9CQUFBLElBQUEsY0FBQTtBQUFZLE1BQUEsMEJBQUE7QUFDcEcsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUVJLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLENBQUE7QUFtQkEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUE0QixJQUFBLFVBQUEsRUFBQTtBQUNTLE1BQUEsd0JBQUEsU0FBQSxTQUFBLGtEQUFBO0FBQUEsZUFBUyxJQUFBLGFBQUE7TUFBYyxDQUFBO0FBQ3BELE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxHQUFBLEdBQUEsWUFBQSxFQUFBLEVBQW1CLElBQUEsdUNBQUEsR0FBQSxHQUFBLFlBQUEsRUFBQTtBQUtuQixNQUFBLG9CQUFBLEVBQUE7QUFDSixNQUFBLDBCQUFBLEVBQVM7QUFHYixNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBRUEsTUFBQSxpQ0FBQSxJQUFBLHVDQUFBLEdBQUEsQ0FBQTtBQWVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNEIsSUFBQSxVQUFBLEVBQUE7QUFDTSxNQUFBLHdCQUFBLFNBQUEsU0FBQSxrREFBQTtBQUFBLGVBQVMsSUFBQSxlQUFBO01BQWdCLENBQUE7O0FBQ25ELE1BQUEsdUJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDQSxNQUFBLG9CQUFBLElBQUEsY0FBQTtBQUNKLE1BQUEsMEJBQUEsRUFBUzs7QUFHYixNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUE0QixJQUFBLFVBQUEsRUFBQTtBQUNHLE1BQUEsd0JBQUEsU0FBQSxTQUFBLGtEQUFBO0FBQUEsZUFBUyxJQUFBLE9BQUE7TUFBUSxDQUFBOztBQUN4QyxNQUFBLHVCQUFBLElBQUEsT0FBQSxFQUFBOztBQUNBLE1BQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBK0IsTUFBQSxvQkFBQSxJQUFBLFNBQUE7QUFBTyxNQUFBLDBCQUFBLEVBQU8sRUFDeEM7QUFHYixNQUFBLGlDQUFBLElBQUEsdUNBQUEsR0FBQSxFQUFBO0FBbUJBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxHQUFBLENBQUE7QUFTSixNQUFBLDBCQUFBLEVBQU0sRUFDSjtBQUlWLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBc0ZBLE1BQUEsaUNBQUEsSUFBQSx1Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBdUJBLE1BQUEsaUNBQUEsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsT0FBQSxFQUFBO0FBaUJBLE1BQUEsaUNBQUEsS0FBQSx3Q0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBZ0RBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFFbUUsS0FBQSxPQUFBLEVBQUEsRUFFOUIsS0FBQSxPQUFBLEVBQUEsRUFFd0YsS0FBQSxPQUFBLEVBQUE7QUFHakgsTUFBQSx1QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUNKLE1BQUEsMEJBQUE7QUFFQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQWtFLEtBQUEsTUFBQSxFQUFBO0FBRTFELE1BQUEsb0JBQUEsS0FBQSx3QkFBQTtBQUNKLE1BQUEsMEJBQUE7QUFFQSxNQUFBLDRCQUFBLEtBQUEsVUFBQSxFQUFBO0FBQ0ksTUFBQSx3QkFBQSxTQUFBLFNBQUEsbURBQUE7QUFBQSxlQUFTLElBQUEsa0JBQWtCLHNCQUFzQjtNQUFDLENBQUE7QUFLbEQsTUFBQSxpQ0FBQSxLQUFBLHdDQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBNEMsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBS2hELE1BQUEsMEJBQUEsRUFBUztBQUdiLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFJMkUsS0FBQSxPQUFBLEVBQUEsRUFFM0IsS0FBQSxLQUFBLEVBQ25DLEtBQUEsT0FBQSxFQUFBO0FBQ29ELE1BQUEsb0JBQUEsR0FBQTs7QUFBcUUsTUFBQSw0QkFBQSxLQUFBLFFBQUEsRUFBQTtBQUE0QyxNQUFBLG9CQUFBLEtBQUEsS0FBQTtBQUFHLE1BQUEsMEJBQUEsRUFBTztBQUNoTCxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0ksTUFBQSxvQkFBQSxHQUFBOztBQUNKLE1BQUEsMEJBQUEsRUFBTTtBQUVWLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBd0IsS0FBQSxPQUFBLEVBQUE7QUFDdUIsTUFBQSxvQkFBQSxLQUFBLGFBQUE7QUFBVyxNQUFBLDBCQUFBO0FBQ3RELE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUE7QUFBdUMsTUFBQSxvQkFBQSxHQUFBO0FBQWlELE1BQUEsMEJBQUEsRUFBTSxFQUM1RixFQUNKO0FBR1YsTUFBQSxpQ0FBQSxLQUFBLHdDQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUFRSixNQUFBLDBCQUFBO0FBRUEsTUFBQSw0QkFBQSxLQUFBLE9BQUEsRUFBQSxFQUF3RyxLQUFBLE1BQUEsRUFBQTtBQUVyQixNQUFBLG9CQUFBLEtBQUEsZ0JBQUE7QUFBYyxNQUFBLDBCQUFBO0FBRTdGLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBbUQsS0FBQSxPQUFBLEVBQUEsRUFFZCxLQUFBLE9BQUEsRUFBQTtBQUNtQixNQUFBLG9CQUFBLEtBQUEsZ0NBQUE7QUFBOEIsTUFBQSwwQkFBQTtBQUM5RSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQW9DLEtBQUEsVUFBQSxFQUFBO0FBQ0EsTUFBQSx3QkFBQSxTQUFBLFNBQUEsbURBQUE7QUFBQSxlQUFTLElBQUEsa0JBQUE7TUFBbUIsQ0FBQTs7QUFDeEQsTUFBQSx1QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUNBLE1BQUEsb0JBQUEsS0FBQSxXQUFBO0FBQ0osTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsVUFBQSxFQUFBO0FBQXNDLE1BQUEsd0JBQUEsU0FBQSxTQUFBLG1EQUFBO0FBQUEsZUFBUyxJQUFBLG1CQUFBO01BQW9CLENBQUE7O0FBQy9ELE1BQUEsdUJBQUEsS0FBQSxPQUFBLEVBQUE7QUFDQSxNQUFBLG9CQUFBLEtBQUEsaUJBQUE7QUFDSixNQUFBLDBCQUFBLEVBQVMsRUFDUDs7QUFHVixNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBLEVBQWlDLEtBQUEsT0FBQSxFQUFBO0FBQ21CLE1BQUEsb0JBQUEsS0FBQSw4QkFBQTtBQUE0QixNQUFBLDBCQUFBO0FBQzVFLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEVBQUEsRUFBb0MsS0FBQSxVQUFBLEdBQUE7QUFDQSxNQUFBLHdCQUFBLFNBQUEsU0FBQSxtREFBQTtBQUFBLGVBQVMsSUFBQSxhQUFBO01BQWMsQ0FBQTs7QUFDbkQsTUFBQSx1QkFBQSxLQUFBLE9BQUEsRUFBQTtBQUNBLE1BQUEsb0JBQUEsS0FBQSxXQUFBO0FBQ0osTUFBQSwwQkFBQTs7QUFDQSxNQUFBLDRCQUFBLEtBQUEsU0FBQSxHQUFBLEVBQTZSLEtBQUEsU0FBQSxHQUFBO0FBQ3RRLE1BQUEsd0JBQUEsVUFBQSxTQUFBLGlEQUFBLFFBQUE7QUFBQSxlQUFVLElBQUEsZUFBQSxNQUFBO01BQXNCLENBQUE7QUFBbkQsTUFBQSwwQkFBQTs7QUFDQSxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSxvQkFBQSxLQUFBLGVBQUE7QUFDSixNQUFBLDBCQUFBLEVBQVEsRUFDTixFQUNKO0FBR1YsTUFBQSxpQ0FBQSxLQUFBLHdDQUFBLElBQUEsR0FBQSxPQUFBLEdBQUE7QUFzQ0osTUFBQSwwQkFBQTs7QUFFQSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQXNJLEtBQUEsT0FBQSxFQUFBLEVBRWhFLEtBQUEsTUFBQSxFQUFBO0FBRTlELE1BQUEsb0JBQUEsS0FBQSx1QkFBQTtBQUNBLE1BQUEsMEJBQUE7QUFFQSxNQUFBLDRCQUFBLEtBQUEsVUFBQSxHQUFBO0FBQ0EsTUFBQSx3QkFBQSxTQUFBLFNBQUEsbURBQUE7QUFBQSxlQUFTLElBQUEsa0JBQWtCLHFCQUFxQjtNQUFDLENBQUE7QUFLakQsTUFBQSxpQ0FBQSxLQUFBLHdDQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBMkMsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBSzNDLE1BQUEsMEJBQUEsRUFBUztBQUdiLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUEsRUFJc0UsS0FBQSxPQUFBLEdBQUEsRUFFdUIsS0FBQSxVQUFBLEdBQUE7QUFDekQsTUFBQSx3QkFBQSxTQUFBLFNBQUEsbURBQUE7QUFBQSxlQUFTLElBQUEsWUFBWSxRQUFRO01BQUMsQ0FBQTtBQU10RCxNQUFBLG9CQUFBLEdBQUE7QUFDSixNQUFBLDBCQUFBO0FBQ0EsTUFBQSw0QkFBQSxLQUFBLFVBQUEsR0FBQTtBQUE2QixNQUFBLHdCQUFBLFNBQUEsU0FBQSxtREFBQTtBQUFBLGVBQVMsSUFBQSxZQUFZLFNBQVM7TUFBQyxDQUFBO0FBTXhELE1BQUEsb0JBQUEsR0FBQTtBQUNKLE1BQUEsMEJBQUEsRUFBUztBQUViLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDSSxNQUFBLGlDQUFBLEtBQUEsd0NBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQSxFQUErQixLQUFBLHdDQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFtQm5DLE1BQUEsMEJBQUE7QUFFQSxNQUFBLGlDQUFBLEtBQUEsd0NBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQTtBQWVBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDSSxNQUFBLGlDQUFBLEtBQUEsd0NBQUEsR0FBQSxDQUFBO0FBOEVBLE1BQUEsaUNBQUEsS0FBQSx3Q0FBQSxHQUFBLENBQUE7QUFrRkosTUFBQSwwQkFBQSxFQUFNO0FBRVYsTUFBQSxpQ0FBQSxLQUFBLHdDQUFBLEdBQUEsR0FBQSxPQUFBLEdBQUE7QUFRSixNQUFBLDBCQUFBLEVBQU07QUFHVixNQUFBLDRCQUFBLEtBQUEsT0FBQSxHQUFBLEVBQTJCLEtBQUEsT0FBQSxHQUFBLEVBQ3dILEtBQUEsT0FBQSxFQUFBLEVBRXpFLEtBQUEsTUFBQSxFQUFBOztBQUUxRCxNQUFBLHVCQUFBLEtBQUEsT0FBQSxHQUFBO0FBQ0EsTUFBQSxvQkFBQSxLQUFBLFdBQUE7O0FBQVEsTUFBQSw0QkFBQSxLQUFBLFFBQUEsR0FBQTtBQUF3RCxNQUFBLG9CQUFBLEdBQUE7QUFBbUMsTUFBQSwwQkFBQSxFQUFPO0FBRzlHLE1BQUEsNEJBQUEsS0FBQSxVQUFBLEdBQUE7QUFDSSxNQUFBLHdCQUFBLFNBQUEsU0FBQSxtREFBQTtBQUFBLGVBQVMsSUFBQSxrQkFBa0IsU0FBUztNQUFDLENBQUE7QUFLckMsTUFBQSxpQ0FBQSxLQUFBLHdDQUFBLEdBQUEsR0FBQSxZQUFBLEVBQUEsRUFBNEIsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsWUFBQSxFQUFBO0FBS2hDLE1BQUEsMEJBQUEsRUFBUztBQUdiLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUEsRUFBOEMsS0FBQSxPQUFBLEdBQUEsRUFLaUIsS0FBQSxPQUFBLEdBQUE7QUFHbkUsTUFBQSw4QkFBQSxLQUFBLGdDQUFBLElBQUEsSUFBQSxPQUFBLEtBQUEsVUFBQTtBQThEQSxNQUFBLGlDQUFBLEtBQUEsd0NBQUEsR0FBQSxHQUFBLE9BQUEsR0FBQTtBQUNKLE1BQUEsMEJBQUEsRUFBTTtBQUdNLE1BQUEsaUNBQUEsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsT0FBQSxFQUFBO0FBUUosTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsS0FBQSxPQUFBLEdBQUE7QUFDSSxNQUFBLGlDQUFBLEtBQUEsd0NBQUEsSUFBQSxHQUFBLE9BQUEsR0FBQSxFQUFrQixLQUFBLHdDQUFBLEdBQUEsQ0FBQSxFQWlDd0IsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsVUFBQSxHQUFBLEVBT0wsS0FBQSx3Q0FBQSxHQUFBLEdBQUEsT0FBQSxHQUFBO0FBbUJ6QyxNQUFBLDBCQUFBLEVBQU0sRUFDSixFQUNKLEVBQ0E7OztBQXR1RFYsTUFBQSwyQkFBQSxJQUFBLE9BQUEsT0FBQSxNQUFBLGVBQUEsQ0FBQSxJQUFBLE9BQUEsU0FBQSxLQUFBLENBQUEsSUFBQSxVQUFBLEtBQUEsQ0FBQSxJQUFBLE9BQUEsYUFBQSxLQUFBLENBQUEsSUFBQSxPQUFBLFlBQUEsS0FBQSxDQUFBLElBQUEsT0FBQSxXQUFBLEtBQUEsQ0FBQSxJQUFBLE9BQUEsZ0JBQUEsSUFBQSxJQUFBLEVBQUE7QUFPQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGNBQUEsSUFBQSxJQUFBLEVBQUE7QUFvQ0EsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxlQUFBLElBQUEsSUFBQSxFQUFBO0FBb0NBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsYUFBQSxJQUFBLElBQUEsRUFBQTtBQW9DQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGdCQUFBLElBQUEsSUFBQSxFQUFBO0FBbUNBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsZUFBQSxJQUFBLElBQUEsRUFBQTtBQXVDQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLE9BQUEsYUFBQSxJQUFBLElBQUEsSUFBQSxPQUFBLFdBQUEsSUFBQSxJQUFBLElBQUEsT0FBQSxZQUFBLElBQUEsSUFBQSxJQUFBLE9BQUEsZ0JBQUEsSUFBQSxJQUFBLEVBQUE7QUF5RUEsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGdCQUFBLElBQUEsS0FBQSxFQUFBO0FBc0RBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsWUFBQSxJQUFBLEtBQUEsRUFBQTtBQStGQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGVBQUEsSUFBQSxLQUFBLEVBQUE7QUFpRUEsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxhQUFBLElBQUEsS0FBQSxFQUFBO0FBbUNBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsZUFBQSxJQUFBLEtBQUEsRUFBQTtBQW1DQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGtCQUFBLElBQUEsS0FBQSxFQUFBO0FBc0dBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsaUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFtRkEsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxpQkFBQSxJQUFBLEtBQUEsRUFBQTtBQTBDaUIsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx3QkFBQSxPQUFBLElBQUEsY0FBQSxPQUFBLEVBQUEsU0FBQSwwQkFBQTtBQVdELE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsa0JBQUEsQ0FBQSxJQUFBLFdBQUEsRUFBQSxzQkFBQSxDQUFBLEVBQThELHlCQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLENBQUE7QUFFOUQsTUFBQSx3QkFBQSxTQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLElBQUEsa0JBQUEsYUFBQTtBQUNBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLElBQUEsS0FBQSxFQUFBO0FBVUksTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxXQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLENBQUEsRUFBc0QsY0FBQSxJQUFBLFdBQUEsRUFBQSxzQkFBQSxDQUFBLEVBQ0csZUFBQSxJQUFBLFdBQUEsRUFBQSxzQkFBQSxDQUFBLEVBQ0MsdUJBQUEsSUFBQSxXQUFBLEVBQUEsc0JBQUEsQ0FBQTtBQUkxRCxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsVUFBQSxJQUFBLEtBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxXQUFBLEtBQUEsRUFBQTtBQVNJLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsS0FBQSxJQUFBLE9BQUEsVUFBQSxHQUFBLFlBQUEsSUFBQSxjQUFBLE9BQUEsRUFBQSxpQkFBQSxHQUFBO0FBR0osTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxPQUFBLGNBQUEsSUFBQSxLQUFBLEVBQUE7QUFjUSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsYUFBQSxJQUFBLEtBQUEsRUFBQTtBQU1JLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEscUJBQUEsSUFBQSxhQUFBLENBQUEsRUFBMEMsbUJBQUEsQ0FBQSxJQUFBLGFBQUEsQ0FBQSxFQUNELCtCQUFBLENBQUEsSUFBQSxhQUFBLENBQUE7QUFFekMsTUFBQSx1QkFBQTtBQUFBLE1BQUEsZ0NBQUEsS0FBQSxJQUFBLE9BQUEsR0FBQSxHQUFBO0FBS0osTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxLQUFBLElBQUEsYUFBQSxJQUFBLFlBQUEsZ0JBQUEsR0FBQTtBQVFJLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEscUJBQUEsQ0FBQSxJQUFBLE9BQUEsVUFBQSxHQUFBLFdBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxZQUFBLFNBQUEsRUFBcUcsa0JBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxZQUFBLFNBQUEsRUFDbkMsbUJBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxZQUFBLFFBQUE7QUFJbEUsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxLQUFBLElBQUEsT0FBQSxVQUFBLEdBQUEsWUFBQSxZQUFBLFlBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxXQUFBLFdBQUEsR0FBQTtBQUtKLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsS0FBQSxDQUFBLElBQUEsT0FBQSxVQUFBLEdBQUEsV0FBQSxJQUFBLE9BQUEsVUFBQSxHQUFBLFlBQUEsWUFBQSw0Q0FBQSxnQ0FBQSxHQUFBO0FBSVIsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxPQUFBLGNBQUEsSUFBQSxLQUFBLEVBQUE7QUFxQmdCLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsc0JBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxrQkFBQSxLQUFBLENBQUEsRUFBeUUsMEJBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxrQkFBQSxNQUFBLENBQUE7QUFHckQsTUFBQSx1QkFBQTtBQUFBLE1BQUEseUJBQUEsb0JBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxrQkFBQSxLQUFBLENBQUE7QUFDcEIsTUFBQSx1QkFBQTtBQUFBLE1BQUEsZ0NBQUEsS0FBQSxJQUFBLE9BQUEsVUFBQSxHQUFBLGtCQUFBLEdBQUEsR0FBQTtBQWF5QixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLGlCQUFBLElBQUEsVUFBQSxLQUFBLElBQUEsVUFBQSxDQUFBLEVBQWtELHlCQUFBLENBQUEsSUFBQSxVQUFBLEtBQUEsQ0FBQSxJQUFBLFVBQUEsQ0FBQTtBQUVuRixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsVUFBQSxJQUFBLEtBQUEsRUFBQTtBQWNoQixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLElBQUEsS0FBQSxFQUFBO0FBY0ksTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxDQUFBLElBQUEsVUFBQSxLQUFBLENBQUEsSUFBQSxPQUFBLFNBQUEsSUFBQSxLQUFBLEVBQUE7QUFxQlEsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLFVBQUEsSUFBQSxLQUFBLEVBQUE7QUFLQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLGdDQUFBLEtBQUEsSUFBQSxVQUFBLElBQUEsV0FBQSxZQUFBLEdBQUE7QUFNUixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsT0FBQSxjQUFBLElBQUEsS0FBQSxFQUFBO0FBK0JBLE1BQUEsdUJBQUEsRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxPQUFBLGNBQUEsSUFBQSxLQUFBLEVBQUE7QUFtQkEsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxPQUFBLGNBQUEsS0FBQSxDQUFBLElBQUEsVUFBQSxLQUFBLENBQUEsSUFBQSxPQUFBLFNBQUEsSUFBQSxLQUFBLEVBQUE7QUFjWixNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGtCQUFBLElBQUEsS0FBQSxFQUFBO0FBc0ZBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsT0FBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBdUJBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsVUFBQSxLQUFBLENBQUEsSUFBQSxPQUFBLFNBQUEsSUFBQSxNQUFBLEVBQUE7QUFpQkEsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxtQkFBQSxJQUFBLE1BQUEsRUFBQTtBQWlESSxNQUFBLHVCQUFBO0FBQUEsTUFBQSx5QkFBQSxjQUFBLElBQUEsVUFBQSxLQUFBLElBQUEsT0FBQSxTQUFBLENBQUEsRUFBcUQsdUJBQUEsSUFBQSxVQUFBLEtBQUEsSUFBQSxPQUFBLFNBQUEsQ0FBQTtBQVF4QyxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLE9BQUEsSUFBQSxjQUFBLE9BQUEsRUFBQSxTQUFBLDBCQUFBO0FBV0QsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxrQkFBQSxDQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLENBQUEsRUFBOEQseUJBQUEsSUFBQSxXQUFBLEVBQUEsc0JBQUEsQ0FBQTtBQUU5RCxNQUFBLHdCQUFBLFNBQUEsSUFBQSxXQUFBLEVBQUEsc0JBQUEsSUFBQSxvQkFBQSxlQUFBO0FBQ0EsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxXQUFBLEVBQUEsc0JBQUEsSUFBQSxNQUFBLEdBQUE7QUFTQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLFdBQUEsSUFBQSxXQUFBLEVBQUEsc0JBQUEsQ0FBQSxFQUFzRCxjQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLENBQUEsRUFDRyxlQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLENBQUEsRUFDQyx1QkFBQSxJQUFBLFdBQUEsRUFBQSxzQkFBQSxDQUFBO0FBS0QsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxJQUFBLHlCQUFBLEtBQUEsTUFBQSxJQUFBLE9BQUEsVUFBQSxHQUFBLFVBQUEsS0FBQSxLQUFBLE9BQUEsR0FBQSxHQUFBO0FBRWpELE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsS0FBQSx5QkFBQSxLQUFBLEtBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxVQUFBLENBQUEsR0FBQSxRQUFBO0FBS21DLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsSUFBQSxJQUFBLE9BQUEsVUFBQSxHQUFBLFdBQUEsTUFBQSxVQUFBO0FBS25ELE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsV0FBQSxFQUFBLHNCQUFBLElBQUEsTUFBQSxFQUFBO0FBaUNxRSxNQUFBLHVCQUFBLEVBQUE7QUFBQSxNQUFBLHdCQUFBLFlBQUEsSUFBQSxpQkFBQSxDQUFBO0FBS2dGLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsd0JBQUEsWUFBQSxJQUFBLGlCQUFBLENBQUE7QUFRckosTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGlCQUFBLElBQUEsTUFBQSxFQUFBO0FBa0RJLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsa0JBQUEsQ0FBQSxJQUFBLFdBQUEsRUFBQSxxQkFBQSxDQUFBLEVBQTZELHlCQUFBLElBQUEsV0FBQSxFQUFBLHFCQUFBLENBQUE7QUFFN0QsTUFBQSx3QkFBQSxTQUFBLElBQUEsV0FBQSxFQUFBLHFCQUFBLElBQUEsbUJBQUEsY0FBQTtBQUNBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsV0FBQSxFQUFBLHFCQUFBLElBQUEsTUFBQSxHQUFBO0FBU0EsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxXQUFBLElBQUEsV0FBQSxFQUFBLHFCQUFBLENBQUEsRUFBcUQsY0FBQSxJQUFBLFdBQUEsRUFBQSxxQkFBQSxDQUFBLEVBQ0csZUFBQSxJQUFBLFdBQUEsRUFBQSxxQkFBQSxDQUFBLEVBQ0MsdUJBQUEsSUFBQSxXQUFBLEVBQUEscUJBQUEsQ0FBQTtBQU03QyxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLG1CQUFBLElBQUEsU0FBQSxNQUFBLFFBQUEsRUFBaUQsaUJBQUEsSUFBQSxTQUFBLE1BQUEsUUFBQSxFQUNGLHlCQUFBLElBQUEsU0FBQSxNQUFBLFFBQUEsRUFDUSx5QkFBQSxJQUFBLFNBQUEsTUFBQSxRQUFBO0FBRTNELE1BQUEsdUJBQUE7QUFBQSxNQUFBLGdDQUFBLGFBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxVQUFBLEdBQUEsSUFBQTtBQUlJLE1BQUEsdUJBQUE7QUFBQSxNQUFBLHlCQUFBLG1CQUFBLElBQUEsU0FBQSxNQUFBLFNBQUEsRUFBa0QsaUJBQUEsSUFBQSxTQUFBLE1BQUEsU0FBQSxFQUNGLHlCQUFBLElBQUEsU0FBQSxNQUFBLFNBQUEsRUFDUSx5QkFBQSxJQUFBLFNBQUEsTUFBQSxTQUFBO0FBRTVELE1BQUEsdUJBQUE7QUFBQSxNQUFBLGdDQUFBLGNBQUEsSUFBQSxPQUFBLFVBQUEsR0FBQSxTQUFBLFVBQUEsR0FBQSxJQUFBO0FBSUosTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLFNBQUEsTUFBQSxXQUFBLE1BQUEsR0FBQTtBQXFCSixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsT0FBQSxjQUFBLElBQUEsTUFBQSxFQUFBO0FBZ0JJLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxTQUFBLE1BQUEsV0FBQSxNQUFBLEVBQUE7QUE4RUEsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxTQUFBLE1BQUEsWUFBQSxNQUFBLEVBQUE7QUFvRlIsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxXQUFBLEVBQUEscUJBQUEsSUFBQSxNQUFBLEVBQUE7QUFpQndFLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsS0FBQSxJQUFBLE9BQUEsWUFBQSxHQUFBLFVBQUE7QUFNaEUsTUFBQSx1QkFBQTtBQUFBLE1BQUEseUJBQUEsa0JBQUEsQ0FBQSxJQUFBLFdBQUEsRUFBQSxPQUFBLEVBQThDLHlCQUFBLElBQUEsV0FBQSxFQUFBLE9BQUE7QUFFOUMsTUFBQSx3QkFBQSxTQUFBLElBQUEsV0FBQSxFQUFBLFVBQUEsbUJBQUEsY0FBQTtBQUNBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsV0FBQSxFQUFBLFVBQUEsTUFBQSxHQUFBO0FBVUksTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxXQUFBLElBQUEsV0FBQSxFQUFBLE9BQUEsRUFBc0MsY0FBQSxJQUFBLFdBQUEsRUFBQSxPQUFBLEVBQ0csZUFBQSxJQUFBLFdBQUEsRUFBQSxPQUFBLEVBQ0MsdUJBQUEsSUFBQSxXQUFBLEVBQUEsT0FBQTtBQUkxRCxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLElBQUEsT0FBQSxRQUFBLENBQWdCO0FBOERoQixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsT0FBQSxRQUFBLEVBQUEsV0FBQSxJQUFBLE1BQUEsRUFBQTtBQUlRLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsV0FBQSxFQUFBLFVBQUEsTUFBQSxFQUFBO0FBV0EsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLFNBQUEsSUFBQSxNQUFBLElBQUEsT0FBQSxtQkFBQSxJQUFBLE1BQUEsSUFBQSxPQUFBLGNBQUEsSUFBQSxNQUFBLEdBQUE7OztJRDNsRFo7SUFBWTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQ1o7SUFBVztJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQ1g7SUFBWTtJQUFBO0lBQUE7SUFBQTtJQUNaO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQVU7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7SUFBQTtJQUFBO0lBQUE7RUFBQSxHQUFBLGVBQUEsRUFBQSxDQUFBOzs7K0VBS0QsZUFBYSxDQUFBO1VBaER6Qjt1QkFDVyxZQUFVLFlBQ1IsTUFBSSxTQUNQO01BQ1A7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7T0FDRCxXQUVVLENBQUMsZ0JBQWdCLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1FBQUEsQ0FBQTs7VUErRzFCO1dBQU8sV0FBVzs7VUE1R3BCO1dBQWEsdUJBQXVCLENBQUMsUUFBUSxDQUFDOztVQU85QztXQUFhLHFCQUFxQjs7OztnRkFSeEIsZUFBYSxFQUFBLFdBQUEsaUJBQUEsVUFBQSxvREFBQSxZQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7OERBQWIsZUFBYSxFQUFBLFNBQUEsQ0FBQSxJQUFBLElBQUEsSUFBQSxJQUFBLHdCQUFBLElBQUEsb0JBQUEsbUNBQUEsYUFBQSxzQkFBQSxHQUFBLENBQUEsa0JBQUEsY0FBQSxhQUFBLGNBQUEsY0FBQSxhQUFBLG1CQUFBLGVBQUEsWUFBQSxhQUFBLGtCQUFBLFlBQUEsYUFBQSxtQkFBQSxxQkFBQSxnQkFBQSxvQkFBQSxhQUFBLFdBQUEscUJBQUEsYUFBQSxTQUFBLFlBQUEsY0FBQSxXQUFBLGlCQUFBLG9CQUFBLGVBQUEsaUJBQUEsYUFBQSxXQUFBLFlBQUEsY0FBQSxXQUFBLGNBQUEsY0FBQSxlQUFBLG1CQUFBLG1CQUFBLGlCQUFBLFlBQUEsYUFBQSxXQUFBLFFBQUEsWUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsc0JBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLENBQUEsTUFBQSxFQUFBLE9BQUEsTUFBQSxzQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7IiwibmFtZXMiOlsiaGV4Il0sImRlYnVnSWQiOiJlN2Y5YjkxNy04ODkwLTUyZjItOGY0ZC0yNDViZjQxYzUwZWIifQ==