//#region node_modules/@scure/base/index.js
/*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var freeze = (fn) => Object.freeze(fn());
function isBytes(a) {
	return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
/** Asserts something is Uint8Array. */
function abytes(b) {
	if (!isBytes(b)) throw new TypeError("Uint8Array expected");
}
function isArrayOf(isString, arr) {
	if (!Array.isArray(arr)) return false;
	if (arr.length === 0) return true;
	if (isString) return arr.every((item) => typeof item === "string");
	else return arr.every((item) => Number.isSafeInteger(item));
}
function afn(input) {
	if (typeof input !== "function") throw new TypeError("function expected");
	return true;
}
function astr(label, input) {
	if (typeof input !== "string") throw new TypeError(`${label}: string expected`);
	return true;
}
function anumber(n, title = "number") {
	if (typeof n !== "number") throw new TypeError(`${title}: expected number, got ${typeof n}`);
	if (!Number.isSafeInteger(n)) throw new RangeError(`${title}: expected safe integer, got ${n}`);
}
function anumArr(label, input) {
	if (!isArrayOf(false, input)) throw new TypeError(`${label}: array of numbers expected`);
}
function chain(...args) {
	const id = (a) => a;
	const wrap = (a, b) => (c) => a(b(c));
	return {
		encode: args.map((x) => x.encode).reduceRight(wrap, id),
		decode: args.map((x) => x.decode).reduce(wrap, id)
	};
}
function normalize(fn) {
	afn(fn);
	return {
		encode: (from) => from,
		decode: (to) => fn(to)
	};
}
var powers = /* @__PURE__ */ (() => {
	let res = [];
	for (let i = 0; i < 40; i++) res.push(2 ** i);
	return res;
})();
function u8ToNumArr(u8, len = u8.length) {
	const res = new Array(len);
	for (let i = 0; i < len; i++) res[i] = u8[i];
	return res;
}
var asciiDecoder = /* @__PURE__ */ (() => {
	try {
		const decoder = new TextDecoder();
		return decoder.decode(Uint8Array.of(65, 48, 43, 127)) === "A0+" ? decoder : void 0;
	} catch (e) {
		return;
	}
})();
var B2S_CHUNK = 8192;
function charcodesToString(codes) {
	const len = codes.length;
	if (asciiDecoder !== void 0 && len >= 12) return asciiDecoder.decode(codes);
	if (len <= B2S_CHUNK) return String.fromCharCode.apply(null, codes);
	let res = "";
	for (let i = 0; i < len; i += B2S_CHUNK) res += String.fromCharCode.apply(null, codes.subarray(i, i + B2S_CHUNK));
	return res;
}
/**
* Linear 8 <-> bits regrouping (radix2Slow semantics), with Uint8Array digits and
* preallocated output.
*/
function radix2(bits) {
	anumber(bits);
	if (bits <= 0 || bits > 8) throw new RangeError("radix2: bits should be in (0..8]");
	const mask = powers[bits] - 1;
	return {
		encode: (bytes) => {
			abytes(bytes);
			const len = bytes.length;
			const res = new Uint8Array(Math.ceil(len * 8 / bits));
			let carry = 0;
			let pos = 0;
			let j = 0;
			for (let i = 0; i < len;) {
				if (i + 2 < len) {
					carry = carry << 24 | bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
					pos += 24;
					i += 3;
				} else {
					carry = (carry << 8 | bytes[i]) & 65535;
					pos += 8;
					i++;
				}
				for (;;) {
					pos -= bits;
					res[j++] = carry >> pos & mask;
					if (pos < bits) break;
				}
			}
			if (pos > 0) res[j] = carry << bits - pos & mask;
			return res;
		},
		decode: (digits) => {
			const len = digits.length;
			const res = new Uint8Array(Math.floor(len * bits / 8));
			let carry = 0;
			let pos = 0;
			let j = 0;
			for (let i = 0; i < len; i++) {
				carry = (carry << bits | digits[i]) & 65535;
				pos += bits;
				for (; pos >= 8; pos -= 8) res[j++] = carry >> pos - 8 & 255;
			}
			carry = carry << 8 - pos & 255;
			if (pos >= bits) throw new Error("Excess padding");
			if (carry > 0) throw new Error(`Non-zero padding: ${carry}`);
			return res;
		}
	};
}
/**
* Digit <-> letter mapping fused with string join (chain(alphabetSlow(letters), join(''))
* semantics), via char-code lookup tables.
*/
function alphabet(letters, aliases) {
	const len = letters.length;
	if (len > 128) throw new Error("alphabet: max 128 letters");
	const encTable = new Uint8Array(len);
	const decTable = (/* @__PURE__ */ new Int8Array(128)).fill(-1);
	for (let i = 0; i < len; i++) {
		const code = letters.charCodeAt(i);
		if (letters.codePointAt(i) !== code || code > 127) throw new Error("alphabet: single-char ASCII letters only");
		encTable[i] = code;
		decTable[code] = i;
	}
	if (aliases !== void 0) for (const alias of Object.keys(aliases)) {
		const code = alias.charCodeAt(0);
		const target = decTable[aliases[alias].charCodeAt(0)];
		if (alias.length !== 1 || code > 127 || target === void 0 || target === -1) throw new Error(`alphabet: invalid alias ${alias}`);
		decTable[code] = target;
	}
	return {
		encode: (digits) => {
			const codes = new Uint8Array(digits.length);
			for (let i = 0; i < digits.length; i++) {
				const d = digits[i];
				const code = encTable[d];
				if (code === void 0) throw new Error(`alphabet.encode: invalid digit ${d}`);
				codes[i] = code;
			}
			return charcodesToString(codes);
		},
		decode: (input) => {
			astr("decode", input);
			const slen = input.length;
			const digits = new Uint8Array(slen);
			for (let i = 0; i < slen; i++) {
				const code = input.charCodeAt(i);
				const digit = code < 128 ? decTable[code] : -1;
				if (digit === -1) throw new Error(`Unknown letter "${input[i]}". Allowed: ${letters}`);
				digits[i] = digit;
			}
			return digits;
		}
	};
}
/**
* Pad / unpad (paddingSlow semantics), on the joined string.
*/
function padding(bits, chr = "=") {
	anumber(bits);
	astr("padding", chr);
	return {
		encode(data) {
			while (data.length * bits % 8) data += chr;
			return data;
		},
		decode(input) {
			astr("decode", input);
			let end = input.length;
			if (end * bits % 8) throw new Error("padding: invalid length");
			for (; end > 0 && input[end - 1] === chr; end--) if ((end - 1) * bits % 8 === 0) throw new Error("padding: excess padding");
			return input.slice(0, end);
		}
	};
}
function unsafeWrapper(fn) {
	afn(fn);
	return function(...args) {
		try {
			return fn.apply(null, args);
		} catch (e) {}
	};
}
function checksum(len, fn) {
	anumber(len);
	if (len <= 0) throw new RangeError(`checksum length must be positive: ${len}`);
	afn(fn);
	const _fn = fn;
	return {
		encode(data) {
			abytes(data);
			const sum = _fn(data).slice(0, len);
			const res = new Uint8Array(data.length + len);
			res.set(data);
			res.set(sum, data.length);
			return res;
		},
		decode(data) {
			abytes(data);
			const payload = data.slice(0, -len);
			const oldChecksum = data.slice(-len);
			const newChecksum = _fn(payload).slice(0, len);
			for (let i = 0; i < len; i++) if (newChecksum[i] !== oldChecksum[i]) throw new Error("Invalid checksum");
			return payload;
		}
	};
}
/**
* base16 encoding from RFC 4648.
* This codec uses RFC 4648 Table 5's uppercase alphabet directly.
* RFC 4648 §8 calls base16 "case-insensitive hex encoding", but we intentionally do not case-fold decode input here.
* Use `hex` for case-insensitive hex decoding.
* @example
* ```js
* base16.encode(Uint8Array.from([0x12, 0xab]));
* // => '12AB'
* ```
*/
var base16 = /* @__PURE__ */ freeze(() => chain(radix2(4), alphabet("0123456789ABCDEF")));
/**
* base32 encoding from RFC 4648. Has padding.
* RFC 4648 §6 Table 3 uses uppercase letters, and RFC 4648 §3.4 allows applications to choose
* upper- or lowercase alphabets. We keep the published uppercase table and do not case-fold decode input.
* Use `base32nopad` for unpadded version.
* Also check out `base32hex`, `base32hexnopad`, `base32crockford`.
* @example
* ```js
* base32.encode(Uint8Array.from([0x12, 0xab]));
* // => 'CKVQ===='
* base32.decode('CKVQ====');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base32 = /* @__PURE__ */ freeze(() => chain(radix2(5), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"), padding(5)));
/**
* base32 encoding from RFC 4648. No padding.
* This variant inherits RFC 4648 base32's uppercase table and intentionally does not case-fold decode input.
* Use `base32` for padded version.
* Also check out `base32hex`, `base32hexnopad`, `base32crockford`.
* @example
* ```js
* base32nopad.encode(Uint8Array.from([0x12, 0xab]));
* // => 'CKVQ'
* base32nopad.decode('CKVQ');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base32nopad = /* @__PURE__ */ freeze(() => chain(radix2(5), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")));
/**
* base32 encoding from RFC 4648. Padded. Compared to ordinary `base32`, slightly different alphabet.
* RFC 4648 §7 Table 4 uses uppercase letters, and we intentionally keep that table without case-folding decode input.
* Use `base32hexnopad` for unpadded version.
* @example
* ```js
* base32hex.encode(Uint8Array.from([0x12, 0xab]));
* // => '2ALG===='
* base32hex.decode('2ALG====');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base32hex = /* @__PURE__ */ freeze(() => chain(radix2(5), alphabet("0123456789ABCDEFGHIJKLMNOPQRSTUV"), padding(5)));
/**
* base32 encoding from RFC 4648. No padding. Compared to ordinary `base32`, slightly different alphabet.
* This variant inherits RFC 4648 base32hex's uppercase table and intentionally does not case-fold decode input.
* Use `base32hex` for padded version.
* @example
* ```js
* base32hexnopad.encode(Uint8Array.from([0x12, 0xab]));
* // => '2ALG'
* base32hexnopad.decode('2ALG');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base32hexnopad = /* @__PURE__ */ freeze(() => chain(radix2(5), alphabet("0123456789ABCDEFGHIJKLMNOPQRSTUV")));
/**
* base32 encoding from RFC 4648. Doug Crockford's version.
* See {@link https://www.crockford.com/base32.html | Douglas Crockford's Base32}.
* @example
* ```js
* base32crockford.encode(Uint8Array.from([0x12, 0xab]));
* // => '2ANG'
* base32crockford.decode('2ANG');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base32crockford = /* @__PURE__ */ freeze(() => chain(radix2(5), alphabet("0123456789ABCDEFGHJKMNPQRSTVWXYZ"), normalize((s) => {
	astr("base32crockford.decode", s);
	return s.toUpperCase().replace(/O/g, "0").replace(/[IL]/g, "1");
})));
var hasBase64Builtin = /* @__PURE__ */ (() => typeof Uint8Array.from([]).toBase64 === "function" && typeof Uint8Array.fromBase64 === "function")();
var ASCII_WHITESPACE = /[\t\n\f\r ]/;
var decodeBase64Builtin = (s, isUrl) => {
	astr("base64", s);
	const alphabet = isUrl ? "base64url" : "base64";
	if (s.length > 0 && ASCII_WHITESPACE.test(s)) throw new Error("invalid base64");
	return Uint8Array.fromBase64(s, {
		alphabet,
		lastChunkHandling: "strict"
	});
};
/** base64 from RFC 4648. Padded. Pure JS version */
var base64Fallback = /* @__PURE__ */ freeze(() => chain(radix2(6), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"), padding(6)));
/**
* base64 from RFC 4648. Padded.
* Alternative variants: `base64nopad`, `base64url`, `base64urlnopad`.
* Utilizes native `Uint8Array.fromBase64` builtin, otherwise falls back to `base64fallback` when it's unavailable.
* @example
* ```js
* base64.encode(Uint8Array.from([0x12, 0xab]));
* // => 'Eqs='
* base64.decode('Eqs=');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base64 = /* @__PURE__ */ freeze(() => hasBase64Builtin ? {
	encode(b) {
		abytes(b);
		return b.toBase64();
	},
	decode(s) {
		return decodeBase64Builtin(s, false);
	}
} : base64Fallback);
/**
* base64 from RFC 4648. No padding.
* Use `base64` for padded version.
* @example
* ```js
* base64nopad.encode(Uint8Array.from([0x12, 0xab]));
* // => 'Eqs'
* base64nopad.decode('Eqs');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base64nopad = /* @__PURE__ */ freeze(() => chain(radix2(6), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")));
/**
* base64 from RFC 4648, using URL-safe alphabet. Padded.
* Use `base64urlnopad` for unpadded version.
* Falls back to built-in function, when available.
* @example
* ```js
* base64url.encode(Uint8Array.from([0x12, 0xab]));
* // => 'Eqs='
* base64url.decode('Eqs=');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base64url = /* @__PURE__ */ freeze(() => hasBase64Builtin ? {
	encode(b) {
		abytes(b);
		return b.toBase64({ alphabet: "base64url" });
	},
	decode(s) {
		return decodeBase64Builtin(s, true);
	}
} : chain(radix2(6), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"), padding(6)));
/**
* base64 from RFC 4648, using URL-safe alphabet. No padding.
* Use `base64url` for padded version.
* @example
* ```js
* base64urlnopad.encode(Uint8Array.from([0x12, 0xab]));
* // => 'Eqs'
* base64urlnopad.decode('Eqs');
* // => Uint8Array.from([0x12, 0xab])
* ```
*/
var base64urlnopad = /* @__PURE__ */ freeze(() => chain(radix2(6), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_")));
var B58_GROUP = 656356768;
var radix58 = {
	encode: (bytes) => {
		abytes(bytes);
		const blen = bytes.length;
		if (blen === 0) return /* @__PURE__ */ new Uint8Array(0);
		let zeros = 0;
		while (zeros < blen - 1 && bytes[zeros] === 0) zeros++;
		const nlimbs = Math.ceil(blen / 2);
		const limbs = new Uint16Array(nlimbs);
		const odd = blen & 1;
		if (odd) limbs[0] = bytes[0];
		for (let i = odd, j = odd; i < blen; i += 2, j++) limbs[j] = bytes[i] << 8 | bytes[i + 1];
		const groups = [];
		let pos = 0;
		while (pos < nlimbs) {
			let carry = 0;
			for (let i = pos; i < nlimbs; i++) {
				const cur = carry * 65536 + limbs[i];
				const q = Math.floor(cur / B58_GROUP);
				carry = cur - q * B58_GROUP;
				limbs[i] = q;
				if (q === 0 && i === pos) pos++;
			}
			groups.push(carry);
		}
		const top = groups.length - 1;
		let sig = top * 5;
		for (let v = groups[top];; v = Math.floor(v / 58)) {
			sig++;
			if (v < 58) break;
		}
		const res = new Uint8Array(zeros + sig);
		let j = res.length - 1;
		for (let g = 0; g < top; g++) {
			let v = groups[g];
			for (let k = 0; k < 5; k++) {
				res[j--] = v % 58;
				v = Math.floor(v / 58);
			}
		}
		for (let v = groups[top]; j >= zeros; v = Math.floor(v / 58)) res[j--] = v % 58;
		return res;
	},
	decode: (digits) => {
		abytes(digits);
		const dlen = digits.length;
		if (dlen === 0) return /* @__PURE__ */ new Uint8Array(0);
		if (dlen >= 65536) throw new Error("invalid length");
		let zeros = 0;
		while (zeros < dlen - 1 && digits[zeros] === 0) zeros++;
		const limbs = new Uint16Array(Math.ceil(dlen * 6 / 16) + 1);
		let used = 0;
		let i = 0;
		let group = dlen % 5 || 5;
		while (i < dlen) {
			let gval = 0;
			let factor = 1;
			for (const end = i + group; i < end; i++) {
				const d = digits[i];
				if (d >= 58) throw new Error(`invalid integer: ${d}`);
				gval = gval * 58 + d;
				factor *= 58;
			}
			group = 5;
			let carry = gval;
			for (let k = 0; k < used; k++) {
				const cur = limbs[k] * factor + carry;
				carry = Math.floor(cur / 65536);
				limbs[k] = cur - carry * 65536;
			}
			for (; carry > 0; carry = Math.floor(carry / 65536)) limbs[used++] = carry % 65536;
		}
		const valueBytes = used === 0 ? 1 : used * 2 - (limbs[used - 1] < 256 ? 1 : 0);
		const res = new Uint8Array(zeros + valueBytes);
		let j = res.length - 1;
		for (let k = 0; k < used; k++) {
			const limb = limbs[k];
			res[j--] = limb & 255;
			if (j >= zeros) res[j--] = limb >> 8;
		}
		return res;
	}
};
var genBase58 = (abc) => chain(radix58, alphabet(abc));
/**
* base58: base64 without ambigous characters +, /, 0, O, I, l.
* Quadratic (O(n^2)) - so, can't be used on large inputs.
* @example
* ```js
* const text = base58.encode(Uint8Array.from([0, 1, 2]));
* base58.decode(text);
* // => Uint8Array.from([0, 1, 2])
* ```
*/
var base58 = /* @__PURE__ */ freeze(() => genBase58("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"));
/**
* base58: flickr version. Check out `base58`.
* @example
* Round-trip bytes with the Flickr alphabet.
* ```ts
* const text = base58flickr.encode(Uint8Array.from([0, 1, 2]));
* base58flickr.decode(text);
* ```
*/
var base58flickr = /* @__PURE__ */ freeze(() => genBase58("123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ"));
/**
* base58: XRP version. Check out `base58`.
* @example
* Round-trip bytes with the XRP alphabet.
* ```ts
* const text = base58xrp.encode(Uint8Array.from([0, 1, 2]));
* base58xrp.decode(text);
* ```
*/
var base58xrp = /* @__PURE__ */ freeze(() => genBase58("rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz"));
var XMR_BLOCK_LEN = [
	0,
	2,
	3,
	5,
	6,
	7,
	9,
	10,
	11
];
/**
* base58: XMR version. Check out `base58`.
* Done in 8-byte blocks (which equals 11 chars in decoding). Last (non-full) block padded with '1' to size in XMR_BLOCK_LEN.
* Block encoding significantly reduces quadratic complexity of base58.
* @example
* Round-trip bytes with the Monero block codec.
* ```ts
* const text = base58xmr.encode(Uint8Array.from([0, 1, 2]));
* base58xmr.decode(text);
* ```
*/
var base58xmr = /* @__PURE__ */ freeze(() => ({
	encode(data) {
		abytes(data);
		let res = "";
		for (let i = 0; i < data.length; i += 8) {
			const block = data.subarray(i, i + 8);
			res += base58.encode(block).padStart(XMR_BLOCK_LEN[block.length], "1");
		}
		return res;
	},
	decode(str) {
		astr("base58xmr.decode", str);
		const strLen = str.length;
		const tailChars = strLen % 11;
		const tailBytes = tailChars === 0 ? 0 : XMR_BLOCK_LEN.indexOf(tailChars);
		if (tailBytes === -1) throw new Error(`base58xmr: invalid block length ${tailChars}`);
		const res = new Uint8Array(Math.floor(strLen / 11) * 8 + tailBytes);
		let w = 0;
		for (let i = 0; i < strLen; i += 11) {
			const slice = str.slice(i, i + 11);
			const blockLen = slice.length === 11 ? 8 : tailBytes;
			const block = base58.decode(slice);
			for (let j = 0; j < block.length - blockLen; j++) if (block[j] !== 0) throw new Error("base58xmr: wrong padding");
			for (let j = block.length - blockLen; j < block.length; j++) res[w++] = block[j];
		}
		return res;
	}
}));
/**
* Method, which creates base58check encoder.
* Requires function, calculating sha256.
* Callers must include any version bytes in `data`; this helper only applies the
* 4-byte double-SHA256 checksum used by Bitcoin Base58Check.
* @param sha256 - Function used to calculate the checksum hash.
* @returns base58check codec using 4 checksum bytes.
* @throws On wrong argument types. {@link TypeError}
* @example
* Create a base58check codec from a SHA-256 implementation.
* ```ts
* import { createBase58check } from '@scure/base';
* import { sha256 } from '@noble/hashes/sha2.js';
* const coder = createBase58check(sha256);
* coder.encode(Uint8Array.from([1, 2, 3]));
* ```
*/
var createBase58check = (sha256) => {
	afn(sha256);
	const _sha256 = sha256;
	return chain(checksum(4, (data) => _sha256(_sha256(data))), base58);
};
/**
* Use `createBase58check` instead.
* @deprecated Use {@link createBase58check} instead.
* Callers must include any version bytes in `data`; this alias keeps the same
* 4-byte double-SHA256 checksum behavior as `createBase58check`.
* @param sha256 - Function used to calculate the checksum hash.
* @returns base58check codec using 4 checksum bytes.
* @example
* Create a base58check codec with the deprecated alias.
* ```ts
* import { base58check } from '@scure/base';
* import { sha256 } from '@noble/hashes/sha2.js';
* const coder = base58check(sha256);
* coder.encode(Uint8Array.from([1, 2, 3]));
* ```
*/
var base58check = createBase58check;
var BECH_ALPHABET = /* @__PURE__ */ alphabet("qpzry9x8gf2tvdw0s3jn54khce6mua7l");
function wordsToU8(words) {
	const len = words.length;
	const res = new Uint8Array(len);
	for (let i = 0; i < len; i++) {
		const w = words[i];
		if (w < 0 || w >= 32) throw new Error(`alphabet.encode: invalid digit ${w}`);
		res[i] = w;
	}
	return res;
}
var POLYMOD_GENERATORS = [
	996825010,
	642813549,
	513874426,
	1027748829,
	705979059
];
function bech32Polymod(pre) {
	const b = pre >> 25;
	let chk = (pre & 33554431) << 5;
	for (let i = 0; i < POLYMOD_GENERATORS.length; i++) if ((b >> i & 1) === 1) chk ^= POLYMOD_GENERATORS[i];
	return chk;
}
function bechChecksum(prefix, words, encodingConst = 1) {
	const len = prefix.length;
	let chk = 1;
	for (let i = 0; i < len; i++) {
		const c = prefix.charCodeAt(i);
		if (c < 33 || c > 126) throw new Error(`Invalid prefix (${prefix})`);
		chk = bech32Polymod(chk) ^ c >> 5;
	}
	chk = bech32Polymod(chk);
	for (let i = 0; i < len; i++) chk = bech32Polymod(chk) ^ prefix.charCodeAt(i) & 31;
	for (let v of words) chk = bech32Polymod(chk) ^ v;
	for (let i = 0; i < 6; i++) chk = bech32Polymod(chk);
	chk ^= encodingConst;
	const sum = /* @__PURE__ */ new Uint8Array(6);
	for (let i = 0; i < 6; i++) sum[i] = chk >>> 5 * (5 - i) & 31;
	return BECH_ALPHABET.encode(sum);
}
function genBech32(encoding) {
	const ENCODING_CONST = encoding === "bech32" ? 1 : 734539939;
	const _words = radix2(5);
	const toWords = (from) => {
		abytes(from);
		const len = from.length;
		const res = new Array(Math.ceil(len * 8 / 5));
		let carry = 0;
		let pos = 0;
		let j = 0;
		for (let i = 0; i < len; i++) {
			carry = carry << 8 | from[i];
			pos += 8;
			for (; pos >= 5; pos -= 5) res[j++] = carry >> pos - 5 & 31;
		}
		if (pos > 0) res[j] = carry << 5 - pos & 31;
		return res;
	};
	const fromWords = (to) => {
		anumArr("radix2.decode", to);
		const len = to.length;
		const digits = new Uint8Array(len);
		for (let i = 0; i < len; i++) {
			const w = to[i];
			if (w < 0 || w >= 32) throw new Error(`convertRadix2: invalid word=${w}`);
			digits[i] = w;
		}
		return _words.decode(digits);
	};
	const fromWordsUnsafe = unsafeWrapper(fromWords);
	function encode(prefix, words, limit = 90) {
		astr("bech32.encode prefix", prefix);
		if (limit !== false) anumber(limit, "limit");
		if (isBytes(words)) words = u8ToNumArr(words);
		anumArr("bech32.encode", words);
		const plen = prefix.length;
		if (plen === 0) throw new TypeError(`Invalid prefix length ${plen}`);
		const actualLength = plen + 7 + words.length;
		if (limit !== false && actualLength > limit) throw new TypeError(`Length ${actualLength} exceeds limit ${limit}`);
		const lowered = prefix.toLowerCase();
		const sum = bechChecksum(lowered, words, ENCODING_CONST);
		return `${lowered}1${BECH_ALPHABET.encode(wordsToU8(words))}${sum}`;
	}
	function decode(str, limit = 90) {
		astr("bech32.decode input", str);
		if (limit !== false) anumber(limit, "limit");
		const slen = str.length;
		if (slen < 8 || limit !== false && slen > limit) throw new TypeError(`invalid string length ${slen}, expected (8..${limit})`);
		const lowered = str.toLowerCase();
		if (str !== lowered && str !== str.toUpperCase()) throw new Error(`mixed-case string not allowed`);
		const sepIndex = lowered.lastIndexOf("1");
		if (sepIndex === 0 || sepIndex === -1) throw new Error(`invalid separator "1"`);
		const prefix = lowered.slice(0, sepIndex);
		const data = lowered.slice(sepIndex + 1);
		if (data.length < 6) throw new Error("invalid data length");
		const digits = BECH_ALPHABET.decode(data);
		const words = u8ToNumArr(digits, digits.length - 6);
		const sum = bechChecksum(prefix, words, ENCODING_CONST);
		if (!data.endsWith(sum)) throw new Error(`Invalid checksum in ${str}`);
		return {
			prefix,
			words
		};
	}
	const decodeUnsafe = unsafeWrapper(decode);
	function decodeToBytes(str) {
		const { prefix, words } = decode(str, false);
		return {
			prefix,
			words,
			bytes: fromWords(words)
		};
	}
	function encodeFromBytes(prefix, bytes) {
		return encode(prefix, toWords(bytes));
	}
	return {
		encode,
		decode,
		encodeFromBytes,
		decodeToBytes,
		decodeUnsafe,
		fromWords,
		fromWordsUnsafe,
		toWords
	};
}
/**
* bech32 from BIP 173. Operates on words.
* For high-level helpers, check out {@link https://github.com/paulmillr/scure-btc-signer | scure-btc-signer}.
* @example
* Convert bytes to words, encode them, then decode back.
* ```ts
* const words = bech32.toWords(Uint8Array.from([1, 2, 3]));
* const text = bech32.encode('bc', words);
* bech32.decode(text);
* ```
*/
var bech32 = /* @__PURE__ */ freeze(() => genBech32("bech32"));
/**
* bech32m from BIP 350. Operates on words.
* It was to mitigate `bech32` weaknesses.
* For high-level helpers, check out {@link https://github.com/paulmillr/scure-btc-signer | scure-btc-signer}.
* @example
* Convert bytes to words, encode them with bech32m, then decode back.
* ```ts
* const words = bech32m.toWords(Uint8Array.from([1, 2, 3]));
* const text = bech32m.encode('bc', words);
* bech32m.decode(text);
* ```
*/
var bech32m = /* @__PURE__ */ freeze(() => genBech32("bech32m"));
/**
* ASCII-to-byte decoder. Rejects non-ASCII text and bytes instead of doing UTF-8 replacement.
* Method names follow `BytesCoder`, so `encode(bytes)` returns a string and `decode(string)` returns bytes.
* @example
* ```js
* const b = ascii.decode("ABC"); // => new Uint8Array([ 65, 66, 67 ])
* const str = ascii.encode(b); // "ABC"
* ```
*/
var ascii = /* @__PURE__ */ freeze(() => ({
	encode(data) {
		abytes(data);
		for (let i = 0; i < data.length; i++) {
			const byte = data[i];
			if (byte > 127) throw new RangeError(`non-ASCII byte ${byte} at ${i}`);
		}
		return charcodesToString(data);
	},
	decode(str) {
		if (typeof str !== "string") throw new TypeError("ascii string expected, got " + typeof str);
		const res = new Uint8Array(str.length);
		for (let i = 0; i < str.length; i++) {
			const charCode = str.charCodeAt(i);
			if (charCode > 127) throw new RangeError(`non-ASCII char "${str[i]}" (${charCode}) at ${i}`);
			res[i] = charCode;
		}
		return res;
	}
}));
var _isWellFormedShim = (str) => {
	try {
		return encodeURI(str) !== null;
	} catch (_unused) {
		return false;
	}
};
var _isWellFormed = /* @__PURE__ */ (() => typeof "".isWellFormed === "function" ? (str) => str.isWellFormed() : _isWellFormedShim)();
var utf8err = (i) => /* @__PURE__ */ new TypeError(`invalid utf8 at byte ${i}`);
var utf8Fallback = /* @__PURE__ */ freeze(() => ({
	encode(data) {
		abytes(data);
		let res = "";
		for (let i = 0; i < data.length;) {
			const a = data[i++];
			if (a < 128) {
				res += String.fromCharCode(a);
				continue;
			}
			if (a < 194 || i >= data.length) throw utf8err(i - 1);
			const b = data[i++];
			if ((b & 192) !== 128) throw utf8err(i - 1);
			let cp = (a & 31) << 6 | b & 63;
			if (a >= 224) {
				if (i >= data.length) throw utf8err(i - 1);
				const c = data[i++];
				if ((c & 192) !== 128 || a === 224 && b < 160 || a === 237 && b >= 160) throw utf8err(i - 1);
				cp = (a & 15) << 12 | (b & 63) << 6 | c & 63;
				if (a >= 240) {
					if (i >= data.length) throw utf8err(i - 1);
					const d = data[i++];
					if (a > 244 || (d & 192) !== 128 || a === 240 && b < 144 || a === 244 && b >= 144) throw utf8err(i - 1);
					cp = (a & 7) << 18 | (b & 63) << 12 | (c & 63) << 6 | d & 63;
				}
			}
			if (cp < 65536) res += String.fromCharCode(cp);
			else {
				cp -= 65536;
				res += String.fromCharCode((cp >> 10) + 55296, (cp & 1023) + 56320);
			}
		}
		return res;
	},
	decode(str) {
		astr("utf8", str);
		if (!_isWellFormed(str)) throw new TypeError("utf8 expected well-formed string");
		const res = new Uint8Array(str.length * 3);
		let pos = 0;
		for (let i = 0; i < str.length; i++) {
			let c = str.charCodeAt(i);
			if (c < 128) {
				res[pos++] = c;
				continue;
			}
			if (c >= 55296 && c <= 57343) {
				const d = str.charCodeAt(++i);
				c = 65536 + (c - 55296 << 10) + d - 56320;
			}
			if (c >= 65536) {
				res[pos++] = c >> 18 | 240;
				res[pos++] = c >> 12 & 63 | 128;
			} else if (c >= 2048) res[pos++] = c >> 12 | 224;
			else res[pos++] = c >> 6 | 192;
			if (c >= 2048) res[pos++] = c >> 6 & 63 | 128;
			res[pos++] = c & 63 | 128;
		}
		return res.subarray(0, pos);
	}
}));
/**
* Strict UTF-8-to-byte decoder. Uses built-in TextDecoder / TextEncoder when available.
* Method names follow `BytesCoder`, so `encode(bytes)` returns a string and
* `decode(string)` returns bytes.
* `encode(bytes)` requires Uint8Array input, preserves an explicit leading BOM, and
*   throws on invalid UTF-8 bytes.
* `decode(string)` requires a primitive string and throws on malformed UTF-16 strings with
*   lone surrogates.
* @example
* ```js
* const b = utf8.decode("hey"); // => new Uint8Array([ 104, 101, 121 ])
* const str = utf8.encode(b); // "hey"
* ```
*/
var utf8 = /* @__PURE__ */ freeze(() => {
	let _utf8Encoder;
	let _utf8Decoder;
	const utf8Builtin = {
		encode(data) {
			abytes(data);
			return (_utf8Decoder || (_utf8Decoder = new TextDecoder("utf-8", {
				ignoreBOM: true,
				fatal: true
			}))).decode(data);
		},
		decode(str) {
			astr("utf8", str);
			if (!_isWellFormed(str)) throw new TypeError("utf8 expected well-formed string");
			return (_utf8Encoder || (_utf8Encoder = new TextEncoder())).encode(str);
		}
	};
	return {
		encode: typeof TextDecoder === "function" ? utf8Builtin.encode : utf8Fallback.encode,
		decode: typeof TextEncoder === "function" ? utf8Builtin.decode : utf8Fallback.decode
	};
});
var __TESTS = /* @__PURE__ */ freeze(() => ({
	alphabet,
	base64Fallback,
	radix2,
	radix58,
	checksum,
	utf8Fallback,
	_isWellFormedShim
}));
var hasHexBuiltin = /* @__PURE__ */ (() => typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function")();
var hexBuiltin = {
	encode(data) {
		abytes(data);
		return data.toHex();
	},
	decode(s) {
		astr("hex", s);
		return Uint8Array.fromHex(s);
	}
};
/**
* hex string decoder. Uses built-in function, when available.
* Lowercase codec; unlike `base16`, this variant accepts either hex case and emits lowercase.
* @example
* ```js
* const b = hex.decode("0102ff"); // => new Uint8Array([ 1, 2, 255 ])
* const str = hex.encode(b); // "0102ff"
* ```
*/
var hex = /* @__PURE__ */ freeze(() => hasHexBuiltin ? hexBuiltin : chain(radix2(4), alphabet("0123456789abcdef", {
	A: "a",
	B: "b",
	C: "c",
	D: "d",
	E: "e",
	F: "f"
}), normalize((s) => {
	astr("hex", s);
	if (s.length % 2 !== 0) throw new TypeError(`hex.decode: odd-length string (${s.length})`);
	return s;
})));
//#endregion
export { __TESTS, ascii, base16, base32, base32crockford, base32hex, base32hexnopad, base32nopad, base58, base58check, base58flickr, base58xmr, base58xrp, base64, base64nopad, base64url, base64urlnopad, bech32, bech32m, createBase58check, hex, utf8 };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHNjdXJlX2Jhc2UuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL0BzY3VyZS9iYXNlL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qISBzY3VyZS1iYXNlIC0gTUlUIExpY2Vuc2UgKGMpIDIwMjIgUGF1bCBNaWxsZXIgKHBhdWxtaWxsci5jb20pICovXG4vLyBGcmVlemUgdGhlIHJlc3VsdCBvZiBhIHRodW5rLiBgLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBleHByKWAga2VlcHMgdGhlIHdob2xlXG4vLyBpbml0aWFsaXplciB0cmVlLXNoYWthYmxlOiB0aGUgYW5ub3RhdGVkIGNhbGwncyBvbmx5IGFyZ3VtZW50IGlzIGEgZnVuY3Rpb24gbGl0ZXJhbCxcbi8vIHNvIGJ1bmRsZXJzIGRyb3AgZXZlcnl0aGluZyAoaW5uZXIgY2hhaW4oKS9hbHBoYWJldCgpIGNhbGxzIGluY2x1ZGVkKSB3aGVuIHVudXNlZC5cbmNvbnN0IGZyZWV6ZSA9IChmbikgPT4gT2JqZWN0LmZyZWV6ZShmbigpKTtcbmZ1bmN0aW9uIGlzQnl0ZXMoYSkge1xuICAgIC8vIFBsYWluIGBpbnN0YW5jZW9mIFVpbnQ4QXJyYXlgIGlzIHRvbyBzdHJpY3QgZm9yIHNvbWUgQnVmZmVyIC8gcHJveHkgLyBjcm9zcy1yZWFsbSBjYXNlcy4gVGhlXG4gICAgLy8gZmFsbGJhY2sgc3RpbGwgcmVxdWlyZXMgYSByZWFsIEFycmF5QnVmZmVyIHZpZXcsIHNvIHBsYWluIEpTT04tZGVzZXJpYWxpemVkXG4gICAgLy8gYHsgY29uc3RydWN0b3I6IC4uLiB9YCBzcG9vZmluZyBpcyByZWplY3RlZC4gYEJZVEVTX1BFUl9FTEVNRU5UID09PSAxYCBrZWVwcyB0aGVcbiAgICAvLyBmYWxsYmFjayBvbiBieXRlLW9yaWVudGVkIHZpZXdzLlxuICAgIHJldHVybiAoYSBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkgfHxcbiAgICAgICAgKEFycmF5QnVmZmVyLmlzVmlldyhhKSAmJlxuICAgICAgICAgICAgYS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnVWludDhBcnJheScgJiZcbiAgICAgICAgICAgICdCWVRFU19QRVJfRUxFTUVOVCcgaW4gYSAmJlxuICAgICAgICAgICAgYS5CWVRFU19QRVJfRUxFTUVOVCA9PT0gMSkpO1xufVxuLyoqIEFzc2VydHMgc29tZXRoaW5nIGlzIFVpbnQ4QXJyYXkuICovXG5mdW5jdGlvbiBhYnl0ZXMoYikge1xuICAgIGlmICghaXNCeXRlcyhiKSlcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVWludDhBcnJheSBleHBlY3RlZCcpO1xufVxuZnVuY3Rpb24gaXNBcnJheU9mKGlzU3RyaW5nLCBhcnIpIHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSlcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChhcnIubGVuZ3RoID09PSAwKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoaXNTdHJpbmcpIHtcbiAgICAgICAgcmV0dXJuIGFyci5ldmVyeSgoaXRlbSkgPT4gdHlwZW9mIGl0ZW0gPT09ICdzdHJpbmcnKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJldHVybiBhcnIuZXZlcnkoKGl0ZW0pID0+IE51bWJlci5pc1NhZmVJbnRlZ2VyKGl0ZW0pKTtcbiAgICB9XG59XG5mdW5jdGlvbiBhZm4oaW5wdXQpIHtcbiAgICBpZiAodHlwZW9mIGlucHV0ICE9PSAnZnVuY3Rpb24nKVxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdmdW5jdGlvbiBleHBlY3RlZCcpO1xuICAgIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gYXN0cihsYWJlbCwgaW5wdXQpIHtcbiAgICBpZiAodHlwZW9mIGlucHV0ICE9PSAnc3RyaW5nJylcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgJHtsYWJlbH06IHN0cmluZyBleHBlY3RlZGApO1xuICAgIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gYW51bWJlcihuLCB0aXRsZSA9ICdudW1iZXInKSB7XG4gICAgaWYgKHR5cGVvZiBuICE9PSAnbnVtYmVyJylcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgJHt0aXRsZX06IGV4cGVjdGVkIG51bWJlciwgZ290ICR7dHlwZW9mIG59YCk7XG4gICAgaWYgKCFOdW1iZXIuaXNTYWZlSW50ZWdlcihuKSlcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYCR7dGl0bGV9OiBleHBlY3RlZCBzYWZlIGludGVnZXIsIGdvdCAke259YCk7XG59XG5mdW5jdGlvbiBhbnVtQXJyKGxhYmVsLCBpbnB1dCkge1xuICAgIGlmICghaXNBcnJheU9mKGZhbHNlLCBpbnB1dCkpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYCR7bGFiZWx9OiBhcnJheSBvZiBudW1iZXJzIGV4cGVjdGVkYCk7XG59XG5mdW5jdGlvbiBjaGFpbiguLi5hcmdzKSB7XG4gICAgY29uc3QgaWQgPSAoYSkgPT4gYTtcbiAgICAvLyBXcmFwIGNhbGwgaW4gY2xvc3VyZSBzbyBKSVQgY2FuIGlubGluZSBjYWxsc1xuICAgIGNvbnN0IHdyYXAgPSAoYSwgYikgPT4gKGMpID0+IGEoYihjKSk7XG4gICAgLy8gQ29uc3RydWN0IGNoYWluIG9mIGFyZ3NbLTFdLmVuY29kZShhcmdzWy0yXS5lbmNvZGUoWy4uLl0pKVxuICAgIGNvbnN0IGVuY29kZSA9IGFyZ3MubWFwKCh4KSA9PiB4LmVuY29kZSkucmVkdWNlUmlnaHQod3JhcCwgaWQpO1xuICAgIC8vIENvbnN0cnVjdCBjaGFpbiBvZiBhcmdzWzBdLmRlY29kZShhcmdzWzFdLmRlY29kZSguLi4pKVxuICAgIGNvbnN0IGRlY29kZSA9IGFyZ3MubWFwKCh4KSA9PiB4LmRlY29kZSkucmVkdWNlKHdyYXAsIGlkKTtcbiAgICByZXR1cm4geyBlbmNvZGUsIGRlY29kZSB9O1xufVxuZnVuY3Rpb24gbm9ybWFsaXplKGZuKSB7XG4gICAgYWZuKGZuKTtcbiAgICByZXR1cm4geyBlbmNvZGU6IChmcm9tKSA9PiBmcm9tLCBkZWNvZGU6ICh0bykgPT4gZm4odG8pIH07XG59XG5jb25zdCBwb3dlcnMgPSAvKiBAX19QVVJFX18gKi8gKCgpID0+IHtcbiAgICBsZXQgcmVzID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0MDsgaSsrKVxuICAgICAgICByZXMucHVzaCgyICoqIGkpO1xuICAgIHJldHVybiByZXM7XG59KSgpO1xuLy8gSW5kZXhlZCBjb3B5IGxvb3BzIGluc3RlYWQgb2YgQXJyYXkuZnJvbSAvIFVpbnQ4QXJyYXkuZnJvbTogdGhvc2UgZ28gdGhyb3VnaCB0aGVcbi8vIGl0ZXJhdG9yIHByb3RvY29sIG9uIHR5cGVkIGFycmF5cywgd2hpY2ggaXMgfjEweCBzbG93ZXIgYW5kIHdvdWxkIHN3YW1wIHRoZSBmYXN0XG4vLyBsaW5rcycgZ2FpbnMgb24gdGhlIGNvbnZlcnNpb24gYm91bmRhcmllcy5cbmZ1bmN0aW9uIHU4VG9OdW1BcnIodTgsIGxlbiA9IHU4Lmxlbmd0aCkge1xuICAgIGNvbnN0IHJlcyA9IG5ldyBBcnJheShsZW4pO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspXG4gICAgICAgIHJlc1tpXSA9IHU4W2ldO1xuICAgIHJldHVybiByZXM7XG59XG4vLyBVVEYtOCBUZXh0RGVjb2RlciBidWlsZHMgYSBzdHJpbmcgZnJvbSBBU0NJSSBjb2RlcyAyeCBmYXN0ZXIgdGhhbiBgVGV4dERlY29kZXIoJ2xhdGluMScpYFxuLy8gKDR4IG9uIGZyZXNobHkgYWxsb2NhdGVkLCBvdXIgZXhhY3QgY2FzZSkuXG4vLyBBbGwgY29kZXMgaGVyZSBhcmUgPCAxMjggKHJhbmdlIGlzIHZhbGlkYXRlZCBlbHNld2hlcmUpOiBVVEYtOCBhZ3JlZXMgd2l0aCBBU0NJSSBieXRlLWZvci1ieXRlLlxuLy8gVVRGLTggbmVlZHMgbm8gSUNVLCBzbyB0aGUgcHJvYmUgb25seSBndWFyZHMgcnVudGltZXMgd2l0aG91dCBUZXh0RGVjb2RlciBhdCBhbGwgKEhlcm1lcykuXG5jb25zdCBhc2NpaURlY29kZXIgPSAvKiBAX19QVVJFX18gKi8gKCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBkZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCk7XG4gICAgICAgIC8vIFNlbGYtY2hlY2sgb24gdGhlIGRvbWFpbiB3ZSB1c2UgKGNvZGVzIDwgMTI4KTogcmVqZWN0IGJyb2tlbiBwb2x5ZmlsbHMgYXRcbiAgICAgICAgLy8gcHJvYmUgdGltZSBpbnN0ZWFkIG9mIHByb2R1Y2luZyBjb3JydXB0ZWQgY29kZWMgb3V0cHV0IGxhdGVyLlxuICAgICAgICByZXR1cm4gZGVjb2Rlci5kZWNvZGUoVWludDhBcnJheS5vZigweDQxLCAweDMwLCAweDJiLCAweDdmKSkgPT09ICdBMCtcXHg3ZidcbiAgICAgICAgICAgID8gZGVjb2RlclxuICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxufSkoKTtcbmNvbnN0IEIyU19DSFVOSyA9IDgxOTI7IC8vIGNoYXIgY29kZXMgcGVyIFN0cmluZy5mcm9tQ2hhckNvZGUgY2FsbCwgYXZvaWRzIGFyZy1jb3VudCBsaW1pdHNcbmZ1bmN0aW9uIGNoYXJjb2Rlc1RvU3RyaW5nKGNvZGVzKSB7XG4gICAgY29uc3QgbGVuID0gY29kZXMubGVuZ3RoO1xuICAgIC8vIE1lYXN1cmVkIGNyb3Nzb3ZlcjogdGhlIFRleHREZWNvZGVyJ3MgcGVyLWNhbGwgc2V0dXAgZG9taW5hdGVzIGJlbG93IH4xMiBjaGFycyxcbiAgICAvLyB3aGVyZSBTdHJpbmcuZnJvbUNoYXJDb2RlIHdpbnMgKGJlY2gzMiBjaGVja3N1bXMsIGJhc2U1OHhtciBibG9ja3MpLlxuICAgIGlmIChhc2NpaURlY29kZXIgIT09IHVuZGVmaW5lZCAmJiBsZW4gPj0gMTIpXG4gICAgICAgIHJldHVybiBhc2NpaURlY29kZXIuZGVjb2RlKGNvZGVzKTtcbiAgICBpZiAobGVuIDw9IEIyU19DSFVOSylcbiAgICAgICAgcmV0dXJuIFN0cmluZy5mcm9tQ2hhckNvZGUuYXBwbHkobnVsbCwgY29kZXMpO1xuICAgIGxldCByZXMgPSAnJztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSBCMlNfQ0hVTkspXG4gICAgICAgIHJlcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KG51bGwsIGNvZGVzLnN1YmFycmF5KGksIGkgKyBCMlNfQ0hVTkspKTtcbiAgICByZXR1cm4gcmVzO1xufVxuLyoqXG4gKiBMaW5lYXIgOCA8LT4gYml0cyByZWdyb3VwaW5nIChyYWRpeDJTbG93IHNlbWFudGljcyksIHdpdGggVWludDhBcnJheSBkaWdpdHMgYW5kXG4gKiBwcmVhbGxvY2F0ZWQgb3V0cHV0LlxuICovXG5mdW5jdGlvbiByYWRpeDIoYml0cykge1xuICAgIGFudW1iZXIoYml0cyk7XG4gICAgaWYgKGJpdHMgPD0gMCB8fCBiaXRzID4gOClcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ3JhZGl4MjogYml0cyBzaG91bGQgYmUgaW4gKDAuLjhdJyk7XG4gICAgY29uc3QgbWFzayA9IHBvd2Vyc1tiaXRzXSAtIDE7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZW5jb2RlOiAoYnl0ZXMpID0+IHtcbiAgICAgICAgICAgIGFieXRlcyhieXRlcyk7XG4gICAgICAgICAgICBjb25zdCBsZW4gPSBieXRlcy5sZW5ndGg7XG4gICAgICAgICAgICAvLyA4LT5iaXRzIHdpdGggemVyby1iaXQgcGFkZGluZyBvZiB0aGUgbGFzdCBkaWdpdCwgbGlrZSBjb252ZXJ0UmFkaXgyKHBhZGRpbmc9dHJ1ZSlcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IG5ldyBVaW50OEFycmF5KE1hdGguY2VpbCgobGVuICogOCkgLyBiaXRzKSk7XG4gICAgICAgICAgICBsZXQgY2FycnkgPSAwO1xuICAgICAgICAgICAgbGV0IHBvcyA9IDA7XG4gICAgICAgICAgICBsZXQgaiA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjspIHtcbiAgICAgICAgICAgICAgICAvLyBBdCBtb3N0IDcgcmVzaWR1YWwgYml0cyBwbHVzIDI0IG5ldyBiaXRzIGZpdCBpbiB0aGUgc2lnbmVkIDMyLWJpdCBjYXJyeS5cbiAgICAgICAgICAgICAgICBpZiAoaSArIDIgPCBsZW4pIHtcbiAgICAgICAgICAgICAgICAgICAgY2FycnkgPSAoY2FycnkgPDwgMjQpIHwgKGJ5dGVzW2ldIDw8IDE2KSB8IChieXRlc1tpICsgMV0gPDwgOCkgfCBieXRlc1tpICsgMl07XG4gICAgICAgICAgICAgICAgICAgIHBvcyArPSAyNDtcbiAgICAgICAgICAgICAgICAgICAgaSArPSAzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gQ29uc3RhbnQgbWFzayBpbnN0ZWFkIG9mIGNvbnZlcnRSYWRpeDIncyBleGFjdCBwb3dlcnNbcG9zXS0xIGNsZWFudXA6IHdpdGhcbiAgICAgICAgICAgICAgICAgICAgLy8gYml0cyA8PSA4IHRoZSByZXNpZHVhbCBpcyBwb3MgPD0gNyBiaXRzLCBzbyBjYXJyeSBuZWVkcyBhdCBtb3N0IHBvcyArIDggPD0gMTVcbiAgICAgICAgICAgICAgICAgICAgLy8gbWVhbmluZ2Z1bCBiaXRzLiBTdGFsZSBiaXRzIGluIFtwb3MsIDE2KSBzaGlmdCB0byA+PSBiaXRzIG9uIGV4dHJhY3Rpb24gYW5kXG4gICAgICAgICAgICAgICAgICAgIC8vIGFyZSByZW1vdmVkIGJ5IGAmIG1hc2tgIHRoZXJlIGFuZCBpbiB0aGUgdGFpbCBiZWxvdy5cbiAgICAgICAgICAgICAgICAgICAgY2FycnkgPSAoKGNhcnJ5IDw8IDgpIHwgYnl0ZXNbaV0pICYgMHhmZmZmO1xuICAgICAgICAgICAgICAgICAgICBwb3MgKz0gODtcbiAgICAgICAgICAgICAgICAgICAgaSsrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBFYWNoIGlucHV0IGFkZHMgYXQgbGVhc3QgYGJpdHNgLCBzbyB0aGUgZmlyc3QgZXh0cmFjdGlvbiBpcyB1bmNvbmRpdGlvbmFsLlxuICAgICAgICAgICAgICAgIGZvciAoOzspIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zIC09IGJpdHM7XG4gICAgICAgICAgICAgICAgICAgIHJlc1tqKytdID0gKGNhcnJ5ID4+IHBvcykgJiBtYXNrO1xuICAgICAgICAgICAgICAgICAgICBpZiAocG9zIDwgYml0cylcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwb3MgPiAwKVxuICAgICAgICAgICAgICAgIHJlc1tqXSA9IChjYXJyeSA8PCAoYml0cyAtIHBvcykpICYgbWFzaztcbiAgICAgICAgICAgIHJldHVybiByZXM7XG4gICAgICAgIH0sXG4gICAgICAgIGRlY29kZTogKGRpZ2l0cykgPT4ge1xuICAgICAgICAgICAgLy8gYml0cy0+OCwgc3RyaWN0IGNhbm9uaWNhbCBmb3JtLCBsaWtlIGNvbnZlcnRSYWRpeDIocGFkZGluZz1mYWxzZSk6XG4gICAgICAgICAgICAvLyByZWplY3RzIGxlZnRvdmVyIHdob2xlIGlucHV0IHdvcmRzIGFuZCBub24temVybyBwYWQgYml0cy5cbiAgICAgICAgICAgIGNvbnN0IGxlbiA9IGRpZ2l0cy5sZW5ndGg7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBuZXcgVWludDhBcnJheShNYXRoLmZsb29yKChsZW4gKiBiaXRzKSAvIDgpKTtcbiAgICAgICAgICAgIGxldCBjYXJyeSA9IDA7XG4gICAgICAgICAgICBsZXQgcG9zID0gMDtcbiAgICAgICAgICAgIGxldCBqID0gMDtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICAvLyBTYW1lIGNvbnN0YW50LW1hc2sgY2FycnkgYm91bmQgYXMgZW5jb2RlOiBwb3MgPD0gNyByZXNpZHVhbCBwbHVzIGJpdHMgPD0gOFxuICAgICAgICAgICAgICAgIC8vIGluY29taW5nIGtlZXBzIG1lYW5pbmdmdWwgY2Fycnkgd2l0aGluIDE1IGJpdHM7IHN0YWxlIGJpdHMgYWJvdmUgcG9zIGFyZVxuICAgICAgICAgICAgICAgIC8vIG1hc2tlZCBvdXQgb24gZXh0cmFjdGlvbiBhbmQgaW4gdGhlIHRhaWwgY2hlY2sgYmVsb3cuXG4gICAgICAgICAgICAgICAgY2FycnkgPSAoKGNhcnJ5IDw8IGJpdHMpIHwgZGlnaXRzW2ldKSAmIDB4ZmZmZjtcbiAgICAgICAgICAgICAgICBwb3MgKz0gYml0cztcbiAgICAgICAgICAgICAgICBmb3IgKDsgcG9zID49IDg7IHBvcyAtPSA4KVxuICAgICAgICAgICAgICAgICAgICByZXNbaisrXSA9IChjYXJyeSA+PiAocG9zIC0gOCkpICYgMHhmZjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhcnJ5ID0gKGNhcnJ5IDw8ICg4IC0gcG9zKSkgJiAweGZmO1xuICAgICAgICAgICAgaWYgKHBvcyA+PSBiaXRzKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignRXhjZXNzIHBhZGRpbmcnKTtcbiAgICAgICAgICAgIGlmIChjYXJyeSA+IDApXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBOb24temVybyBwYWRkaW5nOiAke2NhcnJ5fWApO1xuICAgICAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgICAgfSxcbiAgICB9O1xufVxuLyoqXG4gKiBEaWdpdCA8LT4gbGV0dGVyIG1hcHBpbmcgZnVzZWQgd2l0aCBzdHJpbmcgam9pbiAoY2hhaW4oYWxwaGFiZXRTbG93KGxldHRlcnMpLCBqb2luKCcnKSlcbiAqIHNlbWFudGljcyksIHZpYSBjaGFyLWNvZGUgbG9va3VwIHRhYmxlcy5cbiAqL1xuZnVuY3Rpb24gYWxwaGFiZXQobGV0dGVycywgYWxpYXNlcykge1xuICAgIGNvbnN0IGxlbiA9IGxldHRlcnMubGVuZ3RoO1xuICAgIC8vIExhcmdlciBpbmRleGVzIHdvdWxkIHdyYXAgaW4gdGhlIEludDhBcnJheSByZXZlcnNlIHRhYmxlIGFuZCBkZWNvZGUgdG8gd3JvbmcgZGlnaXRzLlxuICAgIGlmIChsZW4gPiAxMjgpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignYWxwaGFiZXQ6IG1heCAxMjggbGV0dGVycycpO1xuICAgIGNvbnN0IGVuY1RhYmxlID0gbmV3IFVpbnQ4QXJyYXkobGVuKTtcbiAgICBjb25zdCBkZWNUYWJsZSA9IG5ldyBJbnQ4QXJyYXkoMTI4KS5maWxsKC0xKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNvZGUgPSBsZXR0ZXJzLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgIGlmIChsZXR0ZXJzLmNvZGVQb2ludEF0KGkpICE9PSBjb2RlIHx8IGNvZGUgPiAxMjcpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2FscGhhYmV0OiBzaW5nbGUtY2hhciBBU0NJSSBsZXR0ZXJzIG9ubHknKTtcbiAgICAgICAgZW5jVGFibGVbaV0gPSBjb2RlO1xuICAgICAgICBkZWNUYWJsZVtjb2RlXSA9IGk7XG4gICAgfVxuICAgIC8vIEFsaWFzZXMgZGVjb2RlIGxpa2UgdGhlaXIgY2Fub25pY2FsIGxldHRlciAoZS5nLiBoZXggY2FzZS1mb2xkaW5nKSwgd2l0aG91dCBhXG4gICAgLy8gc2VwYXJhdGUgbm9ybWFsaXphdGlvbiBwYXNzIG92ZXIgdGhlIGlucHV0IHN0cmluZy5cbiAgICBpZiAoYWxpYXNlcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGZvciAoY29uc3QgYWxpYXMgb2YgT2JqZWN0LmtleXMoYWxpYXNlcykpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvZGUgPSBhbGlhcy5jaGFyQ29kZUF0KDApO1xuICAgICAgICAgICAgY29uc3QgdGFyZ2V0ID0gZGVjVGFibGVbYWxpYXNlc1thbGlhc10uY2hhckNvZGVBdCgwKV07XG4gICAgICAgICAgICBpZiAoYWxpYXMubGVuZ3RoICE9PSAxIHx8IGNvZGUgPiAxMjcgfHwgdGFyZ2V0ID09PSB1bmRlZmluZWQgfHwgdGFyZ2V0ID09PSAtMSlcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGFscGhhYmV0OiBpbnZhbGlkIGFsaWFzICR7YWxpYXN9YCk7XG4gICAgICAgICAgICBkZWNUYWJsZVtjb2RlXSA9IHRhcmdldDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBlbmNvZGU6IChkaWdpdHMpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvZGVzID0gbmV3IFVpbnQ4QXJyYXkoZGlnaXRzLmxlbmd0aCk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRpZ2l0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGQgPSBkaWdpdHNbaV07XG4gICAgICAgICAgICAgICAgY29uc3QgY29kZSA9IGVuY1RhYmxlW2RdO1xuICAgICAgICAgICAgICAgIC8vIFJldXNlIHRoZSB0YWJsZSBsb29rdXAncyBib3VuZHMgcmVzdWx0IGZvciB0aGUgcmVxdWlyZWQgcGVyLWRpZ2l0IHJhbmdlIGNoZWNrLlxuICAgICAgICAgICAgICAgIC8vIENoYWluZWQgcmFkaXgyIGFsd2F5cyBlbWl0cyBkaWdpdHMgPCAyKipiaXRzID09PSBsZW47IGNoZWNrIGFueXdheSBzbyBhXG4gICAgICAgICAgICAgICAgLy8gbWlzbWF0Y2hlZCBjaGFpbiB0aHJvd3MgKGxpa2UgYWxwaGFiZXRTbG93KSBpbnN0ZWFkIG9mIHNpbGVudGx5IGVtaXR0aW5nIGxldHRlciAwLlxuICAgICAgICAgICAgICAgIGlmIChjb2RlID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgYWxwaGFiZXQuZW5jb2RlOiBpbnZhbGlkIGRpZ2l0ICR7ZH1gKTtcbiAgICAgICAgICAgICAgICBjb2Rlc1tpXSA9IGNvZGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY2hhcmNvZGVzVG9TdHJpbmcoY29kZXMpO1xuICAgICAgICB9LFxuICAgICAgICBkZWNvZGU6IChpbnB1dCkgPT4ge1xuICAgICAgICAgICAgLy8gVW5pZm9ybSBsYWJlbDogdGhpcyBpcyB0aGUgZGVjb2RlIGVudHJ5IGxpbmsgZm9yIG5vcGFkIGNvZGVjcywgcGFkZGluZyBmb3IgcGFkZGVkXG4gICAgICAgICAgICAvLyBvbmVzLiBLZWVwcyBcImRlY29kZTogc3RyaW5nIGV4cGVjdGVkXCIgaWRlbnRpY2FsIGFjcm9zcyBhbGwgYnVpbHQtaW4gY29kZWNzXG4gICAgICAgICAgICAvLyAocmVsZWFzZWQgMi54IHNhaWQgXCJqb2luLmRlY29kZTogc3RyaW5nIGV4cGVjdGVkXCIpLlxuICAgICAgICAgICAgYXN0cignZGVjb2RlJywgaW5wdXQpO1xuICAgICAgICAgICAgY29uc3Qgc2xlbiA9IGlucHV0Lmxlbmd0aDtcbiAgICAgICAgICAgIGNvbnN0IGRpZ2l0cyA9IG5ldyBVaW50OEFycmF5KHNsZW4pO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjb2RlID0gaW5wdXQuY2hhckNvZGVBdChpKTtcbiAgICAgICAgICAgICAgICBjb25zdCBkaWdpdCA9IGNvZGUgPCAxMjggPyBkZWNUYWJsZVtjb2RlXSA6IC0xO1xuICAgICAgICAgICAgICAgIGlmIChkaWdpdCA9PT0gLTEpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBsZXR0ZXIgXCIke2lucHV0W2ldfVwiLiBBbGxvd2VkOiAke2xldHRlcnN9YCk7XG4gICAgICAgICAgICAgICAgZGlnaXRzW2ldID0gZGlnaXQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZGlnaXRzO1xuICAgICAgICB9LFxuICAgIH07XG59XG4vKipcbiAqIFBhZCAvIHVucGFkIChwYWRkaW5nU2xvdyBzZW1hbnRpY3MpLCBvbiB0aGUgam9pbmVkIHN0cmluZy5cbiAqL1xuZnVuY3Rpb24gcGFkZGluZyhiaXRzLCBjaHIgPSAnPScpIHtcbiAgICBhbnVtYmVyKGJpdHMpO1xuICAgIGFzdHIoJ3BhZGRpbmcnLCBjaHIpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGVuY29kZShkYXRhKSB7XG4gICAgICAgICAgICB3aGlsZSAoKGRhdGEubGVuZ3RoICogYml0cykgJSA4KVxuICAgICAgICAgICAgICAgIGRhdGEgKz0gY2hyO1xuICAgICAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgICAgIH0sXG4gICAgICAgIGRlY29kZShpbnB1dCkge1xuICAgICAgICAgICAgLy8gVW5pZm9ybSBsYWJlbCwgc2VlIGFscGhhYmV0LmRlY29kZSBhYm92ZS5cbiAgICAgICAgICAgIGFzdHIoJ2RlY29kZScsIGlucHV0KTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBpbnB1dC5sZW5ndGg7XG4gICAgICAgICAgICBpZiAoKGVuZCAqIGJpdHMpICUgOClcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3BhZGRpbmc6IGludmFsaWQgbGVuZ3RoJyk7XG4gICAgICAgICAgICBmb3IgKDsgZW5kID4gMCAmJiBpbnB1dFtlbmQgLSAxXSA9PT0gY2hyOyBlbmQtLSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGJ5dGUgPSAoZW5kIC0gMSkgKiBiaXRzO1xuICAgICAgICAgICAgICAgIGlmIChieXRlICUgOCA9PT0gMClcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdwYWRkaW5nOiBleGNlc3MgcGFkZGluZycpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGlucHV0LnNsaWNlKDAsIGVuZCk7XG4gICAgICAgIH0sXG4gICAgfTtcbn1cbmZ1bmN0aW9uIHVuc2FmZVdyYXBwZXIoZm4pIHtcbiAgICBhZm4oZm4pO1xuICAgIHJldHVybiBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICAvLyBPbmx5IGZvciAqVW5zYWZlIEFQSXMgdGhhdCBpbnRlbnRpb25hbGx5IGNvbGxhcHNlIHZhbGlkYXRpb24gZmFpbHVyZXMgdG8gYHVuZGVmaW5lZGAuXG4gICAgICAgIC8vIERvIG5vdCB3cmFwIGNvZGUgdGhhdCBuZWVkcyB0byBwcmVzZXJ2ZSBleGNlcHRpb24gZGV0YWlscy5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiBmbi5hcHBseShudWxsLCBhcmdzKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkgeyB9XG4gICAgfTtcbn1cbmZ1bmN0aW9uIGNoZWNrc3VtKGxlbiwgZm4pIHtcbiAgICBhbnVtYmVyKGxlbik7XG4gICAgLy8gUmVqZWN0IGRlZ2VuZXJhdGUgemVyby1ieXRlIGNoZWNrc3VtcyB1cCBmcm9udCBzbyBjYWxsZXJzIGRvbid0IGFjY2lkZW50YWxseVxuICAgIC8vIGJ1aWxkIGEgbm8tb3AgY2hlY2tzdW0gc3RhZ2UuXG4gICAgaWYgKGxlbiA8PSAwKVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgY2hlY2tzdW0gbGVuZ3RoIG11c3QgYmUgcG9zaXRpdmU6ICR7bGVufWApO1xuICAgIGFmbihmbik7XG4gICAgY29uc3QgX2ZuID0gZm47XG4gICAgLy8gVXNlcyB0aGUgZmlyc3QgYGxlbmAgYnl0ZXMgb2YgZm4oZGF0YSkgaW4gYm90aCBkaXJlY3Rpb25zLlxuICAgIC8vIEN1cnJlbnQgY2FsbCBzaXRlcyByZWx5IG9uIGBsZW4gPiAwYCBhbmQgY2hlY2tzdW0gZnVuY3Rpb25zIHRoYXQgcmV0dXJuIGF0IGxlYXN0IHRoYXQgbWFueSBieXRlcy5cbiAgICByZXR1cm4ge1xuICAgICAgICBlbmNvZGUoZGF0YSkge1xuICAgICAgICAgICAgYWJ5dGVzKGRhdGEpO1xuICAgICAgICAgICAgY29uc3Qgc3VtID0gX2ZuKGRhdGEpLnNsaWNlKDAsIGxlbik7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBuZXcgVWludDhBcnJheShkYXRhLmxlbmd0aCArIGxlbik7XG4gICAgICAgICAgICByZXMuc2V0KGRhdGEpO1xuICAgICAgICAgICAgcmVzLnNldChzdW0sIGRhdGEubGVuZ3RoKTtcbiAgICAgICAgICAgIHJldHVybiByZXM7XG4gICAgICAgIH0sXG4gICAgICAgIGRlY29kZShkYXRhKSB7XG4gICAgICAgICAgICBhYnl0ZXMoZGF0YSk7XG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkID0gZGF0YS5zbGljZSgwLCAtbGVuKTtcbiAgICAgICAgICAgIGNvbnN0IG9sZENoZWNrc3VtID0gZGF0YS5zbGljZSgtbGVuKTtcbiAgICAgICAgICAgIGNvbnN0IG5ld0NoZWNrc3VtID0gX2ZuKHBheWxvYWQpLnNsaWNlKDAsIGxlbik7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKVxuICAgICAgICAgICAgICAgIGlmIChuZXdDaGVja3N1bVtpXSAhPT0gb2xkQ2hlY2tzdW1baV0pXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBjaGVja3N1bScpO1xuICAgICAgICAgICAgcmV0dXJuIHBheWxvYWQ7XG4gICAgICAgIH0sXG4gICAgfTtcbn1cbi8vIFJGQyA0NjQ4IGFrYSBSRkMgMzU0OFxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vKipcbiAqIGJhc2UxNiBlbmNvZGluZyBmcm9tIFJGQyA0NjQ4LlxuICogVGhpcyBjb2RlYyB1c2VzIFJGQyA0NjQ4IFRhYmxlIDUncyB1cHBlcmNhc2UgYWxwaGFiZXQgZGlyZWN0bHkuXG4gKiBSRkMgNDY0OCDCpzggY2FsbHMgYmFzZTE2IFwiY2FzZS1pbnNlbnNpdGl2ZSBoZXggZW5jb2RpbmdcIiwgYnV0IHdlIGludGVudGlvbmFsbHkgZG8gbm90IGNhc2UtZm9sZCBkZWNvZGUgaW5wdXQgaGVyZS5cbiAqIFVzZSBgaGV4YCBmb3IgY2FzZS1pbnNlbnNpdGl2ZSBoZXggZGVjb2RpbmcuXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGJhc2UxNi5lbmNvZGUoVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSkpO1xuICogLy8gPT4gJzEyQUInXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGJhc2UxNiA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gY2hhaW4ocmFkaXgyKDQpLCBhbHBoYWJldCgnMDEyMzQ1Njc4OUFCQ0RFRicpKSk7XG4vKipcbiAqIGJhc2UzMiBlbmNvZGluZyBmcm9tIFJGQyA0NjQ4LiBIYXMgcGFkZGluZy5cbiAqIFJGQyA0NjQ4IMKnNiBUYWJsZSAzIHVzZXMgdXBwZXJjYXNlIGxldHRlcnMsIGFuZCBSRkMgNDY0OCDCpzMuNCBhbGxvd3MgYXBwbGljYXRpb25zIHRvIGNob29zZVxuICogdXBwZXItIG9yIGxvd2VyY2FzZSBhbHBoYWJldHMuIFdlIGtlZXAgdGhlIHB1Ymxpc2hlZCB1cHBlcmNhc2UgdGFibGUgYW5kIGRvIG5vdCBjYXNlLWZvbGQgZGVjb2RlIGlucHV0LlxuICogVXNlIGBiYXNlMzJub3BhZGAgZm9yIHVucGFkZGVkIHZlcnNpb24uXG4gKiBBbHNvIGNoZWNrIG91dCBgYmFzZTMyaGV4YCwgYGJhc2UzMmhleG5vcGFkYCwgYGJhc2UzMmNyb2NrZm9yZGAuXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGJhc2UzMi5lbmNvZGUoVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSkpO1xuICogLy8gPT4gJ0NLVlE9PT09J1xuICogYmFzZTMyLmRlY29kZSgnQ0tWUT09PT0nKTtcbiAqIC8vID0+IFVpbnQ4QXJyYXkuZnJvbShbMHgxMiwgMHhhYl0pXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGJhc2UzMiA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gY2hhaW4ocmFkaXgyKDUpLCBhbHBoYWJldCgnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVoyMzQ1NjcnKSwgcGFkZGluZyg1KSkpO1xuLyoqXG4gKiBiYXNlMzIgZW5jb2RpbmcgZnJvbSBSRkMgNDY0OC4gTm8gcGFkZGluZy5cbiAqIFRoaXMgdmFyaWFudCBpbmhlcml0cyBSRkMgNDY0OCBiYXNlMzIncyB1cHBlcmNhc2UgdGFibGUgYW5kIGludGVudGlvbmFsbHkgZG9lcyBub3QgY2FzZS1mb2xkIGRlY29kZSBpbnB1dC5cbiAqIFVzZSBgYmFzZTMyYCBmb3IgcGFkZGVkIHZlcnNpb24uXG4gKiBBbHNvIGNoZWNrIG91dCBgYmFzZTMyaGV4YCwgYGJhc2UzMmhleG5vcGFkYCwgYGJhc2UzMmNyb2NrZm9yZGAuXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGJhc2UzMm5vcGFkLmVuY29kZShVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKSk7XG4gKiAvLyA9PiAnQ0tWUSdcbiAqIGJhc2UzMm5vcGFkLmRlY29kZSgnQ0tWUScpO1xuICogLy8gPT4gVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSlcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYmFzZTMybm9wYWQgPSAvKiBAX19QVVJFX18gKi8gZnJlZXplKCgpID0+IGNoYWluKHJhZGl4Mig1KSwgYWxwaGFiZXQoJ0FCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaMjM0NTY3JykpKTtcbi8qKlxuICogYmFzZTMyIGVuY29kaW5nIGZyb20gUkZDIDQ2NDguIFBhZGRlZC4gQ29tcGFyZWQgdG8gb3JkaW5hcnkgYGJhc2UzMmAsIHNsaWdodGx5IGRpZmZlcmVudCBhbHBoYWJldC5cbiAqIFJGQyA0NjQ4IMKnNyBUYWJsZSA0IHVzZXMgdXBwZXJjYXNlIGxldHRlcnMsIGFuZCB3ZSBpbnRlbnRpb25hbGx5IGtlZXAgdGhhdCB0YWJsZSB3aXRob3V0IGNhc2UtZm9sZGluZyBkZWNvZGUgaW5wdXQuXG4gKiBVc2UgYGJhc2UzMmhleG5vcGFkYCBmb3IgdW5wYWRkZWQgdmVyc2lvbi5cbiAqIEBleGFtcGxlXG4gKiBgYGBqc1xuICogYmFzZTMyaGV4LmVuY29kZShVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKSk7XG4gKiAvLyA9PiAnMkFMRz09PT0nXG4gKiBiYXNlMzJoZXguZGVjb2RlKCcyQUxHPT09PScpO1xuICogLy8gPT4gVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSlcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYmFzZTMyaGV4ID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBjaGFpbihyYWRpeDIoNSksIGFscGhhYmV0KCcwMTIzNDU2Nzg5QUJDREVGR0hJSktMTU5PUFFSU1RVVicpLCBwYWRkaW5nKDUpKSk7XG4vKipcbiAqIGJhc2UzMiBlbmNvZGluZyBmcm9tIFJGQyA0NjQ4LiBObyBwYWRkaW5nLiBDb21wYXJlZCB0byBvcmRpbmFyeSBgYmFzZTMyYCwgc2xpZ2h0bHkgZGlmZmVyZW50IGFscGhhYmV0LlxuICogVGhpcyB2YXJpYW50IGluaGVyaXRzIFJGQyA0NjQ4IGJhc2UzMmhleCdzIHVwcGVyY2FzZSB0YWJsZSBhbmQgaW50ZW50aW9uYWxseSBkb2VzIG5vdCBjYXNlLWZvbGQgZGVjb2RlIGlucHV0LlxuICogVXNlIGBiYXNlMzJoZXhgIGZvciBwYWRkZWQgdmVyc2lvbi5cbiAqIEBleGFtcGxlXG4gKiBgYGBqc1xuICogYmFzZTMyaGV4bm9wYWQuZW5jb2RlKFVpbnQ4QXJyYXkuZnJvbShbMHgxMiwgMHhhYl0pKTtcbiAqIC8vID0+ICcyQUxHJ1xuICogYmFzZTMyaGV4bm9wYWQuZGVjb2RlKCcyQUxHJyk7XG4gKiAvLyA9PiBVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKVxuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBiYXNlMzJoZXhub3BhZCA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gY2hhaW4ocmFkaXgyKDUpLCBhbHBoYWJldCgnMDEyMzQ1Njc4OUFCQ0RFRkdISUpLTE1OT1BRUlNUVVYnKSkpO1xuLyoqXG4gKiBiYXNlMzIgZW5jb2RpbmcgZnJvbSBSRkMgNDY0OC4gRG91ZyBDcm9ja2ZvcmQncyB2ZXJzaW9uLlxuICogU2VlIHtAbGluayBodHRwczovL3d3dy5jcm9ja2ZvcmQuY29tL2Jhc2UzMi5odG1sIHwgRG91Z2xhcyBDcm9ja2ZvcmQncyBCYXNlMzJ9LlxuICogQGV4YW1wbGVcbiAqIGBgYGpzXG4gKiBiYXNlMzJjcm9ja2ZvcmQuZW5jb2RlKFVpbnQ4QXJyYXkuZnJvbShbMHgxMiwgMHhhYl0pKTtcbiAqIC8vID0+ICcyQU5HJ1xuICogYmFzZTMyY3JvY2tmb3JkLmRlY29kZSgnMkFORycpO1xuICogLy8gPT4gVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSlcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYmFzZTMyY3JvY2tmb3JkID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBjaGFpbihyYWRpeDIoNSksIGFscGhhYmV0KCcwMTIzNDU2Nzg5QUJDREVGR0hKS01OUFFSU1RWV1hZWicpLCBub3JtYWxpemUoKHMpID0+IHtcbiAgICBhc3RyKCdiYXNlMzJjcm9ja2ZvcmQuZGVjb2RlJywgcyk7XG4gICAgcmV0dXJuIHMudG9VcHBlckNhc2UoKS5yZXBsYWNlKC9PL2csICcwJykucmVwbGFjZSgvW0lMXS9nLCAnMScpO1xufSkpKTtcbi8vIEJ1aWx0LWluIGJhc2U2NCBjb252ZXJzaW9uIGh0dHBzOi8vY2FuaXVzZS5jb20vbWRuLWphdmFzY3JpcHRfYnVpbHRpbnNfdWludDhhcnJheV9mcm9tYmFzZTY0XG4vLyBSZXF1aXJlIGJvdGggZGlyZWN0aW9ucyBiZWZvcmUgdGFraW5nIHRoZSBuYXRpdmUgZmFzdCBwYXRoLCBzbyBiYXNlNjQvYmFzZTY0dXJsIGRvbid0IG1peCBuYXRpdmUgYW5kIEpTIGJlaGF2aW9yLlxuLy8gcHJldHRpZXItaWdub3JlXG5jb25zdCBoYXNCYXNlNjRCdWlsdGluID0gLyogQF9fUFVSRV9fICovICgoKSA9PiB0eXBlb2YgVWludDhBcnJheS5mcm9tKFtdKS50b0Jhc2U2NCA9PT0gJ2Z1bmN0aW9uJyAmJlxuICAgIHR5cGVvZiBVaW50OEFycmF5LmZyb21CYXNlNjQgPT09ICdmdW5jdGlvbicpKCk7XG4vLyBOYXRpdmUgYFVpbnQ4QXJyYXkuZnJvbUJhc2U2NCgpYCBhY2NlcHRzIHRoZXNlIEFTQ0lJIHdoaXRlc3BhY2UgY2hhcnMuXG4vLyBSZWplY3QgdGhlbSBmaXJzdCBzbyB0aGUgbmF0aXZlIGJhc2U2NCBwYXRoIHN0aWxsIGZvbGxvd3MgUkZDIDQ2NDggwqczLjMuXG4vLyBBU0NJSSB3aGl0ZXNwYWNlIGlzIFUrMDAwOSBUQUIsIFUrMDAwQSBMRiwgVSswMDBDIEZGLCBVKzAwMEQgQ1IsIG9yIFUrMDAyMCBTUEFDRVxuY29uc3QgQVNDSUlfV0hJVEVTUEFDRSA9IC9bXFx0XFxuXFxmXFxyIF0vO1xuY29uc3QgZGVjb2RlQmFzZTY0QnVpbHRpbiA9IChzLCBpc1VybCkgPT4ge1xuICAgIGFzdHIoJ2Jhc2U2NCcsIHMpO1xuICAgIGNvbnN0IGFscGhhYmV0ID0gaXNVcmwgPyAnYmFzZTY0dXJsJyA6ICdiYXNlNjQnO1xuICAgIC8vIFBlciBzcGVjLCAuZnJvbUJhc2U2NCBhbHJlYWR5IHRocm93cyBvbiBhbnkgb3RoZXIgbm9uLWFscGhhYmV0IHN5bWJvbHMgZXhjZXB0IEFTQ0lJIHdoaXRlc3BhY2VcbiAgICAvLyBBbmQgY2hlY2tpbmcganVzdCBmb3Igd2hpdGVzcGFjZSBtYWtlcyBkZWNvZGluZyBhYm91dCAzeCBmYXN0ZXIgdGhhbiBhIGZ1bGwgcmFuZ2UgY2hlY2suXG4gICAgLy8gbGFzdENodW5rSGFuZGxpbmc6ICdzdHJpY3QnIHJlamVjdHMgbG9vc2UgdGFpbHMgYW5kIG5vbi16ZXJvIHBhZCBiaXRzIHNvIG5hdGl2ZSBkZWNvZGluZyBzdGF5cyBjYW5vbmljYWwuXG4gICAgaWYgKHMubGVuZ3RoID4gMCAmJiBBU0NJSV9XSElURVNQQUNFLnRlc3QocykpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBiYXNlNjQnKTtcbiAgICByZXR1cm4gVWludDhBcnJheS5mcm9tQmFzZTY0KHMsIHsgYWxwaGFiZXQsIGxhc3RDaHVua0hhbmRsaW5nOiAnc3RyaWN0JyB9KTtcbn07XG4vKiogYmFzZTY0IGZyb20gUkZDIDQ2NDguIFBhZGRlZC4gUHVyZSBKUyB2ZXJzaW9uICovXG5jb25zdCBiYXNlNjRGYWxsYmFjayA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gY2hhaW4ocmFkaXgyKDYpLCBhbHBoYWJldCgnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLycpLCBwYWRkaW5nKDYpKSk7XG4vKipcbiAqIGJhc2U2NCBmcm9tIFJGQyA0NjQ4LiBQYWRkZWQuXG4gKiBBbHRlcm5hdGl2ZSB2YXJpYW50czogYGJhc2U2NG5vcGFkYCwgYGJhc2U2NHVybGAsIGBiYXNlNjR1cmxub3BhZGAuXG4gKiBVdGlsaXplcyBuYXRpdmUgYFVpbnQ4QXJyYXkuZnJvbUJhc2U2NGAgYnVpbHRpbiwgb3RoZXJ3aXNlIGZhbGxzIGJhY2sgdG8gYGJhc2U2NGZhbGxiYWNrYCB3aGVuIGl0J3MgdW5hdmFpbGFibGUuXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGJhc2U2NC5lbmNvZGUoVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSkpO1xuICogLy8gPT4gJ0Vxcz0nXG4gKiBiYXNlNjQuZGVjb2RlKCdFcXM9Jyk7XG4gKiAvLyA9PiBVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKVxuICogYGBgXG4gKi9cbi8vIHByZXR0aWVyLWlnbm9yZVxuZXhwb3J0IGNvbnN0IGJhc2U2NCA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gaGFzQmFzZTY0QnVpbHRpbiA/IHtcbiAgICBlbmNvZGUoYikgeyBhYnl0ZXMoYik7IHJldHVybiBiLnRvQmFzZTY0KCk7IH0sXG4gICAgZGVjb2RlKHMpIHsgcmV0dXJuIGRlY29kZUJhc2U2NEJ1aWx0aW4ocywgZmFsc2UpOyB9LFxufSA6IGJhc2U2NEZhbGxiYWNrKTtcbi8qKlxuICogYmFzZTY0IGZyb20gUkZDIDQ2NDguIE5vIHBhZGRpbmcuXG4gKiBVc2UgYGJhc2U2NGAgZm9yIHBhZGRlZCB2ZXJzaW9uLlxuICogQGV4YW1wbGVcbiAqIGBgYGpzXG4gKiBiYXNlNjRub3BhZC5lbmNvZGUoVWludDhBcnJheS5mcm9tKFsweDEyLCAweGFiXSkpO1xuICogLy8gPT4gJ0VxcydcbiAqIGJhc2U2NG5vcGFkLmRlY29kZSgnRXFzJyk7XG4gKiAvLyA9PiBVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKVxuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBiYXNlNjRub3BhZCA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gY2hhaW4ocmFkaXgyKDYpLCBhbHBoYWJldCgnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLycpKSk7XG4vKipcbiAqIGJhc2U2NCBmcm9tIFJGQyA0NjQ4LCB1c2luZyBVUkwtc2FmZSBhbHBoYWJldC4gUGFkZGVkLlxuICogVXNlIGBiYXNlNjR1cmxub3BhZGAgZm9yIHVucGFkZGVkIHZlcnNpb24uXG4gKiBGYWxscyBiYWNrIHRvIGJ1aWx0LWluIGZ1bmN0aW9uLCB3aGVuIGF2YWlsYWJsZS5cbiAqIEBleGFtcGxlXG4gKiBgYGBqc1xuICogYmFzZTY0dXJsLmVuY29kZShVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKSk7XG4gKiAvLyA9PiAnRXFzPSdcbiAqIGJhc2U2NHVybC5kZWNvZGUoJ0Vxcz0nKTtcbiAqIC8vID0+IFVpbnQ4QXJyYXkuZnJvbShbMHgxMiwgMHhhYl0pXG4gKiBgYGBcbiAqL1xuLy8gcHJldHRpZXItaWdub3JlXG5leHBvcnQgY29uc3QgYmFzZTY0dXJsID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBoYXNCYXNlNjRCdWlsdGluID8ge1xuICAgIGVuY29kZShiKSB7IGFieXRlcyhiKTsgcmV0dXJuIGIudG9CYXNlNjQoeyBhbHBoYWJldDogJ2Jhc2U2NHVybCcgfSk7IH0sXG4gICAgZGVjb2RlKHMpIHsgcmV0dXJuIGRlY29kZUJhc2U2NEJ1aWx0aW4ocywgdHJ1ZSk7IH0sXG59IDogY2hhaW4ocmFkaXgyKDYpLCBhbHBoYWJldCgnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODktXycpLCBwYWRkaW5nKDYpKSk7XG4vKipcbiAqIGJhc2U2NCBmcm9tIFJGQyA0NjQ4LCB1c2luZyBVUkwtc2FmZSBhbHBoYWJldC4gTm8gcGFkZGluZy5cbiAqIFVzZSBgYmFzZTY0dXJsYCBmb3IgcGFkZGVkIHZlcnNpb24uXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGJhc2U2NHVybG5vcGFkLmVuY29kZShVaW50OEFycmF5LmZyb20oWzB4MTIsIDB4YWJdKSk7XG4gKiAvLyA9PiAnRXFzJ1xuICogYmFzZTY0dXJsbm9wYWQuZGVjb2RlKCdFcXMnKTtcbiAqIC8vID0+IFVpbnQ4QXJyYXkuZnJvbShbMHgxMiwgMHhhYl0pXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGJhc2U2NHVybG5vcGFkID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBjaGFpbihyYWRpeDIoNiksIGFscGhhYmV0KCdBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OS1fJykpKTtcbi8vIGJhc2U1OCBjb2RlXG4vLyAtLS0tLS0tLS0tLVxuLy8gQmFzZSBjb252ZXJzaW9uIDI1NiA8LT4gNTggZG9uZSBvbiAxNi1iaXQgbGltYnMsIGZpdmUgYmFzZTU4IGRpZ2l0cyAob25lIGRpdm1vZCBieVxuLy8gNTgqKjUpIHBlciBwYXNzLCB+MTB4IGZld2VyIGlubmVyLWxvb3AgaXRlcmF0aW9ucyB0aGFuIGRpZ2l0LWF0LWEtdGltZSBjb252ZXJzaW9uLlxuLy8gRXhhY3RuZXNzOiBldmVyeSBpbnRlcm1lZGlhdGUgaXMgYSBub24tbmVnYXRpdmUgaW50ZWdlciBiZWxvdyAyKio1Mywgc28gZmxvYXQ2NFxuLy8gYXJpdGhtZXRpYyAoaW5jbHVkaW5nIE1hdGguZmxvb3Igb2YgdGhlIHF1b3RpZW50cykgaXMgZXhhY3Q6XG4vLyAtIGVuY29kZTogY2FycnkgKiAyKioxNiArIGxpbWIgPCA1OCoqNSAqIDIqKjE2IDwgMioqNDZcbi8vIC0gZGVjb2RlOiBsaW1iICogNTgqKjUgKyBjYXJyeSA8IDIqKjE2ICogNTgqKjUgKyAyKiozMCA8IDIqKjQ2XG4vLyBTdGlsbCBPKG5eMikgb3ZlcmFsbCBsaWtlIGFueSBwb3NpdGlvbmFsLWJhc2UgY29udmVyc2lvbiDigJQgc2VlIHRoZSBiYXNlNTggRG9TIG5vdGUuXG5jb25zdCBCNThfR1JPVVAgPSA2NTYzNTY3Njg7IC8vIDU4Kio1IDwgMioqMzA7IGxpdGVyYWwgKG5vdCBgNTggKiogNWApIHNvIGJ1bmRsZXJzIGNhbiBkcm9wIGl0IGFzIGRlYWQgY29kZVxuY29uc3QgcmFkaXg1OCA9IHtcbiAgICBlbmNvZGU6IChieXRlcykgPT4ge1xuICAgICAgICBhYnl0ZXMoYnl0ZXMpO1xuICAgICAgICBjb25zdCBibGVuID0gYnl0ZXMubGVuZ3RoO1xuICAgICAgICBpZiAoYmxlbiA9PT0gMClcbiAgICAgICAgICAgIHJldHVybiBuZXcgVWludDhBcnJheSgwKTtcbiAgICAgICAgLy8gTGVhZGluZyB6ZXJvIGJ5dGVzIG1hcCAxOjEgdG8gbGVhZGluZyB6ZXJvIGRpZ2l0cyAoYXQgbW9zdCBibGVuLTEgZXhwbGljaXQgemVyb3M7XG4gICAgICAgIC8vIGFuIGFsbC16ZXJvIHZhbHVlIHN0aWxsIGNvbnRyaWJ1dGVzIG9uZSBkaWdpdCBiZWxvdykuXG4gICAgICAgIGxldCB6ZXJvcyA9IDA7XG4gICAgICAgIHdoaWxlICh6ZXJvcyA8IGJsZW4gLSAxICYmIGJ5dGVzW3plcm9zXSA9PT0gMClcbiAgICAgICAgICAgIHplcm9zKys7XG4gICAgICAgIC8vIFBhY2sgYmlnLWVuZGlhbiAxNi1iaXQgbGltYnM7IG9kZCBsZW5ndGggbWFrZXMgdGhlIHRvcCBsaW1iIGEgc2luZ2xlIGJ5dGUuXG4gICAgICAgIGNvbnN0IG5saW1icyA9IE1hdGguY2VpbChibGVuIC8gMik7XG4gICAgICAgIGNvbnN0IGxpbWJzID0gbmV3IFVpbnQxNkFycmF5KG5saW1icyk7XG4gICAgICAgIGNvbnN0IG9kZCA9IGJsZW4gJiAxO1xuICAgICAgICBpZiAob2RkKVxuICAgICAgICAgICAgbGltYnNbMF0gPSBieXRlc1swXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IG9kZCwgaiA9IG9kZDsgaSA8IGJsZW47IGkgKz0gMiwgaisrKVxuICAgICAgICAgICAgbGltYnNbal0gPSAoYnl0ZXNbaV0gPDwgOCkgfCBieXRlc1tpICsgMV07XG4gICAgICAgIC8vIFJlcGVhdGVkIGRpdm1vZCBieSA1OCoqNTsgZWFjaCBwYXNzIGVtaXRzIG9uZSA1LWRpZ2l0IGdyb3VwLCBsZWFzdCBzaWduaWZpY2FudFxuICAgICAgICAvLyBmaXJzdC4gTm8gY2Fycnktb3ZlcmZsb3cgZ3VhcmQgbGlrZSBjb252ZXJ0UmFkaXggaGFkOiB0aGF0IG9uZSBmYWNlZCBhcmJpdHJhcnlcbiAgICAgICAgLy8gY2FsbGVyLWNob3NlbiBiYXNlcywgd2hpbGUgdGhlc2UgYm91bmRzIGFyZSBzdGF0aWMgYW5kIHByb3ZlbiBleGFjdCBhYm92ZS5cbiAgICAgICAgY29uc3QgZ3JvdXBzID0gW107XG4gICAgICAgIGxldCBwb3MgPSAwOyAvLyBsaW1icyBiZWZvcmUgcG9zIGFyZSBrbm93biB6ZXJvXG4gICAgICAgIHdoaWxlIChwb3MgPCBubGltYnMpIHtcbiAgICAgICAgICAgIGxldCBjYXJyeSA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gcG9zOyBpIDwgbmxpbWJzOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjdXIgPSBjYXJyeSAqIDB4MTAwMDAgKyBsaW1ic1tpXTtcbiAgICAgICAgICAgICAgICBjb25zdCBxID0gTWF0aC5mbG9vcihjdXIgLyBCNThfR1JPVVApO1xuICAgICAgICAgICAgICAgIGNhcnJ5ID0gY3VyIC0gcSAqIEI1OF9HUk9VUDtcbiAgICAgICAgICAgICAgICBsaW1ic1tpXSA9IHE7XG4gICAgICAgICAgICAgICAgaWYgKHEgPT09IDAgJiYgaSA9PT0gcG9zKVxuICAgICAgICAgICAgICAgICAgICBwb3MrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGdyb3Vwcy5wdXNoKGNhcnJ5KTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUaGUgdG9wIGdyb3VwIGlzIG5vbnplcm8gdW5sZXNzIHRoZSB3aG9sZSB2YWx1ZSBpcyB6ZXJvLCBzbyB0b3RhbCBzaWduaWZpY2FudFxuICAgICAgICAvLyBkaWdpdCBjb3VudCBpcyA1IHBlciBmdWxsIGdyb3VwIHBsdXMgdGhlIHRvcCBncm91cCdzIG93biB3aWR0aC4gKFdyaXRpbmcgNSBkaWdpdHNcbiAgICAgICAgLy8gcGVyIGdyb3VwIGFuZCB0cmltbWluZyB2aWEgc3ViYXJyYXkgaXMgc21hbGxlciBjb2RlLCBidXQgdGhlIG9mZnNldCB2aWV3IHNsb3dzXG4gICAgICAgIC8vIGVuY29kZSB+MjUlIGFuZCBiYXNlNTh4bXIgMngg4oCUIG1lYXN1cmVkLilcbiAgICAgICAgY29uc3QgdG9wID0gZ3JvdXBzLmxlbmd0aCAtIDE7XG4gICAgICAgIGxldCBzaWcgPSB0b3AgKiA1O1xuICAgICAgICBmb3IgKGxldCB2ID0gZ3JvdXBzW3RvcF07OyB2ID0gTWF0aC5mbG9vcih2IC8gNTgpKSB7XG4gICAgICAgICAgICBzaWcrKztcbiAgICAgICAgICAgIGlmICh2IDwgNTgpXG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzID0gbmV3IFVpbnQ4QXJyYXkoemVyb3MgKyBzaWcpOyAvLyBsZWFkaW5nIHplcm8gZGlnaXRzIGFyZSBhbHJlYWR5IDBcbiAgICAgICAgbGV0IGogPSByZXMubGVuZ3RoIC0gMTtcbiAgICAgICAgZm9yIChsZXQgZyA9IDA7IGcgPCB0b3A7IGcrKykge1xuICAgICAgICAgICAgbGV0IHYgPSBncm91cHNbZ107XG4gICAgICAgICAgICBmb3IgKGxldCBrID0gMDsgayA8IDU7IGsrKykge1xuICAgICAgICAgICAgICAgIHJlc1tqLS1dID0gdiAlIDU4O1xuICAgICAgICAgICAgICAgIHYgPSBNYXRoLmZsb29yKHYgLyA1OCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgdiA9IGdyb3Vwc1t0b3BdOyBqID49IHplcm9zOyB2ID0gTWF0aC5mbG9vcih2IC8gNTgpKVxuICAgICAgICAgICAgcmVzW2otLV0gPSB2ICUgNTg7XG4gICAgICAgIHJldHVybiByZXM7XG4gICAgfSxcbiAgICBkZWNvZGU6IChkaWdpdHMpID0+IHtcbiAgICAgICAgYWJ5dGVzKGRpZ2l0cyk7XG4gICAgICAgIGNvbnN0IGRsZW4gPSBkaWdpdHMubGVuZ3RoO1xuICAgICAgICBpZiAoZGxlbiA9PT0gMClcbiAgICAgICAgICAgIHJldHVybiBuZXcgVWludDhBcnJheSgwKTtcbiAgICAgICAgaWYgKGRsZW4gPj0gNjU1MzYpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgbGVuZ3RoJyk7XG4gICAgICAgIGxldCB6ZXJvcyA9IDA7XG4gICAgICAgIHdoaWxlICh6ZXJvcyA8IGRsZW4gLSAxICYmIGRpZ2l0c1t6ZXJvc10gPT09IDApXG4gICAgICAgICAgICB6ZXJvcysrO1xuICAgICAgICAvLyBNdWx0aXBseS1hY2N1bXVsYXRlIDE2LWJpdCBsaW1icyAobGl0dGxlLWVuZGlhbiwgYHVzZWRgIGxpdmUpIGdyb3VwIGJ5IGdyb3VwLFxuICAgICAgICAvLyBtb3N0IHNpZ25pZmljYW50IGdyb3VwIGZpcnN0OyB0aGUgZmlyc3QgZ3JvdXAgbWF5IGJlIHNob3J0ZXIgdGhhbiA1IGRpZ2l0cywgYW5kXG4gICAgICAgIC8vIGl0cyA1OCoqZ3JvdXAgZmFjdG9yIGZhbGxzIG91dCBvZiB0aGUgZGlnaXQgZm9sZC5cbiAgICAgICAgY29uc3QgbGltYnMgPSBuZXcgVWludDE2QXJyYXkoTWF0aC5jZWlsKChkbGVuICogNikgLyAxNikgKyAxKTtcbiAgICAgICAgbGV0IHVzZWQgPSAwO1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIGxldCBncm91cCA9IGRsZW4gJSA1IHx8IDU7XG4gICAgICAgIHdoaWxlIChpIDwgZGxlbikge1xuICAgICAgICAgICAgbGV0IGd2YWwgPSAwO1xuICAgICAgICAgICAgbGV0IGZhY3RvciA9IDE7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVuZCA9IGkgKyBncm91cDsgaSA8IGVuZDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZCA9IGRpZ2l0c1tpXTtcbiAgICAgICAgICAgICAgICAvLyBVbnJlYWNoYWJsZSB0aHJvdWdoIHRoZSBwdWJsaWMgY2hhaW4gKGFscGhhYmV0IGVtaXRzIGRpZ2l0cyA8IDU4KTsgZ3VhcmRzXG4gICAgICAgICAgICAgICAgLy8gaW50ZXJuYWwgbWlzdXNlIGZyb20gc2lsZW50bHkgY29ycnVwdGluZyBvdXRwdXQuXG4gICAgICAgICAgICAgICAgaWYgKGQgPj0gNTgpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgaW52YWxpZCBpbnRlZ2VyOiAke2R9YCk7XG4gICAgICAgICAgICAgICAgZ3ZhbCA9IGd2YWwgKiA1OCArIGQ7XG4gICAgICAgICAgICAgICAgZmFjdG9yICo9IDU4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZ3JvdXAgPSA1O1xuICAgICAgICAgICAgbGV0IGNhcnJ5ID0gZ3ZhbDtcbiAgICAgICAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgdXNlZDsgaysrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY3VyID0gbGltYnNba10gKiBmYWN0b3IgKyBjYXJyeTtcbiAgICAgICAgICAgICAgICBjYXJyeSA9IE1hdGguZmxvb3IoY3VyIC8gMHgxMDAwMCk7XG4gICAgICAgICAgICAgICAgbGltYnNba10gPSBjdXIgLSBjYXJyeSAqIDB4MTAwMDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKDsgY2FycnkgPiAwOyBjYXJyeSA9IE1hdGguZmxvb3IoY2FycnkgLyAweDEwMDAwKSlcbiAgICAgICAgICAgICAgICBsaW1ic1t1c2VkKytdID0gY2FycnkgJSAweDEwMDAwO1xuICAgICAgICB9XG4gICAgICAgIC8vIHVzZWQgPT09IDAgbWVhbnMgdGhlIHZhbHVlIGlzIHplcm86IGl0IHN0aWxsIGNvbnRyaWJ1dGVzIG9uZSBieXRlLCBsaWtlIGEgbG9uZVxuICAgICAgICAvLyB6ZXJvIGRpZ2l0IGRvZXMuXG4gICAgICAgIGNvbnN0IHZhbHVlQnl0ZXMgPSB1c2VkID09PSAwID8gMSA6IHVzZWQgKiAyIC0gKGxpbWJzW3VzZWQgLSAxXSA8IDI1NiA/IDEgOiAwKTtcbiAgICAgICAgY29uc3QgcmVzID0gbmV3IFVpbnQ4QXJyYXkoemVyb3MgKyB2YWx1ZUJ5dGVzKTsgLy8gbGVhZGluZyB6ZXJvIGJ5dGVzIGFyZSBhbHJlYWR5IDBcbiAgICAgICAgbGV0IGogPSByZXMubGVuZ3RoIC0gMTtcbiAgICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCB1c2VkOyBrKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGxpbWIgPSBsaW1ic1trXTtcbiAgICAgICAgICAgIHJlc1tqLS1dID0gbGltYiAmIDB4ZmY7XG4gICAgICAgICAgICBpZiAoaiA+PSB6ZXJvcylcbiAgICAgICAgICAgICAgICByZXNbai0tXSA9IGxpbWIgPj4gODtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzO1xuICAgIH0sXG59O1xuY29uc3QgZ2VuQmFzZTU4ID0gKGFiYykgPT4gY2hhaW4ocmFkaXg1OCwgYWxwaGFiZXQoYWJjKSk7XG4vKipcbiAqIGJhc2U1ODogYmFzZTY0IHdpdGhvdXQgYW1iaWdvdXMgY2hhcmFjdGVycyArLCAvLCAwLCBPLCBJLCBsLlxuICogUXVhZHJhdGljIChPKG5eMikpIC0gc28sIGNhbid0IGJlIHVzZWQgb24gbGFyZ2UgaW5wdXRzLlxuICogQGV4YW1wbGVcbiAqIGBgYGpzXG4gKiBjb25zdCB0ZXh0ID0gYmFzZTU4LmVuY29kZShVaW50OEFycmF5LmZyb20oWzAsIDEsIDJdKSk7XG4gKiBiYXNlNTguZGVjb2RlKHRleHQpO1xuICogLy8gPT4gVWludDhBcnJheS5mcm9tKFswLCAxLCAyXSlcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYmFzZTU4ID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBnZW5CYXNlNTgoJzEyMzQ1Njc4OUFCQ0RFRkdISktMTU5QUVJTVFVWV1hZWmFiY2RlZmdoaWprbW5vcHFyc3R1dnd4eXonKSk7XG4vKipcbiAqIGJhc2U1ODogZmxpY2tyIHZlcnNpb24uIENoZWNrIG91dCBgYmFzZTU4YC5cbiAqIEBleGFtcGxlXG4gKiBSb3VuZC10cmlwIGJ5dGVzIHdpdGggdGhlIEZsaWNrciBhbHBoYWJldC5cbiAqIGBgYHRzXG4gKiBjb25zdCB0ZXh0ID0gYmFzZTU4ZmxpY2tyLmVuY29kZShVaW50OEFycmF5LmZyb20oWzAsIDEsIDJdKSk7XG4gKiBiYXNlNThmbGlja3IuZGVjb2RlKHRleHQpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBiYXNlNThmbGlja3IgPSAvKiBAX19QVVJFX18gKi8gZnJlZXplKCgpID0+IGdlbkJhc2U1OCgnMTIzNDU2Nzg5YWJjZGVmZ2hpamttbm9wcXJzdHV2d3h5ekFCQ0RFRkdISktMTU5QUVJTVFVWV1hZWicpKTtcbi8qKlxuICogYmFzZTU4OiBYUlAgdmVyc2lvbi4gQ2hlY2sgb3V0IGBiYXNlNThgLlxuICogQGV4YW1wbGVcbiAqIFJvdW5kLXRyaXAgYnl0ZXMgd2l0aCB0aGUgWFJQIGFscGhhYmV0LlxuICogYGBgdHNcbiAqIGNvbnN0IHRleHQgPSBiYXNlNTh4cnAuZW5jb2RlKFVpbnQ4QXJyYXkuZnJvbShbMCwgMSwgMl0pKTtcbiAqIGJhc2U1OHhycC5kZWNvZGUodGV4dCk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGJhc2U1OHhycCA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gZ2VuQmFzZTU4KCdycHNobmFmMzl3QlVETkVHSEpLTE00UFFSU1Q3VldYWVoyYmNkZUNnNjVqa204b0ZxaTF0dXZBeHl6JykpO1xuLy8gRGF0YSBsZW4gKGluZGV4KSAtPiBlbmNvZGVkIGJsb2NrIGxlbi5cbi8vIE1vbmVybyBwYWRzIGVhY2ggMS4uOC1ieXRlIGJsb2NrIHRvIHRoaXMgZml4ZWQgYmFzZTU4IHdpZHRoIHNvIGRlY29kZSBjYW4gcmVjb3ZlciB0aGUgdGFpbCBsZW5ndGguXG5jb25zdCBYTVJfQkxPQ0tfTEVOID0gWzAsIDIsIDMsIDUsIDYsIDcsIDksIDEwLCAxMV07XG4vKipcbiAqIGJhc2U1ODogWE1SIHZlcnNpb24uIENoZWNrIG91dCBgYmFzZTU4YC5cbiAqIERvbmUgaW4gOC1ieXRlIGJsb2NrcyAod2hpY2ggZXF1YWxzIDExIGNoYXJzIGluIGRlY29kaW5nKS4gTGFzdCAobm9uLWZ1bGwpIGJsb2NrIHBhZGRlZCB3aXRoICcxJyB0byBzaXplIGluIFhNUl9CTE9DS19MRU4uXG4gKiBCbG9jayBlbmNvZGluZyBzaWduaWZpY2FudGx5IHJlZHVjZXMgcXVhZHJhdGljIGNvbXBsZXhpdHkgb2YgYmFzZTU4LlxuICogQGV4YW1wbGVcbiAqIFJvdW5kLXRyaXAgYnl0ZXMgd2l0aCB0aGUgTW9uZXJvIGJsb2NrIGNvZGVjLlxuICogYGBgdHNcbiAqIGNvbnN0IHRleHQgPSBiYXNlNTh4bXIuZW5jb2RlKFVpbnQ4QXJyYXkuZnJvbShbMCwgMSwgMl0pKTtcbiAqIGJhc2U1OHhtci5kZWNvZGUodGV4dCk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGJhc2U1OHhtciA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4gKHtcbiAgICBlbmNvZGUoZGF0YSkge1xuICAgICAgICBhYnl0ZXMoZGF0YSk7XG4gICAgICAgIGxldCByZXMgPSAnJztcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSArPSA4KSB7XG4gICAgICAgICAgICBjb25zdCBibG9jayA9IGRhdGEuc3ViYXJyYXkoaSwgaSArIDgpO1xuICAgICAgICAgICAgcmVzICs9IGJhc2U1OC5lbmNvZGUoYmxvY2spLnBhZFN0YXJ0KFhNUl9CTE9DS19MRU5bYmxvY2subGVuZ3RoXSwgJzEnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzO1xuICAgIH0sXG4gICAgZGVjb2RlKHN0cikge1xuICAgICAgICBhc3RyKCdiYXNlNTh4bXIuZGVjb2RlJywgc3RyKTtcbiAgICAgICAgY29uc3Qgc3RyTGVuID0gc3RyLmxlbmd0aDtcbiAgICAgICAgLy8gT25seSB0aGUgbGFzdCBibG9jayBtYXkgYmUgc2hvcnQsIGFuZCBvbmx5IHRvIG9uZSBvZiB0aGUgWE1SX0JMT0NLX0xFTiB3aWR0aHMg4oCUXG4gICAgICAgIC8vIHNvIHRoZSBvdXRwdXQgbGVuZ3RoIGlzIGtub3duIHVwIGZyb250IGFuZCBibG9ja3Mgd3JpdGUgaW50byBwbGFjZS4gR3Jvd2luZyBhXG4gICAgICAgIC8vIG51bWJlcltdIHZpYSBjb25jYXQgcGVyIGJsb2NrIHdhcyBxdWFkcmF0aWM7IHRoaXMga2VlcHMgZGVjb2RlIGxpbmVhciBsaWtlIHRoZVxuICAgICAgICAvLyBibG9jayBlbmNvZGluZyBhbHdheXMgaW50ZW5kZWQuXG4gICAgICAgIGNvbnN0IHRhaWxDaGFycyA9IHN0ckxlbiAlIDExO1xuICAgICAgICBjb25zdCB0YWlsQnl0ZXMgPSB0YWlsQ2hhcnMgPT09IDAgPyAwIDogWE1SX0JMT0NLX0xFTi5pbmRleE9mKHRhaWxDaGFycyk7XG4gICAgICAgIGlmICh0YWlsQnl0ZXMgPT09IC0xKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBiYXNlNTh4bXI6IGludmFsaWQgYmxvY2sgbGVuZ3RoICR7dGFpbENoYXJzfWApO1xuICAgICAgICBjb25zdCByZXMgPSBuZXcgVWludDhBcnJheShNYXRoLmZsb29yKHN0ckxlbiAvIDExKSAqIDggKyB0YWlsQnl0ZXMpO1xuICAgICAgICBsZXQgdyA9IDA7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyTGVuOyBpICs9IDExKSB7XG4gICAgICAgICAgICBjb25zdCBzbGljZSA9IHN0ci5zbGljZShpLCBpICsgMTEpO1xuICAgICAgICAgICAgY29uc3QgYmxvY2tMZW4gPSBzbGljZS5sZW5ndGggPT09IDExID8gOCA6IHRhaWxCeXRlcztcbiAgICAgICAgICAgIGNvbnN0IGJsb2NrID0gYmFzZTU4LmRlY29kZShzbGljZSk7XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGJsb2NrLmxlbmd0aCAtIGJsb2NrTGVuOyBqKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoYmxvY2tbal0gIT09IDApXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYmFzZTU4eG1yOiB3cm9uZyBwYWRkaW5nJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGxldCBqID0gYmxvY2subGVuZ3RoIC0gYmxvY2tMZW47IGogPCBibG9jay5sZW5ndGg7IGorKylcbiAgICAgICAgICAgICAgICByZXNbdysrXSA9IGJsb2NrW2pdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXM7XG4gICAgfSxcbn0pKTtcbi8qKlxuICogTWV0aG9kLCB3aGljaCBjcmVhdGVzIGJhc2U1OGNoZWNrIGVuY29kZXIuXG4gKiBSZXF1aXJlcyBmdW5jdGlvbiwgY2FsY3VsYXRpbmcgc2hhMjU2LlxuICogQ2FsbGVycyBtdXN0IGluY2x1ZGUgYW55IHZlcnNpb24gYnl0ZXMgaW4gYGRhdGFgOyB0aGlzIGhlbHBlciBvbmx5IGFwcGxpZXMgdGhlXG4gKiA0LWJ5dGUgZG91YmxlLVNIQTI1NiBjaGVja3N1bSB1c2VkIGJ5IEJpdGNvaW4gQmFzZTU4Q2hlY2suXG4gKiBAcGFyYW0gc2hhMjU2IC0gRnVuY3Rpb24gdXNlZCB0byBjYWxjdWxhdGUgdGhlIGNoZWNrc3VtIGhhc2guXG4gKiBAcmV0dXJucyBiYXNlNThjaGVjayBjb2RlYyB1c2luZyA0IGNoZWNrc3VtIGJ5dGVzLlxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCB0eXBlcy4ge0BsaW5rIFR5cGVFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBDcmVhdGUgYSBiYXNlNThjaGVjayBjb2RlYyBmcm9tIGEgU0hBLTI1NiBpbXBsZW1lbnRhdGlvbi5cbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBjcmVhdGVCYXNlNThjaGVjayB9IGZyb20gJ0BzY3VyZS9iYXNlJztcbiAqIGltcG9ydCB7IHNoYTI1NiB9IGZyb20gJ0Bub2JsZS9oYXNoZXMvc2hhMi5qcyc7XG4gKiBjb25zdCBjb2RlciA9IGNyZWF0ZUJhc2U1OGNoZWNrKHNoYTI1Nik7XG4gKiBjb2Rlci5lbmNvZGUoVWludDhBcnJheS5mcm9tKFsxLCAyLCAzXSkpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBjcmVhdGVCYXNlNThjaGVjayA9IChzaGEyNTYpID0+IHtcbiAgICAvLyBWYWxpZGF0ZSB0aGUgaGFzaCBmdW5jdGlvbiBhdCBjb25zdHJ1Y3Rpb24gdGltZSBzbyB3cm9uZyBpbnB1dHMgZmFpbCBiZWZvcmUgcmV0dXJuaW5nIGEgY29kZXIuXG4gICAgYWZuKHNoYTI1Nik7XG4gICAgY29uc3QgX3NoYTI1NiA9IHNoYTI1NjtcbiAgICByZXR1cm4gY2hhaW4oY2hlY2tzdW0oNCwgKGRhdGEpID0+IF9zaGEyNTYoX3NoYTI1NihkYXRhKSkpLCBiYXNlNTgpO1xufTtcbi8qKlxuICogVXNlIGBjcmVhdGVCYXNlNThjaGVja2AgaW5zdGVhZC5cbiAqIEBkZXByZWNhdGVkIFVzZSB7QGxpbmsgY3JlYXRlQmFzZTU4Y2hlY2t9IGluc3RlYWQuXG4gKiBDYWxsZXJzIG11c3QgaW5jbHVkZSBhbnkgdmVyc2lvbiBieXRlcyBpbiBgZGF0YWA7IHRoaXMgYWxpYXMga2VlcHMgdGhlIHNhbWVcbiAqIDQtYnl0ZSBkb3VibGUtU0hBMjU2IGNoZWNrc3VtIGJlaGF2aW9yIGFzIGBjcmVhdGVCYXNlNThjaGVja2AuXG4gKiBAcGFyYW0gc2hhMjU2IC0gRnVuY3Rpb24gdXNlZCB0byBjYWxjdWxhdGUgdGhlIGNoZWNrc3VtIGhhc2guXG4gKiBAcmV0dXJucyBiYXNlNThjaGVjayBjb2RlYyB1c2luZyA0IGNoZWNrc3VtIGJ5dGVzLlxuICogQGV4YW1wbGVcbiAqIENyZWF0ZSBhIGJhc2U1OGNoZWNrIGNvZGVjIHdpdGggdGhlIGRlcHJlY2F0ZWQgYWxpYXMuXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgYmFzZTU4Y2hlY2sgfSBmcm9tICdAc2N1cmUvYmFzZSc7XG4gKiBpbXBvcnQgeyBzaGEyNTYgfSBmcm9tICdAbm9ibGUvaGFzaGVzL3NoYTIuanMnO1xuICogY29uc3QgY29kZXIgPSBiYXNlNThjaGVjayhzaGEyNTYpO1xuICogY29kZXIuZW5jb2RlKFVpbnQ4QXJyYXkuZnJvbShbMSwgMiwgM10pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYmFzZTU4Y2hlY2sgPSBjcmVhdGVCYXNlNThjaGVjaztcbi8vIEJJUCAxNzMgY2hhcmFjdGVyIHRhYmxlLlxuLy8gQ2FsbGVycyBhZGFwdCB0aGUgcHVibGljIG51bWJlcltdIHdvcmRzIEFQSSB0byBVaW50OEFycmF5IGF0IHRoZSBlZGdlcyAod29yZHNUb1U4IGJlbG93KTpcbi8vIGZlZWRpbmcgbnVtYmVyW10gaW50byBhbHBoYWJldC5lbmNvZGUgd291bGQgd29yayBhdCBydW50aW1lLCBidXQgaXQgdHVybnMgdGhlIHNoYXJlZFxuLy8gaG90IGxvb3AgcG9seW1vcnBoaWMgYW5kIG1lYXN1cmFibHkgc2xvd3MgdGhlIFJGQyA0NjQ4IGNvZGVjcyB1c2luZyB0aGUgc2FtZSBsaXRlcmFsLlxuY29uc3QgQkVDSF9BTFBIQUJFVCA9IC8qIEBfX1BVUkVfXyAqLyBhbHBoYWJldCgncXB6cnk5eDhnZjJ0dmR3MHMzam41NGtoY2U2bXVhN2wnKTtcbi8vIFJhbmdlLWNoZWNrcyB3aGlsZSBwYWNraW5nOiBhIHBsYWluIGNvcHkgd291bGQgc2lsZW50bHkgd3JhcCBvdXQtb2YtcmFuZ2Ugd29yZHNcbi8vICgyNTYgLT4gMCB3b3VsZCBlbmNvZGUgdG8gYSB2YWxpZCBsZXR0ZXIpLiBTYW1lIG1lc3NhZ2UgdGhlIG9sZCBzbG93IGFscGhhYmV0IHRocmV3LlxuZnVuY3Rpb24gd29yZHNUb1U4KHdvcmRzKSB7XG4gICAgY29uc3QgbGVuID0gd29yZHMubGVuZ3RoO1xuICAgIGNvbnN0IHJlcyA9IG5ldyBVaW50OEFycmF5KGxlbik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBjb25zdCB3ID0gd29yZHNbaV07XG4gICAgICAgIGlmICh3IDwgMCB8fCB3ID49IDMyKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBhbHBoYWJldC5lbmNvZGU6IGludmFsaWQgZGlnaXQgJHt3fWApO1xuICAgICAgICByZXNbaV0gPSB3O1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xufVxuLy8gQklQIDE3MyBgYmVjaDMyX3BvbHltb2RgIEdFTiBjb2VmZmljaWVudHMuXG5jb25zdCBQT0xZTU9EX0dFTkVSQVRPUlMgPSBbMHgzYjZhNTdiMiwgMHgyNjUwOGU2ZCwgMHgxZWExMTlmYSwgMHgzZDQyMzNkZCwgMHgyYTE0NjJiM107XG4vLyBCSVAgMTczIHN0ZXAgc3BsaXQ6IHRoaXMgYXBwbGllcyB0aGUgcG9seW1vZCBzdGF0ZSB0cmFuc2l0aW9uIGJlZm9yZSBjYWxsZXJzIHhvciBpbiB0aGUgbmV4dCA1LWJpdCB2YWx1ZS5cbmZ1bmN0aW9uIGJlY2gzMlBvbHltb2QocHJlKSB7XG4gICAgY29uc3QgYiA9IHByZSA+PiAyNTtcbiAgICBsZXQgY2hrID0gKHByZSAmIDB4MWZmZmZmZikgPDwgNTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IFBPTFlNT0RfR0VORVJBVE9SUy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoKChiID4+IGkpICYgMSkgPT09IDEpXG4gICAgICAgICAgICBjaGsgXj0gUE9MWU1PRF9HRU5FUkFUT1JTW2ldO1xuICAgIH1cbiAgICByZXR1cm4gY2hrO1xufVxuZnVuY3Rpb24gYmVjaENoZWNrc3VtKHByZWZpeCwgd29yZHMsIGVuY29kaW5nQ29uc3QgPSAxKSB7XG4gICAgY29uc3QgbGVuID0gcHJlZml4Lmxlbmd0aDtcbiAgICBsZXQgY2hrID0gMTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGMgPSBwcmVmaXguY2hhckNvZGVBdChpKTtcbiAgICAgICAgaWYgKGMgPCAzMyB8fCBjID4gMTI2KVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIHByZWZpeCAoJHtwcmVmaXh9KWApO1xuICAgICAgICBjaGsgPSBiZWNoMzJQb2x5bW9kKGNoaykgXiAoYyA+PiA1KTtcbiAgICB9XG4gICAgY2hrID0gYmVjaDMyUG9seW1vZChjaGspO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspXG4gICAgICAgIGNoayA9IGJlY2gzMlBvbHltb2QoY2hrKSBeIChwcmVmaXguY2hhckNvZGVBdChpKSAmIDB4MWYpO1xuICAgIGZvciAobGV0IHYgb2Ygd29yZHMpXG4gICAgICAgIGNoayA9IGJlY2gzMlBvbHltb2QoY2hrKSBeIHY7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCA2OyBpKyspXG4gICAgICAgIGNoayA9IGJlY2gzMlBvbHltb2QoY2hrKTtcbiAgICAvLyBCSVAgMTczL0JJUCAzNTA6IHhvciB0aGUgZmluYWwgY2hlY2tzdW0gY29uc3RhbnQsIHRoZW4gZW1pdCB0aGUgMzAtYml0IHN0YXRlIGFzIHNpeCA1LWJpdCBzeW1ib2xzLlxuICAgIGNoayBePSBlbmNvZGluZ0NvbnN0O1xuICAgIGNvbnN0IHN1bSA9IG5ldyBVaW50OEFycmF5KDYpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNjsgaSsrKVxuICAgICAgICBzdW1baV0gPSAoY2hrID4+PiAoNSAqICg1IC0gaSkpKSAmIDMxO1xuICAgIHJldHVybiBCRUNIX0FMUEhBQkVULmVuY29kZShzdW0pO1xufVxuZnVuY3Rpb24gZ2VuQmVjaDMyKGVuY29kaW5nKSB7XG4gICAgLy8gQklQIDE3MyB1c2VzIGZpbmFsIHhvciBjb25zdGFudCAxOyBCSVAgMzUwIHN3YXBzIGluIDB4MmJjODMwYTMgZm9yIEJlY2gzMm0uXG4gICAgY29uc3QgRU5DT0RJTkdfQ09OU1QgPSBlbmNvZGluZyA9PT0gJ2JlY2gzMicgPyAxIDogMHgyYmM4MzBhMztcbiAgICAvLyBQdWJsaWMgQVBJIHdvcmRzIGFyZSBudW1iZXJbXSwgc28gYWRhcHQgdGhlIGZhc3QgcmFkaXgyJ3MgVWludDhBcnJheSBwcm90b2NvbCBhdCB0aGUgZWRnZS5cbiAgICBjb25zdCBfd29yZHMgPSByYWRpeDIoNSk7XG4gICAgY29uc3QgdG9Xb3JkcyA9IChmcm9tKSA9PiB7XG4gICAgICAgIGFieXRlcyhmcm9tKTtcbiAgICAgICAgLy8gRGVkaWNhdGVkIDgtPjUgcmVncm91cGluZyAocmFkaXgyKDUpLmVuY29kZSBzZW1hbnRpY3MpIHdyaXRpbmcgdGhlIHB1YmxpYyBudW1iZXJbXVxuICAgICAgICAvLyBkaXJlY3RseTsgZW5jb2RlLWludG8tVWludDhBcnJheSBwbHVzIGEgY29weSBsb29wIG1lYXN1cmFibHkgcmVncmVzc2VkIHRoaXMgaG90IHBhdGguXG4gICAgICAgIGNvbnN0IGxlbiA9IGZyb20ubGVuZ3RoO1xuICAgICAgICBjb25zdCByZXMgPSBuZXcgQXJyYXkoTWF0aC5jZWlsKChsZW4gKiA4KSAvIDUpKTtcbiAgICAgICAgbGV0IGNhcnJ5ID0gMDtcbiAgICAgICAgbGV0IHBvcyA9IDA7XG4gICAgICAgIGxldCBqID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgLy8gTm8gY2FycnkgY2xlYW51cCBuZWVkZWQ6IHN0YWxlIGJpdHMgc2l0IGFib3ZlIHBvcyBhbmQgZXZlcnkgZXh0cmFjdGlvbiAoaW5jbHVkaW5nXG4gICAgICAgICAgICAvLyB0aGUgdGFpbCBiZWxvdykgbWFza3Mgd2l0aCBgJiAzMWAsIHNvIHRoZXkgbmV2ZXIgcmVhY2ggdGhlIG91dHB1dC4gTWFza2luZyBjYXJyeVxuICAgICAgICAgICAgLy8gaGVyZSBtZWFzdXJhYmx5IHNsb3dlZCB0aGUgbG9vcC5cbiAgICAgICAgICAgIGNhcnJ5ID0gKGNhcnJ5IDw8IDgpIHwgZnJvbVtpXTtcbiAgICAgICAgICAgIHBvcyArPSA4O1xuICAgICAgICAgICAgZm9yICg7IHBvcyA+PSA1OyBwb3MgLT0gNSlcbiAgICAgICAgICAgICAgICByZXNbaisrXSA9IChjYXJyeSA+PiAocG9zIC0gNSkpICYgMzE7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBvcyA+IDApXG4gICAgICAgICAgICByZXNbal0gPSAoY2FycnkgPDwgKDUgLSBwb3MpKSAmIDMxO1xuICAgICAgICByZXR1cm4gcmVzO1xuICAgIH07XG4gICAgY29uc3QgZnJvbVdvcmRzID0gKHRvKSA9PiB7XG4gICAgICAgIGFudW1BcnIoJ3JhZGl4Mi5kZWNvZGUnLCB0byk7XG4gICAgICAgIC8vIFJhbmdlLWNoZWNrIHdoaWxlIHBhY2tpbmcgaW50byB0aGUgYnl0ZSBidWZmZXI6IGEgcGxhaW4gY29weSB3b3VsZCBzaWxlbnRseVxuICAgICAgICAvLyB0cnVuY2F0ZSBvdXQtb2YtcmFuZ2Ugd29yZHMuIFJlamVjdGluZyBuZWdhdGl2ZXMgaXMgYSBkZWxpYmVyYXRlIGZpeCDigJQgdGhlIG9sZFxuICAgICAgICAvLyBjb252ZXJ0UmFkaXgyIHBhdGggc2lsZW50bHkgY29ycnVwdGVkIG91dHB1dCBmb3IgdGhlbS5cbiAgICAgICAgY29uc3QgbGVuID0gdG8ubGVuZ3RoO1xuICAgICAgICBjb25zdCBkaWdpdHMgPSBuZXcgVWludDhBcnJheShsZW4pO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB3ID0gdG9baV07XG4gICAgICAgICAgICBpZiAodyA8IDAgfHwgdyA+PSAzMilcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGNvbnZlcnRSYWRpeDI6IGludmFsaWQgd29yZD0ke3d9YCk7XG4gICAgICAgICAgICBkaWdpdHNbaV0gPSB3O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfd29yZHMuZGVjb2RlKGRpZ2l0cyk7XG4gICAgfTtcbiAgICBjb25zdCBmcm9tV29yZHNVbnNhZmUgPSB1bnNhZmVXcmFwcGVyKGZyb21Xb3Jkcyk7XG4gICAgZnVuY3Rpb24gZW5jb2RlKHByZWZpeCwgd29yZHMsIGxpbWl0ID0gOTApIHtcbiAgICAgICAgYXN0cignYmVjaDMyLmVuY29kZSBwcmVmaXgnLCBwcmVmaXgpO1xuICAgICAgICBpZiAobGltaXQgIT09IGZhbHNlKVxuICAgICAgICAgICAgYW51bWJlcihsaW1pdCwgJ2xpbWl0Jyk7XG4gICAgICAgIGlmIChpc0J5dGVzKHdvcmRzKSlcbiAgICAgICAgICAgIHdvcmRzID0gdThUb051bUFycih3b3Jkcyk7XG4gICAgICAgIGFudW1BcnIoJ2JlY2gzMi5lbmNvZGUnLCB3b3Jkcyk7XG4gICAgICAgIGNvbnN0IHBsZW4gPSBwcmVmaXgubGVuZ3RoO1xuICAgICAgICBpZiAocGxlbiA9PT0gMClcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYEludmFsaWQgcHJlZml4IGxlbmd0aCAke3BsZW59YCk7XG4gICAgICAgIC8vIFRvdGFsIG91dHB1dCBpcyBocnAgKyBgMWAgc2VwYXJhdG9yICsgcGF5bG9hZCB3b3JkcyArIDYgY2hlY2tzdW0gY2hhcnMuXG4gICAgICAgIGNvbnN0IGFjdHVhbExlbmd0aCA9IHBsZW4gKyA3ICsgd29yZHMubGVuZ3RoO1xuICAgICAgICBpZiAobGltaXQgIT09IGZhbHNlICYmIGFjdHVhbExlbmd0aCA+IGxpbWl0KVxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgTGVuZ3RoICR7YWN0dWFsTGVuZ3RofSBleGNlZWRzIGxpbWl0ICR7bGltaXR9YCk7XG4gICAgICAgIGNvbnN0IGxvd2VyZWQgPSBwcmVmaXgudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgY29uc3Qgc3VtID0gYmVjaENoZWNrc3VtKGxvd2VyZWQsIHdvcmRzLCBFTkNPRElOR19DT05TVCk7XG4gICAgICAgIHJldHVybiBgJHtsb3dlcmVkfTEke0JFQ0hfQUxQSEFCRVQuZW5jb2RlKHdvcmRzVG9VOCh3b3JkcykpfSR7c3VtfWA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGRlY29kZShzdHIsIGxpbWl0ID0gOTApIHtcbiAgICAgICAgYXN0cignYmVjaDMyLmRlY29kZSBpbnB1dCcsIHN0cik7XG4gICAgICAgIGlmIChsaW1pdCAhPT0gZmFsc2UpXG4gICAgICAgICAgICBhbnVtYmVyKGxpbWl0LCAnbGltaXQnKTtcbiAgICAgICAgY29uc3Qgc2xlbiA9IHN0ci5sZW5ndGg7XG4gICAgICAgIC8vIE1pbmltdW0gbGVuZ3RoIGlzIDEtY2hhciBocnAgKyBgMWAgc2VwYXJhdG9yICsgNi1jaGFyIGNoZWNrc3VtLlxuICAgICAgICBpZiAoc2xlbiA8IDggfHwgKGxpbWl0ICE9PSBmYWxzZSAmJiBzbGVuID4gbGltaXQpKVxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgaW52YWxpZCBzdHJpbmcgbGVuZ3RoICR7c2xlbn0sIGV4cGVjdGVkICg4Li4ke2xpbWl0fSlgKTtcbiAgICAgICAgLy8gZG9uJ3QgYWxsb3cgbWl4ZWQgY2FzZVxuICAgICAgICBjb25zdCBsb3dlcmVkID0gc3RyLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmIChzdHIgIT09IGxvd2VyZWQgJiYgc3RyICE9PSBzdHIudG9VcHBlckNhc2UoKSlcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgbWl4ZWQtY2FzZSBzdHJpbmcgbm90IGFsbG93ZWRgKTtcbiAgICAgICAgY29uc3Qgc2VwSW5kZXggPSBsb3dlcmVkLmxhc3RJbmRleE9mKCcxJyk7XG4gICAgICAgIGlmIChzZXBJbmRleCA9PT0gMCB8fCBzZXBJbmRleCA9PT0gLTEpXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGludmFsaWQgc2VwYXJhdG9yIFwiMVwiYCk7XG4gICAgICAgIGNvbnN0IHByZWZpeCA9IGxvd2VyZWQuc2xpY2UoMCwgc2VwSW5kZXgpO1xuICAgICAgICBjb25zdCBkYXRhID0gbG93ZXJlZC5zbGljZShzZXBJbmRleCArIDEpO1xuICAgICAgICBpZiAoZGF0YS5sZW5ndGggPCA2KVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGRhdGEgbGVuZ3RoJyk7XG4gICAgICAgIGNvbnN0IGRpZ2l0cyA9IEJFQ0hfQUxQSEFCRVQuZGVjb2RlKGRhdGEpO1xuICAgICAgICBjb25zdCB3b3JkcyA9IHU4VG9OdW1BcnIoZGlnaXRzLCBkaWdpdHMubGVuZ3RoIC0gNik7XG4gICAgICAgIGNvbnN0IHN1bSA9IGJlY2hDaGVja3N1bShwcmVmaXgsIHdvcmRzLCBFTkNPRElOR19DT05TVCk7XG4gICAgICAgIGlmICghZGF0YS5lbmRzV2l0aChzdW0pKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGNoZWNrc3VtIGluICR7c3RyfWApO1xuICAgICAgICByZXR1cm4geyBwcmVmaXgsIHdvcmRzIH07XG4gICAgfVxuICAgIGNvbnN0IGRlY29kZVVuc2FmZSA9IHVuc2FmZVdyYXBwZXIoZGVjb2RlKTtcbiAgICBmdW5jdGlvbiBkZWNvZGVUb0J5dGVzKHN0cikge1xuICAgICAgICAvLyBLZWVwIHRoZSBieXRlIGhlbHBlciB1bmJvdW5kZWQ7IGNhbGxlcnMgdGhhdCBuZWVkIHRoZSBkZWZhdWx0IEJJUCAxNzMgbGVuZ3RoIGNhcCBzaG91bGQgdXNlIGRlY29kZShzdHIpLlxuICAgICAgICBjb25zdCB7IHByZWZpeCwgd29yZHMgfSA9IGRlY29kZShzdHIsIGZhbHNlKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByZWZpeCxcbiAgICAgICAgICAgIHdvcmRzLFxuICAgICAgICAgICAgYnl0ZXM6IGZyb21Xb3Jkcyh3b3JkcyksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIGVuY29kZUZyb21CeXRlcyhwcmVmaXgsIGJ5dGVzKSB7XG4gICAgICAgIC8vIEtlZXAgdGhlIGNvbnZlbmllbmNlIHdyYXBwZXIgb24gZW5jb2RlKCkncyBkZWZhdWx0IDkwLWNoYXIgY2FwOyBjdXN0b20gbGltaXRzIHNob3VsZCBjYWxsIGVuY29kZShwcmVmaXgsIHRvV29yZHMoYnl0ZXMpLCBsaW1pdCkuXG4gICAgICAgIHJldHVybiBlbmNvZGUocHJlZml4LCB0b1dvcmRzKGJ5dGVzKSk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGVuY29kZSxcbiAgICAgICAgZGVjb2RlLFxuICAgICAgICBlbmNvZGVGcm9tQnl0ZXMsXG4gICAgICAgIGRlY29kZVRvQnl0ZXMsXG4gICAgICAgIGRlY29kZVVuc2FmZSxcbiAgICAgICAgZnJvbVdvcmRzLFxuICAgICAgICBmcm9tV29yZHNVbnNhZmUsXG4gICAgICAgIHRvV29yZHMsXG4gICAgfTtcbn1cbi8qKlxuICogYmVjaDMyIGZyb20gQklQIDE3My4gT3BlcmF0ZXMgb24gd29yZHMuXG4gKiBGb3IgaGlnaC1sZXZlbCBoZWxwZXJzLCBjaGVjayBvdXQge0BsaW5rIGh0dHBzOi8vZ2l0aHViLmNvbS9wYXVsbWlsbHIvc2N1cmUtYnRjLXNpZ25lciB8IHNjdXJlLWJ0Yy1zaWduZXJ9LlxuICogQGV4YW1wbGVcbiAqIENvbnZlcnQgYnl0ZXMgdG8gd29yZHMsIGVuY29kZSB0aGVtLCB0aGVuIGRlY29kZSBiYWNrLlxuICogYGBgdHNcbiAqIGNvbnN0IHdvcmRzID0gYmVjaDMyLnRvV29yZHMoVWludDhBcnJheS5mcm9tKFsxLCAyLCAzXSkpO1xuICogY29uc3QgdGV4dCA9IGJlY2gzMi5lbmNvZGUoJ2JjJywgd29yZHMpO1xuICogYmVjaDMyLmRlY29kZSh0ZXh0KTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgYmVjaDMyID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiBnZW5CZWNoMzIoJ2JlY2gzMicpKTtcbi8qKlxuICogYmVjaDMybSBmcm9tIEJJUCAzNTAuIE9wZXJhdGVzIG9uIHdvcmRzLlxuICogSXQgd2FzIHRvIG1pdGlnYXRlIGBiZWNoMzJgIHdlYWtuZXNzZXMuXG4gKiBGb3IgaGlnaC1sZXZlbCBoZWxwZXJzLCBjaGVjayBvdXQge0BsaW5rIGh0dHBzOi8vZ2l0aHViLmNvbS9wYXVsbWlsbHIvc2N1cmUtYnRjLXNpZ25lciB8IHNjdXJlLWJ0Yy1zaWduZXJ9LlxuICogQGV4YW1wbGVcbiAqIENvbnZlcnQgYnl0ZXMgdG8gd29yZHMsIGVuY29kZSB0aGVtIHdpdGggYmVjaDMybSwgdGhlbiBkZWNvZGUgYmFjay5cbiAqIGBgYHRzXG4gKiBjb25zdCB3b3JkcyA9IGJlY2gzMm0udG9Xb3JkcyhVaW50OEFycmF5LmZyb20oWzEsIDIsIDNdKSk7XG4gKiBjb25zdCB0ZXh0ID0gYmVjaDMybS5lbmNvZGUoJ2JjJywgd29yZHMpO1xuICogYmVjaDMybS5kZWNvZGUodGV4dCk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGJlY2gzMm0gPSAvKiBAX19QVVJFX18gKi8gZnJlZXplKCgpID0+IGdlbkJlY2gzMignYmVjaDMybScpKTtcbi8qKlxuICogQVNDSUktdG8tYnl0ZSBkZWNvZGVyLiBSZWplY3RzIG5vbi1BU0NJSSB0ZXh0IGFuZCBieXRlcyBpbnN0ZWFkIG9mIGRvaW5nIFVURi04IHJlcGxhY2VtZW50LlxuICogTWV0aG9kIG5hbWVzIGZvbGxvdyBgQnl0ZXNDb2RlcmAsIHNvIGBlbmNvZGUoYnl0ZXMpYCByZXR1cm5zIGEgc3RyaW5nIGFuZCBgZGVjb2RlKHN0cmluZylgIHJldHVybnMgYnl0ZXMuXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGNvbnN0IGIgPSBhc2NpaS5kZWNvZGUoXCJBQkNcIik7IC8vID0+IG5ldyBVaW50OEFycmF5KFsgNjUsIDY2LCA2NyBdKVxuICogY29uc3Qgc3RyID0gYXNjaWkuZW5jb2RlKGIpOyAvLyBcIkFCQ1wiXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IGFzY2lpID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiAoe1xuICAgIGVuY29kZShkYXRhKSB7XG4gICAgICAgIGFieXRlcyhkYXRhKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBieXRlID0gZGF0YVtpXTtcbiAgICAgICAgICAgIC8vIEFTQ0lJIGlzIDctYml0OyByZWplY3QgYnl0ZXMgb3V0c2lkZSAweDAwLi4weDdmIGluc3RlYWQgb2Ygc2lsZW50bHkgd2lkZW5pbmcgdG9cbiAgICAgICAgICAgIC8vIExhdGluLTEvVVRGLTguIFZhbGlkYXRpbmcgdXAgZnJvbnQga2VlcHMgdGhlIGVycm9yIHBvc2l0aW9uIGV4YWN0IHdoaWxlIHRoZVxuICAgICAgICAgICAgLy8gc3RyaW5nIGl0c2VsZiBpcyBidWlsdCBpbiBidWxrICh+M3ggZmFzdGVyIGF0IDFLQiB0aGFuIHBlci1jaGFyIGNvbmNhdCkuXG4gICAgICAgICAgICBpZiAoYnl0ZSA+IDEyNylcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgbm9uLUFTQ0lJIGJ5dGUgJHtieXRlfSBhdCAke2l9YCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNoYXJjb2Rlc1RvU3RyaW5nKGRhdGEpO1xuICAgIH0sXG4gICAgZGVjb2RlKHN0cikge1xuICAgICAgICBpZiAodHlwZW9mIHN0ciAhPT0gJ3N0cmluZycpXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdhc2NpaSBzdHJpbmcgZXhwZWN0ZWQsIGdvdCAnICsgdHlwZW9mIHN0cik7XG4gICAgICAgIGNvbnN0IHJlcyA9IG5ldyBVaW50OEFycmF5KHN0ci5sZW5ndGgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgLy8gSW5kZXhlZCBhY2Nlc3MgaXMgbXVjaCBmYXN0ZXIgdGhhbiBVaW50OEFycmF5LmZyb20oc3RyLCBtYXBGbikgaGVyZSBhbmQga2VlcHNcbiAgICAgICAgICAgIC8vIGV4YWN0IGVycm9yIHBvc2l0aW9ucy5cbiAgICAgICAgICAgIGNvbnN0IGNoYXJDb2RlID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgICAgICBpZiAoY2hhckNvZGUgPiAxMjcpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYG5vbi1BU0NJSSBjaGFyIFwiJHtzdHJbaV19XCIgKCR7Y2hhckNvZGV9KSBhdCAke2l9YCk7XG4gICAgICAgICAgICByZXNbaV0gPSBjaGFyQ29kZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzO1xuICAgIH0sXG59KSk7XG5jb25zdCBfaXNXZWxsRm9ybWVkU2hpbSA9IChzdHIpID0+IHtcbiAgICAvLyBlbmNvZGVVUkkgcmVqZWN0cyBtYWxmb3JtZWQgVVRGLTE2LCBnaXZpbmcgYSBjb21wYWN0IGZhbGxiYWNrIHRoYXQgbWF0Y2hlcyBuYXRpdmVcbiAgICAvLyBpc1dlbGxGb3JtZWQgb24gb3VyIHRlc3RzL2Z1enogY29ycHVzLlxuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBlbmNvZGVVUkkoc3RyKSAhPT0gbnVsbDtcbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxufTtcbmNvbnN0IF9pc1dlbGxGb3JtZWQgPSAvKiBAX19QVVJFX18gKi8gKCgpID0+IFxuLy8gUGljayB0aGUgbmF0aXZlIGNoZWNrIG9uY2Ugc28gdXRmOC5kZWNvZGUgZG9lc24ndCByZS1wcm9iZSBTdHJpbmcucHJvdG90eXBlIG9uIGV2ZXJ5IGNhbGwuXG50eXBlb2YgJycuaXNXZWxsRm9ybWVkID09PSAnZnVuY3Rpb24nXG4gICAgPyAoc3RyKSA9PiBzdHIuaXNXZWxsRm9ybWVkKClcbiAgICA6IF9pc1dlbGxGb3JtZWRTaGltKSgpO1xuLy8gVGhpcyBmYWxsYmFjayBzdGF5cyBzbWFsbCBiZWNhdXNlIHN0cmljdCBVVEYtOCBvbmx5IG5lZWRzIGZhdGFsIGRlY29kaW5nIHBsdXMgd2VsbC1mb3JtZWRcbi8vIFVURi0xNiBjaGVja3MsIG5vdCB0aGUgcmVwbGFjZW1lbnQsIHN0cmVhbWluZywgb3IgbGVnYWN5LWVuY29kaW5nIGJlaGF2aW9yIG9mIGZ1bGwgcGxhdGZvcm1cbi8vIHRleHQgY29kZWNzLlxuY29uc3QgdXRmOGVyciA9IChpKSA9PiBuZXcgVHlwZUVycm9yKGBpbnZhbGlkIHV0ZjggYXQgYnl0ZSAke2l9YCk7XG5jb25zdCB1dGY4RmFsbGJhY2sgPSAvKiBAX19QVVJFX18gKi8gZnJlZXplKCgpID0+ICh7XG4gICAgZW5jb2RlKGRhdGEpIHtcbiAgICAgICAgYWJ5dGVzKGRhdGEpO1xuICAgICAgICBsZXQgcmVzID0gJyc7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YS5sZW5ndGg7KSB7XG4gICAgICAgICAgICBjb25zdCBhID0gZGF0YVtpKytdO1xuICAgICAgICAgICAgaWYgKGEgPCAwYjEwMDBfMDAwMCkge1xuICAgICAgICAgICAgICAgIHJlcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGEpO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGEgPCAwYjExMDBfMDAxMCB8fCBpID49IGRhdGEubGVuZ3RoKVxuICAgICAgICAgICAgICAgIHRocm93IHV0ZjhlcnIoaSAtIDEpO1xuICAgICAgICAgICAgY29uc3QgYiA9IGRhdGFbaSsrXTtcbiAgICAgICAgICAgIGlmICgoYiAmIDBiMTEwMF8wMDAwKSAhPT0gMGIxMDAwXzAwMDApXG4gICAgICAgICAgICAgICAgdGhyb3cgdXRmOGVycihpIC0gMSk7XG4gICAgICAgICAgICBsZXQgY3AgPSAoKGEgJiAwYjAwMDFfMTExMSkgPDwgNikgfCAoYiAmIDBiMDAxMV8xMTExKTtcbiAgICAgICAgICAgIGlmIChhID49IDBiMTExMF8wMDAwKSB7XG4gICAgICAgICAgICAgICAgaWYgKGkgPj0gZGF0YS5sZW5ndGgpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IHV0ZjhlcnIoaSAtIDEpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGMgPSBkYXRhW2krK107XG4gICAgICAgICAgICAgICAgaWYgKChjICYgMGIxMTAwXzAwMDApICE9PSAwYjEwMDBfMDAwMCB8fFxuICAgICAgICAgICAgICAgICAgICAoYSA9PT0gMGIxMTEwXzAwMDAgJiYgYiA8IDBiMTAxMF8wMDAwKSB8fFxuICAgICAgICAgICAgICAgICAgICAoYSA9PT0gMHhlZCAmJiBiID49IDBiMTAxMF8wMDAwKSlcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgdXRmOGVycihpIC0gMSk7XG4gICAgICAgICAgICAgICAgY3AgPSAoKGEgJiAwYjAwMDBfMTExMSkgPDwgMTIpIHwgKChiICYgMGIwMDExXzExMTEpIDw8IDYpIHwgKGMgJiAwYjAwMTFfMTExMSk7XG4gICAgICAgICAgICAgICAgaWYgKGEgPj0gMGIxMTExXzAwMDApIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGkgPj0gZGF0YS5sZW5ndGgpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyB1dGY4ZXJyKGkgLSAxKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZCA9IGRhdGFbaSsrXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGEgPiAwYjExMTFfMDEwMCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKGQgJiAwYjExMDBfMDAwMCkgIT09IDBiMTAwMF8wMDAwIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAoYSA9PT0gMGIxMTExXzAwMDAgJiYgYiA8IDBiMTAwMV8wMDAwKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKGEgPT09IDBiMTExMV8wMTAwICYmIGIgPj0gMGIxMDAxXzAwMDApKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgdXRmOGVycihpIC0gMSk7XG4gICAgICAgICAgICAgICAgICAgIGNwID1cbiAgICAgICAgICAgICAgICAgICAgICAgICgoYSAmIDcpIDw8IDE4KSB8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKChiICYgMGIwMDExXzExMTEpIDw8IDEyKSB8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKChjICYgMGIwMDExXzExMTEpIDw8IDYpIHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZCAmIDBiMDAxMV8xMTExKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY3AgPCAweDEwMDAwKVxuICAgICAgICAgICAgICAgIHJlcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGNwKTtcbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNwIC09IDB4MTAwMDA7XG4gICAgICAgICAgICAgICAgcmVzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKGNwID4+IDEwKSArIDB4ZDgwMCwgKGNwICYgMHgzZmYpICsgMHhkYzAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzO1xuICAgIH0sXG4gICAgZGVjb2RlKHN0cikge1xuICAgICAgICBhc3RyKCd1dGY4Jywgc3RyKTtcbiAgICAgICAgaWYgKCFfaXNXZWxsRm9ybWVkKHN0cikpXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd1dGY4IGV4cGVjdGVkIHdlbGwtZm9ybWVkIHN0cmluZycpO1xuICAgICAgICAvLyBEaXJlY3QgVWludDhBcnJheSB3cml0ZXMgYXJlIG11Y2ggZmFzdGVyIHRoYW4gbnVtYmVyW10gKyBVaW50OEFycmF5LmZyb20gb24gSGVybWVzIGFuZFxuICAgICAgICAvLyBsYXJnZSBOb2RlIGlucHV0cy5cbiAgICAgICAgY29uc3QgcmVzID0gbmV3IFVpbnQ4QXJyYXkoc3RyLmxlbmd0aCAqIDMpO1xuICAgICAgICBsZXQgcG9zID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxldCBjID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgICAgICBpZiAoYyA8IDBiMTAwMF8wMDAwKSB7XG4gICAgICAgICAgICAgICAgcmVzW3BvcysrXSA9IGM7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYyA+PSAweGQ4MDAgJiYgYyA8PSAweGRmZmYpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkID0gc3RyLmNoYXJDb2RlQXQoKytpKTtcbiAgICAgICAgICAgICAgICBjID0gMHgxMDAwMCArICgoYyAtIDB4ZDgwMCkgPDwgMTApICsgZCAtIDB4ZGMwMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjID49IDB4MTAwMDApIHtcbiAgICAgICAgICAgICAgICByZXNbcG9zKytdID0gKGMgPj4gMTgpIHwgMGIxMTExXzAwMDA7XG4gICAgICAgICAgICAgICAgcmVzW3BvcysrXSA9ICgoYyA+PiAxMikgJiAwYjAwMTFfMTExMSkgfCAwYjEwMDBfMDAwMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGMgPj0gMHg4MDApXG4gICAgICAgICAgICAgICAgcmVzW3BvcysrXSA9IChjID4+IDEyKSB8IDBiMTExMF8wMDAwO1xuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIHJlc1twb3MrK10gPSAoYyA+PiA2KSB8IDBiMTEwMF8wMDAwO1xuICAgICAgICAgICAgaWYgKGMgPj0gMHg4MDApXG4gICAgICAgICAgICAgICAgcmVzW3BvcysrXSA9ICgoYyA+PiA2KSAmIDBiMDAxMV8xMTExKSB8IDBiMTAwMF8wMDAwO1xuICAgICAgICAgICAgcmVzW3BvcysrXSA9IChjICYgMGIwMDExXzExMTEpIHwgMGIxMDAwXzAwMDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlcy5zdWJhcnJheSgwLCBwb3MpO1xuICAgIH0sXG59KSk7XG4vKipcbiAqIFN0cmljdCBVVEYtOC10by1ieXRlIGRlY29kZXIuIFVzZXMgYnVpbHQtaW4gVGV4dERlY29kZXIgLyBUZXh0RW5jb2RlciB3aGVuIGF2YWlsYWJsZS5cbiAqIE1ldGhvZCBuYW1lcyBmb2xsb3cgYEJ5dGVzQ29kZXJgLCBzbyBgZW5jb2RlKGJ5dGVzKWAgcmV0dXJucyBhIHN0cmluZyBhbmRcbiAqIGBkZWNvZGUoc3RyaW5nKWAgcmV0dXJucyBieXRlcy5cbiAqIGBlbmNvZGUoYnl0ZXMpYCByZXF1aXJlcyBVaW50OEFycmF5IGlucHV0LCBwcmVzZXJ2ZXMgYW4gZXhwbGljaXQgbGVhZGluZyBCT00sIGFuZFxuICogICB0aHJvd3Mgb24gaW52YWxpZCBVVEYtOCBieXRlcy5cbiAqIGBkZWNvZGUoc3RyaW5nKWAgcmVxdWlyZXMgYSBwcmltaXRpdmUgc3RyaW5nIGFuZCB0aHJvd3Mgb24gbWFsZm9ybWVkIFVURi0xNiBzdHJpbmdzIHdpdGhcbiAqICAgbG9uZSBzdXJyb2dhdGVzLlxuICogQGV4YW1wbGVcbiAqIGBgYGpzXG4gKiBjb25zdCBiID0gdXRmOC5kZWNvZGUoXCJoZXlcIik7IC8vID0+IG5ldyBVaW50OEFycmF5KFsgMTA0LCAxMDEsIDEyMSBdKVxuICogY29uc3Qgc3RyID0gdXRmOC5lbmNvZGUoYik7IC8vIFwiaGV5XCJcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgdXRmOCA9IC8qIEBfX1BVUkVfXyAqLyBmcmVlemUoKCkgPT4ge1xuICAgIGxldCBfdXRmOEVuY29kZXI7XG4gICAgbGV0IF91dGY4RGVjb2RlcjtcbiAgICBjb25zdCB1dGY4QnVpbHRpbiA9IHtcbiAgICAgICAgLy8gaWdub3JlQk9NIHByZXNlcnZlcyBhbiBleHBsaWNpdCBsZWFkaW5nIFUrRkVGRjtcbiAgICAgICAgLy8gZmF0YWwgcmVqZWN0cyBpbnZhbGlkIFVURi04IGJ5dGVzIGluc3RlYWQgb2YgcmVwbGFjaW5nIHRoZW0uXG4gICAgICAgIGVuY29kZShkYXRhKSB7XG4gICAgICAgICAgICBhYnl0ZXMoZGF0YSk7XG4gICAgICAgICAgICByZXR1cm4gKF91dGY4RGVjb2RlciB8fCAoX3V0ZjhEZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCd1dGYtOCcsIHsgaWdub3JlQk9NOiB0cnVlLCBmYXRhbDogdHJ1ZSB9KSkpLmRlY29kZShkYXRhKTtcbiAgICAgICAgfSxcbiAgICAgICAgZGVjb2RlKHN0cikge1xuICAgICAgICAgICAgYXN0cigndXRmOCcsIHN0cik7XG4gICAgICAgICAgICBpZiAoIV9pc1dlbGxGb3JtZWQoc3RyKSlcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd1dGY4IGV4cGVjdGVkIHdlbGwtZm9ybWVkIHN0cmluZycpO1xuICAgICAgICAgICAgcmV0dXJuIChfdXRmOEVuY29kZXIgfHwgKF91dGY4RW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpKSkuZW5jb2RlKHN0cik7XG4gICAgICAgIH0sXG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICAvLyBTZWxlY3QgZWFjaCBkaXJlY3Rpb24gb25jZSBhdCBtb2R1bGUgaW5pdCwgc2luY2VcbiAgICAgICAgLy8gVGV4dEVuY29kZXIgYW5kIFRleHREZWNvZGVyIGNhbiBleGlzdCBpbmRlcGVuZGVudGx5LlxuICAgICAgICBlbmNvZGU6IHR5cGVvZiBUZXh0RGVjb2RlciA9PT0gJ2Z1bmN0aW9uJyA/IHV0ZjhCdWlsdGluLmVuY29kZSA6IHV0ZjhGYWxsYmFjay5lbmNvZGUsXG4gICAgICAgIGRlY29kZTogdHlwZW9mIFRleHRFbmNvZGVyID09PSAnZnVuY3Rpb24nID8gdXRmOEJ1aWx0aW4uZGVjb2RlIDogdXRmOEZhbGxiYWNrLmRlY29kZSxcbiAgICB9O1xufSk7XG4vLyBLZWVwIGludGVybmFsIHBhcml0eSBwcm9iZXMgYmVoaW5kIGEgdGVzdC1vbmx5IGV4cG9ydC5cbmV4cG9ydCBjb25zdCBfX1RFU1RTID0gLyogQF9fUFVSRV9fICovIGZyZWV6ZSgoKSA9PiAoe1xuICAgIGFscGhhYmV0OiBhbHBoYWJldCxcbiAgICBiYXNlNjRGYWxsYmFjazogYmFzZTY0RmFsbGJhY2ssXG4gICAgcmFkaXgyOiByYWRpeDIsXG4gICAgcmFkaXg1ODogcmFkaXg1OCxcbiAgICBjaGVja3N1bTogY2hlY2tzdW0sXG4gICAgdXRmOEZhbGxiYWNrOiB1dGY4RmFsbGJhY2ssXG4gICAgX2lzV2VsbEZvcm1lZFNoaW06IF9pc1dlbGxGb3JtZWRTaGltLFxufSkpO1xuLy8gQnVpbHQtaW4gaGV4IGNvbnZlcnNpb24gaHR0cHM6Ly9jYW5pdXNlLmNvbS9tZG4tamF2YXNjcmlwdF9idWlsdGluc191aW50OGFycmF5X2Zyb21oZXhcbi8vIHByZXR0aWVyLWlnbm9yZVxuY29uc3QgaGFzSGV4QnVpbHRpbiA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4gXG4vLyBSZXF1aXJlIGJvdGggZGlyZWN0aW9ucyBiZWZvcmUgZW5hYmxpbmcgdGhlIG5hdGl2ZSBoZXggcGF0aCBzbyBlbmNvZGUvZGVjb2RlIHN0YXkgc3ltbWV0cmljLlxudHlwZW9mIFVpbnQ4QXJyYXkuZnJvbShbXSkudG9IZXggPT09ICdmdW5jdGlvbicgJiZcbiAgICB0eXBlb2YgVWludDhBcnJheS5mcm9tSGV4ID09PSAnZnVuY3Rpb24nKSgpO1xuLy8gcHJldHRpZXItaWdub3JlXG5jb25zdCBoZXhCdWlsdGluID0ge1xuICAgIC8vIEtlZXAgbG9jYWwgdHlwZSBndWFyZHMgc28gdGhlIG5hdGl2ZSBwYXRoIHByZXNlcnZlcyBsaWJyYXJ5LWxldmVsIGlucHV0IGVycm9ycy5cbiAgICAvLyBOYXRpdmUgdG9IZXggZW1pdHMgbG93ZXJjYXNlIGhleCwgbWF0Y2hpbmcgdGhlIGZhbGxiYWNrIGFscGhhYmV0IGFuZCBOb2RlJ3MgaGV4IHN0cmluZ3MuXG4gICAgZW5jb2RlKGRhdGEpIHsgYWJ5dGVzKGRhdGEpOyByZXR1cm4gZGF0YS50b0hleCgpOyB9LFxuICAgIC8vIE5hdGl2ZSBmcm9tSGV4IGFjY2VwdHMgZWl0aGVyIGhleCBjYXNlIGFuZCByZWplY3RzIG9kZC1sZW5ndGggLyBub24taGV4IHN5bnRheC5cbiAgICBkZWNvZGUocykgeyBhc3RyKCdoZXgnLCBzKTsgcmV0dXJuIFVpbnQ4QXJyYXkuZnJvbUhleChzKTsgfSxcbn07XG4vKipcbiAqIGhleCBzdHJpbmcgZGVjb2Rlci4gVXNlcyBidWlsdC1pbiBmdW5jdGlvbiwgd2hlbiBhdmFpbGFibGUuXG4gKiBMb3dlcmNhc2UgY29kZWM7IHVubGlrZSBgYmFzZTE2YCwgdGhpcyB2YXJpYW50IGFjY2VwdHMgZWl0aGVyIGhleCBjYXNlIGFuZCBlbWl0cyBsb3dlcmNhc2UuXG4gKiBAZXhhbXBsZVxuICogYGBganNcbiAqIGNvbnN0IGIgPSBoZXguZGVjb2RlKFwiMDEwMmZmXCIpOyAvLyA9PiBuZXcgVWludDhBcnJheShbIDEsIDIsIDI1NSBdKVxuICogY29uc3Qgc3RyID0gaGV4LmVuY29kZShiKTsgLy8gXCIwMTAyZmZcIlxuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBoZXggPSAvKiBAX19QVVJFX18gKi8gZnJlZXplKCgpID0+IGhhc0hleEJ1aWx0aW5cbiAgICA/IGhleEJ1aWx0aW5cbiAgICA6IGNoYWluKHJhZGl4Mig0KSwgXG4gICAgLy8gQ2FzZS1pbnNlbnNpdGl2ZSBkZWNvZGUgdmlhIHRhYmxlIGFsaWFzZXMgaW5zdGVhZCBvZiBhIHRvTG93ZXJDYXNlIHBhc3MuXG4gICAgYWxwaGFiZXQoJzAxMjM0NTY3ODlhYmNkZWYnLCB7IEE6ICdhJywgQjogJ2InLCBDOiAnYycsIEQ6ICdkJywgRTogJ2UnLCBGOiAnZicgfSksIG5vcm1hbGl6ZSgocykgPT4ge1xuICAgICAgICAvLyBhc3RyIGZpcnN0OiBzYW1lIG5vbi1zdHJpbmcgbWVzc2FnZSBhcyB0aGUgbmF0aXZlIHBhdGgsIGFuZCBubyBgcy5sZW5ndGhgXG4gICAgICAgIC8vIGFjY2VzcyBvbiBudWxsIC8gdW5kZWZpbmVkIHdoaWxlIGJ1aWxkaW5nIHRoZSBlcnJvci5cbiAgICAgICAgYXN0cignaGV4Jywgcyk7XG4gICAgICAgIGlmIChzLmxlbmd0aCAlIDIgIT09IDApXG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBoZXguZGVjb2RlOiBvZGQtbGVuZ3RoIHN0cmluZyAoJHtzLmxlbmd0aH0pYCk7XG4gICAgICAgIHJldHVybiBzO1xuICAgIH0pKSk7XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6Ijs7QUFJQSxJQUFNLFVBQVUsT0FBTyxPQUFPLE9BQU8sR0FBRyxDQUFDO0FBQ3pDLFNBQVMsUUFBUSxHQUFHO0NBS2hCLE9BQVEsYUFBYSxjQUNoQixZQUFZLE9BQU8sQ0FBQyxLQUNqQixFQUFFLFlBQVksU0FBUyxnQkFDdkIsdUJBQXVCLEtBQ3ZCLEVBQUUsc0JBQXNCO0FBQ3BDOztBQUVBLFNBQVMsT0FBTyxHQUFHO0NBQ2YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUNWLE1BQU0sSUFBSSxVQUFVLHFCQUFxQjtBQUNqRDtBQUNBLFNBQVMsVUFBVSxVQUFVLEtBQUs7Q0FDOUIsSUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEdBQ2xCLE9BQU87Q0FDWCxJQUFJLElBQUksV0FBVyxHQUNmLE9BQU87Q0FDWCxJQUFJLFVBQ0EsT0FBTyxJQUFJLE9BQU8sU0FBUyxPQUFPLFNBQVMsUUFBUTtNQUduRCxPQUFPLElBQUksT0FBTyxTQUFTLE9BQU8sY0FBYyxJQUFJLENBQUM7QUFFN0Q7QUFDQSxTQUFTLElBQUksT0FBTztDQUNoQixJQUFJLE9BQU8sVUFBVSxZQUNqQixNQUFNLElBQUksVUFBVSxtQkFBbUI7Q0FDM0MsT0FBTztBQUNYO0FBQ0EsU0FBUyxLQUFLLE9BQU8sT0FBTztDQUN4QixJQUFJLE9BQU8sVUFBVSxVQUNqQixNQUFNLElBQUksVUFBVSxHQUFHLE1BQU0sa0JBQWtCO0NBQ25ELE9BQU87QUFDWDtBQUNBLFNBQVMsUUFBUSxHQUFHLFFBQVEsVUFBVTtDQUNsQyxJQUFJLE9BQU8sTUFBTSxVQUNiLE1BQU0sSUFBSSxVQUFVLEdBQUcsTUFBTSx5QkFBeUIsT0FBTyxHQUFHO0NBQ3BFLElBQUksQ0FBQyxPQUFPLGNBQWMsQ0FBQyxHQUN2QixNQUFNLElBQUksV0FBVyxHQUFHLE1BQU0sK0JBQStCLEdBQUc7QUFDeEU7QUFDQSxTQUFTLFFBQVEsT0FBTyxPQUFPO0NBQzNCLElBQUksQ0FBQyxVQUFVLE9BQU8sS0FBSyxHQUN2QixNQUFNLElBQUksVUFBVSxHQUFHLE1BQU0sNEJBQTRCO0FBQ2pFO0FBQ0EsU0FBUyxNQUFNLEdBQUcsTUFBTTtDQUNwQixNQUFNLE1BQU0sTUFBTTtDQUVsQixNQUFNLFFBQVEsR0FBRyxPQUFPLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQztDQUtwQyxPQUFPO0VBQUUsUUFITSxLQUFLLEtBQUssTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLFlBQVksTUFBTSxFQUc3QztFQUFHLFFBREYsS0FBSyxLQUFLLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxPQUFPLE1BQU0sRUFDaEM7Q0FBRTtBQUM1QjtBQUNBLFNBQVMsVUFBVSxJQUFJO0NBQ25CLElBQUksRUFBRTtDQUNOLE9BQU87RUFBRSxTQUFTLFNBQVM7RUFBTSxTQUFTLE9BQU8sR0FBRyxFQUFFO0NBQUU7QUFDNUQ7QUFDQSxJQUFNLFNBQXlCLHVCQUFPO0NBQ2xDLElBQUksTUFBTSxDQUFDO0NBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksS0FDcEIsSUFBSSxLQUFLLEtBQUssQ0FBQztDQUNuQixPQUFPO0FBQ1gsRUFBQSxDQUFHO0FBSUgsU0FBUyxXQUFXLElBQUksTUFBTSxHQUFHLFFBQVE7Q0FDckMsTUFBTSxNQUFNLElBQUksTUFBTSxHQUFHO0NBQ3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQ3JCLElBQUksS0FBSyxHQUFHO0NBQ2hCLE9BQU87QUFDWDtBQUtBLElBQU0sZUFBK0IsdUJBQU87Q0FDeEMsSUFBSTtFQUNBLE1BQU0sVUFBVSxJQUFJLFlBQVk7RUFHaEMsT0FBTyxRQUFRLE9BQU8sV0FBVyxHQUFHLElBQU0sSUFBTSxJQUFNLEdBQUksQ0FBQyxNQUFNLFNBQzNELFVBQ0EsS0FBQTtDQUNWLFNBQ08sR0FBRztFQUNOO0NBQ0o7QUFDSixFQUFBLENBQUc7QUFDSCxJQUFNLFlBQVk7QUFDbEIsU0FBUyxrQkFBa0IsT0FBTztDQUM5QixNQUFNLE1BQU0sTUFBTTtDQUdsQixJQUFJLGlCQUFpQixLQUFBLEtBQWEsT0FBTyxJQUNyQyxPQUFPLGFBQWEsT0FBTyxLQUFLO0NBQ3BDLElBQUksT0FBTyxXQUNQLE9BQU8sT0FBTyxhQUFhLE1BQU0sTUFBTSxLQUFLO0NBQ2hELElBQUksTUFBTTtDQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssV0FDMUIsT0FBTyxPQUFPLGFBQWEsTUFBTSxNQUFNLE1BQU0sU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDO0NBQzNFLE9BQU87QUFDWDs7Ozs7QUFLQSxTQUFTLE9BQU8sTUFBTTtDQUNsQixRQUFRLElBQUk7Q0FDWixJQUFJLFFBQVEsS0FBSyxPQUFPLEdBQ3BCLE1BQU0sSUFBSSxXQUFXLGtDQUFrQztDQUMzRCxNQUFNLE9BQU8sT0FBTyxRQUFRO0NBQzVCLE9BQU87RUFDSCxTQUFTLFVBQVU7R0FDZixPQUFPLEtBQUs7R0FDWixNQUFNLE1BQU0sTUFBTTtHQUVsQixNQUFNLE1BQU0sSUFBSSxXQUFXLEtBQUssS0FBTSxNQUFNLElBQUssSUFBSSxDQUFDO0dBQ3RELElBQUksUUFBUTtHQUNaLElBQUksTUFBTTtHQUNWLElBQUksSUFBSTtHQUNSLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNO0lBRXRCLElBQUksSUFBSSxJQUFJLEtBQUs7S0FDYixRQUFTLFNBQVMsS0FBTyxNQUFNLE1BQU0sS0FBTyxNQUFNLElBQUksTUFBTSxJQUFLLE1BQU0sSUFBSTtLQUMzRSxPQUFPO0tBQ1AsS0FBSztJQUNULE9BQ0s7S0FLRCxTQUFVLFNBQVMsSUFBSyxNQUFNLE1BQU07S0FDcEMsT0FBTztLQUNQO0lBQ0o7SUFFQSxTQUFTO0tBQ0wsT0FBTztLQUNQLElBQUksT0FBUSxTQUFTLE1BQU87S0FDNUIsSUFBSSxNQUFNLE1BQ047SUFDUjtHQUNKO0dBQ0EsSUFBSSxNQUFNLEdBQ04sSUFBSSxLQUFNLFNBQVUsT0FBTyxNQUFRO0dBQ3ZDLE9BQU87RUFDWDtFQUNBLFNBQVMsV0FBVztHQUdoQixNQUFNLE1BQU0sT0FBTztHQUNuQixNQUFNLE1BQU0sSUFBSSxXQUFXLEtBQUssTUFBTyxNQUFNLE9BQVEsQ0FBQyxDQUFDO0dBQ3ZELElBQUksUUFBUTtHQUNaLElBQUksTUFBTTtHQUNWLElBQUksSUFBSTtHQUNSLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7SUFJMUIsU0FBVSxTQUFTLE9BQVEsT0FBTyxNQUFNO0lBQ3hDLE9BQU87SUFDUCxPQUFPLE9BQU8sR0FBRyxPQUFPLEdBQ3BCLElBQUksT0FBUSxTQUFVLE1BQU0sSUFBTTtHQUMxQztHQUNBLFFBQVMsU0FBVSxJQUFJLE1BQVE7R0FDL0IsSUFBSSxPQUFPLE1BQ1AsTUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0dBQ3BDLElBQUksUUFBUSxHQUNSLE1BQU0sSUFBSSxNQUFNLHFCQUFxQixPQUFPO0dBQ2hELE9BQU87RUFDWDtDQUNKO0FBQ0o7Ozs7O0FBS0EsU0FBUyxTQUFTLFNBQVMsU0FBUztDQUNoQyxNQUFNLE1BQU0sUUFBUTtDQUVwQixJQUFJLE1BQU0sS0FDTixNQUFNLElBQUksTUFBTSwyQkFBMkI7Q0FDL0MsTUFBTSxXQUFXLElBQUksV0FBVyxHQUFHO0NBQ25DLE1BQU0sNEJBQVcsSUFBSSxVQUFVLEdBQUcsRUFBQSxDQUFFLEtBQUssRUFBRTtDQUMzQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQzFCLE1BQU0sT0FBTyxRQUFRLFdBQVcsQ0FBQztFQUNqQyxJQUFJLFFBQVEsWUFBWSxDQUFDLE1BQU0sUUFBUSxPQUFPLEtBQzFDLE1BQU0sSUFBSSxNQUFNLDBDQUEwQztFQUM5RCxTQUFTLEtBQUs7RUFDZCxTQUFTLFFBQVE7Q0FDckI7Q0FHQSxJQUFJLFlBQVksS0FBQSxHQUNaLEtBQUssTUFBTSxTQUFTLE9BQU8sS0FBSyxPQUFPLEdBQUc7RUFDdEMsTUFBTSxPQUFPLE1BQU0sV0FBVyxDQUFDO0VBQy9CLE1BQU0sU0FBUyxTQUFTLFFBQVEsTUFBTSxDQUFDLFdBQVcsQ0FBQztFQUNuRCxJQUFJLE1BQU0sV0FBVyxLQUFLLE9BQU8sT0FBTyxXQUFXLEtBQUEsS0FBYSxXQUFXLElBQ3ZFLE1BQU0sSUFBSSxNQUFNLDJCQUEyQixPQUFPO0VBQ3RELFNBQVMsUUFBUTtDQUNyQjtDQUVKLE9BQU87RUFDSCxTQUFTLFdBQVc7R0FDaEIsTUFBTSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU07R0FDMUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0lBQ3BDLE1BQU0sSUFBSSxPQUFPO0lBQ2pCLE1BQU0sT0FBTyxTQUFTO0lBSXRCLElBQUksU0FBUyxLQUFBLEdBQ1QsTUFBTSxJQUFJLE1BQU0sa0NBQWtDLEdBQUc7SUFDekQsTUFBTSxLQUFLO0dBQ2Y7R0FDQSxPQUFPLGtCQUFrQixLQUFLO0VBQ2xDO0VBQ0EsU0FBUyxVQUFVO0dBSWYsS0FBSyxVQUFVLEtBQUs7R0FDcEIsTUFBTSxPQUFPLE1BQU07R0FDbkIsTUFBTSxTQUFTLElBQUksV0FBVyxJQUFJO0dBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUs7SUFDM0IsTUFBTSxPQUFPLE1BQU0sV0FBVyxDQUFDO0lBQy9CLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBUyxRQUFRO0lBQzVDLElBQUksVUFBVSxJQUNWLE1BQU0sSUFBSSxNQUFNLG1CQUFtQixNQUFNLEdBQUcsY0FBYyxTQUFTO0lBQ3ZFLE9BQU8sS0FBSztHQUNoQjtHQUNBLE9BQU87RUFDWDtDQUNKO0FBQ0o7Ozs7QUFJQSxTQUFTLFFBQVEsTUFBTSxNQUFNLEtBQUs7Q0FDOUIsUUFBUSxJQUFJO0NBQ1osS0FBSyxXQUFXLEdBQUc7Q0FDbkIsT0FBTztFQUNILE9BQU8sTUFBTTtHQUNULE9BQVEsS0FBSyxTQUFTLE9BQVEsR0FDMUIsUUFBUTtHQUNaLE9BQU87RUFDWDtFQUNBLE9BQU8sT0FBTztHQUVWLEtBQUssVUFBVSxLQUFLO0dBQ3BCLElBQUksTUFBTSxNQUFNO0dBQ2hCLElBQUssTUFBTSxPQUFRLEdBQ2YsTUFBTSxJQUFJLE1BQU0seUJBQXlCO0dBQzdDLE9BQU8sTUFBTSxLQUFLLE1BQU0sTUFBTSxPQUFPLEtBQUssT0FFdEMsS0FEYyxNQUFNLEtBQUssT0FDZCxNQUFNLEdBQ2IsTUFBTSxJQUFJLE1BQU0seUJBQXlCO0dBRWpELE9BQU8sTUFBTSxNQUFNLEdBQUcsR0FBRztFQUM3QjtDQUNKO0FBQ0o7QUFDQSxTQUFTLGNBQWMsSUFBSTtDQUN2QixJQUFJLEVBQUU7Q0FDTixPQUFPLFNBQVUsR0FBRyxNQUFNO0VBR3RCLElBQUk7R0FDQSxPQUFPLEdBQUcsTUFBTSxNQUFNLElBQUk7RUFDOUIsU0FDTyxHQUFHLENBQUU7Q0FDaEI7QUFDSjtBQUNBLFNBQVMsU0FBUyxLQUFLLElBQUk7Q0FDdkIsUUFBUSxHQUFHO0NBR1gsSUFBSSxPQUFPLEdBQ1AsTUFBTSxJQUFJLFdBQVcscUNBQXFDLEtBQUs7Q0FDbkUsSUFBSSxFQUFFO0NBQ04sTUFBTSxNQUFNO0NBR1osT0FBTztFQUNILE9BQU8sTUFBTTtHQUNULE9BQU8sSUFBSTtHQUNYLE1BQU0sTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHO0dBQ2xDLE1BQU0sTUFBTSxJQUFJLFdBQVcsS0FBSyxTQUFTLEdBQUc7R0FDNUMsSUFBSSxJQUFJLElBQUk7R0FDWixJQUFJLElBQUksS0FBSyxLQUFLLE1BQU07R0FDeEIsT0FBTztFQUNYO0VBQ0EsT0FBTyxNQUFNO0dBQ1QsT0FBTyxJQUFJO0dBQ1gsTUFBTSxVQUFVLEtBQUssTUFBTSxHQUFHLENBQUMsR0FBRztHQUNsQyxNQUFNLGNBQWMsS0FBSyxNQUFNLENBQUMsR0FBRztHQUNuQyxNQUFNLGNBQWMsSUFBSSxPQUFPLENBQUMsQ0FBQyxNQUFNLEdBQUcsR0FBRztHQUM3QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUNyQixJQUFJLFlBQVksT0FBTyxZQUFZLElBQy9CLE1BQU0sSUFBSSxNQUFNLGtCQUFrQjtHQUMxQyxPQUFPO0VBQ1g7Q0FDSjtBQUNKOzs7Ozs7Ozs7Ozs7QUFjQSxJQUFhLFNBQXlCLDZCQUFhLE1BQU0sT0FBTyxDQUFDLEdBQUcsU0FBUyxrQkFBa0IsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUFlakcsSUFBYSxTQUF5Qiw2QkFBYSxNQUFNLE9BQU8sQ0FBQyxHQUFHLFNBQVMsa0NBQWtDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7QUFjN0gsSUFBYSxjQUE4Qiw2QkFBYSxNQUFNLE9BQU8sQ0FBQyxHQUFHLFNBQVMsa0NBQWtDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQWF0SCxJQUFhLFlBQTRCLDZCQUFhLE1BQU0sT0FBTyxDQUFDLEdBQUcsU0FBUyxrQ0FBa0MsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FBYWhJLElBQWEsaUJBQWlDLDZCQUFhLE1BQU0sT0FBTyxDQUFDLEdBQUcsU0FBUyxrQ0FBa0MsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7QUFZekgsSUFBYSxrQkFBa0MsNkJBQWEsTUFBTSxPQUFPLENBQUMsR0FBRyxTQUFTLGtDQUFrQyxHQUFHLFdBQVcsTUFBTTtDQUN4SSxLQUFLLDBCQUEwQixDQUFDO0NBQ2hDLE9BQU8sRUFBRSxZQUFZLENBQUMsQ0FBQyxRQUFRLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBUSxTQUFTLEdBQUc7QUFDbEUsQ0FBQyxDQUFDLENBQUM7QUFJSCxJQUFNLG1CQUFtQyx1QkFBTyxPQUFPLFdBQVcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsY0FDcEYsT0FBTyxXQUFXLGVBQWUsV0FBQSxDQUFZO0FBSWpELElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sdUJBQXVCLEdBQUcsVUFBVTtDQUN0QyxLQUFLLFVBQVUsQ0FBQztDQUNoQixNQUFNLFdBQVcsUUFBUSxjQUFjO0NBSXZDLElBQUksRUFBRSxTQUFTLEtBQUssaUJBQWlCLEtBQUssQ0FBQyxHQUN2QyxNQUFNLElBQUksTUFBTSxnQkFBZ0I7Q0FDcEMsT0FBTyxXQUFXLFdBQVcsR0FBRztFQUFFO0VBQVUsbUJBQW1CO0NBQVMsQ0FBQztBQUM3RTs7QUFFQSxJQUFNLGlCQUFpQyw2QkFBYSxNQUFNLE9BQU8sQ0FBQyxHQUFHLFNBQVMsa0VBQWtFLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7OztBQWM5SixJQUFhLFNBQXlCLDZCQUFhLG1CQUFtQjtDQUNsRSxPQUFPLEdBQUc7RUFBRSxPQUFPLENBQUM7RUFBRyxPQUFPLEVBQUUsU0FBUztDQUFHO0NBQzVDLE9BQU8sR0FBRztFQUFFLE9BQU8sb0JBQW9CLEdBQUcsS0FBSztDQUFHO0FBQ3RELElBQUksY0FBYzs7Ozs7Ozs7Ozs7O0FBWWxCLElBQWEsY0FBOEIsNkJBQWEsTUFBTSxPQUFPLENBQUMsR0FBRyxTQUFTLGtFQUFrRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7QUFjdEosSUFBYSxZQUE0Qiw2QkFBYSxtQkFBbUI7Q0FDckUsT0FBTyxHQUFHO0VBQUUsT0FBTyxDQUFDO0VBQUcsT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUFVLFlBQVksQ0FBQztDQUFHO0NBQ3JFLE9BQU8sR0FBRztFQUFFLE9BQU8sb0JBQW9CLEdBQUcsSUFBSTtDQUFHO0FBQ3JELElBQUksTUFBTSxPQUFPLENBQUMsR0FBRyxTQUFTLGtFQUFrRSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7OztBQVk5RyxJQUFhLGlCQUFpQyw2QkFBYSxNQUFNLE9BQU8sQ0FBQyxHQUFHLFNBQVMsa0VBQWtFLENBQUMsQ0FBQztBQVV6SixJQUFNLFlBQVk7QUFDbEIsSUFBTSxVQUFVO0NBQ1osU0FBUyxVQUFVO0VBQ2YsT0FBTyxLQUFLO0VBQ1osTUFBTSxPQUFPLE1BQU07RUFDbkIsSUFBSSxTQUFTLEdBQ1QsdUJBQU8sSUFBSSxXQUFXLENBQUM7RUFHM0IsSUFBSSxRQUFRO0VBQ1osT0FBTyxRQUFRLE9BQU8sS0FBSyxNQUFNLFdBQVcsR0FDeEM7RUFFSixNQUFNLFNBQVMsS0FBSyxLQUFLLE9BQU8sQ0FBQztFQUNqQyxNQUFNLFFBQVEsSUFBSSxZQUFZLE1BQU07RUFDcEMsTUFBTSxNQUFNLE9BQU87RUFDbkIsSUFBSSxLQUNBLE1BQU0sS0FBSyxNQUFNO0VBQ3JCLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTSxLQUFLLEdBQUcsS0FDekMsTUFBTSxLQUFNLE1BQU0sTUFBTSxJQUFLLE1BQU0sSUFBSTtFQUkzQyxNQUFNLFNBQVMsQ0FBQztFQUNoQixJQUFJLE1BQU07RUFDVixPQUFPLE1BQU0sUUFBUTtHQUNqQixJQUFJLFFBQVE7R0FDWixLQUFLLElBQUksSUFBSSxLQUFLLElBQUksUUFBUSxLQUFLO0lBQy9CLE1BQU0sTUFBTSxRQUFRLFFBQVUsTUFBTTtJQUNwQyxNQUFNLElBQUksS0FBSyxNQUFNLE1BQU0sU0FBUztJQUNwQyxRQUFRLE1BQU0sSUFBSTtJQUNsQixNQUFNLEtBQUs7SUFDWCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQ2pCO0dBQ1I7R0FDQSxPQUFPLEtBQUssS0FBSztFQUNyQjtFQUtBLE1BQU0sTUFBTSxPQUFPLFNBQVM7RUFDNUIsSUFBSSxNQUFNLE1BQU07RUFDaEIsS0FBSyxJQUFJLElBQUksT0FBTyxPQUFPLElBQUksS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHO0dBQy9DO0dBQ0EsSUFBSSxJQUFJLElBQ0o7RUFDUjtFQUNBLE1BQU0sTUFBTSxJQUFJLFdBQVcsUUFBUSxHQUFHO0VBQ3RDLElBQUksSUFBSSxJQUFJLFNBQVM7RUFDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztHQUMxQixJQUFJLElBQUksT0FBTztHQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDeEIsSUFBSSxPQUFPLElBQUk7SUFDZixJQUFJLEtBQUssTUFBTSxJQUFJLEVBQUU7R0FDekI7RUFDSjtFQUNBLEtBQUssSUFBSSxJQUFJLE9BQU8sTUFBTSxLQUFLLE9BQU8sSUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFLEdBQ3ZELElBQUksT0FBTyxJQUFJO0VBQ25CLE9BQU87Q0FDWDtDQUNBLFNBQVMsV0FBVztFQUNoQixPQUFPLE1BQU07RUFDYixNQUFNLE9BQU8sT0FBTztFQUNwQixJQUFJLFNBQVMsR0FDVCx1QkFBTyxJQUFJLFdBQVcsQ0FBQztFQUMzQixJQUFJLFFBQVEsT0FDUixNQUFNLElBQUksTUFBTSxnQkFBZ0I7RUFDcEMsSUFBSSxRQUFRO0VBQ1osT0FBTyxRQUFRLE9BQU8sS0FBSyxPQUFPLFdBQVcsR0FDekM7RUFJSixNQUFNLFFBQVEsSUFBSSxZQUFZLEtBQUssS0FBTSxPQUFPLElBQUssRUFBRSxJQUFJLENBQUM7RUFDNUQsSUFBSSxPQUFPO0VBQ1gsSUFBSSxJQUFJO0VBQ1IsSUFBSSxRQUFRLE9BQU8sS0FBSztFQUN4QixPQUFPLElBQUksTUFBTTtHQUNiLElBQUksT0FBTztHQUNYLElBQUksU0FBUztHQUNiLEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxJQUFJLEtBQUssS0FBSztJQUN0QyxNQUFNLElBQUksT0FBTztJQUdqQixJQUFJLEtBQUssSUFDTCxNQUFNLElBQUksTUFBTSxvQkFBb0IsR0FBRztJQUMzQyxPQUFPLE9BQU8sS0FBSztJQUNuQixVQUFVO0dBQ2Q7R0FDQSxRQUFRO0dBQ1IsSUFBSSxRQUFRO0dBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSztJQUMzQixNQUFNLE1BQU0sTUFBTSxLQUFLLFNBQVM7SUFDaEMsUUFBUSxLQUFLLE1BQU0sTUFBTSxLQUFPO0lBQ2hDLE1BQU0sS0FBSyxNQUFNLFFBQVE7R0FDN0I7R0FDQSxPQUFPLFFBQVEsR0FBRyxRQUFRLEtBQUssTUFBTSxRQUFRLEtBQU8sR0FDaEQsTUFBTSxVQUFVLFFBQVE7RUFDaEM7RUFHQSxNQUFNLGFBQWEsU0FBUyxJQUFJLElBQUksT0FBTyxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSTtFQUM1RSxNQUFNLE1BQU0sSUFBSSxXQUFXLFFBQVEsVUFBVTtFQUM3QyxJQUFJLElBQUksSUFBSSxTQUFTO0VBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEtBQUs7R0FDM0IsTUFBTSxPQUFPLE1BQU07R0FDbkIsSUFBSSxPQUFPLE9BQU87R0FDbEIsSUFBSSxLQUFLLE9BQ0wsSUFBSSxPQUFPLFFBQVE7RUFDM0I7RUFDQSxPQUFPO0NBQ1g7QUFDSjtBQUNBLElBQU0sYUFBYSxRQUFRLE1BQU0sU0FBUyxTQUFTLEdBQUcsQ0FBQzs7Ozs7Ozs7Ozs7QUFXdkQsSUFBYSxTQUF5Qiw2QkFBYSxVQUFVLDREQUE0RCxDQUFDOzs7Ozs7Ozs7O0FBVTFILElBQWEsZUFBK0IsNkJBQWEsVUFBVSw0REFBNEQsQ0FBQzs7Ozs7Ozs7OztBQVVoSSxJQUFhLFlBQTRCLDZCQUFhLFVBQVUsNERBQTRELENBQUM7QUFHN0gsSUFBTSxnQkFBZ0I7Q0FBQztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUk7QUFBRTs7Ozs7Ozs7Ozs7O0FBWWxELElBQWEsWUFBNEIsOEJBQWM7Q0FDbkQsT0FBTyxNQUFNO0VBQ1QsT0FBTyxJQUFJO0VBQ1gsSUFBSSxNQUFNO0VBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLEdBQUc7R0FDckMsTUFBTSxRQUFRLEtBQUssU0FBUyxHQUFHLElBQUksQ0FBQztHQUNwQyxPQUFPLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxTQUFTLGNBQWMsTUFBTSxTQUFTLEdBQUc7RUFDekU7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxPQUFPLEtBQUs7RUFDUixLQUFLLG9CQUFvQixHQUFHO0VBQzVCLE1BQU0sU0FBUyxJQUFJO0VBS25CLE1BQU0sWUFBWSxTQUFTO0VBQzNCLE1BQU0sWUFBWSxjQUFjLElBQUksSUFBSSxjQUFjLFFBQVEsU0FBUztFQUN2RSxJQUFJLGNBQWMsSUFDZCxNQUFNLElBQUksTUFBTSxtQ0FBbUMsV0FBVztFQUNsRSxNQUFNLE1BQU0sSUFBSSxXQUFXLEtBQUssTUFBTSxTQUFTLEVBQUUsSUFBSSxJQUFJLFNBQVM7RUFDbEUsSUFBSSxJQUFJO0VBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSyxJQUFJO0dBQ2pDLE1BQU0sUUFBUSxJQUFJLE1BQU0sR0FBRyxJQUFJLEVBQUU7R0FDakMsTUFBTSxXQUFXLE1BQU0sV0FBVyxLQUFLLElBQUk7R0FDM0MsTUFBTSxRQUFRLE9BQU8sT0FBTyxLQUFLO0dBQ2pDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFNBQVMsVUFBVSxLQUN6QyxJQUFJLE1BQU0sT0FBTyxHQUNiLE1BQU0sSUFBSSxNQUFNLDBCQUEwQjtHQUVsRCxLQUFLLElBQUksSUFBSSxNQUFNLFNBQVMsVUFBVSxJQUFJLE1BQU0sUUFBUSxLQUNwRCxJQUFJLE9BQU8sTUFBTTtFQUN6QjtFQUNBLE9BQU87Q0FDWDtBQUNKLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCRixJQUFhLHFCQUFxQixXQUFXO0NBRXpDLElBQUksTUFBTTtDQUNWLE1BQU0sVUFBVTtDQUNoQixPQUFPLE1BQU0sU0FBUyxJQUFJLFNBQVMsUUFBUSxRQUFRLElBQUksQ0FBQyxDQUFDLEdBQUcsTUFBTTtBQUN0RTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsSUFBYSxjQUFjO0FBSzNCLElBQU0sZ0JBQWdDLHlCQUFTLGtDQUFrQztBQUdqRixTQUFTLFVBQVUsT0FBTztDQUN0QixNQUFNLE1BQU0sTUFBTTtDQUNsQixNQUFNLE1BQU0sSUFBSSxXQUFXLEdBQUc7Q0FDOUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztFQUMxQixNQUFNLElBQUksTUFBTTtFQUNoQixJQUFJLElBQUksS0FBSyxLQUFLLElBQ2QsTUFBTSxJQUFJLE1BQU0sa0NBQWtDLEdBQUc7RUFDekQsSUFBSSxLQUFLO0NBQ2I7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxJQUFNLHFCQUFxQjtDQUFDO0NBQVk7Q0FBWTtDQUFZO0NBQVk7QUFBVTtBQUV0RixTQUFTLGNBQWMsS0FBSztDQUN4QixNQUFNLElBQUksT0FBTztDQUNqQixJQUFJLE9BQU8sTUFBTSxhQUFjO0NBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxtQkFBbUIsUUFBUSxLQUMzQyxLQUFNLEtBQUssSUFBSyxPQUFPLEdBQ25CLE9BQU8sbUJBQW1CO0NBRWxDLE9BQU87QUFDWDtBQUNBLFNBQVMsYUFBYSxRQUFRLE9BQU8sZ0JBQWdCLEdBQUc7Q0FDcEQsTUFBTSxNQUFNLE9BQU87Q0FDbkIsSUFBSSxNQUFNO0NBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztFQUMxQixNQUFNLElBQUksT0FBTyxXQUFXLENBQUM7RUFDN0IsSUFBSSxJQUFJLE1BQU0sSUFBSSxLQUNkLE1BQU0sSUFBSSxNQUFNLG1CQUFtQixPQUFPLEVBQUU7RUFDaEQsTUFBTSxjQUFjLEdBQUcsSUFBSyxLQUFLO0NBQ3JDO0NBQ0EsTUFBTSxjQUFjLEdBQUc7Q0FDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FDckIsTUFBTSxjQUFjLEdBQUcsSUFBSyxPQUFPLFdBQVcsQ0FBQyxJQUFJO0NBQ3ZELEtBQUssSUFBSSxLQUFLLE9BQ1YsTUFBTSxjQUFjLEdBQUcsSUFBSTtDQUMvQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUNuQixNQUFNLGNBQWMsR0FBRztDQUUzQixPQUFPO0NBQ1AsTUFBTSxzQkFBTSxJQUFJLFdBQVcsQ0FBQztDQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUNuQixJQUFJLEtBQU0sUUFBUyxLQUFLLElBQUksS0FBTztDQUN2QyxPQUFPLGNBQWMsT0FBTyxHQUFHO0FBQ25DO0FBQ0EsU0FBUyxVQUFVLFVBQVU7Q0FFekIsTUFBTSxpQkFBaUIsYUFBYSxXQUFXLElBQUk7Q0FFbkQsTUFBTSxTQUFTLE9BQU8sQ0FBQztDQUN2QixNQUFNLFdBQVcsU0FBUztFQUN0QixPQUFPLElBQUk7RUFHWCxNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBTSxNQUFNLElBQUssQ0FBQyxDQUFDO0VBQzlDLElBQUksUUFBUTtFQUNaLElBQUksTUFBTTtFQUNWLElBQUksSUFBSTtFQUNSLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7R0FJMUIsUUFBUyxTQUFTLElBQUssS0FBSztHQUM1QixPQUFPO0dBQ1AsT0FBTyxPQUFPLEdBQUcsT0FBTyxHQUNwQixJQUFJLE9BQVEsU0FBVSxNQUFNLElBQU07RUFDMUM7RUFDQSxJQUFJLE1BQU0sR0FDTixJQUFJLEtBQU0sU0FBVSxJQUFJLE1BQVE7RUFDcEMsT0FBTztDQUNYO0NBQ0EsTUFBTSxhQUFhLE9BQU87RUFDdEIsUUFBUSxpQkFBaUIsRUFBRTtFQUkzQixNQUFNLE1BQU0sR0FBRztFQUNmLE1BQU0sU0FBUyxJQUFJLFdBQVcsR0FBRztFQUNqQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0dBQzFCLE1BQU0sSUFBSSxHQUFHO0dBQ2IsSUFBSSxJQUFJLEtBQUssS0FBSyxJQUNkLE1BQU0sSUFBSSxNQUFNLCtCQUErQixHQUFHO0dBQ3RELE9BQU8sS0FBSztFQUNoQjtFQUNBLE9BQU8sT0FBTyxPQUFPLE1BQU07Q0FDL0I7Q0FDQSxNQUFNLGtCQUFrQixjQUFjLFNBQVM7Q0FDL0MsU0FBUyxPQUFPLFFBQVEsT0FBTyxRQUFRLElBQUk7RUFDdkMsS0FBSyx3QkFBd0IsTUFBTTtFQUNuQyxJQUFJLFVBQVUsT0FDVixRQUFRLE9BQU8sT0FBTztFQUMxQixJQUFJLFFBQVEsS0FBSyxHQUNiLFFBQVEsV0FBVyxLQUFLO0VBQzVCLFFBQVEsaUJBQWlCLEtBQUs7RUFDOUIsTUFBTSxPQUFPLE9BQU87RUFDcEIsSUFBSSxTQUFTLEdBQ1QsTUFBTSxJQUFJLFVBQVUseUJBQXlCLE1BQU07RUFFdkQsTUFBTSxlQUFlLE9BQU8sSUFBSSxNQUFNO0VBQ3RDLElBQUksVUFBVSxTQUFTLGVBQWUsT0FDbEMsTUFBTSxJQUFJLFVBQVUsVUFBVSxhQUFhLGlCQUFpQixPQUFPO0VBQ3ZFLE1BQU0sVUFBVSxPQUFPLFlBQVk7RUFDbkMsTUFBTSxNQUFNLGFBQWEsU0FBUyxPQUFPLGNBQWM7RUFDdkQsT0FBTyxHQUFHLFFBQVEsR0FBRyxjQUFjLE9BQU8sVUFBVSxLQUFLLENBQUMsSUFBSTtDQUNsRTtDQUNBLFNBQVMsT0FBTyxLQUFLLFFBQVEsSUFBSTtFQUM3QixLQUFLLHVCQUF1QixHQUFHO0VBQy9CLElBQUksVUFBVSxPQUNWLFFBQVEsT0FBTyxPQUFPO0VBQzFCLE1BQU0sT0FBTyxJQUFJO0VBRWpCLElBQUksT0FBTyxLQUFNLFVBQVUsU0FBUyxPQUFPLE9BQ3ZDLE1BQU0sSUFBSSxVQUFVLHlCQUF5QixLQUFLLGlCQUFpQixNQUFNLEVBQUU7RUFFL0UsTUFBTSxVQUFVLElBQUksWUFBWTtFQUNoQyxJQUFJLFFBQVEsV0FBVyxRQUFRLElBQUksWUFBWSxHQUMzQyxNQUFNLElBQUksTUFBTSwrQkFBK0I7RUFDbkQsTUFBTSxXQUFXLFFBQVEsWUFBWSxHQUFHO0VBQ3hDLElBQUksYUFBYSxLQUFLLGFBQWEsSUFDL0IsTUFBTSxJQUFJLE1BQU0sdUJBQXVCO0VBQzNDLE1BQU0sU0FBUyxRQUFRLE1BQU0sR0FBRyxRQUFRO0VBQ3hDLE1BQU0sT0FBTyxRQUFRLE1BQU0sV0FBVyxDQUFDO0VBQ3ZDLElBQUksS0FBSyxTQUFTLEdBQ2QsTUFBTSxJQUFJLE1BQU0scUJBQXFCO0VBQ3pDLE1BQU0sU0FBUyxjQUFjLE9BQU8sSUFBSTtFQUN4QyxNQUFNLFFBQVEsV0FBVyxRQUFRLE9BQU8sU0FBUyxDQUFDO0VBQ2xELE1BQU0sTUFBTSxhQUFhLFFBQVEsT0FBTyxjQUFjO0VBQ3RELElBQUksQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUNsQixNQUFNLElBQUksTUFBTSx1QkFBdUIsS0FBSztFQUNoRCxPQUFPO0dBQUU7R0FBUTtFQUFNO0NBQzNCO0NBQ0EsTUFBTSxlQUFlLGNBQWMsTUFBTTtDQUN6QyxTQUFTLGNBQWMsS0FBSztFQUV4QixNQUFNLEVBQUUsUUFBUSxVQUFVLE9BQU8sS0FBSyxLQUFLO0VBQzNDLE9BQU87R0FDSDtHQUNBO0dBQ0EsT0FBTyxVQUFVLEtBQUs7RUFDMUI7Q0FDSjtDQUNBLFNBQVMsZ0JBQWdCLFFBQVEsT0FBTztFQUVwQyxPQUFPLE9BQU8sUUFBUSxRQUFRLEtBQUssQ0FBQztDQUN4QztDQUNBLE9BQU87RUFDSDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0o7QUFDSjs7Ozs7Ozs7Ozs7O0FBWUEsSUFBYSxTQUF5Qiw2QkFBYSxVQUFVLFFBQVEsQ0FBQzs7Ozs7Ozs7Ozs7OztBQWF0RSxJQUFhLFVBQTBCLDZCQUFhLFVBQVUsU0FBUyxDQUFDOzs7Ozs7Ozs7O0FBVXhFLElBQWEsUUFBd0IsOEJBQWM7Q0FDL0MsT0FBTyxNQUFNO0VBQ1QsT0FBTyxJQUFJO0VBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0dBQ2xDLE1BQU0sT0FBTyxLQUFLO0dBSWxCLElBQUksT0FBTyxLQUNQLE1BQU0sSUFBSSxXQUFXLGtCQUFrQixLQUFLLE1BQU0sR0FBRztFQUM3RDtFQUNBLE9BQU8sa0JBQWtCLElBQUk7Q0FDakM7Q0FDQSxPQUFPLEtBQUs7RUFDUixJQUFJLE9BQU8sUUFBUSxVQUNmLE1BQU0sSUFBSSxVQUFVLGdDQUFnQyxPQUFPLEdBQUc7RUFDbEUsTUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07RUFDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0dBR2pDLE1BQU0sV0FBVyxJQUFJLFdBQVcsQ0FBQztHQUNqQyxJQUFJLFdBQVcsS0FDWCxNQUFNLElBQUksV0FBVyxtQkFBbUIsSUFBSSxHQUFHLEtBQUssU0FBUyxPQUFPLEdBQUc7R0FDM0UsSUFBSSxLQUFLO0VBQ2I7RUFDQSxPQUFPO0NBQ1g7QUFDSixFQUFFO0FBQ0YsSUFBTSxxQkFBcUIsUUFBUTtDQUcvQixJQUFJO0VBQ0EsT0FBTyxVQUFVLEdBQUcsTUFBTTtDQUM5QixTQUFBLFNBQ007RUFDRixPQUFPO0NBQ1g7QUFDSjtBQUNBLElBQU0sZ0JBQWdDLHVCQUV0QyxPQUFPLEdBQUcsaUJBQWlCLGNBQ3BCLFFBQVEsSUFBSSxhQUFhLElBQzFCLGtCQUFBLENBQW1CO0FBSXpCLElBQU0sV0FBVyxzQkFBTSxJQUFJLFVBQVUsd0JBQXdCLEdBQUc7QUFDaEUsSUFBTSxlQUErQiw4QkFBYztDQUMvQyxPQUFPLE1BQU07RUFDVCxPQUFPLElBQUk7RUFDWCxJQUFJLE1BQU07RUFDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxTQUFTO0dBQzlCLE1BQU0sSUFBSSxLQUFLO0dBQ2YsSUFBSSxJQUFJLEtBQWE7SUFDakIsT0FBTyxPQUFPLGFBQWEsQ0FBQztJQUM1QjtHQUNKO0dBQ0EsSUFBSSxJQUFJLE9BQWUsS0FBSyxLQUFLLFFBQzdCLE1BQU0sUUFBUSxJQUFJLENBQUM7R0FDdkIsTUFBTSxJQUFJLEtBQUs7R0FDZixLQUFLLElBQUksU0FBaUIsS0FDdEIsTUFBTSxRQUFRLElBQUksQ0FBQztHQUN2QixJQUFJLE1BQU8sSUFBSSxPQUFnQixJQUFNLElBQUk7R0FDekMsSUFBSSxLQUFLLEtBQWE7SUFDbEIsSUFBSSxLQUFLLEtBQUssUUFDVixNQUFNLFFBQVEsSUFBSSxDQUFDO0lBQ3ZCLE1BQU0sSUFBSSxLQUFLO0lBQ2YsS0FBSyxJQUFJLFNBQWlCLE9BQ3JCLE1BQU0sT0FBZSxJQUFJLE9BQ3pCLE1BQU0sT0FBUSxLQUFLLEtBQ3BCLE1BQU0sUUFBUSxJQUFJLENBQUM7SUFDdkIsTUFBTyxJQUFJLE9BQWdCLE1BQVEsSUFBSSxPQUFnQixJQUFNLElBQUk7SUFDakUsSUFBSSxLQUFLLEtBQWE7S0FDbEIsSUFBSSxLQUFLLEtBQUssUUFDVixNQUFNLFFBQVEsSUFBSSxDQUFDO0tBQ3ZCLE1BQU0sSUFBSSxLQUFLO0tBQ2YsSUFBSSxJQUFJLFFBQ0gsSUFBSSxTQUFpQixPQUNyQixNQUFNLE9BQWUsSUFBSSxPQUN6QixNQUFNLE9BQWUsS0FBSyxLQUMzQixNQUFNLFFBQVEsSUFBSSxDQUFDO0tBQ3ZCLE1BQ00sSUFBSSxNQUFNLE1BQ04sSUFBSSxPQUFnQixNQUNwQixJQUFJLE9BQWdCLElBQ3JCLElBQUk7SUFDakI7R0FDSjtHQUNBLElBQUksS0FBSyxPQUNMLE9BQU8sT0FBTyxhQUFhLEVBQUU7UUFDNUI7SUFDRCxNQUFNO0lBQ04sT0FBTyxPQUFPLGNBQWMsTUFBTSxNQUFNLFFBQVMsS0FBSyxRQUFTLEtBQU07R0FDekU7RUFDSjtFQUNBLE9BQU87Q0FDWDtDQUNBLE9BQU8sS0FBSztFQUNSLEtBQUssUUFBUSxHQUFHO0VBQ2hCLElBQUksQ0FBQyxjQUFjLEdBQUcsR0FDbEIsTUFBTSxJQUFJLFVBQVUsa0NBQWtDO0VBRzFELE1BQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxTQUFTLENBQUM7RUFDekMsSUFBSSxNQUFNO0VBQ1YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0dBQ2pDLElBQUksSUFBSSxJQUFJLFdBQVcsQ0FBQztHQUN4QixJQUFJLElBQUksS0FBYTtJQUNqQixJQUFJLFNBQVM7SUFDYjtHQUNKO0dBQ0EsSUFBSSxLQUFLLFNBQVUsS0FBSyxPQUFRO0lBQzVCLE1BQU0sSUFBSSxJQUFJLFdBQVcsRUFBRSxDQUFDO0lBQzVCLElBQUksU0FBWSxJQUFJLFNBQVcsTUFBTSxJQUFJO0dBQzdDO0dBQ0EsSUFBSSxLQUFLLE9BQVM7SUFDZCxJQUFJLFNBQVUsS0FBSyxLQUFNO0lBQ3pCLElBQUksU0FBVyxLQUFLLEtBQU0sS0FBZTtHQUM3QyxPQUNLLElBQUksS0FBSyxNQUNWLElBQUksU0FBVSxLQUFLLEtBQU07UUFFekIsSUFBSSxTQUFVLEtBQUssSUFBSztHQUM1QixJQUFJLEtBQUssTUFDTCxJQUFJLFNBQVcsS0FBSyxJQUFLLEtBQWU7R0FDNUMsSUFBSSxTQUFVLElBQUksS0FBZTtFQUNyQztFQUNBLE9BQU8sSUFBSSxTQUFTLEdBQUcsR0FBRztDQUM5QjtBQUNKLEVBQUU7Ozs7Ozs7Ozs7Ozs7OztBQWVGLElBQWEsT0FBdUIsNkJBQWE7Q0FDN0MsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLGNBQWM7RUFHaEIsT0FBTyxNQUFNO0dBQ1QsT0FBTyxJQUFJO0dBQ1gsUUFBUSxpQkFBaUIsZUFBZSxJQUFJLFlBQVksU0FBUztJQUFFLFdBQVc7SUFBTSxPQUFPO0dBQUssQ0FBQyxHQUFBLENBQUksT0FBTyxJQUFJO0VBQ3BIO0VBQ0EsT0FBTyxLQUFLO0dBQ1IsS0FBSyxRQUFRLEdBQUc7R0FDaEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxHQUNsQixNQUFNLElBQUksVUFBVSxrQ0FBa0M7R0FDMUQsUUFBUSxpQkFBaUIsZUFBZSxJQUFJLFlBQVksR0FBQSxDQUFJLE9BQU8sR0FBRztFQUMxRTtDQUNKO0NBQ0EsT0FBTztFQUdILFFBQVEsT0FBTyxnQkFBZ0IsYUFBYSxZQUFZLFNBQVMsYUFBYTtFQUM5RSxRQUFRLE9BQU8sZ0JBQWdCLGFBQWEsWUFBWSxTQUFTLGFBQWE7Q0FDbEY7QUFDSixDQUFDO0FBRUQsSUFBYSxVQUEwQiw4QkFBYztDQUN2QztDQUNNO0NBQ1I7Q0FDQztDQUNDO0NBQ0k7Q0FDSztBQUN2QixFQUFFO0FBR0YsSUFBTSxnQkFBZ0MsdUJBRXRDLE9BQU8sV0FBVyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxjQUNqQyxPQUFPLFdBQVcsWUFBWSxXQUFBLENBQVk7QUFFOUMsSUFBTSxhQUFhO0NBR2YsT0FBTyxNQUFNO0VBQUUsT0FBTyxJQUFJO0VBQUcsT0FBTyxLQUFLLE1BQU07Q0FBRztDQUVsRCxPQUFPLEdBQUc7RUFBRSxLQUFLLE9BQU8sQ0FBQztFQUFHLE9BQU8sV0FBVyxRQUFRLENBQUM7Q0FBRztBQUM5RDs7Ozs7Ozs7OztBQVVBLElBQWEsTUFBc0IsNkJBQWEsZ0JBQzFDLGFBQ0EsTUFBTSxPQUFPLENBQUMsR0FFaEIsU0FBUyxvQkFBb0I7Q0FBRSxHQUFHO0NBQUssR0FBRztDQUFLLEdBQUc7Q0FBSyxHQUFHO0NBQUssR0FBRztDQUFLLEdBQUc7QUFBSSxDQUFDLEdBQUcsV0FBVyxNQUFNO0NBRy9GLEtBQUssT0FBTyxDQUFDO0NBQ2IsSUFBSSxFQUFFLFNBQVMsTUFBTSxHQUNqQixNQUFNLElBQUksVUFBVSxrQ0FBa0MsRUFBRSxPQUFPLEVBQUU7Q0FDckUsT0FBTztBQUNYLENBQUMsQ0FBQyxDQUFDIn0=