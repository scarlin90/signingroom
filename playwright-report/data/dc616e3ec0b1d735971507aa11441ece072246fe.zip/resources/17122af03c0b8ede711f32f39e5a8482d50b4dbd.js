//#region node_modules/tslib/tslib.es6.mjs
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var extendStatics = function(d, b) {
	extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
		d.__proto__ = b;
	} || function(d, b) {
		for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
	};
	return extendStatics(d, b);
};
function __extends(d, b) {
	if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
	extendStatics(d, b);
	function __() {
		this.constructor = d;
	}
	d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
function __awaiter(thisArg, _arguments, P, generator) {
	function adopt(value) {
		return value instanceof P ? value : new P(function(resolve) {
			resolve(value);
		});
	}
	return new (P || (P = Promise))(function(resolve, reject) {
		function fulfilled(value) {
			try {
				step(generator.next(value));
			} catch (e) {
				reject(e);
			}
		}
		function rejected(value) {
			try {
				step(generator["throw"](value));
			} catch (e) {
				reject(e);
			}
		}
		function step(result) {
			result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
		}
		step((generator = generator.apply(thisArg, _arguments || [])).next());
	});
}
function __generator(thisArg, body) {
	var _ = {
		label: 0,
		sent: function() {
			if (t[0] & 1) throw t[1];
			return t[1];
		},
		trys: [],
		ops: []
	}, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
	return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
		return this;
	}), g;
	function verb(n) {
		return function(v) {
			return step([n, v]);
		};
	}
	function step(op) {
		if (f) throw new TypeError("Generator is already executing.");
		while (g && (g = 0, op[0] && (_ = 0)), _) try {
			if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
			if (y = 0, t) op = [op[0] & 2, t.value];
			switch (op[0]) {
				case 0:
				case 1:
					t = op;
					break;
				case 4:
					_.label++;
					return {
						value: op[1],
						done: false
					};
				case 5:
					_.label++;
					y = op[1];
					op = [0];
					continue;
				case 7:
					op = _.ops.pop();
					_.trys.pop();
					continue;
				default:
					if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
						_ = 0;
						continue;
					}
					if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
						_.label = op[1];
						break;
					}
					if (op[0] === 6 && _.label < t[1]) {
						_.label = t[1];
						t = op;
						break;
					}
					if (t && _.label < t[2]) {
						_.label = t[2];
						_.ops.push(op);
						break;
					}
					if (t[2]) _.ops.pop();
					_.trys.pop();
					continue;
			}
			op = body.call(thisArg, _);
		} catch (e) {
			op = [6, e];
			y = 0;
		} finally {
			f = t = 0;
		}
		if (op[0] & 5) throw op[1];
		return {
			value: op[0] ? op[1] : void 0,
			done: true
		};
	}
}
function __values(o) {
	var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
	if (m) return m.call(o);
	if (o && typeof o.length === "number") return { next: function() {
		if (o && i >= o.length) o = void 0;
		return {
			value: o && o[i++],
			done: !o
		};
	} };
	throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
	var m = typeof Symbol === "function" && o[Symbol.iterator];
	if (!m) return o;
	var i = m.call(o), r, ar = [], e;
	try {
		while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
	} catch (error) {
		e = { error };
	} finally {
		try {
			if (r && !r.done && (m = i["return"])) m.call(i);
		} finally {
			if (e) throw e.error;
		}
	}
	return ar;
}
function __spreadArray(to, from, pack) {
	if (pack || arguments.length === 2) {
		for (var i = 0, l = from.length, ar; i < l; i++) if (ar || !(i in from)) {
			if (!ar) ar = Array.prototype.slice.call(from, 0, i);
			ar[i] = from[i];
		}
	}
	return to.concat(ar || Array.prototype.slice.call(from));
}
function __await(v) {
	return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
	if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
	var g = generator.apply(thisArg, _arguments || []), i, q = [];
	return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
		return this;
	}, i;
	function awaitReturn(f) {
		return function(v) {
			return Promise.resolve(v).then(f, reject);
		};
	}
	function verb(n, f) {
		if (g[n]) {
			i[n] = function(v) {
				return new Promise(function(a, b) {
					q.push([
						n,
						v,
						a,
						b
					]) > 1 || resume(n, v);
				});
			};
			if (f) i[n] = f(i[n]);
		}
	}
	function resume(n, v) {
		try {
			step(g[n](v));
		} catch (e) {
			settle(q[0][3], e);
		}
	}
	function step(r) {
		r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
	}
	function fulfill(value) {
		resume("next", value);
	}
	function reject(value) {
		resume("throw", value);
	}
	function settle(f, v) {
		if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
	}
}
function __asyncValues(o) {
	if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
	var m = o[Symbol.asyncIterator], i;
	return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
		return this;
	}, i);
	function verb(n) {
		i[n] = o[n] && function(v) {
			return new Promise(function(resolve, reject) {
				v = o[n](v), settle(resolve, reject, v.done, v.value);
			});
		};
	}
	function settle(resolve, reject, d, v) {
		Promise.resolve(v).then(function(v) {
			resolve({
				value: v,
				done: d
			});
		}, reject);
	}
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isFunction.js
function isFunction(value) {
	return typeof value === "function";
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/createErrorClass.js
function createErrorClass(createImpl) {
	var _super = function(instance) {
		Error.call(instance);
		instance.stack = (/* @__PURE__ */ new Error()).stack;
	};
	var ctorFunc = createImpl(_super);
	ctorFunc.prototype = Object.create(Error.prototype);
	ctorFunc.prototype.constructor = ctorFunc;
	return ctorFunc;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/UnsubscriptionError.js
var UnsubscriptionError = createErrorClass(function(_super) {
	return function UnsubscriptionErrorImpl(errors) {
		_super(this);
		this.message = errors ? errors.length + " errors occurred during unsubscription:\n" + errors.map(function(err, i) {
			return i + 1 + ") " + err.toString();
		}).join("\n  ") : "";
		this.name = "UnsubscriptionError";
		this.errors = errors;
	};
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/arrRemove.js
function arrRemove(arr, item) {
	if (arr) {
		var index = arr.indexOf(item);
		0 <= index && arr.splice(index, 1);
	}
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/Subscription.js
var Subscription = function() {
	function Subscription(initialTeardown) {
		this.initialTeardown = initialTeardown;
		this.closed = false;
		this._parentage = null;
		this._finalizers = null;
	}
	Subscription.prototype.unsubscribe = function() {
		var e_1, _a, e_2, _b;
		var errors;
		if (!this.closed) {
			this.closed = true;
			var _parentage = this._parentage;
			if (_parentage) {
				this._parentage = null;
				if (Array.isArray(_parentage)) try {
					for (var _parentage_1 = __values(_parentage), _parentage_1_1 = _parentage_1.next(); !_parentage_1_1.done; _parentage_1_1 = _parentage_1.next()) _parentage_1_1.value.remove(this);
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (_parentage_1_1 && !_parentage_1_1.done && (_a = _parentage_1.return)) _a.call(_parentage_1);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
				else _parentage.remove(this);
			}
			var initialFinalizer = this.initialTeardown;
			if (isFunction(initialFinalizer)) try {
				initialFinalizer();
			} catch (e) {
				errors = e instanceof UnsubscriptionError ? e.errors : [e];
			}
			var _finalizers = this._finalizers;
			if (_finalizers) {
				this._finalizers = null;
				try {
					for (var _finalizers_1 = __values(_finalizers), _finalizers_1_1 = _finalizers_1.next(); !_finalizers_1_1.done; _finalizers_1_1 = _finalizers_1.next()) {
						var finalizer = _finalizers_1_1.value;
						try {
							execFinalizer(finalizer);
						} catch (err) {
							errors = errors !== null && errors !== void 0 ? errors : [];
							if (err instanceof UnsubscriptionError) errors = __spreadArray(__spreadArray([], __read(errors)), __read(err.errors));
							else errors.push(err);
						}
					}
				} catch (e_2_1) {
					e_2 = { error: e_2_1 };
				} finally {
					try {
						if (_finalizers_1_1 && !_finalizers_1_1.done && (_b = _finalizers_1.return)) _b.call(_finalizers_1);
					} finally {
						if (e_2) throw e_2.error;
					}
				}
			}
			if (errors) throw new UnsubscriptionError(errors);
		}
	};
	Subscription.prototype.add = function(teardown) {
		var _a;
		if (teardown && teardown !== this) if (this.closed) execFinalizer(teardown);
		else {
			if (teardown instanceof Subscription) {
				if (teardown.closed || teardown._hasParent(this)) return;
				teardown._addParent(this);
			}
			(this._finalizers = (_a = this._finalizers) !== null && _a !== void 0 ? _a : []).push(teardown);
		}
	};
	Subscription.prototype._hasParent = function(parent) {
		var _parentage = this._parentage;
		return _parentage === parent || Array.isArray(_parentage) && _parentage.includes(parent);
	};
	Subscription.prototype._addParent = function(parent) {
		var _parentage = this._parentage;
		this._parentage = Array.isArray(_parentage) ? (_parentage.push(parent), _parentage) : _parentage ? [_parentage, parent] : parent;
	};
	Subscription.prototype._removeParent = function(parent) {
		var _parentage = this._parentage;
		if (_parentage === parent) this._parentage = null;
		else if (Array.isArray(_parentage)) arrRemove(_parentage, parent);
	};
	Subscription.prototype.remove = function(teardown) {
		var _finalizers = this._finalizers;
		_finalizers && arrRemove(_finalizers, teardown);
		if (teardown instanceof Subscription) teardown._removeParent(this);
	};
	Subscription.EMPTY = (function() {
		var empty = new Subscription();
		empty.closed = true;
		return empty;
	})();
	return Subscription;
}();
var EMPTY_SUBSCRIPTION = Subscription.EMPTY;
function isSubscription(value) {
	return value instanceof Subscription || value && "closed" in value && isFunction(value.remove) && isFunction(value.add) && isFunction(value.unsubscribe);
}
function execFinalizer(finalizer) {
	if (isFunction(finalizer)) finalizer();
	else finalizer.unsubscribe();
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/config.js
var config = {
	onUnhandledError: null,
	onStoppedNotification: null,
	Promise: void 0,
	useDeprecatedSynchronousErrorHandling: false,
	useDeprecatedNextContext: false
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/timeoutProvider.js
var timeoutProvider = {
	setTimeout: function(handler, timeout) {
		var args = [];
		for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
		var delegate = timeoutProvider.delegate;
		if (delegate === null || delegate === void 0 ? void 0 : delegate.setTimeout) return delegate.setTimeout.apply(delegate, __spreadArray([handler, timeout], __read(args)));
		return setTimeout.apply(void 0, __spreadArray([handler, timeout], __read(args)));
	},
	clearTimeout: function(handle) {
		var delegate = timeoutProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearTimeout) || clearTimeout)(handle);
	},
	delegate: void 0
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/reportUnhandledError.js
function reportUnhandledError(err) {
	timeoutProvider.setTimeout(function() {
		var onUnhandledError = config.onUnhandledError;
		if (onUnhandledError) onUnhandledError(err);
		else throw err;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/noop.js
function noop() {}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/NotificationFactories.js
var COMPLETE_NOTIFICATION = (function() {
	return createNotification("C", void 0, void 0);
})();
function errorNotification(error) {
	return createNotification("E", void 0, error);
}
function nextNotification(value) {
	return createNotification("N", value, void 0);
}
function createNotification(kind, value, error) {
	return {
		kind,
		value,
		error
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/errorContext.js
var context = null;
function errorContext(cb) {
	if (config.useDeprecatedSynchronousErrorHandling) {
		var isRoot = !context;
		if (isRoot) context = {
			errorThrown: false,
			error: null
		};
		cb();
		if (isRoot) {
			var _a = context, errorThrown = _a.errorThrown, error = _a.error;
			context = null;
			if (errorThrown) throw error;
		}
	} else cb();
}
function captureError(err) {
	if (config.useDeprecatedSynchronousErrorHandling && context) {
		context.errorThrown = true;
		context.error = err;
	}
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/Subscriber.js
var Subscriber = function(_super) {
	__extends(Subscriber, _super);
	function Subscriber(destination) {
		var _this = _super.call(this) || this;
		_this.isStopped = false;
		if (destination) {
			_this.destination = destination;
			if (isSubscription(destination)) destination.add(_this);
		} else _this.destination = EMPTY_OBSERVER;
		return _this;
	}
	Subscriber.create = function(next, error, complete) {
		return new SafeSubscriber(next, error, complete);
	};
	Subscriber.prototype.next = function(value) {
		if (this.isStopped) handleStoppedNotification(nextNotification(value), this);
		else this._next(value);
	};
	Subscriber.prototype.error = function(err) {
		if (this.isStopped) handleStoppedNotification(errorNotification(err), this);
		else {
			this.isStopped = true;
			this._error(err);
		}
	};
	Subscriber.prototype.complete = function() {
		if (this.isStopped) handleStoppedNotification(COMPLETE_NOTIFICATION, this);
		else {
			this.isStopped = true;
			this._complete();
		}
	};
	Subscriber.prototype.unsubscribe = function() {
		if (!this.closed) {
			this.isStopped = true;
			_super.prototype.unsubscribe.call(this);
			this.destination = null;
		}
	};
	Subscriber.prototype._next = function(value) {
		this.destination.next(value);
	};
	Subscriber.prototype._error = function(err) {
		try {
			this.destination.error(err);
		} finally {
			this.unsubscribe();
		}
	};
	Subscriber.prototype._complete = function() {
		try {
			this.destination.complete();
		} finally {
			this.unsubscribe();
		}
	};
	return Subscriber;
}(Subscription);
var _bind = Function.prototype.bind;
function bind(fn, thisArg) {
	return _bind.call(fn, thisArg);
}
var ConsumerObserver = function() {
	function ConsumerObserver(partialObserver) {
		this.partialObserver = partialObserver;
	}
	ConsumerObserver.prototype.next = function(value) {
		var partialObserver = this.partialObserver;
		if (partialObserver.next) try {
			partialObserver.next(value);
		} catch (error) {
			handleUnhandledError(error);
		}
	};
	ConsumerObserver.prototype.error = function(err) {
		var partialObserver = this.partialObserver;
		if (partialObserver.error) try {
			partialObserver.error(err);
		} catch (error) {
			handleUnhandledError(error);
		}
		else handleUnhandledError(err);
	};
	ConsumerObserver.prototype.complete = function() {
		var partialObserver = this.partialObserver;
		if (partialObserver.complete) try {
			partialObserver.complete();
		} catch (error) {
			handleUnhandledError(error);
		}
	};
	return ConsumerObserver;
}();
var SafeSubscriber = function(_super) {
	__extends(SafeSubscriber, _super);
	function SafeSubscriber(observerOrNext, error, complete) {
		var _this = _super.call(this) || this;
		var partialObserver;
		if (isFunction(observerOrNext) || !observerOrNext) partialObserver = {
			next: observerOrNext !== null && observerOrNext !== void 0 ? observerOrNext : void 0,
			error: error !== null && error !== void 0 ? error : void 0,
			complete: complete !== null && complete !== void 0 ? complete : void 0
		};
		else {
			var context_1;
			if (_this && config.useDeprecatedNextContext) {
				context_1 = Object.create(observerOrNext);
				context_1.unsubscribe = function() {
					return _this.unsubscribe();
				};
				partialObserver = {
					next: observerOrNext.next && bind(observerOrNext.next, context_1),
					error: observerOrNext.error && bind(observerOrNext.error, context_1),
					complete: observerOrNext.complete && bind(observerOrNext.complete, context_1)
				};
			} else partialObserver = observerOrNext;
		}
		_this.destination = new ConsumerObserver(partialObserver);
		return _this;
	}
	return SafeSubscriber;
}(Subscriber);
function handleUnhandledError(error) {
	if (config.useDeprecatedSynchronousErrorHandling) captureError(error);
	else reportUnhandledError(error);
}
function defaultErrorHandler(err) {
	throw err;
}
function handleStoppedNotification(notification, subscriber) {
	var onStoppedNotification = config.onStoppedNotification;
	onStoppedNotification && timeoutProvider.setTimeout(function() {
		return onStoppedNotification(notification, subscriber);
	});
}
var EMPTY_OBSERVER = {
	closed: true,
	next: noop,
	error: defaultErrorHandler,
	complete: noop
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/symbol/observable.js
var observable = (function() {
	return typeof Symbol === "function" && Symbol.observable || "@@observable";
})();
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/identity.js
function identity(x) {
	return x;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/pipe.js
function pipe() {
	var fns = [];
	for (var _i = 0; _i < arguments.length; _i++) fns[_i] = arguments[_i];
	return pipeFromArray(fns);
}
function pipeFromArray(fns) {
	if (fns.length === 0) return identity;
	if (fns.length === 1) return fns[0];
	return function piped(input) {
		return fns.reduce(function(prev, fn) {
			return fn(prev);
		}, input);
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/Observable.js
var Observable = function() {
	function Observable(subscribe) {
		if (subscribe) this._subscribe = subscribe;
	}
	Observable.prototype.lift = function(operator) {
		var observable = new Observable();
		observable.source = this;
		observable.operator = operator;
		return observable;
	};
	Observable.prototype.subscribe = function(observerOrNext, error, complete) {
		var _this = this;
		var subscriber = isSubscriber(observerOrNext) ? observerOrNext : new SafeSubscriber(observerOrNext, error, complete);
		errorContext(function() {
			var _a = _this, operator = _a.operator, source = _a.source;
			subscriber.add(operator ? operator.call(subscriber, source) : source ? _this._subscribe(subscriber) : _this._trySubscribe(subscriber));
		});
		return subscriber;
	};
	Observable.prototype._trySubscribe = function(sink) {
		try {
			return this._subscribe(sink);
		} catch (err) {
			sink.error(err);
		}
	};
	Observable.prototype.forEach = function(next, promiseCtor) {
		var _this = this;
		promiseCtor = getPromiseCtor(promiseCtor);
		return new promiseCtor(function(resolve, reject) {
			var subscriber = new SafeSubscriber({
				next: function(value) {
					try {
						next(value);
					} catch (err) {
						reject(err);
						subscriber.unsubscribe();
					}
				},
				error: reject,
				complete: resolve
			});
			_this.subscribe(subscriber);
		});
	};
	Observable.prototype._subscribe = function(subscriber) {
		var _a;
		return (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber);
	};
	Observable.prototype[observable] = function() {
		return this;
	};
	Observable.prototype.pipe = function() {
		var operations = [];
		for (var _i = 0; _i < arguments.length; _i++) operations[_i] = arguments[_i];
		return pipeFromArray(operations)(this);
	};
	Observable.prototype.toPromise = function(promiseCtor) {
		var _this = this;
		promiseCtor = getPromiseCtor(promiseCtor);
		return new promiseCtor(function(resolve, reject) {
			var value;
			_this.subscribe(function(x) {
				return value = x;
			}, function(err) {
				return reject(err);
			}, function() {
				return resolve(value);
			});
		});
	};
	Observable.create = function(subscribe) {
		return new Observable(subscribe);
	};
	return Observable;
}();
function getPromiseCtor(promiseCtor) {
	var _a;
	return (_a = promiseCtor !== null && promiseCtor !== void 0 ? promiseCtor : config.Promise) !== null && _a !== void 0 ? _a : Promise;
}
function isObserver(value) {
	return value && isFunction(value.next) && isFunction(value.error) && isFunction(value.complete);
}
function isSubscriber(value) {
	return value && value instanceof Subscriber || isObserver(value) && isSubscription(value);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/lift.js
function hasLift(source) {
	return isFunction(source === null || source === void 0 ? void 0 : source.lift);
}
function operate(init) {
	return function(source) {
		if (hasLift(source)) return source.lift(function(liftedSource) {
			try {
				return init(liftedSource, this);
			} catch (err) {
				this.error(err);
			}
		});
		throw new TypeError("Unable to lift unknown Observable type");
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/OperatorSubscriber.js
function createOperatorSubscriber(destination, onNext, onComplete, onError, onFinalize) {
	return new OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize);
}
var OperatorSubscriber = function(_super) {
	__extends(OperatorSubscriber, _super);
	function OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize, shouldUnsubscribe) {
		var _this = _super.call(this, destination) || this;
		_this.onFinalize = onFinalize;
		_this.shouldUnsubscribe = shouldUnsubscribe;
		_this._next = onNext ? function(value) {
			try {
				onNext(value);
			} catch (err) {
				destination.error(err);
			}
		} : _super.prototype._next;
		_this._error = onError ? function(err) {
			try {
				onError(err);
			} catch (err) {
				destination.error(err);
			} finally {
				this.unsubscribe();
			}
		} : _super.prototype._error;
		_this._complete = onComplete ? function() {
			try {
				onComplete();
			} catch (err) {
				destination.error(err);
			} finally {
				this.unsubscribe();
			}
		} : _super.prototype._complete;
		return _this;
	}
	OperatorSubscriber.prototype.unsubscribe = function() {
		var _a;
		if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
			var closed_1 = this.closed;
			_super.prototype.unsubscribe.call(this);
			!closed_1 && ((_a = this.onFinalize) === null || _a === void 0 || _a.call(this));
		}
	};
	return OperatorSubscriber;
}(Subscriber);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/refCount.js
function refCount() {
	return operate(function(source, subscriber) {
		var connection = null;
		source._refCount++;
		var refCounter = createOperatorSubscriber(subscriber, void 0, void 0, void 0, function() {
			if (!source || source._refCount <= 0 || 0 < --source._refCount) {
				connection = null;
				return;
			}
			var sharedConnection = source._connection;
			var conn = connection;
			connection = null;
			if (sharedConnection && (!conn || sharedConnection === conn)) sharedConnection.unsubscribe();
			subscriber.unsubscribe();
		});
		source.subscribe(refCounter);
		if (!refCounter.closed) connection = source.connect();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/ConnectableObservable.js
var ConnectableObservable = function(_super) {
	__extends(ConnectableObservable, _super);
	function ConnectableObservable(source, subjectFactory) {
		var _this = _super.call(this) || this;
		_this.source = source;
		_this.subjectFactory = subjectFactory;
		_this._subject = null;
		_this._refCount = 0;
		_this._connection = null;
		if (hasLift(source)) _this.lift = source.lift;
		return _this;
	}
	ConnectableObservable.prototype._subscribe = function(subscriber) {
		return this.getSubject().subscribe(subscriber);
	};
	ConnectableObservable.prototype.getSubject = function() {
		var subject = this._subject;
		if (!subject || subject.isStopped) this._subject = this.subjectFactory();
		return this._subject;
	};
	ConnectableObservable.prototype._teardown = function() {
		this._refCount = 0;
		var _connection = this._connection;
		this._subject = this._connection = null;
		_connection === null || _connection === void 0 || _connection.unsubscribe();
	};
	ConnectableObservable.prototype.connect = function() {
		var _this = this;
		var connection = this._connection;
		if (!connection) {
			connection = this._connection = new Subscription();
			var subject_1 = this.getSubject();
			connection.add(this.source.subscribe(createOperatorSubscriber(subject_1, void 0, function() {
				_this._teardown();
				subject_1.complete();
			}, function(err) {
				_this._teardown();
				subject_1.error(err);
			}, function() {
				return _this._teardown();
			})));
			if (connection.closed) {
				this._connection = null;
				connection = Subscription.EMPTY;
			}
		}
		return connection;
	};
	ConnectableObservable.prototype.refCount = function() {
		return refCount()(this);
	};
	return ConnectableObservable;
}(Observable);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/ObjectUnsubscribedError.js
var ObjectUnsubscribedError = createErrorClass(function(_super) {
	return function ObjectUnsubscribedErrorImpl() {
		_super(this);
		this.name = "ObjectUnsubscribedError";
		this.message = "object unsubscribed";
	};
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/Subject.js
var Subject = function(_super) {
	__extends(Subject, _super);
	function Subject() {
		var _this = _super.call(this) || this;
		_this.closed = false;
		_this.currentObservers = null;
		_this.observers = [];
		_this.isStopped = false;
		_this.hasError = false;
		_this.thrownError = null;
		return _this;
	}
	Subject.prototype.lift = function(operator) {
		var subject = new AnonymousSubject(this, this);
		subject.operator = operator;
		return subject;
	};
	Subject.prototype._throwIfClosed = function() {
		if (this.closed) throw new ObjectUnsubscribedError();
	};
	Subject.prototype.next = function(value) {
		var _this = this;
		errorContext(function() {
			var e_1, _a;
			_this._throwIfClosed();
			if (!_this.isStopped) {
				if (!_this.currentObservers) _this.currentObservers = Array.from(_this.observers);
				try {
					for (var _b = __values(_this.currentObservers), _c = _b.next(); !_c.done; _c = _b.next()) _c.value.next(value);
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
			}
		});
	};
	Subject.prototype.error = function(err) {
		var _this = this;
		errorContext(function() {
			_this._throwIfClosed();
			if (!_this.isStopped) {
				_this.hasError = _this.isStopped = true;
				_this.thrownError = err;
				var observers = _this.observers;
				while (observers.length) observers.shift().error(err);
			}
		});
	};
	Subject.prototype.complete = function() {
		var _this = this;
		errorContext(function() {
			_this._throwIfClosed();
			if (!_this.isStopped) {
				_this.isStopped = true;
				var observers = _this.observers;
				while (observers.length) observers.shift().complete();
			}
		});
	};
	Subject.prototype.unsubscribe = function() {
		this.isStopped = this.closed = true;
		this.observers = this.currentObservers = null;
	};
	Object.defineProperty(Subject.prototype, "observed", {
		get: function() {
			var _a;
			return ((_a = this.observers) === null || _a === void 0 ? void 0 : _a.length) > 0;
		},
		enumerable: false,
		configurable: true
	});
	Subject.prototype._trySubscribe = function(subscriber) {
		this._throwIfClosed();
		return _super.prototype._trySubscribe.call(this, subscriber);
	};
	Subject.prototype._subscribe = function(subscriber) {
		this._throwIfClosed();
		this._checkFinalizedStatuses(subscriber);
		return this._innerSubscribe(subscriber);
	};
	Subject.prototype._innerSubscribe = function(subscriber) {
		var _this = this;
		var _a = this, hasError = _a.hasError, isStopped = _a.isStopped, observers = _a.observers;
		if (hasError || isStopped) return EMPTY_SUBSCRIPTION;
		this.currentObservers = null;
		observers.push(subscriber);
		return new Subscription(function() {
			_this.currentObservers = null;
			arrRemove(observers, subscriber);
		});
	};
	Subject.prototype._checkFinalizedStatuses = function(subscriber) {
		var _a = this, hasError = _a.hasError, thrownError = _a.thrownError, isStopped = _a.isStopped;
		if (hasError) subscriber.error(thrownError);
		else if (isStopped) subscriber.complete();
	};
	Subject.prototype.asObservable = function() {
		var observable = new Observable();
		observable.source = this;
		return observable;
	};
	Subject.create = function(destination, source) {
		return new AnonymousSubject(destination, source);
	};
	return Subject;
}(Observable);
var AnonymousSubject = function(_super) {
	__extends(AnonymousSubject, _super);
	function AnonymousSubject(destination, source) {
		var _this = _super.call(this) || this;
		_this.destination = destination;
		_this.source = source;
		return _this;
	}
	AnonymousSubject.prototype.next = function(value) {
		var _a, _b;
		(_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.next) === null || _b === void 0 || _b.call(_a, value);
	};
	AnonymousSubject.prototype.error = function(err) {
		var _a, _b;
		(_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.error) === null || _b === void 0 || _b.call(_a, err);
	};
	AnonymousSubject.prototype.complete = function() {
		var _a, _b;
		(_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.complete) === null || _b === void 0 || _b.call(_a);
	};
	AnonymousSubject.prototype._subscribe = function(subscriber) {
		var _a, _b;
		return (_b = (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber)) !== null && _b !== void 0 ? _b : EMPTY_SUBSCRIPTION;
	};
	return AnonymousSubject;
}(Subject);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/BehaviorSubject.js
var BehaviorSubject = function(_super) {
	__extends(BehaviorSubject, _super);
	function BehaviorSubject(_value) {
		var _this = _super.call(this) || this;
		_this._value = _value;
		return _this;
	}
	Object.defineProperty(BehaviorSubject.prototype, "value", {
		get: function() {
			return this.getValue();
		},
		enumerable: false,
		configurable: true
	});
	BehaviorSubject.prototype._subscribe = function(subscriber) {
		var subscription = _super.prototype._subscribe.call(this, subscriber);
		!subscription.closed && subscriber.next(this._value);
		return subscription;
	};
	BehaviorSubject.prototype.getValue = function() {
		var _a = this, hasError = _a.hasError, thrownError = _a.thrownError, _value = _a._value;
		if (hasError) throw thrownError;
		this._throwIfClosed();
		return _value;
	};
	BehaviorSubject.prototype.next = function(value) {
		_super.prototype.next.call(this, this._value = value);
	};
	return BehaviorSubject;
}(Subject);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/dateTimestampProvider.js
var dateTimestampProvider = {
	now: function() {
		return (dateTimestampProvider.delegate || Date).now();
	},
	delegate: void 0
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/ReplaySubject.js
var ReplaySubject = function(_super) {
	__extends(ReplaySubject, _super);
	function ReplaySubject(_bufferSize, _windowTime, _timestampProvider) {
		if (_bufferSize === void 0) _bufferSize = Infinity;
		if (_windowTime === void 0) _windowTime = Infinity;
		if (_timestampProvider === void 0) _timestampProvider = dateTimestampProvider;
		var _this = _super.call(this) || this;
		_this._bufferSize = _bufferSize;
		_this._windowTime = _windowTime;
		_this._timestampProvider = _timestampProvider;
		_this._buffer = [];
		_this._infiniteTimeWindow = true;
		_this._infiniteTimeWindow = _windowTime === Infinity;
		_this._bufferSize = Math.max(1, _bufferSize);
		_this._windowTime = Math.max(1, _windowTime);
		return _this;
	}
	ReplaySubject.prototype.next = function(value) {
		var _a = this, isStopped = _a.isStopped, _buffer = _a._buffer, _infiniteTimeWindow = _a._infiniteTimeWindow, _timestampProvider = _a._timestampProvider, _windowTime = _a._windowTime;
		if (!isStopped) {
			_buffer.push(value);
			!_infiniteTimeWindow && _buffer.push(_timestampProvider.now() + _windowTime);
		}
		this._trimBuffer();
		_super.prototype.next.call(this, value);
	};
	ReplaySubject.prototype._subscribe = function(subscriber) {
		this._throwIfClosed();
		this._trimBuffer();
		var subscription = this._innerSubscribe(subscriber);
		var _a = this, _infiniteTimeWindow = _a._infiniteTimeWindow;
		var copy = _a._buffer.slice();
		for (var i = 0; i < copy.length && !subscriber.closed; i += _infiniteTimeWindow ? 1 : 2) subscriber.next(copy[i]);
		this._checkFinalizedStatuses(subscriber);
		return subscription;
	};
	ReplaySubject.prototype._trimBuffer = function() {
		var _a = this, _bufferSize = _a._bufferSize, _timestampProvider = _a._timestampProvider, _buffer = _a._buffer, _infiniteTimeWindow = _a._infiniteTimeWindow;
		var adjustedBufferSize = (_infiniteTimeWindow ? 1 : 2) * _bufferSize;
		_bufferSize < Infinity && adjustedBufferSize < _buffer.length && _buffer.splice(0, _buffer.length - adjustedBufferSize);
		if (!_infiniteTimeWindow) {
			var now = _timestampProvider.now();
			var last = 0;
			for (var i = 1; i < _buffer.length && _buffer[i] <= now; i += 2) last = i;
			last && _buffer.splice(0, last + 1);
		}
	};
	return ReplaySubject;
}(Subject);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/AsyncSubject.js
var AsyncSubject = function(_super) {
	__extends(AsyncSubject, _super);
	function AsyncSubject() {
		var _this = _super !== null && _super.apply(this, arguments) || this;
		_this._value = null;
		_this._hasValue = false;
		_this._isComplete = false;
		return _this;
	}
	AsyncSubject.prototype._checkFinalizedStatuses = function(subscriber) {
		var _a = this, hasError = _a.hasError, _hasValue = _a._hasValue, _value = _a._value, thrownError = _a.thrownError, isStopped = _a.isStopped, _isComplete = _a._isComplete;
		if (hasError) subscriber.error(thrownError);
		else if (isStopped || _isComplete) {
			_hasValue && subscriber.next(_value);
			subscriber.complete();
		}
	};
	AsyncSubject.prototype.next = function(value) {
		if (!this.isStopped) {
			this._value = value;
			this._hasValue = true;
		}
	};
	AsyncSubject.prototype.complete = function() {
		var _a = this, _hasValue = _a._hasValue, _value = _a._value;
		if (!_a._isComplete) {
			this._isComplete = true;
			_hasValue && _super.prototype.next.call(this, _value);
			_super.prototype.complete.call(this);
		}
	};
	return AsyncSubject;
}(Subject);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/Action.js
var Action = function(_super) {
	__extends(Action, _super);
	function Action(scheduler, work) {
		return _super.call(this) || this;
	}
	Action.prototype.schedule = function(state, delay) {
		if (delay === void 0) delay = 0;
		return this;
	};
	return Action;
}(Subscription);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/intervalProvider.js
var intervalProvider = {
	setInterval: function(handler, timeout) {
		var args = [];
		for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
		var delegate = intervalProvider.delegate;
		if (delegate === null || delegate === void 0 ? void 0 : delegate.setInterval) return delegate.setInterval.apply(delegate, __spreadArray([handler, timeout], __read(args)));
		return setInterval.apply(void 0, __spreadArray([handler, timeout], __read(args)));
	},
	clearInterval: function(handle) {
		var delegate = intervalProvider.delegate;
		return ((delegate === null || delegate === void 0 ? void 0 : delegate.clearInterval) || clearInterval)(handle);
	},
	delegate: void 0
};
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/AsyncAction.js
var AsyncAction = function(_super) {
	__extends(AsyncAction, _super);
	function AsyncAction(scheduler, work) {
		var _this = _super.call(this, scheduler, work) || this;
		_this.scheduler = scheduler;
		_this.work = work;
		_this.pending = false;
		return _this;
	}
	AsyncAction.prototype.schedule = function(state, delay) {
		var _a;
		if (delay === void 0) delay = 0;
		if (this.closed) return this;
		this.state = state;
		var id = this.id;
		var scheduler = this.scheduler;
		if (id != null) this.id = this.recycleAsyncId(scheduler, id, delay);
		this.pending = true;
		this.delay = delay;
		this.id = (_a = this.id) !== null && _a !== void 0 ? _a : this.requestAsyncId(scheduler, this.id, delay);
		return this;
	};
	AsyncAction.prototype.requestAsyncId = function(scheduler, _id, delay) {
		if (delay === void 0) delay = 0;
		return intervalProvider.setInterval(scheduler.flush.bind(scheduler, this), delay);
	};
	AsyncAction.prototype.recycleAsyncId = function(_scheduler, id, delay) {
		if (delay === void 0) delay = 0;
		if (delay != null && this.delay === delay && this.pending === false) return id;
		if (id != null) intervalProvider.clearInterval(id);
	};
	AsyncAction.prototype.execute = function(state, delay) {
		if (this.closed) return /* @__PURE__ */ new Error("executing a cancelled action");
		this.pending = false;
		var error = this._execute(state, delay);
		if (error) return error;
		else if (this.pending === false && this.id != null) this.id = this.recycleAsyncId(this.scheduler, this.id, null);
	};
	AsyncAction.prototype._execute = function(state, _delay) {
		var errored = false;
		var errorValue;
		try {
			this.work(state);
		} catch (e) {
			errored = true;
			errorValue = e ? e : /* @__PURE__ */ new Error("Scheduled action threw falsy error");
		}
		if (errored) {
			this.unsubscribe();
			return errorValue;
		}
	};
	AsyncAction.prototype.unsubscribe = function() {
		if (!this.closed) {
			var _a = this, id = _a.id, scheduler = _a.scheduler;
			var actions = scheduler.actions;
			this.work = this.state = this.scheduler = null;
			this.pending = false;
			arrRemove(actions, this);
			if (id != null) this.id = this.recycleAsyncId(scheduler, id, null);
			this.delay = null;
			_super.prototype.unsubscribe.call(this);
		}
	};
	return AsyncAction;
}(Action);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/Scheduler.js
var Scheduler = function() {
	function Scheduler(schedulerActionCtor, now) {
		if (now === void 0) now = Scheduler.now;
		this.schedulerActionCtor = schedulerActionCtor;
		this.now = now;
	}
	Scheduler.prototype.schedule = function(work, delay, state) {
		if (delay === void 0) delay = 0;
		return new this.schedulerActionCtor(this, work).schedule(state, delay);
	};
	Scheduler.now = dateTimestampProvider.now;
	return Scheduler;
}();
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/AsyncScheduler.js
var AsyncScheduler = function(_super) {
	__extends(AsyncScheduler, _super);
	function AsyncScheduler(SchedulerAction, now) {
		if (now === void 0) now = Scheduler.now;
		var _this = _super.call(this, SchedulerAction, now) || this;
		_this.actions = [];
		_this._active = false;
		return _this;
	}
	AsyncScheduler.prototype.flush = function(action) {
		var actions = this.actions;
		if (this._active) {
			actions.push(action);
			return;
		}
		var error;
		this._active = true;
		do
			if (error = action.execute(action.state, action.delay)) break;
		while (action = actions.shift());
		this._active = false;
		if (error) {
			while (action = actions.shift()) action.unsubscribe();
			throw error;
		}
	};
	return AsyncScheduler;
}(Scheduler);
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduler/async.js
var asyncScheduler = new AsyncScheduler(AsyncAction);
var async = asyncScheduler;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/empty.js
var EMPTY = new Observable(function(subscriber) {
	return subscriber.complete();
});
function empty(scheduler) {
	return scheduler ? emptyScheduled(scheduler) : EMPTY;
}
function emptyScheduled(scheduler) {
	return new Observable(function(subscriber) {
		return scheduler.schedule(function() {
			return subscriber.complete();
		});
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isScheduler.js
function isScheduler(value) {
	return value && isFunction(value.schedule);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/args.js
function last$1(arr) {
	return arr[arr.length - 1];
}
function popResultSelector(args) {
	return isFunction(last$1(args)) ? args.pop() : void 0;
}
function popScheduler(args) {
	return isScheduler(last$1(args)) ? args.pop() : void 0;
}
function popNumber(args, defaultValue) {
	return typeof last$1(args) === "number" ? args.pop() : defaultValue;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isArrayLike.js
var isArrayLike = (function(x) {
	return x && typeof x.length === "number" && typeof x !== "function";
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isPromise.js
function isPromise(value) {
	return isFunction(value === null || value === void 0 ? void 0 : value.then);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isInteropObservable.js
function isInteropObservable(input) {
	return isFunction(input[observable]);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isAsyncIterable.js
function isAsyncIterable(obj) {
	return Symbol.asyncIterator && isFunction(obj === null || obj === void 0 ? void 0 : obj[Symbol.asyncIterator]);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/throwUnobservableError.js
function createInvalidObservableTypeError(input) {
	return /* @__PURE__ */ new TypeError("You provided " + (input !== null && typeof input === "object" ? "an invalid object" : "'" + input + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.");
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/symbol/iterator.js
function getSymbolIterator() {
	if (typeof Symbol !== "function" || !Symbol.iterator) return "@@iterator";
	return Symbol.iterator;
}
var iterator = getSymbolIterator();
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isIterable.js
function isIterable(input) {
	return isFunction(input === null || input === void 0 ? void 0 : input[iterator]);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isReadableStreamLike.js
function readableStreamLikeToAsyncGenerator(readableStream) {
	return __asyncGenerator(this, arguments, function readableStreamLikeToAsyncGenerator_1() {
		var reader, _a, value, done;
		return __generator(this, function(_b) {
			switch (_b.label) {
				case 0:
					reader = readableStream.getReader();
					_b.label = 1;
				case 1:
					_b.trys.push([
						1,
						,
						9,
						10
					]);
					_b.label = 2;
				case 2: return [4, __await(reader.read())];
				case 3:
					_a = _b.sent(), value = _a.value, done = _a.done;
					if (!done) return [3, 5];
					return [4, __await(void 0)];
				case 4: return [2, _b.sent()];
				case 5: return [4, __await(value)];
				case 6: return [4, _b.sent()];
				case 7:
					_b.sent();
					return [3, 2];
				case 8: return [3, 10];
				case 9:
					reader.releaseLock();
					return [7];
				case 10: return [2];
			}
		});
	});
}
function isReadableStreamLike(obj) {
	return isFunction(obj === null || obj === void 0 ? void 0 : obj.getReader);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/innerFrom.js
function innerFrom(input) {
	if (input instanceof Observable) return input;
	if (input != null) {
		if (isInteropObservable(input)) return fromInteropObservable(input);
		if (isArrayLike(input)) return fromArrayLike(input);
		if (isPromise(input)) return fromPromise(input);
		if (isAsyncIterable(input)) return fromAsyncIterable(input);
		if (isIterable(input)) return fromIterable(input);
		if (isReadableStreamLike(input)) return fromReadableStreamLike(input);
	}
	throw createInvalidObservableTypeError(input);
}
function fromInteropObservable(obj) {
	return new Observable(function(subscriber) {
		var obs = obj[observable]();
		if (isFunction(obs.subscribe)) return obs.subscribe(subscriber);
		throw new TypeError("Provided object does not correctly implement Symbol.observable");
	});
}
function fromArrayLike(array) {
	return new Observable(function(subscriber) {
		for (var i = 0; i < array.length && !subscriber.closed; i++) subscriber.next(array[i]);
		subscriber.complete();
	});
}
function fromPromise(promise) {
	return new Observable(function(subscriber) {
		promise.then(function(value) {
			if (!subscriber.closed) {
				subscriber.next(value);
				subscriber.complete();
			}
		}, function(err) {
			return subscriber.error(err);
		}).then(null, reportUnhandledError);
	});
}
function fromIterable(iterable) {
	return new Observable(function(subscriber) {
		var e_1, _a;
		try {
			for (var iterable_1 = __values(iterable), iterable_1_1 = iterable_1.next(); !iterable_1_1.done; iterable_1_1 = iterable_1.next()) {
				var value = iterable_1_1.value;
				subscriber.next(value);
				if (subscriber.closed) return;
			}
		} catch (e_1_1) {
			e_1 = { error: e_1_1 };
		} finally {
			try {
				if (iterable_1_1 && !iterable_1_1.done && (_a = iterable_1.return)) _a.call(iterable_1);
			} finally {
				if (e_1) throw e_1.error;
			}
		}
		subscriber.complete();
	});
}
function fromAsyncIterable(asyncIterable) {
	return new Observable(function(subscriber) {
		process(asyncIterable, subscriber).catch(function(err) {
			return subscriber.error(err);
		});
	});
}
function fromReadableStreamLike(readableStream) {
	return fromAsyncIterable(readableStreamLikeToAsyncGenerator(readableStream));
}
function process(asyncIterable, subscriber) {
	var asyncIterable_1, asyncIterable_1_1;
	var e_2, _a;
	return __awaiter(this, void 0, void 0, function() {
		var value, e_2_1;
		return __generator(this, function(_b) {
			switch (_b.label) {
				case 0:
					_b.trys.push([
						0,
						5,
						6,
						11
					]);
					asyncIterable_1 = __asyncValues(asyncIterable);
					_b.label = 1;
				case 1: return [4, asyncIterable_1.next()];
				case 2:
					if (!(asyncIterable_1_1 = _b.sent(), !asyncIterable_1_1.done)) return [3, 4];
					value = asyncIterable_1_1.value;
					subscriber.next(value);
					if (subscriber.closed) return [2];
					_b.label = 3;
				case 3: return [3, 1];
				case 4: return [3, 11];
				case 5:
					e_2_1 = _b.sent();
					e_2 = { error: e_2_1 };
					return [3, 11];
				case 6:
					_b.trys.push([
						6,
						,
						9,
						10
					]);
					if (!(asyncIterable_1_1 && !asyncIterable_1_1.done && (_a = asyncIterable_1.return))) return [3, 8];
					return [4, _a.call(asyncIterable_1)];
				case 7:
					_b.sent();
					_b.label = 8;
				case 8: return [3, 10];
				case 9:
					if (e_2) throw e_2.error;
					return [7];
				case 10: return [7];
				case 11:
					subscriber.complete();
					return [2];
			}
		});
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/executeSchedule.js
function executeSchedule(parentSubscription, scheduler, work, delay, repeat) {
	if (delay === void 0) delay = 0;
	if (repeat === void 0) repeat = false;
	var scheduleSubscription = scheduler.schedule(function() {
		work();
		if (repeat) parentSubscription.add(this.schedule(null, delay));
		else this.unsubscribe();
	}, delay);
	parentSubscription.add(scheduleSubscription);
	if (!repeat) return scheduleSubscription;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/observeOn.js
function observeOn(scheduler, delay) {
	if (delay === void 0) delay = 0;
	return operate(function(source, subscriber) {
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return executeSchedule(subscriber, scheduler, function() {
				return subscriber.next(value);
			}, delay);
		}, function() {
			return executeSchedule(subscriber, scheduler, function() {
				return subscriber.complete();
			}, delay);
		}, function(err) {
			return executeSchedule(subscriber, scheduler, function() {
				return subscriber.error(err);
			}, delay);
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/subscribeOn.js
function subscribeOn(scheduler, delay) {
	if (delay === void 0) delay = 0;
	return operate(function(source, subscriber) {
		subscriber.add(scheduler.schedule(function() {
			return source.subscribe(subscriber);
		}, delay));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/scheduleObservable.js
function scheduleObservable(input, scheduler) {
	return innerFrom(input).pipe(subscribeOn(scheduler), observeOn(scheduler));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/schedulePromise.js
function schedulePromise(input, scheduler) {
	return innerFrom(input).pipe(subscribeOn(scheduler), observeOn(scheduler));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/scheduleArray.js
function scheduleArray(input, scheduler) {
	return new Observable(function(subscriber) {
		var i = 0;
		return scheduler.schedule(function() {
			if (i === input.length) subscriber.complete();
			else {
				subscriber.next(input[i++]);
				if (!subscriber.closed) this.schedule();
			}
		});
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/scheduleIterable.js
function scheduleIterable(input, scheduler) {
	return new Observable(function(subscriber) {
		var iterator$1;
		executeSchedule(subscriber, scheduler, function() {
			iterator$1 = input[iterator]();
			executeSchedule(subscriber, scheduler, function() {
				var _a;
				var value;
				var done;
				try {
					_a = iterator$1.next(), value = _a.value, done = _a.done;
				} catch (err) {
					subscriber.error(err);
					return;
				}
				if (done) subscriber.complete();
				else subscriber.next(value);
			}, 0, true);
		});
		return function() {
			return isFunction(iterator$1 === null || iterator$1 === void 0 ? void 0 : iterator$1.return) && iterator$1.return();
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/scheduleAsyncIterable.js
function scheduleAsyncIterable(input, scheduler) {
	if (!input) throw new Error("Iterable cannot be null");
	return new Observable(function(subscriber) {
		executeSchedule(subscriber, scheduler, function() {
			var iterator = input[Symbol.asyncIterator]();
			executeSchedule(subscriber, scheduler, function() {
				iterator.next().then(function(result) {
					if (result.done) subscriber.complete();
					else subscriber.next(result.value);
				});
			}, 0, true);
		});
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/scheduleReadableStreamLike.js
function scheduleReadableStreamLike(input, scheduler) {
	return scheduleAsyncIterable(readableStreamLikeToAsyncGenerator(input), scheduler);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/scheduled/scheduled.js
function scheduled(input, scheduler) {
	if (input != null) {
		if (isInteropObservable(input)) return scheduleObservable(input, scheduler);
		if (isArrayLike(input)) return scheduleArray(input, scheduler);
		if (isPromise(input)) return schedulePromise(input, scheduler);
		if (isAsyncIterable(input)) return scheduleAsyncIterable(input, scheduler);
		if (isIterable(input)) return scheduleIterable(input, scheduler);
		if (isReadableStreamLike(input)) return scheduleReadableStreamLike(input, scheduler);
	}
	throw createInvalidObservableTypeError(input);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/from.js
function from(input, scheduler) {
	return scheduler ? scheduled(input, scheduler) : innerFrom(input);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/of.js
function of() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	return from(args, popScheduler(args));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/throwError.js
function throwError(errorOrErrorFactory, scheduler) {
	var errorFactory = isFunction(errorOrErrorFactory) ? errorOrErrorFactory : function() {
		return errorOrErrorFactory;
	};
	var init = function(subscriber) {
		return subscriber.error(errorFactory());
	};
	return new Observable(scheduler ? function(subscriber) {
		return scheduler.schedule(init, 0, subscriber);
	} : init);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/Notification.js
var NotificationKind;
(function(NotificationKind) {
	NotificationKind["NEXT"] = "N";
	NotificationKind["ERROR"] = "E";
	NotificationKind["COMPLETE"] = "C";
})(NotificationKind || (NotificationKind = {}));
var Notification = function() {
	function Notification(kind, value, error) {
		this.kind = kind;
		this.value = value;
		this.error = error;
		this.hasValue = kind === "N";
	}
	Notification.prototype.observe = function(observer) {
		return observeNotification(this, observer);
	};
	Notification.prototype.do = function(nextHandler, errorHandler, completeHandler) {
		var _a = this, kind = _a.kind, value = _a.value, error = _a.error;
		return kind === "N" ? nextHandler === null || nextHandler === void 0 ? void 0 : nextHandler(value) : kind === "E" ? errorHandler === null || errorHandler === void 0 ? void 0 : errorHandler(error) : completeHandler === null || completeHandler === void 0 ? void 0 : completeHandler();
	};
	Notification.prototype.accept = function(nextOrObserver, error, complete) {
		var _a;
		return isFunction((_a = nextOrObserver) === null || _a === void 0 ? void 0 : _a.next) ? this.observe(nextOrObserver) : this.do(nextOrObserver, error, complete);
	};
	Notification.prototype.toObservable = function() {
		var _a = this, kind = _a.kind, value = _a.value, error = _a.error;
		var result = kind === "N" ? of(value) : kind === "E" ? throwError(function() {
			return error;
		}) : kind === "C" ? EMPTY : 0;
		if (!result) throw new TypeError("Unexpected notification kind " + kind);
		return result;
	};
	Notification.createNext = function(value) {
		return new Notification("N", value);
	};
	Notification.createError = function(err) {
		return new Notification("E", void 0, err);
	};
	Notification.createComplete = function() {
		return Notification.completeNotification;
	};
	Notification.completeNotification = new Notification("C");
	return Notification;
}();
function observeNotification(notification, observer) {
	var _a, _b, _c;
	var _d = notification, kind = _d.kind, value = _d.value, error = _d.error;
	if (typeof kind !== "string") throw new TypeError("Invalid notification, missing \"kind\"");
	kind === "N" ? (_a = observer.next) === null || _a === void 0 || _a.call(observer, value) : kind === "E" ? (_b = observer.error) === null || _b === void 0 || _b.call(observer, error) : (_c = observer.complete) === null || _c === void 0 || _c.call(observer);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/EmptyError.js
var EmptyError = createErrorClass(function(_super) {
	return function EmptyErrorImpl() {
		_super(this);
		this.name = "EmptyError";
		this.message = "no elements in sequence";
	};
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/ArgumentOutOfRangeError.js
var ArgumentOutOfRangeError = createErrorClass(function(_super) {
	return function ArgumentOutOfRangeErrorImpl() {
		_super(this);
		this.name = "ArgumentOutOfRangeError";
		this.message = "argument out of range";
	};
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/NotFoundError.js
var NotFoundError = createErrorClass(function(_super) {
	return function NotFoundErrorImpl(message) {
		_super(this);
		this.name = "NotFoundError";
		this.message = message;
	};
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/SequenceError.js
var SequenceError = createErrorClass(function(_super) {
	return function SequenceErrorImpl(message) {
		_super(this);
		this.name = "SequenceError";
		this.message = message;
	};
});
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/isDate.js
function isValidDate(value) {
	return value instanceof Date && !isNaN(value);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/timeout.js
var TimeoutError = createErrorClass(function(_super) {
	return function TimeoutErrorImpl(info) {
		if (info === void 0) info = null;
		_super(this);
		this.message = "Timeout has occurred";
		this.name = "TimeoutError";
		this.info = info;
	};
});
function timeout(config, schedulerArg) {
	var _a = isValidDate(config) ? { first: config } : typeof config === "number" ? { each: config } : config, first = _a.first, each = _a.each, _b = _a.with, _with = _b === void 0 ? timeoutErrorFactory : _b, _c = _a.scheduler, scheduler = _c === void 0 ? schedulerArg !== null && schedulerArg !== void 0 ? schedulerArg : asyncScheduler : _c, _d = _a.meta, meta = _d === void 0 ? null : _d;
	if (first == null && each == null) throw new TypeError("No timeout provided.");
	return operate(function(source, subscriber) {
		var originalSourceSubscription;
		var timerSubscription;
		var lastValue = null;
		var seen = 0;
		var startTimer = function(delay) {
			timerSubscription = executeSchedule(subscriber, scheduler, function() {
				try {
					originalSourceSubscription.unsubscribe();
					innerFrom(_with({
						meta,
						lastValue,
						seen
					})).subscribe(subscriber);
				} catch (err) {
					subscriber.error(err);
				}
			}, delay);
		};
		originalSourceSubscription = source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			timerSubscription === null || timerSubscription === void 0 || timerSubscription.unsubscribe();
			seen++;
			subscriber.next(lastValue = value);
			each > 0 && startTimer(each);
		}, void 0, void 0, function() {
			if (!(timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.closed)) timerSubscription === null || timerSubscription === void 0 || timerSubscription.unsubscribe();
			lastValue = null;
		}));
		!seen && startTimer(first != null ? typeof first === "number" ? first : +first - scheduler.now() : each);
	});
}
function timeoutErrorFactory(info) {
	throw new TimeoutError(info);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/map.js
function map(project, thisArg) {
	return operate(function(source, subscriber) {
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			subscriber.next(project.call(thisArg, value, index++));
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/mapOneOrManyArgs.js
var isArray$2 = Array.isArray;
function callOrApply(fn, args) {
	return isArray$2(args) ? fn.apply(void 0, __spreadArray([], __read(args))) : fn(args);
}
function mapOneOrManyArgs(fn) {
	return map(function(args) {
		return callOrApply(fn, args);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/argsArgArrayOrObject.js
var isArray$1 = Array.isArray;
var getPrototypeOf = Object.getPrototypeOf;
var objectProto = Object.prototype;
var getKeys = Object.keys;
function argsArgArrayOrObject(args) {
	if (args.length === 1) {
		var first_1 = args[0];
		if (isArray$1(first_1)) return {
			args: first_1,
			keys: null
		};
		if (isPOJO(first_1)) {
			var keys = getKeys(first_1);
			return {
				args: keys.map(function(key) {
					return first_1[key];
				}),
				keys
			};
		}
	}
	return {
		args,
		keys: null
	};
}
function isPOJO(obj) {
	return obj && typeof obj === "object" && getPrototypeOf(obj) === objectProto;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/createObject.js
function createObject(keys, values) {
	return keys.reduce(function(result, key, i) {
		return result[key] = values[i], result;
	}, {});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/combineLatest.js
function combineLatest$1() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var scheduler = popScheduler(args);
	var resultSelector = popResultSelector(args);
	var _a = argsArgArrayOrObject(args), observables = _a.args, keys = _a.keys;
	if (observables.length === 0) return from([], scheduler);
	var result = new Observable(combineLatestInit(observables, scheduler, keys ? function(values) {
		return createObject(keys, values);
	} : identity));
	return resultSelector ? result.pipe(mapOneOrManyArgs(resultSelector)) : result;
}
function combineLatestInit(observables, scheduler, valueTransform) {
	if (valueTransform === void 0) valueTransform = identity;
	return function(subscriber) {
		maybeSchedule(scheduler, function() {
			var length = observables.length;
			var values = new Array(length);
			var active = length;
			var remainingFirstValues = length;
			var _loop_1 = function(i) {
				maybeSchedule(scheduler, function() {
					var source = from(observables[i], scheduler);
					var hasFirstValue = false;
					source.subscribe(createOperatorSubscriber(subscriber, function(value) {
						values[i] = value;
						if (!hasFirstValue) {
							hasFirstValue = true;
							remainingFirstValues--;
						}
						if (!remainingFirstValues) subscriber.next(valueTransform(values.slice()));
					}, function() {
						if (!--active) subscriber.complete();
					}));
				}, subscriber);
			};
			for (var i = 0; i < length; i++) _loop_1(i);
		}, subscriber);
	};
}
function maybeSchedule(scheduler, execute, subscription) {
	if (scheduler) executeSchedule(subscription, scheduler, execute);
	else execute();
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mergeInternals.js
function mergeInternals(source, subscriber, project, concurrent, onBeforeNext, expand, innerSubScheduler, additionalFinalizer) {
	var buffer = [];
	var active = 0;
	var index = 0;
	var isComplete = false;
	var checkComplete = function() {
		if (isComplete && !buffer.length && !active) subscriber.complete();
	};
	var outerNext = function(value) {
		return active < concurrent ? doInnerSub(value) : buffer.push(value);
	};
	var doInnerSub = function(value) {
		expand && subscriber.next(value);
		active++;
		var innerComplete = false;
		innerFrom(project(value, index++)).subscribe(createOperatorSubscriber(subscriber, function(innerValue) {
			onBeforeNext === null || onBeforeNext === void 0 || onBeforeNext(innerValue);
			if (expand) outerNext(innerValue);
			else subscriber.next(innerValue);
		}, function() {
			innerComplete = true;
		}, void 0, function() {
			if (innerComplete) try {
				active--;
				var _loop_1 = function() {
					var bufferedValue = buffer.shift();
					if (innerSubScheduler) executeSchedule(subscriber, innerSubScheduler, function() {
						return doInnerSub(bufferedValue);
					});
					else doInnerSub(bufferedValue);
				};
				while (buffer.length && active < concurrent) _loop_1();
				checkComplete();
			} catch (err) {
				subscriber.error(err);
			}
		}));
	};
	source.subscribe(createOperatorSubscriber(subscriber, outerNext, function() {
		isComplete = true;
		checkComplete();
	}));
	return function() {
		additionalFinalizer === null || additionalFinalizer === void 0 || additionalFinalizer();
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mergeMap.js
function mergeMap(project, resultSelector, concurrent) {
	if (concurrent === void 0) concurrent = Infinity;
	if (isFunction(resultSelector)) return mergeMap(function(a, i) {
		return map(function(b, ii) {
			return resultSelector(a, b, i, ii);
		})(innerFrom(project(a, i)));
	}, concurrent);
	else if (typeof resultSelector === "number") concurrent = resultSelector;
	return operate(function(source, subscriber) {
		return mergeInternals(source, subscriber, project, concurrent);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mergeAll.js
function mergeAll(concurrent) {
	if (concurrent === void 0) concurrent = Infinity;
	return mergeMap(identity, concurrent);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/concatAll.js
function concatAll() {
	return mergeAll(1);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/concat.js
function concat$1() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	return concatAll()(from(args, popScheduler(args)));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/timer.js
function timer(dueTime, intervalOrScheduler, scheduler) {
	if (dueTime === void 0) dueTime = 0;
	if (scheduler === void 0) scheduler = async;
	var intervalDuration = -1;
	if (intervalOrScheduler != null) if (isScheduler(intervalOrScheduler)) scheduler = intervalOrScheduler;
	else intervalDuration = intervalOrScheduler;
	return new Observable(function(subscriber) {
		var due = isValidDate(dueTime) ? +dueTime - scheduler.now() : dueTime;
		if (due < 0) due = 0;
		var n = 0;
		return scheduler.schedule(function() {
			if (!subscriber.closed) {
				subscriber.next(n++);
				if (0 <= intervalDuration) this.schedule(void 0, intervalDuration);
				else subscriber.complete();
			}
		}, due);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/interval.js
function interval(period, scheduler) {
	if (period === void 0) period = 0;
	if (scheduler === void 0) scheduler = asyncScheduler;
	if (period < 0) period = 0;
	return timer(period, period, scheduler);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/argsOrArgArray.js
var isArray = Array.isArray;
function argsOrArgArray(args) {
	return args.length === 1 && isArray(args[0]) ? args[0] : args;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/onErrorResumeNext.js
function onErrorResumeNext$1() {
	var sources = [];
	for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
	var nextSources = argsOrArgArray(sources);
	return new Observable(function(subscriber) {
		var sourceIndex = 0;
		var subscribeNext = function() {
			if (sourceIndex < nextSources.length) {
				var nextSource = void 0;
				try {
					nextSource = innerFrom(nextSources[sourceIndex++]);
				} catch (err) {
					subscribeNext();
					return;
				}
				var innerSubscriber = new OperatorSubscriber(subscriber, void 0, noop, noop);
				nextSource.subscribe(innerSubscriber);
				innerSubscriber.add(subscribeNext);
			} else subscriber.complete();
		};
		subscribeNext();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/util/not.js
function not(pred, thisArg) {
	return function(value, index) {
		return !pred.call(thisArg, value, index);
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/filter.js
function filter(predicate, thisArg) {
	return operate(function(source, subscriber) {
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return predicate.call(thisArg, value, index++) && subscriber.next(value);
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/race.js
function race() {
	var sources = [];
	for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
	sources = argsOrArgArray(sources);
	return sources.length === 1 ? innerFrom(sources[0]) : new Observable(raceInit(sources));
}
function raceInit(sources) {
	return function(subscriber) {
		var subscriptions = [];
		var _loop_1 = function(i) {
			subscriptions.push(innerFrom(sources[i]).subscribe(createOperatorSubscriber(subscriber, function(value) {
				if (subscriptions) {
					for (var s = 0; s < subscriptions.length; s++) s !== i && subscriptions[s].unsubscribe();
					subscriptions = null;
				}
				subscriber.next(value);
			})));
		};
		for (var i = 0; subscriptions && !subscriber.closed && i < sources.length; i++) _loop_1(i);
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/zip.js
function zip$1() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var resultSelector = popResultSelector(args);
	var sources = argsOrArgArray(args);
	return sources.length ? new Observable(function(subscriber) {
		var buffers = sources.map(function() {
			return [];
		});
		var completed = sources.map(function() {
			return false;
		});
		subscriber.add(function() {
			buffers = completed = null;
		});
		var _loop_1 = function(sourceIndex) {
			innerFrom(sources[sourceIndex]).subscribe(createOperatorSubscriber(subscriber, function(value) {
				buffers[sourceIndex].push(value);
				if (buffers.every(function(buffer) {
					return buffer.length;
				})) {
					var result = buffers.map(function(buffer) {
						return buffer.shift();
					});
					subscriber.next(resultSelector ? resultSelector.apply(void 0, __spreadArray([], __read(result))) : result);
					if (buffers.some(function(buffer, i) {
						return !buffer.length && completed[i];
					})) subscriber.complete();
				}
			}, function() {
				completed[sourceIndex] = true;
				!buffers[sourceIndex].length && subscriber.complete();
			}));
		};
		for (var sourceIndex = 0; !subscriber.closed && sourceIndex < sources.length; sourceIndex++) _loop_1(sourceIndex);
		return function() {
			buffers = completed = null;
		};
	}) : EMPTY;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/audit.js
function audit(durationSelector) {
	return operate(function(source, subscriber) {
		var hasValue = false;
		var lastValue = null;
		var durationSubscriber = null;
		var isComplete = false;
		var endDuration = function() {
			durationSubscriber === null || durationSubscriber === void 0 || durationSubscriber.unsubscribe();
			durationSubscriber = null;
			if (hasValue) {
				hasValue = false;
				var value = lastValue;
				lastValue = null;
				subscriber.next(value);
			}
			isComplete && subscriber.complete();
		};
		var cleanupDuration = function() {
			durationSubscriber = null;
			isComplete && subscriber.complete();
		};
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			hasValue = true;
			lastValue = value;
			if (!durationSubscriber) innerFrom(durationSelector(value)).subscribe(durationSubscriber = createOperatorSubscriber(subscriber, endDuration, cleanupDuration));
		}, function() {
			isComplete = true;
			(!hasValue || !durationSubscriber || durationSubscriber.closed) && subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/auditTime.js
function auditTime(duration, scheduler) {
	if (scheduler === void 0) scheduler = asyncScheduler;
	return audit(function() {
		return timer(duration, scheduler);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/buffer.js
function buffer(closingNotifier) {
	return operate(function(source, subscriber) {
		var currentBuffer = [];
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return currentBuffer.push(value);
		}, function() {
			subscriber.next(currentBuffer);
			subscriber.complete();
		}));
		innerFrom(closingNotifier).subscribe(createOperatorSubscriber(subscriber, function() {
			var b = currentBuffer;
			currentBuffer = [];
			subscriber.next(b);
		}, noop));
		return function() {
			currentBuffer = null;
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/bufferCount.js
function bufferCount(bufferSize, startBufferEvery) {
	if (startBufferEvery === void 0) startBufferEvery = null;
	startBufferEvery = startBufferEvery !== null && startBufferEvery !== void 0 ? startBufferEvery : bufferSize;
	return operate(function(source, subscriber) {
		var buffers = [];
		var count = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var e_1, _a, e_2, _b;
			var toEmit = null;
			if (count++ % startBufferEvery === 0) buffers.push([]);
			try {
				for (var buffers_1 = __values(buffers), buffers_1_1 = buffers_1.next(); !buffers_1_1.done; buffers_1_1 = buffers_1.next()) {
					var buffer = buffers_1_1.value;
					buffer.push(value);
					if (bufferSize <= buffer.length) {
						toEmit = toEmit !== null && toEmit !== void 0 ? toEmit : [];
						toEmit.push(buffer);
					}
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (buffers_1_1 && !buffers_1_1.done && (_a = buffers_1.return)) _a.call(buffers_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			if (toEmit) try {
				for (var toEmit_1 = __values(toEmit), toEmit_1_1 = toEmit_1.next(); !toEmit_1_1.done; toEmit_1_1 = toEmit_1.next()) {
					var buffer = toEmit_1_1.value;
					arrRemove(buffers, buffer);
					subscriber.next(buffer);
				}
			} catch (e_2_1) {
				e_2 = { error: e_2_1 };
			} finally {
				try {
					if (toEmit_1_1 && !toEmit_1_1.done && (_b = toEmit_1.return)) _b.call(toEmit_1);
				} finally {
					if (e_2) throw e_2.error;
				}
			}
		}, function() {
			var e_3, _a;
			try {
				for (var buffers_2 = __values(buffers), buffers_2_1 = buffers_2.next(); !buffers_2_1.done; buffers_2_1 = buffers_2.next()) {
					var buffer = buffers_2_1.value;
					subscriber.next(buffer);
				}
			} catch (e_3_1) {
				e_3 = { error: e_3_1 };
			} finally {
				try {
					if (buffers_2_1 && !buffers_2_1.done && (_a = buffers_2.return)) _a.call(buffers_2);
				} finally {
					if (e_3) throw e_3.error;
				}
			}
			subscriber.complete();
		}, void 0, function() {
			buffers = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/bufferTime.js
function bufferTime(bufferTimeSpan) {
	var _a, _b;
	var otherArgs = [];
	for (var _i = 1; _i < arguments.length; _i++) otherArgs[_i - 1] = arguments[_i];
	var scheduler = (_a = popScheduler(otherArgs)) !== null && _a !== void 0 ? _a : asyncScheduler;
	var bufferCreationInterval = (_b = otherArgs[0]) !== null && _b !== void 0 ? _b : null;
	var maxBufferSize = otherArgs[1] || Infinity;
	return operate(function(source, subscriber) {
		var bufferRecords = [];
		var restartOnEmit = false;
		var emit = function(record) {
			var buffer = record.buffer;
			record.subs.unsubscribe();
			arrRemove(bufferRecords, record);
			subscriber.next(buffer);
			restartOnEmit && startBuffer();
		};
		var startBuffer = function() {
			if (bufferRecords) {
				var subs = new Subscription();
				subscriber.add(subs);
				var record_1 = {
					buffer: [],
					subs
				};
				bufferRecords.push(record_1);
				executeSchedule(subs, scheduler, function() {
					return emit(record_1);
				}, bufferTimeSpan);
			}
		};
		if (bufferCreationInterval !== null && bufferCreationInterval >= 0) executeSchedule(subscriber, scheduler, startBuffer, bufferCreationInterval, true);
		else restartOnEmit = true;
		startBuffer();
		var bufferTimeSubscriber = createOperatorSubscriber(subscriber, function(value) {
			var e_1, _a;
			var recordsCopy = bufferRecords.slice();
			try {
				for (var recordsCopy_1 = __values(recordsCopy), recordsCopy_1_1 = recordsCopy_1.next(); !recordsCopy_1_1.done; recordsCopy_1_1 = recordsCopy_1.next()) {
					var record = recordsCopy_1_1.value;
					var buffer = record.buffer;
					buffer.push(value);
					maxBufferSize <= buffer.length && emit(record);
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (recordsCopy_1_1 && !recordsCopy_1_1.done && (_a = recordsCopy_1.return)) _a.call(recordsCopy_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
		}, function() {
			while (bufferRecords === null || bufferRecords === void 0 ? void 0 : bufferRecords.length) subscriber.next(bufferRecords.shift().buffer);
			bufferTimeSubscriber === null || bufferTimeSubscriber === void 0 || bufferTimeSubscriber.unsubscribe();
			subscriber.complete();
			subscriber.unsubscribe();
		}, void 0, function() {
			return bufferRecords = null;
		});
		source.subscribe(bufferTimeSubscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/bufferToggle.js
function bufferToggle(openings, closingSelector) {
	return operate(function(source, subscriber) {
		var buffers = [];
		innerFrom(openings).subscribe(createOperatorSubscriber(subscriber, function(openValue) {
			var buffer = [];
			buffers.push(buffer);
			var closingSubscription = new Subscription();
			var emitBuffer = function() {
				arrRemove(buffers, buffer);
				subscriber.next(buffer);
				closingSubscription.unsubscribe();
			};
			closingSubscription.add(innerFrom(closingSelector(openValue)).subscribe(createOperatorSubscriber(subscriber, emitBuffer, noop)));
		}, noop));
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var e_1, _a;
			try {
				for (var buffers_1 = __values(buffers), buffers_1_1 = buffers_1.next(); !buffers_1_1.done; buffers_1_1 = buffers_1.next()) buffers_1_1.value.push(value);
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (buffers_1_1 && !buffers_1_1.done && (_a = buffers_1.return)) _a.call(buffers_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
		}, function() {
			while (buffers.length > 0) subscriber.next(buffers.shift());
			subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/bufferWhen.js
function bufferWhen(closingSelector) {
	return operate(function(source, subscriber) {
		var buffer = null;
		var closingSubscriber = null;
		var openBuffer = function() {
			closingSubscriber === null || closingSubscriber === void 0 || closingSubscriber.unsubscribe();
			var b = buffer;
			buffer = [];
			b && subscriber.next(b);
			innerFrom(closingSelector()).subscribe(closingSubscriber = createOperatorSubscriber(subscriber, openBuffer, noop));
		};
		openBuffer();
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return buffer === null || buffer === void 0 ? void 0 : buffer.push(value);
		}, function() {
			buffer && subscriber.next(buffer);
			subscriber.complete();
		}, void 0, function() {
			return buffer = closingSubscriber = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/catchError.js
function catchError(selector) {
	return operate(function(source, subscriber) {
		var innerSub = null;
		var syncUnsub = false;
		var handledResult;
		innerSub = source.subscribe(createOperatorSubscriber(subscriber, void 0, void 0, function(err) {
			handledResult = innerFrom(selector(err, catchError(selector)(source)));
			if (innerSub) {
				innerSub.unsubscribe();
				innerSub = null;
				handledResult.subscribe(subscriber);
			} else syncUnsub = true;
		}));
		if (syncUnsub) {
			innerSub.unsubscribe();
			innerSub = null;
			handledResult.subscribe(subscriber);
		}
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/scanInternals.js
function scanInternals(accumulator, seed, hasSeed, emitOnNext, emitBeforeComplete) {
	return function(source, subscriber) {
		var hasState = hasSeed;
		var state = seed;
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var i = index++;
			state = hasState ? accumulator(state, value, i) : (hasState = true, value);
			emitOnNext && subscriber.next(state);
		}, emitBeforeComplete && (function() {
			hasState && subscriber.next(state);
			subscriber.complete();
		})));
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/reduce.js
function reduce(accumulator, seed) {
	return operate(scanInternals(accumulator, seed, arguments.length >= 2, false, true));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/toArray.js
var arrReducer = function(arr, value) {
	return arr.push(value), arr;
};
function toArray() {
	return operate(function(source, subscriber) {
		reduce(arrReducer, [])(source).subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/joinAllInternals.js
function joinAllInternals(joinFn, project) {
	return pipe(toArray(), mergeMap(function(sources) {
		return joinFn(sources);
	}), project ? mapOneOrManyArgs(project) : identity);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/combineLatestAll.js
function combineLatestAll(project) {
	return joinAllInternals(combineLatest$1, project);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/combineAll.js
var combineAll = combineLatestAll;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/combineLatest.js
function combineLatest() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var resultSelector = popResultSelector(args);
	return resultSelector ? pipe(combineLatest.apply(void 0, __spreadArray([], __read(args))), mapOneOrManyArgs(resultSelector)) : operate(function(source, subscriber) {
		combineLatestInit(__spreadArray([source], __read(argsOrArgArray(args))))(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/combineLatestWith.js
function combineLatestWith() {
	var otherSources = [];
	for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
	return combineLatest.apply(void 0, __spreadArray([], __read(otherSources)));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/concatMap.js
function concatMap(project, resultSelector) {
	return isFunction(resultSelector) ? mergeMap(project, resultSelector, 1) : mergeMap(project, 1);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/concatMapTo.js
function concatMapTo(innerObservable, resultSelector) {
	return isFunction(resultSelector) ? concatMap(function() {
		return innerObservable;
	}, resultSelector) : concatMap(function() {
		return innerObservable;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/concat.js
function concat() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var scheduler = popScheduler(args);
	return operate(function(source, subscriber) {
		concatAll()(from(__spreadArray([source], __read(args)), scheduler)).subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/concatWith.js
function concatWith() {
	var otherSources = [];
	for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
	return concat.apply(void 0, __spreadArray([], __read(otherSources)));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/observable/fromSubscribable.js
function fromSubscribable(subscribable) {
	return new Observable(function(subscriber) {
		return subscribable.subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/connect.js
var DEFAULT_CONFIG = { connector: function() {
	return new Subject();
} };
function connect(selector, config) {
	if (config === void 0) config = DEFAULT_CONFIG;
	var connector = config.connector;
	return operate(function(source, subscriber) {
		var subject = connector();
		innerFrom(selector(fromSubscribable(subject))).subscribe(subscriber);
		subscriber.add(source.subscribe(subject));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/count.js
function count(predicate) {
	return reduce(function(total, value, i) {
		return !predicate || predicate(value, i) ? total + 1 : total;
	}, 0);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/debounce.js
function debounce(durationSelector) {
	return operate(function(source, subscriber) {
		var hasValue = false;
		var lastValue = null;
		var durationSubscriber = null;
		var emit = function() {
			durationSubscriber === null || durationSubscriber === void 0 || durationSubscriber.unsubscribe();
			durationSubscriber = null;
			if (hasValue) {
				hasValue = false;
				var value = lastValue;
				lastValue = null;
				subscriber.next(value);
			}
		};
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			durationSubscriber === null || durationSubscriber === void 0 || durationSubscriber.unsubscribe();
			hasValue = true;
			lastValue = value;
			durationSubscriber = createOperatorSubscriber(subscriber, emit, noop);
			innerFrom(durationSelector(value)).subscribe(durationSubscriber);
		}, function() {
			emit();
			subscriber.complete();
		}, void 0, function() {
			lastValue = durationSubscriber = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/debounceTime.js
function debounceTime(dueTime, scheduler) {
	if (scheduler === void 0) scheduler = asyncScheduler;
	return operate(function(source, subscriber) {
		var activeTask = null;
		var lastValue = null;
		var lastTime = null;
		var emit = function() {
			if (activeTask) {
				activeTask.unsubscribe();
				activeTask = null;
				var value = lastValue;
				lastValue = null;
				subscriber.next(value);
			}
		};
		function emitWhenIdle() {
			var targetTime = lastTime + dueTime;
			var now = scheduler.now();
			if (now < targetTime) {
				activeTask = this.schedule(void 0, targetTime - now);
				subscriber.add(activeTask);
				return;
			}
			emit();
		}
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			lastValue = value;
			lastTime = scheduler.now();
			if (!activeTask) {
				activeTask = scheduler.schedule(emitWhenIdle, dueTime);
				subscriber.add(activeTask);
			}
		}, function() {
			emit();
			subscriber.complete();
		}, void 0, function() {
			lastValue = activeTask = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/defaultIfEmpty.js
function defaultIfEmpty(defaultValue) {
	return operate(function(source, subscriber) {
		var hasValue = false;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			hasValue = true;
			subscriber.next(value);
		}, function() {
			if (!hasValue) subscriber.next(defaultValue);
			subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/take.js
function take(count) {
	return count <= 0 ? function() {
		return EMPTY;
	} : operate(function(source, subscriber) {
		var seen = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			if (++seen <= count) {
				subscriber.next(value);
				if (count <= seen) subscriber.complete();
			}
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/ignoreElements.js
function ignoreElements() {
	return operate(function(source, subscriber) {
		source.subscribe(createOperatorSubscriber(subscriber, noop));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mapTo.js
function mapTo(value) {
	return map(function() {
		return value;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/delayWhen.js
function delayWhen(delayDurationSelector, subscriptionDelay) {
	if (subscriptionDelay) return function(source) {
		return concat$1(subscriptionDelay.pipe(take(1), ignoreElements()), source.pipe(delayWhen(delayDurationSelector)));
	};
	return mergeMap(function(value, index) {
		return innerFrom(delayDurationSelector(value, index)).pipe(take(1), mapTo(value));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/delay.js
function delay(due, scheduler) {
	if (scheduler === void 0) scheduler = asyncScheduler;
	var duration = timer(due, scheduler);
	return delayWhen(function() {
		return duration;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/dematerialize.js
function dematerialize() {
	return operate(function(source, subscriber) {
		source.subscribe(createOperatorSubscriber(subscriber, function(notification) {
			return observeNotification(notification, subscriber);
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/distinct.js
function distinct(keySelector, flushes) {
	return operate(function(source, subscriber) {
		var distinctKeys = /* @__PURE__ */ new Set();
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var key = keySelector ? keySelector(value) : value;
			if (!distinctKeys.has(key)) {
				distinctKeys.add(key);
				subscriber.next(value);
			}
		}));
		flushes && innerFrom(flushes).subscribe(createOperatorSubscriber(subscriber, function() {
			return distinctKeys.clear();
		}, noop));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/distinctUntilChanged.js
function distinctUntilChanged(comparator, keySelector) {
	if (keySelector === void 0) keySelector = identity;
	comparator = comparator !== null && comparator !== void 0 ? comparator : defaultCompare;
	return operate(function(source, subscriber) {
		var previousKey;
		var first = true;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var currentKey = keySelector(value);
			if (first || !comparator(previousKey, currentKey)) {
				first = false;
				previousKey = currentKey;
				subscriber.next(value);
			}
		}));
	});
}
function defaultCompare(a, b) {
	return a === b;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/distinctUntilKeyChanged.js
function distinctUntilKeyChanged(key, compare) {
	return distinctUntilChanged(function(x, y) {
		return compare ? compare(x[key], y[key]) : x[key] === y[key];
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/throwIfEmpty.js
function throwIfEmpty(errorFactory) {
	if (errorFactory === void 0) errorFactory = defaultErrorFactory;
	return operate(function(source, subscriber) {
		var hasValue = false;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			hasValue = true;
			subscriber.next(value);
		}, function() {
			return hasValue ? subscriber.complete() : subscriber.error(errorFactory());
		}));
	});
}
function defaultErrorFactory() {
	return new EmptyError();
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/elementAt.js
function elementAt(index, defaultValue) {
	if (index < 0) throw new ArgumentOutOfRangeError();
	var hasDefaultValue = arguments.length >= 2;
	return function(source) {
		return source.pipe(filter(function(v, i) {
			return i === index;
		}), take(1), hasDefaultValue ? defaultIfEmpty(defaultValue) : throwIfEmpty(function() {
			return new ArgumentOutOfRangeError();
		}));
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/endWith.js
function endWith() {
	var values = [];
	for (var _i = 0; _i < arguments.length; _i++) values[_i] = arguments[_i];
	return function(source) {
		return concat$1(source, of.apply(void 0, __spreadArray([], __read(values))));
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/every.js
function every(predicate, thisArg) {
	return operate(function(source, subscriber) {
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			if (!predicate.call(thisArg, value, index++, source)) {
				subscriber.next(false);
				subscriber.complete();
			}
		}, function() {
			subscriber.next(true);
			subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/exhaustMap.js
function exhaustMap(project, resultSelector) {
	if (resultSelector) return function(source) {
		return source.pipe(exhaustMap(function(a, i) {
			return innerFrom(project(a, i)).pipe(map(function(b, ii) {
				return resultSelector(a, b, i, ii);
			}));
		}));
	};
	return operate(function(source, subscriber) {
		var index = 0;
		var innerSub = null;
		var isComplete = false;
		source.subscribe(createOperatorSubscriber(subscriber, function(outerValue) {
			if (!innerSub) {
				innerSub = createOperatorSubscriber(subscriber, void 0, function() {
					innerSub = null;
					isComplete && subscriber.complete();
				});
				innerFrom(project(outerValue, index++)).subscribe(innerSub);
			}
		}, function() {
			isComplete = true;
			!innerSub && subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/exhaustAll.js
function exhaustAll() {
	return exhaustMap(identity);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/exhaust.js
var exhaust = exhaustAll;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/expand.js
function expand(project, concurrent, scheduler) {
	if (concurrent === void 0) concurrent = Infinity;
	concurrent = (concurrent || 0) < 1 ? Infinity : concurrent;
	return operate(function(source, subscriber) {
		return mergeInternals(source, subscriber, project, concurrent, void 0, true, scheduler);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/finalize.js
function finalize(callback) {
	return operate(function(source, subscriber) {
		try {
			source.subscribe(subscriber);
		} finally {
			subscriber.add(callback);
		}
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/find.js
function find(predicate, thisArg) {
	return operate(createFind(predicate, thisArg, "value"));
}
function createFind(predicate, thisArg, emit) {
	var findIndex = emit === "index";
	return function(source, subscriber) {
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var i = index++;
			if (predicate.call(thisArg, value, i, source)) {
				subscriber.next(findIndex ? i : value);
				subscriber.complete();
			}
		}, function() {
			subscriber.next(findIndex ? -1 : void 0);
			subscriber.complete();
		}));
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/findIndex.js
function findIndex(predicate, thisArg) {
	return operate(createFind(predicate, thisArg, "index"));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/first.js
function first(predicate, defaultValue) {
	var hasDefaultValue = arguments.length >= 2;
	return function(source) {
		return source.pipe(predicate ? filter(function(v, i) {
			return predicate(v, i, source);
		}) : identity, take(1), hasDefaultValue ? defaultIfEmpty(defaultValue) : throwIfEmpty(function() {
			return new EmptyError();
		}));
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/groupBy.js
function groupBy(keySelector, elementOrOptions, duration, connector) {
	return operate(function(source, subscriber) {
		var element;
		if (!elementOrOptions || typeof elementOrOptions === "function") element = elementOrOptions;
		else duration = elementOrOptions.duration, element = elementOrOptions.element, connector = elementOrOptions.connector;
		var groups = /* @__PURE__ */ new Map();
		var notify = function(cb) {
			groups.forEach(cb);
			cb(subscriber);
		};
		var handleError = function(err) {
			return notify(function(consumer) {
				return consumer.error(err);
			});
		};
		var activeGroups = 0;
		var teardownAttempted = false;
		var groupBySourceSubscriber = new OperatorSubscriber(subscriber, function(value) {
			try {
				var key_1 = keySelector(value);
				var group_1 = groups.get(key_1);
				if (!group_1) {
					groups.set(key_1, group_1 = connector ? connector() : new Subject());
					var grouped = createGroupedObservable(key_1, group_1);
					subscriber.next(grouped);
					if (duration) {
						var durationSubscriber_1 = createOperatorSubscriber(group_1, function() {
							group_1.complete();
							durationSubscriber_1 === null || durationSubscriber_1 === void 0 || durationSubscriber_1.unsubscribe();
						}, void 0, void 0, function() {
							return groups.delete(key_1);
						});
						groupBySourceSubscriber.add(innerFrom(duration(grouped)).subscribe(durationSubscriber_1));
					}
				}
				group_1.next(element ? element(value) : value);
			} catch (err) {
				handleError(err);
			}
		}, function() {
			return notify(function(consumer) {
				return consumer.complete();
			});
		}, handleError, function() {
			return groups.clear();
		}, function() {
			teardownAttempted = true;
			return activeGroups === 0;
		});
		source.subscribe(groupBySourceSubscriber);
		function createGroupedObservable(key, groupSubject) {
			var result = new Observable(function(groupSubscriber) {
				activeGroups++;
				var innerSub = groupSubject.subscribe(groupSubscriber);
				return function() {
					innerSub.unsubscribe();
					--activeGroups === 0 && teardownAttempted && groupBySourceSubscriber.unsubscribe();
				};
			});
			result.key = key;
			return result;
		}
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/isEmpty.js
function isEmpty() {
	return operate(function(source, subscriber) {
		source.subscribe(createOperatorSubscriber(subscriber, function() {
			subscriber.next(false);
			subscriber.complete();
		}, function() {
			subscriber.next(true);
			subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/takeLast.js
function takeLast(count) {
	return count <= 0 ? function() {
		return EMPTY;
	} : operate(function(source, subscriber) {
		var buffer = [];
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			buffer.push(value);
			count < buffer.length && buffer.shift();
		}, function() {
			var e_1, _a;
			try {
				for (var buffer_1 = __values(buffer), buffer_1_1 = buffer_1.next(); !buffer_1_1.done; buffer_1_1 = buffer_1.next()) {
					var value = buffer_1_1.value;
					subscriber.next(value);
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (buffer_1_1 && !buffer_1_1.done && (_a = buffer_1.return)) _a.call(buffer_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			subscriber.complete();
		}, void 0, function() {
			buffer = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/last.js
function last(predicate, defaultValue) {
	var hasDefaultValue = arguments.length >= 2;
	return function(source) {
		return source.pipe(predicate ? filter(function(v, i) {
			return predicate(v, i, source);
		}) : identity, takeLast(1), hasDefaultValue ? defaultIfEmpty(defaultValue) : throwIfEmpty(function() {
			return new EmptyError();
		}));
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/materialize.js
function materialize() {
	return operate(function(source, subscriber) {
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			subscriber.next(Notification.createNext(value));
		}, function() {
			subscriber.next(Notification.createComplete());
			subscriber.complete();
		}, function(err) {
			subscriber.next(Notification.createError(err));
			subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/max.js
function max(comparer) {
	return reduce(isFunction(comparer) ? function(x, y) {
		return comparer(x, y) > 0 ? x : y;
	} : function(x, y) {
		return x > y ? x : y;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/flatMap.js
var flatMap = mergeMap;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mergeMapTo.js
function mergeMapTo(innerObservable, resultSelector, concurrent) {
	if (concurrent === void 0) concurrent = Infinity;
	if (isFunction(resultSelector)) return mergeMap(function() {
		return innerObservable;
	}, resultSelector, concurrent);
	if (typeof resultSelector === "number") concurrent = resultSelector;
	return mergeMap(function() {
		return innerObservable;
	}, concurrent);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mergeScan.js
function mergeScan(accumulator, seed, concurrent) {
	if (concurrent === void 0) concurrent = Infinity;
	return operate(function(source, subscriber) {
		var state = seed;
		return mergeInternals(source, subscriber, function(value, index) {
			return accumulator(state, value, index);
		}, concurrent, function(value) {
			state = value;
		}, false, void 0, function() {
			return state = null;
		});
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/merge.js
function merge() {
	var args = [];
	for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
	var scheduler = popScheduler(args);
	var concurrent = popNumber(args, Infinity);
	return operate(function(source, subscriber) {
		mergeAll(concurrent)(from(__spreadArray([source], __read(args)), scheduler)).subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/mergeWith.js
function mergeWith() {
	var otherSources = [];
	for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
	return merge.apply(void 0, __spreadArray([], __read(otherSources)));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/min.js
function min(comparer) {
	return reduce(isFunction(comparer) ? function(x, y) {
		return comparer(x, y) < 0 ? x : y;
	} : function(x, y) {
		return x < y ? x : y;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/multicast.js
function multicast(subjectOrSubjectFactory, selector) {
	var subjectFactory = isFunction(subjectOrSubjectFactory) ? subjectOrSubjectFactory : function() {
		return subjectOrSubjectFactory;
	};
	if (isFunction(selector)) return connect(selector, { connector: subjectFactory });
	return function(source) {
		return new ConnectableObservable(source, subjectFactory);
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/onErrorResumeNextWith.js
function onErrorResumeNextWith() {
	var sources = [];
	for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
	var nextSources = argsOrArgArray(sources);
	return function(source) {
		return onErrorResumeNext$1.apply(void 0, __spreadArray([source], __read(nextSources)));
	};
}
var onErrorResumeNext = onErrorResumeNextWith;
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/pairwise.js
function pairwise() {
	return operate(function(source, subscriber) {
		var prev;
		var hasPrev = false;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var p = prev;
			prev = value;
			hasPrev && subscriber.next([p, value]);
			hasPrev = true;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/pluck.js
function pluck() {
	var properties = [];
	for (var _i = 0; _i < arguments.length; _i++) properties[_i] = arguments[_i];
	var length = properties.length;
	if (length === 0) throw new Error("list of properties cannot be empty.");
	return map(function(x) {
		var currentProp = x;
		for (var i = 0; i < length; i++) {
			var p = currentProp === null || currentProp === void 0 ? void 0 : currentProp[properties[i]];
			if (typeof p !== "undefined") currentProp = p;
			else return;
		}
		return currentProp;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/publish.js
function publish(selector) {
	return selector ? function(source) {
		return connect(selector)(source);
	} : function(source) {
		return multicast(new Subject())(source);
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/publishBehavior.js
function publishBehavior(initialValue) {
	return function(source) {
		var subject = new BehaviorSubject(initialValue);
		return new ConnectableObservable(source, function() {
			return subject;
		});
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/publishLast.js
function publishLast() {
	return function(source) {
		var subject = new AsyncSubject();
		return new ConnectableObservable(source, function() {
			return subject;
		});
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/publishReplay.js
function publishReplay(bufferSize, windowTime, selectorOrScheduler, timestampProvider) {
	if (selectorOrScheduler && !isFunction(selectorOrScheduler)) timestampProvider = selectorOrScheduler;
	var selector = isFunction(selectorOrScheduler) ? selectorOrScheduler : void 0;
	return function(source) {
		return multicast(new ReplaySubject(bufferSize, windowTime, timestampProvider), selector)(source);
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/raceWith.js
function raceWith() {
	var otherSources = [];
	for (var _i = 0; _i < arguments.length; _i++) otherSources[_i] = arguments[_i];
	return !otherSources.length ? identity : operate(function(source, subscriber) {
		raceInit(__spreadArray([source], __read(otherSources)))(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/repeat.js
function repeat(countOrConfig) {
	var _a;
	var count = Infinity;
	var delay;
	if (countOrConfig != null) if (typeof countOrConfig === "object") _a = countOrConfig.count, count = _a === void 0 ? Infinity : _a, delay = countOrConfig.delay;
	else count = countOrConfig;
	return count <= 0 ? function() {
		return EMPTY;
	} : operate(function(source, subscriber) {
		var soFar = 0;
		var sourceSub;
		var resubscribe = function() {
			sourceSub === null || sourceSub === void 0 || sourceSub.unsubscribe();
			sourceSub = null;
			if (delay != null) {
				var notifier = typeof delay === "number" ? timer(delay) : innerFrom(delay(soFar));
				var notifierSubscriber_1 = createOperatorSubscriber(subscriber, function() {
					notifierSubscriber_1.unsubscribe();
					subscribeToSource();
				});
				notifier.subscribe(notifierSubscriber_1);
			} else subscribeToSource();
		};
		var subscribeToSource = function() {
			var syncUnsub = false;
			sourceSub = source.subscribe(createOperatorSubscriber(subscriber, void 0, function() {
				if (++soFar < count) if (sourceSub) resubscribe();
				else syncUnsub = true;
				else subscriber.complete();
			}));
			if (syncUnsub) resubscribe();
		};
		subscribeToSource();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/repeatWhen.js
function repeatWhen(notifier) {
	return operate(function(source, subscriber) {
		var innerSub;
		var syncResub = false;
		var completions$;
		var isNotifierComplete = false;
		var isMainComplete = false;
		var checkComplete = function() {
			return isMainComplete && isNotifierComplete && (subscriber.complete(), true);
		};
		var getCompletionSubject = function() {
			if (!completions$) {
				completions$ = new Subject();
				innerFrom(notifier(completions$)).subscribe(createOperatorSubscriber(subscriber, function() {
					if (innerSub) subscribeForRepeatWhen();
					else syncResub = true;
				}, function() {
					isNotifierComplete = true;
					checkComplete();
				}));
			}
			return completions$;
		};
		var subscribeForRepeatWhen = function() {
			isMainComplete = false;
			innerSub = source.subscribe(createOperatorSubscriber(subscriber, void 0, function() {
				isMainComplete = true;
				!checkComplete() && getCompletionSubject().next();
			}));
			if (syncResub) {
				innerSub.unsubscribe();
				innerSub = null;
				syncResub = false;
				subscribeForRepeatWhen();
			}
		};
		subscribeForRepeatWhen();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/retry.js
function retry(configOrCount) {
	if (configOrCount === void 0) configOrCount = Infinity;
	var config;
	if (configOrCount && typeof configOrCount === "object") config = configOrCount;
	else config = { count: configOrCount };
	var _a = config.count, count = _a === void 0 ? Infinity : _a, delay = config.delay, _b = config.resetOnSuccess, resetOnSuccess = _b === void 0 ? false : _b;
	return count <= 0 ? identity : operate(function(source, subscriber) {
		var soFar = 0;
		var innerSub;
		var subscribeForRetry = function() {
			var syncUnsub = false;
			innerSub = source.subscribe(createOperatorSubscriber(subscriber, function(value) {
				if (resetOnSuccess) soFar = 0;
				subscriber.next(value);
			}, void 0, function(err) {
				if (soFar++ < count) {
					var resub_1 = function() {
						if (innerSub) {
							innerSub.unsubscribe();
							innerSub = null;
							subscribeForRetry();
						} else syncUnsub = true;
					};
					if (delay != null) {
						var notifier = typeof delay === "number" ? timer(delay) : innerFrom(delay(err, soFar));
						var notifierSubscriber_1 = createOperatorSubscriber(subscriber, function() {
							notifierSubscriber_1.unsubscribe();
							resub_1();
						}, function() {
							subscriber.complete();
						});
						notifier.subscribe(notifierSubscriber_1);
					} else resub_1();
				} else subscriber.error(err);
			}));
			if (syncUnsub) {
				innerSub.unsubscribe();
				innerSub = null;
				subscribeForRetry();
			}
		};
		subscribeForRetry();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/retryWhen.js
function retryWhen(notifier) {
	return operate(function(source, subscriber) {
		var innerSub;
		var syncResub = false;
		var errors$;
		var subscribeForRetryWhen = function() {
			innerSub = source.subscribe(createOperatorSubscriber(subscriber, void 0, void 0, function(err) {
				if (!errors$) {
					errors$ = new Subject();
					innerFrom(notifier(errors$)).subscribe(createOperatorSubscriber(subscriber, function() {
						return innerSub ? subscribeForRetryWhen() : syncResub = true;
					}));
				}
				if (errors$) errors$.next(err);
			}));
			if (syncResub) {
				innerSub.unsubscribe();
				innerSub = null;
				syncResub = false;
				subscribeForRetryWhen();
			}
		};
		subscribeForRetryWhen();
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/sample.js
function sample(notifier) {
	return operate(function(source, subscriber) {
		var hasValue = false;
		var lastValue = null;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			hasValue = true;
			lastValue = value;
		}));
		innerFrom(notifier).subscribe(createOperatorSubscriber(subscriber, function() {
			if (hasValue) {
				hasValue = false;
				var value = lastValue;
				lastValue = null;
				subscriber.next(value);
			}
		}, noop));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/sampleTime.js
function sampleTime(period, scheduler) {
	if (scheduler === void 0) scheduler = asyncScheduler;
	return sample(interval(period, scheduler));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/scan.js
function scan(accumulator, seed) {
	return operate(scanInternals(accumulator, seed, arguments.length >= 2, true));
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/sequenceEqual.js
function sequenceEqual(compareTo, comparator) {
	if (comparator === void 0) comparator = function(a, b) {
		return a === b;
	};
	return operate(function(source, subscriber) {
		var aState = createState();
		var bState = createState();
		var emit = function(isEqual) {
			subscriber.next(isEqual);
			subscriber.complete();
		};
		var createSubscriber = function(selfState, otherState) {
			var sequenceEqualSubscriber = createOperatorSubscriber(subscriber, function(a) {
				var buffer = otherState.buffer, complete = otherState.complete;
				if (buffer.length === 0) complete ? emit(false) : selfState.buffer.push(a);
				else !comparator(a, buffer.shift()) && emit(false);
			}, function() {
				selfState.complete = true;
				var complete = otherState.complete, buffer = otherState.buffer;
				complete && emit(buffer.length === 0);
				sequenceEqualSubscriber === null || sequenceEqualSubscriber === void 0 || sequenceEqualSubscriber.unsubscribe();
			});
			return sequenceEqualSubscriber;
		};
		source.subscribe(createSubscriber(aState, bState));
		innerFrom(compareTo).subscribe(createSubscriber(bState, aState));
	});
}
function createState() {
	return {
		buffer: [],
		complete: false
	};
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/share.js
function share(options) {
	if (options === void 0) options = {};
	var _a = options.connector, connector = _a === void 0 ? function() {
		return new Subject();
	} : _a, _b = options.resetOnError, resetOnError = _b === void 0 ? true : _b, _c = options.resetOnComplete, resetOnComplete = _c === void 0 ? true : _c, _d = options.resetOnRefCountZero, resetOnRefCountZero = _d === void 0 ? true : _d;
	return function(wrapperSource) {
		var connection;
		var resetConnection;
		var subject;
		var refCount = 0;
		var hasCompleted = false;
		var hasErrored = false;
		var cancelReset = function() {
			resetConnection === null || resetConnection === void 0 || resetConnection.unsubscribe();
			resetConnection = void 0;
		};
		var reset = function() {
			cancelReset();
			connection = subject = void 0;
			hasCompleted = hasErrored = false;
		};
		var resetAndUnsubscribe = function() {
			var conn = connection;
			reset();
			conn === null || conn === void 0 || conn.unsubscribe();
		};
		return operate(function(source, subscriber) {
			refCount++;
			if (!hasErrored && !hasCompleted) cancelReset();
			var dest = subject = subject !== null && subject !== void 0 ? subject : connector();
			subscriber.add(function() {
				refCount--;
				if (refCount === 0 && !hasErrored && !hasCompleted) resetConnection = handleReset(resetAndUnsubscribe, resetOnRefCountZero);
			});
			dest.subscribe(subscriber);
			if (!connection && refCount > 0) {
				connection = new SafeSubscriber({
					next: function(value) {
						return dest.next(value);
					},
					error: function(err) {
						hasErrored = true;
						cancelReset();
						resetConnection = handleReset(reset, resetOnError, err);
						dest.error(err);
					},
					complete: function() {
						hasCompleted = true;
						cancelReset();
						resetConnection = handleReset(reset, resetOnComplete);
						dest.complete();
					}
				});
				innerFrom(source).subscribe(connection);
			}
		})(wrapperSource);
	};
}
function handleReset(reset, on) {
	var args = [];
	for (var _i = 2; _i < arguments.length; _i++) args[_i - 2] = arguments[_i];
	if (on === true) {
		reset();
		return;
	}
	if (on === false) return;
	var onSubscriber = new SafeSubscriber({ next: function() {
		onSubscriber.unsubscribe();
		reset();
	} });
	return innerFrom(on.apply(void 0, __spreadArray([], __read(args)))).subscribe(onSubscriber);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/shareReplay.js
function shareReplay(configOrBufferSize, windowTime, scheduler) {
	var _a, _b, _c;
	var bufferSize;
	var refCount = false;
	if (configOrBufferSize && typeof configOrBufferSize === "object") _a = configOrBufferSize.bufferSize, bufferSize = _a === void 0 ? Infinity : _a, _b = configOrBufferSize.windowTime, windowTime = _b === void 0 ? Infinity : _b, _c = configOrBufferSize.refCount, refCount = _c === void 0 ? false : _c, scheduler = configOrBufferSize.scheduler;
	else bufferSize = configOrBufferSize !== null && configOrBufferSize !== void 0 ? configOrBufferSize : Infinity;
	return share({
		connector: function() {
			return new ReplaySubject(bufferSize, windowTime, scheduler);
		},
		resetOnError: true,
		resetOnComplete: false,
		resetOnRefCountZero: refCount
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/single.js
function single(predicate) {
	return operate(function(source, subscriber) {
		var hasValue = false;
		var singleValue;
		var seenValue = false;
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			seenValue = true;
			if (!predicate || predicate(value, index++, source)) {
				hasValue && subscriber.error(new SequenceError("Too many matching values"));
				hasValue = true;
				singleValue = value;
			}
		}, function() {
			if (hasValue) {
				subscriber.next(singleValue);
				subscriber.complete();
			} else subscriber.error(seenValue ? new NotFoundError("No matching values") : new EmptyError());
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/skip.js
function skip(count) {
	return filter(function(_, index) {
		return count <= index;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/skipLast.js
function skipLast(skipCount) {
	return skipCount <= 0 ? identity : operate(function(source, subscriber) {
		var ring = new Array(skipCount);
		var seen = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var valueIndex = seen++;
			if (valueIndex < skipCount) ring[valueIndex] = value;
			else {
				var index = valueIndex % skipCount;
				var oldValue = ring[index];
				ring[index] = value;
				subscriber.next(oldValue);
			}
		}));
		return function() {
			ring = null;
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/skipUntil.js
function skipUntil(notifier) {
	return operate(function(source, subscriber) {
		var taking = false;
		var skipSubscriber = createOperatorSubscriber(subscriber, function() {
			skipSubscriber === null || skipSubscriber === void 0 || skipSubscriber.unsubscribe();
			taking = true;
		}, noop);
		innerFrom(notifier).subscribe(skipSubscriber);
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return taking && subscriber.next(value);
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/skipWhile.js
function skipWhile(predicate) {
	return operate(function(source, subscriber) {
		var taking = false;
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return (taking || (taking = !predicate(value, index++))) && subscriber.next(value);
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/startWith.js
function startWith() {
	var values = [];
	for (var _i = 0; _i < arguments.length; _i++) values[_i] = arguments[_i];
	var scheduler = popScheduler(values);
	return operate(function(source, subscriber) {
		(scheduler ? concat$1(values, source, scheduler) : concat$1(values, source)).subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/switchMap.js
function switchMap(project, resultSelector) {
	return operate(function(source, subscriber) {
		var innerSubscriber = null;
		var index = 0;
		var isComplete = false;
		var checkComplete = function() {
			return isComplete && !innerSubscriber && subscriber.complete();
		};
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			innerSubscriber === null || innerSubscriber === void 0 || innerSubscriber.unsubscribe();
			var innerIndex = 0;
			var outerIndex = index++;
			innerFrom(project(value, outerIndex)).subscribe(innerSubscriber = createOperatorSubscriber(subscriber, function(innerValue) {
				return subscriber.next(resultSelector ? resultSelector(value, innerValue, outerIndex, innerIndex++) : innerValue);
			}, function() {
				innerSubscriber = null;
				checkComplete();
			}));
		}, function() {
			isComplete = true;
			checkComplete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/switchAll.js
function switchAll() {
	return switchMap(identity);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/switchMapTo.js
function switchMapTo(innerObservable, resultSelector) {
	return isFunction(resultSelector) ? switchMap(function() {
		return innerObservable;
	}, resultSelector) : switchMap(function() {
		return innerObservable;
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/switchScan.js
function switchScan(accumulator, seed) {
	return operate(function(source, subscriber) {
		var state = seed;
		switchMap(function(value, index) {
			return accumulator(state, value, index);
		}, function(_, innerValue) {
			return state = innerValue, innerValue;
		})(source).subscribe(subscriber);
		return function() {
			state = null;
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/takeUntil.js
function takeUntil(notifier) {
	return operate(function(source, subscriber) {
		innerFrom(notifier).subscribe(createOperatorSubscriber(subscriber, function() {
			return subscriber.complete();
		}, noop));
		!subscriber.closed && source.subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/takeWhile.js
function takeWhile(predicate, inclusive) {
	if (inclusive === void 0) inclusive = false;
	return operate(function(source, subscriber) {
		var index = 0;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var result = predicate(value, index++);
			(result || inclusive) && subscriber.next(value);
			!result && subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/tap.js
function tap(observerOrNext, error, complete) {
	var tapObserver = isFunction(observerOrNext) || error || complete ? {
		next: observerOrNext,
		error,
		complete
	} : observerOrNext;
	return tapObserver ? operate(function(source, subscriber) {
		var _a;
		(_a = tapObserver.subscribe) === null || _a === void 0 || _a.call(tapObserver);
		var isUnsub = true;
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var _a;
			(_a = tapObserver.next) === null || _a === void 0 || _a.call(tapObserver, value);
			subscriber.next(value);
		}, function() {
			var _a;
			isUnsub = false;
			(_a = tapObserver.complete) === null || _a === void 0 || _a.call(tapObserver);
			subscriber.complete();
		}, function(err) {
			var _a;
			isUnsub = false;
			(_a = tapObserver.error) === null || _a === void 0 || _a.call(tapObserver, err);
			subscriber.error(err);
		}, function() {
			var _a, _b;
			if (isUnsub) (_a = tapObserver.unsubscribe) === null || _a === void 0 || _a.call(tapObserver);
			(_b = tapObserver.finalize) === null || _b === void 0 || _b.call(tapObserver);
		}));
	}) : identity;
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/throttle.js
function throttle(durationSelector, config) {
	return operate(function(source, subscriber) {
		var _a = config !== null && config !== void 0 ? config : {}, _b = _a.leading, leading = _b === void 0 ? true : _b, _c = _a.trailing, trailing = _c === void 0 ? false : _c;
		var hasValue = false;
		var sendValue = null;
		var throttled = null;
		var isComplete = false;
		var endThrottling = function() {
			throttled === null || throttled === void 0 || throttled.unsubscribe();
			throttled = null;
			if (trailing) {
				send();
				isComplete && subscriber.complete();
			}
		};
		var cleanupThrottling = function() {
			throttled = null;
			isComplete && subscriber.complete();
		};
		var startThrottle = function(value) {
			return throttled = innerFrom(durationSelector(value)).subscribe(createOperatorSubscriber(subscriber, endThrottling, cleanupThrottling));
		};
		var send = function() {
			if (hasValue) {
				hasValue = false;
				var value = sendValue;
				sendValue = null;
				subscriber.next(value);
				!isComplete && startThrottle(value);
			}
		};
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			hasValue = true;
			sendValue = value;
			!(throttled && !throttled.closed) && (leading ? send() : startThrottle(value));
		}, function() {
			isComplete = true;
			!(trailing && hasValue && throttled && !throttled.closed) && subscriber.complete();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/throttleTime.js
function throttleTime(duration, scheduler, config) {
	if (scheduler === void 0) scheduler = asyncScheduler;
	var duration$ = timer(duration, scheduler);
	return throttle(function() {
		return duration$;
	}, config);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/timeInterval.js
function timeInterval(scheduler) {
	if (scheduler === void 0) scheduler = asyncScheduler;
	return operate(function(source, subscriber) {
		var last = scheduler.now();
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var now = scheduler.now();
			var interval = now - last;
			last = now;
			subscriber.next(new TimeInterval(value, interval));
		}));
	});
}
var TimeInterval = function() {
	function TimeInterval(value, interval) {
		this.value = value;
		this.interval = interval;
	}
	return TimeInterval;
}();
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/timeoutWith.js
function timeoutWith(due, withObservable, scheduler) {
	var first;
	var each;
	var _with;
	scheduler = scheduler !== null && scheduler !== void 0 ? scheduler : async;
	if (isValidDate(due)) first = due;
	else if (typeof due === "number") each = due;
	if (withObservable) _with = function() {
		return withObservable;
	};
	else throw new TypeError("No observable provided to switch to");
	if (first == null && each == null) throw new TypeError("No timeout provided.");
	return timeout({
		first,
		each,
		scheduler,
		with: _with
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/timestamp.js
function timestamp(timestampProvider) {
	if (timestampProvider === void 0) timestampProvider = dateTimestampProvider;
	return map(function(value) {
		return {
			value,
			timestamp: timestampProvider.now()
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/window.js
function window(windowBoundaries) {
	return operate(function(source, subscriber) {
		var windowSubject = new Subject();
		subscriber.next(windowSubject.asObservable());
		var errorHandler = function(err) {
			windowSubject.error(err);
			subscriber.error(err);
		};
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return windowSubject === null || windowSubject === void 0 ? void 0 : windowSubject.next(value);
		}, function() {
			windowSubject.complete();
			subscriber.complete();
		}, errorHandler));
		innerFrom(windowBoundaries).subscribe(createOperatorSubscriber(subscriber, function() {
			windowSubject.complete();
			subscriber.next(windowSubject = new Subject());
		}, noop, errorHandler));
		return function() {
			windowSubject === null || windowSubject === void 0 || windowSubject.unsubscribe();
			windowSubject = null;
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/windowCount.js
function windowCount(windowSize, startWindowEvery) {
	if (startWindowEvery === void 0) startWindowEvery = 0;
	var startEvery = startWindowEvery > 0 ? startWindowEvery : windowSize;
	return operate(function(source, subscriber) {
		var windows = [new Subject()];
		var count = 0;
		subscriber.next(windows[0].asObservable());
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var e_1, _a;
			try {
				for (var windows_1 = __values(windows), windows_1_1 = windows_1.next(); !windows_1_1.done; windows_1_1 = windows_1.next()) windows_1_1.value.next(value);
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (windows_1_1 && !windows_1_1.done && (_a = windows_1.return)) _a.call(windows_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			var c = count - windowSize + 1;
			if (c >= 0 && c % startEvery === 0) windows.shift().complete();
			if (++count % startEvery === 0) {
				var window_2 = new Subject();
				windows.push(window_2);
				subscriber.next(window_2.asObservable());
			}
		}, function() {
			while (windows.length > 0) windows.shift().complete();
			subscriber.complete();
		}, function(err) {
			while (windows.length > 0) windows.shift().error(err);
			subscriber.error(err);
		}, function() {
			windows = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/windowTime.js
function windowTime(windowTimeSpan) {
	var _a, _b;
	var otherArgs = [];
	for (var _i = 1; _i < arguments.length; _i++) otherArgs[_i - 1] = arguments[_i];
	var scheduler = (_a = popScheduler(otherArgs)) !== null && _a !== void 0 ? _a : asyncScheduler;
	var windowCreationInterval = (_b = otherArgs[0]) !== null && _b !== void 0 ? _b : null;
	var maxWindowSize = otherArgs[1] || Infinity;
	return operate(function(source, subscriber) {
		var windowRecords = [];
		var restartOnClose = false;
		var closeWindow = function(record) {
			var window = record.window, subs = record.subs;
			window.complete();
			subs.unsubscribe();
			arrRemove(windowRecords, record);
			restartOnClose && startWindow();
		};
		var startWindow = function() {
			if (windowRecords) {
				var subs = new Subscription();
				subscriber.add(subs);
				var window_1 = new Subject();
				var record_1 = {
					window: window_1,
					subs,
					seen: 0
				};
				windowRecords.push(record_1);
				subscriber.next(window_1.asObservable());
				executeSchedule(subs, scheduler, function() {
					return closeWindow(record_1);
				}, windowTimeSpan);
			}
		};
		if (windowCreationInterval !== null && windowCreationInterval >= 0) executeSchedule(subscriber, scheduler, startWindow, windowCreationInterval, true);
		else restartOnClose = true;
		startWindow();
		var loop = function(cb) {
			return windowRecords.slice().forEach(cb);
		};
		var terminate = function(cb) {
			loop(function(_a) {
				var window = _a.window;
				return cb(window);
			});
			cb(subscriber);
			subscriber.unsubscribe();
		};
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			loop(function(record) {
				record.window.next(value);
				maxWindowSize <= ++record.seen && closeWindow(record);
			});
		}, function() {
			return terminate(function(consumer) {
				return consumer.complete();
			});
		}, function(err) {
			return terminate(function(consumer) {
				return consumer.error(err);
			});
		}));
		return function() {
			windowRecords = null;
		};
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/windowToggle.js
function windowToggle(openings, closingSelector) {
	return operate(function(source, subscriber) {
		var windows = [];
		var handleError = function(err) {
			while (0 < windows.length) windows.shift().error(err);
			subscriber.error(err);
		};
		innerFrom(openings).subscribe(createOperatorSubscriber(subscriber, function(openValue) {
			var window = new Subject();
			windows.push(window);
			var closingSubscription = new Subscription();
			var closeWindow = function() {
				arrRemove(windows, window);
				window.complete();
				closingSubscription.unsubscribe();
			};
			var closingNotifier;
			try {
				closingNotifier = innerFrom(closingSelector(openValue));
			} catch (err) {
				handleError(err);
				return;
			}
			subscriber.next(window.asObservable());
			closingSubscription.add(closingNotifier.subscribe(createOperatorSubscriber(subscriber, closeWindow, noop, handleError)));
		}, noop));
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			var e_1, _a;
			var windowsCopy = windows.slice();
			try {
				for (var windowsCopy_1 = __values(windowsCopy), windowsCopy_1_1 = windowsCopy_1.next(); !windowsCopy_1_1.done; windowsCopy_1_1 = windowsCopy_1.next()) windowsCopy_1_1.value.next(value);
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (windowsCopy_1_1 && !windowsCopy_1_1.done && (_a = windowsCopy_1.return)) _a.call(windowsCopy_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
		}, function() {
			while (0 < windows.length) windows.shift().complete();
			subscriber.complete();
		}, handleError, function() {
			while (0 < windows.length) windows.shift().unsubscribe();
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/windowWhen.js
function windowWhen(closingSelector) {
	return operate(function(source, subscriber) {
		var window;
		var closingSubscriber;
		var handleError = function(err) {
			window.error(err);
			subscriber.error(err);
		};
		var openWindow = function() {
			closingSubscriber === null || closingSubscriber === void 0 || closingSubscriber.unsubscribe();
			window === null || window === void 0 || window.complete();
			window = new Subject();
			subscriber.next(window.asObservable());
			var closingNotifier;
			try {
				closingNotifier = innerFrom(closingSelector());
			} catch (err) {
				handleError(err);
				return;
			}
			closingNotifier.subscribe(closingSubscriber = createOperatorSubscriber(subscriber, openWindow, openWindow, handleError));
		};
		openWindow();
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			return window.next(value);
		}, function() {
			window.complete();
			subscriber.complete();
		}, handleError, function() {
			closingSubscriber === null || closingSubscriber === void 0 || closingSubscriber.unsubscribe();
			window = null;
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/withLatestFrom.js
function withLatestFrom() {
	var inputs = [];
	for (var _i = 0; _i < arguments.length; _i++) inputs[_i] = arguments[_i];
	var project = popResultSelector(inputs);
	return operate(function(source, subscriber) {
		var len = inputs.length;
		var otherValues = new Array(len);
		var hasValue = inputs.map(function() {
			return false;
		});
		var ready = false;
		var _loop_1 = function(i) {
			innerFrom(inputs[i]).subscribe(createOperatorSubscriber(subscriber, function(value) {
				otherValues[i] = value;
				if (!ready && !hasValue[i]) {
					hasValue[i] = true;
					(ready = hasValue.every(identity)) && (hasValue = null);
				}
			}, noop));
		};
		for (var i = 0; i < len; i++) _loop_1(i);
		source.subscribe(createOperatorSubscriber(subscriber, function(value) {
			if (ready) {
				var values = __spreadArray([value], __read(otherValues));
				subscriber.next(project ? project.apply(void 0, __spreadArray([], __read(values))) : values);
			}
		}));
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/zipAll.js
function zipAll(project) {
	return joinAllInternals(zip$1, project);
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/zip.js
function zip() {
	var sources = [];
	for (var _i = 0; _i < arguments.length; _i++) sources[_i] = arguments[_i];
	return operate(function(source, subscriber) {
		zip$1.apply(void 0, __spreadArray([source], __read(sources))).subscribe(subscriber);
	});
}
//#endregion
//#region node_modules/rxjs/dist/esm5/internal/operators/zipWith.js
function zipWith() {
	var otherInputs = [];
	for (var _i = 0; _i < arguments.length; _i++) otherInputs[_i] = arguments[_i];
	return zip.apply(void 0, __spreadArray([], __read(otherInputs)));
}
//#endregion
export { flatMap as $, SafeSubscriber as $n, not as $t, sequenceEqual as A, popNumber as An, count as At, publishLast as B, AsyncAction as Bn, toArray as Bt, skipWhile as C, from as Cn, delayWhen as Ct, single as D, observeOn as Dn, defaultIfEmpty as Dt, skip as E, subscribeOn as En, take as Et, retry as F, empty as Fn, concatMap as Ft, onErrorResumeNext as G, ObjectUnsubscribedError as Gn, bufferTime as Gt, publish as H, ReplaySubject as Hn, catchError as Ht, repeatWhen as I, async as In, combineLatestWith as It, min as J, createOperatorSubscriber as Jn, auditTime as Jt, onErrorResumeNextWith as K, ConnectableObservable as Kn, bufferCount as Kt, repeat as L, asyncScheduler as Ln, combineLatest as Lt, sampleTime as M, popScheduler as Mn, concatWith as Mt, sample as N, isScheduler as Nn, concat as Nt, shareReplay as O, innerFrom as On, debounceTime as Ot, retryWhen as P, EMPTY as Pn, concatMapTo as Pt, mergeMapTo as Q, observable as Qn, filter as Qt, raceWith as R, AsyncScheduler as Rn, combineAll as Rt, startWith as S, of as Sn, delay as St, skipLast as T, scheduleIterable as Tn, ignoreElements as Tt, pluck as U, BehaviorSubject as Un, bufferWhen as Ut, publishBehavior as V, AsyncSubject as Vn, reduce as Vt, pairwise as W, Subject as Wn, bufferToggle as Wt, merge as X, pipe as Xn, zip$1 as Xt, mergeWith as Y, Observable as Yn, audit as Yt, mergeScan as Z, identity as Zn, race as Zt, takeUntil as _, ArgumentOutOfRangeError as _n, throwIfEmpty as _t, windowWhen as a, concatAll as an, isFunction as ar, groupBy as at, switchAll as b, NotificationKind as bn, distinct as bt, windowCount as c, combineLatest$1 as cn, __read as cr, find as ct, timeoutWith as d, mapOneOrManyArgs as dn, exhaust as dt, onErrorResumeNext$1 as en, Subscriber as er, max as et, timeInterval as f, map as fn, exhaustAll as ft, takeWhile as g, NotFoundError as gn, elementAt as gt, tap as h, SequenceError as hn, endWith as ht, withLatestFrom as i, concat$1 as in, UnsubscriptionError as ir, isEmpty as it, scan as j, popResultSelector as jn, connect as jt, share as k, isArrayLike as kn, debounce as kt, window as l, createObject as ln, __spreadArray as lr, finalize as lt, throttle as m, timeout as mn, every as mt, zip as n, interval as nn, config as nr, last as nt, windowToggle as o, mergeAll as on, __extends as or, first as ot, throttleTime as p, TimeoutError as pn, exhaustMap as pt, multicast as q, refCount as qn, buffer as qt, zipAll as r, timer as rn, Subscription as rr, takeLast as rt, windowTime as s, mergeMap as sn, __generator as sr, findIndex as st, zipWith as t, argsOrArgArray as tn, noop as tr, materialize as tt, timestamp as u, argsArgArrayOrObject as un, expand as ut, switchScan as v, EmptyError as vn, distinctUntilKeyChanged as vt, skipUntil as w, scheduled as wn, mapTo as wt, switchMap as x, throwError as xn, dematerialize as xt, switchMapTo as y, Notification as yn, distinctUntilChanged as yt, publishReplay as z, Scheduler as zn, combineLatestAll as zt };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiemlwV2l0aC1Ea3JuTjc5UC5qcyIsIm5hbWVzIjpbIlN5bWJvbF9vYnNlcnZhYmxlIiwiaGlnaGVyT3JkZXJSZWZDb3VudCIsImxhc3QiLCJTeW1ib2xfb2JzZXJ2YWJsZSIsIlN5bWJvbF9pdGVyYXRvciIsIlN5bWJvbF9vYnNlcnZhYmxlIiwiaXRlcmF0b3IiLCJTeW1ib2xfaXRlcmF0b3IiLCJpc0FycmF5IiwiaXNBcnJheSIsImNvbWJpbmVMYXRlc3QiLCJjb25jYXQiLCJhc3luY1NjaGVkdWxlciIsIm9uRXJyb3JSZXN1bWVOZXh0IiwiemlwIiwiY29tYmluZUxhdGVzdCIsImNvbmNhdCIsImNvbmNhdCIsIm9FUk5DcmVhdGUiLCJjb25jYXQiLCJ6aXAiXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvdHNsaWIvdHNsaWIuZXM2Lm1qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2lzRnVuY3Rpb24uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9jcmVhdGVFcnJvckNsYXNzLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3V0aWwvVW5zdWJzY3JpcHRpb25FcnJvci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2FyclJlbW92ZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9TdWJzY3JpcHRpb24uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvY29uZmlnLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3NjaGVkdWxlci90aW1lb3V0UHJvdmlkZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9yZXBvcnRVbmhhbmRsZWRFcnJvci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL25vb3AuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvTm90aWZpY2F0aW9uRmFjdG9yaWVzLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3V0aWwvZXJyb3JDb250ZXh0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL1N1YnNjcmliZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc3ltYm9sL29ic2VydmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pZGVudGl0eS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL3BpcGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvT2JzZXJ2YWJsZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2xpZnQuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL09wZXJhdG9yU3Vic2NyaWJlci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcmVmQ291bnQuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9Db25uZWN0YWJsZU9ic2VydmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9PYmplY3RVbnN1YnNjcmliZWRFcnJvci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9TdWJqZWN0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL0JlaGF2aW9yU3ViamVjdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvZGF0ZVRpbWVzdGFtcFByb3ZpZGVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL1JlcGxheVN1YmplY3QuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvQXN5bmNTdWJqZWN0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3NjaGVkdWxlci9BY3Rpb24uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL2ludGVydmFsUHJvdmlkZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL0FzeW5jQWN0aW9uLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL1NjaGVkdWxlci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZXIvQXN5bmNTY2hlZHVsZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVyL2FzeW5jLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29ic2VydmFibGUvZW1wdHkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pc1NjaGVkdWxlci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2FyZ3MuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pc0FycmF5TGlrZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2lzUHJvbWlzZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2lzSW50ZXJvcE9ic2VydmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pc0FzeW5jSXRlcmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC90aHJvd1Vub2JzZXJ2YWJsZUVycm9yLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3N5bWJvbC9pdGVyYXRvci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2lzSXRlcmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pc1JlYWRhYmxlU3RyZWFtTGlrZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2lubmVyRnJvbS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2V4ZWN1dGVTY2hlZHVsZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvb2JzZXJ2ZU9uLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zdWJzY3JpYmVPbi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZWQvc2NoZWR1bGVPYnNlcnZhYmxlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3NjaGVkdWxlZC9zY2hlZHVsZVByb21pc2UuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVkL3NjaGVkdWxlQXJyYXkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVkL3NjaGVkdWxlSXRlcmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVkL3NjaGVkdWxlQXN5bmNJdGVyYWJsZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9zY2hlZHVsZWQvc2NoZWR1bGVSZWFkYWJsZVN0cmVhbUxpa2UuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvc2NoZWR1bGVkL3NjaGVkdWxlZC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2Zyb20uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9vZi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL3Rocm93RXJyb3IuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvTm90aWZpY2F0aW9uLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3V0aWwvRW1wdHlFcnJvci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL0FyZ3VtZW50T3V0T2ZSYW5nZUVycm9yLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3V0aWwvTm90Rm91bmRFcnJvci5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL1NlcXVlbmNlRXJyb3IuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9pc0RhdGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3RpbWVvdXQuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL21hcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL21hcE9uZU9yTWFueUFyZ3MuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9hcmdzQXJnQXJyYXlPck9iamVjdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC91dGlsL2NyZWF0ZU9iamVjdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2NvbWJpbmVMYXRlc3QuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL21lcmdlSW50ZXJuYWxzLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9tZXJnZU1hcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvbWVyZ2VBbGwuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2NvbmNhdEFsbC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2NvbmNhdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL3RpbWVyLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29ic2VydmFibGUvaW50ZXJ2YWwuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvdXRpbC9hcmdzT3JBcmdBcnJheS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL29uRXJyb3JSZXN1bWVOZXh0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL3V0aWwvbm90LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9maWx0ZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb2JzZXJ2YWJsZS9yYWNlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29ic2VydmFibGUvemlwLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9hdWRpdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvYXVkaXRUaW1lLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9idWZmZXIuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2J1ZmZlckNvdW50LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9idWZmZXJUaW1lLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9idWZmZXJUb2dnbGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2J1ZmZlcldoZW4uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2NhdGNoRXJyb3IuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3NjYW5JbnRlcm5hbHMuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3JlZHVjZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvdG9BcnJheS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvam9pbkFsbEludGVybmFscy5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvY29tYmluZUxhdGVzdEFsbC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvY29tYmluZUFsbC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvY29tYmluZUxhdGVzdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvY29tYmluZUxhdGVzdFdpdGguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2NvbmNhdE1hcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvY29uY2F0TWFwVG8uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2NvbmNhdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvY29uY2F0V2l0aC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vYnNlcnZhYmxlL2Zyb21TdWJzY3JpYmFibGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2Nvbm5lY3QuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2NvdW50LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9kZWJvdW5jZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvZGVib3VuY2VUaW1lLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9kZWZhdWx0SWZFbXB0eS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvdGFrZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvaWdub3JlRWxlbWVudHMuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL21hcFRvLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9kZWxheVdoZW4uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2RlbGF5LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9kZW1hdGVyaWFsaXplLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9kaXN0aW5jdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvZGlzdGluY3RVbnRpbENoYW5nZWQuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2Rpc3RpbmN0VW50aWxLZXlDaGFuZ2VkLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy90aHJvd0lmRW1wdHkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2VsZW1lbnRBdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvZW5kV2l0aC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvZXZlcnkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2V4aGF1c3RNYXAuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2V4aGF1c3RBbGwuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2V4aGF1c3QuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2V4cGFuZC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvZmluYWxpemUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2ZpbmQuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2ZpbmRJbmRleC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvZmlyc3QuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2dyb3VwQnkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL2lzRW1wdHkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3Rha2VMYXN0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9sYXN0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9tYXRlcmlhbGl6ZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvbWF4LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9mbGF0TWFwLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9tZXJnZU1hcFRvLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9tZXJnZVNjYW4uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL21lcmdlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9tZXJnZVdpdGguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL21pbi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvbXVsdGljYXN0LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9vbkVycm9yUmVzdW1lTmV4dFdpdGguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3BhaXJ3aXNlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9wbHVjay5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcHVibGlzaC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcHVibGlzaEJlaGF2aW9yLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9wdWJsaXNoTGFzdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcHVibGlzaFJlcGxheS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcmFjZVdpdGguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3JlcGVhdC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcmVwZWF0V2hlbi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvcmV0cnkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3JldHJ5V2hlbi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc2FtcGxlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zYW1wbGVUaW1lLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zY2FuLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zZXF1ZW5jZUVxdWFsLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zaGFyZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc2hhcmVSZXBsYXkuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3NpbmdsZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc2tpcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc2tpcExhc3QuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3NraXBVbnRpbC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc2tpcFdoaWxlLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zdGFydFdpdGguanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3N3aXRjaE1hcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc3dpdGNoQWxsLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy9zd2l0Y2hNYXBUby5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvc3dpdGNoU2Nhbi5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvdGFrZVVudGlsLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy90YWtlV2hpbGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3RhcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvdGhyb3R0bGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3Rocm90dGxlVGltZS5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvdGltZUludGVydmFsLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy90aW1lb3V0V2l0aC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvdGltZXN0YW1wLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy93aW5kb3cuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3dpbmRvd0NvdW50LmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy93aW5kb3dUaW1lLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy93aW5kb3dUb2dnbGUuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3dpbmRvd1doZW4uanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3dpdGhMYXRlc3RGcm9tLmpzIiwiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3J4anMvZGlzdC9lc201L2ludGVybmFsL29wZXJhdG9ycy96aXBBbGwuanMiLCIuLi8uLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvcnhqcy9kaXN0L2VzbTUvaW50ZXJuYWwvb3BlcmF0b3JzL3ppcC5qcyIsIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9yeGpzL2Rpc3QvZXNtNS9pbnRlcm5hbC9vcGVyYXRvcnMvemlwV2l0aC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqXG5Db3B5cmlnaHQgKGMpIE1pY3Jvc29mdCBDb3Jwb3JhdGlvbi5cblxuUGVybWlzc2lvbiB0byB1c2UsIGNvcHksIG1vZGlmeSwgYW5kL29yIGRpc3RyaWJ1dGUgdGhpcyBzb2Z0d2FyZSBmb3IgYW55XG5wdXJwb3NlIHdpdGggb3Igd2l0aG91dCBmZWUgaXMgaGVyZWJ5IGdyYW50ZWQuXG5cblRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIgQU5EIFRIRSBBVVRIT1IgRElTQ0xBSU1TIEFMTCBXQVJSQU5USUVTIFdJVEhcblJFR0FSRCBUTyBUSElTIFNPRlRXQVJFIElOQ0xVRElORyBBTEwgSU1QTElFRCBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWVxuQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUiBBTlkgU1BFQ0lBTCwgRElSRUNULFxuSU5ESVJFQ1QsIE9SIENPTlNFUVVFTlRJQUwgREFNQUdFUyBPUiBBTlkgREFNQUdFUyBXSEFUU09FVkVSIFJFU1VMVElORyBGUk9NXG5MT1NTIE9GIFVTRSwgREFUQSBPUiBQUk9GSVRTLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgTkVHTElHRU5DRSBPUlxuT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFVTRSBPUlxuUEVSRk9STUFOQ0UgT0YgVEhJUyBTT0ZUV0FSRS5cbioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqICovXG4vKiBnbG9iYWwgUmVmbGVjdCwgUHJvbWlzZSwgU3VwcHJlc3NlZEVycm9yLCBTeW1ib2wsIEl0ZXJhdG9yICovXG5cbnZhciBleHRlbmRTdGF0aWNzID0gZnVuY3Rpb24oZCwgYikge1xuICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XG4gICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XG4gICAgICBmdW5jdGlvbiAoZCwgYikgeyBmb3IgKHZhciBwIGluIGIpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoYiwgcCkpIGRbcF0gPSBiW3BdOyB9O1xuICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2V4dGVuZHMoZCwgYikge1xuICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNsYXNzIGV4dGVuZHMgdmFsdWUgXCIgKyBTdHJpbmcoYikgKyBcIiBpcyBub3QgYSBjb25zdHJ1Y3RvciBvciBudWxsXCIpO1xuICBleHRlbmRTdGF0aWNzKGQsIGIpO1xuICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cbiAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xufVxuXG5leHBvcnQgdmFyIF9fYXNzaWduID0gZnVuY3Rpb24oKSB7XG4gIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XG4gICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICBzID0gYXJndW1lbnRzW2ldO1xuICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XG4gICAgICB9XG4gICAgICByZXR1cm4gdDtcbiAgfVxuICByZXR1cm4gX19hc3NpZ24uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVzdChzLCBlKSB7XG4gIHZhciB0ID0ge307XG4gIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxuICAgICAgdFtwXSA9IHNbcF07XG4gIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXG4gICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xuICAgICAgfVxuICByZXR1cm4gdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcbiAgdmFyIGMgPSBhcmd1bWVudHMubGVuZ3RoLCByID0gYyA8IDMgPyB0YXJnZXQgOiBkZXNjID09PSBudWxsID8gZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBrZXkpIDogZGVzYywgZDtcbiAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcbiAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcbiAgcmV0dXJuIGMgPiAzICYmIHIgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCByKSwgcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fcGFyYW0ocGFyYW1JbmRleCwgZGVjb3JhdG9yKSB7XG4gIHJldHVybiBmdW5jdGlvbiAodGFyZ2V0LCBrZXkpIHsgZGVjb3JhdG9yKHRhcmdldCwga2V5LCBwYXJhbUluZGV4KTsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19lc0RlY29yYXRlKGN0b3IsIGRlc2NyaXB0b3JJbiwgZGVjb3JhdG9ycywgY29udGV4dEluLCBpbml0aWFsaXplcnMsIGV4dHJhSW5pdGlhbGl6ZXJzKSB7XG4gIGZ1bmN0aW9uIGFjY2VwdChmKSB7IGlmIChmICE9PSB2b2lkIDAgJiYgdHlwZW9mIGYgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkZ1bmN0aW9uIGV4cGVjdGVkXCIpOyByZXR1cm4gZjsgfVxuICB2YXIga2luZCA9IGNvbnRleHRJbi5raW5kLCBrZXkgPSBraW5kID09PSBcImdldHRlclwiID8gXCJnZXRcIiA6IGtpbmQgPT09IFwic2V0dGVyXCIgPyBcInNldFwiIDogXCJ2YWx1ZVwiO1xuICB2YXIgdGFyZ2V0ID0gIWRlc2NyaXB0b3JJbiAmJiBjdG9yID8gY29udGV4dEluW1wic3RhdGljXCJdID8gY3RvciA6IGN0b3IucHJvdG90eXBlIDogbnVsbDtcbiAgdmFyIGRlc2NyaXB0b3IgPSBkZXNjcmlwdG9ySW4gfHwgKHRhcmdldCA/IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBjb250ZXh0SW4ubmFtZSkgOiB7fSk7XG4gIHZhciBfLCBkb25lID0gZmFsc2U7XG4gIGZvciAodmFyIGkgPSBkZWNvcmF0b3JzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICB2YXIgY29udGV4dCA9IHt9O1xuICAgICAgZm9yICh2YXIgcCBpbiBjb250ZXh0SW4pIGNvbnRleHRbcF0gPSBwID09PSBcImFjY2Vzc1wiID8ge30gOiBjb250ZXh0SW5bcF07XG4gICAgICBmb3IgKHZhciBwIGluIGNvbnRleHRJbi5hY2Nlc3MpIGNvbnRleHQuYWNjZXNzW3BdID0gY29udGV4dEluLmFjY2Vzc1twXTtcbiAgICAgIGNvbnRleHQuYWRkSW5pdGlhbGl6ZXIgPSBmdW5jdGlvbiAoZikgeyBpZiAoZG9uZSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBhZGQgaW5pdGlhbGl6ZXJzIGFmdGVyIGRlY29yYXRpb24gaGFzIGNvbXBsZXRlZFwiKTsgZXh0cmFJbml0aWFsaXplcnMucHVzaChhY2NlcHQoZiB8fCBudWxsKSk7IH07XG4gICAgICB2YXIgcmVzdWx0ID0gKDAsIGRlY29yYXRvcnNbaV0pKGtpbmQgPT09IFwiYWNjZXNzb3JcIiA/IHsgZ2V0OiBkZXNjcmlwdG9yLmdldCwgc2V0OiBkZXNjcmlwdG9yLnNldCB9IDogZGVzY3JpcHRvcltrZXldLCBjb250ZXh0KTtcbiAgICAgIGlmIChraW5kID09PSBcImFjY2Vzc29yXCIpIHtcbiAgICAgICAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApIGNvbnRpbnVlO1xuICAgICAgICAgIGlmIChyZXN1bHQgPT09IG51bGwgfHwgdHlwZW9mIHJlc3VsdCAhPT0gXCJvYmplY3RcIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBleHBlY3RlZFwiKTtcbiAgICAgICAgICBpZiAoXyA9IGFjY2VwdChyZXN1bHQuZ2V0KSkgZGVzY3JpcHRvci5nZXQgPSBfO1xuICAgICAgICAgIGlmIChfID0gYWNjZXB0KHJlc3VsdC5zZXQpKSBkZXNjcmlwdG9yLnNldCA9IF87XG4gICAgICAgICAgaWYgKF8gPSBhY2NlcHQocmVzdWx0LmluaXQpKSBpbml0aWFsaXplcnMudW5zaGlmdChfKTtcbiAgICAgIH1cbiAgICAgIGVsc2UgaWYgKF8gPSBhY2NlcHQocmVzdWx0KSkge1xuICAgICAgICAgIGlmIChraW5kID09PSBcImZpZWxkXCIpIGluaXRpYWxpemVycy51bnNoaWZ0KF8pO1xuICAgICAgICAgIGVsc2UgZGVzY3JpcHRvcltrZXldID0gXztcbiAgICAgIH1cbiAgfVxuICBpZiAodGFyZ2V0KSBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBjb250ZXh0SW4ubmFtZSwgZGVzY3JpcHRvcik7XG4gIGRvbmUgPSB0cnVlO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fcnVuSW5pdGlhbGl6ZXJzKHRoaXNBcmcsIGluaXRpYWxpemVycywgdmFsdWUpIHtcbiAgdmFyIHVzZVZhbHVlID0gYXJndW1lbnRzLmxlbmd0aCA+IDI7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgaW5pdGlhbGl6ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YWx1ZSA9IHVzZVZhbHVlID8gaW5pdGlhbGl6ZXJzW2ldLmNhbGwodGhpc0FyZywgdmFsdWUpIDogaW5pdGlhbGl6ZXJzW2ldLmNhbGwodGhpc0FyZyk7XG4gIH1cbiAgcmV0dXJuIHVzZVZhbHVlID8gdmFsdWUgOiB2b2lkIDA7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gX19wcm9wS2V5KHgpIHtcbiAgcmV0dXJuIHR5cGVvZiB4ID09PSBcInN5bWJvbFwiID8geCA6IFwiXCIuY29uY2F0KHgpO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fc2V0RnVuY3Rpb25OYW1lKGYsIG5hbWUsIHByZWZpeCkge1xuICBpZiAodHlwZW9mIG5hbWUgPT09IFwic3ltYm9sXCIpIG5hbWUgPSBuYW1lLmRlc2NyaXB0aW9uID8gXCJbXCIuY29uY2F0KG5hbWUuZGVzY3JpcHRpb24sIFwiXVwiKSA6IFwiXCI7XG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoZiwgXCJuYW1lXCIsIHsgY29uZmlndXJhYmxlOiB0cnVlLCB2YWx1ZTogcHJlZml4ID8gXCJcIi5jb25jYXQocHJlZml4LCBcIiBcIiwgbmFtZSkgOiBuYW1lIH0pO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fbWV0YWRhdGEobWV0YWRhdGFLZXksIG1ldGFkYXRhVmFsdWUpIHtcbiAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0Lm1ldGFkYXRhID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBSZWZsZWN0Lm1ldGFkYXRhKG1ldGFkYXRhS2V5LCBtZXRhZGF0YVZhbHVlKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXRlcih0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcbiAgZnVuY3Rpb24gYWRvcHQodmFsdWUpIHsgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUCA/IHZhbHVlIDogbmV3IFAoZnVuY3Rpb24gKHJlc29sdmUpIHsgcmVzb2x2ZSh2YWx1ZSk7IH0pOyB9XG4gIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgZnVuY3Rpb24gcmVqZWN0ZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3JbXCJ0aHJvd1wiXSh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xuICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fZ2VuZXJhdG9yKHRoaXNBcmcsIGJvZHkpIHtcbiAgdmFyIF8gPSB7IGxhYmVsOiAwLCBzZW50OiBmdW5jdGlvbigpIHsgaWYgKHRbMF0gJiAxKSB0aHJvdyB0WzFdOyByZXR1cm4gdFsxXTsgfSwgdHJ5czogW10sIG9wczogW10gfSwgZiwgeSwgdCwgZyA9IE9iamVjdC5jcmVhdGUoKHR5cGVvZiBJdGVyYXRvciA9PT0gXCJmdW5jdGlvblwiID8gSXRlcmF0b3IgOiBPYmplY3QpLnByb3RvdHlwZSk7XG4gIHJldHVybiBnLm5leHQgPSB2ZXJiKDApLCBnW1widGhyb3dcIl0gPSB2ZXJiKDEpLCBnW1wicmV0dXJuXCJdID0gdmVyYigyKSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xuICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cbiAgZnVuY3Rpb24gc3RlcChvcCkge1xuICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xuICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcbiAgICAgICAgICBpZiAoZiA9IDEsIHkgJiYgKHQgPSBvcFswXSAmIDIgPyB5W1wicmV0dXJuXCJdIDogb3BbMF0gPyB5W1widGhyb3dcIl0gfHwgKCh0ID0geVtcInJldHVyblwiXSkgJiYgdC5jYWxsKHkpLCAwKSA6IHkubmV4dCkgJiYgISh0ID0gdC5jYWxsKHksIG9wWzFdKSkuZG9uZSkgcmV0dXJuIHQ7XG4gICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xuICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcbiAgICAgICAgICAgICAgY2FzZSAwOiBjYXNlIDE6IHQgPSBvcDsgYnJlYWs7XG4gICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XG4gICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcbiAgICAgICAgICAgICAgY2FzZSA3OiBvcCA9IF8ub3BzLnBvcCgpOyBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XG4gICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDMgJiYgKCF0IHx8IChvcFsxXSA+IHRbMF0gJiYgb3BbMV0gPCB0WzNdKSkpIHsgXy5sYWJlbCA9IG9wWzFdOyBicmVhazsgfVxuICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgICBpZiAodFsyXSkgXy5vcHMucG9wKCk7XG4gICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBvcCA9IGJvZHkuY2FsbCh0aGlzQXJnLCBfKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cbiAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xuICB9XG59XG5cbmV4cG9ydCB2YXIgX19jcmVhdGVCaW5kaW5nID0gT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICB2YXIgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IobSwgayk7XG4gIGlmICghZGVzYyB8fCAoXCJnZXRcIiBpbiBkZXNjID8gIW0uX19lc01vZHVsZSA6IGRlc2Mud3JpdGFibGUgfHwgZGVzYy5jb25maWd1cmFibGUpKSB7XG4gICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xuICB9XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCBrMiwgZGVzYyk7XG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICBvW2syXSA9IG1ba107XG59KTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fZXhwb3J0U3RhcihtLCBvKSB7XG4gIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobywgcCkpIF9fY3JlYXRlQmluZGluZyhvLCBtLCBwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcbiAgdmFyIHMgPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgU3ltYm9sLml0ZXJhdG9yLCBtID0gcyAmJiBvW3NdLCBpID0gMDtcbiAgaWYgKG0pIHJldHVybiBtLmNhbGwobyk7XG4gIGlmIChvICYmIHR5cGVvZiBvLmxlbmd0aCA9PT0gXCJudW1iZXJcIikgcmV0dXJuIHtcbiAgICAgIG5leHQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xuICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBvICYmIG9baSsrXSwgZG9uZTogIW8gfTtcbiAgICAgIH1cbiAgfTtcbiAgdGhyb3cgbmV3IFR5cGVFcnJvcihzID8gXCJPYmplY3QgaXMgbm90IGl0ZXJhYmxlLlwiIDogXCJTeW1ib2wuaXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gX19yZWFkKG8sIG4pIHtcbiAgdmFyIG0gPSB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgb1tTeW1ib2wuaXRlcmF0b3JdO1xuICBpZiAoIW0pIHJldHVybiBvO1xuICB2YXIgaSA9IG0uY2FsbChvKSwgciwgYXIgPSBbXSwgZTtcbiAgdHJ5IHtcbiAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xuICB9XG4gIGNhdGNoIChlcnJvcikgeyBlID0geyBlcnJvcjogZXJyb3IgfTsgfVxuICBmaW5hbGx5IHtcbiAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKHIgJiYgIXIuZG9uZSAmJiAobSA9IGlbXCJyZXR1cm5cIl0pKSBtLmNhbGwoaSk7XG4gICAgICB9XG4gICAgICBmaW5hbGx5IHsgaWYgKGUpIHRocm93IGUuZXJyb3I7IH1cbiAgfVxuICByZXR1cm4gYXI7XG59XG5cbi8qKiBAZGVwcmVjYXRlZCAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9fc3ByZWFkKCkge1xuICBmb3IgKHZhciBhciA9IFtdLCBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKylcbiAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcbiAgcmV0dXJuIGFyO1xufVxuXG4vKiogQGRlcHJlY2F0ZWQgKi9cbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZEFycmF5cygpIHtcbiAgZm9yICh2YXIgcyA9IDAsIGkgPSAwLCBpbCA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBpbDsgaSsrKSBzICs9IGFyZ3VtZW50c1tpXS5sZW5ndGg7XG4gIGZvciAodmFyIHIgPSBBcnJheShzKSwgayA9IDAsIGkgPSAwOyBpIDwgaWw7IGkrKylcbiAgICAgIGZvciAodmFyIGEgPSBhcmd1bWVudHNbaV0sIGogPSAwLCBqbCA9IGEubGVuZ3RoOyBqIDwgamw7IGorKywgaysrKVxuICAgICAgICAgIHJba10gPSBhW2pdO1xuICByZXR1cm4gcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fc3ByZWFkQXJyYXkodG8sIGZyb20sIHBhY2spIHtcbiAgaWYgKHBhY2sgfHwgYXJndW1lbnRzLmxlbmd0aCA9PT0gMikgZm9yICh2YXIgaSA9IDAsIGwgPSBmcm9tLmxlbmd0aCwgYXI7IGkgPCBsOyBpKyspIHtcbiAgICAgIGlmIChhciB8fCAhKGkgaW4gZnJvbSkpIHtcbiAgICAgICAgICBpZiAoIWFyKSBhciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20sIDAsIGkpO1xuICAgICAgICAgIGFyW2ldID0gZnJvbVtpXTtcbiAgICAgIH1cbiAgfVxuICByZXR1cm4gdG8uY29uY2F0KGFyIHx8IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20pKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xuICByZXR1cm4gdGhpcyBpbnN0YW5jZW9mIF9fYXdhaXQgPyAodGhpcy52ID0gdiwgdGhpcykgOiBuZXcgX19hd2FpdCh2KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYXN5bmNHZW5lcmF0b3IodGhpc0FyZywgX2FyZ3VtZW50cywgZ2VuZXJhdG9yKSB7XG4gIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XG4gIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XG4gIHJldHVybiBpID0gT2JqZWN0LmNyZWF0ZSgodHlwZW9mIEFzeW5jSXRlcmF0b3IgPT09IFwiZnVuY3Rpb25cIiA/IEFzeW5jSXRlcmF0b3IgOiBPYmplY3QpLnByb3RvdHlwZSksIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiksIHZlcmIoXCJyZXR1cm5cIiwgYXdhaXRSZXR1cm4pLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XG4gIGZ1bmN0aW9uIGF3YWl0UmV0dXJuKGYpIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBQcm9taXNlLnJlc29sdmUodikudGhlbihmLCByZWplY3QpOyB9OyB9XG4gIGZ1bmN0aW9uIHZlcmIobiwgZikgeyBpZiAoZ1tuXSkgeyBpW25dID0gZnVuY3Rpb24gKHYpIHsgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChhLCBiKSB7IHEucHVzaChbbiwgdiwgYSwgYl0pID4gMSB8fCByZXN1bWUobiwgdik7IH0pOyB9OyBpZiAoZikgaVtuXSA9IGYoaVtuXSk7IH0gfVxuICBmdW5jdGlvbiByZXN1bWUobiwgdikgeyB0cnkgeyBzdGVwKGdbbl0odikpOyB9IGNhdGNoIChlKSB7IHNldHRsZShxWzBdWzNdLCBlKTsgfSB9XG4gIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxuICBmdW5jdGlvbiBmdWxmaWxsKHZhbHVlKSB7IHJlc3VtZShcIm5leHRcIiwgdmFsdWUpOyB9XG4gIGZ1bmN0aW9uIHJlamVjdCh2YWx1ZSkgeyByZXN1bWUoXCJ0aHJvd1wiLCB2YWx1ZSk7IH1cbiAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XG4gIHZhciBpLCBwO1xuICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIsIGZ1bmN0aW9uIChlKSB7IHRocm93IGU7IH0pLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9LCBpO1xuICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBmYWxzZSB9IDogZiA/IGYodikgOiB2OyB9IDogZjsgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY1ZhbHVlcyhvKSB7XG4gIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XG4gIHZhciBtID0gb1tTeW1ib2wuYXN5bmNJdGVyYXRvcl0sIGk7XG4gIHJldHVybiBtID8gbS5jYWxsKG8pIDogKG8gPSB0eXBlb2YgX192YWx1ZXMgPT09IFwiZnVuY3Rpb25cIiA/IF9fdmFsdWVzKG8pIDogb1tTeW1ib2wuaXRlcmF0b3JdKCksIGkgPSB7fSwgdmVyYihcIm5leHRcIiksIHZlcmIoXCJ0aHJvd1wiKSwgdmVyYihcInJldHVyblwiKSwgaVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9LCBpKTtcbiAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxuICBmdW5jdGlvbiBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCBkLCB2KSB7IFByb21pc2UucmVzb2x2ZSh2KS50aGVuKGZ1bmN0aW9uKHYpIHsgcmVzb2x2ZSh7IHZhbHVlOiB2LCBkb25lOiBkIH0pOyB9LCByZWplY3QpOyB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX21ha2VUZW1wbGF0ZU9iamVjdChjb29rZWQsIHJhdykge1xuICBpZiAoT2JqZWN0LmRlZmluZVByb3BlcnR5KSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb29rZWQsIFwicmF3XCIsIHsgdmFsdWU6IHJhdyB9KTsgfSBlbHNlIHsgY29va2VkLnJhdyA9IHJhdzsgfVxuICByZXR1cm4gY29va2VkO1xufTtcblxudmFyIF9fc2V0TW9kdWxlRGVmYXVsdCA9IE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgdikge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgXCJkZWZhdWx0XCIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHYgfSk7XG59KSA6IGZ1bmN0aW9uKG8sIHYpIHtcbiAgb1tcImRlZmF1bHRcIl0gPSB2O1xufTtcblxudmFyIG93bktleXMgPSBmdW5jdGlvbihvKSB7XG4gIG93bktleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyB8fCBmdW5jdGlvbiAobykge1xuICAgIHZhciBhciA9IFtdO1xuICAgIGZvciAodmFyIGsgaW4gbykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvLCBrKSkgYXJbYXIubGVuZ3RoXSA9IGs7XG4gICAgcmV0dXJuIGFyO1xuICB9O1xuICByZXR1cm4gb3duS2V5cyhvKTtcbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydFN0YXIobW9kKSB7XG4gIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XG4gIHZhciByZXN1bHQgPSB7fTtcbiAgaWYgKG1vZCAhPSBudWxsKSBmb3IgKHZhciBrID0gb3duS2V5cyhtb2QpLCBpID0gMDsgaSA8IGsubGVuZ3RoOyBpKyspIGlmIChrW2ldICE9PSBcImRlZmF1bHRcIikgX19jcmVhdGVCaW5kaW5nKHJlc3VsdCwgbW9kLCBrW2ldKTtcbiAgX19zZXRNb2R1bGVEZWZhdWx0KHJlc3VsdCwgbW9kKTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0RGVmYXVsdChtb2QpIHtcbiAgcmV0dXJuIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpID8gbW9kIDogeyBkZWZhdWx0OiBtb2QgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fY2xhc3NQcml2YXRlRmllbGRHZXQocmVjZWl2ZXIsIHN0YXRlLCBraW5kLCBmKSB7XG4gIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcbiAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgcmVhZCBwcml2YXRlIG1lbWJlciBmcm9tIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gIHJldHVybiBraW5kID09PSBcIm1cIiA/IGYgOiBraW5kID09PSBcImFcIiA/IGYuY2FsbChyZWNlaXZlcikgOiBmID8gZi52YWx1ZSA6IHN0YXRlLmdldChyZWNlaXZlcik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KHJlY2VpdmVyLCBzdGF0ZSwgdmFsdWUsIGtpbmQsIGYpIHtcbiAgaWYgKGtpbmQgPT09IFwibVwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBtZXRob2QgaXMgbm90IHdyaXRhYmxlXCIpO1xuICBpZiAoa2luZCA9PT0gXCJhXCIgJiYgIWYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGFjY2Vzc29yIHdhcyBkZWZpbmVkIHdpdGhvdXQgYSBzZXR0ZXJcIik7XG4gIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHdyaXRlIHByaXZhdGUgbWVtYmVyIHRvIGFuIG9iamVjdCB3aG9zZSBjbGFzcyBkaWQgbm90IGRlY2xhcmUgaXRcIik7XG4gIHJldHVybiAoa2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIsIHZhbHVlKSA6IGYgPyBmLnZhbHVlID0gdmFsdWUgOiBzdGF0ZS5zZXQocmVjZWl2ZXIsIHZhbHVlKSksIHZhbHVlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZEluKHN0YXRlLCByZWNlaXZlcikge1xuICBpZiAocmVjZWl2ZXIgPT09IG51bGwgfHwgKHR5cGVvZiByZWNlaXZlciAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgcmVjZWl2ZXIgIT09IFwiZnVuY3Rpb25cIikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgdXNlICdpbicgb3BlcmF0b3Igb24gbm9uLW9iamVjdFwiKTtcbiAgcmV0dXJuIHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgPT09IHN0YXRlIDogc3RhdGUuaGFzKHJlY2VpdmVyKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIF9fYWRkRGlzcG9zYWJsZVJlc291cmNlKGVudiwgdmFsdWUsIGFzeW5jKSB7XG4gIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdm9pZCAwKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBleHBlY3RlZC5cIik7XG4gICAgdmFyIGRpc3Bvc2UsIGlubmVyO1xuICAgIGlmIChhc3luYykge1xuICAgICAgaWYgKCFTeW1ib2wuYXN5bmNEaXNwb3NlKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmFzeW5jRGlzcG9zZSBpcyBub3QgZGVmaW5lZC5cIik7XG4gICAgICBkaXNwb3NlID0gdmFsdWVbU3ltYm9sLmFzeW5jRGlzcG9zZV07XG4gICAgfVxuICAgIGlmIChkaXNwb3NlID09PSB2b2lkIDApIHtcbiAgICAgIGlmICghU3ltYm9sLmRpc3Bvc2UpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuZGlzcG9zZSBpcyBub3QgZGVmaW5lZC5cIik7XG4gICAgICBkaXNwb3NlID0gdmFsdWVbU3ltYm9sLmRpc3Bvc2VdO1xuICAgICAgaWYgKGFzeW5jKSBpbm5lciA9IGRpc3Bvc2U7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgZGlzcG9zZSAhPT0gXCJmdW5jdGlvblwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiT2JqZWN0IG5vdCBkaXNwb3NhYmxlLlwiKTtcbiAgICBpZiAoaW5uZXIpIGRpc3Bvc2UgPSBmdW5jdGlvbigpIHsgdHJ5IHsgaW5uZXIuY2FsbCh0aGlzKTsgfSBjYXRjaCAoZSkgeyByZXR1cm4gUHJvbWlzZS5yZWplY3QoZSk7IH0gfTtcbiAgICBlbnYuc3RhY2sucHVzaCh7IHZhbHVlOiB2YWx1ZSwgZGlzcG9zZTogZGlzcG9zZSwgYXN5bmM6IGFzeW5jIH0pO1xuICB9XG4gIGVsc2UgaWYgKGFzeW5jKSB7XG4gICAgZW52LnN0YWNrLnB1c2goeyBhc3luYzogdHJ1ZSB9KTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5cbnZhciBfU3VwcHJlc3NlZEVycm9yID0gdHlwZW9mIFN1cHByZXNzZWRFcnJvciA9PT0gXCJmdW5jdGlvblwiID8gU3VwcHJlc3NlZEVycm9yIDogZnVuY3Rpb24gKGVycm9yLCBzdXBwcmVzc2VkLCBtZXNzYWdlKSB7XG4gIHZhciBlID0gbmV3IEVycm9yKG1lc3NhZ2UpO1xuICByZXR1cm4gZS5uYW1lID0gXCJTdXBwcmVzc2VkRXJyb3JcIiwgZS5lcnJvciA9IGVycm9yLCBlLnN1cHByZXNzZWQgPSBzdXBwcmVzc2VkLCBlO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIF9fZGlzcG9zZVJlc291cmNlcyhlbnYpIHtcbiAgZnVuY3Rpb24gZmFpbChlKSB7XG4gICAgZW52LmVycm9yID0gZW52Lmhhc0Vycm9yID8gbmV3IF9TdXBwcmVzc2VkRXJyb3IoZSwgZW52LmVycm9yLCBcIkFuIGVycm9yIHdhcyBzdXBwcmVzc2VkIGR1cmluZyBkaXNwb3NhbC5cIikgOiBlO1xuICAgIGVudi5oYXNFcnJvciA9IHRydWU7XG4gIH1cbiAgdmFyIHIsIHMgPSAwO1xuICBmdW5jdGlvbiBuZXh0KCkge1xuICAgIHdoaWxlIChyID0gZW52LnN0YWNrLnBvcCgpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoIXIuYXN5bmMgJiYgcyA9PT0gMSkgcmV0dXJuIHMgPSAwLCBlbnYuc3RhY2sucHVzaChyKSwgUHJvbWlzZS5yZXNvbHZlKCkudGhlbihuZXh0KTtcbiAgICAgICAgaWYgKHIuZGlzcG9zZSkge1xuICAgICAgICAgIHZhciByZXN1bHQgPSByLmRpc3Bvc2UuY2FsbChyLnZhbHVlKTtcbiAgICAgICAgICBpZiAoci5hc3luYykgcmV0dXJuIHMgfD0gMiwgUHJvbWlzZS5yZXNvbHZlKHJlc3VsdCkudGhlbihuZXh0LCBmdW5jdGlvbihlKSB7IGZhaWwoZSk7IHJldHVybiBuZXh0KCk7IH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgcyB8PSAxO1xuICAgICAgfVxuICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgZmFpbChlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHMgPT09IDEpIHJldHVybiBlbnYuaGFzRXJyb3IgPyBQcm9taXNlLnJlamVjdChlbnYuZXJyb3IpIDogUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgaWYgKGVudi5oYXNFcnJvcikgdGhyb3cgZW52LmVycm9yO1xuICB9XG4gIHJldHVybiBuZXh0KCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBfX3Jld3JpdGVSZWxhdGl2ZUltcG9ydEV4dGVuc2lvbihwYXRoLCBwcmVzZXJ2ZUpzeCkge1xuICBpZiAodHlwZW9mIHBhdGggPT09IFwic3RyaW5nXCIgJiYgL15cXC5cXC4/XFwvLy50ZXN0KHBhdGgpKSB7XG4gICAgICByZXR1cm4gcGF0aC5yZXBsYWNlKC9cXC4odHN4KSR8KCg/OlxcLmQpPykoKD86XFwuW14uL10rPyk/KVxcLihbY21dPyl0cyQvaSwgZnVuY3Rpb24gKG0sIHRzeCwgZCwgZXh0LCBjbSkge1xuICAgICAgICAgIHJldHVybiB0c3ggPyBwcmVzZXJ2ZUpzeCA/IFwiLmpzeFwiIDogXCIuanNcIiA6IGQgJiYgKCFleHQgfHwgIWNtKSA/IG0gOiAoZCArIGV4dCArIFwiLlwiICsgY20udG9Mb3dlckNhc2UoKSArIFwianNcIik7XG4gICAgICB9KTtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICBfX2V4dGVuZHMsXG4gIF9fYXNzaWduLFxuICBfX3Jlc3QsXG4gIF9fZGVjb3JhdGUsXG4gIF9fcGFyYW0sXG4gIF9fZXNEZWNvcmF0ZSxcbiAgX19ydW5Jbml0aWFsaXplcnMsXG4gIF9fcHJvcEtleSxcbiAgX19zZXRGdW5jdGlvbk5hbWUsXG4gIF9fbWV0YWRhdGEsXG4gIF9fYXdhaXRlcixcbiAgX19nZW5lcmF0b3IsXG4gIF9fY3JlYXRlQmluZGluZyxcbiAgX19leHBvcnRTdGFyLFxuICBfX3ZhbHVlcyxcbiAgX19yZWFkLFxuICBfX3NwcmVhZCxcbiAgX19zcHJlYWRBcnJheXMsXG4gIF9fc3ByZWFkQXJyYXksXG4gIF9fYXdhaXQsXG4gIF9fYXN5bmNHZW5lcmF0b3IsXG4gIF9fYXN5bmNEZWxlZ2F0b3IsXG4gIF9fYXN5bmNWYWx1ZXMsXG4gIF9fbWFrZVRlbXBsYXRlT2JqZWN0LFxuICBfX2ltcG9ydFN0YXIsXG4gIF9faW1wb3J0RGVmYXVsdCxcbiAgX19jbGFzc1ByaXZhdGVGaWVsZEdldCxcbiAgX19jbGFzc1ByaXZhdGVGaWVsZFNldCxcbiAgX19jbGFzc1ByaXZhdGVGaWVsZEluLFxuICBfX2FkZERpc3Bvc2FibGVSZXNvdXJjZSxcbiAgX19kaXNwb3NlUmVzb3VyY2VzLFxuICBfX3Jld3JpdGVSZWxhdGl2ZUltcG9ydEV4dGVuc2lvbixcbn07XG4iLCJleHBvcnQgZnVuY3Rpb24gaXNGdW5jdGlvbih2YWx1ZSkge1xuICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbic7XG59XG4iLCJleHBvcnQgZnVuY3Rpb24gY3JlYXRlRXJyb3JDbGFzcyhjcmVhdGVJbXBsKSB7XG4gICAgdmFyIF9zdXBlciA9IGZ1bmN0aW9uIChpbnN0YW5jZSkge1xuICAgICAgICBFcnJvci5jYWxsKGluc3RhbmNlKTtcbiAgICAgICAgaW5zdGFuY2Uuc3RhY2sgPSBuZXcgRXJyb3IoKS5zdGFjaztcbiAgICB9O1xuICAgIHZhciBjdG9yRnVuYyA9IGNyZWF0ZUltcGwoX3N1cGVyKTtcbiAgICBjdG9yRnVuYy5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEVycm9yLnByb3RvdHlwZSk7XG4gICAgY3RvckZ1bmMucHJvdG90eXBlLmNvbnN0cnVjdG9yID0gY3RvckZ1bmM7XG4gICAgcmV0dXJuIGN0b3JGdW5jO1xufVxuIiwiaW1wb3J0IHsgY3JlYXRlRXJyb3JDbGFzcyB9IGZyb20gJy4vY3JlYXRlRXJyb3JDbGFzcyc7XG5leHBvcnQgdmFyIFVuc3Vic2NyaXB0aW9uRXJyb3IgPSBjcmVhdGVFcnJvckNsYXNzKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gVW5zdWJzY3JpcHRpb25FcnJvckltcGwoZXJyb3JzKSB7XG4gICAgICAgIF9zdXBlcih0aGlzKTtcbiAgICAgICAgdGhpcy5tZXNzYWdlID0gZXJyb3JzXG4gICAgICAgICAgICA/IGVycm9ycy5sZW5ndGggKyBcIiBlcnJvcnMgb2NjdXJyZWQgZHVyaW5nIHVuc3Vic2NyaXB0aW9uOlxcblwiICsgZXJyb3JzLm1hcChmdW5jdGlvbiAoZXJyLCBpKSB7IHJldHVybiBpICsgMSArIFwiKSBcIiArIGVyci50b1N0cmluZygpOyB9KS5qb2luKCdcXG4gICcpXG4gICAgICAgICAgICA6ICcnO1xuICAgICAgICB0aGlzLm5hbWUgPSAnVW5zdWJzY3JpcHRpb25FcnJvcic7XG4gICAgICAgIHRoaXMuZXJyb3JzID0gZXJyb3JzO1xuICAgIH07XG59KTtcbiIsImV4cG9ydCBmdW5jdGlvbiBhcnJSZW1vdmUoYXJyLCBpdGVtKSB7XG4gICAgaWYgKGFycikge1xuICAgICAgICB2YXIgaW5kZXggPSBhcnIuaW5kZXhPZihpdGVtKTtcbiAgICAgICAgMCA8PSBpbmRleCAmJiBhcnIuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXksIF9fdmFsdWVzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi91dGlsL2lzRnVuY3Rpb24nO1xuaW1wb3J0IHsgVW5zdWJzY3JpcHRpb25FcnJvciB9IGZyb20gJy4vdXRpbC9VbnN1YnNjcmlwdGlvbkVycm9yJztcbmltcG9ydCB7IGFyclJlbW92ZSB9IGZyb20gJy4vdXRpbC9hcnJSZW1vdmUnO1xudmFyIFN1YnNjcmlwdGlvbiA9IChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gU3Vic2NyaXB0aW9uKGluaXRpYWxUZWFyZG93bikge1xuICAgICAgICB0aGlzLmluaXRpYWxUZWFyZG93biA9IGluaXRpYWxUZWFyZG93bjtcbiAgICAgICAgdGhpcy5jbG9zZWQgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5fcGFyZW50YWdlID0gbnVsbDtcbiAgICAgICAgdGhpcy5fZmluYWxpemVycyA9IG51bGw7XG4gICAgfVxuICAgIFN1YnNjcmlwdGlvbi5wcm90b3R5cGUudW5zdWJzY3JpYmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBlXzEsIF9hLCBlXzIsIF9iO1xuICAgICAgICB2YXIgZXJyb3JzO1xuICAgICAgICBpZiAoIXRoaXMuY2xvc2VkKSB7XG4gICAgICAgICAgICB0aGlzLmNsb3NlZCA9IHRydWU7XG4gICAgICAgICAgICB2YXIgX3BhcmVudGFnZSA9IHRoaXMuX3BhcmVudGFnZTtcbiAgICAgICAgICAgIGlmIChfcGFyZW50YWdlKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fcGFyZW50YWdlID0gbnVsbDtcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShfcGFyZW50YWdlKSkge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX3BhcmVudGFnZV8xID0gX192YWx1ZXMoX3BhcmVudGFnZSksIF9wYXJlbnRhZ2VfMV8xID0gX3BhcmVudGFnZV8xLm5leHQoKTsgIV9wYXJlbnRhZ2VfMV8xLmRvbmU7IF9wYXJlbnRhZ2VfMV8xID0gX3BhcmVudGFnZV8xLm5leHQoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwYXJlbnRfMSA9IF9wYXJlbnRhZ2VfMV8xLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcmVudF8xLnJlbW92ZSh0aGlzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXRjaCAoZV8xXzEpIHsgZV8xID0geyBlcnJvcjogZV8xXzEgfTsgfVxuICAgICAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF9wYXJlbnRhZ2VfMV8xICYmICFfcGFyZW50YWdlXzFfMS5kb25lICYmIChfYSA9IF9wYXJlbnRhZ2VfMS5yZXR1cm4pKSBfYS5jYWxsKF9wYXJlbnRhZ2VfMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIF9wYXJlbnRhZ2UucmVtb3ZlKHRoaXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBpbml0aWFsRmluYWxpemVyID0gdGhpcy5pbml0aWFsVGVhcmRvd247XG4gICAgICAgICAgICBpZiAoaXNGdW5jdGlvbihpbml0aWFsRmluYWxpemVyKSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGluaXRpYWxGaW5hbGl6ZXIoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JzID0gZSBpbnN0YW5jZW9mIFVuc3Vic2NyaXB0aW9uRXJyb3IgPyBlLmVycm9ycyA6IFtlXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgX2ZpbmFsaXplcnMgPSB0aGlzLl9maW5hbGl6ZXJzO1xuICAgICAgICAgICAgaWYgKF9maW5hbGl6ZXJzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZmluYWxpemVycyA9IG51bGw7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2ZpbmFsaXplcnNfMSA9IF9fdmFsdWVzKF9maW5hbGl6ZXJzKSwgX2ZpbmFsaXplcnNfMV8xID0gX2ZpbmFsaXplcnNfMS5uZXh0KCk7ICFfZmluYWxpemVyc18xXzEuZG9uZTsgX2ZpbmFsaXplcnNfMV8xID0gX2ZpbmFsaXplcnNfMS5uZXh0KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBmaW5hbGl6ZXIgPSBfZmluYWxpemVyc18xXzEudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4ZWNGaW5hbGl6ZXIoZmluYWxpemVyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMgPSBlcnJvcnMgIT09IG51bGwgJiYgZXJyb3JzICE9PSB2b2lkIDAgPyBlcnJvcnMgOiBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyIGluc3RhbmNlb2YgVW5zdWJzY3JpcHRpb25FcnJvcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMgPSBfX3NwcmVhZEFycmF5KF9fc3ByZWFkQXJyYXkoW10sIF9fcmVhZChlcnJvcnMpKSwgX19yZWFkKGVyci5lcnJvcnMpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5wdXNoKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlXzJfMSkgeyBlXzIgPSB7IGVycm9yOiBlXzJfMSB9OyB9XG4gICAgICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoX2ZpbmFsaXplcnNfMV8xICYmICFfZmluYWxpemVyc18xXzEuZG9uZSAmJiAoX2IgPSBfZmluYWxpemVyc18xLnJldHVybikpIF9iLmNhbGwoX2ZpbmFsaXplcnNfMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZmluYWxseSB7IGlmIChlXzIpIHRocm93IGVfMi5lcnJvcjsgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChlcnJvcnMpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVW5zdWJzY3JpcHRpb25FcnJvcihlcnJvcnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBTdWJzY3JpcHRpb24ucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uICh0ZWFyZG93bikge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmICh0ZWFyZG93biAmJiB0ZWFyZG93biAhPT0gdGhpcykge1xuICAgICAgICAgICAgaWYgKHRoaXMuY2xvc2VkKSB7XG4gICAgICAgICAgICAgICAgZXhlY0ZpbmFsaXplcih0ZWFyZG93bik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAodGVhcmRvd24gaW5zdGFuY2VvZiBTdWJzY3JpcHRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRlYXJkb3duLmNsb3NlZCB8fCB0ZWFyZG93bi5faGFzUGFyZW50KHRoaXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGVhcmRvd24uX2FkZFBhcmVudCh0aGlzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgKHRoaXMuX2ZpbmFsaXplcnMgPSAoX2EgPSB0aGlzLl9maW5hbGl6ZXJzKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBbXSkucHVzaCh0ZWFyZG93bik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFN1YnNjcmlwdGlvbi5wcm90b3R5cGUuX2hhc1BhcmVudCA9IGZ1bmN0aW9uIChwYXJlbnQpIHtcbiAgICAgICAgdmFyIF9wYXJlbnRhZ2UgPSB0aGlzLl9wYXJlbnRhZ2U7XG4gICAgICAgIHJldHVybiBfcGFyZW50YWdlID09PSBwYXJlbnQgfHwgKEFycmF5LmlzQXJyYXkoX3BhcmVudGFnZSkgJiYgX3BhcmVudGFnZS5pbmNsdWRlcyhwYXJlbnQpKTtcbiAgICB9O1xuICAgIFN1YnNjcmlwdGlvbi5wcm90b3R5cGUuX2FkZFBhcmVudCA9IGZ1bmN0aW9uIChwYXJlbnQpIHtcbiAgICAgICAgdmFyIF9wYXJlbnRhZ2UgPSB0aGlzLl9wYXJlbnRhZ2U7XG4gICAgICAgIHRoaXMuX3BhcmVudGFnZSA9IEFycmF5LmlzQXJyYXkoX3BhcmVudGFnZSkgPyAoX3BhcmVudGFnZS5wdXNoKHBhcmVudCksIF9wYXJlbnRhZ2UpIDogX3BhcmVudGFnZSA/IFtfcGFyZW50YWdlLCBwYXJlbnRdIDogcGFyZW50O1xuICAgIH07XG4gICAgU3Vic2NyaXB0aW9uLnByb3RvdHlwZS5fcmVtb3ZlUGFyZW50ID0gZnVuY3Rpb24gKHBhcmVudCkge1xuICAgICAgICB2YXIgX3BhcmVudGFnZSA9IHRoaXMuX3BhcmVudGFnZTtcbiAgICAgICAgaWYgKF9wYXJlbnRhZ2UgPT09IHBhcmVudCkge1xuICAgICAgICAgICAgdGhpcy5fcGFyZW50YWdlID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KF9wYXJlbnRhZ2UpKSB7XG4gICAgICAgICAgICBhcnJSZW1vdmUoX3BhcmVudGFnZSwgcGFyZW50KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgU3Vic2NyaXB0aW9uLnByb3RvdHlwZS5yZW1vdmUgPSBmdW5jdGlvbiAodGVhcmRvd24pIHtcbiAgICAgICAgdmFyIF9maW5hbGl6ZXJzID0gdGhpcy5fZmluYWxpemVycztcbiAgICAgICAgX2ZpbmFsaXplcnMgJiYgYXJyUmVtb3ZlKF9maW5hbGl6ZXJzLCB0ZWFyZG93bik7XG4gICAgICAgIGlmICh0ZWFyZG93biBpbnN0YW5jZW9mIFN1YnNjcmlwdGlvbikge1xuICAgICAgICAgICAgdGVhcmRvd24uX3JlbW92ZVBhcmVudCh0aGlzKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgU3Vic2NyaXB0aW9uLkVNUFRZID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGVtcHR5ID0gbmV3IFN1YnNjcmlwdGlvbigpO1xuICAgICAgICBlbXB0eS5jbG9zZWQgPSB0cnVlO1xuICAgICAgICByZXR1cm4gZW1wdHk7XG4gICAgfSkoKTtcbiAgICByZXR1cm4gU3Vic2NyaXB0aW9uO1xufSgpKTtcbmV4cG9ydCB7IFN1YnNjcmlwdGlvbiB9O1xuZXhwb3J0IHZhciBFTVBUWV9TVUJTQ1JJUFRJT04gPSBTdWJzY3JpcHRpb24uRU1QVFk7XG5leHBvcnQgZnVuY3Rpb24gaXNTdWJzY3JpcHRpb24odmFsdWUpIHtcbiAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2YgU3Vic2NyaXB0aW9uIHx8XG4gICAgICAgICh2YWx1ZSAmJiAnY2xvc2VkJyBpbiB2YWx1ZSAmJiBpc0Z1bmN0aW9uKHZhbHVlLnJlbW92ZSkgJiYgaXNGdW5jdGlvbih2YWx1ZS5hZGQpICYmIGlzRnVuY3Rpb24odmFsdWUudW5zdWJzY3JpYmUpKSk7XG59XG5mdW5jdGlvbiBleGVjRmluYWxpemVyKGZpbmFsaXplcikge1xuICAgIGlmIChpc0Z1bmN0aW9uKGZpbmFsaXplcikpIHtcbiAgICAgICAgZmluYWxpemVyKCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBmaW5hbGl6ZXIudW5zdWJzY3JpYmUoKTtcbiAgICB9XG59XG4iLCJleHBvcnQgdmFyIGNvbmZpZyA9IHtcbiAgICBvblVuaGFuZGxlZEVycm9yOiBudWxsLFxuICAgIG9uU3RvcHBlZE5vdGlmaWNhdGlvbjogbnVsbCxcbiAgICBQcm9taXNlOiB1bmRlZmluZWQsXG4gICAgdXNlRGVwcmVjYXRlZFN5bmNocm9ub3VzRXJyb3JIYW5kbGluZzogZmFsc2UsXG4gICAgdXNlRGVwcmVjYXRlZE5leHRDb250ZXh0OiBmYWxzZSxcbn07XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmV4cG9ydCB2YXIgdGltZW91dFByb3ZpZGVyID0ge1xuICAgIHNldFRpbWVvdXQ6IGZ1bmN0aW9uIChoYW5kbGVyLCB0aW1lb3V0KSB7XG4gICAgICAgIHZhciBhcmdzID0gW107XG4gICAgICAgIGZvciAodmFyIF9pID0gMjsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICBhcmdzW19pIC0gMl0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICB9XG4gICAgICAgIHZhciBkZWxlZ2F0ZSA9IHRpbWVvdXRQcm92aWRlci5kZWxlZ2F0ZTtcbiAgICAgICAgaWYgKGRlbGVnYXRlID09PSBudWxsIHx8IGRlbGVnYXRlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBkZWxlZ2F0ZS5zZXRUaW1lb3V0KSB7XG4gICAgICAgICAgICByZXR1cm4gZGVsZWdhdGUuc2V0VGltZW91dC5hcHBseShkZWxlZ2F0ZSwgX19zcHJlYWRBcnJheShbaGFuZGxlciwgdGltZW91dF0sIF9fcmVhZChhcmdzKSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzZXRUaW1lb3V0LmFwcGx5KHZvaWQgMCwgX19zcHJlYWRBcnJheShbaGFuZGxlciwgdGltZW91dF0sIF9fcmVhZChhcmdzKSkpO1xuICAgIH0sXG4gICAgY2xlYXJUaW1lb3V0OiBmdW5jdGlvbiAoaGFuZGxlKSB7XG4gICAgICAgIHZhciBkZWxlZ2F0ZSA9IHRpbWVvdXRQcm92aWRlci5kZWxlZ2F0ZTtcbiAgICAgICAgcmV0dXJuICgoZGVsZWdhdGUgPT09IG51bGwgfHwgZGVsZWdhdGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRlbGVnYXRlLmNsZWFyVGltZW91dCkgfHwgY2xlYXJUaW1lb3V0KShoYW5kbGUpO1xuICAgIH0sXG4gICAgZGVsZWdhdGU6IHVuZGVmaW5lZCxcbn07XG4iLCJpbXBvcnQgeyBjb25maWcgfSBmcm9tICcuLi9jb25maWcnO1xuaW1wb3J0IHsgdGltZW91dFByb3ZpZGVyIH0gZnJvbSAnLi4vc2NoZWR1bGVyL3RpbWVvdXRQcm92aWRlcic7XG5leHBvcnQgZnVuY3Rpb24gcmVwb3J0VW5oYW5kbGVkRXJyb3IoZXJyKSB7XG4gICAgdGltZW91dFByb3ZpZGVyLnNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgb25VbmhhbmRsZWRFcnJvciA9IGNvbmZpZy5vblVuaGFuZGxlZEVycm9yO1xuICAgICAgICBpZiAob25VbmhhbmRsZWRFcnJvcikge1xuICAgICAgICAgICAgb25VbmhhbmRsZWRFcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9XG4gICAgfSk7XG59XG4iLCJleHBvcnQgZnVuY3Rpb24gbm9vcCgpIHsgfVxuIiwiZXhwb3J0IHZhciBDT01QTEVURV9OT1RJRklDQVRJT04gPSAoZnVuY3Rpb24gKCkgeyByZXR1cm4gY3JlYXRlTm90aWZpY2F0aW9uKCdDJywgdW5kZWZpbmVkLCB1bmRlZmluZWQpOyB9KSgpO1xuZXhwb3J0IGZ1bmN0aW9uIGVycm9yTm90aWZpY2F0aW9uKGVycm9yKSB7XG4gICAgcmV0dXJuIGNyZWF0ZU5vdGlmaWNhdGlvbignRScsIHVuZGVmaW5lZCwgZXJyb3IpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG5leHROb3RpZmljYXRpb24odmFsdWUpIHtcbiAgICByZXR1cm4gY3JlYXRlTm90aWZpY2F0aW9uKCdOJywgdmFsdWUsIHVuZGVmaW5lZCk7XG59XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTm90aWZpY2F0aW9uKGtpbmQsIHZhbHVlLCBlcnJvcikge1xuICAgIHJldHVybiB7XG4gICAgICAgIGtpbmQ6IGtpbmQsXG4gICAgICAgIHZhbHVlOiB2YWx1ZSxcbiAgICAgICAgZXJyb3I6IGVycm9yLFxuICAgIH07XG59XG4iLCJpbXBvcnQgeyBjb25maWcgfSBmcm9tICcuLi9jb25maWcnO1xudmFyIGNvbnRleHQgPSBudWxsO1xuZXhwb3J0IGZ1bmN0aW9uIGVycm9yQ29udGV4dChjYikge1xuICAgIGlmIChjb25maWcudXNlRGVwcmVjYXRlZFN5bmNocm9ub3VzRXJyb3JIYW5kbGluZykge1xuICAgICAgICB2YXIgaXNSb290ID0gIWNvbnRleHQ7XG4gICAgICAgIGlmIChpc1Jvb3QpIHtcbiAgICAgICAgICAgIGNvbnRleHQgPSB7IGVycm9yVGhyb3duOiBmYWxzZSwgZXJyb3I6IG51bGwgfTtcbiAgICAgICAgfVxuICAgICAgICBjYigpO1xuICAgICAgICBpZiAoaXNSb290KSB7XG4gICAgICAgICAgICB2YXIgX2EgPSBjb250ZXh0LCBlcnJvclRocm93biA9IF9hLmVycm9yVGhyb3duLCBlcnJvciA9IF9hLmVycm9yO1xuICAgICAgICAgICAgY29udGV4dCA9IG51bGw7XG4gICAgICAgICAgICBpZiAoZXJyb3JUaHJvd24pIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY2IoKTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gY2FwdHVyZUVycm9yKGVycikge1xuICAgIGlmIChjb25maWcudXNlRGVwcmVjYXRlZFN5bmNocm9ub3VzRXJyb3JIYW5kbGluZyAmJiBjb250ZXh0KSB7XG4gICAgICAgIGNvbnRleHQuZXJyb3JUaHJvd24gPSB0cnVlO1xuICAgICAgICBjb250ZXh0LmVycm9yID0gZXJyO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4vdXRpbC9pc0Z1bmN0aW9uJztcbmltcG9ydCB7IGlzU3Vic2NyaXB0aW9uLCBTdWJzY3JpcHRpb24gfSBmcm9tICcuL1N1YnNjcmlwdGlvbic7XG5pbXBvcnQgeyBjb25maWcgfSBmcm9tICcuL2NvbmZpZyc7XG5pbXBvcnQgeyByZXBvcnRVbmhhbmRsZWRFcnJvciB9IGZyb20gJy4vdXRpbC9yZXBvcnRVbmhhbmRsZWRFcnJvcic7XG5pbXBvcnQgeyBub29wIH0gZnJvbSAnLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgbmV4dE5vdGlmaWNhdGlvbiwgZXJyb3JOb3RpZmljYXRpb24sIENPTVBMRVRFX05PVElGSUNBVElPTiB9IGZyb20gJy4vTm90aWZpY2F0aW9uRmFjdG9yaWVzJztcbmltcG9ydCB7IHRpbWVvdXRQcm92aWRlciB9IGZyb20gJy4vc2NoZWR1bGVyL3RpbWVvdXRQcm92aWRlcic7XG5pbXBvcnQgeyBjYXB0dXJlRXJyb3IgfSBmcm9tICcuL3V0aWwvZXJyb3JDb250ZXh0JztcbnZhciBTdWJzY3JpYmVyID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoU3Vic2NyaWJlciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBTdWJzY3JpYmVyKGRlc3RpbmF0aW9uKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLmlzU3RvcHBlZCA9IGZhbHNlO1xuICAgICAgICBpZiAoZGVzdGluYXRpb24pIHtcbiAgICAgICAgICAgIF90aGlzLmRlc3RpbmF0aW9uID0gZGVzdGluYXRpb247XG4gICAgICAgICAgICBpZiAoaXNTdWJzY3JpcHRpb24oZGVzdGluYXRpb24pKSB7XG4gICAgICAgICAgICAgICAgZGVzdGluYXRpb24uYWRkKF90aGlzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIF90aGlzLmRlc3RpbmF0aW9uID0gRU1QVFlfT0JTRVJWRVI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBTdWJzY3JpYmVyLmNyZWF0ZSA9IGZ1bmN0aW9uIChuZXh0LCBlcnJvciwgY29tcGxldGUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBTYWZlU3Vic2NyaWJlcihuZXh0LCBlcnJvciwgY29tcGxldGUpO1xuICAgIH07XG4gICAgU3Vic2NyaWJlci5wcm90b3R5cGUubmV4dCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICBpZiAodGhpcy5pc1N0b3BwZWQpIHtcbiAgICAgICAgICAgIGhhbmRsZVN0b3BwZWROb3RpZmljYXRpb24obmV4dE5vdGlmaWNhdGlvbih2YWx1ZSksIHRoaXMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5fbmV4dCh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFN1YnNjcmliZXIucHJvdG90eXBlLmVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAgICAgICBpZiAodGhpcy5pc1N0b3BwZWQpIHtcbiAgICAgICAgICAgIGhhbmRsZVN0b3BwZWROb3RpZmljYXRpb24oZXJyb3JOb3RpZmljYXRpb24oZXJyKSwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmlzU3RvcHBlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLl9lcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBTdWJzY3JpYmVyLnByb3RvdHlwZS5jb21wbGV0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHRoaXMuaXNTdG9wcGVkKSB7XG4gICAgICAgICAgICBoYW5kbGVTdG9wcGVkTm90aWZpY2F0aW9uKENPTVBMRVRFX05PVElGSUNBVElPTiwgdGhpcyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmlzU3RvcHBlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLl9jb21wbGV0ZSgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBTdWJzY3JpYmVyLnByb3RvdHlwZS51bnN1YnNjcmliZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKCF0aGlzLmNsb3NlZCkge1xuICAgICAgICAgICAgdGhpcy5pc1N0b3BwZWQgPSB0cnVlO1xuICAgICAgICAgICAgX3N1cGVyLnByb3RvdHlwZS51bnN1YnNjcmliZS5jYWxsKHRoaXMpO1xuICAgICAgICAgICAgdGhpcy5kZXN0aW5hdGlvbiA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFN1YnNjcmliZXIucHJvdG90eXBlLl9uZXh0ID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuZGVzdGluYXRpb24ubmV4dCh2YWx1ZSk7XG4gICAgfTtcbiAgICBTdWJzY3JpYmVyLnByb3RvdHlwZS5fZXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLmRlc3RpbmF0aW9uLmVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICB0aGlzLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFN1YnNjcmliZXIucHJvdG90eXBlLl9jb21wbGV0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuZGVzdGluYXRpb24uY29tcGxldGUoKTtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHRoaXMudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIFN1YnNjcmliZXI7XG59KFN1YnNjcmlwdGlvbikpO1xuZXhwb3J0IHsgU3Vic2NyaWJlciB9O1xudmFyIF9iaW5kID0gRnVuY3Rpb24ucHJvdG90eXBlLmJpbmQ7XG5mdW5jdGlvbiBiaW5kKGZuLCB0aGlzQXJnKSB7XG4gICAgcmV0dXJuIF9iaW5kLmNhbGwoZm4sIHRoaXNBcmcpO1xufVxudmFyIENvbnN1bWVyT2JzZXJ2ZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIENvbnN1bWVyT2JzZXJ2ZXIocGFydGlhbE9ic2VydmVyKSB7XG4gICAgICAgIHRoaXMucGFydGlhbE9ic2VydmVyID0gcGFydGlhbE9ic2VydmVyO1xuICAgIH1cbiAgICBDb25zdW1lck9ic2VydmVyLnByb3RvdHlwZS5uZXh0ID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgIHZhciBwYXJ0aWFsT2JzZXJ2ZXIgPSB0aGlzLnBhcnRpYWxPYnNlcnZlcjtcbiAgICAgICAgaWYgKHBhcnRpYWxPYnNlcnZlci5uZXh0KSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHBhcnRpYWxPYnNlcnZlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGhhbmRsZVVuaGFuZGxlZEVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgQ29uc3VtZXJPYnNlcnZlci5wcm90b3R5cGUuZXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIHZhciBwYXJ0aWFsT2JzZXJ2ZXIgPSB0aGlzLnBhcnRpYWxPYnNlcnZlcjtcbiAgICAgICAgaWYgKHBhcnRpYWxPYnNlcnZlci5lcnJvcikge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBwYXJ0aWFsT2JzZXJ2ZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGhhbmRsZVVuaGFuZGxlZEVycm9yKGVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGhhbmRsZVVuaGFuZGxlZEVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIENvbnN1bWVyT2JzZXJ2ZXIucHJvdG90eXBlLmNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgcGFydGlhbE9ic2VydmVyID0gdGhpcy5wYXJ0aWFsT2JzZXJ2ZXI7XG4gICAgICAgIGlmIChwYXJ0aWFsT2JzZXJ2ZXIuY29tcGxldGUpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcGFydGlhbE9ic2VydmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVVbmhhbmRsZWRFcnJvcihlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBDb25zdW1lck9ic2VydmVyO1xufSgpKTtcbnZhciBTYWZlU3Vic2NyaWJlciA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKFNhZmVTdWJzY3JpYmVyLCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFNhZmVTdWJzY3JpYmVyKG9ic2VydmVyT3JOZXh0LCBlcnJvciwgY29tcGxldGUpIHtcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyLmNhbGwodGhpcykgfHwgdGhpcztcbiAgICAgICAgdmFyIHBhcnRpYWxPYnNlcnZlcjtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24ob2JzZXJ2ZXJPck5leHQpIHx8ICFvYnNlcnZlck9yTmV4dCkge1xuICAgICAgICAgICAgcGFydGlhbE9ic2VydmVyID0ge1xuICAgICAgICAgICAgICAgIG5leHQ6IChvYnNlcnZlck9yTmV4dCAhPT0gbnVsbCAmJiBvYnNlcnZlck9yTmV4dCAhPT0gdm9pZCAwID8gb2JzZXJ2ZXJPck5leHQgOiB1bmRlZmluZWQpLFxuICAgICAgICAgICAgICAgIGVycm9yOiBlcnJvciAhPT0gbnVsbCAmJiBlcnJvciAhPT0gdm9pZCAwID8gZXJyb3IgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgY29tcGxldGU6IGNvbXBsZXRlICE9PSBudWxsICYmIGNvbXBsZXRlICE9PSB2b2lkIDAgPyBjb21wbGV0ZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YXIgY29udGV4dF8xO1xuICAgICAgICAgICAgaWYgKF90aGlzICYmIGNvbmZpZy51c2VEZXByZWNhdGVkTmV4dENvbnRleHQpIHtcbiAgICAgICAgICAgICAgICBjb250ZXh0XzEgPSBPYmplY3QuY3JlYXRlKG9ic2VydmVyT3JOZXh0KTtcbiAgICAgICAgICAgICAgICBjb250ZXh0XzEudW5zdWJzY3JpYmUgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBfdGhpcy51bnN1YnNjcmliZSgpOyB9O1xuICAgICAgICAgICAgICAgIHBhcnRpYWxPYnNlcnZlciA9IHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dDogb2JzZXJ2ZXJPck5leHQubmV4dCAmJiBiaW5kKG9ic2VydmVyT3JOZXh0Lm5leHQsIGNvbnRleHRfMSksXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBvYnNlcnZlck9yTmV4dC5lcnJvciAmJiBiaW5kKG9ic2VydmVyT3JOZXh0LmVycm9yLCBjb250ZXh0XzEpLFxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZTogb2JzZXJ2ZXJPck5leHQuY29tcGxldGUgJiYgYmluZChvYnNlcnZlck9yTmV4dC5jb21wbGV0ZSwgY29udGV4dF8xKSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcGFydGlhbE9ic2VydmVyID0gb2JzZXJ2ZXJPck5leHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgX3RoaXMuZGVzdGluYXRpb24gPSBuZXcgQ29uc3VtZXJPYnNlcnZlcihwYXJ0aWFsT2JzZXJ2ZXIpO1xuICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgfVxuICAgIHJldHVybiBTYWZlU3Vic2NyaWJlcjtcbn0oU3Vic2NyaWJlcikpO1xuZXhwb3J0IHsgU2FmZVN1YnNjcmliZXIgfTtcbmZ1bmN0aW9uIGhhbmRsZVVuaGFuZGxlZEVycm9yKGVycm9yKSB7XG4gICAgaWYgKGNvbmZpZy51c2VEZXByZWNhdGVkU3luY2hyb25vdXNFcnJvckhhbmRsaW5nKSB7XG4gICAgICAgIGNhcHR1cmVFcnJvcihlcnJvcik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZXBvcnRVbmhhbmRsZWRFcnJvcihlcnJvcik7XG4gICAgfVxufVxuZnVuY3Rpb24gZGVmYXVsdEVycm9ySGFuZGxlcihlcnIpIHtcbiAgICB0aHJvdyBlcnI7XG59XG5mdW5jdGlvbiBoYW5kbGVTdG9wcGVkTm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbiwgc3Vic2NyaWJlcikge1xuICAgIHZhciBvblN0b3BwZWROb3RpZmljYXRpb24gPSBjb25maWcub25TdG9wcGVkTm90aWZpY2F0aW9uO1xuICAgIG9uU3RvcHBlZE5vdGlmaWNhdGlvbiAmJiB0aW1lb3V0UHJvdmlkZXIuc2V0VGltZW91dChmdW5jdGlvbiAoKSB7IHJldHVybiBvblN0b3BwZWROb3RpZmljYXRpb24obm90aWZpY2F0aW9uLCBzdWJzY3JpYmVyKTsgfSk7XG59XG5leHBvcnQgdmFyIEVNUFRZX09CU0VSVkVSID0ge1xuICAgIGNsb3NlZDogdHJ1ZSxcbiAgICBuZXh0OiBub29wLFxuICAgIGVycm9yOiBkZWZhdWx0RXJyb3JIYW5kbGVyLFxuICAgIGNvbXBsZXRlOiBub29wLFxufTtcbiIsImV4cG9ydCB2YXIgb2JzZXJ2YWJsZSA9IChmdW5jdGlvbiAoKSB7IHJldHVybiAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJyAmJiBTeW1ib2wub2JzZXJ2YWJsZSkgfHwgJ0BAb2JzZXJ2YWJsZSc7IH0pKCk7XG4iLCJleHBvcnQgZnVuY3Rpb24gaWRlbnRpdHkoeCkge1xuICAgIHJldHVybiB4O1xufVxuIiwiaW1wb3J0IHsgaWRlbnRpdHkgfSBmcm9tICcuL2lkZW50aXR5JztcbmV4cG9ydCBmdW5jdGlvbiBwaXBlKCkge1xuICAgIHZhciBmbnMgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICBmbnNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgcmV0dXJuIHBpcGVGcm9tQXJyYXkoZm5zKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwaXBlRnJvbUFycmF5KGZucykge1xuICAgIGlmIChmbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBpZGVudGl0eTtcbiAgICB9XG4gICAgaWYgKGZucy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgcmV0dXJuIGZuc1swXTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uIHBpcGVkKGlucHV0KSB7XG4gICAgICAgIHJldHVybiBmbnMucmVkdWNlKGZ1bmN0aW9uIChwcmV2LCBmbikgeyByZXR1cm4gZm4ocHJldik7IH0sIGlucHV0KTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgU2FmZVN1YnNjcmliZXIsIFN1YnNjcmliZXIgfSBmcm9tICcuL1N1YnNjcmliZXInO1xuaW1wb3J0IHsgaXNTdWJzY3JpcHRpb24gfSBmcm9tICcuL1N1YnNjcmlwdGlvbic7XG5pbXBvcnQgeyBvYnNlcnZhYmxlIGFzIFN5bWJvbF9vYnNlcnZhYmxlIH0gZnJvbSAnLi9zeW1ib2wvb2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBwaXBlRnJvbUFycmF5IH0gZnJvbSAnLi91dGlsL3BpcGUnO1xuaW1wb3J0IHsgY29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4vdXRpbC9pc0Z1bmN0aW9uJztcbmltcG9ydCB7IGVycm9yQ29udGV4dCB9IGZyb20gJy4vdXRpbC9lcnJvckNvbnRleHQnO1xudmFyIE9ic2VydmFibGUgPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIE9ic2VydmFibGUoc3Vic2NyaWJlKSB7XG4gICAgICAgIGlmIChzdWJzY3JpYmUpIHtcbiAgICAgICAgICAgIHRoaXMuX3N1YnNjcmliZSA9IHN1YnNjcmliZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBPYnNlcnZhYmxlLnByb3RvdHlwZS5saWZ0ID0gZnVuY3Rpb24gKG9wZXJhdG9yKSB7XG4gICAgICAgIHZhciBvYnNlcnZhYmxlID0gbmV3IE9ic2VydmFibGUoKTtcbiAgICAgICAgb2JzZXJ2YWJsZS5zb3VyY2UgPSB0aGlzO1xuICAgICAgICBvYnNlcnZhYmxlLm9wZXJhdG9yID0gb3BlcmF0b3I7XG4gICAgICAgIHJldHVybiBvYnNlcnZhYmxlO1xuICAgIH07XG4gICAgT2JzZXJ2YWJsZS5wcm90b3R5cGUuc3Vic2NyaWJlID0gZnVuY3Rpb24gKG9ic2VydmVyT3JOZXh0LCBlcnJvciwgY29tcGxldGUpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdmFyIHN1YnNjcmliZXIgPSBpc1N1YnNjcmliZXIob2JzZXJ2ZXJPck5leHQpID8gb2JzZXJ2ZXJPck5leHQgOiBuZXcgU2FmZVN1YnNjcmliZXIob2JzZXJ2ZXJPck5leHQsIGVycm9yLCBjb21wbGV0ZSk7XG4gICAgICAgIGVycm9yQ29udGV4dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgX2EgPSBfdGhpcywgb3BlcmF0b3IgPSBfYS5vcGVyYXRvciwgc291cmNlID0gX2Euc291cmNlO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5hZGQob3BlcmF0b3JcbiAgICAgICAgICAgICAgICA/XG4gICAgICAgICAgICAgICAgICAgIG9wZXJhdG9yLmNhbGwoc3Vic2NyaWJlciwgc291cmNlKVxuICAgICAgICAgICAgICAgIDogc291cmNlXG4gICAgICAgICAgICAgICAgICAgID9cbiAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLl9zdWJzY3JpYmUoc3Vic2NyaWJlcilcbiAgICAgICAgICAgICAgICAgICAgOlxuICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuX3RyeVN1YnNjcmliZShzdWJzY3JpYmVyKSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gc3Vic2NyaWJlcjtcbiAgICB9O1xuICAgIE9ic2VydmFibGUucHJvdG90eXBlLl90cnlTdWJzY3JpYmUgPSBmdW5jdGlvbiAoc2luaykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX3N1YnNjcmliZShzaW5rKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBzaW5rLmVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIE9ic2VydmFibGUucHJvdG90eXBlLmZvckVhY2ggPSBmdW5jdGlvbiAobmV4dCwgcHJvbWlzZUN0b3IpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgcHJvbWlzZUN0b3IgPSBnZXRQcm9taXNlQ3Rvcihwcm9taXNlQ3Rvcik7XG4gICAgICAgIHJldHVybiBuZXcgcHJvbWlzZUN0b3IoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgdmFyIHN1YnNjcmliZXIgPSBuZXcgU2FmZVN1YnNjcmliZXIoe1xuICAgICAgICAgICAgICAgIG5leHQ6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGVycm9yOiByZWplY3QsXG4gICAgICAgICAgICAgICAgY29tcGxldGU6IHJlc29sdmUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIF90aGlzLnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBPYnNlcnZhYmxlLnByb3RvdHlwZS5fc3Vic2NyaWJlID0gZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICByZXR1cm4gKF9hID0gdGhpcy5zb3VyY2UpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfTtcbiAgICBPYnNlcnZhYmxlLnByb3RvdHlwZVtTeW1ib2xfb2JzZXJ2YWJsZV0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgT2JzZXJ2YWJsZS5wcm90b3R5cGUucGlwZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIG9wZXJhdGlvbnMgPSBbXTtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIG9wZXJhdGlvbnNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcGlwZUZyb21BcnJheShvcGVyYXRpb25zKSh0aGlzKTtcbiAgICB9O1xuICAgIE9ic2VydmFibGUucHJvdG90eXBlLnRvUHJvbWlzZSA9IGZ1bmN0aW9uIChwcm9taXNlQ3Rvcikge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBwcm9taXNlQ3RvciA9IGdldFByb21pc2VDdG9yKHByb21pc2VDdG9yKTtcbiAgICAgICAgcmV0dXJuIG5ldyBwcm9taXNlQ3RvcihmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICB2YXIgdmFsdWU7XG4gICAgICAgICAgICBfdGhpcy5zdWJzY3JpYmUoZnVuY3Rpb24gKHgpIHsgcmV0dXJuICh2YWx1ZSA9IHgpOyB9LCBmdW5jdGlvbiAoZXJyKSB7IHJldHVybiByZWplY3QoZXJyKTsgfSwgZnVuY3Rpb24gKCkgeyByZXR1cm4gcmVzb2x2ZSh2YWx1ZSk7IH0pO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIE9ic2VydmFibGUuY3JlYXRlID0gZnVuY3Rpb24gKHN1YnNjcmliZSkge1xuICAgICAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoc3Vic2NyaWJlKTtcbiAgICB9O1xuICAgIHJldHVybiBPYnNlcnZhYmxlO1xufSgpKTtcbmV4cG9ydCB7IE9ic2VydmFibGUgfTtcbmZ1bmN0aW9uIGdldFByb21pc2VDdG9yKHByb21pc2VDdG9yKSB7XG4gICAgdmFyIF9hO1xuICAgIHJldHVybiAoX2EgPSBwcm9taXNlQ3RvciAhPT0gbnVsbCAmJiBwcm9taXNlQ3RvciAhPT0gdm9pZCAwID8gcHJvbWlzZUN0b3IgOiBjb25maWcuUHJvbWlzZSkgIT09IG51bGwgJiYgX2EgIT09IHZvaWQgMCA/IF9hIDogUHJvbWlzZTtcbn1cbmZ1bmN0aW9uIGlzT2JzZXJ2ZXIodmFsdWUpIHtcbiAgICByZXR1cm4gdmFsdWUgJiYgaXNGdW5jdGlvbih2YWx1ZS5uZXh0KSAmJiBpc0Z1bmN0aW9uKHZhbHVlLmVycm9yKSAmJiBpc0Z1bmN0aW9uKHZhbHVlLmNvbXBsZXRlKTtcbn1cbmZ1bmN0aW9uIGlzU3Vic2NyaWJlcih2YWx1ZSkge1xuICAgIHJldHVybiAodmFsdWUgJiYgdmFsdWUgaW5zdGFuY2VvZiBTdWJzY3JpYmVyKSB8fCAoaXNPYnNlcnZlcih2YWx1ZSkgJiYgaXNTdWJzY3JpcHRpb24odmFsdWUpKTtcbn1cbiIsImltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuL2lzRnVuY3Rpb24nO1xuZXhwb3J0IGZ1bmN0aW9uIGhhc0xpZnQoc291cmNlKSB7XG4gICAgcmV0dXJuIGlzRnVuY3Rpb24oc291cmNlID09PSBudWxsIHx8IHNvdXJjZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogc291cmNlLmxpZnQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG9wZXJhdGUoaW5pdCkge1xuICAgIHJldHVybiBmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICAgIGlmIChoYXNMaWZ0KHNvdXJjZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBzb3VyY2UubGlmdChmdW5jdGlvbiAobGlmdGVkU291cmNlKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGluaXQobGlmdGVkU291cmNlLCB0aGlzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVW5hYmxlIHRvIGxpZnQgdW5rbm93biBPYnNlcnZhYmxlIHR5cGUnKTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgX19leHRlbmRzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBTdWJzY3JpYmVyIH0gZnJvbSAnLi4vU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKGRlc3RpbmF0aW9uLCBvbk5leHQsIG9uQ29tcGxldGUsIG9uRXJyb3IsIG9uRmluYWxpemUpIHtcbiAgICByZXR1cm4gbmV3IE9wZXJhdG9yU3Vic2NyaWJlcihkZXN0aW5hdGlvbiwgb25OZXh0LCBvbkNvbXBsZXRlLCBvbkVycm9yLCBvbkZpbmFsaXplKTtcbn1cbnZhciBPcGVyYXRvclN1YnNjcmliZXIgPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhPcGVyYXRvclN1YnNjcmliZXIsIF9zdXBlcik7XG4gICAgZnVuY3Rpb24gT3BlcmF0b3JTdWJzY3JpYmVyKGRlc3RpbmF0aW9uLCBvbk5leHQsIG9uQ29tcGxldGUsIG9uRXJyb3IsIG9uRmluYWxpemUsIHNob3VsZFVuc3Vic2NyaWJlKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMsIGRlc3RpbmF0aW9uKSB8fCB0aGlzO1xuICAgICAgICBfdGhpcy5vbkZpbmFsaXplID0gb25GaW5hbGl6ZTtcbiAgICAgICAgX3RoaXMuc2hvdWxkVW5zdWJzY3JpYmUgPSBzaG91bGRVbnN1YnNjcmliZTtcbiAgICAgICAgX3RoaXMuX25leHQgPSBvbk5leHRcbiAgICAgICAgICAgID8gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgb25OZXh0KHZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICBkZXN0aW5hdGlvbi5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDogX3N1cGVyLnByb3RvdHlwZS5fbmV4dDtcbiAgICAgICAgX3RoaXMuX2Vycm9yID0gb25FcnJvclxuICAgICAgICAgICAgPyBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGRlc3RpbmF0aW9uLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiBfc3VwZXIucHJvdG90eXBlLl9lcnJvcjtcbiAgICAgICAgX3RoaXMuX2NvbXBsZXRlID0gb25Db21wbGV0ZVxuICAgICAgICAgICAgPyBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgb25Db21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGRlc3RpbmF0aW9uLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgOiBfc3VwZXIucHJvdG90eXBlLl9jb21wbGV0ZTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBPcGVyYXRvclN1YnNjcmliZXIucHJvdG90eXBlLnVuc3Vic2NyaWJlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmICghdGhpcy5zaG91bGRVbnN1YnNjcmliZSB8fCB0aGlzLnNob3VsZFVuc3Vic2NyaWJlKCkpIHtcbiAgICAgICAgICAgIHZhciBjbG9zZWRfMSA9IHRoaXMuY2xvc2VkO1xuICAgICAgICAgICAgX3N1cGVyLnByb3RvdHlwZS51bnN1YnNjcmliZS5jYWxsKHRoaXMpO1xuICAgICAgICAgICAgIWNsb3NlZF8xICYmICgoX2EgPSB0aGlzLm9uRmluYWxpemUpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5jYWxsKHRoaXMpKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIE9wZXJhdG9yU3Vic2NyaWJlcjtcbn0oU3Vic2NyaWJlcikpO1xuZXhwb3J0IHsgT3BlcmF0b3JTdWJzY3JpYmVyIH07XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiByZWZDb3VudCgpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBjb25uZWN0aW9uID0gbnVsbDtcbiAgICAgICAgc291cmNlLl9yZWZDb3VudCsrO1xuICAgICAgICB2YXIgcmVmQ291bnRlciA9IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoIXNvdXJjZSB8fCBzb3VyY2UuX3JlZkNvdW50IDw9IDAgfHwgMCA8IC0tc291cmNlLl9yZWZDb3VudCkge1xuICAgICAgICAgICAgICAgIGNvbm5lY3Rpb24gPSBudWxsO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBzaGFyZWRDb25uZWN0aW9uID0gc291cmNlLl9jb25uZWN0aW9uO1xuICAgICAgICAgICAgdmFyIGNvbm4gPSBjb25uZWN0aW9uO1xuICAgICAgICAgICAgY29ubmVjdGlvbiA9IG51bGw7XG4gICAgICAgICAgICBpZiAoc2hhcmVkQ29ubmVjdGlvbiAmJiAoIWNvbm4gfHwgc2hhcmVkQ29ubmVjdGlvbiA9PT0gY29ubikpIHtcbiAgICAgICAgICAgICAgICBzaGFyZWRDb25uZWN0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH0pO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKHJlZkNvdW50ZXIpO1xuICAgICAgICBpZiAoIXJlZkNvdW50ZXIuY2xvc2VkKSB7XG4gICAgICAgICAgICBjb25uZWN0aW9uID0gc291cmNlLmNvbm5lY3QoKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgX19leHRlbmRzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICcuLi9TdWJzY3JpcHRpb24nO1xuaW1wb3J0IHsgcmVmQ291bnQgYXMgaGlnaGVyT3JkZXJSZWZDb3VudCB9IGZyb20gJy4uL29wZXJhdG9ycy9yZWZDb3VudCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuLi9vcGVyYXRvcnMvT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IGhhc0xpZnQgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xudmFyIENvbm5lY3RhYmxlT2JzZXJ2YWJsZSA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKENvbm5lY3RhYmxlT2JzZXJ2YWJsZSwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBDb25uZWN0YWJsZU9ic2VydmFibGUoc291cmNlLCBzdWJqZWN0RmFjdG9yeSkge1xuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgICAgICBfdGhpcy5zb3VyY2UgPSBzb3VyY2U7XG4gICAgICAgIF90aGlzLnN1YmplY3RGYWN0b3J5ID0gc3ViamVjdEZhY3Rvcnk7XG4gICAgICAgIF90aGlzLl9zdWJqZWN0ID0gbnVsbDtcbiAgICAgICAgX3RoaXMuX3JlZkNvdW50ID0gMDtcbiAgICAgICAgX3RoaXMuX2Nvbm5lY3Rpb24gPSBudWxsO1xuICAgICAgICBpZiAoaGFzTGlmdChzb3VyY2UpKSB7XG4gICAgICAgICAgICBfdGhpcy5saWZ0ID0gc291cmNlLmxpZnQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBDb25uZWN0YWJsZU9ic2VydmFibGUucHJvdG90eXBlLl9zdWJzY3JpYmUgPSBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRTdWJqZWN0KCkuc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgIH07XG4gICAgQ29ubmVjdGFibGVPYnNlcnZhYmxlLnByb3RvdHlwZS5nZXRTdWJqZWN0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgc3ViamVjdCA9IHRoaXMuX3N1YmplY3Q7XG4gICAgICAgIGlmICghc3ViamVjdCB8fCBzdWJqZWN0LmlzU3RvcHBlZCkge1xuICAgICAgICAgICAgdGhpcy5fc3ViamVjdCA9IHRoaXMuc3ViamVjdEZhY3RvcnkoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fc3ViamVjdDtcbiAgICB9O1xuICAgIENvbm5lY3RhYmxlT2JzZXJ2YWJsZS5wcm90b3R5cGUuX3RlYXJkb3duID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLl9yZWZDb3VudCA9IDA7XG4gICAgICAgIHZhciBfY29ubmVjdGlvbiA9IHRoaXMuX2Nvbm5lY3Rpb247XG4gICAgICAgIHRoaXMuX3N1YmplY3QgPSB0aGlzLl9jb25uZWN0aW9uID0gbnVsbDtcbiAgICAgICAgX2Nvbm5lY3Rpb24gPT09IG51bGwgfHwgX2Nvbm5lY3Rpb24gPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jb25uZWN0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgfTtcbiAgICBDb25uZWN0YWJsZU9ic2VydmFibGUucHJvdG90eXBlLmNvbm5lY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHZhciBjb25uZWN0aW9uID0gdGhpcy5fY29ubmVjdGlvbjtcbiAgICAgICAgaWYgKCFjb25uZWN0aW9uKSB7XG4gICAgICAgICAgICBjb25uZWN0aW9uID0gdGhpcy5fY29ubmVjdGlvbiA9IG5ldyBTdWJzY3JpcHRpb24oKTtcbiAgICAgICAgICAgIHZhciBzdWJqZWN0XzEgPSB0aGlzLmdldFN1YmplY3QoKTtcbiAgICAgICAgICAgIGNvbm5lY3Rpb24uYWRkKHRoaXMuc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3ViamVjdF8xLCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5fdGVhcmRvd24oKTtcbiAgICAgICAgICAgICAgICBzdWJqZWN0XzEuY29tcGxldGUoKTtcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5fdGVhcmRvd24oKTtcbiAgICAgICAgICAgICAgICBzdWJqZWN0XzEuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uICgpIHsgcmV0dXJuIF90aGlzLl90ZWFyZG93bigpOyB9KSkpO1xuICAgICAgICAgICAgaWYgKGNvbm5lY3Rpb24uY2xvc2VkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fY29ubmVjdGlvbiA9IG51bGw7XG4gICAgICAgICAgICAgICAgY29ubmVjdGlvbiA9IFN1YnNjcmlwdGlvbi5FTVBUWTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29ubmVjdGlvbjtcbiAgICB9O1xuICAgIENvbm5lY3RhYmxlT2JzZXJ2YWJsZS5wcm90b3R5cGUucmVmQ291bnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBoaWdoZXJPcmRlclJlZkNvdW50KCkodGhpcyk7XG4gICAgfTtcbiAgICByZXR1cm4gQ29ubmVjdGFibGVPYnNlcnZhYmxlO1xufShPYnNlcnZhYmxlKSk7XG5leHBvcnQgeyBDb25uZWN0YWJsZU9ic2VydmFibGUgfTtcbiIsImltcG9ydCB7IGNyZWF0ZUVycm9yQ2xhc3MgfSBmcm9tICcuL2NyZWF0ZUVycm9yQ2xhc3MnO1xuZXhwb3J0IHZhciBPYmplY3RVbnN1YnNjcmliZWRFcnJvciA9IGNyZWF0ZUVycm9yQ2xhc3MoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIHJldHVybiBmdW5jdGlvbiBPYmplY3RVbnN1YnNjcmliZWRFcnJvckltcGwoKSB7XG4gICAgICAgIF9zdXBlcih0aGlzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ09iamVjdFVuc3Vic2NyaWJlZEVycm9yJztcbiAgICAgICAgdGhpcy5tZXNzYWdlID0gJ29iamVjdCB1bnN1YnNjcmliZWQnO1xuICAgIH07XG59KTtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcywgX192YWx1ZXMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuL09ic2VydmFibGUnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uLCBFTVBUWV9TVUJTQ1JJUFRJT04gfSBmcm9tICcuL1N1YnNjcmlwdGlvbic7XG5pbXBvcnQgeyBPYmplY3RVbnN1YnNjcmliZWRFcnJvciB9IGZyb20gJy4vdXRpbC9PYmplY3RVbnN1YnNjcmliZWRFcnJvcic7XG5pbXBvcnQgeyBhcnJSZW1vdmUgfSBmcm9tICcuL3V0aWwvYXJyUmVtb3ZlJztcbmltcG9ydCB7IGVycm9yQ29udGV4dCB9IGZyb20gJy4vdXRpbC9lcnJvckNvbnRleHQnO1xudmFyIFN1YmplY3QgPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhTdWJqZWN0LCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIFN1YmplY3QoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLmNsb3NlZCA9IGZhbHNlO1xuICAgICAgICBfdGhpcy5jdXJyZW50T2JzZXJ2ZXJzID0gbnVsbDtcbiAgICAgICAgX3RoaXMub2JzZXJ2ZXJzID0gW107XG4gICAgICAgIF90aGlzLmlzU3RvcHBlZCA9IGZhbHNlO1xuICAgICAgICBfdGhpcy5oYXNFcnJvciA9IGZhbHNlO1xuICAgICAgICBfdGhpcy50aHJvd25FcnJvciA9IG51bGw7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgU3ViamVjdC5wcm90b3R5cGUubGlmdCA9IGZ1bmN0aW9uIChvcGVyYXRvcikge1xuICAgICAgICB2YXIgc3ViamVjdCA9IG5ldyBBbm9ueW1vdXNTdWJqZWN0KHRoaXMsIHRoaXMpO1xuICAgICAgICBzdWJqZWN0Lm9wZXJhdG9yID0gb3BlcmF0b3I7XG4gICAgICAgIHJldHVybiBzdWJqZWN0O1xuICAgIH07XG4gICAgU3ViamVjdC5wcm90b3R5cGUuX3Rocm93SWZDbG9zZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmICh0aGlzLmNsb3NlZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE9iamVjdFVuc3Vic2NyaWJlZEVycm9yKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIFN1YmplY3QucHJvdG90eXBlLm5leHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgZXJyb3JDb250ZXh0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBlXzEsIF9hO1xuICAgICAgICAgICAgX3RoaXMuX3Rocm93SWZDbG9zZWQoKTtcbiAgICAgICAgICAgIGlmICghX3RoaXMuaXNTdG9wcGVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFfdGhpcy5jdXJyZW50T2JzZXJ2ZXJzKSB7XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLmN1cnJlbnRPYnNlcnZlcnMgPSBBcnJheS5mcm9tKF90aGlzLm9ic2VydmVycyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9iID0gX192YWx1ZXMoX3RoaXMuY3VycmVudE9ic2VydmVycyksIF9jID0gX2IubmV4dCgpOyAhX2MuZG9uZTsgX2MgPSBfYi5uZXh0KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBvYnNlcnZlciA9IF9jLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfYyAmJiAhX2MuZG9uZSAmJiAoX2EgPSBfYi5yZXR1cm4pKSBfYS5jYWxsKF9iKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIFN1YmplY3QucHJvdG90eXBlLmVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBlcnJvckNvbnRleHQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgX3RoaXMuX3Rocm93SWZDbG9zZWQoKTtcbiAgICAgICAgICAgIGlmICghX3RoaXMuaXNTdG9wcGVkKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMuaGFzRXJyb3IgPSBfdGhpcy5pc1N0b3BwZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIF90aGlzLnRocm93bkVycm9yID0gZXJyO1xuICAgICAgICAgICAgICAgIHZhciBvYnNlcnZlcnMgPSBfdGhpcy5vYnNlcnZlcnM7XG4gICAgICAgICAgICAgICAgd2hpbGUgKG9ic2VydmVycy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZXJzLnNoaWZ0KCkuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgU3ViamVjdC5wcm90b3R5cGUuY29tcGxldGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIGVycm9yQ29udGV4dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBfdGhpcy5fdGhyb3dJZkNsb3NlZCgpO1xuICAgICAgICAgICAgaWYgKCFfdGhpcy5pc1N0b3BwZWQpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5pc1N0b3BwZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHZhciBvYnNlcnZlcnMgPSBfdGhpcy5vYnNlcnZlcnM7XG4gICAgICAgICAgICAgICAgd2hpbGUgKG9ic2VydmVycy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgb2JzZXJ2ZXJzLnNoaWZ0KCkuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgU3ViamVjdC5wcm90b3R5cGUudW5zdWJzY3JpYmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRoaXMuaXNTdG9wcGVkID0gdGhpcy5jbG9zZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLm9ic2VydmVycyA9IHRoaXMuY3VycmVudE9ic2VydmVycyA9IG51bGw7XG4gICAgfTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoU3ViamVjdC5wcm90b3R5cGUsIFwib2JzZXJ2ZWRcIiwge1xuICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgIHJldHVybiAoKF9hID0gdGhpcy5vYnNlcnZlcnMpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5sZW5ndGgpID4gMDtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIFN1YmplY3QucHJvdG90eXBlLl90cnlTdWJzY3JpYmUgPSBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB0aGlzLl90aHJvd0lmQ2xvc2VkKCk7XG4gICAgICAgIHJldHVybiBfc3VwZXIucHJvdG90eXBlLl90cnlTdWJzY3JpYmUuY2FsbCh0aGlzLCBzdWJzY3JpYmVyKTtcbiAgICB9O1xuICAgIFN1YmplY3QucHJvdG90eXBlLl9zdWJzY3JpYmUgPSBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB0aGlzLl90aHJvd0lmQ2xvc2VkKCk7XG4gICAgICAgIHRoaXMuX2NoZWNrRmluYWxpemVkU3RhdHVzZXMoc3Vic2NyaWJlcik7XG4gICAgICAgIHJldHVybiB0aGlzLl9pbm5lclN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICB9O1xuICAgIFN1YmplY3QucHJvdG90eXBlLl9pbm5lclN1YnNjcmliZSA9IGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHZhciBfYSA9IHRoaXMsIGhhc0Vycm9yID0gX2EuaGFzRXJyb3IsIGlzU3RvcHBlZCA9IF9hLmlzU3RvcHBlZCwgb2JzZXJ2ZXJzID0gX2Eub2JzZXJ2ZXJzO1xuICAgICAgICBpZiAoaGFzRXJyb3IgfHwgaXNTdG9wcGVkKSB7XG4gICAgICAgICAgICByZXR1cm4gRU1QVFlfU1VCU0NSSVBUSU9OO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY3VycmVudE9ic2VydmVycyA9IG51bGw7XG4gICAgICAgIG9ic2VydmVycy5wdXNoKHN1YnNjcmliZXIpO1xuICAgICAgICByZXR1cm4gbmV3IFN1YnNjcmlwdGlvbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBfdGhpcy5jdXJyZW50T2JzZXJ2ZXJzID0gbnVsbDtcbiAgICAgICAgICAgIGFyclJlbW92ZShvYnNlcnZlcnMsIHN1YnNjcmliZXIpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIFN1YmplY3QucHJvdG90eXBlLl9jaGVja0ZpbmFsaXplZFN0YXR1c2VzID0gZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIF9hID0gdGhpcywgaGFzRXJyb3IgPSBfYS5oYXNFcnJvciwgdGhyb3duRXJyb3IgPSBfYS50aHJvd25FcnJvciwgaXNTdG9wcGVkID0gX2EuaXNTdG9wcGVkO1xuICAgICAgICBpZiAoaGFzRXJyb3IpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIuZXJyb3IodGhyb3duRXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzU3RvcHBlZCkge1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBTdWJqZWN0LnByb3RvdHlwZS5hc09ic2VydmFibGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBvYnNlcnZhYmxlID0gbmV3IE9ic2VydmFibGUoKTtcbiAgICAgICAgb2JzZXJ2YWJsZS5zb3VyY2UgPSB0aGlzO1xuICAgICAgICByZXR1cm4gb2JzZXJ2YWJsZTtcbiAgICB9O1xuICAgIFN1YmplY3QuY3JlYXRlID0gZnVuY3Rpb24gKGRlc3RpbmF0aW9uLCBzb3VyY2UpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBBbm9ueW1vdXNTdWJqZWN0KGRlc3RpbmF0aW9uLCBzb3VyY2UpO1xuICAgIH07XG4gICAgcmV0dXJuIFN1YmplY3Q7XG59KE9ic2VydmFibGUpKTtcbmV4cG9ydCB7IFN1YmplY3QgfTtcbnZhciBBbm9ueW1vdXNTdWJqZWN0ID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQW5vbnltb3VzU3ViamVjdCwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBbm9ueW1vdXNTdWJqZWN0KGRlc3RpbmF0aW9uLCBzb3VyY2UpIHtcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyLmNhbGwodGhpcykgfHwgdGhpcztcbiAgICAgICAgX3RoaXMuZGVzdGluYXRpb24gPSBkZXN0aW5hdGlvbjtcbiAgICAgICAgX3RoaXMuc291cmNlID0gc291cmNlO1xuICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgfVxuICAgIEFub255bW91c1N1YmplY3QucHJvdG90eXBlLm5leHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgKF9iID0gKF9hID0gdGhpcy5kZXN0aW5hdGlvbikgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLm5leHQpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5jYWxsKF9hLCB2YWx1ZSk7XG4gICAgfTtcbiAgICBBbm9ueW1vdXNTdWJqZWN0LnByb3RvdHlwZS5lcnJvciA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgKF9iID0gKF9hID0gdGhpcy5kZXN0aW5hdGlvbikgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmVycm9yKSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IuY2FsbChfYSwgZXJyKTtcbiAgICB9O1xuICAgIEFub255bW91c1N1YmplY3QucHJvdG90eXBlLmNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICAoX2IgPSAoX2EgPSB0aGlzLmRlc3RpbmF0aW9uKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuY29tcGxldGUpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5jYWxsKF9hKTtcbiAgICB9O1xuICAgIEFub255bW91c1N1YmplY3QucHJvdG90eXBlLl9zdWJzY3JpYmUgPSBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICByZXR1cm4gKF9iID0gKF9hID0gdGhpcy5zb3VyY2UpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5zdWJzY3JpYmUoc3Vic2NyaWJlcikpICE9PSBudWxsICYmIF9iICE9PSB2b2lkIDAgPyBfYiA6IEVNUFRZX1NVQlNDUklQVElPTjtcbiAgICB9O1xuICAgIHJldHVybiBBbm9ueW1vdXNTdWJqZWN0O1xufShTdWJqZWN0KSk7XG5leHBvcnQgeyBBbm9ueW1vdXNTdWJqZWN0IH07XG4iLCJpbXBvcnQgeyBfX2V4dGVuZHMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICcuL1N1YmplY3QnO1xudmFyIEJlaGF2aW9yU3ViamVjdCA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKEJlaGF2aW9yU3ViamVjdCwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBCZWhhdmlvclN1YmplY3QoX3ZhbHVlKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLl92YWx1ZSA9IF92YWx1ZTtcbiAgICAgICAgcmV0dXJuIF90aGlzO1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQmVoYXZpb3JTdWJqZWN0LnByb3RvdHlwZSwgXCJ2YWx1ZVwiLCB7XG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0VmFsdWUoKTtcbiAgICAgICAgfSxcbiAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgIH0pO1xuICAgIEJlaGF2aW9yU3ViamVjdC5wcm90b3R5cGUuX3N1YnNjcmliZSA9IGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBzdWJzY3JpcHRpb24gPSBfc3VwZXIucHJvdG90eXBlLl9zdWJzY3JpYmUuY2FsbCh0aGlzLCBzdWJzY3JpYmVyKTtcbiAgICAgICAgIXN1YnNjcmlwdGlvbi5jbG9zZWQgJiYgc3Vic2NyaWJlci5uZXh0KHRoaXMuX3ZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHN1YnNjcmlwdGlvbjtcbiAgICB9O1xuICAgIEJlaGF2aW9yU3ViamVjdC5wcm90b3R5cGUuZ2V0VmFsdWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfYSA9IHRoaXMsIGhhc0Vycm9yID0gX2EuaGFzRXJyb3IsIHRocm93bkVycm9yID0gX2EudGhyb3duRXJyb3IsIF92YWx1ZSA9IF9hLl92YWx1ZTtcbiAgICAgICAgaWYgKGhhc0Vycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyB0aHJvd25FcnJvcjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl90aHJvd0lmQ2xvc2VkKCk7XG4gICAgICAgIHJldHVybiBfdmFsdWU7XG4gICAgfTtcbiAgICBCZWhhdmlvclN1YmplY3QucHJvdG90eXBlLm5leHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgX3N1cGVyLnByb3RvdHlwZS5uZXh0LmNhbGwodGhpcywgKHRoaXMuX3ZhbHVlID0gdmFsdWUpKTtcbiAgICB9O1xuICAgIHJldHVybiBCZWhhdmlvclN1YmplY3Q7XG59KFN1YmplY3QpKTtcbmV4cG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9O1xuIiwiZXhwb3J0IHZhciBkYXRlVGltZXN0YW1wUHJvdmlkZXIgPSB7XG4gICAgbm93OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiAoZGF0ZVRpbWVzdGFtcFByb3ZpZGVyLmRlbGVnYXRlIHx8IERhdGUpLm5vdygpO1xuICAgIH0sXG4gICAgZGVsZWdhdGU6IHVuZGVmaW5lZCxcbn07XG4iLCJpbXBvcnQgeyBfX2V4dGVuZHMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICcuL1N1YmplY3QnO1xuaW1wb3J0IHsgZGF0ZVRpbWVzdGFtcFByb3ZpZGVyIH0gZnJvbSAnLi9zY2hlZHVsZXIvZGF0ZVRpbWVzdGFtcFByb3ZpZGVyJztcbnZhciBSZXBsYXlTdWJqZWN0ID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoUmVwbGF5U3ViamVjdCwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBSZXBsYXlTdWJqZWN0KF9idWZmZXJTaXplLCBfd2luZG93VGltZSwgX3RpbWVzdGFtcFByb3ZpZGVyKSB7XG4gICAgICAgIGlmIChfYnVmZmVyU2l6ZSA9PT0gdm9pZCAwKSB7IF9idWZmZXJTaXplID0gSW5maW5pdHk7IH1cbiAgICAgICAgaWYgKF93aW5kb3dUaW1lID09PSB2b2lkIDApIHsgX3dpbmRvd1RpbWUgPSBJbmZpbml0eTsgfVxuICAgICAgICBpZiAoX3RpbWVzdGFtcFByb3ZpZGVyID09PSB2b2lkIDApIHsgX3RpbWVzdGFtcFByb3ZpZGVyID0gZGF0ZVRpbWVzdGFtcFByb3ZpZGVyOyB9XG4gICAgICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLl9idWZmZXJTaXplID0gX2J1ZmZlclNpemU7XG4gICAgICAgIF90aGlzLl93aW5kb3dUaW1lID0gX3dpbmRvd1RpbWU7XG4gICAgICAgIF90aGlzLl90aW1lc3RhbXBQcm92aWRlciA9IF90aW1lc3RhbXBQcm92aWRlcjtcbiAgICAgICAgX3RoaXMuX2J1ZmZlciA9IFtdO1xuICAgICAgICBfdGhpcy5faW5maW5pdGVUaW1lV2luZG93ID0gdHJ1ZTtcbiAgICAgICAgX3RoaXMuX2luZmluaXRlVGltZVdpbmRvdyA9IF93aW5kb3dUaW1lID09PSBJbmZpbml0eTtcbiAgICAgICAgX3RoaXMuX2J1ZmZlclNpemUgPSBNYXRoLm1heCgxLCBfYnVmZmVyU2l6ZSk7XG4gICAgICAgIF90aGlzLl93aW5kb3dUaW1lID0gTWF0aC5tYXgoMSwgX3dpbmRvd1RpbWUpO1xuICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgfVxuICAgIFJlcGxheVN1YmplY3QucHJvdG90eXBlLm5leHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgdmFyIF9hID0gdGhpcywgaXNTdG9wcGVkID0gX2EuaXNTdG9wcGVkLCBfYnVmZmVyID0gX2EuX2J1ZmZlciwgX2luZmluaXRlVGltZVdpbmRvdyA9IF9hLl9pbmZpbml0ZVRpbWVXaW5kb3csIF90aW1lc3RhbXBQcm92aWRlciA9IF9hLl90aW1lc3RhbXBQcm92aWRlciwgX3dpbmRvd1RpbWUgPSBfYS5fd2luZG93VGltZTtcbiAgICAgICAgaWYgKCFpc1N0b3BwZWQpIHtcbiAgICAgICAgICAgIF9idWZmZXIucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICAhX2luZmluaXRlVGltZVdpbmRvdyAmJiBfYnVmZmVyLnB1c2goX3RpbWVzdGFtcFByb3ZpZGVyLm5vdygpICsgX3dpbmRvd1RpbWUpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3RyaW1CdWZmZXIoKTtcbiAgICAgICAgX3N1cGVyLnByb3RvdHlwZS5uZXh0LmNhbGwodGhpcywgdmFsdWUpO1xuICAgIH07XG4gICAgUmVwbGF5U3ViamVjdC5wcm90b3R5cGUuX3N1YnNjcmliZSA9IGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHRoaXMuX3Rocm93SWZDbG9zZWQoKTtcbiAgICAgICAgdGhpcy5fdHJpbUJ1ZmZlcigpO1xuICAgICAgICB2YXIgc3Vic2NyaXB0aW9uID0gdGhpcy5faW5uZXJTdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgICAgIHZhciBfYSA9IHRoaXMsIF9pbmZpbml0ZVRpbWVXaW5kb3cgPSBfYS5faW5maW5pdGVUaW1lV2luZG93LCBfYnVmZmVyID0gX2EuX2J1ZmZlcjtcbiAgICAgICAgdmFyIGNvcHkgPSBfYnVmZmVyLnNsaWNlKCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY29weS5sZW5ndGggJiYgIXN1YnNjcmliZXIuY2xvc2VkOyBpICs9IF9pbmZpbml0ZVRpbWVXaW5kb3cgPyAxIDogMikge1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGNvcHlbaV0pO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2NoZWNrRmluYWxpemVkU3RhdHVzZXMoc3Vic2NyaWJlcik7XG4gICAgICAgIHJldHVybiBzdWJzY3JpcHRpb247XG4gICAgfTtcbiAgICBSZXBsYXlTdWJqZWN0LnByb3RvdHlwZS5fdHJpbUJ1ZmZlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIF9hID0gdGhpcywgX2J1ZmZlclNpemUgPSBfYS5fYnVmZmVyU2l6ZSwgX3RpbWVzdGFtcFByb3ZpZGVyID0gX2EuX3RpbWVzdGFtcFByb3ZpZGVyLCBfYnVmZmVyID0gX2EuX2J1ZmZlciwgX2luZmluaXRlVGltZVdpbmRvdyA9IF9hLl9pbmZpbml0ZVRpbWVXaW5kb3c7XG4gICAgICAgIHZhciBhZGp1c3RlZEJ1ZmZlclNpemUgPSAoX2luZmluaXRlVGltZVdpbmRvdyA/IDEgOiAyKSAqIF9idWZmZXJTaXplO1xuICAgICAgICBfYnVmZmVyU2l6ZSA8IEluZmluaXR5ICYmIGFkanVzdGVkQnVmZmVyU2l6ZSA8IF9idWZmZXIubGVuZ3RoICYmIF9idWZmZXIuc3BsaWNlKDAsIF9idWZmZXIubGVuZ3RoIC0gYWRqdXN0ZWRCdWZmZXJTaXplKTtcbiAgICAgICAgaWYgKCFfaW5maW5pdGVUaW1lV2luZG93KSB7XG4gICAgICAgICAgICB2YXIgbm93ID0gX3RpbWVzdGFtcFByb3ZpZGVyLm5vdygpO1xuICAgICAgICAgICAgdmFyIGxhc3QgPSAwO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDE7IGkgPCBfYnVmZmVyLmxlbmd0aCAmJiBfYnVmZmVyW2ldIDw9IG5vdzsgaSArPSAyKSB7XG4gICAgICAgICAgICAgICAgbGFzdCA9IGk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsYXN0ICYmIF9idWZmZXIuc3BsaWNlKDAsIGxhc3QgKyAxKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIFJlcGxheVN1YmplY3Q7XG59KFN1YmplY3QpKTtcbmV4cG9ydCB7IFJlcGxheVN1YmplY3QgfTtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4vU3ViamVjdCc7XG52YXIgQXN5bmNTdWJqZWN0ID0gKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICBfX2V4dGVuZHMoQXN5bmNTdWJqZWN0LCBfc3VwZXIpO1xuICAgIGZ1bmN0aW9uIEFzeW5jU3ViamVjdCgpIHtcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyICE9PSBudWxsICYmIF9zdXBlci5hcHBseSh0aGlzLCBhcmd1bWVudHMpIHx8IHRoaXM7XG4gICAgICAgIF90aGlzLl92YWx1ZSA9IG51bGw7XG4gICAgICAgIF90aGlzLl9oYXNWYWx1ZSA9IGZhbHNlO1xuICAgICAgICBfdGhpcy5faXNDb21wbGV0ZSA9IGZhbHNlO1xuICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgfVxuICAgIEFzeW5jU3ViamVjdC5wcm90b3R5cGUuX2NoZWNrRmluYWxpemVkU3RhdHVzZXMgPSBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgX2EgPSB0aGlzLCBoYXNFcnJvciA9IF9hLmhhc0Vycm9yLCBfaGFzVmFsdWUgPSBfYS5faGFzVmFsdWUsIF92YWx1ZSA9IF9hLl92YWx1ZSwgdGhyb3duRXJyb3IgPSBfYS50aHJvd25FcnJvciwgaXNTdG9wcGVkID0gX2EuaXNTdG9wcGVkLCBfaXNDb21wbGV0ZSA9IF9hLl9pc0NvbXBsZXRlO1xuICAgICAgICBpZiAoaGFzRXJyb3IpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIuZXJyb3IodGhyb3duRXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzU3RvcHBlZCB8fCBfaXNDb21wbGV0ZSkge1xuICAgICAgICAgICAgX2hhc1ZhbHVlICYmIHN1YnNjcmliZXIubmV4dChfdmFsdWUpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBBc3luY1N1YmplY3QucHJvdG90eXBlLm5leHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgaWYgKCF0aGlzLmlzU3RvcHBlZCkge1xuICAgICAgICAgICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgIHRoaXMuX2hhc1ZhbHVlID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgQXN5bmNTdWJqZWN0LnByb3RvdHlwZS5jb21wbGV0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIF9hID0gdGhpcywgX2hhc1ZhbHVlID0gX2EuX2hhc1ZhbHVlLCBfdmFsdWUgPSBfYS5fdmFsdWUsIF9pc0NvbXBsZXRlID0gX2EuX2lzQ29tcGxldGU7XG4gICAgICAgIGlmICghX2lzQ29tcGxldGUpIHtcbiAgICAgICAgICAgIHRoaXMuX2lzQ29tcGxldGUgPSB0cnVlO1xuICAgICAgICAgICAgX2hhc1ZhbHVlICYmIF9zdXBlci5wcm90b3R5cGUubmV4dC5jYWxsKHRoaXMsIF92YWx1ZSk7XG4gICAgICAgICAgICBfc3VwZXIucHJvdG90eXBlLmNvbXBsZXRlLmNhbGwodGhpcyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBBc3luY1N1YmplY3Q7XG59KFN1YmplY3QpKTtcbmV4cG9ydCB7IEFzeW5jU3ViamVjdCB9O1xuIiwiaW1wb3J0IHsgX19leHRlbmRzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICcuLi9TdWJzY3JpcHRpb24nO1xudmFyIEFjdGlvbiA9IChmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgX19leHRlbmRzKEFjdGlvbiwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBY3Rpb24oc2NoZWR1bGVyLCB3b3JrKSB7XG4gICAgICAgIHJldHVybiBfc3VwZXIuY2FsbCh0aGlzKSB8fCB0aGlzO1xuICAgIH1cbiAgICBBY3Rpb24ucHJvdG90eXBlLnNjaGVkdWxlID0gZnVuY3Rpb24gKHN0YXRlLCBkZWxheSkge1xuICAgICAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICByZXR1cm4gQWN0aW9uO1xufShTdWJzY3JpcHRpb24pKTtcbmV4cG9ydCB7IEFjdGlvbiB9O1xuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5leHBvcnQgdmFyIGludGVydmFsUHJvdmlkZXIgPSB7XG4gICAgc2V0SW50ZXJ2YWw6IGZ1bmN0aW9uIChoYW5kbGVyLCB0aW1lb3V0KSB7XG4gICAgICAgIHZhciBhcmdzID0gW107XG4gICAgICAgIGZvciAodmFyIF9pID0gMjsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgICAgICBhcmdzW19pIC0gMl0gPSBhcmd1bWVudHNbX2ldO1xuICAgICAgICB9XG4gICAgICAgIHZhciBkZWxlZ2F0ZSA9IGludGVydmFsUHJvdmlkZXIuZGVsZWdhdGU7XG4gICAgICAgIGlmIChkZWxlZ2F0ZSA9PT0gbnVsbCB8fCBkZWxlZ2F0ZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogZGVsZWdhdGUuc2V0SW50ZXJ2YWwpIHtcbiAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0ZS5zZXRJbnRlcnZhbC5hcHBseShkZWxlZ2F0ZSwgX19zcHJlYWRBcnJheShbaGFuZGxlciwgdGltZW91dF0sIF9fcmVhZChhcmdzKSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzZXRJbnRlcnZhbC5hcHBseSh2b2lkIDAsIF9fc3ByZWFkQXJyYXkoW2hhbmRsZXIsIHRpbWVvdXRdLCBfX3JlYWQoYXJncykpKTtcbiAgICB9LFxuICAgIGNsZWFySW50ZXJ2YWw6IGZ1bmN0aW9uIChoYW5kbGUpIHtcbiAgICAgICAgdmFyIGRlbGVnYXRlID0gaW50ZXJ2YWxQcm92aWRlci5kZWxlZ2F0ZTtcbiAgICAgICAgcmV0dXJuICgoZGVsZWdhdGUgPT09IG51bGwgfHwgZGVsZWdhdGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGRlbGVnYXRlLmNsZWFySW50ZXJ2YWwpIHx8IGNsZWFySW50ZXJ2YWwpKGhhbmRsZSk7XG4gICAgfSxcbiAgICBkZWxlZ2F0ZTogdW5kZWZpbmVkLFxufTtcbiIsImltcG9ydCB7IF9fZXh0ZW5kcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgQWN0aW9uIH0gZnJvbSAnLi9BY3Rpb24nO1xuaW1wb3J0IHsgaW50ZXJ2YWxQcm92aWRlciB9IGZyb20gJy4vaW50ZXJ2YWxQcm92aWRlcic7XG5pbXBvcnQgeyBhcnJSZW1vdmUgfSBmcm9tICcuLi91dGlsL2FyclJlbW92ZSc7XG52YXIgQXN5bmNBY3Rpb24gPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhBc3luY0FjdGlvbiwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBc3luY0FjdGlvbihzY2hlZHVsZXIsIHdvcmspIHtcbiAgICAgICAgdmFyIF90aGlzID0gX3N1cGVyLmNhbGwodGhpcywgc2NoZWR1bGVyLCB3b3JrKSB8fCB0aGlzO1xuICAgICAgICBfdGhpcy5zY2hlZHVsZXIgPSBzY2hlZHVsZXI7XG4gICAgICAgIF90aGlzLndvcmsgPSB3b3JrO1xuICAgICAgICBfdGhpcy5wZW5kaW5nID0gZmFsc2U7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgQXN5bmNBY3Rpb24ucHJvdG90eXBlLnNjaGVkdWxlID0gZnVuY3Rpb24gKHN0YXRlLCBkZWxheSkge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmIChkZWxheSA9PT0gdm9pZCAwKSB7IGRlbGF5ID0gMDsgfVxuICAgICAgICBpZiAodGhpcy5jbG9zZWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc3RhdGUgPSBzdGF0ZTtcbiAgICAgICAgdmFyIGlkID0gdGhpcy5pZDtcbiAgICAgICAgdmFyIHNjaGVkdWxlciA9IHRoaXMuc2NoZWR1bGVyO1xuICAgICAgICBpZiAoaWQgIT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5pZCA9IHRoaXMucmVjeWNsZUFzeW5jSWQoc2NoZWR1bGVyLCBpZCwgZGVsYXkpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMucGVuZGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMuZGVsYXkgPSBkZWxheTtcbiAgICAgICAgdGhpcy5pZCA9IChfYSA9IHRoaXMuaWQpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IHRoaXMucmVxdWVzdEFzeW5jSWQoc2NoZWR1bGVyLCB0aGlzLmlkLCBkZWxheSk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgQXN5bmNBY3Rpb24ucHJvdG90eXBlLnJlcXVlc3RBc3luY0lkID0gZnVuY3Rpb24gKHNjaGVkdWxlciwgX2lkLCBkZWxheSkge1xuICAgICAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICAgICAgcmV0dXJuIGludGVydmFsUHJvdmlkZXIuc2V0SW50ZXJ2YWwoc2NoZWR1bGVyLmZsdXNoLmJpbmQoc2NoZWR1bGVyLCB0aGlzKSwgZGVsYXkpO1xuICAgIH07XG4gICAgQXN5bmNBY3Rpb24ucHJvdG90eXBlLnJlY3ljbGVBc3luY0lkID0gZnVuY3Rpb24gKF9zY2hlZHVsZXIsIGlkLCBkZWxheSkge1xuICAgICAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICAgICAgaWYgKGRlbGF5ICE9IG51bGwgJiYgdGhpcy5kZWxheSA9PT0gZGVsYXkgJiYgdGhpcy5wZW5kaW5nID09PSBmYWxzZSkge1xuICAgICAgICAgICAgcmV0dXJuIGlkO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpZCAhPSBudWxsKSB7XG4gICAgICAgICAgICBpbnRlcnZhbFByb3ZpZGVyLmNsZWFySW50ZXJ2YWwoaWQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfTtcbiAgICBBc3luY0FjdGlvbi5wcm90b3R5cGUuZXhlY3V0ZSA9IGZ1bmN0aW9uIChzdGF0ZSwgZGVsYXkpIHtcbiAgICAgICAgaWYgKHRoaXMuY2xvc2VkKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IEVycm9yKCdleGVjdXRpbmcgYSBjYW5jZWxsZWQgYWN0aW9uJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5wZW5kaW5nID0gZmFsc2U7XG4gICAgICAgIHZhciBlcnJvciA9IHRoaXMuX2V4ZWN1dGUoc3RhdGUsIGRlbGF5KTtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodGhpcy5wZW5kaW5nID09PSBmYWxzZSAmJiB0aGlzLmlkICE9IG51bGwpIHtcbiAgICAgICAgICAgIHRoaXMuaWQgPSB0aGlzLnJlY3ljbGVBc3luY0lkKHRoaXMuc2NoZWR1bGVyLCB0aGlzLmlkLCBudWxsKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgQXN5bmNBY3Rpb24ucHJvdG90eXBlLl9leGVjdXRlID0gZnVuY3Rpb24gKHN0YXRlLCBfZGVsYXkpIHtcbiAgICAgICAgdmFyIGVycm9yZWQgPSBmYWxzZTtcbiAgICAgICAgdmFyIGVycm9yVmFsdWU7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB0aGlzLndvcmsoc3RhdGUpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICBlcnJvcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgIGVycm9yVmFsdWUgPSBlID8gZSA6IG5ldyBFcnJvcignU2NoZWR1bGVkIGFjdGlvbiB0aHJldyBmYWxzeSBlcnJvcicpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChlcnJvcmVkKSB7XG4gICAgICAgICAgICB0aGlzLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3JWYWx1ZTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgQXN5bmNBY3Rpb24ucHJvdG90eXBlLnVuc3Vic2NyaWJlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZiAoIXRoaXMuY2xvc2VkKSB7XG4gICAgICAgICAgICB2YXIgX2EgPSB0aGlzLCBpZCA9IF9hLmlkLCBzY2hlZHVsZXIgPSBfYS5zY2hlZHVsZXI7XG4gICAgICAgICAgICB2YXIgYWN0aW9ucyA9IHNjaGVkdWxlci5hY3Rpb25zO1xuICAgICAgICAgICAgdGhpcy53b3JrID0gdGhpcy5zdGF0ZSA9IHRoaXMuc2NoZWR1bGVyID0gbnVsbDtcbiAgICAgICAgICAgIHRoaXMucGVuZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgYXJyUmVtb3ZlKGFjdGlvbnMsIHRoaXMpO1xuICAgICAgICAgICAgaWYgKGlkICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmlkID0gdGhpcy5yZWN5Y2xlQXN5bmNJZChzY2hlZHVsZXIsIGlkLCBudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuZGVsYXkgPSBudWxsO1xuICAgICAgICAgICAgX3N1cGVyLnByb3RvdHlwZS51bnN1YnNjcmliZS5jYWxsKHRoaXMpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gQXN5bmNBY3Rpb247XG59KEFjdGlvbikpO1xuZXhwb3J0IHsgQXN5bmNBY3Rpb24gfTtcbiIsImltcG9ydCB7IGRhdGVUaW1lc3RhbXBQcm92aWRlciB9IGZyb20gJy4vc2NoZWR1bGVyL2RhdGVUaW1lc3RhbXBQcm92aWRlcic7XG52YXIgU2NoZWR1bGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBTY2hlZHVsZXIoc2NoZWR1bGVyQWN0aW9uQ3Rvciwgbm93KSB7XG4gICAgICAgIGlmIChub3cgPT09IHZvaWQgMCkgeyBub3cgPSBTY2hlZHVsZXIubm93OyB9XG4gICAgICAgIHRoaXMuc2NoZWR1bGVyQWN0aW9uQ3RvciA9IHNjaGVkdWxlckFjdGlvbkN0b3I7XG4gICAgICAgIHRoaXMubm93ID0gbm93O1xuICAgIH1cbiAgICBTY2hlZHVsZXIucHJvdG90eXBlLnNjaGVkdWxlID0gZnVuY3Rpb24gKHdvcmssIGRlbGF5LCBzdGF0ZSkge1xuICAgICAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICAgICAgcmV0dXJuIG5ldyB0aGlzLnNjaGVkdWxlckFjdGlvbkN0b3IodGhpcywgd29yaykuc2NoZWR1bGUoc3RhdGUsIGRlbGF5KTtcbiAgICB9O1xuICAgIFNjaGVkdWxlci5ub3cgPSBkYXRlVGltZXN0YW1wUHJvdmlkZXIubm93O1xuICAgIHJldHVybiBTY2hlZHVsZXI7XG59KCkpO1xuZXhwb3J0IHsgU2NoZWR1bGVyIH07XG4iLCJpbXBvcnQgeyBfX2V4dGVuZHMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IFNjaGVkdWxlciB9IGZyb20gJy4uL1NjaGVkdWxlcic7XG52YXIgQXN5bmNTY2hlZHVsZXIgPSAoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIF9fZXh0ZW5kcyhBc3luY1NjaGVkdWxlciwgX3N1cGVyKTtcbiAgICBmdW5jdGlvbiBBc3luY1NjaGVkdWxlcihTY2hlZHVsZXJBY3Rpb24sIG5vdykge1xuICAgICAgICBpZiAobm93ID09PSB2b2lkIDApIHsgbm93ID0gU2NoZWR1bGVyLm5vdzsgfVxuICAgICAgICB2YXIgX3RoaXMgPSBfc3VwZXIuY2FsbCh0aGlzLCBTY2hlZHVsZXJBY3Rpb24sIG5vdykgfHwgdGhpcztcbiAgICAgICAgX3RoaXMuYWN0aW9ucyA9IFtdO1xuICAgICAgICBfdGhpcy5fYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHJldHVybiBfdGhpcztcbiAgICB9XG4gICAgQXN5bmNTY2hlZHVsZXIucHJvdG90eXBlLmZsdXNoID0gZnVuY3Rpb24gKGFjdGlvbikge1xuICAgICAgICB2YXIgYWN0aW9ucyA9IHRoaXMuYWN0aW9ucztcbiAgICAgICAgaWYgKHRoaXMuX2FjdGl2ZSkge1xuICAgICAgICAgICAgYWN0aW9ucy5wdXNoKGFjdGlvbik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGVycm9yO1xuICAgICAgICB0aGlzLl9hY3RpdmUgPSB0cnVlO1xuICAgICAgICBkbyB7XG4gICAgICAgICAgICBpZiAoKGVycm9yID0gYWN0aW9uLmV4ZWN1dGUoYWN0aW9uLnN0YXRlLCBhY3Rpb24uZGVsYXkpKSkge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IHdoaWxlICgoYWN0aW9uID0gYWN0aW9ucy5zaGlmdCgpKSk7XG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IGZhbHNlO1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHdoaWxlICgoYWN0aW9uID0gYWN0aW9ucy5zaGlmdCgpKSkge1xuICAgICAgICAgICAgICAgIGFjdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBBc3luY1NjaGVkdWxlcjtcbn0oU2NoZWR1bGVyKSk7XG5leHBvcnQgeyBBc3luY1NjaGVkdWxlciB9O1xuIiwiaW1wb3J0IHsgQXN5bmNBY3Rpb24gfSBmcm9tICcuL0FzeW5jQWN0aW9uJztcbmltcG9ydCB7IEFzeW5jU2NoZWR1bGVyIH0gZnJvbSAnLi9Bc3luY1NjaGVkdWxlcic7XG5leHBvcnQgdmFyIGFzeW5jU2NoZWR1bGVyID0gbmV3IEFzeW5jU2NoZWR1bGVyKEFzeW5jQWN0aW9uKTtcbmV4cG9ydCB2YXIgYXN5bmMgPSBhc3luY1NjaGVkdWxlcjtcbiIsImltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuLi9PYnNlcnZhYmxlJztcbmV4cG9ydCB2YXIgRU1QVFkgPSBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAoc3Vic2NyaWJlcikgeyByZXR1cm4gc3Vic2NyaWJlci5jb21wbGV0ZSgpOyB9KTtcbmV4cG9ydCBmdW5jdGlvbiBlbXB0eShzY2hlZHVsZXIpIHtcbiAgICByZXR1cm4gc2NoZWR1bGVyID8gZW1wdHlTY2hlZHVsZWQoc2NoZWR1bGVyKSA6IEVNUFRZO1xufVxuZnVuY3Rpb24gZW1wdHlTY2hlZHVsZWQoc2NoZWR1bGVyKSB7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7IHJldHVybiBzY2hlZHVsZXIuc2NoZWR1bGUoZnVuY3Rpb24gKCkgeyByZXR1cm4gc3Vic2NyaWJlci5jb21wbGV0ZSgpOyB9KTsgfSk7XG59XG4iLCJpbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi9pc0Z1bmN0aW9uJztcbmV4cG9ydCBmdW5jdGlvbiBpc1NjaGVkdWxlcih2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZSAmJiBpc0Z1bmN0aW9uKHZhbHVlLnNjaGVkdWxlKTtcbn1cbiIsImltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuL2lzRnVuY3Rpb24nO1xuaW1wb3J0IHsgaXNTY2hlZHVsZXIgfSBmcm9tICcuL2lzU2NoZWR1bGVyJztcbmZ1bmN0aW9uIGxhc3QoYXJyKSB7XG4gICAgcmV0dXJuIGFyclthcnIubGVuZ3RoIC0gMV07XG59XG5leHBvcnQgZnVuY3Rpb24gcG9wUmVzdWx0U2VsZWN0b3IoYXJncykge1xuICAgIHJldHVybiBpc0Z1bmN0aW9uKGxhc3QoYXJncykpID8gYXJncy5wb3AoKSA6IHVuZGVmaW5lZDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwb3BTY2hlZHVsZXIoYXJncykge1xuICAgIHJldHVybiBpc1NjaGVkdWxlcihsYXN0KGFyZ3MpKSA/IGFyZ3MucG9wKCkgOiB1bmRlZmluZWQ7XG59XG5leHBvcnQgZnVuY3Rpb24gcG9wTnVtYmVyKGFyZ3MsIGRlZmF1bHRWYWx1ZSkge1xuICAgIHJldHVybiB0eXBlb2YgbGFzdChhcmdzKSA9PT0gJ251bWJlcicgPyBhcmdzLnBvcCgpIDogZGVmYXVsdFZhbHVlO1xufVxuIiwiZXhwb3J0IHZhciBpc0FycmF5TGlrZSA9IChmdW5jdGlvbiAoeCkgeyByZXR1cm4geCAmJiB0eXBlb2YgeC5sZW5ndGggPT09ICdudW1iZXInICYmIHR5cGVvZiB4ICE9PSAnZnVuY3Rpb24nOyB9KTtcbiIsImltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tIFwiLi9pc0Z1bmN0aW9uXCI7XG5leHBvcnQgZnVuY3Rpb24gaXNQcm9taXNlKHZhbHVlKSB7XG4gICAgcmV0dXJuIGlzRnVuY3Rpb24odmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHZhbHVlLnRoZW4pO1xufVxuIiwiaW1wb3J0IHsgb2JzZXJ2YWJsZSBhcyBTeW1ib2xfb2JzZXJ2YWJsZSB9IGZyb20gJy4uL3N5bWJvbC9vYnNlcnZhYmxlJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuL2lzRnVuY3Rpb24nO1xuZXhwb3J0IGZ1bmN0aW9uIGlzSW50ZXJvcE9ic2VydmFibGUoaW5wdXQpIHtcbiAgICByZXR1cm4gaXNGdW5jdGlvbihpbnB1dFtTeW1ib2xfb2JzZXJ2YWJsZV0pO1xufVxuIiwiaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4vaXNGdW5jdGlvbic7XG5leHBvcnQgZnVuY3Rpb24gaXNBc3luY0l0ZXJhYmxlKG9iaikge1xuICAgIHJldHVybiBTeW1ib2wuYXN5bmNJdGVyYXRvciAmJiBpc0Z1bmN0aW9uKG9iaiA9PT0gbnVsbCB8fCBvYmogPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9ialtTeW1ib2wuYXN5bmNJdGVyYXRvcl0pO1xufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUludmFsaWRPYnNlcnZhYmxlVHlwZUVycm9yKGlucHV0KSB7XG4gICAgcmV0dXJuIG5ldyBUeXBlRXJyb3IoXCJZb3UgcHJvdmlkZWQgXCIgKyAoaW5wdXQgIT09IG51bGwgJiYgdHlwZW9mIGlucHV0ID09PSAnb2JqZWN0JyA/ICdhbiBpbnZhbGlkIG9iamVjdCcgOiBcIidcIiArIGlucHV0ICsgXCInXCIpICsgXCIgd2hlcmUgYSBzdHJlYW0gd2FzIGV4cGVjdGVkLiBZb3UgY2FuIHByb3ZpZGUgYW4gT2JzZXJ2YWJsZSwgUHJvbWlzZSwgUmVhZGFibGVTdHJlYW0sIEFycmF5LCBBc3luY0l0ZXJhYmxlLCBvciBJdGVyYWJsZS5cIik7XG59XG4iLCJleHBvcnQgZnVuY3Rpb24gZ2V0U3ltYm9sSXRlcmF0b3IoKSB7XG4gICAgaWYgKHR5cGVvZiBTeW1ib2wgIT09ICdmdW5jdGlvbicgfHwgIVN5bWJvbC5pdGVyYXRvcikge1xuICAgICAgICByZXR1cm4gJ0BAaXRlcmF0b3InO1xuICAgIH1cbiAgICByZXR1cm4gU3ltYm9sLml0ZXJhdG9yO1xufVxuZXhwb3J0IHZhciBpdGVyYXRvciA9IGdldFN5bWJvbEl0ZXJhdG9yKCk7XG4iLCJpbXBvcnQgeyBpdGVyYXRvciBhcyBTeW1ib2xfaXRlcmF0b3IgfSBmcm9tICcuLi9zeW1ib2wvaXRlcmF0b3InO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4vaXNGdW5jdGlvbic7XG5leHBvcnQgZnVuY3Rpb24gaXNJdGVyYWJsZShpbnB1dCkge1xuICAgIHJldHVybiBpc0Z1bmN0aW9uKGlucHV0ID09PSBudWxsIHx8IGlucHV0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBpbnB1dFtTeW1ib2xfaXRlcmF0b3JdKTtcbn1cbiIsImltcG9ydCB7IF9fYXN5bmNHZW5lcmF0b3IsIF9fYXdhaXQsIF9fZ2VuZXJhdG9yIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi9pc0Z1bmN0aW9uJztcbmV4cG9ydCBmdW5jdGlvbiByZWFkYWJsZVN0cmVhbUxpa2VUb0FzeW5jR2VuZXJhdG9yKHJlYWRhYmxlU3RyZWFtKSB7XG4gICAgcmV0dXJuIF9fYXN5bmNHZW5lcmF0b3IodGhpcywgYXJndW1lbnRzLCBmdW5jdGlvbiByZWFkYWJsZVN0cmVhbUxpa2VUb0FzeW5jR2VuZXJhdG9yXzEoKSB7XG4gICAgICAgIHZhciByZWFkZXIsIF9hLCB2YWx1ZSwgZG9uZTtcbiAgICAgICAgcmV0dXJuIF9fZ2VuZXJhdG9yKHRoaXMsIGZ1bmN0aW9uIChfYikge1xuICAgICAgICAgICAgc3dpdGNoIChfYi5sYWJlbCkge1xuICAgICAgICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgICAgICAgICAgcmVhZGVyID0gcmVhZGFibGVTdHJlYW0uZ2V0UmVhZGVyKCk7XG4gICAgICAgICAgICAgICAgICAgIF9iLmxhYmVsID0gMTtcbiAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgIF9iLnRyeXMucHVzaChbMSwgLCA5LCAxMF0pO1xuICAgICAgICAgICAgICAgICAgICBfYi5sYWJlbCA9IDI7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBpZiAoIXRydWUpIHJldHVybiBbMywgOF07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbNCwgX19hd2FpdChyZWFkZXIucmVhZCgpKV07XG4gICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICBfYSA9IF9iLnNlbnQoKSwgdmFsdWUgPSBfYS52YWx1ZSwgZG9uZSA9IF9hLmRvbmU7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZG9uZSkgcmV0dXJuIFszLCA1XTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0LCBfX2F3YWl0KHZvaWQgMCldO1xuICAgICAgICAgICAgICAgIGNhc2UgNDogcmV0dXJuIFsyLCBfYi5zZW50KCldO1xuICAgICAgICAgICAgICAgIGNhc2UgNTogcmV0dXJuIFs0LCBfX2F3YWl0KHZhbHVlKV07XG4gICAgICAgICAgICAgICAgY2FzZSA2OiByZXR1cm4gWzQsIF9iLnNlbnQoKV07XG4gICAgICAgICAgICAgICAgY2FzZSA3OlxuICAgICAgICAgICAgICAgICAgICBfYi5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMywgMl07XG4gICAgICAgICAgICAgICAgY2FzZSA4OiByZXR1cm4gWzMsIDEwXTtcbiAgICAgICAgICAgICAgICBjYXNlIDk6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5yZWxlYXNlTG9jaygpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gWzddO1xuICAgICAgICAgICAgICAgIGNhc2UgMTA6IHJldHVybiBbMl07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzUmVhZGFibGVTdHJlYW1MaWtlKG9iaikge1xuICAgIHJldHVybiBpc0Z1bmN0aW9uKG9iaiA9PT0gbnVsbCB8fCBvYmogPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9iai5nZXRSZWFkZXIpO1xufVxuIiwiaW1wb3J0IHsgX19hc3luY1ZhbHVlcywgX19hd2FpdGVyLCBfX2dlbmVyYXRvciwgX192YWx1ZXMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGlzQXJyYXlMaWtlIH0gZnJvbSAnLi4vdXRpbC9pc0FycmF5TGlrZSc7XG5pbXBvcnQgeyBpc1Byb21pc2UgfSBmcm9tICcuLi91dGlsL2lzUHJvbWlzZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBpc0ludGVyb3BPYnNlcnZhYmxlIH0gZnJvbSAnLi4vdXRpbC9pc0ludGVyb3BPYnNlcnZhYmxlJztcbmltcG9ydCB7IGlzQXN5bmNJdGVyYWJsZSB9IGZyb20gJy4uL3V0aWwvaXNBc3luY0l0ZXJhYmxlJztcbmltcG9ydCB7IGNyZWF0ZUludmFsaWRPYnNlcnZhYmxlVHlwZUVycm9yIH0gZnJvbSAnLi4vdXRpbC90aHJvd1Vub2JzZXJ2YWJsZUVycm9yJztcbmltcG9ydCB7IGlzSXRlcmFibGUgfSBmcm9tICcuLi91dGlsL2lzSXRlcmFibGUnO1xuaW1wb3J0IHsgaXNSZWFkYWJsZVN0cmVhbUxpa2UsIHJlYWRhYmxlU3RyZWFtTGlrZVRvQXN5bmNHZW5lcmF0b3IgfSBmcm9tICcuLi91dGlsL2lzUmVhZGFibGVTdHJlYW1MaWtlJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuLi91dGlsL2lzRnVuY3Rpb24nO1xuaW1wb3J0IHsgcmVwb3J0VW5oYW5kbGVkRXJyb3IgfSBmcm9tICcuLi91dGlsL3JlcG9ydFVuaGFuZGxlZEVycm9yJztcbmltcG9ydCB7IG9ic2VydmFibGUgYXMgU3ltYm9sX29ic2VydmFibGUgfSBmcm9tICcuLi9zeW1ib2wvb2JzZXJ2YWJsZSc7XG5leHBvcnQgZnVuY3Rpb24gaW5uZXJGcm9tKGlucHV0KSB7XG4gICAgaWYgKGlucHV0IGluc3RhbmNlb2YgT2JzZXJ2YWJsZSkge1xuICAgICAgICByZXR1cm4gaW5wdXQ7XG4gICAgfVxuICAgIGlmIChpbnB1dCAhPSBudWxsKSB7XG4gICAgICAgIGlmIChpc0ludGVyb3BPYnNlcnZhYmxlKGlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyb21JbnRlcm9wT2JzZXJ2YWJsZShpbnB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQXJyYXlMaWtlKGlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyb21BcnJheUxpa2UoaW5wdXQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1Byb21pc2UoaW5wdXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gZnJvbVByb21pc2UoaW5wdXQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0FzeW5jSXRlcmFibGUoaW5wdXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gZnJvbUFzeW5jSXRlcmFibGUoaW5wdXQpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0l0ZXJhYmxlKGlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyb21JdGVyYWJsZShpbnB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzUmVhZGFibGVTdHJlYW1MaWtlKGlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyb21SZWFkYWJsZVN0cmVhbUxpa2UoaW5wdXQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IGNyZWF0ZUludmFsaWRPYnNlcnZhYmxlVHlwZUVycm9yKGlucHV0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmcm9tSW50ZXJvcE9ic2VydmFibGUob2JqKSB7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBvYnMgPSBvYmpbU3ltYm9sX29ic2VydmFibGVdKCk7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKG9icy5zdWJzY3JpYmUpKSB7XG4gICAgICAgICAgICByZXR1cm4gb2JzLnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdQcm92aWRlZCBvYmplY3QgZG9lcyBub3QgY29ycmVjdGx5IGltcGxlbWVudCBTeW1ib2wub2JzZXJ2YWJsZScpO1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZyb21BcnJheUxpa2UoYXJyYXkpIHtcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcnJheS5sZW5ndGggJiYgIXN1YnNjcmliZXIuY2xvc2VkOyBpKyspIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChhcnJheVtpXSk7XG4gICAgICAgIH1cbiAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZyb21Qcm9taXNlKHByb21pc2UpIHtcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgcHJvbWlzZVxuICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBpZiAoIXN1YnNjcmliZXIuY2xvc2VkKSB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHsgcmV0dXJuIHN1YnNjcmliZXIuZXJyb3IoZXJyKTsgfSlcbiAgICAgICAgICAgIC50aGVuKG51bGwsIHJlcG9ydFVuaGFuZGxlZEVycm9yKTtcbiAgICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmcm9tSXRlcmFibGUoaXRlcmFibGUpIHtcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGVfMSwgX2E7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBmb3IgKHZhciBpdGVyYWJsZV8xID0gX192YWx1ZXMoaXRlcmFibGUpLCBpdGVyYWJsZV8xXzEgPSBpdGVyYWJsZV8xLm5leHQoKTsgIWl0ZXJhYmxlXzFfMS5kb25lOyBpdGVyYWJsZV8xXzEgPSBpdGVyYWJsZV8xLm5leHQoKSkge1xuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IGl0ZXJhYmxlXzFfMS52YWx1ZTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmIChzdWJzY3JpYmVyLmNsb3NlZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlXzFfMSkgeyBlXzEgPSB7IGVycm9yOiBlXzFfMSB9OyB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBpZiAoaXRlcmFibGVfMV8xICYmICFpdGVyYWJsZV8xXzEuZG9uZSAmJiAoX2EgPSBpdGVyYWJsZV8xLnJldHVybikpIF9hLmNhbGwoaXRlcmFibGVfMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgIH1cbiAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZyb21Bc3luY0l0ZXJhYmxlKGFzeW5jSXRlcmFibGUpIHtcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHtcbiAgICAgICAgcHJvY2Vzcyhhc3luY0l0ZXJhYmxlLCBzdWJzY3JpYmVyKS5jYXRjaChmdW5jdGlvbiAoZXJyKSB7IHJldHVybiBzdWJzY3JpYmVyLmVycm9yKGVycik7IH0pO1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZyb21SZWFkYWJsZVN0cmVhbUxpa2UocmVhZGFibGVTdHJlYW0pIHtcbiAgICByZXR1cm4gZnJvbUFzeW5jSXRlcmFibGUocmVhZGFibGVTdHJlYW1MaWtlVG9Bc3luY0dlbmVyYXRvcihyZWFkYWJsZVN0cmVhbSkpO1xufVxuZnVuY3Rpb24gcHJvY2Vzcyhhc3luY0l0ZXJhYmxlLCBzdWJzY3JpYmVyKSB7XG4gICAgdmFyIGFzeW5jSXRlcmFibGVfMSwgYXN5bmNJdGVyYWJsZV8xXzE7XG4gICAgdmFyIGVfMiwgX2E7XG4gICAgcmV0dXJuIF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgdmFsdWUsIGVfMl8xO1xuICAgICAgICByZXR1cm4gX19nZW5lcmF0b3IodGhpcywgZnVuY3Rpb24gKF9iKSB7XG4gICAgICAgICAgICBzd2l0Y2ggKF9iLmxhYmVsKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgICAgICAgICBfYi50cnlzLnB1c2goWzAsIDUsIDYsIDExXSk7XG4gICAgICAgICAgICAgICAgICAgIGFzeW5jSXRlcmFibGVfMSA9IF9fYXN5bmNWYWx1ZXMoYXN5bmNJdGVyYWJsZSk7XG4gICAgICAgICAgICAgICAgICAgIF9iLmxhYmVsID0gMTtcbiAgICAgICAgICAgICAgICBjYXNlIDE6IHJldHVybiBbNCwgYXN5bmNJdGVyYWJsZV8xLm5leHQoKV07XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBpZiAoIShhc3luY0l0ZXJhYmxlXzFfMSA9IF9iLnNlbnQoKSwgIWFzeW5jSXRlcmFibGVfMV8xLmRvbmUpKSByZXR1cm4gWzMsIDRdO1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZSA9IGFzeW5jSXRlcmFibGVfMV8xLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc3Vic2NyaWJlci5jbG9zZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbMl07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgX2IubGFiZWwgPSAzO1xuICAgICAgICAgICAgICAgIGNhc2UgMzogcmV0dXJuIFszLCAxXTtcbiAgICAgICAgICAgICAgICBjYXNlIDQ6IHJldHVybiBbMywgMTFdO1xuICAgICAgICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgICAgICAgICAgZV8yXzEgPSBfYi5zZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIGVfMiA9IHsgZXJyb3I6IGVfMl8xIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMywgMTFdO1xuICAgICAgICAgICAgICAgIGNhc2UgNjpcbiAgICAgICAgICAgICAgICAgICAgX2IudHJ5cy5wdXNoKFs2LCAsIDksIDEwXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghKGFzeW5jSXRlcmFibGVfMV8xICYmICFhc3luY0l0ZXJhYmxlXzFfMS5kb25lICYmIChfYSA9IGFzeW5jSXRlcmFibGVfMS5yZXR1cm4pKSkgcmV0dXJuIFszLCA4XTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs0LCBfYS5jYWxsKGFzeW5jSXRlcmFibGVfMSldO1xuICAgICAgICAgICAgICAgIGNhc2UgNzpcbiAgICAgICAgICAgICAgICAgICAgX2Iuc2VudCgpO1xuICAgICAgICAgICAgICAgICAgICBfYi5sYWJlbCA9IDg7XG4gICAgICAgICAgICAgICAgY2FzZSA4OiByZXR1cm4gWzMsIDEwXTtcbiAgICAgICAgICAgICAgICBjYXNlIDk6XG4gICAgICAgICAgICAgICAgICAgIGlmIChlXzIpIHRocm93IGVfMi5lcnJvcjtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFs3XTtcbiAgICAgICAgICAgICAgICBjYXNlIDEwOiByZXR1cm4gWzddO1xuICAgICAgICAgICAgICAgIGNhc2UgMTE6XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsyXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG4iLCJleHBvcnQgZnVuY3Rpb24gZXhlY3V0ZVNjaGVkdWxlKHBhcmVudFN1YnNjcmlwdGlvbiwgc2NoZWR1bGVyLCB3b3JrLCBkZWxheSwgcmVwZWF0KSB7XG4gICAgaWYgKGRlbGF5ID09PSB2b2lkIDApIHsgZGVsYXkgPSAwOyB9XG4gICAgaWYgKHJlcGVhdCA9PT0gdm9pZCAwKSB7IHJlcGVhdCA9IGZhbHNlOyB9XG4gICAgdmFyIHNjaGVkdWxlU3Vic2NyaXB0aW9uID0gc2NoZWR1bGVyLnNjaGVkdWxlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgd29yaygpO1xuICAgICAgICBpZiAocmVwZWF0KSB7XG4gICAgICAgICAgICBwYXJlbnRTdWJzY3JpcHRpb24uYWRkKHRoaXMuc2NoZWR1bGUobnVsbCwgZGVsYXkpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfVxuICAgIH0sIGRlbGF5KTtcbiAgICBwYXJlbnRTdWJzY3JpcHRpb24uYWRkKHNjaGVkdWxlU3Vic2NyaXB0aW9uKTtcbiAgICBpZiAoIXJlcGVhdCkge1xuICAgICAgICByZXR1cm4gc2NoZWR1bGVTdWJzY3JpcHRpb247XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgZXhlY3V0ZVNjaGVkdWxlIH0gZnJvbSAnLi4vdXRpbC9leGVjdXRlU2NoZWR1bGUnO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gb2JzZXJ2ZU9uKHNjaGVkdWxlciwgZGVsYXkpIHtcbiAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gZXhlY3V0ZVNjaGVkdWxlKHN1YnNjcmliZXIsIHNjaGVkdWxlciwgZnVuY3Rpb24gKCkgeyByZXR1cm4gc3Vic2NyaWJlci5uZXh0KHZhbHVlKTsgfSwgZGVsYXkpOyB9LCBmdW5jdGlvbiAoKSB7IHJldHVybiBleGVjdXRlU2NoZWR1bGUoc3Vic2NyaWJlciwgc2NoZWR1bGVyLCBmdW5jdGlvbiAoKSB7IHJldHVybiBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7IH0sIGRlbGF5KTsgfSwgZnVuY3Rpb24gKGVycikgeyByZXR1cm4gZXhlY3V0ZVNjaGVkdWxlKHN1YnNjcmliZXIsIHNjaGVkdWxlciwgZnVuY3Rpb24gKCkgeyByZXR1cm4gc3Vic2NyaWJlci5lcnJvcihlcnIpOyB9LCBkZWxheSk7IH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuZXhwb3J0IGZ1bmN0aW9uIHN1YnNjcmliZU9uKHNjaGVkdWxlciwgZGVsYXkpIHtcbiAgICBpZiAoZGVsYXkgPT09IHZvaWQgMCkgeyBkZWxheSA9IDA7IH1cbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHN1YnNjcmliZXIuYWRkKHNjaGVkdWxlci5zY2hlZHVsZShmdW5jdGlvbiAoKSB7IHJldHVybiBzb3VyY2Uuc3Vic2NyaWJlKHN1YnNjcmliZXIpOyB9LCBkZWxheSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgb2JzZXJ2ZU9uIH0gZnJvbSAnLi4vb3BlcmF0b3JzL29ic2VydmVPbic7XG5pbXBvcnQgeyBzdWJzY3JpYmVPbiB9IGZyb20gJy4uL29wZXJhdG9ycy9zdWJzY3JpYmVPbic7XG5leHBvcnQgZnVuY3Rpb24gc2NoZWR1bGVPYnNlcnZhYmxlKGlucHV0LCBzY2hlZHVsZXIpIHtcbiAgICByZXR1cm4gaW5uZXJGcm9tKGlucHV0KS5waXBlKHN1YnNjcmliZU9uKHNjaGVkdWxlciksIG9ic2VydmVPbihzY2hlZHVsZXIpKTtcbn1cbiIsImltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IG9ic2VydmVPbiB9IGZyb20gJy4uL29wZXJhdG9ycy9vYnNlcnZlT24nO1xuaW1wb3J0IHsgc3Vic2NyaWJlT24gfSBmcm9tICcuLi9vcGVyYXRvcnMvc3Vic2NyaWJlT24nO1xuZXhwb3J0IGZ1bmN0aW9uIHNjaGVkdWxlUHJvbWlzZShpbnB1dCwgc2NoZWR1bGVyKSB7XG4gICAgcmV0dXJuIGlubmVyRnJvbShpbnB1dCkucGlwZShzdWJzY3JpYmVPbihzY2hlZHVsZXIpLCBvYnNlcnZlT24oc2NoZWR1bGVyKSk7XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5leHBvcnQgZnVuY3Rpb24gc2NoZWR1bGVBcnJheShpbnB1dCwgc2NoZWR1bGVyKSB7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgcmV0dXJuIHNjaGVkdWxlci5zY2hlZHVsZShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoaSA9PT0gaW5wdXQubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGlucHV0W2krK10pO1xuICAgICAgICAgICAgICAgIGlmICghc3Vic2NyaWJlci5jbG9zZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zY2hlZHVsZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBpdGVyYXRvciBhcyBTeW1ib2xfaXRlcmF0b3IgfSBmcm9tICcuLi9zeW1ib2wvaXRlcmF0b3InO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4uL3V0aWwvaXNGdW5jdGlvbic7XG5pbXBvcnQgeyBleGVjdXRlU2NoZWR1bGUgfSBmcm9tICcuLi91dGlsL2V4ZWN1dGVTY2hlZHVsZSc7XG5leHBvcnQgZnVuY3Rpb24gc2NoZWR1bGVJdGVyYWJsZShpbnB1dCwgc2NoZWR1bGVyKSB7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBpdGVyYXRvcjtcbiAgICAgICAgZXhlY3V0ZVNjaGVkdWxlKHN1YnNjcmliZXIsIHNjaGVkdWxlciwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaXRlcmF0b3IgPSBpbnB1dFtTeW1ib2xfaXRlcmF0b3JdKCk7XG4gICAgICAgICAgICBleGVjdXRlU2NoZWR1bGUoc3Vic2NyaWJlciwgc2NoZWR1bGVyLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIHZhciB2YWx1ZTtcbiAgICAgICAgICAgICAgICB2YXIgZG9uZTtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAoX2EgPSBpdGVyYXRvci5uZXh0KCksIHZhbHVlID0gX2EudmFsdWUsIGRvbmUgPSBfYS5kb25lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAwLCB0cnVlKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7IHJldHVybiBpc0Z1bmN0aW9uKGl0ZXJhdG9yID09PSBudWxsIHx8IGl0ZXJhdG9yID09PSB2b2lkIDAgPyB2b2lkIDAgOiBpdGVyYXRvci5yZXR1cm4pICYmIGl0ZXJhdG9yLnJldHVybigpOyB9O1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgZXhlY3V0ZVNjaGVkdWxlIH0gZnJvbSAnLi4vdXRpbC9leGVjdXRlU2NoZWR1bGUnO1xuZXhwb3J0IGZ1bmN0aW9uIHNjaGVkdWxlQXN5bmNJdGVyYWJsZShpbnB1dCwgc2NoZWR1bGVyKSB7XG4gICAgaWYgKCFpbnB1dCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0l0ZXJhYmxlIGNhbm5vdCBiZSBudWxsJyk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICBleGVjdXRlU2NoZWR1bGUoc3Vic2NyaWJlciwgc2NoZWR1bGVyLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgaXRlcmF0b3IgPSBpbnB1dFtTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKTtcbiAgICAgICAgICAgIGV4ZWN1dGVTY2hlZHVsZShzdWJzY3JpYmVyLCBzY2hlZHVsZXIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpdGVyYXRvci5uZXh0KCkudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQuZG9uZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHJlc3VsdC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0sIDAsIHRydWUpO1xuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IHNjaGVkdWxlQXN5bmNJdGVyYWJsZSB9IGZyb20gJy4vc2NoZWR1bGVBc3luY0l0ZXJhYmxlJztcbmltcG9ydCB7IHJlYWRhYmxlU3RyZWFtTGlrZVRvQXN5bmNHZW5lcmF0b3IgfSBmcm9tICcuLi91dGlsL2lzUmVhZGFibGVTdHJlYW1MaWtlJztcbmV4cG9ydCBmdW5jdGlvbiBzY2hlZHVsZVJlYWRhYmxlU3RyZWFtTGlrZShpbnB1dCwgc2NoZWR1bGVyKSB7XG4gICAgcmV0dXJuIHNjaGVkdWxlQXN5bmNJdGVyYWJsZShyZWFkYWJsZVN0cmVhbUxpa2VUb0FzeW5jR2VuZXJhdG9yKGlucHV0KSwgc2NoZWR1bGVyKTtcbn1cbiIsImltcG9ydCB7IHNjaGVkdWxlT2JzZXJ2YWJsZSB9IGZyb20gJy4vc2NoZWR1bGVPYnNlcnZhYmxlJztcbmltcG9ydCB7IHNjaGVkdWxlUHJvbWlzZSB9IGZyb20gJy4vc2NoZWR1bGVQcm9taXNlJztcbmltcG9ydCB7IHNjaGVkdWxlQXJyYXkgfSBmcm9tICcuL3NjaGVkdWxlQXJyYXknO1xuaW1wb3J0IHsgc2NoZWR1bGVJdGVyYWJsZSB9IGZyb20gJy4vc2NoZWR1bGVJdGVyYWJsZSc7XG5pbXBvcnQgeyBzY2hlZHVsZUFzeW5jSXRlcmFibGUgfSBmcm9tICcuL3NjaGVkdWxlQXN5bmNJdGVyYWJsZSc7XG5pbXBvcnQgeyBpc0ludGVyb3BPYnNlcnZhYmxlIH0gZnJvbSAnLi4vdXRpbC9pc0ludGVyb3BPYnNlcnZhYmxlJztcbmltcG9ydCB7IGlzUHJvbWlzZSB9IGZyb20gJy4uL3V0aWwvaXNQcm9taXNlJztcbmltcG9ydCB7IGlzQXJyYXlMaWtlIH0gZnJvbSAnLi4vdXRpbC9pc0FycmF5TGlrZSc7XG5pbXBvcnQgeyBpc0l0ZXJhYmxlIH0gZnJvbSAnLi4vdXRpbC9pc0l0ZXJhYmxlJztcbmltcG9ydCB7IGlzQXN5bmNJdGVyYWJsZSB9IGZyb20gJy4uL3V0aWwvaXNBc3luY0l0ZXJhYmxlJztcbmltcG9ydCB7IGNyZWF0ZUludmFsaWRPYnNlcnZhYmxlVHlwZUVycm9yIH0gZnJvbSAnLi4vdXRpbC90aHJvd1Vub2JzZXJ2YWJsZUVycm9yJztcbmltcG9ydCB7IGlzUmVhZGFibGVTdHJlYW1MaWtlIH0gZnJvbSAnLi4vdXRpbC9pc1JlYWRhYmxlU3RyZWFtTGlrZSc7XG5pbXBvcnQgeyBzY2hlZHVsZVJlYWRhYmxlU3RyZWFtTGlrZSB9IGZyb20gJy4vc2NoZWR1bGVSZWFkYWJsZVN0cmVhbUxpa2UnO1xuZXhwb3J0IGZ1bmN0aW9uIHNjaGVkdWxlZChpbnB1dCwgc2NoZWR1bGVyKSB7XG4gICAgaWYgKGlucHV0ICE9IG51bGwpIHtcbiAgICAgICAgaWYgKGlzSW50ZXJvcE9ic2VydmFibGUoaW5wdXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gc2NoZWR1bGVPYnNlcnZhYmxlKGlucHV0LCBzY2hlZHVsZXIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0FycmF5TGlrZShpbnB1dCkpIHtcbiAgICAgICAgICAgIHJldHVybiBzY2hlZHVsZUFycmF5KGlucHV0LCBzY2hlZHVsZXIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1Byb21pc2UoaW5wdXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gc2NoZWR1bGVQcm9taXNlKGlucHV0LCBzY2hlZHVsZXIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0FzeW5jSXRlcmFibGUoaW5wdXQpKSB7XG4gICAgICAgICAgICByZXR1cm4gc2NoZWR1bGVBc3luY0l0ZXJhYmxlKGlucHV0LCBzY2hlZHVsZXIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0l0ZXJhYmxlKGlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHNjaGVkdWxlSXRlcmFibGUoaW5wdXQsIHNjaGVkdWxlcik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzUmVhZGFibGVTdHJlYW1MaWtlKGlucHV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHNjaGVkdWxlUmVhZGFibGVTdHJlYW1MaWtlKGlucHV0LCBzY2hlZHVsZXIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRocm93IGNyZWF0ZUludmFsaWRPYnNlcnZhYmxlVHlwZUVycm9yKGlucHV0KTtcbn1cbiIsImltcG9ydCB7IHNjaGVkdWxlZCB9IGZyb20gJy4uL3NjaGVkdWxlZC9zY2hlZHVsZWQnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGZyb20oaW5wdXQsIHNjaGVkdWxlcikge1xuICAgIHJldHVybiBzY2hlZHVsZXIgPyBzY2hlZHVsZWQoaW5wdXQsIHNjaGVkdWxlcikgOiBpbm5lckZyb20oaW5wdXQpO1xufVxuIiwiaW1wb3J0IHsgcG9wU2NoZWR1bGVyIH0gZnJvbSAnLi4vdXRpbC9hcmdzJztcbmltcG9ydCB7IGZyb20gfSBmcm9tICcuL2Zyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIG9mKCkge1xuICAgIHZhciBhcmdzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgc2NoZWR1bGVyID0gcG9wU2NoZWR1bGVyKGFyZ3MpO1xuICAgIHJldHVybiBmcm9tKGFyZ3MsIHNjaGVkdWxlcik7XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi4vdXRpbC9pc0Z1bmN0aW9uJztcbmV4cG9ydCBmdW5jdGlvbiB0aHJvd0Vycm9yKGVycm9yT3JFcnJvckZhY3RvcnksIHNjaGVkdWxlcikge1xuICAgIHZhciBlcnJvckZhY3RvcnkgPSBpc0Z1bmN0aW9uKGVycm9yT3JFcnJvckZhY3RvcnkpID8gZXJyb3JPckVycm9yRmFjdG9yeSA6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIGVycm9yT3JFcnJvckZhY3Rvcnk7IH07XG4gICAgdmFyIGluaXQgPSBmdW5jdGlvbiAoc3Vic2NyaWJlcikgeyByZXR1cm4gc3Vic2NyaWJlci5lcnJvcihlcnJvckZhY3RvcnkoKSk7IH07XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKHNjaGVkdWxlciA/IGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7IHJldHVybiBzY2hlZHVsZXIuc2NoZWR1bGUoaW5pdCwgMCwgc3Vic2NyaWJlcik7IH0gOiBpbml0KTtcbn1cbiIsImltcG9ydCB7IEVNUFRZIH0gZnJvbSAnLi9vYnNlcnZhYmxlL2VtcHR5JztcbmltcG9ydCB7IG9mIH0gZnJvbSAnLi9vYnNlcnZhYmxlL29mJztcbmltcG9ydCB7IHRocm93RXJyb3IgfSBmcm9tICcuL29ic2VydmFibGUvdGhyb3dFcnJvcic7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi91dGlsL2lzRnVuY3Rpb24nO1xuZXhwb3J0IHZhciBOb3RpZmljYXRpb25LaW5kO1xuKGZ1bmN0aW9uIChOb3RpZmljYXRpb25LaW5kKSB7XG4gICAgTm90aWZpY2F0aW9uS2luZFtcIk5FWFRcIl0gPSBcIk5cIjtcbiAgICBOb3RpZmljYXRpb25LaW5kW1wiRVJST1JcIl0gPSBcIkVcIjtcbiAgICBOb3RpZmljYXRpb25LaW5kW1wiQ09NUExFVEVcIl0gPSBcIkNcIjtcbn0pKE5vdGlmaWNhdGlvbktpbmQgfHwgKE5vdGlmaWNhdGlvbktpbmQgPSB7fSkpO1xudmFyIE5vdGlmaWNhdGlvbiA9IChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gTm90aWZpY2F0aW9uKGtpbmQsIHZhbHVlLCBlcnJvcikge1xuICAgICAgICB0aGlzLmtpbmQgPSBraW5kO1xuICAgICAgICB0aGlzLnZhbHVlID0gdmFsdWU7XG4gICAgICAgIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgICAgICAgdGhpcy5oYXNWYWx1ZSA9IGtpbmQgPT09ICdOJztcbiAgICB9XG4gICAgTm90aWZpY2F0aW9uLnByb3RvdHlwZS5vYnNlcnZlID0gZnVuY3Rpb24gKG9ic2VydmVyKSB7XG4gICAgICAgIHJldHVybiBvYnNlcnZlTm90aWZpY2F0aW9uKHRoaXMsIG9ic2VydmVyKTtcbiAgICB9O1xuICAgIE5vdGlmaWNhdGlvbi5wcm90b3R5cGUuZG8gPSBmdW5jdGlvbiAobmV4dEhhbmRsZXIsIGVycm9ySGFuZGxlciwgY29tcGxldGVIYW5kbGVyKSB7XG4gICAgICAgIHZhciBfYSA9IHRoaXMsIGtpbmQgPSBfYS5raW5kLCB2YWx1ZSA9IF9hLnZhbHVlLCBlcnJvciA9IF9hLmVycm9yO1xuICAgICAgICByZXR1cm4ga2luZCA9PT0gJ04nID8gbmV4dEhhbmRsZXIgPT09IG51bGwgfHwgbmV4dEhhbmRsZXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG5leHRIYW5kbGVyKHZhbHVlKSA6IGtpbmQgPT09ICdFJyA/IGVycm9ySGFuZGxlciA9PT0gbnVsbCB8fCBlcnJvckhhbmRsZXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGVycm9ySGFuZGxlcihlcnJvcikgOiBjb21wbGV0ZUhhbmRsZXIgPT09IG51bGwgfHwgY29tcGxldGVIYW5kbGVyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb21wbGV0ZUhhbmRsZXIoKTtcbiAgICB9O1xuICAgIE5vdGlmaWNhdGlvbi5wcm90b3R5cGUuYWNjZXB0ID0gZnVuY3Rpb24gKG5leHRPck9ic2VydmVyLCBlcnJvciwgY29tcGxldGUpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICByZXR1cm4gaXNGdW5jdGlvbigoX2EgPSBuZXh0T3JPYnNlcnZlcikgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLm5leHQpXG4gICAgICAgICAgICA/IHRoaXMub2JzZXJ2ZShuZXh0T3JPYnNlcnZlcilcbiAgICAgICAgICAgIDogdGhpcy5kbyhuZXh0T3JPYnNlcnZlciwgZXJyb3IsIGNvbXBsZXRlKTtcbiAgICB9O1xuICAgIE5vdGlmaWNhdGlvbi5wcm90b3R5cGUudG9PYnNlcnZhYmxlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX2EgPSB0aGlzLCBraW5kID0gX2Eua2luZCwgdmFsdWUgPSBfYS52YWx1ZSwgZXJyb3IgPSBfYS5lcnJvcjtcbiAgICAgICAgdmFyIHJlc3VsdCA9IGtpbmQgPT09ICdOJ1xuICAgICAgICAgICAgP1xuICAgICAgICAgICAgICAgIG9mKHZhbHVlKVxuICAgICAgICAgICAgOlxuICAgICAgICAgICAgICAgIGtpbmQgPT09ICdFJ1xuICAgICAgICAgICAgICAgICAgICA/XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvd0Vycm9yKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGVycm9yOyB9KVxuICAgICAgICAgICAgICAgICAgICA6XG4gICAgICAgICAgICAgICAgICAgICAgICBraW5kID09PSAnQydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVNUFRZXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwO1xuICAgICAgICBpZiAoIXJlc3VsdCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlVuZXhwZWN0ZWQgbm90aWZpY2F0aW9uIGtpbmQgXCIgKyBraW5kKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG4gICAgTm90aWZpY2F0aW9uLmNyZWF0ZU5leHQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBOb3RpZmljYXRpb24oJ04nLCB2YWx1ZSk7XG4gICAgfTtcbiAgICBOb3RpZmljYXRpb24uY3JlYXRlRXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgIHJldHVybiBuZXcgTm90aWZpY2F0aW9uKCdFJywgdW5kZWZpbmVkLCBlcnIpO1xuICAgIH07XG4gICAgTm90aWZpY2F0aW9uLmNyZWF0ZUNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gTm90aWZpY2F0aW9uLmNvbXBsZXRlTm90aWZpY2F0aW9uO1xuICAgIH07XG4gICAgTm90aWZpY2F0aW9uLmNvbXBsZXRlTm90aWZpY2F0aW9uID0gbmV3IE5vdGlmaWNhdGlvbignQycpO1xuICAgIHJldHVybiBOb3RpZmljYXRpb247XG59KCkpO1xuZXhwb3J0IHsgTm90aWZpY2F0aW9uIH07XG5leHBvcnQgZnVuY3Rpb24gb2JzZXJ2ZU5vdGlmaWNhdGlvbihub3RpZmljYXRpb24sIG9ic2VydmVyKSB7XG4gICAgdmFyIF9hLCBfYiwgX2M7XG4gICAgdmFyIF9kID0gbm90aWZpY2F0aW9uLCBraW5kID0gX2Qua2luZCwgdmFsdWUgPSBfZC52YWx1ZSwgZXJyb3IgPSBfZC5lcnJvcjtcbiAgICBpZiAodHlwZW9mIGtpbmQgIT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0ludmFsaWQgbm90aWZpY2F0aW9uLCBtaXNzaW5nIFwia2luZFwiJyk7XG4gICAgfVxuICAgIGtpbmQgPT09ICdOJyA/IChfYSA9IG9ic2VydmVyLm5leHQpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5jYWxsKG9ic2VydmVyLCB2YWx1ZSkgOiBraW5kID09PSAnRScgPyAoX2IgPSBvYnNlcnZlci5lcnJvcikgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLmNhbGwob2JzZXJ2ZXIsIGVycm9yKSA6IChfYyA9IG9ic2VydmVyLmNvbXBsZXRlKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2MuY2FsbChvYnNlcnZlcik7XG59XG4iLCJpbXBvcnQgeyBjcmVhdGVFcnJvckNsYXNzIH0gZnJvbSAnLi9jcmVhdGVFcnJvckNsYXNzJztcbmV4cG9ydCB2YXIgRW1wdHlFcnJvciA9IGNyZWF0ZUVycm9yQ2xhc3MoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIHJldHVybiBmdW5jdGlvbiBFbXB0eUVycm9ySW1wbCgpIHtcbiAgICAgICAgX3N1cGVyKHRoaXMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnRW1wdHlFcnJvcic7XG4gICAgICAgIHRoaXMubWVzc2FnZSA9ICdubyBlbGVtZW50cyBpbiBzZXF1ZW5jZSc7XG4gICAgfTtcbn0pO1xuIiwiaW1wb3J0IHsgY3JlYXRlRXJyb3JDbGFzcyB9IGZyb20gJy4vY3JlYXRlRXJyb3JDbGFzcyc7XG5leHBvcnQgdmFyIEFyZ3VtZW50T3V0T2ZSYW5nZUVycm9yID0gY3JlYXRlRXJyb3JDbGFzcyhmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIEFyZ3VtZW50T3V0T2ZSYW5nZUVycm9ySW1wbCgpIHtcbiAgICAgICAgX3N1cGVyKHRoaXMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnQXJndW1lbnRPdXRPZlJhbmdlRXJyb3InO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSAnYXJndW1lbnQgb3V0IG9mIHJhbmdlJztcbiAgICB9O1xufSk7XG4iLCJpbXBvcnQgeyBjcmVhdGVFcnJvckNsYXNzIH0gZnJvbSAnLi9jcmVhdGVFcnJvckNsYXNzJztcbmV4cG9ydCB2YXIgTm90Rm91bmRFcnJvciA9IGNyZWF0ZUVycm9yQ2xhc3MoZnVuY3Rpb24gKF9zdXBlcikge1xuICAgIHJldHVybiBmdW5jdGlvbiBOb3RGb3VuZEVycm9ySW1wbChtZXNzYWdlKSB7XG4gICAgICAgIF9zdXBlcih0aGlzKTtcbiAgICAgICAgdGhpcy5uYW1lID0gJ05vdEZvdW5kRXJyb3InO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSBtZXNzYWdlO1xuICAgIH07XG59KTtcbiIsImltcG9ydCB7IGNyZWF0ZUVycm9yQ2xhc3MgfSBmcm9tICcuL2NyZWF0ZUVycm9yQ2xhc3MnO1xuZXhwb3J0IHZhciBTZXF1ZW5jZUVycm9yID0gY3JlYXRlRXJyb3JDbGFzcyhmdW5jdGlvbiAoX3N1cGVyKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIFNlcXVlbmNlRXJyb3JJbXBsKG1lc3NhZ2UpIHtcbiAgICAgICAgX3N1cGVyKHRoaXMpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnU2VxdWVuY2VFcnJvcic7XG4gICAgICAgIHRoaXMubWVzc2FnZSA9IG1lc3NhZ2U7XG4gICAgfTtcbn0pO1xuIiwiZXhwb3J0IGZ1bmN0aW9uIGlzVmFsaWREYXRlKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRGF0ZSAmJiAhaXNOYU4odmFsdWUpO1xufVxuIiwiaW1wb3J0IHsgYXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvYXN5bmMnO1xuaW1wb3J0IHsgaXNWYWxpZERhdGUgfSBmcm9tICcuLi91dGlsL2lzRGF0ZSc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IGNyZWF0ZUVycm9yQ2xhc3MgfSBmcm9tICcuLi91dGlsL2NyZWF0ZUVycm9yQ2xhc3MnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgZXhlY3V0ZVNjaGVkdWxlIH0gZnJvbSAnLi4vdXRpbC9leGVjdXRlU2NoZWR1bGUnO1xuZXhwb3J0IHZhciBUaW1lb3V0RXJyb3IgPSBjcmVhdGVFcnJvckNsYXNzKGZ1bmN0aW9uIChfc3VwZXIpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gVGltZW91dEVycm9ySW1wbChpbmZvKSB7XG4gICAgICAgIGlmIChpbmZvID09PSB2b2lkIDApIHsgaW5mbyA9IG51bGw7IH1cbiAgICAgICAgX3N1cGVyKHRoaXMpO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSAnVGltZW91dCBoYXMgb2NjdXJyZWQnO1xuICAgICAgICB0aGlzLm5hbWUgPSAnVGltZW91dEVycm9yJztcbiAgICAgICAgdGhpcy5pbmZvID0gaW5mbztcbiAgICB9O1xufSk7XG5leHBvcnQgZnVuY3Rpb24gdGltZW91dChjb25maWcsIHNjaGVkdWxlckFyZykge1xuICAgIHZhciBfYSA9IChpc1ZhbGlkRGF0ZShjb25maWcpID8geyBmaXJzdDogY29uZmlnIH0gOiB0eXBlb2YgY29uZmlnID09PSAnbnVtYmVyJyA/IHsgZWFjaDogY29uZmlnIH0gOiBjb25maWcpLCBmaXJzdCA9IF9hLmZpcnN0LCBlYWNoID0gX2EuZWFjaCwgX2IgPSBfYS53aXRoLCBfd2l0aCA9IF9iID09PSB2b2lkIDAgPyB0aW1lb3V0RXJyb3JGYWN0b3J5IDogX2IsIF9jID0gX2Euc2NoZWR1bGVyLCBzY2hlZHVsZXIgPSBfYyA9PT0gdm9pZCAwID8gc2NoZWR1bGVyQXJnICE9PSBudWxsICYmIHNjaGVkdWxlckFyZyAhPT0gdm9pZCAwID8gc2NoZWR1bGVyQXJnIDogYXN5bmNTY2hlZHVsZXIgOiBfYywgX2QgPSBfYS5tZXRhLCBtZXRhID0gX2QgPT09IHZvaWQgMCA/IG51bGwgOiBfZDtcbiAgICBpZiAoZmlyc3QgPT0gbnVsbCAmJiBlYWNoID09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTm8gdGltZW91dCBwcm92aWRlZC4nKTtcbiAgICB9XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgb3JpZ2luYWxTb3VyY2VTdWJzY3JpcHRpb247XG4gICAgICAgIHZhciB0aW1lclN1YnNjcmlwdGlvbjtcbiAgICAgICAgdmFyIGxhc3RWYWx1ZSA9IG51bGw7XG4gICAgICAgIHZhciBzZWVuID0gMDtcbiAgICAgICAgdmFyIHN0YXJ0VGltZXIgPSBmdW5jdGlvbiAoZGVsYXkpIHtcbiAgICAgICAgICAgIHRpbWVyU3Vic2NyaXB0aW9uID0gZXhlY3V0ZVNjaGVkdWxlKHN1YnNjcmliZXIsIHNjaGVkdWxlciwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIG9yaWdpbmFsU291cmNlU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgICAgIGlubmVyRnJvbShfd2l0aCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXRhOiBtZXRhLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGFzdFZhbHVlOiBsYXN0VmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWVuOiBzZWVuLFxuICAgICAgICAgICAgICAgICAgICB9KSkuc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCBkZWxheSk7XG4gICAgICAgIH07XG4gICAgICAgIG9yaWdpbmFsU291cmNlU3Vic2NyaXB0aW9uID0gc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB0aW1lclN1YnNjcmlwdGlvbiA9PT0gbnVsbCB8fCB0aW1lclN1YnNjcmlwdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogdGltZXJTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNlZW4rKztcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCgobGFzdFZhbHVlID0gdmFsdWUpKTtcbiAgICAgICAgICAgIGVhY2ggPiAwICYmIHN0YXJ0VGltZXIoZWFjaCk7XG4gICAgICAgIH0sIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoISh0aW1lclN1YnNjcmlwdGlvbiA9PT0gbnVsbCB8fCB0aW1lclN1YnNjcmlwdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogdGltZXJTdWJzY3JpcHRpb24uY2xvc2VkKSkge1xuICAgICAgICAgICAgICAgIHRpbWVyU3Vic2NyaXB0aW9uID09PSBudWxsIHx8IHRpbWVyU3Vic2NyaXB0aW9uID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0aW1lclN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGFzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgfSkpO1xuICAgICAgICAhc2VlbiAmJiBzdGFydFRpbWVyKGZpcnN0ICE9IG51bGwgPyAodHlwZW9mIGZpcnN0ID09PSAnbnVtYmVyJyA/IGZpcnN0IDogK2ZpcnN0IC0gc2NoZWR1bGVyLm5vdygpKSA6IGVhY2gpO1xuICAgIH0pO1xufVxuZnVuY3Rpb24gdGltZW91dEVycm9yRmFjdG9yeShpbmZvKSB7XG4gICAgdGhyb3cgbmV3IFRpbWVvdXRFcnJvcihpbmZvKTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIG1hcChwcm9qZWN0LCB0aGlzQXJnKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChwcm9qZWN0LmNhbGwodGhpc0FyZywgdmFsdWUsIGluZGV4KyspKTtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBtYXAgfSBmcm9tIFwiLi4vb3BlcmF0b3JzL21hcFwiO1xudmFyIGlzQXJyYXkgPSBBcnJheS5pc0FycmF5O1xuZnVuY3Rpb24gY2FsbE9yQXBwbHkoZm4sIGFyZ3MpIHtcbiAgICByZXR1cm4gaXNBcnJheShhcmdzKSA/IGZuLmFwcGx5KHZvaWQgMCwgX19zcHJlYWRBcnJheShbXSwgX19yZWFkKGFyZ3MpKSkgOiBmbihhcmdzKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBtYXBPbmVPck1hbnlBcmdzKGZuKSB7XG4gICAgcmV0dXJuIG1hcChmdW5jdGlvbiAoYXJncykgeyByZXR1cm4gY2FsbE9yQXBwbHkoZm4sIGFyZ3MpOyB9KTtcbn1cbiIsInZhciBpc0FycmF5ID0gQXJyYXkuaXNBcnJheTtcbnZhciBnZXRQcm90b3R5cGVPZiA9IE9iamVjdC5nZXRQcm90b3R5cGVPZiwgb2JqZWN0UHJvdG8gPSBPYmplY3QucHJvdG90eXBlLCBnZXRLZXlzID0gT2JqZWN0LmtleXM7XG5leHBvcnQgZnVuY3Rpb24gYXJnc0FyZ0FycmF5T3JPYmplY3QoYXJncykge1xuICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICB2YXIgZmlyc3RfMSA9IGFyZ3NbMF07XG4gICAgICAgIGlmIChpc0FycmF5KGZpcnN0XzEpKSB7XG4gICAgICAgICAgICByZXR1cm4geyBhcmdzOiBmaXJzdF8xLCBrZXlzOiBudWxsIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzUE9KTyhmaXJzdF8xKSkge1xuICAgICAgICAgICAgdmFyIGtleXMgPSBnZXRLZXlzKGZpcnN0XzEpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBhcmdzOiBrZXlzLm1hcChmdW5jdGlvbiAoa2V5KSB7IHJldHVybiBmaXJzdF8xW2tleV07IH0pLFxuICAgICAgICAgICAgICAgIGtleXM6IGtleXMsXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IGFyZ3M6IGFyZ3MsIGtleXM6IG51bGwgfTtcbn1cbmZ1bmN0aW9uIGlzUE9KTyhvYmopIHtcbiAgICByZXR1cm4gb2JqICYmIHR5cGVvZiBvYmogPT09ICdvYmplY3QnICYmIGdldFByb3RvdHlwZU9mKG9iaikgPT09IG9iamVjdFByb3RvO1xufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZU9iamVjdChrZXlzLCB2YWx1ZXMpIHtcbiAgICByZXR1cm4ga2V5cy5yZWR1Y2UoZnVuY3Rpb24gKHJlc3VsdCwga2V5LCBpKSB7IHJldHVybiAoKHJlc3VsdFtrZXldID0gdmFsdWVzW2ldKSwgcmVzdWx0KTsgfSwge30pO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgYXJnc0FyZ0FycmF5T3JPYmplY3QgfSBmcm9tICcuLi91dGlsL2FyZ3NBcmdBcnJheU9yT2JqZWN0JztcbmltcG9ydCB7IGZyb20gfSBmcm9tICcuL2Zyb20nO1xuaW1wb3J0IHsgaWRlbnRpdHkgfSBmcm9tICcuLi91dGlsL2lkZW50aXR5JztcbmltcG9ydCB7IG1hcE9uZU9yTWFueUFyZ3MgfSBmcm9tICcuLi91dGlsL21hcE9uZU9yTWFueUFyZ3MnO1xuaW1wb3J0IHsgcG9wUmVzdWx0U2VsZWN0b3IsIHBvcFNjaGVkdWxlciB9IGZyb20gJy4uL3V0aWwvYXJncyc7XG5pbXBvcnQgeyBjcmVhdGVPYmplY3QgfSBmcm9tICcuLi91dGlsL2NyZWF0ZU9iamVjdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuLi9vcGVyYXRvcnMvT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IGV4ZWN1dGVTY2hlZHVsZSB9IGZyb20gJy4uL3V0aWwvZXhlY3V0ZVNjaGVkdWxlJztcbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lTGF0ZXN0KCkge1xuICAgIHZhciBhcmdzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgc2NoZWR1bGVyID0gcG9wU2NoZWR1bGVyKGFyZ3MpO1xuICAgIHZhciByZXN1bHRTZWxlY3RvciA9IHBvcFJlc3VsdFNlbGVjdG9yKGFyZ3MpO1xuICAgIHZhciBfYSA9IGFyZ3NBcmdBcnJheU9yT2JqZWN0KGFyZ3MpLCBvYnNlcnZhYmxlcyA9IF9hLmFyZ3MsIGtleXMgPSBfYS5rZXlzO1xuICAgIGlmIChvYnNlcnZhYmxlcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGZyb20oW10sIHNjaGVkdWxlcik7XG4gICAgfVxuICAgIHZhciByZXN1bHQgPSBuZXcgT2JzZXJ2YWJsZShjb21iaW5lTGF0ZXN0SW5pdChvYnNlcnZhYmxlcywgc2NoZWR1bGVyLCBrZXlzXG4gICAgICAgID9cbiAgICAgICAgICAgIGZ1bmN0aW9uICh2YWx1ZXMpIHsgcmV0dXJuIGNyZWF0ZU9iamVjdChrZXlzLCB2YWx1ZXMpOyB9XG4gICAgICAgIDpcbiAgICAgICAgICAgIGlkZW50aXR5KSk7XG4gICAgcmV0dXJuIHJlc3VsdFNlbGVjdG9yID8gcmVzdWx0LnBpcGUobWFwT25lT3JNYW55QXJncyhyZXN1bHRTZWxlY3RvcikpIDogcmVzdWx0O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNvbWJpbmVMYXRlc3RJbml0KG9ic2VydmFibGVzLCBzY2hlZHVsZXIsIHZhbHVlVHJhbnNmb3JtKSB7XG4gICAgaWYgKHZhbHVlVHJhbnNmb3JtID09PSB2b2lkIDApIHsgdmFsdWVUcmFuc2Zvcm0gPSBpZGVudGl0eTsgfVxuICAgIHJldHVybiBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICBtYXliZVNjaGVkdWxlKHNjaGVkdWxlciwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGxlbmd0aCA9IG9ic2VydmFibGVzLmxlbmd0aDtcbiAgICAgICAgICAgIHZhciB2YWx1ZXMgPSBuZXcgQXJyYXkobGVuZ3RoKTtcbiAgICAgICAgICAgIHZhciBhY3RpdmUgPSBsZW5ndGg7XG4gICAgICAgICAgICB2YXIgcmVtYWluaW5nRmlyc3RWYWx1ZXMgPSBsZW5ndGg7XG4gICAgICAgICAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uIChpKSB7XG4gICAgICAgICAgICAgICAgbWF5YmVTY2hlZHVsZShzY2hlZHVsZXIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNvdXJjZSA9IGZyb20ob2JzZXJ2YWJsZXNbaV0sIHNjaGVkdWxlcik7XG4gICAgICAgICAgICAgICAgICAgIHZhciBoYXNGaXJzdFZhbHVlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVzW2ldID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWhhc0ZpcnN0VmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYXNGaXJzdFZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW1haW5pbmdGaXJzdFZhbHVlcy0tO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyZW1haW5pbmdGaXJzdFZhbHVlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZVRyYW5zZm9ybSh2YWx1ZXMuc2xpY2UoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIS0tYWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgfSwgc3Vic2NyaWJlcik7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIF9sb29wXzEoaSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIHN1YnNjcmliZXIpO1xuICAgIH07XG59XG5mdW5jdGlvbiBtYXliZVNjaGVkdWxlKHNjaGVkdWxlciwgZXhlY3V0ZSwgc3Vic2NyaXB0aW9uKSB7XG4gICAgaWYgKHNjaGVkdWxlcikge1xuICAgICAgICBleGVjdXRlU2NoZWR1bGUoc3Vic2NyaXB0aW9uLCBzY2hlZHVsZXIsIGV4ZWN1dGUpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZXhlY3V0ZSgpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IGV4ZWN1dGVTY2hlZHVsZSB9IGZyb20gJy4uL3V0aWwvZXhlY3V0ZVNjaGVkdWxlJztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBtZXJnZUludGVybmFscyhzb3VyY2UsIHN1YnNjcmliZXIsIHByb2plY3QsIGNvbmN1cnJlbnQsIG9uQmVmb3JlTmV4dCwgZXhwYW5kLCBpbm5lclN1YlNjaGVkdWxlciwgYWRkaXRpb25hbEZpbmFsaXplcikge1xuICAgIHZhciBidWZmZXIgPSBbXTtcbiAgICB2YXIgYWN0aXZlID0gMDtcbiAgICB2YXIgaW5kZXggPSAwO1xuICAgIHZhciBpc0NvbXBsZXRlID0gZmFsc2U7XG4gICAgdmFyIGNoZWNrQ29tcGxldGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGlmIChpc0NvbXBsZXRlICYmICFidWZmZXIubGVuZ3RoICYmICFhY3RpdmUpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgdmFyIG91dGVyTmV4dCA9IGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gKGFjdGl2ZSA8IGNvbmN1cnJlbnQgPyBkb0lubmVyU3ViKHZhbHVlKSA6IGJ1ZmZlci5wdXNoKHZhbHVlKSk7IH07XG4gICAgdmFyIGRvSW5uZXJTdWIgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgZXhwYW5kICYmIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgIGFjdGl2ZSsrO1xuICAgICAgICB2YXIgaW5uZXJDb21wbGV0ZSA9IGZhbHNlO1xuICAgICAgICBpbm5lckZyb20ocHJvamVjdCh2YWx1ZSwgaW5kZXgrKykpLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKGlubmVyVmFsdWUpIHtcbiAgICAgICAgICAgIG9uQmVmb3JlTmV4dCA9PT0gbnVsbCB8fCBvbkJlZm9yZU5leHQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9uQmVmb3JlTmV4dChpbm5lclZhbHVlKTtcbiAgICAgICAgICAgIGlmIChleHBhbmQpIHtcbiAgICAgICAgICAgICAgICBvdXRlck5leHQoaW5uZXJWYWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoaW5uZXJWYWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlubmVyQ29tcGxldGUgPSB0cnVlO1xuICAgICAgICB9LCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChpbm5lckNvbXBsZXRlKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlLS07XG4gICAgICAgICAgICAgICAgICAgIHZhciBfbG9vcF8xID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGJ1ZmZlcmVkVmFsdWUgPSBidWZmZXIuc2hpZnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbm5lclN1YlNjaGVkdWxlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4ZWN1dGVTY2hlZHVsZShzdWJzY3JpYmVyLCBpbm5lclN1YlNjaGVkdWxlciwgZnVuY3Rpb24gKCkgeyByZXR1cm4gZG9Jbm5lclN1YihidWZmZXJlZFZhbHVlKTsgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb0lubmVyU3ViKGJ1ZmZlcmVkVmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB3aGlsZSAoYnVmZmVyLmxlbmd0aCAmJiBhY3RpdmUgPCBjb25jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfbG9vcF8xKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2hlY2tDb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICB9O1xuICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIG91dGVyTmV4dCwgZnVuY3Rpb24gKCkge1xuICAgICAgICBpc0NvbXBsZXRlID0gdHJ1ZTtcbiAgICAgICAgY2hlY2tDb21wbGV0ZSgpO1xuICAgIH0pKTtcbiAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICBhZGRpdGlvbmFsRmluYWxpemVyID09PSBudWxsIHx8IGFkZGl0aW9uYWxGaW5hbGl6ZXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGFkZGl0aW9uYWxGaW5hbGl6ZXIoKTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgbWFwIH0gZnJvbSAnLi9tYXAnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBtZXJnZUludGVybmFscyB9IGZyb20gJy4vbWVyZ2VJbnRlcm5hbHMnO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4uL3V0aWwvaXNGdW5jdGlvbic7XG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VNYXAocHJvamVjdCwgcmVzdWx0U2VsZWN0b3IsIGNvbmN1cnJlbnQpIHtcbiAgICBpZiAoY29uY3VycmVudCA9PT0gdm9pZCAwKSB7IGNvbmN1cnJlbnQgPSBJbmZpbml0eTsgfVxuICAgIGlmIChpc0Z1bmN0aW9uKHJlc3VsdFNlbGVjdG9yKSkge1xuICAgICAgICByZXR1cm4gbWVyZ2VNYXAoZnVuY3Rpb24gKGEsIGkpIHsgcmV0dXJuIG1hcChmdW5jdGlvbiAoYiwgaWkpIHsgcmV0dXJuIHJlc3VsdFNlbGVjdG9yKGEsIGIsIGksIGlpKTsgfSkoaW5uZXJGcm9tKHByb2plY3QoYSwgaSkpKTsgfSwgY29uY3VycmVudCk7XG4gICAgfVxuICAgIGVsc2UgaWYgKHR5cGVvZiByZXN1bHRTZWxlY3RvciA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgY29uY3VycmVudCA9IHJlc3VsdFNlbGVjdG9yO1xuICAgIH1cbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7IHJldHVybiBtZXJnZUludGVybmFscyhzb3VyY2UsIHN1YnNjcmliZXIsIHByb2plY3QsIGNvbmN1cnJlbnQpOyB9KTtcbn1cbiIsImltcG9ydCB7IG1lcmdlTWFwIH0gZnJvbSAnLi9tZXJnZU1hcCc7XG5pbXBvcnQgeyBpZGVudGl0eSB9IGZyb20gJy4uL3V0aWwvaWRlbnRpdHknO1xuZXhwb3J0IGZ1bmN0aW9uIG1lcmdlQWxsKGNvbmN1cnJlbnQpIHtcbiAgICBpZiAoY29uY3VycmVudCA9PT0gdm9pZCAwKSB7IGNvbmN1cnJlbnQgPSBJbmZpbml0eTsgfVxuICAgIHJldHVybiBtZXJnZU1hcChpZGVudGl0eSwgY29uY3VycmVudCk7XG59XG4iLCJpbXBvcnQgeyBtZXJnZUFsbCB9IGZyb20gJy4vbWVyZ2VBbGwnO1xuZXhwb3J0IGZ1bmN0aW9uIGNvbmNhdEFsbCgpIHtcbiAgICByZXR1cm4gbWVyZ2VBbGwoMSk7XG59XG4iLCJpbXBvcnQgeyBjb25jYXRBbGwgfSBmcm9tICcuLi9vcGVyYXRvcnMvY29uY2F0QWxsJztcbmltcG9ydCB7IHBvcFNjaGVkdWxlciB9IGZyb20gJy4uL3V0aWwvYXJncyc7XG5pbXBvcnQgeyBmcm9tIH0gZnJvbSAnLi9mcm9tJztcbmV4cG9ydCBmdW5jdGlvbiBjb25jYXQoKSB7XG4gICAgdmFyIGFyZ3MgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICBhcmdzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHJldHVybiBjb25jYXRBbGwoKShmcm9tKGFyZ3MsIHBvcFNjaGVkdWxlcihhcmdzKSkpO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgYXN5bmMgYXMgYXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvYXN5bmMnO1xuaW1wb3J0IHsgaXNTY2hlZHVsZXIgfSBmcm9tICcuLi91dGlsL2lzU2NoZWR1bGVyJztcbmltcG9ydCB7IGlzVmFsaWREYXRlIH0gZnJvbSAnLi4vdXRpbC9pc0RhdGUnO1xuZXhwb3J0IGZ1bmN0aW9uIHRpbWVyKGR1ZVRpbWUsIGludGVydmFsT3JTY2hlZHVsZXIsIHNjaGVkdWxlcikge1xuICAgIGlmIChkdWVUaW1lID09PSB2b2lkIDApIHsgZHVlVGltZSA9IDA7IH1cbiAgICBpZiAoc2NoZWR1bGVyID09PSB2b2lkIDApIHsgc2NoZWR1bGVyID0gYXN5bmNTY2hlZHVsZXI7IH1cbiAgICB2YXIgaW50ZXJ2YWxEdXJhdGlvbiA9IC0xO1xuICAgIGlmIChpbnRlcnZhbE9yU2NoZWR1bGVyICE9IG51bGwpIHtcbiAgICAgICAgaWYgKGlzU2NoZWR1bGVyKGludGVydmFsT3JTY2hlZHVsZXIpKSB7XG4gICAgICAgICAgICBzY2hlZHVsZXIgPSBpbnRlcnZhbE9yU2NoZWR1bGVyO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgaW50ZXJ2YWxEdXJhdGlvbiA9IGludGVydmFsT3JTY2hlZHVsZXI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBkdWUgPSBpc1ZhbGlkRGF0ZShkdWVUaW1lKSA/ICtkdWVUaW1lIC0gc2NoZWR1bGVyLm5vdygpIDogZHVlVGltZTtcbiAgICAgICAgaWYgKGR1ZSA8IDApIHtcbiAgICAgICAgICAgIGR1ZSA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG4gPSAwO1xuICAgICAgICByZXR1cm4gc2NoZWR1bGVyLnNjaGVkdWxlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICghc3Vic2NyaWJlci5jbG9zZWQpIHtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQobisrKTtcbiAgICAgICAgICAgICAgICBpZiAoMCA8PSBpbnRlcnZhbER1cmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2NoZWR1bGUodW5kZWZpbmVkLCBpbnRlcnZhbER1cmF0aW9uKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGR1ZSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBhc3luY1NjaGVkdWxlciB9IGZyb20gJy4uL3NjaGVkdWxlci9hc3luYyc7XG5pbXBvcnQgeyB0aW1lciB9IGZyb20gJy4vdGltZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGludGVydmFsKHBlcmlvZCwgc2NoZWR1bGVyKSB7XG4gICAgaWYgKHBlcmlvZCA9PT0gdm9pZCAwKSB7IHBlcmlvZCA9IDA7IH1cbiAgICBpZiAoc2NoZWR1bGVyID09PSB2b2lkIDApIHsgc2NoZWR1bGVyID0gYXN5bmNTY2hlZHVsZXI7IH1cbiAgICBpZiAocGVyaW9kIDwgMCkge1xuICAgICAgICBwZXJpb2QgPSAwO1xuICAgIH1cbiAgICByZXR1cm4gdGltZXIocGVyaW9kLCBwZXJpb2QsIHNjaGVkdWxlcik7XG59XG4iLCJ2YXIgaXNBcnJheSA9IEFycmF5LmlzQXJyYXk7XG5leHBvcnQgZnVuY3Rpb24gYXJnc09yQXJnQXJyYXkoYXJncykge1xuICAgIHJldHVybiBhcmdzLmxlbmd0aCA9PT0gMSAmJiBpc0FycmF5KGFyZ3NbMF0pID8gYXJnc1swXSA6IGFyZ3M7XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBhcmdzT3JBcmdBcnJheSB9IGZyb20gJy4uL3V0aWwvYXJnc09yQXJnQXJyYXknO1xuaW1wb3J0IHsgT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi4vb3BlcmF0b3JzL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBub29wIH0gZnJvbSAnLi4vdXRpbC9ub29wJztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4vaW5uZXJGcm9tJztcbmV4cG9ydCBmdW5jdGlvbiBvbkVycm9yUmVzdW1lTmV4dCgpIHtcbiAgICB2YXIgc291cmNlcyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHNvdXJjZXNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIG5leHRTb3VyY2VzID0gYXJnc09yQXJnQXJyYXkoc291cmNlcyk7XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBzb3VyY2VJbmRleCA9IDA7XG4gICAgICAgIHZhciBzdWJzY3JpYmVOZXh0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHNvdXJjZUluZGV4IDwgbmV4dFNvdXJjZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgdmFyIG5leHRTb3VyY2UgPSB2b2lkIDA7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dFNvdXJjZSA9IGlubmVyRnJvbShuZXh0U291cmNlc1tzb3VyY2VJbmRleCsrXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlTmV4dCgpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZhciBpbm5lclN1YnNjcmliZXIgPSBuZXcgT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIHVuZGVmaW5lZCwgbm9vcCwgbm9vcCk7XG4gICAgICAgICAgICAgICAgbmV4dFNvdXJjZS5zdWJzY3JpYmUoaW5uZXJTdWJzY3JpYmVyKTtcbiAgICAgICAgICAgICAgICBpbm5lclN1YnNjcmliZXIuYWRkKHN1YnNjcmliZU5leHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBzdWJzY3JpYmVOZXh0KCk7XG4gICAgfSk7XG59XG4iLCJleHBvcnQgZnVuY3Rpb24gbm90KHByZWQsIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHZhbHVlLCBpbmRleCkgeyByZXR1cm4gIXByZWQuY2FsbCh0aGlzQXJnLCB2YWx1ZSwgaW5kZXgpOyB9O1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyKHByZWRpY2F0ZSwgdGhpc0FyZykge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiBwcmVkaWNhdGUuY2FsbCh0aGlzQXJnLCB2YWx1ZSwgaW5kZXgrKykgJiYgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTsgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJy4uL09ic2VydmFibGUnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi9pbm5lckZyb20nO1xuaW1wb3J0IHsgYXJnc09yQXJnQXJyYXkgfSBmcm9tICcuLi91dGlsL2FyZ3NPckFyZ0FycmF5JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4uL29wZXJhdG9ycy9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIHJhY2UoKSB7XG4gICAgdmFyIHNvdXJjZXMgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICBzb3VyY2VzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHNvdXJjZXMgPSBhcmdzT3JBcmdBcnJheShzb3VyY2VzKTtcbiAgICByZXR1cm4gc291cmNlcy5sZW5ndGggPT09IDEgPyBpbm5lckZyb20oc291cmNlc1swXSkgOiBuZXcgT2JzZXJ2YWJsZShyYWNlSW5pdChzb3VyY2VzKSk7XG59XG5leHBvcnQgZnVuY3Rpb24gcmFjZUluaXQoc291cmNlcykge1xuICAgIHJldHVybiBmdW5jdGlvbiAoc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgc3Vic2NyaXB0aW9ucyA9IFtdO1xuICAgICAgICB2YXIgX2xvb3BfMSA9IGZ1bmN0aW9uIChpKSB7XG4gICAgICAgICAgICBzdWJzY3JpcHRpb25zLnB1c2goaW5uZXJGcm9tKHNvdXJjZXNbaV0pLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgaWYgKHN1YnNjcmlwdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgcyA9IDA7IHMgPCBzdWJzY3JpcHRpb25zLmxlbmd0aDsgcysrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzICE9PSBpICYmIHN1YnNjcmlwdGlvbnNbc10udW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBzdWJzY3JpcHRpb25zID0gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgICAgIH0pKSk7XG4gICAgICAgIH07XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBzdWJzY3JpcHRpb25zICYmICFzdWJzY3JpYmVyLmNsb3NlZCAmJiBpIDwgc291cmNlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgX2xvb3BfMShpKTtcbiAgICAgICAgfVxuICAgIH07XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICcuLi9PYnNlcnZhYmxlJztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4vaW5uZXJGcm9tJztcbmltcG9ydCB7IGFyZ3NPckFyZ0FycmF5IH0gZnJvbSAnLi4vdXRpbC9hcmdzT3JBcmdBcnJheSc7XG5pbXBvcnQgeyBFTVBUWSB9IGZyb20gJy4vZW1wdHknO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi4vb3BlcmF0b3JzL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBwb3BSZXN1bHRTZWxlY3RvciB9IGZyb20gJy4uL3V0aWwvYXJncyc7XG5leHBvcnQgZnVuY3Rpb24gemlwKCkge1xuICAgIHZhciBhcmdzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgcmVzdWx0U2VsZWN0b3IgPSBwb3BSZXN1bHRTZWxlY3RvcihhcmdzKTtcbiAgICB2YXIgc291cmNlcyA9IGFyZ3NPckFyZ0FycmF5KGFyZ3MpO1xuICAgIHJldHVybiBzb3VyY2VzLmxlbmd0aFxuICAgICAgICA/IG5ldyBPYnNlcnZhYmxlKGZ1bmN0aW9uIChzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICB2YXIgYnVmZmVycyA9IHNvdXJjZXMubWFwKGZ1bmN0aW9uICgpIHsgcmV0dXJuIFtdOyB9KTtcbiAgICAgICAgICAgIHZhciBjb21wbGV0ZWQgPSBzb3VyY2VzLm1hcChmdW5jdGlvbiAoKSB7IHJldHVybiBmYWxzZTsgfSk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmFkZChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgYnVmZmVycyA9IGNvbXBsZXRlZCA9IG51bGw7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHZhciBfbG9vcF8xID0gZnVuY3Rpb24gKHNvdXJjZUluZGV4KSB7XG4gICAgICAgICAgICAgICAgaW5uZXJGcm9tKHNvdXJjZXNbc291cmNlSW5kZXhdKS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBidWZmZXJzW3NvdXJjZUluZGV4XS5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1ZmZlcnMuZXZlcnkoZnVuY3Rpb24gKGJ1ZmZlcikgeyByZXR1cm4gYnVmZmVyLmxlbmd0aDsgfSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBidWZmZXJzLm1hcChmdW5jdGlvbiAoYnVmZmVyKSB7IHJldHVybiBidWZmZXIuc2hpZnQoKTsgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQocmVzdWx0U2VsZWN0b3IgPyByZXN1bHRTZWxlY3Rvci5hcHBseSh2b2lkIDAsIF9fc3ByZWFkQXJyYXkoW10sIF9fcmVhZChyZXN1bHQpKSkgOiByZXN1bHQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJ1ZmZlcnMuc29tZShmdW5jdGlvbiAoYnVmZmVyLCBpKSB7IHJldHVybiAhYnVmZmVyLmxlbmd0aCAmJiBjb21wbGV0ZWRbaV07IH0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZWRbc291cmNlSW5kZXhdID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgIWJ1ZmZlcnNbc291cmNlSW5kZXhdLmxlbmd0aCAmJiBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGZvciAodmFyIHNvdXJjZUluZGV4ID0gMDsgIXN1YnNjcmliZXIuY2xvc2VkICYmIHNvdXJjZUluZGV4IDwgc291cmNlcy5sZW5ndGg7IHNvdXJjZUluZGV4KyspIHtcbiAgICAgICAgICAgICAgICBfbG9vcF8xKHNvdXJjZUluZGV4KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgYnVmZmVycyA9IGNvbXBsZXRlZCA9IG51bGw7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9KVxuICAgICAgICA6IEVNUFRZO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gYXVkaXQoZHVyYXRpb25TZWxlY3Rvcikge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGhhc1ZhbHVlID0gZmFsc2U7XG4gICAgICAgIHZhciBsYXN0VmFsdWUgPSBudWxsO1xuICAgICAgICB2YXIgZHVyYXRpb25TdWJzY3JpYmVyID0gbnVsbDtcbiAgICAgICAgdmFyIGlzQ29tcGxldGUgPSBmYWxzZTtcbiAgICAgICAgdmFyIGVuZER1cmF0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgZHVyYXRpb25TdWJzY3JpYmVyID09PSBudWxsIHx8IGR1cmF0aW9uU3Vic2NyaWJlciA9PT0gdm9pZCAwID8gdm9pZCAwIDogZHVyYXRpb25TdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICBkdXJhdGlvblN1YnNjcmliZXIgPSBudWxsO1xuICAgICAgICAgICAgaWYgKGhhc1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgaGFzVmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSBsYXN0VmFsdWU7XG4gICAgICAgICAgICAgICAgbGFzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaXNDb21wbGV0ZSAmJiBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH07XG4gICAgICAgIHZhciBjbGVhbnVwRHVyYXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBkdXJhdGlvblN1YnNjcmliZXIgPSBudWxsO1xuICAgICAgICAgICAgaXNDb21wbGV0ZSAmJiBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH07XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgaGFzVmFsdWUgPSB0cnVlO1xuICAgICAgICAgICAgbGFzdFZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICBpZiAoIWR1cmF0aW9uU3Vic2NyaWJlcikge1xuICAgICAgICAgICAgICAgIGlubmVyRnJvbShkdXJhdGlvblNlbGVjdG9yKHZhbHVlKSkuc3Vic2NyaWJlKChkdXJhdGlvblN1YnNjcmliZXIgPSBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZW5kRHVyYXRpb24sIGNsZWFudXBEdXJhdGlvbikpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaXNDb21wbGV0ZSA9IHRydWU7XG4gICAgICAgICAgICAoIWhhc1ZhbHVlIHx8ICFkdXJhdGlvblN1YnNjcmliZXIgfHwgZHVyYXRpb25TdWJzY3JpYmVyLmNsb3NlZCkgJiYgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBhc3luY1NjaGVkdWxlciB9IGZyb20gJy4uL3NjaGVkdWxlci9hc3luYyc7XG5pbXBvcnQgeyBhdWRpdCB9IGZyb20gJy4vYXVkaXQnO1xuaW1wb3J0IHsgdGltZXIgfSBmcm9tICcuLi9vYnNlcnZhYmxlL3RpbWVyJztcbmV4cG9ydCBmdW5jdGlvbiBhdWRpdFRpbWUoZHVyYXRpb24sIHNjaGVkdWxlcikge1xuICAgIGlmIChzY2hlZHVsZXIgPT09IHZvaWQgMCkgeyBzY2hlZHVsZXIgPSBhc3luY1NjaGVkdWxlcjsgfVxuICAgIHJldHVybiBhdWRpdChmdW5jdGlvbiAoKSB7IHJldHVybiB0aW1lcihkdXJhdGlvbiwgc2NoZWR1bGVyKTsgfSk7XG59XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGJ1ZmZlcihjbG9zaW5nTm90aWZpZXIpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBjdXJyZW50QnVmZmVyID0gW107XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gY3VycmVudEJ1ZmZlci5wdXNoKHZhbHVlKTsgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGN1cnJlbnRCdWZmZXIpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9KSk7XG4gICAgICAgIGlubmVyRnJvbShjbG9zaW5nTm90aWZpZXIpLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGIgPSBjdXJyZW50QnVmZmVyO1xuICAgICAgICAgICAgY3VycmVudEJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGIpO1xuICAgICAgICB9LCBub29wKSk7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjdXJyZW50QnVmZmVyID0gbnVsbDtcbiAgICAgICAgfTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IF9fdmFsdWVzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IGFyclJlbW92ZSB9IGZyb20gJy4uL3V0aWwvYXJyUmVtb3ZlJztcbmV4cG9ydCBmdW5jdGlvbiBidWZmZXJDb3VudChidWZmZXJTaXplLCBzdGFydEJ1ZmZlckV2ZXJ5KSB7XG4gICAgaWYgKHN0YXJ0QnVmZmVyRXZlcnkgPT09IHZvaWQgMCkgeyBzdGFydEJ1ZmZlckV2ZXJ5ID0gbnVsbDsgfVxuICAgIHN0YXJ0QnVmZmVyRXZlcnkgPSBzdGFydEJ1ZmZlckV2ZXJ5ICE9PSBudWxsICYmIHN0YXJ0QnVmZmVyRXZlcnkgIT09IHZvaWQgMCA/IHN0YXJ0QnVmZmVyRXZlcnkgOiBidWZmZXJTaXplO1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGJ1ZmZlcnMgPSBbXTtcbiAgICAgICAgdmFyIGNvdW50ID0gMDtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB2YXIgZV8xLCBfYSwgZV8yLCBfYjtcbiAgICAgICAgICAgIHZhciB0b0VtaXQgPSBudWxsO1xuICAgICAgICAgICAgaWYgKGNvdW50KysgJSBzdGFydEJ1ZmZlckV2ZXJ5ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgYnVmZmVycy5wdXNoKFtdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgYnVmZmVyc18xID0gX192YWx1ZXMoYnVmZmVycyksIGJ1ZmZlcnNfMV8xID0gYnVmZmVyc18xLm5leHQoKTsgIWJ1ZmZlcnNfMV8xLmRvbmU7IGJ1ZmZlcnNfMV8xID0gYnVmZmVyc18xLm5leHQoKSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYnVmZmVyID0gYnVmZmVyc18xXzEudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGJ1ZmZlci5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1ZmZlclNpemUgPD0gYnVmZmVyLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdG9FbWl0ID0gdG9FbWl0ICE9PSBudWxsICYmIHRvRW1pdCAhPT0gdm9pZCAwID8gdG9FbWl0IDogW107XG4gICAgICAgICAgICAgICAgICAgICAgICB0b0VtaXQucHVzaChidWZmZXIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChidWZmZXJzXzFfMSAmJiAhYnVmZmVyc18xXzEuZG9uZSAmJiAoX2EgPSBidWZmZXJzXzEucmV0dXJuKSkgX2EuY2FsbChidWZmZXJzXzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAodG9FbWl0KSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgdG9FbWl0XzEgPSBfX3ZhbHVlcyh0b0VtaXQpLCB0b0VtaXRfMV8xID0gdG9FbWl0XzEubmV4dCgpOyAhdG9FbWl0XzFfMS5kb25lOyB0b0VtaXRfMV8xID0gdG9FbWl0XzEubmV4dCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgYnVmZmVyID0gdG9FbWl0XzFfMS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyclJlbW92ZShidWZmZXJzLCBidWZmZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGJ1ZmZlcik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVfMl8xKSB7IGVfMiA9IHsgZXJyb3I6IGVfMl8xIH07IH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0b0VtaXRfMV8xICYmICF0b0VtaXRfMV8xLmRvbmUgJiYgKF9iID0gdG9FbWl0XzEucmV0dXJuKSkgX2IuY2FsbCh0b0VtaXRfMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZmluYWxseSB7IGlmIChlXzIpIHRocm93IGVfMi5lcnJvcjsgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdmFyIGVfMywgX2E7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGJ1ZmZlcnNfMiA9IF9fdmFsdWVzKGJ1ZmZlcnMpLCBidWZmZXJzXzJfMSA9IGJ1ZmZlcnNfMi5uZXh0KCk7ICFidWZmZXJzXzJfMS5kb25lOyBidWZmZXJzXzJfMSA9IGJ1ZmZlcnNfMi5uZXh0KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGJ1ZmZlciA9IGJ1ZmZlcnNfMl8xLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoYnVmZmVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZV8zXzEpIHsgZV8zID0geyBlcnJvcjogZV8zXzEgfTsgfVxuICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1ZmZlcnNfMl8xICYmICFidWZmZXJzXzJfMS5kb25lICYmIChfYSA9IGJ1ZmZlcnNfMi5yZXR1cm4pKSBfYS5jYWxsKGJ1ZmZlcnNfMik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpbmFsbHkgeyBpZiAoZV8zKSB0aHJvdyBlXzMuZXJyb3I7IH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgfSwgdW5kZWZpbmVkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBidWZmZXJzID0gbnVsbDtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgX192YWx1ZXMgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJy4uL1N1YnNjcmlwdGlvbic7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IGFyclJlbW92ZSB9IGZyb20gJy4uL3V0aWwvYXJyUmVtb3ZlJztcbmltcG9ydCB7IGFzeW5jU2NoZWR1bGVyIH0gZnJvbSAnLi4vc2NoZWR1bGVyL2FzeW5jJztcbmltcG9ydCB7IHBvcFNjaGVkdWxlciB9IGZyb20gJy4uL3V0aWwvYXJncyc7XG5pbXBvcnQgeyBleGVjdXRlU2NoZWR1bGUgfSBmcm9tICcuLi91dGlsL2V4ZWN1dGVTY2hlZHVsZSc7XG5leHBvcnQgZnVuY3Rpb24gYnVmZmVyVGltZShidWZmZXJUaW1lU3Bhbikge1xuICAgIHZhciBfYSwgX2I7XG4gICAgdmFyIG90aGVyQXJncyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMTsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIG90aGVyQXJnc1tfaSAtIDFdID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIHNjaGVkdWxlciA9IChfYSA9IHBvcFNjaGVkdWxlcihvdGhlckFyZ3MpKSAhPT0gbnVsbCAmJiBfYSAhPT0gdm9pZCAwID8gX2EgOiBhc3luY1NjaGVkdWxlcjtcbiAgICB2YXIgYnVmZmVyQ3JlYXRpb25JbnRlcnZhbCA9IChfYiA9IG90aGVyQXJnc1swXSkgIT09IG51bGwgJiYgX2IgIT09IHZvaWQgMCA/IF9iIDogbnVsbDtcbiAgICB2YXIgbWF4QnVmZmVyU2l6ZSA9IG90aGVyQXJnc1sxXSB8fCBJbmZpbml0eTtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBidWZmZXJSZWNvcmRzID0gW107XG4gICAgICAgIHZhciByZXN0YXJ0T25FbWl0ID0gZmFsc2U7XG4gICAgICAgIHZhciBlbWl0ID0gZnVuY3Rpb24gKHJlY29yZCkge1xuICAgICAgICAgICAgdmFyIGJ1ZmZlciA9IHJlY29yZC5idWZmZXIsIHN1YnMgPSByZWNvcmQuc3VicztcbiAgICAgICAgICAgIHN1YnMudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIGFyclJlbW92ZShidWZmZXJSZWNvcmRzLCByZWNvcmQpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGJ1ZmZlcik7XG4gICAgICAgICAgICByZXN0YXJ0T25FbWl0ICYmIHN0YXJ0QnVmZmVyKCk7XG4gICAgICAgIH07XG4gICAgICAgIHZhciBzdGFydEJ1ZmZlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmIChidWZmZXJSZWNvcmRzKSB7XG4gICAgICAgICAgICAgICAgdmFyIHN1YnMgPSBuZXcgU3Vic2NyaXB0aW9uKCk7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5hZGQoc3Vicyk7XG4gICAgICAgICAgICAgICAgdmFyIGJ1ZmZlciA9IFtdO1xuICAgICAgICAgICAgICAgIHZhciByZWNvcmRfMSA9IHtcbiAgICAgICAgICAgICAgICAgICAgYnVmZmVyOiBidWZmZXIsXG4gICAgICAgICAgICAgICAgICAgIHN1YnM6IHN1YnMsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBidWZmZXJSZWNvcmRzLnB1c2gocmVjb3JkXzEpO1xuICAgICAgICAgICAgICAgIGV4ZWN1dGVTY2hlZHVsZShzdWJzLCBzY2hlZHVsZXIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGVtaXQocmVjb3JkXzEpOyB9LCBidWZmZXJUaW1lU3Bhbik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGlmIChidWZmZXJDcmVhdGlvbkludGVydmFsICE9PSBudWxsICYmIGJ1ZmZlckNyZWF0aW9uSW50ZXJ2YWwgPj0gMCkge1xuICAgICAgICAgICAgZXhlY3V0ZVNjaGVkdWxlKHN1YnNjcmliZXIsIHNjaGVkdWxlciwgc3RhcnRCdWZmZXIsIGJ1ZmZlckNyZWF0aW9uSW50ZXJ2YWwsIHRydWUpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmVzdGFydE9uRW1pdCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgc3RhcnRCdWZmZXIoKTtcbiAgICAgICAgdmFyIGJ1ZmZlclRpbWVTdWJzY3JpYmVyID0gY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgdmFyIGVfMSwgX2E7XG4gICAgICAgICAgICB2YXIgcmVjb3Jkc0NvcHkgPSBidWZmZXJSZWNvcmRzLnNsaWNlKCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIHJlY29yZHNDb3B5XzEgPSBfX3ZhbHVlcyhyZWNvcmRzQ29weSksIHJlY29yZHNDb3B5XzFfMSA9IHJlY29yZHNDb3B5XzEubmV4dCgpOyAhcmVjb3Jkc0NvcHlfMV8xLmRvbmU7IHJlY29yZHNDb3B5XzFfMSA9IHJlY29yZHNDb3B5XzEubmV4dCgpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZWNvcmQgPSByZWNvcmRzQ29weV8xXzEudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIHZhciBidWZmZXIgPSByZWNvcmQuYnVmZmVyO1xuICAgICAgICAgICAgICAgICAgICBidWZmZXIucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIG1heEJ1ZmZlclNpemUgPD0gYnVmZmVyLmxlbmd0aCAmJiBlbWl0KHJlY29yZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZWNvcmRzQ29weV8xXzEgJiYgIXJlY29yZHNDb3B5XzFfMS5kb25lICYmIChfYSA9IHJlY29yZHNDb3B5XzEucmV0dXJuKSkgX2EuY2FsbChyZWNvcmRzQ29weV8xKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZmluYWxseSB7IGlmIChlXzEpIHRocm93IGVfMS5lcnJvcjsgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB3aGlsZSAoYnVmZmVyUmVjb3JkcyA9PT0gbnVsbCB8fCBidWZmZXJSZWNvcmRzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBidWZmZXJSZWNvcmRzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChidWZmZXJSZWNvcmRzLnNoaWZ0KCkuYnVmZmVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJ1ZmZlclRpbWVTdWJzY3JpYmVyID09PSBudWxsIHx8IGJ1ZmZlclRpbWVTdWJzY3JpYmVyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBidWZmZXJUaW1lU3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICB9LCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIChidWZmZXJSZWNvcmRzID0gbnVsbCk7IH0pO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGJ1ZmZlclRpbWVTdWJzY3JpYmVyKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IF9fdmFsdWVzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICcuLi9TdWJzY3JpcHRpb24nO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBub29wIH0gZnJvbSAnLi4vdXRpbC9ub29wJztcbmltcG9ydCB7IGFyclJlbW92ZSB9IGZyb20gJy4uL3V0aWwvYXJyUmVtb3ZlJztcbmV4cG9ydCBmdW5jdGlvbiBidWZmZXJUb2dnbGUob3BlbmluZ3MsIGNsb3NpbmdTZWxlY3Rvcikge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGJ1ZmZlcnMgPSBbXTtcbiAgICAgICAgaW5uZXJGcm9tKG9wZW5pbmdzKS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uIChvcGVuVmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBidWZmZXIgPSBbXTtcbiAgICAgICAgICAgIGJ1ZmZlcnMucHVzaChidWZmZXIpO1xuICAgICAgICAgICAgdmFyIGNsb3NpbmdTdWJzY3JpcHRpb24gPSBuZXcgU3Vic2NyaXB0aW9uKCk7XG4gICAgICAgICAgICB2YXIgZW1pdEJ1ZmZlciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBhcnJSZW1vdmUoYnVmZmVycywgYnVmZmVyKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoYnVmZmVyKTtcbiAgICAgICAgICAgICAgICBjbG9zaW5nU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgY2xvc2luZ1N1YnNjcmlwdGlvbi5hZGQoaW5uZXJGcm9tKGNsb3NpbmdTZWxlY3RvcihvcGVuVmFsdWUpKS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGVtaXRCdWZmZXIsIG5vb3ApKSk7XG4gICAgICAgIH0sIG5vb3ApKTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB2YXIgZV8xLCBfYTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgYnVmZmVyc18xID0gX192YWx1ZXMoYnVmZmVycyksIGJ1ZmZlcnNfMV8xID0gYnVmZmVyc18xLm5leHQoKTsgIWJ1ZmZlcnNfMV8xLmRvbmU7IGJ1ZmZlcnNfMV8xID0gYnVmZmVyc18xLm5leHQoKSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYnVmZmVyID0gYnVmZmVyc18xXzEudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGJ1ZmZlci5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZV8xXzEpIHsgZV8xID0geyBlcnJvcjogZV8xXzEgfTsgfVxuICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGJ1ZmZlcnNfMV8xICYmICFidWZmZXJzXzFfMS5kb25lICYmIChfYSA9IGJ1ZmZlcnNfMS5yZXR1cm4pKSBfYS5jYWxsKGJ1ZmZlcnNfMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpbmFsbHkgeyBpZiAoZV8xKSB0aHJvdyBlXzEuZXJyb3I7IH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgd2hpbGUgKGJ1ZmZlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChidWZmZXJzLnNoaWZ0KCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGJ1ZmZlcldoZW4oY2xvc2luZ1NlbGVjdG9yKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgYnVmZmVyID0gbnVsbDtcbiAgICAgICAgdmFyIGNsb3NpbmdTdWJzY3JpYmVyID0gbnVsbDtcbiAgICAgICAgdmFyIG9wZW5CdWZmZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBjbG9zaW5nU3Vic2NyaWJlciA9PT0gbnVsbCB8fCBjbG9zaW5nU3Vic2NyaWJlciA9PT0gdm9pZCAwID8gdm9pZCAwIDogY2xvc2luZ1N1YnNjcmliZXIudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHZhciBiID0gYnVmZmVyO1xuICAgICAgICAgICAgYnVmZmVyID0gW107XG4gICAgICAgICAgICBiICYmIHN1YnNjcmliZXIubmV4dChiKTtcbiAgICAgICAgICAgIGlubmVyRnJvbShjbG9zaW5nU2VsZWN0b3IoKSkuc3Vic2NyaWJlKChjbG9zaW5nU3Vic2NyaWJlciA9IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBvcGVuQnVmZmVyLCBub29wKSkpO1xuICAgICAgICB9O1xuICAgICAgICBvcGVuQnVmZmVyKCk7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gYnVmZmVyID09PSBudWxsIHx8IGJ1ZmZlciA9PT0gdm9pZCAwID8gdm9pZCAwIDogYnVmZmVyLnB1c2godmFsdWUpOyB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBidWZmZXIgJiYgc3Vic2NyaWJlci5uZXh0KGJ1ZmZlcik7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0sIHVuZGVmaW5lZCwgZnVuY3Rpb24gKCkgeyByZXR1cm4gKGJ1ZmZlciA9IGNsb3NpbmdTdWJzY3JpYmVyID0gbnVsbCk7IH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuZXhwb3J0IGZ1bmN0aW9uIGNhdGNoRXJyb3Ioc2VsZWN0b3IpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBpbm5lclN1YiA9IG51bGw7XG4gICAgICAgIHZhciBzeW5jVW5zdWIgPSBmYWxzZTtcbiAgICAgICAgdmFyIGhhbmRsZWRSZXN1bHQ7XG4gICAgICAgIGlubmVyU3ViID0gc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgIGhhbmRsZWRSZXN1bHQgPSBpbm5lckZyb20oc2VsZWN0b3IoZXJyLCBjYXRjaEVycm9yKHNlbGVjdG9yKShzb3VyY2UpKSk7XG4gICAgICAgICAgICBpZiAoaW5uZXJTdWIpIHtcbiAgICAgICAgICAgICAgICBpbm5lclN1Yi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgIGlubmVyU3ViID0gbnVsbDtcbiAgICAgICAgICAgICAgICBoYW5kbGVkUmVzdWx0LnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHN5bmNVbnN1YiA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICAgICAgaWYgKHN5bmNVbnN1Yikge1xuICAgICAgICAgICAgaW5uZXJTdWIudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIGlubmVyU3ViID0gbnVsbDtcbiAgICAgICAgICAgIGhhbmRsZWRSZXN1bHQuc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gc2NhbkludGVybmFscyhhY2N1bXVsYXRvciwgc2VlZCwgaGFzU2VlZCwgZW1pdE9uTmV4dCwgZW1pdEJlZm9yZUNvbXBsZXRlKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGhhc1N0YXRlID0gaGFzU2VlZDtcbiAgICAgICAgdmFyIHN0YXRlID0gc2VlZDtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB2YXIgaSA9IGluZGV4Kys7XG4gICAgICAgICAgICBzdGF0ZSA9IGhhc1N0YXRlXG4gICAgICAgICAgICAgICAgP1xuICAgICAgICAgICAgICAgICAgICBhY2N1bXVsYXRvcihzdGF0ZSwgdmFsdWUsIGkpXG4gICAgICAgICAgICAgICAgOlxuICAgICAgICAgICAgICAgICAgICAoKGhhc1N0YXRlID0gdHJ1ZSksIHZhbHVlKTtcbiAgICAgICAgICAgIGVtaXRPbk5leHQgJiYgc3Vic2NyaWJlci5uZXh0KHN0YXRlKTtcbiAgICAgICAgfSwgZW1pdEJlZm9yZUNvbXBsZXRlICYmXG4gICAgICAgICAgICAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGhhc1N0YXRlICYmIHN1YnNjcmliZXIubmV4dChzdGF0ZSk7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgfSkpKTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgc2NhbkludGVybmFscyB9IGZyb20gJy4vc2NhbkludGVybmFscyc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmV4cG9ydCBmdW5jdGlvbiByZWR1Y2UoYWNjdW11bGF0b3IsIHNlZWQpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShzY2FuSW50ZXJuYWxzKGFjY3VtdWxhdG9yLCBzZWVkLCBhcmd1bWVudHMubGVuZ3RoID49IDIsIGZhbHNlLCB0cnVlKSk7XG59XG4iLCJpbXBvcnQgeyByZWR1Y2UgfSBmcm9tICcuL3JlZHVjZSc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbnZhciBhcnJSZWR1Y2VyID0gZnVuY3Rpb24gKGFyciwgdmFsdWUpIHsgcmV0dXJuIChhcnIucHVzaCh2YWx1ZSksIGFycik7IH07XG5leHBvcnQgZnVuY3Rpb24gdG9BcnJheSgpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHJlZHVjZShhcnJSZWR1Y2VyLCBbXSkoc291cmNlKS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBpZGVudGl0eSB9IGZyb20gJy4uL3V0aWwvaWRlbnRpdHknO1xuaW1wb3J0IHsgbWFwT25lT3JNYW55QXJncyB9IGZyb20gJy4uL3V0aWwvbWFwT25lT3JNYW55QXJncyc7XG5pbXBvcnQgeyBwaXBlIH0gZnJvbSAnLi4vdXRpbC9waXBlJztcbmltcG9ydCB7IG1lcmdlTWFwIH0gZnJvbSAnLi9tZXJnZU1hcCc7XG5pbXBvcnQgeyB0b0FycmF5IH0gZnJvbSAnLi90b0FycmF5JztcbmV4cG9ydCBmdW5jdGlvbiBqb2luQWxsSW50ZXJuYWxzKGpvaW5GbiwgcHJvamVjdCkge1xuICAgIHJldHVybiBwaXBlKHRvQXJyYXkoKSwgbWVyZ2VNYXAoZnVuY3Rpb24gKHNvdXJjZXMpIHsgcmV0dXJuIGpvaW5Gbihzb3VyY2VzKTsgfSksIHByb2plY3QgPyBtYXBPbmVPck1hbnlBcmdzKHByb2plY3QpIDogaWRlbnRpdHkpO1xufVxuIiwiaW1wb3J0IHsgY29tYmluZUxhdGVzdCB9IGZyb20gJy4uL29ic2VydmFibGUvY29tYmluZUxhdGVzdCc7XG5pbXBvcnQgeyBqb2luQWxsSW50ZXJuYWxzIH0gZnJvbSAnLi9qb2luQWxsSW50ZXJuYWxzJztcbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lTGF0ZXN0QWxsKHByb2plY3QpIHtcbiAgICByZXR1cm4gam9pbkFsbEludGVybmFscyhjb21iaW5lTGF0ZXN0LCBwcm9qZWN0KTtcbn1cbiIsImltcG9ydCB7IGNvbWJpbmVMYXRlc3RBbGwgfSBmcm9tICcuL2NvbWJpbmVMYXRlc3RBbGwnO1xuZXhwb3J0IHZhciBjb21iaW5lQWxsID0gY29tYmluZUxhdGVzdEFsbDtcbiIsImltcG9ydCB7IF9fcmVhZCwgX19zcHJlYWRBcnJheSB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgY29tYmluZUxhdGVzdEluaXQgfSBmcm9tICcuLi9vYnNlcnZhYmxlL2NvbWJpbmVMYXRlc3QnO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBhcmdzT3JBcmdBcnJheSB9IGZyb20gJy4uL3V0aWwvYXJnc09yQXJnQXJyYXknO1xuaW1wb3J0IHsgbWFwT25lT3JNYW55QXJncyB9IGZyb20gJy4uL3V0aWwvbWFwT25lT3JNYW55QXJncyc7XG5pbXBvcnQgeyBwaXBlIH0gZnJvbSAnLi4vdXRpbC9waXBlJztcbmltcG9ydCB7IHBvcFJlc3VsdFNlbGVjdG9yIH0gZnJvbSAnLi4vdXRpbC9hcmdzJztcbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lTGF0ZXN0KCkge1xuICAgIHZhciBhcmdzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgcmVzdWx0U2VsZWN0b3IgPSBwb3BSZXN1bHRTZWxlY3RvcihhcmdzKTtcbiAgICByZXR1cm4gcmVzdWx0U2VsZWN0b3JcbiAgICAgICAgPyBwaXBlKGNvbWJpbmVMYXRlc3QuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQoYXJncykpKSwgbWFwT25lT3JNYW55QXJncyhyZXN1bHRTZWxlY3RvcikpXG4gICAgICAgIDogb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICBjb21iaW5lTGF0ZXN0SW5pdChfX3NwcmVhZEFycmF5KFtzb3VyY2VdLCBfX3JlYWQoYXJnc09yQXJnQXJyYXkoYXJncykpKSkoc3Vic2NyaWJlcik7XG4gICAgICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBjb21iaW5lTGF0ZXN0IH0gZnJvbSAnLi9jb21iaW5lTGF0ZXN0JztcbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lTGF0ZXN0V2l0aCgpIHtcbiAgICB2YXIgb3RoZXJTb3VyY2VzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgb3RoZXJTb3VyY2VzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHJldHVybiBjb21iaW5lTGF0ZXN0LmFwcGx5KHZvaWQgMCwgX19zcHJlYWRBcnJheShbXSwgX19yZWFkKG90aGVyU291cmNlcykpKTtcbn1cbiIsImltcG9ydCB7IG1lcmdlTWFwIH0gZnJvbSAnLi9tZXJnZU1hcCc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi4vdXRpbC9pc0Z1bmN0aW9uJztcbmV4cG9ydCBmdW5jdGlvbiBjb25jYXRNYXAocHJvamVjdCwgcmVzdWx0U2VsZWN0b3IpIHtcbiAgICByZXR1cm4gaXNGdW5jdGlvbihyZXN1bHRTZWxlY3RvcikgPyBtZXJnZU1hcChwcm9qZWN0LCByZXN1bHRTZWxlY3RvciwgMSkgOiBtZXJnZU1hcChwcm9qZWN0LCAxKTtcbn1cbiIsImltcG9ydCB7IGNvbmNhdE1hcCB9IGZyb20gJy4vY29uY2F0TWFwJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuLi91dGlsL2lzRnVuY3Rpb24nO1xuZXhwb3J0IGZ1bmN0aW9uIGNvbmNhdE1hcFRvKGlubmVyT2JzZXJ2YWJsZSwgcmVzdWx0U2VsZWN0b3IpIHtcbiAgICByZXR1cm4gaXNGdW5jdGlvbihyZXN1bHRTZWxlY3RvcikgPyBjb25jYXRNYXAoZnVuY3Rpb24gKCkgeyByZXR1cm4gaW5uZXJPYnNlcnZhYmxlOyB9LCByZXN1bHRTZWxlY3RvcikgOiBjb25jYXRNYXAoZnVuY3Rpb24gKCkgeyByZXR1cm4gaW5uZXJPYnNlcnZhYmxlOyB9KTtcbn1cbiIsImltcG9ydCB7IF9fcmVhZCwgX19zcHJlYWRBcnJheSB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjb25jYXRBbGwgfSBmcm9tICcuL2NvbmNhdEFsbCc7XG5pbXBvcnQgeyBwb3BTY2hlZHVsZXIgfSBmcm9tICcuLi91dGlsL2FyZ3MnO1xuaW1wb3J0IHsgZnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvZnJvbSc7XG5leHBvcnQgZnVuY3Rpb24gY29uY2F0KCkge1xuICAgIHZhciBhcmdzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgYXJnc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgc2NoZWR1bGVyID0gcG9wU2NoZWR1bGVyKGFyZ3MpO1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgY29uY2F0QWxsKCkoZnJvbShfX3NwcmVhZEFycmF5KFtzb3VyY2VdLCBfX3JlYWQoYXJncykpLCBzY2hlZHVsZXIpKS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGNvbmNhdCB9IGZyb20gJy4vY29uY2F0JztcbmV4cG9ydCBmdW5jdGlvbiBjb25jYXRXaXRoKCkge1xuICAgIHZhciBvdGhlclNvdXJjZXMgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICBvdGhlclNvdXJjZXNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbmNhdC5hcHBseSh2b2lkIDAsIF9fc3ByZWFkQXJyYXkoW10sIF9fcmVhZChvdGhlclNvdXJjZXMpKSk7XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5leHBvcnQgZnVuY3Rpb24gZnJvbVN1YnNjcmliYWJsZShzdWJzY3JpYmFibGUpIHtcbiAgICByZXR1cm4gbmV3IE9ic2VydmFibGUoZnVuY3Rpb24gKHN1YnNjcmliZXIpIHsgcmV0dXJuIHN1YnNjcmliYWJsZS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7IH0pO1xufVxuIiwiaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4uL1N1YmplY3QnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBmcm9tU3Vic2NyaWJhYmxlIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9mcm9tU3Vic2NyaWJhYmxlJztcbnZhciBERUZBVUxUX0NPTkZJRyA9IHtcbiAgICBjb25uZWN0b3I6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIG5ldyBTdWJqZWN0KCk7IH0sXG59O1xuZXhwb3J0IGZ1bmN0aW9uIGNvbm5lY3Qoc2VsZWN0b3IsIGNvbmZpZykge1xuICAgIGlmIChjb25maWcgPT09IHZvaWQgMCkgeyBjb25maWcgPSBERUZBVUxUX0NPTkZJRzsgfVxuICAgIHZhciBjb25uZWN0b3IgPSBjb25maWcuY29ubmVjdG9yO1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIHN1YmplY3QgPSBjb25uZWN0b3IoKTtcbiAgICAgICAgaW5uZXJGcm9tKHNlbGVjdG9yKGZyb21TdWJzY3JpYmFibGUoc3ViamVjdCkpKS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgICAgIHN1YnNjcmliZXIuYWRkKHNvdXJjZS5zdWJzY3JpYmUoc3ViamVjdCkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgcmVkdWNlIH0gZnJvbSAnLi9yZWR1Y2UnO1xuZXhwb3J0IGZ1bmN0aW9uIGNvdW50KHByZWRpY2F0ZSkge1xuICAgIHJldHVybiByZWR1Y2UoZnVuY3Rpb24gKHRvdGFsLCB2YWx1ZSwgaSkgeyByZXR1cm4gKCFwcmVkaWNhdGUgfHwgcHJlZGljYXRlKHZhbHVlLCBpKSA/IHRvdGFsICsgMSA6IHRvdGFsKTsgfSwgMCk7XG59XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGRlYm91bmNlKGR1cmF0aW9uU2VsZWN0b3IpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBoYXNWYWx1ZSA9IGZhbHNlO1xuICAgICAgICB2YXIgbGFzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgdmFyIGR1cmF0aW9uU3Vic2NyaWJlciA9IG51bGw7XG4gICAgICAgIHZhciBlbWl0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgZHVyYXRpb25TdWJzY3JpYmVyID09PSBudWxsIHx8IGR1cmF0aW9uU3Vic2NyaWJlciA9PT0gdm9pZCAwID8gdm9pZCAwIDogZHVyYXRpb25TdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICBkdXJhdGlvblN1YnNjcmliZXIgPSBudWxsO1xuICAgICAgICAgICAgaWYgKGhhc1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgaGFzVmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSBsYXN0VmFsdWU7XG4gICAgICAgICAgICAgICAgbGFzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIGR1cmF0aW9uU3Vic2NyaWJlciA9PT0gbnVsbCB8fCBkdXJhdGlvblN1YnNjcmliZXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGR1cmF0aW9uU3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgaGFzVmFsdWUgPSB0cnVlO1xuICAgICAgICAgICAgbGFzdFZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICBkdXJhdGlvblN1YnNjcmliZXIgPSBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZW1pdCwgbm9vcCk7XG4gICAgICAgICAgICBpbm5lckZyb20oZHVyYXRpb25TZWxlY3Rvcih2YWx1ZSkpLnN1YnNjcmliZShkdXJhdGlvblN1YnNjcmliZXIpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBlbWl0KCk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0sIHVuZGVmaW5lZCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgbGFzdFZhbHVlID0gZHVyYXRpb25TdWJzY3JpYmVyID0gbnVsbDtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgYXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvYXN5bmMnO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gZGVib3VuY2VUaW1lKGR1ZVRpbWUsIHNjaGVkdWxlcikge1xuICAgIGlmIChzY2hlZHVsZXIgPT09IHZvaWQgMCkgeyBzY2hlZHVsZXIgPSBhc3luY1NjaGVkdWxlcjsgfVxuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGFjdGl2ZVRhc2sgPSBudWxsO1xuICAgICAgICB2YXIgbGFzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgdmFyIGxhc3RUaW1lID0gbnVsbDtcbiAgICAgICAgdmFyIGVtaXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoYWN0aXZlVGFzaykge1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhc2sudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICBhY3RpdmVUYXNrID0gbnVsbDtcbiAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSBsYXN0VmFsdWU7XG4gICAgICAgICAgICAgICAgbGFzdFZhbHVlID0gbnVsbDtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBmdW5jdGlvbiBlbWl0V2hlbklkbGUoKSB7XG4gICAgICAgICAgICB2YXIgdGFyZ2V0VGltZSA9IGxhc3RUaW1lICsgZHVlVGltZTtcbiAgICAgICAgICAgIHZhciBub3cgPSBzY2hlZHVsZXIubm93KCk7XG4gICAgICAgICAgICBpZiAobm93IDwgdGFyZ2V0VGltZSkge1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhc2sgPSB0aGlzLnNjaGVkdWxlKHVuZGVmaW5lZCwgdGFyZ2V0VGltZSAtIG5vdyk7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5hZGQoYWN0aXZlVGFzayk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZW1pdCgpO1xuICAgICAgICB9XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgbGFzdFZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICBsYXN0VGltZSA9IHNjaGVkdWxlci5ub3coKTtcbiAgICAgICAgICAgIGlmICghYWN0aXZlVGFzaykge1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhc2sgPSBzY2hlZHVsZXIuc2NoZWR1bGUoZW1pdFdoZW5JZGxlLCBkdWVUaW1lKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmFkZChhY3RpdmVUYXNrKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgZW1pdCgpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9LCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGxhc3RWYWx1ZSA9IGFjdGl2ZVRhc2sgPSBudWxsO1xuICAgICAgICB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBkZWZhdWx0SWZFbXB0eShkZWZhdWx0VmFsdWUpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBoYXNWYWx1ZSA9IGZhbHNlO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIGhhc1ZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlmICghaGFzVmFsdWUpIHtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoZGVmYXVsdFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgRU1QVFkgfSBmcm9tICcuLi9vYnNlcnZhYmxlL2VtcHR5JztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIHRha2UoY291bnQpIHtcbiAgICByZXR1cm4gY291bnQgPD0gMFxuICAgICAgICA/XG4gICAgICAgICAgICBmdW5jdGlvbiAoKSB7IHJldHVybiBFTVBUWTsgfVxuICAgICAgICA6IG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICAgICAgdmFyIHNlZW4gPSAwO1xuICAgICAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgaWYgKCsrc2VlbiA8PSBjb3VudCkge1xuICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY291bnQgPD0gc2Vlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9KTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gJy4uL3V0aWwvbm9vcCc7XG5leHBvcnQgZnVuY3Rpb24gaWdub3JlRWxlbWVudHMoKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBub29wKSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBtYXAgfSBmcm9tICcuL21hcCc7XG5leHBvcnQgZnVuY3Rpb24gbWFwVG8odmFsdWUpIHtcbiAgICByZXR1cm4gbWFwKGZ1bmN0aW9uICgpIHsgcmV0dXJuIHZhbHVlOyB9KTtcbn1cbiIsImltcG9ydCB7IGNvbmNhdCB9IGZyb20gJy4uL29ic2VydmFibGUvY29uY2F0JztcbmltcG9ydCB7IHRha2UgfSBmcm9tICcuL3Rha2UnO1xuaW1wb3J0IHsgaWdub3JlRWxlbWVudHMgfSBmcm9tICcuL2lnbm9yZUVsZW1lbnRzJztcbmltcG9ydCB7IG1hcFRvIH0gZnJvbSAnLi9tYXBUbyc7XG5pbXBvcnQgeyBtZXJnZU1hcCB9IGZyb20gJy4vbWVyZ2VNYXAnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGRlbGF5V2hlbihkZWxheUR1cmF0aW9uU2VsZWN0b3IsIHN1YnNjcmlwdGlvbkRlbGF5KSB7XG4gICAgaWYgKHN1YnNjcmlwdGlvbkRlbGF5KSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICAgICAgICByZXR1cm4gY29uY2F0KHN1YnNjcmlwdGlvbkRlbGF5LnBpcGUodGFrZSgxKSwgaWdub3JlRWxlbWVudHMoKSksIHNvdXJjZS5waXBlKGRlbGF5V2hlbihkZWxheUR1cmF0aW9uU2VsZWN0b3IpKSk7XG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBtZXJnZU1hcChmdW5jdGlvbiAodmFsdWUsIGluZGV4KSB7IHJldHVybiBpbm5lckZyb20oZGVsYXlEdXJhdGlvblNlbGVjdG9yKHZhbHVlLCBpbmRleCkpLnBpcGUodGFrZSgxKSwgbWFwVG8odmFsdWUpKTsgfSk7XG59XG4iLCJpbXBvcnQgeyBhc3luY1NjaGVkdWxlciB9IGZyb20gJy4uL3NjaGVkdWxlci9hc3luYyc7XG5pbXBvcnQgeyBkZWxheVdoZW4gfSBmcm9tICcuL2RlbGF5V2hlbic7XG5pbXBvcnQgeyB0aW1lciB9IGZyb20gJy4uL29ic2VydmFibGUvdGltZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGRlbGF5KGR1ZSwgc2NoZWR1bGVyKSB7XG4gICAgaWYgKHNjaGVkdWxlciA9PT0gdm9pZCAwKSB7IHNjaGVkdWxlciA9IGFzeW5jU2NoZWR1bGVyOyB9XG4gICAgdmFyIGR1cmF0aW9uID0gdGltZXIoZHVlLCBzY2hlZHVsZXIpO1xuICAgIHJldHVybiBkZWxheVdoZW4oZnVuY3Rpb24gKCkgeyByZXR1cm4gZHVyYXRpb247IH0pO1xufVxuIiwiaW1wb3J0IHsgb2JzZXJ2ZU5vdGlmaWNhdGlvbiB9IGZyb20gJy4uL05vdGlmaWNhdGlvbic7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBkZW1hdGVyaWFsaXplKCkge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKG5vdGlmaWNhdGlvbikgeyByZXR1cm4gb2JzZXJ2ZU5vdGlmaWNhdGlvbihub3RpZmljYXRpb24sIHN1YnNjcmliZXIpOyB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIGRpc3RpbmN0KGtleVNlbGVjdG9yLCBmbHVzaGVzKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgZGlzdGluY3RLZXlzID0gbmV3IFNldCgpO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBrZXkgPSBrZXlTZWxlY3RvciA/IGtleVNlbGVjdG9yKHZhbHVlKSA6IHZhbHVlO1xuICAgICAgICAgICAgaWYgKCFkaXN0aW5jdEtleXMuaGFzKGtleSkpIHtcbiAgICAgICAgICAgICAgICBkaXN0aW5jdEtleXMuYWRkKGtleSk7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkpO1xuICAgICAgICBmbHVzaGVzICYmIGlubmVyRnJvbShmbHVzaGVzKS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIGRpc3RpbmN0S2V5cy5jbGVhcigpOyB9LCBub29wKSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBpZGVudGl0eSB9IGZyb20gJy4uL3V0aWwvaWRlbnRpdHknO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gZGlzdGluY3RVbnRpbENoYW5nZWQoY29tcGFyYXRvciwga2V5U2VsZWN0b3IpIHtcbiAgICBpZiAoa2V5U2VsZWN0b3IgPT09IHZvaWQgMCkgeyBrZXlTZWxlY3RvciA9IGlkZW50aXR5OyB9XG4gICAgY29tcGFyYXRvciA9IGNvbXBhcmF0b3IgIT09IG51bGwgJiYgY29tcGFyYXRvciAhPT0gdm9pZCAwID8gY29tcGFyYXRvciA6IGRlZmF1bHRDb21wYXJlO1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIHByZXZpb3VzS2V5O1xuICAgICAgICB2YXIgZmlyc3QgPSB0cnVlO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBjdXJyZW50S2V5ID0ga2V5U2VsZWN0b3IodmFsdWUpO1xuICAgICAgICAgICAgaWYgKGZpcnN0IHx8ICFjb21wYXJhdG9yKHByZXZpb3VzS2V5LCBjdXJyZW50S2V5KSkge1xuICAgICAgICAgICAgICAgIGZpcnN0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgcHJldmlvdXNLZXkgPSBjdXJyZW50S2V5O1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRDb21wYXJlKGEsIGIpIHtcbiAgICByZXR1cm4gYSA9PT0gYjtcbn1cbiIsImltcG9ydCB7IGRpc3RpbmN0VW50aWxDaGFuZ2VkIH0gZnJvbSAnLi9kaXN0aW5jdFVudGlsQ2hhbmdlZCc7XG5leHBvcnQgZnVuY3Rpb24gZGlzdGluY3RVbnRpbEtleUNoYW5nZWQoa2V5LCBjb21wYXJlKSB7XG4gICAgcmV0dXJuIGRpc3RpbmN0VW50aWxDaGFuZ2VkKGZ1bmN0aW9uICh4LCB5KSB7IHJldHVybiAoY29tcGFyZSA/IGNvbXBhcmUoeFtrZXldLCB5W2tleV0pIDogeFtrZXldID09PSB5W2tleV0pOyB9KTtcbn1cbiIsImltcG9ydCB7IEVtcHR5RXJyb3IgfSBmcm9tICcuLi91dGlsL0VtcHR5RXJyb3InO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gdGhyb3dJZkVtcHR5KGVycm9yRmFjdG9yeSkge1xuICAgIGlmIChlcnJvckZhY3RvcnkgPT09IHZvaWQgMCkgeyBlcnJvckZhY3RvcnkgPSBkZWZhdWx0RXJyb3JGYWN0b3J5OyB9XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgaGFzVmFsdWUgPSBmYWxzZTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBoYXNWYWx1ZSA9IHRydWU7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodmFsdWUpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7IHJldHVybiAoaGFzVmFsdWUgPyBzdWJzY3JpYmVyLmNvbXBsZXRlKCkgOiBzdWJzY3JpYmVyLmVycm9yKGVycm9yRmFjdG9yeSgpKSk7IH0pKTtcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGRlZmF1bHRFcnJvckZhY3RvcnkoKSB7XG4gICAgcmV0dXJuIG5ldyBFbXB0eUVycm9yKCk7XG59XG4iLCJpbXBvcnQgeyBBcmd1bWVudE91dE9mUmFuZ2VFcnJvciB9IGZyb20gJy4uL3V0aWwvQXJndW1lbnRPdXRPZlJhbmdlRXJyb3InO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAnLi9maWx0ZXInO1xuaW1wb3J0IHsgdGhyb3dJZkVtcHR5IH0gZnJvbSAnLi90aHJvd0lmRW1wdHknO1xuaW1wb3J0IHsgZGVmYXVsdElmRW1wdHkgfSBmcm9tICcuL2RlZmF1bHRJZkVtcHR5JztcbmltcG9ydCB7IHRha2UgfSBmcm9tICcuL3Rha2UnO1xuZXhwb3J0IGZ1bmN0aW9uIGVsZW1lbnRBdChpbmRleCwgZGVmYXVsdFZhbHVlKSB7XG4gICAgaWYgKGluZGV4IDwgMCkge1xuICAgICAgICB0aHJvdyBuZXcgQXJndW1lbnRPdXRPZlJhbmdlRXJyb3IoKTtcbiAgICB9XG4gICAgdmFyIGhhc0RlZmF1bHRWYWx1ZSA9IGFyZ3VtZW50cy5sZW5ndGggPj0gMjtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHNvdXJjZSkge1xuICAgICAgICByZXR1cm4gc291cmNlLnBpcGUoZmlsdGVyKGZ1bmN0aW9uICh2LCBpKSB7IHJldHVybiBpID09PSBpbmRleDsgfSksIHRha2UoMSksIGhhc0RlZmF1bHRWYWx1ZSA/IGRlZmF1bHRJZkVtcHR5KGRlZmF1bHRWYWx1ZSkgOiB0aHJvd0lmRW1wdHkoZnVuY3Rpb24gKCkgeyByZXR1cm4gbmV3IEFyZ3VtZW50T3V0T2ZSYW5nZUVycm9yKCk7IH0pKTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBjb25jYXQgfSBmcm9tICcuLi9vYnNlcnZhYmxlL2NvbmNhdCc7XG5pbXBvcnQgeyBvZiB9IGZyb20gJy4uL29ic2VydmFibGUvb2YnO1xuZXhwb3J0IGZ1bmN0aW9uIGVuZFdpdGgoKSB7XG4gICAgdmFyIHZhbHVlcyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHZhbHVlc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICByZXR1cm4gZnVuY3Rpb24gKHNvdXJjZSkgeyByZXR1cm4gY29uY2F0KHNvdXJjZSwgb2YuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQodmFsdWVzKSkpKTsgfTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGV2ZXJ5KHByZWRpY2F0ZSwgdGhpc0FyZykge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBpZiAoIXByZWRpY2F0ZS5jYWxsKHRoaXNBcmcsIHZhbHVlLCBpbmRleCsrLCBzb3VyY2UpKSB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGZhbHNlKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh0cnVlKTtcbiAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgbWFwIH0gZnJvbSAnLi9tYXAnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gZXhoYXVzdE1hcChwcm9qZWN0LCByZXN1bHRTZWxlY3Rvcikge1xuICAgIGlmIChyZXN1bHRTZWxlY3Rvcikge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKHNvdXJjZSkge1xuICAgICAgICAgICAgcmV0dXJuIHNvdXJjZS5waXBlKGV4aGF1c3RNYXAoZnVuY3Rpb24gKGEsIGkpIHsgcmV0dXJuIGlubmVyRnJvbShwcm9qZWN0KGEsIGkpKS5waXBlKG1hcChmdW5jdGlvbiAoYiwgaWkpIHsgcmV0dXJuIHJlc3VsdFNlbGVjdG9yKGEsIGIsIGksIGlpKTsgfSkpOyB9KSk7XG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgdmFyIGlubmVyU3ViID0gbnVsbDtcbiAgICAgICAgdmFyIGlzQ29tcGxldGUgPSBmYWxzZTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKG91dGVyVmFsdWUpIHtcbiAgICAgICAgICAgIGlmICghaW5uZXJTdWIpIHtcbiAgICAgICAgICAgICAgICBpbm5lclN1YiA9IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJTdWIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICBpc0NvbXBsZXRlICYmIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpbm5lckZyb20ocHJvamVjdChvdXRlclZhbHVlLCBpbmRleCsrKSkuc3Vic2NyaWJlKGlubmVyU3ViKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaXNDb21wbGV0ZSA9IHRydWU7XG4gICAgICAgICAgICAhaW5uZXJTdWIgJiYgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBleGhhdXN0TWFwIH0gZnJvbSAnLi9leGhhdXN0TWFwJztcbmltcG9ydCB7IGlkZW50aXR5IH0gZnJvbSAnLi4vdXRpbC9pZGVudGl0eSc7XG5leHBvcnQgZnVuY3Rpb24gZXhoYXVzdEFsbCgpIHtcbiAgICByZXR1cm4gZXhoYXVzdE1hcChpZGVudGl0eSk7XG59XG4iLCJpbXBvcnQgeyBleGhhdXN0QWxsIH0gZnJvbSAnLi9leGhhdXN0QWxsJztcbmV4cG9ydCB2YXIgZXhoYXVzdCA9IGV4aGF1c3RBbGw7XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IG1lcmdlSW50ZXJuYWxzIH0gZnJvbSAnLi9tZXJnZUludGVybmFscyc7XG5leHBvcnQgZnVuY3Rpb24gZXhwYW5kKHByb2plY3QsIGNvbmN1cnJlbnQsIHNjaGVkdWxlcikge1xuICAgIGlmIChjb25jdXJyZW50ID09PSB2b2lkIDApIHsgY29uY3VycmVudCA9IEluZmluaXR5OyB9XG4gICAgY29uY3VycmVudCA9IChjb25jdXJyZW50IHx8IDApIDwgMSA/IEluZmluaXR5IDogY29uY3VycmVudDtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHJldHVybiBtZXJnZUludGVybmFscyhzb3VyY2UsIHN1YnNjcmliZXIsIHByb2plY3QsIGNvbmN1cnJlbnQsIHVuZGVmaW5lZCwgdHJ1ZSwgc2NoZWR1bGVyKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuZXhwb3J0IGZ1bmN0aW9uIGZpbmFsaXplKGNhbGxiYWNrKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgc291cmNlLnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIuYWRkKGNhbGxiYWNrKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gZmluZChwcmVkaWNhdGUsIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShjcmVhdGVGaW5kKHByZWRpY2F0ZSwgdGhpc0FyZywgJ3ZhbHVlJykpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUZpbmQocHJlZGljYXRlLCB0aGlzQXJnLCBlbWl0KSB7XG4gICAgdmFyIGZpbmRJbmRleCA9IGVtaXQgPT09ICdpbmRleCc7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGluZGV4ID0gMDtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB2YXIgaSA9IGluZGV4Kys7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlLmNhbGwodGhpc0FyZywgdmFsdWUsIGksIHNvdXJjZSkpIHtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoZmluZEluZGV4ID8gaSA6IHZhbHVlKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChmaW5kSW5kZXggPyAtMSA6IHVuZGVmaW5lZCk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0pKTtcbiAgICB9O1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVGaW5kIH0gZnJvbSAnLi9maW5kJztcbmV4cG9ydCBmdW5jdGlvbiBmaW5kSW5kZXgocHJlZGljYXRlLCB0aGlzQXJnKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoY3JlYXRlRmluZChwcmVkaWNhdGUsIHRoaXNBcmcsICdpbmRleCcpKTtcbn1cbiIsImltcG9ydCB7IEVtcHR5RXJyb3IgfSBmcm9tICcuLi91dGlsL0VtcHR5RXJyb3InO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAnLi9maWx0ZXInO1xuaW1wb3J0IHsgdGFrZSB9IGZyb20gJy4vdGFrZSc7XG5pbXBvcnQgeyBkZWZhdWx0SWZFbXB0eSB9IGZyb20gJy4vZGVmYXVsdElmRW1wdHknO1xuaW1wb3J0IHsgdGhyb3dJZkVtcHR5IH0gZnJvbSAnLi90aHJvd0lmRW1wdHknO1xuaW1wb3J0IHsgaWRlbnRpdHkgfSBmcm9tICcuLi91dGlsL2lkZW50aXR5JztcbmV4cG9ydCBmdW5jdGlvbiBmaXJzdChwcmVkaWNhdGUsIGRlZmF1bHRWYWx1ZSkge1xuICAgIHZhciBoYXNEZWZhdWx0VmFsdWUgPSBhcmd1bWVudHMubGVuZ3RoID49IDI7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzb3VyY2UpIHtcbiAgICAgICAgcmV0dXJuIHNvdXJjZS5waXBlKHByZWRpY2F0ZSA/IGZpbHRlcihmdW5jdGlvbiAodiwgaSkgeyByZXR1cm4gcHJlZGljYXRlKHYsIGksIHNvdXJjZSk7IH0pIDogaWRlbnRpdHksIHRha2UoMSksIGhhc0RlZmF1bHRWYWx1ZSA/IGRlZmF1bHRJZkVtcHR5KGRlZmF1bHRWYWx1ZSkgOiB0aHJvd0lmRW1wdHkoZnVuY3Rpb24gKCkgeyByZXR1cm4gbmV3IEVtcHR5RXJyb3IoKTsgfSkpO1xuICAgIH07XG59XG4iLCJpbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAnLi4vT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAnLi4vU3ViamVjdCc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciwgT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGdyb3VwQnkoa2V5U2VsZWN0b3IsIGVsZW1lbnRPck9wdGlvbnMsIGR1cmF0aW9uLCBjb25uZWN0b3IpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBlbGVtZW50O1xuICAgICAgICBpZiAoIWVsZW1lbnRPck9wdGlvbnMgfHwgdHlwZW9mIGVsZW1lbnRPck9wdGlvbnMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGVsZW1lbnQgPSBlbGVtZW50T3JPcHRpb25zO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgKGR1cmF0aW9uID0gZWxlbWVudE9yT3B0aW9ucy5kdXJhdGlvbiwgZWxlbWVudCA9IGVsZW1lbnRPck9wdGlvbnMuZWxlbWVudCwgY29ubmVjdG9yID0gZWxlbWVudE9yT3B0aW9ucy5jb25uZWN0b3IpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBncm91cHMgPSBuZXcgTWFwKCk7XG4gICAgICAgIHZhciBub3RpZnkgPSBmdW5jdGlvbiAoY2IpIHtcbiAgICAgICAgICAgIGdyb3Vwcy5mb3JFYWNoKGNiKTtcbiAgICAgICAgICAgIGNiKHN1YnNjcmliZXIpO1xuICAgICAgICB9O1xuICAgICAgICB2YXIgaGFuZGxlRXJyb3IgPSBmdW5jdGlvbiAoZXJyKSB7IHJldHVybiBub3RpZnkoZnVuY3Rpb24gKGNvbnN1bWVyKSB7IHJldHVybiBjb25zdW1lci5lcnJvcihlcnIpOyB9KTsgfTtcbiAgICAgICAgdmFyIGFjdGl2ZUdyb3VwcyA9IDA7XG4gICAgICAgIHZhciB0ZWFyZG93bkF0dGVtcHRlZCA9IGZhbHNlO1xuICAgICAgICB2YXIgZ3JvdXBCeVNvdXJjZVN1YnNjcmliZXIgPSBuZXcgT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB2YXIga2V5XzEgPSBrZXlTZWxlY3Rvcih2YWx1ZSk7XG4gICAgICAgICAgICAgICAgdmFyIGdyb3VwXzEgPSBncm91cHMuZ2V0KGtleV8xKTtcbiAgICAgICAgICAgICAgICBpZiAoIWdyb3VwXzEpIHtcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzLnNldChrZXlfMSwgKGdyb3VwXzEgPSBjb25uZWN0b3IgPyBjb25uZWN0b3IoKSA6IG5ldyBTdWJqZWN0KCkpKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGdyb3VwZWQgPSBjcmVhdGVHcm91cGVkT2JzZXJ2YWJsZShrZXlfMSwgZ3JvdXBfMSk7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChncm91cGVkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGR1cmF0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZHVyYXRpb25TdWJzY3JpYmVyXzEgPSBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoZ3JvdXBfMSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwXzEuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdXJhdGlvblN1YnNjcmliZXJfMSA9PT0gbnVsbCB8fCBkdXJhdGlvblN1YnNjcmliZXJfMSA9PT0gdm9pZCAwID8gdm9pZCAwIDogZHVyYXRpb25TdWJzY3JpYmVyXzEudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBmdW5jdGlvbiAoKSB7IHJldHVybiBncm91cHMuZGVsZXRlKGtleV8xKTsgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBncm91cEJ5U291cmNlU3Vic2NyaWJlci5hZGQoaW5uZXJGcm9tKGR1cmF0aW9uKGdyb3VwZWQpKS5zdWJzY3JpYmUoZHVyYXRpb25TdWJzY3JpYmVyXzEpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBncm91cF8xLm5leHQoZWxlbWVudCA/IGVsZW1lbnQodmFsdWUpIDogdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGhhbmRsZUVycm9yKGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHsgcmV0dXJuIG5vdGlmeShmdW5jdGlvbiAoY29uc3VtZXIpIHsgcmV0dXJuIGNvbnN1bWVyLmNvbXBsZXRlKCk7IH0pOyB9LCBoYW5kbGVFcnJvciwgZnVuY3Rpb24gKCkgeyByZXR1cm4gZ3JvdXBzLmNsZWFyKCk7IH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHRlYXJkb3duQXR0ZW1wdGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHJldHVybiBhY3RpdmVHcm91cHMgPT09IDA7XG4gICAgICAgIH0pO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGdyb3VwQnlTb3VyY2VTdWJzY3JpYmVyKTtcbiAgICAgICAgZnVuY3Rpb24gY3JlYXRlR3JvdXBlZE9ic2VydmFibGUoa2V5LCBncm91cFN1YmplY3QpIHtcbiAgICAgICAgICAgIHZhciByZXN1bHQgPSBuZXcgT2JzZXJ2YWJsZShmdW5jdGlvbiAoZ3JvdXBTdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICAgICAgYWN0aXZlR3JvdXBzKys7XG4gICAgICAgICAgICAgICAgdmFyIGlubmVyU3ViID0gZ3JvdXBTdWJqZWN0LnN1YnNjcmliZShncm91cFN1YnNjcmliZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlubmVyU3ViLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgICAgIC0tYWN0aXZlR3JvdXBzID09PSAwICYmIHRlYXJkb3duQXR0ZW1wdGVkICYmIGdyb3VwQnlTb3VyY2VTdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmVzdWx0LmtleSA9IGtleTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIGlzRW1wdHkoKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoZmFsc2UpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQodHJ1ZSk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IF9fdmFsdWVzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBFTVBUWSB9IGZyb20gJy4uL29ic2VydmFibGUvZW1wdHknO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gdGFrZUxhc3QoY291bnQpIHtcbiAgICByZXR1cm4gY291bnQgPD0gMFxuICAgICAgICA/IGZ1bmN0aW9uICgpIHsgcmV0dXJuIEVNUFRZOyB9XG4gICAgICAgIDogb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICB2YXIgYnVmZmVyID0gW107XG4gICAgICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgICAgICBidWZmZXIucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgY291bnQgPCBidWZmZXIubGVuZ3RoICYmIGJ1ZmZlci5zaGlmdCgpO1xuICAgICAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHZhciBlXzEsIF9hO1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGJ1ZmZlcl8xID0gX192YWx1ZXMoYnVmZmVyKSwgYnVmZmVyXzFfMSA9IGJ1ZmZlcl8xLm5leHQoKTsgIWJ1ZmZlcl8xXzEuZG9uZTsgYnVmZmVyXzFfMSA9IGJ1ZmZlcl8xLm5leHQoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHZhbHVlID0gYnVmZmVyXzFfMS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWZmZXJfMV8xICYmICFidWZmZXJfMV8xLmRvbmUgJiYgKF9hID0gYnVmZmVyXzEucmV0dXJuKSkgX2EuY2FsbChidWZmZXJfMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZmluYWxseSB7IGlmIChlXzEpIHRocm93IGVfMS5lcnJvcjsgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9LCB1bmRlZmluZWQsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBidWZmZXIgPSBudWxsO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9KTtcbn1cbiIsImltcG9ydCB7IEVtcHR5RXJyb3IgfSBmcm9tICcuLi91dGlsL0VtcHR5RXJyb3InO1xuaW1wb3J0IHsgZmlsdGVyIH0gZnJvbSAnLi9maWx0ZXInO1xuaW1wb3J0IHsgdGFrZUxhc3QgfSBmcm9tICcuL3Rha2VMYXN0JztcbmltcG9ydCB7IHRocm93SWZFbXB0eSB9IGZyb20gJy4vdGhyb3dJZkVtcHR5JztcbmltcG9ydCB7IGRlZmF1bHRJZkVtcHR5IH0gZnJvbSAnLi9kZWZhdWx0SWZFbXB0eSc7XG5pbXBvcnQgeyBpZGVudGl0eSB9IGZyb20gJy4uL3V0aWwvaWRlbnRpdHknO1xuZXhwb3J0IGZ1bmN0aW9uIGxhc3QocHJlZGljYXRlLCBkZWZhdWx0VmFsdWUpIHtcbiAgICB2YXIgaGFzRGVmYXVsdFZhbHVlID0gYXJndW1lbnRzLmxlbmd0aCA+PSAyO1xuICAgIHJldHVybiBmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICAgIHJldHVybiBzb3VyY2UucGlwZShwcmVkaWNhdGUgPyBmaWx0ZXIoZnVuY3Rpb24gKHYsIGkpIHsgcmV0dXJuIHByZWRpY2F0ZSh2LCBpLCBzb3VyY2UpOyB9KSA6IGlkZW50aXR5LCB0YWtlTGFzdCgxKSwgaGFzRGVmYXVsdFZhbHVlID8gZGVmYXVsdElmRW1wdHkoZGVmYXVsdFZhbHVlKSA6IHRocm93SWZFbXB0eShmdW5jdGlvbiAoKSB7IHJldHVybiBuZXcgRW1wdHlFcnJvcigpOyB9KSk7XG4gICAgfTtcbn1cbiIsImltcG9ydCB7IE5vdGlmaWNhdGlvbiB9IGZyb20gJy4uL05vdGlmaWNhdGlvbic7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBtYXRlcmlhbGl6ZSgpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KE5vdGlmaWNhdGlvbi5jcmVhdGVOZXh0KHZhbHVlKSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChOb3RpZmljYXRpb24uY3JlYXRlQ29tcGxldGUoKSk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChOb3RpZmljYXRpb24uY3JlYXRlRXJyb3IoZXJyKSk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IHJlZHVjZSB9IGZyb20gJy4vcmVkdWNlJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuLi91dGlsL2lzRnVuY3Rpb24nO1xuZXhwb3J0IGZ1bmN0aW9uIG1heChjb21wYXJlcikge1xuICAgIHJldHVybiByZWR1Y2UoaXNGdW5jdGlvbihjb21wYXJlcikgPyBmdW5jdGlvbiAoeCwgeSkgeyByZXR1cm4gKGNvbXBhcmVyKHgsIHkpID4gMCA/IHggOiB5KTsgfSA6IGZ1bmN0aW9uICh4LCB5KSB7IHJldHVybiAoeCA+IHkgPyB4IDogeSk7IH0pO1xufVxuIiwiaW1wb3J0IHsgbWVyZ2VNYXAgfSBmcm9tICcuL21lcmdlTWFwJztcbmV4cG9ydCB2YXIgZmxhdE1hcCA9IG1lcmdlTWFwO1xuIiwiaW1wb3J0IHsgbWVyZ2VNYXAgfSBmcm9tICcuL21lcmdlTWFwJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICcuLi91dGlsL2lzRnVuY3Rpb24nO1xuZXhwb3J0IGZ1bmN0aW9uIG1lcmdlTWFwVG8oaW5uZXJPYnNlcnZhYmxlLCByZXN1bHRTZWxlY3RvciwgY29uY3VycmVudCkge1xuICAgIGlmIChjb25jdXJyZW50ID09PSB2b2lkIDApIHsgY29uY3VycmVudCA9IEluZmluaXR5OyB9XG4gICAgaWYgKGlzRnVuY3Rpb24ocmVzdWx0U2VsZWN0b3IpKSB7XG4gICAgICAgIHJldHVybiBtZXJnZU1hcChmdW5jdGlvbiAoKSB7IHJldHVybiBpbm5lck9ic2VydmFibGU7IH0sIHJlc3VsdFNlbGVjdG9yLCBjb25jdXJyZW50KTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiByZXN1bHRTZWxlY3RvciA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgY29uY3VycmVudCA9IHJlc3VsdFNlbGVjdG9yO1xuICAgIH1cbiAgICByZXR1cm4gbWVyZ2VNYXAoZnVuY3Rpb24gKCkgeyByZXR1cm4gaW5uZXJPYnNlcnZhYmxlOyB9LCBjb25jdXJyZW50KTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgbWVyZ2VJbnRlcm5hbHMgfSBmcm9tICcuL21lcmdlSW50ZXJuYWxzJztcbmV4cG9ydCBmdW5jdGlvbiBtZXJnZVNjYW4oYWNjdW11bGF0b3IsIHNlZWQsIGNvbmN1cnJlbnQpIHtcbiAgICBpZiAoY29uY3VycmVudCA9PT0gdm9pZCAwKSB7IGNvbmN1cnJlbnQgPSBJbmZpbml0eTsgfVxuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIHN0YXRlID0gc2VlZDtcbiAgICAgICAgcmV0dXJuIG1lcmdlSW50ZXJuYWxzKHNvdXJjZSwgc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlLCBpbmRleCkgeyByZXR1cm4gYWNjdW11bGF0b3Ioc3RhdGUsIHZhbHVlLCBpbmRleCk7IH0sIGNvbmN1cnJlbnQsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgc3RhdGUgPSB2YWx1ZTtcbiAgICAgICAgfSwgZmFsc2UsIHVuZGVmaW5lZCwgZnVuY3Rpb24gKCkgeyByZXR1cm4gKHN0YXRlID0gbnVsbCk7IH0pO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgX19yZWFkLCBfX3NwcmVhZEFycmF5IH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IG1lcmdlQWxsIH0gZnJvbSAnLi9tZXJnZUFsbCc7XG5pbXBvcnQgeyBwb3BOdW1iZXIsIHBvcFNjaGVkdWxlciB9IGZyb20gJy4uL3V0aWwvYXJncyc7XG5pbXBvcnQgeyBmcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9mcm9tJztcbmV4cG9ydCBmdW5jdGlvbiBtZXJnZSgpIHtcbiAgICB2YXIgYXJncyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIGFyZ3NbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIHNjaGVkdWxlciA9IHBvcFNjaGVkdWxlcihhcmdzKTtcbiAgICB2YXIgY29uY3VycmVudCA9IHBvcE51bWJlcihhcmdzLCBJbmZpbml0eSk7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICBtZXJnZUFsbChjb25jdXJyZW50KShmcm9tKF9fc3ByZWFkQXJyYXkoW3NvdXJjZV0sIF9fcmVhZChhcmdzKSksIHNjaGVkdWxlcikpLnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IF9fcmVhZCwgX19zcHJlYWRBcnJheSB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgbWVyZ2UgfSBmcm9tICcuL21lcmdlJztcbmV4cG9ydCBmdW5jdGlvbiBtZXJnZVdpdGgoKSB7XG4gICAgdmFyIG90aGVyU291cmNlcyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIG90aGVyU291cmNlc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICByZXR1cm4gbWVyZ2UuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQob3RoZXJTb3VyY2VzKSkpO1xufVxuIiwiaW1wb3J0IHsgcmVkdWNlIH0gZnJvbSAnLi9yZWR1Y2UnO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4uL3V0aWwvaXNGdW5jdGlvbic7XG5leHBvcnQgZnVuY3Rpb24gbWluKGNvbXBhcmVyKSB7XG4gICAgcmV0dXJuIHJlZHVjZShpc0Z1bmN0aW9uKGNvbXBhcmVyKSA/IGZ1bmN0aW9uICh4LCB5KSB7IHJldHVybiAoY29tcGFyZXIoeCwgeSkgPCAwID8geCA6IHkpOyB9IDogZnVuY3Rpb24gKHgsIHkpIHsgcmV0dXJuICh4IDwgeSA/IHggOiB5KTsgfSk7XG59XG4iLCJpbXBvcnQgeyBDb25uZWN0YWJsZU9ic2VydmFibGUgfSBmcm9tICcuLi9vYnNlcnZhYmxlL0Nvbm5lY3RhYmxlT2JzZXJ2YWJsZSc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi4vdXRpbC9pc0Z1bmN0aW9uJztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICcuL2Nvbm5lY3QnO1xuZXhwb3J0IGZ1bmN0aW9uIG11bHRpY2FzdChzdWJqZWN0T3JTdWJqZWN0RmFjdG9yeSwgc2VsZWN0b3IpIHtcbiAgICB2YXIgc3ViamVjdEZhY3RvcnkgPSBpc0Z1bmN0aW9uKHN1YmplY3RPclN1YmplY3RGYWN0b3J5KSA/IHN1YmplY3RPclN1YmplY3RGYWN0b3J5IDogZnVuY3Rpb24gKCkgeyByZXR1cm4gc3ViamVjdE9yU3ViamVjdEZhY3Rvcnk7IH07XG4gICAgaWYgKGlzRnVuY3Rpb24oc2VsZWN0b3IpKSB7XG4gICAgICAgIHJldHVybiBjb25uZWN0KHNlbGVjdG9yLCB7XG4gICAgICAgICAgICBjb25uZWN0b3I6IHN1YmplY3RGYWN0b3J5LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChzb3VyY2UpIHsgcmV0dXJuIG5ldyBDb25uZWN0YWJsZU9ic2VydmFibGUoc291cmNlLCBzdWJqZWN0RmFjdG9yeSk7IH07XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGFyZ3NPckFyZ0FycmF5IH0gZnJvbSAnLi4vdXRpbC9hcmdzT3JBcmdBcnJheSc7XG5pbXBvcnQgeyBvbkVycm9yUmVzdW1lTmV4dCBhcyBvRVJOQ3JlYXRlIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9vbkVycm9yUmVzdW1lTmV4dCc7XG5leHBvcnQgZnVuY3Rpb24gb25FcnJvclJlc3VtZU5leHRXaXRoKCkge1xuICAgIHZhciBzb3VyY2VzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgc291cmNlc1tfaV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgbmV4dFNvdXJjZXMgPSBhcmdzT3JBcmdBcnJheShzb3VyY2VzKTtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHNvdXJjZSkgeyByZXR1cm4gb0VSTkNyZWF0ZS5hcHBseSh2b2lkIDAsIF9fc3ByZWFkQXJyYXkoW3NvdXJjZV0sIF9fcmVhZChuZXh0U291cmNlcykpKTsgfTtcbn1cbmV4cG9ydCB2YXIgb25FcnJvclJlc3VtZU5leHQgPSBvbkVycm9yUmVzdW1lTmV4dFdpdGg7XG4iLCJpbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBwYWlyd2lzZSgpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBwcmV2O1xuICAgICAgICB2YXIgaGFzUHJldiA9IGZhbHNlO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBwID0gcHJldjtcbiAgICAgICAgICAgIHByZXYgPSB2YWx1ZTtcbiAgICAgICAgICAgIGhhc1ByZXYgJiYgc3Vic2NyaWJlci5uZXh0KFtwLCB2YWx1ZV0pO1xuICAgICAgICAgICAgaGFzUHJldiA9IHRydWU7XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IG1hcCB9IGZyb20gJy4vbWFwJztcbmV4cG9ydCBmdW5jdGlvbiBwbHVjaygpIHtcbiAgICB2YXIgcHJvcGVydGllcyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHByb3BlcnRpZXNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIGxlbmd0aCA9IHByb3BlcnRpZXMubGVuZ3RoO1xuICAgIGlmIChsZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdsaXN0IG9mIHByb3BlcnRpZXMgY2Fubm90IGJlIGVtcHR5LicpO1xuICAgIH1cbiAgICByZXR1cm4gbWFwKGZ1bmN0aW9uICh4KSB7XG4gICAgICAgIHZhciBjdXJyZW50UHJvcCA9IHg7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciBwID0gY3VycmVudFByb3AgPT09IG51bGwgfHwgY3VycmVudFByb3AgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGN1cnJlbnRQcm9wW3Byb3BlcnRpZXNbaV1dO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBwICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIGN1cnJlbnRQcm9wID0gcDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGN1cnJlbnRQcm9wO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4uL1N1YmplY3QnO1xuaW1wb3J0IHsgbXVsdGljYXN0IH0gZnJvbSAnLi9tdWx0aWNhc3QnO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJy4vY29ubmVjdCc7XG5leHBvcnQgZnVuY3Rpb24gcHVibGlzaChzZWxlY3Rvcikge1xuICAgIHJldHVybiBzZWxlY3RvciA/IGZ1bmN0aW9uIChzb3VyY2UpIHsgcmV0dXJuIGNvbm5lY3Qoc2VsZWN0b3IpKHNvdXJjZSk7IH0gOiBmdW5jdGlvbiAoc291cmNlKSB7IHJldHVybiBtdWx0aWNhc3QobmV3IFN1YmplY3QoKSkoc291cmNlKTsgfTtcbn1cbiIsImltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJy4uL0JlaGF2aW9yU3ViamVjdCc7XG5pbXBvcnQgeyBDb25uZWN0YWJsZU9ic2VydmFibGUgfSBmcm9tICcuLi9vYnNlcnZhYmxlL0Nvbm5lY3RhYmxlT2JzZXJ2YWJsZSc7XG5leHBvcnQgZnVuY3Rpb24gcHVibGlzaEJlaGF2aW9yKGluaXRpYWxWYWx1ZSkge1xuICAgIHJldHVybiBmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICAgIHZhciBzdWJqZWN0ID0gbmV3IEJlaGF2aW9yU3ViamVjdChpbml0aWFsVmFsdWUpO1xuICAgICAgICByZXR1cm4gbmV3IENvbm5lY3RhYmxlT2JzZXJ2YWJsZShzb3VyY2UsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIHN1YmplY3Q7IH0pO1xuICAgIH07XG59XG4iLCJpbXBvcnQgeyBBc3luY1N1YmplY3QgfSBmcm9tICcuLi9Bc3luY1N1YmplY3QnO1xuaW1wb3J0IHsgQ29ubmVjdGFibGVPYnNlcnZhYmxlIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9Db25uZWN0YWJsZU9ic2VydmFibGUnO1xuZXhwb3J0IGZ1bmN0aW9uIHB1Ymxpc2hMYXN0KCkge1xuICAgIHJldHVybiBmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICAgIHZhciBzdWJqZWN0ID0gbmV3IEFzeW5jU3ViamVjdCgpO1xuICAgICAgICByZXR1cm4gbmV3IENvbm5lY3RhYmxlT2JzZXJ2YWJsZShzb3VyY2UsIGZ1bmN0aW9uICgpIHsgcmV0dXJuIHN1YmplY3Q7IH0pO1xuICAgIH07XG59XG4iLCJpbXBvcnQgeyBSZXBsYXlTdWJqZWN0IH0gZnJvbSAnLi4vUmVwbGF5U3ViamVjdCc7XG5pbXBvcnQgeyBtdWx0aWNhc3QgfSBmcm9tICcuL211bHRpY2FzdCc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi4vdXRpbC9pc0Z1bmN0aW9uJztcbmV4cG9ydCBmdW5jdGlvbiBwdWJsaXNoUmVwbGF5KGJ1ZmZlclNpemUsIHdpbmRvd1RpbWUsIHNlbGVjdG9yT3JTY2hlZHVsZXIsIHRpbWVzdGFtcFByb3ZpZGVyKSB7XG4gICAgaWYgKHNlbGVjdG9yT3JTY2hlZHVsZXIgJiYgIWlzRnVuY3Rpb24oc2VsZWN0b3JPclNjaGVkdWxlcikpIHtcbiAgICAgICAgdGltZXN0YW1wUHJvdmlkZXIgPSBzZWxlY3Rvck9yU2NoZWR1bGVyO1xuICAgIH1cbiAgICB2YXIgc2VsZWN0b3IgPSBpc0Z1bmN0aW9uKHNlbGVjdG9yT3JTY2hlZHVsZXIpID8gc2VsZWN0b3JPclNjaGVkdWxlciA6IHVuZGVmaW5lZDtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHNvdXJjZSkgeyByZXR1cm4gbXVsdGljYXN0KG5ldyBSZXBsYXlTdWJqZWN0KGJ1ZmZlclNpemUsIHdpbmRvd1RpbWUsIHRpbWVzdGFtcFByb3ZpZGVyKSwgc2VsZWN0b3IpKHNvdXJjZSk7IH07XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IHJhY2VJbml0IH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9yYWNlJztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgaWRlbnRpdHkgfSBmcm9tICcuLi91dGlsL2lkZW50aXR5JztcbmV4cG9ydCBmdW5jdGlvbiByYWNlV2l0aCgpIHtcbiAgICB2YXIgb3RoZXJTb3VyY2VzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgb3RoZXJTb3VyY2VzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHJldHVybiAhb3RoZXJTb3VyY2VzLmxlbmd0aFxuICAgICAgICA/IGlkZW50aXR5XG4gICAgICAgIDogb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICByYWNlSW5pdChfX3NwcmVhZEFycmF5KFtzb3VyY2VdLCBfX3JlYWQob3RoZXJTb3VyY2VzKSkpKHN1YnNjcmliZXIpO1xuICAgICAgICB9KTtcbn1cbiIsImltcG9ydCB7IEVNUFRZIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9lbXB0eSc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS90aW1lcic7XG5leHBvcnQgZnVuY3Rpb24gcmVwZWF0KGNvdW50T3JDb25maWcpIHtcbiAgICB2YXIgX2E7XG4gICAgdmFyIGNvdW50ID0gSW5maW5pdHk7XG4gICAgdmFyIGRlbGF5O1xuICAgIGlmIChjb3VudE9yQ29uZmlnICE9IG51bGwpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBjb3VudE9yQ29uZmlnID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgKF9hID0gY291bnRPckNvbmZpZy5jb3VudCwgY291bnQgPSBfYSA9PT0gdm9pZCAwID8gSW5maW5pdHkgOiBfYSwgZGVsYXkgPSBjb3VudE9yQ29uZmlnLmRlbGF5KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvdW50ID0gY291bnRPckNvbmZpZztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY291bnQgPD0gMFxuICAgICAgICA/IGZ1bmN0aW9uICgpIHsgcmV0dXJuIEVNUFRZOyB9XG4gICAgICAgIDogb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICB2YXIgc29GYXIgPSAwO1xuICAgICAgICAgICAgdmFyIHNvdXJjZVN1YjtcbiAgICAgICAgICAgIHZhciByZXN1YnNjcmliZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBzb3VyY2VTdWIgPT09IG51bGwgfHwgc291cmNlU3ViID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzb3VyY2VTdWIudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICBzb3VyY2VTdWIgPSBudWxsO1xuICAgICAgICAgICAgICAgIGlmIChkZWxheSAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBub3RpZmllciA9IHR5cGVvZiBkZWxheSA9PT0gJ251bWJlcicgPyB0aW1lcihkZWxheSkgOiBpbm5lckZyb20oZGVsYXkoc29GYXIpKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG5vdGlmaWVyU3Vic2NyaWJlcl8xID0gY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vdGlmaWVyU3Vic2NyaWJlcl8xLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVUb1NvdXJjZSgpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgbm90aWZpZXIuc3Vic2NyaWJlKG5vdGlmaWVyU3Vic2NyaWJlcl8xKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZVRvU291cmNlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHZhciBzdWJzY3JpYmVUb1NvdXJjZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICB2YXIgc3luY1Vuc3ViID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgc291cmNlU3ViID0gc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgdW5kZWZpbmVkLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICgrK3NvRmFyIDwgY291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzb3VyY2VTdWIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3luY1Vuc3ViID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICBpZiAoc3luY1Vuc3ViKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHN1YnNjcmliZVRvU291cmNlKCk7XG4gICAgICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4uL1N1YmplY3QnO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gcmVwZWF0V2hlbihub3RpZmllcikge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGlubmVyU3ViO1xuICAgICAgICB2YXIgc3luY1Jlc3ViID0gZmFsc2U7XG4gICAgICAgIHZhciBjb21wbGV0aW9ucyQ7XG4gICAgICAgIHZhciBpc05vdGlmaWVyQ29tcGxldGUgPSBmYWxzZTtcbiAgICAgICAgdmFyIGlzTWFpbkNvbXBsZXRlID0gZmFsc2U7XG4gICAgICAgIHZhciBjaGVja0NvbXBsZXRlID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gaXNNYWluQ29tcGxldGUgJiYgaXNOb3RpZmllckNvbXBsZXRlICYmIChzdWJzY3JpYmVyLmNvbXBsZXRlKCksIHRydWUpOyB9O1xuICAgICAgICB2YXIgZ2V0Q29tcGxldGlvblN1YmplY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoIWNvbXBsZXRpb25zJCkge1xuICAgICAgICAgICAgICAgIGNvbXBsZXRpb25zJCA9IG5ldyBTdWJqZWN0KCk7XG4gICAgICAgICAgICAgICAgaW5uZXJGcm9tKG5vdGlmaWVyKGNvbXBsZXRpb25zJCkpLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaW5uZXJTdWIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZUZvclJlcGVhdFdoZW4oKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN5bmNSZXN1YiA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlzTm90aWZpZXJDb21wbGV0ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIGNoZWNrQ29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY29tcGxldGlvbnMkO1xuICAgICAgICB9O1xuICAgICAgICB2YXIgc3Vic2NyaWJlRm9yUmVwZWF0V2hlbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlzTWFpbkNvbXBsZXRlID0gZmFsc2U7XG4gICAgICAgICAgICBpbm5lclN1YiA9IHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIHVuZGVmaW5lZCwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGlzTWFpbkNvbXBsZXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAhY2hlY2tDb21wbGV0ZSgpICYmIGdldENvbXBsZXRpb25TdWJqZWN0KCkubmV4dCgpO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgaWYgKHN5bmNSZXN1Yikge1xuICAgICAgICAgICAgICAgIGlubmVyU3ViLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgaW5uZXJTdWIgPSBudWxsO1xuICAgICAgICAgICAgICAgIHN5bmNSZXN1YiA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZUZvclJlcGVhdFdoZW4oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgc3Vic2NyaWJlRm9yUmVwZWF0V2hlbigpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBpZGVudGl0eSB9IGZyb20gJy4uL3V0aWwvaWRlbnRpdHknO1xuaW1wb3J0IHsgdGltZXIgfSBmcm9tICcuLi9vYnNlcnZhYmxlL3RpbWVyJztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmV4cG9ydCBmdW5jdGlvbiByZXRyeShjb25maWdPckNvdW50KSB7XG4gICAgaWYgKGNvbmZpZ09yQ291bnQgPT09IHZvaWQgMCkgeyBjb25maWdPckNvdW50ID0gSW5maW5pdHk7IH1cbiAgICB2YXIgY29uZmlnO1xuICAgIGlmIChjb25maWdPckNvdW50ICYmIHR5cGVvZiBjb25maWdPckNvdW50ID09PSAnb2JqZWN0Jykge1xuICAgICAgICBjb25maWcgPSBjb25maWdPckNvdW50O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uZmlnID0ge1xuICAgICAgICAgICAgY291bnQ6IGNvbmZpZ09yQ291bnQsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHZhciBfYSA9IGNvbmZpZy5jb3VudCwgY291bnQgPSBfYSA9PT0gdm9pZCAwID8gSW5maW5pdHkgOiBfYSwgZGVsYXkgPSBjb25maWcuZGVsYXksIF9iID0gY29uZmlnLnJlc2V0T25TdWNjZXNzLCByZXNldE9uU3VjY2VzcyA9IF9iID09PSB2b2lkIDAgPyBmYWxzZSA6IF9iO1xuICAgIHJldHVybiBjb3VudCA8PSAwXG4gICAgICAgID8gaWRlbnRpdHlcbiAgICAgICAgOiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgICAgIHZhciBzb0ZhciA9IDA7XG4gICAgICAgICAgICB2YXIgaW5uZXJTdWI7XG4gICAgICAgICAgICB2YXIgc3Vic2NyaWJlRm9yUmV0cnkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIHN5bmNVbnN1YiA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGlubmVyU3ViID0gc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNldE9uU3VjY2Vzcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc29GYXIgPSAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfSwgdW5kZWZpbmVkLCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzb0ZhcisrIDwgY291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN1Yl8xID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbm5lclN1Yikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbm5lclN1Yi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbm5lclN1YiA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZUZvclJldHJ5KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzeW5jVW5zdWIgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGVsYXkgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBub3RpZmllciA9IHR5cGVvZiBkZWxheSA9PT0gJ251bWJlcicgPyB0aW1lcihkZWxheSkgOiBpbm5lckZyb20oZGVsYXkoZXJyLCBzb0ZhcikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBub3RpZmllclN1YnNjcmliZXJfMSA9IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5vdGlmaWVyU3Vic2NyaWJlcl8xLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3ViXzEoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBub3RpZmllci5zdWJzY3JpYmUobm90aWZpZXJTdWJzY3JpYmVyXzEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWJfMSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIGlmIChzeW5jVW5zdWIpIHtcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJTdWIudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJTdWIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICBzdWJzY3JpYmVGb3JSZXRyeSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzdWJzY3JpYmVGb3JSZXRyeSgpO1xuICAgICAgICB9KTtcbn1cbiIsImltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICcuLi9TdWJqZWN0JztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIHJldHJ5V2hlbihub3RpZmllcikge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGlubmVyU3ViO1xuICAgICAgICB2YXIgc3luY1Jlc3ViID0gZmFsc2U7XG4gICAgICAgIHZhciBlcnJvcnMkO1xuICAgICAgICB2YXIgc3Vic2NyaWJlRm9yUmV0cnlXaGVuID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaW5uZXJTdWIgPSBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCB1bmRlZmluZWQsIHVuZGVmaW5lZCwgZnVuY3Rpb24gKGVycikge1xuICAgICAgICAgICAgICAgIGlmICghZXJyb3JzJCkge1xuICAgICAgICAgICAgICAgICAgICBlcnJvcnMkID0gbmV3IFN1YmplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJGcm9tKG5vdGlmaWVyKGVycm9ycyQpKS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpbm5lclN1YiA/IHN1YnNjcmliZUZvclJldHJ5V2hlbigpIDogKHN5bmNSZXN1YiA9IHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChlcnJvcnMkKSB7XG4gICAgICAgICAgICAgICAgICAgIGVycm9ycyQubmV4dChlcnIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIGlmIChzeW5jUmVzdWIpIHtcbiAgICAgICAgICAgICAgICBpbm5lclN1Yi51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgIGlubmVyU3ViID0gbnVsbDtcbiAgICAgICAgICAgICAgICBzeW5jUmVzdWIgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVGb3JSZXRyeVdoZW4oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgc3Vic2NyaWJlRm9yUmV0cnlXaGVuKCk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuZXhwb3J0IGZ1bmN0aW9uIHNhbXBsZShub3RpZmllcikge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGhhc1ZhbHVlID0gZmFsc2U7XG4gICAgICAgIHZhciBsYXN0VmFsdWUgPSBudWxsO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIGhhc1ZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgIGxhc3RWYWx1ZSA9IHZhbHVlO1xuICAgICAgICB9KSk7XG4gICAgICAgIGlubmVyRnJvbShub3RpZmllcikuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoaGFzVmFsdWUpIHtcbiAgICAgICAgICAgICAgICBoYXNWYWx1ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IGxhc3RWYWx1ZTtcbiAgICAgICAgICAgICAgICBsYXN0VmFsdWUgPSBudWxsO1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIG5vb3ApKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IGFzeW5jU2NoZWR1bGVyIH0gZnJvbSAnLi4vc2NoZWR1bGVyL2FzeW5jJztcbmltcG9ydCB7IHNhbXBsZSB9IGZyb20gJy4vc2FtcGxlJztcbmltcG9ydCB7IGludGVydmFsIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbnRlcnZhbCc7XG5leHBvcnQgZnVuY3Rpb24gc2FtcGxlVGltZShwZXJpb2QsIHNjaGVkdWxlcikge1xuICAgIGlmIChzY2hlZHVsZXIgPT09IHZvaWQgMCkgeyBzY2hlZHVsZXIgPSBhc3luY1NjaGVkdWxlcjsgfVxuICAgIHJldHVybiBzYW1wbGUoaW50ZXJ2YWwocGVyaW9kLCBzY2hlZHVsZXIpKTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgc2NhbkludGVybmFscyB9IGZyb20gJy4vc2NhbkludGVybmFscyc7XG5leHBvcnQgZnVuY3Rpb24gc2NhbihhY2N1bXVsYXRvciwgc2VlZCkge1xuICAgIHJldHVybiBvcGVyYXRlKHNjYW5JbnRlcm5hbHMoYWNjdW11bGF0b3IsIHNlZWQsIGFyZ3VtZW50cy5sZW5ndGggPj0gMiwgdHJ1ZSkpO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5leHBvcnQgZnVuY3Rpb24gc2VxdWVuY2VFcXVhbChjb21wYXJlVG8sIGNvbXBhcmF0b3IpIHtcbiAgICBpZiAoY29tcGFyYXRvciA9PT0gdm9pZCAwKSB7IGNvbXBhcmF0b3IgPSBmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gYSA9PT0gYjsgfTsgfVxuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGFTdGF0ZSA9IGNyZWF0ZVN0YXRlKCk7XG4gICAgICAgIHZhciBiU3RhdGUgPSBjcmVhdGVTdGF0ZSgpO1xuICAgICAgICB2YXIgZW1pdCA9IGZ1bmN0aW9uIChpc0VxdWFsKSB7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoaXNFcXVhbCk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH07XG4gICAgICAgIHZhciBjcmVhdGVTdWJzY3JpYmVyID0gZnVuY3Rpb24gKHNlbGZTdGF0ZSwgb3RoZXJTdGF0ZSkge1xuICAgICAgICAgICAgdmFyIHNlcXVlbmNlRXF1YWxTdWJzY3JpYmVyID0gY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uIChhKSB7XG4gICAgICAgICAgICAgICAgdmFyIGJ1ZmZlciA9IG90aGVyU3RhdGUuYnVmZmVyLCBjb21wbGV0ZSA9IG90aGVyU3RhdGUuY29tcGxldGU7XG4gICAgICAgICAgICAgICAgaWYgKGJ1ZmZlci5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgY29tcGxldGUgPyBlbWl0KGZhbHNlKSA6IHNlbGZTdGF0ZS5idWZmZXIucHVzaChhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICFjb21wYXJhdG9yKGEsIGJ1ZmZlci5zaGlmdCgpKSAmJiBlbWl0KGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgc2VsZlN0YXRlLmNvbXBsZXRlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB2YXIgY29tcGxldGUgPSBvdGhlclN0YXRlLmNvbXBsZXRlLCBidWZmZXIgPSBvdGhlclN0YXRlLmJ1ZmZlcjtcbiAgICAgICAgICAgICAgICBjb21wbGV0ZSAmJiBlbWl0KGJ1ZmZlci5sZW5ndGggPT09IDApO1xuICAgICAgICAgICAgICAgIHNlcXVlbmNlRXF1YWxTdWJzY3JpYmVyID09PSBudWxsIHx8IHNlcXVlbmNlRXF1YWxTdWJzY3JpYmVyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzZXF1ZW5jZUVxdWFsU3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4gc2VxdWVuY2VFcXVhbFN1YnNjcmliZXI7XG4gICAgICAgIH07XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlU3Vic2NyaWJlcihhU3RhdGUsIGJTdGF0ZSkpO1xuICAgICAgICBpbm5lckZyb20oY29tcGFyZVRvKS5zdWJzY3JpYmUoY3JlYXRlU3Vic2NyaWJlcihiU3RhdGUsIGFTdGF0ZSkpO1xuICAgIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlU3RhdGUoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYnVmZmVyOiBbXSxcbiAgICAgICAgY29tcGxldGU6IGZhbHNlLFxuICAgIH07XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICcuLi9TdWJqZWN0JztcbmltcG9ydCB7IFNhZmVTdWJzY3JpYmVyIH0gZnJvbSAnLi4vU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmV4cG9ydCBmdW5jdGlvbiBzaGFyZShvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICB2YXIgX2EgPSBvcHRpb25zLmNvbm5lY3RvciwgY29ubmVjdG9yID0gX2EgPT09IHZvaWQgMCA/IGZ1bmN0aW9uICgpIHsgcmV0dXJuIG5ldyBTdWJqZWN0KCk7IH0gOiBfYSwgX2IgPSBvcHRpb25zLnJlc2V0T25FcnJvciwgcmVzZXRPbkVycm9yID0gX2IgPT09IHZvaWQgMCA/IHRydWUgOiBfYiwgX2MgPSBvcHRpb25zLnJlc2V0T25Db21wbGV0ZSwgcmVzZXRPbkNvbXBsZXRlID0gX2MgPT09IHZvaWQgMCA/IHRydWUgOiBfYywgX2QgPSBvcHRpb25zLnJlc2V0T25SZWZDb3VudFplcm8sIHJlc2V0T25SZWZDb3VudFplcm8gPSBfZCA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9kO1xuICAgIHJldHVybiBmdW5jdGlvbiAod3JhcHBlclNvdXJjZSkge1xuICAgICAgICB2YXIgY29ubmVjdGlvbjtcbiAgICAgICAgdmFyIHJlc2V0Q29ubmVjdGlvbjtcbiAgICAgICAgdmFyIHN1YmplY3Q7XG4gICAgICAgIHZhciByZWZDb3VudCA9IDA7XG4gICAgICAgIHZhciBoYXNDb21wbGV0ZWQgPSBmYWxzZTtcbiAgICAgICAgdmFyIGhhc0Vycm9yZWQgPSBmYWxzZTtcbiAgICAgICAgdmFyIGNhbmNlbFJlc2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmVzZXRDb25uZWN0aW9uID09PSBudWxsIHx8IHJlc2V0Q29ubmVjdGlvbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVzZXRDb25uZWN0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICByZXNldENvbm5lY3Rpb24gPSB1bmRlZmluZWQ7XG4gICAgICAgIH07XG4gICAgICAgIHZhciByZXNldCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNhbmNlbFJlc2V0KCk7XG4gICAgICAgICAgICBjb25uZWN0aW9uID0gc3ViamVjdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGhhc0NvbXBsZXRlZCA9IGhhc0Vycm9yZWQgPSBmYWxzZTtcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIHJlc2V0QW5kVW5zdWJzY3JpYmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgY29ubiA9IGNvbm5lY3Rpb247XG4gICAgICAgICAgICByZXNldCgpO1xuICAgICAgICAgICAgY29ubiA9PT0gbnVsbCB8fCBjb25uID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb25uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH07XG4gICAgICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgICAgIHJlZkNvdW50Kys7XG4gICAgICAgICAgICBpZiAoIWhhc0Vycm9yZWQgJiYgIWhhc0NvbXBsZXRlZCkge1xuICAgICAgICAgICAgICAgIGNhbmNlbFJlc2V0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgZGVzdCA9IChzdWJqZWN0ID0gc3ViamVjdCAhPT0gbnVsbCAmJiBzdWJqZWN0ICE9PSB2b2lkIDAgPyBzdWJqZWN0IDogY29ubmVjdG9yKCkpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5hZGQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJlZkNvdW50LS07XG4gICAgICAgICAgICAgICAgaWYgKHJlZkNvdW50ID09PSAwICYmICFoYXNFcnJvcmVkICYmICFoYXNDb21wbGV0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzZXRDb25uZWN0aW9uID0gaGFuZGxlUmVzZXQocmVzZXRBbmRVbnN1YnNjcmliZSwgcmVzZXRPblJlZkNvdW50WmVybyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBkZXN0LnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgICAgIGlmICghY29ubmVjdGlvbiAmJlxuICAgICAgICAgICAgICAgIHJlZkNvdW50ID4gMCkge1xuICAgICAgICAgICAgICAgIGNvbm5lY3Rpb24gPSBuZXcgU2FmZVN1YnNjcmliZXIoe1xuICAgICAgICAgICAgICAgICAgICBuZXh0OiBmdW5jdGlvbiAodmFsdWUpIHsgcmV0dXJuIGRlc3QubmV4dCh2YWx1ZSk7IH0sXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNFcnJvcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFJlc2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNldENvbm5lY3Rpb24gPSBoYW5kbGVSZXNldChyZXNldCwgcmVzZXRPbkVycm9yLCBlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVzdC5lcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZTogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaGFzQ29tcGxldGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFJlc2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNldENvbm5lY3Rpb24gPSBoYW5kbGVSZXNldChyZXNldCwgcmVzZXRPbkNvbXBsZXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc3QuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBpbm5lckZyb20oc291cmNlKS5zdWJzY3JpYmUoY29ubmVjdGlvbik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKHdyYXBwZXJTb3VyY2UpO1xuICAgIH07XG59XG5mdW5jdGlvbiBoYW5kbGVSZXNldChyZXNldCwgb24pIHtcbiAgICB2YXIgYXJncyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMjsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIGFyZ3NbX2kgLSAyXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIGlmIChvbiA9PT0gdHJ1ZSkge1xuICAgICAgICByZXNldCgpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChvbiA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgb25TdWJzY3JpYmVyID0gbmV3IFNhZmVTdWJzY3JpYmVyKHtcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgb25TdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICByZXNldCgpO1xuICAgICAgICB9LFxuICAgIH0pO1xuICAgIHJldHVybiBpbm5lckZyb20ob24uYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQoYXJncykpKSkuc3Vic2NyaWJlKG9uU3Vic2NyaWJlcik7XG59XG4iLCJpbXBvcnQgeyBSZXBsYXlTdWJqZWN0IH0gZnJvbSAnLi4vUmVwbGF5U3ViamVjdCc7XG5pbXBvcnQgeyBzaGFyZSB9IGZyb20gJy4vc2hhcmUnO1xuZXhwb3J0IGZ1bmN0aW9uIHNoYXJlUmVwbGF5KGNvbmZpZ09yQnVmZmVyU2l6ZSwgd2luZG93VGltZSwgc2NoZWR1bGVyKSB7XG4gICAgdmFyIF9hLCBfYiwgX2M7XG4gICAgdmFyIGJ1ZmZlclNpemU7XG4gICAgdmFyIHJlZkNvdW50ID0gZmFsc2U7XG4gICAgaWYgKGNvbmZpZ09yQnVmZmVyU2l6ZSAmJiB0eXBlb2YgY29uZmlnT3JCdWZmZXJTaXplID09PSAnb2JqZWN0Jykge1xuICAgICAgICAoX2EgPSBjb25maWdPckJ1ZmZlclNpemUuYnVmZmVyU2l6ZSwgYnVmZmVyU2l6ZSA9IF9hID09PSB2b2lkIDAgPyBJbmZpbml0eSA6IF9hLCBfYiA9IGNvbmZpZ09yQnVmZmVyU2l6ZS53aW5kb3dUaW1lLCB3aW5kb3dUaW1lID0gX2IgPT09IHZvaWQgMCA/IEluZmluaXR5IDogX2IsIF9jID0gY29uZmlnT3JCdWZmZXJTaXplLnJlZkNvdW50LCByZWZDb3VudCA9IF9jID09PSB2b2lkIDAgPyBmYWxzZSA6IF9jLCBzY2hlZHVsZXIgPSBjb25maWdPckJ1ZmZlclNpemUuc2NoZWR1bGVyKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGJ1ZmZlclNpemUgPSAoY29uZmlnT3JCdWZmZXJTaXplICE9PSBudWxsICYmIGNvbmZpZ09yQnVmZmVyU2l6ZSAhPT0gdm9pZCAwID8gY29uZmlnT3JCdWZmZXJTaXplIDogSW5maW5pdHkpO1xuICAgIH1cbiAgICByZXR1cm4gc2hhcmUoe1xuICAgICAgICBjb25uZWN0b3I6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIG5ldyBSZXBsYXlTdWJqZWN0KGJ1ZmZlclNpemUsIHdpbmRvd1RpbWUsIHNjaGVkdWxlcik7IH0sXG4gICAgICAgIHJlc2V0T25FcnJvcjogdHJ1ZSxcbiAgICAgICAgcmVzZXRPbkNvbXBsZXRlOiBmYWxzZSxcbiAgICAgICAgcmVzZXRPblJlZkNvdW50WmVybzogcmVmQ291bnQsXG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBFbXB0eUVycm9yIH0gZnJvbSAnLi4vdXRpbC9FbXB0eUVycm9yJztcbmltcG9ydCB7IFNlcXVlbmNlRXJyb3IgfSBmcm9tICcuLi91dGlsL1NlcXVlbmNlRXJyb3InO1xuaW1wb3J0IHsgTm90Rm91bmRFcnJvciB9IGZyb20gJy4uL3V0aWwvTm90Rm91bmRFcnJvcic7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBzaW5nbGUocHJlZGljYXRlKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgaGFzVmFsdWUgPSBmYWxzZTtcbiAgICAgICAgdmFyIHNpbmdsZVZhbHVlO1xuICAgICAgICB2YXIgc2VlblZhbHVlID0gZmFsc2U7XG4gICAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgc2VlblZhbHVlID0gdHJ1ZTtcbiAgICAgICAgICAgIGlmICghcHJlZGljYXRlIHx8IHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKywgc291cmNlKSkge1xuICAgICAgICAgICAgICAgIGhhc1ZhbHVlICYmIHN1YnNjcmliZXIuZXJyb3IobmV3IFNlcXVlbmNlRXJyb3IoJ1RvbyBtYW55IG1hdGNoaW5nIHZhbHVlcycpKTtcbiAgICAgICAgICAgICAgICBoYXNWYWx1ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgc2luZ2xlVmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKGhhc1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHNpbmdsZVZhbHVlKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmVycm9yKHNlZW5WYWx1ZSA/IG5ldyBOb3RGb3VuZEVycm9yKCdObyBtYXRjaGluZyB2YWx1ZXMnKSA6IG5ldyBFbXB0eUVycm9yKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBmaWx0ZXIgfSBmcm9tICcuL2ZpbHRlcic7XG5leHBvcnQgZnVuY3Rpb24gc2tpcChjb3VudCkge1xuICAgIHJldHVybiBmaWx0ZXIoZnVuY3Rpb24gKF8sIGluZGV4KSB7IHJldHVybiBjb3VudCA8PSBpbmRleDsgfSk7XG59XG4iLCJpbXBvcnQgeyBpZGVudGl0eSB9IGZyb20gJy4uL3V0aWwvaWRlbnRpdHknO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gc2tpcExhc3Qoc2tpcENvdW50KSB7XG4gICAgcmV0dXJuIHNraXBDb3VudCA8PSAwXG4gICAgICAgID9cbiAgICAgICAgICAgIGlkZW50aXR5XG4gICAgICAgIDogb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICB2YXIgcmluZyA9IG5ldyBBcnJheShza2lwQ291bnQpO1xuICAgICAgICAgICAgdmFyIHNlZW4gPSAwO1xuICAgICAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdmFyIHZhbHVlSW5kZXggPSBzZWVuKys7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlSW5kZXggPCBza2lwQ291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmluZ1t2YWx1ZUluZGV4XSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGluZGV4ID0gdmFsdWVJbmRleCAlIHNraXBDb3VudDtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG9sZFZhbHVlID0gcmluZ1tpbmRleF07XG4gICAgICAgICAgICAgICAgICAgIHJpbmdbaW5kZXhdID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dChvbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByaW5nID0gbnVsbDtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBub29wIH0gZnJvbSAnLi4vdXRpbC9ub29wJztcbmV4cG9ydCBmdW5jdGlvbiBza2lwVW50aWwobm90aWZpZXIpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciB0YWtpbmcgPSBmYWxzZTtcbiAgICAgICAgdmFyIHNraXBTdWJzY3JpYmVyID0gY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHNraXBTdWJzY3JpYmVyID09PSBudWxsIHx8IHNraXBTdWJzY3JpYmVyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBza2lwU3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgdGFraW5nID0gdHJ1ZTtcbiAgICAgICAgfSwgbm9vcCk7XG4gICAgICAgIGlubmVyRnJvbShub3RpZmllcikuc3Vic2NyaWJlKHNraXBTdWJzY3JpYmVyKTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiB0YWtpbmcgJiYgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTsgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gc2tpcFdoaWxlKHByZWRpY2F0ZSkge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIHRha2luZyA9IGZhbHNlO1xuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHsgcmV0dXJuICh0YWtpbmcgfHwgKHRha2luZyA9ICFwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspKSkgJiYgc3Vic2NyaWJlci5uZXh0KHZhbHVlKTsgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgY29uY2F0IH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9jb25jYXQnO1xuaW1wb3J0IHsgcG9wU2NoZWR1bGVyIH0gZnJvbSAnLi4vdXRpbC9hcmdzJztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuZXhwb3J0IGZ1bmN0aW9uIHN0YXJ0V2l0aCgpIHtcbiAgICB2YXIgdmFsdWVzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgdmFsdWVzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHZhciBzY2hlZHVsZXIgPSBwb3BTY2hlZHVsZXIodmFsdWVzKTtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIChzY2hlZHVsZXIgPyBjb25jYXQodmFsdWVzLCBzb3VyY2UsIHNjaGVkdWxlcikgOiBjb25jYXQodmFsdWVzLCBzb3VyY2UpKS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBpbm5lckZyb20gfSBmcm9tICcuLi9vYnNlcnZhYmxlL2lubmVyRnJvbSc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiBzd2l0Y2hNYXAocHJvamVjdCwgcmVzdWx0U2VsZWN0b3IpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciBpbm5lclN1YnNjcmliZXIgPSBudWxsO1xuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICB2YXIgaXNDb21wbGV0ZSA9IGZhbHNlO1xuICAgICAgICB2YXIgY2hlY2tDb21wbGV0ZSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIGlzQ29tcGxldGUgJiYgIWlubmVyU3Vic2NyaWJlciAmJiBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7IH07XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgaW5uZXJTdWJzY3JpYmVyID09PSBudWxsIHx8IGlubmVyU3Vic2NyaWJlciA9PT0gdm9pZCAwID8gdm9pZCAwIDogaW5uZXJTdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB2YXIgaW5uZXJJbmRleCA9IDA7XG4gICAgICAgICAgICB2YXIgb3V0ZXJJbmRleCA9IGluZGV4Kys7XG4gICAgICAgICAgICBpbm5lckZyb20ocHJvamVjdCh2YWx1ZSwgb3V0ZXJJbmRleCkpLnN1YnNjcmliZSgoaW5uZXJTdWJzY3JpYmVyID0gY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uIChpbm5lclZhbHVlKSB7IHJldHVybiBzdWJzY3JpYmVyLm5leHQocmVzdWx0U2VsZWN0b3IgPyByZXN1bHRTZWxlY3Rvcih2YWx1ZSwgaW5uZXJWYWx1ZSwgb3V0ZXJJbmRleCwgaW5uZXJJbmRleCsrKSA6IGlubmVyVmFsdWUpOyB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgaW5uZXJTdWJzY3JpYmVyID0gbnVsbDtcbiAgICAgICAgICAgICAgICBjaGVja0NvbXBsZXRlKCk7XG4gICAgICAgICAgICB9KSkpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpc0NvbXBsZXRlID0gdHJ1ZTtcbiAgICAgICAgICAgIGNoZWNrQ29tcGxldGUoKTtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgc3dpdGNoTWFwIH0gZnJvbSAnLi9zd2l0Y2hNYXAnO1xuaW1wb3J0IHsgaWRlbnRpdHkgfSBmcm9tICcuLi91dGlsL2lkZW50aXR5JztcbmV4cG9ydCBmdW5jdGlvbiBzd2l0Y2hBbGwoKSB7XG4gICAgcmV0dXJuIHN3aXRjaE1hcChpZGVudGl0eSk7XG59XG4iLCJpbXBvcnQgeyBzd2l0Y2hNYXAgfSBmcm9tICcuL3N3aXRjaE1hcCc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi4vdXRpbC9pc0Z1bmN0aW9uJztcbmV4cG9ydCBmdW5jdGlvbiBzd2l0Y2hNYXBUbyhpbm5lck9ic2VydmFibGUsIHJlc3VsdFNlbGVjdG9yKSB7XG4gICAgcmV0dXJuIGlzRnVuY3Rpb24ocmVzdWx0U2VsZWN0b3IpID8gc3dpdGNoTWFwKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGlubmVyT2JzZXJ2YWJsZTsgfSwgcmVzdWx0U2VsZWN0b3IpIDogc3dpdGNoTWFwKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGlubmVyT2JzZXJ2YWJsZTsgfSk7XG59XG4iLCJpbXBvcnQgeyBzd2l0Y2hNYXAgfSBmcm9tICcuL3N3aXRjaE1hcCc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmV4cG9ydCBmdW5jdGlvbiBzd2l0Y2hTY2FuKGFjY3VtdWxhdG9yLCBzZWVkKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgc3RhdGUgPSBzZWVkO1xuICAgICAgICBzd2l0Y2hNYXAoZnVuY3Rpb24gKHZhbHVlLCBpbmRleCkgeyByZXR1cm4gYWNjdW11bGF0b3Ioc3RhdGUsIHZhbHVlLCBpbmRleCk7IH0sIGZ1bmN0aW9uIChfLCBpbm5lclZhbHVlKSB7IHJldHVybiAoKHN0YXRlID0gaW5uZXJWYWx1ZSksIGlubmVyVmFsdWUpOyB9KShzb3VyY2UpLnN1YnNjcmliZShzdWJzY3JpYmVyKTtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN0YXRlID0gbnVsbDtcbiAgICAgICAgfTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gJy4uL3V0aWwvbm9vcCc7XG5leHBvcnQgZnVuY3Rpb24gdGFrZVVudGlsKG5vdGlmaWVyKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICBpbm5lckZyb20obm90aWZpZXIpLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKCkgeyByZXR1cm4gc3Vic2NyaWJlci5jb21wbGV0ZSgpOyB9LCBub29wKSk7XG4gICAgICAgICFzdWJzY3JpYmVyLmNsb3NlZCAmJiBzb3VyY2Uuc3Vic2NyaWJlKHN1YnNjcmliZXIpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gdGFrZVdoaWxlKHByZWRpY2F0ZSwgaW5jbHVzaXZlKSB7XG4gICAgaWYgKGluY2x1c2l2ZSA9PT0gdm9pZCAwKSB7IGluY2x1c2l2ZSA9IGZhbHNlOyB9XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgICBzb3VyY2Uuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgICAgICAgIHZhciByZXN1bHQgPSBwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspO1xuICAgICAgICAgICAgKHJlc3VsdCB8fCBpbmNsdXNpdmUpICYmIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAhcmVzdWx0ICYmIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJy4uL3V0aWwvaXNGdW5jdGlvbic7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmltcG9ydCB7IGlkZW50aXR5IH0gZnJvbSAnLi4vdXRpbC9pZGVudGl0eSc7XG5leHBvcnQgZnVuY3Rpb24gdGFwKG9ic2VydmVyT3JOZXh0LCBlcnJvciwgY29tcGxldGUpIHtcbiAgICB2YXIgdGFwT2JzZXJ2ZXIgPSBpc0Z1bmN0aW9uKG9ic2VydmVyT3JOZXh0KSB8fCBlcnJvciB8fCBjb21wbGV0ZVxuICAgICAgICA/XG4gICAgICAgICAgICB7IG5leHQ6IG9ic2VydmVyT3JOZXh0LCBlcnJvcjogZXJyb3IsIGNvbXBsZXRlOiBjb21wbGV0ZSB9XG4gICAgICAgIDogb2JzZXJ2ZXJPck5leHQ7XG4gICAgcmV0dXJuIHRhcE9ic2VydmVyXG4gICAgICAgID8gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAoX2EgPSB0YXBPYnNlcnZlci5zdWJzY3JpYmUpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5jYWxsKHRhcE9ic2VydmVyKTtcbiAgICAgICAgICAgIHZhciBpc1Vuc3ViID0gdHJ1ZTtcbiAgICAgICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBfYTtcbiAgICAgICAgICAgICAgICAoX2EgPSB0YXBPYnNlcnZlci5uZXh0KSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuY2FsbCh0YXBPYnNlcnZlciwgdmFsdWUpO1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIF9hO1xuICAgICAgICAgICAgICAgIGlzVW5zdWIgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAoX2EgPSB0YXBPYnNlcnZlci5jb21wbGV0ZSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmNhbGwodGFwT2JzZXJ2ZXIpO1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgICAgIH0sIGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgICAgICB2YXIgX2E7XG4gICAgICAgICAgICAgICAgaXNVbnN1YiA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIChfYSA9IHRhcE9ic2VydmVyLmVycm9yKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2EuY2FsbCh0YXBPYnNlcnZlciwgZXJyKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmVycm9yKGVycik7XG4gICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIF9hLCBfYjtcbiAgICAgICAgICAgICAgICBpZiAoaXNVbnN1Yikge1xuICAgICAgICAgICAgICAgICAgICAoX2EgPSB0YXBPYnNlcnZlci51bnN1YnNjcmliZSkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmNhbGwodGFwT2JzZXJ2ZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAoX2IgPSB0YXBPYnNlcnZlci5maW5hbGl6ZSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLmNhbGwodGFwT2JzZXJ2ZXIpO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9KVxuICAgICAgICA6XG4gICAgICAgICAgICBpZGVudGl0eTtcbn1cbiIsImltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIHRocm90dGxlKGR1cmF0aW9uU2VsZWN0b3IsIGNvbmZpZykge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIF9hID0gY29uZmlnICE9PSBudWxsICYmIGNvbmZpZyAhPT0gdm9pZCAwID8gY29uZmlnIDoge30sIF9iID0gX2EubGVhZGluZywgbGVhZGluZyA9IF9iID09PSB2b2lkIDAgPyB0cnVlIDogX2IsIF9jID0gX2EudHJhaWxpbmcsIHRyYWlsaW5nID0gX2MgPT09IHZvaWQgMCA/IGZhbHNlIDogX2M7XG4gICAgICAgIHZhciBoYXNWYWx1ZSA9IGZhbHNlO1xuICAgICAgICB2YXIgc2VuZFZhbHVlID0gbnVsbDtcbiAgICAgICAgdmFyIHRocm90dGxlZCA9IG51bGw7XG4gICAgICAgIHZhciBpc0NvbXBsZXRlID0gZmFsc2U7XG4gICAgICAgIHZhciBlbmRUaHJvdHRsaW5nID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgdGhyb3R0bGVkID09PSBudWxsIHx8IHRocm90dGxlZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogdGhyb3R0bGVkLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB0aHJvdHRsZWQgPSBudWxsO1xuICAgICAgICAgICAgaWYgKHRyYWlsaW5nKSB7XG4gICAgICAgICAgICAgICAgc2VuZCgpO1xuICAgICAgICAgICAgICAgIGlzQ29tcGxldGUgJiYgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB2YXIgY2xlYW51cFRocm90dGxpbmcgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB0aHJvdHRsZWQgPSBudWxsO1xuICAgICAgICAgICAgaXNDb21wbGV0ZSAmJiBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH07XG4gICAgICAgIHZhciBzdGFydFRocm90dGxlID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICByZXR1cm4gKHRocm90dGxlZCA9IGlubmVyRnJvbShkdXJhdGlvblNlbGVjdG9yKHZhbHVlKSkuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBlbmRUaHJvdHRsaW5nLCBjbGVhbnVwVGhyb3R0bGluZykpKTtcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIHNlbmQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAoaGFzVmFsdWUpIHtcbiAgICAgICAgICAgICAgICBoYXNWYWx1ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHZhciB2YWx1ZSA9IHNlbmRWYWx1ZTtcbiAgICAgICAgICAgICAgICBzZW5kVmFsdWUgPSBudWxsO1xuICAgICAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgIWlzQ29tcGxldGUgJiYgc3RhcnRUaHJvdHRsZSh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgaGFzVmFsdWUgPSB0cnVlO1xuICAgICAgICAgICAgc2VuZFZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgICAhKHRocm90dGxlZCAmJiAhdGhyb3R0bGVkLmNsb3NlZCkgJiYgKGxlYWRpbmcgPyBzZW5kKCkgOiBzdGFydFRocm90dGxlKHZhbHVlKSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGlzQ29tcGxldGUgPSB0cnVlO1xuICAgICAgICAgICAgISh0cmFpbGluZyAmJiBoYXNWYWx1ZSAmJiB0aHJvdHRsZWQgJiYgIXRocm90dGxlZC5jbG9zZWQpICYmIHN1YnNjcmliZXIuY29tcGxldGUoKTtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgYXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvYXN5bmMnO1xuaW1wb3J0IHsgdGhyb3R0bGUgfSBmcm9tICcuL3Rocm90dGxlJztcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS90aW1lcic7XG5leHBvcnQgZnVuY3Rpb24gdGhyb3R0bGVUaW1lKGR1cmF0aW9uLCBzY2hlZHVsZXIsIGNvbmZpZykge1xuICAgIGlmIChzY2hlZHVsZXIgPT09IHZvaWQgMCkgeyBzY2hlZHVsZXIgPSBhc3luY1NjaGVkdWxlcjsgfVxuICAgIHZhciBkdXJhdGlvbiQgPSB0aW1lcihkdXJhdGlvbiwgc2NoZWR1bGVyKTtcbiAgICByZXR1cm4gdGhyb3R0bGUoZnVuY3Rpb24gKCkgeyByZXR1cm4gZHVyYXRpb24kOyB9LCBjb25maWcpO1xufVxuIiwiaW1wb3J0IHsgYXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvYXN5bmMnO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5leHBvcnQgZnVuY3Rpb24gdGltZUludGVydmFsKHNjaGVkdWxlcikge1xuICAgIGlmIChzY2hlZHVsZXIgPT09IHZvaWQgMCkgeyBzY2hlZHVsZXIgPSBhc3luY1NjaGVkdWxlcjsgfVxuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGxhc3QgPSBzY2hlZHVsZXIubm93KCk7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgdmFyIG5vdyA9IHNjaGVkdWxlci5ub3coKTtcbiAgICAgICAgICAgIHZhciBpbnRlcnZhbCA9IG5vdyAtIGxhc3Q7XG4gICAgICAgICAgICBsYXN0ID0gbm93O1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KG5ldyBUaW1lSW50ZXJ2YWwodmFsdWUsIGludGVydmFsKSk7XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbnZhciBUaW1lSW50ZXJ2YWwgPSAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFRpbWVJbnRlcnZhbCh2YWx1ZSwgaW50ZXJ2YWwpIHtcbiAgICAgICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICAgICAgICB0aGlzLmludGVydmFsID0gaW50ZXJ2YWw7XG4gICAgfVxuICAgIHJldHVybiBUaW1lSW50ZXJ2YWw7XG59KCkpO1xuZXhwb3J0IHsgVGltZUludGVydmFsIH07XG4iLCJpbXBvcnQgeyBhc3luYyB9IGZyb20gJy4uL3NjaGVkdWxlci9hc3luYyc7XG5pbXBvcnQgeyBpc1ZhbGlkRGF0ZSB9IGZyb20gJy4uL3V0aWwvaXNEYXRlJztcbmltcG9ydCB7IHRpbWVvdXQgfSBmcm9tICcuL3RpbWVvdXQnO1xuZXhwb3J0IGZ1bmN0aW9uIHRpbWVvdXRXaXRoKGR1ZSwgd2l0aE9ic2VydmFibGUsIHNjaGVkdWxlcikge1xuICAgIHZhciBmaXJzdDtcbiAgICB2YXIgZWFjaDtcbiAgICB2YXIgX3dpdGg7XG4gICAgc2NoZWR1bGVyID0gc2NoZWR1bGVyICE9PSBudWxsICYmIHNjaGVkdWxlciAhPT0gdm9pZCAwID8gc2NoZWR1bGVyIDogYXN5bmM7XG4gICAgaWYgKGlzVmFsaWREYXRlKGR1ZSkpIHtcbiAgICAgICAgZmlyc3QgPSBkdWU7XG4gICAgfVxuICAgIGVsc2UgaWYgKHR5cGVvZiBkdWUgPT09ICdudW1iZXInKSB7XG4gICAgICAgIGVhY2ggPSBkdWU7XG4gICAgfVxuICAgIGlmICh3aXRoT2JzZXJ2YWJsZSkge1xuICAgICAgICBfd2l0aCA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHdpdGhPYnNlcnZhYmxlOyB9O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTm8gb2JzZXJ2YWJsZSBwcm92aWRlZCB0byBzd2l0Y2ggdG8nKTtcbiAgICB9XG4gICAgaWYgKGZpcnN0ID09IG51bGwgJiYgZWFjaCA9PSBudWxsKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ05vIHRpbWVvdXQgcHJvdmlkZWQuJyk7XG4gICAgfVxuICAgIHJldHVybiB0aW1lb3V0KHtcbiAgICAgICAgZmlyc3Q6IGZpcnN0LFxuICAgICAgICBlYWNoOiBlYWNoLFxuICAgICAgICBzY2hlZHVsZXI6IHNjaGVkdWxlcixcbiAgICAgICAgd2l0aDogX3dpdGgsXG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBkYXRlVGltZXN0YW1wUHJvdmlkZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvZGF0ZVRpbWVzdGFtcFByb3ZpZGVyJztcbmltcG9ydCB7IG1hcCB9IGZyb20gJy4vbWFwJztcbmV4cG9ydCBmdW5jdGlvbiB0aW1lc3RhbXAodGltZXN0YW1wUHJvdmlkZXIpIHtcbiAgICBpZiAodGltZXN0YW1wUHJvdmlkZXIgPT09IHZvaWQgMCkgeyB0aW1lc3RhbXBQcm92aWRlciA9IGRhdGVUaW1lc3RhbXBQcm92aWRlcjsgfVxuICAgIHJldHVybiBtYXAoZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiAoeyB2YWx1ZTogdmFsdWUsIHRpbWVzdGFtcDogdGltZXN0YW1wUHJvdmlkZXIubm93KCkgfSk7IH0pO1xufVxuIiwiaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4uL1N1YmplY3QnO1xuaW1wb3J0IHsgb3BlcmF0ZSB9IGZyb20gJy4uL3V0aWwvbGlmdCc7XG5pbXBvcnQgeyBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIgfSBmcm9tICcuL09wZXJhdG9yU3Vic2NyaWJlcic7XG5pbXBvcnQgeyBub29wIH0gZnJvbSAnLi4vdXRpbC9ub29wJztcbmltcG9ydCB7IGlubmVyRnJvbSB9IGZyb20gJy4uL29ic2VydmFibGUvaW5uZXJGcm9tJztcbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3cod2luZG93Qm91bmRhcmllcykge1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIHdpbmRvd1N1YmplY3QgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICBzdWJzY3JpYmVyLm5leHQod2luZG93U3ViamVjdC5hc09ic2VydmFibGUoKSk7XG4gICAgICAgIHZhciBlcnJvckhhbmRsZXIgPSBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICB3aW5kb3dTdWJqZWN0LmVycm9yKGVycik7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmVycm9yKGVycik7XG4gICAgICAgIH07XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkgeyByZXR1cm4gd2luZG93U3ViamVjdCA9PT0gbnVsbCB8fCB3aW5kb3dTdWJqZWN0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiB3aW5kb3dTdWJqZWN0Lm5leHQodmFsdWUpOyB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB3aW5kb3dTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0sIGVycm9ySGFuZGxlcikpO1xuICAgICAgICBpbm5lckZyb20od2luZG93Qm91bmRhcmllcykuc3Vic2NyaWJlKGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlcihzdWJzY3JpYmVyLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB3aW5kb3dTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgICAgICAgICBzdWJzY3JpYmVyLm5leHQoKHdpbmRvd1N1YmplY3QgPSBuZXcgU3ViamVjdCgpKSk7XG4gICAgICAgIH0sIG5vb3AsIGVycm9ySGFuZGxlcikpO1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgd2luZG93U3ViamVjdCA9PT0gbnVsbCB8fCB3aW5kb3dTdWJqZWN0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiB3aW5kb3dTdWJqZWN0LnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB3aW5kb3dTdWJqZWN0ID0gbnVsbDtcbiAgICAgICAgfTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IF9fdmFsdWVzIH0gZnJvbSBcInRzbGliXCI7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSAnLi4vU3ViamVjdCc7XG5pbXBvcnQgeyBvcGVyYXRlIH0gZnJvbSAnLi4vdXRpbC9saWZ0JztcbmltcG9ydCB7IGNyZWF0ZU9wZXJhdG9yU3Vic2NyaWJlciB9IGZyb20gJy4vT3BlcmF0b3JTdWJzY3JpYmVyJztcbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dDb3VudCh3aW5kb3dTaXplLCBzdGFydFdpbmRvd0V2ZXJ5KSB7XG4gICAgaWYgKHN0YXJ0V2luZG93RXZlcnkgPT09IHZvaWQgMCkgeyBzdGFydFdpbmRvd0V2ZXJ5ID0gMDsgfVxuICAgIHZhciBzdGFydEV2ZXJ5ID0gc3RhcnRXaW5kb3dFdmVyeSA+IDAgPyBzdGFydFdpbmRvd0V2ZXJ5IDogd2luZG93U2l6ZTtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciB3aW5kb3dzID0gW25ldyBTdWJqZWN0KCldO1xuICAgICAgICB2YXIgc3RhcnRzID0gW107XG4gICAgICAgIHZhciBjb3VudCA9IDA7XG4gICAgICAgIHN1YnNjcmliZXIubmV4dCh3aW5kb3dzWzBdLmFzT2JzZXJ2YWJsZSgpKTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICB2YXIgZV8xLCBfYTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgd2luZG93c18xID0gX192YWx1ZXMod2luZG93cyksIHdpbmRvd3NfMV8xID0gd2luZG93c18xLm5leHQoKTsgIXdpbmRvd3NfMV8xLmRvbmU7IHdpbmRvd3NfMV8xID0gd2luZG93c18xLm5leHQoKSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgd2luZG93XzEgPSB3aW5kb3dzXzFfMS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93XzEubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh3aW5kb3dzXzFfMSAmJiAhd2luZG93c18xXzEuZG9uZSAmJiAoX2EgPSB3aW5kb3dzXzEucmV0dXJuKSkgX2EuY2FsbCh3aW5kb3dzXzEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmaW5hbGx5IHsgaWYgKGVfMSkgdGhyb3cgZV8xLmVycm9yOyB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgYyA9IGNvdW50IC0gd2luZG93U2l6ZSArIDE7XG4gICAgICAgICAgICBpZiAoYyA+PSAwICYmIGMgJSBzdGFydEV2ZXJ5ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgd2luZG93cy5zaGlmdCgpLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoKytjb3VudCAlIHN0YXJ0RXZlcnkgPT09IDApIHtcbiAgICAgICAgICAgICAgICB2YXIgd2luZG93XzIgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICAgICAgICAgIHdpbmRvd3MucHVzaCh3aW5kb3dfMik7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHdpbmRvd18yLmFzT2JzZXJ2YWJsZSgpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgd2hpbGUgKHdpbmRvd3MubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICAgIHdpbmRvd3Muc2hpZnQoKS5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9LCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAgICAgICB3aGlsZSAod2luZG93cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgd2luZG93cy5zaGlmdCgpLmVycm9yKGVycik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmVycm9yKGVycik7XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHN0YXJ0cyA9IG51bGw7XG4gICAgICAgICAgICB3aW5kb3dzID0gbnVsbDtcbiAgICAgICAgfSkpO1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4uL1N1YmplY3QnO1xuaW1wb3J0IHsgYXN5bmNTY2hlZHVsZXIgfSBmcm9tICcuLi9zY2hlZHVsZXIvYXN5bmMnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAnLi4vU3Vic2NyaXB0aW9uJztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgYXJyUmVtb3ZlIH0gZnJvbSAnLi4vdXRpbC9hcnJSZW1vdmUnO1xuaW1wb3J0IHsgcG9wU2NoZWR1bGVyIH0gZnJvbSAnLi4vdXRpbC9hcmdzJztcbmltcG9ydCB7IGV4ZWN1dGVTY2hlZHVsZSB9IGZyb20gJy4uL3V0aWwvZXhlY3V0ZVNjaGVkdWxlJztcbmV4cG9ydCBmdW5jdGlvbiB3aW5kb3dUaW1lKHdpbmRvd1RpbWVTcGFuKSB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICB2YXIgb3RoZXJBcmdzID0gW107XG4gICAgZm9yICh2YXIgX2kgPSAxOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgb3RoZXJBcmdzW19pIC0gMV0gPSBhcmd1bWVudHNbX2ldO1xuICAgIH1cbiAgICB2YXIgc2NoZWR1bGVyID0gKF9hID0gcG9wU2NoZWR1bGVyKG90aGVyQXJncykpICE9PSBudWxsICYmIF9hICE9PSB2b2lkIDAgPyBfYSA6IGFzeW5jU2NoZWR1bGVyO1xuICAgIHZhciB3aW5kb3dDcmVhdGlvbkludGVydmFsID0gKF9iID0gb3RoZXJBcmdzWzBdKSAhPT0gbnVsbCAmJiBfYiAhPT0gdm9pZCAwID8gX2IgOiBudWxsO1xuICAgIHZhciBtYXhXaW5kb3dTaXplID0gb3RoZXJBcmdzWzFdIHx8IEluZmluaXR5O1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIHdpbmRvd1JlY29yZHMgPSBbXTtcbiAgICAgICAgdmFyIHJlc3RhcnRPbkNsb3NlID0gZmFsc2U7XG4gICAgICAgIHZhciBjbG9zZVdpbmRvdyA9IGZ1bmN0aW9uIChyZWNvcmQpIHtcbiAgICAgICAgICAgIHZhciB3aW5kb3cgPSByZWNvcmQud2luZG93LCBzdWJzID0gcmVjb3JkLnN1YnM7XG4gICAgICAgICAgICB3aW5kb3cuY29tcGxldGUoKTtcbiAgICAgICAgICAgIHN1YnMudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIGFyclJlbW92ZSh3aW5kb3dSZWNvcmRzLCByZWNvcmQpO1xuICAgICAgICAgICAgcmVzdGFydE9uQ2xvc2UgJiYgc3RhcnRXaW5kb3coKTtcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIHN0YXJ0V2luZG93ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgaWYgKHdpbmRvd1JlY29yZHMpIHtcbiAgICAgICAgICAgICAgICB2YXIgc3VicyA9IG5ldyBTdWJzY3JpcHRpb24oKTtcbiAgICAgICAgICAgICAgICBzdWJzY3JpYmVyLmFkZChzdWJzKTtcbiAgICAgICAgICAgICAgICB2YXIgd2luZG93XzEgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICAgICAgICAgIHZhciByZWNvcmRfMSA9IHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93OiB3aW5kb3dfMSxcbiAgICAgICAgICAgICAgICAgICAgc3Viczogc3VicyxcbiAgICAgICAgICAgICAgICAgICAgc2VlbjogMCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHdpbmRvd1JlY29yZHMucHVzaChyZWNvcmRfMSk7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHdpbmRvd18xLmFzT2JzZXJ2YWJsZSgpKTtcbiAgICAgICAgICAgICAgICBleGVjdXRlU2NoZWR1bGUoc3Vicywgc2NoZWR1bGVyLCBmdW5jdGlvbiAoKSB7IHJldHVybiBjbG9zZVdpbmRvdyhyZWNvcmRfMSk7IH0sIHdpbmRvd1RpbWVTcGFuKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgaWYgKHdpbmRvd0NyZWF0aW9uSW50ZXJ2YWwgIT09IG51bGwgJiYgd2luZG93Q3JlYXRpb25JbnRlcnZhbCA+PSAwKSB7XG4gICAgICAgICAgICBleGVjdXRlU2NoZWR1bGUoc3Vic2NyaWJlciwgc2NoZWR1bGVyLCBzdGFydFdpbmRvdywgd2luZG93Q3JlYXRpb25JbnRlcnZhbCwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXN0YXJ0T25DbG9zZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgc3RhcnRXaW5kb3coKTtcbiAgICAgICAgdmFyIGxvb3AgPSBmdW5jdGlvbiAoY2IpIHsgcmV0dXJuIHdpbmRvd1JlY29yZHMuc2xpY2UoKS5mb3JFYWNoKGNiKTsgfTtcbiAgICAgICAgdmFyIHRlcm1pbmF0ZSA9IGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgbG9vcChmdW5jdGlvbiAoX2EpIHtcbiAgICAgICAgICAgICAgICB2YXIgd2luZG93ID0gX2Eud2luZG93O1xuICAgICAgICAgICAgICAgIHJldHVybiBjYih3aW5kb3cpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjYihzdWJzY3JpYmVyKTtcbiAgICAgICAgICAgIHN1YnNjcmliZXIudW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICBsb29wKGZ1bmN0aW9uIChyZWNvcmQpIHtcbiAgICAgICAgICAgICAgICByZWNvcmQud2luZG93Lm5leHQodmFsdWUpO1xuICAgICAgICAgICAgICAgIG1heFdpbmRvd1NpemUgPD0gKytyZWNvcmQuc2VlbiAmJiBjbG9zZVdpbmRvdyhyZWNvcmQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRlcm1pbmF0ZShmdW5jdGlvbiAoY29uc3VtZXIpIHsgcmV0dXJuIGNvbnN1bWVyLmNvbXBsZXRlKCk7IH0pOyB9LCBmdW5jdGlvbiAoZXJyKSB7IHJldHVybiB0ZXJtaW5hdGUoZnVuY3Rpb24gKGNvbnN1bWVyKSB7IHJldHVybiBjb25zdW1lci5lcnJvcihlcnIpOyB9KTsgfSkpO1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgd2luZG93UmVjb3JkcyA9IG51bGw7XG4gICAgICAgIH07XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBfX3ZhbHVlcyB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gJy4uL1N1YmplY3QnO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAnLi4vU3Vic2NyaXB0aW9uJztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgbm9vcCB9IGZyb20gJy4uL3V0aWwvbm9vcCc7XG5pbXBvcnQgeyBhcnJSZW1vdmUgfSBmcm9tICcuLi91dGlsL2FyclJlbW92ZSc7XG5leHBvcnQgZnVuY3Rpb24gd2luZG93VG9nZ2xlKG9wZW5pbmdzLCBjbG9zaW5nU2VsZWN0b3IpIHtcbiAgICByZXR1cm4gb3BlcmF0ZShmdW5jdGlvbiAoc291cmNlLCBzdWJzY3JpYmVyKSB7XG4gICAgICAgIHZhciB3aW5kb3dzID0gW107XG4gICAgICAgIHZhciBoYW5kbGVFcnJvciA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgIHdoaWxlICgwIDwgd2luZG93cy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3dzLnNoaWZ0KCkuZXJyb3IoZXJyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN1YnNjcmliZXIuZXJyb3IoZXJyKTtcbiAgICAgICAgfTtcbiAgICAgICAgaW5uZXJGcm9tKG9wZW5pbmdzKS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uIChvcGVuVmFsdWUpIHtcbiAgICAgICAgICAgIHZhciB3aW5kb3cgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICAgICAgd2luZG93cy5wdXNoKHdpbmRvdyk7XG4gICAgICAgICAgICB2YXIgY2xvc2luZ1N1YnNjcmlwdGlvbiA9IG5ldyBTdWJzY3JpcHRpb24oKTtcbiAgICAgICAgICAgIHZhciBjbG9zZVdpbmRvdyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBhcnJSZW1vdmUod2luZG93cywgd2luZG93KTtcbiAgICAgICAgICAgICAgICB3aW5kb3cuY29tcGxldGUoKTtcbiAgICAgICAgICAgICAgICBjbG9zaW5nU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdmFyIGNsb3NpbmdOb3RpZmllcjtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY2xvc2luZ05vdGlmaWVyID0gaW5uZXJGcm9tKGNsb3NpbmdTZWxlY3RvcihvcGVuVmFsdWUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVFcnJvcihlcnIpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHN1YnNjcmliZXIubmV4dCh3aW5kb3cuYXNPYnNlcnZhYmxlKCkpO1xuICAgICAgICAgICAgY2xvc2luZ1N1YnNjcmlwdGlvbi5hZGQoY2xvc2luZ05vdGlmaWVyLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgY2xvc2VXaW5kb3csIG5vb3AsIGhhbmRsZUVycm9yKSkpO1xuICAgICAgICB9LCBub29wKSk7XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgdmFyIGVfMSwgX2E7XG4gICAgICAgICAgICB2YXIgd2luZG93c0NvcHkgPSB3aW5kb3dzLnNsaWNlKCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIHdpbmRvd3NDb3B5XzEgPSBfX3ZhbHVlcyh3aW5kb3dzQ29weSksIHdpbmRvd3NDb3B5XzFfMSA9IHdpbmRvd3NDb3B5XzEubmV4dCgpOyAhd2luZG93c0NvcHlfMV8xLmRvbmU7IHdpbmRvd3NDb3B5XzFfMSA9IHdpbmRvd3NDb3B5XzEubmV4dCgpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB3aW5kb3dfMSA9IHdpbmRvd3NDb3B5XzFfMS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93XzEubmV4dCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVfMV8xKSB7IGVfMSA9IHsgZXJyb3I6IGVfMV8xIH07IH1cbiAgICAgICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh3aW5kb3dzQ29weV8xXzEgJiYgIXdpbmRvd3NDb3B5XzFfMS5kb25lICYmIChfYSA9IHdpbmRvd3NDb3B5XzEucmV0dXJuKSkgX2EuY2FsbCh3aW5kb3dzQ29weV8xKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZmluYWxseSB7IGlmIChlXzEpIHRocm93IGVfMS5lcnJvcjsgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB3aGlsZSAoMCA8IHdpbmRvd3MubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgd2luZG93cy5zaGlmdCgpLmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdWJzY3JpYmVyLmNvbXBsZXRlKCk7XG4gICAgICAgIH0sIGhhbmRsZUVycm9yLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB3aGlsZSAoMCA8IHdpbmRvd3MubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgd2luZG93cy5zaGlmdCgpLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IFN1YmplY3QgfSBmcm9tICcuLi9TdWJqZWN0JztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuZXhwb3J0IGZ1bmN0aW9uIHdpbmRvd1doZW4oY2xvc2luZ1NlbGVjdG9yKSB7XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB2YXIgd2luZG93O1xuICAgICAgICB2YXIgY2xvc2luZ1N1YnNjcmliZXI7XG4gICAgICAgIHZhciBoYW5kbGVFcnJvciA9IGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgICAgICAgIHdpbmRvdy5lcnJvcihlcnIpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5lcnJvcihlcnIpO1xuICAgICAgICB9O1xuICAgICAgICB2YXIgb3BlbldpbmRvdyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNsb3NpbmdTdWJzY3JpYmVyID09PSBudWxsIHx8IGNsb3NpbmdTdWJzY3JpYmVyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjbG9zaW5nU3Vic2NyaWJlci51bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgd2luZG93ID09PSBudWxsIHx8IHdpbmRvdyA9PT0gdm9pZCAwID8gdm9pZCAwIDogd2luZG93LmNvbXBsZXRlKCk7XG4gICAgICAgICAgICB3aW5kb3cgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHdpbmRvdy5hc09ic2VydmFibGUoKSk7XG4gICAgICAgICAgICB2YXIgY2xvc2luZ05vdGlmaWVyO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjbG9zaW5nTm90aWZpZXIgPSBpbm5lckZyb20oY2xvc2luZ1NlbGVjdG9yKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgICAgIGhhbmRsZUVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2xvc2luZ05vdGlmaWVyLnN1YnNjcmliZSgoY2xvc2luZ1N1YnNjcmliZXIgPSBjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgb3BlbldpbmRvdywgb3BlbldpbmRvdywgaGFuZGxlRXJyb3IpKSk7XG4gICAgICAgIH07XG4gICAgICAgIG9wZW5XaW5kb3coKTtcbiAgICAgICAgc291cmNlLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7IHJldHVybiB3aW5kb3cubmV4dCh2YWx1ZSk7IH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHdpbmRvdy5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgc3Vic2NyaWJlci5jb21wbGV0ZSgpO1xuICAgICAgICB9LCBoYW5kbGVFcnJvciwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY2xvc2luZ1N1YnNjcmliZXIgPT09IG51bGwgfHwgY2xvc2luZ1N1YnNjcmliZXIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGNsb3NpbmdTdWJzY3JpYmVyLnVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICB3aW5kb3cgPSBudWxsO1xuICAgICAgICB9KSk7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuaW1wb3J0IHsgY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyIH0gZnJvbSAnLi9PcGVyYXRvclN1YnNjcmliZXInO1xuaW1wb3J0IHsgaW5uZXJGcm9tIH0gZnJvbSAnLi4vb2JzZXJ2YWJsZS9pbm5lckZyb20nO1xuaW1wb3J0IHsgaWRlbnRpdHkgfSBmcm9tICcuLi91dGlsL2lkZW50aXR5JztcbmltcG9ydCB7IG5vb3AgfSBmcm9tICcuLi91dGlsL25vb3AnO1xuaW1wb3J0IHsgcG9wUmVzdWx0U2VsZWN0b3IgfSBmcm9tICcuLi91dGlsL2FyZ3MnO1xuZXhwb3J0IGZ1bmN0aW9uIHdpdGhMYXRlc3RGcm9tKCkge1xuICAgIHZhciBpbnB1dHMgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgICBpbnB1dHNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIHByb2plY3QgPSBwb3BSZXN1bHRTZWxlY3RvcihpbnB1dHMpO1xuICAgIHJldHVybiBvcGVyYXRlKGZ1bmN0aW9uIChzb3VyY2UsIHN1YnNjcmliZXIpIHtcbiAgICAgICAgdmFyIGxlbiA9IGlucHV0cy5sZW5ndGg7XG4gICAgICAgIHZhciBvdGhlclZhbHVlcyA9IG5ldyBBcnJheShsZW4pO1xuICAgICAgICB2YXIgaGFzVmFsdWUgPSBpbnB1dHMubWFwKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGZhbHNlOyB9KTtcbiAgICAgICAgdmFyIHJlYWR5ID0gZmFsc2U7XG4gICAgICAgIHZhciBfbG9vcF8xID0gZnVuY3Rpb24gKGkpIHtcbiAgICAgICAgICAgIGlubmVyRnJvbShpbnB1dHNbaV0pLnN1YnNjcmliZShjcmVhdGVPcGVyYXRvclN1YnNjcmliZXIoc3Vic2NyaWJlciwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgb3RoZXJWYWx1ZXNbaV0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoIXJlYWR5ICYmICFoYXNWYWx1ZVtpXSkge1xuICAgICAgICAgICAgICAgICAgICBoYXNWYWx1ZVtpXSA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIChyZWFkeSA9IGhhc1ZhbHVlLmV2ZXJ5KGlkZW50aXR5KSkgJiYgKGhhc1ZhbHVlID0gbnVsbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgbm9vcCkpO1xuICAgICAgICB9O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICBfbG9vcF8xKGkpO1xuICAgICAgICB9XG4gICAgICAgIHNvdXJjZS5zdWJzY3JpYmUoY3JlYXRlT3BlcmF0b3JTdWJzY3JpYmVyKHN1YnNjcmliZXIsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgaWYgKHJlYWR5KSB7XG4gICAgICAgICAgICAgICAgdmFyIHZhbHVlcyA9IF9fc3ByZWFkQXJyYXkoW3ZhbHVlXSwgX19yZWFkKG90aGVyVmFsdWVzKSk7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KHByb2plY3QgPyBwcm9qZWN0LmFwcGx5KHZvaWQgMCwgX19zcHJlYWRBcnJheShbXSwgX19yZWFkKHZhbHVlcykpKSA6IHZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKTtcbiAgICB9KTtcbn1cbiIsImltcG9ydCB7IHppcCB9IGZyb20gJy4uL29ic2VydmFibGUvemlwJztcbmltcG9ydCB7IGpvaW5BbGxJbnRlcm5hbHMgfSBmcm9tICcuL2pvaW5BbGxJbnRlcm5hbHMnO1xuZXhwb3J0IGZ1bmN0aW9uIHppcEFsbChwcm9qZWN0KSB7XG4gICAgcmV0dXJuIGpvaW5BbGxJbnRlcm5hbHMoemlwLCBwcm9qZWN0KTtcbn1cbiIsImltcG9ydCB7IF9fcmVhZCwgX19zcHJlYWRBcnJheSB9IGZyb20gXCJ0c2xpYlwiO1xuaW1wb3J0IHsgemlwIGFzIHppcFN0YXRpYyB9IGZyb20gJy4uL29ic2VydmFibGUvemlwJztcbmltcG9ydCB7IG9wZXJhdGUgfSBmcm9tICcuLi91dGlsL2xpZnQnO1xuZXhwb3J0IGZ1bmN0aW9uIHppcCgpIHtcbiAgICB2YXIgc291cmNlcyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIHNvdXJjZXNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgcmV0dXJuIG9wZXJhdGUoZnVuY3Rpb24gKHNvdXJjZSwgc3Vic2NyaWJlcikge1xuICAgICAgICB6aXBTdGF0aWMuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtzb3VyY2VdLCBfX3JlYWQoc291cmNlcykpKS5zdWJzY3JpYmUoc3Vic2NyaWJlcik7XG4gICAgfSk7XG59XG4iLCJpbXBvcnQgeyBfX3JlYWQsIF9fc3ByZWFkQXJyYXkgfSBmcm9tIFwidHNsaWJcIjtcbmltcG9ydCB7IHppcCB9IGZyb20gJy4vemlwJztcbmV4cG9ydCBmdW5jdGlvbiB6aXBXaXRoKCkge1xuICAgIHZhciBvdGhlcklucHV0cyA9IFtdO1xuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBhcmd1bWVudHMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICAgIG90aGVySW5wdXRzW19pXSA9IGFyZ3VtZW50c1tfaV07XG4gICAgfVxuICAgIHJldHVybiB6aXAuYXBwbHkodm9pZCAwLCBfX3NwcmVhZEFycmF5KFtdLCBfX3JlYWQob3RoZXJJbnB1dHMpKSk7XG59XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjQsMjUsMjYsMjcsMjgsMjksMzAsMzEsMzIsMzMsMzQsMzUsMzYsMzcsMzgsMzksNDAsNDEsNDIsNDMsNDQsNDUsNDYsNDcsNDgsNDksNTAsNTEsNTIsNTMsNTQsNTUsNTYsNTcsNTgsNTksNjAsNjEsNjIsNjMsNjQsNjUsNjYsNjcsNjgsNjksNzAsNzEsNzIsNzMsNzQsNzUsNzYsNzcsNzgsNzksODAsODEsODIsODMsODQsODUsODYsODcsODgsODksOTAsOTEsOTIsOTMsOTQsOTUsOTYsOTcsOTgsOTksMTAwLDEwMSwxMDIsMTAzLDEwNCwxMDUsMTA2LDEwNywxMDgsMTA5LDExMCwxMTEsMTEyLDExMywxMTQsMTE1LDExNiwxMTcsMTE4LDExOSwxMjAsMTIxLDEyMiwxMjMsMTI0LDEyNSwxMjYsMTI3LDEyOCwxMjksMTMwLDEzMSwxMzIsMTMzLDEzNCwxMzUsMTM2LDEzNywxMzgsMTM5LDE0MCwxNDEsMTQyLDE0MywxNDQsMTQ1LDE0NiwxNDcsMTQ4LDE0OSwxNTAsMTUxLDE1MiwxNTMsMTU0LDE1NSwxNTYsMTU3LDE1OCwxNTksMTYwLDE2MSwxNjIsMTYzLDE2NCwxNjUsMTY2LDE2NywxNjgsMTY5LDE3MCwxNzEsMTcyLDE3MywxNzQsMTc1LDE3NiwxNzcsMTc4LDE3OSwxODAsMTgxLDE4MiwxODMsMTg0LDE4NSwxODYsMTg3XSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxJQUFJLGdCQUFnQixTQUFTLEdBQUcsR0FBRztDQUNqQyxnQkFBZ0IsT0FBTyxrQkFDbEIsRUFBRSxXQUFXLENBQUMsRUFBRSxhQUFhLFNBQVMsU0FBVSxHQUFHLEdBQUc7RUFBRSxFQUFFLFlBQVk7Q0FBRyxLQUMxRSxTQUFVLEdBQUcsR0FBRztFQUFFLEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxFQUFFO0NBQUk7Q0FDcEcsT0FBTyxjQUFjLEdBQUcsQ0FBQztBQUMzQjtBQUVBLFNBQWdCLFVBQVUsR0FBRyxHQUFHO0NBQzlCLElBQUksT0FBTyxNQUFNLGNBQWMsTUFBTSxNQUNqQyxNQUFNLElBQUksVUFBVSx5QkFBeUIsT0FBTyxDQUFDLElBQUksK0JBQStCO0NBQzVGLGNBQWMsR0FBRyxDQUFDO0NBQ2xCLFNBQVMsS0FBSztFQUFFLEtBQUssY0FBYztDQUFHO0NBQ3RDLEVBQUUsWUFBWSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUMsS0FBSyxHQUFHLFlBQVksRUFBRSxXQUFXLElBQUksR0FBRztBQUNwRjtBQXFGQSxTQUFnQixVQUFVLFNBQVMsWUFBWSxHQUFHLFdBQVc7Q0FDM0QsU0FBUyxNQUFNLE9BQU87RUFBRSxPQUFPLGlCQUFpQixJQUFJLFFBQVEsSUFBSSxFQUFFLFNBQVUsU0FBUztHQUFFLFFBQVEsS0FBSztFQUFHLENBQUM7Q0FBRztDQUMzRyxPQUFPLEtBQUssTUFBTSxJQUFJLFVBQVUsU0FBVSxTQUFTLFFBQVE7RUFDdkQsU0FBUyxVQUFVLE9BQU87R0FBRSxJQUFJO0lBQUUsS0FBSyxVQUFVLEtBQUssS0FBSyxDQUFDO0dBQUcsU0FBUyxHQUFHO0lBQUUsT0FBTyxDQUFDO0dBQUc7RUFBRTtFQUMxRixTQUFTLFNBQVMsT0FBTztHQUFFLElBQUk7SUFBRSxLQUFLLFVBQVUsUUFBUSxDQUFDLEtBQUssQ0FBQztHQUFHLFNBQVMsR0FBRztJQUFFLE9BQU8sQ0FBQztHQUFHO0VBQUU7RUFDN0YsU0FBUyxLQUFLLFFBQVE7R0FBRSxPQUFPLE9BQU8sUUFBUSxPQUFPLEtBQUssSUFBSSxNQUFNLE9BQU8sS0FBSyxDQUFDLENBQUMsS0FBSyxXQUFXLFFBQVE7RUFBRztFQUM3RyxNQUFNLFlBQVksVUFBVSxNQUFNLFNBQVMsY0FBYyxDQUFDLENBQUMsRUFBQSxDQUFHLEtBQUssQ0FBQztDQUN4RSxDQUFDO0FBQ0g7QUFFQSxTQUFnQixZQUFZLFNBQVMsTUFBTTtDQUN6QyxJQUFJLElBQUk7RUFBRSxPQUFPO0VBQUcsTUFBTSxXQUFXO0dBQUUsSUFBSSxFQUFFLEtBQUssR0FBRyxNQUFNLEVBQUU7R0FBSSxPQUFPLEVBQUU7RUFBSTtFQUFHLE1BQU0sQ0FBQztFQUFHLEtBQUssQ0FBQztDQUFFLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxPQUFPLFFBQVEsT0FBTyxhQUFhLGFBQWEsV0FBVyxPQUFBLENBQVEsU0FBUztDQUMvTCxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUMsR0FBRyxFQUFFLFdBQVcsS0FBSyxDQUFDLEdBQUcsRUFBRSxZQUFZLEtBQUssQ0FBQyxHQUFHLE9BQU8sV0FBVyxlQUFlLEVBQUUsT0FBTyxZQUFZLFdBQVc7RUFBRSxPQUFPO0NBQU0sSUFBSTtDQUMxSixTQUFTLEtBQUssR0FBRztFQUFFLE9BQU8sU0FBVSxHQUFHO0dBQUUsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7RUFBRztDQUFHO0NBQ2pFLFNBQVMsS0FBSyxJQUFJO0VBQ2QsSUFBSSxHQUFHLE1BQU0sSUFBSSxVQUFVLGlDQUFpQztFQUM1RCxPQUFPLE1BQU0sSUFBSSxHQUFHLEdBQUcsT0FBTyxJQUFJLEtBQUssR0FBRyxJQUFJO0dBQzFDLElBQUksSUFBSSxHQUFHLE1BQU0sSUFBSSxHQUFHLEtBQUssSUFBSSxFQUFFLFlBQVksR0FBRyxLQUFLLEVBQUUsY0FBYyxJQUFJLEVBQUUsY0FBYyxFQUFFLEtBQUssQ0FBQyxHQUFHLEtBQUssRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLEtBQUssR0FBRyxHQUFHLEVBQUUsRUFBQSxDQUFHLE1BQU0sT0FBTztHQUMzSixJQUFJLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUFFLEtBQUs7R0FDdEMsUUFBUSxHQUFHLElBQVg7SUFDSSxLQUFLO0lBQUcsS0FBSztLQUFHLElBQUk7S0FBSTtJQUN4QixLQUFLO0tBQUcsRUFBRTtLQUFTLE9BQU87TUFBRSxPQUFPLEdBQUc7TUFBSSxNQUFNO0tBQU07SUFDdEQsS0FBSztLQUFHLEVBQUU7S0FBUyxJQUFJLEdBQUc7S0FBSSxLQUFLLENBQUMsQ0FBQztLQUFHO0lBQ3hDLEtBQUs7S0FBRyxLQUFLLEVBQUUsSUFBSSxJQUFJO0tBQUcsRUFBRSxLQUFLLElBQUk7S0FBRztJQUN4QztLQUNJLElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxJQUFJLEVBQUUsU0FBUyxLQUFLLEVBQUUsRUFBRSxTQUFTLFFBQVEsR0FBRyxPQUFPLEtBQUssR0FBRyxPQUFPLElBQUk7TUFBRSxJQUFJO01BQUc7S0FBVTtLQUMzRyxJQUFJLEdBQUcsT0FBTyxNQUFNLENBQUMsS0FBTSxHQUFHLEtBQUssRUFBRSxNQUFNLEdBQUcsS0FBSyxFQUFFLEtBQU07TUFBRSxFQUFFLFFBQVEsR0FBRztNQUFJO0tBQU87S0FDckYsSUFBSSxHQUFHLE9BQU8sS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJO01BQUUsRUFBRSxRQUFRLEVBQUU7TUFBSSxJQUFJO01BQUk7S0FBTztLQUNwRSxJQUFJLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSTtNQUFFLEVBQUUsUUFBUSxFQUFFO01BQUksRUFBRSxJQUFJLEtBQUssRUFBRTtNQUFHO0tBQU87S0FDbEUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLElBQUk7S0FDcEIsRUFBRSxLQUFLLElBQUk7S0FBRztHQUN0QjtHQUNBLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQztFQUM3QixTQUFTLEdBQUc7R0FBRSxLQUFLLENBQUMsR0FBRyxDQUFDO0dBQUcsSUFBSTtFQUFHLFVBQVU7R0FBRSxJQUFJLElBQUk7RUFBRztFQUN6RCxJQUFJLEdBQUcsS0FBSyxHQUFHLE1BQU0sR0FBRztFQUFJLE9BQU87R0FBRSxPQUFPLEdBQUcsS0FBSyxHQUFHLEtBQUssS0FBSztHQUFHLE1BQU07RUFBSztDQUNuRjtBQUNGO0FBa0JBLFNBQWdCLFNBQVMsR0FBRztDQUMxQixJQUFJLElBQUksT0FBTyxXQUFXLGNBQWMsT0FBTyxVQUFVLElBQUksS0FBSyxFQUFFLElBQUksSUFBSTtDQUM1RSxJQUFJLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQztDQUN0QixJQUFJLEtBQUssT0FBTyxFQUFFLFdBQVcsVUFBVSxPQUFPLEVBQzFDLE1BQU0sV0FBWTtFQUNkLElBQUksS0FBSyxLQUFLLEVBQUUsUUFBUSxJQUFJLEtBQUs7RUFDakMsT0FBTztHQUFFLE9BQU8sS0FBSyxFQUFFO0dBQU0sTUFBTSxDQUFDO0VBQUU7Q0FDMUMsRUFDSjtDQUNBLE1BQU0sSUFBSSxVQUFVLElBQUksNEJBQTRCLGlDQUFpQztBQUN2RjtBQUVBLFNBQWdCLE9BQU8sR0FBRyxHQUFHO0NBQzNCLElBQUksSUFBSSxPQUFPLFdBQVcsY0FBYyxFQUFFLE9BQU87Q0FDakQsSUFBSSxDQUFDLEdBQUcsT0FBTztDQUNmLElBQUksSUFBSSxFQUFFLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLEdBQUc7Q0FDL0IsSUFBSTtFQUNBLFFBQVEsTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBQSxDQUFHLE1BQU0sR0FBRyxLQUFLLEVBQUUsS0FBSztDQUM3RSxTQUNPLE9BQU87RUFBRSxJQUFJLEVBQVMsTUFBTTtDQUFHLFVBQzlCO0VBQ0osSUFBSTtHQUNBLElBQUksS0FBSyxDQUFDLEVBQUUsU0FBUyxJQUFJLEVBQUUsWUFBWSxFQUFFLEtBQUssQ0FBQztFQUNuRCxVQUNRO0dBQUUsSUFBSSxHQUFHLE1BQU0sRUFBRTtFQUFPO0NBQ3BDO0NBQ0EsT0FBTztBQUNUO0FBa0JBLFNBQWdCLGNBQWMsSUFBSSxNQUFNLE1BQU07Q0FDNUMsSUFBSSxRQUFRLFVBQVUsV0FBVztPQUFRLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLElBQUksSUFBSSxHQUFHLEtBQzVFLElBQUksTUFBTSxFQUFFLEtBQUssT0FBTztHQUNwQixJQUFJLENBQUMsSUFBSSxLQUFLLE1BQU0sVUFBVSxNQUFNLEtBQUssTUFBTSxHQUFHLENBQUM7R0FDbkQsR0FBRyxLQUFLLEtBQUs7RUFDakI7O0NBRUosT0FBTyxHQUFHLE9BQU8sTUFBTSxNQUFNLFVBQVUsTUFBTSxLQUFLLElBQUksQ0FBQztBQUN6RDtBQUVBLFNBQWdCLFFBQVEsR0FBRztDQUN6QixPQUFPLGdCQUFnQixXQUFXLEtBQUssSUFBSSxHQUFHLFFBQVEsSUFBSSxRQUFRLENBQUM7QUFDckU7QUFFQSxTQUFnQixpQkFBaUIsU0FBUyxZQUFZLFdBQVc7Q0FDL0QsSUFBSSxDQUFDLE9BQU8sZUFBZSxNQUFNLElBQUksVUFBVSxzQ0FBc0M7Q0FDckYsSUFBSSxJQUFJLFVBQVUsTUFBTSxTQUFTLGNBQWMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUM7Q0FDNUQsT0FBTyxJQUFJLE9BQU8sUUFBUSxPQUFPLGtCQUFrQixhQUFhLGdCQUFnQixPQUFBLENBQVEsU0FBUyxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUssT0FBTyxHQUFHLEtBQUssVUFBVSxXQUFXLEdBQUcsRUFBRSxPQUFPLGlCQUFpQixXQUFZO0VBQUUsT0FBTztDQUFNLEdBQUc7Q0FDdE4sU0FBUyxZQUFZLEdBQUc7RUFBRSxPQUFPLFNBQVUsR0FBRztHQUFFLE9BQU8sUUFBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUFNO0VBQUc7Q0FBRztDQUM5RixTQUFTLEtBQUssR0FBRyxHQUFHO0VBQUUsSUFBSSxFQUFFLElBQUk7R0FBRSxFQUFFLEtBQUssU0FBVSxHQUFHO0lBQUUsT0FBTyxJQUFJLFFBQVEsU0FBVSxHQUFHLEdBQUc7S0FBRSxFQUFFLEtBQUs7TUFBQztNQUFHO01BQUc7TUFBRztLQUFDLENBQUMsSUFBSSxLQUFLLE9BQU8sR0FBRyxDQUFDO0lBQUcsQ0FBQztHQUFHO0dBQUcsSUFBSSxHQUFHLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRTtFQUFHO0NBQUU7Q0FDdkssU0FBUyxPQUFPLEdBQUcsR0FBRztFQUFFLElBQUk7R0FBRSxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztFQUFHLFNBQVMsR0FBRztHQUFFLE9BQU8sRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDO0VBQUc7Q0FBRTtDQUNqRixTQUFTLEtBQUssR0FBRztFQUFFLEVBQUUsaUJBQWlCLFVBQVUsUUFBUSxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsTUFBTSxJQUFJLE9BQU8sRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDO0NBQUc7Q0FDdkgsU0FBUyxRQUFRLE9BQU87RUFBRSxPQUFPLFFBQVEsS0FBSztDQUFHO0NBQ2pELFNBQVMsT0FBTyxPQUFPO0VBQUUsT0FBTyxTQUFTLEtBQUs7Q0FBRztDQUNqRCxTQUFTLE9BQU8sR0FBRyxHQUFHO0VBQUUsSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLFFBQVEsT0FBTyxFQUFFLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLEVBQUU7Q0FBRztBQUNuRjtBQVFBLFNBQWdCLGNBQWMsR0FBRztDQUMvQixJQUFJLENBQUMsT0FBTyxlQUFlLE1BQU0sSUFBSSxVQUFVLHNDQUFzQztDQUNyRixJQUFJLElBQUksRUFBRSxPQUFPLGdCQUFnQjtDQUNqQyxPQUFPLElBQUksRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLE9BQU8sYUFBYSxhQUFhLFNBQVMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxLQUFLLE1BQU0sR0FBRyxLQUFLLE9BQU8sR0FBRyxLQUFLLFFBQVEsR0FBRyxFQUFFLE9BQU8saUJBQWlCLFdBQVk7RUFBRSxPQUFPO0NBQU0sR0FBRztDQUM5TSxTQUFTLEtBQUssR0FBRztFQUFFLEVBQUUsS0FBSyxFQUFFLE1BQU0sU0FBVSxHQUFHO0dBQUUsT0FBTyxJQUFJLFFBQVEsU0FBVSxTQUFTLFFBQVE7SUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRyxPQUFPLFNBQVMsUUFBUSxFQUFFLE1BQU0sRUFBRSxLQUFLO0dBQUcsQ0FBQztFQUFHO0NBQUc7Q0FDL0osU0FBUyxPQUFPLFNBQVMsUUFBUSxHQUFHLEdBQUc7RUFBRSxRQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLEdBQUc7R0FBRSxRQUFRO0lBQUUsT0FBTztJQUFHLE1BQU07R0FBRSxDQUFDO0VBQUcsR0FBRyxNQUFNO0NBQUc7QUFDN0g7OztBQzVQQSxTQUFnQixXQUFXLE9BQU87Q0FDOUIsT0FBTyxPQUFPLFVBQVU7QUFDNUI7OztBQ0ZBLFNBQWdCLGlCQUFpQixZQUFZO0NBQ3pDLElBQUksU0FBUyxTQUFVLFVBQVU7RUFDN0IsTUFBTSxLQUFLLFFBQVE7RUFDbkIsU0FBUyx5QkFBUSxJQUFJLE1BQU0sRUFBQSxDQUFFO0NBQ2pDO0NBQ0EsSUFBSSxXQUFXLFdBQVcsTUFBTTtDQUNoQyxTQUFTLFlBQVksT0FBTyxPQUFPLE1BQU0sU0FBUztDQUNsRCxTQUFTLFVBQVUsY0FBYztDQUNqQyxPQUFPO0FBQ1g7OztBQ1JBLElBQVcsc0JBQXNCLGlCQUFpQixTQUFVLFFBQVE7Q0FDaEUsT0FBTyxTQUFTLHdCQUF3QixRQUFRO0VBQzVDLE9BQU8sSUFBSTtFQUNYLEtBQUssVUFBVSxTQUNULE9BQU8sU0FBUyw4Q0FBOEMsT0FBTyxJQUFJLFNBQVUsS0FBSyxHQUFHO0dBQUUsT0FBTyxJQUFJLElBQUksT0FBTyxJQUFJLFNBQVM7RUFBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sSUFDako7RUFDTixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVM7Q0FDbEI7QUFDSixDQUFDOzs7QUNWRCxTQUFnQixVQUFVLEtBQUssTUFBTTtDQUNqQyxJQUFJLEtBQUs7RUFDTCxJQUFJLFFBQVEsSUFBSSxRQUFRLElBQUk7RUFDNUIsS0FBSyxTQUFTLElBQUksT0FBTyxPQUFPLENBQUM7Q0FDckM7QUFDSjs7O0FDREEsSUFBSSxlQUFnQixXQUFZO0NBQzVCLFNBQVMsYUFBYSxpQkFBaUI7RUFDbkMsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxhQUFhO0VBQ2xCLEtBQUssY0FBYztDQUN2QjtDQUNBLGFBQWEsVUFBVSxjQUFjLFdBQVk7RUFDN0MsSUFBSSxLQUFLLElBQUksS0FBSztFQUNsQixJQUFJO0VBQ0osSUFBSSxDQUFDLEtBQUssUUFBUTtHQUNkLEtBQUssU0FBUztHQUNkLElBQUksYUFBYSxLQUFLO0dBQ3RCLElBQUksWUFBWTtJQUNaLEtBQUssYUFBYTtJQUNsQixJQUFJLE1BQU0sUUFBUSxVQUFVLEdBQ3hCLElBQUk7S0FDQSxLQUFLLElBQUksZUFBZSxTQUFTLFVBQVUsR0FBRyxpQkFBaUIsYUFBYSxLQUFLLEdBQUcsQ0FBQyxlQUFlLE1BQU0saUJBQWlCLGFBQWEsS0FBSyxHQUV6SSxlQUQ4QixNQUNyQixPQUFPLElBQUk7SUFFNUIsU0FDTyxPQUFPO0tBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTTtJQUFHLFVBQ2hDO0tBQ0osSUFBSTtNQUNBLElBQUksa0JBQWtCLENBQUMsZUFBZSxTQUFTLEtBQUssYUFBYSxTQUFTLEdBQUcsS0FBSyxZQUFZO0tBQ2xHLFVBQ1E7TUFBRSxJQUFJLEtBQUssTUFBTSxJQUFJO0tBQU87SUFDeEM7U0FHQSxXQUFXLE9BQU8sSUFBSTtHQUU5QjtHQUNBLElBQUksbUJBQW1CLEtBQUs7R0FDNUIsSUFBSSxXQUFXLGdCQUFnQixHQUMzQixJQUFJO0lBQ0EsaUJBQWlCO0dBQ3JCLFNBQ08sR0FBRztJQUNOLFNBQVMsYUFBYSxzQkFBc0IsRUFBRSxTQUFTLENBQUMsQ0FBQztHQUM3RDtHQUVKLElBQUksY0FBYyxLQUFLO0dBQ3ZCLElBQUksYUFBYTtJQUNiLEtBQUssY0FBYztJQUNuQixJQUFJO0tBQ0EsS0FBSyxJQUFJLGdCQUFnQixTQUFTLFdBQVcsR0FBRyxrQkFBa0IsY0FBYyxLQUFLLEdBQUcsQ0FBQyxnQkFBZ0IsTUFBTSxrQkFBa0IsY0FBYyxLQUFLLEdBQUc7TUFDbkosSUFBSSxZQUFZLGdCQUFnQjtNQUNoQyxJQUFJO09BQ0EsY0FBYyxTQUFTO01BQzNCLFNBQ08sS0FBSztPQUNSLFNBQVMsV0FBVyxRQUFRLFdBQVcsS0FBSyxJQUFJLFNBQVMsQ0FBQztPQUMxRCxJQUFJLGVBQWUscUJBQ2YsU0FBUyxjQUFjLGNBQWMsQ0FBQyxHQUFHLE9BQU8sTUFBTSxDQUFDLEdBQUcsT0FBTyxJQUFJLE1BQU0sQ0FBQztZQUc1RSxPQUFPLEtBQUssR0FBRztNQUV2QjtLQUNKO0lBQ0osU0FDTyxPQUFPO0tBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTTtJQUFHLFVBQ2hDO0tBQ0osSUFBSTtNQUNBLElBQUksbUJBQW1CLENBQUMsZ0JBQWdCLFNBQVMsS0FBSyxjQUFjLFNBQVMsR0FBRyxLQUFLLGFBQWE7S0FDdEcsVUFDUTtNQUFFLElBQUksS0FBSyxNQUFNLElBQUk7S0FBTztJQUN4QztHQUNKO0dBQ0EsSUFBSSxRQUNBLE1BQU0sSUFBSSxvQkFBb0IsTUFBTTtFQUU1QztDQUNKO0NBQ0EsYUFBYSxVQUFVLE1BQU0sU0FBVSxVQUFVO0VBQzdDLElBQUk7RUFDSixJQUFJLFlBQVksYUFBYSxNQUN6QixJQUFJLEtBQUssUUFDTCxjQUFjLFFBQVE7T0FFckI7R0FDRCxJQUFJLG9CQUFvQixjQUFjO0lBQ2xDLElBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxJQUFJLEdBQzNDO0lBRUosU0FBUyxXQUFXLElBQUk7R0FDNUI7R0FDQSxDQUFDLEtBQUssZUFBZSxLQUFLLEtBQUssaUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDLEVBQUEsQ0FBRyxLQUFLLFFBQVE7RUFDbEc7Q0FFUjtDQUNBLGFBQWEsVUFBVSxhQUFhLFNBQVUsUUFBUTtFQUNsRCxJQUFJLGFBQWEsS0FBSztFQUN0QixPQUFPLGVBQWUsVUFBVyxNQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVcsU0FBUyxNQUFNO0NBQzVGO0NBQ0EsYUFBYSxVQUFVLGFBQWEsU0FBVSxRQUFRO0VBQ2xELElBQUksYUFBYSxLQUFLO0VBQ3RCLEtBQUssYUFBYSxNQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVcsS0FBSyxNQUFNLEdBQUcsY0FBYyxhQUFhLENBQUMsWUFBWSxNQUFNLElBQUk7Q0FDOUg7Q0FDQSxhQUFhLFVBQVUsZ0JBQWdCLFNBQVUsUUFBUTtFQUNyRCxJQUFJLGFBQWEsS0FBSztFQUN0QixJQUFJLGVBQWUsUUFDZixLQUFLLGFBQWE7T0FFakIsSUFBSSxNQUFNLFFBQVEsVUFBVSxHQUM3QixVQUFVLFlBQVksTUFBTTtDQUVwQztDQUNBLGFBQWEsVUFBVSxTQUFTLFNBQVUsVUFBVTtFQUNoRCxJQUFJLGNBQWMsS0FBSztFQUN2QixlQUFlLFVBQVUsYUFBYSxRQUFRO0VBQzlDLElBQUksb0JBQW9CLGNBQ3BCLFNBQVMsY0FBYyxJQUFJO0NBRW5DO0NBQ0EsYUFBYSxTQUFTLFdBQVk7RUFDOUIsSUFBSSxRQUFRLElBQUksYUFBYTtFQUM3QixNQUFNLFNBQVM7RUFDZixPQUFPO0NBQ1gsRUFBQSxDQUFHO0NBQ0gsT0FBTztBQUNYLEVBQUU7QUFFRixJQUFXLHFCQUFxQixhQUFhO0FBQzdDLFNBQWdCLGVBQWUsT0FBTztDQUNsQyxPQUFRLGlCQUFpQixnQkFDcEIsU0FBUyxZQUFZLFNBQVMsV0FBVyxNQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sR0FBRyxLQUFLLFdBQVcsTUFBTSxXQUFXO0FBQ3hIO0FBQ0EsU0FBUyxjQUFjLFdBQVc7Q0FDOUIsSUFBSSxXQUFXLFNBQVMsR0FDcEIsVUFBVTtNQUdWLFVBQVUsWUFBWTtBQUU5Qjs7O0FDN0lBLElBQVcsU0FBUztDQUNoQixrQkFBa0I7Q0FDbEIsdUJBQXVCO0NBQ3ZCLFNBQVMsS0FBQTtDQUNULHVDQUF1QztDQUN2QywwQkFBMEI7QUFDOUI7OztBQ0xBLElBQVcsa0JBQWtCO0NBQ3pCLFlBQVksU0FBVSxTQUFTLFNBQVM7RUFDcEMsSUFBSSxPQUFPLENBQUM7RUFDWixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLEtBQUssS0FBSyxLQUFLLFVBQVU7RUFFN0IsSUFBSSxXQUFXLGdCQUFnQjtFQUMvQixJQUFJLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxZQUM3RCxPQUFPLFNBQVMsV0FBVyxNQUFNLFVBQVUsY0FBYyxDQUFDLFNBQVMsT0FBTyxHQUFHLE9BQU8sSUFBSSxDQUFDLENBQUM7RUFFOUYsT0FBTyxXQUFXLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxTQUFTLE9BQU8sR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDO0NBQ25GO0NBQ0EsY0FBYyxTQUFVLFFBQVE7RUFDNUIsSUFBSSxXQUFXLGdCQUFnQjtFQUMvQixTQUFTLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxpQkFBaUIsYUFBQSxDQUFjLE1BQU07Q0FDL0c7Q0FDQSxVQUFVLEtBQUE7QUFDZDs7O0FDaEJBLFNBQWdCLHFCQUFxQixLQUFLO0NBQ3RDLGdCQUFnQixXQUFXLFdBQVk7RUFDbkMsSUFBSSxtQkFBbUIsT0FBTztFQUM5QixJQUFJLGtCQUNBLGlCQUFpQixHQUFHO09BR3BCLE1BQU07Q0FFZCxDQUFDO0FBQ0w7OztBQ1pBLFNBQWdCLE9BQU8sQ0FBRTs7O0FDQXpCLElBQVcseUJBQXlCLFdBQVk7Q0FBRSxPQUFPLG1CQUFtQixLQUFLLEtBQUEsR0FBVyxLQUFBLENBQVM7QUFBRyxFQUFBLENBQUc7QUFDM0csU0FBZ0Isa0JBQWtCLE9BQU87Q0FDckMsT0FBTyxtQkFBbUIsS0FBSyxLQUFBLEdBQVcsS0FBSztBQUNuRDtBQUNBLFNBQWdCLGlCQUFpQixPQUFPO0NBQ3BDLE9BQU8sbUJBQW1CLEtBQUssT0FBTyxLQUFBLENBQVM7QUFDbkQ7QUFDQSxTQUFnQixtQkFBbUIsTUFBTSxPQUFPLE9BQU87Q0FDbkQsT0FBTztFQUNHO0VBQ0M7RUFDQTtDQUNYO0FBQ0o7OztBQ1pBLElBQUksVUFBVTtBQUNkLFNBQWdCLGFBQWEsSUFBSTtDQUM3QixJQUFJLE9BQU8sdUNBQXVDO0VBQzlDLElBQUksU0FBUyxDQUFDO0VBQ2QsSUFBSSxRQUNBLFVBQVU7R0FBRSxhQUFhO0dBQU8sT0FBTztFQUFLO0VBRWhELEdBQUc7RUFDSCxJQUFJLFFBQVE7R0FDUixJQUFJLEtBQUssU0FBUyxjQUFjLEdBQUcsYUFBYSxRQUFRLEdBQUc7R0FDM0QsVUFBVTtHQUNWLElBQUksYUFDQSxNQUFNO0VBRWQ7Q0FDSixPQUVJLEdBQUc7QUFFWDtBQUNBLFNBQWdCLGFBQWEsS0FBSztDQUM5QixJQUFJLE9BQU8seUNBQXlDLFNBQVM7RUFDekQsUUFBUSxjQUFjO0VBQ3RCLFFBQVEsUUFBUTtDQUNwQjtBQUNKOzs7QUNqQkEsSUFBSSxhQUFjLFNBQVUsUUFBUTtDQUNoQyxVQUFVLFlBQVksTUFBTTtDQUM1QixTQUFTLFdBQVcsYUFBYTtFQUM3QixJQUFJLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUNqQyxNQUFNLFlBQVk7RUFDbEIsSUFBSSxhQUFhO0dBQ2IsTUFBTSxjQUFjO0dBQ3BCLElBQUksZUFBZSxXQUFXLEdBQzFCLFlBQVksSUFBSSxLQUFLO0VBRTdCLE9BRUksTUFBTSxjQUFjO0VBRXhCLE9BQU87Q0FDWDtDQUNBLFdBQVcsU0FBUyxTQUFVLE1BQU0sT0FBTyxVQUFVO0VBQ2pELE9BQU8sSUFBSSxlQUFlLE1BQU0sT0FBTyxRQUFRO0NBQ25EO0NBQ0EsV0FBVyxVQUFVLE9BQU8sU0FBVSxPQUFPO0VBQ3pDLElBQUksS0FBSyxXQUNMLDBCQUEwQixpQkFBaUIsS0FBSyxHQUFHLElBQUk7T0FHdkQsS0FBSyxNQUFNLEtBQUs7Q0FFeEI7Q0FDQSxXQUFXLFVBQVUsUUFBUSxTQUFVLEtBQUs7RUFDeEMsSUFBSSxLQUFLLFdBQ0wsMEJBQTBCLGtCQUFrQixHQUFHLEdBQUcsSUFBSTtPQUVyRDtHQUNELEtBQUssWUFBWTtHQUNqQixLQUFLLE9BQU8sR0FBRztFQUNuQjtDQUNKO0NBQ0EsV0FBVyxVQUFVLFdBQVcsV0FBWTtFQUN4QyxJQUFJLEtBQUssV0FDTCwwQkFBMEIsdUJBQXVCLElBQUk7T0FFcEQ7R0FDRCxLQUFLLFlBQVk7R0FDakIsS0FBSyxVQUFVO0VBQ25CO0NBQ0o7Q0FDQSxXQUFXLFVBQVUsY0FBYyxXQUFZO0VBQzNDLElBQUksQ0FBQyxLQUFLLFFBQVE7R0FDZCxLQUFLLFlBQVk7R0FDakIsT0FBTyxVQUFVLFlBQVksS0FBSyxJQUFJO0dBQ3RDLEtBQUssY0FBYztFQUN2QjtDQUNKO0NBQ0EsV0FBVyxVQUFVLFFBQVEsU0FBVSxPQUFPO0VBQzFDLEtBQUssWUFBWSxLQUFLLEtBQUs7Q0FDL0I7Q0FDQSxXQUFXLFVBQVUsU0FBUyxTQUFVLEtBQUs7RUFDekMsSUFBSTtHQUNBLEtBQUssWUFBWSxNQUFNLEdBQUc7RUFDOUIsVUFDUTtHQUNKLEtBQUssWUFBWTtFQUNyQjtDQUNKO0NBQ0EsV0FBVyxVQUFVLFlBQVksV0FBWTtFQUN6QyxJQUFJO0dBQ0EsS0FBSyxZQUFZLFNBQVM7RUFDOUIsVUFDUTtHQUNKLEtBQUssWUFBWTtFQUNyQjtDQUNKO0NBQ0EsT0FBTztBQUNYLEVBQUUsWUFBWTtBQUVkLElBQUksUUFBUSxTQUFTLFVBQVU7QUFDL0IsU0FBUyxLQUFLLElBQUksU0FBUztDQUN2QixPQUFPLE1BQU0sS0FBSyxJQUFJLE9BQU87QUFDakM7QUFDQSxJQUFJLG1CQUFvQixXQUFZO0NBQ2hDLFNBQVMsaUJBQWlCLGlCQUFpQjtFQUN2QyxLQUFLLGtCQUFrQjtDQUMzQjtDQUNBLGlCQUFpQixVQUFVLE9BQU8sU0FBVSxPQUFPO0VBQy9DLElBQUksa0JBQWtCLEtBQUs7RUFDM0IsSUFBSSxnQkFBZ0IsTUFDaEIsSUFBSTtHQUNBLGdCQUFnQixLQUFLLEtBQUs7RUFDOUIsU0FDTyxPQUFPO0dBQ1YscUJBQXFCLEtBQUs7RUFDOUI7Q0FFUjtDQUNBLGlCQUFpQixVQUFVLFFBQVEsU0FBVSxLQUFLO0VBQzlDLElBQUksa0JBQWtCLEtBQUs7RUFDM0IsSUFBSSxnQkFBZ0IsT0FDaEIsSUFBSTtHQUNBLGdCQUFnQixNQUFNLEdBQUc7RUFDN0IsU0FDTyxPQUFPO0dBQ1YscUJBQXFCLEtBQUs7RUFDOUI7T0FHQSxxQkFBcUIsR0FBRztDQUVoQztDQUNBLGlCQUFpQixVQUFVLFdBQVcsV0FBWTtFQUM5QyxJQUFJLGtCQUFrQixLQUFLO0VBQzNCLElBQUksZ0JBQWdCLFVBQ2hCLElBQUk7R0FDQSxnQkFBZ0IsU0FBUztFQUM3QixTQUNPLE9BQU87R0FDVixxQkFBcUIsS0FBSztFQUM5QjtDQUVSO0NBQ0EsT0FBTztBQUNYLEVBQUU7QUFDRixJQUFJLGlCQUFrQixTQUFVLFFBQVE7Q0FDcEMsVUFBVSxnQkFBZ0IsTUFBTTtDQUNoQyxTQUFTLGVBQWUsZ0JBQWdCLE9BQU8sVUFBVTtFQUNyRCxJQUFJLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUNqQyxJQUFJO0VBQ0osSUFBSSxXQUFXLGNBQWMsS0FBSyxDQUFDLGdCQUMvQixrQkFBa0I7R0FDZCxNQUFPLG1CQUFtQixRQUFRLG1CQUFtQixLQUFLLElBQUksaUJBQWlCLEtBQUE7R0FDL0UsT0FBTyxVQUFVLFFBQVEsVUFBVSxLQUFLLElBQUksUUFBUSxLQUFBO0dBQ3BELFVBQVUsYUFBYSxRQUFRLGFBQWEsS0FBSyxJQUFJLFdBQVcsS0FBQTtFQUNwRTtPQUVDO0dBQ0QsSUFBSTtHQUNKLElBQUksU0FBUyxPQUFPLDBCQUEwQjtJQUMxQyxZQUFZLE9BQU8sT0FBTyxjQUFjO0lBQ3hDLFVBQVUsY0FBYyxXQUFZO0tBQUUsT0FBTyxNQUFNLFlBQVk7SUFBRztJQUNsRSxrQkFBa0I7S0FDZCxNQUFNLGVBQWUsUUFBUSxLQUFLLGVBQWUsTUFBTSxTQUFTO0tBQ2hFLE9BQU8sZUFBZSxTQUFTLEtBQUssZUFBZSxPQUFPLFNBQVM7S0FDbkUsVUFBVSxlQUFlLFlBQVksS0FBSyxlQUFlLFVBQVUsU0FBUztJQUNoRjtHQUNKLE9BRUksa0JBQWtCO0VBRTFCO0VBQ0EsTUFBTSxjQUFjLElBQUksaUJBQWlCLGVBQWU7RUFDeEQsT0FBTztDQUNYO0NBQ0EsT0FBTztBQUNYLEVBQUUsVUFBVTtBQUVaLFNBQVMscUJBQXFCLE9BQU87Q0FDakMsSUFBSSxPQUFPLHVDQUNQLGFBQWEsS0FBSztNQUdsQixxQkFBcUIsS0FBSztBQUVsQztBQUNBLFNBQVMsb0JBQW9CLEtBQUs7Q0FDOUIsTUFBTTtBQUNWO0FBQ0EsU0FBUywwQkFBMEIsY0FBYyxZQUFZO0NBQ3pELElBQUksd0JBQXdCLE9BQU87Q0FDbkMseUJBQXlCLGdCQUFnQixXQUFXLFdBQVk7RUFBRSxPQUFPLHNCQUFzQixjQUFjLFVBQVU7Q0FBRyxDQUFDO0FBQy9IO0FBQ0EsSUFBVyxpQkFBaUI7Q0FDeEIsUUFBUTtDQUNSLE1BQU07Q0FDTixPQUFPO0NBQ1AsVUFBVTtBQUNkOzs7QUN0TEEsSUFBVyxjQUFjLFdBQVk7Q0FBRSxPQUFRLE9BQU8sV0FBVyxjQUFjLE9BQU8sY0FBZTtBQUFnQixFQUFBLENBQUc7OztBQ0F4SCxTQUFnQixTQUFTLEdBQUc7Q0FDeEIsT0FBTztBQUNYOzs7QUNEQSxTQUFnQixPQUFPO0NBQ25CLElBQUksTUFBTSxDQUFDO0NBQ1gsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxJQUFJLE1BQU0sVUFBVTtDQUV4QixPQUFPLGNBQWMsR0FBRztBQUM1QjtBQUNBLFNBQWdCLGNBQWMsS0FBSztDQUMvQixJQUFJLElBQUksV0FBVyxHQUNmLE9BQU87Q0FFWCxJQUFJLElBQUksV0FBVyxHQUNmLE9BQU8sSUFBSTtDQUVmLE9BQU8sU0FBUyxNQUFNLE9BQU87RUFDekIsT0FBTyxJQUFJLE9BQU8sU0FBVSxNQUFNLElBQUk7R0FBRSxPQUFPLEdBQUcsSUFBSTtFQUFHLEdBQUcsS0FBSztDQUNyRTtBQUNKOzs7QUNYQSxJQUFJLGFBQWMsV0FBWTtDQUMxQixTQUFTLFdBQVcsV0FBVztFQUMzQixJQUFJLFdBQ0EsS0FBSyxhQUFhO0NBRTFCO0NBQ0EsV0FBVyxVQUFVLE9BQU8sU0FBVSxVQUFVO0VBQzVDLElBQUksYUFBYSxJQUFJLFdBQVc7RUFDaEMsV0FBVyxTQUFTO0VBQ3BCLFdBQVcsV0FBVztFQUN0QixPQUFPO0NBQ1g7Q0FDQSxXQUFXLFVBQVUsWUFBWSxTQUFVLGdCQUFnQixPQUFPLFVBQVU7RUFDeEUsSUFBSSxRQUFRO0VBQ1osSUFBSSxhQUFhLGFBQWEsY0FBYyxJQUFJLGlCQUFpQixJQUFJLGVBQWUsZ0JBQWdCLE9BQU8sUUFBUTtFQUNuSCxhQUFhLFdBQVk7R0FDckIsSUFBSSxLQUFLLE9BQU8sV0FBVyxHQUFHLFVBQVUsU0FBUyxHQUFHO0dBQ3BELFdBQVcsSUFBSSxXQUVQLFNBQVMsS0FBSyxZQUFZLE1BQU0sSUFDbEMsU0FFTSxNQUFNLFdBQVcsVUFBVSxJQUUzQixNQUFNLGNBQWMsVUFBVSxDQUFDO0VBQy9DLENBQUM7RUFDRCxPQUFPO0NBQ1g7Q0FDQSxXQUFXLFVBQVUsZ0JBQWdCLFNBQVUsTUFBTTtFQUNqRCxJQUFJO0dBQ0EsT0FBTyxLQUFLLFdBQVcsSUFBSTtFQUMvQixTQUNPLEtBQUs7R0FDUixLQUFLLE1BQU0sR0FBRztFQUNsQjtDQUNKO0NBQ0EsV0FBVyxVQUFVLFVBQVUsU0FBVSxNQUFNLGFBQWE7RUFDeEQsSUFBSSxRQUFRO0VBQ1osY0FBYyxlQUFlLFdBQVc7RUFDeEMsT0FBTyxJQUFJLFlBQVksU0FBVSxTQUFTLFFBQVE7R0FDOUMsSUFBSSxhQUFhLElBQUksZUFBZTtJQUNoQyxNQUFNLFNBQVUsT0FBTztLQUNuQixJQUFJO01BQ0EsS0FBSyxLQUFLO0tBQ2QsU0FDTyxLQUFLO01BQ1IsT0FBTyxHQUFHO01BQ1YsV0FBVyxZQUFZO0tBQzNCO0lBQ0o7SUFDQSxPQUFPO0lBQ1AsVUFBVTtHQUNkLENBQUM7R0FDRCxNQUFNLFVBQVUsVUFBVTtFQUM5QixDQUFDO0NBQ0w7Q0FDQSxXQUFXLFVBQVUsYUFBYSxTQUFVLFlBQVk7RUFDcEQsSUFBSTtFQUNKLFFBQVEsS0FBSyxLQUFLLFlBQVksUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxVQUFVLFVBQVU7Q0FDMUY7Q0FDQSxXQUFXLFVBQVVBLGNBQXFCLFdBQVk7RUFDbEQsT0FBTztDQUNYO0NBQ0EsV0FBVyxVQUFVLE9BQU8sV0FBWTtFQUNwQyxJQUFJLGFBQWEsQ0FBQztFQUNsQixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLFdBQVcsTUFBTSxVQUFVO0VBRS9CLE9BQU8sY0FBYyxVQUFVLENBQUMsQ0FBQyxJQUFJO0NBQ3pDO0NBQ0EsV0FBVyxVQUFVLFlBQVksU0FBVSxhQUFhO0VBQ3BELElBQUksUUFBUTtFQUNaLGNBQWMsZUFBZSxXQUFXO0VBQ3hDLE9BQU8sSUFBSSxZQUFZLFNBQVUsU0FBUyxRQUFRO0dBQzlDLElBQUk7R0FDSixNQUFNLFVBQVUsU0FBVSxHQUFHO0lBQUUsT0FBUSxRQUFRO0dBQUksR0FBRyxTQUFVLEtBQUs7SUFBRSxPQUFPLE9BQU8sR0FBRztHQUFHLEdBQUcsV0FBWTtJQUFFLE9BQU8sUUFBUSxLQUFLO0dBQUcsQ0FBQztFQUN4SSxDQUFDO0NBQ0w7Q0FDQSxXQUFXLFNBQVMsU0FBVSxXQUFXO0VBQ3JDLE9BQU8sSUFBSSxXQUFXLFNBQVM7Q0FDbkM7Q0FDQSxPQUFPO0FBQ1gsRUFBRTtBQUVGLFNBQVMsZUFBZSxhQUFhO0NBQ2pDLElBQUk7Q0FDSixRQUFRLEtBQUssZ0JBQWdCLFFBQVEsZ0JBQWdCLEtBQUssSUFBSSxjQUFjLE9BQU8sYUFBYSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7QUFDakk7QUFDQSxTQUFTLFdBQVcsT0FBTztDQUN2QixPQUFPLFNBQVMsV0FBVyxNQUFNLElBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxLQUFLLFdBQVcsTUFBTSxRQUFRO0FBQ2xHO0FBQ0EsU0FBUyxhQUFhLE9BQU87Q0FDekIsT0FBUSxTQUFTLGlCQUFpQixjQUFnQixXQUFXLEtBQUssS0FBSyxlQUFlLEtBQUs7QUFDL0Y7OztBQ25HQSxTQUFnQixRQUFRLFFBQVE7Q0FDNUIsT0FBTyxXQUFXLFdBQVcsUUFBUSxXQUFXLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxJQUFJO0FBQ2pGO0FBQ0EsU0FBZ0IsUUFBUSxNQUFNO0NBQzFCLE9BQU8sU0FBVSxRQUFRO0VBQ3JCLElBQUksUUFBUSxNQUFNLEdBQ2QsT0FBTyxPQUFPLEtBQUssU0FBVSxjQUFjO0dBQ3ZDLElBQUk7SUFDQSxPQUFPLEtBQUssY0FBYyxJQUFJO0dBQ2xDLFNBQ08sS0FBSztJQUNSLEtBQUssTUFBTSxHQUFHO0dBQ2xCO0VBQ0osQ0FBQztFQUVMLE1BQU0sSUFBSSxVQUFVLHdDQUF3QztDQUNoRTtBQUNKOzs7QUNoQkEsU0FBZ0IseUJBQXlCLGFBQWEsUUFBUSxZQUFZLFNBQVMsWUFBWTtDQUMzRixPQUFPLElBQUksbUJBQW1CLGFBQWEsUUFBUSxZQUFZLFNBQVMsVUFBVTtBQUN0RjtBQUNBLElBQUkscUJBQXNCLFNBQVUsUUFBUTtDQUN4QyxVQUFVLG9CQUFvQixNQUFNO0NBQ3BDLFNBQVMsbUJBQW1CLGFBQWEsUUFBUSxZQUFZLFNBQVMsWUFBWSxtQkFBbUI7RUFDakcsSUFBSSxRQUFRLE9BQU8sS0FBSyxNQUFNLFdBQVcsS0FBSztFQUM5QyxNQUFNLGFBQWE7RUFDbkIsTUFBTSxvQkFBb0I7RUFDMUIsTUFBTSxRQUFRLFNBQ1IsU0FBVSxPQUFPO0dBQ2YsSUFBSTtJQUNBLE9BQU8sS0FBSztHQUNoQixTQUNPLEtBQUs7SUFDUixZQUFZLE1BQU0sR0FBRztHQUN6QjtFQUNKLElBQ0UsT0FBTyxVQUFVO0VBQ3ZCLE1BQU0sU0FBUyxVQUNULFNBQVUsS0FBSztHQUNiLElBQUk7SUFDQSxRQUFRLEdBQUc7R0FDZixTQUNPLEtBQUs7SUFDUixZQUFZLE1BQU0sR0FBRztHQUN6QixVQUNRO0lBQ0osS0FBSyxZQUFZO0dBQ3JCO0VBQ0osSUFDRSxPQUFPLFVBQVU7RUFDdkIsTUFBTSxZQUFZLGFBQ1osV0FBWTtHQUNWLElBQUk7SUFDQSxXQUFXO0dBQ2YsU0FDTyxLQUFLO0lBQ1IsWUFBWSxNQUFNLEdBQUc7R0FDekIsVUFDUTtJQUNKLEtBQUssWUFBWTtHQUNyQjtFQUNKLElBQ0UsT0FBTyxVQUFVO0VBQ3ZCLE9BQU87Q0FDWDtDQUNBLG1CQUFtQixVQUFVLGNBQWMsV0FBWTtFQUNuRCxJQUFJO0VBQ0osSUFBSSxDQUFDLEtBQUsscUJBQXFCLEtBQUssa0JBQWtCLEdBQUc7R0FDckQsSUFBSSxXQUFXLEtBQUs7R0FDcEIsT0FBTyxVQUFVLFlBQVksS0FBSyxJQUFJO0dBQ3RDLENBQUMsY0FBYyxLQUFLLEtBQUssZ0JBQWdCLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxLQUFLLElBQUk7RUFDMUY7Q0FDSjtDQUNBLE9BQU87QUFDWCxFQUFFLFVBQVU7OztBQ3hEWixTQUFnQixXQUFXO0NBQ3ZCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLGFBQWE7RUFDakIsT0FBTztFQUNQLElBQUksYUFBYSx5QkFBeUIsWUFBWSxLQUFBLEdBQVcsS0FBQSxHQUFXLEtBQUEsR0FBVyxXQUFZO0dBQy9GLElBQUksQ0FBQyxVQUFVLE9BQU8sYUFBYSxLQUFLLElBQUksRUFBRSxPQUFPLFdBQVc7SUFDNUQsYUFBYTtJQUNiO0dBQ0o7R0FDQSxJQUFJLG1CQUFtQixPQUFPO0dBQzlCLElBQUksT0FBTztHQUNYLGFBQWE7R0FDYixJQUFJLHFCQUFxQixDQUFDLFFBQVEscUJBQXFCLE9BQ25ELGlCQUFpQixZQUFZO0dBRWpDLFdBQVcsWUFBWTtFQUMzQixDQUFDO0VBQ0QsT0FBTyxVQUFVLFVBQVU7RUFDM0IsSUFBSSxDQUFDLFdBQVcsUUFDWixhQUFhLE9BQU8sUUFBUTtDQUVwQyxDQUFDO0FBQ0w7OztBQ2xCQSxJQUFJLHdCQUF5QixTQUFVLFFBQVE7Q0FDM0MsVUFBVSx1QkFBdUIsTUFBTTtDQUN2QyxTQUFTLHNCQUFzQixRQUFRLGdCQUFnQjtFQUNuRCxJQUFJLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUNqQyxNQUFNLFNBQVM7RUFDZixNQUFNLGlCQUFpQjtFQUN2QixNQUFNLFdBQVc7RUFDakIsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sY0FBYztFQUNwQixJQUFJLFFBQVEsTUFBTSxHQUNkLE1BQU0sT0FBTyxPQUFPO0VBRXhCLE9BQU87Q0FDWDtDQUNBLHNCQUFzQixVQUFVLGFBQWEsU0FBVSxZQUFZO0VBQy9ELE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxVQUFVLFVBQVU7Q0FDakQ7Q0FDQSxzQkFBc0IsVUFBVSxhQUFhLFdBQVk7RUFDckQsSUFBSSxVQUFVLEtBQUs7RUFDbkIsSUFBSSxDQUFDLFdBQVcsUUFBUSxXQUNwQixLQUFLLFdBQVcsS0FBSyxlQUFlO0VBRXhDLE9BQU8sS0FBSztDQUNoQjtDQUNBLHNCQUFzQixVQUFVLFlBQVksV0FBWTtFQUNwRCxLQUFLLFlBQVk7RUFDakIsSUFBSSxjQUFjLEtBQUs7RUFDdkIsS0FBSyxXQUFXLEtBQUssY0FBYztFQUNuQyxnQkFBZ0IsUUFBUSxnQkFBZ0IsS0FBSyxLQUFhLFlBQVksWUFBWTtDQUN0RjtDQUNBLHNCQUFzQixVQUFVLFVBQVUsV0FBWTtFQUNsRCxJQUFJLFFBQVE7RUFDWixJQUFJLGFBQWEsS0FBSztFQUN0QixJQUFJLENBQUMsWUFBWTtHQUNiLGFBQWEsS0FBSyxjQUFjLElBQUksYUFBYTtHQUNqRCxJQUFJLFlBQVksS0FBSyxXQUFXO0dBQ2hDLFdBQVcsSUFBSSxLQUFLLE9BQU8sVUFBVSx5QkFBeUIsV0FBVyxLQUFBLEdBQVcsV0FBWTtJQUM1RixNQUFNLFVBQVU7SUFDaEIsVUFBVSxTQUFTO0dBQ3ZCLEdBQUcsU0FBVSxLQUFLO0lBQ2QsTUFBTSxVQUFVO0lBQ2hCLFVBQVUsTUFBTSxHQUFHO0dBQ3ZCLEdBQUcsV0FBWTtJQUFFLE9BQU8sTUFBTSxVQUFVO0dBQUcsQ0FBQyxDQUFDLENBQUM7R0FDOUMsSUFBSSxXQUFXLFFBQVE7SUFDbkIsS0FBSyxjQUFjO0lBQ25CLGFBQWEsYUFBYTtHQUM5QjtFQUNKO0VBQ0EsT0FBTztDQUNYO0NBQ0Esc0JBQXNCLFVBQVUsV0FBVyxXQUFZO0VBQ25ELE9BQU9DLFNBQW9CLENBQUMsQ0FBQyxJQUFJO0NBQ3JDO0NBQ0EsT0FBTztBQUNYLEVBQUUsVUFBVTs7O0FDM0RaLElBQVcsMEJBQTBCLGlCQUFpQixTQUFVLFFBQVE7Q0FDcEUsT0FBTyxTQUFTLDhCQUE4QjtFQUMxQyxPQUFPLElBQUk7RUFDWCxLQUFLLE9BQU87RUFDWixLQUFLLFVBQVU7Q0FDbkI7QUFDSixDQUFDOzs7QUNERCxJQUFJLFVBQVcsU0FBVSxRQUFRO0NBQzdCLFVBQVUsU0FBUyxNQUFNO0NBQ3pCLFNBQVMsVUFBVTtFQUNmLElBQUksUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0VBQ2pDLE1BQU0sU0FBUztFQUNmLE1BQU0sbUJBQW1CO0VBQ3pCLE1BQU0sWUFBWSxDQUFDO0VBQ25CLE1BQU0sWUFBWTtFQUNsQixNQUFNLFdBQVc7RUFDakIsTUFBTSxjQUFjO0VBQ3BCLE9BQU87Q0FDWDtDQUNBLFFBQVEsVUFBVSxPQUFPLFNBQVUsVUFBVTtFQUN6QyxJQUFJLFVBQVUsSUFBSSxpQkFBaUIsTUFBTSxJQUFJO0VBQzdDLFFBQVEsV0FBVztFQUNuQixPQUFPO0NBQ1g7Q0FDQSxRQUFRLFVBQVUsaUJBQWlCLFdBQVk7RUFDM0MsSUFBSSxLQUFLLFFBQ0wsTUFBTSxJQUFJLHdCQUF3QjtDQUUxQztDQUNBLFFBQVEsVUFBVSxPQUFPLFNBQVUsT0FBTztFQUN0QyxJQUFJLFFBQVE7RUFDWixhQUFhLFdBQVk7R0FDckIsSUFBSSxLQUFLO0dBQ1QsTUFBTSxlQUFlO0dBQ3JCLElBQUksQ0FBQyxNQUFNLFdBQVc7SUFDbEIsSUFBSSxDQUFDLE1BQU0sa0JBQ1AsTUFBTSxtQkFBbUIsTUFBTSxLQUFLLE1BQU0sU0FBUztJQUV2RCxJQUFJO0tBQ0EsS0FBSyxJQUFJLEtBQUssU0FBUyxNQUFNLGdCQUFnQixHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsQ0FBQyxHQUFHLE1BQU0sS0FBSyxHQUFHLEtBQUssR0FFbkYsR0FEa0IsTUFDVCxLQUFLLEtBQUs7SUFFM0IsU0FDTyxPQUFPO0tBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTTtJQUFHLFVBQ2hDO0tBQ0osSUFBSTtNQUNBLElBQUksTUFBTSxDQUFDLEdBQUcsU0FBUyxLQUFLLEdBQUcsU0FBUyxHQUFHLEtBQUssRUFBRTtLQUN0RCxVQUNRO01BQUUsSUFBSSxLQUFLLE1BQU0sSUFBSTtLQUFPO0lBQ3hDO0dBQ0o7RUFDSixDQUFDO0NBQ0w7Q0FDQSxRQUFRLFVBQVUsUUFBUSxTQUFVLEtBQUs7RUFDckMsSUFBSSxRQUFRO0VBQ1osYUFBYSxXQUFZO0dBQ3JCLE1BQU0sZUFBZTtHQUNyQixJQUFJLENBQUMsTUFBTSxXQUFXO0lBQ2xCLE1BQU0sV0FBVyxNQUFNLFlBQVk7SUFDbkMsTUFBTSxjQUFjO0lBQ3BCLElBQUksWUFBWSxNQUFNO0lBQ3RCLE9BQU8sVUFBVSxRQUNiLFVBQVUsTUFBTSxDQUFDLENBQUMsTUFBTSxHQUFHO0dBRW5DO0VBQ0osQ0FBQztDQUNMO0NBQ0EsUUFBUSxVQUFVLFdBQVcsV0FBWTtFQUNyQyxJQUFJLFFBQVE7RUFDWixhQUFhLFdBQVk7R0FDckIsTUFBTSxlQUFlO0dBQ3JCLElBQUksQ0FBQyxNQUFNLFdBQVc7SUFDbEIsTUFBTSxZQUFZO0lBQ2xCLElBQUksWUFBWSxNQUFNO0lBQ3RCLE9BQU8sVUFBVSxRQUNiLFVBQVUsTUFBTSxDQUFDLENBQUMsU0FBUztHQUVuQztFQUNKLENBQUM7Q0FDTDtDQUNBLFFBQVEsVUFBVSxjQUFjLFdBQVk7RUFDeEMsS0FBSyxZQUFZLEtBQUssU0FBUztFQUMvQixLQUFLLFlBQVksS0FBSyxtQkFBbUI7Q0FDN0M7Q0FDQSxPQUFPLGVBQWUsUUFBUSxXQUFXLFlBQVk7RUFDakQsS0FBSyxXQUFZO0dBQ2IsSUFBSTtHQUNKLFNBQVMsS0FBSyxLQUFLLGVBQWUsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxVQUFVO0VBQ3BGO0VBQ0EsWUFBWTtFQUNaLGNBQWM7Q0FDbEIsQ0FBQztDQUNELFFBQVEsVUFBVSxnQkFBZ0IsU0FBVSxZQUFZO0VBQ3BELEtBQUssZUFBZTtFQUNwQixPQUFPLE9BQU8sVUFBVSxjQUFjLEtBQUssTUFBTSxVQUFVO0NBQy9EO0NBQ0EsUUFBUSxVQUFVLGFBQWEsU0FBVSxZQUFZO0VBQ2pELEtBQUssZUFBZTtFQUNwQixLQUFLLHdCQUF3QixVQUFVO0VBQ3ZDLE9BQU8sS0FBSyxnQkFBZ0IsVUFBVTtDQUMxQztDQUNBLFFBQVEsVUFBVSxrQkFBa0IsU0FBVSxZQUFZO0VBQ3RELElBQUksUUFBUTtFQUNaLElBQUksS0FBSyxNQUFNLFdBQVcsR0FBRyxVQUFVLFlBQVksR0FBRyxXQUFXLFlBQVksR0FBRztFQUNoRixJQUFJLFlBQVksV0FDWixPQUFPO0VBRVgsS0FBSyxtQkFBbUI7RUFDeEIsVUFBVSxLQUFLLFVBQVU7RUFDekIsT0FBTyxJQUFJLGFBQWEsV0FBWTtHQUNoQyxNQUFNLG1CQUFtQjtHQUN6QixVQUFVLFdBQVcsVUFBVTtFQUNuQyxDQUFDO0NBQ0w7Q0FDQSxRQUFRLFVBQVUsMEJBQTBCLFNBQVUsWUFBWTtFQUM5RCxJQUFJLEtBQUssTUFBTSxXQUFXLEdBQUcsVUFBVSxjQUFjLEdBQUcsYUFBYSxZQUFZLEdBQUc7RUFDcEYsSUFBSSxVQUNBLFdBQVcsTUFBTSxXQUFXO09BRTNCLElBQUksV0FDTCxXQUFXLFNBQVM7Q0FFNUI7Q0FDQSxRQUFRLFVBQVUsZUFBZSxXQUFZO0VBQ3pDLElBQUksYUFBYSxJQUFJLFdBQVc7RUFDaEMsV0FBVyxTQUFTO0VBQ3BCLE9BQU87Q0FDWDtDQUNBLFFBQVEsU0FBUyxTQUFVLGFBQWEsUUFBUTtFQUM1QyxPQUFPLElBQUksaUJBQWlCLGFBQWEsTUFBTTtDQUNuRDtDQUNBLE9BQU87QUFDWCxFQUFFLFVBQVU7QUFFWixJQUFJLG1CQUFvQixTQUFVLFFBQVE7Q0FDdEMsVUFBVSxrQkFBa0IsTUFBTTtDQUNsQyxTQUFTLGlCQUFpQixhQUFhLFFBQVE7RUFDM0MsSUFBSSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDakMsTUFBTSxjQUFjO0VBQ3BCLE1BQU0sU0FBUztFQUNmLE9BQU87Q0FDWDtDQUNBLGlCQUFpQixVQUFVLE9BQU8sU0FBVSxPQUFPO0VBQy9DLElBQUksSUFBSTtFQUNSLENBQUMsTUFBTSxLQUFLLEtBQUssaUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsVUFBVSxRQUFRLE9BQU8sS0FBSyxLQUFhLEdBQUcsS0FBSyxJQUFJLEtBQUs7Q0FDdEk7Q0FDQSxpQkFBaUIsVUFBVSxRQUFRLFNBQVUsS0FBSztFQUM5QyxJQUFJLElBQUk7RUFDUixDQUFDLE1BQU0sS0FBSyxLQUFLLGlCQUFpQixRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLFdBQVcsUUFBUSxPQUFPLEtBQUssS0FBYSxHQUFHLEtBQUssSUFBSSxHQUFHO0NBQ3JJO0NBQ0EsaUJBQWlCLFVBQVUsV0FBVyxXQUFZO0VBQzlDLElBQUksSUFBSTtFQUNSLENBQUMsTUFBTSxLQUFLLEtBQUssaUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsY0FBYyxRQUFRLE9BQU8sS0FBSyxLQUFhLEdBQUcsS0FBSyxFQUFFO0NBQ25JO0NBQ0EsaUJBQWlCLFVBQVUsYUFBYSxTQUFVLFlBQVk7RUFDMUQsSUFBSSxJQUFJO0VBQ1IsUUFBUSxNQUFNLEtBQUssS0FBSyxZQUFZLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsVUFBVSxVQUFVLE9BQU8sUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0NBQ3BJO0NBQ0EsT0FBTztBQUNYLEVBQUUsT0FBTzs7O0FDN0pULElBQUksa0JBQW1CLFNBQVUsUUFBUTtDQUNyQyxVQUFVLGlCQUFpQixNQUFNO0NBQ2pDLFNBQVMsZ0JBQWdCLFFBQVE7RUFDN0IsSUFBSSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDakMsTUFBTSxTQUFTO0VBQ2YsT0FBTztDQUNYO0NBQ0EsT0FBTyxlQUFlLGdCQUFnQixXQUFXLFNBQVM7RUFDdEQsS0FBSyxXQUFZO0dBQ2IsT0FBTyxLQUFLLFNBQVM7RUFDekI7RUFDQSxZQUFZO0VBQ1osY0FBYztDQUNsQixDQUFDO0NBQ0QsZ0JBQWdCLFVBQVUsYUFBYSxTQUFVLFlBQVk7RUFDekQsSUFBSSxlQUFlLE9BQU8sVUFBVSxXQUFXLEtBQUssTUFBTSxVQUFVO0VBQ3BFLENBQUMsYUFBYSxVQUFVLFdBQVcsS0FBSyxLQUFLLE1BQU07RUFDbkQsT0FBTztDQUNYO0NBQ0EsZ0JBQWdCLFVBQVUsV0FBVyxXQUFZO0VBQzdDLElBQUksS0FBSyxNQUFNLFdBQVcsR0FBRyxVQUFVLGNBQWMsR0FBRyxhQUFhLFNBQVMsR0FBRztFQUNqRixJQUFJLFVBQ0EsTUFBTTtFQUVWLEtBQUssZUFBZTtFQUNwQixPQUFPO0NBQ1g7Q0FDQSxnQkFBZ0IsVUFBVSxPQUFPLFNBQVUsT0FBTztFQUM5QyxPQUFPLFVBQVUsS0FBSyxLQUFLLE1BQU8sS0FBSyxTQUFTLEtBQU07Q0FDMUQ7Q0FDQSxPQUFPO0FBQ1gsRUFBRSxPQUFPOzs7QUNqQ1QsSUFBVyx3QkFBd0I7Q0FDL0IsS0FBSyxXQUFZO0VBQ2IsUUFBUSxzQkFBc0IsWUFBWSxLQUFBLENBQU0sSUFBSTtDQUN4RDtDQUNBLFVBQVUsS0FBQTtBQUNkOzs7QUNGQSxJQUFJLGdCQUFpQixTQUFVLFFBQVE7Q0FDbkMsVUFBVSxlQUFlLE1BQU07Q0FDL0IsU0FBUyxjQUFjLGFBQWEsYUFBYSxvQkFBb0I7RUFDakUsSUFBSSxnQkFBZ0IsS0FBSyxHQUFLLGNBQWM7RUFDNUMsSUFBSSxnQkFBZ0IsS0FBSyxHQUFLLGNBQWM7RUFDNUMsSUFBSSx1QkFBdUIsS0FBSyxHQUFLLHFCQUFxQjtFQUMxRCxJQUFJLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUNqQyxNQUFNLGNBQWM7RUFDcEIsTUFBTSxjQUFjO0VBQ3BCLE1BQU0scUJBQXFCO0VBQzNCLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLE1BQU0sc0JBQXNCO0VBQzVCLE1BQU0sc0JBQXNCLGdCQUFnQjtFQUM1QyxNQUFNLGNBQWMsS0FBSyxJQUFJLEdBQUcsV0FBVztFQUMzQyxNQUFNLGNBQWMsS0FBSyxJQUFJLEdBQUcsV0FBVztFQUMzQyxPQUFPO0NBQ1g7Q0FDQSxjQUFjLFVBQVUsT0FBTyxTQUFVLE9BQU87RUFDNUMsSUFBSSxLQUFLLE1BQU0sWUFBWSxHQUFHLFdBQVcsVUFBVSxHQUFHLFNBQVMsc0JBQXNCLEdBQUcscUJBQXFCLHFCQUFxQixHQUFHLG9CQUFvQixjQUFjLEdBQUc7RUFDMUssSUFBSSxDQUFDLFdBQVc7R0FDWixRQUFRLEtBQUssS0FBSztHQUNsQixDQUFDLHVCQUF1QixRQUFRLEtBQUssbUJBQW1CLElBQUksSUFBSSxXQUFXO0VBQy9FO0VBQ0EsS0FBSyxZQUFZO0VBQ2pCLE9BQU8sVUFBVSxLQUFLLEtBQUssTUFBTSxLQUFLO0NBQzFDO0NBQ0EsY0FBYyxVQUFVLGFBQWEsU0FBVSxZQUFZO0VBQ3ZELEtBQUssZUFBZTtFQUNwQixLQUFLLFlBQVk7RUFDakIsSUFBSSxlQUFlLEtBQUssZ0JBQWdCLFVBQVU7RUFDbEQsSUFBSSxLQUFLLE1BQU0sc0JBQXNCLEdBQUc7RUFDeEMsSUFBSSxPQURtRSxHQUFHLFFBQ3ZELE1BQU07RUFDekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxDQUFDLFdBQVcsUUFBUSxLQUFLLHNCQUFzQixJQUFJLEdBQ2xGLFdBQVcsS0FBSyxLQUFLLEVBQUU7RUFFM0IsS0FBSyx3QkFBd0IsVUFBVTtFQUN2QyxPQUFPO0NBQ1g7Q0FDQSxjQUFjLFVBQVUsY0FBYyxXQUFZO0VBQzlDLElBQUksS0FBSyxNQUFNLGNBQWMsR0FBRyxhQUFhLHFCQUFxQixHQUFHLG9CQUFvQixVQUFVLEdBQUcsU0FBUyxzQkFBc0IsR0FBRztFQUN4SSxJQUFJLHNCQUFzQixzQkFBc0IsSUFBSSxLQUFLO0VBQ3pELGNBQWMsWUFBWSxxQkFBcUIsUUFBUSxVQUFVLFFBQVEsT0FBTyxHQUFHLFFBQVEsU0FBUyxrQkFBa0I7RUFDdEgsSUFBSSxDQUFDLHFCQUFxQjtHQUN0QixJQUFJLE1BQU0sbUJBQW1CLElBQUk7R0FDakMsSUFBSSxPQUFPO0dBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsVUFBVSxRQUFRLE1BQU0sS0FBSyxLQUFLLEdBQzFELE9BQU87R0FFWCxRQUFRLFFBQVEsT0FBTyxHQUFHLE9BQU8sQ0FBQztFQUN0QztDQUNKO0NBQ0EsT0FBTztBQUNYLEVBQUUsT0FBTzs7O0FDckRULElBQUksZUFBZ0IsU0FBVSxRQUFRO0NBQ2xDLFVBQVUsY0FBYyxNQUFNO0NBQzlCLFNBQVMsZUFBZTtFQUNwQixJQUFJLFFBQVEsV0FBVyxRQUFRLE9BQU8sTUFBTSxNQUFNLFNBQVMsS0FBSztFQUNoRSxNQUFNLFNBQVM7RUFDZixNQUFNLFlBQVk7RUFDbEIsTUFBTSxjQUFjO0VBQ3BCLE9BQU87Q0FDWDtDQUNBLGFBQWEsVUFBVSwwQkFBMEIsU0FBVSxZQUFZO0VBQ25FLElBQUksS0FBSyxNQUFNLFdBQVcsR0FBRyxVQUFVLFlBQVksR0FBRyxXQUFXLFNBQVMsR0FBRyxRQUFRLGNBQWMsR0FBRyxhQUFhLFlBQVksR0FBRyxXQUFXLGNBQWMsR0FBRztFQUM5SixJQUFJLFVBQ0EsV0FBVyxNQUFNLFdBQVc7T0FFM0IsSUFBSSxhQUFhLGFBQWE7R0FDL0IsYUFBYSxXQUFXLEtBQUssTUFBTTtHQUNuQyxXQUFXLFNBQVM7RUFDeEI7Q0FDSjtDQUNBLGFBQWEsVUFBVSxPQUFPLFNBQVUsT0FBTztFQUMzQyxJQUFJLENBQUMsS0FBSyxXQUFXO0dBQ2pCLEtBQUssU0FBUztHQUNkLEtBQUssWUFBWTtFQUNyQjtDQUNKO0NBQ0EsYUFBYSxVQUFVLFdBQVcsV0FBWTtFQUMxQyxJQUFJLEtBQUssTUFBTSxZQUFZLEdBQUcsV0FBVyxTQUFTLEdBQUc7RUFDckQsSUFBSSxDQUR1RSxHQUFHLGFBQzVEO0dBQ2QsS0FBSyxjQUFjO0dBQ25CLGFBQWEsT0FBTyxVQUFVLEtBQUssS0FBSyxNQUFNLE1BQU07R0FDcEQsT0FBTyxVQUFVLFNBQVMsS0FBSyxJQUFJO0VBQ3ZDO0NBQ0o7Q0FDQSxPQUFPO0FBQ1gsRUFBRSxPQUFPOzs7QUNsQ1QsSUFBSSxTQUFVLFNBQVUsUUFBUTtDQUM1QixVQUFVLFFBQVEsTUFBTTtDQUN4QixTQUFTLE9BQU8sV0FBVyxNQUFNO0VBQzdCLE9BQU8sT0FBTyxLQUFLLElBQUksS0FBSztDQUNoQztDQUNBLE9BQU8sVUFBVSxXQUFXLFNBQVUsT0FBTyxPQUFPO0VBQ2hELElBQUksVUFBVSxLQUFLLEdBQUssUUFBUTtFQUNoQyxPQUFPO0NBQ1g7Q0FDQSxPQUFPO0FBQ1gsRUFBRSxZQUFZOzs7QUNYZCxJQUFXLG1CQUFtQjtDQUMxQixhQUFhLFNBQVUsU0FBUyxTQUFTO0VBQ3JDLElBQUksT0FBTyxDQUFDO0VBQ1osS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxLQUFLLEtBQUssS0FBSyxVQUFVO0VBRTdCLElBQUksV0FBVyxpQkFBaUI7RUFDaEMsSUFBSSxhQUFhLFFBQVEsYUFBYSxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsYUFDN0QsT0FBTyxTQUFTLFlBQVksTUFBTSxVQUFVLGNBQWMsQ0FBQyxTQUFTLE9BQU8sR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDO0VBRS9GLE9BQU8sWUFBWSxNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsU0FBUyxPQUFPLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQztDQUNwRjtDQUNBLGVBQWUsU0FBVSxRQUFRO0VBQzdCLElBQUksV0FBVyxpQkFBaUI7RUFDaEMsU0FBUyxhQUFhLFFBQVEsYUFBYSxLQUFLLElBQUksS0FBSyxJQUFJLFNBQVMsa0JBQWtCLGNBQUEsQ0FBZSxNQUFNO0NBQ2pIO0NBQ0EsVUFBVSxLQUFBO0FBQ2Q7OztBQ2RBLElBQUksY0FBZSxTQUFVLFFBQVE7Q0FDakMsVUFBVSxhQUFhLE1BQU07Q0FDN0IsU0FBUyxZQUFZLFdBQVcsTUFBTTtFQUNsQyxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0sV0FBVyxJQUFJLEtBQUs7RUFDbEQsTUFBTSxZQUFZO0VBQ2xCLE1BQU0sT0FBTztFQUNiLE1BQU0sVUFBVTtFQUNoQixPQUFPO0NBQ1g7Q0FDQSxZQUFZLFVBQVUsV0FBVyxTQUFVLE9BQU8sT0FBTztFQUNyRCxJQUFJO0VBQ0osSUFBSSxVQUFVLEtBQUssR0FBSyxRQUFRO0VBQ2hDLElBQUksS0FBSyxRQUNMLE9BQU87RUFFWCxLQUFLLFFBQVE7RUFDYixJQUFJLEtBQUssS0FBSztFQUNkLElBQUksWUFBWSxLQUFLO0VBQ3JCLElBQUksTUFBTSxNQUNOLEtBQUssS0FBSyxLQUFLLGVBQWUsV0FBVyxJQUFJLEtBQUs7RUFFdEQsS0FBSyxVQUFVO0VBQ2YsS0FBSyxRQUFRO0VBQ2IsS0FBSyxNQUFNLEtBQUssS0FBSyxRQUFRLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxLQUFLLGVBQWUsV0FBVyxLQUFLLElBQUksS0FBSztFQUN2RyxPQUFPO0NBQ1g7Q0FDQSxZQUFZLFVBQVUsaUJBQWlCLFNBQVUsV0FBVyxLQUFLLE9BQU87RUFDcEUsSUFBSSxVQUFVLEtBQUssR0FBSyxRQUFRO0VBQ2hDLE9BQU8saUJBQWlCLFlBQVksVUFBVSxNQUFNLEtBQUssV0FBVyxJQUFJLEdBQUcsS0FBSztDQUNwRjtDQUNBLFlBQVksVUFBVSxpQkFBaUIsU0FBVSxZQUFZLElBQUksT0FBTztFQUNwRSxJQUFJLFVBQVUsS0FBSyxHQUFLLFFBQVE7RUFDaEMsSUFBSSxTQUFTLFFBQVEsS0FBSyxVQUFVLFNBQVMsS0FBSyxZQUFZLE9BQzFELE9BQU87RUFFWCxJQUFJLE1BQU0sTUFDTixpQkFBaUIsY0FBYyxFQUFFO0NBR3pDO0NBQ0EsWUFBWSxVQUFVLFVBQVUsU0FBVSxPQUFPLE9BQU87RUFDcEQsSUFBSSxLQUFLLFFBQ0wsdUJBQU8sSUFBSSxNQUFNLDhCQUE4QjtFQUVuRCxLQUFLLFVBQVU7RUFDZixJQUFJLFFBQVEsS0FBSyxTQUFTLE9BQU8sS0FBSztFQUN0QyxJQUFJLE9BQ0EsT0FBTztPQUVOLElBQUksS0FBSyxZQUFZLFNBQVMsS0FBSyxNQUFNLE1BQzFDLEtBQUssS0FBSyxLQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssSUFBSSxJQUFJO0NBRW5FO0NBQ0EsWUFBWSxVQUFVLFdBQVcsU0FBVSxPQUFPLFFBQVE7RUFDdEQsSUFBSSxVQUFVO0VBQ2QsSUFBSTtFQUNKLElBQUk7R0FDQSxLQUFLLEtBQUssS0FBSztFQUNuQixTQUNPLEdBQUc7R0FDTixVQUFVO0dBQ1YsYUFBYSxJQUFJLG9CQUFJLElBQUksTUFBTSxvQ0FBb0M7RUFDdkU7RUFDQSxJQUFJLFNBQVM7R0FDVCxLQUFLLFlBQVk7R0FDakIsT0FBTztFQUNYO0NBQ0o7Q0FDQSxZQUFZLFVBQVUsY0FBYyxXQUFZO0VBQzVDLElBQUksQ0FBQyxLQUFLLFFBQVE7R0FDZCxJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUcsSUFBSSxZQUFZLEdBQUc7R0FDMUMsSUFBSSxVQUFVLFVBQVU7R0FDeEIsS0FBSyxPQUFPLEtBQUssUUFBUSxLQUFLLFlBQVk7R0FDMUMsS0FBSyxVQUFVO0dBQ2YsVUFBVSxTQUFTLElBQUk7R0FDdkIsSUFBSSxNQUFNLE1BQ04sS0FBSyxLQUFLLEtBQUssZUFBZSxXQUFXLElBQUksSUFBSTtHQUVyRCxLQUFLLFFBQVE7R0FDYixPQUFPLFVBQVUsWUFBWSxLQUFLLElBQUk7RUFDMUM7Q0FDSjtDQUNBLE9BQU87QUFDWCxFQUFFLE1BQU07OztBQ3RGUixJQUFJLFlBQWEsV0FBWTtDQUN6QixTQUFTLFVBQVUscUJBQXFCLEtBQUs7RUFDekMsSUFBSSxRQUFRLEtBQUssR0FBSyxNQUFNLFVBQVU7RUFDdEMsS0FBSyxzQkFBc0I7RUFDM0IsS0FBSyxNQUFNO0NBQ2Y7Q0FDQSxVQUFVLFVBQVUsV0FBVyxTQUFVLE1BQU0sT0FBTyxPQUFPO0VBQ3pELElBQUksVUFBVSxLQUFLLEdBQUssUUFBUTtFQUNoQyxPQUFPLElBQUksS0FBSyxvQkFBb0IsTUFBTSxJQUFJLENBQUMsQ0FBQyxTQUFTLE9BQU8sS0FBSztDQUN6RTtDQUNBLFVBQVUsTUFBTSxzQkFBc0I7Q0FDdEMsT0FBTztBQUNYLEVBQUU7OztBQ1hGLElBQUksaUJBQWtCLFNBQVUsUUFBUTtDQUNwQyxVQUFVLGdCQUFnQixNQUFNO0NBQ2hDLFNBQVMsZUFBZSxpQkFBaUIsS0FBSztFQUMxQyxJQUFJLFFBQVEsS0FBSyxHQUFLLE1BQU0sVUFBVTtFQUN0QyxJQUFJLFFBQVEsT0FBTyxLQUFLLE1BQU0saUJBQWlCLEdBQUcsS0FBSztFQUN2RCxNQUFNLFVBQVUsQ0FBQztFQUNqQixNQUFNLFVBQVU7RUFDaEIsT0FBTztDQUNYO0NBQ0EsZUFBZSxVQUFVLFFBQVEsU0FBVSxRQUFRO0VBQy9DLElBQUksVUFBVSxLQUFLO0VBQ25CLElBQUksS0FBSyxTQUFTO0dBQ2QsUUFBUSxLQUFLLE1BQU07R0FDbkI7RUFDSjtFQUNBLElBQUk7RUFDSixLQUFLLFVBQVU7RUFDZjtHQUNJLElBQUssUUFBUSxPQUFPLFFBQVEsT0FBTyxPQUFPLE9BQU8sS0FBSyxHQUNsRDtTQUVFLFNBQVMsUUFBUSxNQUFNO0VBQ2pDLEtBQUssVUFBVTtFQUNmLElBQUksT0FBTztHQUNQLE9BQVEsU0FBUyxRQUFRLE1BQU0sR0FDM0IsT0FBTyxZQUFZO0dBRXZCLE1BQU07RUFDVjtDQUNKO0NBQ0EsT0FBTztBQUNYLEVBQUUsU0FBUzs7O0FDL0JYLElBQVcsaUJBQWlCLElBQUksZUFBZSxXQUFXO0FBQzFELElBQVcsUUFBUTs7O0FDRm5CLElBQVcsUUFBUSxJQUFJLFdBQVcsU0FBVSxZQUFZO0NBQUUsT0FBTyxXQUFXLFNBQVM7QUFBRyxDQUFDO0FBQ3pGLFNBQWdCLE1BQU0sV0FBVztDQUM3QixPQUFPLFlBQVksZUFBZSxTQUFTLElBQUk7QUFDbkQ7QUFDQSxTQUFTLGVBQWUsV0FBVztDQUMvQixPQUFPLElBQUksV0FBVyxTQUFVLFlBQVk7RUFBRSxPQUFPLFVBQVUsU0FBUyxXQUFZO0dBQUUsT0FBTyxXQUFXLFNBQVM7RUFBRyxDQUFDO0NBQUcsQ0FBQztBQUM3SDs7O0FDTkEsU0FBZ0IsWUFBWSxPQUFPO0NBQy9CLE9BQU8sU0FBUyxXQUFXLE1BQU0sUUFBUTtBQUM3Qzs7O0FDREEsU0FBU0MsT0FBSyxLQUFLO0NBQ2YsT0FBTyxJQUFJLElBQUksU0FBUztBQUM1QjtBQUNBLFNBQWdCLGtCQUFrQixNQUFNO0NBQ3BDLE9BQU8sV0FBV0EsT0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFBO0FBQ2pEO0FBQ0EsU0FBZ0IsYUFBYSxNQUFNO0NBQy9CLE9BQU8sWUFBWUEsT0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFBO0FBQ2xEO0FBQ0EsU0FBZ0IsVUFBVSxNQUFNLGNBQWM7Q0FDMUMsT0FBTyxPQUFPQSxPQUFLLElBQUksTUFBTSxXQUFXLEtBQUssSUFBSSxJQUFJO0FBQ3pEOzs7QUNiQSxJQUFXLGVBQWUsU0FBVSxHQUFHO0NBQUUsT0FBTyxLQUFLLE9BQU8sRUFBRSxXQUFXLFlBQVksT0FBTyxNQUFNO0FBQVk7OztBQ0M5RyxTQUFnQixVQUFVLE9BQU87Q0FDN0IsT0FBTyxXQUFXLFVBQVUsUUFBUSxVQUFVLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJO0FBQzlFOzs7QUNEQSxTQUFnQixvQkFBb0IsT0FBTztDQUN2QyxPQUFPLFdBQVcsTUFBTUMsV0FBa0I7QUFDOUM7OztBQ0hBLFNBQWdCLGdCQUFnQixLQUFLO0NBQ2pDLE9BQU8sT0FBTyxpQkFBaUIsV0FBVyxRQUFRLFFBQVEsUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksT0FBTyxjQUFjO0FBQ2pIOzs7QUNIQSxTQUFnQixpQ0FBaUMsT0FBTztDQUNwRCx1QkFBTyxJQUFJLFVBQVUsbUJBQW1CLFVBQVUsUUFBUSxPQUFPLFVBQVUsV0FBVyxzQkFBc0IsTUFBTSxRQUFRLE9BQU8sMEhBQTBIO0FBQy9QOzs7QUNGQSxTQUFnQixvQkFBb0I7Q0FDaEMsSUFBSSxPQUFPLFdBQVcsY0FBYyxDQUFDLE9BQU8sVUFDeEMsT0FBTztDQUVYLE9BQU8sT0FBTztBQUNsQjtBQUNBLElBQVcsV0FBVyxrQkFBa0I7OztBQ0p4QyxTQUFnQixXQUFXLE9BQU87Q0FDOUIsT0FBTyxXQUFXLFVBQVUsUUFBUSxVQUFVLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTUMsU0FBZ0I7QUFDMUY7OztBQ0ZBLFNBQWdCLG1DQUFtQyxnQkFBZ0I7Q0FDL0QsT0FBTyxpQkFBaUIsTUFBTSxXQUFXLFNBQVMsdUNBQXVDO0VBQ3JGLElBQUksUUFBUSxJQUFJLE9BQU87RUFDdkIsT0FBTyxZQUFZLE1BQU0sU0FBVSxJQUFJO0dBQ25DLFFBQVEsR0FBRyxPQUFYO0lBQ0ksS0FBSztLQUNELFNBQVMsZUFBZSxVQUFVO0tBQ2xDLEdBQUcsUUFBUTtJQUNmLEtBQUs7S0FDRCxHQUFHLEtBQUssS0FBSztNQUFDOztNQUFLO01BQUc7S0FBRSxDQUFDO0tBQ3pCLEdBQUcsUUFBUTtJQUNmLEtBQUssR0FFRCxPQUFPLENBQUMsR0FBRyxRQUFRLE9BQU8sS0FBSyxDQUFDLENBQUM7SUFDckMsS0FBSztLQUNELEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxHQUFHLE9BQU8sT0FBTyxHQUFHO0tBQzVDLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7S0FDdkIsT0FBTyxDQUFDLEdBQUcsUUFBUSxLQUFLLENBQUMsQ0FBQztJQUM5QixLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUM7SUFDNUIsS0FBSyxHQUFHLE9BQU8sQ0FBQyxHQUFHLFFBQVEsS0FBSyxDQUFDO0lBQ2pDLEtBQUssR0FBRyxPQUFPLENBQUMsR0FBRyxHQUFHLEtBQUssQ0FBQztJQUM1QixLQUFLO0tBQ0QsR0FBRyxLQUFLO0tBQ1IsT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNoQixLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBRTtJQUNyQixLQUFLO0tBQ0QsT0FBTyxZQUFZO0tBQ25CLE9BQU8sQ0FBQyxDQUFDO0lBQ2IsS0FBSyxJQUFJLE9BQU8sQ0FBQyxDQUFDO0dBQ3RCO0VBQ0osQ0FBQztDQUNMLENBQUM7QUFDTDtBQUNBLFNBQWdCLHFCQUFxQixLQUFLO0NBQ3RDLE9BQU8sV0FBVyxRQUFRLFFBQVEsUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksU0FBUztBQUM3RTs7O0FDekJBLFNBQWdCLFVBQVUsT0FBTztDQUM3QixJQUFJLGlCQUFpQixZQUNqQixPQUFPO0NBRVgsSUFBSSxTQUFTLE1BQU07RUFDZixJQUFJLG9CQUFvQixLQUFLLEdBQ3pCLE9BQU8sc0JBQXNCLEtBQUs7RUFFdEMsSUFBSSxZQUFZLEtBQUssR0FDakIsT0FBTyxjQUFjLEtBQUs7RUFFOUIsSUFBSSxVQUFVLEtBQUssR0FDZixPQUFPLFlBQVksS0FBSztFQUU1QixJQUFJLGdCQUFnQixLQUFLLEdBQ3JCLE9BQU8sa0JBQWtCLEtBQUs7RUFFbEMsSUFBSSxXQUFXLEtBQUssR0FDaEIsT0FBTyxhQUFhLEtBQUs7RUFFN0IsSUFBSSxxQkFBcUIsS0FBSyxHQUMxQixPQUFPLHVCQUF1QixLQUFLO0NBRTNDO0NBQ0EsTUFBTSxpQ0FBaUMsS0FBSztBQUNoRDtBQUNBLFNBQWdCLHNCQUFzQixLQUFLO0NBQ3ZDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxJQUFJLE1BQU0sSUFBSUMsV0FBa0IsQ0FBQztFQUNqQyxJQUFJLFdBQVcsSUFBSSxTQUFTLEdBQ3hCLE9BQU8sSUFBSSxVQUFVLFVBQVU7RUFFbkMsTUFBTSxJQUFJLFVBQVUsZ0VBQWdFO0NBQ3hGLENBQUM7QUFDTDtBQUNBLFNBQWdCLGNBQWMsT0FBTztDQUNqQyxPQUFPLElBQUksV0FBVyxTQUFVLFlBQVk7RUFDeEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sVUFBVSxDQUFDLFdBQVcsUUFBUSxLQUNwRCxXQUFXLEtBQUssTUFBTSxFQUFFO0VBRTVCLFdBQVcsU0FBUztDQUN4QixDQUFDO0FBQ0w7QUFDQSxTQUFnQixZQUFZLFNBQVM7Q0FDakMsT0FBTyxJQUFJLFdBQVcsU0FBVSxZQUFZO0VBQ3hDLFFBQ0ssS0FBSyxTQUFVLE9BQU87R0FDdkIsSUFBSSxDQUFDLFdBQVcsUUFBUTtJQUNwQixXQUFXLEtBQUssS0FBSztJQUNyQixXQUFXLFNBQVM7R0FDeEI7RUFDSixHQUFHLFNBQVUsS0FBSztHQUFFLE9BQU8sV0FBVyxNQUFNLEdBQUc7RUFBRyxDQUFDLENBQUMsQ0FDL0MsS0FBSyxNQUFNLG9CQUFvQjtDQUN4QyxDQUFDO0FBQ0w7QUFDQSxTQUFnQixhQUFhLFVBQVU7Q0FDbkMsT0FBTyxJQUFJLFdBQVcsU0FBVSxZQUFZO0VBQ3hDLElBQUksS0FBSztFQUNULElBQUk7R0FDQSxLQUFLLElBQUksYUFBYSxTQUFTLFFBQVEsR0FBRyxlQUFlLFdBQVcsS0FBSyxHQUFHLENBQUMsYUFBYSxNQUFNLGVBQWUsV0FBVyxLQUFLLEdBQUc7SUFDOUgsSUFBSSxRQUFRLGFBQWE7SUFDekIsV0FBVyxLQUFLLEtBQUs7SUFDckIsSUFBSSxXQUFXLFFBQ1g7R0FFUjtFQUNKLFNBQ08sT0FBTztHQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU07RUFBRyxVQUNoQztHQUNKLElBQUk7SUFDQSxJQUFJLGdCQUFnQixDQUFDLGFBQWEsU0FBUyxLQUFLLFdBQVcsU0FBUyxHQUFHLEtBQUssVUFBVTtHQUMxRixVQUNRO0lBQUUsSUFBSSxLQUFLLE1BQU0sSUFBSTtHQUFPO0VBQ3hDO0VBQ0EsV0FBVyxTQUFTO0NBQ3hCLENBQUM7QUFDTDtBQUNBLFNBQWdCLGtCQUFrQixlQUFlO0NBQzdDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxRQUFRLGVBQWUsVUFBVSxDQUFDLENBQUMsTUFBTSxTQUFVLEtBQUs7R0FBRSxPQUFPLFdBQVcsTUFBTSxHQUFHO0VBQUcsQ0FBQztDQUM3RixDQUFDO0FBQ0w7QUFDQSxTQUFnQix1QkFBdUIsZ0JBQWdCO0NBQ25ELE9BQU8sa0JBQWtCLG1DQUFtQyxjQUFjLENBQUM7QUFDL0U7QUFDQSxTQUFTLFFBQVEsZUFBZSxZQUFZO0NBQ3hDLElBQUksaUJBQWlCO0NBQ3JCLElBQUksS0FBSztDQUNULE9BQU8sVUFBVSxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsV0FBWTtFQUMvQyxJQUFJLE9BQU87RUFDWCxPQUFPLFlBQVksTUFBTSxTQUFVLElBQUk7R0FDbkMsUUFBUSxHQUFHLE9BQVg7SUFDSSxLQUFLO0tBQ0QsR0FBRyxLQUFLLEtBQUs7TUFBQztNQUFHO01BQUc7TUFBRztLQUFFLENBQUM7S0FDMUIsa0JBQWtCLGNBQWMsYUFBYTtLQUM3QyxHQUFHLFFBQVE7SUFDZixLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztJQUN6QyxLQUFLO0tBQ0QsSUFBSSxFQUFFLG9CQUFvQixHQUFHLEtBQUssR0FBRyxDQUFDLGtCQUFrQixPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUM7S0FDM0UsUUFBUSxrQkFBa0I7S0FDMUIsV0FBVyxLQUFLLEtBQUs7S0FDckIsSUFBSSxXQUFXLFFBQ1gsT0FBTyxDQUFDLENBQUM7S0FFYixHQUFHLFFBQVE7SUFDZixLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQztJQUNwQixLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsRUFBRTtJQUNyQixLQUFLO0tBQ0QsUUFBUSxHQUFHLEtBQUs7S0FDaEIsTUFBTSxFQUFFLE9BQU8sTUFBTTtLQUNyQixPQUFPLENBQUMsR0FBRyxFQUFFO0lBQ2pCLEtBQUs7S0FDRCxHQUFHLEtBQUssS0FBSztNQUFDOztNQUFLO01BQUc7S0FBRSxDQUFDO0tBQ3pCLElBQUksRUFBRSxxQkFBcUIsQ0FBQyxrQkFBa0IsU0FBUyxLQUFLLGdCQUFnQixVQUFVLE9BQU8sQ0FBQyxHQUFHLENBQUM7S0FDbEcsT0FBTyxDQUFDLEdBQUcsR0FBRyxLQUFLLGVBQWUsQ0FBQztJQUN2QyxLQUFLO0tBQ0QsR0FBRyxLQUFLO0tBQ1IsR0FBRyxRQUFRO0lBQ2YsS0FBSyxHQUFHLE9BQU8sQ0FBQyxHQUFHLEVBQUU7SUFDckIsS0FBSztLQUNELElBQUksS0FBSyxNQUFNLElBQUk7S0FDbkIsT0FBTyxDQUFDLENBQUM7SUFDYixLQUFLLElBQUksT0FBTyxDQUFDLENBQUM7SUFDbEIsS0FBSztLQUNELFdBQVcsU0FBUztLQUNwQixPQUFPLENBQUMsQ0FBQztHQUNqQjtFQUNKLENBQUM7Q0FDTCxDQUFDO0FBQ0w7OztBQzdJQSxTQUFnQixnQkFBZ0Isb0JBQW9CLFdBQVcsTUFBTSxPQUFPLFFBQVE7Q0FDaEYsSUFBSSxVQUFVLEtBQUssR0FBSyxRQUFRO0NBQ2hDLElBQUksV0FBVyxLQUFLLEdBQUssU0FBUztDQUNsQyxJQUFJLHVCQUF1QixVQUFVLFNBQVMsV0FBWTtFQUN0RCxLQUFLO0VBQ0wsSUFBSSxRQUNBLG1CQUFtQixJQUFJLEtBQUssU0FBUyxNQUFNLEtBQUssQ0FBQztPQUdqRCxLQUFLLFlBQVk7Q0FFekIsR0FBRyxLQUFLO0NBQ1IsbUJBQW1CLElBQUksb0JBQW9CO0NBQzNDLElBQUksQ0FBQyxRQUNELE9BQU87QUFFZjs7O0FDYkEsU0FBZ0IsVUFBVSxXQUFXLE9BQU87Q0FDeEMsSUFBSSxVQUFVLEtBQUssR0FBSyxRQUFRO0NBQ2hDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQUUsT0FBTyxnQkFBZ0IsWUFBWSxXQUFXLFdBQVk7SUFBRSxPQUFPLFdBQVcsS0FBSyxLQUFLO0dBQUcsR0FBRyxLQUFLO0VBQUcsR0FBRyxXQUFZO0dBQUUsT0FBTyxnQkFBZ0IsWUFBWSxXQUFXLFdBQVk7SUFBRSxPQUFPLFdBQVcsU0FBUztHQUFHLEdBQUcsS0FBSztFQUFHLEdBQUcsU0FBVSxLQUFLO0dBQUUsT0FBTyxnQkFBZ0IsWUFBWSxXQUFXLFdBQVk7SUFBRSxPQUFPLFdBQVcsTUFBTSxHQUFHO0dBQUcsR0FBRyxLQUFLO0VBQUcsQ0FBQyxDQUFDO0NBQ3BhLENBQUM7QUFDTDs7O0FDUEEsU0FBZ0IsWUFBWSxXQUFXLE9BQU87Q0FDMUMsSUFBSSxVQUFVLEtBQUssR0FBSyxRQUFRO0NBQ2hDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxXQUFXLElBQUksVUFBVSxTQUFTLFdBQVk7R0FBRSxPQUFPLE9BQU8sVUFBVSxVQUFVO0VBQUcsR0FBRyxLQUFLLENBQUM7Q0FDbEcsQ0FBQztBQUNMOzs7QUNIQSxTQUFnQixtQkFBbUIsT0FBTyxXQUFXO0NBQ2pELE9BQU8sVUFBVSxLQUFLLENBQUMsQ0FBQyxLQUFLLFlBQVksU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBQzdFOzs7QUNGQSxTQUFnQixnQkFBZ0IsT0FBTyxXQUFXO0NBQzlDLE9BQU8sVUFBVSxLQUFLLENBQUMsQ0FBQyxLQUFLLFlBQVksU0FBUyxHQUFHLFVBQVUsU0FBUyxDQUFDO0FBQzdFOzs7QUNKQSxTQUFnQixjQUFjLE9BQU8sV0FBVztDQUM1QyxPQUFPLElBQUksV0FBVyxTQUFVLFlBQVk7RUFDeEMsSUFBSSxJQUFJO0VBQ1IsT0FBTyxVQUFVLFNBQVMsV0FBWTtHQUNsQyxJQUFJLE1BQU0sTUFBTSxRQUNaLFdBQVcsU0FBUztRQUVuQjtJQUNELFdBQVcsS0FBSyxNQUFNLElBQUk7SUFDMUIsSUFBSSxDQUFDLFdBQVcsUUFDWixLQUFLLFNBQVM7R0FFdEI7RUFDSixDQUFDO0NBQ0wsQ0FBQztBQUNMOzs7QUNaQSxTQUFnQixpQkFBaUIsT0FBTyxXQUFXO0NBQy9DLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxJQUFJQztFQUNKLGdCQUFnQixZQUFZLFdBQVcsV0FBWTtHQUMvQyxhQUFXLE1BQU1DLFNBQWdCLENBQUM7R0FDbEMsZ0JBQWdCLFlBQVksV0FBVyxXQUFZO0lBQy9DLElBQUk7SUFDSixJQUFJO0lBQ0osSUFBSTtJQUNKLElBQUk7S0FDQSxLQUFNRCxXQUFTLEtBQUssR0FBRyxRQUFRLEdBQUcsT0FBTyxPQUFPLEdBQUc7SUFDdkQsU0FDTyxLQUFLO0tBQ1IsV0FBVyxNQUFNLEdBQUc7S0FDcEI7SUFDSjtJQUNBLElBQUksTUFDQSxXQUFXLFNBQVM7U0FHcEIsV0FBVyxLQUFLLEtBQUs7R0FFN0IsR0FBRyxHQUFHLElBQUk7RUFDZCxDQUFDO0VBQ0QsT0FBTyxXQUFZO0dBQUUsT0FBTyxXQUFXQSxlQUFhLFFBQVFBLGVBQWEsS0FBSyxJQUFJLEtBQUssSUFBSUEsV0FBUyxNQUFNLEtBQUtBLFdBQVMsT0FBTztFQUFHO0NBQ3RJLENBQUM7QUFDTDs7O0FDNUJBLFNBQWdCLHNCQUFzQixPQUFPLFdBQVc7Q0FDcEQsSUFBSSxDQUFDLE9BQ0QsTUFBTSxJQUFJLE1BQU0seUJBQXlCO0NBRTdDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxnQkFBZ0IsWUFBWSxXQUFXLFdBQVk7R0FDL0MsSUFBSSxXQUFXLE1BQU0sT0FBTyxjQUFjLENBQUM7R0FDM0MsZ0JBQWdCLFlBQVksV0FBVyxXQUFZO0lBQy9DLFNBQVMsS0FBSyxDQUFDLENBQUMsS0FBSyxTQUFVLFFBQVE7S0FDbkMsSUFBSSxPQUFPLE1BQ1AsV0FBVyxTQUFTO1VBR3BCLFdBQVcsS0FBSyxPQUFPLEtBQUs7SUFFcEMsQ0FBQztHQUNMLEdBQUcsR0FBRyxJQUFJO0VBQ2QsQ0FBQztDQUNMLENBQUM7QUFDTDs7O0FDbkJBLFNBQWdCLDJCQUEyQixPQUFPLFdBQVc7Q0FDekQsT0FBTyxzQkFBc0IsbUNBQW1DLEtBQUssR0FBRyxTQUFTO0FBQ3JGOzs7QUNTQSxTQUFnQixVQUFVLE9BQU8sV0FBVztDQUN4QyxJQUFJLFNBQVMsTUFBTTtFQUNmLElBQUksb0JBQW9CLEtBQUssR0FDekIsT0FBTyxtQkFBbUIsT0FBTyxTQUFTO0VBRTlDLElBQUksWUFBWSxLQUFLLEdBQ2pCLE9BQU8sY0FBYyxPQUFPLFNBQVM7RUFFekMsSUFBSSxVQUFVLEtBQUssR0FDZixPQUFPLGdCQUFnQixPQUFPLFNBQVM7RUFFM0MsSUFBSSxnQkFBZ0IsS0FBSyxHQUNyQixPQUFPLHNCQUFzQixPQUFPLFNBQVM7RUFFakQsSUFBSSxXQUFXLEtBQUssR0FDaEIsT0FBTyxpQkFBaUIsT0FBTyxTQUFTO0VBRTVDLElBQUkscUJBQXFCLEtBQUssR0FDMUIsT0FBTywyQkFBMkIsT0FBTyxTQUFTO0NBRTFEO0NBQ0EsTUFBTSxpQ0FBaUMsS0FBSztBQUNoRDs7O0FDakNBLFNBQWdCLEtBQUssT0FBTyxXQUFXO0NBQ25DLE9BQU8sWUFBWSxVQUFVLE9BQU8sU0FBUyxJQUFJLFVBQVUsS0FBSztBQUNwRTs7O0FDRkEsU0FBZ0IsS0FBSztDQUNqQixJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7Q0FHekIsT0FBTyxLQUFLLE1BREksYUFBYSxJQUNILENBQUM7QUFDL0I7OztBQ1BBLFNBQWdCLFdBQVcscUJBQXFCLFdBQVc7Q0FDdkQsSUFBSSxlQUFlLFdBQVcsbUJBQW1CLElBQUksc0JBQXNCLFdBQVk7RUFBRSxPQUFPO0NBQXFCO0NBQ3JILElBQUksT0FBTyxTQUFVLFlBQVk7RUFBRSxPQUFPLFdBQVcsTUFBTSxhQUFhLENBQUM7Q0FBRztDQUM1RSxPQUFPLElBQUksV0FBVyxZQUFZLFNBQVUsWUFBWTtFQUFFLE9BQU8sVUFBVSxTQUFTLE1BQU0sR0FBRyxVQUFVO0NBQUcsSUFBSSxJQUFJO0FBQ3RIOzs7QUNGQSxJQUFXO0NBQ1YsU0FBVSxrQkFBa0I7Q0FDekIsaUJBQWlCLFVBQVU7Q0FDM0IsaUJBQWlCLFdBQVc7Q0FDNUIsaUJBQWlCLGNBQWM7QUFDbkMsRUFBQSxDQUFHLHFCQUFxQixtQkFBbUIsQ0FBQyxFQUFFO0FBQzlDLElBQUksZUFBZ0IsV0FBWTtDQUM1QixTQUFTLGFBQWEsTUFBTSxPQUFPLE9BQU87RUFDdEMsS0FBSyxPQUFPO0VBQ1osS0FBSyxRQUFRO0VBQ2IsS0FBSyxRQUFRO0VBQ2IsS0FBSyxXQUFXLFNBQVM7Q0FDN0I7Q0FDQSxhQUFhLFVBQVUsVUFBVSxTQUFVLFVBQVU7RUFDakQsT0FBTyxvQkFBb0IsTUFBTSxRQUFRO0NBQzdDO0NBQ0EsYUFBYSxVQUFVLEtBQUssU0FBVSxhQUFhLGNBQWMsaUJBQWlCO0VBQzlFLElBQUksS0FBSyxNQUFNLE9BQU8sR0FBRyxNQUFNLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRztFQUM1RCxPQUFPLFNBQVMsTUFBTSxnQkFBZ0IsUUFBUSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssSUFBSSxZQUFZLEtBQUssSUFBSSxTQUFTLE1BQU0saUJBQWlCLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxLQUFLLElBQUksYUFBYSxLQUFLLElBQUksb0JBQW9CLFFBQVEsb0JBQW9CLEtBQUssSUFBSSxLQUFLLElBQUksZ0JBQWdCO0NBQzVSO0NBQ0EsYUFBYSxVQUFVLFNBQVMsU0FBVSxnQkFBZ0IsT0FBTyxVQUFVO0VBQ3ZFLElBQUk7RUFDSixPQUFPLFlBQVksS0FBSyxvQkFBb0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxJQUFJLElBQzlFLEtBQUssUUFBUSxjQUFjLElBQzNCLEtBQUssR0FBRyxnQkFBZ0IsT0FBTyxRQUFRO0NBQ2pEO0NBQ0EsYUFBYSxVQUFVLGVBQWUsV0FBWTtFQUM5QyxJQUFJLEtBQUssTUFBTSxPQUFPLEdBQUcsTUFBTSxRQUFRLEdBQUcsT0FBTyxRQUFRLEdBQUc7RUFDNUQsSUFBSSxTQUFTLFNBQVMsTUFFZCxHQUFHLEtBQUssSUFFUixTQUFTLE1BRUQsV0FBVyxXQUFZO0dBQUUsT0FBTztFQUFPLENBQUMsSUFFeEMsU0FBUyxNQUVELFFBRUE7RUFDeEIsSUFBSSxDQUFDLFFBQ0QsTUFBTSxJQUFJLFVBQVUsa0NBQWtDLElBQUk7RUFFOUQsT0FBTztDQUNYO0NBQ0EsYUFBYSxhQUFhLFNBQVUsT0FBTztFQUN2QyxPQUFPLElBQUksYUFBYSxLQUFLLEtBQUs7Q0FDdEM7Q0FDQSxhQUFhLGNBQWMsU0FBVSxLQUFLO0VBQ3RDLE9BQU8sSUFBSSxhQUFhLEtBQUssS0FBQSxHQUFXLEdBQUc7Q0FDL0M7Q0FDQSxhQUFhLGlCQUFpQixXQUFZO0VBQ3RDLE9BQU8sYUFBYTtDQUN4QjtDQUNBLGFBQWEsdUJBQXVCLElBQUksYUFBYSxHQUFHO0NBQ3hELE9BQU87QUFDWCxFQUFFO0FBRUYsU0FBZ0Isb0JBQW9CLGNBQWMsVUFBVTtDQUN4RCxJQUFJLElBQUksSUFBSTtDQUNaLElBQUksS0FBSyxjQUFjLE9BQU8sR0FBRyxNQUFNLFFBQVEsR0FBRyxPQUFPLFFBQVEsR0FBRztDQUNwRSxJQUFJLE9BQU8sU0FBUyxVQUNoQixNQUFNLElBQUksVUFBVSx3Q0FBc0M7Q0FFOUQsU0FBUyxPQUFPLEtBQUssU0FBUyxVQUFVLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxLQUFLLFVBQVUsS0FBSyxJQUFJLFNBQVMsT0FBTyxLQUFLLFNBQVMsV0FBVyxRQUFRLE9BQU8sS0FBSyxLQUFhLEdBQUcsS0FBSyxVQUFVLEtBQUssS0FBSyxLQUFLLFNBQVMsY0FBYyxRQUFRLE9BQU8sS0FBSyxLQUFhLEdBQUcsS0FBSyxRQUFRO0FBQzNSOzs7QUNyRUEsSUFBVyxhQUFhLGlCQUFpQixTQUFVLFFBQVE7Q0FDdkQsT0FBTyxTQUFTLGlCQUFpQjtFQUM3QixPQUFPLElBQUk7RUFDWCxLQUFLLE9BQU87RUFDWixLQUFLLFVBQVU7Q0FDbkI7QUFDSixDQUFDOzs7QUNORCxJQUFXLDBCQUEwQixpQkFBaUIsU0FBVSxRQUFRO0NBQ3BFLE9BQU8sU0FBUyw4QkFBOEI7RUFDMUMsT0FBTyxJQUFJO0VBQ1gsS0FBSyxPQUFPO0VBQ1osS0FBSyxVQUFVO0NBQ25CO0FBQ0osQ0FBQzs7O0FDTkQsSUFBVyxnQkFBZ0IsaUJBQWlCLFNBQVUsUUFBUTtDQUMxRCxPQUFPLFNBQVMsa0JBQWtCLFNBQVM7RUFDdkMsT0FBTyxJQUFJO0VBQ1gsS0FBSyxPQUFPO0VBQ1osS0FBSyxVQUFVO0NBQ25CO0FBQ0osQ0FBQzs7O0FDTkQsSUFBVyxnQkFBZ0IsaUJBQWlCLFNBQVUsUUFBUTtDQUMxRCxPQUFPLFNBQVMsa0JBQWtCLFNBQVM7RUFDdkMsT0FBTyxJQUFJO0VBQ1gsS0FBSyxPQUFPO0VBQ1osS0FBSyxVQUFVO0NBQ25CO0FBQ0osQ0FBQzs7O0FDUEQsU0FBZ0IsWUFBWSxPQUFPO0NBQy9CLE9BQU8saUJBQWlCLFFBQVEsQ0FBQyxNQUFNLEtBQUs7QUFDaEQ7OztBQ0tBLElBQVcsZUFBZSxpQkFBaUIsU0FBVSxRQUFRO0NBQ3pELE9BQU8sU0FBUyxpQkFBaUIsTUFBTTtFQUNuQyxJQUFJLFNBQVMsS0FBSyxHQUFLLE9BQU87RUFDOUIsT0FBTyxJQUFJO0VBQ1gsS0FBSyxVQUFVO0VBQ2YsS0FBSyxPQUFPO0VBQ1osS0FBSyxPQUFPO0NBQ2hCO0FBQ0osQ0FBQztBQUNELFNBQWdCLFFBQVEsUUFBUSxjQUFjO0NBQzFDLElBQUksS0FBTSxZQUFZLE1BQU0sSUFBSSxFQUFFLE9BQU8sT0FBTyxJQUFJLE9BQU8sV0FBVyxXQUFXLEVBQUUsTUFBTSxPQUFPLElBQUksUUFBUyxRQUFRLEdBQUcsT0FBTyxPQUFPLEdBQUcsTUFBTSxLQUFLLEdBQUcsTUFBTSxRQUFRLE9BQU8sS0FBSyxJQUFJLHNCQUFzQixJQUFJLEtBQUssR0FBRyxXQUFXLFlBQVksT0FBTyxLQUFLLElBQUksaUJBQWlCLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxlQUFlLGlCQUFpQixJQUFJLEtBQUssR0FBRyxNQUFNLE9BQU8sT0FBTyxLQUFLLElBQUksT0FBTztDQUNqWSxJQUFJLFNBQVMsUUFBUSxRQUFRLE1BQ3pCLE1BQU0sSUFBSSxVQUFVLHNCQUFzQjtDQUU5QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJLFlBQVk7RUFDaEIsSUFBSSxPQUFPO0VBQ1gsSUFBSSxhQUFhLFNBQVUsT0FBTztHQUM5QixvQkFBb0IsZ0JBQWdCLFlBQVksV0FBVyxXQUFZO0lBQ25FLElBQUk7S0FDQSwyQkFBMkIsWUFBWTtLQUN2QyxVQUFVLE1BQU07TUFDTjtNQUNLO01BQ0w7S0FDVixDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsVUFBVTtJQUM1QixTQUNPLEtBQUs7S0FDUixXQUFXLE1BQU0sR0FBRztJQUN4QjtHQUNKLEdBQUcsS0FBSztFQUNaO0VBQ0EsNkJBQTZCLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDaEcsc0JBQXNCLFFBQVEsc0JBQXNCLEtBQUssS0FBYSxrQkFBa0IsWUFBWTtHQUNwRztHQUNBLFdBQVcsS0FBTSxZQUFZLEtBQU07R0FDbkMsT0FBTyxLQUFLLFdBQVcsSUFBSTtFQUMvQixHQUFHLEtBQUEsR0FBVyxLQUFBLEdBQVcsV0FBWTtHQUNqQyxJQUFJLEVBQUUsc0JBQXNCLFFBQVEsc0JBQXNCLEtBQUssSUFBSSxLQUFLLElBQUksa0JBQWtCLFNBQzFGLHNCQUFzQixRQUFRLHNCQUFzQixLQUFLLEtBQWEsa0JBQWtCLFlBQVk7R0FFeEcsWUFBWTtFQUNoQixDQUFDLENBQUM7RUFDRixDQUFDLFFBQVEsV0FBVyxTQUFTLE9BQVEsT0FBTyxVQUFVLFdBQVcsUUFBUSxDQUFDLFFBQVEsVUFBVSxJQUFJLElBQUssSUFBSTtDQUM3RyxDQUFDO0FBQ0w7QUFDQSxTQUFTLG9CQUFvQixNQUFNO0NBQy9CLE1BQU0sSUFBSSxhQUFhLElBQUk7QUFDL0I7OztBQ3ZEQSxTQUFnQixJQUFJLFNBQVMsU0FBUztDQUNsQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxRQUFRO0VBQ1osT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxXQUFXLEtBQUssUUFBUSxLQUFLLFNBQVMsT0FBTyxPQUFPLENBQUM7RUFDekQsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUNQQSxJQUFJRSxZQUFVLE1BQU07QUFDcEIsU0FBUyxZQUFZLElBQUksTUFBTTtDQUMzQixPQUFPQSxVQUFRLElBQUksSUFBSSxHQUFHLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxHQUFHLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUk7QUFDdEY7QUFDQSxTQUFnQixpQkFBaUIsSUFBSTtDQUNqQyxPQUFPLElBQUksU0FBVSxNQUFNO0VBQUUsT0FBTyxZQUFZLElBQUksSUFBSTtDQUFHLENBQUM7QUFDaEU7OztBQ1JBLElBQUlDLFlBQVUsTUFBTTtBQUNwQixJQUFJLGlCQUFpQixPQUFPO0lBQWdCLGNBQWMsT0FBTztJQUFXLFVBQVUsT0FBTztBQUM3RixTQUFnQixxQkFBcUIsTUFBTTtDQUN2QyxJQUFJLEtBQUssV0FBVyxHQUFHO0VBQ25CLElBQUksVUFBVSxLQUFLO0VBQ25CLElBQUlBLFVBQVEsT0FBTyxHQUNmLE9BQU87R0FBRSxNQUFNO0dBQVMsTUFBTTtFQUFLO0VBRXZDLElBQUksT0FBTyxPQUFPLEdBQUc7R0FDakIsSUFBSSxPQUFPLFFBQVEsT0FBTztHQUMxQixPQUFPO0lBQ0gsTUFBTSxLQUFLLElBQUksU0FBVSxLQUFLO0tBQUUsT0FBTyxRQUFRO0lBQU0sQ0FBQztJQUNoRDtHQUNWO0VBQ0o7Q0FDSjtDQUNBLE9BQU87RUFBUTtFQUFNLE1BQU07Q0FBSztBQUNwQztBQUNBLFNBQVMsT0FBTyxLQUFLO0NBQ2pCLE9BQU8sT0FBTyxPQUFPLFFBQVEsWUFBWSxlQUFlLEdBQUcsTUFBTTtBQUNyRTs7O0FDcEJBLFNBQWdCLGFBQWEsTUFBTSxRQUFRO0NBQ3ZDLE9BQU8sS0FBSyxPQUFPLFNBQVUsUUFBUSxLQUFLLEdBQUc7RUFBRSxPQUFTLE9BQU8sT0FBTyxPQUFPLElBQUs7Q0FBUyxHQUFHLENBQUMsQ0FBQztBQUNwRzs7O0FDT0EsU0FBZ0JDLGtCQUFnQjtDQUM1QixJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7Q0FFekIsSUFBSSxZQUFZLGFBQWEsSUFBSTtDQUNqQyxJQUFJLGlCQUFpQixrQkFBa0IsSUFBSTtDQUMzQyxJQUFJLEtBQUsscUJBQXFCLElBQUksR0FBRyxjQUFjLEdBQUcsTUFBTSxPQUFPLEdBQUc7Q0FDdEUsSUFBSSxZQUFZLFdBQVcsR0FDdkIsT0FBTyxLQUFLLENBQUMsR0FBRyxTQUFTO0NBRTdCLElBQUksU0FBUyxJQUFJLFdBQVcsa0JBQWtCLGFBQWEsV0FBVyxPQUU5RCxTQUFVLFFBQVE7RUFBRSxPQUFPLGFBQWEsTUFBTSxNQUFNO0NBQUcsSUFFdkQsUUFBUSxDQUFDO0NBQ2pCLE9BQU8saUJBQWlCLE9BQU8sS0FBSyxpQkFBaUIsY0FBYyxDQUFDLElBQUk7QUFDNUU7QUFDQSxTQUFnQixrQkFBa0IsYUFBYSxXQUFXLGdCQUFnQjtDQUN0RSxJQUFJLG1CQUFtQixLQUFLLEdBQUssaUJBQWlCO0NBQ2xELE9BQU8sU0FBVSxZQUFZO0VBQ3pCLGNBQWMsV0FBVyxXQUFZO0dBQ2pDLElBQUksU0FBUyxZQUFZO0dBQ3pCLElBQUksU0FBUyxJQUFJLE1BQU0sTUFBTTtHQUM3QixJQUFJLFNBQVM7R0FDYixJQUFJLHVCQUF1QjtHQUMzQixJQUFJLFVBQVUsU0FBVSxHQUFHO0lBQ3ZCLGNBQWMsV0FBVyxXQUFZO0tBQ2pDLElBQUksU0FBUyxLQUFLLFlBQVksSUFBSSxTQUFTO0tBQzNDLElBQUksZ0JBQWdCO0tBQ3BCLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87TUFDbkUsT0FBTyxLQUFLO01BQ1osSUFBSSxDQUFDLGVBQWU7T0FDaEIsZ0JBQWdCO09BQ2hCO01BQ0o7TUFDQSxJQUFJLENBQUMsc0JBQ0QsV0FBVyxLQUFLLGVBQWUsT0FBTyxNQUFNLENBQUMsQ0FBQztLQUV0RCxHQUFHLFdBQVk7TUFDWCxJQUFJLENBQUMsRUFBRSxRQUNILFdBQVcsU0FBUztLQUU1QixDQUFDLENBQUM7SUFDTixHQUFHLFVBQVU7R0FDakI7R0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUN4QixRQUFRLENBQUM7RUFFakIsR0FBRyxVQUFVO0NBQ2pCO0FBQ0o7QUFDQSxTQUFTLGNBQWMsV0FBVyxTQUFTLGNBQWM7Q0FDckQsSUFBSSxXQUNBLGdCQUFnQixjQUFjLFdBQVcsT0FBTztNQUdoRCxRQUFRO0FBRWhCOzs7QUNqRUEsU0FBZ0IsZUFBZSxRQUFRLFlBQVksU0FBUyxZQUFZLGNBQWMsUUFBUSxtQkFBbUIscUJBQXFCO0NBQ2xJLElBQUksU0FBUyxDQUFDO0NBQ2QsSUFBSSxTQUFTO0NBQ2IsSUFBSSxRQUFRO0NBQ1osSUFBSSxhQUFhO0NBQ2pCLElBQUksZ0JBQWdCLFdBQVk7RUFDNUIsSUFBSSxjQUFjLENBQUMsT0FBTyxVQUFVLENBQUMsUUFDakMsV0FBVyxTQUFTO0NBRTVCO0NBQ0EsSUFBSSxZQUFZLFNBQVUsT0FBTztFQUFFLE9BQVEsU0FBUyxhQUFhLFdBQVcsS0FBSyxJQUFJLE9BQU8sS0FBSyxLQUFLO0NBQUk7Q0FDMUcsSUFBSSxhQUFhLFNBQVUsT0FBTztFQUM5QixVQUFVLFdBQVcsS0FBSyxLQUFLO0VBQy9CO0VBQ0EsSUFBSSxnQkFBZ0I7RUFDcEIsVUFBVSxRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsWUFBWTtHQUNwRyxpQkFBaUIsUUFBUSxpQkFBaUIsS0FBSyxLQUFhLGFBQWEsVUFBVTtHQUNuRixJQUFJLFFBQ0EsVUFBVSxVQUFVO1FBR3BCLFdBQVcsS0FBSyxVQUFVO0VBRWxDLEdBQUcsV0FBWTtHQUNYLGdCQUFnQjtFQUNwQixHQUFHLEtBQUEsR0FBVyxXQUFZO0dBQ3RCLElBQUksZUFDQSxJQUFJO0lBQ0E7SUFDQSxJQUFJLFVBQVUsV0FBWTtLQUN0QixJQUFJLGdCQUFnQixPQUFPLE1BQU07S0FDakMsSUFBSSxtQkFDQSxnQkFBZ0IsWUFBWSxtQkFBbUIsV0FBWTtNQUFFLE9BQU8sV0FBVyxhQUFhO0tBQUcsQ0FBQztVQUdoRyxXQUFXLGFBQWE7SUFFaEM7SUFDQSxPQUFPLE9BQU8sVUFBVSxTQUFTLFlBQzdCLFFBQVE7SUFFWixjQUFjO0dBQ2xCLFNBQ08sS0FBSztJQUNSLFdBQVcsTUFBTSxHQUFHO0dBQ3hCO0VBRVIsQ0FBQyxDQUFDO0NBQ047Q0FDQSxPQUFPLFVBQVUseUJBQXlCLFlBQVksV0FBVyxXQUFZO0VBQ3pFLGFBQWE7RUFDYixjQUFjO0NBQ2xCLENBQUMsQ0FBQztDQUNGLE9BQU8sV0FBWTtFQUNmLHdCQUF3QixRQUFRLHdCQUF3QixLQUFLLEtBQWEsb0JBQW9CO0NBQ2xHO0FBQ0o7OztBQ3REQSxTQUFnQixTQUFTLFNBQVMsZ0JBQWdCLFlBQVk7Q0FDMUQsSUFBSSxlQUFlLEtBQUssR0FBSyxhQUFhO0NBQzFDLElBQUksV0FBVyxjQUFjLEdBQ3pCLE9BQU8sU0FBUyxTQUFVLEdBQUcsR0FBRztFQUFFLE9BQU8sSUFBSSxTQUFVLEdBQUcsSUFBSTtHQUFFLE9BQU8sZUFBZSxHQUFHLEdBQUcsR0FBRyxFQUFFO0VBQUcsQ0FBQyxDQUFDLENBQUMsVUFBVSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FBRyxHQUFHLFVBQVU7TUFFOUksSUFBSSxPQUFPLG1CQUFtQixVQUMvQixhQUFhO0NBRWpCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUFFLE9BQU8sZUFBZSxRQUFRLFlBQVksU0FBUyxVQUFVO0NBQUcsQ0FBQztBQUNwSDs7O0FDWkEsU0FBZ0IsU0FBUyxZQUFZO0NBQ2pDLElBQUksZUFBZSxLQUFLLEdBQUssYUFBYTtDQUMxQyxPQUFPLFNBQVMsVUFBVSxVQUFVO0FBQ3hDOzs7QUNKQSxTQUFnQixZQUFZO0NBQ3hCLE9BQU8sU0FBUyxDQUFDO0FBQ3JCOzs7QUNBQSxTQUFnQkMsV0FBUztDQUNyQixJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7Q0FFekIsT0FBTyxVQUFVLENBQUMsQ0FBQyxLQUFLLE1BQU0sYUFBYSxJQUFJLENBQUMsQ0FBQztBQUNyRDs7O0FDTEEsU0FBZ0IsTUFBTSxTQUFTLHFCQUFxQixXQUFXO0NBQzNELElBQUksWUFBWSxLQUFLLEdBQUssVUFBVTtDQUNwQyxJQUFJLGNBQWMsS0FBSyxHQUFLLFlBQVlDO0NBQ3hDLElBQUksbUJBQW1CO0NBQ3ZCLElBQUksdUJBQXVCLE1BQ3ZCLElBQUksWUFBWSxtQkFBbUIsR0FDL0IsWUFBWTtNQUdaLG1CQUFtQjtDQUczQixPQUFPLElBQUksV0FBVyxTQUFVLFlBQVk7RUFDeEMsSUFBSSxNQUFNLFlBQVksT0FBTyxJQUFJLENBQUMsVUFBVSxVQUFVLElBQUksSUFBSTtFQUM5RCxJQUFJLE1BQU0sR0FDTixNQUFNO0VBRVYsSUFBSSxJQUFJO0VBQ1IsT0FBTyxVQUFVLFNBQVMsV0FBWTtHQUNsQyxJQUFJLENBQUMsV0FBVyxRQUFRO0lBQ3BCLFdBQVcsS0FBSyxHQUFHO0lBQ25CLElBQUksS0FBSyxrQkFDTCxLQUFLLFNBQVMsS0FBQSxHQUFXLGdCQUFnQjtTQUd6QyxXQUFXLFNBQVM7R0FFNUI7RUFDSixHQUFHLEdBQUc7Q0FDVixDQUFDO0FBQ0w7OztBQ2hDQSxTQUFnQixTQUFTLFFBQVEsV0FBVztDQUN4QyxJQUFJLFdBQVcsS0FBSyxHQUFLLFNBQVM7Q0FDbEMsSUFBSSxjQUFjLEtBQUssR0FBSyxZQUFZO0NBQ3hDLElBQUksU0FBUyxHQUNULFNBQVM7Q0FFYixPQUFPLE1BQU0sUUFBUSxRQUFRLFNBQVM7QUFDMUM7OztBQ1RBLElBQUksVUFBVSxNQUFNO0FBQ3BCLFNBQWdCLGVBQWUsTUFBTTtDQUNqQyxPQUFPLEtBQUssV0FBVyxLQUFLLFFBQVEsS0FBSyxFQUFFLElBQUksS0FBSyxLQUFLO0FBQzdEOzs7QUNFQSxTQUFnQkMsc0JBQW9CO0NBQ2hDLElBQUksVUFBVSxDQUFDO0NBQ2YsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxRQUFRLE1BQU0sVUFBVTtDQUU1QixJQUFJLGNBQWMsZUFBZSxPQUFPO0NBQ3hDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUN4QyxJQUFJLGNBQWM7RUFDbEIsSUFBSSxnQkFBZ0IsV0FBWTtHQUM1QixJQUFJLGNBQWMsWUFBWSxRQUFRO0lBQ2xDLElBQUksYUFBYSxLQUFLO0lBQ3RCLElBQUk7S0FDQSxhQUFhLFVBQVUsWUFBWSxjQUFjO0lBQ3JELFNBQ08sS0FBSztLQUNSLGNBQWM7S0FDZDtJQUNKO0lBQ0EsSUFBSSxrQkFBa0IsSUFBSSxtQkFBbUIsWUFBWSxLQUFBLEdBQVcsTUFBTSxJQUFJO0lBQzlFLFdBQVcsVUFBVSxlQUFlO0lBQ3BDLGdCQUFnQixJQUFJLGFBQWE7R0FDckMsT0FFSSxXQUFXLFNBQVM7RUFFNUI7RUFDQSxjQUFjO0NBQ2xCLENBQUM7QUFDTDs7O0FDakNBLFNBQWdCLElBQUksTUFBTSxTQUFTO0NBQy9CLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFBRSxPQUFPLENBQUMsS0FBSyxLQUFLLFNBQVMsT0FBTyxLQUFLO0NBQUc7QUFDL0U7OztBQ0FBLFNBQWdCLE9BQU8sV0FBVyxTQUFTO0NBQ3ZDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFFBQVE7RUFDWixPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQUUsT0FBTyxVQUFVLEtBQUssU0FBUyxPQUFPLE9BQU8sS0FBSyxXQUFXLEtBQUssS0FBSztFQUFHLENBQUMsQ0FBQztDQUN6SixDQUFDO0FBQ0w7OztBQ0hBLFNBQWdCLE9BQU87Q0FDbkIsSUFBSSxVQUFVLENBQUM7Q0FDZixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLFFBQVEsTUFBTSxVQUFVO0NBRTVCLFVBQVUsZUFBZSxPQUFPO0NBQ2hDLE9BQU8sUUFBUSxXQUFXLElBQUksVUFBVSxRQUFRLEVBQUUsSUFBSSxJQUFJLFdBQVcsU0FBUyxPQUFPLENBQUM7QUFDMUY7QUFDQSxTQUFnQixTQUFTLFNBQVM7Q0FDOUIsT0FBTyxTQUFVLFlBQVk7RUFDekIsSUFBSSxnQkFBZ0IsQ0FBQztFQUNyQixJQUFJLFVBQVUsU0FBVSxHQUFHO0dBQ3ZCLGNBQWMsS0FBSyxVQUFVLFFBQVEsRUFBRSxDQUFDLENBQUMsVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87SUFDckcsSUFBSSxlQUFlO0tBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUN0QyxNQUFNLEtBQUssY0FBYyxFQUFFLENBQUMsWUFBWTtLQUU1QyxnQkFBZ0I7SUFDcEI7SUFDQSxXQUFXLEtBQUssS0FBSztHQUN6QixDQUFDLENBQUMsQ0FBQztFQUNQO0VBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxpQkFBaUIsQ0FBQyxXQUFXLFVBQVUsSUFBSSxRQUFRLFFBQVEsS0FDdkUsUUFBUSxDQUFDO0NBRWpCO0FBQ0o7OztBQ3ZCQSxTQUFnQkMsUUFBTTtDQUNsQixJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7Q0FFekIsSUFBSSxpQkFBaUIsa0JBQWtCLElBQUk7Q0FDM0MsSUFBSSxVQUFVLGVBQWUsSUFBSTtDQUNqQyxPQUFPLFFBQVEsU0FDVCxJQUFJLFdBQVcsU0FBVSxZQUFZO0VBQ25DLElBQUksVUFBVSxRQUFRLElBQUksV0FBWTtHQUFFLE9BQU8sQ0FBQztFQUFHLENBQUM7RUFDcEQsSUFBSSxZQUFZLFFBQVEsSUFBSSxXQUFZO0dBQUUsT0FBTztFQUFPLENBQUM7RUFDekQsV0FBVyxJQUFJLFdBQVk7R0FDdkIsVUFBVSxZQUFZO0VBQzFCLENBQUM7RUFDRCxJQUFJLFVBQVUsU0FBVSxhQUFhO0dBQ2pDLFVBQVUsUUFBUSxZQUFZLENBQUMsQ0FBQyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztJQUM1RixRQUFRLFlBQVksQ0FBQyxLQUFLLEtBQUs7SUFDL0IsSUFBSSxRQUFRLE1BQU0sU0FBVSxRQUFRO0tBQUUsT0FBTyxPQUFPO0lBQVEsQ0FBQyxHQUFHO0tBQzVELElBQUksU0FBUyxRQUFRLElBQUksU0FBVSxRQUFRO01BQUUsT0FBTyxPQUFPLE1BQU07S0FBRyxDQUFDO0tBQ3JFLFdBQVcsS0FBSyxpQkFBaUIsZUFBZSxNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsR0FBRyxPQUFPLE1BQU0sQ0FBQyxDQUFDLElBQUksTUFBTTtLQUN6RyxJQUFJLFFBQVEsS0FBSyxTQUFVLFFBQVEsR0FBRztNQUFFLE9BQU8sQ0FBQyxPQUFPLFVBQVUsVUFBVTtLQUFJLENBQUMsR0FDNUUsV0FBVyxTQUFTO0lBRTVCO0dBQ0osR0FBRyxXQUFZO0lBQ1gsVUFBVSxlQUFlO0lBQ3pCLENBQUMsUUFBUSxZQUFZLENBQUMsVUFBVSxXQUFXLFNBQVM7R0FDeEQsQ0FBQyxDQUFDO0VBQ047RUFDQSxLQUFLLElBQUksY0FBYyxHQUFHLENBQUMsV0FBVyxVQUFVLGNBQWMsUUFBUSxRQUFRLGVBQzFFLFFBQVEsV0FBVztFQUV2QixPQUFPLFdBQVk7R0FDZixVQUFVLFlBQVk7RUFDMUI7Q0FDSixDQUFDLElBQ0M7QUFDVjs7O0FDekNBLFNBQWdCLE1BQU0sa0JBQWtCO0NBQ3BDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFdBQVc7RUFDZixJQUFJLFlBQVk7RUFDaEIsSUFBSSxxQkFBcUI7RUFDekIsSUFBSSxhQUFhO0VBQ2pCLElBQUksY0FBYyxXQUFZO0dBQzFCLHVCQUF1QixRQUFRLHVCQUF1QixLQUFLLEtBQWEsbUJBQW1CLFlBQVk7R0FDdkcscUJBQXFCO0dBQ3JCLElBQUksVUFBVTtJQUNWLFdBQVc7SUFDWCxJQUFJLFFBQVE7SUFDWixZQUFZO0lBQ1osV0FBVyxLQUFLLEtBQUs7R0FDekI7R0FDQSxjQUFjLFdBQVcsU0FBUztFQUN0QztFQUNBLElBQUksa0JBQWtCLFdBQVk7R0FDOUIscUJBQXFCO0dBQ3JCLGNBQWMsV0FBVyxTQUFTO0VBQ3RDO0VBQ0EsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxXQUFXO0dBQ1gsWUFBWTtHQUNaLElBQUksQ0FBQyxvQkFDRCxVQUFVLGlCQUFpQixLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVcscUJBQXFCLHlCQUF5QixZQUFZLGFBQWEsZUFBZSxDQUFFO0VBRTlJLEdBQUcsV0FBWTtHQUNYLGFBQWE7R0FDYixDQUFDLENBQUMsWUFBWSxDQUFDLHNCQUFzQixtQkFBbUIsV0FBVyxXQUFXLFNBQVM7RUFDM0YsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUNoQ0EsU0FBZ0IsVUFBVSxVQUFVLFdBQVc7Q0FDM0MsSUFBSSxjQUFjLEtBQUssR0FBSyxZQUFZO0NBQ3hDLE9BQU8sTUFBTSxXQUFZO0VBQUUsT0FBTyxNQUFNLFVBQVUsU0FBUztDQUFHLENBQUM7QUFDbkU7OztBQ0ZBLFNBQWdCLE9BQU8saUJBQWlCO0NBQ3BDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLGdCQUFnQixDQUFDO0VBQ3JCLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FBRSxPQUFPLGNBQWMsS0FBSyxLQUFLO0VBQUcsR0FBRyxXQUFZO0dBQ3RILFdBQVcsS0FBSyxhQUFhO0dBQzdCLFdBQVcsU0FBUztFQUN4QixDQUFDLENBQUM7RUFDRixVQUFVLGVBQWUsQ0FBQyxDQUFDLFVBQVUseUJBQXlCLFlBQVksV0FBWTtHQUNsRixJQUFJLElBQUk7R0FDUixnQkFBZ0IsQ0FBQztHQUNqQixXQUFXLEtBQUssQ0FBQztFQUNyQixHQUFHLElBQUksQ0FBQztFQUNSLE9BQU8sV0FBWTtHQUNmLGdCQUFnQjtFQUNwQjtDQUNKLENBQUM7QUFDTDs7O0FDaEJBLFNBQWdCLFlBQVksWUFBWSxrQkFBa0I7Q0FDdEQsSUFBSSxxQkFBcUIsS0FBSyxHQUFLLG1CQUFtQjtDQUN0RCxtQkFBbUIscUJBQXFCLFFBQVEscUJBQXFCLEtBQUssSUFBSSxtQkFBbUI7Q0FDakcsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksVUFBVSxDQUFDO0VBQ2YsSUFBSSxRQUFRO0VBQ1osT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLEtBQUssSUFBSSxLQUFLO0dBQ2xCLElBQUksU0FBUztHQUNiLElBQUksVUFBVSxxQkFBcUIsR0FDL0IsUUFBUSxLQUFLLENBQUMsQ0FBQztHQUVuQixJQUFJO0lBQ0EsS0FBSyxJQUFJLFlBQVksU0FBUyxPQUFPLEdBQUcsY0FBYyxVQUFVLEtBQUssR0FBRyxDQUFDLFlBQVksTUFBTSxjQUFjLFVBQVUsS0FBSyxHQUFHO0tBQ3ZILElBQUksU0FBUyxZQUFZO0tBQ3pCLE9BQU8sS0FBSyxLQUFLO0tBQ2pCLElBQUksY0FBYyxPQUFPLFFBQVE7TUFDN0IsU0FBUyxXQUFXLFFBQVEsV0FBVyxLQUFLLElBQUksU0FBUyxDQUFDO01BQzFELE9BQU8sS0FBSyxNQUFNO0tBQ3RCO0lBQ0o7R0FDSixTQUNPLE9BQU87SUFBRSxNQUFNLEVBQUUsT0FBTyxNQUFNO0dBQUcsVUFDaEM7SUFDSixJQUFJO0tBQ0EsSUFBSSxlQUFlLENBQUMsWUFBWSxTQUFTLEtBQUssVUFBVSxTQUFTLEdBQUcsS0FBSyxTQUFTO0lBQ3RGLFVBQ1E7S0FBRSxJQUFJLEtBQUssTUFBTSxJQUFJO0lBQU87R0FDeEM7R0FDQSxJQUFJLFFBQ0EsSUFBSTtJQUNBLEtBQUssSUFBSSxXQUFXLFNBQVMsTUFBTSxHQUFHLGFBQWEsU0FBUyxLQUFLLEdBQUcsQ0FBQyxXQUFXLE1BQU0sYUFBYSxTQUFTLEtBQUssR0FBRztLQUNoSCxJQUFJLFNBQVMsV0FBVztLQUN4QixVQUFVLFNBQVMsTUFBTTtLQUN6QixXQUFXLEtBQUssTUFBTTtJQUMxQjtHQUNKLFNBQ08sT0FBTztJQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU07R0FBRyxVQUNoQztJQUNKLElBQUk7S0FDQSxJQUFJLGNBQWMsQ0FBQyxXQUFXLFNBQVMsS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLFFBQVE7SUFDbEYsVUFDUTtLQUFFLElBQUksS0FBSyxNQUFNLElBQUk7SUFBTztHQUN4QztFQUVSLEdBQUcsV0FBWTtHQUNYLElBQUksS0FBSztHQUNULElBQUk7SUFDQSxLQUFLLElBQUksWUFBWSxTQUFTLE9BQU8sR0FBRyxjQUFjLFVBQVUsS0FBSyxHQUFHLENBQUMsWUFBWSxNQUFNLGNBQWMsVUFBVSxLQUFLLEdBQUc7S0FDdkgsSUFBSSxTQUFTLFlBQVk7S0FDekIsV0FBVyxLQUFLLE1BQU07SUFDMUI7R0FDSixTQUNPLE9BQU87SUFBRSxNQUFNLEVBQUUsT0FBTyxNQUFNO0dBQUcsVUFDaEM7SUFDSixJQUFJO0tBQ0EsSUFBSSxlQUFlLENBQUMsWUFBWSxTQUFTLEtBQUssVUFBVSxTQUFTLEdBQUcsS0FBSyxTQUFTO0lBQ3RGLFVBQ1E7S0FBRSxJQUFJLEtBQUssTUFBTSxJQUFJO0lBQU87R0FDeEM7R0FDQSxXQUFXLFNBQVM7RUFDeEIsR0FBRyxLQUFBLEdBQVcsV0FBWTtHQUN0QixVQUFVO0VBQ2QsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUM3REEsU0FBZ0IsV0FBVyxnQkFBZ0I7Q0FDdkMsSUFBSSxJQUFJO0NBQ1IsSUFBSSxZQUFZLENBQUM7Q0FDakIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxVQUFVLEtBQUssS0FBSyxVQUFVO0NBRWxDLElBQUksYUFBYSxLQUFLLGFBQWEsU0FBUyxPQUFPLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztDQUNoRixJQUFJLDBCQUEwQixLQUFLLFVBQVUsUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7Q0FDbEYsSUFBSSxnQkFBZ0IsVUFBVSxNQUFNO0NBQ3BDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLGdCQUFnQixDQUFDO0VBQ3JCLElBQUksZ0JBQWdCO0VBQ3BCLElBQUksT0FBTyxTQUFVLFFBQVE7R0FDekIsSUFBSSxTQUFTLE9BQU87R0FDcEIsT0FEMEMsS0FDckMsWUFBWTtHQUNqQixVQUFVLGVBQWUsTUFBTTtHQUMvQixXQUFXLEtBQUssTUFBTTtHQUN0QixpQkFBaUIsWUFBWTtFQUNqQztFQUNBLElBQUksY0FBYyxXQUFZO0dBQzFCLElBQUksZUFBZTtJQUNmLElBQUksT0FBTyxJQUFJLGFBQWE7SUFDNUIsV0FBVyxJQUFJLElBQUk7SUFFbkIsSUFBSSxXQUFXO0tBQ1gsUUFBUSxDQUFLO0tBQ1A7SUFDVjtJQUNBLGNBQWMsS0FBSyxRQUFRO0lBQzNCLGdCQUFnQixNQUFNLFdBQVcsV0FBWTtLQUFFLE9BQU8sS0FBSyxRQUFRO0lBQUcsR0FBRyxjQUFjO0dBQzNGO0VBQ0o7RUFDQSxJQUFJLDJCQUEyQixRQUFRLDBCQUEwQixHQUM3RCxnQkFBZ0IsWUFBWSxXQUFXLGFBQWEsd0JBQXdCLElBQUk7T0FHaEYsZ0JBQWdCO0VBRXBCLFlBQVk7RUFDWixJQUFJLHVCQUF1Qix5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDN0UsSUFBSSxLQUFLO0dBQ1QsSUFBSSxjQUFjLGNBQWMsTUFBTTtHQUN0QyxJQUFJO0lBQ0EsS0FBSyxJQUFJLGdCQUFnQixTQUFTLFdBQVcsR0FBRyxrQkFBa0IsY0FBYyxLQUFLLEdBQUcsQ0FBQyxnQkFBZ0IsTUFBTSxrQkFBa0IsY0FBYyxLQUFLLEdBQUc7S0FDbkosSUFBSSxTQUFTLGdCQUFnQjtLQUM3QixJQUFJLFNBQVMsT0FBTztLQUNwQixPQUFPLEtBQUssS0FBSztLQUNqQixpQkFBaUIsT0FBTyxVQUFVLEtBQUssTUFBTTtJQUNqRDtHQUNKLFNBQ08sT0FBTztJQUFFLE1BQU0sRUFBRSxPQUFPLE1BQU07R0FBRyxVQUNoQztJQUNKLElBQUk7S0FDQSxJQUFJLG1CQUFtQixDQUFDLGdCQUFnQixTQUFTLEtBQUssY0FBYyxTQUFTLEdBQUcsS0FBSyxhQUFhO0lBQ3RHLFVBQ1E7S0FBRSxJQUFJLEtBQUssTUFBTSxJQUFJO0lBQU87R0FDeEM7RUFDSixHQUFHLFdBQVk7R0FDWCxPQUFPLGtCQUFrQixRQUFRLGtCQUFrQixLQUFLLElBQUksS0FBSyxJQUFJLGNBQWMsUUFDL0UsV0FBVyxLQUFLLGNBQWMsTUFBTSxDQUFDLENBQUMsTUFBTTtHQUVoRCx5QkFBeUIsUUFBUSx5QkFBeUIsS0FBSyxLQUFhLHFCQUFxQixZQUFZO0dBQzdHLFdBQVcsU0FBUztHQUNwQixXQUFXLFlBQVk7RUFDM0IsR0FBRyxLQUFBLEdBQVcsV0FBWTtHQUFFLE9BQVEsZ0JBQWdCO0VBQU8sQ0FBQztFQUM1RCxPQUFPLFVBQVUsb0JBQW9CO0NBQ3pDLENBQUM7QUFDTDs7O0FDcEVBLFNBQWdCLGFBQWEsVUFBVSxpQkFBaUI7Q0FDcEQsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksVUFBVSxDQUFDO0VBQ2YsVUFBVSxRQUFRLENBQUMsQ0FBQyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsV0FBVztHQUNwRixJQUFJLFNBQVMsQ0FBQztHQUNkLFFBQVEsS0FBSyxNQUFNO0dBQ25CLElBQUksc0JBQXNCLElBQUksYUFBYTtHQUMzQyxJQUFJLGFBQWEsV0FBWTtJQUN6QixVQUFVLFNBQVMsTUFBTTtJQUN6QixXQUFXLEtBQUssTUFBTTtJQUN0QixvQkFBb0IsWUFBWTtHQUNwQztHQUNBLG9CQUFvQixJQUFJLFVBQVUsZ0JBQWdCLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVSx5QkFBeUIsWUFBWSxZQUFZLElBQUksQ0FBQyxDQUFDO0VBQ25JLEdBQUcsSUFBSSxDQUFDO0VBQ1IsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLEtBQUs7R0FDVCxJQUFJO0lBQ0EsS0FBSyxJQUFJLFlBQVksU0FBUyxPQUFPLEdBQUcsY0FBYyxVQUFVLEtBQUssR0FBRyxDQUFDLFlBQVksTUFBTSxjQUFjLFVBQVUsS0FBSyxHQUVwSCxZQUR5QixNQUNsQixLQUFLLEtBQUs7R0FFekIsU0FDTyxPQUFPO0lBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTTtHQUFHLFVBQ2hDO0lBQ0osSUFBSTtLQUNBLElBQUksZUFBZSxDQUFDLFlBQVksU0FBUyxLQUFLLFVBQVUsU0FBUyxHQUFHLEtBQUssU0FBUztJQUN0RixVQUNRO0tBQUUsSUFBSSxLQUFLLE1BQU0sSUFBSTtJQUFPO0dBQ3hDO0VBQ0osR0FBRyxXQUFZO0dBQ1gsT0FBTyxRQUFRLFNBQVMsR0FDcEIsV0FBVyxLQUFLLFFBQVEsTUFBTSxDQUFDO0dBRW5DLFdBQVcsU0FBUztFQUN4QixDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7OztBQ3ZDQSxTQUFnQixXQUFXLGlCQUFpQjtDQUN4QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxTQUFTO0VBQ2IsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSSxhQUFhLFdBQVk7R0FDekIsc0JBQXNCLFFBQVEsc0JBQXNCLEtBQUssS0FBYSxrQkFBa0IsWUFBWTtHQUNwRyxJQUFJLElBQUk7R0FDUixTQUFTLENBQUM7R0FDVixLQUFLLFdBQVcsS0FBSyxDQUFDO0dBQ3RCLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFVBQVcsb0JBQW9CLHlCQUF5QixZQUFZLFlBQVksSUFBSSxDQUFFO0VBQ3ZIO0VBQ0EsV0FBVztFQUNYLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FBRSxPQUFPLFdBQVcsUUFBUSxXQUFXLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxLQUFLLEtBQUs7RUFBRyxHQUFHLFdBQVk7R0FDL0osVUFBVSxXQUFXLEtBQUssTUFBTTtHQUNoQyxXQUFXLFNBQVM7RUFDeEIsR0FBRyxLQUFBLEdBQVcsV0FBWTtHQUFFLE9BQVEsU0FBUyxvQkFBb0I7RUFBTyxDQUFDLENBQUM7Q0FDOUUsQ0FBQztBQUNMOzs7QUNsQkEsU0FBZ0IsV0FBVyxVQUFVO0NBQ2pDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFdBQVc7RUFDZixJQUFJLFlBQVk7RUFDaEIsSUFBSTtFQUNKLFdBQVcsT0FBTyxVQUFVLHlCQUF5QixZQUFZLEtBQUEsR0FBVyxLQUFBLEdBQVcsU0FBVSxLQUFLO0dBQ2xHLGdCQUFnQixVQUFVLFNBQVMsS0FBSyxXQUFXLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0dBQ3JFLElBQUksVUFBVTtJQUNWLFNBQVMsWUFBWTtJQUNyQixXQUFXO0lBQ1gsY0FBYyxVQUFVLFVBQVU7R0FDdEMsT0FFSSxZQUFZO0VBRXBCLENBQUMsQ0FBQztFQUNGLElBQUksV0FBVztHQUNYLFNBQVMsWUFBWTtHQUNyQixXQUFXO0dBQ1gsY0FBYyxVQUFVLFVBQVU7RUFDdEM7Q0FDSixDQUFDO0FBQ0w7OztBQ3hCQSxTQUFnQixjQUFjLGFBQWEsTUFBTSxTQUFTLFlBQVksb0JBQW9CO0NBQ3RGLE9BQU8sU0FBVSxRQUFRLFlBQVk7RUFDakMsSUFBSSxXQUFXO0VBQ2YsSUFBSSxRQUFRO0VBQ1osSUFBSSxRQUFRO0VBQ1osT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLElBQUk7R0FDUixRQUFRLFdBRUEsWUFBWSxPQUFPLE9BQU8sQ0FBQyxLQUV6QixXQUFXLE1BQU87R0FDNUIsY0FBYyxXQUFXLEtBQUssS0FBSztFQUN2QyxHQUFHLHVCQUNFLFdBQVk7R0FDVCxZQUFZLFdBQVcsS0FBSyxLQUFLO0dBQ2pDLFdBQVcsU0FBUztFQUN4QixFQUFFLENBQUM7Q0FDWDtBQUNKOzs7QUNsQkEsU0FBZ0IsT0FBTyxhQUFhLE1BQU07Q0FDdEMsT0FBTyxRQUFRLGNBQWMsYUFBYSxNQUFNLFVBQVUsVUFBVSxHQUFHLE9BQU8sSUFBSSxDQUFDO0FBQ3ZGOzs7QUNGQSxJQUFJLGFBQWEsU0FBVSxLQUFLLE9BQU87Q0FBRSxPQUFRLElBQUksS0FBSyxLQUFLLEdBQUc7QUFBTTtBQUN4RSxTQUFnQixVQUFVO0NBQ3RCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxPQUFPLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLFVBQVU7Q0FDdkQsQ0FBQztBQUNMOzs7QUNGQSxTQUFnQixpQkFBaUIsUUFBUSxTQUFTO0NBQzlDLE9BQU8sS0FBSyxRQUFRLEdBQUcsU0FBUyxTQUFVLFNBQVM7RUFBRSxPQUFPLE9BQU8sT0FBTztDQUFHLENBQUMsR0FBRyxVQUFVLGlCQUFpQixPQUFPLElBQUksUUFBUTtBQUNuSTs7O0FDTEEsU0FBZ0IsaUJBQWlCLFNBQVM7Q0FDdEMsT0FBTyxpQkFBaUJDLGlCQUFlLE9BQU87QUFDbEQ7OztBQ0hBLElBQVcsYUFBYTs7O0FDTXhCLFNBQWdCLGdCQUFnQjtDQUM1QixJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7Q0FFekIsSUFBSSxpQkFBaUIsa0JBQWtCLElBQUk7Q0FDM0MsT0FBTyxpQkFDRCxLQUFLLGNBQWMsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsT0FBTyxJQUFJLENBQUMsQ0FBQyxHQUFHLGlCQUFpQixjQUFjLENBQUMsSUFDbkcsUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUNwQyxrQkFBa0IsY0FBYyxDQUFDLE1BQU0sR0FBRyxPQUFPLGVBQWUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtDQUN2RixDQUFDO0FBQ1Q7OztBQ2hCQSxTQUFnQixvQkFBb0I7Q0FDaEMsSUFBSSxlQUFlLENBQUM7Q0FDcEIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxhQUFhLE1BQU0sVUFBVTtDQUVqQyxPQUFPLGNBQWMsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUM5RTs7O0FDTkEsU0FBZ0IsVUFBVSxTQUFTLGdCQUFnQjtDQUMvQyxPQUFPLFdBQVcsY0FBYyxJQUFJLFNBQVMsU0FBUyxnQkFBZ0IsQ0FBQyxJQUFJLFNBQVMsU0FBUyxDQUFDO0FBQ2xHOzs7QUNGQSxTQUFnQixZQUFZLGlCQUFpQixnQkFBZ0I7Q0FDekQsT0FBTyxXQUFXLGNBQWMsSUFBSSxVQUFVLFdBQVk7RUFBRSxPQUFPO0NBQWlCLEdBQUcsY0FBYyxJQUFJLFVBQVUsV0FBWTtFQUFFLE9BQU87Q0FBaUIsQ0FBQztBQUM5Sjs7O0FDQ0EsU0FBZ0IsU0FBUztDQUNyQixJQUFJLE9BQU8sQ0FBQztDQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsS0FBSyxNQUFNLFVBQVU7Q0FFekIsSUFBSSxZQUFZLGFBQWEsSUFBSTtDQUNqQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsVUFBVSxDQUFDLENBQUMsS0FBSyxjQUFjLENBQUMsTUFBTSxHQUFHLE9BQU8sSUFBSSxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLFVBQVU7Q0FDNUYsQ0FBQztBQUNMOzs7QUNaQSxTQUFnQixhQUFhO0NBQ3pCLElBQUksZUFBZSxDQUFDO0NBQ3BCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsYUFBYSxNQUFNLFVBQVU7Q0FFakMsT0FBTyxPQUFPLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxHQUFHLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDdkU7OztBQ1BBLFNBQWdCLGlCQUFpQixjQUFjO0NBQzNDLE9BQU8sSUFBSSxXQUFXLFNBQVUsWUFBWTtFQUFFLE9BQU8sYUFBYSxVQUFVLFVBQVU7Q0FBRyxDQUFDO0FBQzlGOzs7QUNDQSxJQUFJLGlCQUFpQixFQUNqQixXQUFXLFdBQVk7Q0FBRSxPQUFPLElBQUksUUFBUTtBQUFHLEVBQ25EO0FBQ0EsU0FBZ0IsUUFBUSxVQUFVLFFBQVE7Q0FDdEMsSUFBSSxXQUFXLEtBQUssR0FBSyxTQUFTO0NBQ2xDLElBQUksWUFBWSxPQUFPO0NBQ3ZCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFVBQVUsVUFBVTtFQUN4QixVQUFVLFNBQVMsaUJBQWlCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLFVBQVU7RUFDbkUsV0FBVyxJQUFJLE9BQU8sVUFBVSxPQUFPLENBQUM7Q0FDNUMsQ0FBQztBQUNMOzs7QUNkQSxTQUFnQixNQUFNLFdBQVc7Q0FDN0IsT0FBTyxPQUFPLFNBQVUsT0FBTyxPQUFPLEdBQUc7RUFBRSxPQUFRLENBQUMsYUFBYSxVQUFVLE9BQU8sQ0FBQyxJQUFJLFFBQVEsSUFBSTtDQUFRLEdBQUcsQ0FBQztBQUNuSDs7O0FDQ0EsU0FBZ0IsU0FBUyxrQkFBa0I7Q0FDdkMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksV0FBVztFQUNmLElBQUksWUFBWTtFQUNoQixJQUFJLHFCQUFxQjtFQUN6QixJQUFJLE9BQU8sV0FBWTtHQUNuQix1QkFBdUIsUUFBUSx1QkFBdUIsS0FBSyxLQUFhLG1CQUFtQixZQUFZO0dBQ3ZHLHFCQUFxQjtHQUNyQixJQUFJLFVBQVU7SUFDVixXQUFXO0lBQ1gsSUFBSSxRQUFRO0lBQ1osWUFBWTtJQUNaLFdBQVcsS0FBSyxLQUFLO0dBQ3pCO0VBQ0o7RUFDQSxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLHVCQUF1QixRQUFRLHVCQUF1QixLQUFLLEtBQWEsbUJBQW1CLFlBQVk7R0FDdkcsV0FBVztHQUNYLFlBQVk7R0FDWixxQkFBcUIseUJBQXlCLFlBQVksTUFBTSxJQUFJO0dBQ3BFLFVBQVUsaUJBQWlCLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxrQkFBa0I7RUFDbkUsR0FBRyxXQUFZO0dBQ1gsS0FBSztHQUNMLFdBQVcsU0FBUztFQUN4QixHQUFHLEtBQUEsR0FBVyxXQUFZO0dBQ3RCLFlBQVkscUJBQXFCO0VBQ3JDLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDN0JBLFNBQWdCLGFBQWEsU0FBUyxXQUFXO0NBQzdDLElBQUksY0FBYyxLQUFLLEdBQUssWUFBWTtDQUN4QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxhQUFhO0VBQ2pCLElBQUksWUFBWTtFQUNoQixJQUFJLFdBQVc7RUFDZixJQUFJLE9BQU8sV0FBWTtHQUNuQixJQUFJLFlBQVk7SUFDWixXQUFXLFlBQVk7SUFDdkIsYUFBYTtJQUNiLElBQUksUUFBUTtJQUNaLFlBQVk7SUFDWixXQUFXLEtBQUssS0FBSztHQUN6QjtFQUNKO0VBQ0EsU0FBUyxlQUFlO0dBQ3BCLElBQUksYUFBYSxXQUFXO0dBQzVCLElBQUksTUFBTSxVQUFVLElBQUk7R0FDeEIsSUFBSSxNQUFNLFlBQVk7SUFDbEIsYUFBYSxLQUFLLFNBQVMsS0FBQSxHQUFXLGFBQWEsR0FBRztJQUN0RCxXQUFXLElBQUksVUFBVTtJQUN6QjtHQUNKO0dBQ0EsS0FBSztFQUNUO0VBQ0EsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxZQUFZO0dBQ1osV0FBVyxVQUFVLElBQUk7R0FDekIsSUFBSSxDQUFDLFlBQVk7SUFDYixhQUFhLFVBQVUsU0FBUyxjQUFjLE9BQU87SUFDckQsV0FBVyxJQUFJLFVBQVU7R0FDN0I7RUFDSixHQUFHLFdBQVk7R0FDWCxLQUFLO0dBQ0wsV0FBVyxTQUFTO0VBQ3hCLEdBQUcsS0FBQSxHQUFXLFdBQVk7R0FDdEIsWUFBWSxhQUFhO0VBQzdCLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDeENBLFNBQWdCLGVBQWUsY0FBYztDQUN6QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxXQUFXO0VBQ2YsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxXQUFXO0dBQ1gsV0FBVyxLQUFLLEtBQUs7RUFDekIsR0FBRyxXQUFZO0dBQ1gsSUFBSSxDQUFDLFVBQ0QsV0FBVyxLQUFLLFlBQVk7R0FFaEMsV0FBVyxTQUFTO0VBQ3hCLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDWkEsU0FBZ0IsS0FBSyxPQUFPO0NBQ3hCLE9BQU8sU0FBUyxJQUVSLFdBQVk7RUFBRSxPQUFPO0NBQU8sSUFDOUIsUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUNwQyxJQUFJLE9BQU87RUFDWCxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLElBQUksRUFBRSxRQUFRLE9BQU87SUFDakIsV0FBVyxLQUFLLEtBQUs7SUFDckIsSUFBSSxTQUFTLE1BQ1QsV0FBVyxTQUFTO0dBRTVCO0VBQ0osQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNUOzs7QUNmQSxTQUFnQixpQkFBaUI7Q0FDN0IsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxJQUFJLENBQUM7Q0FDL0QsQ0FBQztBQUNMOzs7QUNOQSxTQUFnQixNQUFNLE9BQU87Q0FDekIsT0FBTyxJQUFJLFdBQVk7RUFBRSxPQUFPO0NBQU8sQ0FBQztBQUM1Qzs7O0FDR0EsU0FBZ0IsVUFBVSx1QkFBdUIsbUJBQW1CO0NBQ2hFLElBQUksbUJBQ0EsT0FBTyxTQUFVLFFBQVE7RUFDckIsT0FBT0MsU0FBTyxrQkFBa0IsS0FBSyxLQUFLLENBQUMsR0FBRyxlQUFlLENBQUMsR0FBRyxPQUFPLEtBQUssVUFBVSxxQkFBcUIsQ0FBQyxDQUFDO0NBQ2xIO0NBRUosT0FBTyxTQUFTLFNBQVUsT0FBTyxPQUFPO0VBQUUsT0FBTyxVQUFVLHNCQUFzQixPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEtBQUssQ0FBQztDQUFHLENBQUM7QUFDbEk7OztBQ1ZBLFNBQWdCLE1BQU0sS0FBSyxXQUFXO0NBQ2xDLElBQUksY0FBYyxLQUFLLEdBQUssWUFBWTtDQUN4QyxJQUFJLFdBQVcsTUFBTSxLQUFLLFNBQVM7Q0FDbkMsT0FBTyxVQUFVLFdBQVk7RUFBRSxPQUFPO0NBQVUsQ0FBQztBQUNyRDs7O0FDSkEsU0FBZ0IsZ0JBQWdCO0NBQzVCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxjQUFjO0dBQUUsT0FBTyxvQkFBb0IsY0FBYyxVQUFVO0VBQUcsQ0FBQyxDQUFDO0NBQzVJLENBQUM7QUFDTDs7O0FDSEEsU0FBZ0IsU0FBUyxhQUFhLFNBQVM7Q0FDM0MsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksK0JBQWUsSUFBSSxJQUFJO0VBQzNCLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsSUFBSSxNQUFNLGNBQWMsWUFBWSxLQUFLLElBQUk7R0FDN0MsSUFBSSxDQUFDLGFBQWEsSUFBSSxHQUFHLEdBQUc7SUFDeEIsYUFBYSxJQUFJLEdBQUc7SUFDcEIsV0FBVyxLQUFLLEtBQUs7R0FDekI7RUFDSixDQUFDLENBQUM7RUFDRixXQUFXLFVBQVUsT0FBTyxDQUFDLENBQUMsVUFBVSx5QkFBeUIsWUFBWSxXQUFZO0dBQUUsT0FBTyxhQUFhLE1BQU07RUFBRyxHQUFHLElBQUksQ0FBQztDQUNwSSxDQUFDO0FBQ0w7OztBQ2JBLFNBQWdCLHFCQUFxQixZQUFZLGFBQWE7Q0FDMUQsSUFBSSxnQkFBZ0IsS0FBSyxHQUFLLGNBQWM7Q0FDNUMsYUFBYSxlQUFlLFFBQVEsZUFBZSxLQUFLLElBQUksYUFBYTtDQUN6RSxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSTtFQUNKLElBQUksUUFBUTtFQUNaLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsSUFBSSxhQUFhLFlBQVksS0FBSztHQUNsQyxJQUFJLFNBQVMsQ0FBQyxXQUFXLGFBQWEsVUFBVSxHQUFHO0lBQy9DLFFBQVE7SUFDUixjQUFjO0lBQ2QsV0FBVyxLQUFLLEtBQUs7R0FDekI7RUFDSixDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7QUFDQSxTQUFTLGVBQWUsR0FBRyxHQUFHO0NBQzFCLE9BQU8sTUFBTTtBQUNqQjs7O0FDcEJBLFNBQWdCLHdCQUF3QixLQUFLLFNBQVM7Q0FDbEQsT0FBTyxxQkFBcUIsU0FBVSxHQUFHLEdBQUc7RUFBRSxPQUFRLFVBQVUsUUFBUSxFQUFFLE1BQU0sRUFBRSxJQUFJLElBQUksRUFBRSxTQUFTLEVBQUU7Q0FBTyxDQUFDO0FBQ25IOzs7QUNBQSxTQUFnQixhQUFhLGNBQWM7Q0FDdkMsSUFBSSxpQkFBaUIsS0FBSyxHQUFLLGVBQWU7Q0FDOUMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksV0FBVztFQUNmLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsV0FBVztHQUNYLFdBQVcsS0FBSyxLQUFLO0VBQ3pCLEdBQUcsV0FBWTtHQUFFLE9BQVEsV0FBVyxXQUFXLFNBQVMsSUFBSSxXQUFXLE1BQU0sYUFBYSxDQUFDO0VBQUksQ0FBQyxDQUFDO0NBQ3JHLENBQUM7QUFDTDtBQUNBLFNBQVMsc0JBQXNCO0NBQzNCLE9BQU8sSUFBSSxXQUFXO0FBQzFCOzs7QUNWQSxTQUFnQixVQUFVLE9BQU8sY0FBYztDQUMzQyxJQUFJLFFBQVEsR0FDUixNQUFNLElBQUksd0JBQXdCO0NBRXRDLElBQUksa0JBQWtCLFVBQVUsVUFBVTtDQUMxQyxPQUFPLFNBQVUsUUFBUTtFQUNyQixPQUFPLE9BQU8sS0FBSyxPQUFPLFNBQVUsR0FBRyxHQUFHO0dBQUUsT0FBTyxNQUFNO0VBQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLGtCQUFrQixlQUFlLFlBQVksSUFBSSxhQUFhLFdBQVk7R0FBRSxPQUFPLElBQUksd0JBQXdCO0VBQUcsQ0FBQyxDQUFDO0NBQ3JNO0FBQ0o7OztBQ1ZBLFNBQWdCLFVBQVU7Q0FDdEIsSUFBSSxTQUFTLENBQUM7Q0FDZCxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLE9BQU8sTUFBTSxVQUFVO0NBRTNCLE9BQU8sU0FBVSxRQUFRO0VBQUUsT0FBT0MsU0FBTyxRQUFRLEdBQUcsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDO0NBQUc7QUFDM0c7OztBQ1BBLFNBQWdCLE1BQU0sV0FBVyxTQUFTO0NBQ3RDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFFBQVE7RUFDWixPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLElBQUksQ0FBQyxVQUFVLEtBQUssU0FBUyxPQUFPLFNBQVMsTUFBTSxHQUFHO0lBQ2xELFdBQVcsS0FBSyxLQUFLO0lBQ3JCLFdBQVcsU0FBUztHQUN4QjtFQUNKLEdBQUcsV0FBWTtHQUNYLFdBQVcsS0FBSyxJQUFJO0dBQ3BCLFdBQVcsU0FBUztFQUN4QixDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7OztBQ1hBLFNBQWdCLFdBQVcsU0FBUyxnQkFBZ0I7Q0FDaEQsSUFBSSxnQkFDQSxPQUFPLFNBQVUsUUFBUTtFQUNyQixPQUFPLE9BQU8sS0FBSyxXQUFXLFNBQVUsR0FBRyxHQUFHO0dBQUUsT0FBTyxVQUFVLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxTQUFVLEdBQUcsSUFBSTtJQUFFLE9BQU8sZUFBZSxHQUFHLEdBQUcsR0FBRyxFQUFFO0dBQUcsQ0FBQyxDQUFDO0VBQUcsQ0FBQyxDQUFDO0NBQzNKO0NBRUosT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksUUFBUTtFQUNaLElBQUksV0FBVztFQUNmLElBQUksYUFBYTtFQUNqQixPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxZQUFZO0dBQ3hFLElBQUksQ0FBQyxVQUFVO0lBQ1gsV0FBVyx5QkFBeUIsWUFBWSxLQUFBLEdBQVcsV0FBWTtLQUNuRSxXQUFXO0tBQ1gsY0FBYyxXQUFXLFNBQVM7SUFDdEMsQ0FBQztJQUNELFVBQVUsUUFBUSxZQUFZLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVSxRQUFRO0dBQzlEO0VBQ0osR0FBRyxXQUFZO0dBQ1gsYUFBYTtHQUNiLENBQUMsWUFBWSxXQUFXLFNBQVM7RUFDckMsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUN6QkEsU0FBZ0IsYUFBYTtDQUN6QixPQUFPLFdBQVcsUUFBUTtBQUM5Qjs7O0FDSEEsSUFBVyxVQUFVOzs7QUNDckIsU0FBZ0IsT0FBTyxTQUFTLFlBQVksV0FBVztDQUNuRCxJQUFJLGVBQWUsS0FBSyxHQUFLLGFBQWE7Q0FDMUMsY0FBYyxjQUFjLEtBQUssSUFBSSxXQUFXO0NBQ2hELE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxPQUFPLGVBQWUsUUFBUSxZQUFZLFNBQVMsWUFBWSxLQUFBLEdBQVcsTUFBTSxTQUFTO0NBQzdGLENBQUM7QUFDTDs7O0FDUEEsU0FBZ0IsU0FBUyxVQUFVO0NBQy9CLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJO0dBQ0EsT0FBTyxVQUFVLFVBQVU7RUFDL0IsVUFDUTtHQUNKLFdBQVcsSUFBSSxRQUFRO0VBQzNCO0NBQ0osQ0FBQztBQUNMOzs7QUNSQSxTQUFnQixLQUFLLFdBQVcsU0FBUztDQUNyQyxPQUFPLFFBQVEsV0FBVyxXQUFXLFNBQVMsT0FBTyxDQUFDO0FBQzFEO0FBQ0EsU0FBZ0IsV0FBVyxXQUFXLFNBQVMsTUFBTTtDQUNqRCxJQUFJLFlBQVksU0FBUztDQUN6QixPQUFPLFNBQVUsUUFBUSxZQUFZO0VBQ2pDLElBQUksUUFBUTtFQUNaLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsSUFBSSxJQUFJO0dBQ1IsSUFBSSxVQUFVLEtBQUssU0FBUyxPQUFPLEdBQUcsTUFBTSxHQUFHO0lBQzNDLFdBQVcsS0FBSyxZQUFZLElBQUksS0FBSztJQUNyQyxXQUFXLFNBQVM7R0FDeEI7RUFDSixHQUFHLFdBQVk7R0FDWCxXQUFXLEtBQUssWUFBWSxLQUFLLEtBQUEsQ0FBUztHQUMxQyxXQUFXLFNBQVM7RUFDeEIsQ0FBQyxDQUFDO0NBQ047QUFDSjs7O0FDbEJBLFNBQWdCLFVBQVUsV0FBVyxTQUFTO0NBQzFDLE9BQU8sUUFBUSxXQUFXLFdBQVcsU0FBUyxPQUFPLENBQUM7QUFDMUQ7OztBQ0VBLFNBQWdCLE1BQU0sV0FBVyxjQUFjO0NBQzNDLElBQUksa0JBQWtCLFVBQVUsVUFBVTtDQUMxQyxPQUFPLFNBQVUsUUFBUTtFQUNyQixPQUFPLE9BQU8sS0FBSyxZQUFZLE9BQU8sU0FBVSxHQUFHLEdBQUc7R0FBRSxPQUFPLFVBQVUsR0FBRyxHQUFHLE1BQU07RUFBRyxDQUFDLElBQUksVUFBVSxLQUFLLENBQUMsR0FBRyxrQkFBa0IsZUFBZSxZQUFZLElBQUksYUFBYSxXQUFZO0dBQUUsT0FBTyxJQUFJLFdBQVc7RUFBRyxDQUFDLENBQUM7Q0FDM047QUFDSjs7O0FDTkEsU0FBZ0IsUUFBUSxhQUFhLGtCQUFrQixVQUFVLFdBQVc7Q0FDeEUsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUk7RUFDSixJQUFJLENBQUMsb0JBQW9CLE9BQU8scUJBQXFCLFlBQ2pELFVBQVU7T0FHVixXQUFZLGlCQUFpQixVQUFVLFVBQVUsaUJBQWlCLFNBQVMsWUFBWSxpQkFBaUI7RUFFNUcsSUFBSSx5QkFBUyxJQUFJLElBQUk7RUFDckIsSUFBSSxTQUFTLFNBQVUsSUFBSTtHQUN2QixPQUFPLFFBQVEsRUFBRTtHQUNqQixHQUFHLFVBQVU7RUFDakI7RUFDQSxJQUFJLGNBQWMsU0FBVSxLQUFLO0dBQUUsT0FBTyxPQUFPLFNBQVUsVUFBVTtJQUFFLE9BQU8sU0FBUyxNQUFNLEdBQUc7R0FBRyxDQUFDO0VBQUc7RUFDdkcsSUFBSSxlQUFlO0VBQ25CLElBQUksb0JBQW9CO0VBQ3hCLElBQUksMEJBQTBCLElBQUksbUJBQW1CLFlBQVksU0FBVSxPQUFPO0dBQzlFLElBQUk7SUFDQSxJQUFJLFFBQVEsWUFBWSxLQUFLO0lBQzdCLElBQUksVUFBVSxPQUFPLElBQUksS0FBSztJQUM5QixJQUFJLENBQUMsU0FBUztLQUNWLE9BQU8sSUFBSSxPQUFRLFVBQVUsWUFBWSxVQUFVLElBQUksSUFBSSxRQUFRLENBQUU7S0FDckUsSUFBSSxVQUFVLHdCQUF3QixPQUFPLE9BQU87S0FDcEQsV0FBVyxLQUFLLE9BQU87S0FDdkIsSUFBSSxVQUFVO01BQ1YsSUFBSSx1QkFBdUIseUJBQXlCLFNBQVMsV0FBWTtPQUNyRSxRQUFRLFNBQVM7T0FDakIseUJBQXlCLFFBQVEseUJBQXlCLEtBQUssS0FBYSxxQkFBcUIsWUFBWTtNQUNqSCxHQUFHLEtBQUEsR0FBVyxLQUFBLEdBQVcsV0FBWTtPQUFFLE9BQU8sT0FBTyxPQUFPLEtBQUs7TUFBRyxDQUFDO01BQ3JFLHdCQUF3QixJQUFJLFVBQVUsU0FBUyxPQUFPLENBQUMsQ0FBQyxDQUFDLFVBQVUsb0JBQW9CLENBQUM7S0FDNUY7SUFDSjtJQUNBLFFBQVEsS0FBSyxVQUFVLFFBQVEsS0FBSyxJQUFJLEtBQUs7R0FDakQsU0FDTyxLQUFLO0lBQ1IsWUFBWSxHQUFHO0dBQ25CO0VBQ0osR0FBRyxXQUFZO0dBQUUsT0FBTyxPQUFPLFNBQVUsVUFBVTtJQUFFLE9BQU8sU0FBUyxTQUFTO0dBQUcsQ0FBQztFQUFHLEdBQUcsYUFBYSxXQUFZO0dBQUUsT0FBTyxPQUFPLE1BQU07RUFBRyxHQUFHLFdBQVk7R0FDckosb0JBQW9CO0dBQ3BCLE9BQU8saUJBQWlCO0VBQzVCLENBQUM7RUFDRCxPQUFPLFVBQVUsdUJBQXVCO0VBQ3hDLFNBQVMsd0JBQXdCLEtBQUssY0FBYztHQUNoRCxJQUFJLFNBQVMsSUFBSSxXQUFXLFNBQVUsaUJBQWlCO0lBQ25EO0lBQ0EsSUFBSSxXQUFXLGFBQWEsVUFBVSxlQUFlO0lBQ3JELE9BQU8sV0FBWTtLQUNmLFNBQVMsWUFBWTtLQUNyQixFQUFFLGlCQUFpQixLQUFLLHFCQUFxQix3QkFBd0IsWUFBWTtJQUNyRjtHQUNKLENBQUM7R0FDRCxPQUFPLE1BQU07R0FDYixPQUFPO0VBQ1g7Q0FDSixDQUFDO0FBQ0w7OztBQzNEQSxTQUFnQixVQUFVO0NBQ3RCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxPQUFPLFVBQVUseUJBQXlCLFlBQVksV0FBWTtHQUM5RCxXQUFXLEtBQUssS0FBSztHQUNyQixXQUFXLFNBQVM7RUFDeEIsR0FBRyxXQUFZO0dBQ1gsV0FBVyxLQUFLLElBQUk7R0FDcEIsV0FBVyxTQUFTO0VBQ3hCLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDUkEsU0FBZ0IsU0FBUyxPQUFPO0NBQzVCLE9BQU8sU0FBUyxJQUNWLFdBQVk7RUFBRSxPQUFPO0NBQU8sSUFDNUIsUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUNwQyxJQUFJLFNBQVMsQ0FBQztFQUNkLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsT0FBTyxLQUFLLEtBQUs7R0FDakIsUUFBUSxPQUFPLFVBQVUsT0FBTyxNQUFNO0VBQzFDLEdBQUcsV0FBWTtHQUNYLElBQUksS0FBSztHQUNULElBQUk7SUFDQSxLQUFLLElBQUksV0FBVyxTQUFTLE1BQU0sR0FBRyxhQUFhLFNBQVMsS0FBSyxHQUFHLENBQUMsV0FBVyxNQUFNLGFBQWEsU0FBUyxLQUFLLEdBQUc7S0FDaEgsSUFBSSxRQUFRLFdBQVc7S0FDdkIsV0FBVyxLQUFLLEtBQUs7SUFDekI7R0FDSixTQUNPLE9BQU87SUFBRSxNQUFNLEVBQUUsT0FBTyxNQUFNO0dBQUcsVUFDaEM7SUFDSixJQUFJO0tBQ0EsSUFBSSxjQUFjLENBQUMsV0FBVyxTQUFTLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxRQUFRO0lBQ2xGLFVBQ1E7S0FBRSxJQUFJLEtBQUssTUFBTSxJQUFJO0lBQU87R0FDeEM7R0FDQSxXQUFXLFNBQVM7RUFDeEIsR0FBRyxLQUFBLEdBQVcsV0FBWTtHQUN0QixTQUFTO0VBQ2IsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNUOzs7QUMxQkEsU0FBZ0IsS0FBSyxXQUFXLGNBQWM7Q0FDMUMsSUFBSSxrQkFBa0IsVUFBVSxVQUFVO0NBQzFDLE9BQU8sU0FBVSxRQUFRO0VBQ3JCLE9BQU8sT0FBTyxLQUFLLFlBQVksT0FBTyxTQUFVLEdBQUcsR0FBRztHQUFFLE9BQU8sVUFBVSxHQUFHLEdBQUcsTUFBTTtFQUFHLENBQUMsSUFBSSxVQUFVLFNBQVMsQ0FBQyxHQUFHLGtCQUFrQixlQUFlLFlBQVksSUFBSSxhQUFhLFdBQVk7R0FBRSxPQUFPLElBQUksV0FBVztFQUFHLENBQUMsQ0FBQztDQUMvTjtBQUNKOzs7QUNSQSxTQUFnQixjQUFjO0NBQzFCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLFdBQVcsS0FBSyxhQUFhLFdBQVcsS0FBSyxDQUFDO0VBQ2xELEdBQUcsV0FBWTtHQUNYLFdBQVcsS0FBSyxhQUFhLGVBQWUsQ0FBQztHQUM3QyxXQUFXLFNBQVM7RUFDeEIsR0FBRyxTQUFVLEtBQUs7R0FDZCxXQUFXLEtBQUssYUFBYSxZQUFZLEdBQUcsQ0FBQztHQUM3QyxXQUFXLFNBQVM7RUFDeEIsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUNiQSxTQUFnQixJQUFJLFVBQVU7Q0FDMUIsT0FBTyxPQUFPLFdBQVcsUUFBUSxJQUFJLFNBQVUsR0FBRyxHQUFHO0VBQUUsT0FBUSxTQUFTLEdBQUcsQ0FBQyxJQUFJLElBQUksSUFBSTtDQUFJLElBQUksU0FBVSxHQUFHLEdBQUc7RUFBRSxPQUFRLElBQUksSUFBSSxJQUFJO0NBQUksQ0FBQztBQUMvSTs7O0FDSEEsSUFBVyxVQUFVOzs7QUNDckIsU0FBZ0IsV0FBVyxpQkFBaUIsZ0JBQWdCLFlBQVk7Q0FDcEUsSUFBSSxlQUFlLEtBQUssR0FBSyxhQUFhO0NBQzFDLElBQUksV0FBVyxjQUFjLEdBQ3pCLE9BQU8sU0FBUyxXQUFZO0VBQUUsT0FBTztDQUFpQixHQUFHLGdCQUFnQixVQUFVO0NBRXZGLElBQUksT0FBTyxtQkFBbUIsVUFDMUIsYUFBYTtDQUVqQixPQUFPLFNBQVMsV0FBWTtFQUFFLE9BQU87Q0FBaUIsR0FBRyxVQUFVO0FBQ3ZFOzs7QUNUQSxTQUFnQixVQUFVLGFBQWEsTUFBTSxZQUFZO0NBQ3JELElBQUksZUFBZSxLQUFLLEdBQUssYUFBYTtDQUMxQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxRQUFRO0VBQ1osT0FBTyxlQUFlLFFBQVEsWUFBWSxTQUFVLE9BQU8sT0FBTztHQUFFLE9BQU8sWUFBWSxPQUFPLE9BQU8sS0FBSztFQUFHLEdBQUcsWUFBWSxTQUFVLE9BQU87R0FDekksUUFBUTtFQUNaLEdBQUcsT0FBTyxLQUFBLEdBQVcsV0FBWTtHQUFFLE9BQVEsUUFBUTtFQUFPLENBQUM7Q0FDL0QsQ0FBQztBQUNMOzs7QUNMQSxTQUFnQixRQUFRO0NBQ3BCLElBQUksT0FBTyxDQUFDO0NBQ1osS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxLQUFLLE1BQU0sVUFBVTtDQUV6QixJQUFJLFlBQVksYUFBYSxJQUFJO0NBQ2pDLElBQUksYUFBYSxVQUFVLE1BQU0sUUFBUTtDQUN6QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsU0FBUyxVQUFVLENBQUMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxJQUFJLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsVUFBVTtDQUNyRyxDQUFDO0FBQ0w7OztBQ2JBLFNBQWdCLFlBQVk7Q0FDeEIsSUFBSSxlQUFlLENBQUM7Q0FDcEIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxhQUFhLE1BQU0sVUFBVTtDQUVqQyxPQUFPLE1BQU0sTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUN0RTs7O0FDTkEsU0FBZ0IsSUFBSSxVQUFVO0NBQzFCLE9BQU8sT0FBTyxXQUFXLFFBQVEsSUFBSSxTQUFVLEdBQUcsR0FBRztFQUFFLE9BQVEsU0FBUyxHQUFHLENBQUMsSUFBSSxJQUFJLElBQUk7Q0FBSSxJQUFJLFNBQVUsR0FBRyxHQUFHO0VBQUUsT0FBUSxJQUFJLElBQUksSUFBSTtDQUFJLENBQUM7QUFDL0k7OztBQ0RBLFNBQWdCLFVBQVUseUJBQXlCLFVBQVU7Q0FDekQsSUFBSSxpQkFBaUIsV0FBVyx1QkFBdUIsSUFBSSwwQkFBMEIsV0FBWTtFQUFFLE9BQU87Q0FBeUI7Q0FDbkksSUFBSSxXQUFXLFFBQVEsR0FDbkIsT0FBTyxRQUFRLFVBQVUsRUFDckIsV0FBVyxlQUNmLENBQUM7Q0FFTCxPQUFPLFNBQVUsUUFBUTtFQUFFLE9BQU8sSUFBSSxzQkFBc0IsUUFBUSxjQUFjO0NBQUc7QUFDekY7OztBQ1JBLFNBQWdCLHdCQUF3QjtDQUNwQyxJQUFJLFVBQVUsQ0FBQztDQUNmLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsUUFBUSxNQUFNLFVBQVU7Q0FFNUIsSUFBSSxjQUFjLGVBQWUsT0FBTztDQUN4QyxPQUFPLFNBQVUsUUFBUTtFQUFFLE9BQU9DLG9CQUFXLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxXQUFXLENBQUMsQ0FBQztDQUFHO0FBQzlHO0FBQ0EsSUFBVyxvQkFBb0I7OztBQ1QvQixTQUFnQixXQUFXO0NBQ3ZCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJO0VBQ0osSUFBSSxVQUFVO0VBQ2QsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLElBQUk7R0FDUixPQUFPO0dBQ1AsV0FBVyxXQUFXLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQztHQUNyQyxVQUFVO0VBQ2QsQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUNaQSxTQUFnQixRQUFRO0NBQ3BCLElBQUksYUFBYSxDQUFDO0NBQ2xCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsV0FBVyxNQUFNLFVBQVU7Q0FFL0IsSUFBSSxTQUFTLFdBQVc7Q0FDeEIsSUFBSSxXQUFXLEdBQ1gsTUFBTSxJQUFJLE1BQU0scUNBQXFDO0NBRXpELE9BQU8sSUFBSSxTQUFVLEdBQUc7RUFDcEIsSUFBSSxjQUFjO0VBQ2xCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7R0FDN0IsSUFBSSxJQUFJLGdCQUFnQixRQUFRLGdCQUFnQixLQUFLLElBQUksS0FBSyxJQUFJLFlBQVksV0FBVztHQUN6RixJQUFJLE9BQU8sTUFBTSxhQUNiLGNBQWM7UUFHZDtFQUVSO0VBQ0EsT0FBTztDQUNYLENBQUM7QUFDTDs7O0FDcEJBLFNBQWdCLFFBQVEsVUFBVTtDQUM5QixPQUFPLFdBQVcsU0FBVSxRQUFRO0VBQUUsT0FBTyxRQUFRLFFBQVEsQ0FBQyxDQUFDLE1BQU07Q0FBRyxJQUFJLFNBQVUsUUFBUTtFQUFFLE9BQU8sVUFBVSxJQUFJLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtDQUFHO0FBQzdJOzs7QUNIQSxTQUFnQixnQkFBZ0IsY0FBYztDQUMxQyxPQUFPLFNBQVUsUUFBUTtFQUNyQixJQUFJLFVBQVUsSUFBSSxnQkFBZ0IsWUFBWTtFQUM5QyxPQUFPLElBQUksc0JBQXNCLFFBQVEsV0FBWTtHQUFFLE9BQU87RUFBUyxDQUFDO0NBQzVFO0FBQ0o7OztBQ0xBLFNBQWdCLGNBQWM7Q0FDMUIsT0FBTyxTQUFVLFFBQVE7RUFDckIsSUFBSSxVQUFVLElBQUksYUFBYTtFQUMvQixPQUFPLElBQUksc0JBQXNCLFFBQVEsV0FBWTtHQUFFLE9BQU87RUFBUyxDQUFDO0NBQzVFO0FBQ0o7OztBQ0pBLFNBQWdCLGNBQWMsWUFBWSxZQUFZLHFCQUFxQixtQkFBbUI7Q0FDMUYsSUFBSSx1QkFBdUIsQ0FBQyxXQUFXLG1CQUFtQixHQUN0RCxvQkFBb0I7Q0FFeEIsSUFBSSxXQUFXLFdBQVcsbUJBQW1CLElBQUksc0JBQXNCLEtBQUE7Q0FDdkUsT0FBTyxTQUFVLFFBQVE7RUFBRSxPQUFPLFVBQVUsSUFBSSxjQUFjLFlBQVksWUFBWSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsQ0FBQyxNQUFNO0NBQUc7QUFDakk7OztBQ0xBLFNBQWdCLFdBQVc7Q0FDdkIsSUFBSSxlQUFlLENBQUM7Q0FDcEIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLFVBQVUsUUFBUSxNQUNwQyxhQUFhLE1BQU0sVUFBVTtDQUVqQyxPQUFPLENBQUMsYUFBYSxTQUNmLFdBQ0EsUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUNwQyxTQUFTLGNBQWMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtDQUN0RSxDQUFDO0FBQ1Q7OztBQ1RBLFNBQWdCLE9BQU8sZUFBZTtDQUNsQyxJQUFJO0NBQ0osSUFBSSxRQUFRO0NBQ1osSUFBSTtDQUNKLElBQUksaUJBQWlCLE1BQ2pCLElBQUksT0FBTyxrQkFBa0IsVUFDekIsS0FBTSxjQUFjLE9BQU8sUUFBUSxPQUFPLEtBQUssSUFBSSxXQUFXLElBQUksUUFBUSxjQUFjO01BR3hGLFFBQVE7Q0FHaEIsT0FBTyxTQUFTLElBQ1YsV0FBWTtFQUFFLE9BQU87Q0FBTyxJQUM1QixRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3BDLElBQUksUUFBUTtFQUNaLElBQUk7RUFDSixJQUFJLGNBQWMsV0FBWTtHQUMxQixjQUFjLFFBQVEsY0FBYyxLQUFLLEtBQWEsVUFBVSxZQUFZO0dBQzVFLFlBQVk7R0FDWixJQUFJLFNBQVMsTUFBTTtJQUNmLElBQUksV0FBVyxPQUFPLFVBQVUsV0FBVyxNQUFNLEtBQUssSUFBSSxVQUFVLE1BQU0sS0FBSyxDQUFDO0lBQ2hGLElBQUksdUJBQXVCLHlCQUF5QixZQUFZLFdBQVk7S0FDeEUscUJBQXFCLFlBQVk7S0FDakMsa0JBQWtCO0lBQ3RCLENBQUM7SUFDRCxTQUFTLFVBQVUsb0JBQW9CO0dBQzNDLE9BRUksa0JBQWtCO0VBRTFCO0VBQ0EsSUFBSSxvQkFBb0IsV0FBWTtHQUNoQyxJQUFJLFlBQVk7R0FDaEIsWUFBWSxPQUFPLFVBQVUseUJBQXlCLFlBQVksS0FBQSxHQUFXLFdBQVk7SUFDckYsSUFBSSxFQUFFLFFBQVEsT0FDVixJQUFJLFdBQ0EsWUFBWTtTQUdaLFlBQVk7U0FJaEIsV0FBVyxTQUFTO0dBRTVCLENBQUMsQ0FBQztHQUNGLElBQUksV0FDQSxZQUFZO0VBRXBCO0VBQ0Esa0JBQWtCO0NBQ3RCLENBQUM7QUFDVDs7O0FDdERBLFNBQWdCLFdBQVcsVUFBVTtDQUNqQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSTtFQUNKLElBQUksWUFBWTtFQUNoQixJQUFJO0VBQ0osSUFBSSxxQkFBcUI7RUFDekIsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxnQkFBZ0IsV0FBWTtHQUFFLE9BQU8sa0JBQWtCLHVCQUF1QixXQUFXLFNBQVMsR0FBRztFQUFPO0VBQ2hILElBQUksdUJBQXVCLFdBQVk7R0FDbkMsSUFBSSxDQUFDLGNBQWM7SUFDZixlQUFlLElBQUksUUFBUTtJQUMzQixVQUFVLFNBQVMsWUFBWSxDQUFDLENBQUMsQ0FBQyxVQUFVLHlCQUF5QixZQUFZLFdBQVk7S0FDekYsSUFBSSxVQUNBLHVCQUF1QjtVQUd2QixZQUFZO0lBRXBCLEdBQUcsV0FBWTtLQUNYLHFCQUFxQjtLQUNyQixjQUFjO0lBQ2xCLENBQUMsQ0FBQztHQUNOO0dBQ0EsT0FBTztFQUNYO0VBQ0EsSUFBSSx5QkFBeUIsV0FBWTtHQUNyQyxpQkFBaUI7R0FDakIsV0FBVyxPQUFPLFVBQVUseUJBQXlCLFlBQVksS0FBQSxHQUFXLFdBQVk7SUFDcEYsaUJBQWlCO0lBQ2pCLENBQUMsY0FBYyxLQUFLLHFCQUFxQixDQUFDLENBQUMsS0FBSztHQUNwRCxDQUFDLENBQUM7R0FDRixJQUFJLFdBQVc7SUFDWCxTQUFTLFlBQVk7SUFDckIsV0FBVztJQUNYLFlBQVk7SUFDWix1QkFBdUI7R0FDM0I7RUFDSjtFQUNBLHVCQUF1QjtDQUMzQixDQUFDO0FBQ0w7OztBQ3ZDQSxTQUFnQixNQUFNLGVBQWU7Q0FDakMsSUFBSSxrQkFBa0IsS0FBSyxHQUFLLGdCQUFnQjtDQUNoRCxJQUFJO0NBQ0osSUFBSSxpQkFBaUIsT0FBTyxrQkFBa0IsVUFDMUMsU0FBUztNQUdULFNBQVMsRUFDTCxPQUFPLGNBQ1g7Q0FFSixJQUFJLEtBQUssT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLLElBQUksV0FBVyxJQUFJLFFBQVEsT0FBTyxPQUFPLEtBQUssT0FBTyxnQkFBZ0IsaUJBQWlCLE9BQU8sS0FBSyxJQUFJLFFBQVE7Q0FDekosT0FBTyxTQUFTLElBQ1YsV0FDQSxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3BDLElBQUksUUFBUTtFQUNaLElBQUk7RUFDSixJQUFJLG9CQUFvQixXQUFZO0dBQ2hDLElBQUksWUFBWTtHQUNoQixXQUFXLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87SUFDOUUsSUFBSSxnQkFDQSxRQUFRO0lBRVosV0FBVyxLQUFLLEtBQUs7R0FDekIsR0FBRyxLQUFBLEdBQVcsU0FBVSxLQUFLO0lBQ3pCLElBQUksVUFBVSxPQUFPO0tBQ2pCLElBQUksVUFBVSxXQUFZO01BQ3RCLElBQUksVUFBVTtPQUNWLFNBQVMsWUFBWTtPQUNyQixXQUFXO09BQ1gsa0JBQWtCO01BQ3RCLE9BRUksWUFBWTtLQUVwQjtLQUNBLElBQUksU0FBUyxNQUFNO01BQ2YsSUFBSSxXQUFXLE9BQU8sVUFBVSxXQUFXLE1BQU0sS0FBSyxJQUFJLFVBQVUsTUFBTSxLQUFLLEtBQUssQ0FBQztNQUNyRixJQUFJLHVCQUF1Qix5QkFBeUIsWUFBWSxXQUFZO09BQ3hFLHFCQUFxQixZQUFZO09BQ2pDLFFBQVE7TUFDWixHQUFHLFdBQVk7T0FDWCxXQUFXLFNBQVM7TUFDeEIsQ0FBQztNQUNELFNBQVMsVUFBVSxvQkFBb0I7S0FDM0MsT0FFSSxRQUFRO0lBRWhCLE9BRUksV0FBVyxNQUFNLEdBQUc7R0FFNUIsQ0FBQyxDQUFDO0dBQ0YsSUFBSSxXQUFXO0lBQ1gsU0FBUyxZQUFZO0lBQ3JCLFdBQVc7SUFDWCxrQkFBa0I7R0FDdEI7RUFDSjtFQUNBLGtCQUFrQjtDQUN0QixDQUFDO0FBQ1Q7OztBQy9EQSxTQUFnQixVQUFVLFVBQVU7Q0FDaEMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUk7RUFDSixJQUFJLFlBQVk7RUFDaEIsSUFBSTtFQUNKLElBQUksd0JBQXdCLFdBQVk7R0FDcEMsV0FBVyxPQUFPLFVBQVUseUJBQXlCLFlBQVksS0FBQSxHQUFXLEtBQUEsR0FBVyxTQUFVLEtBQUs7SUFDbEcsSUFBSSxDQUFDLFNBQVM7S0FDVixVQUFVLElBQUksUUFBUTtLQUN0QixVQUFVLFNBQVMsT0FBTyxDQUFDLENBQUMsQ0FBQyxVQUFVLHlCQUF5QixZQUFZLFdBQVk7TUFDcEYsT0FBTyxXQUFXLHNCQUFzQixJQUFLLFlBQVk7S0FDN0QsQ0FBQyxDQUFDO0lBQ047SUFDQSxJQUFJLFNBQ0EsUUFBUSxLQUFLLEdBQUc7R0FFeEIsQ0FBQyxDQUFDO0dBQ0YsSUFBSSxXQUFXO0lBQ1gsU0FBUyxZQUFZO0lBQ3JCLFdBQVc7SUFDWCxZQUFZO0lBQ1osc0JBQXNCO0dBQzFCO0VBQ0o7RUFDQSxzQkFBc0I7Q0FDMUIsQ0FBQztBQUNMOzs7QUMxQkEsU0FBZ0IsT0FBTyxVQUFVO0NBQzdCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFdBQVc7RUFDZixJQUFJLFlBQVk7RUFDaEIsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxXQUFXO0dBQ1gsWUFBWTtFQUNoQixDQUFDLENBQUM7RUFDRixVQUFVLFFBQVEsQ0FBQyxDQUFDLFVBQVUseUJBQXlCLFlBQVksV0FBWTtHQUMzRSxJQUFJLFVBQVU7SUFDVixXQUFXO0lBQ1gsSUFBSSxRQUFRO0lBQ1osWUFBWTtJQUNaLFdBQVcsS0FBSyxLQUFLO0dBQ3pCO0VBQ0osR0FBRyxJQUFJLENBQUM7Q0FDWixDQUFDO0FBQ0w7OztBQ2xCQSxTQUFnQixXQUFXLFFBQVEsV0FBVztDQUMxQyxJQUFJLGNBQWMsS0FBSyxHQUFLLFlBQVk7Q0FDeEMsT0FBTyxPQUFPLFNBQVMsUUFBUSxTQUFTLENBQUM7QUFDN0M7OztBQ0pBLFNBQWdCLEtBQUssYUFBYSxNQUFNO0NBQ3BDLE9BQU8sUUFBUSxjQUFjLGFBQWEsTUFBTSxVQUFVLFVBQVUsR0FBRyxJQUFJLENBQUM7QUFDaEY7OztBQ0RBLFNBQWdCLGNBQWMsV0FBVyxZQUFZO0NBQ2pELElBQUksZUFBZSxLQUFLLEdBQUssYUFBYSxTQUFVLEdBQUcsR0FBRztFQUFFLE9BQU8sTUFBTTtDQUFHO0NBQzVFLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLFNBQVMsWUFBWTtFQUN6QixJQUFJLFNBQVMsWUFBWTtFQUN6QixJQUFJLE9BQU8sU0FBVSxTQUFTO0dBQzFCLFdBQVcsS0FBSyxPQUFPO0dBQ3ZCLFdBQVcsU0FBUztFQUN4QjtFQUNBLElBQUksbUJBQW1CLFNBQVUsV0FBVyxZQUFZO0dBQ3BELElBQUksMEJBQTBCLHlCQUF5QixZQUFZLFNBQVUsR0FBRztJQUM1RSxJQUFJLFNBQVMsV0FBVyxRQUFRLFdBQVcsV0FBVztJQUN0RCxJQUFJLE9BQU8sV0FBVyxHQUNsQixXQUFXLEtBQUssS0FBSyxJQUFJLFVBQVUsT0FBTyxLQUFLLENBQUM7U0FHaEQsQ0FBQyxXQUFXLEdBQUcsT0FBTyxNQUFNLENBQUMsS0FBSyxLQUFLLEtBQUs7R0FFcEQsR0FBRyxXQUFZO0lBQ1gsVUFBVSxXQUFXO0lBQ3JCLElBQUksV0FBVyxXQUFXLFVBQVUsU0FBUyxXQUFXO0lBQ3hELFlBQVksS0FBSyxPQUFPLFdBQVcsQ0FBQztJQUNwQyw0QkFBNEIsUUFBUSw0QkFBNEIsS0FBSyxLQUFhLHdCQUF3QixZQUFZO0dBQzFILENBQUM7R0FDRCxPQUFPO0VBQ1g7RUFDQSxPQUFPLFVBQVUsaUJBQWlCLFFBQVEsTUFBTSxDQUFDO0VBQ2pELFVBQVUsU0FBUyxDQUFDLENBQUMsVUFBVSxpQkFBaUIsUUFBUSxNQUFNLENBQUM7Q0FDbkUsQ0FBQztBQUNMO0FBQ0EsU0FBUyxjQUFjO0NBQ25CLE9BQU87RUFDSCxRQUFRLENBQUM7RUFDVCxVQUFVO0NBQ2Q7QUFDSjs7O0FDakNBLFNBQWdCLE1BQU0sU0FBUztDQUMzQixJQUFJLFlBQVksS0FBSyxHQUFLLFVBQVUsQ0FBQztDQUNyQyxJQUFJLEtBQUssUUFBUSxXQUFXLFlBQVksT0FBTyxLQUFLLElBQUksV0FBWTtFQUFFLE9BQU8sSUFBSSxRQUFRO0NBQUcsSUFBSSxJQUFJLEtBQUssUUFBUSxjQUFjLGVBQWUsT0FBTyxLQUFLLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxpQkFBaUIsa0JBQWtCLE9BQU8sS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEscUJBQXFCLHNCQUFzQixPQUFPLEtBQUssSUFBSSxPQUFPO0NBQ25VLE9BQU8sU0FBVSxlQUFlO0VBQzVCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUksV0FBVztFQUNmLElBQUksZUFBZTtFQUNuQixJQUFJLGFBQWE7RUFDakIsSUFBSSxjQUFjLFdBQVk7R0FDMUIsb0JBQW9CLFFBQVEsb0JBQW9CLEtBQUssS0FBYSxnQkFBZ0IsWUFBWTtHQUM5RixrQkFBa0IsS0FBQTtFQUN0QjtFQUNBLElBQUksUUFBUSxXQUFZO0dBQ3BCLFlBQVk7R0FDWixhQUFhLFVBQVUsS0FBQTtHQUN2QixlQUFlLGFBQWE7RUFDaEM7RUFDQSxJQUFJLHNCQUFzQixXQUFZO0dBQ2xDLElBQUksT0FBTztHQUNYLE1BQU07R0FDTixTQUFTLFFBQVEsU0FBUyxLQUFLLEtBQWEsS0FBSyxZQUFZO0VBQ2pFO0VBQ0EsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0dBQ3pDO0dBQ0EsSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUNoQixZQUFZO0dBRWhCLElBQUksT0FBUSxVQUFVLFlBQVksUUFBUSxZQUFZLEtBQUssSUFBSSxVQUFVLFVBQVU7R0FDbkYsV0FBVyxJQUFJLFdBQVk7SUFDdkI7SUFDQSxJQUFJLGFBQWEsS0FBSyxDQUFDLGNBQWMsQ0FBQyxjQUNsQyxrQkFBa0IsWUFBWSxxQkFBcUIsbUJBQW1CO0dBRTlFLENBQUM7R0FDRCxLQUFLLFVBQVUsVUFBVTtHQUN6QixJQUFJLENBQUMsY0FDRCxXQUFXLEdBQUc7SUFDZCxhQUFhLElBQUksZUFBZTtLQUM1QixNQUFNLFNBQVUsT0FBTztNQUFFLE9BQU8sS0FBSyxLQUFLLEtBQUs7S0FBRztLQUNsRCxPQUFPLFNBQVUsS0FBSztNQUNsQixhQUFhO01BQ2IsWUFBWTtNQUNaLGtCQUFrQixZQUFZLE9BQU8sY0FBYyxHQUFHO01BQ3RELEtBQUssTUFBTSxHQUFHO0tBQ2xCO0tBQ0EsVUFBVSxXQUFZO01BQ2xCLGVBQWU7TUFDZixZQUFZO01BQ1osa0JBQWtCLFlBQVksT0FBTyxlQUFlO01BQ3BELEtBQUssU0FBUztLQUNsQjtJQUNKLENBQUM7SUFDRCxVQUFVLE1BQU0sQ0FBQyxDQUFDLFVBQVUsVUFBVTtHQUMxQztFQUNKLENBQUMsQ0FBQyxDQUFDLGFBQWE7Q0FDcEI7QUFDSjtBQUNBLFNBQVMsWUFBWSxPQUFPLElBQUk7Q0FDNUIsSUFBSSxPQUFPLENBQUM7Q0FDWixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLEtBQUssS0FBSyxLQUFLLFVBQVU7Q0FFN0IsSUFBSSxPQUFPLE1BQU07RUFDYixNQUFNO0VBQ047Q0FDSjtDQUNBLElBQUksT0FBTyxPQUNQO0NBRUosSUFBSSxlQUFlLElBQUksZUFBZSxFQUNsQyxNQUFNLFdBQVk7RUFDZCxhQUFhLFlBQVk7RUFDekIsTUFBTTtDQUNWLEVBQ0osQ0FBQztDQUNELE9BQU8sVUFBVSxHQUFHLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxHQUFHLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxZQUFZO0FBQzlGOzs7QUNqRkEsU0FBZ0IsWUFBWSxvQkFBb0IsWUFBWSxXQUFXO0NBQ25FLElBQUksSUFBSSxJQUFJO0NBQ1osSUFBSTtDQUNKLElBQUksV0FBVztDQUNmLElBQUksc0JBQXNCLE9BQU8sdUJBQXVCLFVBQ3BELEtBQU0sbUJBQW1CLFlBQVksYUFBYSxPQUFPLEtBQUssSUFBSSxXQUFXLElBQUksS0FBSyxtQkFBbUIsWUFBWSxhQUFhLE9BQU8sS0FBSyxJQUFJLFdBQVcsSUFBSSxLQUFLLG1CQUFtQixVQUFVLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxJQUFJLFlBQVksbUJBQW1CO01BR3pRLGFBQWMsdUJBQXVCLFFBQVEsdUJBQXVCLEtBQUssSUFBSSxxQkFBcUI7Q0FFdEcsT0FBTyxNQUFNO0VBQ1QsV0FBVyxXQUFZO0dBQUUsT0FBTyxJQUFJLGNBQWMsWUFBWSxZQUFZLFNBQVM7RUFBRztFQUN0RixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLHFCQUFxQjtDQUN6QixDQUFDO0FBQ0w7OztBQ2JBLFNBQWdCLE9BQU8sV0FBVztDQUM5QixPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxXQUFXO0VBQ2YsSUFBSTtFQUNKLElBQUksWUFBWTtFQUNoQixJQUFJLFFBQVE7RUFDWixPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLFlBQVk7R0FDWixJQUFJLENBQUMsYUFBYSxVQUFVLE9BQU8sU0FBUyxNQUFNLEdBQUc7SUFDakQsWUFBWSxXQUFXLE1BQU0sSUFBSSxjQUFjLDBCQUEwQixDQUFDO0lBQzFFLFdBQVc7SUFDWCxjQUFjO0dBQ2xCO0VBQ0osR0FBRyxXQUFZO0dBQ1gsSUFBSSxVQUFVO0lBQ1YsV0FBVyxLQUFLLFdBQVc7SUFDM0IsV0FBVyxTQUFTO0dBQ3hCLE9BRUksV0FBVyxNQUFNLFlBQVksSUFBSSxjQUFjLG9CQUFvQixJQUFJLElBQUksV0FBVyxDQUFDO0VBRS9GLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDM0JBLFNBQWdCLEtBQUssT0FBTztDQUN4QixPQUFPLE9BQU8sU0FBVSxHQUFHLE9BQU87RUFBRSxPQUFPLFNBQVM7Q0FBTyxDQUFDO0FBQ2hFOzs7QUNBQSxTQUFnQixTQUFTLFdBQVc7Q0FDaEMsT0FBTyxhQUFhLElBRVosV0FDRixRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3BDLElBQUksT0FBTyxJQUFJLE1BQU0sU0FBUztFQUM5QixJQUFJLE9BQU87RUFDWCxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLElBQUksYUFBYTtHQUNqQixJQUFJLGFBQWEsV0FDYixLQUFLLGNBQWM7UUFFbEI7SUFDRCxJQUFJLFFBQVEsYUFBYTtJQUN6QixJQUFJLFdBQVcsS0FBSztJQUNwQixLQUFLLFNBQVM7SUFDZCxXQUFXLEtBQUssUUFBUTtHQUM1QjtFQUNKLENBQUMsQ0FBQztFQUNGLE9BQU8sV0FBWTtHQUNmLE9BQU87RUFDWDtDQUNKLENBQUM7QUFDVDs7O0FDdEJBLFNBQWdCLFVBQVUsVUFBVTtDQUNoQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxTQUFTO0VBQ2IsSUFBSSxpQkFBaUIseUJBQXlCLFlBQVksV0FBWTtHQUNsRSxtQkFBbUIsUUFBUSxtQkFBbUIsS0FBSyxLQUFhLGVBQWUsWUFBWTtHQUMzRixTQUFTO0VBQ2IsR0FBRyxJQUFJO0VBQ1AsVUFBVSxRQUFRLENBQUMsQ0FBQyxVQUFVLGNBQWM7RUFDNUMsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUFFLE9BQU8sVUFBVSxXQUFXLEtBQUssS0FBSztFQUFHLENBQUMsQ0FBQztDQUN4SCxDQUFDO0FBQ0w7OztBQ1pBLFNBQWdCLFVBQVUsV0FBVztDQUNqQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxTQUFTO0VBQ2IsSUFBSSxRQUFRO0VBQ1osT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUFFLFFBQVEsV0FBVyxTQUFTLENBQUMsVUFBVSxPQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUssS0FBSztFQUFHLENBQUMsQ0FBQztDQUNuSyxDQUFDO0FBQ0w7OztBQ0xBLFNBQWdCLFlBQVk7Q0FDeEIsSUFBSSxTQUFTLENBQUM7Q0FDZCxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLE9BQU8sTUFBTSxVQUFVO0NBRTNCLElBQUksWUFBWSxhQUFhLE1BQU07Q0FDbkMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLENBQUMsWUFBWUMsU0FBTyxRQUFRLFFBQVEsU0FBUyxJQUFJQSxTQUFPLFFBQVEsTUFBTSxFQUFBLENBQUcsVUFBVSxVQUFVO0NBQ2pHLENBQUM7QUFDTDs7O0FDVEEsU0FBZ0IsVUFBVSxTQUFTLGdCQUFnQjtDQUMvQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxrQkFBa0I7RUFDdEIsSUFBSSxRQUFRO0VBQ1osSUFBSSxhQUFhO0VBQ2pCLElBQUksZ0JBQWdCLFdBQVk7R0FBRSxPQUFPLGNBQWMsQ0FBQyxtQkFBbUIsV0FBVyxTQUFTO0VBQUc7RUFDbEcsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxvQkFBb0IsUUFBUSxvQkFBb0IsS0FBSyxLQUFhLGdCQUFnQixZQUFZO0dBQzlGLElBQUksYUFBYTtHQUNqQixJQUFJLGFBQWE7R0FDakIsVUFBVSxRQUFRLE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxVQUFXLGtCQUFrQix5QkFBeUIsWUFBWSxTQUFVLFlBQVk7SUFBRSxPQUFPLFdBQVcsS0FBSyxpQkFBaUIsZUFBZSxPQUFPLFlBQVksWUFBWSxZQUFZLElBQUksVUFBVTtHQUFHLEdBQUcsV0FBWTtJQUM5UCxrQkFBa0I7SUFDbEIsY0FBYztHQUNsQixDQUFDLENBQUU7RUFDUCxHQUFHLFdBQVk7R0FDWCxhQUFhO0dBQ2IsY0FBYztFQUNsQixDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7OztBQ3BCQSxTQUFnQixZQUFZO0NBQ3hCLE9BQU8sVUFBVSxRQUFRO0FBQzdCOzs7QUNGQSxTQUFnQixZQUFZLGlCQUFpQixnQkFBZ0I7Q0FDekQsT0FBTyxXQUFXLGNBQWMsSUFBSSxVQUFVLFdBQVk7RUFBRSxPQUFPO0NBQWlCLEdBQUcsY0FBYyxJQUFJLFVBQVUsV0FBWTtFQUFFLE9BQU87Q0FBaUIsQ0FBQztBQUM5Sjs7O0FDRkEsU0FBZ0IsV0FBVyxhQUFhLE1BQU07Q0FDMUMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksUUFBUTtFQUNaLFVBQVUsU0FBVSxPQUFPLE9BQU87R0FBRSxPQUFPLFlBQVksT0FBTyxPQUFPLEtBQUs7RUFBRyxHQUFHLFNBQVUsR0FBRyxZQUFZO0dBQUUsT0FBUyxRQUFRLFlBQWE7RUFBYSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLFVBQVU7RUFDckwsT0FBTyxXQUFZO0dBQ2YsUUFBUTtFQUNaO0NBQ0osQ0FBQztBQUNMOzs7QUNOQSxTQUFnQixVQUFVLFVBQVU7Q0FDaEMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLFVBQVUsUUFBUSxDQUFDLENBQUMsVUFBVSx5QkFBeUIsWUFBWSxXQUFZO0dBQUUsT0FBTyxXQUFXLFNBQVM7RUFBRyxHQUFHLElBQUksQ0FBQztFQUN2SCxDQUFDLFdBQVcsVUFBVSxPQUFPLFVBQVUsVUFBVTtDQUNyRCxDQUFDO0FBQ0w7OztBQ1BBLFNBQWdCLFVBQVUsV0FBVyxXQUFXO0NBQzVDLElBQUksY0FBYyxLQUFLLEdBQUssWUFBWTtDQUN4QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxRQUFRO0VBQ1osT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLFNBQVMsVUFBVSxPQUFPLE9BQU87R0FDckMsQ0FBQyxVQUFVLGNBQWMsV0FBVyxLQUFLLEtBQUs7R0FDOUMsQ0FBQyxVQUFVLFdBQVcsU0FBUztFQUNuQyxDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7OztBQ1JBLFNBQWdCLElBQUksZ0JBQWdCLE9BQU8sVUFBVTtDQUNqRCxJQUFJLGNBQWMsV0FBVyxjQUFjLEtBQUssU0FBUyxXQUVqRDtFQUFFLE1BQU07RUFBdUI7RUFBaUI7Q0FBUyxJQUMzRDtDQUNOLE9BQU8sY0FDRCxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3BDLElBQUk7RUFDSixDQUFDLEtBQUssWUFBWSxlQUFlLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxLQUFLLFdBQVc7RUFDckYsSUFBSSxVQUFVO0VBQ2QsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJO0dBQ0osQ0FBQyxLQUFLLFlBQVksVUFBVSxRQUFRLE9BQU8sS0FBSyxLQUFhLEdBQUcsS0FBSyxhQUFhLEtBQUs7R0FDdkYsV0FBVyxLQUFLLEtBQUs7RUFDekIsR0FBRyxXQUFZO0dBQ1gsSUFBSTtHQUNKLFVBQVU7R0FDVixDQUFDLEtBQUssWUFBWSxjQUFjLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxLQUFLLFdBQVc7R0FDcEYsV0FBVyxTQUFTO0VBQ3hCLEdBQUcsU0FBVSxLQUFLO0dBQ2QsSUFBSTtHQUNKLFVBQVU7R0FDVixDQUFDLEtBQUssWUFBWSxXQUFXLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxLQUFLLGFBQWEsR0FBRztHQUN0RixXQUFXLE1BQU0sR0FBRztFQUN4QixHQUFHLFdBQVk7R0FDWCxJQUFJLElBQUk7R0FDUixJQUFJLFNBQ0EsQ0FBQyxLQUFLLFlBQVksaUJBQWlCLFFBQVEsT0FBTyxLQUFLLEtBQWEsR0FBRyxLQUFLLFdBQVc7R0FFM0YsQ0FBQyxLQUFLLFlBQVksY0FBYyxRQUFRLE9BQU8sS0FBSyxLQUFhLEdBQUcsS0FBSyxXQUFXO0VBQ3hGLENBQUMsQ0FBQztDQUNOLENBQUMsSUFFRztBQUNaOzs7QUNuQ0EsU0FBZ0IsU0FBUyxrQkFBa0IsUUFBUTtDQUMvQyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxLQUFLLFdBQVcsUUFBUSxXQUFXLEtBQUssSUFBSSxTQUFTLENBQUMsR0FBRyxLQUFLLEdBQUcsU0FBUyxVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUFLLEdBQUcsVUFBVSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVE7RUFDeEssSUFBSSxXQUFXO0VBQ2YsSUFBSSxZQUFZO0VBQ2hCLElBQUksWUFBWTtFQUNoQixJQUFJLGFBQWE7RUFDakIsSUFBSSxnQkFBZ0IsV0FBWTtHQUM1QixjQUFjLFFBQVEsY0FBYyxLQUFLLEtBQWEsVUFBVSxZQUFZO0dBQzVFLFlBQVk7R0FDWixJQUFJLFVBQVU7SUFDVixLQUFLO0lBQ0wsY0FBYyxXQUFXLFNBQVM7R0FDdEM7RUFDSjtFQUNBLElBQUksb0JBQW9CLFdBQVk7R0FDaEMsWUFBWTtHQUNaLGNBQWMsV0FBVyxTQUFTO0VBQ3RDO0VBQ0EsSUFBSSxnQkFBZ0IsU0FBVSxPQUFPO0dBQ2pDLE9BQVEsWUFBWSxVQUFVLGlCQUFpQixLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUseUJBQXlCLFlBQVksZUFBZSxpQkFBaUIsQ0FBQztFQUMzSTtFQUNBLElBQUksT0FBTyxXQUFZO0dBQ25CLElBQUksVUFBVTtJQUNWLFdBQVc7SUFDWCxJQUFJLFFBQVE7SUFDWixZQUFZO0lBQ1osV0FBVyxLQUFLLEtBQUs7SUFDckIsQ0FBQyxjQUFjLGNBQWMsS0FBSztHQUN0QztFQUNKO0VBQ0EsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxXQUFXO0dBQ1gsWUFBWTtHQUNaLEVBQUUsYUFBYSxDQUFDLFVBQVUsWUFBWSxVQUFVLEtBQUssSUFBSSxjQUFjLEtBQUs7RUFDaEYsR0FBRyxXQUFZO0dBQ1gsYUFBYTtHQUNiLEVBQUUsWUFBWSxZQUFZLGFBQWEsQ0FBQyxVQUFVLFdBQVcsV0FBVyxTQUFTO0VBQ3JGLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDeENBLFNBQWdCLGFBQWEsVUFBVSxXQUFXLFFBQVE7Q0FDdEQsSUFBSSxjQUFjLEtBQUssR0FBSyxZQUFZO0NBQ3hDLElBQUksWUFBWSxNQUFNLFVBQVUsU0FBUztDQUN6QyxPQUFPLFNBQVMsV0FBWTtFQUFFLE9BQU87Q0FBVyxHQUFHLE1BQU07QUFDN0Q7OztBQ0pBLFNBQWdCLGFBQWEsV0FBVztDQUNwQyxJQUFJLGNBQWMsS0FBSyxHQUFLLFlBQVk7Q0FDeEMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksT0FBTyxVQUFVLElBQUk7RUFDekIsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLE1BQU0sVUFBVSxJQUFJO0dBQ3hCLElBQUksV0FBVyxNQUFNO0dBQ3JCLE9BQU87R0FDUCxXQUFXLEtBQUssSUFBSSxhQUFhLE9BQU8sUUFBUSxDQUFDO0VBQ3JELENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDtBQUNBLElBQUksZUFBZ0IsV0FBWTtDQUM1QixTQUFTLGFBQWEsT0FBTyxVQUFVO0VBQ25DLEtBQUssUUFBUTtFQUNiLEtBQUssV0FBVztDQUNwQjtDQUNBLE9BQU87QUFDWCxFQUFFOzs7QUNsQkYsU0FBZ0IsWUFBWSxLQUFLLGdCQUFnQixXQUFXO0NBQ3hELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLFlBQVksY0FBYyxRQUFRLGNBQWMsS0FBSyxJQUFJLFlBQVk7Q0FDckUsSUFBSSxZQUFZLEdBQUcsR0FDZixRQUFRO01BRVAsSUFBSSxPQUFPLFFBQVEsVUFDcEIsT0FBTztDQUVYLElBQUksZ0JBQ0EsUUFBUSxXQUFZO0VBQUUsT0FBTztDQUFnQjtNQUc3QyxNQUFNLElBQUksVUFBVSxxQ0FBcUM7Q0FFN0QsSUFBSSxTQUFTLFFBQVEsUUFBUSxNQUN6QixNQUFNLElBQUksVUFBVSxzQkFBc0I7Q0FFOUMsT0FBTyxRQUFRO0VBQ0o7RUFDRDtFQUNLO0VBQ1gsTUFBTTtDQUNWLENBQUM7QUFDTDs7O0FDM0JBLFNBQWdCLFVBQVUsbUJBQW1CO0NBQ3pDLElBQUksc0JBQXNCLEtBQUssR0FBSyxvQkFBb0I7Q0FDeEQsT0FBTyxJQUFJLFNBQVUsT0FBTztFQUFFLE9BQVE7R0FBUztHQUFPLFdBQVcsa0JBQWtCLElBQUk7RUFBRTtDQUFJLENBQUM7QUFDbEc7OztBQ0FBLFNBQWdCLE9BQU8sa0JBQWtCO0NBQ3JDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLGdCQUFnQixJQUFJLFFBQVE7RUFDaEMsV0FBVyxLQUFLLGNBQWMsYUFBYSxDQUFDO0VBQzVDLElBQUksZUFBZSxTQUFVLEtBQUs7R0FDOUIsY0FBYyxNQUFNLEdBQUc7R0FDdkIsV0FBVyxNQUFNLEdBQUc7RUFDeEI7RUFDQSxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQUUsT0FBTyxrQkFBa0IsUUFBUSxrQkFBa0IsS0FBSyxJQUFJLEtBQUssSUFBSSxjQUFjLEtBQUssS0FBSztFQUFHLEdBQUcsV0FBWTtHQUNwTCxjQUFjLFNBQVM7R0FDdkIsV0FBVyxTQUFTO0VBQ3hCLEdBQUcsWUFBWSxDQUFDO0VBQ2hCLFVBQVUsZ0JBQWdCLENBQUMsQ0FBQyxVQUFVLHlCQUF5QixZQUFZLFdBQVk7R0FDbkYsY0FBYyxTQUFTO0dBQ3ZCLFdBQVcsS0FBTSxnQkFBZ0IsSUFBSSxRQUFRLENBQUU7RUFDbkQsR0FBRyxNQUFNLFlBQVksQ0FBQztFQUN0QixPQUFPLFdBQVk7R0FDZixrQkFBa0IsUUFBUSxrQkFBa0IsS0FBSyxLQUFhLGNBQWMsWUFBWTtHQUN4RixnQkFBZ0I7RUFDcEI7Q0FDSixDQUFDO0FBQ0w7OztBQ3RCQSxTQUFnQixZQUFZLFlBQVksa0JBQWtCO0NBQ3RELElBQUkscUJBQXFCLEtBQUssR0FBSyxtQkFBbUI7Q0FDdEQsSUFBSSxhQUFhLG1CQUFtQixJQUFJLG1CQUFtQjtDQUMzRCxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxVQUFVLENBQUMsSUFBSSxRQUFRLENBQUM7RUFFNUIsSUFBSSxRQUFRO0VBQ1osV0FBVyxLQUFLLFFBQVEsRUFBRSxDQUFDLGFBQWEsQ0FBQztFQUN6QyxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQ25FLElBQUksS0FBSztHQUNULElBQUk7SUFDQSxLQUFLLElBQUksWUFBWSxTQUFTLE9BQU8sR0FBRyxjQUFjLFVBQVUsS0FBSyxHQUFHLENBQUMsWUFBWSxNQUFNLGNBQWMsVUFBVSxLQUFLLEdBRXBILFlBRDJCLE1BQ2xCLEtBQUssS0FBSztHQUUzQixTQUNPLE9BQU87SUFBRSxNQUFNLEVBQUUsT0FBTyxNQUFNO0dBQUcsVUFDaEM7SUFDSixJQUFJO0tBQ0EsSUFBSSxlQUFlLENBQUMsWUFBWSxTQUFTLEtBQUssVUFBVSxTQUFTLEdBQUcsS0FBSyxTQUFTO0lBQ3RGLFVBQ1E7S0FBRSxJQUFJLEtBQUssTUFBTSxJQUFJO0lBQU87R0FDeEM7R0FDQSxJQUFJLElBQUksUUFBUSxhQUFhO0dBQzdCLElBQUksS0FBSyxLQUFLLElBQUksZUFBZSxHQUM3QixRQUFRLE1BQU0sQ0FBQyxDQUFDLFNBQVM7R0FFN0IsSUFBSSxFQUFFLFFBQVEsZUFBZSxHQUFHO0lBQzVCLElBQUksV0FBVyxJQUFJLFFBQVE7SUFDM0IsUUFBUSxLQUFLLFFBQVE7SUFDckIsV0FBVyxLQUFLLFNBQVMsYUFBYSxDQUFDO0dBQzNDO0VBQ0osR0FBRyxXQUFZO0dBQ1gsT0FBTyxRQUFRLFNBQVMsR0FDcEIsUUFBUSxNQUFNLENBQUMsQ0FBQyxTQUFTO0dBRTdCLFdBQVcsU0FBUztFQUN4QixHQUFHLFNBQVUsS0FBSztHQUNkLE9BQU8sUUFBUSxTQUFTLEdBQ3BCLFFBQVEsTUFBTSxDQUFDLENBQUMsTUFBTSxHQUFHO0dBRTdCLFdBQVcsTUFBTSxHQUFHO0VBQ3hCLEdBQUcsV0FBWTtHQUVYLFVBQVU7RUFDZCxDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7OztBQzNDQSxTQUFnQixXQUFXLGdCQUFnQjtDQUN2QyxJQUFJLElBQUk7Q0FDUixJQUFJLFlBQVksQ0FBQztDQUNqQixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLFVBQVUsS0FBSyxLQUFLLFVBQVU7Q0FFbEMsSUFBSSxhQUFhLEtBQUssYUFBYSxTQUFTLE9BQU8sUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0NBQ2hGLElBQUksMEJBQTBCLEtBQUssVUFBVSxRQUFRLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztDQUNsRixJQUFJLGdCQUFnQixVQUFVLE1BQU07Q0FDcEMsT0FBTyxRQUFRLFNBQVUsUUFBUSxZQUFZO0VBQ3pDLElBQUksZ0JBQWdCLENBQUM7RUFDckIsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxjQUFjLFNBQVUsUUFBUTtHQUNoQyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sT0FBTztHQUMxQyxPQUFPLFNBQVM7R0FDaEIsS0FBSyxZQUFZO0dBQ2pCLFVBQVUsZUFBZSxNQUFNO0dBQy9CLGtCQUFrQixZQUFZO0VBQ2xDO0VBQ0EsSUFBSSxjQUFjLFdBQVk7R0FDMUIsSUFBSSxlQUFlO0lBQ2YsSUFBSSxPQUFPLElBQUksYUFBYTtJQUM1QixXQUFXLElBQUksSUFBSTtJQUNuQixJQUFJLFdBQVcsSUFBSSxRQUFRO0lBQzNCLElBQUksV0FBVztLQUNYLFFBQVE7S0FDRjtLQUNOLE1BQU07SUFDVjtJQUNBLGNBQWMsS0FBSyxRQUFRO0lBQzNCLFdBQVcsS0FBSyxTQUFTLGFBQWEsQ0FBQztJQUN2QyxnQkFBZ0IsTUFBTSxXQUFXLFdBQVk7S0FBRSxPQUFPLFlBQVksUUFBUTtJQUFHLEdBQUcsY0FBYztHQUNsRztFQUNKO0VBQ0EsSUFBSSwyQkFBMkIsUUFBUSwwQkFBMEIsR0FDN0QsZ0JBQWdCLFlBQVksV0FBVyxhQUFhLHdCQUF3QixJQUFJO09BR2hGLGlCQUFpQjtFQUVyQixZQUFZO0VBQ1osSUFBSSxPQUFPLFNBQVUsSUFBSTtHQUFFLE9BQU8sY0FBYyxNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUU7RUFBRztFQUNyRSxJQUFJLFlBQVksU0FBVSxJQUFJO0dBQzFCLEtBQUssU0FBVSxJQUFJO0lBQ2YsSUFBSSxTQUFTLEdBQUc7SUFDaEIsT0FBTyxHQUFHLE1BQU07R0FDcEIsQ0FBQztHQUNELEdBQUcsVUFBVTtHQUNiLFdBQVcsWUFBWTtFQUMzQjtFQUNBLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsS0FBSyxTQUFVLFFBQVE7SUFDbkIsT0FBTyxPQUFPLEtBQUssS0FBSztJQUN4QixpQkFBaUIsRUFBRSxPQUFPLFFBQVEsWUFBWSxNQUFNO0dBQ3hELENBQUM7RUFDTCxHQUFHLFdBQVk7R0FBRSxPQUFPLFVBQVUsU0FBVSxVQUFVO0lBQUUsT0FBTyxTQUFTLFNBQVM7R0FBRyxDQUFDO0VBQUcsR0FBRyxTQUFVLEtBQUs7R0FBRSxPQUFPLFVBQVUsU0FBVSxVQUFVO0lBQUUsT0FBTyxTQUFTLE1BQU0sR0FBRztHQUFHLENBQUM7RUFBRyxDQUFDLENBQUM7RUFDckwsT0FBTyxXQUFZO0dBQ2YsZ0JBQWdCO0VBQ3BCO0NBQ0osQ0FBQztBQUNMOzs7QUM1REEsU0FBZ0IsYUFBYSxVQUFVLGlCQUFpQjtDQUNwRCxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSSxVQUFVLENBQUM7RUFDZixJQUFJLGNBQWMsU0FBVSxLQUFLO0dBQzdCLE9BQU8sSUFBSSxRQUFRLFFBQ2YsUUFBUSxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUc7R0FFN0IsV0FBVyxNQUFNLEdBQUc7RUFDeEI7RUFDQSxVQUFVLFFBQVEsQ0FBQyxDQUFDLFVBQVUseUJBQXlCLFlBQVksU0FBVSxXQUFXO0dBQ3BGLElBQUksU0FBUyxJQUFJLFFBQVE7R0FDekIsUUFBUSxLQUFLLE1BQU07R0FDbkIsSUFBSSxzQkFBc0IsSUFBSSxhQUFhO0dBQzNDLElBQUksY0FBYyxXQUFZO0lBQzFCLFVBQVUsU0FBUyxNQUFNO0lBQ3pCLE9BQU8sU0FBUztJQUNoQixvQkFBb0IsWUFBWTtHQUNwQztHQUNBLElBQUk7R0FDSixJQUFJO0lBQ0Esa0JBQWtCLFVBQVUsZ0JBQWdCLFNBQVMsQ0FBQztHQUMxRCxTQUNPLEtBQUs7SUFDUixZQUFZLEdBQUc7SUFDZjtHQUNKO0dBQ0EsV0FBVyxLQUFLLE9BQU8sYUFBYSxDQUFDO0dBQ3JDLG9CQUFvQixJQUFJLGdCQUFnQixVQUFVLHlCQUF5QixZQUFZLGFBQWEsTUFBTSxXQUFXLENBQUMsQ0FBQztFQUMzSCxHQUFHLElBQUksQ0FBQztFQUNSLE9BQU8sVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87R0FDbkUsSUFBSSxLQUFLO0dBQ1QsSUFBSSxjQUFjLFFBQVEsTUFBTTtHQUNoQyxJQUFJO0lBQ0EsS0FBSyxJQUFJLGdCQUFnQixTQUFTLFdBQVcsR0FBRyxrQkFBa0IsY0FBYyxLQUFLLEdBQUcsQ0FBQyxnQkFBZ0IsTUFBTSxrQkFBa0IsY0FBYyxLQUFLLEdBRWhKLGdCQUQrQixNQUN0QixLQUFLLEtBQUs7R0FFM0IsU0FDTyxPQUFPO0lBQUUsTUFBTSxFQUFFLE9BQU8sTUFBTTtHQUFHLFVBQ2hDO0lBQ0osSUFBSTtLQUNBLElBQUksbUJBQW1CLENBQUMsZ0JBQWdCLFNBQVMsS0FBSyxjQUFjLFNBQVMsR0FBRyxLQUFLLGFBQWE7SUFDdEcsVUFDUTtLQUFFLElBQUksS0FBSyxNQUFNLElBQUk7SUFBTztHQUN4QztFQUNKLEdBQUcsV0FBWTtHQUNYLE9BQU8sSUFBSSxRQUFRLFFBQ2YsUUFBUSxNQUFNLENBQUMsQ0FBQyxTQUFTO0dBRTdCLFdBQVcsU0FBUztFQUN4QixHQUFHLGFBQWEsV0FBWTtHQUN4QixPQUFPLElBQUksUUFBUSxRQUNmLFFBQVEsTUFBTSxDQUFDLENBQUMsWUFBWTtFQUVwQyxDQUFDLENBQUM7Q0FDTixDQUFDO0FBQ0w7OztBQzVEQSxTQUFnQixXQUFXLGlCQUFpQjtDQUN4QyxPQUFPLFFBQVEsU0FBVSxRQUFRLFlBQVk7RUFDekMsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJLGNBQWMsU0FBVSxLQUFLO0dBQzdCLE9BQU8sTUFBTSxHQUFHO0dBQ2hCLFdBQVcsTUFBTSxHQUFHO0VBQ3hCO0VBQ0EsSUFBSSxhQUFhLFdBQVk7R0FDekIsc0JBQXNCLFFBQVEsc0JBQXNCLEtBQUssS0FBYSxrQkFBa0IsWUFBWTtHQUNwRyxXQUFXLFFBQVEsV0FBVyxLQUFLLEtBQWEsT0FBTyxTQUFTO0dBQ2hFLFNBQVMsSUFBSSxRQUFRO0dBQ3JCLFdBQVcsS0FBSyxPQUFPLGFBQWEsQ0FBQztHQUNyQyxJQUFJO0dBQ0osSUFBSTtJQUNBLGtCQUFrQixVQUFVLGdCQUFnQixDQUFDO0dBQ2pELFNBQ08sS0FBSztJQUNSLFlBQVksR0FBRztJQUNmO0dBQ0o7R0FDQSxnQkFBZ0IsVUFBVyxvQkFBb0IseUJBQXlCLFlBQVksWUFBWSxZQUFZLFdBQVcsQ0FBRTtFQUM3SDtFQUNBLFdBQVc7RUFDWCxPQUFPLFVBQVUseUJBQXlCLFlBQVksU0FBVSxPQUFPO0dBQUUsT0FBTyxPQUFPLEtBQUssS0FBSztFQUFHLEdBQUcsV0FBWTtHQUMvRyxPQUFPLFNBQVM7R0FDaEIsV0FBVyxTQUFTO0VBQ3hCLEdBQUcsYUFBYSxXQUFZO0dBQ3hCLHNCQUFzQixRQUFRLHNCQUFzQixLQUFLLEtBQWEsa0JBQWtCLFlBQVk7R0FDcEcsU0FBUztFQUNiLENBQUMsQ0FBQztDQUNOLENBQUM7QUFDTDs7O0FDN0JBLFNBQWdCLGlCQUFpQjtDQUM3QixJQUFJLFNBQVMsQ0FBQztDQUNkLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDcEMsT0FBTyxNQUFNLFVBQVU7Q0FFM0IsSUFBSSxVQUFVLGtCQUFrQixNQUFNO0NBQ3RDLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxJQUFJLE1BQU0sT0FBTztFQUNqQixJQUFJLGNBQWMsSUFBSSxNQUFNLEdBQUc7RUFDL0IsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFZO0dBQUUsT0FBTztFQUFPLENBQUM7RUFDdkQsSUFBSSxRQUFRO0VBQ1osSUFBSSxVQUFVLFNBQVUsR0FBRztHQUN2QixVQUFVLE9BQU8sRUFBRSxDQUFDLENBQUMsVUFBVSx5QkFBeUIsWUFBWSxTQUFVLE9BQU87SUFDakYsWUFBWSxLQUFLO0lBQ2pCLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxJQUFJO0tBQ3hCLFNBQVMsS0FBSztLQUNkLENBQUMsUUFBUSxTQUFTLE1BQU0sUUFBUSxPQUFPLFdBQVc7SUFDdEQ7R0FDSixHQUFHLElBQUksQ0FBQztFQUNaO0VBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FDckIsUUFBUSxDQUFDO0VBRWIsT0FBTyxVQUFVLHlCQUF5QixZQUFZLFNBQVUsT0FBTztHQUNuRSxJQUFJLE9BQU87SUFDUCxJQUFJLFNBQVMsY0FBYyxDQUFDLEtBQUssR0FBRyxPQUFPLFdBQVcsQ0FBQztJQUN2RCxXQUFXLEtBQUssVUFBVSxRQUFRLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxHQUFHLE9BQU8sTUFBTSxDQUFDLENBQUMsSUFBSSxNQUFNO0dBQy9GO0VBQ0osQ0FBQyxDQUFDO0NBQ04sQ0FBQztBQUNMOzs7QUNuQ0EsU0FBZ0IsT0FBTyxTQUFTO0NBQzVCLE9BQU8saUJBQWlCQyxPQUFLLE9BQU87QUFDeEM7OztBQ0RBLFNBQWdCLE1BQU07Q0FDbEIsSUFBSSxVQUFVLENBQUM7Q0FDZixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLFFBQVEsTUFBTSxVQUFVO0NBRTVCLE9BQU8sUUFBUSxTQUFVLFFBQVEsWUFBWTtFQUN6QyxNQUFVLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxVQUFVO0NBQzFGLENBQUM7QUFDTDs7O0FDVEEsU0FBZ0IsVUFBVTtDQUN0QixJQUFJLGNBQWMsQ0FBQztDQUNuQixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3BDLFlBQVksTUFBTSxVQUFVO0NBRWhDLE9BQU8sSUFBSSxNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsR0FBRyxPQUFPLFdBQVcsQ0FBQyxDQUFDO0FBQ25FIn0=