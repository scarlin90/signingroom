const UR = __vite__cjsImport12__ngraveio_bcUr["UR"]; const URDecoder = __vite__cjsImport12__ngraveio_bcUr["URDecoder"]; const UREncoder = __vite__cjsImport12__ngraveio_bcUr["UREncoder"];import {
  __async,
  __export,
  __spreadProps,
  __spreadValues,
  environment
} from "/chunk-PZ54WRVW.js";

// libs/sdk/src/lib/crypto/encryption-engine.ts
var EncryptionEngine = class {
  /**
   * Safely retrieves the cryptographic SubtleCrypto API across global contexts.
   * @returns The active environment's SubtleCrypto instance.
   * @throws {Error} If WebCrypto or its Subtle property is unsupported in the host environment.
   */
  getCrypto() {
    const c = typeof window !== "undefined" && window.crypto || typeof global !== "undefined" && global.crypto;
    if (!c || !c.subtle) throw new Error("WebCrypto not supported");
    return c.subtle;
  }
  /**
   * Fills a given Uint8Array with cryptographically strong pseudo-random values.
   * @param array - The destination array to populate with random bytes.
   * @returns The same populated Uint8Array instance.
   * @throws {Error} If a reliable cryptographically secure random number generator is unavailable.
   */
  getRandomValues(array) {
    const c = typeof window !== "undefined" && window.crypto || typeof global !== "undefined" && global.crypto;
    if (!c || !c.getRandomValues) throw new Error("Crypto not supported");
    return c.getRandomValues(array);
  }
  /**
   * Converts a binary ArrayBuffer to a standard Base64 string representation.
   * @param buffer - The raw binary data buffer.
   * @returns A base64-encoded string.
   */
  buf2base64(buffer) {
    if (typeof Buffer !== "undefined") {
      return Buffer.from(buffer).toString("base64");
    }
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
  }
  /**
   * Decodes a standard Base64 string back into binary byte format.
   * @param base64Str - The base64-encoded string.
   * @returns A Uint8Array containing the raw binary bytes.
   */
  base642buf(base64Str) {
    if (typeof Buffer !== "undefined") {
      return new Uint8Array(Buffer.from(base64Str, "base64"));
    }
    return Uint8Array.from(atob(base64Str), (c) => c.charCodeAt(0));
  }
  /**
   * Generates a brand new, random 256-bit AES-GCM symmetric key.
   * @returns A Promise that resolves to the raw exported key encoded in Base64 format (44 characters).
   */
  generateKey() {
    return __async(this, null, function* () {
      const cryptoSubtle = this.getCrypto();
      const key = yield cryptoSubtle.generateKey({ name: "AES-GCM", length: 256 }, true, [
        "encrypt",
        "decrypt"
      ]);
      const exported = yield cryptoSubtle.exportKey("raw", key);
      return this.buf2base64(exported);
    });
  }
  /**
   * Encrypts plain text string data using authenticated 256-bit AES-GCM encryption.
   * @param data - The string message content to encrypt.
   * @param key - The base64-encoded 256-bit secret key.
   * @returns A Promise resolving to a single Base64 string containing both the 12-byte random Initialization Vector (IV) and the encrypted ciphertext payload.
   */
  encrypt(data, key) {
    return __async(this, null, function* () {
      const encoder = new TextEncoder();
      const rawKey = this.base642buf(key);
      const cryptoSubtle = this.getCrypto();
      const keyBuffer = yield cryptoSubtle.importKey("raw", rawKey, { name: "AES-GCM" }, true, [
        "encrypt",
        "decrypt"
      ]);
      const iv = this.getRandomValues(new Uint8Array(12));
      const encryptedData = yield cryptoSubtle.encrypt(
        { name: "AES-GCM", iv },
        keyBuffer,
        encoder.encode(data)
      );
      const result = new Uint8Array(iv.length + encryptedData.byteLength);
      result.set(iv);
      result.set(new Uint8Array(encryptedData), iv.length);
      return this.buf2base64(result.buffer);
    });
  }
  /**
   * Decrypts a combined IV and ciphertext payload using 256-bit AES-GCM.
   * @param encryptedData - The base64 string combining the 12-byte IV and the encrypted payload.
   * @param key - The base64-encoded 256-bit secret key matching the encryption instance.
   * @returns A Promise resolving to the original UTF-8 plain text string.
   * @throws {Error} If decryption fails, indicating invalid parameters, data tampering, or a key mismatch.
   */
  decrypt(encryptedData, key) {
    return __async(this, null, function* () {
      const rawKey = this.base642buf(key);
      const cryptoSubtle = this.getCrypto();
      const keyBuffer = yield cryptoSubtle.importKey(
        "raw",
        rawKey,
        { name: "AES-GCM" },
        true,
        ["encrypt", "decrypt"]
      );
      const encryptedArray = this.base642buf(encryptedData);
      const iv = encryptedArray.slice(0, 12);
      const ciphertext = encryptedArray.slice(12);
      const decryptedData = yield cryptoSubtle.decrypt(
        { name: "AES-GCM", iv },
        keyBuffer,
        ciphertext
      );
      return new TextDecoder().decode(decryptedData);
    });
  }
  /**
   * Generates a deterministic, one-way pseudo-anonymous data blind via SHA-256 hashing.
   * Given identical parameters, the output string remains deterministic, making it ideal for tracking identity metrics without storing plain records.
   * @param data - The contextual raw input string to mask.
   * @param key - Salt/Key material appended to the data structure prior to hashing.
   * @returns A Promise resolving to a fixed 16-character hex-encoded string segment of the resulting digest.
   */
  blindData(data, key) {
    return __async(this, null, function* () {
      const encoder = new TextEncoder();
      const dataBuffer = encoder.encode(data + key);
      const cryptoSubtle = this.getCrypto();
      const hashBuffer = yield cryptoSubtle.digest("SHA-256", dataBuffer);
      return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, 16);
    });
  }
};

// libs/sdk/src/lib/bitcoin/psbt-utils.ts
import { Transaction } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_btc-signer.js?v=cf17c1b4";
import { base64, hex } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_base.js?v=cf17c1b4";
import { bech32, bech32m } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_base.js?v=cf17c1b4";
import { NETWORK, TEST_NETWORK, Address } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_btc-signer.js?v=cf17c1b4";
var PsbtUtils = class {
  /**
   * Decodes a raw PSBT string payload into a strictly typed binary byte array.
   * Intelligently detects and routes between hex-encoded and base64-encoded formats.
   * * @param raw - The raw, unformatted PSBT string payload.
   * @returns A decoded Uint8Array containing the raw binary transaction.
   */
  static decode(raw) {
    const clean = raw.replace(/\s/g, "");
    return /^[0-9a-fA-F]+$/.test(clean) ? hex.decode(clean) : base64.decode(clean);
  }
  /**
   * Normalizes an arbitrary PSBT input string into a standard Base64 representation.
   * Auto-converts valid hex strings containing the PSBT magic bytes into Base64.
   * * @param input - The raw PSBT string (Base64 or Hex).
   * @returns A sanitized, Base64 encoded PSBT string.
   */
  static normalize(input) {
    const clean = input.trim();
    if (/^[0-9a-fA-F]+$/.test(clean) && clean.toLowerCase().startsWith("70736274")) {
      try {
        return base64.encode(hex.decode(clean));
      } catch (e) {
        return input;
      }
    }
    return clean;
  }
  /**
   * Cryptographically merges two distinct PSBT payloads sharing the same underlying transaction state.
   * Used to aggregate isolated participant signatures into a unified transaction map.
   * * @param base - The primary Base64 PSBT payload.
   * @param next - The secondary Base64 PSBT payload containing parallel signatures.
   * @returns A new Base64 PSBT string containing the combined signatures, or the original base on failure.
   */
  static merge(base, next) {
    try {
      const txBase = Transaction.fromPSBT(this.decode(base));
      const txNext = Transaction.fromPSBT(this.decode(next));
      txBase.combine(txNext);
      return base64.encode(txBase.toPSBT());
    } catch (e) {
      console.error("[Merge Failed]", e);
      return base;
    }
  }
  /**
   * Extracts the M-of-N multisig required threshold directly from the redeem/witness script.
   * * @param psbtBase64 - The normalized Base64 PSBT payload.
   * @returns The integer representing the minimum signatures required, or 0 if unreadable.
   */
  static getThreshold(psbtBase64) {
    try {
      const tx = Transaction.fromPSBT(base64.decode(psbtBase64));
      for (let i = 0; i < tx.inputsLength; i++) {
        const input = tx.getInput(i);
        if (!input) continue;
        const script = input.witnessScript || input.redeemScript;
        if (!script || script.length === 0) continue;
        const firstOp = script[0];
        if (firstOp >= 81 && firstOp <= 96) {
          return firstOp - 80;
        }
      }
      return 0;
    } catch (e) {
      return 0;
    }
  }
  /**
   * Identifies the primary signer's master key fingerprint associated with the first detected partial signature.
   * * @param psbtData - The normalized Base64 PSBT payload.
   * @returns The 8-character hex fingerprint string, or null if no valid signature mapping is found.
   */
  static getFingerprintFromPsbt(psbtData) {
    try {
      const bytes = this.decode(psbtData);
      const tx = Transaction.fromPSBT(bytes);
      for (let i = 0; i < tx.inputsLength; i++) {
        const input = tx.getInput(i);
        if (input.partialSig && input.partialSig.length > 0) {
          const pubkeySigned = input.partialSig[0][0];
          if (input.bip32Derivation) {
            for (const [pubkey, meta] of input.bip32Derivation) {
              if (hex.encode(pubkey) === hex.encode(pubkeySigned)) {
                return meta.fingerprint.toString(16).padStart(8, "0");
              }
            }
          }
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }
  /**
   * Completely parses a PSBT to derive human-readable financial metrics, I/O maps, and fee estimators.
   * * @param psbtBase64 - The normalized Base64 PSBT payload.
   * @param network - The target network context required for accurate address formatting.
   * @returns A structured TxDetails object, or null if the parsing engine encounters a fatal error.
   */
  static parseTxDetails(psbtBase64, network = "bitcoin") {
    try {
      const tx = Transaction.fromPSBT(base64.decode(psbtBase64));
      const inputsList = [];
      const outputs = [];
      let totalInput = 0;
      let totalOutput = 0;
      for (let i = 0; i < tx.inputsLength; i++) {
        const input = tx.getInput(i);
        let amount = 0;
        let address = "Legacy/Unknown";
        if (input.witnessUtxo) {
          amount = Number(input.witnessUtxo.amount);
          totalInput += amount;
          address = this.formatScriptAddress(input.witnessUtxo.script, network);
        } else if (input.nonWitnessUtxo) {
          address = "Legacy Input";
        }
        let txId = "????";
        let vout = 0;
        try {
          const rawInput = tx.unsignedTx.inputs[i];
          if (rawInput?.txid) {
            txId = hex.encode(rawInput.txid).slice(0, 8) + "...";
            vout = rawInput.index;
          }
        } catch (e) {
        }
        inputsList.push({ address, amount, txId, vout });
      }
      for (let i = 0; i < tx.outputsLength; i++) {
        const output = tx.getOutput(i);
        const amount = Number(output.amount);
        totalOutput += amount;
        const address = this.formatScriptAddress(output.script || new Uint8Array([]), network);
        let isChange = false;
        if (output.bip32Derivation) {
          for (const [, meta] of output.bip32Derivation) {
            if (meta?.path?.length >= 2 && meta.path[meta.path.length - 2] === 1) {
              isChange = true;
              break;
            }
          }
        }
        outputs.push({ address, amount, isChange });
      }
      outputs.sort((a, b) => Number(b.isChange) - Number(a.isChange));
      const fee = totalInput > 0 ? Math.max(0, totalInput - totalOutput) : 0;
      let vBytes = 10 + tx.inputsLength * 100 + tx.outputsLength * 31;
      try {
        vBytes = tx.vsize || vBytes;
      } catch (e) {
      }
      const feeRate = vBytes > 0 ? Number((fee / vBytes).toFixed(2)) : 0;
      return {
        amount: totalOutput,
        fee,
        vBytes,
        feeRate,
        inputs: tx.inputsLength,
        inputsList,
        outputs
      };
    } catch (e) {
      console.error("Failed to parse PSBT", e);
      return null;
    }
  }
  /**
   * Scans a PSBT to map all expected participants and evaluates their current signature state.
   * Works across both legacy ECDSA (partialSig) and Schnorr (tapScriptSig) signature schemes.
   * * @param psbtBase64 - The normalized Base64 PSBT payload.
   * @returns An array mapping participant fingerprints to their active signed status.
   */
  static extractSigners(psbtBase64) {
    try {
      const tx = Transaction.fromPSBT(base64.decode(psbtBase64));
      const signersMap = /* @__PURE__ */ new Map();
      for (let i = 0; i < tx.inputsLength; i++) {
        const input = tx.getInput(i);
        const derivations = input.bip32Derivation;
        if (derivations) {
          for (const [pubkey, meta] of derivations) {
            if (!meta?.fingerprint) continue;
            const fpHex = meta.fingerprint.toString(16).padStart(8, "0");
            let isSigned = false;
            if (input.partialSig) {
              isSigned = input.partialSig.some((p) => this.areKeysEqual(p[0], pubkey));
            }
            if (!isSigned && input.tapScriptSig) {
              isSigned = input.tapScriptSig.some((p) => this.areKeysEqual(p.pubKey, pubkey));
            }
            const current = signersMap.get(fpHex) || false;
            signersMap.set(fpHex, current || isSigned);
          }
        }
      }
      return Array.from(signersMap.entries()).map(([fp, signed]) => ({ fingerprint: fp, signed }));
    } catch (e) {
      return [];
    }
  }
  /**
   * Decodes an arbitrary output script into a human-readable Bitcoin address.
   * Supports P2PKH, P2SH, SegWit v0 (Bech32), and Taproot (Bech32m).
   * * @param script - The raw locking script byte array.
   * @param network - The target network configuration.
   * @returns The formatted public address, or a raw hex fallback if unsupported.
   */
  static formatScriptAddress(script, network) {
    if (!script || script.length === 0) {
      return "Unknown";
    }
    try {
      const s = hex.encode(script);
      const currentNetwork = network || "bitcoin";
      const isTestnetLike = currentNetwork === "testnet" || currentNetwork === "signet";
      const hrp = isTestnetLike ? "tb" : "bc";
      const networkConfig = isTestnetLike ? TEST_NETWORK : NETWORK;
      if (s.startsWith("76a914") && s.endsWith("88ac") && script.length === 25) {
        const pubKeyHash = script.slice(3, 23);
        return Address(networkConfig).encode({ type: "pkh", hash: pubKeyHash });
      }
      if (s.startsWith("a914") && s.endsWith("87") && script.length === 23) {
        const scriptHash = script.slice(2, 22);
        return Address(networkConfig).encode({ type: "sh", hash: scriptHash });
      }
      if (s.startsWith("0014") && script.length === 22 || s.startsWith("0020") && script.length === 34) {
        const witnessProgram = script.slice(2);
        const words = bech32.toWords(witnessProgram);
        words.unshift(0);
        return bech32.encode(hrp, words);
      }
      if (s.length >= 4) {
        const versionByte = parseInt(s.slice(0, 2), 16);
        if (versionByte >= 81 && versionByte <= 96) {
          const witnessVersion = versionByte - 80;
          const witnessProgram = script.slice(2);
          const words = bech32m.toWords(witnessProgram);
          words.unshift(witnessVersion);
          return bech32m.encode(hrp, words);
        }
      }
      return s;
    } catch (e) {
      console.warn("Address formatting failed:", e, hex.encode(script));
      const s = hex.encode(script);
      if (s.startsWith("0014") || s.startsWith("0020") || s.startsWith("51")) return s.slice(4);
      if (s.startsWith("76a914")) return s.slice(6, 46);
      if (s.startsWith("a914")) return s.slice(4, 44);
      return s;
    }
  }
  /**
   * Validates structural equivalence between two public keys, handling compression mismatch safely.
   */
  static areKeysEqual(k1, k2) {
    if (hex.encode(k1) === hex.encode(k2)) return true;
    try {
      const getX = (k) => k.length === 33 ? k.slice(1) : k.length === 65 ? k.slice(1, 33) : k;
      return hex.encode(getX(k1)) === hex.encode(getX(k2));
    } catch (e) {
      return false;
    }
  }
  /**
   * Finalizes an fully-signed PSBT map into an extracted, broadcast-ready raw hex string.
   * * @param psbtBase64 - The fully signed Base64 PSBT payload.
   * @returns An object containing the raw transaction hex and derived txId, or null on failure.
   */
  static finalizeTx(psbtBase64) {
    try {
      const tx = Transaction.fromPSBT(this.decode(psbtBase64));
      tx.finalize();
      return { hex: hex.encode(tx.extract()), txId: tx.id };
    } catch (e) {
      return null;
    }
  }
  /**
   * Performs a rapid, unauthenticated surface analysis of a PSBT.
   * Primarily utilized to ascertain high-level sanity constraints and block out-of-network payloads.
   * * @param psbtBase64 - The normalized Base64 PSBT payload.
   * @returns A high-level PsbtAnalysis configuration object, or null on parse failure.
   */
  static analyze(psbtBase64) {
    try {
      const psbtBytes = this.decode(psbtBase64);
      const tx = Transaction.fromPSBT(psbtBytes, { allowUnknown: true });
      const fingerprints = /* @__PURE__ */ new Set();
      let totalInput = 0, totalOutput = 0, networkScore = 0;
      for (let i = 0; i < tx.inputsLength; i++) {
        const input = tx.getInput(i);
        if (input.witnessUtxo) totalInput += Number(input.witnessUtxo.amount);
        if (input.bip32Derivation) {
          for (const [, meta] of input.bip32Derivation) {
            if (meta?.fingerprint) fingerprints.add(meta.fingerprint.toString(16));
            if (meta?.path) {
              const coinType = meta.path[1];
              if (coinType === 2147483648) networkScore--;
              if (coinType === 2147483649) networkScore++;
            }
          }
        }
      }
      for (let i = 0; i < tx.outputsLength; i++) totalOutput += Number(tx.getOutput(i).amount);
      const fee = totalInput > 0 ? totalInput - totalOutput : 0;
      return {
        valid: true,
        signerCount: fingerprints.size || 1,
        amountBtc: totalOutput / 1e8,
        networkFeeSat: fee,
        outputCount: tx.outputsLength,
        detectedNetwork: networkScore > 0 ? "testnet" : "bitcoin"
      };
    } catch (e) {
      return null;
    }
  }
};

// libs/sdk/src/index.ts
var src_exports = {};
__export(src_exports, {
  EncryptionEngine: () => EncryptionEngine,
  PsbtUtils: () => PsbtUtils,
  RelayClient: () => RelayClient,
  RoomAuditor: () => RoomAuditor,
  RoomEventBus: () => RoomEventBus,
  RoomFactory: () => RoomFactory,
  RoomStateStore: () => RoomStateStore,
  SigningRoomClient: () => SigningRoomClient
});

// libs/sdk/src/lib/events/room-event-bus.ts
import { Subject } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/rxjs.js?v=cf17c1b4";
import { filter } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/rxjs_operators.js?v=cf17c1b4";
var RoomEventBus = class {
  /** Internal streaming subject piping incoming signals down active subscriber branches. */
  eventsSubject = new Subject();
  /**
   * Publishes an event to the messaging bus layout, casting it to all current observers.
   * Typically used internally by the SDK module components.
   * * @param type - The exact event classifier tag.
   * @param payload - Optional extra metadata parameters associated with the operation scope.
   */
  dispatch(type, payload) {
    this.eventsSubject.next({ type, payload });
  }
  /**
   * Generates a reactive channel filtered down to an isolated event string type.
   * * @param eventType - The target event indicator to listen for.
   * @returns An RxJS Observable yielding exclusive target events.
   */
  on(eventType) {
    return this.eventsSubject.asObservable().pipe(filter((event) => event.type === eventType));
  }
  /**
   * Generates an un-filtered event stream listening to every message running across the bus architecture.
   * Perfect for building centralized auditing engines, telemetry logs, or state synchronizers.
   * * @returns An RxJS Observable catching all events moving across the channel surface.
   */
  onAll() {
    return this.eventsSubject.asObservable();
  }
};

// libs/sdk/src/lib/relay/relay-client.ts
import { Transaction as Transaction2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_btc-signer.js?v=cf17c1b4";
var RelayClient = class {
  /**
   * Initializes a fresh instance of the RelayClient coordination module.
   * @param crypto - The active abstraction engine executing encryption/decryption requests.
   */
  constructor(crypto2) {
    this.crypto = crypto2;
  }
  crypto;
  /** The internal WebSocket connection instance tracking active server pipelines. */
  ws = null;
  /** Public reactive message channel bus for host frameworks (like Angular) to hook listeners. */
  events = new RoomEventBus();
  /** The standard 256-bit symmetric key configuration utilized for encryption boundaries. */
  encryptionKey = null;
  /** Local cache mapping blinded hex-string tokens back to physical 8-character hardware wallet fingerprints. */
  blindFingerprintMap = /* @__PURE__ */ new Map();
  /**
   * Directly maps or flushes the symmetric key token applied across state parameters.
   * @param key - The base64-encoded secret passphrase or null to revoke permissions.
   */
  setKey(key) {
    this.encryptionKey = key;
  }
  /**
   * Instantiates a live WebSocket session pointing to a target relay instance.
   * Establishes low-level hooks routing platform errors and server frames cleanly into reactive buses.
   * @param url - The absolute target location protocol string (e.g., `wss://relay...`).
   */
  connect(url) {
    this.disconnect(true);
    this.ws = new WebSocket(url);
    this.ws.onopen = () => {
      this.events.dispatch("ROOM_CONNECTED");
    };
    this.ws.onclose = (e) => {
      this.events.dispatch("ROOM_DISCONNECTED", { code: e.code, reason: e.reason });
      if (e.code === 4026) {
        this.events.dispatch("PROTOCOL_ERROR", { type: "version_mismatch", roomVersion: "1.0.0" });
      } else if (e.code === 4001) {
        this.events.dispatch("PROTOCOL_ERROR", { type: "room_full" });
      } else if (e.code === 1006) {
        this.events.dispatch("PROTOCOL_ERROR", { type: "access_denied" });
      } else if (e.code === 4004) {
        this.events.dispatch("PROTOCOL_ERROR", { type: "not_found" });
      }
    };
    this.ws.onerror = (e) => this.events.dispatch("ERROR", e);
    this.ws.onmessage = (event) => __async(this, null, function* () {
      try {
        const msg = JSON.parse(event.data);
        yield this.routeMessage(msg);
      } catch (e) {
        console.error("RelayClient: Message parse error", e);
      }
    });
  }
  /**
   * Sanitizes key parameters, calculates access passes, and joins a targeted collaboration session.
   * Automatically normalizes percent-encoded and whitespace-padded URL fragments.
   * @param wsBaseUrl - The root protocol base target URL.
   * @param roomId - The target workspace room uuid string.
   * @param key - The raw symmetric workspace key string argument.
   * @param version - The client version identifier string checking backend compatibility.
   */
  joinRoom(wsBaseUrl, roomId, key, version) {
    return __async(this, null, function* () {
      let cleanKey = key.trim();
      if (cleanKey.includes("%")) {
        try {
          cleanKey = decodeURIComponent(cleanKey);
        } catch (e) {
        }
      }
      this.setKey(cleanKey);
      const roomPass = cleanKey ? yield this.crypto.blindData(roomId, cleanKey) : "";
      const url = `${wsBaseUrl}/api/room/${roomId}/websocket?v=${version}&pass=${roomPass}`;
      this.connect(url);
    });
  }
  /**
   * Breaks active socket tunnels cleanly and de-allocates platform state references.
   * @param clearListeners - Set to true to zero out event properties preventing execution leakage.
   */
  disconnect(clearListeners = false) {
    if (this.ws) {
      if (clearListeners) {
        this.ws.onclose = null;
        this.ws.onerror = null;
        this.ws.onmessage = null;
        this.ws.onopen = null;
      }
      this.ws.close();
      this.ws = null;
    }
  }
  /**
   * Serializes and writes data objects to the server socket pipeline.
   * Short-circuits completely if the underlying socket state is not explicitly open.
   * @param type - The outbound event token action header.
   * @param payload - Optional content mappings defining parameters for the requested action.
   */
  send(type, payload = {}) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(__spreadValues({ type }, payload)));
    }
  }
  /**
   * Evaluates incoming message topics and invokes targeted structural sorting or deciphering paths.
   * Dispatches warning topics immediately down the bus line if structural payloads encounter missing context keys.
   * @param msg - The raw parsed server frame payload object.
   */
  routeMessage(msg) {
    return __async(this, null, function* () {
      if (!this.encryptionKey && (msg.encryptedPsbt || msg.type === "NEW_PARTIAL_DATA")) {
        this.events.dispatch("DECRYPTION_ERROR", "Decryption Key Missing");
        return;
      }
      switch (msg.type) {
        case "SESSION_CONNECTED":
          this.events.dispatch("SESSION_CONNECTED", msg.sessionId);
          break;
        case "STATE_SYNC":
          const syncData = yield this.processStateSync(msg);
          if (syncData) this.events.dispatch("STATE_SYNC_DECRYPTED", syncData);
          break;
        case "NEW_PARTIAL_DATA":
          const partialData = yield this.processNewPartial(msg);
          if (partialData) this.events.dispatch("NEW_PARTIAL_DECRYPTED", partialData);
          break;
        case "LABELS_UPDATED":
          this.events.dispatch("LABELS_DECRYPTED", yield this.decryptLabels(msg.signerLabels));
          break;
        case "ROOM_RENAMED":
          if (msg.encryptedName && this.encryptionKey) {
            try {
              const roomName = yield this.crypto.decrypt(msg.encryptedName, this.encryptionKey);
              this.events.dispatch("ROOM_RENAMED_DECRYPTED", roomName);
            } catch (e) {
              console.error("Relay: Failed to decrypt room name", e);
            }
          }
          break;
        case "LOG_UPDATE":
          this.events.dispatch(
            "LOG_UPDATE_DECRYPTED",
            yield this.decryptAuditLog(msg.auditLog || [])
          );
          break;
        case "CONNECTIONS_UPDATE":
          this.events.dispatch("CONNECTIONS_DECRYPTED", {
            count: msg.count,
            sessions: yield this.decryptSessions(msg.sessions)
          });
          break;
        case "ROLE_UPDATE":
          this.events.dispatch("ROLE_UPDATE", msg.role);
          break;
        case "ROOM_CLOSED":
          this.events.dispatch("ROOM_CLOSED");
          break;
        case "WHITELIST_UPDATED":
          if (msg.encryptedWhitelist && this.encryptionKey) {
            try {
              const decW = yield this.crypto.decrypt(msg.encryptedWhitelist, this.encryptionKey);
              this.events.dispatch("WHITELIST_DECRYPTED", JSON.parse(decW));
            } catch (e) {
              console.error("Relay: Failed to decrypt whitelist", e);
            }
          }
          break;
        case "PARTICIPANTS_UPDATE":
          this.events.dispatch(
            "PARTICIPANTS_DECRYPTED",
            yield this.decryptParticipants(msg.participants)
          );
          break;
        case "LOCK_UPDATED":
          this.events.dispatch("LOCK_UPDATED", msg);
          break;
        case "TX_FINALIZED_BROADCAST":
          if (msg.encryptedFinalTxHex && msg.encryptedFinalTxId && this.encryptionKey) {
            try {
              const finalTxHex = yield this.crypto.decrypt(
                msg.encryptedFinalTxHex,
                this.encryptionKey
              );
              const finalTxId = yield this.crypto.decrypt(msg.encryptedFinalTxId, this.encryptionKey);
              this.events.dispatch("TX_FINALIZED_DECRYPTED", { finalTxHex, finalTxId });
            } catch (e) {
              console.error("Relay: Failed to decrypt final tx", e);
            }
          }
          break;
        case "ERROR_LOCKED":
          this.events.dispatch("PROTOCOL_ERROR", { type: "locked" });
          break;
        case "ERROR_NOT_FOUND":
          this.events.dispatch("PROTOCOL_ERROR", { type: "not_found" });
          break;
        case "ERROR_VERSION_MISMATCH":
          this.events.dispatch("PROTOCOL_ERROR", {
            type: "version_mismatch",
            roomVersion: msg.roomVersion
          });
          break;
        default:
          this.events.dispatch("RAW_MESSAGE", msg);
      }
    });
  }
  /**
   * Parses complete room history packages, combining multi-sig sign files and cleaning ledger matrices.
   * @param msg - Raw block payload mapping configuration parameters.
   * @returns A Promise resolving to structural composite state metrics or null if execution encounters errors.
   */
  processStateSync(msg) {
    return __async(this, null, function* () {
      let masterPsbt = "";
      try {
        masterPsbt = msg.encryptedPsbt ? yield this.crypto.decrypt(msg.encryptedPsbt, this.encryptionKey) : msg.psbt || "";
      } catch (e) {
        this.events.dispatch("DECRYPTION_ERROR", "Invalid decryption key provided.");
        return null;
      }
      masterPsbt = PsbtUtils.normalize(masterPsbt);
      const decryptedHistory = [];
      if (msg.signatures?.length) {
        for (const sig of msg.signatures) {
          try {
            const encTarget = sig?.encryptedData || sig;
            const dec = yield this.crypto.decrypt(encTarget, this.encryptionKey);
            decryptedHistory.push(PsbtUtils.normalize(dec));
          } catch (e) {
            if (typeof sig === "string") decryptedHistory.push(PsbtUtils.normalize(sig));
          }
        }
      }
      let mergedPsbt = masterPsbt;
      for (const sigData of decryptedHistory) {
        mergedPsbt = PsbtUtils.merge(mergedPsbt, sigData);
      }
      if (mergedPsbt) {
        yield this.registerAllFingerprints(mergedPsbt);
      }
      const decryptedLabels = yield this.decryptLabels(msg.signerLabels || {});
      const decryptedLog = yield this.decryptAuditLog(msg.auditLog || []);
      const decryptedParticipants = yield this.decryptParticipants(msg.participants || {});
      let decryptedWhitelist = [];
      if (msg.whitelist && typeof msg.whitelist === "string") {
        try {
          const decW = yield this.crypto.decrypt(msg.whitelist, this.encryptionKey);
          decryptedWhitelist = JSON.parse(decW);
        } catch (e) {
          console.error("Relay: Failed to decrypt whitelist in sync");
        }
      } else if (Array.isArray(msg.whitelist)) {
        decryptedWhitelist = msg.whitelist;
      }
      let decryptedRoomName = "Untitled Room";
      if (msg.roomName && this.encryptionKey) {
        if (msg.roomName.length >= 40) {
          try {
            decryptedRoomName = yield this.crypto.decrypt(msg.roomName, this.encryptionKey);
          } catch (e) {
            decryptedRoomName = msg.roomName;
          }
        } else {
          decryptedRoomName = msg.roomName;
        }
      }
      let finalTxHex = msg.finalTxHex;
      let finalTxId = msg.finalTxId;
      if (msg.encryptedFinalTxHex && msg.encryptedFinalTxId && this.encryptionKey) {
        try {
          finalTxHex = yield this.crypto.decrypt(msg.encryptedFinalTxHex, this.encryptionKey);
          finalTxId = yield this.crypto.decrypt(msg.encryptedFinalTxId, this.encryptionKey);
        } catch (e) {
          console.error("Relay: Failed to decrypt final TX data in sync", e);
        }
      }
      return __spreadProps(__spreadValues({}, msg), {
        psbt: mergedPsbt,
        signatures: decryptedHistory,
        signerLabels: Object.keys(decryptedLabels).length > 0 ? decryptedLabels : msg.signerLabels,
        auditLog: decryptedLog,
        whitelist: decryptedWhitelist,
        participants: Object.keys(decryptedParticipants).length > 0 ? decryptedParticipants : msg.participants || {},
        roomName: decryptedRoomName,
        finalTxHex,
        finalTxId
      });
    });
  }
  /**
   * Decrypts individual standalone incoming user signature frames.
   * @param msg - The partial data payload container.
   * @returns Decoded structural mapping properties or null if empty.
   */
  processNewPartial(msg) {
    return __async(this, null, function* () {
      if (!msg.data?.encryptedData) return null;
      const decrypted = yield this.crypto.decrypt(msg.data.encryptedData, this.encryptionKey);
      const realFingerprint = this.blindFingerprintMap.get(msg.fingerprint) || msg.fingerprint;
      return {
        decryptedPsbt: PsbtUtils.normalize(decrypted),
        fingerprint: realFingerprint,
        sessionId: msg.sessionId
      };
    });
  }
  /**
   * Decodes input scopes inside a PSBT map, extracting and caching hardware BIP32 source paths.
   * @param psbtData - Target unencrypted transaction base64 string.
   */
  registerAllFingerprints(psbtData) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      try {
        const bytes = PsbtUtils.decode(psbtData);
        const tx = Transaction2.fromPSBT(bytes);
        for (let i = 0; i < tx.inputsLength; i++) {
          const input = tx.getInput(i);
          if (input.bip32Derivation) {
            for (const [, meta] of input.bip32Derivation) {
              const fp = meta.fingerprint.toString(16).padStart(8, "0");
              const blinded = yield this.crypto.blindData(fp, this.encryptionKey);
              this.blindFingerprintMap.set(blinded, fp);
              this.blindFingerprintMap.set(fp, fp);
            }
          }
        }
      } catch (e) {
        console.error("Relay: Failed to parse fingerprints");
      }
    });
  }
  /**
   * Reconstructs historical audit entries, deciphering encrypted data rows sequentially.
   * @param logs - Collection of plain or encrypted tracking items.
   */
  decryptAuditLog(logs) {
    return __async(this, null, function* () {
      if (!this.encryptionKey || !logs || !Array.isArray(logs)) return [];
      const decryptedLog = [];
      for (const item of logs) {
        if (!item) continue;
        const encryptedBlob = typeof item === "string" ? item : item.encryptedLogBlob;
        if (encryptedBlob) {
          try {
            const dec = yield this.crypto.decrypt(encryptedBlob, this.encryptionKey);
            const entry = JSON.parse(dec);
            if (entry) decryptedLog.push(entry);
          } catch (e) {
            decryptedLog.push({
              timestamp: 0,
              event: "Encrypted Data (Decryption Failed)",
              user: "Unknown"
            });
          }
        } else if (item.event && item.user) {
          decryptedLog.push(item);
        }
      }
      return decryptedLog.filter((e) => e !== null).sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    });
  }
  /**
   * Re-evaluates signer tags, matching real wallet ids to readable identifiers.
   * @param encryptedLabels - Key value mapping configuration using blinded properties.
   */
  decryptLabels(encryptedLabels) {
    return __async(this, null, function* () {
      const decryptedLabels = {};
      if (!encryptedLabels || !this.encryptionKey) return decryptedLabels;
      for (const [blindedFp, encryptedLabel] of Object.entries(encryptedLabels)) {
        const realFp = this.blindFingerprintMap.get(blindedFp) || blindedFp;
        try {
          decryptedLabels[realFp] = encryptedLabel.length >= 40 ? yield this.crypto.decrypt(encryptedLabel, this.encryptionKey) : encryptedLabel;
        } catch (e) {
          decryptedLabels[realFp] = encryptedLabel;
        }
      }
      return decryptedLabels;
    });
  }
  /**
   * Decodes list matrices tracking currently connected user metadata identities.
   * @param sessions - Active connection array profiles.
   */
  decryptSessions(sessions) {
    return __async(this, null, function* () {
      if (!sessions || !this.encryptionKey) return [];
      return yield Promise.all(
        sessions.map((s) => __async(this, null, function* () {
          let plainName = void 0;
          if (s.encryptedDisplayName) {
            try {
              plainName = yield this.crypto.decrypt(s.encryptedDisplayName, this.encryptionKey);
            } catch (e) {
              plainName = "Decrypt Error";
            }
          }
          return { id: s.id, role: s.role, displayName: plainName };
        }))
      );
    });
  }
  /**
   * Decodes explicit historical registration arrays defining structural workspace membership profiles.
   * @param participants - Map dictionary containing authorization parameters.
   */
  decryptParticipants(participants) {
    return __async(this, null, function* () {
      const decParts = {};
      if (!participants || !this.encryptionKey) return decParts;
      for (const [sid, pData] of Object.entries(participants)) {
        let plainName = void 0;
        const typedP = pData;
        if (typedP.encryptedDisplayName) {
          try {
            plainName = yield this.crypto.decrypt(typedP.encryptedDisplayName, this.encryptionKey);
          } catch (e) {
          }
        }
        decParts[sid] = __spreadProps(__spreadValues({}, typedP), { displayName: plainName });
      }
      return decParts;
    });
  }
  /**
   * Packs unified auditing lines into base64 encryptions ready for platform synchronization.
   * @param event - Core title representing the executed method.
   * @param detail - Informative log context statement data.
   * @param user - Human handle triggering the action task.
   */
  createSecureLogBlob(event, detail, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return "";
      const logEntry = { timestamp: Date.now(), event, detail, user };
      return yield this.crypto.encrypt(JSON.stringify(logEntry), this.encryptionKey);
    });
  }
  /**
   * Encrypts and transmits a live action log tracking record out to the server workspace relay.
   */
  logAction(event, detail, user) {
    return __async(this, null, function* () {
      const encryptedLogBlob = yield this.createSecureLogBlob(event, detail, user);
      this.send("LOG_ACTION", { encryptedLogBlob });
    });
  }
  /**
   * Prepares and uploads a multi-sig signature payload to the server pipeline.
   * @param partialPsbtBase64 - Raw signed PSBT data representation framework.
   * @param fingerprint - Core 8-character wallet string identifier.
   * @param user - Username indicator logging execution profiles.
   */
  uploadSignature(partialPsbtBase64, fingerprint, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const blindedFingerprint = yield this.crypto.blindData(fingerprint, this.encryptionKey);
      const encryptedData = yield this.crypto.encrypt(partialPsbtBase64, this.encryptionKey);
      const encryptedLogBlob = yield this.createSecureLogBlob(
        "Signature Uploaded",
        `Signer: ${fingerprint}`,
        user
      );
      this.blindFingerprintMap.set(blindedFingerprint, fingerprint);
      this.blindFingerprintMap.set(fingerprint, fingerprint);
      this.send("UPLOAD_PARTIAL", {
        fingerprint: blindedFingerprint,
        data: { encryptedData },
        encryptedLogBlob
      });
    });
  }
  /**
   * Validates explicit management tokens granting elevated coordinator configuration options.
   * @param secureToken - Admin passphrase payload string.
   */
  claimCoordinator(secureToken) {
    if (secureToken) this.send("AUTH", { token: secureToken.trim() });
  }
  /** Submits an intentional instruction forcing the remote server instance to close completely. */
  closeRoom() {
    this.send("CLOSE_ROOM");
  }
  /**
   * Emits trailing connection telemetry out before executing low-level WebSocket termination steps.
   * @param sessionId - Socket communication identity handle tracking ownership.
   */
  gracefullyDisconnect(sessionId) {
    return __async(this, null, function* () {
      if (sessionId && this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          const encryptedLogBlob = yield this.createSecureLogBlob(
            "User Left",
            `Session ID: ${sessionId}`,
            "Guest"
          );
          this.send("LOG_ACTION", { encryptedLogBlob });
        } catch (e) {
          console.error("Failed to send disconnect log");
        }
      }
      setTimeout(() => this.disconnect(), 50);
    });
  }
  /**
   * Mutates active room descriptions, dispatching corresponding encrypted logs out to observers.
   * @param newName - Target cleartext title string.
   */
  renameRoom(newName, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const encryptedName = yield this.crypto.encrypt(newName, this.encryptionKey);
      const encryptedLogBlob = yield this.createSecureLogBlob(
        "Room Renamed",
        `Renamed: ${newName}`,
        user
      );
      this.send("RENAME_ROOM", { encryptedName, encryptedLogBlob });
    });
  }
  /**
   * Overwrites metadata descriptions linking specialized multi-sig hardware profiles to custom names.
   * @param fingerprint - Hardware wallet tracking reference string.
   * @param label - Custom user identification nickname mapping string.
   */
  updateSignerLabel(fingerprint, label, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const safeLabel = label || "";
      const blindedFingerprint = yield this.crypto.blindData(fingerprint, this.encryptionKey);
      const encryptedLabel = yield this.crypto.encrypt(safeLabel, this.encryptionKey);
      const encryptedLogBlob = yield this.createSecureLogBlob(
        "Label Updated",
        `${safeLabel} (${fingerprint})`,
        user
      );
      this.blindFingerprintMap.set(blindedFingerprint, fingerprint);
      this.send("UPDATE_LABEL", {
        fingerprint: blindedFingerprint,
        label: encryptedLabel,
        encryptedLogBlob
      });
    });
  }
  /**
   * Modifies the local session user's display name broadcast to other collaborative room peers.
   * @param name - Raw alphanumeric display nickname. Empty or clean mappings send null value indicators.
   */
  setDisplayName(name) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const safeName = name.trim().substring(0, 64);
      if (safeName) {
        const encryptedDisplayName = yield this.crypto.encrypt(safeName, this.encryptionKey);
        this.send("SET_DISPLAY_NAME", { encryptedDisplayName });
      } else {
        this.send("SET_DISPLAY_NAME", { encryptedDisplayName: null });
      }
    });
  }
  /**
   * Updates authorization matrices controlling collaborative access lists.
   * @param newList - Plain text arrays housing verified authorization descriptors.
   * @param actionDetail - Descriptive action ledger explanation tracking the rule change.
   */
  updateWhitelist(newList, actionDetail, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const encryptedWhitelist = yield this.crypto.encrypt(
        JSON.stringify(newList),
        this.encryptionKey
      );
      const encryptedLogBlob = yield this.createSecureLogBlob(
        "Whitelist Updated",
        actionDetail,
        user
      );
      this.send("UPDATE_WHITELIST", { encryptedWhitelist, encryptedLogBlob });
    });
  }
  /**
   * Controls workspace interaction constraints, preventing or permitting operations dynamically.
   * @param isLocked - Evaluation condition flag checking state locks.
   */
  toggleLock(isLocked, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const actionDetail = isLocked ? "Coordinator locked the room" : "Coordinator unlocked the room";
      const encryptedLogBlob = yield this.createSecureLogBlob("Room Locked", actionDetail, user);
      this.send("TOGGLE_LOCK", { isLocked, encryptedLogBlob });
    });
  }
  /**
   * Publishes complete assembled transaction profiles out to active session instances.
   * @param finalTxHex - Complete serialized ready-to-broadcast bitcoin hex matrix format.
   * @param finalTxId - Unique tracking transactional chain ID.
   */
  broadcastFinalization(finalTxHex, finalTxId, user) {
    return __async(this, null, function* () {
      if (!this.encryptionKey) return;
      const encryptedFinalTxHex = yield this.crypto.encrypt(finalTxHex, this.encryptionKey);
      const encryptedFinalTxId = yield this.crypto.encrypt(finalTxId, this.encryptionKey);
      const encryptedLogBlob = yield this.createSecureLogBlob(
        "Tx Finalized",
        "Signatures merged successfully",
        user
      );
      this.send("TX_FINALIZED", { encryptedFinalTxHex, encryptedFinalTxId, encryptedLogBlob });
    });
  }
};

// libs/sdk/src/lib/relay/room-state-store.ts
var RoomStateStore = class {
  /**
   * Initializes state layout streams and establishes implicit event bus subscription handlers.
   * @param events - The central decoupled messaging interface system layer.
   */
  constructor(events) {
    this.events = events;
    this.events.on("STATE_SYNC_DECRYPTED").subscribe((e) => this.sync(e.payload));
    this.events.on("NEW_PARTIAL_DECRYPTED").subscribe((e) => this.merge(e.payload));
    this.events.on("LOCK_UPDATED").subscribe((e) => {
      const isLocked = typeof e.payload?.isLocked === "boolean" ? e.payload.isLocked : e.payload;
      this.updatePartial({ isLocked });
    });
    this.events.on("LABELS_DECRYPTED").subscribe((e) => this.updatePartial({ signerLabels: e.payload }));
    this.events.on("ROOM_RENAMED_DECRYPTED").subscribe((e) => this.updatePartial({ roomName: e.payload }));
    this.events.on("LOG_UPDATE_DECRYPTED").subscribe((e) => this.updatePartial({ auditLog: e.payload }));
    this.events.on("WHITELIST_DECRYPTED").subscribe((e) => this.updatePartial({ whitelist: e.payload }));
    this.events.on("PARTICIPANTS_DECRYPTED").subscribe((e) => this.updatePartial({ participants: e.payload }));
    this.events.on("CONNECTIONS_DECRYPTED").subscribe((e) => this.updatePartial({ connectedCount: e.payload.count }));
    this.events.on("TX_FINALIZED_DECRYPTED").subscribe(
      (e) => this.updatePartial({
        finalTxHex: e.payload.finalTxHex,
        finalTxId: e.payload.finalTxId
      })
    );
    this.events.on("UPDATE_LABEL").subscribe((e) => {
      const { fingerprint, label } = e.payload;
      this.updatePartial({
        signerLabels: __spreadProps(__spreadValues({}, this.state?.signerLabels), {
          [fingerprint]: label
        })
      });
    });
  }
  events;
  /** The current active memory allocation tree layer mapping state metrics. */
  state = null;
  /**
   * Mutates current state map attributes on-the-fly and broadcasts modification signals.
   * Short-circuits execution completely if the store has not been structurally initialized.
   * @param partialState - An object mapping key properties to match against the schema structure.
   */
  updatePartial(partialState) {
    if (!this.state) return;
    this.state = __spreadValues(__spreadValues({}, this.state), partialState);
    this.events.dispatch("STATE_CHANGED", this.state);
  }
  /**
   * Returns a synchronous snapshot of the active memory allocation reference structure.
   * @returns The active RoomState model blueprint or null if unallocated.
   */
  getState() {
    return this.state;
  }
  /**
   * Allocates a baseline structural template mapping zeroed default attributes for a session.
   * * @param roomId - The unique tracking identifier mapping space boundary scopes.
   * @param protocolVersion - Semantic version string targeting execution profiles.
   */
  init(roomId, protocolVersion) {
    this.state = {
      roomId,
      psbt: "",
      signatures: [],
      connectedCount: 0,
      createdAt: Date.now(),
      expiresAt: Date.now() + 12e5,
      auditLog: [],
      signerLabels: {},
      roomName: "Signing Room",
      whitelist: [],
      participants: {},
      isLocked: false,
      network: "bitcoin",
      protocolVersion
    };
    this.events.dispatch("STATE_CHANGED", this.state);
  }
  /**
   * Replaces existing state structures wholesale by executing deep assignment merges.
   * @param data - The raw model mapping representation extracted from a socket stream line.
   */
  sync(data) {
    this.state = __spreadValues(__spreadValues({}, this.state), data);
    this.events.dispatch("STATE_CHANGED", this.state);
  }
  /**
   * Higher-order transformation function executing functional updates safely.
   * @param updater - A mutation callback function mapping state maps to newly evaluated profiles.
   */
  update(updater) {
    this.state = updater(this.state);
    if (this.state) {
      this.events.dispatch("STATE_CHANGED", this.state);
    }
  }
  /**
   * Directly overrides the state tracking allocation profile with an explicit input target.
   * @param newState - The new complete model configuration or null to wipe clean.
   */
  set(newState) {
    this.state = newState;
    if (newState) {
      this.events.dispatch("STATE_CHANGED", newState);
    }
  }
  /**
   * Combines incoming partial transactional details into current active signature layers.
   * Leverages structural PsbtUtils helpers to reconcile divergent hex paths.
   * @param payload - Data configuration structures tracking network signature details.
   */
  merge(payload) {
    if (!this.state) return;
    this.state = __spreadProps(__spreadValues({}, this.state), {
      psbt: PsbtUtils.merge(this.state.psbt, payload.decryptedPsbt),
      signatures: [...this.state.signatures, payload.decryptedPsbt]
    });
    this.events.dispatch("STATE_CHANGED", this.state);
  }
};

// libs/sdk/src/lib/relay/room-factory.ts
import { v4 as uuidv4 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/uuid.js?v=cf17c1b4";
var RoomFactory = class {
  /**
   * Prepares and encrypts all required token structures into a structured payload ready for backend initialization.
   * Handles all Key, Identifier, and cryptographic signature mappings automatically.
   * * @param engine - The structural EncryptionEngine instance running cryptographic tasks.
   * @param rawPsbtBase64 - The unencrypted Base64 string payload representing a Partically Signed Bitcoin Transaction.
   * @param network - The targeted blockchain network context constraint identifier.
   * @param roomName - The raw descriptive title assigned to the collaborative session space. Default is "Untitled Room".
   * @param protocolVersion - Semantic version configuration mapping. Default is "1.0.0".
   * @returns A Promise resolving to a completed RoomCreationPayload schema mapping.
   */
  static prepareCreationPayload(engine, rawPsbtBase64, network, roomName = "Untitled Room", protocolVersion = "1.0.0") {
    return __async(this, null, function* () {
      const encryptionKey = yield engine.generateKey();
      const roomId = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : this.fallbackUUID();
      const adminSecret = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : this.fallbackUUID();
      const encryptedData = yield engine.encrypt(rawPsbtBase64, encryptionKey);
      const encryptedAdminToken = yield engine.encrypt(adminSecret, encryptionKey);
      const encryptedRoomName = yield engine.encrypt(roomName, encryptionKey);
      const expectedPass = yield engine.blindData(roomId, encryptionKey);
      return {
        localData: {
          roomId,
          encryptionKey,
          adminSecret
        },
        httpPayload: {
          roomId,
          expectedPass,
          encryptedPsbt: encryptedData,
          adminToken: encryptedAdminToken,
          network,
          protocolVersion,
          encryptedRoomName
        }
      };
    });
  }
  /**
   * Generates a cryptographically secure RFC 4122 version 4 compliant UUID.
   *
   * This acts as a robust polyfill for non-standard execution contexts where the native
   * `crypto.randomUUID` is unavailable. It utilizes a cryptographically secure pseudo-random
   * number generator (CSPRNG) to guarantee unpredictability and prevent state hijacking.
   *
   * @returns {string} A formatted 36-character canonical UUIDv4 string.
   */
  static fallbackUUID() {
    return uuidv4();
  }
};

// libs/sdk/src/lib/bitcoin/room-auditor.ts
var RoomAuditor = class {
  /**
   * Compiles top-level transaction and participant metadata into a comma-separated format.
   * @param state - The active RoomState containing participant and network contexts.
   * @param tx - The parsed transaction details including I/O maps and fees.
   * @param signers - The list of active signers and their current signature status.
   * @returns A raw CSV string containing the formatted settlement row.
   */
  static getSettlementCsvData(state, tx, signers) {
    const headers = [
      "Date",
      "Room ID",
      "Network",
      "TXID",
      "Total Amount (BTC)",
      "Fee Rate (sats/vB)",
      "Inputs",
      "Outputs",
      "Signers",
      "Witnesses",
      "Status"
    ];
    const signersList = signers.map((s) => `${s.fingerprint}${s.signed ? "(Signed)" : "(Pending)"}`).join("; ");
    const participantsObj = state.participants || {};
    const witnessesList = Object.values(participantsObj).map((p) => {
      const name = p.displayName || "Anonymous";
      const role = p.role === "admin" ? "Coordinator" : "Guest";
      return `${name} [${role}] (${p.id})`;
    }).join("; ");
    const row = [
      (/* @__PURE__ */ new Date()).toISOString(),
      state.roomId,
      state.network,
      state.finalTxId || "Pending",
      (tx.amount / 1e8).toFixed(8),
      tx.feeRate,
      tx.inputsList?.length || 0,
      tx.outputs?.length || 0,
      `"${signersList}"`,
      `"${witnessesList}"`,
      state?.finalTxHex ? "Signed & Ready" : "Pending Signatures"
    ];
    return headers.join(",") + "\n" + row.join(",");
  }
  /**
   * Transforms the decentralized room audit log into a flat CSV format for external archiving.
   * @param state - The active RoomState containing the chronological audit log.
   * @returns A raw CSV string containing headers and sanitized event rows.
   */
  static getAuditLogCsvData(state) {
    const logs = state.auditLog || [];
    const csvHeader = "Timestamp,Event,User,Detail\n";
    const csvRows = logs.map((l) => {
      const time = new Date(l.timestamp).toISOString();
      const event = `"${l.event.replace(/"/g, '""')}"`;
      const user = `"${l.user.replace(/"/g, '""')}"`;
      const detail = `"${(l.detail || "").replace(/"/g, '""')}"`;
      return `${time},${event},${user},${detail}`;
    }).join("\n");
    return csvHeader + csvRows;
  }
  /**
   * Generates a Data URI string containing the settlement CSV for direct browser downloading.
   * @param state - The active RoomState.
   * @param tx - The parsed transaction details.
   * @param signers - The list of active signers.
   * @returns A URI-encoded data string (data:text/csv...).
   */
  static getEncodedCsvData(state, tx, signers) {
    const csvContent = "data:text/csv;charset=utf-8," + this.getSettlementCsvData(state, tx, signers);
    return encodeURI(csvContent);
  }
  /**
   * Procedurally constructs a comprehensive, multi-page compliance PDF using the provided jsPDF instance.
   * Maps room governance, cryptographic anchors, participant manifests, and transaction parameters into a standard format.
   * @param doc - An initialized jsPDF instance.
   * @param state - The finalized RoomState containing metadata and logs.
   * @param tx - The parsed transaction payload (can be null if unparseable).
   * @param signers - The list of signers mapping fingerprints to signature states.
   * @param finalHex - The extracted, broadcast-ready raw transaction hex, if available.
   * @returns A Promise resolving to an object containing the mutated document and the standardized filename.
   */
  static generateAuditPdf(doc, state, tx, signers, finalHex, options) {
    return __async(this, null, function* () {
      let y = 20;
      const checkPageBreak = (spaceNeeded) => {
        if (y + spaceNeeded > 280) {
          doc.addPage();
          y = 20;
        }
      };
      let headingText = "SigningRoom.io";
      if (options?.isWhitelabel) {
        headingText = options?.brandName || "SigningRoom.io";
      }
      const brandColor = options?.brandColor || [16, 185, 129];
      let currentX = 20;
      const logoHeight = 12;
      const logoYOffset = y - 9;
      if (options?.logoDataUrl) {
        try {
          const imgProps = doc.getImageProperties(options.logoDataUrl);
          const logoWidth = imgProps.width * logoHeight / imgProps.height;
          doc.addImage(options.logoDataUrl, "PNG", currentX, logoYOffset, logoWidth, logoHeight);
          currentX += logoWidth + 4;
        } catch (e) {
          console.warn("Failed to embed logo in PDF", e);
        }
      }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(24);
      doc.setTextColor(brandColor[0], brandColor[1], brandColor[2]);
      doc.text(headingText, currentX, y);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(16);
      doc.setTextColor(100);
      doc.text("Audit Log", 20, y + 12);
      y += 24;
      doc.setDrawColor(200);
      doc.setLineWidth(0.5);
      doc.line(20, y, 190, y);
      y += 10;
      if (finalHex && state.auditLog && state.auditLog.length > 0) {
        checkPageBreak(35);
        const anchor = yield this.calculateForensicAnchor(state.auditLog, finalHex);
        doc.setFontSize(14);
        doc.setTextColor(brandColor[0], brandColor[1], brandColor[2]);
        doc.setFont("helvetica", "bold");
        doc.text("Cryptographic Integrity Seal", 20, y);
        y += 6;
        doc.setFontSize(9);
        doc.setTextColor(100);
        doc.setFont("helvetica", "italic");
        doc.text(
          "This anchor mathematically binds the raw transaction hex to the chronological event timeline below.",
          20,
          y
        );
        y += 5;
        doc.text("Verification formula: SHA256(Audit_Log_CSV_String + Final_Tx_Hex)", 20, y);
        y += 8;
        doc.setFontSize(10);
        doc.setTextColor(0);
        doc.setFont("courier", "bold");
        doc.text(anchor, 20, y);
        y += 10;
        doc.setDrawColor(200);
        doc.setLineWidth(0.5);
        doc.line(20, y, 190, y);
        y += 10;
      }
      checkPageBreak(40);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Room Info & Governance", 20, y);
      y += 8;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(50);
      doc.text(`Room: ${state.roomName}`, 20, y);
      y += 6;
      doc.text(`Room ID: ${state.roomId}`, 20, y);
      y += 6;
      doc.text(`Network: ${(state.network || "bitcoin").toUpperCase()}`, 20, y);
      y += 6;
      doc.text(`Created: ${new Date(state.createdAt).toLocaleString()}`, 20, y);
      y += 6;
      const lockStatus = state.isLocked ? "LOCKED (Secure)" : "UNLOCKED (Open)";
      doc.text(`Room Status: ${lockStatus}`, 20, y);
      y += 6;
      const whitelistCount = state.whitelist?.length || 0;
      doc.text(`Whitelist Enforcement: ${whitelistCount > 0 ? "Active" : "Disabled"}`, 20, y);
      y += 15;
      checkPageBreak(40);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Transaction Data", 20, y);
      y += 8;
      const txId = state.finalTxId;
      if (txId) {
        doc.setFontSize(10);
        doc.setTextColor(50);
        doc.setFont("helvetica", "bold");
        doc.text("Transaction ID (TXID):", 20, y);
        y += 5;
        doc.setFont("courier", "bold");
        doc.setFontSize(9);
        doc.setTextColor(0);
        doc.text(String(txId), 20, y);
        y += 8;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(8);
        doc.setTextColor(100);
        const explorerUrl = state.network === "testnet" ? "mempool.space/testnet/tx/" : state.network === "signet" ? "mempool.space/signet/tx/" : "mempool.space/tx/";
        doc.text(`View on Explorer: ${explorerUrl}${txId.slice(0, 8)}...`, 20, y);
        y += 10;
      }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.setTextColor(50);
      doc.text("Raw Hex Data (Partial):", 20, y);
      y += 5;
      doc.setFontSize(8);
      doc.setFont("courier", "normal");
      doc.setTextColor(80);
      let partialHexDisplay = "Not yet finalized";
      if (finalHex) {
        partialHexDisplay = `${finalHex.slice(0, 32)}...[${finalHex.length} bytes]...${finalHex.slice(-32)}`;
      }
      doc.text(partialHexDisplay, 20, y, { maxWidth: 170 });
      doc.setFont("helvetica", "normal");
      y += 15;
      checkPageBreak(30);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Signer Activity", 20, y);
      y += 10;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      if (signers.length === 0) {
        doc.setTextColor(150);
        doc.text("No signers detected yet.", 20, y);
        y += 6;
      } else {
        signers.forEach((s, i) => {
          checkPageBreak(10);
          const status = s.signed ? "SIGNED" : "PENDING";
          const label = state.signerLabels?.[s.fingerprint];
          const displayName = label ? `${label} (${s.fingerprint})` : s.fingerprint;
          doc.setTextColor(50);
          doc.text(`${i + 1}. ${displayName}`, 20, y);
          doc.text(status, 150, y);
          y += 6;
        });
      }
      y += 10;
      checkPageBreak(30);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Room Participants (Witnesses)", 20, y);
      y += 8;
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      const participantsObj = state.participants || {};
      const historicalParticipants = Object.values(participantsObj);
      if (historicalParticipants.length === 0) {
        doc.setTextColor(150);
        doc.text("No participants recorded.", 20, y);
        y += 6;
      } else {
        historicalParticipants.forEach((p, i) => {
          checkPageBreak(10);
          doc.setTextColor(50);
          const roleBadge = p.role === "admin" ? "[Coordinator]" : "[Guest]";
          const displayName = p.displayName ? p.displayName : "Anonymous";
          doc.setFont("helvetica", "bold");
          doc.text(`${i + 1}. ${displayName} ${roleBadge}`, 20, y);
          doc.setFont("courier", "normal");
          doc.setFontSize(9);
          doc.setTextColor(100);
          doc.text(`Session ID: ${p.id}`, 140, y);
          doc.setFontSize(10);
          y += 6;
        });
      }
      y += 10;
      checkPageBreak(30);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Event Timeline", 20, y);
      y += 10;
      doc.setFontSize(9);
      const logs = state.auditLog || [];
      if (logs.length === 0) {
        doc.setTextColor(150);
        doc.setFont("helvetica", "italic");
        doc.text("No events logged yet.", 20, y);
        y += 6;
      } else {
        logs.forEach((log) => {
          if (!log) return;
          checkPageBreak(15);
          const safeEvent = log.event ? String(log.event) : "System Event";
          const safeUser = log.user ? String(log.user) : "System";
          const time = log.timestamp ? new Date(log.timestamp).toLocaleTimeString() : "--:--";
          const date = log.timestamp ? new Date(log.timestamp).toLocaleDateString() : "--/--/--";
          doc.setTextColor(120);
          doc.setFont("helvetica", "normal");
          doc.text(`${date} ${time}`, 20, y);
          doc.setTextColor(0);
          doc.setFont("helvetica", "bold");
          doc.text(safeEvent, 65, y);
          doc.setFont("helvetica", "normal");
          doc.text(safeUser, 110, y);
          if (log.detail) {
            doc.setTextColor(100);
            const detailStr = String(log.detail);
            const detailText = detailStr.length > 30 ? detailStr.substring(0, 27) + "..." : detailStr;
            doc.text(detailText, 150, y);
          }
          y += 7;
        });
      }
      y += 10;
      checkPageBreak(30);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Input Verification (Sources)", 20, y);
      y += 6;
      doc.setDrawColor(200);
      doc.line(20, y, 190, y);
      y += 5;
      const inputs = tx?.inputsList || [];
      const whitelist = state.whitelist || [];
      if (inputs.length === 0) {
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9);
        doc.setTextColor(150);
        doc.text("No input data parsed.", 20, y);
        y += 6;
      } else {
        inputs.forEach((inpt, i) => {
          checkPageBreak(15);
          const isWhitelisted = whitelist.includes(inpt.address);
          const amount = (inpt.amount / 1e8).toFixed(8);
          doc.setFontSize(8);
          doc.setTextColor(50);
          doc.setFont("courier", "normal");
          doc.text(`${i + 1}. ${inpt.address}`, 20, y);
          y += 4;
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9);
          doc.setTextColor(0);
          doc.text(`${amount} BTC`, 25, y);
          if (whitelist.length === 0) {
            doc.setTextColor(100);
            doc.text("NO WHITELIST", 150, y);
          } else if (isWhitelisted) {
            doc.setTextColor(16, 185, 129);
            doc.text("VERIFIED SOURCE", 150, y);
          } else {
            doc.setTextColor(220, 38, 38);
            doc.text("UNVERIFIED", 150, y);
          }
          y += 8;
        });
      }
      y += 10;
      checkPageBreak(30);
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Output Verification", 20, y);
      y += 6;
      doc.setDrawColor(200);
      doc.line(20, y, 190, y);
      y += 5;
      const outputs = tx?.outputs || [];
      if (outputs.length === 0) {
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9);
        doc.setTextColor(150);
        doc.text("No output data available yet.", 20, y);
        y += 6;
      } else {
        outputs.forEach((out, i) => {
          checkPageBreak(15);
          const isWhitelisted = whitelist.includes(out.address);
          const amount = (out.amount / 1e8).toFixed(8);
          doc.setFontSize(8);
          doc.setTextColor(50);
          doc.setFont("courier", "normal");
          doc.text(`${i + 1}. ${out.address}`, 20, y);
          y += 4;
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9);
          doc.setTextColor(0);
          doc.text(`${amount} BTC`, 25, y);
          if (whitelist.length === 0) {
            doc.setTextColor(100);
            doc.text("NO WHITELIST", 150, y);
          } else if (out.isChange) {
            doc.setTextColor(245, 158, 11);
            doc.text("CHANGE (VERIFIED)", 150, y);
          } else if (isWhitelisted) {
            doc.setTextColor(16, 185, 129);
            doc.text("VERIFIED DESTINATION", 150, y);
          } else {
            doc.setTextColor(220, 38, 38);
            doc.text("UNVERIFIED", 150, y);
          }
          y += 8;
        });
        doc.setDrawColor(200);
        doc.line(20, y, 190, y);
        y += 8;
        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        doc.setTextColor(100);
        doc.text(`Total Outputs: ${outputs.length}`, 20, y);
        y += 15;
      }
      const dateStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
      const shortId = state.roomId.slice(0, 8);
      const txSuffix = state.finalTxId ? state.finalTxId.slice(0, 8) : "Pending";
      let filename = `SigningRoom_Audit_${dateStr}_Room-${shortId}_Tx-${txSuffix}.pdf`;
      if (options?.isWhitelabel) {
        filename = `${options?.brandName?.replace(/\s+/g, "") || "SigningRoom"}_Audit_${dateStr}_Room-${shortId}_Tx-${txSuffix}.pdf`;
      }
      return { doc, filename };
    });
  }
  /**
   * Derives a deterministic cryptographic hash connecting the chronological audit log and the final transaction hex.
   * Prevents post-hoc modification of either the historical log or the finalized transaction data.
   * @param auditLog - The array of historical RoomState log entries.
   * @param finalTxHex - The broadcast-ready raw transaction hex.
   * @returns A Promise resolving to a 64-character SHA-256 hex string.
   */
  static calculateForensicAnchor(auditLog, finalTxHex) {
    return __async(this, null, function* () {
      const sortedLog = [...auditLog].sort((a, b) => a.timestamp - b.timestamp);
      const logStrings = sortedLog.map((entry) => {
        return `${new Date(entry.timestamp).toISOString()}|${entry.event}|${entry.user}|${entry.detail || ""}`;
      });
      const payload = logStrings.join("") + finalTxHex;
      const encoder = new TextEncoder();
      const data = encoder.encode(payload);
      const hashBuffer = yield crypto.subtle.digest("SHA-256", data);
      return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
    });
  }
  /**
   * Verifies that the current audit log and transaction hex match a previously issued forensic anchor.
   * @param state - The finalized RoomState to verify.
   * @param expectedAnchor - The known, previously calculated SHA-256 hash.
   * @returns A Promise resolving to an object containing the re-calculated anchor and a boolean validity flag.
   * @throws {Error} If the room state lacks required finalization parameters (hex or log).
   */
  static verifyRoomIntegrity(state, expectedAnchor) {
    return __async(this, null, function* () {
      if (!state.finalTxHex || !state.auditLog) {
        throw new Error("Room not finalized or audit log missing");
      }
      const calculatedAnchor = yield this.calculateForensicAnchor(state.auditLog, state.finalTxHex);
      const isValid = calculatedAnchor === expectedAnchor;
      return { anchor: calculatedAnchor, isValid };
    });
  }
  /**
   * Extracts a fresh cryptographic integrity report for a finalized room.
   * @param state - The finalized RoomState.
   * @returns A Promise resolving to the calculated forensic anchor and the current ISO timestamp.
   * @throws {Error} If the room state lacks required finalization parameters.
   */
  static getIntegrityReport(state) {
    return __async(this, null, function* () {
      if (!state.finalTxHex || !state.auditLog) throw new Error("Room not finalized");
      return {
        anchor: yield this.calculateForensicAnchor(state.auditLog, state.finalTxHex),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
    });
  }
};

// libs/sdk/src/lib/signing-room-client.ts
import { firstValueFrom } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/rxjs.js?v=cf17c1b4";
import { jsPDF } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/jspdf.js?v=cf17c1b4";
var SigningRoomClient = class {
  engine;
  relay;
  store;
  apiUrl;
  protocolVersion;
  _sessionId = null;
  _role = "guest";
  _encryptionKey = null;
  /**
   * Initializes a new SigningRoom client.
   * @param config - The API configuration and optional protocol versioning.
   */
  constructor(config) {
    this.apiUrl = config.apiUrl.replace(/\/$/, "");
    this.protocolVersion = config.protocolVersion || "1.0.0";
    this.engine = new EncryptionEngine();
    this.relay = new RelayClient(this.engine);
    this.store = new RoomStateStore(this.relay.events);
    this.relay.events.on("SESSION_CONNECTED").subscribe((e) => {
      this._sessionId = e.payload;
    });
    this.relay.events.on("ROLE_UPDATE").subscribe((e) => __async(this, null, function* () {
      const newRole = e.payload;
      if (this._role === "guest" && newRole === "admin") {
        yield this.logParticipantAction(
          "Role Claimed Coordinator",
          `Session ID: ${this._sessionId} upgraded`,
          "Coordinator"
        );
      }
      this._role = newRole;
    }));
    this.relay.events.on("NEW_PARTIAL_DECRYPTED").subscribe((e) => {
      const progress = this.getSignatureProgress();
      const threshold = this.getThreshold(this.getRoomState());
      this.relay.events.dispatch("SIGNATURE_RECEIVED", {
        fingerprint: e.payload?.fingerprint,
        signaturesReceived: progress.signaturesReceived,
        totalSigners: progress.totalSigners
      });
      if (this.isThresholdMet()) {
        this.relay.events.dispatch("THRESHOLD_MET", {
          signaturesReceived: progress.signaturesReceived,
          threshold
        });
      }
    });
  }
  /**
   * Returns a human-readable identifier for the current user's session and role.
   */
  get userContext() {
    return this._role === "admin" ? "Coordinator" : `Guest (${this._sessionId || "Unknown"})`;
  }
  /**
   * Provides an observable stream of room state changes for UI reactivity.
   */
  onStateChange() {
    return this.relay.events.on("STATE_CHANGED");
  }
  /**
   * Subscribes to specific room events triggered by network operations.
   * * @param eventType - The specific event type to listen to (e.g., 'SIGNATURE_RECEIVED')
   * @returns An RxJS Observable yielding the target events.
   */
  onEvent(eventType) {
    return this.relay.events.on(eventType);
  }
  /**
   * Retrieves the current, synchronized state of the room.
   */
  getRoomState() {
    return this.store.getState();
  }
  /**
   * Orchestrates the creation of a new collaborative cryptographic room.
   * @param psbtBase64 - The initial, unsigned PSBT string.
   * @param network - The target Bitcoin network (mainnet, testnet, or signet).
   * @param roomName - The display name for the room.
   * @returns The room's access credentials including the admin secret.
   */
  createRoom(psbtBase64, network, roomName = "Untitled Room") {
    return __async(this, null, function* () {
      const payload = yield RoomFactory.prepareCreationPayload(
        this.engine,
        psbtBase64,
        network,
        roomName,
        this.protocolVersion
      );
      this._encryptionKey = payload.localData.encryptionKey;
      const res = yield fetch(`${this.apiUrl}/api/room`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload.httpPayload)
      });
      if (!res.ok) throw new Error(`Failed to create room: ${yield res.text()}`);
      return payload;
    });
  }
  /**
   * Orchestrates the creation of a new collaborative cryptographic room and joins as coordinator.
   * @param psbtBase64 - The initial, unsigned PSBT string.
   * @param network - The target Bitcoin network (mainnet, testnet, or signet).
   * @param roomName - The display name for the room.
   * @returns The room's access credentials including the admin secret.
   */
  createRoomAndJoin(psbtBase64, network, roomName = "Untitled Room") {
    return __async(this, null, function* () {
      const payload = yield this.createRoom(psbtBase64, network, roomName);
      const connectionEvent = firstValueFrom(this.relay.events.on("ROOM_CONNECTED"));
      const sessionEvent = firstValueFrom(this.relay.events.on("SESSION_CONNECTED"));
      const wsUrl = this.apiUrl.replace(/^http/, "ws");
      this.store.init(payload.localData.roomId, this.protocolVersion);
      yield this.relay.joinRoom(
        wsUrl,
        payload.localData.roomId,
        payload.localData.encryptionKey,
        this.protocolVersion
      );
      yield connectionEvent;
      yield sessionEvent;
      yield this.logParticipantAction("User Joined", `Session: ${this._sessionId}`);
      const roleEvent = firstValueFrom(this.relay.events.on("ROLE_UPDATE"));
      this.relay.claimCoordinator(payload.httpPayload.adminToken);
      yield roleEvent;
      return {
        roomId: payload.localData.roomId,
        encryptionKey: payload.localData.encryptionKey,
        adminSecret: payload.localData.adminSecret,
        encryptedAdminToken: payload.httpPayload.adminToken
      };
    });
  }
  /**
   * Joins an existing room using its unique ID and encryption key.
   * @param roomId - Unique identifier for the room.
   * @param encryptionKey - The shared secret key for the room.
   */
  joinRoom(roomId, encryptionKey) {
    return __async(this, null, function* () {
      this._encryptionKey = encryptionKey;
      const connectionEvent = firstValueFrom(this.relay.events.on("ROOM_CONNECTED"));
      const sessionEvent = firstValueFrom(this.relay.events.on("SESSION_CONNECTED"));
      const wsUrl = this.apiUrl.replace(/^http/, "ws");
      this.store.init(roomId, this.protocolVersion);
      yield this.relay.joinRoom(wsUrl, roomId, encryptionKey, this.protocolVersion);
      yield connectionEvent;
      yield sessionEvent;
      yield this.logParticipantAction("User Joined", `Session: ${this._sessionId}`);
    });
  }
  /** * Updates the display name of the room.
   * @param name - The new room name.
   */
  setRoomName(name) {
    return __async(this, null, function* () {
      const confirmation = this.waitForEvent("ROOM_RENAMED_DECRYPTED");
      yield this.relay.renameRoom(name, this.userContext);
      yield confirmation;
    });
  }
  /** * Toggles the room's locked status to restrict participant access.
   * @param isLocked - Boolean toggle for room lock.
   */
  toggleLock(isLocked) {
    return __async(this, null, function* () {
      const confirmation = this.waitForEvent("LOCK_UPDATED");
      yield this.relay.toggleLock(isLocked, this.userContext);
      yield confirmation;
    });
  }
  /** * Uploads a partial signature to the room for the specified hardware wallet.
   * @param psbtBase64 - The partial PSBT payload.
   * @param fingerprint - The hardware device's master key fingerprint.
   */
  uploadSignature(psbtBase64, fingerprint) {
    return __async(this, null, function* () {
      const confirmation = this.waitForEvent("NEW_PARTIAL_DECRYPTED");
      yield this.relay.uploadSignature(psbtBase64, fingerprint, this.userContext);
      yield confirmation;
    });
  }
  /** * Records a secure audit trail event for the current room state.
   * @param action - Human-readable label of the action.
   * @param detail - Supplementary information about the action.
   * @param overrideRole - Optional role override for audit reporting.
   */
  logParticipantAction(action, detail, overrideRole) {
    return __async(this, null, function* () {
      const roleContext = overrideRole || this.userContext;
      const blob = yield this.relay.createSecureLogBlob(action, detail, roleContext);
      this.relay.send("LOG_ACTION", { encryptedLogBlob: blob });
    });
  }
  /** * Updates the display name for the current participant session.
   * @param name - The new display name.
   */
  setDisplayName(name) {
    return __async(this, null, function* () {
      const confirmation = this.waitForEvent("PARTICIPANTS_DECRYPTED");
      yield this.relay.setDisplayName(name);
      yield this.logParticipantAction("Participant Identified", `Identified as '${name}'`);
      yield confirmation;
    });
  }
  /** * Assigns a human-readable label to a hardware device fingerprint.
   * @param fingerprint - The master key fingerprint.
   * @param label - The label to apply.
   */
  setSignerLabel(fingerprint, label) {
    return __async(this, null, function* () {
      const confirmation = this.waitForEvent("LABELS_DECRYPTED");
      yield this.relay.updateSignerLabel(fingerprint, label, this.userContext);
      yield confirmation;
    });
  }
  /** * Closes the room session, ejecting all participants and wiping temporary relay state.
   * Only the Coordinator can execute this.
   */
  closeRoom() {
    return __async(this, null, function* () {
      const confirmation = this.waitForEvent("ROOM_CLOSED");
      this.relay.closeRoom();
      yield confirmation;
    });
  }
  /** * Generates a CSV-formatted export of the current audit trail.
   * @returns A CSV string containing the room's event history.
   */
  getAuditLogCsv() {
    const state = this.getRoomState();
    if (!state) return "";
    return RoomAuditor.getAuditLogCsvData(state);
  }
  getSettlementCsvData() {
    const state = this.getRoomState();
    const tx = this.getTxDetails(state);
    const signers = this.getSignersStatus(state);
    if (!state || !tx) return "";
    return RoomAuditor.getSettlementCsvData(state, tx, signers);
  }
  getAuditLogPdf(options) {
    return __async(this, null, function* () {
      const state = this.getRoomState();
      const tx = this.getTxDetails(state);
      const signers = this.getSignersStatus(state);
      const finalHex = this.getFinalTransactionHex();
      if (!state) throw new Error("No state available for audit report.");
      return yield RoomAuditor.generateAuditPdf(new jsPDF(), state, tx, signers, finalHex, options);
    });
  }
  /** * Updates the whitelist allowlist. Handles both single addresses and batches,
   * automatically formatting the audit log appropriately.
   * @param addresses - Array of addresses to add or remove.
   * @param remove - Toggle to either add (false) or remove (true) addresses.
   */
  updateWhitelist(addresses, remove = false) {
    return __async(this, null, function* () {
      if (!addresses || addresses.length === 0) return;
      const state = this.getRoomState();
      const currentList = state?.whitelist || [];
      let newList = [];
      if (remove) {
        newList = currentList.filter((a) => !addresses.includes(a));
      } else {
        newList = Array.from(/* @__PURE__ */ new Set([...currentList, ...addresses]));
      }
      if (currentList.length === newList.length) return;
      let detail = "";
      if (addresses.length === 1) {
        const address = addresses[0];
        const shortAddr = address.length > 5 ? address.slice(-5) : address;
        const actionWord = remove ? "Removed" : "Added";
        detail = `${actionWord} ...${shortAddr} to whitelist`;
      } else {
        const actionWord = remove ? "Removed" : "Verified";
        detail = `${actionWord} ${addresses.length} batch address(es)`;
      }
      const confirmation = this.waitForEvent("WHITELIST_DECRYPTED");
      yield this.relay.updateWhitelist(newList, detail, this.userContext);
      yield confirmation;
    });
  }
  /**
   * Finalizes the PSBT, updates local state, and automatically broadcasts
   * the finalized transaction to the room so all participants sync.
   * Guarantees the forensic audit log is sealed before resolving.
   * @returns A Promise resolving to the finalized hex and transaction ID, or null if the PSBT is invalid.
   */
  finalizeTransaction() {
    return __async(this, null, function* () {
      const state = this.getRoomState();
      if (!state) return null;
      const result = PsbtUtils.finalizeTx(state.psbt);
      if (result) {
        this.store.update((s) => __spreadProps(__spreadValues({}, s), { finalTxHex: result.hex, finalTxId: result.txId }));
        const confirmation = this.waitForState(
          (s) => s.auditLog.some((log) => log.event === "Tx Finalized")
        );
        yield this.relay.broadcastFinalization(result.hex, result.txId, this.userContext);
        yield confirmation;
      }
      return result;
    });
  }
  /** * Returns the finalized transaction hex if the threshold has been reached.
   */
  getFinalTransactionHex() {
    const state = this.store.getState();
    return state?.finalTxHex || null;
  }
  /** * Gracefully closes the connection to the relay server.
   */
  disconnect() {
    this.relay.gracefullyDisconnect(null);
  }
  /**
   * Returns the current progress of the signing ceremony.
   * Extracts the total hardware signers from the PSBT script and compares to received signatures.
   * @returns Signature progress metrics.
   */
  getSignatureProgress() {
    const state = this.getRoomState();
    if (!state || !state.psbt) return { totalSigners: 0, signaturesReceived: 0 };
    const analysis = PsbtUtils.analyze(state.psbt);
    return {
      totalSigners: analysis?.signerCount || 0,
      signaturesReceived: state.signatures.length
    };
  }
  /**
   * Dynamically evaluates if the aggregated PSBT has met the required script threshold.
   * @returns True if the transaction can be finalized.
   */
  isThresholdMet() {
    const state = this.getRoomState();
    if (!state || !state.psbt) return false;
    return PsbtUtils.finalizeTx(state.psbt) !== null;
  }
  /**
   * Calculates how many signatures are still required to finalize the transaction.
   * @param threshold The mathematical threshold of the script (e.g., 3 for a 3-of-5).
   * @returns The number of remaining signatures needed (minimum 0).
   */
  getSignaturesRemaining(threshold) {
    const state = this.getRoomState();
    if (!state) return threshold;
    const remaining = threshold - state.signatures.length;
    return Math.max(0, remaining);
  }
  /** * Returns full parsed transaction details (Inputs, Outputs, Fees).
   */
  getTransactionDetails() {
    const state = this.getRoomState();
    if (!state || !state.psbt) return null;
    return PsbtUtils.parseTxDetails(state.psbt, state.network);
  }
  /** Returns the list of outputs for the current PSBT. */
  getOutputs() {
    return this.getTransactionDetails()?.outputs || [];
  }
  /** Returns the list of inputs for the current PSBT. */
  getInputs() {
    return this.getTransactionDetails()?.inputsList || [];
  }
  /** Returns the calculated network fee for the current transaction in satoshis. */
  getNetworkFee() {
    return this.getTransactionDetails()?.fee || 0;
  }
  /** * Returns a list of all required hardware fingerprints for this transaction,
   * and a boolean indicating if their signature has been provided yet.
   */
  getSignersStatus(state) {
    if (!state || !state.psbt) return [];
    return PsbtUtils.extractSigners(state.psbt);
  }
  getTxDetails(state) {
    return state?.psbt ? PsbtUtils.parseTxDetails(state.psbt, state.network) : null;
  }
  getThreshold(state) {
    if (!state?.psbt) return 0;
    const threshold = PsbtUtils.getThreshold(state.psbt);
    return threshold > 0 ? threshold : this.getSignersStatus(state).length;
  }
  /**
   * Extracts the hardware fingerprint from a signed PSBT before uploading it to the room.
   * @param signedPsbtBase64 - The signed PSBT payload.
   */
  extractFingerprintFromSignature(signedPsbtBase64) {
    return PsbtUtils.getFingerprintFromPsbt(signedPsbtBase64);
  }
  /** * Internal helper to wait for a specific server response event before resolving.
   * @param eventType - The event key to listen for.
   */
  waitForEvent(eventType) {
    return new Promise((resolve) => {
      const sub = this.relay.events.on(eventType).subscribe(() => {
        sub.unsubscribe();
        resolve();
      });
    });
  }
  /**
   * Pauses execution until the RoomState satisfies a provided condition.
   * Excellent for UI transitions and integration testing.
   * @param condition A function that evaluates the current RoomState.
   * @param timeoutMs Max time to wait before rejecting (default 10s).
   */
  waitForState(condition, timeoutMs = 1e4) {
    return new Promise((resolve, reject) => {
      const currentState = this.getRoomState();
      if (currentState && condition(currentState)) return resolve();
      const timer = setTimeout(() => {
        sub.unsubscribe();
        reject(new Error("waitForState condition timed out"));
      }, timeoutMs);
      const sub = this.onStateChange().subscribe(() => {
        const state = this.getRoomState();
        if (state && condition(state)) {
          clearTimeout(timer);
          sub.unsubscribe();
          resolve();
        }
      });
    });
  }
  /** * Generates a sharing link for the room.
   * @param appBaseUrl The base URL of your web UI.
   * @param includeKey Whether to include the decryption key in the URL hash.
   */
  getRoomLink(appBaseUrl, includeKey = false) {
    const state = this.getRoomState();
    if (!state || !state.roomId) return "";
    let link = `${appBaseUrl.replace(/\/$/, "")}/room/${state.roomId}`;
    if (includeKey && this._encryptionKey) {
      link += `#${encodeURIComponent(this._encryptionKey)}`;
    }
    return link;
  }
  /**
   * Validates the forensic integrity of the room.
   * @param expectedAnchor The forensic anchor broadcasted at finalization.
   */
  verifyIntegrity(expectedAnchor) {
    return __async(this, null, function* () {
      const state = this.getRoomState();
      if (!state) throw new Error("No room state available to verify.");
      return yield RoomAuditor.verifyRoomIntegrity(state, expectedAnchor);
    });
  }
  /**
   * Helper to derive the room's forensic anchor from the current state.
   */
  getForensicAnchor() {
    return __async(this, null, function* () {
      const state = this.getRoomState();
      if (!state || !state.finalTxHex || !state.auditLog) {
        throw new Error("Cannot generate anchor: Room not finalized.");
      }
      return yield RoomAuditor.calculateForensicAnchor(state.auditLog, state.finalTxHex);
    });
  }
  /**
   * Retrieves a full cryptographic integrity report for the current room state.
   */
  getIntegrityReport() {
    return __async(this, null, function* () {
      const state = this.getRoomState();
      if (!state) throw new Error("No state");
      return yield RoomAuditor.getIntegrityReport(state);
    });
  }
  /**
   * Promotes the current session to Coordinator role using the admin secret.
   * This is used for session recovery after re-joining a room.
   */
  claimCoordinator(adminSecret) {
    return __async(this, null, function* () {
      if (this.store.getState() === null) {
        throw new Error("Must join room before claiming coordinator role.");
      }
      this.relay.send("AUTH", { token: adminSecret });
      yield this.waitForState((state) => {
        if (!this._sessionId || !state.participants) return false;
        return state.participants[this._sessionId]?.role === "admin";
      }, 15e3);
    });
  }
  parsePsbtFile(file) {
    return __async(this, null, function* () {
      const buffer = yield file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      const isBinary = bytes[0] === 112 && bytes[1] === 115 && bytes[2] === 98 && bytes[3] === 116 && bytes[4] === 255;
      const content = isBinary ? Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("") : new TextDecoder().decode(bytes).trim();
      if (content.startsWith("010000") || content.startsWith("020000")) {
        throw new Error("This looks like a Raw Transaction. Please export as PSBT from your wallet.");
      }
      return content;
    });
  }
  getErrorCategory(code) {
    if (code === 4026) return "PROTOCOL_MISMATCH";
    if (code === 4001) return "ROOM_FULL";
    if (code === 1006) return "AUTH_FAILED";
    return "UNKNOWN";
  }
};

// apps/client/src/app/services/ur/ur.service.ts
var ur_service_exports = {};
__export(ur_service_exports, {
  UrService: () => UrService
});
import { Injectable, signal } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import __vite__cjsImport12__ngraveio_bcUr from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@ngraveio_bc-ur.js?v=cf17c1b4";
import * as fflate from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/fflate.js?v=cf17c1b4";
import { hex as hex2, base64 as base642 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@scure_base.js?v=cf17c1b4";
import * as i0 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
var UrService = class _UrService {
  decoder = new URDecoder();
  scanProgress = signal(
    0,
    ...ngDevMode ? [{ debugName: "scanProgress" }] : (
      /* istanbul ignore next */
      []
    )
  );
  bbqrState = /* @__PURE__ */ new Map();
  bbqrTotal = 0;
  lastScannedText = signal(
    "Waiting for camera to lock on...",
    ...ngDevMode ? [{ debugName: "lastScannedText" }] : (
      /* istanbul ignore next */
      []
    )
  );
  scanError = signal(
    null,
    ...ngDevMode ? [{ debugName: "scanError" }] : (
      /* istanbul ignore next */
      []
    )
  );
  /**
   * EXHALE: Converts a Hex PSBT into an array of animated QR fragments
   */
  generateFrames(psbtBase64, maxFragmentLength = 150) {
    const cleanBase64 = psbtBase64.replace(/\s+/g, "");
    const psbtBytes = base642.decode(cleanBase64);
    const genericUr = UR.fromBuffer(Buffer.from(psbtBytes));
    const cborPayload = genericUr.cbor || genericUr._cbor || genericUr.cborMessage;
    if (!cborPayload) {
      console.error("Critical: Could not extract CBOR payload from UR", genericUr);
      return [];
    }
    const ur = new UR(cborPayload, "crypto-psbt");
    const encoder = new UREncoder(ur, maxFragmentLength);
    const frames = [];
    for (let i = 0; i < encoder.fragmentsLength * 2; i++) {
      frames.push(encoder.nextPart().toUpperCase());
    }
    return frames;
  }
  generateBBQrFrames(psbtBase64, charsPerFrame = 1e3) {
    const psbtBytes = base642.decode(psbtBase64.replace(/\s+/g, ""));
    const psbtHex = hex2.encode(psbtBytes).toUpperCase();
    const totalChunks = Math.ceil(psbtHex.length / charsPerFrame);
    if (totalChunks > 1295)
      throw new Error("PSBT too large for BBQr");
    const totalBase36 = totalChunks.toString(36).toUpperCase().padStart(2, "0");
    const frames = [];
    for (let i = 0; i < totalChunks; i++) {
      const currentBase36 = i.toString(36).toUpperCase().padStart(2, "0");
      const header = `B$HP${totalBase36}${currentBase36}`;
      const chunk = psbtHex.substring(i * charsPerFrame, (i + 1) * charsPerFrame);
      frames.push(header + chunk);
    }
    return frames;
  }
  /**
   * INHALE (OMNI-DECODER): Automatically detects and decodes UR, BBQr, or Static QRs.
   */
  processFragment(fragment) {
    if (!fragment || typeof fragment !== "string") {
      this.scanError.set("Invalid QR data received.");
      return null;
    }
    try {
      const upper = fragment.toUpperCase();
      this.lastScannedText.set(upper.length > 40 ? upper.substring(0, 40) + "..." : upper);
      this.scanError.set(null);
      if (upper.startsWith("UR:")) {
        this.decoder.receivePart(upper);
        const progress = this.decoder.estimatedPercentComplete();
        this.scanProgress.set(Math.max(progress, this.scanProgress()));
        if (this.decoder.isComplete()) {
          if (this.decoder.isSuccess()) {
            try {
              const resultUR = this.decoder.resultUR();
              const cborPayload = resultUR.cbor || resultUR._cbor || resultUR.cborMessage;
              if (cborPayload) {
                let hexData = hex2.encode(new Uint8Array(cborPayload)).toLowerCase();
                const magicIndex = hexData.indexOf("70736274ff");
                if (magicIndex !== -1) {
                  hexData = hexData.substring(magicIndex);
                }
                this.resetDecoder();
                return hexData;
              }
            } catch (e) {
              console.error("Failed to decode CBOR", e);
              this.scanError.set("UR decoded but payload extraction failed");
            }
          } else {
            this.scanError.set("UR checksum failed. Please rescan.");
            this.resetDecoder();
          }
        }
        return null;
      }
      if (upper.startsWith("B$")) {
        const encoding = upper[2];
        const totalStr = upper.substring(4, 6);
        const indexStr = upper.substring(6, 8);
        const payload = upper.substring(8);
        const total = parseInt(totalStr, 36);
        const index = parseInt(indexStr, 36);
        if (this.bbqrTotal === 0)
          this.bbqrTotal = total;
        if (!this.bbqrState.has(index)) {
          this.bbqrState.set(index, payload);
          this.scanProgress.set(this.bbqrState.size / this.bbqrTotal);
        }
        if (this.bbqrState.size === this.bbqrTotal) {
          let fullPayload = "";
          for (let i = 0; i < this.bbqrTotal; i++) {
            fullPayload += this.bbqrState.get(i);
          }
          if (encoding === "Z") {
            const compressed = this.decodeBase32(fullPayload);
            const decompressed = fflate.inflateSync(compressed);
            this.resetDecoder();
            return hex2.encode(decompressed);
          } else {
            this.resetDecoder();
            return fullPayload;
          }
        }
        return null;
      }
      this.resetDecoder();
      return fragment;
    } catch (e) {
      console.error("Omni-Decoder error:", e);
      this.scanError.set("Decoding failure. Check wallet settings.");
      return null;
    }
  }
  // --- Helper: Base32 Decoding (RFC 4648) for BBQr ---
  decodeBase32(s) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    const lookup = new Map([...alphabet].map((char, i) => [char, i]));
    const bits = s.split("").map((c) => lookup.get(c.toUpperCase()) ?? 0);
    const bytes = new Uint8Array(Math.floor(bits.length * 5 / 8));
    let bitBuffer = 0, bitCount = 0, byteIndex = 0;
    for (const b of bits) {
      bitBuffer = bitBuffer << 5 | b;
      bitCount += 5;
      if (bitCount >= 8) {
        bytes[byteIndex++] = bitBuffer >> bitCount - 8 & 255;
        bitCount -= 8;
      }
    }
    return bytes;
  }
  resetDecoder() {
    this.decoder = new URDecoder();
    this.bbqrState.clear();
    this.bbqrTotal = 0;
    this.scanProgress.set(0);
  }
  static \u0275fac = function UrService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _UrService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _UrService, factory: _UrService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(UrService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// apps/client/src/app/services/socket/socket.service.ts
var socket_service_exports = {};
__export(socket_service_exports, {
  PROTOCOL_VERSION: () => PROTOCOL_VERSION2,
  SocketService: () => SocketService
});
import { Injectable as Injectable3, Inject, PLATFORM_ID, signal as signal2, computed } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import { isPlatformBrowser } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_common.js?v=cf17c1b4";
import { Subject as Subject2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/rxjs.js?v=cf17c1b4";
import * as i03 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";

// apps/client/src/app/services/sdk-client-factory/sdk-client-factory.service.ts
import { Injectable as Injectable2 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i02 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
var PROTOCOL_VERSION = "1.0.0";
var SDKClientFactoryService = class _SDKClientFactoryService {
  /**
   * Creates a Signing Room SDK Client
   * @returns SigningRoomClient
   */
  create(config) {
    return new SigningRoomClient({
      apiUrl: config?.apiUrl ?? environment.apiUrl,
      protocolVersion: config?.protocolVersion ?? PROTOCOL_VERSION
    });
  }
  static \u0275fac = function SDKClientFactoryService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _SDKClientFactoryService)();
  };
  static \u0275prov = /* @__PURE__ */ i02.\u0275\u0275defineInjectable({ token: _SDKClientFactoryService, factory: _SDKClientFactoryService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(SDKClientFactoryService, [{
    type: Injectable2,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// apps/client/src/app/services/socket/socket.service.ts
var PROTOCOL_VERSION2 = "1.0.0";
var SocketService = class _SocketService {
  constructor(platformId, sdkFactory) {
    this.platformId = platformId;
    this.sdkFactory = sdkFactory;
    this.isBrowser = isPlatformBrowser(this.platformId);
    this.sdk = this.sdkFactory.create();
    this.relay = this.sdk.relay;
    this.store = this.sdk.store;
    this.encryptionEngine = this.sdk.engine;
    this.registerEventlisteners();
  }
  platformId;
  sdkFactory;
  sdk;
  store;
  relay;
  encryptionEngine;
  hasAnnouncedJoin = false;
  securityAlert$ = new Subject2();
  fallbackVersion = null;
  failedKeyAttempts = 0;
  encryptionKey = null;
  isBrowser;
  registerEventlisteners() {
    this.sdk.onStateChange().subscribe((state) => {
      this.roomState.set(this.sdk.getRoomState());
    });
    this.relay.events.on("ROOM_CONNECTED").subscribe(() => {
      this.status.set("connected");
    });
    this.relay.events.on("SESSION_CONNECTED").subscribe((e) => this.currentSessionId.set(e.payload));
    this.relay.events.on("ROOM_DISCONNECTED").subscribe((event) => {
      this.status.set("disconnected");
      if (!this.isClosed()) {
        setTimeout(() => {
          const hasTerminalError = this.roomNotFound() || this.isLockedOut() || this.isRoomFull() || this.decryptionError() !== null;
          if (this.status() === "disconnected" && !hasTerminalError) {
            this.connect(this.roomState()?.roomId || "", this.getRoomKey());
          }
        }, 3e3);
      }
    });
    this.relay.events.on("LABELS_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { signerLabels: e.payload }) : null);
    });
    this.relay.events.on("ROOM_RENAMED_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { roomName: e.payload }) : null);
    });
    this.relay.events.on("LOG_UPDATE_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { auditLog: e.payload }) : null);
    });
    this.relay.events.on("CONNECTIONS_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { connectedCount: e.payload.count }) : null);
      this.activeSessions.set(e.payload.sessions);
    });
    this.relay.events.on("WHITELIST_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { whitelist: e.payload }) : null);
    });
    this.relay.events.on("PARTICIPANTS_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { participants: e.payload }) : null);
    });
    this.relay.events.on("LOCK_UPDATED").subscribe((e) => {
      const payload = e.payload || {};
      const isLocked = payload.isLocked !== void 0 ? payload.isLocked : true;
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { isLocked }) : null);
    });
    this.relay.events.on("TOGGLE_LOCK").subscribe((e) => {
      const isLocked = e.payload?.isLocked !== void 0 ? e.payload.isLocked : true;
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { isLocked }) : null);
    });
    this.relay.events.on("TX_FINALIZED_DECRYPTED").subscribe((e) => {
      this.store.update((s) => s ? __spreadProps(__spreadValues({}, s), { finalTxHex: e.payload.finalTxHex, finalTxId: e.payload.finalTxId }) : null);
    });
    this.relay.events.on("ROOM_CLOSED").subscribe(() => {
      this.isClosed.set(true);
      const roomToClear = this.roomState()?.roomId;
      if (roomToClear)
        this.clearLocalRoomData(roomToClear);
      this.disconnect();
    });
    this.relay.events.on("PROTOCOL_ERROR").subscribe((e) => {
      const errorType = e.payload.type;
      if (errorType === "locked") {
        this.isLockedOut.set(true);
        this.disconnect();
      } else if (errorType === "not_found") {
        this.roomNotFound.set(true);
        this.disconnect();
      } else if (errorType === "version_mismatch") {
        this.fallbackVersion = e.payload.roomVersion;
      } else if (errorType === "room_full") {
        this.isRoomFull.set(true);
      } else if (errorType === "access_denied") {
        if (!this.hasAnnouncedJoin) {
          this.decryptionError.set("Invalid decryption key. Access denied.");
          this.setRoomKey(null);
          this.failedKeyAttempts++;
          this.securityAlert$.next({ type: "access_denied", count: this.failedKeyAttempts });
        }
      }
    });
    this.relay.events.on("DECRYPTION_ERROR").subscribe((e) => {
      if (!this.isLockedOut() && !this.isRoomFull() && !this.roomNotFound()) {
        this.decryptionError.set(e.payload);
        this.setRoomKey(null);
        this.disconnect();
      }
    });
    this.relay.events.on("STATE_CHANGED").subscribe((e) => {
      this.roomState.set(e.payload);
    });
    this.relay.events.on("STATE_SYNC_DECRYPTED").subscribe((event) => {
      const syncData = event.payload;
      const hasAdminToken = !!sessionStorage.getItem(`admin_token_${syncData.roomId}`);
      if (!this.hasAnnouncedJoin && this.currentSessionId() && !hasAdminToken) {
        this.hasAnnouncedJoin = true;
      }
    });
    this.relay.events.on("NEW_PARTIAL_DECRYPTED").subscribe((event) => {
      const { decryptedPsbt, fingerprint, sessionId } = event.payload;
      this.store.update((current) => {
        if (!current)
          return null;
        return __spreadProps(__spreadValues({}, current), {
          psbt: this.mergePsbts(current.psbt, decryptedPsbt),
          signatures: [...current.signatures, decryptedPsbt]
        });
      });
      if (fingerprint && sessionId) {
        this.networkSignatureReceived$.next({ fingerprint, sessionId });
      }
    });
    this.relay.events.on("ROLE_UPDATE").subscribe((e) => {
      const newRole = e.payload;
      this.role.set(newRole);
      if (!this.hasAnnouncedJoin && newRole === "admin") {
        this.hasAnnouncedJoin = true;
      }
    });
  }
  setRoomKey(key) {
    this.encryptionKey = key;
  }
  getRoomKey() {
    return this.encryptionKey;
  }
  connect(roomId, key) {
    return __async(this, null, function* () {
      if (this.status() === "connecting")
        return;
      this.reset();
      this.status.set("connecting");
      try {
        if (!key)
          throw new Error("Decryption key required");
        if (this.sdk.store.getState() !== null) {
          this.sdk.disconnect();
          yield new Promise((r) => setTimeout(r, 50));
        }
        yield this.sdk.joinRoom(roomId, key);
        if (this.isBrowser) {
          const secureToken = sessionStorage.getItem(`admin_token_${roomId}`);
          if (secureToken) {
            try {
              const decryptedToken = yield this.encryptionEngine.decrypt(secureToken, key);
              if (decryptedToken) {
                yield this.sdk.claimCoordinator(decryptedToken);
              }
            } catch (decryptError) {
              console.warn("Failed to decrypt local admin token. Proceeding as guest.");
              sessionStorage.removeItem(`admin_token_${roomId}`);
            }
          }
          const savedName = localStorage.getItem(`display_name_${roomId}`);
          if (savedName) {
            yield this.sdk.setDisplayName(savedName);
          }
        }
        this.status.set("connected");
      } catch (e) {
        console.error("Connection/Upgrade failed:", e);
        this.status.set("error");
      }
    });
  }
  disconnect() {
    this.sdk.disconnect();
    this.status.set("disconnected");
  }
  createRoom(psbtBase64, network, roomName = "Untitled Room") {
    return __async(this, null, function* () {
      return yield this.sdk.createRoom(psbtBase64, network, roomName);
    });
  }
  renameRoom(name) {
    return __async(this, null, function* () {
      yield this.sdk.setRoomName(name);
    });
  }
  closeRoom() {
    return __async(this, null, function* () {
      yield this.sdk.closeRoom();
      const state = this.sdk.getRoomState();
      if (state) {
        sessionStorage.removeItem(`admin_token_${state.roomId}`);
        localStorage.removeItem(`display_name_${state.roomId}`);
      }
    });
  }
  setDisplayName(name) {
    return __async(this, null, function* () {
      const state = this.sdk.getRoomState();
      if (state)
        localStorage.setItem(`display_name_${state.roomId}`, name);
      yield this.sdk.setDisplayName(name);
    });
  }
  toggleLock(isLocked) {
    return __async(this, null, function* () {
      yield this.sdk.toggleLock(isLocked);
    });
  }
  updateWhitelist(addresses, remove = false) {
    return __async(this, null, function* () {
      yield this.sdk.updateWhitelist(addresses, remove);
    });
  }
  claimCoordinator(secureToken) {
    return __async(this, null, function* () {
      this.sdk.claimCoordinator(secureToken);
    });
  }
  getRoomLink(appBaseUrl, includeKey = false) {
    return this.sdk.getRoomLink(appBaseUrl, includeKey);
  }
  logAction(action, detail) {
    return __async(this, null, function* () {
      console.log("=== logAction CALLED ===", action, detail);
      yield this.sdk.logParticipantAction(action, detail);
    });
  }
  getAuditLogCsv() {
    return this.sdk.getAuditLogCsv();
  }
  getSettlementCsvData() {
    return this.sdk.getSettlementCsvData();
  }
  getAuditLogPdf(options) {
    return __async(this, null, function* () {
      return yield this.sdk.getAuditLogPdf(options);
    });
  }
  getLocalLabel(fingerprint) {
    return localStorage.getItem(`addr_book_${fingerprint}`);
  }
  saveToAddressBook(fingerprint, label) {
    localStorage.setItem(`addr_book_${fingerprint}`, label);
  }
  removeFromAddressBook(fingerprint) {
    localStorage.removeItem(`addr_book_${fingerprint}`);
  }
  updateSignerLabel(fingerprint, label) {
    return __async(this, null, function* () {
      const state = this.sdk.getRoomState();
      if (state)
        localStorage.setItem(`signer_label_${state.roomId}_${fingerprint}`, label);
      yield this.sdk.setSignerLabel(fingerprint, label);
    });
  }
  checkAndApplyLocalLabels() {
    if (!this.isCoordinator())
      return;
    const state = this.roomState();
    if (!state)
      return;
    const currentLabels = state.signerLabels || {};
    const signers = this.signers();
    signers.forEach((signer) => {
      if (currentLabels[signer.fingerprint] === void 0) {
        const savedName = this.getLocalLabel(signer.fingerprint);
        if (savedName)
          this.updateSignerLabel(signer.fingerprint, savedName);
      }
    });
  }
  uploadSignature(psbtBase64) {
    return __async(this, null, function* () {
      const fingerprint = this.sdk.extractFingerprintFromSignature(psbtBase64);
      if (!fingerprint)
        throw new Error("Could not extract fingerprint from PSBT");
      yield this.sdk.uploadSignature(psbtBase64, fingerprint);
    });
  }
  getFinalTxHex() {
    if (this.role() !== "admin")
      return null;
    const state = this.roomState();
    if (!state?.psbt)
      return null;
    return PsbtUtils.finalizeTx(state.psbt)?.hex || null;
  }
  getFinalTxId() {
    if (this.role() !== "admin")
      return null;
    const state = this.roomState();
    if (!state?.psbt)
      return null;
    return PsbtUtils.finalizeTx(state.psbt)?.txId || null;
  }
  mergePsbts(base, next) {
    return PsbtUtils.merge(base, next);
  }
  getThreshold(psbtBase64) {
    return PsbtUtils.getThreshold(psbtBase64);
  }
  finalizeTransaction() {
    return __async(this, null, function* () {
      return yield this.sdk.finalizeTransaction();
    });
  }
  reset() {
    this.role.set("guest");
    this.isClosed.set(false);
    this.decryptionError.set(null);
    this.isLockedOut.set(false);
    this.isRoomFull.set(false);
    this.roomNotFound.set(false);
    this.activeSessions.set([]);
    this.status.set("disconnected");
  }
  clearLocalRoomData(roomId) {
    localStorage.removeItem(`display_name_${roomId}`);
    sessionStorage.removeItem(`admin_token_${roomId}`);
  }
  roomState = signal2(
    null,
    ...ngDevMode ? [{ debugName: "roomState" }] : (
      /* istanbul ignore next */
      []
    )
  );
  status = signal2(
    "disconnected",
    ...ngDevMode ? [{ debugName: "status" }] : (
      /* istanbul ignore next */
      []
    )
  );
  role = signal2(
    "guest",
    ...ngDevMode ? [{ debugName: "role" }] : (
      /* istanbul ignore next */
      []
    )
  );
  currentSessionId = signal2(
    null,
    ...ngDevMode ? [{ debugName: "currentSessionId" }] : (
      /* istanbul ignore next */
      []
    )
  );
  activeSessions = signal2(
    [],
    ...ngDevMode ? [{ debugName: "activeSessions" }] : (
      /* istanbul ignore next */
      []
    )
  );
  networkSignatureReceived$ = new Subject2();
  isRoomFull = signal2(
    false,
    ...ngDevMode ? [{ debugName: "isRoomFull" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isClosed = signal2(
    false,
    ...ngDevMode ? [{ debugName: "isClosed" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isLockedOut = signal2(
    false,
    ...ngDevMode ? [{ debugName: "isLockedOut" }] : (
      /* istanbul ignore next */
      []
    )
  );
  roomNotFound = signal2(
    false,
    ...ngDevMode ? [{ debugName: "roomNotFound" }] : (
      /* istanbul ignore next */
      []
    )
  );
  decryptionError = signal2(
    null,
    ...ngDevMode ? [{ debugName: "decryptionError" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isCoordinator = computed(
    () => this.role() === "admin",
    ...ngDevMode ? [{ debugName: "isCoordinator" }] : (
      /* istanbul ignore next */
      []
    )
  );
  signers = computed(
    () => {
      const state = this.roomState();
      return this.sdk.getSignersStatus(state);
    },
    ...ngDevMode ? [{ debugName: "signers" }] : (
      /* istanbul ignore next */
      []
    )
  );
  txDetails = computed(
    () => {
      const state = this.roomState();
      return this.sdk.getTxDetails(state);
    },
    ...ngDevMode ? [{ debugName: "txDetails" }] : (
      /* istanbul ignore next */
      []
    )
  );
  signerThreshold = computed(
    () => {
      const state = this.roomState();
      return this.sdk.getThreshold(state);
    },
    ...ngDevMode ? [{ debugName: "signerThreshold" }] : (
      /* istanbul ignore next */
      []
    )
  );
  signerCount = computed(
    () => this.signers().filter((signer) => signer.signed).length,
    ...ngDevMode ? [{ debugName: "signerCount" }] : (
      /* istanbul ignore next */
      []
    )
  );
  isReadyToBroadcast = computed(
    () => this.signerCount() >= this.signerThreshold(),
    ...ngDevMode ? [{ debugName: "isReadyToBroadcast" }] : (
      /* istanbul ignore next */
      []
    )
  );
  static \u0275fac = function SocketService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _SocketService)(i03.\u0275\u0275inject(PLATFORM_ID), i03.\u0275\u0275inject(SDKClientFactoryService));
  };
  static \u0275prov = /* @__PURE__ */ i03.\u0275\u0275defineInjectable({ token: _SocketService, factory: _SocketService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassMetadata(SocketService, [{
    type: Injectable3,
    args: [{ providedIn: "root" }]
  }], () => [{ type: Object, decorators: [{
    type: Inject,
    args: [PLATFORM_ID]
  }] }, { type: SDKClientFactoryService }], null);
})();

// apps/client/src/app/services/widget-dispatcher/widget-dispatcher.service.ts
var widget_dispatcher_service_exports = {};
__export(widget_dispatcher_service_exports, {
  WidgetDispatcherService: () => WidgetDispatcherService
});
import { Injectable as Injectable4 } from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
import * as i04 from "/@fs/C:/Users/seanc/Projects/signingroom/.angular/cache/22.1.4/client/vite/deps/@angular_core.js?v=cf17c1b4";
var WidgetDispatcherService = class _WidgetDispatcherService {
  constructor(socket) {
    this.socket = socket;
  }
  socket;
  /**
   * Securely checks if the application is running inside an iframe.
   */
  get isEmbedded() {
    try {
      return window !== window.top;
    } catch (e) {
      return true;
    }
  }
  targetOrigin = typeof window !== "undefined" ? window.location.origin : "";
  /**
   * Sets the strict origin for all outgoing window.postMessage events.
   */
  setTargetOrigin(origin) {
    this.targetOrigin = origin;
  }
  /**
   * Helper to return current state of room
   */
  getBaseContext() {
    const state = this.socket.roomState();
    return {
      roomId: state?.roomId || null,
      sessionId: this.socket.currentSessionId() || null,
      role: this.socket.isCoordinator() ? "coordinator" : state ? "guest" : "unknown",
      network: state?.network || null,
      timestamp: Date.now()
    };
  }
  /**
   * Core dispatcher that emits events to the parent window (signing room) with a consistent structure. All widget events should funnel through this method.
   */
  dispatchEvent(action, payload) {
    if (!this.isEmbedded) {
      return;
    }
    if (window && window.parent) {
      const enrichedPayload = __spreadValues(__spreadValues({}, this.getBaseContext()), payload);
      window.parent.postMessage({
        type: "SIGNING_ROOM_EVENT",
        action,
        payload: enrichedPayload
      }, this.targetOrigin);
    }
  }
  // --- PRIVACY TOGGLES ---
  emitModalView(modalName, context) {
    const payload = { modalName, context };
    this.dispatchEvent("modalViewed", payload);
  }
  emitPrivacyToggle(section, state) {
    const payload = { section, state };
    this.dispatchEvent("privacyToggled", payload);
  }
  // --- ROOM OVERVIEW & ACTIONS ---
  emitRoomRenamed(newName) {
    const payload = { newName };
    this.dispatchEvent("roomRenamed", payload);
  }
  emitDataCopied(dataType) {
    const payload = { dataType };
    this.dispatchEvent("dataCopied", payload);
  }
  emitDownloadTriggered(fileType) {
    const payload = { fileType };
    this.dispatchEvent("downloadTriggered", payload);
  }
  emitRoomStateChanged(state) {
    const payload = { state };
    this.dispatchEvent("roomStateChanged", payload);
  }
  emitQrStateChanged(includesKey, isRevealed) {
    const payload = { includesKey, isRevealed };
    this.dispatchEvent("qrStateChanged", payload);
  }
  // --- SIGNER ACTIONS & TRANSACTION DETAILS ---
  emitFountainFormatChanged(format) {
    this.dispatchEvent("fountainFormatChanged", { format });
  }
  emitFountainStateChanged(isRevealed, format) {
    this.dispatchEvent("fountainStateChanged", { isRevealed, format });
  }
  emitPsbtImported(method) {
    this.dispatchEvent("psbtImported", { method });
  }
  emitTransactionViewChanged(view) {
    this.dispatchEvent("transactionViewChanged", { view });
  }
  emitDestinationVerified(type, address, isVerified) {
    this.dispatchEvent("destinationVerified", { type, address, isVerified });
  }
  emitAddressCopied(address) {
    this.dispatchEvent("addressCopied", { address });
  }
  emitRoomCreated(roomId, network) {
    this.dispatchEvent("roomCreated", { roomId, network });
  }
  // --- TRANSACTION FINALIZATION ---
  emitTransactionFinalized(payload) {
    this.dispatchEvent("transactionFinalized", payload);
  }
  // --- PARTICIPANT PRESENCE ---
  emitParticipantPresence(action, participantId, participantRole, displayName) {
    this.dispatchEvent("participantPresence", {
      action,
      participantId,
      participantRole,
      displayName
    });
  }
  // --- SIGNATURES ---
  emitSignatureReceived(fingerprint, signerLabel, signerSessionId, signerName) {
    this.dispatchEvent("signatureReceived", {
      fingerprint,
      signerLabel,
      signerSessionId,
      signerName
    });
  }
  emitParticipantLabelled(target, label, fingerprint, participantId) {
    this.dispatchEvent("participantLabelled", { target, label, fingerprint, participantId });
  }
  emitSecurityAlert(alertType, severity, message) {
    this.dispatchEvent("securityAlert", { alertType, severity, message });
  }
  static \u0275fac = function WidgetDispatcherService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _WidgetDispatcherService)(i04.\u0275\u0275inject(SocketService));
  };
  static \u0275prov = /* @__PURE__ */ i04.\u0275\u0275defineInjectable({ token: _WidgetDispatcherService, factory: _WidgetDispatcherService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassMetadata(WidgetDispatcherService, [{
    type: Injectable4,
    args: [{
      providedIn: "root"
    }]
  }], () => [{ type: SocketService }], null);
})();

export {
  EncryptionEngine,
  PsbtUtils,
  src_exports,
  UrService,
  ur_service_exports,
  SocketService,
  socket_service_exports,
  WidgetDispatcherService,
  widget_dispatcher_service_exports
};
//# debugId=3cd42a7b-e807-56b0-9b53-a186a388b403
//# sourceMappingURL=chunk-2GVOWOPG.js.map

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpYnMvc2RrL3NyYy9saWIvY3J5cHRvL2VuY3J5cHRpb24tZW5naW5lLnRzIiwibGlicy9zZGsvc3JjL2xpYi9iaXRjb2luL3BzYnQtdXRpbHMudHMiLCJsaWJzL3Nkay9zcmMvaW5kZXgudHMiLCJsaWJzL3Nkay9zcmMvbGliL2V2ZW50cy9yb29tLWV2ZW50LWJ1cy50cyIsImxpYnMvc2RrL3NyYy9saWIvcmVsYXkvcmVsYXktY2xpZW50LnRzIiwibGlicy9zZGsvc3JjL2xpYi9yZWxheS9yb29tLXN0YXRlLXN0b3JlLnRzIiwibGlicy9zZGsvc3JjL2xpYi9yZWxheS9yb29tLWZhY3RvcnkudHMiLCJsaWJzL3Nkay9zcmMvbGliL2JpdGNvaW4vcm9vbS1hdWRpdG9yLnRzIiwibGlicy9zZGsvc3JjL2xpYi9zaWduaW5nLXJvb20tY2xpZW50LnRzIiwiYXBwcy9jbGllbnQvc3JjL2FwcC9zZXJ2aWNlcy91ci91ci5zZXJ2aWNlLnRzIiwiYXBwcy9jbGllbnQvc3JjL2FwcC9zZXJ2aWNlcy9zb2NrZXQvc29ja2V0LnNlcnZpY2UudHMiLCJhcHBzL2NsaWVudC9zcmMvYXBwL3NlcnZpY2VzL3Nkay1jbGllbnQtZmFjdG9yeS9zZGstY2xpZW50LWZhY3Rvcnkuc2VydmljZS50cyIsImFwcHMvY2xpZW50L3NyYy9hcHAvc2VydmljZXMvd2lkZ2V0LWRpc3BhdGNoZXIvd2lkZ2V0LWRpc3BhdGNoZXIuc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogVXRpbGl0eSBlbmdpbmUgcHJvdmlkaW5nIGhpZ2gtbGV2ZWwgY3J5cHRvZ3JhcGhpYyBvcGVyYXRpb25zIGluY2x1ZGluZ1xyXG4gKiBzeW1tZXRyaWNhbCBlbmNyeXB0aW9uLCBkZWNyeXB0aW9uLCBrZXkgZ2VuZXJhdGlvbiwgYW5kIGRldGVybWluaXN0aWMgZGF0YSBibGluZGluZy5cclxuICogTmF0aXZlIHdlYiBjcnlwdG8gQVBJcyBhcmUgYWJzdHJhY3RlZCB0byBzYWZlbHkgZmFsbCBiYWNrIGJldHdlZW4gQnJvd3NlciBhbmQgTm9kZS5qcyBydW50aW1lcy5cclxuICovXHJcbmV4cG9ydCBjbGFzcyBFbmNyeXB0aW9uRW5naW5lIHtcclxuICAvKipcclxuICAgKiBTYWZlbHkgcmV0cmlldmVzIHRoZSBjcnlwdG9ncmFwaGljIFN1YnRsZUNyeXB0byBBUEkgYWNyb3NzIGdsb2JhbCBjb250ZXh0cy5cclxuICAgKiBAcmV0dXJucyBUaGUgYWN0aXZlIGVudmlyb25tZW50J3MgU3VidGxlQ3J5cHRvIGluc3RhbmNlLlxyXG4gICAqIEB0aHJvd3Mge0Vycm9yfSBJZiBXZWJDcnlwdG8gb3IgaXRzIFN1YnRsZSBwcm9wZXJ0eSBpcyB1bnN1cHBvcnRlZCBpbiB0aGUgaG9zdCBlbnZpcm9ubWVudC5cclxuICAgKi9cclxuICBwcml2YXRlIGdldENyeXB0bygpIHtcclxuICAgIGNvbnN0IGMgPVxyXG4gICAgICAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmNyeXB0bykgfHxcclxuICAgICAgKHR5cGVvZiBnbG9iYWwgIT09ICd1bmRlZmluZWQnICYmIChnbG9iYWwgYXMgYW55KS5jcnlwdG8pO1xyXG4gICAgaWYgKCFjIHx8ICFjLnN1YnRsZSkgdGhyb3cgbmV3IEVycm9yKCdXZWJDcnlwdG8gbm90IHN1cHBvcnRlZCcpO1xyXG4gICAgcmV0dXJuIGMuc3VidGxlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRmlsbHMgYSBnaXZlbiBVaW50OEFycmF5IHdpdGggY3J5cHRvZ3JhcGhpY2FsbHkgc3Ryb25nIHBzZXVkby1yYW5kb20gdmFsdWVzLlxyXG4gICAqIEBwYXJhbSBhcnJheSAtIFRoZSBkZXN0aW5hdGlvbiBhcnJheSB0byBwb3B1bGF0ZSB3aXRoIHJhbmRvbSBieXRlcy5cclxuICAgKiBAcmV0dXJucyBUaGUgc2FtZSBwb3B1bGF0ZWQgVWludDhBcnJheSBpbnN0YW5jZS5cclxuICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgYSByZWxpYWJsZSBjcnlwdG9ncmFwaGljYWxseSBzZWN1cmUgcmFuZG9tIG51bWJlciBnZW5lcmF0b3IgaXMgdW5hdmFpbGFibGUuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBnZXRSYW5kb21WYWx1ZXMoYXJyYXk6IFVpbnQ4QXJyYXkpIHtcclxuICAgIGNvbnN0IGMgPVxyXG4gICAgICAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LmNyeXB0bykgfHxcclxuICAgICAgKHR5cGVvZiBnbG9iYWwgIT09ICd1bmRlZmluZWQnICYmIChnbG9iYWwgYXMgYW55KS5jcnlwdG8pO1xyXG4gICAgaWYgKCFjIHx8ICFjLmdldFJhbmRvbVZhbHVlcykgdGhyb3cgbmV3IEVycm9yKCdDcnlwdG8gbm90IHN1cHBvcnRlZCcpO1xyXG4gICAgcmV0dXJuIGMuZ2V0UmFuZG9tVmFsdWVzKGFycmF5KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnZlcnRzIGEgYmluYXJ5IEFycmF5QnVmZmVyIHRvIGEgc3RhbmRhcmQgQmFzZTY0IHN0cmluZyByZXByZXNlbnRhdGlvbi5cclxuICAgKiBAcGFyYW0gYnVmZmVyIC0gVGhlIHJhdyBiaW5hcnkgZGF0YSBidWZmZXIuXHJcbiAgICogQHJldHVybnMgQSBiYXNlNjQtZW5jb2RlZCBzdHJpbmcuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBidWYyYmFzZTY0KGJ1ZmZlcjogQXJyYXlCdWZmZXIpOiBzdHJpbmcge1xyXG4gICAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgIHJldHVybiBCdWZmZXIuZnJvbShidWZmZXIpLnRvU3RyaW5nKCdiYXNlNjQnKTtcclxuICAgIH1cclxuICAgIHJldHVybiBidG9hKFN0cmluZy5mcm9tQ2hhckNvZGUoLi4ubmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSkpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGVjb2RlcyBhIHN0YW5kYXJkIEJhc2U2NCBzdHJpbmcgYmFjayBpbnRvIGJpbmFyeSBieXRlIGZvcm1hdC5cclxuICAgKiBAcGFyYW0gYmFzZTY0U3RyIC0gVGhlIGJhc2U2NC1lbmNvZGVkIHN0cmluZy5cclxuICAgKiBAcmV0dXJucyBBIFVpbnQ4QXJyYXkgY29udGFpbmluZyB0aGUgcmF3IGJpbmFyeSBieXRlcy5cclxuICAgKi9cclxuICBwcml2YXRlIGJhc2U2NDJidWYoYmFzZTY0U3RyOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcclxuICAgIGlmICh0eXBlb2YgQnVmZmVyICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoQnVmZmVyLmZyb20oYmFzZTY0U3RyLCAnYmFzZTY0JykpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIFVpbnQ4QXJyYXkuZnJvbShhdG9iKGJhc2U2NFN0ciksIChjKSA9PiBjLmNoYXJDb2RlQXQoMCkpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2VuZXJhdGVzIGEgYnJhbmQgbmV3LCByYW5kb20gMjU2LWJpdCBBRVMtR0NNIHN5bW1ldHJpYyBrZXkuXHJcbiAgICogQHJldHVybnMgQSBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgdG8gdGhlIHJhdyBleHBvcnRlZCBrZXkgZW5jb2RlZCBpbiBCYXNlNjQgZm9ybWF0ICg0NCBjaGFyYWN0ZXJzKS5cclxuICAgKi9cclxuICBhc3luYyBnZW5lcmF0ZUtleSgpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gICAgY29uc3QgY3J5cHRvU3VidGxlID0gdGhpcy5nZXRDcnlwdG8oKTtcclxuICAgIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0b1N1YnRsZS5nZW5lcmF0ZUtleSh7IG5hbWU6ICdBRVMtR0NNJywgbGVuZ3RoOiAyNTYgfSwgdHJ1ZSwgW1xyXG4gICAgICAnZW5jcnlwdCcsXHJcbiAgICAgICdkZWNyeXB0JyxcclxuICAgIF0pO1xyXG4gICAgY29uc3QgZXhwb3J0ZWQgPSBhd2FpdCBjcnlwdG9TdWJ0bGUuZXhwb3J0S2V5KCdyYXcnLCBrZXkpO1xyXG4gICAgcmV0dXJuIHRoaXMuYnVmMmJhc2U2NChleHBvcnRlZCBhcyBBcnJheUJ1ZmZlcik7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBFbmNyeXB0cyBwbGFpbiB0ZXh0IHN0cmluZyBkYXRhIHVzaW5nIGF1dGhlbnRpY2F0ZWQgMjU2LWJpdCBBRVMtR0NNIGVuY3J5cHRpb24uXHJcbiAgICogQHBhcmFtIGRhdGEgLSBUaGUgc3RyaW5nIG1lc3NhZ2UgY29udGVudCB0byBlbmNyeXB0LlxyXG4gICAqIEBwYXJhbSBrZXkgLSBUaGUgYmFzZTY0LWVuY29kZWQgMjU2LWJpdCBzZWNyZXQga2V5LlxyXG4gICAqIEByZXR1cm5zIEEgUHJvbWlzZSByZXNvbHZpbmcgdG8gYSBzaW5nbGUgQmFzZTY0IHN0cmluZyBjb250YWluaW5nIGJvdGggdGhlIDEyLWJ5dGUgcmFuZG9tIEluaXRpYWxpemF0aW9uIFZlY3RvciAoSVYpIGFuZCB0aGUgZW5jcnlwdGVkIGNpcGhlcnRleHQgcGF5bG9hZC5cclxuICAgKi9cclxuICBhc3luYyBlbmNyeXB0KGRhdGE6IHN0cmluZywga2V5OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gICAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xyXG4gICAgY29uc3QgcmF3S2V5ID0gdGhpcy5iYXNlNjQyYnVmKGtleSk7XHJcbiAgICBjb25zdCBjcnlwdG9TdWJ0bGUgPSB0aGlzLmdldENyeXB0bygpO1xyXG5cclxuICAgIGNvbnN0IGtleUJ1ZmZlciA9IGF3YWl0IGNyeXB0b1N1YnRsZS5pbXBvcnRLZXkoJ3JhdycsIHJhd0tleSwgeyBuYW1lOiAnQUVTLUdDTScgfSwgdHJ1ZSwgW1xyXG4gICAgICAnZW5jcnlwdCcsXHJcbiAgICAgICdkZWNyeXB0JyxcclxuICAgIF0pO1xyXG5cclxuICAgIGNvbnN0IGl2ID0gdGhpcy5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcclxuICAgIGNvbnN0IGVuY3J5cHRlZERhdGEgPSBhd2FpdCBjcnlwdG9TdWJ0bGUuZW5jcnlwdChcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2IH0sXHJcbiAgICAgIGtleUJ1ZmZlcixcclxuICAgICAgZW5jb2Rlci5lbmNvZGUoZGF0YSksXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBVaW50OEFycmF5KGl2Lmxlbmd0aCArIGVuY3J5cHRlZERhdGEuYnl0ZUxlbmd0aCk7XHJcbiAgICByZXN1bHQuc2V0KGl2KTtcclxuICAgIHJlc3VsdC5zZXQobmV3IFVpbnQ4QXJyYXkoZW5jcnlwdGVkRGF0YSksIGl2Lmxlbmd0aCk7XHJcbiAgICByZXR1cm4gdGhpcy5idWYyYmFzZTY0KHJlc3VsdC5idWZmZXIpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGVjcnlwdHMgYSBjb21iaW5lZCBJViBhbmQgY2lwaGVydGV4dCBwYXlsb2FkIHVzaW5nIDI1Ni1iaXQgQUVTLUdDTS5cclxuICAgKiBAcGFyYW0gZW5jcnlwdGVkRGF0YSAtIFRoZSBiYXNlNjQgc3RyaW5nIGNvbWJpbmluZyB0aGUgMTItYnl0ZSBJViBhbmQgdGhlIGVuY3J5cHRlZCBwYXlsb2FkLlxyXG4gICAqIEBwYXJhbSBrZXkgLSBUaGUgYmFzZTY0LWVuY29kZWQgMjU2LWJpdCBzZWNyZXQga2V5IG1hdGNoaW5nIHRoZSBlbmNyeXB0aW9uIGluc3RhbmNlLlxyXG4gICAqIEByZXR1cm5zIEEgUHJvbWlzZSByZXNvbHZpbmcgdG8gdGhlIG9yaWdpbmFsIFVURi04IHBsYWluIHRleHQgc3RyaW5nLlxyXG4gICAqIEB0aHJvd3Mge0Vycm9yfSBJZiBkZWNyeXB0aW9uIGZhaWxzLCBpbmRpY2F0aW5nIGludmFsaWQgcGFyYW1ldGVycywgZGF0YSB0YW1wZXJpbmcsIG9yIGEga2V5IG1pc21hdGNoLlxyXG4gICAqL1xyXG4gIGFzeW5jIGRlY3J5cHQoZW5jcnlwdGVkRGF0YTogc3RyaW5nLCBrZXk6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCByYXdLZXkgPSB0aGlzLmJhc2U2NDJidWYoa2V5KTtcclxuICAgIGNvbnN0IGNyeXB0b1N1YnRsZSA9IHRoaXMuZ2V0Q3J5cHRvKCk7XHJcbiAgICBjb25zdCBrZXlCdWZmZXIgPSBhd2FpdCBjcnlwdG9TdWJ0bGUuaW1wb3J0S2V5KFxyXG4gICAgICAncmF3JyxcclxuICAgICAgcmF3S2V5IGFzIEJ1ZmZlclNvdXJjZSxcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScgfSxcclxuICAgICAgdHJ1ZSxcclxuICAgICAgWydlbmNyeXB0JywgJ2RlY3J5cHQnXSxcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgZW5jcnlwdGVkQXJyYXkgPSB0aGlzLmJhc2U2NDJidWYoZW5jcnlwdGVkRGF0YSk7XHJcbiAgICBjb25zdCBpdiA9IGVuY3J5cHRlZEFycmF5LnNsaWNlKDAsIDEyKTtcclxuICAgIGNvbnN0IGNpcGhlcnRleHQgPSBlbmNyeXB0ZWRBcnJheS5zbGljZSgxMik7XHJcblxyXG4gICAgY29uc3QgZGVjcnlwdGVkRGF0YSA9IGF3YWl0IGNyeXB0b1N1YnRsZS5kZWNyeXB0KFxyXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcclxuICAgICAga2V5QnVmZmVyLFxyXG4gICAgICBjaXBoZXJ0ZXh0LFxyXG4gICAgKTtcclxuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoZGVjcnlwdGVkRGF0YSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZW5lcmF0ZXMgYSBkZXRlcm1pbmlzdGljLCBvbmUtd2F5IHBzZXVkby1hbm9ueW1vdXMgZGF0YSBibGluZCB2aWEgU0hBLTI1NiBoYXNoaW5nLlxyXG4gICAqIEdpdmVuIGlkZW50aWNhbCBwYXJhbWV0ZXJzLCB0aGUgb3V0cHV0IHN0cmluZyByZW1haW5zIGRldGVybWluaXN0aWMsIG1ha2luZyBpdCBpZGVhbCBmb3IgdHJhY2tpbmcgaWRlbnRpdHkgbWV0cmljcyB3aXRob3V0IHN0b3JpbmcgcGxhaW4gcmVjb3Jkcy5cclxuICAgKiBAcGFyYW0gZGF0YSAtIFRoZSBjb250ZXh0dWFsIHJhdyBpbnB1dCBzdHJpbmcgdG8gbWFzay5cclxuICAgKiBAcGFyYW0ga2V5IC0gU2FsdC9LZXkgbWF0ZXJpYWwgYXBwZW5kZWQgdG8gdGhlIGRhdGEgc3RydWN0dXJlIHByaW9yIHRvIGhhc2hpbmcuXHJcbiAgICogQHJldHVybnMgQSBQcm9taXNlIHJlc29sdmluZyB0byBhIGZpeGVkIDE2LWNoYXJhY3RlciBoZXgtZW5jb2RlZCBzdHJpbmcgc2VnbWVudCBvZiB0aGUgcmVzdWx0aW5nIGRpZ2VzdC5cclxuICAgKi9cclxuICBhc3luYyBibGluZERhdGEoZGF0YTogc3RyaW5nLCBrZXk6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XHJcbiAgICBjb25zdCBkYXRhQnVmZmVyID0gZW5jb2Rlci5lbmNvZGUoZGF0YSArIGtleSk7XHJcbiAgICBjb25zdCBjcnlwdG9TdWJ0bGUgPSB0aGlzLmdldENyeXB0bygpO1xyXG4gICAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0b1N1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBkYXRhQnVmZmVyKTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGhhc2hCdWZmZXIpKVxyXG4gICAgICAubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxyXG4gICAgICAuam9pbignJylcclxuICAgICAgLnNsaWNlKDAsIDE2KTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgVHJhbnNhY3Rpb24gfSBmcm9tICdAc2N1cmUvYnRjLXNpZ25lcic7XHJcbmltcG9ydCB7IGJhc2U2NCwgaGV4IH0gZnJvbSAnQHNjdXJlL2Jhc2UnO1xyXG5pbXBvcnQgeyBiZWNoMzIsIGJlY2gzMm0gfSBmcm9tICdAc2N1cmUvYmFzZSc7XHJcbmltcG9ydCB7IE5FVFdPUkssIFRFU1RfTkVUV09SSywgQWRkcmVzcyB9IGZyb20gJ0BzY3VyZS9idGMtc2lnbmVyJztcclxuXHJcbi8qKlxyXG4gKiBHcmFudWxhciBicmVha2Rvd24gb2YgYSB0cmFuc2FjdGlvbidzIHN0cnVjdHVyYWwgcGF5bG9hZC5cclxuICogUHJvdmlkZXMgYSBodW1hbi1yZWFkYWJsZSBzdW1tYXJ5IG9mIGlucHV0cywgb3V0cHV0cywgYW5kIG5ldHdvcmsgZmVlcy5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHhEZXRhaWxzIHtcclxuICAvKiogVGhlIHRvdGFsIG91dGJvdW5kIHZvbHVtZSBvZiB0aGUgdHJhbnNhY3Rpb24sIGV4cHJlc3NlZCBpbiBzYXRvc2hpcyAoZXhjbHVkaW5nIGZlZXMpLiAqL1xyXG4gIGFtb3VudDogbnVtYmVyO1xyXG4gIC8qKiBUaGUgdG90YWwgbmV0d29yayBmZWUgY2FsY3VsYXRlZCBhcyB0aGUgZGlmZmVyZW5jZSBiZXR3ZWVuIHRvdGFsIGlucHV0cyBhbmQgb3V0cHV0cy4gKi9cclxuICBmZWU6IG51bWJlcjtcclxuICAvKiogVGhlIGVzdGltYXRlZCB2aXJ0dWFsIGJ5dGUgKHZCKSBzaXplIG9mIHRoZSBmaW5hbGl6ZWQgdHJhbnNhY3Rpb24uICovXHJcbiAgdkJ5dGVzOiBudW1iZXI7XHJcbiAgLyoqIFRoZSBlZmZlY3RpdmUgZmVlIHJhdGUgcGFpZCB0byBtaW5lcnMsIGV4cHJlc3NlZCBpbiBzYXRvc2hpcyBwZXIgdkJ5dGUgKHNhdC92QikuICovXHJcbiAgZmVlUmF0ZTogbnVtYmVyO1xyXG4gIC8qKiBUaGUgdG90YWwgY291bnQgb2YgdW5zcGVudCB0cmFuc2FjdGlvbiBvdXRwdXRzIChVVFhPcykgY29uc3VtZWQgYXMgaW5wdXRzLiAqL1xyXG4gIGlucHV0czogbnVtYmVyO1xyXG4gIC8qKiBEZXRhaWxlZCBtYXBwaW5nIG9mIGV2ZXJ5IGNvbnN1bWVkIGlucHV0LCBpbmNsdWRpbmcgb3JpZ2luIHR4SWQgYW5kIHNhdG9zaGkgdmFsdWUuICovXHJcbiAgaW5wdXRzTGlzdDogeyBhZGRyZXNzOiBzdHJpbmc7IGFtb3VudDogbnVtYmVyOyB0eElkOiBzdHJpbmc7IHZvdXQ6IG51bWJlciB9W107XHJcbiAgLyoqIERldGFpbGVkIG1hcHBpbmcgb2YgZXZlcnkgY3JlYXRlZCBvdXRwdXQsIGluZGljYXRpbmcgZGVzdGluYXRpb24gYWRkcmVzc2VzIGFuZCBjaGFuZ2Ugcm91dGluZy4gKi9cclxuICBvdXRwdXRzOiB7IGFkZHJlc3M6IHN0cmluZzsgYW1vdW50OiBudW1iZXI7IGlzQ2hhbmdlOiBib29sZWFuIH1bXTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFJlcHJlc2VudHMgdGhlIHNpZ25hdHVyZSBzdGF0dXMgb2YgYSBzcGVjaWZpYyBoYXJkd2FyZSB3YWxsZXQgb3Igc2lnbmluZyBwYXJ0aWNpcGFudC5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgU2lnbmVyU3RhdHVzIHtcclxuICAvKiogVGhlIG1hc3RlciBrZXkgZmluZ2VycHJpbnQgKDggaGV4IGNoYXJhY3RlcnMpIGlkZW50aWZ5aW5nIHRoZSBzaWduZXIuICovXHJcbiAgZmluZ2VycHJpbnQ6IHN0cmluZztcclxuICAvKiogSW5kaWNhdGVzIHdoZXRoZXIgYSB2YWxpZCBwYXJ0aWFsIHNpZ25hdHVyZSBleGlzdHMgZnJvbSB0aGlzIHBhcnRpY2lwYW50LiAqL1xyXG4gIHNpZ25lZDogYm9vbGVhbjtcclxufVxyXG5cclxuLyoqXHJcbiAqIEhpZ2gtbGV2ZWwgYW5hbHl0aWNhbCBvdmVydmlldyBvZiBhIFBhcnRpYWxseSBTaWduZWQgQml0Y29pbiBUcmFuc2FjdGlvbiAoUFNCVCkuXHJcbiAqIFVzZWQgZm9yIHJhcGlkIHZhbGlkYXRpb24gYW5kIGVudmlyb25tZW50YWwgcm91dGluZy5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHNidEFuYWx5c2lzIHtcclxuICAvKiogSW5kaWNhdGVzIGlmIHRoZSBwcm92aWRlZCBQU0JUIHN0cmluZyBpcyBzdHJ1Y3R1cmFsbHkgc291bmQgYW5kIHBhcnNhYmxlLiAqL1xyXG4gIHZhbGlkOiBib29sZWFuO1xyXG4gIC8qKiBUaGUgdG90YWwgY291bnQgb2YgZGlzdGluY3QgZXh0ZW5kZWQgcHVibGljIGtleSBmaW5nZXJwcmludHMgaW52b2x2ZWQgaW4gdGhlIHRyYW5zYWN0aW9uLiAqL1xyXG4gIHNpZ25lckNvdW50OiBudW1iZXI7XHJcbiAgLyoqIFRoZSBhZ2dyZWdhdGUgdHJhbnNhY3Rpb24gb3V0cHV0IHZvbHVtZSBjb252ZXJ0ZWQgdG8gd2hvbGUgQml0Y29pbiAoQlRDKS4gKi9cclxuICBhbW91bnRCdGM6IG51bWJlcjtcclxuICAvKiogVGhlIGFic29sdXRlIG5ldHdvcmsgZmVlIGV4cGVjdGVkIGJ5IHRoZSBuZXR3b3JrLCBleHByZXNzZWQgaW4gc2F0b3NoaXMuICovXHJcbiAgbmV0d29ya0ZlZVNhdDogbnVtYmVyO1xyXG4gIC8qKiBUaGUgdG90YWwgY291bnQgb2YgbmV3bHkgY3JlYXRlZCBVVFhPcyByZXN1bHRpbmcgZnJvbSB0aGlzIHRyYW5zYWN0aW9uLiAqL1xyXG4gIG91dHB1dENvdW50OiBudW1iZXI7XHJcbiAgLyoqIFRoZSBjcnlwdG9ncmFwaGljIG5ldHdvcmsgZW52aXJvbm1lbnQgZGVyaXZlZCBmcm9tIEJJUDMyIGRlcml2YXRpb24gcGF0aHMuICovXHJcbiAgZGV0ZWN0ZWROZXR3b3JrOiAnYml0Y29pbicgfCAndGVzdG5ldCcgfCAndW5rbm93bic7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBVdGlsaXR5IGNsYXNzIHByb3ZpZGluZyBzdGF0aWMgbWV0aG9kcyBmb3IgcGFyc2luZywgdmFsaWRhdGluZywgbXV0YXRpbmcsXHJcbiAqIGFuZCBleHRyYWN0aW5nIG1ldGFkYXRhIGZyb20gUGFydGlhbGx5IFNpZ25lZCBCaXRjb2luIFRyYW5zYWN0aW9ucyAoUFNCVHMpLlxyXG4gKi9cclxuZXhwb3J0IGNsYXNzIFBzYnRVdGlscyB7XHJcbiAgLyoqXHJcbiAgICogRGVjb2RlcyBhIHJhdyBQU0JUIHN0cmluZyBwYXlsb2FkIGludG8gYSBzdHJpY3RseSB0eXBlZCBiaW5hcnkgYnl0ZSBhcnJheS5cclxuICAgKiBJbnRlbGxpZ2VudGx5IGRldGVjdHMgYW5kIHJvdXRlcyBiZXR3ZWVuIGhleC1lbmNvZGVkIGFuZCBiYXNlNjQtZW5jb2RlZCBmb3JtYXRzLlxyXG4gICAqICogQHBhcmFtIHJhdyAtIFRoZSByYXcsIHVuZm9ybWF0dGVkIFBTQlQgc3RyaW5nIHBheWxvYWQuXHJcbiAgICogQHJldHVybnMgQSBkZWNvZGVkIFVpbnQ4QXJyYXkgY29udGFpbmluZyB0aGUgcmF3IGJpbmFyeSB0cmFuc2FjdGlvbi5cclxuICAgKi9cclxuICBzdGF0aWMgZGVjb2RlKHJhdzogc3RyaW5nKTogVWludDhBcnJheSB7XHJcbiAgICBjb25zdCBjbGVhbiA9IHJhdy5yZXBsYWNlKC9cXHMvZywgJycpO1xyXG4gICAgcmV0dXJuIC9eWzAtOWEtZkEtRl0rJC8udGVzdChjbGVhbikgPyBoZXguZGVjb2RlKGNsZWFuKSA6IGJhc2U2NC5kZWNvZGUoY2xlYW4pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTm9ybWFsaXplcyBhbiBhcmJpdHJhcnkgUFNCVCBpbnB1dCBzdHJpbmcgaW50byBhIHN0YW5kYXJkIEJhc2U2NCByZXByZXNlbnRhdGlvbi5cclxuICAgKiBBdXRvLWNvbnZlcnRzIHZhbGlkIGhleCBzdHJpbmdzIGNvbnRhaW5pbmcgdGhlIFBTQlQgbWFnaWMgYnl0ZXMgaW50byBCYXNlNjQuXHJcbiAgICogKiBAcGFyYW0gaW5wdXQgLSBUaGUgcmF3IFBTQlQgc3RyaW5nIChCYXNlNjQgb3IgSGV4KS5cclxuICAgKiBAcmV0dXJucyBBIHNhbml0aXplZCwgQmFzZTY0IGVuY29kZWQgUFNCVCBzdHJpbmcuXHJcbiAgICovXHJcbiAgc3RhdGljIG5vcm1hbGl6ZShpbnB1dDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGNsZWFuID0gaW5wdXQudHJpbSgpO1xyXG4gICAgaWYgKC9eWzAtOWEtZkEtRl0rJC8udGVzdChjbGVhbikgJiYgY2xlYW4udG9Mb3dlckNhc2UoKS5zdGFydHNXaXRoKCc3MDczNjI3NCcpKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgcmV0dXJuIGJhc2U2NC5lbmNvZGUoaGV4LmRlY29kZShjbGVhbikpO1xyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgcmV0dXJuIGlucHV0O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gY2xlYW47XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDcnlwdG9ncmFwaGljYWxseSBtZXJnZXMgdHdvIGRpc3RpbmN0IFBTQlQgcGF5bG9hZHMgc2hhcmluZyB0aGUgc2FtZSB1bmRlcmx5aW5nIHRyYW5zYWN0aW9uIHN0YXRlLlxyXG4gICAqIFVzZWQgdG8gYWdncmVnYXRlIGlzb2xhdGVkIHBhcnRpY2lwYW50IHNpZ25hdHVyZXMgaW50byBhIHVuaWZpZWQgdHJhbnNhY3Rpb24gbWFwLlxyXG4gICAqICogQHBhcmFtIGJhc2UgLSBUaGUgcHJpbWFyeSBCYXNlNjQgUFNCVCBwYXlsb2FkLlxyXG4gICAqIEBwYXJhbSBuZXh0IC0gVGhlIHNlY29uZGFyeSBCYXNlNjQgUFNCVCBwYXlsb2FkIGNvbnRhaW5pbmcgcGFyYWxsZWwgc2lnbmF0dXJlcy5cclxuICAgKiBAcmV0dXJucyBBIG5ldyBCYXNlNjQgUFNCVCBzdHJpbmcgY29udGFpbmluZyB0aGUgY29tYmluZWQgc2lnbmF0dXJlcywgb3IgdGhlIG9yaWdpbmFsIGJhc2Ugb24gZmFpbHVyZS5cclxuICAgKi9cclxuICBzdGF0aWMgbWVyZ2UoYmFzZTogc3RyaW5nLCBuZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdHhCYXNlID0gVHJhbnNhY3Rpb24uZnJvbVBTQlQodGhpcy5kZWNvZGUoYmFzZSkpO1xyXG4gICAgICBjb25zdCB0eE5leHQgPSBUcmFuc2FjdGlvbi5mcm9tUFNCVCh0aGlzLmRlY29kZShuZXh0KSk7XHJcbiAgICAgIHR4QmFzZS5jb21iaW5lKHR4TmV4dCk7XHJcbiAgICAgIHJldHVybiBiYXNlNjQuZW5jb2RlKHR4QmFzZS50b1BTQlQoKSk7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tNZXJnZSBGYWlsZWRdJywgZSk7XHJcbiAgICAgIHJldHVybiBiYXNlO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRXh0cmFjdHMgdGhlIE0tb2YtTiBtdWx0aXNpZyByZXF1aXJlZCB0aHJlc2hvbGQgZGlyZWN0bHkgZnJvbSB0aGUgcmVkZWVtL3dpdG5lc3Mgc2NyaXB0LlxyXG4gICAqICogQHBhcmFtIHBzYnRCYXNlNjQgLSBUaGUgbm9ybWFsaXplZCBCYXNlNjQgUFNCVCBwYXlsb2FkLlxyXG4gICAqIEByZXR1cm5zIFRoZSBpbnRlZ2VyIHJlcHJlc2VudGluZyB0aGUgbWluaW11bSBzaWduYXR1cmVzIHJlcXVpcmVkLCBvciAwIGlmIHVucmVhZGFibGUuXHJcbiAgICovXHJcbiAgc3RhdGljIGdldFRocmVzaG9sZChwc2J0QmFzZTY0OiBzdHJpbmcpOiBudW1iZXIge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdHggPSBUcmFuc2FjdGlvbi5mcm9tUFNCVChiYXNlNjQuZGVjb2RlKHBzYnRCYXNlNjQpKTtcclxuXHJcbiAgICAgIC8vIEl0ZXJhdGUgdGhyb3VnaCBhbGwgaW5wdXRzIGluIHRoZSB0cmFuc2FjdGlvblxyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR4LmlucHV0c0xlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgY29uc3QgaW5wdXQgPSB0eC5nZXRJbnB1dChpKTtcclxuICAgICAgICBpZiAoIWlucHV0KSBjb250aW51ZTtcclxuXHJcbiAgICAgICAgY29uc3Qgc2NyaXB0ID0gaW5wdXQud2l0bmVzc1NjcmlwdCB8fCBpbnB1dC5yZWRlZW1TY3JpcHQ7XHJcbiAgICAgICAgaWYgKCFzY3JpcHQgfHwgc2NyaXB0Lmxlbmd0aCA9PT0gMCkgY29udGludWU7XHJcblxyXG4gICAgICAgIGNvbnN0IGZpcnN0T3AgPSBzY3JpcHRbMF07XHJcbiAgICAgICAgLy8gQ2hlY2sgaWYgdGhlIGZpcnN0IG9wY29kZSBpcyBhIHZhbGlkIHB1c2ggZm9yIGEgdGhyZXNob2xkIChPUF8xIHRvIE9QXzE2KVxyXG4gICAgICAgIGlmIChmaXJzdE9wID49IDB4NTEgJiYgZmlyc3RPcCA8PSAweDYwKSB7XHJcbiAgICAgICAgICByZXR1cm4gZmlyc3RPcCAtIDB4NTA7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gMDtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIElkZW50aWZpZXMgdGhlIHByaW1hcnkgc2lnbmVyJ3MgbWFzdGVyIGtleSBmaW5nZXJwcmludCBhc3NvY2lhdGVkIHdpdGggdGhlIGZpcnN0IGRldGVjdGVkIHBhcnRpYWwgc2lnbmF0dXJlLlxyXG4gICAqICogQHBhcmFtIHBzYnREYXRhIC0gVGhlIG5vcm1hbGl6ZWQgQmFzZTY0IFBTQlQgcGF5bG9hZC5cclxuICAgKiBAcmV0dXJucyBUaGUgOC1jaGFyYWN0ZXIgaGV4IGZpbmdlcnByaW50IHN0cmluZywgb3IgbnVsbCBpZiBubyB2YWxpZCBzaWduYXR1cmUgbWFwcGluZyBpcyBmb3VuZC5cclxuICAgKi9cclxuICBzdGF0aWMgZ2V0RmluZ2VycHJpbnRGcm9tUHNidChwc2J0RGF0YTogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBieXRlcyA9IHRoaXMuZGVjb2RlKHBzYnREYXRhKTtcclxuICAgICAgY29uc3QgdHggPSBUcmFuc2FjdGlvbi5mcm9tUFNCVChieXRlcyk7XHJcblxyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR4LmlucHV0c0xlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgY29uc3QgaW5wdXQgPSB0eC5nZXRJbnB1dChpKTtcclxuXHJcbiAgICAgICAgaWYgKGlucHV0LnBhcnRpYWxTaWcgJiYgaW5wdXQucGFydGlhbFNpZy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCBwdWJrZXlTaWduZWQgPSBpbnB1dC5wYXJ0aWFsU2lnWzBdWzBdO1xyXG5cclxuICAgICAgICAgIGlmIChpbnB1dC5iaXAzMkRlcml2YXRpb24pIHtcclxuICAgICAgICAgICAgZm9yIChjb25zdCBbcHVia2V5LCBtZXRhXSBvZiBpbnB1dC5iaXAzMkRlcml2YXRpb24pIHtcclxuICAgICAgICAgICAgICBpZiAoaGV4LmVuY29kZShwdWJrZXkpID09PSBoZXguZW5jb2RlKHB1YmtleVNpZ25lZCkpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBtZXRhLmZpbmdlcnByaW50LnRvU3RyaW5nKDE2KS5wYWRTdGFydCg4LCAnMCcpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb21wbGV0ZWx5IHBhcnNlcyBhIFBTQlQgdG8gZGVyaXZlIGh1bWFuLXJlYWRhYmxlIGZpbmFuY2lhbCBtZXRyaWNzLCBJL08gbWFwcywgYW5kIGZlZSBlc3RpbWF0b3JzLlxyXG4gICAqICogQHBhcmFtIHBzYnRCYXNlNjQgLSBUaGUgbm9ybWFsaXplZCBCYXNlNjQgUFNCVCBwYXlsb2FkLlxyXG4gICAqIEBwYXJhbSBuZXR3b3JrIC0gVGhlIHRhcmdldCBuZXR3b3JrIGNvbnRleHQgcmVxdWlyZWQgZm9yIGFjY3VyYXRlIGFkZHJlc3MgZm9ybWF0dGluZy5cclxuICAgKiBAcmV0dXJucyBBIHN0cnVjdHVyZWQgVHhEZXRhaWxzIG9iamVjdCwgb3IgbnVsbCBpZiB0aGUgcGFyc2luZyBlbmdpbmUgZW5jb3VudGVycyBhIGZhdGFsIGVycm9yLlxyXG4gICAqL1xyXG4gIHN0YXRpYyBwYXJzZVR4RGV0YWlscyhcclxuICAgIHBzYnRCYXNlNjQ6IHN0cmluZyxcclxuICAgIG5ldHdvcms6ICdiaXRjb2luJyB8ICd0ZXN0bmV0JyB8ICdzaWduZXQnID0gJ2JpdGNvaW4nLFxyXG4gICk6IFR4RGV0YWlscyB8IG51bGwge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdHggPSBUcmFuc2FjdGlvbi5mcm9tUFNCVChiYXNlNjQuZGVjb2RlKHBzYnRCYXNlNjQpKTtcclxuICAgICAgY29uc3QgaW5wdXRzTGlzdCA9IFtdO1xyXG4gICAgICBjb25zdCBvdXRwdXRzID0gW107XHJcbiAgICAgIGxldCB0b3RhbElucHV0ID0gMDtcclxuICAgICAgbGV0IHRvdGFsT3V0cHV0ID0gMDtcclxuXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHguaW5wdXRzTGVuZ3RoOyBpKyspIHtcclxuICAgICAgICBjb25zdCBpbnB1dCA9IHR4LmdldElucHV0KGkpO1xyXG4gICAgICAgIGxldCBhbW91bnQgPSAwO1xyXG4gICAgICAgIGxldCBhZGRyZXNzID0gJ0xlZ2FjeS9Vbmtub3duJztcclxuXHJcbiAgICAgICAgaWYgKGlucHV0LndpdG5lc3NVdHhvKSB7XHJcbiAgICAgICAgICBhbW91bnQgPSBOdW1iZXIoaW5wdXQud2l0bmVzc1V0eG8uYW1vdW50KTtcclxuICAgICAgICAgIHRvdGFsSW5wdXQgKz0gYW1vdW50O1xyXG4gICAgICAgICAgYWRkcmVzcyA9IHRoaXMuZm9ybWF0U2NyaXB0QWRkcmVzcyhpbnB1dC53aXRuZXNzVXR4by5zY3JpcHQsIG5ldHdvcmspO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoaW5wdXQubm9uV2l0bmVzc1V0eG8pIHtcclxuICAgICAgICAgIGFkZHJlc3MgPSAnTGVnYWN5IElucHV0JztcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCB0eElkID0gJz8/Pz8nO1xyXG4gICAgICAgIGxldCB2b3V0ID0gMDtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgcmF3SW5wdXQgPSAodHggYXMgYW55KS51bnNpZ25lZFR4LmlucHV0c1tpXTtcclxuICAgICAgICAgIGlmIChyYXdJbnB1dD8udHhpZCkge1xyXG4gICAgICAgICAgICB0eElkID0gaGV4LmVuY29kZShyYXdJbnB1dC50eGlkKS5zbGljZSgwLCA4KSArICcuLi4nO1xyXG4gICAgICAgICAgICB2b3V0ID0gcmF3SW5wdXQuaW5kZXg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgaW5wdXRzTGlzdC5wdXNoKHsgYWRkcmVzcywgYW1vdW50LCB0eElkLCB2b3V0IH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR4Lm91dHB1dHNMZW5ndGg7IGkrKykge1xyXG4gICAgICAgIGNvbnN0IG91dHB1dCA9IHR4LmdldE91dHB1dChpKTtcclxuICAgICAgICBjb25zdCBhbW91bnQgPSBOdW1iZXIob3V0cHV0LmFtb3VudCk7XHJcbiAgICAgICAgdG90YWxPdXRwdXQgKz0gYW1vdW50O1xyXG5cclxuICAgICAgICBjb25zdCBhZGRyZXNzID0gdGhpcy5mb3JtYXRTY3JpcHRBZGRyZXNzKG91dHB1dC5zY3JpcHQgfHwgbmV3IFVpbnQ4QXJyYXkoW10pLCBuZXR3b3JrKTtcclxuICAgICAgICBsZXQgaXNDaGFuZ2UgPSBmYWxzZTtcclxuXHJcbiAgICAgICAgaWYgKG91dHB1dC5iaXAzMkRlcml2YXRpb24pIHtcclxuICAgICAgICAgIGZvciAoY29uc3QgWywgbWV0YV0gb2Ygb3V0cHV0LmJpcDMyRGVyaXZhdGlvbiBhcyBhbnlbXSkge1xyXG4gICAgICAgICAgICBpZiAobWV0YT8ucGF0aD8ubGVuZ3RoID49IDIgJiYgbWV0YS5wYXRoW21ldGEucGF0aC5sZW5ndGggLSAyXSA9PT0gMSkge1xyXG4gICAgICAgICAgICAgIGlzQ2hhbmdlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBvdXRwdXRzLnB1c2goeyBhZGRyZXNzLCBhbW91bnQsIGlzQ2hhbmdlIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBvdXRwdXRzLnNvcnQoKGEsIGIpID0+IE51bWJlcihiLmlzQ2hhbmdlKSAtIE51bWJlcihhLmlzQ2hhbmdlKSk7XHJcbiAgICAgIGNvbnN0IGZlZSA9IHRvdGFsSW5wdXQgPiAwID8gTWF0aC5tYXgoMCwgdG90YWxJbnB1dCAtIHRvdGFsT3V0cHV0KSA6IDA7XHJcbiAgICAgIGxldCB2Qnl0ZXMgPSAxMCArIHR4LmlucHV0c0xlbmd0aCAqIDEwMCArIHR4Lm91dHB1dHNMZW5ndGggKiAzMTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB2Qnl0ZXMgPSAodHggYXMgYW55KS52c2l6ZSB8fCB2Qnl0ZXM7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgIGNvbnN0IGZlZVJhdGUgPSB2Qnl0ZXMgPiAwID8gTnVtYmVyKChmZWUgLyB2Qnl0ZXMpLnRvRml4ZWQoMikpIDogMDtcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgYW1vdW50OiB0b3RhbE91dHB1dCxcclxuICAgICAgICBmZWUsXHJcbiAgICAgICAgdkJ5dGVzLFxyXG4gICAgICAgIGZlZVJhdGUsXHJcbiAgICAgICAgaW5wdXRzOiB0eC5pbnB1dHNMZW5ndGgsXHJcbiAgICAgICAgaW5wdXRzTGlzdCxcclxuICAgICAgICBvdXRwdXRzLFxyXG4gICAgICB9O1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gcGFyc2UgUFNCVCcsIGUpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFNjYW5zIGEgUFNCVCB0byBtYXAgYWxsIGV4cGVjdGVkIHBhcnRpY2lwYW50cyBhbmQgZXZhbHVhdGVzIHRoZWlyIGN1cnJlbnQgc2lnbmF0dXJlIHN0YXRlLlxyXG4gICAqIFdvcmtzIGFjcm9zcyBib3RoIGxlZ2FjeSBFQ0RTQSAocGFydGlhbFNpZykgYW5kIFNjaG5vcnIgKHRhcFNjcmlwdFNpZykgc2lnbmF0dXJlIHNjaGVtZXMuXHJcbiAgICogKiBAcGFyYW0gcHNidEJhc2U2NCAtIFRoZSBub3JtYWxpemVkIEJhc2U2NCBQU0JUIHBheWxvYWQuXHJcbiAgICogQHJldHVybnMgQW4gYXJyYXkgbWFwcGluZyBwYXJ0aWNpcGFudCBmaW5nZXJwcmludHMgdG8gdGhlaXIgYWN0aXZlIHNpZ25lZCBzdGF0dXMuXHJcbiAgICovXHJcbiAgc3RhdGljIGV4dHJhY3RTaWduZXJzKHBzYnRCYXNlNjQ6IHN0cmluZyk6IFNpZ25lclN0YXR1c1tdIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHR4ID0gVHJhbnNhY3Rpb24uZnJvbVBTQlQoYmFzZTY0LmRlY29kZShwc2J0QmFzZTY0KSk7XHJcbiAgICAgIGNvbnN0IHNpZ25lcnNNYXAgPSBuZXcgTWFwPHN0cmluZywgYm9vbGVhbj4oKTtcclxuXHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHguaW5wdXRzTGVuZ3RoOyBpKyspIHtcclxuICAgICAgICBjb25zdCBpbnB1dCA9IHR4LmdldElucHV0KGkpO1xyXG4gICAgICAgIGNvbnN0IGRlcml2YXRpb25zID0gaW5wdXQuYmlwMzJEZXJpdmF0aW9uIGFzIGFueVtdO1xyXG5cclxuICAgICAgICBpZiAoZGVyaXZhdGlvbnMpIHtcclxuICAgICAgICAgIGZvciAoY29uc3QgW3B1YmtleSwgbWV0YV0gb2YgZGVyaXZhdGlvbnMpIHtcclxuICAgICAgICAgICAgaWYgKCFtZXRhPy5maW5nZXJwcmludCkgY29udGludWU7XHJcbiAgICAgICAgICAgIGNvbnN0IGZwSGV4ID0gbWV0YS5maW5nZXJwcmludC50b1N0cmluZygxNikucGFkU3RhcnQoOCwgJzAnKTtcclxuICAgICAgICAgICAgbGV0IGlzU2lnbmVkID0gZmFsc2U7XHJcblxyXG4gICAgICAgICAgICBpZiAoaW5wdXQucGFydGlhbFNpZykge1xyXG4gICAgICAgICAgICAgIGlzU2lnbmVkID0gaW5wdXQucGFydGlhbFNpZy5zb21lKChwKSA9PiB0aGlzLmFyZUtleXNFcXVhbChwWzBdLCBwdWJrZXkpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoIWlzU2lnbmVkICYmIGlucHV0LnRhcFNjcmlwdFNpZykge1xyXG4gICAgICAgICAgICAgIGlzU2lnbmVkID0gaW5wdXQudGFwU2NyaXB0U2lnLnNvbWUoKHA6IGFueSkgPT4gdGhpcy5hcmVLZXlzRXF1YWwocC5wdWJLZXksIHB1YmtleSkpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBjb25zdCBjdXJyZW50ID0gc2lnbmVyc01hcC5nZXQoZnBIZXgpIHx8IGZhbHNlO1xyXG4gICAgICAgICAgICBzaWduZXJzTWFwLnNldChmcEhleCwgY3VycmVudCB8fCBpc1NpZ25lZCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiBBcnJheS5mcm9tKHNpZ25lcnNNYXAuZW50cmllcygpKS5tYXAoKFtmcCwgc2lnbmVkXSkgPT4gKHsgZmluZ2VycHJpbnQ6IGZwLCBzaWduZWQgfSkpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBEZWNvZGVzIGFuIGFyYml0cmFyeSBvdXRwdXQgc2NyaXB0IGludG8gYSBodW1hbi1yZWFkYWJsZSBCaXRjb2luIGFkZHJlc3MuXHJcbiAgICogU3VwcG9ydHMgUDJQS0gsIFAyU0gsIFNlZ1dpdCB2MCAoQmVjaDMyKSwgYW5kIFRhcHJvb3QgKEJlY2gzMm0pLlxyXG4gICAqICogQHBhcmFtIHNjcmlwdCAtIFRoZSByYXcgbG9ja2luZyBzY3JpcHQgYnl0ZSBhcnJheS5cclxuICAgKiBAcGFyYW0gbmV0d29yayAtIFRoZSB0YXJnZXQgbmV0d29yayBjb25maWd1cmF0aW9uLlxyXG4gICAqIEByZXR1cm5zIFRoZSBmb3JtYXR0ZWQgcHVibGljIGFkZHJlc3MsIG9yIGEgcmF3IGhleCBmYWxsYmFjayBpZiB1bnN1cHBvcnRlZC5cclxuICAgKi9cclxuICBzdGF0aWMgZm9ybWF0U2NyaXB0QWRkcmVzcyhcclxuICAgIHNjcmlwdDogVWludDhBcnJheSxcclxuICAgIG5ldHdvcms6ICdiaXRjb2luJyB8ICd0ZXN0bmV0JyB8ICdzaWduZXQnLFxyXG4gICk6IHN0cmluZyB7XHJcbiAgICBpZiAoIXNjcmlwdCB8fCBzY3JpcHQubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHJldHVybiAnVW5rbm93bic7XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcyA9IGhleC5lbmNvZGUoc2NyaXB0KTtcclxuICAgICAgY29uc3QgY3VycmVudE5ldHdvcmsgPSBuZXR3b3JrIHx8ICdiaXRjb2luJztcclxuICAgICAgY29uc3QgaXNUZXN0bmV0TGlrZSA9IGN1cnJlbnROZXR3b3JrID09PSAndGVzdG5ldCcgfHwgY3VycmVudE5ldHdvcmsgPT09ICdzaWduZXQnO1xyXG4gICAgICBjb25zdCBocnAgPSBpc1Rlc3RuZXRMaWtlID8gJ3RiJyA6ICdiYyc7XHJcbiAgICAgIGNvbnN0IG5ldHdvcmtDb25maWcgPSBpc1Rlc3RuZXRMaWtlID8gVEVTVF9ORVRXT1JLIDogTkVUV09SSztcclxuXHJcbiAgICAgIC8vIExlZ2FjeSBQMlBLSCAoaW1wb3J0YW50IGZvciBvbGQgbXVsdGlzaWcvdW5zaWduZWQgdHhzKVxyXG4gICAgICBpZiAocy5zdGFydHNXaXRoKCc3NmE5MTQnKSAmJiBzLmVuZHNXaXRoKCc4OGFjJykgJiYgc2NyaXB0Lmxlbmd0aCA9PT0gMjUpIHtcclxuICAgICAgICBjb25zdCBwdWJLZXlIYXNoID0gc2NyaXB0LnNsaWNlKDMsIDIzKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIEFkZHJlc3MobmV0d29ya0NvbmZpZykuZW5jb2RlKHsgdHlwZTogJ3BraCcsIGhhc2g6IHB1YktleUhhc2ggfSBhcyBhbnkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBMZWdhY3kgUDJTSCAmIE5lc3RlZCBTZWdXaXQgKHN0YXJ0cyB3aXRoIGE5MTQsIGxlbmd0aCAyMyBieXRlcylcclxuICAgICAgaWYgKHMuc3RhcnRzV2l0aCgnYTkxNCcpICYmIHMuZW5kc1dpdGgoJzg3JykgJiYgc2NyaXB0Lmxlbmd0aCA9PT0gMjMpIHtcclxuICAgICAgICBjb25zdCBzY3JpcHRIYXNoID0gc2NyaXB0LnNsaWNlKDIsIDIyKTsgLy8gRXh0cmFjdCB0aGUgMjAtYnl0ZSBzY3JpcHQgaGFzaFxyXG4gICAgICAgIHJldHVybiBBZGRyZXNzKG5ldHdvcmtDb25maWcpLmVuY29kZSh7IHR5cGU6ICdzaCcsIGhhc2g6IHNjcmlwdEhhc2ggfSBhcyBhbnkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBTZWdXaXQgdjAgLSBQMldQS0ggKDIyIGJ5dGVzKSBvciBQMldTSCAoMzQgYnl0ZXMpID0gQmVjaDMyXHJcbiAgICAgIGlmIChcclxuICAgICAgICAocy5zdGFydHNXaXRoKCcwMDE0JykgJiYgc2NyaXB0Lmxlbmd0aCA9PT0gMjIpIHx8XHJcbiAgICAgICAgKHMuc3RhcnRzV2l0aCgnMDAyMCcpICYmIHNjcmlwdC5sZW5ndGggPT09IDM0KVxyXG4gICAgICApIHtcclxuICAgICAgICBjb25zdCB3aXRuZXNzUHJvZ3JhbSA9IHNjcmlwdC5zbGljZSgyKTtcclxuICAgICAgICBjb25zdCB3b3JkcyA9IGJlY2gzMi50b1dvcmRzKHdpdG5lc3NQcm9ncmFtKTtcclxuICAgICAgICB3b3Jkcy51bnNoaWZ0KDApO1xyXG4gICAgICAgIHJldHVybiBiZWNoMzIuZW5jb2RlKGhycCwgd29yZHMpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBUYXByb290ICsgRnV0dXJlIFdpdG5lc3MgVmVyc2lvbnMgKHYxIHRvIHYxNikgPSBCZWNoMzJtIChCSVAtMzUwKVxyXG4gICAgICBpZiAocy5sZW5ndGggPj0gNCkge1xyXG4gICAgICAgIGNvbnN0IHZlcnNpb25CeXRlID0gcGFyc2VJbnQocy5zbGljZSgwLCAyKSwgMTYpO1xyXG4gICAgICAgIGlmICh2ZXJzaW9uQnl0ZSA+PSAweDUxICYmIHZlcnNpb25CeXRlIDw9IDB4NjApIHtcclxuICAgICAgICAgIC8vIE9QXzEgdG8gT1BfMTZcclxuICAgICAgICAgIGNvbnN0IHdpdG5lc3NWZXJzaW9uID0gdmVyc2lvbkJ5dGUgLSAweDUwO1xyXG4gICAgICAgICAgY29uc3Qgd2l0bmVzc1Byb2dyYW0gPSBzY3JpcHQuc2xpY2UoMik7XHJcblxyXG4gICAgICAgICAgY29uc3Qgd29yZHMgPSBiZWNoMzJtLnRvV29yZHMod2l0bmVzc1Byb2dyYW0pO1xyXG4gICAgICAgICAgd29yZHMudW5zaGlmdCh3aXRuZXNzVmVyc2lvbik7XHJcbiAgICAgICAgICByZXR1cm4gYmVjaDMybS5lbmNvZGUoaHJwLCB3b3Jkcyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBGYWxsYmFjazogc2hvdyByYXcgaGV4IGZvciB1bmtub3duIHNjcmlwdHNcclxuICAgICAgcmV0dXJuIHM7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUud2FybignQWRkcmVzcyBmb3JtYXR0aW5nIGZhaWxlZDonLCBlLCBoZXguZW5jb2RlKHNjcmlwdCkpO1xyXG5cclxuICAgICAgY29uc3QgcyA9IGhleC5lbmNvZGUoc2NyaXB0KTtcclxuICAgICAgaWYgKHMuc3RhcnRzV2l0aCgnMDAxNCcpIHx8IHMuc3RhcnRzV2l0aCgnMDAyMCcpIHx8IHMuc3RhcnRzV2l0aCgnNTEnKSkgcmV0dXJuIHMuc2xpY2UoNCk7XHJcbiAgICAgIGlmIChzLnN0YXJ0c1dpdGgoJzc2YTkxNCcpKSByZXR1cm4gcy5zbGljZSg2LCA0Nik7IC8vIFAyUEtIIGZhbGxiYWNrXHJcbiAgICAgIGlmIChzLnN0YXJ0c1dpdGgoJ2E5MTQnKSkgcmV0dXJuIHMuc2xpY2UoNCwgNDQpOyAvLyBQMlNIIGZhbGxiYWNrXHJcbiAgICAgIHJldHVybiBzO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVmFsaWRhdGVzIHN0cnVjdHVyYWwgZXF1aXZhbGVuY2UgYmV0d2VlbiB0d28gcHVibGljIGtleXMsIGhhbmRsaW5nIGNvbXByZXNzaW9uIG1pc21hdGNoIHNhZmVseS5cclxuICAgKi9cclxuICBwcml2YXRlIHN0YXRpYyBhcmVLZXlzRXF1YWwoazE6IFVpbnQ4QXJyYXksIGsyOiBVaW50OEFycmF5KTogYm9vbGVhbiB7XHJcbiAgICBpZiAoaGV4LmVuY29kZShrMSkgPT09IGhleC5lbmNvZGUoazIpKSByZXR1cm4gdHJ1ZTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGdldFggPSAoazogVWludDhBcnJheSkgPT5cclxuICAgICAgICBrLmxlbmd0aCA9PT0gMzMgPyBrLnNsaWNlKDEpIDogay5sZW5ndGggPT09IDY1ID8gay5zbGljZSgxLCAzMykgOiBrO1xyXG4gICAgICByZXR1cm4gaGV4LmVuY29kZShnZXRYKGsxKSkgPT09IGhleC5lbmNvZGUoZ2V0WChrMikpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBGaW5hbGl6ZXMgYW4gZnVsbHktc2lnbmVkIFBTQlQgbWFwIGludG8gYW4gZXh0cmFjdGVkLCBicm9hZGNhc3QtcmVhZHkgcmF3IGhleCBzdHJpbmcuXHJcbiAgICogKiBAcGFyYW0gcHNidEJhc2U2NCAtIFRoZSBmdWxseSBzaWduZWQgQmFzZTY0IFBTQlQgcGF5bG9hZC5cclxuICAgKiBAcmV0dXJucyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgcmF3IHRyYW5zYWN0aW9uIGhleCBhbmQgZGVyaXZlZCB0eElkLCBvciBudWxsIG9uIGZhaWx1cmUuXHJcbiAgICovXHJcbiAgc3RhdGljIGZpbmFsaXplVHgocHNidEJhc2U2NDogc3RyaW5nKTogeyBoZXg6IHN0cmluZzsgdHhJZDogc3RyaW5nIH0gfCBudWxsIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHR4ID0gVHJhbnNhY3Rpb24uZnJvbVBTQlQodGhpcy5kZWNvZGUocHNidEJhc2U2NCkpO1xyXG4gICAgICB0eC5maW5hbGl6ZSgpO1xyXG4gICAgICByZXR1cm4geyBoZXg6IGhleC5lbmNvZGUodHguZXh0cmFjdCgpKSwgdHhJZDogdHguaWQgfTtcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBQZXJmb3JtcyBhIHJhcGlkLCB1bmF1dGhlbnRpY2F0ZWQgc3VyZmFjZSBhbmFseXNpcyBvZiBhIFBTQlQuXHJcbiAgICogUHJpbWFyaWx5IHV0aWxpemVkIHRvIGFzY2VydGFpbiBoaWdoLWxldmVsIHNhbml0eSBjb25zdHJhaW50cyBhbmQgYmxvY2sgb3V0LW9mLW5ldHdvcmsgcGF5bG9hZHMuXHJcbiAgICogKiBAcGFyYW0gcHNidEJhc2U2NCAtIFRoZSBub3JtYWxpemVkIEJhc2U2NCBQU0JUIHBheWxvYWQuXHJcbiAgICogQHJldHVybnMgQSBoaWdoLWxldmVsIFBzYnRBbmFseXNpcyBjb25maWd1cmF0aW9uIG9iamVjdCwgb3IgbnVsbCBvbiBwYXJzZSBmYWlsdXJlLlxyXG4gICAqL1xyXG4gIHN0YXRpYyBhbmFseXplKHBzYnRCYXNlNjQ6IHN0cmluZyk6IFBzYnRBbmFseXNpcyB8IG51bGwge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcHNidEJ5dGVzID0gdGhpcy5kZWNvZGUocHNidEJhc2U2NCk7XHJcbiAgICAgIGNvbnN0IHR4ID0gVHJhbnNhY3Rpb24uZnJvbVBTQlQocHNidEJ5dGVzLCB7IGFsbG93VW5rbm93bjogdHJ1ZSB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGZpbmdlcnByaW50cyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gICAgICBsZXQgdG90YWxJbnB1dCA9IDAsXHJcbiAgICAgICAgdG90YWxPdXRwdXQgPSAwLFxyXG4gICAgICAgIG5ldHdvcmtTY29yZSA9IDA7XHJcblxyXG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR4LmlucHV0c0xlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgY29uc3QgaW5wdXQgPSB0eC5nZXRJbnB1dChpKTtcclxuICAgICAgICBpZiAoaW5wdXQud2l0bmVzc1V0eG8pIHRvdGFsSW5wdXQgKz0gTnVtYmVyKGlucHV0LndpdG5lc3NVdHhvLmFtb3VudCk7XHJcbiAgICAgICAgaWYgKGlucHV0LmJpcDMyRGVyaXZhdGlvbikge1xyXG4gICAgICAgICAgZm9yIChjb25zdCBbLCBtZXRhXSBvZiBpbnB1dC5iaXAzMkRlcml2YXRpb24gYXMgYW55W10pIHtcclxuICAgICAgICAgICAgaWYgKG1ldGE/LmZpbmdlcnByaW50KSBmaW5nZXJwcmludHMuYWRkKG1ldGEuZmluZ2VycHJpbnQudG9TdHJpbmcoMTYpKTtcclxuICAgICAgICAgICAgaWYgKG1ldGE/LnBhdGgpIHtcclxuICAgICAgICAgICAgICBjb25zdCBjb2luVHlwZSA9IG1ldGEucGF0aFsxXTtcclxuICAgICAgICAgICAgICBpZiAoY29pblR5cGUgPT09IDIxNDc0ODM2NDgpIG5ldHdvcmtTY29yZS0tO1xyXG4gICAgICAgICAgICAgIGlmIChjb2luVHlwZSA9PT0gMjE0NzQ4MzY0OSkgbmV0d29ya1Njb3JlKys7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0eC5vdXRwdXRzTGVuZ3RoOyBpKyspIHRvdGFsT3V0cHV0ICs9IE51bWJlcih0eC5nZXRPdXRwdXQoaSkuYW1vdW50KTtcclxuXHJcbiAgICAgIGNvbnN0IGZlZSA9IHRvdGFsSW5wdXQgPiAwID8gdG90YWxJbnB1dCAtIHRvdGFsT3V0cHV0IDogMDtcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdmFsaWQ6IHRydWUsXHJcbiAgICAgICAgc2lnbmVyQ291bnQ6IGZpbmdlcnByaW50cy5zaXplIHx8IDEsXHJcbiAgICAgICAgYW1vdW50QnRjOiB0b3RhbE91dHB1dCAvIDEwMDAwMDAwMCxcclxuICAgICAgICBuZXR3b3JrRmVlU2F0OiBmZWUsXHJcbiAgICAgICAgb3V0cHV0Q291bnQ6IHR4Lm91dHB1dHNMZW5ndGgsXHJcbiAgICAgICAgZGV0ZWN0ZWROZXR3b3JrOiBuZXR3b3JrU2NvcmUgPiAwID8gJ3Rlc3RuZXQnIDogJ2JpdGNvaW4nLFxyXG4gICAgICB9O1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiZXhwb3J0ICogZnJvbSAnLi9saWIvc2lnbmluZy1yb29tLWNsaWVudCc7XHJcbmV4cG9ydCAqIGZyb20gJy4vbGliL3R5cGVzL2NsaWVudC1ldmVudHMnO1xyXG5leHBvcnQgKiBmcm9tICcuL2xpYi9jcnlwdG8vZW5jcnlwdGlvbi1lbmdpbmUnO1xyXG5leHBvcnQgKiBmcm9tICcuL2xpYi9yZWxheS9yZWxheS1jbGllbnQnO1xyXG5leHBvcnQgKiBmcm9tICcuL2xpYi9yZWxheS9yb29tLWZhY3RvcnknO1xyXG5leHBvcnQgKiBmcm9tICcuL2xpYi9yZWxheS9yb29tLXN0YXRlLXN0b3JlJztcclxuZXhwb3J0ICogZnJvbSAnLi9saWIvYml0Y29pbi9wc2J0LXV0aWxzJztcclxuZXhwb3J0ICogZnJvbSAnLi9saWIvYml0Y29pbi9yb29tLWF1ZGl0b3InO1xyXG5leHBvcnQgKiBmcm9tICcuL2xpYi9ldmVudHMvcm9vbS1ldmVudC1idXMnO1xyXG4iLCJpbXBvcnQgeyBTdWJqZWN0LCBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGZpbHRlciB9IGZyb20gJ3J4anMvb3BlcmF0b3JzJztcclxuaW1wb3J0IHsgUm9vbUV2ZW50LCBSb29tRXZlbnRUeXBlIH0gZnJvbSAnLi4vdHlwZXMvY2xpZW50LWV2ZW50cyc7XHJcblxyXG4vKipcclxuICogQ2VudHJhbCBicm9rZXIgaW1wbGVtZW50YXRpb24gcHJvdmlkaW5nIGRlY291cGxlZCBSeEpTLWJhc2VkIHJlYWN0aXZlIGV2ZW50IGxpbmVzLlxyXG4gKiBFbmFibGVzIHRoZSBsaWJyYXJ5IGtlcm5lbCB0byB0cmFuc3BhcmVudGx5IGRpc3BhdGNoIHNpZ25hbHMgdG8gbGlzdGVuaW5nIGhvc3QgcGxhdGZvcm1zIChzdWNoIGFzIEFuZ3VsYXIgYXBwcykuXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgUm9vbUV2ZW50QnVzIHtcclxuICAvKiogSW50ZXJuYWwgc3RyZWFtaW5nIHN1YmplY3QgcGlwaW5nIGluY29taW5nIHNpZ25hbHMgZG93biBhY3RpdmUgc3Vic2NyaWJlciBicmFuY2hlcy4gKi9cclxuICBwcml2YXRlIGV2ZW50c1N1YmplY3QgPSBuZXcgU3ViamVjdDxSb29tRXZlbnQ+KCk7XHJcblxyXG4gIC8qKlxyXG4gICAqIFB1Ymxpc2hlcyBhbiBldmVudCB0byB0aGUgbWVzc2FnaW5nIGJ1cyBsYXlvdXQsIGNhc3RpbmcgaXQgdG8gYWxsIGN1cnJlbnQgb2JzZXJ2ZXJzLlxyXG4gICAqIFR5cGljYWxseSB1c2VkIGludGVybmFsbHkgYnkgdGhlIFNESyBtb2R1bGUgY29tcG9uZW50cy5cclxuICAgKiAqIEBwYXJhbSB0eXBlIC0gVGhlIGV4YWN0IGV2ZW50IGNsYXNzaWZpZXIgdGFnLlxyXG4gICAqIEBwYXJhbSBwYXlsb2FkIC0gT3B0aW9uYWwgZXh0cmEgbWV0YWRhdGEgcGFyYW1ldGVycyBhc3NvY2lhdGVkIHdpdGggdGhlIG9wZXJhdGlvbiBzY29wZS5cclxuICAgKi9cclxuICBwdWJsaWMgZGlzcGF0Y2godHlwZTogUm9vbUV2ZW50VHlwZSwgcGF5bG9hZD86IGFueSk6IHZvaWQge1xyXG4gICAgdGhpcy5ldmVudHNTdWJqZWN0Lm5leHQoeyB0eXBlLCBwYXlsb2FkIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2VuZXJhdGVzIGEgcmVhY3RpdmUgY2hhbm5lbCBmaWx0ZXJlZCBkb3duIHRvIGFuIGlzb2xhdGVkIGV2ZW50IHN0cmluZyB0eXBlLlxyXG4gICAqICogQHBhcmFtIGV2ZW50VHlwZSAtIFRoZSB0YXJnZXQgZXZlbnQgaW5kaWNhdG9yIHRvIGxpc3RlbiBmb3IuXHJcbiAgICogQHJldHVybnMgQW4gUnhKUyBPYnNlcnZhYmxlIHlpZWxkaW5nIGV4Y2x1c2l2ZSB0YXJnZXQgZXZlbnRzLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBvbihldmVudFR5cGU6IFJvb21FdmVudFR5cGUpOiBPYnNlcnZhYmxlPFJvb21FdmVudD4ge1xyXG4gICAgcmV0dXJuIHRoaXMuZXZlbnRzU3ViamVjdC5hc09ic2VydmFibGUoKS5waXBlKGZpbHRlcigoZXZlbnQpID0+IGV2ZW50LnR5cGUgPT09IGV2ZW50VHlwZSkpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2VuZXJhdGVzIGFuIHVuLWZpbHRlcmVkIGV2ZW50IHN0cmVhbSBsaXN0ZW5pbmcgdG8gZXZlcnkgbWVzc2FnZSBydW5uaW5nIGFjcm9zcyB0aGUgYnVzIGFyY2hpdGVjdHVyZS5cclxuICAgKiBQZXJmZWN0IGZvciBidWlsZGluZyBjZW50cmFsaXplZCBhdWRpdGluZyBlbmdpbmVzLCB0ZWxlbWV0cnkgbG9ncywgb3Igc3RhdGUgc3luY2hyb25pemVycy5cclxuICAgKiAqIEByZXR1cm5zIEFuIFJ4SlMgT2JzZXJ2YWJsZSBjYXRjaGluZyBhbGwgZXZlbnRzIG1vdmluZyBhY3Jvc3MgdGhlIGNoYW5uZWwgc3VyZmFjZS5cclxuICAgKi9cclxuICBwdWJsaWMgb25BbGwoKTogT2JzZXJ2YWJsZTxSb29tRXZlbnQ+IHtcclxuICAgIHJldHVybiB0aGlzLmV2ZW50c1N1YmplY3QuYXNPYnNlcnZhYmxlKCk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IFJvb21FdmVudEJ1cyB9IGZyb20gJy4uL2V2ZW50cy9yb29tLWV2ZW50LWJ1cyc7XHJcbmltcG9ydCB7IEVuY3J5cHRpb25FbmdpbmUgfSBmcm9tICcuLi9jcnlwdG8vZW5jcnlwdGlvbi1lbmdpbmUnO1xyXG5pbXBvcnQgeyBQc2J0VXRpbHMgfSBmcm9tICcuLi9iaXRjb2luL3BzYnQtdXRpbHMnO1xyXG5pbXBvcnQgeyBUcmFuc2FjdGlvbiB9IGZyb20gJ0BzY3VyZS9idGMtc2lnbmVyJztcclxuXHJcbi8qKlxyXG4gKiBBY3RpdmUgb3JjaGVzdHJhdG9yIGNsaWVudCByZXNwb25zaWJsZSBmb3IgZnVsbC1kdXBsZXggcm9vbSByZWxheSBjb21tdW5pY2F0aW9ucy5cclxuICogSGFuZGxlcyBjb250aW51b3VzIHN5bW1ldHJpYyBkYXRhIGVuY3J5cHRpb24gcGlwZWxpbmVzLCBXZWJTb2NrZXQgbmV0d29yayBjeWNsZXMsXHJcbiAqIGFuZCBtYXBwaW5nIGNyeXB0b2dyYXBoaWNhbGx5IGJsaW5kZWQgbXVsdGktc2lnIGRldmljZSBoYXJkd2FyZSBmaW5nZXJwcmludHMuXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgUmVsYXlDbGllbnQge1xyXG4gIC8qKiBUaGUgaW50ZXJuYWwgV2ViU29ja2V0IGNvbm5lY3Rpb24gaW5zdGFuY2UgdHJhY2tpbmcgYWN0aXZlIHNlcnZlciBwaXBlbGluZXMuICovXHJcbiAgcHJpdmF0ZSB3czogV2ViU29ja2V0IHwgbnVsbCA9IG51bGw7XHJcbiAgLyoqIFB1YmxpYyByZWFjdGl2ZSBtZXNzYWdlIGNoYW5uZWwgYnVzIGZvciBob3N0IGZyYW1ld29ya3MgKGxpa2UgQW5ndWxhcikgdG8gaG9vayBsaXN0ZW5lcnMuICovXHJcbiAgcHVibGljIGV2ZW50cyA9IG5ldyBSb29tRXZlbnRCdXMoKTtcclxuXHJcbiAgLyoqIFRoZSBzdGFuZGFyZCAyNTYtYml0IHN5bW1ldHJpYyBrZXkgY29uZmlndXJhdGlvbiB1dGlsaXplZCBmb3IgZW5jcnlwdGlvbiBib3VuZGFyaWVzLiAqL1xyXG4gIHByaXZhdGUgZW5jcnlwdGlvbktleTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcbiAgLyoqIExvY2FsIGNhY2hlIG1hcHBpbmcgYmxpbmRlZCBoZXgtc3RyaW5nIHRva2VucyBiYWNrIHRvIHBoeXNpY2FsIDgtY2hhcmFjdGVyIGhhcmR3YXJlIHdhbGxldCBmaW5nZXJwcmludHMuICovXHJcbiAgcHVibGljIGJsaW5kRmluZ2VycHJpbnRNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nPigpO1xyXG5cclxuICAvKipcclxuICAgKiBJbml0aWFsaXplcyBhIGZyZXNoIGluc3RhbmNlIG9mIHRoZSBSZWxheUNsaWVudCBjb29yZGluYXRpb24gbW9kdWxlLlxyXG4gICAqIEBwYXJhbSBjcnlwdG8gLSBUaGUgYWN0aXZlIGFic3RyYWN0aW9uIGVuZ2luZSBleGVjdXRpbmcgZW5jcnlwdGlvbi9kZWNyeXB0aW9uIHJlcXVlc3RzLlxyXG4gICAqL1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY3J5cHRvOiBFbmNyeXB0aW9uRW5naW5lKSB7fVxyXG5cclxuICAvKipcclxuICAgKiBEaXJlY3RseSBtYXBzIG9yIGZsdXNoZXMgdGhlIHN5bW1ldHJpYyBrZXkgdG9rZW4gYXBwbGllZCBhY3Jvc3Mgc3RhdGUgcGFyYW1ldGVycy5cclxuICAgKiBAcGFyYW0ga2V5IC0gVGhlIGJhc2U2NC1lbmNvZGVkIHNlY3JldCBwYXNzcGhyYXNlIG9yIG51bGwgdG8gcmV2b2tlIHBlcm1pc3Npb25zLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBzZXRLZXkoa2V5OiBzdHJpbmcgfCBudWxsKSB7XHJcbiAgICB0aGlzLmVuY3J5cHRpb25LZXkgPSBrZXk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBJbnN0YW50aWF0ZXMgYSBsaXZlIFdlYlNvY2tldCBzZXNzaW9uIHBvaW50aW5nIHRvIGEgdGFyZ2V0IHJlbGF5IGluc3RhbmNlLlxyXG4gICAqIEVzdGFibGlzaGVzIGxvdy1sZXZlbCBob29rcyByb3V0aW5nIHBsYXRmb3JtIGVycm9ycyBhbmQgc2VydmVyIGZyYW1lcyBjbGVhbmx5IGludG8gcmVhY3RpdmUgYnVzZXMuXHJcbiAgICogQHBhcmFtIHVybCAtIFRoZSBhYnNvbHV0ZSB0YXJnZXQgbG9jYXRpb24gcHJvdG9jb2wgc3RyaW5nIChlLmcuLCBgd3NzOi8vcmVsYXkuLi5gKS5cclxuICAgKi9cclxuICBwdWJsaWMgY29ubmVjdCh1cmw6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgdGhpcy5kaXNjb25uZWN0KHRydWUpO1xyXG4gICAgdGhpcy53cyA9IG5ldyBXZWJTb2NrZXQodXJsKTtcclxuXHJcbiAgICB0aGlzLndzLm9ub3BlbiA9ICgpID0+IHtcclxuICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1JPT01fQ09OTkVDVEVEJyk7XHJcbiAgICB9O1xyXG4gICAgdGhpcy53cy5vbmNsb3NlID0gKGUpID0+IHtcclxuICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1JPT01fRElTQ09OTkVDVEVEJywgeyBjb2RlOiBlLmNvZGUsIHJlYXNvbjogZS5yZWFzb24gfSk7XHJcblxyXG4gICAgICBpZiAoZS5jb2RlID09PSA0MDI2KSB7XHJcbiAgICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1BST1RPQ09MX0VSUk9SJywgeyB0eXBlOiAndmVyc2lvbl9taXNtYXRjaCcsIHJvb21WZXJzaW9uOiAnMS4wLjAnIH0pO1xyXG4gICAgICB9IGVsc2UgaWYgKGUuY29kZSA9PT0gNDAwMSkge1xyXG4gICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdQUk9UT0NPTF9FUlJPUicsIHsgdHlwZTogJ3Jvb21fZnVsbCcgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAoZS5jb2RlID09PSAxMDA2KSB7XHJcbiAgICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1BST1RPQ09MX0VSUk9SJywgeyB0eXBlOiAnYWNjZXNzX2RlbmllZCcgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAoZS5jb2RlID09PSA0MDA0KSB7XHJcbiAgICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1BST1RPQ09MX0VSUk9SJywgeyB0eXBlOiAnbm90X2ZvdW5kJyB9KTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIHRoaXMud3Mub25lcnJvciA9IChlKSA9PiB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnRVJST1InLCBlKTtcclxuXHJcbiAgICB0aGlzLndzLm9ubWVzc2FnZSA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IG1zZyA9IEpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5yb3V0ZU1lc3NhZ2UobXNnKTtcclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1JlbGF5Q2xpZW50OiBNZXNzYWdlIHBhcnNlIGVycm9yJywgZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBTYW5pdGl6ZXMga2V5IHBhcmFtZXRlcnMsIGNhbGN1bGF0ZXMgYWNjZXNzIHBhc3NlcywgYW5kIGpvaW5zIGEgdGFyZ2V0ZWQgY29sbGFib3JhdGlvbiBzZXNzaW9uLlxyXG4gICAqIEF1dG9tYXRpY2FsbHkgbm9ybWFsaXplcyBwZXJjZW50LWVuY29kZWQgYW5kIHdoaXRlc3BhY2UtcGFkZGVkIFVSTCBmcmFnbWVudHMuXHJcbiAgICogQHBhcmFtIHdzQmFzZVVybCAtIFRoZSByb290IHByb3RvY29sIGJhc2UgdGFyZ2V0IFVSTC5cclxuICAgKiBAcGFyYW0gcm9vbUlkIC0gVGhlIHRhcmdldCB3b3Jrc3BhY2Ugcm9vbSB1dWlkIHN0cmluZy5cclxuICAgKiBAcGFyYW0ga2V5IC0gVGhlIHJhdyBzeW1tZXRyaWMgd29ya3NwYWNlIGtleSBzdHJpbmcgYXJndW1lbnQuXHJcbiAgICogQHBhcmFtIHZlcnNpb24gLSBUaGUgY2xpZW50IHZlcnNpb24gaWRlbnRpZmllciBzdHJpbmcgY2hlY2tpbmcgYmFja2VuZCBjb21wYXRpYmlsaXR5LlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBqb2luUm9vbSh3c0Jhc2VVcmw6IHN0cmluZywgcm9vbUlkOiBzdHJpbmcsIGtleTogc3RyaW5nLCB2ZXJzaW9uOiBzdHJpbmcpIHtcclxuICAgIGxldCBjbGVhbktleSA9IGtleS50cmltKCk7XHJcblxyXG4gICAgaWYgKGNsZWFuS2V5LmluY2x1ZGVzKCclJykpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjbGVhbktleSA9IGRlY29kZVVSSUNvbXBvbmVudChjbGVhbktleSk7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZXRLZXkoY2xlYW5LZXkpO1xyXG5cclxuICAgIGNvbnN0IHJvb21QYXNzID0gY2xlYW5LZXkgPyBhd2FpdCB0aGlzLmNyeXB0by5ibGluZERhdGEocm9vbUlkLCBjbGVhbktleSkgOiAnJztcclxuICAgIGNvbnN0IHVybCA9IGAke3dzQmFzZVVybH0vYXBpL3Jvb20vJHtyb29tSWR9L3dlYnNvY2tldD92PSR7dmVyc2lvbn0mcGFzcz0ke3Jvb21QYXNzfWA7XHJcbiAgICB0aGlzLmNvbm5lY3QodXJsKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEJyZWFrcyBhY3RpdmUgc29ja2V0IHR1bm5lbHMgY2xlYW5seSBhbmQgZGUtYWxsb2NhdGVzIHBsYXRmb3JtIHN0YXRlIHJlZmVyZW5jZXMuXHJcbiAgICogQHBhcmFtIGNsZWFyTGlzdGVuZXJzIC0gU2V0IHRvIHRydWUgdG8gemVybyBvdXQgZXZlbnQgcHJvcGVydGllcyBwcmV2ZW50aW5nIGV4ZWN1dGlvbiBsZWFrYWdlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBkaXNjb25uZWN0KGNsZWFyTGlzdGVuZXJzID0gZmFsc2UpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLndzKSB7XHJcbiAgICAgIGlmIChjbGVhckxpc3RlbmVycykge1xyXG4gICAgICAgIHRoaXMud3Mub25jbG9zZSA9IG51bGw7XHJcbiAgICAgICAgdGhpcy53cy5vbmVycm9yID0gbnVsbDtcclxuICAgICAgICB0aGlzLndzLm9ubWVzc2FnZSA9IG51bGw7XHJcbiAgICAgICAgdGhpcy53cy5vbm9wZW4gPSBudWxsO1xyXG4gICAgICB9XHJcbiAgICAgIHRoaXMud3MuY2xvc2UoKTtcclxuICAgICAgdGhpcy53cyA9IG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBTZXJpYWxpemVzIGFuZCB3cml0ZXMgZGF0YSBvYmplY3RzIHRvIHRoZSBzZXJ2ZXIgc29ja2V0IHBpcGVsaW5lLlxyXG4gICAqIFNob3J0LWNpcmN1aXRzIGNvbXBsZXRlbHkgaWYgdGhlIHVuZGVybHlpbmcgc29ja2V0IHN0YXRlIGlzIG5vdCBleHBsaWNpdGx5IG9wZW4uXHJcbiAgICogQHBhcmFtIHR5cGUgLSBUaGUgb3V0Ym91bmQgZXZlbnQgdG9rZW4gYWN0aW9uIGhlYWRlci5cclxuICAgKiBAcGFyYW0gcGF5bG9hZCAtIE9wdGlvbmFsIGNvbnRlbnQgbWFwcGluZ3MgZGVmaW5pbmcgcGFyYW1ldGVycyBmb3IgdGhlIHJlcXVlc3RlZCBhY3Rpb24uXHJcbiAgICovXHJcbiAgcHVibGljIHNlbmQodHlwZTogc3RyaW5nLCBwYXlsb2FkOiBhbnkgPSB7fSk6IHZvaWQge1xyXG4gICAgaWYgKHRoaXMud3MgJiYgdGhpcy53cy5yZWFkeVN0YXRlID09PSBXZWJTb2NrZXQuT1BFTikge1xyXG4gICAgICB0aGlzLndzLnNlbmQoSlNPTi5zdHJpbmdpZnkoeyB0eXBlLCAuLi5wYXlsb2FkIH0pKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEV2YWx1YXRlcyBpbmNvbWluZyBtZXNzYWdlIHRvcGljcyBhbmQgaW52b2tlcyB0YXJnZXRlZCBzdHJ1Y3R1cmFsIHNvcnRpbmcgb3IgZGVjaXBoZXJpbmcgcGF0aHMuXHJcbiAgICogRGlzcGF0Y2hlcyB3YXJuaW5nIHRvcGljcyBpbW1lZGlhdGVseSBkb3duIHRoZSBidXMgbGluZSBpZiBzdHJ1Y3R1cmFsIHBheWxvYWRzIGVuY291bnRlciBtaXNzaW5nIGNvbnRleHQga2V5cy5cclxuICAgKiBAcGFyYW0gbXNnIC0gVGhlIHJhdyBwYXJzZWQgc2VydmVyIGZyYW1lIHBheWxvYWQgb2JqZWN0LlxyXG4gICAqL1xyXG4gIHByaXZhdGUgYXN5bmMgcm91dGVNZXNzYWdlKG1zZzogYW55KSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSAmJiAobXNnLmVuY3J5cHRlZFBzYnQgfHwgbXNnLnR5cGUgPT09ICdORVdfUEFSVElBTF9EQVRBJykpIHtcclxuICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ0RFQ1JZUFRJT05fRVJST1InLCAnRGVjcnlwdGlvbiBLZXkgTWlzc2luZycpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc3dpdGNoIChtc2cudHlwZSkge1xyXG4gICAgICBjYXNlICdTRVNTSU9OX0NPTk5FQ1RFRCc6XHJcbiAgICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1NFU1NJT05fQ09OTkVDVEVEJywgbXNnLnNlc3Npb25JZCk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ1NUQVRFX1NZTkMnOlxyXG4gICAgICAgIGNvbnN0IHN5bmNEYXRhID0gYXdhaXQgdGhpcy5wcm9jZXNzU3RhdGVTeW5jKG1zZyk7XHJcbiAgICAgICAgaWYgKHN5bmNEYXRhKSB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnU1RBVEVfU1lOQ19ERUNSWVBURUQnLCBzeW5jRGF0YSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ05FV19QQVJUSUFMX0RBVEEnOlxyXG4gICAgICAgIGNvbnN0IHBhcnRpYWxEYXRhID0gYXdhaXQgdGhpcy5wcm9jZXNzTmV3UGFydGlhbChtc2cpO1xyXG4gICAgICAgIGlmIChwYXJ0aWFsRGF0YSkgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ05FV19QQVJUSUFMX0RFQ1JZUFRFRCcsIHBhcnRpYWxEYXRhKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnTEFCRUxTX1VQREFURUQnOlxyXG4gICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdMQUJFTFNfREVDUllQVEVEJywgYXdhaXQgdGhpcy5kZWNyeXB0TGFiZWxzKG1zZy5zaWduZXJMYWJlbHMpKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnUk9PTV9SRU5BTUVEJzpcclxuICAgICAgICBpZiAobXNnLmVuY3J5cHRlZE5hbWUgJiYgdGhpcy5lbmNyeXB0aW9uS2V5KSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByb29tTmFtZSA9IGF3YWl0IHRoaXMuY3J5cHRvLmRlY3J5cHQobXNnLmVuY3J5cHRlZE5hbWUsIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgICAgICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdST09NX1JFTkFNRURfREVDUllQVEVEJywgcm9vbU5hbWUpO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdSZWxheTogRmFpbGVkIHRvIGRlY3J5cHQgcm9vbSBuYW1lJywgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdMT0dfVVBEQVRFJzpcclxuICAgICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaChcclxuICAgICAgICAgICdMT0dfVVBEQVRFX0RFQ1JZUFRFRCcsXHJcbiAgICAgICAgICBhd2FpdCB0aGlzLmRlY3J5cHRBdWRpdExvZyhtc2cuYXVkaXRMb2cgfHwgW10pLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ0NPTk5FQ1RJT05TX1VQREFURSc6XHJcbiAgICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ0NPTk5FQ1RJT05TX0RFQ1JZUFRFRCcsIHtcclxuICAgICAgICAgIGNvdW50OiBtc2cuY291bnQsXHJcbiAgICAgICAgICBzZXNzaW9uczogYXdhaXQgdGhpcy5kZWNyeXB0U2Vzc2lvbnMobXNnLnNlc3Npb25zKSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnUk9MRV9VUERBVEUnOlxyXG4gICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdST0xFX1VQREFURScsIG1zZy5yb2xlKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnUk9PTV9DTE9TRUQnOlxyXG4gICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdST09NX0NMT1NFRCcpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdXSElURUxJU1RfVVBEQVRFRCc6XHJcbiAgICAgICAgaWYgKG1zZy5lbmNyeXB0ZWRXaGl0ZWxpc3QgJiYgdGhpcy5lbmNyeXB0aW9uS2V5KSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCBkZWNXID0gYXdhaXQgdGhpcy5jcnlwdG8uZGVjcnlwdChtc2cuZW5jcnlwdGVkV2hpdGVsaXN0LCB0aGlzLmVuY3J5cHRpb25LZXkpO1xyXG4gICAgICAgICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnV0hJVEVMSVNUX0RFQ1JZUFRFRCcsIEpTT04ucGFyc2UoZGVjVykpO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdSZWxheTogRmFpbGVkIHRvIGRlY3J5cHQgd2hpdGVsaXN0JywgZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdQQVJUSUNJUEFOVFNfVVBEQVRFJzpcclxuICAgICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaChcclxuICAgICAgICAgICdQQVJUSUNJUEFOVFNfREVDUllQVEVEJyxcclxuICAgICAgICAgIGF3YWl0IHRoaXMuZGVjcnlwdFBhcnRpY2lwYW50cyhtc2cucGFydGljaXBhbnRzKSxcclxuICAgICAgICApO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdMT0NLX1VQREFURUQnOlxyXG4gICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdMT0NLX1VQREFURUQnLCBtc2cpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdUWF9GSU5BTElaRURfQlJPQURDQVNUJzpcclxuICAgICAgICBpZiAobXNnLmVuY3J5cHRlZEZpbmFsVHhIZXggJiYgbXNnLmVuY3J5cHRlZEZpbmFsVHhJZCAmJiB0aGlzLmVuY3J5cHRpb25LZXkpIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpbmFsVHhIZXggPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KFxyXG4gICAgICAgICAgICAgIG1zZy5lbmNyeXB0ZWRGaW5hbFR4SGV4LFxyXG4gICAgICAgICAgICAgIHRoaXMuZW5jcnlwdGlvbktleSxcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgY29uc3QgZmluYWxUeElkID0gYXdhaXQgdGhpcy5jcnlwdG8uZGVjcnlwdChtc2cuZW5jcnlwdGVkRmluYWxUeElkLCB0aGlzLmVuY3J5cHRpb25LZXkpO1xyXG4gICAgICAgICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnVFhfRklOQUxJWkVEX0RFQ1JZUFRFRCcsIHsgZmluYWxUeEhleCwgZmluYWxUeElkIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdSZWxheTogRmFpbGVkIHRvIGRlY3J5cHQgZmluYWwgdHgnLCBlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ0VSUk9SX0xPQ0tFRCc6XHJcbiAgICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1BST1RPQ09MX0VSUk9SJywgeyB0eXBlOiAnbG9ja2VkJyB9KTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnRVJST1JfTk9UX0ZPVU5EJzpcclxuICAgICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnUFJPVE9DT0xfRVJST1InLCB7IHR5cGU6ICdub3RfZm91bmQnIH0pO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdFUlJPUl9WRVJTSU9OX01JU01BVENIJzpcclxuICAgICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnUFJPVE9DT0xfRVJST1InLCB7XHJcbiAgICAgICAgICB0eXBlOiAndmVyc2lvbl9taXNtYXRjaCcsXHJcbiAgICAgICAgICByb29tVmVyc2lvbjogbXNnLnJvb21WZXJzaW9uLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdSQVdfTUVTU0FHRScsIG1zZyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBQYXJzZXMgY29tcGxldGUgcm9vbSBoaXN0b3J5IHBhY2thZ2VzLCBjb21iaW5pbmcgbXVsdGktc2lnIHNpZ24gZmlsZXMgYW5kIGNsZWFuaW5nIGxlZGdlciBtYXRyaWNlcy5cclxuICAgKiBAcGFyYW0gbXNnIC0gUmF3IGJsb2NrIHBheWxvYWQgbWFwcGluZyBjb25maWd1cmF0aW9uIHBhcmFtZXRlcnMuXHJcbiAgICogQHJldHVybnMgQSBQcm9taXNlIHJlc29sdmluZyB0byBzdHJ1Y3R1cmFsIGNvbXBvc2l0ZSBzdGF0ZSBtZXRyaWNzIG9yIG51bGwgaWYgZXhlY3V0aW9uIGVuY291bnRlcnMgZXJyb3JzLlxyXG4gICAqL1xyXG4gIHByaXZhdGUgYXN5bmMgcHJvY2Vzc1N0YXRlU3luYyhtc2c6IGFueSk6IFByb21pc2U8YW55IHwgbnVsbD4ge1xyXG4gICAgbGV0IG1hc3RlclBzYnQgPSAnJztcclxuICAgIHRyeSB7XHJcbiAgICAgIG1hc3RlclBzYnQgPSBtc2cuZW5jcnlwdGVkUHNidFxyXG4gICAgICAgID8gYXdhaXQgdGhpcy5jcnlwdG8uZGVjcnlwdChtc2cuZW5jcnlwdGVkUHNidCwgdGhpcy5lbmNyeXB0aW9uS2V5ISlcclxuICAgICAgICA6IG1zZy5wc2J0IHx8ICcnO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnREVDUllQVElPTl9FUlJPUicsICdJbnZhbGlkIGRlY3J5cHRpb24ga2V5IHByb3ZpZGVkLicpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBtYXN0ZXJQc2J0ID0gUHNidFV0aWxzLm5vcm1hbGl6ZShtYXN0ZXJQc2J0KTtcclxuICAgIGNvbnN0IGRlY3J5cHRlZEhpc3Rvcnk6IHN0cmluZ1tdID0gW107XHJcblxyXG4gICAgaWYgKG1zZy5zaWduYXR1cmVzPy5sZW5ndGgpIHtcclxuICAgICAgZm9yIChjb25zdCBzaWcgb2YgbXNnLnNpZ25hdHVyZXMpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgZW5jVGFyZ2V0ID0gc2lnPy5lbmNyeXB0ZWREYXRhIHx8IHNpZztcclxuICAgICAgICAgIGNvbnN0IGRlYyA9IGF3YWl0IHRoaXMuY3J5cHRvLmRlY3J5cHQoZW5jVGFyZ2V0LCB0aGlzLmVuY3J5cHRpb25LZXkhKTtcclxuICAgICAgICAgIGRlY3J5cHRlZEhpc3RvcnkucHVzaChQc2J0VXRpbHMubm9ybWFsaXplKGRlYykpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIGlmICh0eXBlb2Ygc2lnID09PSAnc3RyaW5nJykgZGVjcnlwdGVkSGlzdG9yeS5wdXNoKFBzYnRVdGlscy5ub3JtYWxpemUoc2lnKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1lcmdlZFBzYnQgPSBtYXN0ZXJQc2J0O1xyXG4gICAgZm9yIChjb25zdCBzaWdEYXRhIG9mIGRlY3J5cHRlZEhpc3RvcnkpIHtcclxuICAgICAgbWVyZ2VkUHNidCA9IFBzYnRVdGlscy5tZXJnZShtZXJnZWRQc2J0LCBzaWdEYXRhKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAobWVyZ2VkUHNidCkge1xyXG4gICAgICBhd2FpdCB0aGlzLnJlZ2lzdGVyQWxsRmluZ2VycHJpbnRzKG1lcmdlZFBzYnQpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGRlY3J5cHRlZExhYmVscyA9IGF3YWl0IHRoaXMuZGVjcnlwdExhYmVscyhtc2cuc2lnbmVyTGFiZWxzIHx8IHt9KTtcclxuICAgIGNvbnN0IGRlY3J5cHRlZExvZyA9IGF3YWl0IHRoaXMuZGVjcnlwdEF1ZGl0TG9nKG1zZy5hdWRpdExvZyB8fCBbXSk7XHJcbiAgICBjb25zdCBkZWNyeXB0ZWRQYXJ0aWNpcGFudHMgPSBhd2FpdCB0aGlzLmRlY3J5cHRQYXJ0aWNpcGFudHMobXNnLnBhcnRpY2lwYW50cyB8fCB7fSk7XHJcblxyXG4gICAgbGV0IGRlY3J5cHRlZFdoaXRlbGlzdDogc3RyaW5nW10gPSBbXTtcclxuICAgIGlmIChtc2cud2hpdGVsaXN0ICYmIHR5cGVvZiBtc2cud2hpdGVsaXN0ID09PSAnc3RyaW5nJykge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGRlY1cgPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KG1zZy53aGl0ZWxpc3QsIHRoaXMuZW5jcnlwdGlvbktleSEpO1xyXG4gICAgICAgIGRlY3J5cHRlZFdoaXRlbGlzdCA9IEpTT04ucGFyc2UoZGVjVyk7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdSZWxheTogRmFpbGVkIHRvIGRlY3J5cHQgd2hpdGVsaXN0IGluIHN5bmMnKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KG1zZy53aGl0ZWxpc3QpKSB7XHJcbiAgICAgIGRlY3J5cHRlZFdoaXRlbGlzdCA9IG1zZy53aGl0ZWxpc3Q7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IGRlY3J5cHRlZFJvb21OYW1lID0gJ1VudGl0bGVkIFJvb20nO1xyXG4gICAgaWYgKG1zZy5yb29tTmFtZSAmJiB0aGlzLmVuY3J5cHRpb25LZXkpIHtcclxuICAgICAgaWYgKG1zZy5yb29tTmFtZS5sZW5ndGggPj0gNDApIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgZGVjcnlwdGVkUm9vbU5hbWUgPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KG1zZy5yb29tTmFtZSwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBkZWNyeXB0ZWRSb29tTmFtZSA9IG1zZy5yb29tTmFtZTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZGVjcnlwdGVkUm9vbU5hbWUgPSBtc2cucm9vbU5hbWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBsZXQgZmluYWxUeEhleCA9IG1zZy5maW5hbFR4SGV4O1xyXG4gICAgbGV0IGZpbmFsVHhJZCA9IG1zZy5maW5hbFR4SWQ7XHJcbiAgICBpZiAobXNnLmVuY3J5cHRlZEZpbmFsVHhIZXggJiYgbXNnLmVuY3J5cHRlZEZpbmFsVHhJZCAmJiB0aGlzLmVuY3J5cHRpb25LZXkpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBmaW5hbFR4SGV4ID0gYXdhaXQgdGhpcy5jcnlwdG8uZGVjcnlwdChtc2cuZW5jcnlwdGVkRmluYWxUeEhleCwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgICAgICBmaW5hbFR4SWQgPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KG1zZy5lbmNyeXB0ZWRGaW5hbFR4SWQsIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdSZWxheTogRmFpbGVkIHRvIGRlY3J5cHQgZmluYWwgVFggZGF0YSBpbiBzeW5jJywgZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAuLi5tc2csXHJcbiAgICAgIHBzYnQ6IG1lcmdlZFBzYnQsXHJcbiAgICAgIHNpZ25hdHVyZXM6IGRlY3J5cHRlZEhpc3RvcnksXHJcbiAgICAgIHNpZ25lckxhYmVsczogT2JqZWN0LmtleXMoZGVjcnlwdGVkTGFiZWxzKS5sZW5ndGggPiAwID8gZGVjcnlwdGVkTGFiZWxzIDogbXNnLnNpZ25lckxhYmVscyxcclxuICAgICAgYXVkaXRMb2c6IGRlY3J5cHRlZExvZyxcclxuICAgICAgd2hpdGVsaXN0OiBkZWNyeXB0ZWRXaGl0ZWxpc3QsXHJcbiAgICAgIHBhcnRpY2lwYW50czpcclxuICAgICAgICBPYmplY3Qua2V5cyhkZWNyeXB0ZWRQYXJ0aWNpcGFudHMpLmxlbmd0aCA+IDBcclxuICAgICAgICAgID8gZGVjcnlwdGVkUGFydGljaXBhbnRzXHJcbiAgICAgICAgICA6IG1zZy5wYXJ0aWNpcGFudHMgfHwge30sXHJcbiAgICAgIHJvb21OYW1lOiBkZWNyeXB0ZWRSb29tTmFtZSxcclxuICAgICAgZmluYWxUeEhleDogZmluYWxUeEhleCxcclxuICAgICAgZmluYWxUeElkOiBmaW5hbFR4SWQsXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGVjcnlwdHMgaW5kaXZpZHVhbCBzdGFuZGFsb25lIGluY29taW5nIHVzZXIgc2lnbmF0dXJlIGZyYW1lcy5cclxuICAgKiBAcGFyYW0gbXNnIC0gVGhlIHBhcnRpYWwgZGF0YSBwYXlsb2FkIGNvbnRhaW5lci5cclxuICAgKiBAcmV0dXJucyBEZWNvZGVkIHN0cnVjdHVyYWwgbWFwcGluZyBwcm9wZXJ0aWVzIG9yIG51bGwgaWYgZW1wdHkuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhc3luYyBwcm9jZXNzTmV3UGFydGlhbChtc2c6IGFueSkge1xyXG4gICAgaWYgKCFtc2cuZGF0YT8uZW5jcnlwdGVkRGF0YSkgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBkZWNyeXB0ZWQgPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KG1zZy5kYXRhLmVuY3J5cHRlZERhdGEsIHRoaXMuZW5jcnlwdGlvbktleSEpO1xyXG4gICAgY29uc3QgcmVhbEZpbmdlcnByaW50ID0gdGhpcy5ibGluZEZpbmdlcnByaW50TWFwLmdldChtc2cuZmluZ2VycHJpbnQpIHx8IG1zZy5maW5nZXJwcmludDtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBkZWNyeXB0ZWRQc2J0OiBQc2J0VXRpbHMubm9ybWFsaXplKGRlY3J5cHRlZCksXHJcbiAgICAgIGZpbmdlcnByaW50OiByZWFsRmluZ2VycHJpbnQsXHJcbiAgICAgIHNlc3Npb25JZDogbXNnLnNlc3Npb25JZCxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBEZWNvZGVzIGlucHV0IHNjb3BlcyBpbnNpZGUgYSBQU0JUIG1hcCwgZXh0cmFjdGluZyBhbmQgY2FjaGluZyBoYXJkd2FyZSBCSVAzMiBzb3VyY2UgcGF0aHMuXHJcbiAgICogQHBhcmFtIHBzYnREYXRhIC0gVGFyZ2V0IHVuZW5jcnlwdGVkIHRyYW5zYWN0aW9uIGJhc2U2NCBzdHJpbmcuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhc3luYyByZWdpc3RlckFsbEZpbmdlcnByaW50cyhwc2J0RGF0YTogc3RyaW5nKSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgYnl0ZXMgPSBQc2J0VXRpbHMuZGVjb2RlKHBzYnREYXRhKTtcclxuICAgICAgY29uc3QgdHggPSBUcmFuc2FjdGlvbi5mcm9tUFNCVChieXRlcyk7XHJcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdHguaW5wdXRzTGVuZ3RoOyBpKyspIHtcclxuICAgICAgICBjb25zdCBpbnB1dCA9IHR4LmdldElucHV0KGkpO1xyXG4gICAgICAgIGlmIChpbnB1dC5iaXAzMkRlcml2YXRpb24pIHtcclxuICAgICAgICAgIGZvciAoY29uc3QgWywgbWV0YV0gb2YgaW5wdXQuYmlwMzJEZXJpdmF0aW9uKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZwID0gbWV0YS5maW5nZXJwcmludC50b1N0cmluZygxNikucGFkU3RhcnQoOCwgJzAnKTtcclxuICAgICAgICAgICAgY29uc3QgYmxpbmRlZCA9IGF3YWl0IHRoaXMuY3J5cHRvLmJsaW5kRGF0YShmcCwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgICAgICAgICAgdGhpcy5ibGluZEZpbmdlcnByaW50TWFwLnNldChibGluZGVkLCBmcCk7XHJcbiAgICAgICAgICAgIHRoaXMuYmxpbmRGaW5nZXJwcmludE1hcC5zZXQoZnAsIGZwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignUmVsYXk6IEZhaWxlZCB0byBwYXJzZSBmaW5nZXJwcmludHMnKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJlY29uc3RydWN0cyBoaXN0b3JpY2FsIGF1ZGl0IGVudHJpZXMsIGRlY2lwaGVyaW5nIGVuY3J5cHRlZCBkYXRhIHJvd3Mgc2VxdWVudGlhbGx5LlxyXG4gICAqIEBwYXJhbSBsb2dzIC0gQ29sbGVjdGlvbiBvZiBwbGFpbiBvciBlbmNyeXB0ZWQgdHJhY2tpbmcgaXRlbXMuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhc3luYyBkZWNyeXB0QXVkaXRMb2cobG9nczogYW55W10pOiBQcm9taXNlPGFueVtdPiB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSB8fCAhbG9ncyB8fCAhQXJyYXkuaXNBcnJheShsb2dzKSkgcmV0dXJuIFtdO1xyXG4gICAgY29uc3QgZGVjcnlwdGVkTG9nID0gW107XHJcblxyXG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGxvZ3MpIHtcclxuICAgICAgaWYgKCFpdGVtKSBjb250aW51ZTtcclxuICAgICAgY29uc3QgZW5jcnlwdGVkQmxvYiA9IHR5cGVvZiBpdGVtID09PSAnc3RyaW5nJyA/IGl0ZW0gOiBpdGVtLmVuY3J5cHRlZExvZ0Jsb2I7XHJcblxyXG4gICAgICBpZiAoZW5jcnlwdGVkQmxvYikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCBkZWMgPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KGVuY3J5cHRlZEJsb2IsIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgICAgICAgICBjb25zdCBlbnRyeSA9IEpTT04ucGFyc2UoZGVjKTtcclxuICAgICAgICAgIGlmIChlbnRyeSkgZGVjcnlwdGVkTG9nLnB1c2goZW50cnkpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIGRlY3J5cHRlZExvZy5wdXNoKHtcclxuICAgICAgICAgICAgdGltZXN0YW1wOiAwLFxyXG4gICAgICAgICAgICBldmVudDogJ0VuY3J5cHRlZCBEYXRhIChEZWNyeXB0aW9uIEZhaWxlZCknLFxyXG4gICAgICAgICAgICB1c2VyOiAnVW5rbm93bicsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSBpZiAoaXRlbS5ldmVudCAmJiBpdGVtLnVzZXIpIHtcclxuICAgICAgICBkZWNyeXB0ZWRMb2cucHVzaChpdGVtKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGRlY3J5cHRlZExvZ1xyXG4gICAgICAuZmlsdGVyKChlKSA9PiBlICE9PSBudWxsKVxyXG4gICAgICAuc29ydCgoYSwgYikgPT4gKGEudGltZXN0YW1wIHx8IDApIC0gKGIudGltZXN0YW1wIHx8IDApKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJlLWV2YWx1YXRlcyBzaWduZXIgdGFncywgbWF0Y2hpbmcgcmVhbCB3YWxsZXQgaWRzIHRvIHJlYWRhYmxlIGlkZW50aWZpZXJzLlxyXG4gICAqIEBwYXJhbSBlbmNyeXB0ZWRMYWJlbHMgLSBLZXkgdmFsdWUgbWFwcGluZyBjb25maWd1cmF0aW9uIHVzaW5nIGJsaW5kZWQgcHJvcGVydGllcy5cclxuICAgKi9cclxuICBwcml2YXRlIGFzeW5jIGRlY3J5cHRMYWJlbHMoXHJcbiAgICBlbmNyeXB0ZWRMYWJlbHM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sXHJcbiAgKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+PiB7XHJcbiAgICBjb25zdCBkZWNyeXB0ZWRMYWJlbHM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcclxuICAgIGlmICghZW5jcnlwdGVkTGFiZWxzIHx8ICF0aGlzLmVuY3J5cHRpb25LZXkpIHJldHVybiBkZWNyeXB0ZWRMYWJlbHM7XHJcblxyXG4gICAgZm9yIChjb25zdCBbYmxpbmRlZEZwLCBlbmNyeXB0ZWRMYWJlbF0gb2YgT2JqZWN0LmVudHJpZXMoZW5jcnlwdGVkTGFiZWxzKSkge1xyXG4gICAgICBjb25zdCByZWFsRnAgPSB0aGlzLmJsaW5kRmluZ2VycHJpbnRNYXAuZ2V0KGJsaW5kZWRGcCkgfHwgYmxpbmRlZEZwO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGRlY3J5cHRlZExhYmVsc1tyZWFsRnBdID1cclxuICAgICAgICAgIGVuY3J5cHRlZExhYmVsLmxlbmd0aCA+PSA0MFxyXG4gICAgICAgICAgICA/IGF3YWl0IHRoaXMuY3J5cHRvLmRlY3J5cHQoZW5jcnlwdGVkTGFiZWwsIHRoaXMuZW5jcnlwdGlvbktleSlcclxuICAgICAgICAgICAgOiBlbmNyeXB0ZWRMYWJlbDtcclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGRlY3J5cHRlZExhYmVsc1tyZWFsRnBdID0gZW5jcnlwdGVkTGFiZWw7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBkZWNyeXB0ZWRMYWJlbHM7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBEZWNvZGVzIGxpc3QgbWF0cmljZXMgdHJhY2tpbmcgY3VycmVudGx5IGNvbm5lY3RlZCB1c2VyIG1ldGFkYXRhIGlkZW50aXRpZXMuXHJcbiAgICogQHBhcmFtIHNlc3Npb25zIC0gQWN0aXZlIGNvbm5lY3Rpb24gYXJyYXkgcHJvZmlsZXMuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhc3luYyBkZWNyeXB0U2Vzc2lvbnMoc2Vzc2lvbnM6IGFueVtdKSB7XHJcbiAgICBpZiAoIXNlc3Npb25zIHx8ICF0aGlzLmVuY3J5cHRpb25LZXkpIHJldHVybiBbXTtcclxuICAgIHJldHVybiBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAgc2Vzc2lvbnMubWFwKGFzeW5jIChzOiBhbnkpID0+IHtcclxuICAgICAgICBsZXQgcGxhaW5OYW1lID0gdW5kZWZpbmVkO1xyXG4gICAgICAgIGlmIChzLmVuY3J5cHRlZERpc3BsYXlOYW1lKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBwbGFpbk5hbWUgPSBhd2FpdCB0aGlzLmNyeXB0by5kZWNyeXB0KHMuZW5jcnlwdGVkRGlzcGxheU5hbWUsIHRoaXMuZW5jcnlwdGlvbktleSEpO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBwbGFpbk5hbWUgPSAnRGVjcnlwdCBFcnJvcic7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB7IGlkOiBzLmlkLCByb2xlOiBzLnJvbGUsIGRpc3BsYXlOYW1lOiBwbGFpbk5hbWUgfTtcclxuICAgICAgfSksXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGVjb2RlcyBleHBsaWNpdCBoaXN0b3JpY2FsIHJlZ2lzdHJhdGlvbiBhcnJheXMgZGVmaW5pbmcgc3RydWN0dXJhbCB3b3Jrc3BhY2UgbWVtYmVyc2hpcCBwcm9maWxlcy5cclxuICAgKiBAcGFyYW0gcGFydGljaXBhbnRzIC0gTWFwIGRpY3Rpb25hcnkgY29udGFpbmluZyBhdXRob3JpemF0aW9uIHBhcmFtZXRlcnMuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBhc3luYyBkZWNyeXB0UGFydGljaXBhbnRzKHBhcnRpY2lwYW50czogYW55KSB7XHJcbiAgICBjb25zdCBkZWNQYXJ0czogUmVjb3JkPHN0cmluZywgYW55PiA9IHt9O1xyXG4gICAgaWYgKCFwYXJ0aWNpcGFudHMgfHwgIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuIGRlY1BhcnRzO1xyXG4gICAgZm9yIChjb25zdCBbc2lkLCBwRGF0YV0gb2YgT2JqZWN0LmVudHJpZXMocGFydGljaXBhbnRzKSkge1xyXG4gICAgICBsZXQgcGxhaW5OYW1lID0gdW5kZWZpbmVkO1xyXG4gICAgICBjb25zdCB0eXBlZFAgPSBwRGF0YSBhcyBhbnk7XHJcbiAgICAgIGlmICh0eXBlZFAuZW5jcnlwdGVkRGlzcGxheU5hbWUpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgcGxhaW5OYW1lID0gYXdhaXQgdGhpcy5jcnlwdG8uZGVjcnlwdCh0eXBlZFAuZW5jcnlwdGVkRGlzcGxheU5hbWUsIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgfVxyXG4gICAgICBkZWNQYXJ0c1tzaWRdID0geyAuLi50eXBlZFAsIGRpc3BsYXlOYW1lOiBwbGFpbk5hbWUgfTtcclxuICAgIH1cclxuICAgIHJldHVybiBkZWNQYXJ0cztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFBhY2tzIHVuaWZpZWQgYXVkaXRpbmcgbGluZXMgaW50byBiYXNlNjQgZW5jcnlwdGlvbnMgcmVhZHkgZm9yIHBsYXRmb3JtIHN5bmNocm9uaXphdGlvbi5cclxuICAgKiBAcGFyYW0gZXZlbnQgLSBDb3JlIHRpdGxlIHJlcHJlc2VudGluZyB0aGUgZXhlY3V0ZWQgbWV0aG9kLlxyXG4gICAqIEBwYXJhbSBkZXRhaWwgLSBJbmZvcm1hdGl2ZSBsb2cgY29udGV4dCBzdGF0ZW1lbnQgZGF0YS5cclxuICAgKiBAcGFyYW0gdXNlciAtIEh1bWFuIGhhbmRsZSB0cmlnZ2VyaW5nIHRoZSBhY3Rpb24gdGFzay5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgY3JlYXRlU2VjdXJlTG9nQmxvYihldmVudDogc3RyaW5nLCBkZXRhaWw6IHN0cmluZywgdXNlcjogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgIGlmICghdGhpcy5lbmNyeXB0aW9uS2V5KSByZXR1cm4gJyc7XHJcbiAgICBjb25zdCBsb2dFbnRyeSA9IHsgdGltZXN0YW1wOiBEYXRlLm5vdygpLCBldmVudCwgZGV0YWlsLCB1c2VyIH07XHJcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5jcnlwdG8uZW5jcnlwdChKU09OLnN0cmluZ2lmeShsb2dFbnRyeSksIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBFbmNyeXB0cyBhbmQgdHJhbnNtaXRzIGEgbGl2ZSBhY3Rpb24gbG9nIHRyYWNraW5nIHJlY29yZCBvdXQgdG8gdGhlIHNlcnZlciB3b3Jrc3BhY2UgcmVsYXkuXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIGxvZ0FjdGlvbihldmVudDogc3RyaW5nLCBkZXRhaWw6IHN0cmluZywgdXNlcjogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBlbmNyeXB0ZWRMb2dCbG9iID0gYXdhaXQgdGhpcy5jcmVhdGVTZWN1cmVMb2dCbG9iKGV2ZW50LCBkZXRhaWwsIHVzZXIpO1xyXG4gICAgdGhpcy5zZW5kKCdMT0dfQUNUSU9OJywgeyBlbmNyeXB0ZWRMb2dCbG9iIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUHJlcGFyZXMgYW5kIHVwbG9hZHMgYSBtdWx0aS1zaWcgc2lnbmF0dXJlIHBheWxvYWQgdG8gdGhlIHNlcnZlciBwaXBlbGluZS5cclxuICAgKiBAcGFyYW0gcGFydGlhbFBzYnRCYXNlNjQgLSBSYXcgc2lnbmVkIFBTQlQgZGF0YSByZXByZXNlbnRhdGlvbiBmcmFtZXdvcmsuXHJcbiAgICogQHBhcmFtIGZpbmdlcnByaW50IC0gQ29yZSA4LWNoYXJhY3RlciB3YWxsZXQgc3RyaW5nIGlkZW50aWZpZXIuXHJcbiAgICogQHBhcmFtIHVzZXIgLSBVc2VybmFtZSBpbmRpY2F0b3IgbG9nZ2luZyBleGVjdXRpb24gcHJvZmlsZXMuXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIHVwbG9hZFNpZ25hdHVyZShwYXJ0aWFsUHNidEJhc2U2NDogc3RyaW5nLCBmaW5nZXJwcmludDogc3RyaW5nLCB1c2VyOiBzdHJpbmcpIHtcclxuICAgIGlmICghdGhpcy5lbmNyeXB0aW9uS2V5KSByZXR1cm47XHJcbiAgICBjb25zdCBibGluZGVkRmluZ2VycHJpbnQgPSBhd2FpdCB0aGlzLmNyeXB0by5ibGluZERhdGEoZmluZ2VycHJpbnQsIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgICBjb25zdCBlbmNyeXB0ZWREYXRhID0gYXdhaXQgdGhpcy5jcnlwdG8uZW5jcnlwdChwYXJ0aWFsUHNidEJhc2U2NCwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgIGNvbnN0IGVuY3J5cHRlZExvZ0Jsb2IgPSBhd2FpdCB0aGlzLmNyZWF0ZVNlY3VyZUxvZ0Jsb2IoXHJcbiAgICAgICdTaWduYXR1cmUgVXBsb2FkZWQnLFxyXG4gICAgICBgU2lnbmVyOiAke2ZpbmdlcnByaW50fWAsXHJcbiAgICAgIHVzZXIsXHJcbiAgICApO1xyXG5cclxuICAgIHRoaXMuYmxpbmRGaW5nZXJwcmludE1hcC5zZXQoYmxpbmRlZEZpbmdlcnByaW50LCBmaW5nZXJwcmludCk7XHJcbiAgICB0aGlzLmJsaW5kRmluZ2VycHJpbnRNYXAuc2V0KGZpbmdlcnByaW50LCBmaW5nZXJwcmludCk7XHJcblxyXG4gICAgdGhpcy5zZW5kKCdVUExPQURfUEFSVElBTCcsIHtcclxuICAgICAgZmluZ2VycHJpbnQ6IGJsaW5kZWRGaW5nZXJwcmludCxcclxuICAgICAgZGF0YTogeyBlbmNyeXB0ZWREYXRhIH0sXHJcbiAgICAgIGVuY3J5cHRlZExvZ0Jsb2IsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFZhbGlkYXRlcyBleHBsaWNpdCBtYW5hZ2VtZW50IHRva2VucyBncmFudGluZyBlbGV2YXRlZCBjb29yZGluYXRvciBjb25maWd1cmF0aW9uIG9wdGlvbnMuXHJcbiAgICogQHBhcmFtIHNlY3VyZVRva2VuIC0gQWRtaW4gcGFzc3BocmFzZSBwYXlsb2FkIHN0cmluZy5cclxuICAgKi9cclxuICBwdWJsaWMgY2xhaW1Db29yZGluYXRvcihzZWN1cmVUb2tlbjogc3RyaW5nKSB7XHJcbiAgICBpZiAoc2VjdXJlVG9rZW4pIHRoaXMuc2VuZCgnQVVUSCcsIHsgdG9rZW46IHNlY3VyZVRva2VuLnRyaW0oKSB9KTtcclxuICB9XHJcblxyXG4gIC8qKiBTdWJtaXRzIGFuIGludGVudGlvbmFsIGluc3RydWN0aW9uIGZvcmNpbmcgdGhlIHJlbW90ZSBzZXJ2ZXIgaW5zdGFuY2UgdG8gY2xvc2UgY29tcGxldGVseS4gKi9cclxuICBwdWJsaWMgY2xvc2VSb29tKCkge1xyXG4gICAgdGhpcy5zZW5kKCdDTE9TRV9ST09NJyk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBFbWl0cyB0cmFpbGluZyBjb25uZWN0aW9uIHRlbGVtZXRyeSBvdXQgYmVmb3JlIGV4ZWN1dGluZyBsb3ctbGV2ZWwgV2ViU29ja2V0IHRlcm1pbmF0aW9uIHN0ZXBzLlxyXG4gICAqIEBwYXJhbSBzZXNzaW9uSWQgLSBTb2NrZXQgY29tbXVuaWNhdGlvbiBpZGVudGl0eSBoYW5kbGUgdHJhY2tpbmcgb3duZXJzaGlwLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBncmFjZWZ1bGx5RGlzY29ubmVjdChzZXNzaW9uSWQ6IHN0cmluZyB8IG51bGwpIHtcclxuICAgIGlmIChzZXNzaW9uSWQgJiYgdGhpcy53cyAmJiB0aGlzLndzLnJlYWR5U3RhdGUgPT09IFdlYlNvY2tldC5PUEVOKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgZW5jcnlwdGVkTG9nQmxvYiA9IGF3YWl0IHRoaXMuY3JlYXRlU2VjdXJlTG9nQmxvYihcclxuICAgICAgICAgICdVc2VyIExlZnQnLFxyXG4gICAgICAgICAgYFNlc3Npb24gSUQ6ICR7c2Vzc2lvbklkfWAsXHJcbiAgICAgICAgICAnR3Vlc3QnLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgdGhpcy5zZW5kKCdMT0dfQUNUSU9OJywgeyBlbmNyeXB0ZWRMb2dCbG9iIH0pO1xyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIHNlbmQgZGlzY29ubmVjdCBsb2cnKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLmRpc2Nvbm5lY3QoKSwgNTApO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTXV0YXRlcyBhY3RpdmUgcm9vbSBkZXNjcmlwdGlvbnMsIGRpc3BhdGNoaW5nIGNvcnJlc3BvbmRpbmcgZW5jcnlwdGVkIGxvZ3Mgb3V0IHRvIG9ic2VydmVycy5cclxuICAgKiBAcGFyYW0gbmV3TmFtZSAtIFRhcmdldCBjbGVhcnRleHQgdGl0bGUgc3RyaW5nLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyByZW5hbWVSb29tKG5ld05hbWU6IHN0cmluZywgdXNlcjogc3RyaW5nKSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuO1xyXG4gICAgY29uc3QgZW5jcnlwdGVkTmFtZSA9IGF3YWl0IHRoaXMuY3J5cHRvLmVuY3J5cHQobmV3TmFtZSwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgIGNvbnN0IGVuY3J5cHRlZExvZ0Jsb2IgPSBhd2FpdCB0aGlzLmNyZWF0ZVNlY3VyZUxvZ0Jsb2IoXHJcbiAgICAgICdSb29tIFJlbmFtZWQnLFxyXG4gICAgICBgUmVuYW1lZDogJHtuZXdOYW1lfWAsXHJcbiAgICAgIHVzZXIsXHJcbiAgICApO1xyXG4gICAgdGhpcy5zZW5kKCdSRU5BTUVfUk9PTScsIHsgZW5jcnlwdGVkTmFtZSwgZW5jcnlwdGVkTG9nQmxvYiB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIE92ZXJ3cml0ZXMgbWV0YWRhdGEgZGVzY3JpcHRpb25zIGxpbmtpbmcgc3BlY2lhbGl6ZWQgbXVsdGktc2lnIGhhcmR3YXJlIHByb2ZpbGVzIHRvIGN1c3RvbSBuYW1lcy5cclxuICAgKiBAcGFyYW0gZmluZ2VycHJpbnQgLSBIYXJkd2FyZSB3YWxsZXQgdHJhY2tpbmcgcmVmZXJlbmNlIHN0cmluZy5cclxuICAgKiBAcGFyYW0gbGFiZWwgLSBDdXN0b20gdXNlciBpZGVudGlmaWNhdGlvbiBuaWNrbmFtZSBtYXBwaW5nIHN0cmluZy5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgdXBkYXRlU2lnbmVyTGFiZWwoZmluZ2VycHJpbnQ6IHN0cmluZywgbGFiZWw6IHN0cmluZywgdXNlcjogc3RyaW5nKSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuO1xyXG4gICAgY29uc3Qgc2FmZUxhYmVsID0gbGFiZWwgfHwgJyc7XHJcbiAgICBjb25zdCBibGluZGVkRmluZ2VycHJpbnQgPSBhd2FpdCB0aGlzLmNyeXB0by5ibGluZERhdGEoZmluZ2VycHJpbnQsIHRoaXMuZW5jcnlwdGlvbktleSk7XHJcbiAgICBjb25zdCBlbmNyeXB0ZWRMYWJlbCA9IGF3YWl0IHRoaXMuY3J5cHRvLmVuY3J5cHQoc2FmZUxhYmVsLCB0aGlzLmVuY3J5cHRpb25LZXkpO1xyXG4gICAgY29uc3QgZW5jcnlwdGVkTG9nQmxvYiA9IGF3YWl0IHRoaXMuY3JlYXRlU2VjdXJlTG9nQmxvYihcclxuICAgICAgJ0xhYmVsIFVwZGF0ZWQnLFxyXG4gICAgICBgJHtzYWZlTGFiZWx9ICgke2ZpbmdlcnByaW50fSlgLFxyXG4gICAgICB1c2VyLFxyXG4gICAgKTtcclxuXHJcbiAgICB0aGlzLmJsaW5kRmluZ2VycHJpbnRNYXAuc2V0KGJsaW5kZWRGaW5nZXJwcmludCwgZmluZ2VycHJpbnQpO1xyXG4gICAgdGhpcy5zZW5kKCdVUERBVEVfTEFCRUwnLCB7XHJcbiAgICAgIGZpbmdlcnByaW50OiBibGluZGVkRmluZ2VycHJpbnQsXHJcbiAgICAgIGxhYmVsOiBlbmNyeXB0ZWRMYWJlbCxcclxuICAgICAgZW5jcnlwdGVkTG9nQmxvYixcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogTW9kaWZpZXMgdGhlIGxvY2FsIHNlc3Npb24gdXNlcidzIGRpc3BsYXkgbmFtZSBicm9hZGNhc3QgdG8gb3RoZXIgY29sbGFib3JhdGl2ZSByb29tIHBlZXJzLlxyXG4gICAqIEBwYXJhbSBuYW1lIC0gUmF3IGFscGhhbnVtZXJpYyBkaXNwbGF5IG5pY2tuYW1lLiBFbXB0eSBvciBjbGVhbiBtYXBwaW5ncyBzZW5kIG51bGwgdmFsdWUgaW5kaWNhdG9ycy5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgc2V0RGlzcGxheU5hbWUobmFtZTogc3RyaW5nKSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuO1xyXG4gICAgY29uc3Qgc2FmZU5hbWUgPSBuYW1lLnRyaW0oKS5zdWJzdHJpbmcoMCwgNjQpO1xyXG4gICAgaWYgKHNhZmVOYW1lKSB7XHJcbiAgICAgIGNvbnN0IGVuY3J5cHRlZERpc3BsYXlOYW1lID0gYXdhaXQgdGhpcy5jcnlwdG8uZW5jcnlwdChzYWZlTmFtZSwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgICAgdGhpcy5zZW5kKCdTRVRfRElTUExBWV9OQU1FJywgeyBlbmNyeXB0ZWREaXNwbGF5TmFtZSB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuc2VuZCgnU0VUX0RJU1BMQVlfTkFNRScsIHsgZW5jcnlwdGVkRGlzcGxheU5hbWU6IG51bGwgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBVcGRhdGVzIGF1dGhvcml6YXRpb24gbWF0cmljZXMgY29udHJvbGxpbmcgY29sbGFib3JhdGl2ZSBhY2Nlc3MgbGlzdHMuXHJcbiAgICogQHBhcmFtIG5ld0xpc3QgLSBQbGFpbiB0ZXh0IGFycmF5cyBob3VzaW5nIHZlcmlmaWVkIGF1dGhvcml6YXRpb24gZGVzY3JpcHRvcnMuXHJcbiAgICogQHBhcmFtIGFjdGlvbkRldGFpbCAtIERlc2NyaXB0aXZlIGFjdGlvbiBsZWRnZXIgZXhwbGFuYXRpb24gdHJhY2tpbmcgdGhlIHJ1bGUgY2hhbmdlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyB1cGRhdGVXaGl0ZWxpc3QobmV3TGlzdDogc3RyaW5nW10sIGFjdGlvbkRldGFpbDogc3RyaW5nLCB1c2VyOiBzdHJpbmcpIHtcclxuICAgIGlmICghdGhpcy5lbmNyeXB0aW9uS2V5KSByZXR1cm47XHJcbiAgICBjb25zdCBlbmNyeXB0ZWRXaGl0ZWxpc3QgPSBhd2FpdCB0aGlzLmNyeXB0by5lbmNyeXB0KFxyXG4gICAgICBKU09OLnN0cmluZ2lmeShuZXdMaXN0KSxcclxuICAgICAgdGhpcy5lbmNyeXB0aW9uS2V5LFxyXG4gICAgKTtcclxuICAgIGNvbnN0IGVuY3J5cHRlZExvZ0Jsb2IgPSBhd2FpdCB0aGlzLmNyZWF0ZVNlY3VyZUxvZ0Jsb2IoXHJcbiAgICAgICdXaGl0ZWxpc3QgVXBkYXRlZCcsXHJcbiAgICAgIGFjdGlvbkRldGFpbCxcclxuICAgICAgdXNlcixcclxuICAgICk7XHJcbiAgICB0aGlzLnNlbmQoJ1VQREFURV9XSElURUxJU1QnLCB7IGVuY3J5cHRlZFdoaXRlbGlzdCwgZW5jcnlwdGVkTG9nQmxvYiB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENvbnRyb2xzIHdvcmtzcGFjZSBpbnRlcmFjdGlvbiBjb25zdHJhaW50cywgcHJldmVudGluZyBvciBwZXJtaXR0aW5nIG9wZXJhdGlvbnMgZHluYW1pY2FsbHkuXHJcbiAgICogQHBhcmFtIGlzTG9ja2VkIC0gRXZhbHVhdGlvbiBjb25kaXRpb24gZmxhZyBjaGVja2luZyBzdGF0ZSBsb2Nrcy5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgdG9nZ2xlTG9jayhpc0xvY2tlZDogYm9vbGVhbiwgdXNlcjogc3RyaW5nKSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuO1xyXG4gICAgY29uc3QgYWN0aW9uRGV0YWlsID0gaXNMb2NrZWQgPyAnQ29vcmRpbmF0b3IgbG9ja2VkIHRoZSByb29tJyA6ICdDb29yZGluYXRvciB1bmxvY2tlZCB0aGUgcm9vbSc7XHJcbiAgICBjb25zdCBlbmNyeXB0ZWRMb2dCbG9iID0gYXdhaXQgdGhpcy5jcmVhdGVTZWN1cmVMb2dCbG9iKCdSb29tIExvY2tlZCcsIGFjdGlvbkRldGFpbCwgdXNlcik7XHJcbiAgICB0aGlzLnNlbmQoJ1RPR0dMRV9MT0NLJywgeyBpc0xvY2tlZCwgZW5jcnlwdGVkTG9nQmxvYiB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFB1Ymxpc2hlcyBjb21wbGV0ZSBhc3NlbWJsZWQgdHJhbnNhY3Rpb24gcHJvZmlsZXMgb3V0IHRvIGFjdGl2ZSBzZXNzaW9uIGluc3RhbmNlcy5cclxuICAgKiBAcGFyYW0gZmluYWxUeEhleCAtIENvbXBsZXRlIHNlcmlhbGl6ZWQgcmVhZHktdG8tYnJvYWRjYXN0IGJpdGNvaW4gaGV4IG1hdHJpeCBmb3JtYXQuXHJcbiAgICogQHBhcmFtIGZpbmFsVHhJZCAtIFVuaXF1ZSB0cmFja2luZyB0cmFuc2FjdGlvbmFsIGNoYWluIElELlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBicm9hZGNhc3RGaW5hbGl6YXRpb24oZmluYWxUeEhleDogc3RyaW5nLCBmaW5hbFR4SWQ6IHN0cmluZywgdXNlcjogc3RyaW5nKSB7XHJcbiAgICBpZiAoIXRoaXMuZW5jcnlwdGlvbktleSkgcmV0dXJuO1xyXG4gICAgY29uc3QgZW5jcnlwdGVkRmluYWxUeEhleCA9IGF3YWl0IHRoaXMuY3J5cHRvLmVuY3J5cHQoZmluYWxUeEhleCwgdGhpcy5lbmNyeXB0aW9uS2V5KTtcclxuICAgIGNvbnN0IGVuY3J5cHRlZEZpbmFsVHhJZCA9IGF3YWl0IHRoaXMuY3J5cHRvLmVuY3J5cHQoZmluYWxUeElkLCB0aGlzLmVuY3J5cHRpb25LZXkpO1xyXG4gICAgY29uc3QgZW5jcnlwdGVkTG9nQmxvYiA9IGF3YWl0IHRoaXMuY3JlYXRlU2VjdXJlTG9nQmxvYihcclxuICAgICAgJ1R4IEZpbmFsaXplZCcsXHJcbiAgICAgICdTaWduYXR1cmVzIG1lcmdlZCBzdWNjZXNzZnVsbHknLFxyXG4gICAgICB1c2VyLFxyXG4gICAgKTtcclxuICAgIHRoaXMuc2VuZCgnVFhfRklOQUxJWkVEJywgeyBlbmNyeXB0ZWRGaW5hbFR4SGV4LCBlbmNyeXB0ZWRGaW5hbFR4SWQsIGVuY3J5cHRlZExvZ0Jsb2IgfSk7XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IFJvb21FdmVudEJ1cyB9IGZyb20gJy4uL2V2ZW50cy9yb29tLWV2ZW50LWJ1cyc7XHJcbmltcG9ydCB7IFBzYnRVdGlscyB9IGZyb20gJy4uL2JpdGNvaW4vcHNidC11dGlscyc7XHJcblxyXG4vKipcclxuICogTWV0YWRhdGEgcmVjb3JkIGRlcGljdGluZyBhIGRpc3RpbmN0IGFjdGlvbiBvciBvcGVyYXRpb25hbCBzdGVwIHdpdGhpbiB0aGUgd29ya3NwYWNlLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBBdWRpdEVudHJ5IHtcclxuICAvKiogVW5peCBtaWxsaXNlY29uZCBlcG9jaCB0aW1lc3RhbXAgdHJhY2tpbmcgZXhlY3V0aW9uIGVudHJ5IHJ1bnRpbWUuICovXHJcbiAgdGltZXN0YW1wOiBudW1iZXI7XHJcbiAgLyoqIFByaW1hcnkgZXZlbnQgaWRlbnRpZmllciBzdHJpbmcgZGVzY3JpcHRpb24gdGFnLiAqL1xyXG4gIGV2ZW50OiBzdHJpbmc7XHJcbiAgLyoqIFVuZW5jcnlwdGVkIGh1bWFuLXJlYWRhYmxlIGRldGFpbHMgYWJvdXQgdGhlIGF1ZGl0IG9wZXJhdGlvbiBpZiBhdmFpbGFibGUuICovXHJcbiAgZGV0YWlsPzogc3RyaW5nO1xyXG4gIC8qKiBTZWN1cmVseSBlbmNyeXB0ZWQgZGV0YWlsIHBhY2thZ2UgcGF5bG9hZCBzdHJpbmcuICovXHJcbiAgZW5jcnlwdGVkRGV0YWlsPzogc3RyaW5nO1xyXG4gIC8qKiBJZGVudGl0eSBoYW5kbGUgb3Igcm9sZSBsYWJlbCBpbmRpY2F0aW5nIHRoZSBvcGVyYXRpb25hbCBwYXJ0aWNpcGFudCBhY3Rvci4gKi9cclxuICB1c2VyOiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDb21wbGV0ZSBpbnRlcm5hbCBhcHBsaWNhdGlvbiBtZW1vcnkgcmVwcmVzZW50YXRpb24gb2YgYSBjb2xsYWJvcmF0aXZlIHNpZ25pbmcgY2hhbWJlciBzZXNzaW9uLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBSb29tU3RhdGUge1xyXG4gIC8qKiBTZW1hbnRpYyB2ZXJzaW9uIHN0cmluZyBzcGVjaWZ5aW5nIHN0cnVjdHVyYWwgdmFsaWRhdGlvbiBleHBlY3RhdGlvbnMuICovXHJcbiAgcHJvdG9jb2xWZXJzaW9uOiBzdHJpbmc7XHJcbiAgLyoqIFRoZSB1bmlxdWUgc3RyaW5nIHRyYWNraW5nIGlkZW50aWZpZXIgZm9yIHRoZSBzZXNzaW9uIHJvb20gc3BhY2UuICovXHJcbiAgcm9vbUlkOiBzdHJpbmc7XHJcbiAgLyoqIERlc2NyaXB0aXZlIG5hbWUgb3Igc3RydWN0dXJhbCB0ZXh0IGxhYmVsIGFzc2lnbmVkIHRvIHRoZSByb29tIHdvcmtzcGFjZS4gKi9cclxuICByb29tTmFtZTogc3RyaW5nO1xyXG4gIC8qKiBCbG9ja2NoYWluIGV4ZWN1dGlvbiBjb250ZXh0IHBhcmFtZXRlcnMgY29uc3RyYWludCB0YWcuICovXHJcbiAgbmV0d29yazogJ2JpdGNvaW4nIHwgJ3Rlc3RuZXQnIHwgJ3NpZ25ldCc7XHJcbiAgLyoqIFRoZSBjb3JlIHBhcnRpYWxseSBzaWduZWQgYml0Y29pbiB0cmFuc2FjdGlvbiBtYXRyaXggc3RyaW5nLiAqL1xyXG4gIHBzYnQ6IHN0cmluZztcclxuICAvKiogQSBjb2xsZWN0aW9uIG9mIGluZGl2aWR1YWwgY3J5cHRvZ3JhcGhpYyBwYXJ0aWFsIHNpZ25hdHVyZXMgY29sbGVjdGVkIGZyb20gcm9vbSBtZW1iZXJzLiAqL1xyXG4gIHNpZ25hdHVyZXM6IHN0cmluZ1tdO1xyXG4gIC8qKiBUaGUgZnVsbHkgY29uc3RydWN0ZWQsIHNlcmlhbGl6ZWQgbmV0d29yayB0cmFuc2FjdGlvbiBwYXlsb2FkIHN0cmluZyBpZiBmaW5hbGl6ZWQuICovXHJcbiAgZmluYWxUeEhleD86IHN0cmluZztcclxuICAvKiogVGhlIHJlc3VsdGluZyB1bmlxdWUgVFhJRCBzdHJpbmcgaWRlbnRpZnlpbmcgdGhlIHRyYW5zYWN0aW9uIHBheWxvYWQgb24tY2hhaW4uICovXHJcbiAgZmluYWxUeElkPzogc3RyaW5nO1xyXG4gIC8qKiBMaXZlIGNvdW50ZXIgdHJhY2tpbmcgYWN0aXZlIHNvY2tldCBzb2NrZXQgY29ubmVjdGlvbiBpbnN0YW5jZXMuICovXHJcbiAgY29ubmVjdGVkQ291bnQ6IG51bWJlcjtcclxuICAvKiogVW5peCBtaWxsaXNlY29uZCB0aW1lc3RhbXAgcGlucG9pbnRpbmcgd29ya3NwYWNlIGluaXRpYWxpemF0aW9uLiAqL1xyXG4gIGNyZWF0ZWRBdDogbnVtYmVyO1xyXG4gIC8qKiBVbml4IG1pbGxpc2Vjb25kIHRpbWVzdGFtcCBzaWduYWxpbmcgd29ya3NwYWNlIGV2aWN0aW9uIGNyaXRlcmlhLiAqL1xyXG4gIGV4cGlyZXNBdDogbnVtYmVyO1xyXG4gIC8qKiBGbGFnIHJlc3RyaWN0aW5nIGluY29taW5nIHVzZXIgcmVnaXN0cmF0aW9ucyBvciB0cmFuc2FjdGlvbiBzdGF0ZSBhZGp1c3RtZW50cy4gKi9cclxuICBpc0xvY2tlZDogYm9vbGVhbjtcclxuICAvKiogQ2hyb25vbG9naWNhbCBsZWRnZXIgc2VxdWVuY2UgY2FjaGluZyBhY3Rpb25zIHBlcmZvcm1lZCBpbnNpZGUgdGhlIG1vZHVsZSBlbnZpcm9ubWVudC4gKi9cclxuICBhdWRpdExvZzogQXVkaXRFbnRyeVtdO1xyXG4gIC8qKiBDcnlwdG9ncmFwaGljIGhhcmR3YXJlIGtleSBpZGVudGlmaWVycyBtYXRjaGVkIGFnYWluc3QgaHVtYW4tcmVhZGFibGUgY3VzdG9tIGFsaWFzZXMuICovXHJcbiAgc2lnbmVyTGFiZWxzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xyXG4gIC8qKiBFeHBsaWNpdCBsaXN0IGNvbnRhaW5pbmcgYXV0aG9yaXplZCBwdWJsaWMgYWNjZXNzIGtleXMgcGVybWl0dGVkIGluc2lkZSB0aGUgd29ya3NwYWNlLiAqL1xyXG4gIHdoaXRlbGlzdDogc3RyaW5nW107XHJcbiAgLyoqIERpY3Rpb25hcnkgY2FjaGluZyBhY3RpdmUgcGFydGljaXBhbnQgZW50aXRpZXMgdHJhY2tlZCBieSB1bmlxdWUgcHVibGljIGlkZW50aWZpZXJzLiAqL1xyXG4gIHBhcnRpY2lwYW50cz86IFJlY29yZDxcclxuICAgIHN0cmluZyxcclxuICAgIHsgaWQ6IHN0cmluZzsgcm9sZTogc3RyaW5nOyBlbmNyeXB0ZWREaXNwbGF5TmFtZT86IHN0cmluZzsgZGlzcGxheU5hbWU/OiBzdHJpbmcgfVxyXG4gID47XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTdGF0ZSBjb250YWluZXIgbWFuYWdpbmcgcmVhY3RpdmUgcmVhZCwgd3JpdGUsIGluaXRpYWxpemF0aW9uLCBhbmQgc3luYyBjb25maWd1cmF0aW9uc1xyXG4gKiBmb3IgbGl2ZSBzaWduYXR1cmUgbXVsdGktc2lnIHNlc3Npb25zLiBMaXN0ZW5zIHRvIHNwZWNpYWxpemVkIHRvcGljIGJvdW5kYXJpZXMgb24gdGhlXHJcbiAqIGdsb2JhbCBidXMgY2hhbm5lbCBhbmQgdXBkYXRlcyBkYXRhIHByb2ZpbGVzIHNlYW1sZXNzbHkuXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgUm9vbVN0YXRlU3RvcmUge1xyXG4gIC8qKiBUaGUgY3VycmVudCBhY3RpdmUgbWVtb3J5IGFsbG9jYXRpb24gdHJlZSBsYXllciBtYXBwaW5nIHN0YXRlIG1ldHJpY3MuICovXHJcbiAgcHJpdmF0ZSBzdGF0ZTogUm9vbVN0YXRlIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIC8qKlxyXG4gICAqIEluaXRpYWxpemVzIHN0YXRlIGxheW91dCBzdHJlYW1zIGFuZCBlc3RhYmxpc2hlcyBpbXBsaWNpdCBldmVudCBidXMgc3Vic2NyaXB0aW9uIGhhbmRsZXJzLlxyXG4gICAqIEBwYXJhbSBldmVudHMgLSBUaGUgY2VudHJhbCBkZWNvdXBsZWQgbWVzc2FnaW5nIGludGVyZmFjZSBzeXN0ZW0gbGF5ZXIuXHJcbiAgICovXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBldmVudHM6IFJvb21FdmVudEJ1cykge1xyXG4gICAgdGhpcy5ldmVudHMub24oJ1NUQVRFX1NZTkNfREVDUllQVEVEJykuc3Vic2NyaWJlKChlKSA9PiB0aGlzLnN5bmMoZS5wYXlsb2FkKSk7XHJcbiAgICB0aGlzLmV2ZW50cy5vbignTkVXX1BBUlRJQUxfREVDUllQVEVEJykuc3Vic2NyaWJlKChlKSA9PiB0aGlzLm1lcmdlKGUucGF5bG9hZCkpO1xyXG4gICAgdGhpcy5ldmVudHMub24oJ0xPQ0tfVVBEQVRFRCcpLnN1YnNjcmliZSgoZSkgPT4ge1xyXG4gICAgICBjb25zdCBpc0xvY2tlZCA9IHR5cGVvZiBlLnBheWxvYWQ/LmlzTG9ja2VkID09PSAnYm9vbGVhbicgPyBlLnBheWxvYWQuaXNMb2NrZWQgOiBlLnBheWxvYWQ7XHJcbiAgICAgIHRoaXMudXBkYXRlUGFydGlhbCh7IGlzTG9ja2VkIH0pO1xyXG4gICAgfSk7XHJcbiAgICB0aGlzLmV2ZW50c1xyXG4gICAgICAub24oJ0xBQkVMU19ERUNSWVBURUQnKVxyXG4gICAgICAuc3Vic2NyaWJlKChlKSA9PiB0aGlzLnVwZGF0ZVBhcnRpYWwoeyBzaWduZXJMYWJlbHM6IGUucGF5bG9hZCB9KSk7XHJcbiAgICB0aGlzLmV2ZW50c1xyXG4gICAgICAub24oJ1JPT01fUkVOQU1FRF9ERUNSWVBURUQnKVxyXG4gICAgICAuc3Vic2NyaWJlKChlKSA9PiB0aGlzLnVwZGF0ZVBhcnRpYWwoeyByb29tTmFtZTogZS5wYXlsb2FkIH0pKTtcclxuICAgIHRoaXMuZXZlbnRzXHJcbiAgICAgIC5vbignTE9HX1VQREFURV9ERUNSWVBURUQnKVxyXG4gICAgICAuc3Vic2NyaWJlKChlKSA9PiB0aGlzLnVwZGF0ZVBhcnRpYWwoeyBhdWRpdExvZzogZS5wYXlsb2FkIH0pKTtcclxuICAgIHRoaXMuZXZlbnRzXHJcbiAgICAgIC5vbignV0hJVEVMSVNUX0RFQ1JZUFRFRCcpXHJcbiAgICAgIC5zdWJzY3JpYmUoKGUpID0+IHRoaXMudXBkYXRlUGFydGlhbCh7IHdoaXRlbGlzdDogZS5wYXlsb2FkIH0pKTtcclxuICAgIHRoaXMuZXZlbnRzXHJcbiAgICAgIC5vbignUEFSVElDSVBBTlRTX0RFQ1JZUFRFRCcpXHJcbiAgICAgIC5zdWJzY3JpYmUoKGUpID0+IHRoaXMudXBkYXRlUGFydGlhbCh7IHBhcnRpY2lwYW50czogZS5wYXlsb2FkIH0pKTtcclxuICAgIHRoaXMuZXZlbnRzXHJcbiAgICAgIC5vbignQ09OTkVDVElPTlNfREVDUllQVEVEJylcclxuICAgICAgLnN1YnNjcmliZSgoZSkgPT4gdGhpcy51cGRhdGVQYXJ0aWFsKHsgY29ubmVjdGVkQ291bnQ6IGUucGF5bG9hZC5jb3VudCB9KSk7XHJcbiAgICB0aGlzLmV2ZW50cy5vbignVFhfRklOQUxJWkVEX0RFQ1JZUFRFRCcpLnN1YnNjcmliZSgoZSkgPT5cclxuICAgICAgdGhpcy51cGRhdGVQYXJ0aWFsKHtcclxuICAgICAgICBmaW5hbFR4SGV4OiBlLnBheWxvYWQuZmluYWxUeEhleCxcclxuICAgICAgICBmaW5hbFR4SWQ6IGUucGF5bG9hZC5maW5hbFR4SWQsXHJcbiAgICAgIH0pLFxyXG4gICAgKTtcclxuICAgIHRoaXMuZXZlbnRzLm9uKCdVUERBVEVfTEFCRUwnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgY29uc3QgeyBmaW5nZXJwcmludCwgbGFiZWwgfSA9IGUucGF5bG9hZDtcclxuICAgICAgdGhpcy51cGRhdGVQYXJ0aWFsKHtcclxuICAgICAgICBzaWduZXJMYWJlbHM6IHtcclxuICAgICAgICAgIC4uLnRoaXMuc3RhdGU/LnNpZ25lckxhYmVscyxcclxuICAgICAgICAgIFtmaW5nZXJwcmludF06IGxhYmVsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBNdXRhdGVzIGN1cnJlbnQgc3RhdGUgbWFwIGF0dHJpYnV0ZXMgb24tdGhlLWZseSBhbmQgYnJvYWRjYXN0cyBtb2RpZmljYXRpb24gc2lnbmFscy5cclxuICAgKiBTaG9ydC1jaXJjdWl0cyBleGVjdXRpb24gY29tcGxldGVseSBpZiB0aGUgc3RvcmUgaGFzIG5vdCBiZWVuIHN0cnVjdHVyYWxseSBpbml0aWFsaXplZC5cclxuICAgKiBAcGFyYW0gcGFydGlhbFN0YXRlIC0gQW4gb2JqZWN0IG1hcHBpbmcga2V5IHByb3BlcnRpZXMgdG8gbWF0Y2ggYWdhaW5zdCB0aGUgc2NoZW1hIHN0cnVjdHVyZS5cclxuICAgKi9cclxuICBwcml2YXRlIHVwZGF0ZVBhcnRpYWwocGFydGlhbFN0YXRlOiBQYXJ0aWFsPFJvb21TdGF0ZT4pIHtcclxuICAgIGlmICghdGhpcy5zdGF0ZSkgcmV0dXJuO1xyXG4gICAgdGhpcy5zdGF0ZSA9IHsgLi4udGhpcy5zdGF0ZSwgLi4ucGFydGlhbFN0YXRlIH07XHJcbiAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnU1RBVEVfQ0hBTkdFRCcsIHRoaXMuc3RhdGUpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBhIHN5bmNocm9ub3VzIHNuYXBzaG90IG9mIHRoZSBhY3RpdmUgbWVtb3J5IGFsbG9jYXRpb24gcmVmZXJlbmNlIHN0cnVjdHVyZS5cclxuICAgKiBAcmV0dXJucyBUaGUgYWN0aXZlIFJvb21TdGF0ZSBtb2RlbCBibHVlcHJpbnQgb3IgbnVsbCBpZiB1bmFsbG9jYXRlZC5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0U3RhdGUoKTogUm9vbVN0YXRlIHwgbnVsbCB7XHJcbiAgICByZXR1cm4gdGhpcy5zdGF0ZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEFsbG9jYXRlcyBhIGJhc2VsaW5lIHN0cnVjdHVyYWwgdGVtcGxhdGUgbWFwcGluZyB6ZXJvZWQgZGVmYXVsdCBhdHRyaWJ1dGVzIGZvciBhIHNlc3Npb24uXHJcbiAgICogKiBAcGFyYW0gcm9vbUlkIC0gVGhlIHVuaXF1ZSB0cmFja2luZyBpZGVudGlmaWVyIG1hcHBpbmcgc3BhY2UgYm91bmRhcnkgc2NvcGVzLlxyXG4gICAqIEBwYXJhbSBwcm90b2NvbFZlcnNpb24gLSBTZW1hbnRpYyB2ZXJzaW9uIHN0cmluZyB0YXJnZXRpbmcgZXhlY3V0aW9uIHByb2ZpbGVzLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBpbml0KHJvb21JZDogc3RyaW5nLCBwcm90b2NvbFZlcnNpb246IHN0cmluZykge1xyXG4gICAgdGhpcy5zdGF0ZSA9IHtcclxuICAgICAgcm9vbUlkLFxyXG4gICAgICBwc2J0OiAnJyxcclxuICAgICAgc2lnbmF0dXJlczogW10sXHJcbiAgICAgIGNvbm5lY3RlZENvdW50OiAwLFxyXG4gICAgICBjcmVhdGVkQXQ6IERhdGUubm93KCksXHJcbiAgICAgIGV4cGlyZXNBdDogRGF0ZS5ub3coKSArIDEyMDAwMDAsXHJcbiAgICAgIGF1ZGl0TG9nOiBbXSxcclxuICAgICAgc2lnbmVyTGFiZWxzOiB7fSxcclxuICAgICAgcm9vbU5hbWU6ICdTaWduaW5nIFJvb20nLFxyXG4gICAgICB3aGl0ZWxpc3Q6IFtdLFxyXG4gICAgICBwYXJ0aWNpcGFudHM6IHt9LFxyXG4gICAgICBpc0xvY2tlZDogZmFsc2UsXHJcbiAgICAgIG5ldHdvcms6ICdiaXRjb2luJyxcclxuICAgICAgcHJvdG9jb2xWZXJzaW9uOiBwcm90b2NvbFZlcnNpb24sXHJcbiAgICB9O1xyXG4gICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1NUQVRFX0NIQU5HRUQnLCB0aGlzLnN0YXRlKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJlcGxhY2VzIGV4aXN0aW5nIHN0YXRlIHN0cnVjdHVyZXMgd2hvbGVzYWxlIGJ5IGV4ZWN1dGluZyBkZWVwIGFzc2lnbm1lbnQgbWVyZ2VzLlxyXG4gICAqIEBwYXJhbSBkYXRhIC0gVGhlIHJhdyBtb2RlbCBtYXBwaW5nIHJlcHJlc2VudGF0aW9uIGV4dHJhY3RlZCBmcm9tIGEgc29ja2V0IHN0cmVhbSBsaW5lLlxyXG4gICAqL1xyXG4gIHByaXZhdGUgc3luYyhkYXRhOiBhbnkpIHtcclxuICAgIHRoaXMuc3RhdGUgPSB7IC4uLnRoaXMuc3RhdGUsIC4uLmRhdGEgfTtcclxuICAgIHRoaXMuZXZlbnRzLmRpc3BhdGNoKCdTVEFURV9DSEFOR0VEJywgdGhpcy5zdGF0ZSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBIaWdoZXItb3JkZXIgdHJhbnNmb3JtYXRpb24gZnVuY3Rpb24gZXhlY3V0aW5nIGZ1bmN0aW9uYWwgdXBkYXRlcyBzYWZlbHkuXHJcbiAgICogQHBhcmFtIHVwZGF0ZXIgLSBBIG11dGF0aW9uIGNhbGxiYWNrIGZ1bmN0aW9uIG1hcHBpbmcgc3RhdGUgbWFwcyB0byBuZXdseSBldmFsdWF0ZWQgcHJvZmlsZXMuXHJcbiAgICovXHJcbiAgcHVibGljIHVwZGF0ZSh1cGRhdGVyOiAoczogUm9vbVN0YXRlIHwgbnVsbCkgPT4gUm9vbVN0YXRlIHwgbnVsbCkge1xyXG4gICAgdGhpcy5zdGF0ZSA9IHVwZGF0ZXIodGhpcy5zdGF0ZSk7XHJcbiAgICBpZiAodGhpcy5zdGF0ZSkge1xyXG4gICAgICB0aGlzLmV2ZW50cy5kaXNwYXRjaCgnU1RBVEVfQ0hBTkdFRCcsIHRoaXMuc3RhdGUpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRGlyZWN0bHkgb3ZlcnJpZGVzIHRoZSBzdGF0ZSB0cmFja2luZyBhbGxvY2F0aW9uIHByb2ZpbGUgd2l0aCBhbiBleHBsaWNpdCBpbnB1dCB0YXJnZXQuXHJcbiAgICogQHBhcmFtIG5ld1N0YXRlIC0gVGhlIG5ldyBjb21wbGV0ZSBtb2RlbCBjb25maWd1cmF0aW9uIG9yIG51bGwgdG8gd2lwZSBjbGVhbi5cclxuICAgKi9cclxuICBwdWJsaWMgc2V0KG5ld1N0YXRlOiBSb29tU3RhdGUgfCBudWxsKSB7XHJcbiAgICB0aGlzLnN0YXRlID0gbmV3U3RhdGU7XHJcbiAgICBpZiAobmV3U3RhdGUpIHtcclxuICAgICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1NUQVRFX0NIQU5HRUQnLCBuZXdTdGF0ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb21iaW5lcyBpbmNvbWluZyBwYXJ0aWFsIHRyYW5zYWN0aW9uYWwgZGV0YWlscyBpbnRvIGN1cnJlbnQgYWN0aXZlIHNpZ25hdHVyZSBsYXllcnMuXHJcbiAgICogTGV2ZXJhZ2VzIHN0cnVjdHVyYWwgUHNidFV0aWxzIGhlbHBlcnMgdG8gcmVjb25jaWxlIGRpdmVyZ2VudCBoZXggcGF0aHMuXHJcbiAgICogQHBhcmFtIHBheWxvYWQgLSBEYXRhIGNvbmZpZ3VyYXRpb24gc3RydWN0dXJlcyB0cmFja2luZyBuZXR3b3JrIHNpZ25hdHVyZSBkZXRhaWxzLlxyXG4gICAqL1xyXG4gIHByaXZhdGUgbWVyZ2UocGF5bG9hZDogYW55KSB7XHJcbiAgICBpZiAoIXRoaXMuc3RhdGUpIHJldHVybjtcclxuICAgIHRoaXMuc3RhdGUgPSB7XHJcbiAgICAgIC4uLnRoaXMuc3RhdGUsXHJcbiAgICAgIHBzYnQ6IFBzYnRVdGlscy5tZXJnZSh0aGlzLnN0YXRlLnBzYnQsIHBheWxvYWQuZGVjcnlwdGVkUHNidCksXHJcbiAgICAgIHNpZ25hdHVyZXM6IFsuLi50aGlzLnN0YXRlLnNpZ25hdHVyZXMsIHBheWxvYWQuZGVjcnlwdGVkUHNidF0sXHJcbiAgICB9O1xyXG4gICAgdGhpcy5ldmVudHMuZGlzcGF0Y2goJ1NUQVRFX0NIQU5HRUQnLCB0aGlzLnN0YXRlKTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgRW5jcnlwdGlvbkVuZ2luZSB9IGZyb20gJy4uL2NyeXB0by9lbmNyeXB0aW9uLWVuZ2luZSc7XHJcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnO1xyXG5cclxuLyoqXHJcbiAqIERhdGEgcGF5bG9hZCByZXR1cm5lZCB1cG9uIHJvb20gcHJvZHVjdGlvbi4gU2VwYXJhdGVzIHJlY29yZHMgaW50ZW5kZWQgZm9yIGxvY2FsIGludGVncmF0aW9uXHJcbiAqIGZyb20gcmVjb3JkcyBwcmVwYXJlZCBmb3IgZGlyZWN0IG5ldHdvcmsgc2VyaWFsaXphdGlvbi5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgUm9vbUNyZWF0aW9uUGF5bG9hZCB7XHJcbiAgLyoqIFByaXZhdGUgY29uZmlndXJhdGlvbnMgdGhhdCBtdXN0IGJlIHNhdmVkIGxvY2FsbHkgb3IgaW5qZWN0ZWQgZGlyZWN0bHkgaW50byBzZWN1cmUgVVJMIGhhc2hlcy4gKi9cclxuICBsb2NhbERhdGE6IHtcclxuICAgIC8qKiBUaGUgdW5pcXVlIHN0cmluZyB0cmFja2luZyBpZGVudGlmaWVyIGZvciB0aGUgc2Vzc2lvbiByb29tIHNwYWNlLiAqL1xyXG4gICAgcm9vbUlkOiBzdHJpbmc7XHJcbiAgICAvKiogVGhlIGJhc2U2NC1lbmNvZGVkIHN5bW1ldHJpYyBlbmNyeXB0aW9uIGtleSB1c2VkIHRvIGVuY3J5cHQgdGhlIHNlc3Npb24gcGF5bG9hZCBib3VuZGFyaWVzLiAqL1xyXG4gICAgZW5jcnlwdGlvbktleTogc3RyaW5nO1xyXG4gICAgLyoqIFRoZSB1bmlxdWUgYWRtaW5pc3RyYXRpdmUgdG9rZW4gcmVxdWlyZWQgdG8gbW9kaWZ5IHJvb20gcHJpdmlsZWdlcyBvciBzdGF0ZSBmbGFncy4gKi9cclxuICAgIGFkbWluU2VjcmV0OiBzdHJpbmc7XHJcbiAgfTtcclxuICAvKiogUHJlLWZvcm1hdHRlZCBkYXRhIG1hcHBpbmcgcmVhZHkgdG8gYmUgZXhwbGljaXRseSBQT1NUZWQgdG8gdGhlIGhvc3QgYC9hcGkvcm9vbWAgZW5kcG9pbnQuICovXHJcbiAgaHR0cFBheWxvYWQ6IHtcclxuICAgIC8qKiBUaGUgdW5pcXVlIHN0cmluZyB0cmFja2luZyBpZGVudGlmaWVyIGZvciB0aGUgc2Vzc2lvbiByb29tIHNwYWNlLiAqL1xyXG4gICAgcm9vbUlkOiBzdHJpbmc7XHJcbiAgICAvKiogQSBibGluZGVkIGNyeXB0b2dyYXBoaWMgcHJvb2YgdXNlZCB0byB2ZXJpZnkgdmFsaWQgcm9vbSBhY2Nlc3MgcGFyYW1ldGVycyB3aXRob3V0IGxlYWtpbmcga2V5cy4gKi9cclxuICAgIGV4cGVjdGVkUGFzczogc3RyaW5nO1xyXG4gICAgLyoqIFRoZSBiYXNlNjQtZW5jb2RlZCBlbmNyeXB0ZWQgc3RyaW5nIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBjb3JlIHRyYW5zYWN0aW9uIG1hdHJpeCAoUFNCVCkuICovXHJcbiAgICBlbmNyeXB0ZWRQc2J0OiBzdHJpbmc7XHJcbiAgICAvKiogVGhlIGJhc2U2NC1lbmNvZGVkIGVuY3J5cHRlZCBzdHJpbmcgZm9ybWF0IG9mIHRoZSBhZG1pbmlzdHJhdGl2ZSBhY2Nlc3MgdG9rZW4uICovXHJcbiAgICBhZG1pblRva2VuOiBzdHJpbmc7XHJcbiAgICAvKiogVGhlIHRhcmdldCBibG9ja2NoYWluIGVudmlyb25tZW50IGNvbnN0cmFpbnRzIGNvbmZpZ3VyYXRpb24uICovXHJcbiAgICBuZXR3b3JrOiAnYml0Y29pbicgfCAndGVzdG5ldCcgfCAnc2lnbmV0JztcclxuICAgIC8qKiBUaGUgbWF0Y2hpbmcgc2VtYW50aWMgdmVyc2lvbmluZyBpZGVudGlmaWVyIHRyYWNraW5nIGxpYnJhcnkgY29tbXVuaWNhdGlvbnMgcHJvdG9jb2xzLiAqL1xyXG4gICAgcHJvdG9jb2xWZXJzaW9uOiBzdHJpbmc7XHJcbiAgICAvKiogVGhlIGJhc2U2NC1lbmNvZGVkIGVuY3J5cHRlZCBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgdGhlIGRlc2NyaXB0aXZlIHJvb20gdGl0bGUuICovXHJcbiAgICBlbmNyeXB0ZWRSb29tTmFtZTogc3RyaW5nO1xyXG4gIH07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGYWN0b3J5IGNvb3JkaW5hdG9yIGVuZ2luZSBtYW5hZ2luZyB0aGUgc2V0dXAgY29uZmlndXJhdGlvbnMgZm9yIHRlbXBvcmFyeSBjb2xsYWJvcmF0aXZlIHdvcmtzcGFjZXMuXHJcbiAqIEFic3RyYWN0cyBVVUlEIGdlbmVyYXRpb24sIGJsaW5kIHNhbHRpbmcsIGFuZCBrZXkgZGlzdHJpYnV0aW9uIGNvbmZpZ3VyYXRpb25zIGFjcm9zcyBuZXR3b3JrIG9wZXJhdGlvbnMuXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgUm9vbUZhY3Rvcnkge1xyXG4gIC8qKlxyXG4gICAqIFByZXBhcmVzIGFuZCBlbmNyeXB0cyBhbGwgcmVxdWlyZWQgdG9rZW4gc3RydWN0dXJlcyBpbnRvIGEgc3RydWN0dXJlZCBwYXlsb2FkIHJlYWR5IGZvciBiYWNrZW5kIGluaXRpYWxpemF0aW9uLlxyXG4gICAqIEhhbmRsZXMgYWxsIEtleSwgSWRlbnRpZmllciwgYW5kIGNyeXB0b2dyYXBoaWMgc2lnbmF0dXJlIG1hcHBpbmdzIGF1dG9tYXRpY2FsbHkuXHJcbiAgICogKiBAcGFyYW0gZW5naW5lIC0gVGhlIHN0cnVjdHVyYWwgRW5jcnlwdGlvbkVuZ2luZSBpbnN0YW5jZSBydW5uaW5nIGNyeXB0b2dyYXBoaWMgdGFza3MuXHJcbiAgICogQHBhcmFtIHJhd1BzYnRCYXNlNjQgLSBUaGUgdW5lbmNyeXB0ZWQgQmFzZTY0IHN0cmluZyBwYXlsb2FkIHJlcHJlc2VudGluZyBhIFBhcnRpY2FsbHkgU2lnbmVkIEJpdGNvaW4gVHJhbnNhY3Rpb24uXHJcbiAgICogQHBhcmFtIG5ldHdvcmsgLSBUaGUgdGFyZ2V0ZWQgYmxvY2tjaGFpbiBuZXR3b3JrIGNvbnRleHQgY29uc3RyYWludCBpZGVudGlmaWVyLlxyXG4gICAqIEBwYXJhbSByb29tTmFtZSAtIFRoZSByYXcgZGVzY3JpcHRpdmUgdGl0bGUgYXNzaWduZWQgdG8gdGhlIGNvbGxhYm9yYXRpdmUgc2Vzc2lvbiBzcGFjZS4gRGVmYXVsdCBpcyBcIlVudGl0bGVkIFJvb21cIi5cclxuICAgKiBAcGFyYW0gcHJvdG9jb2xWZXJzaW9uIC0gU2VtYW50aWMgdmVyc2lvbiBjb25maWd1cmF0aW9uIG1hcHBpbmcuIERlZmF1bHQgaXMgXCIxLjAuMFwiLlxyXG4gICAqIEByZXR1cm5zIEEgUHJvbWlzZSByZXNvbHZpbmcgdG8gYSBjb21wbGV0ZWQgUm9vbUNyZWF0aW9uUGF5bG9hZCBzY2hlbWEgbWFwcGluZy5cclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgcHJlcGFyZUNyZWF0aW9uUGF5bG9hZChcclxuICAgIGVuZ2luZTogRW5jcnlwdGlvbkVuZ2luZSxcclxuICAgIHJhd1BzYnRCYXNlNjQ6IHN0cmluZyxcclxuICAgIG5ldHdvcms6ICdiaXRjb2luJyB8ICd0ZXN0bmV0JyB8ICdzaWduZXQnLFxyXG4gICAgcm9vbU5hbWU6IHN0cmluZyA9ICdVbnRpdGxlZCBSb29tJyxcclxuICAgIHByb3RvY29sVmVyc2lvbjogc3RyaW5nID0gJzEuMC4wJyxcclxuICApOiBQcm9taXNlPFJvb21DcmVhdGlvblBheWxvYWQ+IHtcclxuICAgIC8vIEdlbmVyYXRlIGNvcmUgc2VjcmV0cyBzYWZlbHkgZGVwZW5kaW5nIG9uIGVudmlyb25tZW50YWwgY2FwYWJpbGl0aWVzXHJcbiAgICBjb25zdCBlbmNyeXB0aW9uS2V5ID0gYXdhaXQgZW5naW5lLmdlbmVyYXRlS2V5KCk7XHJcbiAgICBjb25zdCByb29tSWQgPVxyXG4gICAgICB0eXBlb2YgY3J5cHRvICE9PSAndW5kZWZpbmVkJyAmJiBjcnlwdG8ucmFuZG9tVVVJRFxyXG4gICAgICAgID8gY3J5cHRvLnJhbmRvbVVVSUQoKVxyXG4gICAgICAgIDogdGhpcy5mYWxsYmFja1VVSUQoKTtcclxuICAgIGNvbnN0IGFkbWluU2VjcmV0ID1cclxuICAgICAgdHlwZW9mIGNyeXB0byAhPT0gJ3VuZGVmaW5lZCcgJiYgY3J5cHRvLnJhbmRvbVVVSURcclxuICAgICAgICA/IGNyeXB0by5yYW5kb21VVUlEKClcclxuICAgICAgICA6IHRoaXMuZmFsbGJhY2tVVUlEKCk7XHJcblxyXG4gICAgLy8gRW5jcnlwdCBwYXlsb2FkcyB1c2luZyB0aGUgc2hhcmVkIGtleVxyXG4gICAgY29uc3QgZW5jcnlwdGVkRGF0YSA9IGF3YWl0IGVuZ2luZS5lbmNyeXB0KHJhd1BzYnRCYXNlNjQsIGVuY3J5cHRpb25LZXkpO1xyXG4gICAgY29uc3QgZW5jcnlwdGVkQWRtaW5Ub2tlbiA9IGF3YWl0IGVuZ2luZS5lbmNyeXB0KGFkbWluU2VjcmV0LCBlbmNyeXB0aW9uS2V5KTtcclxuICAgIGNvbnN0IGVuY3J5cHRlZFJvb21OYW1lID0gYXdhaXQgZW5naW5lLmVuY3J5cHQocm9vbU5hbWUsIGVuY3J5cHRpb25LZXkpO1xyXG4gICAgY29uc3QgZXhwZWN0ZWRQYXNzID0gYXdhaXQgZW5naW5lLmJsaW5kRGF0YShyb29tSWQsIGVuY3J5cHRpb25LZXkpO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGxvY2FsRGF0YToge1xyXG4gICAgICAgIHJvb21JZCxcclxuICAgICAgICBlbmNyeXB0aW9uS2V5LFxyXG4gICAgICAgIGFkbWluU2VjcmV0LFxyXG4gICAgICB9LFxyXG4gICAgICBodHRwUGF5bG9hZDoge1xyXG4gICAgICAgIHJvb21JZCxcclxuICAgICAgICBleHBlY3RlZFBhc3MsXHJcbiAgICAgICAgZW5jcnlwdGVkUHNidDogZW5jcnlwdGVkRGF0YSxcclxuICAgICAgICBhZG1pblRva2VuOiBlbmNyeXB0ZWRBZG1pblRva2VuLFxyXG4gICAgICAgIG5ldHdvcmssXHJcbiAgICAgICAgcHJvdG9jb2xWZXJzaW9uLFxyXG4gICAgICAgIGVuY3J5cHRlZFJvb21OYW1lLFxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdlbmVyYXRlcyBhIGNyeXB0b2dyYXBoaWNhbGx5IHNlY3VyZSBSRkMgNDEyMiB2ZXJzaW9uIDQgY29tcGxpYW50IFVVSUQuXHJcbiAgICpcclxuICAgKiBUaGlzIGFjdHMgYXMgYSByb2J1c3QgcG9seWZpbGwgZm9yIG5vbi1zdGFuZGFyZCBleGVjdXRpb24gY29udGV4dHMgd2hlcmUgdGhlIG5hdGl2ZVxyXG4gICAqIGBjcnlwdG8ucmFuZG9tVVVJRGAgaXMgdW5hdmFpbGFibGUuIEl0IHV0aWxpemVzIGEgY3J5cHRvZ3JhcGhpY2FsbHkgc2VjdXJlIHBzZXVkby1yYW5kb21cclxuICAgKiBudW1iZXIgZ2VuZXJhdG9yIChDU1BSTkcpIHRvIGd1YXJhbnRlZSB1bnByZWRpY3RhYmlsaXR5IGFuZCBwcmV2ZW50IHN0YXRlIGhpamFja2luZy5cclxuICAgKlxyXG4gICAqIEByZXR1cm5zIHtzdHJpbmd9IEEgZm9ybWF0dGVkIDM2LWNoYXJhY3RlciBjYW5vbmljYWwgVVVJRHY0IHN0cmluZy5cclxuICAgKi9cclxuICBwcml2YXRlIHN0YXRpYyBmYWxsYmFja1VVSUQoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB1dWlkdjQoKTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgU2lnbmVyU3RhdHVzLCBUeERldGFpbHMgfSBmcm9tICcuL3BzYnQtdXRpbHMnO1xyXG5pbXBvcnQgeyBSb29tU3RhdGUsIEF1ZGl0RW50cnkgfSBmcm9tICcuLi9yZWxheS9yb29tLXN0YXRlLXN0b3JlJztcclxuaW1wb3J0IHsganNQREYgfSBmcm9tICdqc3BkZic7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEF1ZGl0TG9nT3B0aW9ucyB7XHJcbiAgYnJhbmROYW1lPzogc3RyaW5nO1xyXG4gIGJyYW5kQ29sb3I/OiBbbnVtYmVyLCBudW1iZXIsIG51bWJlcl07XHJcbiAgbG9nb0RhdGFVcmw/OiBzdHJpbmc7XHJcbiAgaXNXaGl0ZWxhYmVsPzogYm9vbGVhbjtcclxufVxyXG5cclxuLyoqXHJcbiAqIFV0aWxpdHkgY2xhc3MgcmVzcG9uc2libGUgZm9yIGdlbmVyYXRpbmcgY3J5cHRvZ3JhcGhpYyBpbnRlZ3JpdHkgcHJvb2ZzIGFuZFxyXG4gKiBodW1hbi1yZWFkYWJsZSBjb21wbGlhbmNlIHJlcG9ydHMgKFBERiwgQ1NWKSBmcm9tIHJlYWwtdGltZSByb29tIHN0YXRlcy5cclxuICovXHJcbmV4cG9ydCBjbGFzcyBSb29tQXVkaXRvciB7XHJcbiAgLyoqXHJcbiAgICogQ29tcGlsZXMgdG9wLWxldmVsIHRyYW5zYWN0aW9uIGFuZCBwYXJ0aWNpcGFudCBtZXRhZGF0YSBpbnRvIGEgY29tbWEtc2VwYXJhdGVkIGZvcm1hdC5cclxuICAgKiBAcGFyYW0gc3RhdGUgLSBUaGUgYWN0aXZlIFJvb21TdGF0ZSBjb250YWluaW5nIHBhcnRpY2lwYW50IGFuZCBuZXR3b3JrIGNvbnRleHRzLlxyXG4gICAqIEBwYXJhbSB0eCAtIFRoZSBwYXJzZWQgdHJhbnNhY3Rpb24gZGV0YWlscyBpbmNsdWRpbmcgSS9PIG1hcHMgYW5kIGZlZXMuXHJcbiAgICogQHBhcmFtIHNpZ25lcnMgLSBUaGUgbGlzdCBvZiBhY3RpdmUgc2lnbmVycyBhbmQgdGhlaXIgY3VycmVudCBzaWduYXR1cmUgc3RhdHVzLlxyXG4gICAqIEByZXR1cm5zIEEgcmF3IENTViBzdHJpbmcgY29udGFpbmluZyB0aGUgZm9ybWF0dGVkIHNldHRsZW1lbnQgcm93LlxyXG4gICAqL1xyXG4gIHN0YXRpYyBnZXRTZXR0bGVtZW50Q3N2RGF0YShzdGF0ZTogUm9vbVN0YXRlLCB0eDogVHhEZXRhaWxzLCBzaWduZXJzOiBTaWduZXJTdGF0dXNbXSk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBoZWFkZXJzID0gW1xyXG4gICAgICAnRGF0ZScsXHJcbiAgICAgICdSb29tIElEJyxcclxuICAgICAgJ05ldHdvcmsnLFxyXG4gICAgICAnVFhJRCcsXHJcbiAgICAgICdUb3RhbCBBbW91bnQgKEJUQyknLFxyXG4gICAgICAnRmVlIFJhdGUgKHNhdHMvdkIpJyxcclxuICAgICAgJ0lucHV0cycsXHJcbiAgICAgICdPdXRwdXRzJyxcclxuICAgICAgJ1NpZ25lcnMnLFxyXG4gICAgICAnV2l0bmVzc2VzJyxcclxuICAgICAgJ1N0YXR1cycsXHJcbiAgICBdO1xyXG5cclxuICAgIGNvbnN0IHNpZ25lcnNMaXN0ID0gc2lnbmVyc1xyXG4gICAgICAubWFwKChzKSA9PiBgJHtzLmZpbmdlcnByaW50fSR7cy5zaWduZWQgPyAnKFNpZ25lZCknIDogJyhQZW5kaW5nKSd9YClcclxuICAgICAgLmpvaW4oJzsgJyk7XHJcblxyXG4gICAgY29uc3QgcGFydGljaXBhbnRzT2JqID0gc3RhdGUucGFydGljaXBhbnRzIHx8IHt9O1xyXG4gICAgY29uc3Qgd2l0bmVzc2VzTGlzdCA9IE9iamVjdC52YWx1ZXMocGFydGljaXBhbnRzT2JqKVxyXG4gICAgICAubWFwKChwOiBhbnkpID0+IHtcclxuICAgICAgICBjb25zdCBuYW1lID0gcC5kaXNwbGF5TmFtZSB8fCAnQW5vbnltb3VzJztcclxuICAgICAgICBjb25zdCByb2xlID0gcC5yb2xlID09PSAnYWRtaW4nID8gJ0Nvb3JkaW5hdG9yJyA6ICdHdWVzdCc7XHJcbiAgICAgICAgcmV0dXJuIGAke25hbWV9IFske3JvbGV9XSAoJHtwLmlkfSlgO1xyXG4gICAgICB9KVxyXG4gICAgICAuam9pbignOyAnKTtcclxuXHJcbiAgICBjb25zdCByb3cgPSBbXHJcbiAgICAgIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgc3RhdGUucm9vbUlkLFxyXG4gICAgICBzdGF0ZS5uZXR3b3JrLFxyXG4gICAgICBzdGF0ZS5maW5hbFR4SWQgfHwgJ1BlbmRpbmcnLFxyXG4gICAgICAodHguYW1vdW50IC8gMTAwMDAwMDAwKS50b0ZpeGVkKDgpLFxyXG4gICAgICB0eC5mZWVSYXRlLFxyXG4gICAgICB0eC5pbnB1dHNMaXN0Py5sZW5ndGggfHwgMCxcclxuICAgICAgdHgub3V0cHV0cz8ubGVuZ3RoIHx8IDAsXHJcbiAgICAgIGBcIiR7c2lnbmVyc0xpc3R9XCJgLFxyXG4gICAgICBgXCIke3dpdG5lc3Nlc0xpc3R9XCJgLFxyXG4gICAgICBzdGF0ZT8uZmluYWxUeEhleCA/ICdTaWduZWQgJiBSZWFkeScgOiAnUGVuZGluZyBTaWduYXR1cmVzJyxcclxuICAgIF07XHJcblxyXG4gICAgcmV0dXJuIGhlYWRlcnMuam9pbignLCcpICsgJ1xcbicgKyByb3cuam9pbignLCcpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVHJhbnNmb3JtcyB0aGUgZGVjZW50cmFsaXplZCByb29tIGF1ZGl0IGxvZyBpbnRvIGEgZmxhdCBDU1YgZm9ybWF0IGZvciBleHRlcm5hbCBhcmNoaXZpbmcuXHJcbiAgICogQHBhcmFtIHN0YXRlIC0gVGhlIGFjdGl2ZSBSb29tU3RhdGUgY29udGFpbmluZyB0aGUgY2hyb25vbG9naWNhbCBhdWRpdCBsb2cuXHJcbiAgICogQHJldHVybnMgQSByYXcgQ1NWIHN0cmluZyBjb250YWluaW5nIGhlYWRlcnMgYW5kIHNhbml0aXplZCBldmVudCByb3dzLlxyXG4gICAqL1xyXG4gIHN0YXRpYyBnZXRBdWRpdExvZ0NzdkRhdGEoc3RhdGU6IFJvb21TdGF0ZSk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBsb2dzID0gc3RhdGUuYXVkaXRMb2cgfHwgW107XHJcbiAgICBjb25zdCBjc3ZIZWFkZXIgPSAnVGltZXN0YW1wLEV2ZW50LFVzZXIsRGV0YWlsXFxuJztcclxuICAgIGNvbnN0IGNzdlJvd3MgPSBsb2dzXHJcbiAgICAgIC5tYXAoKGwpID0+IHtcclxuICAgICAgICBjb25zdCB0aW1lID0gbmV3IERhdGUobC50aW1lc3RhbXApLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgICAgY29uc3QgZXZlbnQgPSBgXCIke2wuZXZlbnQucmVwbGFjZSgvXCIvZywgJ1wiXCInKX1cImA7XHJcbiAgICAgICAgY29uc3QgdXNlciA9IGBcIiR7bC51c2VyLnJlcGxhY2UoL1wiL2csICdcIlwiJyl9XCJgO1xyXG4gICAgICAgIGNvbnN0IGRldGFpbCA9IGBcIiR7KGwuZGV0YWlsIHx8ICcnKS5yZXBsYWNlKC9cIi9nLCAnXCJcIicpfVwiYDtcclxuICAgICAgICByZXR1cm4gYCR7dGltZX0sJHtldmVudH0sJHt1c2VyfSwke2RldGFpbH1gO1xyXG4gICAgICB9KVxyXG4gICAgICAuam9pbignXFxuJyk7XHJcbiAgICByZXR1cm4gY3N2SGVhZGVyICsgY3N2Um93cztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdlbmVyYXRlcyBhIERhdGEgVVJJIHN0cmluZyBjb250YWluaW5nIHRoZSBzZXR0bGVtZW50IENTViBmb3IgZGlyZWN0IGJyb3dzZXIgZG93bmxvYWRpbmcuXHJcbiAgICogQHBhcmFtIHN0YXRlIC0gVGhlIGFjdGl2ZSBSb29tU3RhdGUuXHJcbiAgICogQHBhcmFtIHR4IC0gVGhlIHBhcnNlZCB0cmFuc2FjdGlvbiBkZXRhaWxzLlxyXG4gICAqIEBwYXJhbSBzaWduZXJzIC0gVGhlIGxpc3Qgb2YgYWN0aXZlIHNpZ25lcnMuXHJcbiAgICogQHJldHVybnMgQSBVUkktZW5jb2RlZCBkYXRhIHN0cmluZyAoZGF0YTp0ZXh0L2Nzdi4uLikuXHJcbiAgICovXHJcbiAgc3RhdGljIGdldEVuY29kZWRDc3ZEYXRhKHN0YXRlOiBSb29tU3RhdGUsIHR4OiBUeERldGFpbHMsIHNpZ25lcnM6IFNpZ25lclN0YXR1c1tdKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IGNzdkNvbnRlbnQgPVxyXG4gICAgICAnZGF0YTp0ZXh0L2NzdjtjaGFyc2V0PXV0Zi04LCcgKyB0aGlzLmdldFNldHRsZW1lbnRDc3ZEYXRhKHN0YXRlLCB0eCwgc2lnbmVycyk7XHJcbiAgICByZXR1cm4gZW5jb2RlVVJJKGNzdkNvbnRlbnQpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUHJvY2VkdXJhbGx5IGNvbnN0cnVjdHMgYSBjb21wcmVoZW5zaXZlLCBtdWx0aS1wYWdlIGNvbXBsaWFuY2UgUERGIHVzaW5nIHRoZSBwcm92aWRlZCBqc1BERiBpbnN0YW5jZS5cclxuICAgKiBNYXBzIHJvb20gZ292ZXJuYW5jZSwgY3J5cHRvZ3JhcGhpYyBhbmNob3JzLCBwYXJ0aWNpcGFudCBtYW5pZmVzdHMsIGFuZCB0cmFuc2FjdGlvbiBwYXJhbWV0ZXJzIGludG8gYSBzdGFuZGFyZCBmb3JtYXQuXHJcbiAgICogQHBhcmFtIGRvYyAtIEFuIGluaXRpYWxpemVkIGpzUERGIGluc3RhbmNlLlxyXG4gICAqIEBwYXJhbSBzdGF0ZSAtIFRoZSBmaW5hbGl6ZWQgUm9vbVN0YXRlIGNvbnRhaW5pbmcgbWV0YWRhdGEgYW5kIGxvZ3MuXHJcbiAgICogQHBhcmFtIHR4IC0gVGhlIHBhcnNlZCB0cmFuc2FjdGlvbiBwYXlsb2FkIChjYW4gYmUgbnVsbCBpZiB1bnBhcnNlYWJsZSkuXHJcbiAgICogQHBhcmFtIHNpZ25lcnMgLSBUaGUgbGlzdCBvZiBzaWduZXJzIG1hcHBpbmcgZmluZ2VycHJpbnRzIHRvIHNpZ25hdHVyZSBzdGF0ZXMuXHJcbiAgICogQHBhcmFtIGZpbmFsSGV4IC0gVGhlIGV4dHJhY3RlZCwgYnJvYWRjYXN0LXJlYWR5IHJhdyB0cmFuc2FjdGlvbiBoZXgsIGlmIGF2YWlsYWJsZS5cclxuICAgKiBAcmV0dXJucyBBIFByb21pc2UgcmVzb2x2aW5nIHRvIGFuIG9iamVjdCBjb250YWluaW5nIHRoZSBtdXRhdGVkIGRvY3VtZW50IGFuZCB0aGUgc3RhbmRhcmRpemVkIGZpbGVuYW1lLlxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBnZW5lcmF0ZUF1ZGl0UGRmKFxyXG4gICAgZG9jOiBqc1BERixcclxuICAgIHN0YXRlOiBSb29tU3RhdGUsXHJcbiAgICB0eDogVHhEZXRhaWxzIHwgbnVsbCxcclxuICAgIHNpZ25lcnM6IFNpZ25lclN0YXR1c1tdLFxyXG4gICAgZmluYWxIZXg6IHN0cmluZyB8IG51bGwsXHJcbiAgICBvcHRpb25zPzogQXVkaXRMb2dPcHRpb25zLFxyXG4gICk6IFByb21pc2U8eyBkb2M6IGpzUERGOyBmaWxlbmFtZTogc3RyaW5nIH0+IHtcclxuICAgIGxldCB5ID0gMjA7XHJcblxyXG4gICAgY29uc3QgY2hlY2tQYWdlQnJlYWsgPSAoc3BhY2VOZWVkZWQ6IG51bWJlcikgPT4ge1xyXG4gICAgICBpZiAoeSArIHNwYWNlTmVlZGVkID4gMjgwKSB7XHJcbiAgICAgICAgZG9jLmFkZFBhZ2UoKTtcclxuICAgICAgICB5ID0gMjA7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gSGVhZGVyIHNldHVwXHJcbiAgICBsZXQgaGVhZGluZ1RleHQgPSAnU2lnbmluZ1Jvb20uaW8nO1xyXG5cclxuICAgIGlmIChvcHRpb25zPy5pc1doaXRlbGFiZWwpIHtcclxuICAgICAgaGVhZGluZ1RleHQgPSBvcHRpb25zPy5icmFuZE5hbWUgfHwgJ1NpZ25pbmdSb29tLmlvJztcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBicmFuZENvbG9yID0gb3B0aW9ucz8uYnJhbmRDb2xvciB8fCBbMTYsIDE4NSwgMTI5XTtcclxuXHJcbiAgICBsZXQgY3VycmVudFggPSAyMDtcclxuICAgIGNvbnN0IGxvZ29IZWlnaHQgPSAxMjtcclxuICAgIGNvbnN0IGxvZ29ZT2Zmc2V0ID0geSAtIDk7XHJcblxyXG4gICAgLy8gRW1iZWQgTG9nbyBpZiBwcm92aWRlZFxyXG4gICAgaWYgKG9wdGlvbnM/LmxvZ29EYXRhVXJsKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgaW1nUHJvcHMgPSBkb2MuZ2V0SW1hZ2VQcm9wZXJ0aWVzKG9wdGlvbnMubG9nb0RhdGFVcmwpO1xyXG4gICAgICAgIGNvbnN0IGxvZ29XaWR0aCA9IChpbWdQcm9wcy53aWR0aCAqIGxvZ29IZWlnaHQpIC8gaW1nUHJvcHMuaGVpZ2h0O1xyXG5cclxuICAgICAgICBkb2MuYWRkSW1hZ2Uob3B0aW9ucy5sb2dvRGF0YVVybCwgJ1BORycsIGN1cnJlbnRYLCBsb2dvWU9mZnNldCwgbG9nb1dpZHRoLCBsb2dvSGVpZ2h0KTtcclxuXHJcbiAgICAgICAgY3VycmVudFggKz0gbG9nb1dpZHRoICsgNDtcclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIGNvbnNvbGUud2FybignRmFpbGVkIHRvIGVtYmVkIGxvZ28gaW4gUERGJywgZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgIGRvYy5zZXRGb250U2l6ZSgyNCk7XHJcbiAgICBkb2Muc2V0VGV4dENvbG9yKGJyYW5kQ29sb3JbMF0sIGJyYW5kQ29sb3JbMV0sIGJyYW5kQ29sb3JbMl0pO1xyXG4gICAgZG9jLnRleHQoaGVhZGluZ1RleHQsIGN1cnJlbnRYLCB5KTtcclxuXHJcbiAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ25vcm1hbCcpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE2KTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoMTAwKTtcclxuICAgIGRvYy50ZXh0KCdBdWRpdCBMb2cnLCAyMCwgeSArIDEyKTtcclxuICAgIHkgKz0gMjQ7XHJcblxyXG4gICAgLy8gU2VwYXJhdG9yIExpbmVcclxuICAgIGRvYy5zZXREcmF3Q29sb3IoMjAwKTtcclxuICAgIGRvYy5zZXRMaW5lV2lkdGgoMC41KTtcclxuICAgIGRvYy5saW5lKDIwLCB5LCAxOTAsIHkpO1xyXG4gICAgeSArPSAxMDtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIFNFQ1RJT04gMDogRk9SRU5TSUMgSU5URUdSSVRZIFNFQUxcclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgaWYgKGZpbmFsSGV4ICYmIHN0YXRlLmF1ZGl0TG9nICYmIHN0YXRlLmF1ZGl0TG9nLmxlbmd0aCA+IDApIHtcclxuICAgICAgY2hlY2tQYWdlQnJlYWsoMzUpO1xyXG4gICAgICBjb25zdCBhbmNob3IgPSBhd2FpdCB0aGlzLmNhbGN1bGF0ZUZvcmVuc2ljQW5jaG9yKHN0YXRlLmF1ZGl0TG9nLCBmaW5hbEhleCk7XHJcblxyXG4gICAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgICBkb2Muc2V0VGV4dENvbG9yKGJyYW5kQ29sb3JbMF0sIGJyYW5kQ29sb3JbMV0sIGJyYW5kQ29sb3JbMl0pO1xyXG4gICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgICAgZG9jLnRleHQoJ0NyeXB0b2dyYXBoaWMgSW50ZWdyaXR5IFNlYWwnLCAyMCwgeSk7XHJcbiAgICAgIHkgKz0gNjtcclxuXHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgICAgZG9jLnNldFRleHRDb2xvcigxMDApO1xyXG4gICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2l0YWxpYycpO1xyXG4gICAgICBkb2MudGV4dChcclxuICAgICAgICAnVGhpcyBhbmNob3IgbWF0aGVtYXRpY2FsbHkgYmluZHMgdGhlIHJhdyB0cmFuc2FjdGlvbiBoZXggdG8gdGhlIGNocm9ub2xvZ2ljYWwgZXZlbnQgdGltZWxpbmUgYmVsb3cuJyxcclxuICAgICAgICAyMCxcclxuICAgICAgICB5LFxyXG4gICAgICApO1xyXG4gICAgICB5ICs9IDU7XHJcbiAgICAgIGRvYy50ZXh0KCdWZXJpZmljYXRpb24gZm9ybXVsYTogU0hBMjU2KEF1ZGl0X0xvZ19DU1ZfU3RyaW5nICsgRmluYWxfVHhfSGV4KScsIDIwLCB5KTtcclxuICAgICAgeSArPSA4O1xyXG5cclxuICAgICAgZG9jLnNldEZvbnRTaXplKDEwKTtcclxuICAgICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgICAgZG9jLnNldEZvbnQoJ2NvdXJpZXInLCAnYm9sZCcpO1xyXG4gICAgICBkb2MudGV4dChhbmNob3IsIDIwLCB5KTtcclxuICAgICAgeSArPSAxMDtcclxuXHJcbiAgICAgIC8vIFNlcGFyYXRvciBMaW5lXHJcbiAgICAgIGRvYy5zZXREcmF3Q29sb3IoMjAwKTtcclxuICAgICAgZG9jLnNldExpbmVXaWR0aCgwLjUpO1xyXG4gICAgICBkb2MubGluZSgyMCwgeSwgMTkwLCB5KTtcclxuICAgICAgeSArPSAxMDtcclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIFNFQ1RJT04gMTogUk9PTSBNRVRBREFUQSAmIEdPVkVSTkFOQ0VcclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgY2hlY2tQYWdlQnJlYWsoNDApO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE0KTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoMCk7XHJcbiAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgIGRvYy50ZXh0KCdSb29tIEluZm8gJiBHb3Zlcm5hbmNlJywgMjAsIHkpO1xyXG4gICAgeSArPSA4O1xyXG5cclxuICAgIGRvYy5zZXRGb250U2l6ZSgxMCk7XHJcbiAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ25vcm1hbCcpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcig1MCk7XHJcblxyXG4gICAgZG9jLnRleHQoYFJvb206ICR7c3RhdGUucm9vbU5hbWV9YCwgMjAsIHkpO1xyXG4gICAgeSArPSA2O1xyXG4gICAgZG9jLnRleHQoYFJvb20gSUQ6ICR7c3RhdGUucm9vbUlkfWAsIDIwLCB5KTtcclxuICAgIHkgKz0gNjtcclxuICAgIGRvYy50ZXh0KGBOZXR3b3JrOiAkeyhzdGF0ZS5uZXR3b3JrIHx8ICdiaXRjb2luJykudG9VcHBlckNhc2UoKX1gLCAyMCwgeSk7XHJcbiAgICB5ICs9IDY7XHJcbiAgICBkb2MudGV4dChgQ3JlYXRlZDogJHtuZXcgRGF0ZShzdGF0ZS5jcmVhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKCl9YCwgMjAsIHkpO1xyXG4gICAgeSArPSA2O1xyXG5cclxuICAgIGNvbnN0IGxvY2tTdGF0dXMgPSBzdGF0ZS5pc0xvY2tlZCA/ICdMT0NLRUQgKFNlY3VyZSknIDogJ1VOTE9DS0VEIChPcGVuKSc7XHJcbiAgICBkb2MudGV4dChgUm9vbSBTdGF0dXM6ICR7bG9ja1N0YXR1c31gLCAyMCwgeSk7XHJcbiAgICB5ICs9IDY7XHJcblxyXG4gICAgY29uc3Qgd2hpdGVsaXN0Q291bnQgPSBzdGF0ZS53aGl0ZWxpc3Q/Lmxlbmd0aCB8fCAwO1xyXG4gICAgZG9jLnRleHQoYFdoaXRlbGlzdCBFbmZvcmNlbWVudDogJHt3aGl0ZWxpc3RDb3VudCA+IDAgPyAnQWN0aXZlJyA6ICdEaXNhYmxlZCd9YCwgMjAsIHkpO1xyXG4gICAgeSArPSAxNTtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIFNFQ1RJT04gMjogVFJBTlNBQ1RJT04gREFUQVxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICBjaGVja1BhZ2VCcmVhayg0MCk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgZG9jLnRleHQoJ1RyYW5zYWN0aW9uIERhdGEnLCAyMCwgeSk7XHJcbiAgICB5ICs9IDg7XHJcblxyXG4gICAgY29uc3QgdHhJZCA9IHN0YXRlLmZpbmFsVHhJZDtcclxuICAgIGlmICh0eElkKSB7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSgxMCk7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoNTApO1xyXG4gICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgICAgZG9jLnRleHQoJ1RyYW5zYWN0aW9uIElEIChUWElEKTonLCAyMCwgeSk7XHJcbiAgICAgIHkgKz0gNTtcclxuXHJcbiAgICAgIGRvYy5zZXRGb250KCdjb3VyaWVyJywgJ2JvbGQnKTtcclxuICAgICAgZG9jLnNldEZvbnRTaXplKDkpO1xyXG4gICAgICBkb2Muc2V0VGV4dENvbG9yKDApO1xyXG4gICAgICBkb2MudGV4dChTdHJpbmcodHhJZCksIDIwLCB5KTtcclxuICAgICAgeSArPSA4O1xyXG5cclxuICAgICAgLy8gQWRkIGEgY2xpY2thYmxlIGxpbmsgaGludFxyXG4gICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2l0YWxpYycpO1xyXG4gICAgICBkb2Muc2V0Rm9udFNpemUoOCk7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTAwKTtcclxuICAgICAgY29uc3QgZXhwbG9yZXJVcmwgPVxyXG4gICAgICAgIHN0YXRlLm5ldHdvcmsgPT09ICd0ZXN0bmV0J1xyXG4gICAgICAgICAgPyAnbWVtcG9vbC5zcGFjZS90ZXN0bmV0L3R4LydcclxuICAgICAgICAgIDogc3RhdGUubmV0d29yayA9PT0gJ3NpZ25ldCdcclxuICAgICAgICAgICAgPyAnbWVtcG9vbC5zcGFjZS9zaWduZXQvdHgvJ1xyXG4gICAgICAgICAgICA6ICdtZW1wb29sLnNwYWNlL3R4Lyc7XHJcbiAgICAgIGRvYy50ZXh0KGBWaWV3IG9uIEV4cGxvcmVyOiAke2V4cGxvcmVyVXJsfSR7dHhJZC5zbGljZSgwLCA4KX0uLi5gLCAyMCwgeSk7XHJcbiAgICAgIHkgKz0gMTA7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUGFydGlhbCBIZXggKFZpc3VhbCBDaGVjaylcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDEwKTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoNTApO1xyXG4gICAgZG9jLnRleHQoJ1JhdyBIZXggRGF0YSAoUGFydGlhbCk6JywgMjAsIHkpO1xyXG4gICAgeSArPSA1O1xyXG5cclxuICAgIGRvYy5zZXRGb250U2l6ZSg4KTtcclxuICAgIGRvYy5zZXRGb250KCdjb3VyaWVyJywgJ25vcm1hbCcpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcig4MCk7XHJcblxyXG4gICAgbGV0IHBhcnRpYWxIZXhEaXNwbGF5ID0gJ05vdCB5ZXQgZmluYWxpemVkJztcclxuICAgIGlmIChmaW5hbEhleCkge1xyXG4gICAgICBwYXJ0aWFsSGV4RGlzcGxheSA9IGAke2ZpbmFsSGV4LnNsaWNlKDAsIDMyKX0uLi5bJHtmaW5hbEhleC5sZW5ndGh9IGJ5dGVzXS4uLiR7ZmluYWxIZXguc2xpY2UoLTMyKX1gO1xyXG4gICAgfVxyXG5cclxuICAgIGRvYy50ZXh0KHBhcnRpYWxIZXhEaXNwbGF5LCAyMCwgeSwgeyBtYXhXaWR0aDogMTcwIH0pO1xyXG4gICAgZG9jLnNldEZvbnQoJ2hlbHZldGljYScsICdub3JtYWwnKTtcclxuICAgIHkgKz0gMTU7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAvLyBTRUNUSU9OIDM6IFNJR05FUiBBQ1RJVklUWVxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICBjaGVja1BhZ2VCcmVhaygzMCk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgZG9jLnRleHQoJ1NpZ25lciBBY3Rpdml0eScsIDIwLCB5KTtcclxuICAgIHkgKz0gMTA7XHJcblxyXG4gICAgZG9jLnNldEZvbnRTaXplKDEwKTtcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnbm9ybWFsJyk7XHJcblxyXG4gICAgaWYgKHNpZ25lcnMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTUwKTtcclxuICAgICAgZG9jLnRleHQoJ05vIHNpZ25lcnMgZGV0ZWN0ZWQgeWV0LicsIDIwLCB5KTtcclxuICAgICAgeSArPSA2O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2lnbmVycy5mb3JFYWNoKChzLCBpKSA9PiB7XHJcbiAgICAgICAgY2hlY2tQYWdlQnJlYWsoMTApO1xyXG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IHMuc2lnbmVkID8gJ1NJR05FRCcgOiAnUEVORElORyc7XHJcbiAgICAgICAgY29uc3QgbGFiZWwgPSBzdGF0ZS5zaWduZXJMYWJlbHM/LltzLmZpbmdlcnByaW50XTtcclxuICAgICAgICBjb25zdCBkaXNwbGF5TmFtZSA9IGxhYmVsID8gYCR7bGFiZWx9ICgke3MuZmluZ2VycHJpbnR9KWAgOiBzLmZpbmdlcnByaW50O1xyXG5cclxuICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDUwKTtcclxuICAgICAgICBkb2MudGV4dChgJHtpICsgMX0uICR7ZGlzcGxheU5hbWV9YCwgMjAsIHkpO1xyXG4gICAgICAgIGRvYy50ZXh0KHN0YXR1cywgMTUwLCB5KTtcclxuICAgICAgICB5ICs9IDY7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgeSArPSAxMDtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIFNFQ1RJT04gNDogUk9PTSBQQVJUSUNJUEFOVFNcclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgY2hlY2tQYWdlQnJlYWsoMzApO1xyXG4gICAgZG9jLnNldEZvbnRTaXplKDE0KTtcclxuICAgIGRvYy5zZXRUZXh0Q29sb3IoMCk7XHJcbiAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgIGRvYy50ZXh0KCdSb29tIFBhcnRpY2lwYW50cyAoV2l0bmVzc2VzKScsIDIwLCB5KTtcclxuICAgIHkgKz0gODtcclxuXHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTApO1xyXG4gICAgZG9jLnNldEZvbnQoJ2hlbHZldGljYScsICdub3JtYWwnKTtcclxuXHJcbiAgICBjb25zdCBwYXJ0aWNpcGFudHNPYmogPSBzdGF0ZS5wYXJ0aWNpcGFudHMgfHwge307XHJcbiAgICBjb25zdCBoaXN0b3JpY2FsUGFydGljaXBhbnRzID0gT2JqZWN0LnZhbHVlcyhwYXJ0aWNpcGFudHNPYmopO1xyXG5cclxuICAgIGlmIChoaXN0b3JpY2FsUGFydGljaXBhbnRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBkb2Muc2V0VGV4dENvbG9yKDE1MCk7XHJcbiAgICAgIGRvYy50ZXh0KCdObyBwYXJ0aWNpcGFudHMgcmVjb3JkZWQuJywgMjAsIHkpO1xyXG4gICAgICB5ICs9IDY7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBoaXN0b3JpY2FsUGFydGljaXBhbnRzLmZvckVhY2goKHA6IGFueSwgaSkgPT4ge1xyXG4gICAgICAgIGNoZWNrUGFnZUJyZWFrKDEwKTtcclxuICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDUwKTtcclxuXHJcbiAgICAgICAgY29uc3Qgcm9sZUJhZGdlID0gcC5yb2xlID09PSAnYWRtaW4nID8gJ1tDb29yZGluYXRvcl0nIDogJ1tHdWVzdF0nO1xyXG4gICAgICAgIGNvbnN0IGRpc3BsYXlOYW1lID0gcC5kaXNwbGF5TmFtZSA/IHAuZGlzcGxheU5hbWUgOiAnQW5vbnltb3VzJztcclxuXHJcbiAgICAgICAgZG9jLnNldEZvbnQoJ2hlbHZldGljYScsICdib2xkJyk7XHJcbiAgICAgICAgZG9jLnRleHQoYCR7aSArIDF9LiAke2Rpc3BsYXlOYW1lfSAke3JvbGVCYWRnZX1gLCAyMCwgeSk7XHJcblxyXG4gICAgICAgIGRvYy5zZXRGb250KCdjb3VyaWVyJywgJ25vcm1hbCcpO1xyXG4gICAgICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDEwMCk7XHJcbiAgICAgICAgZG9jLnRleHQoYFNlc3Npb24gSUQ6ICR7cC5pZH1gLCAxNDAsIHkpO1xyXG5cclxuICAgICAgICBkb2Muc2V0Rm9udFNpemUoMTApO1xyXG4gICAgICAgIHkgKz0gNjtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICB5ICs9IDEwO1xyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgLy8gU0VDVElPTiA1OiBFVkVOVCBUSU1FTElORVxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICBjaGVja1BhZ2VCcmVhaygzMCk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgZG9jLnRleHQoJ0V2ZW50IFRpbWVsaW5lJywgMjAsIHkpO1xyXG4gICAgeSArPSAxMDtcclxuXHJcbiAgICBkb2Muc2V0Rm9udFNpemUoOSk7XHJcbiAgICBjb25zdCBsb2dzID0gc3RhdGUuYXVkaXRMb2cgfHwgW107XHJcblxyXG4gICAgaWYgKGxvZ3MubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTUwKTtcclxuICAgICAgZG9jLnNldEZvbnQoJ2hlbHZldGljYScsICdpdGFsaWMnKTtcclxuICAgICAgZG9jLnRleHQoJ05vIGV2ZW50cyBsb2dnZWQgeWV0LicsIDIwLCB5KTtcclxuICAgICAgeSArPSA2O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbG9ncy5mb3JFYWNoKChsb2cpID0+IHtcclxuICAgICAgICBpZiAoIWxvZykgcmV0dXJuO1xyXG4gICAgICAgIGNoZWNrUGFnZUJyZWFrKDE1KTtcclxuXHJcbiAgICAgICAgY29uc3Qgc2FmZUV2ZW50ID0gbG9nLmV2ZW50ID8gU3RyaW5nKGxvZy5ldmVudCkgOiAnU3lzdGVtIEV2ZW50JztcclxuICAgICAgICBjb25zdCBzYWZlVXNlciA9IGxvZy51c2VyID8gU3RyaW5nKGxvZy51c2VyKSA6ICdTeXN0ZW0nO1xyXG5cclxuICAgICAgICBjb25zdCB0aW1lID0gbG9nLnRpbWVzdGFtcCA/IG5ldyBEYXRlKGxvZy50aW1lc3RhbXApLnRvTG9jYWxlVGltZVN0cmluZygpIDogJy0tOi0tJztcclxuICAgICAgICBjb25zdCBkYXRlID0gbG9nLnRpbWVzdGFtcCA/IG5ldyBEYXRlKGxvZy50aW1lc3RhbXApLnRvTG9jYWxlRGF0ZVN0cmluZygpIDogJy0tLy0tLy0tJztcclxuXHJcbiAgICAgICAgZG9jLnNldFRleHRDb2xvcigxMjApO1xyXG4gICAgICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnbm9ybWFsJyk7XHJcbiAgICAgICAgZG9jLnRleHQoYCR7ZGF0ZX0gJHt0aW1lfWAsIDIwLCB5KTtcclxuXHJcbiAgICAgICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgICAgICBkb2MudGV4dChzYWZlRXZlbnQsIDY1LCB5KTtcclxuXHJcbiAgICAgICAgZG9jLnNldEZvbnQoJ2hlbHZldGljYScsICdub3JtYWwnKTtcclxuICAgICAgICBkb2MudGV4dChzYWZlVXNlciwgMTEwLCB5KTtcclxuXHJcbiAgICAgICAgaWYgKGxvZy5kZXRhaWwpIHtcclxuICAgICAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTAwKTtcclxuICAgICAgICAgIGNvbnN0IGRldGFpbFN0ciA9IFN0cmluZyhsb2cuZGV0YWlsKTtcclxuICAgICAgICAgIGNvbnN0IGRldGFpbFRleHQgPSBkZXRhaWxTdHIubGVuZ3RoID4gMzAgPyBkZXRhaWxTdHIuc3Vic3RyaW5nKDAsIDI3KSArICcuLi4nIDogZGV0YWlsU3RyO1xyXG4gICAgICAgICAgZG9jLnRleHQoZGV0YWlsVGV4dCwgMTUwLCB5KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgeSArPSA3O1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIHkgKz0gMTA7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAvLyBTRUNUSU9OIDY6IElOUFVUIFZFUklGSUNBVElPTlxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICBjaGVja1BhZ2VCcmVhaygzMCk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgZG9jLnRleHQoJ0lucHV0IFZlcmlmaWNhdGlvbiAoU291cmNlcyknLCAyMCwgeSk7XHJcbiAgICB5ICs9IDY7XHJcblxyXG4gICAgZG9jLnNldERyYXdDb2xvcigyMDApO1xyXG4gICAgZG9jLmxpbmUoMjAsIHksIDE5MCwgeSk7XHJcbiAgICB5ICs9IDU7XHJcblxyXG4gICAgY29uc3QgaW5wdXRzID0gdHg/LmlucHV0c0xpc3QgfHwgW107XHJcbiAgICBjb25zdCB3aGl0ZWxpc3QgPSBzdGF0ZS53aGl0ZWxpc3QgfHwgW107XHJcblxyXG4gICAgaWYgKGlucHV0cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgZG9jLnNldEZvbnQoJ2hlbHZldGljYScsICdpdGFsaWMnKTtcclxuICAgICAgZG9jLnNldEZvbnRTaXplKDkpO1xyXG4gICAgICBkb2Muc2V0VGV4dENvbG9yKDE1MCk7XHJcbiAgICAgIGRvYy50ZXh0KCdObyBpbnB1dCBkYXRhIHBhcnNlZC4nLCAyMCwgeSk7XHJcbiAgICAgIHkgKz0gNjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGlucHV0cy5mb3JFYWNoKChpbnB0LCBpKSA9PiB7XHJcbiAgICAgICAgY2hlY2tQYWdlQnJlYWsoMTUpO1xyXG4gICAgICAgIGNvbnN0IGlzV2hpdGVsaXN0ZWQgPSB3aGl0ZWxpc3QuaW5jbHVkZXMoaW5wdC5hZGRyZXNzKTtcclxuICAgICAgICBjb25zdCBhbW91bnQgPSAoaW5wdC5hbW91bnQgLyAxMDAwMDAwMDApLnRvRml4ZWQoOCk7XHJcblxyXG4gICAgICAgIGRvYy5zZXRGb250U2l6ZSg4KTtcclxuICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDUwKTtcclxuICAgICAgICBkb2Muc2V0Rm9udCgnY291cmllcicsICdub3JtYWwnKTtcclxuICAgICAgICBkb2MudGV4dChgJHtpICsgMX0uICR7aW5wdC5hZGRyZXNzfWAsIDIwLCB5KTtcclxuICAgICAgICB5ICs9IDQ7XHJcblxyXG4gICAgICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgICAgIGRvYy5zZXRGb250U2l6ZSg5KTtcclxuICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDApO1xyXG4gICAgICAgIGRvYy50ZXh0KGAke2Ftb3VudH0gQlRDYCwgMjUsIHkpO1xyXG5cclxuICAgICAgICBpZiAod2hpdGVsaXN0Lmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgZG9jLnNldFRleHRDb2xvcigxMDApO1xyXG4gICAgICAgICAgZG9jLnRleHQoJ05PIFdISVRFTElTVCcsIDE1MCwgeSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChpc1doaXRlbGlzdGVkKSB7XHJcbiAgICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDE2LCAxODUsIDEyOSk7XHJcbiAgICAgICAgICBkb2MudGV4dCgnVkVSSUZJRUQgU09VUkNFJywgMTUwLCB5KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgZG9jLnNldFRleHRDb2xvcigyMjAsIDM4LCAzOCk7XHJcbiAgICAgICAgICBkb2MudGV4dCgnVU5WRVJJRklFRCcsIDE1MCwgeSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB5ICs9IDg7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgeSArPSAxMDtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIC8vIFNFQ1RJT04gNzogT1VUUFVUIFZFUklGSUNBVElPTlxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICBjaGVja1BhZ2VCcmVhaygzMCk7XHJcbiAgICBkb2Muc2V0Rm9udFNpemUoMTQpO1xyXG4gICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnYm9sZCcpO1xyXG4gICAgZG9jLnRleHQoJ091dHB1dCBWZXJpZmljYXRpb24nLCAyMCwgeSk7XHJcbiAgICB5ICs9IDY7XHJcblxyXG4gICAgZG9jLnNldERyYXdDb2xvcigyMDApO1xyXG4gICAgZG9jLmxpbmUoMjAsIHksIDE5MCwgeSk7XHJcbiAgICB5ICs9IDU7XHJcblxyXG4gICAgY29uc3Qgb3V0cHV0cyA9IHR4Py5vdXRwdXRzIHx8IFtdO1xyXG5cclxuICAgIGlmIChvdXRwdXRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2l0YWxpYycpO1xyXG4gICAgICBkb2Muc2V0Rm9udFNpemUoOSk7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTUwKTtcclxuICAgICAgZG9jLnRleHQoJ05vIG91dHB1dCBkYXRhIGF2YWlsYWJsZSB5ZXQuJywgMjAsIHkpO1xyXG4gICAgICB5ICs9IDY7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBvdXRwdXRzLmZvckVhY2goKG91dCwgaSkgPT4ge1xyXG4gICAgICAgIGNoZWNrUGFnZUJyZWFrKDE1KTtcclxuICAgICAgICBjb25zdCBpc1doaXRlbGlzdGVkID0gd2hpdGVsaXN0LmluY2x1ZGVzKG91dC5hZGRyZXNzKTtcclxuICAgICAgICBjb25zdCBhbW91bnQgPSAob3V0LmFtb3VudCAvIDEwMDAwMDAwMCkudG9GaXhlZCg4KTtcclxuXHJcbiAgICAgICAgZG9jLnNldEZvbnRTaXplKDgpO1xyXG4gICAgICAgIGRvYy5zZXRUZXh0Q29sb3IoNTApO1xyXG4gICAgICAgIGRvYy5zZXRGb250KCdjb3VyaWVyJywgJ25vcm1hbCcpO1xyXG4gICAgICAgIGRvYy50ZXh0KGAke2kgKyAxfS4gJHtvdXQuYWRkcmVzc31gLCAyMCwgeSk7XHJcbiAgICAgICAgeSArPSA0O1xyXG5cclxuICAgICAgICBkb2Muc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcclxuICAgICAgICBkb2Muc2V0Rm9udFNpemUoOSk7XHJcbiAgICAgICAgZG9jLnNldFRleHRDb2xvcigwKTtcclxuICAgICAgICBkb2MudGV4dChgJHthbW91bnR9IEJUQ2AsIDI1LCB5KTtcclxuXHJcbiAgICAgICAgaWYgKHdoaXRlbGlzdC5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTAwKTtcclxuICAgICAgICAgIGRvYy50ZXh0KCdOTyBXSElURUxJU1QnLCAxNTAsIHkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAob3V0LmlzQ2hhbmdlKSB7XHJcbiAgICAgICAgICBkb2Muc2V0VGV4dENvbG9yKDI0NSwgMTU4LCAxMSk7XHJcbiAgICAgICAgICBkb2MudGV4dCgnQ0hBTkdFIChWRVJJRklFRCknLCAxNTAsIHkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoaXNXaGl0ZWxpc3RlZCkge1xyXG4gICAgICAgICAgZG9jLnNldFRleHRDb2xvcigxNiwgMTg1LCAxMjkpOyAvLyBHcmVlblxyXG4gICAgICAgICAgZG9jLnRleHQoJ1ZFUklGSUVEIERFU1RJTkFUSU9OJywgMTUwLCB5KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgZG9jLnNldFRleHRDb2xvcigyMjAsIDM4LCAzOCk7IC8vIFJlZFxyXG4gICAgICAgICAgZG9jLnRleHQoJ1VOVkVSSUZJRUQnLCAxNTAsIHkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgeSArPSA4O1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGRvYy5zZXREcmF3Q29sb3IoMjAwKTtcclxuICAgICAgZG9jLmxpbmUoMjAsIHksIDE5MCwgeSk7XHJcbiAgICAgIHkgKz0gODtcclxuXHJcbiAgICAgIGRvYy5zZXRGb250KCdoZWx2ZXRpY2EnLCAnbm9ybWFsJyk7XHJcbiAgICAgIGRvYy5zZXRGb250U2l6ZSgxMCk7XHJcbiAgICAgIGRvYy5zZXRUZXh0Q29sb3IoMTAwKTtcclxuICAgICAgZG9jLnRleHQoYFRvdGFsIE91dHB1dHM6ICR7b3V0cHV0cy5sZW5ndGh9YCwgMjAsIHkpO1xyXG4gICAgICB5ICs9IDE1O1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgLy8gRk9PVEVSIChGSUxFIE1FVEFEQVRBIE9OTFkpXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIGNvbnN0IGRhdGVTdHIgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcclxuICAgIGNvbnN0IHNob3J0SWQgPSBzdGF0ZS5yb29tSWQuc2xpY2UoMCwgOCk7XHJcbiAgICBjb25zdCB0eFN1ZmZpeCA9IHN0YXRlLmZpbmFsVHhJZCA/IHN0YXRlLmZpbmFsVHhJZC5zbGljZSgwLCA4KSA6ICdQZW5kaW5nJztcclxuICAgIGxldCBmaWxlbmFtZSA9IGBTaWduaW5nUm9vbV9BdWRpdF8ke2RhdGVTdHJ9X1Jvb20tJHtzaG9ydElkfV9UeC0ke3R4U3VmZml4fS5wZGZgO1xyXG5cclxuICAgIGlmIChvcHRpb25zPy5pc1doaXRlbGFiZWwpIHtcclxuICAgICAgZmlsZW5hbWUgPSBgJHtvcHRpb25zPy5icmFuZE5hbWU/LnJlcGxhY2UoL1xccysvZywgJycpIHx8ICdTaWduaW5nUm9vbSd9X0F1ZGl0XyR7ZGF0ZVN0cn1fUm9vbS0ke3Nob3J0SWR9X1R4LSR7dHhTdWZmaXh9LnBkZmA7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHsgZG9jLCBmaWxlbmFtZSB9O1xyXG4gIH1cclxuICAvKipcclxuICAgKiBEZXJpdmVzIGEgZGV0ZXJtaW5pc3RpYyBjcnlwdG9ncmFwaGljIGhhc2ggY29ubmVjdGluZyB0aGUgY2hyb25vbG9naWNhbCBhdWRpdCBsb2cgYW5kIHRoZSBmaW5hbCB0cmFuc2FjdGlvbiBoZXguXHJcbiAgICogUHJldmVudHMgcG9zdC1ob2MgbW9kaWZpY2F0aW9uIG9mIGVpdGhlciB0aGUgaGlzdG9yaWNhbCBsb2cgb3IgdGhlIGZpbmFsaXplZCB0cmFuc2FjdGlvbiBkYXRhLlxyXG4gICAqIEBwYXJhbSBhdWRpdExvZyAtIFRoZSBhcnJheSBvZiBoaXN0b3JpY2FsIFJvb21TdGF0ZSBsb2cgZW50cmllcy5cclxuICAgKiBAcGFyYW0gZmluYWxUeEhleCAtIFRoZSBicm9hZGNhc3QtcmVhZHkgcmF3IHRyYW5zYWN0aW9uIGhleC5cclxuICAgKiBAcmV0dXJucyBBIFByb21pc2UgcmVzb2x2aW5nIHRvIGEgNjQtY2hhcmFjdGVyIFNIQS0yNTYgaGV4IHN0cmluZy5cclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgY2FsY3VsYXRlRm9yZW5zaWNBbmNob3IoXHJcbiAgICBhdWRpdExvZzogQXVkaXRFbnRyeVtdLFxyXG4gICAgZmluYWxUeEhleDogc3RyaW5nLFxyXG4gICk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCBzb3J0ZWRMb2cgPSBbLi4uYXVkaXRMb2ddLnNvcnQoKGEsIGIpID0+IGEudGltZXN0YW1wIC0gYi50aW1lc3RhbXApO1xyXG5cclxuICAgIGNvbnN0IGxvZ1N0cmluZ3MgPSBzb3J0ZWRMb2cubWFwKChlbnRyeSkgPT4ge1xyXG4gICAgICByZXR1cm4gYCR7bmV3IERhdGUoZW50cnkudGltZXN0YW1wKS50b0lTT1N0cmluZygpfXwke2VudHJ5LmV2ZW50fXwke2VudHJ5LnVzZXJ9fCR7ZW50cnkuZGV0YWlsIHx8ICcnfWA7XHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBwYXlsb2FkID0gbG9nU3RyaW5ncy5qb2luKCcnKSArIGZpbmFsVHhIZXg7XHJcblxyXG4gICAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xyXG4gICAgY29uc3QgZGF0YSA9IGVuY29kZXIuZW5jb2RlKHBheWxvYWQpO1xyXG4gICAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgZGF0YSk7XHJcblxyXG4gICAgcmV0dXJuIEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaEJ1ZmZlcikpXHJcbiAgICAgIC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXHJcbiAgICAgIC5qb2luKCcnKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFZlcmlmaWVzIHRoYXQgdGhlIGN1cnJlbnQgYXVkaXQgbG9nIGFuZCB0cmFuc2FjdGlvbiBoZXggbWF0Y2ggYSBwcmV2aW91c2x5IGlzc3VlZCBmb3JlbnNpYyBhbmNob3IuXHJcbiAgICogQHBhcmFtIHN0YXRlIC0gVGhlIGZpbmFsaXplZCBSb29tU3RhdGUgdG8gdmVyaWZ5LlxyXG4gICAqIEBwYXJhbSBleHBlY3RlZEFuY2hvciAtIFRoZSBrbm93biwgcHJldmlvdXNseSBjYWxjdWxhdGVkIFNIQS0yNTYgaGFzaC5cclxuICAgKiBAcmV0dXJucyBBIFByb21pc2UgcmVzb2x2aW5nIHRvIGFuIG9iamVjdCBjb250YWluaW5nIHRoZSByZS1jYWxjdWxhdGVkIGFuY2hvciBhbmQgYSBib29sZWFuIHZhbGlkaXR5IGZsYWcuXHJcbiAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSByb29tIHN0YXRlIGxhY2tzIHJlcXVpcmVkIGZpbmFsaXphdGlvbiBwYXJhbWV0ZXJzIChoZXggb3IgbG9nKS5cclxuICAgKi9cclxuICBzdGF0aWMgYXN5bmMgdmVyaWZ5Um9vbUludGVncml0eShcclxuICAgIHN0YXRlOiBSb29tU3RhdGUsXHJcbiAgICBleHBlY3RlZEFuY2hvcjogc3RyaW5nLFxyXG4gICk6IFByb21pc2U8eyBhbmNob3I6IHN0cmluZzsgaXNWYWxpZDogYm9vbGVhbiB9PiB7XHJcbiAgICBpZiAoIXN0YXRlLmZpbmFsVHhIZXggfHwgIXN0YXRlLmF1ZGl0TG9nKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcignUm9vbSBub3QgZmluYWxpemVkIG9yIGF1ZGl0IGxvZyBtaXNzaW5nJyk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY2FsY3VsYXRlZEFuY2hvciA9IGF3YWl0IHRoaXMuY2FsY3VsYXRlRm9yZW5zaWNBbmNob3Ioc3RhdGUuYXVkaXRMb2csIHN0YXRlLmZpbmFsVHhIZXgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IGNhbGN1bGF0ZWRBbmNob3IgPT09IGV4cGVjdGVkQW5jaG9yO1xyXG5cclxuICAgIHJldHVybiB7IGFuY2hvcjogY2FsY3VsYXRlZEFuY2hvciwgaXNWYWxpZCB9O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogRXh0cmFjdHMgYSBmcmVzaCBjcnlwdG9ncmFwaGljIGludGVncml0eSByZXBvcnQgZm9yIGEgZmluYWxpemVkIHJvb20uXHJcbiAgICogQHBhcmFtIHN0YXRlIC0gVGhlIGZpbmFsaXplZCBSb29tU3RhdGUuXHJcbiAgICogQHJldHVybnMgQSBQcm9taXNlIHJlc29sdmluZyB0byB0aGUgY2FsY3VsYXRlZCBmb3JlbnNpYyBhbmNob3IgYW5kIHRoZSBjdXJyZW50IElTTyB0aW1lc3RhbXAuXHJcbiAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSByb29tIHN0YXRlIGxhY2tzIHJlcXVpcmVkIGZpbmFsaXphdGlvbiBwYXJhbWV0ZXJzLlxyXG4gICAqL1xyXG4gIHN0YXRpYyBhc3luYyBnZXRJbnRlZ3JpdHlSZXBvcnQoXHJcbiAgICBzdGF0ZTogUm9vbVN0YXRlLFxyXG4gICk6IFByb21pc2U8eyBhbmNob3I6IHN0cmluZzsgdGltZXN0YW1wOiBzdHJpbmcgfT4ge1xyXG4gICAgaWYgKCFzdGF0ZS5maW5hbFR4SGV4IHx8ICFzdGF0ZS5hdWRpdExvZykgdGhyb3cgbmV3IEVycm9yKCdSb29tIG5vdCBmaW5hbGl6ZWQnKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBhbmNob3I6IGF3YWl0IHRoaXMuY2FsY3VsYXRlRm9yZW5zaWNBbmNob3Ioc3RhdGUuYXVkaXRMb2csIHN0YXRlLmZpbmFsVHhIZXgpLFxyXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IEVuY3J5cHRpb25FbmdpbmUgfSBmcm9tICcuL2NyeXB0by9lbmNyeXB0aW9uLWVuZ2luZSc7XHJcbmltcG9ydCB7IFJlbGF5Q2xpZW50IH0gZnJvbSAnLi9yZWxheS9yZWxheS1jbGllbnQnO1xyXG5pbXBvcnQgeyBSb29tU3RhdGVTdG9yZSwgUm9vbVN0YXRlIH0gZnJvbSAnLi9yZWxheS9yb29tLXN0YXRlLXN0b3JlJztcclxuaW1wb3J0IHsgUm9vbUZhY3RvcnksIFJvb21DcmVhdGlvblBheWxvYWQgfSBmcm9tICcuL3JlbGF5L3Jvb20tZmFjdG9yeSc7XHJcbmltcG9ydCB7IFJvb21FdmVudCwgUm9vbUV2ZW50VHlwZSB9IGZyb20gJy4vdHlwZXMvY2xpZW50LWV2ZW50cyc7XHJcbmltcG9ydCB7IEF1ZGl0TG9nT3B0aW9ucywgUm9vbUF1ZGl0b3IgfSBmcm9tICcuL2JpdGNvaW4vcm9vbS1hdWRpdG9yJztcclxuaW1wb3J0IHsgUHNidFV0aWxzLCBUeERldGFpbHMgfSBmcm9tICcuL2JpdGNvaW4vcHNidC11dGlscyc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUsIGZpcnN0VmFsdWVGcm9tIH0gZnJvbSAncnhqcyc7XHJcbmltcG9ydCB7IGpzUERGIH0gZnJvbSAnanNwZGYnO1xyXG5cclxuLyoqXHJcbiAqIENvbmZpZ3VyYXRpb24gc2NoZW1hIGZvciBpbml0aWFsaXppbmcgdGhlIFNpZ25pbmdSb29tIFNESyBjbGllbnQuXHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIFNpZ25pbmdSb29tQ29uZmlnIHtcclxuICAvKiogVGhlIGJhc2UgVVJMIG9mIHRoZSBTaWduaW5nUm9vbSBzaWduYWxpbmcgQVBJLiAqL1xyXG4gIGFwaVVybDogc3RyaW5nO1xyXG4gIC8qKiBPcHRpb25hbCB2ZXJzaW9uIHRhZyB0byBlbnN1cmUgY29tcGF0aWJpbGl0eSB3aXRoIGJhY2tlbmQgcHJvdG9jb2wgdXBkYXRlcy4gKi9cclxuICBwcm90b2NvbFZlcnNpb24/OiBzdHJpbmc7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBUaGUgcHJpbWFyeSBlbnRyeSBwb2ludCBmb3IgdGhlIFNpZ25pbmdSb29tIFNESy5cclxuICogRmFjaWxpdGF0ZXMgcm9vbSBvcmNoZXN0cmF0aW9uLCBjcnlwdG9ncmFwaGljIGtleSBtYW5hZ2VtZW50LCByZWxheSBjb29yZGluYXRpb24sXHJcbiAqIGFuZCBhdXRvbWF0ZWQgc3RhdGUgc3luY2hyb25pemF0aW9uIGFjcm9zcyB0aGUgY29sbGFib3JhdGl2ZSBsaWZlY3ljbGUuXHJcbiAqL1xyXG5leHBvcnQgY2xhc3MgU2lnbmluZ1Jvb21DbGllbnQge1xyXG4gIHB1YmxpYyByZWFkb25seSBlbmdpbmU6IEVuY3J5cHRpb25FbmdpbmU7XHJcbiAgcHVibGljIHJlYWRvbmx5IHJlbGF5OiBSZWxheUNsaWVudDtcclxuICBwdWJsaWMgcmVhZG9ubHkgc3RvcmU6IFJvb21TdGF0ZVN0b3JlO1xyXG5cclxuICBwcml2YXRlIGFwaVVybDogc3RyaW5nO1xyXG4gIHByaXZhdGUgcHJvdG9jb2xWZXJzaW9uOiBzdHJpbmc7XHJcbiAgcHJpdmF0ZSBfc2Vzc2lvbklkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuICBwcml2YXRlIF9yb2xlOiAnYWRtaW4nIHwgJ2d1ZXN0JyA9ICdndWVzdCc7XHJcbiAgcHJpdmF0ZSBfZW5jcnlwdGlvbktleTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIC8qKlxyXG4gICAqIEluaXRpYWxpemVzIGEgbmV3IFNpZ25pbmdSb29tIGNsaWVudC5cclxuICAgKiBAcGFyYW0gY29uZmlnIC0gVGhlIEFQSSBjb25maWd1cmF0aW9uIGFuZCBvcHRpb25hbCBwcm90b2NvbCB2ZXJzaW9uaW5nLlxyXG4gICAqL1xyXG4gIGNvbnN0cnVjdG9yKGNvbmZpZzogU2lnbmluZ1Jvb21Db25maWcpIHtcclxuICAgIHRoaXMuYXBpVXJsID0gY29uZmlnLmFwaVVybC5yZXBsYWNlKC9cXC8kLywgJycpO1xyXG4gICAgdGhpcy5wcm90b2NvbFZlcnNpb24gPSBjb25maWcucHJvdG9jb2xWZXJzaW9uIHx8ICcxLjAuMCc7XHJcblxyXG4gICAgdGhpcy5lbmdpbmUgPSBuZXcgRW5jcnlwdGlvbkVuZ2luZSgpO1xyXG4gICAgdGhpcy5yZWxheSA9IG5ldyBSZWxheUNsaWVudCh0aGlzLmVuZ2luZSk7XHJcbiAgICB0aGlzLnN0b3JlID0gbmV3IFJvb21TdGF0ZVN0b3JlKHRoaXMucmVsYXkuZXZlbnRzKTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50cy5vbignU0VTU0lPTl9DT05ORUNURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5fc2Vzc2lvbklkID0gZS5wYXlsb2FkO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1JPTEVfVVBEQVRFJykuc3Vic2NyaWJlKGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIGNvbnN0IG5ld1JvbGUgPSBlLnBheWxvYWQ7XHJcbiAgICAgIGlmICh0aGlzLl9yb2xlID09PSAnZ3Vlc3QnICYmIG5ld1JvbGUgPT09ICdhZG1pbicpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLmxvZ1BhcnRpY2lwYW50QWN0aW9uKFxyXG4gICAgICAgICAgJ1JvbGUgQ2xhaW1lZCBDb29yZGluYXRvcicsXHJcbiAgICAgICAgICBgU2Vzc2lvbiBJRDogJHt0aGlzLl9zZXNzaW9uSWR9IHVwZ3JhZGVkYCxcclxuICAgICAgICAgICdDb29yZGluYXRvcicsXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLl9yb2xlID0gbmV3Um9sZTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMucmVsYXkuZXZlbnRzLm9uKCdORVdfUEFSVElBTF9ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgY29uc3QgcHJvZ3Jlc3MgPSB0aGlzLmdldFNpZ25hdHVyZVByb2dyZXNzKCk7XHJcbiAgICAgIGNvbnN0IHRocmVzaG9sZCA9IHRoaXMuZ2V0VGhyZXNob2xkKHRoaXMuZ2V0Um9vbVN0YXRlKCkpO1xyXG5cclxuICAgICAgdGhpcy5yZWxheS5ldmVudHMuZGlzcGF0Y2goJ1NJR05BVFVSRV9SRUNFSVZFRCcsIHtcclxuICAgICAgICBmaW5nZXJwcmludDogZS5wYXlsb2FkPy5maW5nZXJwcmludCxcclxuICAgICAgICBzaWduYXR1cmVzUmVjZWl2ZWQ6IHByb2dyZXNzLnNpZ25hdHVyZXNSZWNlaXZlZCxcclxuICAgICAgICB0b3RhbFNpZ25lcnM6IHByb2dyZXNzLnRvdGFsU2lnbmVycyxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAodGhpcy5pc1RocmVzaG9sZE1ldCgpKSB7XHJcbiAgICAgICAgdGhpcy5yZWxheS5ldmVudHMuZGlzcGF0Y2goJ1RIUkVTSE9MRF9NRVQnLCB7XHJcbiAgICAgICAgICBzaWduYXR1cmVzUmVjZWl2ZWQ6IHByb2dyZXNzLnNpZ25hdHVyZXNSZWNlaXZlZCxcclxuICAgICAgICAgIHRocmVzaG9sZDogdGhyZXNob2xkLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgYSBodW1hbi1yZWFkYWJsZSBpZGVudGlmaWVyIGZvciB0aGUgY3VycmVudCB1c2VyJ3Mgc2Vzc2lvbiBhbmQgcm9sZS5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0IHVzZXJDb250ZXh0KCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gdGhpcy5fcm9sZSA9PT0gJ2FkbWluJyA/ICdDb29yZGluYXRvcicgOiBgR3Vlc3QgKCR7dGhpcy5fc2Vzc2lvbklkIHx8ICdVbmtub3duJ30pYDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb3ZpZGVzIGFuIG9ic2VydmFibGUgc3RyZWFtIG9mIHJvb20gc3RhdGUgY2hhbmdlcyBmb3IgVUkgcmVhY3Rpdml0eS5cclxuICAgKi9cclxuICBwdWJsaWMgb25TdGF0ZUNoYW5nZSgpOiBPYnNlcnZhYmxlPFJvb21FdmVudD4ge1xyXG4gICAgcmV0dXJuIHRoaXMucmVsYXkuZXZlbnRzLm9uKCdTVEFURV9DSEFOR0VEJyk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBTdWJzY3JpYmVzIHRvIHNwZWNpZmljIHJvb20gZXZlbnRzIHRyaWdnZXJlZCBieSBuZXR3b3JrIG9wZXJhdGlvbnMuXHJcbiAgICogKiBAcGFyYW0gZXZlbnRUeXBlIC0gVGhlIHNwZWNpZmljIGV2ZW50IHR5cGUgdG8gbGlzdGVuIHRvIChlLmcuLCAnU0lHTkFUVVJFX1JFQ0VJVkVEJylcclxuICAgKiBAcmV0dXJucyBBbiBSeEpTIE9ic2VydmFibGUgeWllbGRpbmcgdGhlIHRhcmdldCBldmVudHMuXHJcbiAgICovXHJcbiAgcHVibGljIG9uRXZlbnQoZXZlbnRUeXBlOiBSb29tRXZlbnRUeXBlKTogT2JzZXJ2YWJsZTxSb29tRXZlbnQ+IHtcclxuICAgIHJldHVybiB0aGlzLnJlbGF5LmV2ZW50cy5vbihldmVudFR5cGUpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0cmlldmVzIHRoZSBjdXJyZW50LCBzeW5jaHJvbml6ZWQgc3RhdGUgb2YgdGhlIHJvb20uXHJcbiAgICovXHJcbiAgcHVibGljIGdldFJvb21TdGF0ZSgpOiBSb29tU3RhdGUgfCBudWxsIHtcclxuICAgIHJldHVybiB0aGlzLnN0b3JlLmdldFN0YXRlKCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBPcmNoZXN0cmF0ZXMgdGhlIGNyZWF0aW9uIG9mIGEgbmV3IGNvbGxhYm9yYXRpdmUgY3J5cHRvZ3JhcGhpYyByb29tLlxyXG4gICAqIEBwYXJhbSBwc2J0QmFzZTY0IC0gVGhlIGluaXRpYWwsIHVuc2lnbmVkIFBTQlQgc3RyaW5nLlxyXG4gICAqIEBwYXJhbSBuZXR3b3JrIC0gVGhlIHRhcmdldCBCaXRjb2luIG5ldHdvcmsgKG1haW5uZXQsIHRlc3RuZXQsIG9yIHNpZ25ldCkuXHJcbiAgICogQHBhcmFtIHJvb21OYW1lIC0gVGhlIGRpc3BsYXkgbmFtZSBmb3IgdGhlIHJvb20uXHJcbiAgICogQHJldHVybnMgVGhlIHJvb20ncyBhY2Nlc3MgY3JlZGVudGlhbHMgaW5jbHVkaW5nIHRoZSBhZG1pbiBzZWNyZXQuXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIGNyZWF0ZVJvb20oXHJcbiAgICBwc2J0QmFzZTY0OiBzdHJpbmcsXHJcbiAgICBuZXR3b3JrOiAnYml0Y29pbicgfCAndGVzdG5ldCcgfCAnc2lnbmV0JyxcclxuICAgIHJvb21OYW1lID0gJ1VudGl0bGVkIFJvb20nLFxyXG4gICkge1xyXG4gICAgY29uc3QgcGF5bG9hZCA9IGF3YWl0IFJvb21GYWN0b3J5LnByZXBhcmVDcmVhdGlvblBheWxvYWQoXHJcbiAgICAgIHRoaXMuZW5naW5lLFxyXG4gICAgICBwc2J0QmFzZTY0LFxyXG4gICAgICBuZXR3b3JrLFxyXG4gICAgICByb29tTmFtZSxcclxuICAgICAgdGhpcy5wcm90b2NvbFZlcnNpb24sXHJcbiAgICApO1xyXG5cclxuICAgIHRoaXMuX2VuY3J5cHRpb25LZXkgPSBwYXlsb2FkLmxvY2FsRGF0YS5lbmNyeXB0aW9uS2V5O1xyXG5cclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke3RoaXMuYXBpVXJsfS9hcGkvcm9vbWAsIHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxyXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkLmh0dHBQYXlsb2FkKSxcclxuICAgIH0pO1xyXG5cclxuICAgIGlmICghcmVzLm9rKSB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBjcmVhdGUgcm9vbTogJHthd2FpdCByZXMudGV4dCgpfWApO1xyXG5cclxuICAgIHJldHVybiBwYXlsb2FkO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogT3JjaGVzdHJhdGVzIHRoZSBjcmVhdGlvbiBvZiBhIG5ldyBjb2xsYWJvcmF0aXZlIGNyeXB0b2dyYXBoaWMgcm9vbSBhbmQgam9pbnMgYXMgY29vcmRpbmF0b3IuXHJcbiAgICogQHBhcmFtIHBzYnRCYXNlNjQgLSBUaGUgaW5pdGlhbCwgdW5zaWduZWQgUFNCVCBzdHJpbmcuXHJcbiAgICogQHBhcmFtIG5ldHdvcmsgLSBUaGUgdGFyZ2V0IEJpdGNvaW4gbmV0d29yayAobWFpbm5ldCwgdGVzdG5ldCwgb3Igc2lnbmV0KS5cclxuICAgKiBAcGFyYW0gcm9vbU5hbWUgLSBUaGUgZGlzcGxheSBuYW1lIGZvciB0aGUgcm9vbS5cclxuICAgKiBAcmV0dXJucyBUaGUgcm9vbSdzIGFjY2VzcyBjcmVkZW50aWFscyBpbmNsdWRpbmcgdGhlIGFkbWluIHNlY3JldC5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgY3JlYXRlUm9vbUFuZEpvaW4oXHJcbiAgICBwc2J0QmFzZTY0OiBzdHJpbmcsXHJcbiAgICBuZXR3b3JrOiAnYml0Y29pbicgfCAndGVzdG5ldCcgfCAnc2lnbmV0JyxcclxuICAgIHJvb21OYW1lID0gJ1VudGl0bGVkIFJvb20nLFxyXG4gICkge1xyXG4gICAgY29uc3QgcGF5bG9hZDogUm9vbUNyZWF0aW9uUGF5bG9hZCA9IGF3YWl0IHRoaXMuY3JlYXRlUm9vbShwc2J0QmFzZTY0LCBuZXR3b3JrLCByb29tTmFtZSk7XHJcblxyXG4gICAgY29uc3QgY29ubmVjdGlvbkV2ZW50ID0gZmlyc3RWYWx1ZUZyb20odGhpcy5yZWxheS5ldmVudHMub24oJ1JPT01fQ09OTkVDVEVEJykpO1xyXG4gICAgY29uc3Qgc2Vzc2lvbkV2ZW50ID0gZmlyc3RWYWx1ZUZyb20odGhpcy5yZWxheS5ldmVudHMub24oJ1NFU1NJT05fQ09OTkVDVEVEJykpO1xyXG5cclxuICAgIGNvbnN0IHdzVXJsID0gdGhpcy5hcGlVcmwucmVwbGFjZSgvXmh0dHAvLCAnd3MnKTtcclxuICAgIHRoaXMuc3RvcmUuaW5pdChwYXlsb2FkLmxvY2FsRGF0YS5yb29tSWQsIHRoaXMucHJvdG9jb2xWZXJzaW9uKTtcclxuICAgIGF3YWl0IHRoaXMucmVsYXkuam9pblJvb20oXHJcbiAgICAgIHdzVXJsLFxyXG4gICAgICBwYXlsb2FkLmxvY2FsRGF0YS5yb29tSWQsXHJcbiAgICAgIHBheWxvYWQubG9jYWxEYXRhLmVuY3J5cHRpb25LZXksXHJcbiAgICAgIHRoaXMucHJvdG9jb2xWZXJzaW9uLFxyXG4gICAgKTtcclxuXHJcbiAgICBhd2FpdCBjb25uZWN0aW9uRXZlbnQ7XHJcbiAgICBhd2FpdCBzZXNzaW9uRXZlbnQ7XHJcblxyXG4gICAgYXdhaXQgdGhpcy5sb2dQYXJ0aWNpcGFudEFjdGlvbignVXNlciBKb2luZWQnLCBgU2Vzc2lvbjogJHt0aGlzLl9zZXNzaW9uSWR9YCk7XHJcblxyXG4gICAgY29uc3Qgcm9sZUV2ZW50ID0gZmlyc3RWYWx1ZUZyb20odGhpcy5yZWxheS5ldmVudHMub24oJ1JPTEVfVVBEQVRFJykpO1xyXG4gICAgdGhpcy5yZWxheS5jbGFpbUNvb3JkaW5hdG9yKHBheWxvYWQuaHR0cFBheWxvYWQuYWRtaW5Ub2tlbik7XHJcbiAgICBhd2FpdCByb2xlRXZlbnQ7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcm9vbUlkOiBwYXlsb2FkLmxvY2FsRGF0YS5yb29tSWQsXHJcbiAgICAgIGVuY3J5cHRpb25LZXk6IHBheWxvYWQubG9jYWxEYXRhLmVuY3J5cHRpb25LZXksXHJcbiAgICAgIGFkbWluU2VjcmV0OiBwYXlsb2FkLmxvY2FsRGF0YS5hZG1pblNlY3JldCxcclxuICAgICAgZW5jcnlwdGVkQWRtaW5Ub2tlbjogcGF5bG9hZC5odHRwUGF5bG9hZC5hZG1pblRva2VuLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEpvaW5zIGFuIGV4aXN0aW5nIHJvb20gdXNpbmcgaXRzIHVuaXF1ZSBJRCBhbmQgZW5jcnlwdGlvbiBrZXkuXHJcbiAgICogQHBhcmFtIHJvb21JZCAtIFVuaXF1ZSBpZGVudGlmaWVyIGZvciB0aGUgcm9vbS5cclxuICAgKiBAcGFyYW0gZW5jcnlwdGlvbktleSAtIFRoZSBzaGFyZWQgc2VjcmV0IGtleSBmb3IgdGhlIHJvb20uXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIGpvaW5Sb29tKHJvb21JZDogc3RyaW5nLCBlbmNyeXB0aW9uS2V5OiBzdHJpbmcpIHtcclxuICAgIHRoaXMuX2VuY3J5cHRpb25LZXkgPSBlbmNyeXB0aW9uS2V5O1xyXG5cclxuICAgIC8vIExpc3RlbiBmb3IgQk9USCBldmVudHNcclxuICAgIGNvbnN0IGNvbm5lY3Rpb25FdmVudCA9IGZpcnN0VmFsdWVGcm9tKHRoaXMucmVsYXkuZXZlbnRzLm9uKCdST09NX0NPTk5FQ1RFRCcpKTtcclxuICAgIGNvbnN0IHNlc3Npb25FdmVudCA9IGZpcnN0VmFsdWVGcm9tKHRoaXMucmVsYXkuZXZlbnRzLm9uKCdTRVNTSU9OX0NPTk5FQ1RFRCcpKTtcclxuXHJcbiAgICBjb25zdCB3c1VybCA9IHRoaXMuYXBpVXJsLnJlcGxhY2UoL15odHRwLywgJ3dzJyk7XHJcbiAgICB0aGlzLnN0b3JlLmluaXQocm9vbUlkLCB0aGlzLnByb3RvY29sVmVyc2lvbik7XHJcblxyXG4gICAgYXdhaXQgdGhpcy5yZWxheS5qb2luUm9vbSh3c1VybCwgcm9vbUlkLCBlbmNyeXB0aW9uS2V5LCB0aGlzLnByb3RvY29sVmVyc2lvbik7XHJcblxyXG4gICAgLy8gQXdhaXQgYm90aCBldmVudHNcclxuICAgIGF3YWl0IGNvbm5lY3Rpb25FdmVudDtcclxuICAgIGF3YWl0IHNlc3Npb25FdmVudDtcclxuXHJcbiAgICBhd2FpdCB0aGlzLmxvZ1BhcnRpY2lwYW50QWN0aW9uKCdVc2VyIEpvaW5lZCcsIGBTZXNzaW9uOiAke3RoaXMuX3Nlc3Npb25JZH1gKTtcclxuICB9XHJcblxyXG4gIC8qKiAqIFVwZGF0ZXMgdGhlIGRpc3BsYXkgbmFtZSBvZiB0aGUgcm9vbS5cclxuICAgKiBAcGFyYW0gbmFtZSAtIFRoZSBuZXcgcm9vbSBuYW1lLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBzZXRSb29tTmFtZShuYW1lOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGNvbmZpcm1hdGlvbiA9IHRoaXMud2FpdEZvckV2ZW50KCdST09NX1JFTkFNRURfREVDUllQVEVEJyk7XHJcbiAgICBhd2FpdCB0aGlzLnJlbGF5LnJlbmFtZVJvb20obmFtZSwgdGhpcy51c2VyQ29udGV4dCk7XHJcbiAgICBhd2FpdCBjb25maXJtYXRpb247XHJcbiAgfVxyXG5cclxuICAvKiogKiBUb2dnbGVzIHRoZSByb29tJ3MgbG9ja2VkIHN0YXR1cyB0byByZXN0cmljdCBwYXJ0aWNpcGFudCBhY2Nlc3MuXHJcbiAgICogQHBhcmFtIGlzTG9ja2VkIC0gQm9vbGVhbiB0b2dnbGUgZm9yIHJvb20gbG9jay5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgdG9nZ2xlTG9jayhpc0xvY2tlZDogYm9vbGVhbikge1xyXG4gICAgY29uc3QgY29uZmlybWF0aW9uID0gdGhpcy53YWl0Rm9yRXZlbnQoJ0xPQ0tfVVBEQVRFRCcpO1xyXG4gICAgYXdhaXQgdGhpcy5yZWxheS50b2dnbGVMb2NrKGlzTG9ja2VkLCB0aGlzLnVzZXJDb250ZXh0KTtcclxuICAgIGF3YWl0IGNvbmZpcm1hdGlvbjtcclxuICB9XHJcblxyXG4gIC8qKiAqIFVwbG9hZHMgYSBwYXJ0aWFsIHNpZ25hdHVyZSB0byB0aGUgcm9vbSBmb3IgdGhlIHNwZWNpZmllZCBoYXJkd2FyZSB3YWxsZXQuXHJcbiAgICogQHBhcmFtIHBzYnRCYXNlNjQgLSBUaGUgcGFydGlhbCBQU0JUIHBheWxvYWQuXHJcbiAgICogQHBhcmFtIGZpbmdlcnByaW50IC0gVGhlIGhhcmR3YXJlIGRldmljZSdzIG1hc3RlciBrZXkgZmluZ2VycHJpbnQuXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIHVwbG9hZFNpZ25hdHVyZShwc2J0QmFzZTY0OiBzdHJpbmcsIGZpbmdlcnByaW50OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGNvbmZpcm1hdGlvbiA9IHRoaXMud2FpdEZvckV2ZW50KCdORVdfUEFSVElBTF9ERUNSWVBURUQnKTtcclxuICAgIGF3YWl0IHRoaXMucmVsYXkudXBsb2FkU2lnbmF0dXJlKHBzYnRCYXNlNjQsIGZpbmdlcnByaW50LCB0aGlzLnVzZXJDb250ZXh0KTtcclxuICAgIGF3YWl0IGNvbmZpcm1hdGlvbjtcclxuICB9XHJcblxyXG4gIC8qKiAqIFJlY29yZHMgYSBzZWN1cmUgYXVkaXQgdHJhaWwgZXZlbnQgZm9yIHRoZSBjdXJyZW50IHJvb20gc3RhdGUuXHJcbiAgICogQHBhcmFtIGFjdGlvbiAtIEh1bWFuLXJlYWRhYmxlIGxhYmVsIG9mIHRoZSBhY3Rpb24uXHJcbiAgICogQHBhcmFtIGRldGFpbCAtIFN1cHBsZW1lbnRhcnkgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGFjdGlvbi5cclxuICAgKiBAcGFyYW0gb3ZlcnJpZGVSb2xlIC0gT3B0aW9uYWwgcm9sZSBvdmVycmlkZSBmb3IgYXVkaXQgcmVwb3J0aW5nLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBsb2dQYXJ0aWNpcGFudEFjdGlvbihhY3Rpb246IHN0cmluZywgZGV0YWlsOiBzdHJpbmcsIG92ZXJyaWRlUm9sZT86IHN0cmluZykge1xyXG4gICAgY29uc3Qgcm9sZUNvbnRleHQgPSBvdmVycmlkZVJvbGUgfHwgdGhpcy51c2VyQ29udGV4dDtcclxuXHJcbiAgICBjb25zdCBibG9iID0gYXdhaXQgdGhpcy5yZWxheS5jcmVhdGVTZWN1cmVMb2dCbG9iKGFjdGlvbiwgZGV0YWlsLCByb2xlQ29udGV4dCk7XHJcbiAgICB0aGlzLnJlbGF5LnNlbmQoJ0xPR19BQ1RJT04nLCB7IGVuY3J5cHRlZExvZ0Jsb2I6IGJsb2IgfSk7XHJcbiAgfVxyXG5cclxuICAvKiogKiBVcGRhdGVzIHRoZSBkaXNwbGF5IG5hbWUgZm9yIHRoZSBjdXJyZW50IHBhcnRpY2lwYW50IHNlc3Npb24uXHJcbiAgICogQHBhcmFtIG5hbWUgLSBUaGUgbmV3IGRpc3BsYXkgbmFtZS5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgc2V0RGlzcGxheU5hbWUobmFtZTogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBjb25maXJtYXRpb24gPSB0aGlzLndhaXRGb3JFdmVudCgnUEFSVElDSVBBTlRTX0RFQ1JZUFRFRCcpO1xyXG4gICAgYXdhaXQgdGhpcy5yZWxheS5zZXREaXNwbGF5TmFtZShuYW1lKTtcclxuICAgIGF3YWl0IHRoaXMubG9nUGFydGljaXBhbnRBY3Rpb24oJ1BhcnRpY2lwYW50IElkZW50aWZpZWQnLCBgSWRlbnRpZmllZCBhcyAnJHtuYW1lfSdgKTtcclxuICAgIGF3YWl0IGNvbmZpcm1hdGlvbjtcclxuICB9XHJcblxyXG4gIC8qKiAqIEFzc2lnbnMgYSBodW1hbi1yZWFkYWJsZSBsYWJlbCB0byBhIGhhcmR3YXJlIGRldmljZSBmaW5nZXJwcmludC5cclxuICAgKiBAcGFyYW0gZmluZ2VycHJpbnQgLSBUaGUgbWFzdGVyIGtleSBmaW5nZXJwcmludC5cclxuICAgKiBAcGFyYW0gbGFiZWwgLSBUaGUgbGFiZWwgdG8gYXBwbHkuXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIHNldFNpZ25lckxhYmVsKGZpbmdlcnByaW50OiBzdHJpbmcsIGxhYmVsOiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGNvbmZpcm1hdGlvbiA9IHRoaXMud2FpdEZvckV2ZW50KCdMQUJFTFNfREVDUllQVEVEJyk7XHJcbiAgICBhd2FpdCB0aGlzLnJlbGF5LnVwZGF0ZVNpZ25lckxhYmVsKGZpbmdlcnByaW50LCBsYWJlbCwgdGhpcy51c2VyQ29udGV4dCk7XHJcbiAgICBhd2FpdCBjb25maXJtYXRpb247XHJcbiAgfVxyXG5cclxuICAvKiogKiBDbG9zZXMgdGhlIHJvb20gc2Vzc2lvbiwgZWplY3RpbmcgYWxsIHBhcnRpY2lwYW50cyBhbmQgd2lwaW5nIHRlbXBvcmFyeSByZWxheSBzdGF0ZS5cclxuICAgKiBPbmx5IHRoZSBDb29yZGluYXRvciBjYW4gZXhlY3V0ZSB0aGlzLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBjbG9zZVJvb20oKSB7XHJcbiAgICBjb25zdCBjb25maXJtYXRpb24gPSB0aGlzLndhaXRGb3JFdmVudCgnUk9PTV9DTE9TRUQnKTtcclxuICAgIHRoaXMucmVsYXkuY2xvc2VSb29tKCk7XHJcbiAgICBhd2FpdCBjb25maXJtYXRpb247XHJcbiAgfVxyXG5cclxuICAvKiogKiBHZW5lcmF0ZXMgYSBDU1YtZm9ybWF0dGVkIGV4cG9ydCBvZiB0aGUgY3VycmVudCBhdWRpdCB0cmFpbC5cclxuICAgKiBAcmV0dXJucyBBIENTViBzdHJpbmcgY29udGFpbmluZyB0aGUgcm9vbSdzIGV2ZW50IGhpc3RvcnkuXHJcbiAgICovXHJcbiAgcHVibGljIGdldEF1ZGl0TG9nQ3N2KCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuZ2V0Um9vbVN0YXRlKCk7XHJcbiAgICBpZiAoIXN0YXRlKSByZXR1cm4gJyc7XHJcbiAgICByZXR1cm4gUm9vbUF1ZGl0b3IuZ2V0QXVkaXRMb2dDc3ZEYXRhKHN0YXRlKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBnZXRTZXR0bGVtZW50Q3N2RGF0YSgpOiBzdHJpbmcge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgY29uc3QgdHggPSB0aGlzLmdldFR4RGV0YWlscyhzdGF0ZSk7XHJcbiAgICBjb25zdCBzaWduZXJzID0gdGhpcy5nZXRTaWduZXJzU3RhdHVzKHN0YXRlKTtcclxuXHJcbiAgICBpZiAoIXN0YXRlIHx8ICF0eCkgcmV0dXJuICcnO1xyXG5cclxuICAgIHJldHVybiBSb29tQXVkaXRvci5nZXRTZXR0bGVtZW50Q3N2RGF0YShzdGF0ZSwgdHgsIHNpZ25lcnMpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGFzeW5jIGdldEF1ZGl0TG9nUGRmKG9wdGlvbnM/OiBBdWRpdExvZ09wdGlvbnMpOiBQcm9taXNlPHsgZG9jOiBhbnk7IGZpbGVuYW1lOiBzdHJpbmcgfT4ge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgY29uc3QgdHggPSB0aGlzLmdldFR4RGV0YWlscyhzdGF0ZSk7XHJcbiAgICBjb25zdCBzaWduZXJzID0gdGhpcy5nZXRTaWduZXJzU3RhdHVzKHN0YXRlKTtcclxuICAgIGNvbnN0IGZpbmFsSGV4ID0gdGhpcy5nZXRGaW5hbFRyYW5zYWN0aW9uSGV4KCk7XHJcblxyXG4gICAgaWYgKCFzdGF0ZSkgdGhyb3cgbmV3IEVycm9yKCdObyBzdGF0ZSBhdmFpbGFibGUgZm9yIGF1ZGl0IHJlcG9ydC4nKTtcclxuXHJcbiAgICByZXR1cm4gYXdhaXQgUm9vbUF1ZGl0b3IuZ2VuZXJhdGVBdWRpdFBkZihuZXcganNQREYoKSwgc3RhdGUsIHR4LCBzaWduZXJzLCBmaW5hbEhleCwgb3B0aW9ucyk7XHJcbiAgfVxyXG5cclxuICAvKiogKiBVcGRhdGVzIHRoZSB3aGl0ZWxpc3QgYWxsb3dsaXN0LiBIYW5kbGVzIGJvdGggc2luZ2xlIGFkZHJlc3NlcyBhbmQgYmF0Y2hlcyxcclxuICAgKiBhdXRvbWF0aWNhbGx5IGZvcm1hdHRpbmcgdGhlIGF1ZGl0IGxvZyBhcHByb3ByaWF0ZWx5LlxyXG4gICAqIEBwYXJhbSBhZGRyZXNzZXMgLSBBcnJheSBvZiBhZGRyZXNzZXMgdG8gYWRkIG9yIHJlbW92ZS5cclxuICAgKiBAcGFyYW0gcmVtb3ZlIC0gVG9nZ2xlIHRvIGVpdGhlciBhZGQgKGZhbHNlKSBvciByZW1vdmUgKHRydWUpIGFkZHJlc3Nlcy5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgdXBkYXRlV2hpdGVsaXN0KGFkZHJlc3Nlczogc3RyaW5nW10sIHJlbW92ZTogYm9vbGVhbiA9IGZhbHNlKSB7XHJcbiAgICBpZiAoIWFkZHJlc3NlcyB8fCBhZGRyZXNzZXMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgY29uc3QgY3VycmVudExpc3QgPSBzdGF0ZT8ud2hpdGVsaXN0IHx8IFtdO1xyXG4gICAgbGV0IG5ld0xpc3Q6IHN0cmluZ1tdID0gW107XHJcblxyXG4gICAgaWYgKHJlbW92ZSkge1xyXG4gICAgICBuZXdMaXN0ID0gY3VycmVudExpc3QuZmlsdGVyKChhKSA9PiAhYWRkcmVzc2VzLmluY2x1ZGVzKGEpKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG5ld0xpc3QgPSBBcnJheS5mcm9tKG5ldyBTZXQoWy4uLmN1cnJlbnRMaXN0LCAuLi5hZGRyZXNzZXNdKSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUHJldmVudCB1bm5lY2Vzc2FyeSBuZXR3b3JrIGNhbGxzIGlmIHRoZSBsaXN0IGRpZG4ndCBhY3R1YWxseSBjaGFuZ2VcclxuICAgIGlmIChjdXJyZW50TGlzdC5sZW5ndGggPT09IG5ld0xpc3QubGVuZ3RoKSByZXR1cm47XHJcblxyXG4gICAgbGV0IGRldGFpbCA9ICcnO1xyXG4gICAgaWYgKGFkZHJlc3Nlcy5sZW5ndGggPT09IDEpIHtcclxuICAgICAgY29uc3QgYWRkcmVzcyA9IGFkZHJlc3Nlc1swXTtcclxuICAgICAgY29uc3Qgc2hvcnRBZGRyID0gYWRkcmVzcy5sZW5ndGggPiA1ID8gYWRkcmVzcy5zbGljZSgtNSkgOiBhZGRyZXNzO1xyXG4gICAgICBjb25zdCBhY3Rpb25Xb3JkID0gcmVtb3ZlID8gJ1JlbW92ZWQnIDogJ0FkZGVkJztcclxuICAgICAgZGV0YWlsID0gYCR7YWN0aW9uV29yZH0gLi4uJHtzaG9ydEFkZHJ9IHRvIHdoaXRlbGlzdGA7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBhY3Rpb25Xb3JkID0gcmVtb3ZlID8gJ1JlbW92ZWQnIDogJ1ZlcmlmaWVkJztcclxuICAgICAgZGV0YWlsID0gYCR7YWN0aW9uV29yZH0gJHthZGRyZXNzZXMubGVuZ3RofSBiYXRjaCBhZGRyZXNzKGVzKWA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY29uZmlybWF0aW9uID0gdGhpcy53YWl0Rm9yRXZlbnQoJ1dISVRFTElTVF9ERUNSWVBURUQnKTtcclxuICAgIGF3YWl0IHRoaXMucmVsYXkudXBkYXRlV2hpdGVsaXN0KG5ld0xpc3QsIGRldGFpbCwgdGhpcy51c2VyQ29udGV4dCk7XHJcbiAgICBhd2FpdCBjb25maXJtYXRpb247XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBGaW5hbGl6ZXMgdGhlIFBTQlQsIHVwZGF0ZXMgbG9jYWwgc3RhdGUsIGFuZCBhdXRvbWF0aWNhbGx5IGJyb2FkY2FzdHNcclxuICAgKiB0aGUgZmluYWxpemVkIHRyYW5zYWN0aW9uIHRvIHRoZSByb29tIHNvIGFsbCBwYXJ0aWNpcGFudHMgc3luYy5cclxuICAgKiBHdWFyYW50ZWVzIHRoZSBmb3JlbnNpYyBhdWRpdCBsb2cgaXMgc2VhbGVkIGJlZm9yZSByZXNvbHZpbmcuXHJcbiAgICogQHJldHVybnMgQSBQcm9taXNlIHJlc29sdmluZyB0byB0aGUgZmluYWxpemVkIGhleCBhbmQgdHJhbnNhY3Rpb24gSUQsIG9yIG51bGwgaWYgdGhlIFBTQlQgaXMgaW52YWxpZC5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgZmluYWxpemVUcmFuc2FjdGlvbigpOiBQcm9taXNlPHsgaGV4OiBzdHJpbmc7IHR4SWQ6IHN0cmluZyB9IHwgbnVsbD4ge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKCFzdGF0ZSkgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgY29uc3QgcmVzdWx0ID0gUHNidFV0aWxzLmZpbmFsaXplVHgoc3RhdGUucHNidCk7XHJcblxyXG4gICAgaWYgKHJlc3VsdCkge1xyXG4gICAgICB0aGlzLnN0b3JlLnVwZGF0ZSgocykgPT4gKHsgLi4ucyEsIGZpbmFsVHhIZXg6IHJlc3VsdC5oZXgsIGZpbmFsVHhJZDogcmVzdWx0LnR4SWQgfSkpO1xyXG5cclxuICAgICAgY29uc3QgY29uZmlybWF0aW9uID0gdGhpcy53YWl0Rm9yU3RhdGUoKHMpID0+XHJcbiAgICAgICAgcy5hdWRpdExvZy5zb21lKChsb2cpID0+IGxvZy5ldmVudCA9PT0gJ1R4IEZpbmFsaXplZCcpLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgYXdhaXQgdGhpcy5yZWxheS5icm9hZGNhc3RGaW5hbGl6YXRpb24ocmVzdWx0LmhleCwgcmVzdWx0LnR4SWQsIHRoaXMudXNlckNvbnRleHQpO1xyXG4gICAgICBhd2FpdCBjb25maXJtYXRpb247XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9XHJcblxyXG4gIC8qKiAqIFJldHVybnMgdGhlIGZpbmFsaXplZCB0cmFuc2FjdGlvbiBoZXggaWYgdGhlIHRocmVzaG9sZCBoYXMgYmVlbiByZWFjaGVkLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRGaW5hbFRyYW5zYWN0aW9uSGV4KCk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLnN0b3JlLmdldFN0YXRlKCk7XHJcbiAgICByZXR1cm4gc3RhdGU/LmZpbmFsVHhIZXggfHwgbnVsbDtcclxuICB9XHJcblxyXG4gIC8qKiAqIEdyYWNlZnVsbHkgY2xvc2VzIHRoZSBjb25uZWN0aW9uIHRvIHRoZSByZWxheSBzZXJ2ZXIuXHJcbiAgICovXHJcbiAgcHVibGljIGRpc2Nvbm5lY3QoKSB7XHJcbiAgICB0aGlzLnJlbGF5LmdyYWNlZnVsbHlEaXNjb25uZWN0KG51bGwpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyB0aGUgY3VycmVudCBwcm9ncmVzcyBvZiB0aGUgc2lnbmluZyBjZXJlbW9ueS5cclxuICAgKiBFeHRyYWN0cyB0aGUgdG90YWwgaGFyZHdhcmUgc2lnbmVycyBmcm9tIHRoZSBQU0JUIHNjcmlwdCBhbmQgY29tcGFyZXMgdG8gcmVjZWl2ZWQgc2lnbmF0dXJlcy5cclxuICAgKiBAcmV0dXJucyBTaWduYXR1cmUgcHJvZ3Jlc3MgbWV0cmljcy5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0U2lnbmF0dXJlUHJvZ3Jlc3MoKTogeyB0b3RhbFNpZ25lcnM6IG51bWJlcjsgc2lnbmF0dXJlc1JlY2VpdmVkOiBudW1iZXIgfSB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuZ2V0Um9vbVN0YXRlKCk7XHJcbiAgICBpZiAoIXN0YXRlIHx8ICFzdGF0ZS5wc2J0KSByZXR1cm4geyB0b3RhbFNpZ25lcnM6IDAsIHNpZ25hdHVyZXNSZWNlaXZlZDogMCB9O1xyXG5cclxuICAgIGNvbnN0IGFuYWx5c2lzID0gUHNidFV0aWxzLmFuYWx5emUoc3RhdGUucHNidCk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxTaWduZXJzOiBhbmFseXNpcz8uc2lnbmVyQ291bnQgfHwgMCxcclxuICAgICAgc2lnbmF0dXJlc1JlY2VpdmVkOiBzdGF0ZS5zaWduYXR1cmVzLmxlbmd0aCxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBEeW5hbWljYWxseSBldmFsdWF0ZXMgaWYgdGhlIGFnZ3JlZ2F0ZWQgUFNCVCBoYXMgbWV0IHRoZSByZXF1aXJlZCBzY3JpcHQgdGhyZXNob2xkLlxyXG4gICAqIEByZXR1cm5zIFRydWUgaWYgdGhlIHRyYW5zYWN0aW9uIGNhbiBiZSBmaW5hbGl6ZWQuXHJcbiAgICovXHJcbiAgcHVibGljIGlzVGhyZXNob2xkTWV0KCk6IGJvb2xlYW4ge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKCFzdGF0ZSB8fCAhc3RhdGUucHNidCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgcmV0dXJuIFBzYnRVdGlscy5maW5hbGl6ZVR4KHN0YXRlLnBzYnQpICE9PSBudWxsO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2FsY3VsYXRlcyBob3cgbWFueSBzaWduYXR1cmVzIGFyZSBzdGlsbCByZXF1aXJlZCB0byBmaW5hbGl6ZSB0aGUgdHJhbnNhY3Rpb24uXHJcbiAgICogQHBhcmFtIHRocmVzaG9sZCBUaGUgbWF0aGVtYXRpY2FsIHRocmVzaG9sZCBvZiB0aGUgc2NyaXB0IChlLmcuLCAzIGZvciBhIDMtb2YtNSkuXHJcbiAgICogQHJldHVybnMgVGhlIG51bWJlciBvZiByZW1haW5pbmcgc2lnbmF0dXJlcyBuZWVkZWQgKG1pbmltdW0gMCkuXHJcbiAgICovXHJcbiAgcHVibGljIGdldFNpZ25hdHVyZXNSZW1haW5pbmcodGhyZXNob2xkOiBudW1iZXIpOiBudW1iZXIge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKCFzdGF0ZSkgcmV0dXJuIHRocmVzaG9sZDtcclxuXHJcbiAgICBjb25zdCByZW1haW5pbmcgPSB0aHJlc2hvbGQgLSBzdGF0ZS5zaWduYXR1cmVzLmxlbmd0aDtcclxuICAgIHJldHVybiBNYXRoLm1heCgwLCByZW1haW5pbmcpO1xyXG4gIH1cclxuXHJcbiAgLyoqICogUmV0dXJucyBmdWxsIHBhcnNlZCB0cmFuc2FjdGlvbiBkZXRhaWxzIChJbnB1dHMsIE91dHB1dHMsIEZlZXMpLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRUcmFuc2FjdGlvbkRldGFpbHMoKSB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuZ2V0Um9vbVN0YXRlKCk7XHJcbiAgICBpZiAoIXN0YXRlIHx8ICFzdGF0ZS5wc2J0KSByZXR1cm4gbnVsbDtcclxuICAgIHJldHVybiBQc2J0VXRpbHMucGFyc2VUeERldGFpbHMoc3RhdGUucHNidCwgc3RhdGUubmV0d29yayk7XHJcbiAgfVxyXG5cclxuICAvKiogUmV0dXJucyB0aGUgbGlzdCBvZiBvdXRwdXRzIGZvciB0aGUgY3VycmVudCBQU0JULiAqL1xyXG4gIHB1YmxpYyBnZXRPdXRwdXRzKCkge1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0VHJhbnNhY3Rpb25EZXRhaWxzKCk/Lm91dHB1dHMgfHwgW107XHJcbiAgfVxyXG5cclxuICAvKiogUmV0dXJucyB0aGUgbGlzdCBvZiBpbnB1dHMgZm9yIHRoZSBjdXJyZW50IFBTQlQuICovXHJcbiAgcHVibGljIGdldElucHV0cygpIHtcclxuICAgIHJldHVybiB0aGlzLmdldFRyYW5zYWN0aW9uRGV0YWlscygpPy5pbnB1dHNMaXN0IHx8IFtdO1xyXG4gIH1cclxuXHJcbiAgLyoqIFJldHVybnMgdGhlIGNhbGN1bGF0ZWQgbmV0d29yayBmZWUgZm9yIHRoZSBjdXJyZW50IHRyYW5zYWN0aW9uIGluIHNhdG9zaGlzLiAqL1xyXG4gIHB1YmxpYyBnZXROZXR3b3JrRmVlKCk6IG51bWJlciB7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRUcmFuc2FjdGlvbkRldGFpbHMoKT8uZmVlIHx8IDA7XHJcbiAgfVxyXG5cclxuICAvKiogKiBSZXR1cm5zIGEgbGlzdCBvZiBhbGwgcmVxdWlyZWQgaGFyZHdhcmUgZmluZ2VycHJpbnRzIGZvciB0aGlzIHRyYW5zYWN0aW9uLFxyXG4gICAqIGFuZCBhIGJvb2xlYW4gaW5kaWNhdGluZyBpZiB0aGVpciBzaWduYXR1cmUgaGFzIGJlZW4gcHJvdmlkZWQgeWV0LlxyXG4gICAqL1xyXG4gIHB1YmxpYyBnZXRTaWduZXJzU3RhdHVzKHN0YXRlOiBSb29tU3RhdGUgfCBudWxsKTogYW55W10ge1xyXG4gICAgaWYgKCFzdGF0ZSB8fCAhc3RhdGUucHNidCkgcmV0dXJuIFtdO1xyXG4gICAgcmV0dXJuIFBzYnRVdGlscy5leHRyYWN0U2lnbmVycyhzdGF0ZS5wc2J0KTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBnZXRUeERldGFpbHMoc3RhdGU6IFJvb21TdGF0ZSB8IG51bGwpOiBUeERldGFpbHMgfCBudWxsIHtcclxuICAgIHJldHVybiBzdGF0ZT8ucHNidCA/IFBzYnRVdGlscy5wYXJzZVR4RGV0YWlscyhzdGF0ZS5wc2J0LCBzdGF0ZS5uZXR3b3JrKSA6IG51bGw7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZ2V0VGhyZXNob2xkKHN0YXRlOiBSb29tU3RhdGUgfCBudWxsKTogbnVtYmVyIHtcclxuICAgIGlmICghc3RhdGU/LnBzYnQpIHJldHVybiAwO1xyXG4gICAgY29uc3QgdGhyZXNob2xkID0gUHNidFV0aWxzLmdldFRocmVzaG9sZChzdGF0ZS5wc2J0KTtcclxuICAgIHJldHVybiB0aHJlc2hvbGQgPiAwID8gdGhyZXNob2xkIDogdGhpcy5nZXRTaWduZXJzU3RhdHVzKHN0YXRlKS5sZW5ndGg7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBFeHRyYWN0cyB0aGUgaGFyZHdhcmUgZmluZ2VycHJpbnQgZnJvbSBhIHNpZ25lZCBQU0JUIGJlZm9yZSB1cGxvYWRpbmcgaXQgdG8gdGhlIHJvb20uXHJcbiAgICogQHBhcmFtIHNpZ25lZFBzYnRCYXNlNjQgLSBUaGUgc2lnbmVkIFBTQlQgcGF5bG9hZC5cclxuICAgKi9cclxuICBwdWJsaWMgZXh0cmFjdEZpbmdlcnByaW50RnJvbVNpZ25hdHVyZShzaWduZWRQc2J0QmFzZTY0OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICAgIHJldHVybiBQc2J0VXRpbHMuZ2V0RmluZ2VycHJpbnRGcm9tUHNidChzaWduZWRQc2J0QmFzZTY0KTtcclxuICB9XHJcblxyXG4gIC8qKiAqIEludGVybmFsIGhlbHBlciB0byB3YWl0IGZvciBhIHNwZWNpZmljIHNlcnZlciByZXNwb25zZSBldmVudCBiZWZvcmUgcmVzb2x2aW5nLlxyXG4gICAqIEBwYXJhbSBldmVudFR5cGUgLSBUaGUgZXZlbnQga2V5IHRvIGxpc3RlbiBmb3IuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSB3YWl0Rm9yRXZlbnQoZXZlbnRUeXBlOiBhbnkpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xyXG4gICAgICBjb25zdCBzdWIgPSB0aGlzLnJlbGF5LmV2ZW50cy5vbihldmVudFR5cGUpLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgICAgc3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUGF1c2VzIGV4ZWN1dGlvbiB1bnRpbCB0aGUgUm9vbVN0YXRlIHNhdGlzZmllcyBhIHByb3ZpZGVkIGNvbmRpdGlvbi5cclxuICAgKiBFeGNlbGxlbnQgZm9yIFVJIHRyYW5zaXRpb25zIGFuZCBpbnRlZ3JhdGlvbiB0ZXN0aW5nLlxyXG4gICAqIEBwYXJhbSBjb25kaXRpb24gQSBmdW5jdGlvbiB0aGF0IGV2YWx1YXRlcyB0aGUgY3VycmVudCBSb29tU3RhdGUuXHJcbiAgICogQHBhcmFtIHRpbWVvdXRNcyBNYXggdGltZSB0byB3YWl0IGJlZm9yZSByZWplY3RpbmcgKGRlZmF1bHQgMTBzKS5cclxuICAgKi9cclxuICBwdWJsaWMgd2FpdEZvclN0YXRlKGNvbmRpdGlvbjogKHN0YXRlOiBSb29tU3RhdGUpID0+IGJvb2xlYW4sIHRpbWVvdXRNcyA9IDEwMDAwKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICBjb25zdCBjdXJyZW50U3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgICBpZiAoY3VycmVudFN0YXRlICYmIGNvbmRpdGlvbihjdXJyZW50U3RhdGUpKSByZXR1cm4gcmVzb2x2ZSgpO1xyXG5cclxuICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBzdWIudW5zdWJzY3JpYmUoKTtcclxuICAgICAgICByZWplY3QobmV3IEVycm9yKCd3YWl0Rm9yU3RhdGUgY29uZGl0aW9uIHRpbWVkIG91dCcpKTtcclxuICAgICAgfSwgdGltZW91dE1zKTtcclxuXHJcbiAgICAgIGNvbnN0IHN1YiA9IHRoaXMub25TdGF0ZUNoYW5nZSgpLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgICAgIGlmIChzdGF0ZSAmJiBjb25kaXRpb24oc3RhdGUpKSB7XHJcbiAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xyXG4gICAgICAgICAgc3ViLnVuc3Vic2NyaWJlKCk7XHJcbiAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqICogR2VuZXJhdGVzIGEgc2hhcmluZyBsaW5rIGZvciB0aGUgcm9vbS5cclxuICAgKiBAcGFyYW0gYXBwQmFzZVVybCBUaGUgYmFzZSBVUkwgb2YgeW91ciB3ZWIgVUkuXHJcbiAgICogQHBhcmFtIGluY2x1ZGVLZXkgV2hldGhlciB0byBpbmNsdWRlIHRoZSBkZWNyeXB0aW9uIGtleSBpbiB0aGUgVVJMIGhhc2guXHJcbiAgICovXHJcbiAgcHVibGljIGdldFJvb21MaW5rKGFwcEJhc2VVcmw6IHN0cmluZywgaW5jbHVkZUtleTogYm9vbGVhbiA9IGZhbHNlKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5nZXRSb29tU3RhdGUoKTtcclxuICAgIGlmICghc3RhdGUgfHwgIXN0YXRlLnJvb21JZCkgcmV0dXJuICcnO1xyXG5cclxuICAgIGxldCBsaW5rID0gYCR7YXBwQmFzZVVybC5yZXBsYWNlKC9cXC8kLywgJycpfS9yb29tLyR7c3RhdGUucm9vbUlkfWA7XHJcbiAgICBpZiAoaW5jbHVkZUtleSAmJiB0aGlzLl9lbmNyeXB0aW9uS2V5KSB7XHJcbiAgICAgIGxpbmsgKz0gYCMke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLl9lbmNyeXB0aW9uS2V5KX1gO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGxpbms7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBWYWxpZGF0ZXMgdGhlIGZvcmVuc2ljIGludGVncml0eSBvZiB0aGUgcm9vbS5cclxuICAgKiBAcGFyYW0gZXhwZWN0ZWRBbmNob3IgVGhlIGZvcmVuc2ljIGFuY2hvciBicm9hZGNhc3RlZCBhdCBmaW5hbGl6YXRpb24uXHJcbiAgICovXHJcbiAgcHVibGljIGFzeW5jIHZlcmlmeUludGVncml0eShcclxuICAgIGV4cGVjdGVkQW5jaG9yOiBzdHJpbmcsXHJcbiAgKTogUHJvbWlzZTx7IGFuY2hvcjogc3RyaW5nOyBpc1ZhbGlkOiBib29sZWFuIH0+IHtcclxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5nZXRSb29tU3RhdGUoKTtcclxuICAgIGlmICghc3RhdGUpIHRocm93IG5ldyBFcnJvcignTm8gcm9vbSBzdGF0ZSBhdmFpbGFibGUgdG8gdmVyaWZ5LicpO1xyXG4gICAgcmV0dXJuIGF3YWl0IFJvb21BdWRpdG9yLnZlcmlmeVJvb21JbnRlZ3JpdHkoc3RhdGUsIGV4cGVjdGVkQW5jaG9yKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEhlbHBlciB0byBkZXJpdmUgdGhlIHJvb20ncyBmb3JlbnNpYyBhbmNob3IgZnJvbSB0aGUgY3VycmVudCBzdGF0ZS5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgZ2V0Rm9yZW5zaWNBbmNob3IoKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5nZXRSb29tU3RhdGUoKTtcclxuICAgIGlmICghc3RhdGUgfHwgIXN0YXRlLmZpbmFsVHhIZXggfHwgIXN0YXRlLmF1ZGl0TG9nKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGdlbmVyYXRlIGFuY2hvcjogUm9vbSBub3QgZmluYWxpemVkLicpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGF3YWl0IFJvb21BdWRpdG9yLmNhbGN1bGF0ZUZvcmVuc2ljQW5jaG9yKHN0YXRlLmF1ZGl0TG9nLCBzdGF0ZS5maW5hbFR4SGV4KTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHJpZXZlcyBhIGZ1bGwgY3J5cHRvZ3JhcGhpYyBpbnRlZ3JpdHkgcmVwb3J0IGZvciB0aGUgY3VycmVudCByb29tIHN0YXRlLlxyXG4gICAqL1xyXG4gIHB1YmxpYyBhc3luYyBnZXRJbnRlZ3JpdHlSZXBvcnQoKSB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuZ2V0Um9vbVN0YXRlKCk7XHJcbiAgICBpZiAoIXN0YXRlKSB0aHJvdyBuZXcgRXJyb3IoJ05vIHN0YXRlJyk7XHJcbiAgICByZXR1cm4gYXdhaXQgUm9vbUF1ZGl0b3IuZ2V0SW50ZWdyaXR5UmVwb3J0KHN0YXRlKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFByb21vdGVzIHRoZSBjdXJyZW50IHNlc3Npb24gdG8gQ29vcmRpbmF0b3Igcm9sZSB1c2luZyB0aGUgYWRtaW4gc2VjcmV0LlxyXG4gICAqIFRoaXMgaXMgdXNlZCBmb3Igc2Vzc2lvbiByZWNvdmVyeSBhZnRlciByZS1qb2luaW5nIGEgcm9vbS5cclxuICAgKi9cclxuICBwdWJsaWMgYXN5bmMgY2xhaW1Db29yZGluYXRvcihhZG1pblNlY3JldDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBpZiAodGhpcy5zdG9yZS5nZXRTdGF0ZSgpID09PSBudWxsKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcignTXVzdCBqb2luIHJvb20gYmVmb3JlIGNsYWltaW5nIGNvb3JkaW5hdG9yIHJvbGUuJyk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnJlbGF5LnNlbmQoJ0FVVEgnLCB7IHRva2VuOiBhZG1pblNlY3JldCB9KTtcclxuXHJcbiAgICBhd2FpdCB0aGlzLndhaXRGb3JTdGF0ZSgoc3RhdGUpID0+IHtcclxuICAgICAgaWYgKCF0aGlzLl9zZXNzaW9uSWQgfHwgIXN0YXRlLnBhcnRpY2lwYW50cykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICByZXR1cm4gc3RhdGUucGFydGljaXBhbnRzW3RoaXMuX3Nlc3Npb25JZF0/LnJvbGUgPT09ICdhZG1pbic7XHJcbiAgICB9LCAxNTAwMCk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgYXN5bmMgcGFyc2VQc2J0RmlsZShmaWxlOiBGaWxlKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IGZpbGUuYXJyYXlCdWZmZXIoKTtcclxuICAgIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYnVmZmVyKTtcclxuXHJcbiAgICAvLyBMb2dpYyBjdXJyZW50bHkgaW4geW91ciBSb29tQ29tcG9uZW50XHJcbiAgICBjb25zdCBpc0JpbmFyeSA9XHJcbiAgICAgIGJ5dGVzWzBdID09PSAweDcwICYmXHJcbiAgICAgIGJ5dGVzWzFdID09PSAweDczICYmXHJcbiAgICAgIGJ5dGVzWzJdID09PSAweDYyICYmXHJcbiAgICAgIGJ5dGVzWzNdID09PSAweDc0ICYmXHJcbiAgICAgIGJ5dGVzWzRdID09PSAweGZmO1xyXG5cclxuICAgIGNvbnN0IGNvbnRlbnQgPSBpc0JpbmFyeVxyXG4gICAgICA/IEFycmF5LmZyb20oYnl0ZXMpXHJcbiAgICAgICAgICAubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxyXG4gICAgICAgICAgLmpvaW4oJycpXHJcbiAgICAgIDogbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGJ5dGVzKS50cmltKCk7XHJcblxyXG4gICAgaWYgKGNvbnRlbnQuc3RhcnRzV2l0aCgnMDEwMDAwJykgfHwgY29udGVudC5zdGFydHNXaXRoKCcwMjAwMDAnKSkge1xyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoaXMgbG9va3MgbGlrZSBhIFJhdyBUcmFuc2FjdGlvbi4gUGxlYXNlIGV4cG9ydCBhcyBQU0JUIGZyb20geW91ciB3YWxsZXQuJyk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGNvbnRlbnQ7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZ2V0RXJyb3JDYXRlZ29yeShcclxuICAgIGNvZGU6IG51bWJlcixcclxuICApOiAnUk9PTV9GVUxMJyB8ICdBVVRIX0ZBSUxFRCcgfCAnUFJPVE9DT0xfTUlTTUFUQ0gnIHwgJ1VOS05PV04nIHtcclxuICAgIGlmIChjb2RlID09PSA0MDI2KSByZXR1cm4gJ1BST1RPQ09MX01JU01BVENIJztcclxuICAgIGlmIChjb2RlID09PSA0MDAxKSByZXR1cm4gJ1JPT01fRlVMTCc7XHJcbiAgICBpZiAoY29kZSA9PT0gMTAwNikgcmV0dXJuICdBVVRIX0ZBSUxFRCc7XHJcbiAgICByZXR1cm4gJ1VOS05PV04nO1xyXG4gIH1cclxufVxyXG4iLCIvKlxyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMjYgU3RhdGVsZXNzIFJlc2VhcmNoIEx0ZFxyXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgR05VIEFmZmVybyBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIHYzLjBcclxuICovXHJcblxyXG5pbXBvcnQgeyBJbmplY3RhYmxlLCBzaWduYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgVVIsIFVSRGVjb2RlciwgVVJFbmNvZGVyIH0gZnJvbSAnQG5ncmF2ZWlvL2JjLXVyJztcclxuaW1wb3J0ICogYXMgZmZsYXRlIGZyb20gJ2ZmbGF0ZSc7XHJcbmltcG9ydCB7IGhleCwgYmFzZTY0IH0gZnJvbSAnQHNjdXJlL2Jhc2UnO1xyXG5cclxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcclxuZXhwb3J0IGNsYXNzIFVyU2VydmljZSB7XHJcbiAgcHJpdmF0ZSBkZWNvZGVyID0gbmV3IFVSRGVjb2RlcigpO1xyXG5cclxuICBwdWJsaWMgc2NhblByb2dyZXNzID0gc2lnbmFsPG51bWJlcj4oMCk7XHJcblxyXG4gIHByaXZhdGUgYmJxclN0YXRlID0gbmV3IE1hcDxudW1iZXIsIHN0cmluZz4oKTtcclxuICBwcml2YXRlIGJicXJUb3RhbCA9IDA7XHJcblxyXG4gIHB1YmxpYyBsYXN0U2Nhbm5lZFRleHQgPSBzaWduYWw8c3RyaW5nPignV2FpdGluZyBmb3IgY2FtZXJhIHRvIGxvY2sgb24uLi4nKTtcclxuICBwdWJsaWMgc2NhbkVycm9yID0gc2lnbmFsPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvKipcclxuICAgKiBFWEhBTEU6IENvbnZlcnRzIGEgSGV4IFBTQlQgaW50byBhbiBhcnJheSBvZiBhbmltYXRlZCBRUiBmcmFnbWVudHNcclxuICAgKi9cclxuICBnZW5lcmF0ZUZyYW1lcyhwc2J0QmFzZTY0OiBzdHJpbmcsIG1heEZyYWdtZW50TGVuZ3RoID0gMTUwKTogc3RyaW5nW10ge1xyXG4gICAgY29uc3QgY2xlYW5CYXNlNjQgPSBwc2J0QmFzZTY0LnJlcGxhY2UoL1xccysvZywgJycpO1xyXG4gICAgY29uc3QgcHNidEJ5dGVzID0gYmFzZTY0LmRlY29kZShjbGVhbkJhc2U2NCk7IC8vIFVzaW5nIEBzY3VyZS9iYXNlXHJcblxyXG4gICAgLy8gZ2VuZXJhdGUgdGhlIENCT1IgQnl0ZSBTdHJpbmdcclxuICAgIGNvbnN0IGdlbmVyaWNVciA9IFVSLmZyb21CdWZmZXIoQnVmZmVyLmZyb20ocHNidEJ5dGVzKSk7XHJcblxyXG4gICAgY29uc3QgY2JvclBheWxvYWQgPVxyXG4gICAgICBnZW5lcmljVXIuY2JvciB8fCAoZ2VuZXJpY1VyIGFzIGFueSkuX2Nib3IgfHwgKGdlbmVyaWNVciBhcyBhbnkpLmNib3JNZXNzYWdlO1xyXG5cclxuICAgIGlmICghY2JvclBheWxvYWQpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignQ3JpdGljYWw6IENvdWxkIG5vdCBleHRyYWN0IENCT1IgcGF5bG9hZCBmcm9tIFVSJywgZ2VuZXJpY1VyKTtcclxuICAgICAgcmV0dXJuIFtdO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHVyID0gbmV3IFVSKGNib3JQYXlsb2FkLCAnY3J5cHRvLXBzYnQnKTtcclxuICAgIGNvbnN0IGVuY29kZXIgPSBuZXcgVVJFbmNvZGVyKHVyLCBtYXhGcmFnbWVudExlbmd0aCk7XHJcbiAgICBjb25zdCBmcmFtZXM6IHN0cmluZ1tdID0gW107XHJcblxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlbmNvZGVyLmZyYWdtZW50c0xlbmd0aCAqIDI7IGkrKykge1xyXG4gICAgICBmcmFtZXMucHVzaChlbmNvZGVyLm5leHRQYXJ0KCkudG9VcHBlckNhc2UoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGZyYW1lcztcclxuICB9XHJcblxyXG4gIGdlbmVyYXRlQkJRckZyYW1lcyhwc2J0QmFzZTY0OiBzdHJpbmcsIGNoYXJzUGVyRnJhbWUgPSAxMDAwKTogc3RyaW5nW10ge1xyXG4gICAgY29uc3QgcHNidEJ5dGVzID0gYmFzZTY0LmRlY29kZShwc2J0QmFzZTY0LnJlcGxhY2UoL1xccysvZywgJycpKTtcclxuICAgIGNvbnN0IHBzYnRIZXggPSBoZXguZW5jb2RlKHBzYnRCeXRlcykudG9VcHBlckNhc2UoKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbENodW5rcyA9IE1hdGguY2VpbChwc2J0SGV4Lmxlbmd0aCAvIGNoYXJzUGVyRnJhbWUpO1xyXG5cclxuICAgIGlmICh0b3RhbENodW5rcyA+IDEyOTUpIHRocm93IG5ldyBFcnJvcignUFNCVCB0b28gbGFyZ2UgZm9yIEJCUXInKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbEJhc2UzNiA9IHRvdGFsQ2h1bmtzLnRvU3RyaW5nKDM2KS50b1VwcGVyQ2FzZSgpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBmcmFtZXM6IHN0cmluZ1tdID0gW107XHJcblxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0b3RhbENodW5rczsgaSsrKSB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRCYXNlMzYgPSBpLnRvU3RyaW5nKDM2KS50b1VwcGVyQ2FzZSgpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICAgIGNvbnN0IGhlYWRlciA9IGBCJEhQJHt0b3RhbEJhc2UzNn0ke2N1cnJlbnRCYXNlMzZ9YDtcclxuICAgICAgY29uc3QgY2h1bmsgPSBwc2J0SGV4LnN1YnN0cmluZyhpICogY2hhcnNQZXJGcmFtZSwgKGkgKyAxKSAqIGNoYXJzUGVyRnJhbWUpO1xyXG4gICAgICBmcmFtZXMucHVzaChoZWFkZXIgKyBjaHVuayk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGZyYW1lcztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIElOSEFMRSAoT01OSS1ERUNPREVSKTogQXV0b21hdGljYWxseSBkZXRlY3RzIGFuZCBkZWNvZGVzIFVSLCBCQlFyLCBvciBTdGF0aWMgUVJzLlxyXG4gICAqL1xyXG4gIHByb2Nlc3NGcmFnbWVudChmcmFnbWVudDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICBpZiAoIWZyYWdtZW50IHx8IHR5cGVvZiBmcmFnbWVudCAhPT0gJ3N0cmluZycpIHtcclxuICAgICAgdGhpcy5zY2FuRXJyb3Iuc2V0KCdJbnZhbGlkIFFSIGRhdGEgcmVjZWl2ZWQuJyk7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVwcGVyID0gZnJhZ21lbnQudG9VcHBlckNhc2UoKTtcclxuICAgICAgdGhpcy5sYXN0U2Nhbm5lZFRleHQuc2V0KHVwcGVyLmxlbmd0aCA+IDQwID8gdXBwZXIuc3Vic3RyaW5nKDAsIDQwKSArICcuLi4nIDogdXBwZXIpO1xyXG4gICAgICB0aGlzLnNjYW5FcnJvci5zZXQobnVsbCk7XHJcblxyXG4gICAgICAvLyAtLS0gUFJPVE9DT0wgMTogQkMtVVIgLS0tXHJcbiAgICAgIGlmICh1cHBlci5zdGFydHNXaXRoKCdVUjonKSkge1xyXG4gICAgICAgIHRoaXMuZGVjb2Rlci5yZWNlaXZlUGFydCh1cHBlcik7XHJcblxyXG4gICAgICAgIGNvbnN0IHByb2dyZXNzID0gdGhpcy5kZWNvZGVyLmVzdGltYXRlZFBlcmNlbnRDb21wbGV0ZSgpO1xyXG4gICAgICAgIHRoaXMuc2NhblByb2dyZXNzLnNldChNYXRoLm1heChwcm9ncmVzcywgdGhpcy5zY2FuUHJvZ3Jlc3MoKSkpO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5kZWNvZGVyLmlzQ29tcGxldGUoKSkge1xyXG4gICAgICAgICAgaWYgKHRoaXMuZGVjb2Rlci5pc1N1Y2Nlc3MoKSkge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHJlc3VsdFVSID0gdGhpcy5kZWNvZGVyLnJlc3VsdFVSKCk7XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IGNib3JQYXlsb2FkID1cclxuICAgICAgICAgICAgICAgIHJlc3VsdFVSLmNib3IgfHwgKHJlc3VsdFVSIGFzIGFueSkuX2Nib3IgfHwgKHJlc3VsdFVSIGFzIGFueSkuY2Jvck1lc3NhZ2U7XHJcblxyXG4gICAgICAgICAgICAgIGlmIChjYm9yUGF5bG9hZCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IGhleERhdGEgPSBoZXguZW5jb2RlKG5ldyBVaW50OEFycmF5KGNib3JQYXlsb2FkKSkudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBtYWdpY0luZGV4ID0gaGV4RGF0YS5pbmRleE9mKCc3MDczNjI3NGZmJyk7XHJcbiAgICAgICAgICAgICAgICBpZiAobWFnaWNJbmRleCAhPT0gLTEpIHtcclxuICAgICAgICAgICAgICAgICAgaGV4RGF0YSA9IGhleERhdGEuc3Vic3RyaW5nKG1hZ2ljSW5kZXgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMucmVzZXREZWNvZGVyKCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaGV4RGF0YTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gZGVjb2RlIENCT1InLCBlKTtcclxuICAgICAgICAgICAgICB0aGlzLnNjYW5FcnJvci5zZXQoJ1VSIGRlY29kZWQgYnV0IHBheWxvYWQgZXh0cmFjdGlvbiBmYWlsZWQnKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5zY2FuRXJyb3Iuc2V0KCdVUiBjaGVja3N1bSBmYWlsZWQuIFBsZWFzZSByZXNjYW4uJyk7XHJcbiAgICAgICAgICAgIHRoaXMucmVzZXREZWNvZGVyKCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyAtLS0gUFJPVE9DT0wgMjogQkJRciAoQ29sZGNhcmQgLyBDb21wcmVzc2VkIFJlbGF5KSAtLS1cclxuICAgICAgaWYgKHVwcGVyLnN0YXJ0c1dpdGgoJ0IkJykpIHtcclxuICAgICAgICBjb25zdCBlbmNvZGluZyA9IHVwcGVyWzJdOyAvLyAnSCcgKEhleCkgb3IgJ1onIChabGliKVxyXG4gICAgICAgIGNvbnN0IHRvdGFsU3RyID0gdXBwZXIuc3Vic3RyaW5nKDQsIDYpO1xyXG4gICAgICAgIGNvbnN0IGluZGV4U3RyID0gdXBwZXIuc3Vic3RyaW5nKDYsIDgpO1xyXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSB1cHBlci5zdWJzdHJpbmcoOCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHRvdGFsID0gcGFyc2VJbnQodG90YWxTdHIsIDM2KTtcclxuICAgICAgICBjb25zdCBpbmRleCA9IHBhcnNlSW50KGluZGV4U3RyLCAzNik7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmJicXJUb3RhbCA9PT0gMCkgdGhpcy5iYnFyVG90YWwgPSB0b3RhbDtcclxuXHJcbiAgICAgICAgaWYgKCF0aGlzLmJicXJTdGF0ZS5oYXMoaW5kZXgpKSB7XHJcbiAgICAgICAgICB0aGlzLmJicXJTdGF0ZS5zZXQoaW5kZXgsIHBheWxvYWQpO1xyXG4gICAgICAgICAgdGhpcy5zY2FuUHJvZ3Jlc3Muc2V0KHRoaXMuYmJxclN0YXRlLnNpemUgLyB0aGlzLmJicXJUb3RhbCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAodGhpcy5iYnFyU3RhdGUuc2l6ZSA9PT0gdGhpcy5iYnFyVG90YWwpIHtcclxuICAgICAgICAgIGxldCBmdWxsUGF5bG9hZCA9ICcnO1xyXG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmJicXJUb3RhbDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZ1bGxQYXlsb2FkICs9IHRoaXMuYmJxclN0YXRlLmdldChpKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZW5jb2RpbmcgPT09ICdaJykge1xyXG4gICAgICAgICAgICBjb25zdCBjb21wcmVzc2VkID0gdGhpcy5kZWNvZGVCYXNlMzIoZnVsbFBheWxvYWQpO1xyXG4gICAgICAgICAgICBjb25zdCBkZWNvbXByZXNzZWQgPSBmZmxhdGUuaW5mbGF0ZVN5bmMoY29tcHJlc3NlZCk7XHJcbiAgICAgICAgICAgIHRoaXMucmVzZXREZWNvZGVyKCk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gaGV4LmVuY29kZShkZWNvbXByZXNzZWQpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5yZXNldERlY29kZXIoKTtcclxuICAgICAgICAgICAgcmV0dXJuIGZ1bGxQYXlsb2FkO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfVxyXG5cclxuICAgICAgdGhpcy5yZXNldERlY29kZXIoKTtcclxuICAgICAgcmV0dXJuIGZyYWdtZW50O1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdPbW5pLURlY29kZXIgZXJyb3I6JywgZSk7XHJcbiAgICAgIHRoaXMuc2NhbkVycm9yLnNldCgnRGVjb2RpbmcgZmFpbHVyZS4gQ2hlY2sgd2FsbGV0IHNldHRpbmdzLicpO1xyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIC0tLSBIZWxwZXI6IEJhc2UzMiBEZWNvZGluZyAoUkZDIDQ2NDgpIGZvciBCQlFyIC0tLVxyXG4gIHByaXZhdGUgZGVjb2RlQmFzZTMyKHM6IHN0cmluZyk6IFVpbnQ4QXJyYXkge1xyXG4gICAgY29uc3QgYWxwaGFiZXQgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVoyMzQ1NjcnO1xyXG4gICAgY29uc3QgbG9va3VwID0gbmV3IE1hcChbLi4uYWxwaGFiZXRdLm1hcCgoY2hhciwgaSkgPT4gW2NoYXIsIGldKSk7XHJcbiAgICBjb25zdCBiaXRzID0gcy5zcGxpdCgnJykubWFwKChjKSA9PiBsb29rdXAuZ2V0KGMudG9VcHBlckNhc2UoKSkgPz8gMCk7XHJcbiAgICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KE1hdGguZmxvb3IoKGJpdHMubGVuZ3RoICogNSkgLyA4KSk7XHJcbiAgICBsZXQgYml0QnVmZmVyID0gMCxcclxuICAgICAgYml0Q291bnQgPSAwLFxyXG4gICAgICBieXRlSW5kZXggPSAwO1xyXG4gICAgZm9yIChjb25zdCBiIG9mIGJpdHMpIHtcclxuICAgICAgYml0QnVmZmVyID0gKGJpdEJ1ZmZlciA8PCA1KSB8IGI7XHJcbiAgICAgIGJpdENvdW50ICs9IDU7XHJcbiAgICAgIGlmIChiaXRDb3VudCA+PSA4KSB7XHJcbiAgICAgICAgYnl0ZXNbYnl0ZUluZGV4KytdID0gKGJpdEJ1ZmZlciA+PiAoYml0Q291bnQgLSA4KSkgJiAweGZmO1xyXG4gICAgICAgIGJpdENvdW50IC09IDg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBieXRlcztcclxuICB9XHJcblxyXG4gIHJlc2V0RGVjb2RlcigpIHtcclxuICAgIHRoaXMuZGVjb2RlciA9IG5ldyBVUkRlY29kZXIoKTtcclxuICAgIHRoaXMuYmJxclN0YXRlLmNsZWFyKCk7XHJcbiAgICB0aGlzLmJicXJUb3RhbCA9IDA7XHJcbiAgICB0aGlzLnNjYW5Qcm9ncmVzcy5zZXQoMCk7XHJcbiAgfVxyXG59XHJcbiIsIi8qXHJcbiAqIENvcHlyaWdodCAoQykgMjAyNiBTdGF0ZWxlc3MgUmVzZWFyY2ggTHRkXHJcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBHTlUgQWZmZXJvIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgdjMuMFxyXG4gKi9cclxuXHJcbmltcG9ydCB7IEluamVjdGFibGUsIEluamVjdCwgUExBVEZPUk1fSUQsIHNpZ25hbCwgY29tcHV0ZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgaXNQbGF0Zm9ybUJyb3dzZXIgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQge1xyXG4gIFNpZ25pbmdSb29tQ2xpZW50LFxyXG4gIFJvb21TdGF0ZSxcclxuICBQc2J0VXRpbHMsXHJcbiAgUmVsYXlDbGllbnQsXHJcbiAgUm9vbVN0YXRlU3RvcmUsXHJcbiAgRW5jcnlwdGlvbkVuZ2luZSxcclxuICBBdWRpdExvZ09wdGlvbnMsXHJcbn0gZnJvbSAnQHNpZ25pbmctcm9vbS9zZGsnO1xyXG5pbXBvcnQgeyBTREtDbGllbnRGYWN0b3J5U2VydmljZSB9IGZyb20gJy4uL3Nkay1jbGllbnQtZmFjdG9yeS9zZGstY2xpZW50LWZhY3Rvcnkuc2VydmljZSc7XHJcbmltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBQUk9UT0NPTF9WRVJTSU9OID0gJzEuMC4wJztcclxuXHJcbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXHJcbmV4cG9ydCBjbGFzcyBTb2NrZXRTZXJ2aWNlIHtcclxuICBwdWJsaWMgc2RrOiBTaWduaW5nUm9vbUNsaWVudDtcclxuICBwcml2YXRlIHN0b3JlOiBSb29tU3RhdGVTdG9yZTtcclxuICBwcml2YXRlIHJlbGF5OiBSZWxheUNsaWVudDtcclxuICBwcml2YXRlIGVuY3J5cHRpb25FbmdpbmU6IEVuY3J5cHRpb25FbmdpbmU7XHJcblxyXG4gIHByaXZhdGUgaGFzQW5ub3VuY2VkSm9pbiA9IGZhbHNlO1xyXG4gIHB1YmxpYyBzZWN1cml0eUFsZXJ0JCA9IG5ldyBTdWJqZWN0PHsgdHlwZTogJ2FjY2Vzc19kZW5pZWQnOyBjb3VudDogbnVtYmVyIH0+KCk7XHJcbiAgcHJpdmF0ZSBmYWxsYmFja1ZlcnNpb246IHN0cmluZyB8IG51bGwgPSBudWxsO1xyXG4gIHByaXZhdGUgZmFpbGVkS2V5QXR0ZW1wdHMgPSAwO1xyXG4gIHByaXZhdGUgZW5jcnlwdGlvbktleTogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIHB1YmxpYyBpc0Jyb3dzZXI6IGJvb2xlYW47XHJcblxyXG4gIGNvbnN0cnVjdG9yKFxyXG4gICAgQEluamVjdChQTEFURk9STV9JRCkgcHJpdmF0ZSBwbGF0Zm9ybUlkOiBPYmplY3QsXHJcbiAgICBwcml2YXRlIHNka0ZhY3Rvcnk6IFNES0NsaWVudEZhY3RvcnlTZXJ2aWNlLFxyXG4gICkge1xyXG4gICAgdGhpcy5pc0Jyb3dzZXIgPSBpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpO1xyXG5cclxuICAgIHRoaXMuc2RrID0gdGhpcy5zZGtGYWN0b3J5LmNyZWF0ZSgpO1xyXG4gICAgdGhpcy5yZWxheSA9IHRoaXMuc2RrLnJlbGF5O1xyXG4gICAgdGhpcy5zdG9yZSA9IHRoaXMuc2RrLnN0b3JlO1xyXG4gICAgdGhpcy5lbmNyeXB0aW9uRW5naW5lID0gdGhpcy5zZGsuZW5naW5lO1xyXG4gICAgdGhpcy5yZWdpc3RlckV2ZW50bGlzdGVuZXJzKCk7XHJcbiAgfVxyXG5cclxuICByZWdpc3RlckV2ZW50bGlzdGVuZXJzKCkge1xyXG4gICAgdGhpcy5zZGsub25TdGF0ZUNoYW5nZSgpLnN1YnNjcmliZSgoc3RhdGUpID0+IHtcclxuICAgICAgdGhpcy5yb29tU3RhdGUuc2V0KHRoaXMuc2RrLmdldFJvb21TdGF0ZSgpKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMucmVsYXkuZXZlbnRzLm9uKCdST09NX0NPTk5FQ1RFRCcpLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgIHRoaXMuc3RhdHVzLnNldCgnY29ubmVjdGVkJyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50c1xyXG4gICAgICAub24oJ1NFU1NJT05fQ09OTkVDVEVEJylcclxuICAgICAgLnN1YnNjcmliZSgoZSkgPT4gdGhpcy5jdXJyZW50U2Vzc2lvbklkLnNldChlLnBheWxvYWQpKTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50cy5vbignUk9PTV9ESVNDT05ORUNURUQnKS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XHJcbiAgICAgIHRoaXMuc3RhdHVzLnNldCgnZGlzY29ubmVjdGVkJyk7XHJcblxyXG4gICAgICBpZiAoIXRoaXMuaXNDbG9zZWQoKSkge1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgaGFzVGVybWluYWxFcnJvciA9XHJcbiAgICAgICAgICAgIHRoaXMucm9vbU5vdEZvdW5kKCkgfHxcclxuICAgICAgICAgICAgdGhpcy5pc0xvY2tlZE91dCgpIHx8XHJcbiAgICAgICAgICAgIHRoaXMuaXNSb29tRnVsbCgpIHx8XHJcbiAgICAgICAgICAgIHRoaXMuZGVjcnlwdGlvbkVycm9yKCkgIT09IG51bGw7XHJcblxyXG4gICAgICAgICAgaWYgKHRoaXMuc3RhdHVzKCkgPT09ICdkaXNjb25uZWN0ZWQnICYmICFoYXNUZXJtaW5hbEVycm9yKSB7XHJcbiAgICAgICAgICAgIHRoaXMuY29ubmVjdCh0aGlzLnJvb21TdGF0ZSgpPy5yb29tSWQgfHwgJycsIHRoaXMuZ2V0Um9vbUtleSgpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9LCAzMDAwKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ0xBQkVMU19ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCBzaWduZXJMYWJlbHM6IGUucGF5bG9hZCB9IDogbnVsbCkpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1JPT01fUkVOQU1FRF9ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCByb29tTmFtZTogZS5wYXlsb2FkIH0gOiBudWxsKSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50cy5vbignTE9HX1VQREFURV9ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCBhdWRpdExvZzogZS5wYXlsb2FkIH0gOiBudWxsKSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50cy5vbignQ09OTkVDVElPTlNfREVDUllQVEVEJykuc3Vic2NyaWJlKChlKSA9PiB7XHJcbiAgICAgIHRoaXMuc3RvcmUudXBkYXRlKChzKSA9PiAocyA/IHsgLi4ucywgY29ubmVjdGVkQ291bnQ6IGUucGF5bG9hZC5jb3VudCB9IDogbnVsbCkpO1xyXG4gICAgICB0aGlzLmFjdGl2ZVNlc3Npb25zLnNldChlLnBheWxvYWQuc2Vzc2lvbnMpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1dISVRFTElTVF9ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCB3aGl0ZWxpc3Q6IGUucGF5bG9hZCB9IDogbnVsbCkpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1BBUlRJQ0lQQU5UU19ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCBwYXJ0aWNpcGFudHM6IGUucGF5bG9hZCB9IDogbnVsbCkpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ0xPQ0tfVVBEQVRFRCcpLnN1YnNjcmliZSgoZSkgPT4ge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0gZS5wYXlsb2FkIHx8IHt9O1xyXG4gICAgICBjb25zdCBpc0xvY2tlZCA9IHBheWxvYWQuaXNMb2NrZWQgIT09IHVuZGVmaW5lZCA/IHBheWxvYWQuaXNMb2NrZWQgOiB0cnVlO1xyXG5cclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCBpc0xvY2tlZCB9IDogbnVsbCkpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1RPR0dMRV9MT0NLJykuc3Vic2NyaWJlKChlKSA9PiB7XHJcbiAgICAgIGNvbnN0IGlzTG9ja2VkID0gZS5wYXlsb2FkPy5pc0xvY2tlZCAhPT0gdW5kZWZpbmVkID8gZS5wYXlsb2FkLmlzTG9ja2VkIDogdHJ1ZTtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+IChzID8geyAuLi5zLCBpc0xvY2tlZCB9IDogbnVsbCkpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1RYX0ZJTkFMSVpFRF9ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5zdG9yZS51cGRhdGUoKHMpID0+XHJcbiAgICAgICAgcyA/IHsgLi4ucywgZmluYWxUeEhleDogZS5wYXlsb2FkLmZpbmFsVHhIZXgsIGZpbmFsVHhJZDogZS5wYXlsb2FkLmZpbmFsVHhJZCB9IDogbnVsbCxcclxuICAgICAgKTtcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMucmVsYXkuZXZlbnRzLm9uKCdST09NX0NMT1NFRCcpLnN1YnNjcmliZSgoKSA9PiB7XHJcbiAgICAgIHRoaXMuaXNDbG9zZWQuc2V0KHRydWUpO1xyXG4gICAgICBjb25zdCByb29tVG9DbGVhciA9IHRoaXMucm9vbVN0YXRlKCk/LnJvb21JZDtcclxuICAgICAgaWYgKHJvb21Ub0NsZWFyKSB0aGlzLmNsZWFyTG9jYWxSb29tRGF0YShyb29tVG9DbGVhcik7XHJcbiAgICAgIHRoaXMuZGlzY29ubmVjdCgpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1BST1RPQ09MX0VSUk9SJykuc3Vic2NyaWJlKChlKSA9PiB7XHJcbiAgICAgIGNvbnN0IGVycm9yVHlwZSA9IGUucGF5bG9hZC50eXBlO1xyXG5cclxuICAgICAgaWYgKGVycm9yVHlwZSA9PT0gJ2xvY2tlZCcpIHtcclxuICAgICAgICB0aGlzLmlzTG9ja2VkT3V0LnNldCh0cnVlKTtcclxuICAgICAgICB0aGlzLmRpc2Nvbm5lY3QoKTtcclxuICAgICAgfSBlbHNlIGlmIChlcnJvclR5cGUgPT09ICdub3RfZm91bmQnKSB7XHJcbiAgICAgICAgdGhpcy5yb29tTm90Rm91bmQuc2V0KHRydWUpO1xyXG4gICAgICAgIHRoaXMuZGlzY29ubmVjdCgpO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycm9yVHlwZSA9PT0gJ3ZlcnNpb25fbWlzbWF0Y2gnKSB7XHJcbiAgICAgICAgdGhpcy5mYWxsYmFja1ZlcnNpb24gPSBlLnBheWxvYWQucm9vbVZlcnNpb247XHJcbiAgICAgICAgLy8gVHJpZ2dlciBkb3duZ3JhZGUgY29ubmVjdGlvbiBsb2dpYyBoZXJlXHJcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3JUeXBlID09PSAncm9vbV9mdWxsJykge1xyXG4gICAgICAgIHRoaXMuaXNSb29tRnVsbC5zZXQodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3JUeXBlID09PSAnYWNjZXNzX2RlbmllZCcpIHtcclxuICAgICAgICBpZiAoIXRoaXMuaGFzQW5ub3VuY2VkSm9pbikge1xyXG4gICAgICAgICAgdGhpcy5kZWNyeXB0aW9uRXJyb3Iuc2V0KCdJbnZhbGlkIGRlY3J5cHRpb24ga2V5LiBBY2Nlc3MgZGVuaWVkLicpO1xyXG4gICAgICAgICAgdGhpcy5zZXRSb29tS2V5KG51bGwpO1xyXG4gICAgICAgICAgdGhpcy5mYWlsZWRLZXlBdHRlbXB0cysrO1xyXG4gICAgICAgICAgdGhpcy5zZWN1cml0eUFsZXJ0JC5uZXh0KHsgdHlwZTogJ2FjY2Vzc19kZW5pZWQnLCBjb3VudDogdGhpcy5mYWlsZWRLZXlBdHRlbXB0cyB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMucmVsYXkuZXZlbnRzLm9uKCdERUNSWVBUSU9OX0VSUk9SJykuc3Vic2NyaWJlKChlKSA9PiB7XHJcbiAgICAgIGlmICghdGhpcy5pc0xvY2tlZE91dCgpICYmICF0aGlzLmlzUm9vbUZ1bGwoKSAmJiAhdGhpcy5yb29tTm90Rm91bmQoKSkge1xyXG4gICAgICAgIHRoaXMuZGVjcnlwdGlvbkVycm9yLnNldChlLnBheWxvYWQpO1xyXG4gICAgICAgIHRoaXMuc2V0Um9vbUtleShudWxsKTtcclxuICAgICAgICB0aGlzLmRpc2Nvbm5lY3QoKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy5yZWxheS5ldmVudHMub24oJ1NUQVRFX0NIQU5HRUQnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgdGhpcy5yb29tU3RhdGUuc2V0KGUucGF5bG9hZCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50cy5vbignU1RBVEVfU1lOQ19ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IHN5bmNEYXRhID0gZXZlbnQucGF5bG9hZDtcclxuICAgICAgY29uc3QgaGFzQWRtaW5Ub2tlbiA9ICEhc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShgYWRtaW5fdG9rZW5fJHtzeW5jRGF0YS5yb29tSWR9YCk7XHJcblxyXG4gICAgICBpZiAoIXRoaXMuaGFzQW5ub3VuY2VkSm9pbiAmJiB0aGlzLmN1cnJlbnRTZXNzaW9uSWQoKSAmJiAhaGFzQWRtaW5Ub2tlbikge1xyXG4gICAgICAgIHRoaXMuaGFzQW5ub3VuY2VkSm9pbiA9IHRydWU7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMucmVsYXkuZXZlbnRzLm9uKCdORVdfUEFSVElBTF9ERUNSWVBURUQnKS5zdWJzY3JpYmUoKGV2ZW50KSA9PiB7XHJcbiAgICAgIGNvbnN0IHsgZGVjcnlwdGVkUHNidCwgZmluZ2VycHJpbnQsIHNlc3Npb25JZCB9ID0gZXZlbnQucGF5bG9hZDtcclxuXHJcbiAgICAgIHRoaXMuc3RvcmUudXBkYXRlKChjdXJyZW50KSA9PiB7XHJcbiAgICAgICAgaWYgKCFjdXJyZW50KSByZXR1cm4gbnVsbDtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgLi4uY3VycmVudCxcclxuICAgICAgICAgIHBzYnQ6IHRoaXMubWVyZ2VQc2J0cyhjdXJyZW50LnBzYnQsIGRlY3J5cHRlZFBzYnQpLFxyXG4gICAgICAgICAgc2lnbmF0dXJlczogWy4uLmN1cnJlbnQuc2lnbmF0dXJlcywgZGVjcnlwdGVkUHNidF0sXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAoZmluZ2VycHJpbnQgJiYgc2Vzc2lvbklkKSB7XHJcbiAgICAgICAgdGhpcy5uZXR3b3JrU2lnbmF0dXJlUmVjZWl2ZWQkLm5leHQoeyBmaW5nZXJwcmludCwgc2Vzc2lvbklkIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICB0aGlzLnJlbGF5LmV2ZW50cy5vbignUk9MRV9VUERBVEUnKS5zdWJzY3JpYmUoKGUpID0+IHtcclxuICAgICAgY29uc3QgbmV3Um9sZSA9IGUucGF5bG9hZDtcclxuICAgICAgdGhpcy5yb2xlLnNldChuZXdSb2xlKTtcclxuXHJcbiAgICAgIGlmICghdGhpcy5oYXNBbm5vdW5jZWRKb2luICYmIG5ld1JvbGUgPT09ICdhZG1pbicpIHtcclxuICAgICAgICB0aGlzLmhhc0Fubm91bmNlZEpvaW4gPSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHNldFJvb21LZXkoa2V5OiBzdHJpbmcgfCBudWxsKSB7XHJcbiAgICB0aGlzLmVuY3J5cHRpb25LZXkgPSBrZXk7XHJcbiAgfVxyXG5cclxuICBnZXRSb29tS2V5KCk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgcmV0dXJuIHRoaXMuZW5jcnlwdGlvbktleTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbm5lY3Qocm9vbUlkOiBzdHJpbmcsIGtleTogc3RyaW5nIHwgbnVsbCkge1xyXG4gICAgaWYgKHRoaXMuc3RhdHVzKCkgPT09ICdjb25uZWN0aW5nJykgcmV0dXJuO1xyXG5cclxuICAgIHRoaXMucmVzZXQoKTtcclxuICAgIHRoaXMuc3RhdHVzLnNldCgnY29ubmVjdGluZycpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICgha2V5KSB0aHJvdyBuZXcgRXJyb3IoJ0RlY3J5cHRpb24ga2V5IHJlcXVpcmVkJyk7XHJcblxyXG4gICAgICBpZiAodGhpcy5zZGsuc3RvcmUuZ2V0U3RhdGUoKSAhPT0gbnVsbCkge1xyXG4gICAgICAgIHRoaXMuc2RrLmRpc2Nvbm5lY3QoKTtcclxuICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCA1MCkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBhd2FpdCB0aGlzLnNkay5qb2luUm9vbShyb29tSWQsIGtleSk7XHJcblxyXG4gICAgICBpZiAodGhpcy5pc0Jyb3dzZXIpIHtcclxuICAgICAgICBjb25zdCBzZWN1cmVUb2tlbiA9IHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oYGFkbWluX3Rva2VuXyR7cm9vbUlkfWApO1xyXG5cclxuICAgICAgICBpZiAoc2VjdXJlVG9rZW4pIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRlY3J5cHRlZFRva2VuID0gYXdhaXQgdGhpcy5lbmNyeXB0aW9uRW5naW5lLmRlY3J5cHQoc2VjdXJlVG9rZW4sIGtleSk7XHJcbiAgICAgICAgICAgIGlmIChkZWNyeXB0ZWRUb2tlbikge1xyXG4gICAgICAgICAgICAgIGF3YWl0IHRoaXMuc2RrLmNsYWltQ29vcmRpbmF0b3IoZGVjcnlwdGVkVG9rZW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9IGNhdGNoIChkZWNyeXB0RXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gZGVjcnlwdCBsb2NhbCBhZG1pbiB0b2tlbi4gUHJvY2VlZGluZyBhcyBndWVzdC4nKTtcclxuICAgICAgICAgICAgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbShgYWRtaW5fdG9rZW5fJHtyb29tSWR9YCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBzYXZlZE5hbWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgZGlzcGxheV9uYW1lXyR7cm9vbUlkfWApO1xyXG4gICAgICAgIGlmIChzYXZlZE5hbWUpIHtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuc2RrLnNldERpc3BsYXlOYW1lKHNhdmVkTmFtZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICB0aGlzLnN0YXR1cy5zZXQoJ2Nvbm5lY3RlZCcpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdDb25uZWN0aW9uL1VwZ3JhZGUgZmFpbGVkOicsIGUpO1xyXG4gICAgICB0aGlzLnN0YXR1cy5zZXQoJ2Vycm9yJyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZGlzY29ubmVjdCgpIHtcclxuICAgIHRoaXMuc2RrLmRpc2Nvbm5lY3QoKTtcclxuICAgIHRoaXMuc3RhdHVzLnNldCgnZGlzY29ubmVjdGVkJyk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjcmVhdGVSb29tKFxyXG4gICAgcHNidEJhc2U2NDogc3RyaW5nLFxyXG4gICAgbmV0d29yazogJ2JpdGNvaW4nIHwgJ3Rlc3RuZXQnIHwgJ3NpZ25ldCcsXHJcbiAgICByb29tTmFtZTogc3RyaW5nID0gJ1VudGl0bGVkIFJvb20nLFxyXG4gICkge1xyXG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuc2RrLmNyZWF0ZVJvb20ocHNidEJhc2U2NCwgbmV0d29yaywgcm9vbU5hbWUpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGFzeW5jIHJlbmFtZVJvb20obmFtZTogc3RyaW5nKSB7XHJcbiAgICBhd2FpdCB0aGlzLnNkay5zZXRSb29tTmFtZShuYW1lKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBhc3luYyBjbG9zZVJvb20oKSB7XHJcbiAgICBhd2FpdCB0aGlzLnNkay5jbG9zZVJvb20oKTtcclxuXHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuc2RrLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKHN0YXRlKSB7XHJcbiAgICAgIHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0oYGFkbWluX3Rva2VuXyR7c3RhdGUucm9vbUlkfWApO1xyXG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShgZGlzcGxheV9uYW1lXyR7c3RhdGUucm9vbUlkfWApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHVibGljIGFzeW5jIHNldERpc3BsYXlOYW1lKG5hbWU6IHN0cmluZykge1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLnNkay5nZXRSb29tU3RhdGUoKTtcclxuICAgIGlmIChzdGF0ZSkgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYGRpc3BsYXlfbmFtZV8ke3N0YXRlLnJvb21JZH1gLCBuYW1lKTtcclxuXHJcbiAgICBhd2FpdCB0aGlzLnNkay5zZXREaXNwbGF5TmFtZShuYW1lKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBhc3luYyB0b2dnbGVMb2NrKGlzTG9ja2VkOiBib29sZWFuKSB7XHJcbiAgICBhd2FpdCB0aGlzLnNkay50b2dnbGVMb2NrKGlzTG9ja2VkKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBhc3luYyB1cGRhdGVXaGl0ZWxpc3QoYWRkcmVzc2VzOiBzdHJpbmdbXSwgcmVtb3ZlOiBib29sZWFuID0gZmFsc2UpIHtcclxuICAgIGF3YWl0IHRoaXMuc2RrLnVwZGF0ZVdoaXRlbGlzdChhZGRyZXNzZXMsIHJlbW92ZSk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjbGFpbUNvb3JkaW5hdG9yKHNlY3VyZVRva2VuOiBzdHJpbmcpIHtcclxuICAgIHRoaXMuc2RrLmNsYWltQ29vcmRpbmF0b3Ioc2VjdXJlVG9rZW4pO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldFJvb21MaW5rKGFwcEJhc2VVcmw6IHN0cmluZywgaW5jbHVkZUtleTogYm9vbGVhbiA9IGZhbHNlKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLnNkay5nZXRSb29tTGluayhhcHBCYXNlVXJsLCBpbmNsdWRlS2V5KTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGxvZ0FjdGlvbihhY3Rpb246IHN0cmluZywgZGV0YWlsOiBzdHJpbmcpIHtcclxuICAgIGNvbnNvbGUubG9nKCc9PT0gbG9nQWN0aW9uIENBTExFRCA9PT0nLCBhY3Rpb24sIGRldGFpbCk7XHJcbiAgICBhd2FpdCB0aGlzLnNkay5sb2dQYXJ0aWNpcGFudEFjdGlvbihhY3Rpb24sIGRldGFpbCk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgZ2V0QXVkaXRMb2dDc3YoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLnNkay5nZXRBdWRpdExvZ0NzdigpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGdldFNldHRsZW1lbnRDc3ZEYXRhKCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gdGhpcy5zZGsuZ2V0U2V0dGxlbWVudENzdkRhdGEoKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBhc3luYyBnZXRBdWRpdExvZ1BkZihvcHRpb25zPzogQXVkaXRMb2dPcHRpb25zKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5zZGsuZ2V0QXVkaXRMb2dQZGYob3B0aW9ucyk7XHJcbiAgfVxyXG5cclxuICBnZXRMb2NhbExhYmVsKGZpbmdlcnByaW50OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgYWRkcl9ib29rXyR7ZmluZ2VycHJpbnR9YCk7XHJcbiAgfVxyXG5cclxuICBzYXZlVG9BZGRyZXNzQm9vayhmaW5nZXJwcmludDogc3RyaW5nLCBsYWJlbDogc3RyaW5nKSB7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShgYWRkcl9ib29rXyR7ZmluZ2VycHJpbnR9YCwgbGFiZWwpO1xyXG4gIH1cclxuXHJcbiAgcmVtb3ZlRnJvbUFkZHJlc3NCb29rKGZpbmdlcnByaW50OiBzdHJpbmcpIHtcclxuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKGBhZGRyX2Jvb2tfJHtmaW5nZXJwcmludH1gKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBhc3luYyB1cGRhdGVTaWduZXJMYWJlbChmaW5nZXJwcmludDogc3RyaW5nLCBsYWJlbDogc3RyaW5nKSB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuc2RrLmdldFJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKHN0YXRlKSBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShgc2lnbmVyX2xhYmVsXyR7c3RhdGUucm9vbUlkfV8ke2ZpbmdlcnByaW50fWAsIGxhYmVsKTtcclxuXHJcbiAgICBhd2FpdCB0aGlzLnNkay5zZXRTaWduZXJMYWJlbChmaW5nZXJwcmludCwgbGFiZWwpO1xyXG4gIH1cclxuXHJcbiAgY2hlY2tBbmRBcHBseUxvY2FsTGFiZWxzKCkge1xyXG4gICAgaWYgKCF0aGlzLmlzQ29vcmRpbmF0b3IoKSkgcmV0dXJuO1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLnJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKCFzdGF0ZSkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGN1cnJlbnRMYWJlbHMgPSBzdGF0ZS5zaWduZXJMYWJlbHMgfHwge307XHJcbiAgICBjb25zdCBzaWduZXJzID0gdGhpcy5zaWduZXJzKCk7XHJcblxyXG4gICAgc2lnbmVycy5mb3JFYWNoKChzaWduZXIpID0+IHtcclxuICAgICAgaWYgKGN1cnJlbnRMYWJlbHNbc2lnbmVyLmZpbmdlcnByaW50XSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgY29uc3Qgc2F2ZWROYW1lID0gdGhpcy5nZXRMb2NhbExhYmVsKHNpZ25lci5maW5nZXJwcmludCk7XHJcbiAgICAgICAgaWYgKHNhdmVkTmFtZSkgdGhpcy51cGRhdGVTaWduZXJMYWJlbChzaWduZXIuZmluZ2VycHJpbnQsIHNhdmVkTmFtZSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGFzeW5jIHVwbG9hZFNpZ25hdHVyZShwc2J0QmFzZTY0OiBzdHJpbmcpIHtcclxuICAgIGNvbnN0IGZpbmdlcnByaW50ID0gdGhpcy5zZGsuZXh0cmFjdEZpbmdlcnByaW50RnJvbVNpZ25hdHVyZShwc2J0QmFzZTY0KTtcclxuICAgIGlmICghZmluZ2VycHJpbnQpIHRocm93IG5ldyBFcnJvcignQ291bGQgbm90IGV4dHJhY3QgZmluZ2VycHJpbnQgZnJvbSBQU0JUJyk7XHJcblxyXG4gICAgYXdhaXQgdGhpcy5zZGsudXBsb2FkU2lnbmF0dXJlKHBzYnRCYXNlNjQsIGZpbmdlcnByaW50KTtcclxuICB9XHJcblxyXG4gIGdldEZpbmFsVHhIZXgoKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICBpZiAodGhpcy5yb2xlKCkgIT09ICdhZG1pbicpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3Qgc3RhdGUgPSB0aGlzLnJvb21TdGF0ZSgpO1xyXG4gICAgaWYgKCFzdGF0ZT8ucHNidCkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4gUHNidFV0aWxzLmZpbmFsaXplVHgoc3RhdGUucHNidCk/LmhleCB8fCBudWxsO1xyXG4gIH1cclxuXHJcbiAgZ2V0RmluYWxUeElkKCk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgaWYgKHRoaXMucm9sZSgpICE9PSAnYWRtaW4nKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5yb29tU3RhdGUoKTtcclxuICAgIGlmICghc3RhdGU/LnBzYnQpIHJldHVybiBudWxsO1xyXG4gICAgcmV0dXJuIFBzYnRVdGlscy5maW5hbGl6ZVR4KHN0YXRlLnBzYnQpPy50eElkIHx8IG51bGw7XHJcbiAgfVxyXG5cclxuICBtZXJnZVBzYnRzKGJhc2U6IHN0cmluZywgbmV4dDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIHJldHVybiBQc2J0VXRpbHMubWVyZ2UoYmFzZSwgbmV4dCk7XHJcbiAgfVxyXG5cclxuICBnZXRUaHJlc2hvbGQocHNidEJhc2U2NDogc3RyaW5nKTogbnVtYmVyIHtcclxuICAgIHJldHVybiBQc2J0VXRpbHMuZ2V0VGhyZXNob2xkKHBzYnRCYXNlNjQpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIGFzeW5jIGZpbmFsaXplVHJhbnNhY3Rpb24oKSB7XHJcbiAgICByZXR1cm4gYXdhaXQgdGhpcy5zZGsuZmluYWxpemVUcmFuc2FjdGlvbigpO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIHJlc2V0KCkge1xyXG4gICAgdGhpcy5yb2xlLnNldCgnZ3Vlc3QnKTtcclxuICAgIHRoaXMuaXNDbG9zZWQuc2V0KGZhbHNlKTtcclxuXHJcbiAgICB0aGlzLmRlY3J5cHRpb25FcnJvci5zZXQobnVsbCk7XHJcbiAgICB0aGlzLmlzTG9ja2VkT3V0LnNldChmYWxzZSk7XHJcbiAgICB0aGlzLmlzUm9vbUZ1bGwuc2V0KGZhbHNlKTtcclxuICAgIHRoaXMucm9vbU5vdEZvdW5kLnNldChmYWxzZSk7XHJcblxyXG4gICAgdGhpcy5hY3RpdmVTZXNzaW9ucy5zZXQoW10pO1xyXG4gICAgdGhpcy5zdGF0dXMuc2V0KCdkaXNjb25uZWN0ZWQnKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgY2xlYXJMb2NhbFJvb21EYXRhKHJvb21JZDogc3RyaW5nKSB7XHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShgZGlzcGxheV9uYW1lXyR7cm9vbUlkfWApO1xyXG4gICAgc2Vzc2lvblN0b3JhZ2UucmVtb3ZlSXRlbShgYWRtaW5fdG9rZW5fJHtyb29tSWR9YCk7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgcm9vbVN0YXRlID0gc2lnbmFsPFJvb21TdGF0ZSB8IG51bGw+KG51bGwpO1xyXG4gIHB1YmxpYyBzdGF0dXMgPSBzaWduYWw8J2Rpc2Nvbm5lY3RlZCcgfCAnY29ubmVjdGluZycgfCAnY29ubmVjdGVkJyB8ICdlcnJvcic+KCdkaXNjb25uZWN0ZWQnKTtcclxuICBwdWJsaWMgcm9sZSA9IHNpZ25hbDwnZ3Vlc3QnIHwgJ2FkbWluJz4oJ2d1ZXN0Jyk7XHJcbiAgcHVibGljIGN1cnJlbnRTZXNzaW9uSWQgPSBzaWduYWw8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgcHVibGljIGFjdGl2ZVNlc3Npb25zID0gc2lnbmFsPHsgaWQ6IHN0cmluZzsgcm9sZTogc3RyaW5nOyBkaXNwbGF5TmFtZT86IHN0cmluZyB9W10+KFtdKTtcclxuICBwdWJsaWMgbmV0d29ya1NpZ25hdHVyZVJlY2VpdmVkJCA9IG5ldyBTdWJqZWN0PHsgZmluZ2VycHJpbnQ6IHN0cmluZzsgc2Vzc2lvbklkOiBzdHJpbmcgfT4oKTtcclxuXHJcbiAgcHVibGljIGlzUm9vbUZ1bGwgPSBzaWduYWwoZmFsc2UpO1xyXG4gIHB1YmxpYyBpc0Nsb3NlZCA9IHNpZ25hbChmYWxzZSk7XHJcbiAgcHVibGljIGlzTG9ja2VkT3V0ID0gc2lnbmFsKGZhbHNlKTtcclxuICBwdWJsaWMgcm9vbU5vdEZvdW5kID0gc2lnbmFsKGZhbHNlKTtcclxuICBwdWJsaWMgZGVjcnlwdGlvbkVycm9yID0gc2lnbmFsPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICBwdWJsaWMgaXNDb29yZGluYXRvciA9IGNvbXB1dGVkKCgpID0+IHRoaXMucm9sZSgpID09PSAnYWRtaW4nKTtcclxuXHJcbiAgcHVibGljIHNpZ25lcnMgPSBjb21wdXRlZCgoKSA9PiB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMucm9vbVN0YXRlKCk7XHJcbiAgICByZXR1cm4gdGhpcy5zZGsuZ2V0U2lnbmVyc1N0YXR1cyhzdGF0ZSk7XHJcbiAgfSk7XHJcblxyXG4gIHB1YmxpYyB0eERldGFpbHMgPSBjb21wdXRlZCgoKSA9PiB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMucm9vbVN0YXRlKCk7XHJcbiAgICByZXR1cm4gdGhpcy5zZGsuZ2V0VHhEZXRhaWxzKHN0YXRlKTtcclxuICB9KTtcclxuXHJcbiAgcHVibGljIHNpZ25lclRocmVzaG9sZCA9IGNvbXB1dGVkKCgpID0+IHtcclxuICAgIGNvbnN0IHN0YXRlID0gdGhpcy5yb29tU3RhdGUoKTtcclxuICAgIHJldHVybiB0aGlzLnNkay5nZXRUaHJlc2hvbGQoc3RhdGUpO1xyXG4gIH0pO1xyXG5cclxuICBwdWJsaWMgc2lnbmVyQ291bnQgPSBjb21wdXRlZCgoKSA9PiB0aGlzLnNpZ25lcnMoKS5maWx0ZXIoKHNpZ25lcikgPT4gc2lnbmVyLnNpZ25lZCkubGVuZ3RoKTtcclxuXHJcbiAgcHVibGljIGlzUmVhZHlUb0Jyb2FkY2FzdCA9IGNvbXB1dGVkKCgpID0+IHRoaXMuc2lnbmVyQ291bnQoKSA+PSB0aGlzLnNpZ25lclRocmVzaG9sZCgpKTtcclxufVxyXG4iLCIvKlxyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMjYgU3RhdGVsZXNzIFJlc2VhcmNoIEx0ZFxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTogeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBBZmZlcm8gR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWRcclxuICogYnkgdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbiwgZWl0aGVyIHZlcnNpb24gMyBvZiB0aGUgTGljZW5zZSwgb3JcclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cclxuICpcclxuICogVGhpcyBwcm9ncmFtIGlzIGRpc3RyaWJ1dGVkIGluIHRoZSBob3BlIHRoYXQgaXQgd2lsbCBiZSB1c2VmdWwsXHJcbiAqIGJ1dCBXSVRIT1VUIEFOWSBXQVJSQU5UWTsgd2l0aG91dCBldmVuIHRoZSBpbXBsaWVkIHdhcnJhbnR5IG9mXHJcbiAqIE1FUkNIQU5UQUJJTElUWSBvciBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRS4gU2VlIHRoZVxyXG4gKiBHTlUgQWZmZXJvIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgZm9yIG1vcmUgZGV0YWlscy5cclxuICovXHJcblxyXG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IGVudmlyb25tZW50IH0gZnJvbSAnLi4vLi4vLi4vZW52aXJvbm1lbnRzL2Vudmlyb25tZW50JztcclxuZXhwb3J0IGNvbnN0IFBST1RPQ09MX1ZFUlNJT04gPSAnMS4wLjAnO1xyXG5pbXBvcnQgeyBTaWduaW5nUm9vbUNsaWVudCB9IGZyb20gJ0BzaWduaW5nLXJvb20vc2RrJztcclxuXHJcbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXHJcbmV4cG9ydCBjbGFzcyBTREtDbGllbnRGYWN0b3J5U2VydmljZSB7XHJcbiAgLyoqXHJcbiAgICogQ3JlYXRlcyBhIFNpZ25pbmcgUm9vbSBTREsgQ2xpZW50XHJcbiAgICogQHJldHVybnMgU2lnbmluZ1Jvb21DbGllbnRcclxuICAgKi9cclxuICBjcmVhdGUoY29uZmlnPzogUGFydGlhbDx7IGFwaVVybDogc3RyaW5nOyBwcm90b2NvbFZlcnNpb246IHN0cmluZyB9Pikge1xyXG4gICAgcmV0dXJuIG5ldyBTaWduaW5nUm9vbUNsaWVudCh7XHJcbiAgICAgIGFwaVVybDogY29uZmlnPy5hcGlVcmwgPz8gZW52aXJvbm1lbnQuYXBpVXJsLFxyXG4gICAgICBwcm90b2NvbFZlcnNpb246IGNvbmZpZz8ucHJvdG9jb2xWZXJzaW9uID8/IFBST1RPQ09MX1ZFUlNJT04sXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTb2NrZXRTZXJ2aWNlIH0gZnJvbSAnLi4vc29ja2V0L3NvY2tldC5zZXJ2aWNlJztcclxuaW1wb3J0IHtcclxuICBNb2RhbFZpZXdlZFBheWxvYWQsXHJcbiAgUHJpdmFjeVRvZ2dsZWRQYXlsb2FkLFxyXG4gIFByaXZhY3lTZWN0aW9uLFxyXG4gIFByaXZhY3lTdGF0ZSxcclxuICBEYXRhQ29waWVkUGF5bG9hZCxcclxuICBSb29tUmVuYW1lZFBheWxvYWQsXHJcbiAgUGFydGljaXBhbnRMYWJlbGxlZFBheWxvYWQsXHJcbiAgRG93bmxvYWRUcmlnZ2VyZWRQYXlsb2FkLFxyXG4gIFJvb21TdGF0ZUNoYW5nZWRQYXlsb2FkLFxyXG4gIFFyU3RhdGVDaGFuZ2VkUGF5bG9hZCxcclxuICBGb3VudGFpbkZvcm1hdENoYW5nZWRQYXlsb2FkLFxyXG4gIFBzYnRJbXBvcnRlZFBheWxvYWQsXHJcbiAgVHJhbnNhY3Rpb25WaWV3Q2hhbmdlZFBheWxvYWQsXHJcbiAgQmFzZUV2ZW50Q29udGV4dCxcclxuICBTZWN1cml0eUFsZXJ0UGF5bG9hZCxcclxufSBmcm9tICcuLi8uLi9tb2RlbHMvd2lkZ2V0LWV2ZW50cy5tb2RlbCc7XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgV2lkZ2V0RGlzcGF0Y2hlclNlcnZpY2Uge1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgc29ja2V0OiBTb2NrZXRTZXJ2aWNlKSB7fVxyXG5cclxuICAvKipcclxuICAgKiBTZWN1cmVseSBjaGVja3MgaWYgdGhlIGFwcGxpY2F0aW9uIGlzIHJ1bm5pbmcgaW5zaWRlIGFuIGlmcmFtZS5cclxuICAgKi9cclxuICBwdWJsaWMgZ2V0IGlzRW1iZWRkZWQoKTogYm9vbGVhbiB7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXR1cm4gd2luZG93ICE9PSB3aW5kb3cudG9wO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgdGFyZ2V0T3JpZ2luOiBzdHJpbmcgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gOiAnJztcclxuXHJcbiAgLyoqXHJcbiAgICogU2V0cyB0aGUgc3RyaWN0IG9yaWdpbiBmb3IgYWxsIG91dGdvaW5nIHdpbmRvdy5wb3N0TWVzc2FnZSBldmVudHMuXHJcbiAgICovXHJcbiAgcHVibGljIHNldFRhcmdldE9yaWdpbihvcmlnaW46IHN0cmluZyk6IHZvaWQge1xyXG4gICAgdGhpcy50YXJnZXRPcmlnaW4gPSBvcmlnaW47XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBIZWxwZXIgdG8gcmV0dXJuIGN1cnJlbnQgc3RhdGUgb2Ygcm9vbVxyXG4gICAqL1xyXG4gIHByaXZhdGUgZ2V0QmFzZUNvbnRleHQoKTogQmFzZUV2ZW50Q29udGV4dCB7XHJcbiAgICBjb25zdCBzdGF0ZSA9IHRoaXMuc29ja2V0LnJvb21TdGF0ZSgpO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcm9vbUlkOiBzdGF0ZT8ucm9vbUlkIHx8IG51bGwsXHJcbiAgICAgIHNlc3Npb25JZDogdGhpcy5zb2NrZXQuY3VycmVudFNlc3Npb25JZCgpIHx8IG51bGwsXHJcbiAgICAgIHJvbGU6IHRoaXMuc29ja2V0LmlzQ29vcmRpbmF0b3IoKSA/ICdjb29yZGluYXRvcicgOiBzdGF0ZSA/ICdndWVzdCcgOiAndW5rbm93bicsXHJcbiAgICAgIG5ldHdvcms6IHN0YXRlPy5uZXR3b3JrIHx8IG51bGwsXHJcbiAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb3JlIGRpc3BhdGNoZXIgdGhhdCBlbWl0cyBldmVudHMgdG8gdGhlIHBhcmVudCB3aW5kb3cgKHNpZ25pbmcgcm9vbSkgd2l0aCBhIGNvbnNpc3RlbnQgc3RydWN0dXJlLiBBbGwgd2lkZ2V0IGV2ZW50cyBzaG91bGQgZnVubmVsIHRocm91Z2ggdGhpcyBtZXRob2QuXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBkaXNwYXRjaEV2ZW50KGFjdGlvbjogc3RyaW5nLCBwYXlsb2FkOiBhbnkpOiB2b2lkIHtcclxuICAgIGlmICghdGhpcy5pc0VtYmVkZGVkKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAod2luZG93ICYmIHdpbmRvdy5wYXJlbnQpIHtcclxuICAgICAgY29uc3QgZW5yaWNoZWRQYXlsb2FkID0ge1xyXG4gICAgICAgIC4uLnRoaXMuZ2V0QmFzZUNvbnRleHQoKSxcclxuICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgd2luZG93LnBhcmVudC5wb3N0TWVzc2FnZShcclxuICAgICAgICB7XHJcbiAgICAgICAgICB0eXBlOiAnU0lHTklOR19ST09NX0VWRU5UJyxcclxuICAgICAgICAgIGFjdGlvbjogYWN0aW9uLFxyXG4gICAgICAgICAgcGF5bG9hZDogZW5yaWNoZWRQYXlsb2FkLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGhpcy50YXJnZXRPcmlnaW4sXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyAtLS0gUFJJVkFDWSBUT0dHTEVTIC0tLVxyXG5cclxuICBlbWl0TW9kYWxWaWV3KG1vZGFsTmFtZTogc3RyaW5nLCBjb250ZXh0Pzogc3RyaW5nKTogdm9pZCB7XHJcbiAgICBjb25zdCBwYXlsb2FkOiBNb2RhbFZpZXdlZFBheWxvYWQgPSB7IG1vZGFsTmFtZSwgY29udGV4dCB9O1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdtb2RhbFZpZXdlZCcsIHBheWxvYWQpO1xyXG4gIH1cclxuXHJcbiAgZW1pdFByaXZhY3lUb2dnbGUoc2VjdGlvbjogUHJpdmFjeVNlY3Rpb24sIHN0YXRlOiBQcml2YWN5U3RhdGUpOiB2b2lkIHtcclxuICAgIGNvbnN0IHBheWxvYWQ6IFByaXZhY3lUb2dnbGVkUGF5bG9hZCA9IHsgc2VjdGlvbiwgc3RhdGUgfTtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgncHJpdmFjeVRvZ2dsZWQnLCBwYXlsb2FkKTtcclxuICB9XHJcblxyXG4gIC8vIC0tLSBST09NIE9WRVJWSUVXICYgQUNUSU9OUyAtLS1cclxuXHJcbiAgZW1pdFJvb21SZW5hbWVkKG5ld05hbWU6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgY29uc3QgcGF5bG9hZDogUm9vbVJlbmFtZWRQYXlsb2FkID0geyBuZXdOYW1lIH07XHJcbiAgICB0aGlzLmRpc3BhdGNoRXZlbnQoJ3Jvb21SZW5hbWVkJywgcGF5bG9hZCk7XHJcbiAgfVxyXG5cclxuICBlbWl0RGF0YUNvcGllZChkYXRhVHlwZTogRGF0YUNvcGllZFBheWxvYWRbJ2RhdGFUeXBlJ10pOiB2b2lkIHtcclxuICAgIGNvbnN0IHBheWxvYWQ6IERhdGFDb3BpZWRQYXlsb2FkID0geyBkYXRhVHlwZSB9O1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdkYXRhQ29waWVkJywgcGF5bG9hZCk7XHJcbiAgfVxyXG5cclxuICBlbWl0RG93bmxvYWRUcmlnZ2VyZWQoZmlsZVR5cGU6IERvd25sb2FkVHJpZ2dlcmVkUGF5bG9hZFsnZmlsZVR5cGUnXSk6IHZvaWQge1xyXG4gICAgY29uc3QgcGF5bG9hZDogRG93bmxvYWRUcmlnZ2VyZWRQYXlsb2FkID0geyBmaWxlVHlwZSB9O1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdkb3dubG9hZFRyaWdnZXJlZCcsIHBheWxvYWQpO1xyXG4gIH1cclxuXHJcbiAgZW1pdFJvb21TdGF0ZUNoYW5nZWQoc3RhdGU6IFJvb21TdGF0ZUNoYW5nZWRQYXlsb2FkWydzdGF0ZSddKTogdm9pZCB7XHJcbiAgICBjb25zdCBwYXlsb2FkOiBSb29tU3RhdGVDaGFuZ2VkUGF5bG9hZCA9IHsgc3RhdGUgfTtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgncm9vbVN0YXRlQ2hhbmdlZCcsIHBheWxvYWQpO1xyXG4gIH1cclxuXHJcbiAgZW1pdFFyU3RhdGVDaGFuZ2VkKGluY2x1ZGVzS2V5OiBib29sZWFuLCBpc1JldmVhbGVkOiBib29sZWFuKTogdm9pZCB7XHJcbiAgICBjb25zdCBwYXlsb2FkOiBRclN0YXRlQ2hhbmdlZFBheWxvYWQgPSB7IGluY2x1ZGVzS2V5LCBpc1JldmVhbGVkIH07XHJcbiAgICB0aGlzLmRpc3BhdGNoRXZlbnQoJ3FyU3RhdGVDaGFuZ2VkJywgcGF5bG9hZCk7XHJcbiAgfVxyXG5cclxuICAvLyAtLS0gU0lHTkVSIEFDVElPTlMgJiBUUkFOU0FDVElPTiBERVRBSUxTIC0tLVxyXG5cclxuICBlbWl0Rm91bnRhaW5Gb3JtYXRDaGFuZ2VkKGZvcm1hdDogRm91bnRhaW5Gb3JtYXRDaGFuZ2VkUGF5bG9hZFsnZm9ybWF0J10pOiB2b2lkIHtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgnZm91bnRhaW5Gb3JtYXRDaGFuZ2VkJywgeyBmb3JtYXQgfSk7XHJcbiAgfVxyXG5cclxuICBlbWl0Rm91bnRhaW5TdGF0ZUNoYW5nZWQoaXNSZXZlYWxlZDogYm9vbGVhbiwgZm9ybWF0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgnZm91bnRhaW5TdGF0ZUNoYW5nZWQnLCB7IGlzUmV2ZWFsZWQsIGZvcm1hdCB9KTtcclxuICB9XHJcblxyXG4gIGVtaXRQc2J0SW1wb3J0ZWQobWV0aG9kOiBQc2J0SW1wb3J0ZWRQYXlsb2FkWydtZXRob2QnXSk6IHZvaWQge1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdwc2J0SW1wb3J0ZWQnLCB7IG1ldGhvZCB9KTtcclxuICB9XHJcblxyXG4gIGVtaXRUcmFuc2FjdGlvblZpZXdDaGFuZ2VkKHZpZXc6IFRyYW5zYWN0aW9uVmlld0NoYW5nZWRQYXlsb2FkWyd2aWV3J10pOiB2b2lkIHtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgndHJhbnNhY3Rpb25WaWV3Q2hhbmdlZCcsIHsgdmlldyB9KTtcclxuICB9XHJcblxyXG4gIGVtaXREZXN0aW5hdGlvblZlcmlmaWVkKFxyXG4gICAgdHlwZTogJ2lucHV0cycgfCAnb3V0cHV0cycsXHJcbiAgICBhZGRyZXNzOiBzdHJpbmcgfCAnYmF0Y2gnLFxyXG4gICAgaXNWZXJpZmllZDogYm9vbGVhbixcclxuICApOiB2b2lkIHtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgnZGVzdGluYXRpb25WZXJpZmllZCcsIHsgdHlwZSwgYWRkcmVzcywgaXNWZXJpZmllZCB9KTtcclxuICB9XHJcblxyXG4gIGVtaXRBZGRyZXNzQ29waWVkKGFkZHJlc3M6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdhZGRyZXNzQ29waWVkJywgeyBhZGRyZXNzIH0pO1xyXG4gIH1cclxuXHJcbiAgZW1pdFJvb21DcmVhdGVkKHJvb21JZDogc3RyaW5nLCBuZXR3b3JrOiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgncm9vbUNyZWF0ZWQnLCB7IHJvb21JZCwgbmV0d29yayB9KTtcclxuICB9XHJcblxyXG4gIC8vIC0tLSBUUkFOU0FDVElPTiBGSU5BTElaQVRJT04gLS0tXHJcbiAgZW1pdFRyYW5zYWN0aW9uRmluYWxpemVkKHBheWxvYWQ6IHtcclxuICAgIHR4SWQ6IHN0cmluZztcclxuICAgIHR4SGV4OiBzdHJpbmc7XHJcbiAgICByb29tU3RhdGU6IGFueTtcclxuICAgIGF1ZGl0TG9nQ3N2OiBzdHJpbmc7XHJcbiAgICBzZXR0bGVtZW50Q3N2OiBzdHJpbmcgfCB1bmRlZmluZWQ7XHJcbiAgICBhdWRpdFBkZlVyaTogc3RyaW5nIHwgbnVsbDtcclxuICB9KTogdm9pZCB7XHJcbiAgICB0aGlzLmRpc3BhdGNoRXZlbnQoJ3RyYW5zYWN0aW9uRmluYWxpemVkJywgcGF5bG9hZCk7XHJcbiAgfVxyXG5cclxuICAvLyAtLS0gUEFSVElDSVBBTlQgUFJFU0VOQ0UgLS0tXHJcbiAgZW1pdFBhcnRpY2lwYW50UHJlc2VuY2UoXHJcbiAgICBhY3Rpb246ICdqb2luZWQnIHwgJ2xlZnQnLFxyXG4gICAgcGFydGljaXBhbnRJZDogc3RyaW5nLFxyXG4gICAgcGFydGljaXBhbnRSb2xlOiBzdHJpbmcsXHJcbiAgICBkaXNwbGF5TmFtZT86IHN0cmluZyxcclxuICApOiB2b2lkIHtcclxuICAgIHRoaXMuZGlzcGF0Y2hFdmVudCgncGFydGljaXBhbnRQcmVzZW5jZScsIHtcclxuICAgICAgYWN0aW9uLFxyXG4gICAgICBwYXJ0aWNpcGFudElkLFxyXG4gICAgICBwYXJ0aWNpcGFudFJvbGUsXHJcbiAgICAgIGRpc3BsYXlOYW1lLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyAtLS0gU0lHTkFUVVJFUyAtLS1cclxuICBlbWl0U2lnbmF0dXJlUmVjZWl2ZWQoXHJcbiAgICBmaW5nZXJwcmludDogc3RyaW5nLFxyXG4gICAgc2lnbmVyTGFiZWw/OiBzdHJpbmcsXHJcbiAgICBzaWduZXJTZXNzaW9uSWQ/OiBzdHJpbmcsXHJcbiAgICBzaWduZXJOYW1lPzogc3RyaW5nLFxyXG4gICk6IHZvaWQge1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdzaWduYXR1cmVSZWNlaXZlZCcsIHtcclxuICAgICAgZmluZ2VycHJpbnQsXHJcbiAgICAgIHNpZ25lckxhYmVsLFxyXG4gICAgICBzaWduZXJTZXNzaW9uSWQsXHJcbiAgICAgIHNpZ25lck5hbWUsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGVtaXRQYXJ0aWNpcGFudExhYmVsbGVkKFxyXG4gICAgdGFyZ2V0OiAnc2VsZicgfCAncGFydGljaXBhbnQnIHwgJ3NpZ25lcicsXHJcbiAgICBsYWJlbDogc3RyaW5nLFxyXG4gICAgZmluZ2VycHJpbnQ/OiBzdHJpbmcsXHJcbiAgICBwYXJ0aWNpcGFudElkPzogc3RyaW5nLFxyXG4gICk6IHZvaWQge1xyXG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KCdwYXJ0aWNpcGFudExhYmVsbGVkJywgeyB0YXJnZXQsIGxhYmVsLCBmaW5nZXJwcmludCwgcGFydGljaXBhbnRJZCB9KTtcclxuICB9XHJcblxyXG4gIGVtaXRTZWN1cml0eUFsZXJ0KFxyXG4gICAgYWxlcnRUeXBlOiBTZWN1cml0eUFsZXJ0UGF5bG9hZFsnYWxlcnRUeXBlJ10sXHJcbiAgICBzZXZlcml0eTogU2VjdXJpdHlBbGVydFBheWxvYWRbJ3NldmVyaXR5J10sXHJcbiAgICBtZXNzYWdlOiBzdHJpbmcsXHJcbiAgKTogdm9pZCB7XHJcbiAgICB0aGlzLmRpc3BhdGNoRXZlbnQoJ3NlY3VyaXR5QWxlcnQnLCB7IGFsZXJ0VHlwZSwgc2V2ZXJpdHksIG1lc3NhZ2UgfSk7XHJcbiAgfVxyXG59XHJcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBS08sSUFBTSxtQkFBTixNQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1wQixZQUFZO0FBQ2xCLFVBQU0sSUFDSCxPQUFPLFdBQVcsZUFBZSxPQUFPLFVBQ3hDLE9BQU8sV0FBVyxlQUFnQixPQUFlO0FBQ3BELFFBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxPQUFRLE9BQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM5RCxXQUFPLEVBQUU7QUFBQSxFQUNYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRUSxnQkFBZ0IsT0FBbUI7QUFDekMsVUFBTSxJQUNILE9BQU8sV0FBVyxlQUFlLE9BQU8sVUFDeEMsT0FBTyxXQUFXLGVBQWdCLE9BQWU7QUFDcEQsUUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLGdCQUFpQixPQUFNLElBQUksTUFBTSxzQkFBc0I7QUFDcEUsV0FBTyxFQUFFLGdCQUFnQixLQUFLO0FBQUEsRUFDaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPUSxXQUFXLFFBQTZCO0FBQzlDLFFBQUksT0FBTyxXQUFXLGFBQWE7QUFDakMsYUFBTyxPQUFPLEtBQUssTUFBTSxFQUFFLFNBQVMsUUFBUTtBQUFBLElBQzlDO0FBQ0EsV0FBTyxLQUFLLE9BQU8sYUFBYSxHQUFHLElBQUksV0FBVyxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT1EsV0FBVyxXQUErQjtBQUNoRCxRQUFJLE9BQU8sV0FBVyxhQUFhO0FBQ2pDLGFBQU8sSUFBSSxXQUFXLE9BQU8sS0FBSyxXQUFXLFFBQVEsQ0FBQztBQUFBLElBQ3hEO0FBQ0EsV0FBTyxXQUFXLEtBQUssS0FBSyxTQUFTLEdBQUcsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7QUFBQSxFQUNoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNTSxjQUErQjtBQUFBO0FBQ25DLFlBQU0sZUFBZSxLQUFLLFVBQVU7QUFDcEMsWUFBTSxNQUFNLE1BQU0sYUFBYSxZQUFZLEVBQUUsTUFBTSxXQUFXLFFBQVEsSUFBSSxHQUFHLE1BQU07QUFBQSxRQUNqRjtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFDRCxZQUFNLFdBQVcsTUFBTSxhQUFhLFVBQVUsT0FBTyxHQUFHO0FBQ3hELGFBQU8sS0FBSyxXQUFXLFFBQXVCO0FBQUEsSUFDaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUU0sUUFBUSxNQUFjLEtBQThCO0FBQUE7QUFDeEQsWUFBTSxVQUFVLElBQUksWUFBWTtBQUNoQyxZQUFNLFNBQVMsS0FBSyxXQUFXLEdBQUc7QUFDbEMsWUFBTSxlQUFlLEtBQUssVUFBVTtBQUVwQyxZQUFNLFlBQVksTUFBTSxhQUFhLFVBQVUsT0FBTyxRQUFRLEVBQUUsTUFBTSxVQUFVLEdBQUcsTUFBTTtBQUFBLFFBQ3ZGO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU0sS0FBSyxLQUFLLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ2xELFlBQU0sZ0JBQWdCLE1BQU0sYUFBYTtBQUFBLFFBQ3ZDLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxRQUN0QjtBQUFBLFFBQ0EsUUFBUSxPQUFPLElBQUk7QUFBQSxNQUNyQjtBQUVBLFlBQU0sU0FBUyxJQUFJLFdBQVcsR0FBRyxTQUFTLGNBQWMsVUFBVTtBQUNsRSxhQUFPLElBQUksRUFBRTtBQUNiLGFBQU8sSUFBSSxJQUFJLFdBQVcsYUFBYSxHQUFHLEdBQUcsTUFBTTtBQUNuRCxhQUFPLEtBQUssV0FBVyxPQUFPLE1BQU07QUFBQSxJQUN0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNNLFFBQVEsZUFBdUIsS0FBOEI7QUFBQTtBQUNqRSxZQUFNLFNBQVMsS0FBSyxXQUFXLEdBQUc7QUFDbEMsWUFBTSxlQUFlLEtBQUssVUFBVTtBQUNwQyxZQUFNLFlBQVksTUFBTSxhQUFhO0FBQUEsUUFDbkM7QUFBQSxRQUNBO0FBQUEsUUFDQSxFQUFFLE1BQU0sVUFBVTtBQUFBLFFBQ2xCO0FBQUEsUUFDQSxDQUFDLFdBQVcsU0FBUztBQUFBLE1BQ3ZCO0FBRUEsWUFBTSxpQkFBaUIsS0FBSyxXQUFXLGFBQWE7QUFDcEQsWUFBTSxLQUFLLGVBQWUsTUFBTSxHQUFHLEVBQUU7QUFDckMsWUFBTSxhQUFhLGVBQWUsTUFBTSxFQUFFO0FBRTFDLFlBQU0sZ0JBQWdCLE1BQU0sYUFBYTtBQUFBLFFBQ3ZDLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxRQUN0QjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsYUFBTyxJQUFJLFlBQVksRUFBRSxPQUFPLGFBQWE7QUFBQSxJQUMvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNNLFVBQVUsTUFBYyxLQUE4QjtBQUFBO0FBQzFELFlBQU0sVUFBVSxJQUFJLFlBQVk7QUFDaEMsWUFBTSxhQUFhLFFBQVEsT0FBTyxPQUFPLEdBQUc7QUFDNUMsWUFBTSxlQUFlLEtBQUssVUFBVTtBQUNwQyxZQUFNLGFBQWEsTUFBTSxhQUFhLE9BQU8sV0FBVyxVQUFVO0FBQ2xFLGFBQU8sTUFBTSxLQUFLLElBQUksV0FBVyxVQUFVLENBQUMsRUFDekMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxFQUNQLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDaEI7QUFBQTtBQUNGOzs7QUNuSkEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxRQUFRLFdBQVc7QUFDNUIsU0FBUyxRQUFRLGVBQWU7QUFDaEMsU0FBUyxTQUFTLGNBQWMsZUFBZTtBQXdEeEMsSUFBTSxZQUFOLE1BQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPckIsT0FBTyxPQUFPLEtBQXlCO0FBQ3JDLFVBQU0sUUFBUSxJQUFJLFFBQVEsT0FBTyxFQUFFO0FBQ25DLFdBQU8saUJBQWlCLEtBQUssS0FBSyxJQUFJLElBQUksT0FBTyxLQUFLLElBQUksT0FBTyxPQUFPLEtBQUs7QUFBQSxFQUMvRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsT0FBTyxVQUFVLE9BQXVCO0FBQ3RDLFVBQU0sUUFBUSxNQUFNLEtBQUs7QUFDekIsUUFBSSxpQkFBaUIsS0FBSyxLQUFLLEtBQUssTUFBTSxZQUFZLEVBQUUsV0FBVyxVQUFVLEdBQUc7QUFDOUUsVUFBSTtBQUNGLGVBQU8sT0FBTyxPQUFPLElBQUksT0FBTyxLQUFLLENBQUM7QUFBQSxNQUN4QyxTQUFTLEdBQUc7QUFDVixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFPLE1BQU0sTUFBYyxNQUFzQjtBQUMvQyxRQUFJO0FBQ0YsWUFBTSxTQUFTLFlBQVksU0FBUyxLQUFLLE9BQU8sSUFBSSxDQUFDO0FBQ3JELFlBQU0sU0FBUyxZQUFZLFNBQVMsS0FBSyxPQUFPLElBQUksQ0FBQztBQUNyRCxhQUFPLFFBQVEsTUFBTTtBQUNyQixhQUFPLE9BQU8sT0FBTyxPQUFPLE9BQU8sQ0FBQztBQUFBLElBQ3RDLFNBQVMsR0FBRztBQUNWLGNBQVEsTUFBTSxrQkFBa0IsQ0FBQztBQUNqQyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxPQUFPLGFBQWEsWUFBNEI7QUFDOUMsUUFBSTtBQUNGLFlBQU0sS0FBSyxZQUFZLFNBQVMsT0FBTyxPQUFPLFVBQVUsQ0FBQztBQUd6RCxlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsY0FBYyxLQUFLO0FBQ3hDLGNBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUMzQixZQUFJLENBQUMsTUFBTztBQUVaLGNBQU0sU0FBUyxNQUFNLGlCQUFpQixNQUFNO0FBQzVDLFlBQUksQ0FBQyxVQUFVLE9BQU8sV0FBVyxFQUFHO0FBRXBDLGNBQU0sVUFBVSxPQUFPLENBQUM7QUFFeEIsWUFBSSxXQUFXLE1BQVEsV0FBVyxJQUFNO0FBQ3RDLGlCQUFPLFVBQVU7QUFBQSxRQUNuQjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVCxTQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsT0FBTyx1QkFBdUIsVUFBaUM7QUFDN0QsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLE9BQU8sUUFBUTtBQUNsQyxZQUFNLEtBQUssWUFBWSxTQUFTLEtBQUs7QUFFckMsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLGNBQWMsS0FBSztBQUN4QyxjQUFNLFFBQVEsR0FBRyxTQUFTLENBQUM7QUFFM0IsWUFBSSxNQUFNLGNBQWMsTUFBTSxXQUFXLFNBQVMsR0FBRztBQUNuRCxnQkFBTSxlQUFlLE1BQU0sV0FBVyxDQUFDLEVBQUUsQ0FBQztBQUUxQyxjQUFJLE1BQU0saUJBQWlCO0FBQ3pCLHVCQUFXLENBQUMsUUFBUSxJQUFJLEtBQUssTUFBTSxpQkFBaUI7QUFDbEQsa0JBQUksSUFBSSxPQUFPLE1BQU0sTUFBTSxJQUFJLE9BQU8sWUFBWSxHQUFHO0FBQ25ELHVCQUFPLEtBQUssWUFBWSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUFBLGNBQ3REO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNULFNBQVMsR0FBRztBQUNWLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsT0FBTyxlQUNMLFlBQ0EsVUFBNEMsV0FDMUI7QUFDbEIsUUFBSTtBQUNGLFlBQU0sS0FBSyxZQUFZLFNBQVMsT0FBTyxPQUFPLFVBQVUsQ0FBQztBQUN6RCxZQUFNLGFBQWEsQ0FBQztBQUNwQixZQUFNLFVBQVUsQ0FBQztBQUNqQixVQUFJLGFBQWE7QUFDakIsVUFBSSxjQUFjO0FBRWxCLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxjQUFjLEtBQUs7QUFDeEMsY0FBTSxRQUFRLEdBQUcsU0FBUyxDQUFDO0FBQzNCLFlBQUksU0FBUztBQUNiLFlBQUksVUFBVTtBQUVkLFlBQUksTUFBTSxhQUFhO0FBQ3JCLG1CQUFTLE9BQU8sTUFBTSxZQUFZLE1BQU07QUFDeEMsd0JBQWM7QUFDZCxvQkFBVSxLQUFLLG9CQUFvQixNQUFNLFlBQVksUUFBUSxPQUFPO0FBQUEsUUFDdEUsV0FBVyxNQUFNLGdCQUFnQjtBQUMvQixvQkFBVTtBQUFBLFFBQ1o7QUFFQSxZQUFJLE9BQU87QUFDWCxZQUFJLE9BQU87QUFDWCxZQUFJO0FBQ0YsZ0JBQU0sV0FBWSxHQUFXLFdBQVcsT0FBTyxDQUFDO0FBQ2hELGNBQUksVUFBVSxNQUFNO0FBQ2xCLG1CQUFPLElBQUksT0FBTyxTQUFTLElBQUksRUFBRSxNQUFNLEdBQUcsQ0FBQyxJQUFJO0FBQy9DLG1CQUFPLFNBQVM7QUFBQSxVQUNsQjtBQUFBLFFBQ0YsU0FBUyxHQUFHO0FBQUEsUUFBQztBQUViLG1CQUFXLEtBQUssRUFBRSxTQUFTLFFBQVEsTUFBTSxLQUFLLENBQUM7QUFBQSxNQUNqRDtBQUVBLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxlQUFlLEtBQUs7QUFDekMsY0FBTSxTQUFTLEdBQUcsVUFBVSxDQUFDO0FBQzdCLGNBQU0sU0FBUyxPQUFPLE9BQU8sTUFBTTtBQUNuQyx1QkFBZTtBQUVmLGNBQU0sVUFBVSxLQUFLLG9CQUFvQixPQUFPLFVBQVUsSUFBSSxXQUFXLENBQUMsQ0FBQyxHQUFHLE9BQU87QUFDckYsWUFBSSxXQUFXO0FBRWYsWUFBSSxPQUFPLGlCQUFpQjtBQUMxQixxQkFBVyxDQUFDLEVBQUUsSUFBSSxLQUFLLE9BQU8saUJBQTBCO0FBQ3RELGdCQUFJLE1BQU0sTUFBTSxVQUFVLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUMsTUFBTSxHQUFHO0FBQ3BFLHlCQUFXO0FBQ1g7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxnQkFBUSxLQUFLLEVBQUUsU0FBUyxRQUFRLFNBQVMsQ0FBQztBQUFBLE1BQzVDO0FBRUEsY0FBUSxLQUFLLENBQUMsR0FBRyxNQUFNLE9BQU8sRUFBRSxRQUFRLElBQUksT0FBTyxFQUFFLFFBQVEsQ0FBQztBQUM5RCxZQUFNLE1BQU0sYUFBYSxJQUFJLEtBQUssSUFBSSxHQUFHLGFBQWEsV0FBVyxJQUFJO0FBQ3JFLFVBQUksU0FBUyxLQUFLLEdBQUcsZUFBZSxNQUFNLEdBQUcsZ0JBQWdCO0FBQzdELFVBQUk7QUFDRixpQkFBVSxHQUFXLFNBQVM7QUFBQSxNQUNoQyxTQUFTLEdBQUc7QUFBQSxNQUFDO0FBQ2IsWUFBTSxVQUFVLFNBQVMsSUFBSSxRQUFRLE1BQU0sUUFBUSxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBRWpFLGFBQU87QUFBQSxRQUNMLFFBQVE7QUFBQSxRQUNSO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFFBQVEsR0FBRztBQUFBLFFBQ1g7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUyxHQUFHO0FBQ1YsY0FBUSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZDLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsT0FBTyxlQUFlLFlBQW9DO0FBQ3hELFFBQUk7QUFDRixZQUFNLEtBQUssWUFBWSxTQUFTLE9BQU8sT0FBTyxVQUFVLENBQUM7QUFDekQsWUFBTSxhQUFhLG9CQUFJLElBQXFCO0FBRTVDLGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxjQUFjLEtBQUs7QUFDeEMsY0FBTSxRQUFRLEdBQUcsU0FBUyxDQUFDO0FBQzNCLGNBQU0sY0FBYyxNQUFNO0FBRTFCLFlBQUksYUFBYTtBQUNmLHFCQUFXLENBQUMsUUFBUSxJQUFJLEtBQUssYUFBYTtBQUN4QyxnQkFBSSxDQUFDLE1BQU0sWUFBYTtBQUN4QixrQkFBTSxRQUFRLEtBQUssWUFBWSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxnQkFBSSxXQUFXO0FBRWYsZ0JBQUksTUFBTSxZQUFZO0FBQ3BCLHlCQUFXLE1BQU0sV0FBVyxLQUFLLENBQUMsTUFBTSxLQUFLLGFBQWEsRUFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDO0FBQUEsWUFDekU7QUFDQSxnQkFBSSxDQUFDLFlBQVksTUFBTSxjQUFjO0FBQ25DLHlCQUFXLE1BQU0sYUFBYSxLQUFLLENBQUMsTUFBVyxLQUFLLGFBQWEsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUFBLFlBQ3BGO0FBRUEsa0JBQU0sVUFBVSxXQUFXLElBQUksS0FBSyxLQUFLO0FBQ3pDLHVCQUFXLElBQUksT0FBTyxXQUFXLFFBQVE7QUFBQSxVQUMzQztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsYUFBTyxNQUFNLEtBQUssV0FBVyxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLE1BQU0sT0FBTyxFQUFFLGFBQWEsSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUM3RixTQUFTLEdBQUc7QUFDVixhQUFPLENBQUM7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFPLG9CQUNMLFFBQ0EsU0FDUTtBQUNSLFFBQUksQ0FBQyxVQUFVLE9BQU8sV0FBVyxHQUFHO0FBQ2xDLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSTtBQUNGLFlBQU0sSUFBSSxJQUFJLE9BQU8sTUFBTTtBQUMzQixZQUFNLGlCQUFpQixXQUFXO0FBQ2xDLFlBQU0sZ0JBQWdCLG1CQUFtQixhQUFhLG1CQUFtQjtBQUN6RSxZQUFNLE1BQU0sZ0JBQWdCLE9BQU87QUFDbkMsWUFBTSxnQkFBZ0IsZ0JBQWdCLGVBQWU7QUFHckQsVUFBSSxFQUFFLFdBQVcsUUFBUSxLQUFLLEVBQUUsU0FBUyxNQUFNLEtBQUssT0FBTyxXQUFXLElBQUk7QUFDeEUsY0FBTSxhQUFhLE9BQU8sTUFBTSxHQUFHLEVBQUU7QUFFckMsZUFBTyxRQUFRLGFBQWEsRUFBRSxPQUFPLEVBQUUsTUFBTSxPQUFPLE1BQU0sV0FBVyxDQUFRO0FBQUEsTUFDL0U7QUFHQSxVQUFJLEVBQUUsV0FBVyxNQUFNLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSTtBQUNwRSxjQUFNLGFBQWEsT0FBTyxNQUFNLEdBQUcsRUFBRTtBQUNyQyxlQUFPLFFBQVEsYUFBYSxFQUFFLE9BQU8sRUFBRSxNQUFNLE1BQU0sTUFBTSxXQUFXLENBQVE7QUFBQSxNQUM5RTtBQUdBLFVBQ0csRUFBRSxXQUFXLE1BQU0sS0FBSyxPQUFPLFdBQVcsTUFDMUMsRUFBRSxXQUFXLE1BQU0sS0FBSyxPQUFPLFdBQVcsSUFDM0M7QUFDQSxjQUFNLGlCQUFpQixPQUFPLE1BQU0sQ0FBQztBQUNyQyxjQUFNLFFBQVEsT0FBTyxRQUFRLGNBQWM7QUFDM0MsY0FBTSxRQUFRLENBQUM7QUFDZixlQUFPLE9BQU8sT0FBTyxLQUFLLEtBQUs7QUFBQSxNQUNqQztBQUdBLFVBQUksRUFBRSxVQUFVLEdBQUc7QUFDakIsY0FBTSxjQUFjLFNBQVMsRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQUU7QUFDOUMsWUFBSSxlQUFlLE1BQVEsZUFBZSxJQUFNO0FBRTlDLGdCQUFNLGlCQUFpQixjQUFjO0FBQ3JDLGdCQUFNLGlCQUFpQixPQUFPLE1BQU0sQ0FBQztBQUVyQyxnQkFBTSxRQUFRLFFBQVEsUUFBUSxjQUFjO0FBQzVDLGdCQUFNLFFBQVEsY0FBYztBQUM1QixpQkFBTyxRQUFRLE9BQU8sS0FBSyxLQUFLO0FBQUEsUUFDbEM7QUFBQSxNQUNGO0FBR0EsYUFBTztBQUFBLElBQ1QsU0FBUyxHQUFHO0FBQ1YsY0FBUSxLQUFLLDhCQUE4QixHQUFHLElBQUksT0FBTyxNQUFNLENBQUM7QUFFaEUsWUFBTSxJQUFJLElBQUksT0FBTyxNQUFNO0FBQzNCLFVBQUksRUFBRSxXQUFXLE1BQU0sS0FBSyxFQUFFLFdBQVcsTUFBTSxLQUFLLEVBQUUsV0FBVyxJQUFJLEVBQUcsUUFBTyxFQUFFLE1BQU0sQ0FBQztBQUN4RixVQUFJLEVBQUUsV0FBVyxRQUFRLEVBQUcsUUFBTyxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQ2hELFVBQUksRUFBRSxXQUFXLE1BQU0sRUFBRyxRQUFPLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDOUMsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQSxPQUFlLGFBQWEsSUFBZ0IsSUFBeUI7QUFDbkUsUUFBSSxJQUFJLE9BQU8sRUFBRSxNQUFNLElBQUksT0FBTyxFQUFFLEVBQUcsUUFBTztBQUM5QyxRQUFJO0FBQ0YsWUFBTSxPQUFPLENBQUMsTUFDWixFQUFFLFdBQVcsS0FBSyxFQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUUsV0FBVyxLQUFLLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUNwRSxhQUFPLElBQUksT0FBTyxLQUFLLEVBQUUsQ0FBQyxNQUFNLElBQUksT0FBTyxLQUFLLEVBQUUsQ0FBQztBQUFBLElBQ3JELFNBQVMsR0FBRztBQUNWLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE9BQU8sV0FBVyxZQUEwRDtBQUMxRSxRQUFJO0FBQ0YsWUFBTSxLQUFLLFlBQVksU0FBUyxLQUFLLE9BQU8sVUFBVSxDQUFDO0FBQ3ZELFNBQUcsU0FBUztBQUNaLGFBQU8sRUFBRSxLQUFLLElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxHQUFHLE1BQU0sR0FBRyxHQUFHO0FBQUEsSUFDdEQsU0FBUyxHQUFHO0FBQ1YsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxPQUFPLFFBQVEsWUFBeUM7QUFDdEQsUUFBSTtBQUNGLFlBQU0sWUFBWSxLQUFLLE9BQU8sVUFBVTtBQUN4QyxZQUFNLEtBQUssWUFBWSxTQUFTLFdBQVcsRUFBRSxjQUFjLEtBQUssQ0FBQztBQUVqRSxZQUFNLGVBQWUsb0JBQUksSUFBWTtBQUNyQyxVQUFJLGFBQWEsR0FDZixjQUFjLEdBQ2QsZUFBZTtBQUVqQixlQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsY0FBYyxLQUFLO0FBQ3hDLGNBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUMzQixZQUFJLE1BQU0sWUFBYSxlQUFjLE9BQU8sTUFBTSxZQUFZLE1BQU07QUFDcEUsWUFBSSxNQUFNLGlCQUFpQjtBQUN6QixxQkFBVyxDQUFDLEVBQUUsSUFBSSxLQUFLLE1BQU0saUJBQTBCO0FBQ3JELGdCQUFJLE1BQU0sWUFBYSxjQUFhLElBQUksS0FBSyxZQUFZLFNBQVMsRUFBRSxDQUFDO0FBQ3JFLGdCQUFJLE1BQU0sTUFBTTtBQUNkLG9CQUFNLFdBQVcsS0FBSyxLQUFLLENBQUM7QUFDNUIsa0JBQUksYUFBYSxXQUFZO0FBQzdCLGtCQUFJLGFBQWEsV0FBWTtBQUFBLFlBQy9CO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsZUFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLGVBQWUsSUFBSyxnQkFBZSxPQUFPLEdBQUcsVUFBVSxDQUFDLEVBQUUsTUFBTTtBQUV2RixZQUFNLE1BQU0sYUFBYSxJQUFJLGFBQWEsY0FBYztBQUV4RCxhQUFPO0FBQUEsUUFDTCxPQUFPO0FBQUEsUUFDUCxhQUFhLGFBQWEsUUFBUTtBQUFBLFFBQ2xDLFdBQVcsY0FBYztBQUFBLFFBQ3pCLGVBQWU7QUFBQSxRQUNmLGFBQWEsR0FBRztBQUFBLFFBQ2hCLGlCQUFpQixlQUFlLElBQUksWUFBWTtBQUFBLE1BQ2xEO0FBQUEsSUFDRixTQUFTLEdBQUc7QUFDVixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRjs7O0FDemJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7OztBQ0FBLFNBQVMsZUFBMkI7QUFDcEMsU0FBUyxjQUFjO0FBT2hCLElBQU0sZUFBTixNQUFtQjtBQUFBO0FBQUEsRUFFaEIsZ0JBQWdCLElBQUksUUFBbUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVF4QyxTQUFTLE1BQXFCLFNBQXFCO0FBQ3hELFNBQUssY0FBYyxLQUFLLEVBQUUsTUFBTSxRQUFRLENBQUM7QUFBQSxFQUMzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9PLEdBQUcsV0FBaUQ7QUFDekQsV0FBTyxLQUFLLGNBQWMsYUFBYSxFQUFFLEtBQUssT0FBTyxDQUFDLFVBQVUsTUFBTSxTQUFTLFNBQVMsQ0FBQztBQUFBLEVBQzNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT08sUUFBK0I7QUFDcEMsV0FBTyxLQUFLLGNBQWMsYUFBYTtBQUFBLEVBQ3pDO0FBQ0Y7OztBQ3BDQSxTQUFTLGVBQUFBLG9CQUFtQjtBQU9yQixJQUFNLGNBQU4sTUFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBZXZCLFlBQW9CQyxTQUEwQjtBQUExQixrQkFBQUE7QUFBQSxFQUEyQjtBQUFBLEVBQTNCO0FBQUE7QUFBQSxFQWJaLEtBQXVCO0FBQUE7QUFBQSxFQUV4QixTQUFTLElBQUksYUFBYTtBQUFBO0FBQUEsRUFHekIsZ0JBQStCO0FBQUE7QUFBQSxFQUVoQyxzQkFBc0Isb0JBQUksSUFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWTlDLE9BQU8sS0FBb0I7QUFDaEMsU0FBSyxnQkFBZ0I7QUFBQSxFQUN2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9PLFFBQVEsS0FBbUI7QUFDaEMsU0FBSyxXQUFXLElBQUk7QUFDcEIsU0FBSyxLQUFLLElBQUksVUFBVSxHQUFHO0FBRTNCLFNBQUssR0FBRyxTQUFTLE1BQU07QUFDckIsV0FBSyxPQUFPLFNBQVMsZ0JBQWdCO0FBQUEsSUFDdkM7QUFDQSxTQUFLLEdBQUcsVUFBVSxDQUFDLE1BQU07QUFDdkIsV0FBSyxPQUFPLFNBQVMscUJBQXFCLEVBQUUsTUFBTSxFQUFFLE1BQU0sUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUU1RSxVQUFJLEVBQUUsU0FBUyxNQUFNO0FBQ25CLGFBQUssT0FBTyxTQUFTLGtCQUFrQixFQUFFLE1BQU0sb0JBQW9CLGFBQWEsUUFBUSxDQUFDO0FBQUEsTUFDM0YsV0FBVyxFQUFFLFNBQVMsTUFBTTtBQUMxQixhQUFLLE9BQU8sU0FBUyxrQkFBa0IsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLE1BQzlELFdBQVcsRUFBRSxTQUFTLE1BQU07QUFDMUIsYUFBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUFBLE1BQ2xFLFdBQVcsRUFBRSxTQUFTLE1BQU07QUFDMUIsYUFBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFBQSxNQUM5RDtBQUFBLElBQ0Y7QUFDQSxTQUFLLEdBQUcsVUFBVSxDQUFDLE1BQU0sS0FBSyxPQUFPLFNBQVMsU0FBUyxDQUFDO0FBRXhELFNBQUssR0FBRyxZQUFZLENBQU8sVUFBVTtBQUNuQyxVQUFJO0FBQ0YsY0FBTSxNQUFNLEtBQUssTUFBTSxNQUFNLElBQUk7QUFDakMsY0FBTSxLQUFLLGFBQWEsR0FBRztBQUFBLE1BQzdCLFNBQVMsR0FBRztBQUNWLGdCQUFRLE1BQU0sb0NBQW9DLENBQUM7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBVWEsU0FBUyxXQUFtQixRQUFnQixLQUFhLFNBQWlCO0FBQUE7QUFDckYsVUFBSSxXQUFXLElBQUksS0FBSztBQUV4QixVQUFJLFNBQVMsU0FBUyxHQUFHLEdBQUc7QUFDMUIsWUFBSTtBQUNGLHFCQUFXLG1CQUFtQixRQUFRO0FBQUEsUUFDeEMsU0FBUyxHQUFHO0FBQUEsUUFBQztBQUFBLE1BQ2Y7QUFFQSxXQUFLLE9BQU8sUUFBUTtBQUVwQixZQUFNLFdBQVcsV0FBVyxNQUFNLEtBQUssT0FBTyxVQUFVLFFBQVEsUUFBUSxJQUFJO0FBQzVFLFlBQU0sTUFBTSxHQUFHLFNBQVMsYUFBYSxNQUFNLGdCQUFnQixPQUFPLFNBQVMsUUFBUTtBQUNuRixXQUFLLFFBQVEsR0FBRztBQUFBLElBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTU8sV0FBVyxpQkFBaUIsT0FBYTtBQUM5QyxRQUFJLEtBQUssSUFBSTtBQUNYLFVBQUksZ0JBQWdCO0FBQ2xCLGFBQUssR0FBRyxVQUFVO0FBQ2xCLGFBQUssR0FBRyxVQUFVO0FBQ2xCLGFBQUssR0FBRyxZQUFZO0FBQ3BCLGFBQUssR0FBRyxTQUFTO0FBQUEsTUFDbkI7QUFDQSxXQUFLLEdBQUcsTUFBTTtBQUNkLFdBQUssS0FBSztBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRTyxLQUFLLE1BQWMsVUFBZSxDQUFDLEdBQVM7QUFDakQsUUFBSSxLQUFLLE1BQU0sS0FBSyxHQUFHLGVBQWUsVUFBVSxNQUFNO0FBQ3BELFdBQUssR0FBRyxLQUFLLEtBQUssVUFBVSxpQkFBRSxRQUFTLFFBQVMsQ0FBQztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9jLGFBQWEsS0FBVTtBQUFBO0FBQ25DLFVBQUksQ0FBQyxLQUFLLGtCQUFrQixJQUFJLGlCQUFpQixJQUFJLFNBQVMscUJBQXFCO0FBQ2pGLGFBQUssT0FBTyxTQUFTLG9CQUFvQix3QkFBd0I7QUFDakU7QUFBQSxNQUNGO0FBRUEsY0FBUSxJQUFJLE1BQU07QUFBQSxRQUNoQixLQUFLO0FBQ0gsZUFBSyxPQUFPLFNBQVMscUJBQXFCLElBQUksU0FBUztBQUN2RDtBQUFBLFFBQ0YsS0FBSztBQUNILGdCQUFNLFdBQVcsTUFBTSxLQUFLLGlCQUFpQixHQUFHO0FBQ2hELGNBQUksU0FBVSxNQUFLLE9BQU8sU0FBUyx3QkFBd0IsUUFBUTtBQUNuRTtBQUFBLFFBQ0YsS0FBSztBQUNILGdCQUFNLGNBQWMsTUFBTSxLQUFLLGtCQUFrQixHQUFHO0FBQ3BELGNBQUksWUFBYSxNQUFLLE9BQU8sU0FBUyx5QkFBeUIsV0FBVztBQUMxRTtBQUFBLFFBQ0YsS0FBSztBQUNILGVBQUssT0FBTyxTQUFTLG9CQUFvQixNQUFNLEtBQUssY0FBYyxJQUFJLFlBQVksQ0FBQztBQUNuRjtBQUFBLFFBQ0YsS0FBSztBQUNILGNBQUksSUFBSSxpQkFBaUIsS0FBSyxlQUFlO0FBQzNDLGdCQUFJO0FBQ0Ysb0JBQU0sV0FBVyxNQUFNLEtBQUssT0FBTyxRQUFRLElBQUksZUFBZSxLQUFLLGFBQWE7QUFDaEYsbUJBQUssT0FBTyxTQUFTLDBCQUEwQixRQUFRO0FBQUEsWUFDekQsU0FBUyxHQUFHO0FBQ1Ysc0JBQVEsTUFBTSxzQ0FBc0MsQ0FBQztBQUFBLFlBQ3ZEO0FBQUEsVUFDRjtBQUNBO0FBQUEsUUFDRixLQUFLO0FBQ0gsZUFBSyxPQUFPO0FBQUEsWUFDVjtBQUFBLFlBQ0EsTUFBTSxLQUFLLGdCQUFnQixJQUFJLFlBQVksQ0FBQyxDQUFDO0FBQUEsVUFDL0M7QUFDQTtBQUFBLFFBQ0YsS0FBSztBQUNILGVBQUssT0FBTyxTQUFTLHlCQUF5QjtBQUFBLFlBQzVDLE9BQU8sSUFBSTtBQUFBLFlBQ1gsVUFBVSxNQUFNLEtBQUssZ0JBQWdCLElBQUksUUFBUTtBQUFBLFVBQ25ELENBQUM7QUFDRDtBQUFBLFFBQ0YsS0FBSztBQUNILGVBQUssT0FBTyxTQUFTLGVBQWUsSUFBSSxJQUFJO0FBQzVDO0FBQUEsUUFDRixLQUFLO0FBQ0gsZUFBSyxPQUFPLFNBQVMsYUFBYTtBQUNsQztBQUFBLFFBQ0YsS0FBSztBQUNILGNBQUksSUFBSSxzQkFBc0IsS0FBSyxlQUFlO0FBQ2hELGdCQUFJO0FBQ0Ysb0JBQU0sT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLElBQUksb0JBQW9CLEtBQUssYUFBYTtBQUNqRixtQkFBSyxPQUFPLFNBQVMsdUJBQXVCLEtBQUssTUFBTSxJQUFJLENBQUM7QUFBQSxZQUM5RCxTQUFTLEdBQUc7QUFDVixzQkFBUSxNQUFNLHNDQUFzQyxDQUFDO0FBQUEsWUFDdkQ7QUFBQSxVQUNGO0FBQ0E7QUFBQSxRQUNGLEtBQUs7QUFDSCxlQUFLLE9BQU87QUFBQSxZQUNWO0FBQUEsWUFDQSxNQUFNLEtBQUssb0JBQW9CLElBQUksWUFBWTtBQUFBLFVBQ2pEO0FBQ0E7QUFBQSxRQUNGLEtBQUs7QUFDSCxlQUFLLE9BQU8sU0FBUyxnQkFBZ0IsR0FBRztBQUN4QztBQUFBLFFBQ0YsS0FBSztBQUNILGNBQUksSUFBSSx1QkFBdUIsSUFBSSxzQkFBc0IsS0FBSyxlQUFlO0FBQzNFLGdCQUFJO0FBQ0Ysb0JBQU0sYUFBYSxNQUFNLEtBQUssT0FBTztBQUFBLGdCQUNuQyxJQUFJO0FBQUEsZ0JBQ0osS0FBSztBQUFBLGNBQ1A7QUFDQSxvQkFBTSxZQUFZLE1BQU0sS0FBSyxPQUFPLFFBQVEsSUFBSSxvQkFBb0IsS0FBSyxhQUFhO0FBQ3RGLG1CQUFLLE9BQU8sU0FBUywwQkFBMEIsRUFBRSxZQUFZLFVBQVUsQ0FBQztBQUFBLFlBQzFFLFNBQVMsR0FBRztBQUNWLHNCQUFRLE1BQU0scUNBQXFDLENBQUM7QUFBQSxZQUN0RDtBQUFBLFVBQ0Y7QUFDQTtBQUFBLFFBQ0YsS0FBSztBQUNILGVBQUssT0FBTyxTQUFTLGtCQUFrQixFQUFFLE1BQU0sU0FBUyxDQUFDO0FBQ3pEO0FBQUEsUUFDRixLQUFLO0FBQ0gsZUFBSyxPQUFPLFNBQVMsa0JBQWtCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDNUQ7QUFBQSxRQUNGLEtBQUs7QUFDSCxlQUFLLE9BQU8sU0FBUyxrQkFBa0I7QUFBQSxZQUNyQyxNQUFNO0FBQUEsWUFDTixhQUFhLElBQUk7QUFBQSxVQUNuQixDQUFDO0FBQ0Q7QUFBQSxRQUNGO0FBQ0UsZUFBSyxPQUFPLFNBQVMsZUFBZSxHQUFHO0FBQUEsTUFDM0M7QUFBQSxJQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPYyxpQkFBaUIsS0FBK0I7QUFBQTtBQUM1RCxVQUFJLGFBQWE7QUFDakIsVUFBSTtBQUNGLHFCQUFhLElBQUksZ0JBQ2IsTUFBTSxLQUFLLE9BQU8sUUFBUSxJQUFJLGVBQWUsS0FBSyxhQUFjLElBQ2hFLElBQUksUUFBUTtBQUFBLE1BQ2xCLFNBQVMsR0FBRztBQUNWLGFBQUssT0FBTyxTQUFTLG9CQUFvQixrQ0FBa0M7QUFDM0UsZUFBTztBQUFBLE1BQ1Q7QUFFQSxtQkFBYSxVQUFVLFVBQVUsVUFBVTtBQUMzQyxZQUFNLG1CQUE2QixDQUFDO0FBRXBDLFVBQUksSUFBSSxZQUFZLFFBQVE7QUFDMUIsbUJBQVcsT0FBTyxJQUFJLFlBQVk7QUFDaEMsY0FBSTtBQUNGLGtCQUFNLFlBQVksS0FBSyxpQkFBaUI7QUFDeEMsa0JBQU0sTUFBTSxNQUFNLEtBQUssT0FBTyxRQUFRLFdBQVcsS0FBSyxhQUFjO0FBQ3BFLDZCQUFpQixLQUFLLFVBQVUsVUFBVSxHQUFHLENBQUM7QUFBQSxVQUNoRCxTQUFTLEdBQUc7QUFDVixnQkFBSSxPQUFPLFFBQVEsU0FBVSxrQkFBaUIsS0FBSyxVQUFVLFVBQVUsR0FBRyxDQUFDO0FBQUEsVUFDN0U7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUksYUFBYTtBQUNqQixpQkFBVyxXQUFXLGtCQUFrQjtBQUN0QyxxQkFBYSxVQUFVLE1BQU0sWUFBWSxPQUFPO0FBQUEsTUFDbEQ7QUFFQSxVQUFJLFlBQVk7QUFDZCxjQUFNLEtBQUssd0JBQXdCLFVBQVU7QUFBQSxNQUMvQztBQUVBLFlBQU0sa0JBQWtCLE1BQU0sS0FBSyxjQUFjLElBQUksZ0JBQWdCLENBQUMsQ0FBQztBQUN2RSxZQUFNLGVBQWUsTUFBTSxLQUFLLGdCQUFnQixJQUFJLFlBQVksQ0FBQyxDQUFDO0FBQ2xFLFlBQU0sd0JBQXdCLE1BQU0sS0FBSyxvQkFBb0IsSUFBSSxnQkFBZ0IsQ0FBQyxDQUFDO0FBRW5GLFVBQUkscUJBQStCLENBQUM7QUFDcEMsVUFBSSxJQUFJLGFBQWEsT0FBTyxJQUFJLGNBQWMsVUFBVTtBQUN0RCxZQUFJO0FBQ0YsZ0JBQU0sT0FBTyxNQUFNLEtBQUssT0FBTyxRQUFRLElBQUksV0FBVyxLQUFLLGFBQWM7QUFDekUsK0JBQXFCLEtBQUssTUFBTSxJQUFJO0FBQUEsUUFDdEMsU0FBUyxHQUFHO0FBQ1Ysa0JBQVEsTUFBTSw0Q0FBNEM7QUFBQSxRQUM1RDtBQUFBLE1BQ0YsV0FBVyxNQUFNLFFBQVEsSUFBSSxTQUFTLEdBQUc7QUFDdkMsNkJBQXFCLElBQUk7QUFBQSxNQUMzQjtBQUVBLFVBQUksb0JBQW9CO0FBQ3hCLFVBQUksSUFBSSxZQUFZLEtBQUssZUFBZTtBQUN0QyxZQUFJLElBQUksU0FBUyxVQUFVLElBQUk7QUFDN0IsY0FBSTtBQUNGLGdDQUFvQixNQUFNLEtBQUssT0FBTyxRQUFRLElBQUksVUFBVSxLQUFLLGFBQWE7QUFBQSxVQUNoRixTQUFTLEdBQUc7QUFDVixnQ0FBb0IsSUFBSTtBQUFBLFVBQzFCO0FBQUEsUUFDRixPQUFPO0FBQ0wsOEJBQW9CLElBQUk7QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLGFBQWEsSUFBSTtBQUNyQixVQUFJLFlBQVksSUFBSTtBQUNwQixVQUFJLElBQUksdUJBQXVCLElBQUksc0JBQXNCLEtBQUssZUFBZTtBQUMzRSxZQUFJO0FBQ0YsdUJBQWEsTUFBTSxLQUFLLE9BQU8sUUFBUSxJQUFJLHFCQUFxQixLQUFLLGFBQWE7QUFDbEYsc0JBQVksTUFBTSxLQUFLLE9BQU8sUUFBUSxJQUFJLG9CQUFvQixLQUFLLGFBQWE7QUFBQSxRQUNsRixTQUFTLEdBQUc7QUFDVixrQkFBUSxNQUFNLGtEQUFrRCxDQUFDO0FBQUEsUUFDbkU7QUFBQSxNQUNGO0FBRUEsYUFBTyxpQ0FDRixNQURFO0FBQUEsUUFFTCxNQUFNO0FBQUEsUUFDTixZQUFZO0FBQUEsUUFDWixjQUFjLE9BQU8sS0FBSyxlQUFlLEVBQUUsU0FBUyxJQUFJLGtCQUFrQixJQUFJO0FBQUEsUUFDOUUsVUFBVTtBQUFBLFFBQ1YsV0FBVztBQUFBLFFBQ1gsY0FDRSxPQUFPLEtBQUsscUJBQXFCLEVBQUUsU0FBUyxJQUN4Qyx3QkFDQSxJQUFJLGdCQUFnQixDQUFDO0FBQUEsUUFDM0IsVUFBVTtBQUFBLFFBQ1Y7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9jLGtCQUFrQixLQUFVO0FBQUE7QUFDeEMsVUFBSSxDQUFDLElBQUksTUFBTSxjQUFlLFFBQU87QUFDckMsWUFBTSxZQUFZLE1BQU0sS0FBSyxPQUFPLFFBQVEsSUFBSSxLQUFLLGVBQWUsS0FBSyxhQUFjO0FBQ3ZGLFlBQU0sa0JBQWtCLEtBQUssb0JBQW9CLElBQUksSUFBSSxXQUFXLEtBQUssSUFBSTtBQUU3RSxhQUFPO0FBQUEsUUFDTCxlQUFlLFVBQVUsVUFBVSxTQUFTO0FBQUEsUUFDNUMsYUFBYTtBQUFBLFFBQ2IsV0FBVyxJQUFJO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTWMsd0JBQXdCLFVBQWtCO0FBQUE7QUFDdEQsVUFBSSxDQUFDLEtBQUssY0FBZTtBQUN6QixVQUFJO0FBQ0YsY0FBTSxRQUFRLFVBQVUsT0FBTyxRQUFRO0FBQ3ZDLGNBQU0sS0FBS0MsYUFBWSxTQUFTLEtBQUs7QUFDckMsaUJBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxjQUFjLEtBQUs7QUFDeEMsZ0JBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUMzQixjQUFJLE1BQU0saUJBQWlCO0FBQ3pCLHVCQUFXLENBQUMsRUFBRSxJQUFJLEtBQUssTUFBTSxpQkFBaUI7QUFDNUMsb0JBQU0sS0FBSyxLQUFLLFlBQVksU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDeEQsb0JBQU0sVUFBVSxNQUFNLEtBQUssT0FBTyxVQUFVLElBQUksS0FBSyxhQUFhO0FBQ2xFLG1CQUFLLG9CQUFvQixJQUFJLFNBQVMsRUFBRTtBQUN4QyxtQkFBSyxvQkFBb0IsSUFBSSxJQUFJLEVBQUU7QUFBQSxZQUNyQztBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTLEdBQUc7QUFDVixnQkFBUSxNQUFNLHFDQUFxQztBQUFBLE1BQ3JEO0FBQUEsSUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1jLGdCQUFnQixNQUE2QjtBQUFBO0FBQ3pELFVBQUksQ0FBQyxLQUFLLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxNQUFNLFFBQVEsSUFBSSxFQUFHLFFBQU8sQ0FBQztBQUNsRSxZQUFNLGVBQWUsQ0FBQztBQUV0QixpQkFBVyxRQUFRLE1BQU07QUFDdkIsWUFBSSxDQUFDLEtBQU07QUFDWCxjQUFNLGdCQUFnQixPQUFPLFNBQVMsV0FBVyxPQUFPLEtBQUs7QUFFN0QsWUFBSSxlQUFlO0FBQ2pCLGNBQUk7QUFDRixrQkFBTSxNQUFNLE1BQU0sS0FBSyxPQUFPLFFBQVEsZUFBZSxLQUFLLGFBQWE7QUFDdkUsa0JBQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztBQUM1QixnQkFBSSxNQUFPLGNBQWEsS0FBSyxLQUFLO0FBQUEsVUFDcEMsU0FBUyxHQUFHO0FBQ1YseUJBQWEsS0FBSztBQUFBLGNBQ2hCLFdBQVc7QUFBQSxjQUNYLE9BQU87QUFBQSxjQUNQLE1BQU07QUFBQSxZQUNSLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRixXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDbEMsdUJBQWEsS0FBSyxJQUFJO0FBQUEsUUFDeEI7QUFBQSxNQUNGO0FBQ0EsYUFBTyxhQUNKLE9BQU8sQ0FBQyxNQUFNLE1BQU0sSUFBSSxFQUN4QixLQUFLLENBQUMsR0FBRyxPQUFPLEVBQUUsYUFBYSxNQUFNLEVBQUUsYUFBYSxFQUFFO0FBQUEsSUFDM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNYyxjQUNaLGlCQUNpQztBQUFBO0FBQ2pDLFlBQU0sa0JBQTBDLENBQUM7QUFDakQsVUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssY0FBZSxRQUFPO0FBRXBELGlCQUFXLENBQUMsV0FBVyxjQUFjLEtBQUssT0FBTyxRQUFRLGVBQWUsR0FBRztBQUN6RSxjQUFNLFNBQVMsS0FBSyxvQkFBb0IsSUFBSSxTQUFTLEtBQUs7QUFDMUQsWUFBSTtBQUNGLDBCQUFnQixNQUFNLElBQ3BCLGVBQWUsVUFBVSxLQUNyQixNQUFNLEtBQUssT0FBTyxRQUFRLGdCQUFnQixLQUFLLGFBQWEsSUFDNUQ7QUFBQSxRQUNSLFNBQVMsR0FBRztBQUNWLDBCQUFnQixNQUFNLElBQUk7QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1jLGdCQUFnQixVQUFpQjtBQUFBO0FBQzdDLFVBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxjQUFlLFFBQU8sQ0FBQztBQUM5QyxhQUFPLE1BQU0sUUFBUTtBQUFBLFFBQ25CLFNBQVMsSUFBSSxDQUFPLE1BQVc7QUFDN0IsY0FBSSxZQUFZO0FBQ2hCLGNBQUksRUFBRSxzQkFBc0I7QUFDMUIsZ0JBQUk7QUFDRiwwQkFBWSxNQUFNLEtBQUssT0FBTyxRQUFRLEVBQUUsc0JBQXNCLEtBQUssYUFBYztBQUFBLFlBQ25GLFNBQVMsR0FBRztBQUNWLDBCQUFZO0FBQUEsWUFDZDtBQUFBLFVBQ0Y7QUFDQSxpQkFBTyxFQUFFLElBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxNQUFNLGFBQWEsVUFBVTtBQUFBLFFBQzFELEVBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1jLG9CQUFvQixjQUFtQjtBQUFBO0FBQ25ELFlBQU0sV0FBZ0MsQ0FBQztBQUN2QyxVQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxjQUFlLFFBQU87QUFDakQsaUJBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxPQUFPLFFBQVEsWUFBWSxHQUFHO0FBQ3ZELFlBQUksWUFBWTtBQUNoQixjQUFNLFNBQVM7QUFDZixZQUFJLE9BQU8sc0JBQXNCO0FBQy9CLGNBQUk7QUFDRix3QkFBWSxNQUFNLEtBQUssT0FBTyxRQUFRLE9BQU8sc0JBQXNCLEtBQUssYUFBYTtBQUFBLFVBQ3ZGLFNBQVMsR0FBRztBQUFBLFVBQUM7QUFBQSxRQUNmO0FBQ0EsaUJBQVMsR0FBRyxJQUFJLGlDQUFLLFNBQUwsRUFBYSxhQUFhLFVBQVU7QUFBQSxNQUN0RDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFhLG9CQUFvQixPQUFlLFFBQWdCLE1BQStCO0FBQUE7QUFDN0YsVUFBSSxDQUFDLEtBQUssY0FBZSxRQUFPO0FBQ2hDLFlBQU0sV0FBVyxFQUFFLFdBQVcsS0FBSyxJQUFJLEdBQUcsT0FBTyxRQUFRLEtBQUs7QUFDOUQsYUFBTyxNQUFNLEtBQUssT0FBTyxRQUFRLEtBQUssVUFBVSxRQUFRLEdBQUcsS0FBSyxhQUFhO0FBQUEsSUFDL0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2EsVUFBVSxPQUFlLFFBQWdCLE1BQWM7QUFBQTtBQUNsRSxZQUFNLG1CQUFtQixNQUFNLEtBQUssb0JBQW9CLE9BQU8sUUFBUSxJQUFJO0FBQzNFLFdBQUssS0FBSyxjQUFjLEVBQUUsaUJBQWlCLENBQUM7QUFBQSxJQUM5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRYSxnQkFBZ0IsbUJBQTJCLGFBQXFCLE1BQWM7QUFBQTtBQUN6RixVQUFJLENBQUMsS0FBSyxjQUFlO0FBQ3pCLFlBQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPLFVBQVUsYUFBYSxLQUFLLGFBQWE7QUFDdEYsWUFBTSxnQkFBZ0IsTUFBTSxLQUFLLE9BQU8sUUFBUSxtQkFBbUIsS0FBSyxhQUFhO0FBQ3JGLFlBQU0sbUJBQW1CLE1BQU0sS0FBSztBQUFBLFFBQ2xDO0FBQUEsUUFDQSxXQUFXLFdBQVc7QUFBQSxRQUN0QjtBQUFBLE1BQ0Y7QUFFQSxXQUFLLG9CQUFvQixJQUFJLG9CQUFvQixXQUFXO0FBQzVELFdBQUssb0JBQW9CLElBQUksYUFBYSxXQUFXO0FBRXJELFdBQUssS0FBSyxrQkFBa0I7QUFBQSxRQUMxQixhQUFhO0FBQUEsUUFDYixNQUFNLEVBQUUsY0FBYztBQUFBLFFBQ3RCO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1PLGlCQUFpQixhQUFxQjtBQUMzQyxRQUFJLFlBQWEsTUFBSyxLQUFLLFFBQVEsRUFBRSxPQUFPLFlBQVksS0FBSyxFQUFFLENBQUM7QUFBQSxFQUNsRTtBQUFBO0FBQUEsRUFHTyxZQUFZO0FBQ2pCLFNBQUssS0FBSyxZQUFZO0FBQUEsRUFDeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTWEscUJBQXFCLFdBQTBCO0FBQUE7QUFDMUQsVUFBSSxhQUFhLEtBQUssTUFBTSxLQUFLLEdBQUcsZUFBZSxVQUFVLE1BQU07QUFDakUsWUFBSTtBQUNGLGdCQUFNLG1CQUFtQixNQUFNLEtBQUs7QUFBQSxZQUNsQztBQUFBLFlBQ0EsZUFBZSxTQUFTO0FBQUEsWUFDeEI7QUFBQSxVQUNGO0FBQ0EsZUFBSyxLQUFLLGNBQWMsRUFBRSxpQkFBaUIsQ0FBQztBQUFBLFFBQzlDLFNBQVMsR0FBRztBQUNWLGtCQUFRLE1BQU0sK0JBQStCO0FBQUEsUUFDL0M7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsTUFBTSxLQUFLLFdBQVcsR0FBRyxFQUFFO0FBQUEsSUFDeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNYSxXQUFXLFNBQWlCLE1BQWM7QUFBQTtBQUNyRCxVQUFJLENBQUMsS0FBSyxjQUFlO0FBQ3pCLFlBQU0sZ0JBQWdCLE1BQU0sS0FBSyxPQUFPLFFBQVEsU0FBUyxLQUFLLGFBQWE7QUFDM0UsWUFBTSxtQkFBbUIsTUFBTSxLQUFLO0FBQUEsUUFDbEM7QUFBQSxRQUNBLFlBQVksT0FBTztBQUFBLFFBQ25CO0FBQUEsTUFDRjtBQUNBLFdBQUssS0FBSyxlQUFlLEVBQUUsZUFBZSxpQkFBaUIsQ0FBQztBQUFBLElBQzlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPYSxrQkFBa0IsYUFBcUIsT0FBZSxNQUFjO0FBQUE7QUFDL0UsVUFBSSxDQUFDLEtBQUssY0FBZTtBQUN6QixZQUFNLFlBQVksU0FBUztBQUMzQixZQUFNLHFCQUFxQixNQUFNLEtBQUssT0FBTyxVQUFVLGFBQWEsS0FBSyxhQUFhO0FBQ3RGLFlBQU0saUJBQWlCLE1BQU0sS0FBSyxPQUFPLFFBQVEsV0FBVyxLQUFLLGFBQWE7QUFDOUUsWUFBTSxtQkFBbUIsTUFBTSxLQUFLO0FBQUEsUUFDbEM7QUFBQSxRQUNBLEdBQUcsU0FBUyxLQUFLLFdBQVc7QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFFQSxXQUFLLG9CQUFvQixJQUFJLG9CQUFvQixXQUFXO0FBQzVELFdBQUssS0FBSyxnQkFBZ0I7QUFBQSxRQUN4QixhQUFhO0FBQUEsUUFDYixPQUFPO0FBQUEsUUFDUDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNYSxlQUFlLE1BQWM7QUFBQTtBQUN4QyxVQUFJLENBQUMsS0FBSyxjQUFlO0FBQ3pCLFlBQU0sV0FBVyxLQUFLLEtBQUssRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUM1QyxVQUFJLFVBQVU7QUFDWixjQUFNLHVCQUF1QixNQUFNLEtBQUssT0FBTyxRQUFRLFVBQVUsS0FBSyxhQUFhO0FBQ25GLGFBQUssS0FBSyxvQkFBb0IsRUFBRSxxQkFBcUIsQ0FBQztBQUFBLE1BQ3hELE9BQU87QUFDTCxhQUFLLEtBQUssb0JBQW9CLEVBQUUsc0JBQXNCLEtBQUssQ0FBQztBQUFBLE1BQzlEO0FBQUEsSUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT2EsZ0JBQWdCLFNBQW1CLGNBQXNCLE1BQWM7QUFBQTtBQUNsRixVQUFJLENBQUMsS0FBSyxjQUFlO0FBQ3pCLFlBQU0scUJBQXFCLE1BQU0sS0FBSyxPQUFPO0FBQUEsUUFDM0MsS0FBSyxVQUFVLE9BQU87QUFBQSxRQUN0QixLQUFLO0FBQUEsTUFDUDtBQUNBLFlBQU0sbUJBQW1CLE1BQU0sS0FBSztBQUFBLFFBQ2xDO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQ0EsV0FBSyxLQUFLLG9CQUFvQixFQUFFLG9CQUFvQixpQkFBaUIsQ0FBQztBQUFBLElBQ3hFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTWEsV0FBVyxVQUFtQixNQUFjO0FBQUE7QUFDdkQsVUFBSSxDQUFDLEtBQUssY0FBZTtBQUN6QixZQUFNLGVBQWUsV0FBVyxnQ0FBZ0M7QUFDaEUsWUFBTSxtQkFBbUIsTUFBTSxLQUFLLG9CQUFvQixlQUFlLGNBQWMsSUFBSTtBQUN6RixXQUFLLEtBQUssZUFBZSxFQUFFLFVBQVUsaUJBQWlCLENBQUM7QUFBQSxJQUN6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT2Esc0JBQXNCLFlBQW9CLFdBQW1CLE1BQWM7QUFBQTtBQUN0RixVQUFJLENBQUMsS0FBSyxjQUFlO0FBQ3pCLFlBQU0sc0JBQXNCLE1BQU0sS0FBSyxPQUFPLFFBQVEsWUFBWSxLQUFLLGFBQWE7QUFDcEYsWUFBTSxxQkFBcUIsTUFBTSxLQUFLLE9BQU8sUUFBUSxXQUFXLEtBQUssYUFBYTtBQUNsRixZQUFNLG1CQUFtQixNQUFNLEtBQUs7QUFBQSxRQUNsQztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUNBLFdBQUssS0FBSyxnQkFBZ0IsRUFBRSxxQkFBcUIsb0JBQW9CLGlCQUFpQixDQUFDO0FBQUEsSUFDekY7QUFBQTtBQUNGOzs7QUNwa0JPLElBQU0saUJBQU4sTUFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUTFCLFlBQW9CLFFBQXNCO0FBQXRCO0FBQ2xCLFNBQUssT0FBTyxHQUFHLHNCQUFzQixFQUFFLFVBQVUsQ0FBQyxNQUFNLEtBQUssS0FBSyxFQUFFLE9BQU8sQ0FBQztBQUM1RSxTQUFLLE9BQU8sR0FBRyx1QkFBdUIsRUFBRSxVQUFVLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRSxPQUFPLENBQUM7QUFDOUUsU0FBSyxPQUFPLEdBQUcsY0FBYyxFQUFFLFVBQVUsQ0FBQyxNQUFNO0FBQzlDLFlBQU0sV0FBVyxPQUFPLEVBQUUsU0FBUyxhQUFhLFlBQVksRUFBRSxRQUFRLFdBQVcsRUFBRTtBQUNuRixXQUFLLGNBQWMsRUFBRSxTQUFTLENBQUM7QUFBQSxJQUNqQyxDQUFDO0FBQ0QsU0FBSyxPQUNGLEdBQUcsa0JBQWtCLEVBQ3JCLFVBQVUsQ0FBQyxNQUFNLEtBQUssY0FBYyxFQUFFLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUNuRSxTQUFLLE9BQ0YsR0FBRyx3QkFBd0IsRUFDM0IsVUFBVSxDQUFDLE1BQU0sS0FBSyxjQUFjLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQy9ELFNBQUssT0FDRixHQUFHLHNCQUFzQixFQUN6QixVQUFVLENBQUMsTUFBTSxLQUFLLGNBQWMsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDL0QsU0FBSyxPQUNGLEdBQUcscUJBQXFCLEVBQ3hCLFVBQVUsQ0FBQyxNQUFNLEtBQUssY0FBYyxFQUFFLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUNoRSxTQUFLLE9BQ0YsR0FBRyx3QkFBd0IsRUFDM0IsVUFBVSxDQUFDLE1BQU0sS0FBSyxjQUFjLEVBQUUsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQ25FLFNBQUssT0FDRixHQUFHLHVCQUF1QixFQUMxQixVQUFVLENBQUMsTUFBTSxLQUFLLGNBQWMsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRLE1BQU0sQ0FBQyxDQUFDO0FBQzNFLFNBQUssT0FBTyxHQUFHLHdCQUF3QixFQUFFO0FBQUEsTUFBVSxDQUFDLE1BQ2xELEtBQUssY0FBYztBQUFBLFFBQ2pCLFlBQVksRUFBRSxRQUFRO0FBQUEsUUFDdEIsV0FBVyxFQUFFLFFBQVE7QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFNBQUssT0FBTyxHQUFHLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBTTtBQUM5QyxZQUFNLEVBQUUsYUFBYSxNQUFNLElBQUksRUFBRTtBQUNqQyxXQUFLLGNBQWM7QUFBQSxRQUNqQixjQUFjLGlDQUNULEtBQUssT0FBTyxlQURIO0FBQUEsVUFFWixDQUFDLFdBQVcsR0FBRztBQUFBLFFBQ2pCO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBeENvQjtBQUFBO0FBQUEsRUFOWixRQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFEMUIsY0FBYyxjQUFrQztBQUN0RCxRQUFJLENBQUMsS0FBSyxNQUFPO0FBQ2pCLFNBQUssUUFBUSxrQ0FBSyxLQUFLLFFBQVU7QUFDakMsU0FBSyxPQUFPLFNBQVMsaUJBQWlCLEtBQUssS0FBSztBQUFBLEVBQ2xEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1PLFdBQTZCO0FBQ2xDLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPTyxLQUFLLFFBQWdCLGlCQUF5QjtBQUNuRCxTQUFLLFFBQVE7QUFBQSxNQUNYO0FBQUEsTUFDQSxNQUFNO0FBQUEsTUFDTixZQUFZLENBQUM7QUFBQSxNQUNiLGdCQUFnQjtBQUFBLE1BQ2hCLFdBQVcsS0FBSyxJQUFJO0FBQUEsTUFDcEIsV0FBVyxLQUFLLElBQUksSUFBSTtBQUFBLE1BQ3hCLFVBQVUsQ0FBQztBQUFBLE1BQ1gsY0FBYyxDQUFDO0FBQUEsTUFDZixVQUFVO0FBQUEsTUFDVixXQUFXLENBQUM7QUFBQSxNQUNaLGNBQWMsQ0FBQztBQUFBLE1BQ2YsVUFBVTtBQUFBLE1BQ1YsU0FBUztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsU0FBSyxPQUFPLFNBQVMsaUJBQWlCLEtBQUssS0FBSztBQUFBLEVBQ2xEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1RLEtBQUssTUFBVztBQUN0QixTQUFLLFFBQVEsa0NBQUssS0FBSyxRQUFVO0FBQ2pDLFNBQUssT0FBTyxTQUFTLGlCQUFpQixLQUFLLEtBQUs7QUFBQSxFQUNsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNTyxPQUFPLFNBQW9EO0FBQ2hFLFNBQUssUUFBUSxRQUFRLEtBQUssS0FBSztBQUMvQixRQUFJLEtBQUssT0FBTztBQUNkLFdBQUssT0FBTyxTQUFTLGlCQUFpQixLQUFLLEtBQUs7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTU8sSUFBSSxVQUE0QjtBQUNyQyxTQUFLLFFBQVE7QUFDYixRQUFJLFVBQVU7QUFDWixXQUFLLE9BQU8sU0FBUyxpQkFBaUIsUUFBUTtBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9RLE1BQU0sU0FBYztBQUMxQixRQUFJLENBQUMsS0FBSyxNQUFPO0FBQ2pCLFNBQUssUUFBUSxpQ0FDUixLQUFLLFFBREc7QUFBQSxNQUVYLE1BQU0sVUFBVSxNQUFNLEtBQUssTUFBTSxNQUFNLFFBQVEsYUFBYTtBQUFBLE1BQzVELFlBQVksQ0FBQyxHQUFHLEtBQUssTUFBTSxZQUFZLFFBQVEsYUFBYTtBQUFBLElBQzlEO0FBQ0EsU0FBSyxPQUFPLFNBQVMsaUJBQWlCLEtBQUssS0FBSztBQUFBLEVBQ2xEO0FBQ0Y7OztBQzNNQSxTQUFTLE1BQU0sY0FBYztBQXVDdEIsSUFBTSxjQUFOLE1BQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVd2QixPQUFhLHVCQUNYLFFBQ0EsZUFDQSxTQUNBLFdBQW1CLGlCQUNuQixrQkFBMEIsU0FDSTtBQUFBO0FBRTlCLFlBQU0sZ0JBQWdCLE1BQU0sT0FBTyxZQUFZO0FBQy9DLFlBQU0sU0FDSixPQUFPLFdBQVcsZUFBZSxPQUFPLGFBQ3BDLE9BQU8sV0FBVyxJQUNsQixLQUFLLGFBQWE7QUFDeEIsWUFBTSxjQUNKLE9BQU8sV0FBVyxlQUFlLE9BQU8sYUFDcEMsT0FBTyxXQUFXLElBQ2xCLEtBQUssYUFBYTtBQUd4QixZQUFNLGdCQUFnQixNQUFNLE9BQU8sUUFBUSxlQUFlLGFBQWE7QUFDdkUsWUFBTSxzQkFBc0IsTUFBTSxPQUFPLFFBQVEsYUFBYSxhQUFhO0FBQzNFLFlBQU0sb0JBQW9CLE1BQU0sT0FBTyxRQUFRLFVBQVUsYUFBYTtBQUN0RSxZQUFNLGVBQWUsTUFBTSxPQUFPLFVBQVUsUUFBUSxhQUFhO0FBRWpFLGFBQU87QUFBQSxRQUNMLFdBQVc7QUFBQSxVQUNUO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsUUFDQSxhQUFhO0FBQUEsVUFDWDtBQUFBLFVBQ0E7QUFBQSxVQUNBLGVBQWU7QUFBQSxVQUNmLFlBQVk7QUFBQSxVQUNaO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBV0EsT0FBZSxlQUF1QjtBQUNwQyxXQUFPLE9BQU87QUFBQSxFQUNoQjtBQUNGOzs7QUMxRk8sSUFBTSxjQUFOLE1BQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVF2QixPQUFPLHFCQUFxQixPQUFrQixJQUFlLFNBQWlDO0FBQzVGLFVBQU0sVUFBVTtBQUFBLE1BQ2Q7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUVBLFVBQU0sY0FBYyxRQUNqQixJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsV0FBVyxHQUFHLEVBQUUsU0FBUyxhQUFhLFdBQVcsRUFBRSxFQUNuRSxLQUFLLElBQUk7QUFFWixVQUFNLGtCQUFrQixNQUFNLGdCQUFnQixDQUFDO0FBQy9DLFVBQU0sZ0JBQWdCLE9BQU8sT0FBTyxlQUFlLEVBQ2hELElBQUksQ0FBQyxNQUFXO0FBQ2YsWUFBTSxPQUFPLEVBQUUsZUFBZTtBQUM5QixZQUFNLE9BQU8sRUFBRSxTQUFTLFVBQVUsZ0JBQWdCO0FBQ2xELGFBQU8sR0FBRyxJQUFJLEtBQUssSUFBSSxNQUFNLEVBQUUsRUFBRTtBQUFBLElBQ25DLENBQUMsRUFDQSxLQUFLLElBQUk7QUFFWixVQUFNLE1BQU07QUFBQSxPQUNWLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDdkIsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTSxhQUFhO0FBQUEsT0FDbEIsR0FBRyxTQUFTLEtBQVcsUUFBUSxDQUFDO0FBQUEsTUFDakMsR0FBRztBQUFBLE1BQ0gsR0FBRyxZQUFZLFVBQVU7QUFBQSxNQUN6QixHQUFHLFNBQVMsVUFBVTtBQUFBLE1BQ3RCLElBQUksV0FBVztBQUFBLE1BQ2YsSUFBSSxhQUFhO0FBQUEsTUFDakIsT0FBTyxhQUFhLG1CQUFtQjtBQUFBLElBQ3pDO0FBRUEsV0FBTyxRQUFRLEtBQUssR0FBRyxJQUFJLE9BQU8sSUFBSSxLQUFLLEdBQUc7QUFBQSxFQUNoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE9BQU8sbUJBQW1CLE9BQTBCO0FBQ2xELFVBQU0sT0FBTyxNQUFNLFlBQVksQ0FBQztBQUNoQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxVQUFVLEtBQ2IsSUFBSSxDQUFDLE1BQU07QUFDVixZQUFNLE9BQU8sSUFBSSxLQUFLLEVBQUUsU0FBUyxFQUFFLFlBQVk7QUFDL0MsWUFBTSxRQUFRLElBQUksRUFBRSxNQUFNLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFDN0MsWUFBTSxPQUFPLElBQUksRUFBRSxLQUFLLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFDM0MsWUFBTSxTQUFTLEtBQUssRUFBRSxVQUFVLElBQUksUUFBUSxNQUFNLElBQUksQ0FBQztBQUN2RCxhQUFPLEdBQUcsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUksTUFBTTtBQUFBLElBQzNDLENBQUMsRUFDQSxLQUFLLElBQUk7QUFDWixXQUFPLFlBQVk7QUFBQSxFQUNyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFPLGtCQUFrQixPQUFrQixJQUFlLFNBQWlDO0FBQ3pGLFVBQU0sYUFDSixpQ0FBaUMsS0FBSyxxQkFBcUIsT0FBTyxJQUFJLE9BQU87QUFDL0UsV0FBTyxVQUFVLFVBQVU7QUFBQSxFQUM3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZQSxPQUFhLGlCQUNYLEtBQ0EsT0FDQSxJQUNBLFNBQ0EsVUFDQSxTQUMyQztBQUFBO0FBQzNDLFVBQUksSUFBSTtBQUVSLFlBQU0saUJBQWlCLENBQUMsZ0JBQXdCO0FBQzlDLFlBQUksSUFBSSxjQUFjLEtBQUs7QUFDekIsY0FBSSxRQUFRO0FBQ1osY0FBSTtBQUFBLFFBQ047QUFBQSxNQUNGO0FBR0EsVUFBSSxjQUFjO0FBRWxCLFVBQUksU0FBUyxjQUFjO0FBQ3pCLHNCQUFjLFNBQVMsYUFBYTtBQUFBLE1BQ3RDO0FBRUEsWUFBTSxhQUFhLFNBQVMsY0FBYyxDQUFDLElBQUksS0FBSyxHQUFHO0FBRXZELFVBQUksV0FBVztBQUNmLFlBQU0sYUFBYTtBQUNuQixZQUFNLGNBQWMsSUFBSTtBQUd4QixVQUFJLFNBQVMsYUFBYTtBQUN4QixZQUFJO0FBQ0YsZ0JBQU0sV0FBVyxJQUFJLG1CQUFtQixRQUFRLFdBQVc7QUFDM0QsZ0JBQU0sWUFBYSxTQUFTLFFBQVEsYUFBYyxTQUFTO0FBRTNELGNBQUksU0FBUyxRQUFRLGFBQWEsT0FBTyxVQUFVLGFBQWEsV0FBVyxVQUFVO0FBRXJGLHNCQUFZLFlBQVk7QUFBQSxRQUMxQixTQUFTLEdBQUc7QUFDVixrQkFBUSxLQUFLLCtCQUErQixDQUFDO0FBQUEsUUFDL0M7QUFBQSxNQUNGO0FBRUEsVUFBSSxRQUFRLGFBQWEsTUFBTTtBQUMvQixVQUFJLFlBQVksRUFBRTtBQUNsQixVQUFJLGFBQWEsV0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDLENBQUM7QUFDNUQsVUFBSSxLQUFLLGFBQWEsVUFBVSxDQUFDO0FBRWpDLFVBQUksUUFBUSxhQUFhLFFBQVE7QUFDakMsVUFBSSxZQUFZLEVBQUU7QUFDbEIsVUFBSSxhQUFhLEdBQUc7QUFDcEIsVUFBSSxLQUFLLGFBQWEsSUFBSSxJQUFJLEVBQUU7QUFDaEMsV0FBSztBQUdMLFVBQUksYUFBYSxHQUFHO0FBQ3BCLFVBQUksYUFBYSxHQUFHO0FBQ3BCLFVBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQ3RCLFdBQUs7QUFLTCxVQUFJLFlBQVksTUFBTSxZQUFZLE1BQU0sU0FBUyxTQUFTLEdBQUc7QUFDM0QsdUJBQWUsRUFBRTtBQUNqQixjQUFNLFNBQVMsTUFBTSxLQUFLLHdCQUF3QixNQUFNLFVBQVUsUUFBUTtBQUUxRSxZQUFJLFlBQVksRUFBRTtBQUNsQixZQUFJLGFBQWEsV0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFDLENBQUM7QUFDNUQsWUFBSSxRQUFRLGFBQWEsTUFBTTtBQUMvQixZQUFJLEtBQUssZ0NBQWdDLElBQUksQ0FBQztBQUM5QyxhQUFLO0FBRUwsWUFBSSxZQUFZLENBQUM7QUFDakIsWUFBSSxhQUFhLEdBQUc7QUFDcEIsWUFBSSxRQUFRLGFBQWEsUUFBUTtBQUNqQyxZQUFJO0FBQUEsVUFDRjtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUNBLGFBQUs7QUFDTCxZQUFJLEtBQUsscUVBQXFFLElBQUksQ0FBQztBQUNuRixhQUFLO0FBRUwsWUFBSSxZQUFZLEVBQUU7QUFDbEIsWUFBSSxhQUFhLENBQUM7QUFDbEIsWUFBSSxRQUFRLFdBQVcsTUFBTTtBQUM3QixZQUFJLEtBQUssUUFBUSxJQUFJLENBQUM7QUFDdEIsYUFBSztBQUdMLFlBQUksYUFBYSxHQUFHO0FBQ3BCLFlBQUksYUFBYSxHQUFHO0FBQ3BCLFlBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQ3RCLGFBQUs7QUFBQSxNQUNQO0FBS0EscUJBQWUsRUFBRTtBQUNqQixVQUFJLFlBQVksRUFBRTtBQUNsQixVQUFJLGFBQWEsQ0FBQztBQUNsQixVQUFJLFFBQVEsYUFBYSxNQUFNO0FBQy9CLFVBQUksS0FBSywwQkFBMEIsSUFBSSxDQUFDO0FBQ3hDLFdBQUs7QUFFTCxVQUFJLFlBQVksRUFBRTtBQUNsQixVQUFJLFFBQVEsYUFBYSxRQUFRO0FBQ2pDLFVBQUksYUFBYSxFQUFFO0FBRW5CLFVBQUksS0FBSyxTQUFTLE1BQU0sUUFBUSxJQUFJLElBQUksQ0FBQztBQUN6QyxXQUFLO0FBQ0wsVUFBSSxLQUFLLFlBQVksTUFBTSxNQUFNLElBQUksSUFBSSxDQUFDO0FBQzFDLFdBQUs7QUFDTCxVQUFJLEtBQUssYUFBYSxNQUFNLFdBQVcsV0FBVyxZQUFZLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDeEUsV0FBSztBQUNMLFVBQUksS0FBSyxZQUFZLElBQUksS0FBSyxNQUFNLFNBQVMsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDeEUsV0FBSztBQUVMLFlBQU0sYUFBYSxNQUFNLFdBQVcsb0JBQW9CO0FBQ3hELFVBQUksS0FBSyxnQkFBZ0IsVUFBVSxJQUFJLElBQUksQ0FBQztBQUM1QyxXQUFLO0FBRUwsWUFBTSxpQkFBaUIsTUFBTSxXQUFXLFVBQVU7QUFDbEQsVUFBSSxLQUFLLDBCQUEwQixpQkFBaUIsSUFBSSxXQUFXLFVBQVUsSUFBSSxJQUFJLENBQUM7QUFDdEYsV0FBSztBQUtMLHFCQUFlLEVBQUU7QUFDakIsVUFBSSxZQUFZLEVBQUU7QUFDbEIsVUFBSSxhQUFhLENBQUM7QUFDbEIsVUFBSSxRQUFRLGFBQWEsTUFBTTtBQUMvQixVQUFJLEtBQUssb0JBQW9CLElBQUksQ0FBQztBQUNsQyxXQUFLO0FBRUwsWUFBTSxPQUFPLE1BQU07QUFDbkIsVUFBSSxNQUFNO0FBQ1IsWUFBSSxZQUFZLEVBQUU7QUFDbEIsWUFBSSxhQUFhLEVBQUU7QUFDbkIsWUFBSSxRQUFRLGFBQWEsTUFBTTtBQUMvQixZQUFJLEtBQUssMEJBQTBCLElBQUksQ0FBQztBQUN4QyxhQUFLO0FBRUwsWUFBSSxRQUFRLFdBQVcsTUFBTTtBQUM3QixZQUFJLFlBQVksQ0FBQztBQUNqQixZQUFJLGFBQWEsQ0FBQztBQUNsQixZQUFJLEtBQUssT0FBTyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQzVCLGFBQUs7QUFHTCxZQUFJLFFBQVEsYUFBYSxRQUFRO0FBQ2pDLFlBQUksWUFBWSxDQUFDO0FBQ2pCLFlBQUksYUFBYSxHQUFHO0FBQ3BCLGNBQU0sY0FDSixNQUFNLFlBQVksWUFDZCw4QkFDQSxNQUFNLFlBQVksV0FDaEIsNkJBQ0E7QUFDUixZQUFJLEtBQUsscUJBQXFCLFdBQVcsR0FBRyxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUM7QUFDeEUsYUFBSztBQUFBLE1BQ1A7QUFHQSxVQUFJLFFBQVEsYUFBYSxNQUFNO0FBQy9CLFVBQUksWUFBWSxFQUFFO0FBQ2xCLFVBQUksYUFBYSxFQUFFO0FBQ25CLFVBQUksS0FBSywyQkFBMkIsSUFBSSxDQUFDO0FBQ3pDLFdBQUs7QUFFTCxVQUFJLFlBQVksQ0FBQztBQUNqQixVQUFJLFFBQVEsV0FBVyxRQUFRO0FBQy9CLFVBQUksYUFBYSxFQUFFO0FBRW5CLFVBQUksb0JBQW9CO0FBQ3hCLFVBQUksVUFBVTtBQUNaLDRCQUFvQixHQUFHLFNBQVMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxPQUFPLFNBQVMsTUFBTSxhQUFhLFNBQVMsTUFBTSxHQUFHLENBQUM7QUFBQSxNQUNwRztBQUVBLFVBQUksS0FBSyxtQkFBbUIsSUFBSSxHQUFHLEVBQUUsVUFBVSxJQUFJLENBQUM7QUFDcEQsVUFBSSxRQUFRLGFBQWEsUUFBUTtBQUNqQyxXQUFLO0FBS0wscUJBQWUsRUFBRTtBQUNqQixVQUFJLFlBQVksRUFBRTtBQUNsQixVQUFJLGFBQWEsQ0FBQztBQUNsQixVQUFJLFFBQVEsYUFBYSxNQUFNO0FBQy9CLFVBQUksS0FBSyxtQkFBbUIsSUFBSSxDQUFDO0FBQ2pDLFdBQUs7QUFFTCxVQUFJLFlBQVksRUFBRTtBQUNsQixVQUFJLFFBQVEsYUFBYSxRQUFRO0FBRWpDLFVBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsWUFBSSxhQUFhLEdBQUc7QUFDcEIsWUFBSSxLQUFLLDRCQUE0QixJQUFJLENBQUM7QUFDMUMsYUFBSztBQUFBLE1BQ1AsT0FBTztBQUNMLGdCQUFRLFFBQVEsQ0FBQyxHQUFHLE1BQU07QUFDeEIseUJBQWUsRUFBRTtBQUNqQixnQkFBTSxTQUFTLEVBQUUsU0FBUyxXQUFXO0FBQ3JDLGdCQUFNLFFBQVEsTUFBTSxlQUFlLEVBQUUsV0FBVztBQUNoRCxnQkFBTSxjQUFjLFFBQVEsR0FBRyxLQUFLLEtBQUssRUFBRSxXQUFXLE1BQU0sRUFBRTtBQUU5RCxjQUFJLGFBQWEsRUFBRTtBQUNuQixjQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxXQUFXLElBQUksSUFBSSxDQUFDO0FBQzFDLGNBQUksS0FBSyxRQUFRLEtBQUssQ0FBQztBQUN2QixlQUFLO0FBQUEsUUFDUCxDQUFDO0FBQUEsTUFDSDtBQUNBLFdBQUs7QUFLTCxxQkFBZSxFQUFFO0FBQ2pCLFVBQUksWUFBWSxFQUFFO0FBQ2xCLFVBQUksYUFBYSxDQUFDO0FBQ2xCLFVBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsVUFBSSxLQUFLLGlDQUFpQyxJQUFJLENBQUM7QUFDL0MsV0FBSztBQUVMLFVBQUksWUFBWSxFQUFFO0FBQ2xCLFVBQUksUUFBUSxhQUFhLFFBQVE7QUFFakMsWUFBTSxrQkFBa0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUMvQyxZQUFNLHlCQUF5QixPQUFPLE9BQU8sZUFBZTtBQUU1RCxVQUFJLHVCQUF1QixXQUFXLEdBQUc7QUFDdkMsWUFBSSxhQUFhLEdBQUc7QUFDcEIsWUFBSSxLQUFLLDZCQUE2QixJQUFJLENBQUM7QUFDM0MsYUFBSztBQUFBLE1BQ1AsT0FBTztBQUNMLCtCQUF1QixRQUFRLENBQUMsR0FBUSxNQUFNO0FBQzVDLHlCQUFlLEVBQUU7QUFDakIsY0FBSSxhQUFhLEVBQUU7QUFFbkIsZ0JBQU0sWUFBWSxFQUFFLFNBQVMsVUFBVSxrQkFBa0I7QUFDekQsZ0JBQU0sY0FBYyxFQUFFLGNBQWMsRUFBRSxjQUFjO0FBRXBELGNBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsY0FBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssV0FBVyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFFdkQsY0FBSSxRQUFRLFdBQVcsUUFBUTtBQUMvQixjQUFJLFlBQVksQ0FBQztBQUNqQixjQUFJLGFBQWEsR0FBRztBQUNwQixjQUFJLEtBQUssZUFBZSxFQUFFLEVBQUUsSUFBSSxLQUFLLENBQUM7QUFFdEMsY0FBSSxZQUFZLEVBQUU7QUFDbEIsZUFBSztBQUFBLFFBQ1AsQ0FBQztBQUFBLE1BQ0g7QUFDQSxXQUFLO0FBS0wscUJBQWUsRUFBRTtBQUNqQixVQUFJLFlBQVksRUFBRTtBQUNsQixVQUFJLGFBQWEsQ0FBQztBQUNsQixVQUFJLFFBQVEsYUFBYSxNQUFNO0FBQy9CLFVBQUksS0FBSyxrQkFBa0IsSUFBSSxDQUFDO0FBQ2hDLFdBQUs7QUFFTCxVQUFJLFlBQVksQ0FBQztBQUNqQixZQUFNLE9BQU8sTUFBTSxZQUFZLENBQUM7QUFFaEMsVUFBSSxLQUFLLFdBQVcsR0FBRztBQUNyQixZQUFJLGFBQWEsR0FBRztBQUNwQixZQUFJLFFBQVEsYUFBYSxRQUFRO0FBQ2pDLFlBQUksS0FBSyx5QkFBeUIsSUFBSSxDQUFDO0FBQ3ZDLGFBQUs7QUFBQSxNQUNQLE9BQU87QUFDTCxhQUFLLFFBQVEsQ0FBQyxRQUFRO0FBQ3BCLGNBQUksQ0FBQyxJQUFLO0FBQ1YseUJBQWUsRUFBRTtBQUVqQixnQkFBTSxZQUFZLElBQUksUUFBUSxPQUFPLElBQUksS0FBSyxJQUFJO0FBQ2xELGdCQUFNLFdBQVcsSUFBSSxPQUFPLE9BQU8sSUFBSSxJQUFJLElBQUk7QUFFL0MsZ0JBQU0sT0FBTyxJQUFJLFlBQVksSUFBSSxLQUFLLElBQUksU0FBUyxFQUFFLG1CQUFtQixJQUFJO0FBQzVFLGdCQUFNLE9BQU8sSUFBSSxZQUFZLElBQUksS0FBSyxJQUFJLFNBQVMsRUFBRSxtQkFBbUIsSUFBSTtBQUU1RSxjQUFJLGFBQWEsR0FBRztBQUNwQixjQUFJLFFBQVEsYUFBYSxRQUFRO0FBQ2pDLGNBQUksS0FBSyxHQUFHLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDO0FBRWpDLGNBQUksYUFBYSxDQUFDO0FBQ2xCLGNBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsY0FBSSxLQUFLLFdBQVcsSUFBSSxDQUFDO0FBRXpCLGNBQUksUUFBUSxhQUFhLFFBQVE7QUFDakMsY0FBSSxLQUFLLFVBQVUsS0FBSyxDQUFDO0FBRXpCLGNBQUksSUFBSSxRQUFRO0FBQ2QsZ0JBQUksYUFBYSxHQUFHO0FBQ3BCLGtCQUFNLFlBQVksT0FBTyxJQUFJLE1BQU07QUFDbkMsa0JBQU0sYUFBYSxVQUFVLFNBQVMsS0FBSyxVQUFVLFVBQVUsR0FBRyxFQUFFLElBQUksUUFBUTtBQUNoRixnQkFBSSxLQUFLLFlBQVksS0FBSyxDQUFDO0FBQUEsVUFDN0I7QUFDQSxlQUFLO0FBQUEsUUFDUCxDQUFDO0FBQUEsTUFDSDtBQUNBLFdBQUs7QUFLTCxxQkFBZSxFQUFFO0FBQ2pCLFVBQUksWUFBWSxFQUFFO0FBQ2xCLFVBQUksYUFBYSxDQUFDO0FBQ2xCLFVBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsVUFBSSxLQUFLLGdDQUFnQyxJQUFJLENBQUM7QUFDOUMsV0FBSztBQUVMLFVBQUksYUFBYSxHQUFHO0FBQ3BCLFVBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQ3RCLFdBQUs7QUFFTCxZQUFNLFNBQVMsSUFBSSxjQUFjLENBQUM7QUFDbEMsWUFBTSxZQUFZLE1BQU0sYUFBYSxDQUFDO0FBRXRDLFVBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBSSxRQUFRLGFBQWEsUUFBUTtBQUNqQyxZQUFJLFlBQVksQ0FBQztBQUNqQixZQUFJLGFBQWEsR0FBRztBQUNwQixZQUFJLEtBQUsseUJBQXlCLElBQUksQ0FBQztBQUN2QyxhQUFLO0FBQUEsTUFDUCxPQUFPO0FBQ0wsZUFBTyxRQUFRLENBQUMsTUFBTSxNQUFNO0FBQzFCLHlCQUFlLEVBQUU7QUFDakIsZ0JBQU0sZ0JBQWdCLFVBQVUsU0FBUyxLQUFLLE9BQU87QUFDckQsZ0JBQU0sVUFBVSxLQUFLLFNBQVMsS0FBVyxRQUFRLENBQUM7QUFFbEQsY0FBSSxZQUFZLENBQUM7QUFDakIsY0FBSSxhQUFhLEVBQUU7QUFDbkIsY0FBSSxRQUFRLFdBQVcsUUFBUTtBQUMvQixjQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxLQUFLLE9BQU8sSUFBSSxJQUFJLENBQUM7QUFDM0MsZUFBSztBQUVMLGNBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsY0FBSSxZQUFZLENBQUM7QUFDakIsY0FBSSxhQUFhLENBQUM7QUFDbEIsY0FBSSxLQUFLLEdBQUcsTUFBTSxRQUFRLElBQUksQ0FBQztBQUUvQixjQUFJLFVBQVUsV0FBVyxHQUFHO0FBQzFCLGdCQUFJLGFBQWEsR0FBRztBQUNwQixnQkFBSSxLQUFLLGdCQUFnQixLQUFLLENBQUM7QUFBQSxVQUNqQyxXQUFXLGVBQWU7QUFDeEIsZ0JBQUksYUFBYSxJQUFJLEtBQUssR0FBRztBQUM3QixnQkFBSSxLQUFLLG1CQUFtQixLQUFLLENBQUM7QUFBQSxVQUNwQyxPQUFPO0FBQ0wsZ0JBQUksYUFBYSxLQUFLLElBQUksRUFBRTtBQUM1QixnQkFBSSxLQUFLLGNBQWMsS0FBSyxDQUFDO0FBQUEsVUFDL0I7QUFFQSxlQUFLO0FBQUEsUUFDUCxDQUFDO0FBQUEsTUFDSDtBQUNBLFdBQUs7QUFLTCxxQkFBZSxFQUFFO0FBQ2pCLFVBQUksWUFBWSxFQUFFO0FBQ2xCLFVBQUksYUFBYSxDQUFDO0FBQ2xCLFVBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsVUFBSSxLQUFLLHVCQUF1QixJQUFJLENBQUM7QUFDckMsV0FBSztBQUVMLFVBQUksYUFBYSxHQUFHO0FBQ3BCLFVBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQ3RCLFdBQUs7QUFFTCxZQUFNLFVBQVUsSUFBSSxXQUFXLENBQUM7QUFFaEMsVUFBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixZQUFJLFFBQVEsYUFBYSxRQUFRO0FBQ2pDLFlBQUksWUFBWSxDQUFDO0FBQ2pCLFlBQUksYUFBYSxHQUFHO0FBQ3BCLFlBQUksS0FBSyxpQ0FBaUMsSUFBSSxDQUFDO0FBQy9DLGFBQUs7QUFBQSxNQUNQLE9BQU87QUFDTCxnQkFBUSxRQUFRLENBQUMsS0FBSyxNQUFNO0FBQzFCLHlCQUFlLEVBQUU7QUFDakIsZ0JBQU0sZ0JBQWdCLFVBQVUsU0FBUyxJQUFJLE9BQU87QUFDcEQsZ0JBQU0sVUFBVSxJQUFJLFNBQVMsS0FBVyxRQUFRLENBQUM7QUFFakQsY0FBSSxZQUFZLENBQUM7QUFDakIsY0FBSSxhQUFhLEVBQUU7QUFDbkIsY0FBSSxRQUFRLFdBQVcsUUFBUTtBQUMvQixjQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxJQUFJLE9BQU8sSUFBSSxJQUFJLENBQUM7QUFDMUMsZUFBSztBQUVMLGNBQUksUUFBUSxhQUFhLE1BQU07QUFDL0IsY0FBSSxZQUFZLENBQUM7QUFDakIsY0FBSSxhQUFhLENBQUM7QUFDbEIsY0FBSSxLQUFLLEdBQUcsTUFBTSxRQUFRLElBQUksQ0FBQztBQUUvQixjQUFJLFVBQVUsV0FBVyxHQUFHO0FBQzFCLGdCQUFJLGFBQWEsR0FBRztBQUNwQixnQkFBSSxLQUFLLGdCQUFnQixLQUFLLENBQUM7QUFBQSxVQUNqQyxXQUFXLElBQUksVUFBVTtBQUN2QixnQkFBSSxhQUFhLEtBQUssS0FBSyxFQUFFO0FBQzdCLGdCQUFJLEtBQUsscUJBQXFCLEtBQUssQ0FBQztBQUFBLFVBQ3RDLFdBQVcsZUFBZTtBQUN4QixnQkFBSSxhQUFhLElBQUksS0FBSyxHQUFHO0FBQzdCLGdCQUFJLEtBQUssd0JBQXdCLEtBQUssQ0FBQztBQUFBLFVBQ3pDLE9BQU87QUFDTCxnQkFBSSxhQUFhLEtBQUssSUFBSSxFQUFFO0FBQzVCLGdCQUFJLEtBQUssY0FBYyxLQUFLLENBQUM7QUFBQSxVQUMvQjtBQUVBLGVBQUs7QUFBQSxRQUNQLENBQUM7QUFFRCxZQUFJLGFBQWEsR0FBRztBQUNwQixZQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssQ0FBQztBQUN0QixhQUFLO0FBRUwsWUFBSSxRQUFRLGFBQWEsUUFBUTtBQUNqQyxZQUFJLFlBQVksRUFBRTtBQUNsQixZQUFJLGFBQWEsR0FBRztBQUNwQixZQUFJLEtBQUssa0JBQWtCLFFBQVEsTUFBTSxJQUFJLElBQUksQ0FBQztBQUNsRCxhQUFLO0FBQUEsTUFDUDtBQUtBLFlBQU0sV0FBVSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDckQsWUFBTSxVQUFVLE1BQU0sT0FBTyxNQUFNLEdBQUcsQ0FBQztBQUN2QyxZQUFNLFdBQVcsTUFBTSxZQUFZLE1BQU0sVUFBVSxNQUFNLEdBQUcsQ0FBQyxJQUFJO0FBQ2pFLFVBQUksV0FBVyxxQkFBcUIsT0FBTyxTQUFTLE9BQU8sT0FBTyxRQUFRO0FBRTFFLFVBQUksU0FBUyxjQUFjO0FBQ3pCLG1CQUFXLEdBQUcsU0FBUyxXQUFXLFFBQVEsUUFBUSxFQUFFLEtBQUssYUFBYSxVQUFVLE9BQU8sU0FBUyxPQUFPLE9BQU8sUUFBUTtBQUFBLE1BQ3hIO0FBRUEsYUFBTyxFQUFFLEtBQUssU0FBUztBQUFBLElBQ3pCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsT0FBYSx3QkFDWCxVQUNBLFlBQ2lCO0FBQUE7QUFDakIsWUFBTSxZQUFZLENBQUMsR0FBRyxRQUFRLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLFlBQVksRUFBRSxTQUFTO0FBRXhFLFlBQU0sYUFBYSxVQUFVLElBQUksQ0FBQyxVQUFVO0FBQzFDLGVBQU8sR0FBRyxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUUsWUFBWSxDQUFDLElBQUksTUFBTSxLQUFLLElBQUksTUFBTSxJQUFJLElBQUksTUFBTSxVQUFVLEVBQUU7QUFBQSxNQUN0RyxDQUFDO0FBRUQsWUFBTSxVQUFVLFdBQVcsS0FBSyxFQUFFLElBQUk7QUFFdEMsWUFBTSxVQUFVLElBQUksWUFBWTtBQUNoQyxZQUFNLE9BQU8sUUFBUSxPQUFPLE9BQU87QUFDbkMsWUFBTSxhQUFhLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxJQUFJO0FBRTdELGFBQU8sTUFBTSxLQUFLLElBQUksV0FBVyxVQUFVLENBQUMsRUFDekMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUFBLElBQ1o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxPQUFhLG9CQUNYLE9BQ0EsZ0JBQytDO0FBQUE7QUFDL0MsVUFBSSxDQUFDLE1BQU0sY0FBYyxDQUFDLE1BQU0sVUFBVTtBQUN4QyxjQUFNLElBQUksTUFBTSx5Q0FBeUM7QUFBQSxNQUMzRDtBQUVBLFlBQU0sbUJBQW1CLE1BQU0sS0FBSyx3QkFBd0IsTUFBTSxVQUFVLE1BQU0sVUFBVTtBQUM1RixZQUFNLFVBQVUscUJBQXFCO0FBRXJDLGFBQU8sRUFBRSxRQUFRLGtCQUFrQixRQUFRO0FBQUEsSUFDN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUEsT0FBYSxtQkFDWCxPQUNnRDtBQUFBO0FBQ2hELFVBQUksQ0FBQyxNQUFNLGNBQWMsQ0FBQyxNQUFNLFNBQVUsT0FBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRTlFLGFBQU87QUFBQSxRQUNMLFFBQVEsTUFBTSxLQUFLLHdCQUF3QixNQUFNLFVBQVUsTUFBTSxVQUFVO0FBQUEsUUFDM0UsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ3BDO0FBQUEsSUFDRjtBQUFBO0FBQ0Y7OztBQzNtQkEsU0FBcUIsc0JBQXNCO0FBQzNDLFNBQVMsYUFBYTtBQWlCZixJQUFNLG9CQUFOLE1BQXdCO0FBQUEsRUFDYjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFFUjtBQUFBLEVBQ0E7QUFBQSxFQUNBLGFBQTRCO0FBQUEsRUFDNUIsUUFBMkI7QUFBQSxFQUMzQixpQkFBZ0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTXhDLFlBQVksUUFBMkI7QUFDckMsU0FBSyxTQUFTLE9BQU8sT0FBTyxRQUFRLE9BQU8sRUFBRTtBQUM3QyxTQUFLLGtCQUFrQixPQUFPLG1CQUFtQjtBQUVqRCxTQUFLLFNBQVMsSUFBSSxpQkFBaUI7QUFDbkMsU0FBSyxRQUFRLElBQUksWUFBWSxLQUFLLE1BQU07QUFDeEMsU0FBSyxRQUFRLElBQUksZUFBZSxLQUFLLE1BQU0sTUFBTTtBQUVqRCxTQUFLLE1BQU0sT0FBTyxHQUFHLG1CQUFtQixFQUFFLFVBQVUsQ0FBQyxNQUFNO0FBQ3pELFdBQUssYUFBYSxFQUFFO0FBQUEsSUFDdEIsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsYUFBYSxFQUFFLFVBQVUsQ0FBTyxNQUFNO0FBQ3pELFlBQU0sVUFBVSxFQUFFO0FBQ2xCLFVBQUksS0FBSyxVQUFVLFdBQVcsWUFBWSxTQUFTO0FBQ2pELGNBQU0sS0FBSztBQUFBLFVBQ1Q7QUFBQSxVQUNBLGVBQWUsS0FBSyxVQUFVO0FBQUEsVUFDOUI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFdBQUssUUFBUTtBQUFBLElBQ2YsRUFBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsdUJBQXVCLEVBQUUsVUFBVSxDQUFDLE1BQU07QUFDN0QsWUFBTSxXQUFXLEtBQUsscUJBQXFCO0FBQzNDLFlBQU0sWUFBWSxLQUFLLGFBQWEsS0FBSyxhQUFhLENBQUM7QUFFdkQsV0FBSyxNQUFNLE9BQU8sU0FBUyxzQkFBc0I7QUFBQSxRQUMvQyxhQUFhLEVBQUUsU0FBUztBQUFBLFFBQ3hCLG9CQUFvQixTQUFTO0FBQUEsUUFDN0IsY0FBYyxTQUFTO0FBQUEsTUFDekIsQ0FBQztBQUVELFVBQUksS0FBSyxlQUFlLEdBQUc7QUFDekIsYUFBSyxNQUFNLE9BQU8sU0FBUyxpQkFBaUI7QUFBQSxVQUMxQyxvQkFBb0IsU0FBUztBQUFBLFVBQzdCO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUtBLElBQVcsY0FBc0I7QUFDL0IsV0FBTyxLQUFLLFVBQVUsVUFBVSxnQkFBZ0IsVUFBVSxLQUFLLGNBQWMsU0FBUztBQUFBLEVBQ3hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLTyxnQkFBdUM7QUFDNUMsV0FBTyxLQUFLLE1BQU0sT0FBTyxHQUFHLGVBQWU7QUFBQSxFQUM3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9PLFFBQVEsV0FBaUQ7QUFDOUQsV0FBTyxLQUFLLE1BQU0sT0FBTyxHQUFHLFNBQVM7QUFBQSxFQUN2QztBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS08sZUFBaUM7QUFDdEMsV0FBTyxLQUFLLE1BQU0sU0FBUztBQUFBLEVBQzdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNhLFdBQ1gsWUFDQSxTQUNBLFdBQVcsaUJBQ1g7QUFBQTtBQUNBLFlBQU0sVUFBVSxNQUFNLFlBQVk7QUFBQSxRQUNoQyxLQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLO0FBQUEsTUFDUDtBQUVBLFdBQUssaUJBQWlCLFFBQVEsVUFBVTtBQUV4QyxZQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsS0FBSyxNQUFNLGFBQWE7QUFBQSxRQUNqRCxRQUFRO0FBQUEsUUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLFFBQzlDLE1BQU0sS0FBSyxVQUFVLFFBQVEsV0FBVztBQUFBLE1BQzFDLENBQUM7QUFFRCxVQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sSUFBSSxNQUFNLDBCQUEwQixNQUFNLElBQUksS0FBSyxDQUFDLEVBQUU7QUFFekUsYUFBTztBQUFBLElBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTYSxrQkFDWCxZQUNBLFNBQ0EsV0FBVyxpQkFDWDtBQUFBO0FBQ0EsWUFBTSxVQUErQixNQUFNLEtBQUssV0FBVyxZQUFZLFNBQVMsUUFBUTtBQUV4RixZQUFNLGtCQUFrQixlQUFlLEtBQUssTUFBTSxPQUFPLEdBQUcsZ0JBQWdCLENBQUM7QUFDN0UsWUFBTSxlQUFlLGVBQWUsS0FBSyxNQUFNLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQztBQUU3RSxZQUFNLFFBQVEsS0FBSyxPQUFPLFFBQVEsU0FBUyxJQUFJO0FBQy9DLFdBQUssTUFBTSxLQUFLLFFBQVEsVUFBVSxRQUFRLEtBQUssZUFBZTtBQUM5RCxZQUFNLEtBQUssTUFBTTtBQUFBLFFBQ2Y7QUFBQSxRQUNBLFFBQVEsVUFBVTtBQUFBLFFBQ2xCLFFBQVEsVUFBVTtBQUFBLFFBQ2xCLEtBQUs7QUFBQSxNQUNQO0FBRUEsWUFBTTtBQUNOLFlBQU07QUFFTixZQUFNLEtBQUsscUJBQXFCLGVBQWUsWUFBWSxLQUFLLFVBQVUsRUFBRTtBQUU1RSxZQUFNLFlBQVksZUFBZSxLQUFLLE1BQU0sT0FBTyxHQUFHLGFBQWEsQ0FBQztBQUNwRSxXQUFLLE1BQU0saUJBQWlCLFFBQVEsWUFBWSxVQUFVO0FBQzFELFlBQU07QUFFTixhQUFPO0FBQUEsUUFDTCxRQUFRLFFBQVEsVUFBVTtBQUFBLFFBQzFCLGVBQWUsUUFBUSxVQUFVO0FBQUEsUUFDakMsYUFBYSxRQUFRLFVBQVU7QUFBQSxRQUMvQixxQkFBcUIsUUFBUSxZQUFZO0FBQUEsTUFDM0M7QUFBQSxJQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPYSxTQUFTLFFBQWdCLGVBQXVCO0FBQUE7QUFDM0QsV0FBSyxpQkFBaUI7QUFHdEIsWUFBTSxrQkFBa0IsZUFBZSxLQUFLLE1BQU0sT0FBTyxHQUFHLGdCQUFnQixDQUFDO0FBQzdFLFlBQU0sZUFBZSxlQUFlLEtBQUssTUFBTSxPQUFPLEdBQUcsbUJBQW1CLENBQUM7QUFFN0UsWUFBTSxRQUFRLEtBQUssT0FBTyxRQUFRLFNBQVMsSUFBSTtBQUMvQyxXQUFLLE1BQU0sS0FBSyxRQUFRLEtBQUssZUFBZTtBQUU1QyxZQUFNLEtBQUssTUFBTSxTQUFTLE9BQU8sUUFBUSxlQUFlLEtBQUssZUFBZTtBQUc1RSxZQUFNO0FBQ04sWUFBTTtBQUVOLFlBQU0sS0FBSyxxQkFBcUIsZUFBZSxZQUFZLEtBQUssVUFBVSxFQUFFO0FBQUEsSUFDOUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS2EsWUFBWSxNQUFjO0FBQUE7QUFDckMsWUFBTSxlQUFlLEtBQUssYUFBYSx3QkFBd0I7QUFDL0QsWUFBTSxLQUFLLE1BQU0sV0FBVyxNQUFNLEtBQUssV0FBVztBQUNsRCxZQUFNO0FBQUEsSUFDUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLYSxXQUFXLFVBQW1CO0FBQUE7QUFDekMsWUFBTSxlQUFlLEtBQUssYUFBYSxjQUFjO0FBQ3JELFlBQU0sS0FBSyxNQUFNLFdBQVcsVUFBVSxLQUFLLFdBQVc7QUFDdEQsWUFBTTtBQUFBLElBQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNYSxnQkFBZ0IsWUFBb0IsYUFBcUI7QUFBQTtBQUNwRSxZQUFNLGVBQWUsS0FBSyxhQUFhLHVCQUF1QjtBQUM5RCxZQUFNLEtBQUssTUFBTSxnQkFBZ0IsWUFBWSxhQUFhLEtBQUssV0FBVztBQUMxRSxZQUFNO0FBQUEsSUFDUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT2EscUJBQXFCLFFBQWdCLFFBQWdCLGNBQXVCO0FBQUE7QUFDdkYsWUFBTSxjQUFjLGdCQUFnQixLQUFLO0FBRXpDLFlBQU0sT0FBTyxNQUFNLEtBQUssTUFBTSxvQkFBb0IsUUFBUSxRQUFRLFdBQVc7QUFDN0UsV0FBSyxNQUFNLEtBQUssY0FBYyxFQUFFLGtCQUFrQixLQUFLLENBQUM7QUFBQSxJQUMxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLYSxlQUFlLE1BQWM7QUFBQTtBQUN4QyxZQUFNLGVBQWUsS0FBSyxhQUFhLHdCQUF3QjtBQUMvRCxZQUFNLEtBQUssTUFBTSxlQUFlLElBQUk7QUFDcEMsWUFBTSxLQUFLLHFCQUFxQiwwQkFBMEIsa0JBQWtCLElBQUksR0FBRztBQUNuRixZQUFNO0FBQUEsSUFDUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1hLGVBQWUsYUFBcUIsT0FBZTtBQUFBO0FBQzlELFlBQU0sZUFBZSxLQUFLLGFBQWEsa0JBQWtCO0FBQ3pELFlBQU0sS0FBSyxNQUFNLGtCQUFrQixhQUFhLE9BQU8sS0FBSyxXQUFXO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUthLFlBQVk7QUFBQTtBQUN2QixZQUFNLGVBQWUsS0FBSyxhQUFhLGFBQWE7QUFDcEQsV0FBSyxNQUFNLFVBQVU7QUFDckIsWUFBTTtBQUFBLElBQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS08saUJBQXlCO0FBQzlCLFVBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsUUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixXQUFPLFlBQVksbUJBQW1CLEtBQUs7QUFBQSxFQUM3QztBQUFBLEVBRU8sdUJBQStCO0FBQ3BDLFVBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsVUFBTSxLQUFLLEtBQUssYUFBYSxLQUFLO0FBQ2xDLFVBQU0sVUFBVSxLQUFLLGlCQUFpQixLQUFLO0FBRTNDLFFBQUksQ0FBQyxTQUFTLENBQUMsR0FBSSxRQUFPO0FBRTFCLFdBQU8sWUFBWSxxQkFBcUIsT0FBTyxJQUFJLE9BQU87QUFBQSxFQUM1RDtBQUFBLEVBRWEsZUFBZSxTQUFvRTtBQUFBO0FBQzlGLFlBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsWUFBTSxLQUFLLEtBQUssYUFBYSxLQUFLO0FBQ2xDLFlBQU0sVUFBVSxLQUFLLGlCQUFpQixLQUFLO0FBQzNDLFlBQU0sV0FBVyxLQUFLLHVCQUF1QjtBQUU3QyxVQUFJLENBQUMsTUFBTyxPQUFNLElBQUksTUFBTSxzQ0FBc0M7QUFFbEUsYUFBTyxNQUFNLFlBQVksaUJBQWlCLElBQUksTUFBTSxHQUFHLE9BQU8sSUFBSSxTQUFTLFVBQVUsT0FBTztBQUFBLElBQzlGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPYSxnQkFBZ0IsV0FBcUIsU0FBa0IsT0FBTztBQUFBO0FBQ3pFLFVBQUksQ0FBQyxhQUFhLFVBQVUsV0FBVyxFQUFHO0FBRTFDLFlBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsWUFBTSxjQUFjLE9BQU8sYUFBYSxDQUFDO0FBQ3pDLFVBQUksVUFBb0IsQ0FBQztBQUV6QixVQUFJLFFBQVE7QUFDVixrQkFBVSxZQUFZLE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxTQUFTLENBQUMsQ0FBQztBQUFBLE1BQzVELE9BQU87QUFDTCxrQkFBVSxNQUFNLEtBQUssb0JBQUksSUFBSSxDQUFDLEdBQUcsYUFBYSxHQUFHLFNBQVMsQ0FBQyxDQUFDO0FBQUEsTUFDOUQ7QUFHQSxVQUFJLFlBQVksV0FBVyxRQUFRLE9BQVE7QUFFM0MsVUFBSSxTQUFTO0FBQ2IsVUFBSSxVQUFVLFdBQVcsR0FBRztBQUMxQixjQUFNLFVBQVUsVUFBVSxDQUFDO0FBQzNCLGNBQU0sWUFBWSxRQUFRLFNBQVMsSUFBSSxRQUFRLE1BQU0sRUFBRSxJQUFJO0FBQzNELGNBQU0sYUFBYSxTQUFTLFlBQVk7QUFDeEMsaUJBQVMsR0FBRyxVQUFVLE9BQU8sU0FBUztBQUFBLE1BQ3hDLE9BQU87QUFDTCxjQUFNLGFBQWEsU0FBUyxZQUFZO0FBQ3hDLGlCQUFTLEdBQUcsVUFBVSxJQUFJLFVBQVUsTUFBTTtBQUFBLE1BQzVDO0FBRUEsWUFBTSxlQUFlLEtBQUssYUFBYSxxQkFBcUI7QUFDNUQsWUFBTSxLQUFLLE1BQU0sZ0JBQWdCLFNBQVMsUUFBUSxLQUFLLFdBQVc7QUFDbEUsWUFBTTtBQUFBLElBQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUWEsc0JBQXFFO0FBQUE7QUFDaEYsWUFBTSxRQUFRLEtBQUssYUFBYTtBQUNoQyxVQUFJLENBQUMsTUFBTyxRQUFPO0FBRW5CLFlBQU0sU0FBUyxVQUFVLFdBQVcsTUFBTSxJQUFJO0FBRTlDLFVBQUksUUFBUTtBQUNWLGFBQUssTUFBTSxPQUFPLENBQUMsTUFBTyxpQ0FBSyxJQUFMLEVBQVMsWUFBWSxPQUFPLEtBQUssV0FBVyxPQUFPLEtBQUssRUFBRTtBQUVwRixjQUFNLGVBQWUsS0FBSztBQUFBLFVBQWEsQ0FBQyxNQUN0QyxFQUFFLFNBQVMsS0FBSyxDQUFDLFFBQVEsSUFBSSxVQUFVLGNBQWM7QUFBQSxRQUN2RDtBQUVBLGNBQU0sS0FBSyxNQUFNLHNCQUFzQixPQUFPLEtBQUssT0FBTyxNQUFNLEtBQUssV0FBVztBQUNoRixjQUFNO0FBQUEsTUFDUjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJTyx5QkFBd0M7QUFDN0MsVUFBTSxRQUFRLEtBQUssTUFBTSxTQUFTO0FBQ2xDLFdBQU8sT0FBTyxjQUFjO0FBQUEsRUFDOUI7QUFBQTtBQUFBO0FBQUEsRUFJTyxhQUFhO0FBQ2xCLFNBQUssTUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ3RDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT08sdUJBQTZFO0FBQ2xGLFVBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEtBQU0sUUFBTyxFQUFFLGNBQWMsR0FBRyxvQkFBb0IsRUFBRTtBQUUzRSxVQUFNLFdBQVcsVUFBVSxRQUFRLE1BQU0sSUFBSTtBQUU3QyxXQUFPO0FBQUEsTUFDTCxjQUFjLFVBQVUsZUFBZTtBQUFBLE1BQ3ZDLG9CQUFvQixNQUFNLFdBQVc7QUFBQSxJQUN2QztBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTU8saUJBQTBCO0FBQy9CLFVBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEtBQU0sUUFBTztBQUNsQyxXQUFPLFVBQVUsV0FBVyxNQUFNLElBQUksTUFBTTtBQUFBLEVBQzlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT08sdUJBQXVCLFdBQTJCO0FBQ3ZELFVBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsUUFBSSxDQUFDLE1BQU8sUUFBTztBQUVuQixVQUFNLFlBQVksWUFBWSxNQUFNLFdBQVc7QUFDL0MsV0FBTyxLQUFLLElBQUksR0FBRyxTQUFTO0FBQUEsRUFDOUI7QUFBQTtBQUFBO0FBQUEsRUFJTyx3QkFBd0I7QUFDN0IsVUFBTSxRQUFRLEtBQUssYUFBYTtBQUNoQyxRQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sS0FBTSxRQUFPO0FBQ2xDLFdBQU8sVUFBVSxlQUFlLE1BQU0sTUFBTSxNQUFNLE9BQU87QUFBQSxFQUMzRDtBQUFBO0FBQUEsRUFHTyxhQUFhO0FBQ2xCLFdBQU8sS0FBSyxzQkFBc0IsR0FBRyxXQUFXLENBQUM7QUFBQSxFQUNuRDtBQUFBO0FBQUEsRUFHTyxZQUFZO0FBQ2pCLFdBQU8sS0FBSyxzQkFBc0IsR0FBRyxjQUFjLENBQUM7QUFBQSxFQUN0RDtBQUFBO0FBQUEsRUFHTyxnQkFBd0I7QUFDN0IsV0FBTyxLQUFLLHNCQUFzQixHQUFHLE9BQU87QUFBQSxFQUM5QztBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS08saUJBQWlCLE9BQWdDO0FBQ3RELFFBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxLQUFNLFFBQU8sQ0FBQztBQUNuQyxXQUFPLFVBQVUsZUFBZSxNQUFNLElBQUk7QUFBQSxFQUM1QztBQUFBLEVBRU8sYUFBYSxPQUEyQztBQUM3RCxXQUFPLE9BQU8sT0FBTyxVQUFVLGVBQWUsTUFBTSxNQUFNLE1BQU0sT0FBTyxJQUFJO0FBQUEsRUFDN0U7QUFBQSxFQUVPLGFBQWEsT0FBaUM7QUFDbkQsUUFBSSxDQUFDLE9BQU8sS0FBTSxRQUFPO0FBQ3pCLFVBQU0sWUFBWSxVQUFVLGFBQWEsTUFBTSxJQUFJO0FBQ25ELFdBQU8sWUFBWSxJQUFJLFlBQVksS0FBSyxpQkFBaUIsS0FBSyxFQUFFO0FBQUEsRUFDbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTU8sZ0NBQWdDLGtCQUF5QztBQUM5RSxXQUFPLFVBQVUsdUJBQXVCLGdCQUFnQjtBQUFBLEVBQzFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLUSxhQUFhLFdBQStCO0FBQ2xELFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixZQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sR0FBRyxTQUFTLEVBQUUsVUFBVSxNQUFNO0FBQzFELFlBQUksWUFBWTtBQUNoQixnQkFBUTtBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFPLGFBQWEsV0FBMEMsWUFBWSxLQUFzQjtBQUM5RixXQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxZQUFNLGVBQWUsS0FBSyxhQUFhO0FBQ3ZDLFVBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFHLFFBQU8sUUFBUTtBQUU1RCxZQUFNLFFBQVEsV0FBVyxNQUFNO0FBQzdCLFlBQUksWUFBWTtBQUNoQixlQUFPLElBQUksTUFBTSxrQ0FBa0MsQ0FBQztBQUFBLE1BQ3RELEdBQUcsU0FBUztBQUVaLFlBQU0sTUFBTSxLQUFLLGNBQWMsRUFBRSxVQUFVLE1BQU07QUFDL0MsY0FBTSxRQUFRLEtBQUssYUFBYTtBQUNoQyxZQUFJLFNBQVMsVUFBVSxLQUFLLEdBQUc7QUFDN0IsdUJBQWEsS0FBSztBQUNsQixjQUFJLFlBQVk7QUFDaEIsa0JBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNTyxZQUFZLFlBQW9CLGFBQXNCLE9BQWU7QUFDMUUsVUFBTSxRQUFRLEtBQUssYUFBYTtBQUNoQyxRQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sT0FBUSxRQUFPO0FBRXBDLFFBQUksT0FBTyxHQUFHLFdBQVcsUUFBUSxPQUFPLEVBQUUsQ0FBQyxTQUFTLE1BQU0sTUFBTTtBQUNoRSxRQUFJLGNBQWMsS0FBSyxnQkFBZ0I7QUFDckMsY0FBUSxJQUFJLG1CQUFtQixLQUFLLGNBQWMsQ0FBQztBQUFBLElBQ3JEO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTWEsZ0JBQ1gsZ0JBQytDO0FBQUE7QUFDL0MsWUFBTSxRQUFRLEtBQUssYUFBYTtBQUNoQyxVQUFJLENBQUMsTUFBTyxPQUFNLElBQUksTUFBTSxvQ0FBb0M7QUFDaEUsYUFBTyxNQUFNLFlBQVksb0JBQW9CLE9BQU8sY0FBYztBQUFBLElBQ3BFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUthLG9CQUFxQztBQUFBO0FBQ2hELFlBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsVUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLGNBQWMsQ0FBQyxNQUFNLFVBQVU7QUFDbEQsY0FBTSxJQUFJLE1BQU0sNkNBQTZDO0FBQUEsTUFDL0Q7QUFDQSxhQUFPLE1BQU0sWUFBWSx3QkFBd0IsTUFBTSxVQUFVLE1BQU0sVUFBVTtBQUFBLElBQ25GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUthLHFCQUFxQjtBQUFBO0FBQ2hDLFlBQU0sUUFBUSxLQUFLLGFBQWE7QUFDaEMsVUFBSSxDQUFDLE1BQU8sT0FBTSxJQUFJLE1BQU0sVUFBVTtBQUN0QyxhQUFPLE1BQU0sWUFBWSxtQkFBbUIsS0FBSztBQUFBLElBQ25EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTWEsaUJBQWlCLGFBQW9DO0FBQUE7QUFDaEUsVUFBSSxLQUFLLE1BQU0sU0FBUyxNQUFNLE1BQU07QUFDbEMsY0FBTSxJQUFJLE1BQU0sa0RBQWtEO0FBQUEsTUFDcEU7QUFDQSxXQUFLLE1BQU0sS0FBSyxRQUFRLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFFOUMsWUFBTSxLQUFLLGFBQWEsQ0FBQyxVQUFVO0FBQ2pDLFlBQUksQ0FBQyxLQUFLLGNBQWMsQ0FBQyxNQUFNLGFBQWMsUUFBTztBQUNwRCxlQUFPLE1BQU0sYUFBYSxLQUFLLFVBQVUsR0FBRyxTQUFTO0FBQUEsTUFDdkQsR0FBRyxJQUFLO0FBQUEsSUFDVjtBQUFBO0FBQUEsRUFFYSxjQUFjLE1BQTZCO0FBQUE7QUFDdEQsWUFBTSxTQUFTLE1BQU0sS0FBSyxZQUFZO0FBQ3RDLFlBQU0sUUFBUSxJQUFJLFdBQVcsTUFBTTtBQUduQyxZQUFNLFdBQ0osTUFBTSxDQUFDLE1BQU0sT0FDYixNQUFNLENBQUMsTUFBTSxPQUNiLE1BQU0sQ0FBQyxNQUFNLE1BQ2IsTUFBTSxDQUFDLE1BQU0sT0FDYixNQUFNLENBQUMsTUFBTTtBQUVmLFlBQU0sVUFBVSxXQUNaLE1BQU0sS0FBSyxLQUFLLEVBQ2IsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRSxJQUNWLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSyxFQUFFLEtBQUs7QUFFekMsVUFBSSxRQUFRLFdBQVcsUUFBUSxLQUFLLFFBQVEsV0FBVyxRQUFRLEdBQUc7QUFDaEUsY0FBTSxJQUFJLE1BQU0sNEVBQTRFO0FBQUEsTUFDOUY7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUFBO0FBQUEsRUFFTyxpQkFDTCxNQUMrRDtBQUMvRCxRQUFJLFNBQVMsS0FBTSxRQUFPO0FBQzFCLFFBQUksU0FBUyxLQUFNLFFBQU87QUFDMUIsUUFBSSxTQUFTLEtBQU0sUUFBTztBQUMxQixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUNwbUJBOzs7O0FBS0EsU0FBUyxZQUFZLGNBQWM7QUFDbkMsU0FBUyxJQUFJLFdBQVcsaUJBQWlCO0FBQ3pDLFlBQVksWUFBWTtBQUN4QixTQUFTLE9BQUFDLE1BQUssVUFBQUMsZUFBYzs7QUFHdEIsSUFBTyxZQUFQLE1BQU8sV0FBUztFQUNaLFVBQVUsSUFBSSxVQUFTO0VBRXhCLGVBQWU7SUFBZTs7Ozs7O0VBRTdCLFlBQVksb0JBQUksSUFBa0I7RUFDbEMsWUFBWTtFQUViLGtCQUFrQjtJQUFlOzs7Ozs7RUFDakMsWUFBWTtJQUFzQjs7Ozs7Ozs7O0VBS3pDLGVBQWUsWUFBb0Isb0JBQW9CLEtBQWM7QUFDbkUsVUFBTSxjQUFjLFdBQVcsUUFBUSxRQUFRLEVBQUU7QUFDakQsVUFBTSxZQUFZQSxRQUFPLE9BQU8sV0FBVztBQUczQyxVQUFNLFlBQVksR0FBRyxXQUFXLE9BQU8sS0FBSyxTQUFTLENBQUM7QUFFdEQsVUFBTSxjQUNKLFVBQVUsUUFBUyxVQUFrQixTQUFVLFVBQWtCO0FBRW5FLFFBQUksQ0FBQyxhQUFhO0FBQ2hCLGNBQVEsTUFBTSxvREFBb0QsU0FBUztBQUMzRSxhQUFPLENBQUE7SUFDVDtBQUVBLFVBQU0sS0FBSyxJQUFJLEdBQUcsYUFBYSxhQUFhO0FBQzVDLFVBQU0sVUFBVSxJQUFJLFVBQVUsSUFBSSxpQkFBaUI7QUFDbkQsVUFBTSxTQUFtQixDQUFBO0FBRXpCLGFBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxrQkFBa0IsR0FBRyxLQUFLO0FBQ3BELGFBQU8sS0FBSyxRQUFRLFNBQVEsRUFBRyxZQUFXLENBQUU7SUFDOUM7QUFFQSxXQUFPO0VBQ1Q7RUFFQSxtQkFBbUIsWUFBb0IsZ0JBQWdCLEtBQWU7QUFDcEUsVUFBTSxZQUFZQSxRQUFPLE9BQU8sV0FBVyxRQUFRLFFBQVEsRUFBRSxDQUFDO0FBQzlELFVBQU0sVUFBVUQsS0FBSSxPQUFPLFNBQVMsRUFBRSxZQUFXO0FBRWpELFVBQU0sY0FBYyxLQUFLLEtBQUssUUFBUSxTQUFTLGFBQWE7QUFFNUQsUUFBSSxjQUFjO0FBQU0sWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBRWpFLFVBQU0sY0FBYyxZQUFZLFNBQVMsRUFBRSxFQUFFLFlBQVcsRUFBRyxTQUFTLEdBQUcsR0FBRztBQUMxRSxVQUFNLFNBQW1CLENBQUE7QUFFekIsYUFBUyxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQUs7QUFDcEMsWUFBTSxnQkFBZ0IsRUFBRSxTQUFTLEVBQUUsRUFBRSxZQUFXLEVBQUcsU0FBUyxHQUFHLEdBQUc7QUFDbEUsWUFBTSxTQUFTLE9BQU8sV0FBVyxHQUFHLGFBQWE7QUFDakQsWUFBTSxRQUFRLFFBQVEsVUFBVSxJQUFJLGdCQUFnQixJQUFJLEtBQUssYUFBYTtBQUMxRSxhQUFPLEtBQUssU0FBUyxLQUFLO0lBQzVCO0FBRUEsV0FBTztFQUNUOzs7O0VBS0EsZ0JBQWdCLFVBQWdDO0FBQzlDLFFBQUksQ0FBQyxZQUFZLE9BQU8sYUFBYSxVQUFVO0FBQzdDLFdBQUssVUFBVSxJQUFJLDJCQUEyQjtBQUM5QyxhQUFPO0lBQ1Q7QUFFQSxRQUFJO0FBQ0YsWUFBTSxRQUFRLFNBQVMsWUFBVztBQUNsQyxXQUFLLGdCQUFnQixJQUFJLE1BQU0sU0FBUyxLQUFLLE1BQU0sVUFBVSxHQUFHLEVBQUUsSUFBSSxRQUFRLEtBQUs7QUFDbkYsV0FBSyxVQUFVLElBQUksSUFBSTtBQUd2QixVQUFJLE1BQU0sV0FBVyxLQUFLLEdBQUc7QUFDM0IsYUFBSyxRQUFRLFlBQVksS0FBSztBQUU5QixjQUFNLFdBQVcsS0FBSyxRQUFRLHlCQUF3QjtBQUN0RCxhQUFLLGFBQWEsSUFBSSxLQUFLLElBQUksVUFBVSxLQUFLLGFBQVksQ0FBRSxDQUFDO0FBRTdELFlBQUksS0FBSyxRQUFRLFdBQVUsR0FBSTtBQUM3QixjQUFJLEtBQUssUUFBUSxVQUFTLEdBQUk7QUFDNUIsZ0JBQUk7QUFDRixvQkFBTSxXQUFXLEtBQUssUUFBUSxTQUFRO0FBRXRDLG9CQUFNLGNBQ0osU0FBUyxRQUFTLFNBQWlCLFNBQVUsU0FBaUI7QUFFaEUsa0JBQUksYUFBYTtBQUNmLG9CQUFJLFVBQVVBLEtBQUksT0FBTyxJQUFJLFdBQVcsV0FBVyxDQUFDLEVBQUUsWUFBVztBQUVqRSxzQkFBTSxhQUFhLFFBQVEsUUFBUSxZQUFZO0FBQy9DLG9CQUFJLGVBQWUsSUFBSTtBQUNyQiw0QkFBVSxRQUFRLFVBQVUsVUFBVTtnQkFDeEM7QUFFQSxxQkFBSyxhQUFZO0FBQ2pCLHVCQUFPO2NBQ1Q7WUFDRixTQUFTLEdBQUc7QUFDVixzQkFBUSxNQUFNLHlCQUF5QixDQUFDO0FBQ3hDLG1CQUFLLFVBQVUsSUFBSSwwQ0FBMEM7WUFDL0Q7VUFDRixPQUFPO0FBQ0wsaUJBQUssVUFBVSxJQUFJLG9DQUFvQztBQUN2RCxpQkFBSyxhQUFZO1VBQ25CO1FBQ0Y7QUFDQSxlQUFPO01BQ1Q7QUFHQSxVQUFJLE1BQU0sV0FBVyxJQUFJLEdBQUc7QUFDMUIsY0FBTSxXQUFXLE1BQU0sQ0FBQztBQUN4QixjQUFNLFdBQVcsTUFBTSxVQUFVLEdBQUcsQ0FBQztBQUNyQyxjQUFNLFdBQVcsTUFBTSxVQUFVLEdBQUcsQ0FBQztBQUNyQyxjQUFNLFVBQVUsTUFBTSxVQUFVLENBQUM7QUFFakMsY0FBTSxRQUFRLFNBQVMsVUFBVSxFQUFFO0FBQ25DLGNBQU0sUUFBUSxTQUFTLFVBQVUsRUFBRTtBQUVuQyxZQUFJLEtBQUssY0FBYztBQUFHLGVBQUssWUFBWTtBQUUzQyxZQUFJLENBQUMsS0FBSyxVQUFVLElBQUksS0FBSyxHQUFHO0FBQzlCLGVBQUssVUFBVSxJQUFJLE9BQU8sT0FBTztBQUNqQyxlQUFLLGFBQWEsSUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFNBQVM7UUFDNUQ7QUFFQSxZQUFJLEtBQUssVUFBVSxTQUFTLEtBQUssV0FBVztBQUMxQyxjQUFJLGNBQWM7QUFDbEIsbUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxXQUFXLEtBQUs7QUFDdkMsMkJBQWUsS0FBSyxVQUFVLElBQUksQ0FBQztVQUNyQztBQUVBLGNBQUksYUFBYSxLQUFLO0FBQ3BCLGtCQUFNLGFBQWEsS0FBSyxhQUFhLFdBQVc7QUFDaEQsa0JBQU0sZUFBc0IsbUJBQVksVUFBVTtBQUNsRCxpQkFBSyxhQUFZO0FBRWpCLG1CQUFPQSxLQUFJLE9BQU8sWUFBWTtVQUNoQyxPQUFPO0FBQ0wsaUJBQUssYUFBWTtBQUNqQixtQkFBTztVQUNUO1FBQ0Y7QUFDQSxlQUFPO01BQ1Q7QUFFQSxXQUFLLGFBQVk7QUFDakIsYUFBTztJQUNULFNBQVMsR0FBRztBQUNWLGNBQVEsTUFBTSx1QkFBdUIsQ0FBQztBQUN0QyxXQUFLLFVBQVUsSUFBSSwwQ0FBMEM7QUFDN0QsYUFBTztJQUNUO0VBQ0Y7O0VBR1EsYUFBYSxHQUFzQjtBQUN6QyxVQUFNLFdBQVc7QUFDakIsVUFBTSxTQUFTLElBQUksSUFBSSxDQUFDLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLFVBQU0sT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLE9BQU8sSUFBSSxFQUFFLFlBQVcsQ0FBRSxLQUFLLENBQUM7QUFDcEUsVUFBTSxRQUFRLElBQUksV0FBVyxLQUFLLE1BQU8sS0FBSyxTQUFTLElBQUssQ0FBQyxDQUFDO0FBQzlELFFBQUksWUFBWSxHQUNkLFdBQVcsR0FDWCxZQUFZO0FBQ2QsZUFBVyxLQUFLLE1BQU07QUFDcEIsa0JBQWEsYUFBYSxJQUFLO0FBQy9CLGtCQUFZO0FBQ1osVUFBSSxZQUFZLEdBQUc7QUFDakIsY0FBTSxXQUFXLElBQUssYUFBYyxXQUFXLElBQU07QUFDckQsb0JBQVk7TUFDZDtJQUNGO0FBQ0EsV0FBTztFQUNUO0VBRUEsZUFBWTtBQUNWLFNBQUssVUFBVSxJQUFJLFVBQVM7QUFDNUIsU0FBSyxVQUFVLE1BQUs7QUFDcEIsU0FBSyxZQUFZO0FBQ2pCLFNBQUssYUFBYSxJQUFJLENBQUM7RUFDekI7O3FDQXhMVyxZQUFTO0VBQUE7K0VBQVQsWUFBUyxTQUFULFdBQVMsV0FBQSxZQURJLE9BQU0sQ0FBQTs7OytFQUNuQixXQUFTLENBQUE7VUFEckI7V0FBVyxFQUFFLFlBQVksT0FBTSxDQUFFOzs7OztBQ1ZsQzs7MEJBQUFFO0VBQUE7O0FBS0EsU0FBUyxjQUFBQyxhQUFZLFFBQVEsYUFBYSxVQUFBQyxTQUFRLGdCQUFnQjtBQUNsRSxTQUFTLHlCQUF5QjtBQVdsQyxTQUFTLFdBQUFDLGdCQUFlOzs7O0FDSHhCLFNBQVMsY0FBQUMsbUJBQWtCOztBQUVwQixJQUFNLG1CQUFtQjtBQUkxQixJQUFPLDBCQUFQLE1BQU8seUJBQXVCOzs7OztFQUtsQyxPQUFPLFFBQTZEO0FBQ2xFLFdBQU8sSUFBSSxrQkFBa0I7TUFDM0IsUUFBUSxRQUFRLFVBQVUsWUFBWTtNQUN0QyxpQkFBaUIsUUFBUSxtQkFBbUI7S0FDN0M7RUFDSDs7cUNBVlcsMEJBQXVCO0VBQUE7Z0ZBQXZCLDBCQUF1QixTQUF2Qix5QkFBdUIsV0FBQSxZQURWLE9BQU0sQ0FBQTs7O2dGQUNuQix5QkFBdUIsQ0FBQTtVQURuQ0M7V0FBVyxFQUFFLFlBQVksT0FBTSxDQUFFOzs7OztBREEzQixJQUFNQyxvQkFBbUI7QUFHMUIsSUFBTyxnQkFBUCxNQUFPLGVBQWE7RUFjeEIsWUFDK0IsWUFDckIsWUFBbUM7QUFEZDtBQUNyQjtBQUVSLFNBQUssWUFBWSxrQkFBa0IsS0FBSyxVQUFVO0FBRWxELFNBQUssTUFBTSxLQUFLLFdBQVcsT0FBTTtBQUNqQyxTQUFLLFFBQVEsS0FBSyxJQUFJO0FBQ3RCLFNBQUssUUFBUSxLQUFLLElBQUk7QUFDdEIsU0FBSyxtQkFBbUIsS0FBSyxJQUFJO0FBQ2pDLFNBQUssdUJBQXNCO0VBQzdCO0VBVitCO0VBQ3JCO0VBZkg7RUFDQztFQUNBO0VBQ0E7RUFFQSxtQkFBbUI7RUFDcEIsaUJBQWlCLElBQUlDLFNBQWdEO0VBQ3BFLGtCQUFpQztFQUNqQyxvQkFBb0I7RUFDcEIsZ0JBQStCO0VBRWhDO0VBZVAseUJBQXNCO0FBQ3BCLFNBQUssSUFBSSxjQUFhLEVBQUcsVUFBVSxDQUFDLFVBQVM7QUFDM0MsV0FBSyxVQUFVLElBQUksS0FBSyxJQUFJLGFBQVksQ0FBRTtJQUM1QyxDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQU8sR0FBRyxnQkFBZ0IsRUFBRSxVQUFVLE1BQUs7QUFDcEQsV0FBSyxPQUFPLElBQUksV0FBVztJQUM3QixDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQ1IsR0FBRyxtQkFBbUIsRUFDdEIsVUFBVSxDQUFDLE1BQU0sS0FBSyxpQkFBaUIsSUFBSSxFQUFFLE9BQU8sQ0FBQztBQUV4RCxTQUFLLE1BQU0sT0FBTyxHQUFHLG1CQUFtQixFQUFFLFVBQVUsQ0FBQyxVQUFTO0FBQzVELFdBQUssT0FBTyxJQUFJLGNBQWM7QUFFOUIsVUFBSSxDQUFDLEtBQUssU0FBUSxHQUFJO0FBQ3BCLG1CQUFXLE1BQUs7QUFDZCxnQkFBTSxtQkFDSixLQUFLLGFBQVksS0FDakIsS0FBSyxZQUFXLEtBQ2hCLEtBQUssV0FBVSxLQUNmLEtBQUssZ0JBQWUsTUFBTztBQUU3QixjQUFJLEtBQUssT0FBTSxNQUFPLGtCQUFrQixDQUFDLGtCQUFrQjtBQUN6RCxpQkFBSyxRQUFRLEtBQUssVUFBUyxHQUFJLFVBQVUsSUFBSSxLQUFLLFdBQVUsQ0FBRTtVQUNoRTtRQUNGLEdBQUcsR0FBSTtNQUNUO0lBQ0YsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsa0JBQWtCLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDdkQsV0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFPLElBQUksaUNBQUssSUFBTCxFQUFRLGNBQWMsRUFBRSxRQUFPLEtBQUssSUFBSztJQUN6RSxDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQU8sR0FBRyx3QkFBd0IsRUFBRSxVQUFVLENBQUMsTUFBSztBQUM3RCxXQUFLLE1BQU0sT0FBTyxDQUFDLE1BQU8sSUFBSSxpQ0FBSyxJQUFMLEVBQVEsVUFBVSxFQUFFLFFBQU8sS0FBSyxJQUFLO0lBQ3JFLENBQUM7QUFFRCxTQUFLLE1BQU0sT0FBTyxHQUFHLHNCQUFzQixFQUFFLFVBQVUsQ0FBQyxNQUFLO0FBQzNELFdBQUssTUFBTSxPQUFPLENBQUMsTUFBTyxJQUFJLGlDQUFLLElBQUwsRUFBUSxVQUFVLEVBQUUsUUFBTyxLQUFLLElBQUs7SUFDckUsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsdUJBQXVCLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDNUQsV0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFPLElBQUksaUNBQUssSUFBTCxFQUFRLGdCQUFnQixFQUFFLFFBQVEsTUFBSyxLQUFLLElBQUs7QUFDL0UsV0FBSyxlQUFlLElBQUksRUFBRSxRQUFRLFFBQVE7SUFDNUMsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcscUJBQXFCLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDMUQsV0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFPLElBQUksaUNBQUssSUFBTCxFQUFRLFdBQVcsRUFBRSxRQUFPLEtBQUssSUFBSztJQUN0RSxDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQU8sR0FBRyx3QkFBd0IsRUFBRSxVQUFVLENBQUMsTUFBSztBQUM3RCxXQUFLLE1BQU0sT0FBTyxDQUFDLE1BQU8sSUFBSSxpQ0FBSyxJQUFMLEVBQVEsY0FBYyxFQUFFLFFBQU8sS0FBSyxJQUFLO0lBQ3pFLENBQUM7QUFFRCxTQUFLLE1BQU0sT0FBTyxHQUFHLGNBQWMsRUFBRSxVQUFVLENBQUMsTUFBSztBQUNuRCxZQUFNLFVBQVUsRUFBRSxXQUFXLENBQUE7QUFDN0IsWUFBTSxXQUFXLFFBQVEsYUFBYSxTQUFZLFFBQVEsV0FBVztBQUVyRSxXQUFLLE1BQU0sT0FBTyxDQUFDLE1BQU8sSUFBSSxpQ0FBSyxJQUFMLEVBQVEsU0FBUSxLQUFLLElBQUs7SUFDMUQsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsYUFBYSxFQUFFLFVBQVUsQ0FBQyxNQUFLO0FBQ2xELFlBQU0sV0FBVyxFQUFFLFNBQVMsYUFBYSxTQUFZLEVBQUUsUUFBUSxXQUFXO0FBQzFFLFdBQUssTUFBTSxPQUFPLENBQUMsTUFBTyxJQUFJLGlDQUFLLElBQUwsRUFBUSxTQUFRLEtBQUssSUFBSztJQUMxRCxDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQU8sR0FBRyx3QkFBd0IsRUFBRSxVQUFVLENBQUMsTUFBSztBQUM3RCxXQUFLLE1BQU0sT0FBTyxDQUFDLE1BQ2pCLElBQUksaUNBQUssSUFBTCxFQUFRLFlBQVksRUFBRSxRQUFRLFlBQVksV0FBVyxFQUFFLFFBQVEsVUFBUyxLQUFLLElBQUk7SUFFekYsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsYUFBYSxFQUFFLFVBQVUsTUFBSztBQUNqRCxXQUFLLFNBQVMsSUFBSSxJQUFJO0FBQ3RCLFlBQU0sY0FBYyxLQUFLLFVBQVMsR0FBSTtBQUN0QyxVQUFJO0FBQWEsYUFBSyxtQkFBbUIsV0FBVztBQUNwRCxXQUFLLFdBQVU7SUFDakIsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDckQsWUFBTSxZQUFZLEVBQUUsUUFBUTtBQUU1QixVQUFJLGNBQWMsVUFBVTtBQUMxQixhQUFLLFlBQVksSUFBSSxJQUFJO0FBQ3pCLGFBQUssV0FBVTtNQUNqQixXQUFXLGNBQWMsYUFBYTtBQUNwQyxhQUFLLGFBQWEsSUFBSSxJQUFJO0FBQzFCLGFBQUssV0FBVTtNQUNqQixXQUFXLGNBQWMsb0JBQW9CO0FBQzNDLGFBQUssa0JBQWtCLEVBQUUsUUFBUTtNQUVuQyxXQUFXLGNBQWMsYUFBYTtBQUNwQyxhQUFLLFdBQVcsSUFBSSxJQUFJO01BQzFCLFdBQVcsY0FBYyxpQkFBaUI7QUFDeEMsWUFBSSxDQUFDLEtBQUssa0JBQWtCO0FBQzFCLGVBQUssZ0JBQWdCLElBQUksd0NBQXdDO0FBQ2pFLGVBQUssV0FBVyxJQUFJO0FBQ3BCLGVBQUs7QUFDTCxlQUFLLGVBQWUsS0FBSyxFQUFFLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxrQkFBaUIsQ0FBRTtRQUNuRjtNQUNGO0lBQ0YsQ0FBQztBQUVELFNBQUssTUFBTSxPQUFPLEdBQUcsa0JBQWtCLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDdkQsVUFBSSxDQUFDLEtBQUssWUFBVyxLQUFNLENBQUMsS0FBSyxXQUFVLEtBQU0sQ0FBQyxLQUFLLGFBQVksR0FBSTtBQUNyRSxhQUFLLGdCQUFnQixJQUFJLEVBQUUsT0FBTztBQUNsQyxhQUFLLFdBQVcsSUFBSTtBQUNwQixhQUFLLFdBQVU7TUFDakI7SUFDRixDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQU8sR0FBRyxlQUFlLEVBQUUsVUFBVSxDQUFDLE1BQUs7QUFDcEQsV0FBSyxVQUFVLElBQUksRUFBRSxPQUFPO0lBQzlCLENBQUM7QUFFRCxTQUFLLE1BQU0sT0FBTyxHQUFHLHNCQUFzQixFQUFFLFVBQVUsQ0FBQyxVQUFTO0FBQy9ELFlBQU0sV0FBVyxNQUFNO0FBQ3ZCLFlBQU0sZ0JBQWdCLENBQUMsQ0FBQyxlQUFlLFFBQVEsZUFBZSxTQUFTLE1BQU0sRUFBRTtBQUUvRSxVQUFJLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxpQkFBZ0IsS0FBTSxDQUFDLGVBQWU7QUFDdkUsYUFBSyxtQkFBbUI7TUFDMUI7SUFDRixDQUFDO0FBRUQsU0FBSyxNQUFNLE9BQU8sR0FBRyx1QkFBdUIsRUFBRSxVQUFVLENBQUMsVUFBUztBQUNoRSxZQUFNLEVBQUUsZUFBZSxhQUFhLFVBQVMsSUFBSyxNQUFNO0FBRXhELFdBQUssTUFBTSxPQUFPLENBQUMsWUFBVztBQUM1QixZQUFJLENBQUM7QUFBUyxpQkFBTztBQUNyQixlQUFPLGlDQUNGLFVBREU7VUFFTCxNQUFNLEtBQUssV0FBVyxRQUFRLE1BQU0sYUFBYTtVQUNqRCxZQUFZLENBQUMsR0FBRyxRQUFRLFlBQVksYUFBYTs7TUFFckQsQ0FBQztBQUVELFVBQUksZUFBZSxXQUFXO0FBQzVCLGFBQUssMEJBQTBCLEtBQUssRUFBRSxhQUFhLFVBQVMsQ0FBRTtNQUNoRTtJQUNGLENBQUM7QUFFRCxTQUFLLE1BQU0sT0FBTyxHQUFHLGFBQWEsRUFBRSxVQUFVLENBQUMsTUFBSztBQUNsRCxZQUFNLFVBQVUsRUFBRTtBQUNsQixXQUFLLEtBQUssSUFBSSxPQUFPO0FBRXJCLFVBQUksQ0FBQyxLQUFLLG9CQUFvQixZQUFZLFNBQVM7QUFDakQsYUFBSyxtQkFBbUI7TUFDMUI7SUFDRixDQUFDO0VBQ0g7RUFFQSxXQUFXLEtBQWtCO0FBQzNCLFNBQUssZ0JBQWdCO0VBQ3ZCO0VBRUEsYUFBMkI7QUFDekIsV0FBTyxLQUFLO0VBQ2Q7RUFFTSxRQUFRLFFBQWdCLEtBQWtCOztBQUM5QyxVQUFJLEtBQUssT0FBTSxNQUFPO0FBQWM7QUFFcEMsV0FBSyxNQUFLO0FBQ1YsV0FBSyxPQUFPLElBQUksWUFBWTtBQUU1QixVQUFJO0FBQ0YsWUFBSSxDQUFDO0FBQUssZ0JBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUVuRCxZQUFJLEtBQUssSUFBSSxNQUFNLFNBQVEsTUFBTyxNQUFNO0FBQ3RDLGVBQUssSUFBSSxXQUFVO0FBQ25CLGdCQUFNLElBQUksUUFBUSxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUM1QztBQUVBLGNBQU0sS0FBSyxJQUFJLFNBQVMsUUFBUSxHQUFHO0FBRW5DLFlBQUksS0FBSyxXQUFXO0FBQ2xCLGdCQUFNLGNBQWMsZUFBZSxRQUFRLGVBQWUsTUFBTSxFQUFFO0FBRWxFLGNBQUksYUFBYTtBQUNmLGdCQUFJO0FBQ0Ysb0JBQU0saUJBQWlCLE1BQU0sS0FBSyxpQkFBaUIsUUFBUSxhQUFhLEdBQUc7QUFDM0Usa0JBQUksZ0JBQWdCO0FBQ2xCLHNCQUFNLEtBQUssSUFBSSxpQkFBaUIsY0FBYztjQUNoRDtZQUNGLFNBQVMsY0FBYztBQUNyQixzQkFBUSxLQUFLLDJEQUEyRDtBQUN4RSw2QkFBZSxXQUFXLGVBQWUsTUFBTSxFQUFFO1lBQ25EO1VBQ0Y7QUFFQSxnQkFBTSxZQUFZLGFBQWEsUUFBUSxnQkFBZ0IsTUFBTSxFQUFFO0FBQy9ELGNBQUksV0FBVztBQUNiLGtCQUFNLEtBQUssSUFBSSxlQUFlLFNBQVM7VUFDekM7UUFDRjtBQUVBLGFBQUssT0FBTyxJQUFJLFdBQVc7TUFDN0IsU0FBUyxHQUFHO0FBQ1YsZ0JBQVEsTUFBTSw4QkFBOEIsQ0FBQztBQUM3QyxhQUFLLE9BQU8sSUFBSSxPQUFPO01BQ3pCO0lBQ0Y7O0VBRU8sYUFBVTtBQUNmLFNBQUssSUFBSSxXQUFVO0FBQ25CLFNBQUssT0FBTyxJQUFJLGNBQWM7RUFDaEM7RUFFTSxXQUNKLFlBQ0EsU0FDQSxXQUFtQixpQkFBZTs7QUFFbEMsYUFBTyxNQUFNLEtBQUssSUFBSSxXQUFXLFlBQVksU0FBUyxRQUFRO0lBQ2hFOztFQUVhLFdBQVcsTUFBWTs7QUFDbEMsWUFBTSxLQUFLLElBQUksWUFBWSxJQUFJO0lBQ2pDOztFQUVhLFlBQVM7O0FBQ3BCLFlBQU0sS0FBSyxJQUFJLFVBQVM7QUFFeEIsWUFBTSxRQUFRLEtBQUssSUFBSSxhQUFZO0FBQ25DLFVBQUksT0FBTztBQUNULHVCQUFlLFdBQVcsZUFBZSxNQUFNLE1BQU0sRUFBRTtBQUN2RCxxQkFBYSxXQUFXLGdCQUFnQixNQUFNLE1BQU0sRUFBRTtNQUN4RDtJQUNGOztFQUVhLGVBQWUsTUFBWTs7QUFDdEMsWUFBTSxRQUFRLEtBQUssSUFBSSxhQUFZO0FBQ25DLFVBQUk7QUFBTyxxQkFBYSxRQUFRLGdCQUFnQixNQUFNLE1BQU0sSUFBSSxJQUFJO0FBRXBFLFlBQU0sS0FBSyxJQUFJLGVBQWUsSUFBSTtJQUNwQzs7RUFFYSxXQUFXLFVBQWlCOztBQUN2QyxZQUFNLEtBQUssSUFBSSxXQUFXLFFBQVE7SUFDcEM7O0VBRWEsZ0JBQWdCLFdBQXFCLFNBQWtCLE9BQUs7O0FBQ3ZFLFlBQU0sS0FBSyxJQUFJLGdCQUFnQixXQUFXLE1BQU07SUFDbEQ7O0VBRU0saUJBQWlCLGFBQW1COztBQUN4QyxXQUFLLElBQUksaUJBQWlCLFdBQVc7SUFDdkM7O0VBRU8sWUFBWSxZQUFvQixhQUFzQixPQUFjO0FBQ3pFLFdBQU8sS0FBSyxJQUFJLFlBQVksWUFBWSxVQUFVO0VBQ3BEO0VBRU0sVUFBVSxRQUFnQixRQUFjOztBQUM1QyxjQUFRLElBQUksNEJBQTRCLFFBQVEsTUFBTTtBQUN0RCxZQUFNLEtBQUssSUFBSSxxQkFBcUIsUUFBUSxNQUFNO0lBQ3BEOztFQUVPLGlCQUF3QjtBQUM3QixXQUFPLEtBQUssSUFBSSxlQUFjO0VBQ2hDO0VBRU8sdUJBQThCO0FBQ25DLFdBQU8sS0FBSyxJQUFJLHFCQUFvQjtFQUN0QztFQUVhLGVBQWUsU0FBeUI7O0FBQ25ELGFBQU8sTUFBTSxLQUFLLElBQUksZUFBZSxPQUFPO0lBQzlDOztFQUVBLGNBQWMsYUFBbUM7QUFDL0MsV0FBTyxhQUFhLFFBQVEsYUFBYSxXQUFXLEVBQUU7RUFDeEQ7RUFFQSxrQkFBa0IsYUFBcUIsT0FBYTtBQUNsRCxpQkFBYSxRQUFRLGFBQWEsV0FBVyxJQUFJLEtBQUs7RUFDeEQ7RUFFQSxzQkFBc0IsYUFBbUI7QUFDdkMsaUJBQWEsV0FBVyxhQUFhLFdBQVcsRUFBRTtFQUNwRDtFQUVhLGtCQUFrQixhQUFxQixPQUFhOztBQUMvRCxZQUFNLFFBQVEsS0FBSyxJQUFJLGFBQVk7QUFDbkMsVUFBSTtBQUFPLHFCQUFhLFFBQVEsZ0JBQWdCLE1BQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxLQUFLO0FBRXBGLFlBQU0sS0FBSyxJQUFJLGVBQWUsYUFBYSxLQUFLO0lBQ2xEOztFQUVBLDJCQUF3QjtBQUN0QixRQUFJLENBQUMsS0FBSyxjQUFhO0FBQUk7QUFDM0IsVUFBTSxRQUFRLEtBQUssVUFBUztBQUM1QixRQUFJLENBQUM7QUFBTztBQUVaLFVBQU0sZ0JBQWdCLE1BQU0sZ0JBQWdCLENBQUE7QUFDNUMsVUFBTSxVQUFVLEtBQUssUUFBTztBQUU1QixZQUFRLFFBQVEsQ0FBQyxXQUFVO0FBQ3pCLFVBQUksY0FBYyxPQUFPLFdBQVcsTUFBTSxRQUFXO0FBQ25ELGNBQU0sWUFBWSxLQUFLLGNBQWMsT0FBTyxXQUFXO0FBQ3ZELFlBQUk7QUFBVyxlQUFLLGtCQUFrQixPQUFPLGFBQWEsU0FBUztNQUNyRTtJQUNGLENBQUM7RUFDSDtFQUVhLGdCQUFnQixZQUFrQjs7QUFDN0MsWUFBTSxjQUFjLEtBQUssSUFBSSxnQ0FBZ0MsVUFBVTtBQUN2RSxVQUFJLENBQUM7QUFBYSxjQUFNLElBQUksTUFBTSx5Q0FBeUM7QUFFM0UsWUFBTSxLQUFLLElBQUksZ0JBQWdCLFlBQVksV0FBVztJQUN4RDs7RUFFQSxnQkFBOEI7QUFDNUIsUUFBSSxLQUFLLEtBQUksTUFBTztBQUFTLGFBQU87QUFDcEMsVUFBTSxRQUFRLEtBQUssVUFBUztBQUM1QixRQUFJLENBQUMsT0FBTztBQUFNLGFBQU87QUFDekIsV0FBTyxVQUFVLFdBQVcsTUFBTSxJQUFJLEdBQUcsT0FBTztFQUNsRDtFQUVBLGVBQTZCO0FBQzNCLFFBQUksS0FBSyxLQUFJLE1BQU87QUFBUyxhQUFPO0FBQ3BDLFVBQU0sUUFBUSxLQUFLLFVBQVM7QUFDNUIsUUFBSSxDQUFDLE9BQU87QUFBTSxhQUFPO0FBQ3pCLFdBQU8sVUFBVSxXQUFXLE1BQU0sSUFBSSxHQUFHLFFBQVE7RUFDbkQ7RUFFQSxXQUFXLE1BQWMsTUFBcUI7QUFDNUMsV0FBTyxVQUFVLE1BQU0sTUFBTSxJQUFJO0VBQ25DO0VBRUEsYUFBYSxZQUEyQjtBQUN0QyxXQUFPLFVBQVUsYUFBYSxVQUFVO0VBQzFDO0VBRWEsc0JBQW1COztBQUM5QixhQUFPLE1BQU0sS0FBSyxJQUFJLG9CQUFtQjtJQUMzQzs7RUFFTyxRQUFLO0FBQ1YsU0FBSyxLQUFLLElBQUksT0FBTztBQUNyQixTQUFLLFNBQVMsSUFBSSxLQUFLO0FBRXZCLFNBQUssZ0JBQWdCLElBQUksSUFBSTtBQUM3QixTQUFLLFlBQVksSUFBSSxLQUFLO0FBQzFCLFNBQUssV0FBVyxJQUFJLEtBQUs7QUFDekIsU0FBSyxhQUFhLElBQUksS0FBSztBQUUzQixTQUFLLGVBQWUsSUFBSSxDQUFBLENBQUU7QUFDMUIsU0FBSyxPQUFPLElBQUksY0FBYztFQUNoQztFQUVRLG1CQUFtQixRQUFjO0FBQ3ZDLGlCQUFhLFdBQVcsZ0JBQWdCLE1BQU0sRUFBRTtBQUNoRCxtQkFBZSxXQUFXLGVBQWUsTUFBTSxFQUFFO0VBQ25EO0VBRU8sWUFBWUM7SUFBeUI7Ozs7OztFQUNyQyxTQUFTQTtJQUE4RDs7Ozs7O0VBQ3ZFLE9BQU9BO0lBQTBCOzs7Ozs7RUFDakMsbUJBQW1CQTtJQUFzQjs7Ozs7O0VBQ3pDLGlCQUFpQkE7SUFBNkQsQ0FBQTs7Ozs7O0VBQzlFLDRCQUE0QixJQUFJRCxTQUFrRDtFQUVsRixhQUFhQztJQUFPOzs7Ozs7RUFDcEIsV0FBV0E7SUFBTzs7Ozs7O0VBQ2xCLGNBQWNBO0lBQU87Ozs7OztFQUNyQixlQUFlQTtJQUFPOzs7Ozs7RUFDdEIsa0JBQWtCQTtJQUFzQjs7Ozs7O0VBRXhDLGdCQUFnQjtJQUFTLE1BQU0sS0FBSyxLQUFJLE1BQU87Ozs7OztFQUUvQyxVQUFVO0lBQVMsTUFBSztBQUM3QixZQUFNLFFBQVEsS0FBSyxVQUFTO0FBQzVCLGFBQU8sS0FBSyxJQUFJLGlCQUFpQixLQUFLO0lBQ3hDOzs7Ozs7RUFFTyxZQUFZO0lBQVMsTUFBSztBQUMvQixZQUFNLFFBQVEsS0FBSyxVQUFTO0FBQzVCLGFBQU8sS0FBSyxJQUFJLGFBQWEsS0FBSztJQUNwQzs7Ozs7O0VBRU8sa0JBQWtCO0lBQVMsTUFBSztBQUNyQyxZQUFNLFFBQVEsS0FBSyxVQUFTO0FBQzVCLGFBQU8sS0FBSyxJQUFJLGFBQWEsS0FBSztJQUNwQzs7Ozs7O0VBRU8sY0FBYztJQUFTLE1BQU0sS0FBSyxRQUFPLEVBQUcsT0FBTyxDQUFDLFdBQVcsT0FBTyxNQUFNLEVBQUU7Ozs7OztFQUU5RSxxQkFBcUI7SUFBUyxNQUFNLEtBQUssWUFBVyxLQUFNLEtBQUssZ0JBQWU7Ozs7Ozs7cUNBamExRSxnQkFBYSx1QkFlZCxXQUFXLEdBQUEsdUJBQUEsdUJBQUEsQ0FBQTtFQUFBO2dGQWZWLGdCQUFhLFNBQWIsZUFBYSxXQUFBLFlBREEsT0FBTSxDQUFBOzs7Z0ZBQ25CLGVBQWEsQ0FBQTtVQUR6QkM7V0FBVyxFQUFFLFlBQVksT0FBTSxDQUFFOztVQWdCN0I7V0FBTyxXQUFXOzs7OztBRXJDdkI7Ozs7U0FBUyxjQUFBQyxtQkFBa0I7O0FBdUJyQixJQUFPLDBCQUFQLE1BQU8seUJBQXVCO0VBQ2xDLFlBQW9CLFFBQXFCO0FBQXJCO0VBQXdCO0VBQXhCOzs7O0VBS3BCLElBQVcsYUFBcUI7QUFDOUIsUUFBSTtBQUNGLGFBQU8sV0FBVyxPQUFPO0lBQzNCLFNBQVMsR0FBRztBQUNWLGFBQU87SUFDVDtFQUNGO0VBRVEsZUFBdUIsT0FBTyxXQUFXLGNBQWMsT0FBTyxTQUFTLFNBQVM7Ozs7RUFLakYsZ0JBQWdCLFFBQXFCO0FBQzFDLFNBQUssZUFBZTtFQUN0Qjs7OztFQUtRLGlCQUFrQztBQUN4QyxVQUFNLFFBQVEsS0FBSyxPQUFPLFVBQVM7QUFDbkMsV0FBTztNQUNMLFFBQVEsT0FBTyxVQUFVO01BQ3pCLFdBQVcsS0FBSyxPQUFPLGlCQUFnQixLQUFNO01BQzdDLE1BQU0sS0FBSyxPQUFPLGNBQWEsSUFBSyxnQkFBZ0IsUUFBUSxVQUFVO01BQ3RFLFNBQVMsT0FBTyxXQUFXO01BQzNCLFdBQVcsS0FBSyxJQUFHOztFQUV2Qjs7OztFQUtRLGNBQWMsUUFBZ0IsU0FBbUI7QUFDdkQsUUFBSSxDQUFDLEtBQUssWUFBWTtBQUNwQjtJQUNGO0FBRUEsUUFBSSxVQUFVLE9BQU8sUUFBUTtBQUMzQixZQUFNLGtCQUFrQixrQ0FDbkIsS0FBSyxlQUFjLElBQ25CO0FBR0wsYUFBTyxPQUFPLFlBQ1o7UUFDRSxNQUFNO1FBQ047UUFDQSxTQUFTO1NBRVgsS0FBSyxZQUFZO0lBRXJCO0VBQ0Y7O0VBSUEsY0FBYyxXQUFtQixTQUF1QjtBQUN0RCxVQUFNLFVBQThCLEVBQUUsV0FBVyxRQUFPO0FBQ3hELFNBQUssY0FBYyxlQUFlLE9BQU87RUFDM0M7RUFFQSxrQkFBa0IsU0FBeUIsT0FBMEI7QUFDbkUsVUFBTSxVQUFpQyxFQUFFLFNBQVMsTUFBSztBQUN2RCxTQUFLLGNBQWMsa0JBQWtCLE9BQU87RUFDOUM7O0VBSUEsZ0JBQWdCLFNBQXNCO0FBQ3BDLFVBQU0sVUFBOEIsRUFBRSxRQUFPO0FBQzdDLFNBQUssY0FBYyxlQUFlLE9BQU87RUFDM0M7RUFFQSxlQUFlLFVBQThDO0FBQzNELFVBQU0sVUFBNkIsRUFBRSxTQUFRO0FBQzdDLFNBQUssY0FBYyxjQUFjLE9BQU87RUFDMUM7RUFFQSxzQkFBc0IsVUFBcUQ7QUFDekUsVUFBTSxVQUFvQyxFQUFFLFNBQVE7QUFDcEQsU0FBSyxjQUFjLHFCQUFxQixPQUFPO0VBQ2pEO0VBRUEscUJBQXFCLE9BQThDO0FBQ2pFLFVBQU0sVUFBbUMsRUFBRSxNQUFLO0FBQ2hELFNBQUssY0FBYyxvQkFBb0IsT0FBTztFQUNoRDtFQUVBLG1CQUFtQixhQUFzQixZQUEwQjtBQUNqRSxVQUFNLFVBQWlDLEVBQUUsYUFBYSxXQUFVO0FBQ2hFLFNBQUssY0FBYyxrQkFBa0IsT0FBTztFQUM5Qzs7RUFJQSwwQkFBMEIsUUFBcUQ7QUFDN0UsU0FBSyxjQUFjLHlCQUF5QixFQUFFLE9BQU0sQ0FBRTtFQUN4RDtFQUVBLHlCQUF5QixZQUFxQixRQUFxQjtBQUNqRSxTQUFLLGNBQWMsd0JBQXdCLEVBQUUsWUFBWSxPQUFNLENBQUU7RUFDbkU7RUFFQSxpQkFBaUIsUUFBNEM7QUFDM0QsU0FBSyxjQUFjLGdCQUFnQixFQUFFLE9BQU0sQ0FBRTtFQUMvQztFQUVBLDJCQUEyQixNQUFrRDtBQUMzRSxTQUFLLGNBQWMsMEJBQTBCLEVBQUUsS0FBSSxDQUFFO0VBQ3ZEO0VBRUEsd0JBQ0UsTUFDQSxTQUNBLFlBQ0s7QUFDTCxTQUFLLGNBQWMsdUJBQXVCLEVBQUUsTUFBTSxTQUFTLFdBQVUsQ0FBRTtFQUN6RTtFQUVBLGtCQUFrQixTQUFzQjtBQUN0QyxTQUFLLGNBQWMsaUJBQWlCLEVBQUUsUUFBTyxDQUFFO0VBQ2pEO0VBRUEsZ0JBQWdCLFFBQWdCLFNBQXNCO0FBQ3BELFNBQUssY0FBYyxlQUFlLEVBQUUsUUFBUSxRQUFPLENBQUU7RUFDdkQ7O0VBR0EseUJBQXlCLFNBT2pCO0FBQ04sU0FBSyxjQUFjLHdCQUF3QixPQUFPO0VBQ3BEOztFQUdBLHdCQUNFLFFBQ0EsZUFDQSxpQkFDQSxhQUNLO0FBQ0wsU0FBSyxjQUFjLHVCQUF1QjtNQUN4QztNQUNBO01BQ0E7TUFDQTtLQUNEO0VBQ0g7O0VBR0Esc0JBQ0UsYUFDQSxhQUNBLGlCQUNBLFlBQ0s7QUFDTCxTQUFLLGNBQWMscUJBQXFCO01BQ3RDO01BQ0E7TUFDQTtNQUNBO0tBQ0Q7RUFDSDtFQUVBLHdCQUNFLFFBQ0EsT0FDQSxhQUNBLGVBQ0s7QUFDTCxTQUFLLGNBQWMsdUJBQXVCLEVBQUUsUUFBUSxPQUFPLGFBQWEsY0FBYSxDQUFFO0VBQ3pGO0VBRUEsa0JBQ0UsV0FDQSxVQUNBLFNBQ0s7QUFDTCxTQUFLLGNBQWMsaUJBQWlCLEVBQUUsV0FBVyxVQUFVLFFBQU8sQ0FBRTtFQUN0RTs7cUNBaE1XLDBCQUF1Qix1QkFBQSxhQUFBLENBQUE7RUFBQTtnRkFBdkIsMEJBQXVCLFNBQXZCLHlCQUF1QixXQUFBLFlBRnRCLE9BQU0sQ0FBQTs7O2dGQUVQLHlCQUF1QixDQUFBO1VBSG5DQztXQUFXO01BQ1YsWUFBWTtLQUNiOzs7IiwibmFtZXMiOlsiVHJhbnNhY3Rpb24iLCJjcnlwdG8iLCJUcmFuc2FjdGlvbiIsImhleCIsImJhc2U2NCIsIlBST1RPQ09MX1ZFUlNJT04iLCJJbmplY3RhYmxlIiwic2lnbmFsIiwiU3ViamVjdCIsIkluamVjdGFibGUiLCJJbmplY3RhYmxlIiwiUFJPVE9DT0xfVkVSU0lPTiIsIlN1YmplY3QiLCJzaWduYWwiLCJJbmplY3RhYmxlIiwiSW5qZWN0YWJsZSIsIkluamVjdGFibGUiXSwiZGVidWdJZCI6IjNjZDQyYTdiLWU4MDctNTZiMC05YjUzLWExODZhMzg4YjQwMyJ9