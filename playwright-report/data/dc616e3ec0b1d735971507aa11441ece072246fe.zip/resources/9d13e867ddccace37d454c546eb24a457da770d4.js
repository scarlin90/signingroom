//#region node_modules/zone.js/fesm2015/zone.js
/**
* @license Angular
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
	enumerable: true,
	configurable: true,
	writable: true,
	value
}) : obj[key] = value;
var __spreadValues = (a, b) => {
	for (var prop in b || (b = {})) if (__hasOwnProp.call(b, prop)) __defNormalProp(a, prop, b[prop]);
	if (__getOwnPropSymbols) {
		for (var prop of __getOwnPropSymbols(b)) if (__propIsEnum.call(b, prop)) __defNormalProp(a, prop, b[prop]);
	}
	return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __publicField = (obj, key, value) => {
	__defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
	return value;
};
var global = globalThis;
function __symbol__(name) {
	return (global["__Zone_symbol_prefix"] || "__zone_symbol__") + name;
}
function initZone() {
	const performance = global["performance"];
	function mark(name) {
		performance && performance["mark"] && performance["mark"](name);
	}
	function performanceMeasure(name, label) {
		performance && performance["measure"] && performance["measure"](name, label);
	}
	mark("Zone");
	const _ZoneImpl = class _ZoneImpl {
		constructor(parent, zoneSpec) {
			__publicField(this, "_parent");
			__publicField(this, "_name");
			__publicField(this, "_properties");
			__publicField(this, "_zoneDelegate");
			this._parent = parent;
			this._name = zoneSpec ? zoneSpec.name || "unnamed" : "<root>";
			this._properties = zoneSpec && zoneSpec.properties || {};
			this._zoneDelegate = new _ZoneDelegate(this, this._parent && this._parent._zoneDelegate, zoneSpec);
		}
		static assertZonePatched() {
			if (global["Promise"] !== patches["ZoneAwarePromise"]) throw new Error("Zone.js has detected that ZoneAwarePromise `(window|global).Promise` has been overwritten.\nMost likely cause is that a Promise polyfill has been loaded after Zone.js (Polyfilling Promise api is not necessary when zone.js is loaded. If you must load one, do so before loading zone.js.)");
		}
		static get root() {
			let zone = _ZoneImpl.current;
			while (zone.parent) zone = zone.parent;
			return zone;
		}
		static get current() {
			return _currentZoneFrame.zone;
		}
		static get currentTask() {
			return _currentTask;
		}
		static __load_patch(name, fn, ignoreDuplicate = false) {
			if (patches.hasOwnProperty(name)) {
				const checkDuplicate = global[__symbol__("forceDuplicateZoneCheck")] === true;
				if (!ignoreDuplicate && checkDuplicate) throw Error("Already loaded patch: " + name);
			} else if (!global["__Zone_disable_" + name]) {
				const perfName = "Zone:" + name;
				mark(perfName);
				patches[name] = fn(global, _ZoneImpl, _api);
				performanceMeasure(perfName, perfName);
			}
		}
		get parent() {
			return this._parent;
		}
		get name() {
			return this._name;
		}
		get(key) {
			const zone = this.getZoneWith(key);
			if (zone) return zone._properties[key];
		}
		getZoneWith(key) {
			let current = this;
			while (current) {
				if (current._properties.hasOwnProperty(key)) return current;
				current = current._parent;
			}
			return null;
		}
		fork(zoneSpec) {
			if (!zoneSpec) throw new Error("ZoneSpec required!");
			return this._zoneDelegate.fork(this, zoneSpec);
		}
		wrap(callback, source) {
			if (typeof callback !== "function") throw new Error("Expecting function got: " + callback);
			const _callback = this._zoneDelegate.intercept(this, callback, source);
			const zone = this;
			return function() {
				return zone.runGuarded(_callback, this, arguments, source);
			};
		}
		run(callback, applyThis, applyArgs, source) {
			_currentZoneFrame = {
				parent: _currentZoneFrame,
				zone: this
			};
			try {
				return this._zoneDelegate.invoke(this, callback, applyThis, applyArgs, source);
			} finally {
				_currentZoneFrame = _currentZoneFrame.parent;
			}
		}
		runGuarded(callback, applyThis = null, applyArgs, source) {
			_currentZoneFrame = {
				parent: _currentZoneFrame,
				zone: this
			};
			try {
				try {
					return this._zoneDelegate.invoke(this, callback, applyThis, applyArgs, source);
				} catch (error) {
					if (this._zoneDelegate.handleError(this, error)) throw error;
				}
			} finally {
				_currentZoneFrame = _currentZoneFrame.parent;
			}
		}
		runTask(task, applyThis, applyArgs) {
			if (task.zone != this) throw new Error("A task can only be run in the zone of creation! (Creation: " + (task.zone || NO_ZONE).name + "; Execution: " + this.name + ")");
			const zoneTask = task;
			const { type, data: { isPeriodic = false, isRefreshable = false } = {} } = task;
			if (task.state === notScheduled && (type === eventTask || type === macroTask)) return;
			const reEntryGuard = task.state != running;
			reEntryGuard && zoneTask._transitionTo(running, scheduled);
			const previousTask = _currentTask;
			_currentTask = zoneTask;
			_currentZoneFrame = {
				parent: _currentZoneFrame,
				zone: this
			};
			try {
				if (type == macroTask && task.data && !isPeriodic && !isRefreshable) task.cancelFn = void 0;
				try {
					return this._zoneDelegate.invokeTask(this, zoneTask, applyThis, applyArgs);
				} catch (error) {
					if (this._zoneDelegate.handleError(this, error)) throw error;
				}
			} finally {
				const state = task.state;
				if (state !== notScheduled && state !== unknown) if (type == eventTask || isPeriodic || isRefreshable && state === scheduling) reEntryGuard && zoneTask._transitionTo(scheduled, running, scheduling);
				else {
					const zoneDelegates = zoneTask._zoneDelegates;
					this._updateTaskCount(zoneTask, -1);
					reEntryGuard && zoneTask._transitionTo(notScheduled, running, notScheduled);
					if (isRefreshable) zoneTask._zoneDelegates = zoneDelegates;
				}
				_currentZoneFrame = _currentZoneFrame.parent;
				_currentTask = previousTask;
			}
		}
		scheduleTask(task) {
			if (task.zone && task.zone !== this) {
				let newZone = this;
				while (newZone) {
					if (newZone === task.zone) throw Error(`can not reschedule task to ${this.name} which is descendants of the original zone ${task.zone.name}`);
					newZone = newZone.parent;
				}
			}
			task._transitionTo(scheduling, notScheduled);
			const zoneDelegates = [];
			task._zoneDelegates = zoneDelegates;
			task._zone = this;
			try {
				task = this._zoneDelegate.scheduleTask(this, task);
			} catch (err) {
				task._transitionTo(unknown, scheduling, notScheduled);
				this._zoneDelegate.handleError(this, err);
				throw err;
			}
			if (task._zoneDelegates === zoneDelegates) this._updateTaskCount(task, 1);
			if (task.state == scheduling) task._transitionTo(scheduled, scheduling);
			return task;
		}
		scheduleMicroTask(source, callback, data, customSchedule) {
			return this.scheduleTask(new ZoneTask(microTask, source, callback, data, customSchedule, void 0));
		}
		scheduleMacroTask(source, callback, data, customSchedule, customCancel) {
			return this.scheduleTask(new ZoneTask(macroTask, source, callback, data, customSchedule, customCancel));
		}
		scheduleEventTask(source, callback, data, customSchedule, customCancel) {
			return this.scheduleTask(new ZoneTask(eventTask, source, callback, data, customSchedule, customCancel));
		}
		cancelTask(task) {
			if (task.zone != this) throw new Error("A task can only be cancelled in the zone of creation! (Creation: " + (task.zone || NO_ZONE).name + "; Execution: " + this.name + ")");
			if (task.state !== scheduled && task.state !== running) return;
			task._transitionTo(canceling, scheduled, running);
			try {
				this._zoneDelegate.cancelTask(this, task);
			} catch (err) {
				task._transitionTo(unknown, canceling);
				this._zoneDelegate.handleError(this, err);
				throw err;
			}
			this._updateTaskCount(task, -1);
			task._transitionTo(notScheduled, canceling);
			task.runCount = -1;
			return task;
		}
		_updateTaskCount(task, count) {
			const zoneDelegates = task._zoneDelegates;
			if (count == -1) task._zoneDelegates = null;
			for (let i = 0; i < zoneDelegates.length; i++) zoneDelegates[i]._updateTaskCount(task.type, count);
		}
	};
	__publicField(_ZoneImpl, "__symbol__", __symbol__);
	let ZoneImpl = _ZoneImpl;
	const DELEGATE_ZS = {
		name: "",
		onHasTask: (delegate, _, target, hasTaskState) => delegate.hasTask(target, hasTaskState),
		onScheduleTask: (delegate, _, target, task) => delegate.scheduleTask(target, task),
		onInvokeTask: (delegate, _, target, task, applyThis, applyArgs) => delegate.invokeTask(target, task, applyThis, applyArgs),
		onCancelTask: (delegate, _, target, task) => delegate.cancelTask(target, task)
	};
	class _ZoneDelegate {
		constructor(zone, parentDelegate, zoneSpec) {
			__publicField(this, "_zone");
			__publicField(this, "_taskCounts", {
				"microTask": 0,
				"macroTask": 0,
				"eventTask": 0
			});
			__publicField(this, "_forkDlgt");
			__publicField(this, "_forkZS");
			__publicField(this, "_forkCurrZone");
			__publicField(this, "_interceptDlgt");
			__publicField(this, "_interceptZS");
			__publicField(this, "_interceptCurrZone");
			__publicField(this, "_invokeDlgt");
			__publicField(this, "_invokeZS");
			__publicField(this, "_invokeCurrZone");
			__publicField(this, "_handleErrorDlgt");
			__publicField(this, "_handleErrorZS");
			__publicField(this, "_handleErrorCurrZone");
			__publicField(this, "_scheduleTaskDlgt");
			__publicField(this, "_scheduleTaskZS");
			__publicField(this, "_scheduleTaskCurrZone");
			__publicField(this, "_invokeTaskDlgt");
			__publicField(this, "_invokeTaskZS");
			__publicField(this, "_invokeTaskCurrZone");
			__publicField(this, "_cancelTaskDlgt");
			__publicField(this, "_cancelTaskZS");
			__publicField(this, "_cancelTaskCurrZone");
			__publicField(this, "_hasTaskDlgt");
			__publicField(this, "_hasTaskDlgtOwner");
			__publicField(this, "_hasTaskZS");
			__publicField(this, "_hasTaskCurrZone");
			this._zone = zone;
			this._forkZS = zoneSpec && (zoneSpec && zoneSpec.onFork ? zoneSpec : parentDelegate._forkZS);
			this._forkDlgt = zoneSpec && (zoneSpec.onFork ? parentDelegate : parentDelegate._forkDlgt);
			this._forkCurrZone = zoneSpec && (zoneSpec.onFork ? this._zone : parentDelegate._forkCurrZone);
			this._interceptZS = zoneSpec && (zoneSpec.onIntercept ? zoneSpec : parentDelegate._interceptZS);
			this._interceptDlgt = zoneSpec && (zoneSpec.onIntercept ? parentDelegate : parentDelegate._interceptDlgt);
			this._interceptCurrZone = zoneSpec && (zoneSpec.onIntercept ? this._zone : parentDelegate._interceptCurrZone);
			this._invokeZS = zoneSpec && (zoneSpec.onInvoke ? zoneSpec : parentDelegate._invokeZS);
			this._invokeDlgt = zoneSpec && (zoneSpec.onInvoke ? parentDelegate : parentDelegate._invokeDlgt);
			this._invokeCurrZone = zoneSpec && (zoneSpec.onInvoke ? this._zone : parentDelegate._invokeCurrZone);
			this._handleErrorZS = zoneSpec && (zoneSpec.onHandleError ? zoneSpec : parentDelegate._handleErrorZS);
			this._handleErrorDlgt = zoneSpec && (zoneSpec.onHandleError ? parentDelegate : parentDelegate._handleErrorDlgt);
			this._handleErrorCurrZone = zoneSpec && (zoneSpec.onHandleError ? this._zone : parentDelegate._handleErrorCurrZone);
			this._scheduleTaskZS = zoneSpec && (zoneSpec.onScheduleTask ? zoneSpec : parentDelegate._scheduleTaskZS);
			this._scheduleTaskDlgt = zoneSpec && (zoneSpec.onScheduleTask ? parentDelegate : parentDelegate._scheduleTaskDlgt);
			this._scheduleTaskCurrZone = zoneSpec && (zoneSpec.onScheduleTask ? this._zone : parentDelegate._scheduleTaskCurrZone);
			this._invokeTaskZS = zoneSpec && (zoneSpec.onInvokeTask ? zoneSpec : parentDelegate._invokeTaskZS);
			this._invokeTaskDlgt = zoneSpec && (zoneSpec.onInvokeTask ? parentDelegate : parentDelegate._invokeTaskDlgt);
			this._invokeTaskCurrZone = zoneSpec && (zoneSpec.onInvokeTask ? this._zone : parentDelegate._invokeTaskCurrZone);
			this._cancelTaskZS = zoneSpec && (zoneSpec.onCancelTask ? zoneSpec : parentDelegate._cancelTaskZS);
			this._cancelTaskDlgt = zoneSpec && (zoneSpec.onCancelTask ? parentDelegate : parentDelegate._cancelTaskDlgt);
			this._cancelTaskCurrZone = zoneSpec && (zoneSpec.onCancelTask ? this._zone : parentDelegate._cancelTaskCurrZone);
			this._hasTaskZS = null;
			this._hasTaskDlgt = null;
			this._hasTaskDlgtOwner = null;
			this._hasTaskCurrZone = null;
			const zoneSpecHasTask = zoneSpec && zoneSpec.onHasTask;
			const parentHasTask = parentDelegate && parentDelegate._hasTaskZS;
			if (zoneSpecHasTask || parentHasTask) {
				this._hasTaskZS = zoneSpecHasTask ? zoneSpec : DELEGATE_ZS;
				this._hasTaskDlgt = parentDelegate;
				this._hasTaskDlgtOwner = this;
				this._hasTaskCurrZone = this._zone;
				if (!zoneSpec.onScheduleTask) {
					this._scheduleTaskZS = DELEGATE_ZS;
					this._scheduleTaskDlgt = parentDelegate;
					this._scheduleTaskCurrZone = this._zone;
				}
				if (!zoneSpec.onInvokeTask) {
					this._invokeTaskZS = DELEGATE_ZS;
					this._invokeTaskDlgt = parentDelegate;
					this._invokeTaskCurrZone = this._zone;
				}
				if (!zoneSpec.onCancelTask) {
					this._cancelTaskZS = DELEGATE_ZS;
					this._cancelTaskDlgt = parentDelegate;
					this._cancelTaskCurrZone = this._zone;
				}
			}
		}
		get zone() {
			return this._zone;
		}
		fork(targetZone, zoneSpec) {
			return this._forkZS ? this._forkZS.onFork(this._forkDlgt, this.zone, targetZone, zoneSpec) : new ZoneImpl(targetZone, zoneSpec);
		}
		intercept(targetZone, callback, source) {
			return this._interceptZS ? this._interceptZS.onIntercept(this._interceptDlgt, this._interceptCurrZone, targetZone, callback, source) : callback;
		}
		invoke(targetZone, callback, applyThis, applyArgs, source) {
			return this._invokeZS ? this._invokeZS.onInvoke(this._invokeDlgt, this._invokeCurrZone, targetZone, callback, applyThis, applyArgs, source) : callback.apply(applyThis, applyArgs);
		}
		handleError(targetZone, error) {
			return this._handleErrorZS ? this._handleErrorZS.onHandleError(this._handleErrorDlgt, this._handleErrorCurrZone, targetZone, error) : true;
		}
		scheduleTask(targetZone, task) {
			let returnTask = task;
			if (this._scheduleTaskZS) {
				if (this._hasTaskZS) returnTask._zoneDelegates.push(this._hasTaskDlgtOwner);
				returnTask = this._scheduleTaskZS.onScheduleTask(this._scheduleTaskDlgt, this._scheduleTaskCurrZone, targetZone, task);
				if (!returnTask) returnTask = task;
			} else if (task.scheduleFn) task.scheduleFn(task);
			else if (task.type == microTask) scheduleMicroTask(task);
			else throw new Error("Task is missing scheduleFn.");
			return returnTask;
		}
		invokeTask(targetZone, task, applyThis, applyArgs) {
			return this._invokeTaskZS ? this._invokeTaskZS.onInvokeTask(this._invokeTaskDlgt, this._invokeTaskCurrZone, targetZone, task, applyThis, applyArgs) : task.callback.apply(applyThis, applyArgs);
		}
		cancelTask(targetZone, task) {
			let value;
			if (this._cancelTaskZS) value = this._cancelTaskZS.onCancelTask(this._cancelTaskDlgt, this._cancelTaskCurrZone, targetZone, task);
			else {
				if (!task.cancelFn) throw Error("Task is not cancelable");
				value = task.cancelFn(task);
			}
			return value;
		}
		hasTask(targetZone, isEmpty) {
			try {
				this._hasTaskZS && this._hasTaskZS.onHasTask(this._hasTaskDlgt, this._hasTaskCurrZone, targetZone, isEmpty);
			} catch (err) {
				this.handleError(targetZone, err);
			}
		}
		_updateTaskCount(type, count) {
			const counts = this._taskCounts;
			const prev = counts[type];
			const next = counts[type] = prev + count;
			if (next < 0) throw new Error("More tasks executed then were scheduled.");
			if (prev == 0 || next == 0) {
				const isEmpty = {
					microTask: counts["microTask"] > 0,
					macroTask: counts["macroTask"] > 0,
					eventTask: counts["eventTask"] > 0,
					change: type
				};
				this.hasTask(this._zone, isEmpty);
			}
		}
	}
	class ZoneTask {
		constructor(type, source, callback, options, scheduleFn, cancelFn) {
			__publicField(this, "type");
			__publicField(this, "source");
			__publicField(this, "invoke");
			__publicField(this, "callback");
			__publicField(this, "data");
			__publicField(this, "scheduleFn");
			__publicField(this, "cancelFn");
			__publicField(this, "_zone", null);
			__publicField(this, "runCount", 0);
			__publicField(this, "_zoneDelegates", null);
			__publicField(this, "_state", "notScheduled");
			this.type = type;
			this.source = source;
			this.data = options;
			this.scheduleFn = scheduleFn;
			this.cancelFn = cancelFn;
			if (!callback) throw new Error("callback is not defined");
			this.callback = callback;
			const self2 = this;
			if (type === eventTask && options && options.useG) this.invoke = ZoneTask.invokeTask;
			else this.invoke = function() {
				return ZoneTask.invokeTask.call(global, self2, this, arguments);
			};
		}
		static invokeTask(task, target, args) {
			if (!task) task = this;
			_numberOfNestedTaskFrames++;
			try {
				task.runCount++;
				return task.zone.runTask(task, target, args);
			} finally {
				if (_numberOfNestedTaskFrames === 1 && !global[enableNativeMicrotaskDraining]) drainMicroTaskQueueSynchronously();
				_numberOfNestedTaskFrames--;
			}
		}
		get zone() {
			return this._zone;
		}
		get state() {
			return this._state;
		}
		cancelScheduleRequest() {
			this._transitionTo(notScheduled, scheduling);
		}
		_transitionTo(toState, fromState1, fromState2) {
			if (this._state === fromState1 || this._state === fromState2) {
				this._state = toState;
				if (toState == notScheduled) this._zoneDelegates = null;
			} else throw new Error(`${this.type} '${this.source}': can not transition to '${toState}', expecting state '${fromState1}'${fromState2 ? " or '" + fromState2 + "'" : ""}, was '${this._state}'.`);
		}
		toString() {
			if (this.data && typeof this.data.handleId !== "undefined") return this.data.handleId.toString();
			else return Object.prototype.toString.call(this);
		}
		toJSON() {
			return {
				type: this.type,
				state: this.state,
				source: this.source,
				zone: this.zone.name,
				runCount: this.runCount
			};
		}
	}
	const symbolSetTimeout = __symbol__("setTimeout");
	const symbolPromise = __symbol__("Promise");
	const symbolThen = __symbol__("then");
	const enableNativeMicrotaskDraining = __symbol__("enable_native_microtask_draining");
	let _microTaskQueue = [];
	let _isDrainingMicrotaskQueue = false;
	let nativeMicroTaskQueuePromise;
	function nativeScheduleMicroTask(func) {
		var _a;
		if (!nativeMicroTaskQueuePromise && global[symbolPromise]) nativeMicroTaskQueuePromise = global[symbolPromise].resolve(0);
		if (nativeMicroTaskQueuePromise) ((_a = nativeMicroTaskQueuePromise[symbolThen]) != null ? _a : nativeMicroTaskQueuePromise["then"]).call(nativeMicroTaskQueuePromise, func);
		else global[symbolSetTimeout](func, 0);
	}
	function scheduleMicroTask(task) {
		const isNativeDrainingEnabled = global[enableNativeMicrotaskDraining];
		const shouldDrainWithNative = isNativeDrainingEnabled && _microTaskQueue.length === 0 && !_isDrainingMicrotaskQueue;
		const shouldDrainWithoutNative = !isNativeDrainingEnabled && _numberOfNestedTaskFrames === 0 && _microTaskQueue.length === 0;
		if (shouldDrainWithNative || shouldDrainWithoutNative) nativeScheduleMicroTask(drainMicroTaskQueueSynchronously);
		if (task) _microTaskQueue.push(task);
	}
	function drainMicroTaskQueueSynchronously() {
		if (_isDrainingMicrotaskQueue) return;
		_isDrainingMicrotaskQueue = true;
		while (_microTaskQueue.length) {
			const queue = _microTaskQueue;
			_microTaskQueue = [];
			for (const task of queue) try {
				task.zone.runTask(task, null, null);
			} catch (error) {
				_api.onUnhandledError(error);
			}
		}
		if (global[enableNativeMicrotaskDraining]) {
			_isDrainingMicrotaskQueue = false;
			_api.microtaskDrainDone();
		} else {
			_api.microtaskDrainDone();
			_isDrainingMicrotaskQueue = false;
		}
	}
	const NO_ZONE = { name: "NO ZONE" };
	const notScheduled = "notScheduled", scheduling = "scheduling", scheduled = "scheduled", running = "running", canceling = "canceling", unknown = "unknown";
	const microTask = "microTask", macroTask = "macroTask", eventTask = "eventTask";
	const patches = {};
	const _api = {
		symbol: __symbol__,
		currentZoneFrame: () => _currentZoneFrame,
		onUnhandledError: noop,
		microtaskDrainDone: noop,
		scheduleMicroTask,
		showUncaughtError: () => !ZoneImpl[__symbol__("ignoreConsoleErrorUncaughtError")],
		patchEventTarget: () => [],
		patchOnProperties: noop,
		patchMethod: () => noop,
		bindArguments: () => [],
		patchThen: () => noop,
		patchMacroTask: () => noop,
		patchEventPrototype: () => noop,
		getGlobalObjects: () => void 0,
		ObjectDefineProperty: () => noop,
		ObjectGetOwnPropertyDescriptor: () => void 0,
		ObjectCreate: () => void 0,
		ArraySlice: () => [],
		patchClass: () => noop,
		wrapWithCurrentZone: () => noop,
		filterProperties: () => [],
		attachOriginToPatched: () => noop,
		_redefineProperty: () => noop,
		patchCallbacks: () => noop,
		nativeScheduleMicroTask
	};
	let _currentZoneFrame = {
		parent: null,
		zone: new ZoneImpl(null, null)
	};
	let _currentTask = null;
	let _numberOfNestedTaskFrames = 0;
	function noop() {}
	performanceMeasure("Zone", "Zone");
	return ZoneImpl;
}
function loadZone() {
	const global2 = globalThis;
	const checkDuplicate = global2[__symbol__("forceDuplicateZoneCheck")] === true;
	if (global2["Zone"] && (checkDuplicate || typeof global2["Zone"].__symbol__ !== "function")) throw new Error("Zone already loaded.");
	global2["Zone"] != null || (global2["Zone"] = initZone());
	return global2["Zone"];
}
var ObjectGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ObjectDefineProperty = Object.defineProperty;
var ObjectGetPrototypeOf = Object.getPrototypeOf;
var ObjectCreate = Object.create;
var ArraySlice = Array.prototype.slice;
var ADD_EVENT_LISTENER_STR = "addEventListener";
var REMOVE_EVENT_LISTENER_STR = "removeEventListener";
var ZONE_SYMBOL_ADD_EVENT_LISTENER = __symbol__(ADD_EVENT_LISTENER_STR);
var ZONE_SYMBOL_REMOVE_EVENT_LISTENER = __symbol__(REMOVE_EVENT_LISTENER_STR);
var TRUE_STR = "true";
var FALSE_STR = "false";
var ZONE_SYMBOL_PREFIX = __symbol__("");
function wrapWithCurrentZone(callback, source) {
	return Zone.current.wrap(callback, source);
}
function scheduleMacroTaskWithCurrentZone(source, callback, data, customSchedule, customCancel) {
	return Zone.current.scheduleMacroTask(source, callback, data, customSchedule, customCancel);
}
var zoneSymbol = __symbol__;
var isWindowExists = typeof window !== "undefined";
var internalWindow = isWindowExists ? window : void 0;
var _global = isWindowExists && internalWindow || globalThis;
var REMOVE_ATTRIBUTE = "removeAttribute";
function bindArguments(args, source) {
	for (let i = args.length - 1; i >= 0; i--) if (typeof args[i] === "function") args[i] = wrapWithCurrentZone(args[i], source + "_" + i);
	return args;
}
function patchPrototype(prototype, fnNames) {
	const source = prototype.constructor["name"];
	for (let i = 0; i < fnNames.length; i++) {
		const name = fnNames[i];
		const delegate = prototype[name];
		if (delegate) {
			if (!isPropertyWritable(ObjectGetOwnPropertyDescriptor(prototype, name))) continue;
			prototype[name] = ((delegate2) => {
				const patched = function() {
					return delegate2.apply(this, bindArguments(arguments, source + "." + name));
				};
				attachOriginToPatched(patched, delegate2);
				return patched;
			})(delegate);
		}
	}
}
function isPropertyWritable(propertyDesc) {
	if (!propertyDesc) return true;
	if (propertyDesc.writable === false) return false;
	return !(typeof propertyDesc.get === "function" && typeof propertyDesc.set === "undefined");
}
var isWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
var isNode = !("nw" in _global) && typeof _global.process !== "undefined" && _global.process.toString() === "[object process]";
var isBrowser = !isNode && !isWebWorker && !!(isWindowExists && internalWindow["HTMLElement"]);
var isMix = typeof _global.process !== "undefined" && _global.process.toString() === "[object process]" && !isWebWorker && !!(isWindowExists && internalWindow["HTMLElement"]);
var zoneSymbolEventNames = {};
var enableBeforeunloadSymbol = zoneSymbol("enable_beforeunload");
var wrapFn = function(event) {
	event = event || _global.event;
	if (!event) return;
	let eventNameSymbol = zoneSymbolEventNames[event.type];
	if (!eventNameSymbol) eventNameSymbol = zoneSymbolEventNames[event.type] = zoneSymbol("ON_PROPERTY" + event.type);
	const target = this || event.target || _global;
	const listener = target[eventNameSymbol];
	let result;
	if (isBrowser && target === internalWindow && event.type === "error") {
		const errorEvent = event;
		result = listener && listener.call(this, errorEvent.message, errorEvent.filename, errorEvent.lineno, errorEvent.colno, errorEvent.error);
		if (result === true) event.preventDefault();
	} else {
		result = listener && listener.apply(this, arguments);
		if (event.type === "beforeunload" && _global[enableBeforeunloadSymbol] && typeof result === "string") event.returnValue = result;
		else if (result != void 0 && !result) event.preventDefault();
	}
	return result;
};
function patchProperty(obj, prop, prototype) {
	let desc = ObjectGetOwnPropertyDescriptor(obj, prop);
	if (!desc && prototype) {
		if (ObjectGetOwnPropertyDescriptor(prototype, prop)) desc = {
			enumerable: true,
			configurable: true
		};
	}
	if (!desc || !desc.configurable) return;
	const onPropPatchedSymbol = zoneSymbol("on" + prop + "patched");
	if (obj.hasOwnProperty(onPropPatchedSymbol) && obj[onPropPatchedSymbol]) return;
	delete desc.writable;
	delete desc.value;
	const originalDescGet = desc.get;
	const originalDescSet = desc.set;
	const eventName = prop.slice(2);
	let eventNameSymbol = zoneSymbolEventNames[eventName];
	if (!eventNameSymbol) eventNameSymbol = zoneSymbolEventNames[eventName] = zoneSymbol("ON_PROPERTY" + eventName);
	desc.set = function(newValue) {
		let target = this;
		if (!target && obj === _global) target = _global;
		if (!target) return;
		if (typeof target[eventNameSymbol] === "function") target.removeEventListener(eventName, wrapFn);
		originalDescSet == null || originalDescSet.call(target, null);
		target[eventNameSymbol] = newValue;
		if (typeof newValue === "function") target.addEventListener(eventName, wrapFn, false);
	};
	desc.get = function() {
		let target = this;
		if (!target && obj === _global) target = _global;
		if (!target) return null;
		const listener = target[eventNameSymbol];
		if (listener) return listener;
		else if (originalDescGet) {
			let value = originalDescGet.call(this);
			if (value) {
				desc.set.call(this, value);
				if (typeof target[REMOVE_ATTRIBUTE] === "function") target.removeAttribute(prop);
				return value;
			}
		}
		return null;
	};
	ObjectDefineProperty(obj, prop, desc);
	obj[onPropPatchedSymbol] = true;
}
function patchOnProperties(obj, properties, prototype) {
	if (properties) for (let i = 0; i < properties.length; i++) patchProperty(obj, "on" + properties[i], prototype);
	else {
		const onProperties = [];
		for (const prop in obj) if (prop.slice(0, 2) == "on") onProperties.push(prop);
		for (let j = 0; j < onProperties.length; j++) patchProperty(obj, onProperties[j], prototype);
	}
}
var originalInstanceKey = zoneSymbol("originalInstance");
function patchClass(className) {
	const OriginalClass = _global[className];
	if (!OriginalClass) return;
	_global[zoneSymbol(className)] = OriginalClass;
	_global[className] = function() {
		const a = bindArguments(arguments, className);
		switch (a.length) {
			case 0:
				this[originalInstanceKey] = new OriginalClass();
				break;
			case 1:
				this[originalInstanceKey] = new OriginalClass(a[0]);
				break;
			case 2:
				this[originalInstanceKey] = new OriginalClass(a[0], a[1]);
				break;
			case 3:
				this[originalInstanceKey] = new OriginalClass(a[0], a[1], a[2]);
				break;
			case 4:
				this[originalInstanceKey] = new OriginalClass(a[0], a[1], a[2], a[3]);
				break;
			default: throw new Error("Arg list too long.");
		}
	};
	attachOriginToPatched(_global[className], OriginalClass);
	const instance = new OriginalClass(function() {});
	let prop;
	for (prop in instance) {
		if (className === "XMLHttpRequest" && prop === "responseBlob") continue;
		(function(prop2) {
			if (typeof instance[prop2] === "function") _global[className].prototype[prop2] = function() {
				return this[originalInstanceKey][prop2].apply(this[originalInstanceKey], arguments);
			};
			else ObjectDefineProperty(_global[className].prototype, prop2, {
				set: function(fn) {
					if (typeof fn === "function") {
						this[originalInstanceKey][prop2] = wrapWithCurrentZone(fn, className + "." + prop2);
						attachOriginToPatched(this[originalInstanceKey][prop2], fn);
					} else this[originalInstanceKey][prop2] = fn;
				},
				get: function() {
					return this[originalInstanceKey][prop2];
				}
			});
		})(prop);
	}
	for (prop in OriginalClass) if (prop !== "prototype" && OriginalClass.hasOwnProperty(prop)) _global[className][prop] = OriginalClass[prop];
}
function copySymbolProperties(src, dest) {
	if (typeof Object.getOwnPropertySymbols !== "function") return;
	Object.getOwnPropertySymbols(src).forEach((symbol) => {
		const desc = Object.getOwnPropertyDescriptor(src, symbol);
		Object.defineProperty(dest, symbol, {
			get: function() {
				return src[symbol];
			},
			set: function(value) {
				if (desc && (!desc.writable || typeof desc.set !== "function")) return;
				src[symbol] = value;
			},
			enumerable: desc ? desc.enumerable : true,
			configurable: desc ? desc.configurable : true
		});
	});
}
var shouldCopySymbolProperties = false;
function patchMethod(target, name, patchFn) {
	let proto = target;
	while (proto && !proto.hasOwnProperty(name)) proto = ObjectGetPrototypeOf(proto);
	if (!proto && target[name]) proto = target;
	const delegateName = zoneSymbol(name);
	let delegate = null;
	if (proto && (!(delegate = proto[delegateName]) || !proto.hasOwnProperty(delegateName))) {
		delegate = proto[delegateName] = proto[name];
		if (isPropertyWritable(proto && ObjectGetOwnPropertyDescriptor(proto, name))) {
			const patchDelegate = patchFn(delegate, delegateName, name);
			proto[name] = function() {
				return patchDelegate(this, arguments);
			};
			attachOriginToPatched(proto[name], delegate);
			if (shouldCopySymbolProperties) copySymbolProperties(delegate, proto[name]);
		}
	}
	return delegate;
}
function patchMacroTask(obj, funcName, metaCreator) {
	let setNative = null;
	function scheduleTask(task) {
		const data = task.data;
		data.args[data.cbIdx] = function() {
			task.invoke.apply(this, arguments);
		};
		setNative.apply(data.target, data.args);
		return task;
	}
	setNative = patchMethod(obj, funcName, (delegate) => function(self2, args) {
		const meta = metaCreator(self2, args);
		if (meta.cbIdx >= 0 && typeof args[meta.cbIdx] === "function") return scheduleMacroTaskWithCurrentZone(meta.name, args[meta.cbIdx], meta, scheduleTask);
		else return delegate.apply(self2, args);
	});
}
function attachOriginToPatched(patched, original) {
	patched[zoneSymbol("OriginalDelegate")] = original;
}
function isFunction(value) {
	return typeof value === "function";
}
function isNumber(value) {
	return typeof value === "number";
}
var OPTIMIZED_ZONE_EVENT_TASK_DATA = { useG: true };
var zoneSymbolEventNames2 = {};
var globalSources = {};
var EVENT_NAME_SYMBOL_REGX = new RegExp("^" + ZONE_SYMBOL_PREFIX + "(\\w+)(true|false)$");
var IMMEDIATE_PROPAGATION_SYMBOL = zoneSymbol("propagationStopped");
function prepareEventNames(eventName, eventNameToString) {
	const falseEventName = (eventNameToString ? eventNameToString(eventName) : eventName) + FALSE_STR;
	const trueEventName = (eventNameToString ? eventNameToString(eventName) : eventName) + TRUE_STR;
	const symbol = ZONE_SYMBOL_PREFIX + falseEventName;
	const symbolCapture = ZONE_SYMBOL_PREFIX + trueEventName;
	zoneSymbolEventNames2[eventName] = {};
	zoneSymbolEventNames2[eventName][FALSE_STR] = symbol;
	zoneSymbolEventNames2[eventName][TRUE_STR] = symbolCapture;
}
function patchEventTarget(_global2, api, apis, patchOptions) {
	const ADD_EVENT_LISTENER = patchOptions && patchOptions.add || ADD_EVENT_LISTENER_STR;
	const REMOVE_EVENT_LISTENER = patchOptions && patchOptions.rm || REMOVE_EVENT_LISTENER_STR;
	const LISTENERS_EVENT_LISTENER = patchOptions && patchOptions.listeners || "eventListeners";
	const REMOVE_ALL_LISTENERS_EVENT_LISTENER = patchOptions && patchOptions.rmAll || "removeAllListeners";
	const zoneSymbolAddEventListener = zoneSymbol(ADD_EVENT_LISTENER);
	const ADD_EVENT_LISTENER_SOURCE = "." + ADD_EVENT_LISTENER + ":";
	const PREPEND_EVENT_LISTENER = "prependListener";
	const PREPEND_EVENT_LISTENER_SOURCE = ".prependListener:";
	const invokeTask = function(task, target, event) {
		if (task.isRemoved) return;
		const delegate = task.callback;
		if (typeof delegate === "object" && delegate.handleEvent) {
			task.callback = (event2) => delegate.handleEvent(event2);
			task.originalDelegate = delegate;
		}
		let error;
		try {
			task.invoke(task, target, [event]);
		} catch (err) {
			error = err;
		}
		const options = task.options;
		if (options && typeof options === "object" && options.once) {
			const delegate2 = task.originalDelegate ? task.originalDelegate : task.callback;
			target[REMOVE_EVENT_LISTENER].call(target, event.type, delegate2, options);
		}
		return error;
	};
	function globalCallback(context, event, isCapture) {
		event = event || _global2.event;
		if (!event) return;
		const target = context || event.target || _global2;
		const tasks = target[zoneSymbolEventNames2[event.type][isCapture ? TRUE_STR : FALSE_STR]];
		if (tasks) {
			const errors = [];
			if (tasks.length === 1) {
				const err = invokeTask(tasks[0], target, event);
				err && errors.push(err);
			} else {
				const copyTasks = tasks.slice();
				for (let i = 0; i < copyTasks.length; i++) {
					if (event && event[IMMEDIATE_PROPAGATION_SYMBOL] === true) break;
					const err = invokeTask(copyTasks[i], target, event);
					err && errors.push(err);
				}
			}
			if (errors.length === 1) throw errors[0];
			else for (let i = 0; i < errors.length; i++) {
				const err = errors[i];
				api.nativeScheduleMicroTask(() => {
					throw err;
				});
			}
		}
	}
	const globalZoneAwareCallback = function(event) {
		return globalCallback(this, event, false);
	};
	const globalZoneAwareCaptureCallback = function(event) {
		return globalCallback(this, event, true);
	};
	function patchEventTargetMethods(obj, patchOptions2) {
		if (!obj) return false;
		let useGlobalCallback = true;
		if (patchOptions2 && patchOptions2.useG !== void 0) useGlobalCallback = patchOptions2.useG;
		const validateHandler = patchOptions2 && patchOptions2.vh;
		let checkDuplicate = true;
		if (patchOptions2 && patchOptions2.chkDup !== void 0) checkDuplicate = patchOptions2.chkDup;
		let returnTarget = false;
		if (patchOptions2 && patchOptions2.rt !== void 0) returnTarget = patchOptions2.rt;
		let proto = obj;
		while (proto && !proto.hasOwnProperty(ADD_EVENT_LISTENER)) proto = ObjectGetPrototypeOf(proto);
		if (!proto && obj[ADD_EVENT_LISTENER]) proto = obj;
		if (!proto) return false;
		if (proto[zoneSymbolAddEventListener]) return false;
		const eventNameToString = patchOptions2 && patchOptions2.eventNameToString;
		const taskData = {};
		const nativeAddEventListener = proto[zoneSymbolAddEventListener] = proto[ADD_EVENT_LISTENER];
		const nativeRemoveEventListener = proto[zoneSymbol(REMOVE_EVENT_LISTENER)] = proto[REMOVE_EVENT_LISTENER];
		const nativeListeners = proto[zoneSymbol(LISTENERS_EVENT_LISTENER)] = proto[LISTENERS_EVENT_LISTENER];
		const nativeRemoveAllListeners = proto[zoneSymbol(REMOVE_ALL_LISTENERS_EVENT_LISTENER)] = proto[REMOVE_ALL_LISTENERS_EVENT_LISTENER];
		let nativePrependEventListener;
		if (patchOptions2 && patchOptions2.prepend) nativePrependEventListener = proto[zoneSymbol(patchOptions2.prepend)] = proto[patchOptions2.prepend];
		function buildEventListenerOptions(options, passive) {
			if (!passive) return options;
			if (typeof options === "boolean") return {
				capture: options,
				passive: true
			};
			if (!options) return { passive: true };
			if (typeof options === "object" && options.passive !== false) return __spreadProps(__spreadValues({}, options), { passive: true });
			return options;
		}
		const customScheduleGlobal = function(task) {
			if (taskData.isExisting) return;
			return nativeAddEventListener.call(taskData.target, taskData.eventName, taskData.capture ? globalZoneAwareCaptureCallback : globalZoneAwareCallback, taskData.options);
		};
		const customCancelGlobal = function(task) {
			if (!task.isRemoved) {
				const symbolEventNames = zoneSymbolEventNames2[task.eventName];
				let symbolEventName;
				if (symbolEventNames) symbolEventName = symbolEventNames[task.capture ? TRUE_STR : FALSE_STR];
				const existingTasks = symbolEventName && task.target[symbolEventName];
				if (existingTasks) {
					for (let i = 0; i < existingTasks.length; i++) if (existingTasks[i] === task) {
						existingTasks.splice(i, 1);
						task.isRemoved = true;
						if (task.removeAbortListener) {
							task.removeAbortListener();
							task.removeAbortListener = null;
						}
						if (existingTasks.length === 0) {
							task.allRemoved = true;
							task.target[symbolEventName] = null;
						}
						break;
					}
				}
			}
			if (!task.allRemoved) return;
			return nativeRemoveEventListener.call(task.target, task.eventName, task.capture ? globalZoneAwareCaptureCallback : globalZoneAwareCallback, task.options);
		};
		const customScheduleNonGlobal = function(task) {
			return nativeAddEventListener.call(taskData.target, taskData.eventName, task.invoke, taskData.options);
		};
		const customSchedulePrepend = function(task) {
			return nativePrependEventListener.call(taskData.target, taskData.eventName, task.invoke, taskData.options);
		};
		const customCancelNonGlobal = function(task) {
			return nativeRemoveEventListener.call(task.target, task.eventName, task.invoke, task.options);
		};
		const customSchedule = useGlobalCallback ? customScheduleGlobal : customScheduleNonGlobal;
		const customCancel = useGlobalCallback ? customCancelGlobal : customCancelNonGlobal;
		const compareTaskCallbackVsDelegate = function(task, delegate) {
			const typeOfDelegate = typeof delegate;
			return typeOfDelegate === "function" && task.callback === delegate || typeOfDelegate === "object" && task.originalDelegate === delegate;
		};
		const compare = (patchOptions2 == null ? void 0 : patchOptions2.diff) || compareTaskCallbackVsDelegate;
		const unpatchedEvents = Zone[zoneSymbol("UNPATCHED_EVENTS")];
		const passiveEvents = _global2[zoneSymbol("PASSIVE_EVENTS")];
		function copyEventListenerOptions(options) {
			if (typeof options === "object" && options !== null) {
				const newOptions = __spreadValues({}, options);
				if (options.signal) newOptions.signal = options.signal;
				return newOptions;
			}
			return options;
		}
		const makeAddListener = function(nativeListener, addSource, customScheduleFn, customCancelFn, returnTarget2 = false, prepend = false) {
			return function() {
				const target = this || _global2;
				let eventName = arguments[0];
				if (patchOptions2 && patchOptions2.transferEventName) eventName = patchOptions2.transferEventName(eventName);
				let delegate = arguments[1];
				if (!delegate) return nativeListener.apply(this, arguments);
				if (isNode && eventName === "uncaughtException") return nativeListener.apply(this, arguments);
				let isEventListenerObject = false;
				if (typeof delegate !== "function") {
					if (!delegate.handleEvent) return nativeListener.apply(this, arguments);
					isEventListenerObject = true;
				}
				if (validateHandler && !validateHandler(nativeListener, delegate, target, arguments)) return;
				const passive = !!passiveEvents && passiveEvents.indexOf(eventName) !== -1;
				const options = copyEventListenerOptions(buildEventListenerOptions(arguments[2], passive));
				const signal = options == null ? void 0 : options.signal;
				if (signal == null ? void 0 : signal.aborted) return;
				if (unpatchedEvents) {
					for (let i = 0; i < unpatchedEvents.length; i++) if (eventName === unpatchedEvents[i]) if (passive) return nativeListener.call(target, eventName, delegate, options);
					else return nativeListener.apply(this, arguments);
				}
				const capture = !options ? false : typeof options === "boolean" ? true : options.capture;
				const once = options && typeof options === "object" ? options.once : false;
				const zone = Zone.current;
				let symbolEventNames = zoneSymbolEventNames2[eventName];
				if (!symbolEventNames) {
					prepareEventNames(eventName, eventNameToString);
					symbolEventNames = zoneSymbolEventNames2[eventName];
				}
				const symbolEventName = symbolEventNames[capture ? TRUE_STR : FALSE_STR];
				let existingTasks = target[symbolEventName];
				let isExisting = false;
				if (existingTasks) {
					isExisting = true;
					if (checkDuplicate) {
						for (let i = 0; i < existingTasks.length; i++) if (compare(existingTasks[i], delegate)) return;
					}
				} else existingTasks = target[symbolEventName] = [];
				let source;
				const constructorName = target.constructor["name"];
				const targetSource = globalSources[constructorName];
				if (targetSource) source = targetSource[eventName];
				if (!source) source = constructorName + addSource + (eventNameToString ? eventNameToString(eventName) : eventName);
				taskData.options = options;
				if (once) taskData.options.once = false;
				taskData.target = target;
				taskData.capture = capture;
				taskData.eventName = eventName;
				taskData.isExisting = isExisting;
				const data = useGlobalCallback ? OPTIMIZED_ZONE_EVENT_TASK_DATA : void 0;
				if (data) data.taskData = taskData;
				if (signal) taskData.options.signal = void 0;
				const task = zone.scheduleEventTask(source, delegate, data, customScheduleFn, customCancelFn);
				if (signal) {
					taskData.options.signal = signal;
					const onAbort = () => task.zone.cancelTask(task);
					nativeListener.call(signal, "abort", onAbort, { once: true });
					task.removeAbortListener = () => signal.removeEventListener("abort", onAbort);
				}
				taskData.target = null;
				if (data) data.taskData = null;
				if (once) taskData.options.once = true;
				if (typeof task.options !== "boolean") task.options = options;
				task.target = target;
				task.capture = capture;
				task.eventName = eventName;
				if (isEventListenerObject) task.originalDelegate = delegate;
				if (!prepend) existingTasks.push(task);
				else existingTasks.unshift(task);
				if (returnTarget2) return target;
			};
		};
		proto[ADD_EVENT_LISTENER] = makeAddListener(nativeAddEventListener, ADD_EVENT_LISTENER_SOURCE, customSchedule, customCancel, returnTarget);
		if (nativePrependEventListener) proto[PREPEND_EVENT_LISTENER] = makeAddListener(nativePrependEventListener, PREPEND_EVENT_LISTENER_SOURCE, customSchedulePrepend, customCancel, returnTarget, true);
		proto[REMOVE_EVENT_LISTENER] = function() {
			const target = this || _global2;
			let eventName = arguments[0];
			if (patchOptions2 && patchOptions2.transferEventName) eventName = patchOptions2.transferEventName(eventName);
			const options = arguments[2];
			const capture = !options ? false : typeof options === "boolean" ? true : options.capture;
			const delegate = arguments[1];
			if (!delegate) return nativeRemoveEventListener.apply(this, arguments);
			if (validateHandler && !validateHandler(nativeRemoveEventListener, delegate, target, arguments)) return;
			const symbolEventNames = zoneSymbolEventNames2[eventName];
			let symbolEventName;
			if (symbolEventNames) symbolEventName = symbolEventNames[capture ? TRUE_STR : FALSE_STR];
			const existingTasks = symbolEventName && target[symbolEventName];
			if (existingTasks) for (let i = 0; i < existingTasks.length; i++) {
				const existingTask = existingTasks[i];
				if (compare(existingTask, delegate)) {
					existingTasks.splice(i, 1);
					existingTask.isRemoved = true;
					if (existingTasks.length === 0) {
						existingTask.allRemoved = true;
						target[symbolEventName] = null;
						if (!capture && typeof eventName === "string") {
							const onPropertySymbol = ZONE_SYMBOL_PREFIX + "ON_PROPERTY" + eventName;
							target[onPropertySymbol] = null;
						}
					}
					existingTask.zone.cancelTask(existingTask);
					if (returnTarget) return target;
					return;
				}
			}
			return nativeRemoveEventListener.apply(this, arguments);
		};
		proto[LISTENERS_EVENT_LISTENER] = function() {
			const target = this || _global2;
			let eventName = arguments[0];
			if (patchOptions2 && patchOptions2.transferEventName) eventName = patchOptions2.transferEventName(eventName);
			const listeners = [];
			const tasks = findEventTasks(target, eventNameToString ? eventNameToString(eventName) : eventName);
			for (let i = 0; i < tasks.length; i++) {
				const task = tasks[i];
				let delegate = task.originalDelegate ? task.originalDelegate : task.callback;
				listeners.push(delegate);
			}
			return listeners;
		};
		proto[REMOVE_ALL_LISTENERS_EVENT_LISTENER] = function() {
			const target = this || _global2;
			let eventName = arguments[0];
			if (!eventName) {
				const keys = Object.keys(target);
				for (let i = 0; i < keys.length; i++) {
					const prop = keys[i];
					const match = EVENT_NAME_SYMBOL_REGX.exec(prop);
					let evtName = match && match[1];
					if (evtName && evtName !== "removeListener") this[REMOVE_ALL_LISTENERS_EVENT_LISTENER].call(this, evtName);
				}
				this[REMOVE_ALL_LISTENERS_EVENT_LISTENER].call(this, "removeListener");
			} else {
				if (patchOptions2 && patchOptions2.transferEventName) eventName = patchOptions2.transferEventName(eventName);
				const symbolEventNames = zoneSymbolEventNames2[eventName];
				if (symbolEventNames) {
					const symbolEventName = symbolEventNames[FALSE_STR];
					const symbolCaptureEventName = symbolEventNames[TRUE_STR];
					const tasks = target[symbolEventName];
					const captureTasks = target[symbolCaptureEventName];
					if (tasks) {
						const removeTasks = tasks.slice();
						for (let i = 0; i < removeTasks.length; i++) {
							const task = removeTasks[i];
							let delegate = task.originalDelegate ? task.originalDelegate : task.callback;
							this[REMOVE_EVENT_LISTENER].call(this, eventName, delegate, task.options);
						}
					}
					if (captureTasks) {
						const removeTasks = captureTasks.slice();
						for (let i = 0; i < removeTasks.length; i++) {
							const task = removeTasks[i];
							let delegate = task.originalDelegate ? task.originalDelegate : task.callback;
							this[REMOVE_EVENT_LISTENER].call(this, eventName, delegate, task.options);
						}
					}
				}
			}
			if (returnTarget) return this;
		};
		attachOriginToPatched(proto[ADD_EVENT_LISTENER], nativeAddEventListener);
		attachOriginToPatched(proto[REMOVE_EVENT_LISTENER], nativeRemoveEventListener);
		if (nativeRemoveAllListeners) attachOriginToPatched(proto[REMOVE_ALL_LISTENERS_EVENT_LISTENER], nativeRemoveAllListeners);
		if (nativeListeners) attachOriginToPatched(proto[LISTENERS_EVENT_LISTENER], nativeListeners);
		return true;
	}
	let results = [];
	for (let i = 0; i < apis.length; i++) results[i] = patchEventTargetMethods(apis[i], patchOptions);
	return results;
}
function findEventTasks(target, eventName) {
	if (!eventName) {
		const foundTasks = [];
		for (let prop in target) {
			const match = EVENT_NAME_SYMBOL_REGX.exec(prop);
			let evtName = match && match[1];
			if (evtName && (!eventName || evtName === eventName)) {
				const tasks = target[prop];
				if (tasks) for (let i = 0; i < tasks.length; i++) foundTasks.push(tasks[i]);
			}
		}
		return foundTasks;
	}
	let symbolEventName = zoneSymbolEventNames2[eventName];
	if (!symbolEventName) {
		prepareEventNames(eventName);
		symbolEventName = zoneSymbolEventNames2[eventName];
	}
	const captureFalseTasks = target[symbolEventName[FALSE_STR]];
	const captureTrueTasks = target[symbolEventName[TRUE_STR]];
	if (!captureFalseTasks) return captureTrueTasks ? captureTrueTasks.slice() : [];
	else return captureTrueTasks ? captureFalseTasks.concat(captureTrueTasks) : captureFalseTasks.slice();
}
function patchEventPrototype(global2, api) {
	const Event = global2["Event"];
	if (Event && Event.prototype) api.patchMethod(Event.prototype, "stopImmediatePropagation", (delegate) => function(self2, args) {
		self2[IMMEDIATE_PROPAGATION_SYMBOL] = true;
		delegate && delegate.apply(self2, args);
	});
}
function patchQueueMicrotask(global2, api) {
	api.patchMethod(global2, "queueMicrotask", (delegate) => {
		return function(self2, args) {
			Zone.current.scheduleMicroTask("queueMicrotask", args[0]);
		};
	});
}
var taskSymbol = zoneSymbol("zoneTask");
function patchTimer(window2, setName, cancelName, nameSuffix) {
	let setNative = null;
	let clearNative = null;
	setName += nameSuffix;
	cancelName += nameSuffix;
	const tasksByHandleId = {};
	function scheduleTask(task) {
		const data = task.data;
		data.args[0] = function() {
			return task.invoke.apply(this, arguments);
		};
		const handleOrId = setNative.apply(window2, data.args);
		if (isNumber(handleOrId)) data.handleId = handleOrId;
		else {
			data.handle = handleOrId;
			data.isRefreshable = isFunction(handleOrId.refresh);
		}
		return task;
	}
	function clearTask(task) {
		const { handle, handleId } = task.data;
		return clearNative.call(window2, handle != null ? handle : handleId);
	}
	setNative = patchMethod(window2, setName, (delegate) => function(self2, args) {
		var _a;
		if (isFunction(args[0])) {
			const options = {
				isRefreshable: false,
				isPeriodic: nameSuffix === "Interval",
				delay: nameSuffix === "Timeout" || nameSuffix === "Interval" ? args[1] || 0 : void 0,
				args
			};
			const callback = args[0];
			args[0] = function timer() {
				try {
					return callback.apply(this, arguments);
				} finally {
					const { handle: handle2, handleId: handleId2, isPeriodic: isPeriodic2, isRefreshable: isRefreshable2 } = options;
					if (!isPeriodic2 && !isRefreshable2) {
						if (handleId2) delete tasksByHandleId[handleId2];
						else if (handle2) handle2[taskSymbol] = null;
					}
				}
			};
			const task = scheduleMacroTaskWithCurrentZone(setName, args[0], options, scheduleTask, clearTask);
			if (!task) return task;
			const { handleId, handle, isRefreshable, isPeriodic } = task.data;
			if (handleId) tasksByHandleId[handleId] = task;
			else if (handle) {
				handle[taskSymbol] = task;
				if (isRefreshable && !isPeriodic) {
					const originalRefresh = handle.refresh;
					handle.refresh = function() {
						const { zone, state } = task;
						if (state === "notScheduled") {
							task._state = "scheduled";
							zone._updateTaskCount(task, 1);
						} else if (state === "running") task._state = "scheduling";
						return originalRefresh.call(this);
					};
				}
			}
			return (_a = handle != null ? handle : handleId) != null ? _a : task;
		} else return delegate.apply(window2, args);
	});
	clearNative = patchMethod(window2, cancelName, (delegate) => function(self2, args) {
		const id = args[0];
		let task;
		if (isNumber(id)) {
			task = tasksByHandleId[id];
			delete tasksByHandleId[id];
		} else {
			task = id == null ? void 0 : id[taskSymbol];
			if (task) id[taskSymbol] = null;
			else task = id;
		}
		if (task == null ? void 0 : task.type) {
			if (task.cancelFn) task.zone.cancelTask(task);
		} else delegate.apply(window2, args);
	});
}
function patchCustomElements(_global2, api) {
	const { isBrowser: isBrowser2, isMix: isMix2 } = api.getGlobalObjects();
	if (!isBrowser2 && !isMix2 || !_global2["customElements"] || !("customElements" in _global2)) return;
	api.patchCallbacks(api, _global2.customElements, "customElements", "define", [
		"connectedCallback",
		"disconnectedCallback",
		"adoptedCallback",
		"attributeChangedCallback",
		"formAssociatedCallback",
		"formDisabledCallback",
		"formResetCallback",
		"formStateRestoreCallback"
	]);
}
function eventTargetPatch(_global2, api) {
	if (Zone[api.symbol("patchEventTarget")]) return;
	const { eventNames, zoneSymbolEventNames: zoneSymbolEventNames3, TRUE_STR: TRUE_STR2, FALSE_STR: FALSE_STR2, ZONE_SYMBOL_PREFIX: ZONE_SYMBOL_PREFIX2 } = api.getGlobalObjects();
	for (let i = 0; i < eventNames.length; i++) {
		const eventName = eventNames[i];
		const falseEventName = eventName + FALSE_STR2;
		const trueEventName = eventName + TRUE_STR2;
		const symbol = ZONE_SYMBOL_PREFIX2 + falseEventName;
		const symbolCapture = ZONE_SYMBOL_PREFIX2 + trueEventName;
		zoneSymbolEventNames3[eventName] = {};
		zoneSymbolEventNames3[eventName][FALSE_STR2] = symbol;
		zoneSymbolEventNames3[eventName][TRUE_STR2] = symbolCapture;
	}
	const EVENT_TARGET = _global2["EventTarget"];
	if (!EVENT_TARGET || !EVENT_TARGET.prototype) return;
	api.patchEventTarget(_global2, api, [EVENT_TARGET && EVENT_TARGET.prototype]);
	return true;
}
function patchEvent(global2, api) {
	api.patchEventPrototype(global2, api);
}
function filterProperties(target, onProperties, ignoreProperties) {
	if (!ignoreProperties || ignoreProperties.length === 0) return onProperties;
	const tip = ignoreProperties.filter((ip) => ip.target === target);
	if (tip.length === 0) return onProperties;
	const targetIgnoreProperties = tip[0].ignoreProperties;
	return onProperties.filter((op) => targetIgnoreProperties.indexOf(op) === -1);
}
function patchFilteredProperties(target, onProperties, ignoreProperties, prototype) {
	if (!target) return;
	patchOnProperties(target, filterProperties(target, onProperties, ignoreProperties), prototype);
}
function getOnEventNames(target) {
	return Object.getOwnPropertyNames(target).filter((name) => name.startsWith("on") && name.length > 2).map((name) => name.substring(2));
}
function propertyDescriptorPatch(api, _global2) {
	if (isNode && !isMix) return;
	if (Zone[api.symbol("patchEvents")]) return;
	const ignoreProperties = _global2["__Zone_ignore_on_properties"];
	let patchTargets = [];
	if (isBrowser) {
		const internalWindow2 = window;
		patchTargets = patchTargets.concat([
			"Document",
			"SVGElement",
			"Element",
			"HTMLElement",
			"HTMLBodyElement",
			"HTMLMediaElement",
			"HTMLFrameSetElement",
			"HTMLFrameElement",
			"HTMLIFrameElement",
			"HTMLMarqueeElement",
			"Worker"
		]);
		patchFilteredProperties(internalWindow2, getOnEventNames(internalWindow2), ignoreProperties, ObjectGetPrototypeOf(internalWindow2));
	}
	patchTargets = patchTargets.concat([
		"XMLHttpRequest",
		"XMLHttpRequestEventTarget",
		"IDBIndex",
		"IDBRequest",
		"IDBOpenDBRequest",
		"IDBDatabase",
		"IDBTransaction",
		"IDBCursor",
		"WebSocket"
	]);
	for (let i = 0; i < patchTargets.length; i++) {
		const target = _global2[patchTargets[i]];
		target != null && target.prototype && patchFilteredProperties(target.prototype, getOnEventNames(target.prototype), ignoreProperties);
	}
}
function patchBrowser(Zone3) {
	Zone3.__load_patch("timers", (global2) => {
		const set = "set";
		const clear = "clear";
		patchTimer(global2, set, clear, "Timeout");
		patchTimer(global2, set, clear, "Interval");
		patchTimer(global2, set, clear, "Immediate");
	});
	Zone3.__load_patch("requestAnimationFrame", (global2) => {
		patchTimer(global2, "request", "cancel", "AnimationFrame");
		patchTimer(global2, "mozRequest", "mozCancel", "AnimationFrame");
		patchTimer(global2, "webkitRequest", "webkitCancel", "AnimationFrame");
	});
	Zone3.__load_patch("blocking", (global2, Zone4) => {
		const blockingMethods = [
			"alert",
			"prompt",
			"confirm"
		];
		for (let i = 0; i < blockingMethods.length; i++) {
			const name = blockingMethods[i];
			patchMethod(global2, name, (delegate, symbol, name2) => {
				return function(s, args) {
					return Zone4.current.run(delegate, global2, args, name2);
				};
			});
		}
	});
	Zone3.__load_patch("EventTarget", (global2, Zone4, api) => {
		patchEvent(global2, api);
		eventTargetPatch(global2, api);
		const XMLHttpRequestEventTarget = global2["XMLHttpRequestEventTarget"];
		if (XMLHttpRequestEventTarget && XMLHttpRequestEventTarget.prototype) api.patchEventTarget(global2, api, [XMLHttpRequestEventTarget.prototype]);
	});
	Zone3.__load_patch("MutationObserver", (global2, Zone4, api) => {
		patchClass("MutationObserver");
		patchClass("WebKitMutationObserver");
	});
	Zone3.__load_patch("IntersectionObserver", (global2, Zone4, api) => {
		patchClass("IntersectionObserver");
	});
	Zone3.__load_patch("FileReader", (global2, Zone4, api) => {
		patchClass("FileReader");
	});
	Zone3.__load_patch("on_property", (global2, Zone4, api) => {
		propertyDescriptorPatch(api, global2);
	});
	Zone3.__load_patch("customElements", (global2, Zone4, api) => {
		patchCustomElements(global2, api);
	});
	Zone3.__load_patch("XHR", (global2, Zone4) => {
		patchXHR(global2);
		const XHR_TASK = zoneSymbol("xhrTask");
		const XHR_SYNC = zoneSymbol("xhrSync");
		const XHR_LISTENER = zoneSymbol("xhrListener");
		const XHR_SCHEDULED = zoneSymbol("xhrScheduled");
		const XHR_URL = zoneSymbol("xhrURL");
		const XHR_ERROR_BEFORE_SCHEDULED = zoneSymbol("xhrErrorBeforeScheduled");
		function patchXHR(window2) {
			const XMLHttpRequest = window2["XMLHttpRequest"];
			if (!XMLHttpRequest) return;
			const XMLHttpRequestPrototype = XMLHttpRequest.prototype;
			function findPendingTask(target) {
				return target[XHR_TASK];
			}
			let oriAddListener = XMLHttpRequestPrototype[ZONE_SYMBOL_ADD_EVENT_LISTENER];
			let oriRemoveListener = XMLHttpRequestPrototype[ZONE_SYMBOL_REMOVE_EVENT_LISTENER];
			if (!oriAddListener) {
				const XMLHttpRequestEventTarget = window2["XMLHttpRequestEventTarget"];
				if (XMLHttpRequestEventTarget) {
					const XMLHttpRequestEventTargetPrototype = XMLHttpRequestEventTarget.prototype;
					oriAddListener = XMLHttpRequestEventTargetPrototype[ZONE_SYMBOL_ADD_EVENT_LISTENER];
					oriRemoveListener = XMLHttpRequestEventTargetPrototype[ZONE_SYMBOL_REMOVE_EVENT_LISTENER];
				}
			}
			const READY_STATE_CHANGE = "readystatechange";
			const SCHEDULED = "scheduled";
			function scheduleTask(task) {
				const data = task.data;
				const target = data.target;
				target[XHR_SCHEDULED] = false;
				target[XHR_ERROR_BEFORE_SCHEDULED] = false;
				const listener = target[XHR_LISTENER];
				if (!oriAddListener) {
					oriAddListener = target[ZONE_SYMBOL_ADD_EVENT_LISTENER];
					oriRemoveListener = target[ZONE_SYMBOL_REMOVE_EVENT_LISTENER];
				}
				if (listener) oriRemoveListener.call(target, READY_STATE_CHANGE, listener);
				const newListener = target[XHR_LISTENER] = () => {
					if (target.readyState === target.DONE) {
						if (!data.aborted && target[XHR_SCHEDULED] && task.state === SCHEDULED) {
							const loadTasks = target[Zone4.__symbol__("loadfalse")];
							if (target.status !== 0 && loadTasks && loadTasks.length > 0) {
								const oriInvoke = task.invoke;
								task.invoke = function() {
									const loadTasks2 = target[Zone4.__symbol__("loadfalse")];
									for (let i = 0; i < loadTasks2.length; i++) if (loadTasks2[i] === task) loadTasks2.splice(i, 1);
									if (!data.aborted && task.state === SCHEDULED) oriInvoke.call(task);
								};
								loadTasks.push(task);
							} else task.invoke();
						} else if (!data.aborted && target[XHR_SCHEDULED] === false) target[XHR_ERROR_BEFORE_SCHEDULED] = true;
					}
				};
				oriAddListener.call(target, READY_STATE_CHANGE, newListener);
				if (!target[XHR_TASK]) target[XHR_TASK] = task;
				sendNative.apply(target, data.args);
				target[XHR_SCHEDULED] = true;
				return task;
			}
			function placeholderCallback() {}
			function clearTask(task) {
				const data = task.data;
				data.aborted = true;
				return abortNative.apply(data.target, data.args);
			}
			const openNative = patchMethod(XMLHttpRequestPrototype, "open", () => function(self2, args) {
				self2[XHR_SYNC] = args[2] == false;
				self2[XHR_URL] = args[1];
				return openNative.apply(self2, args);
			});
			const XMLHTTPREQUEST_SOURCE = "XMLHttpRequest.send";
			const fetchTaskAborting = zoneSymbol("fetchTaskAborting");
			const fetchTaskScheduling = zoneSymbol("fetchTaskScheduling");
			const sendNative = patchMethod(XMLHttpRequestPrototype, "send", () => function(self2, args) {
				if (Zone4.current[fetchTaskScheduling] === true) return sendNative.apply(self2, args);
				if (self2[XHR_SYNC]) return sendNative.apply(self2, args);
				else {
					const options = {
						target: self2,
						url: self2[XHR_URL],
						isPeriodic: false,
						args,
						aborted: false
					};
					const task = scheduleMacroTaskWithCurrentZone(XMLHTTPREQUEST_SOURCE, placeholderCallback, options, scheduleTask, clearTask);
					if (self2 && self2[XHR_ERROR_BEFORE_SCHEDULED] === true && !options.aborted && task.state === SCHEDULED) task.invoke();
				}
			});
			const abortNative = patchMethod(XMLHttpRequestPrototype, "abort", () => function(self2, args) {
				const task = findPendingTask(self2);
				if (task && typeof task.type == "string") {
					if (task.cancelFn == null || task.data && task.data.aborted) return;
					task.zone.cancelTask(task);
				} else if (Zone4.current[fetchTaskAborting] === true) return abortNative.apply(self2, args);
			});
		}
	});
	Zone3.__load_patch("geolocation", (global2) => {
		if (global2["navigator"] && global2["navigator"].geolocation) patchPrototype(global2["navigator"].geolocation, ["getCurrentPosition", "watchPosition"]);
	});
	Zone3.__load_patch("PromiseRejectionEvent", (global2, Zone4) => {
		function findPromiseRejectionHandler(evtName) {
			return function(e) {
				findEventTasks(global2, evtName).forEach((eventTask) => {
					const PromiseRejectionEvent = global2["PromiseRejectionEvent"];
					if (PromiseRejectionEvent) {
						const evt = new PromiseRejectionEvent(evtName, {
							promise: e.promise,
							reason: e.rejection
						});
						eventTask.invoke(evt);
					}
				});
			};
		}
		if (global2["PromiseRejectionEvent"]) {
			Zone4[zoneSymbol("unhandledPromiseRejectionHandler")] = findPromiseRejectionHandler("unhandledrejection");
			Zone4[zoneSymbol("rejectionHandledHandler")] = findPromiseRejectionHandler("rejectionhandled");
		}
	});
	Zone3.__load_patch("queueMicrotask", (global2, Zone4, api) => {
		patchQueueMicrotask(global2, api);
	});
}
function patchPromise(Zone3) {
	Zone3.__load_patch("ZoneAwarePromise", (global2, Zone4, api) => {
		const ObjectGetOwnPropertyDescriptor2 = Object.getOwnPropertyDescriptor;
		const ObjectDefineProperty2 = Object.defineProperty;
		function readableObjectToString(obj) {
			if (obj && obj.toString === Object.prototype.toString) {
				const className = obj.constructor && obj.constructor.name;
				return (className ? className : "") + ": " + JSON.stringify(obj);
			}
			return obj ? obj.toString() : Object.prototype.toString.call(obj);
		}
		const __symbol__2 = api.symbol;
		const _uncaughtPromiseErrors = [];
		const isDisableWrappingUncaughtPromiseRejection = global2[__symbol__2("DISABLE_WRAPPING_UNCAUGHT_PROMISE_REJECTION")] !== false;
		const symbolPromise = __symbol__2("Promise");
		const symbolThen = __symbol__2("then");
		const creationTrace = "__creationTrace__";
		api.onUnhandledError = (e) => {
			if (api.showUncaughtError()) {
				const rejection = e && e.rejection;
				if (rejection) console.error("Unhandled Promise rejection:", rejection instanceof Error ? rejection.message : rejection, "; Zone:", e.zone.name, "; Task:", e.task && e.task.source, "; Value:", rejection, rejection instanceof Error ? rejection.stack : void 0);
				else console.error(e);
			}
		};
		api.microtaskDrainDone = () => {
			while (_uncaughtPromiseErrors.length) {
				const uncaughtPromiseError = _uncaughtPromiseErrors.shift();
				try {
					uncaughtPromiseError.zone.runGuarded(() => {
						if (uncaughtPromiseError.throwOriginal) throw uncaughtPromiseError.rejection;
						throw uncaughtPromiseError;
					});
				} catch (error) {
					handleUnhandledRejection(error);
				}
			}
		};
		const UNHANDLED_PROMISE_REJECTION_HANDLER_SYMBOL = __symbol__2("unhandledPromiseRejectionHandler");
		function handleUnhandledRejection(e) {
			api.onUnhandledError(e);
			try {
				const handler = Zone4[UNHANDLED_PROMISE_REJECTION_HANDLER_SYMBOL];
				if (typeof handler === "function") handler.call(this, e);
			} catch (err) {}
		}
		function isThenable(value) {
			return value && typeof value.then === "function";
		}
		function forwardResolution(value) {
			return value;
		}
		function forwardRejection(rejection) {
			return ZoneAwarePromise.reject(rejection);
		}
		const symbolState = __symbol__2("state");
		const symbolValue = __symbol__2("value");
		const symbolFinally = __symbol__2("finally");
		const symbolParentPromiseValue = __symbol__2("parentPromiseValue");
		const symbolParentPromiseState = __symbol__2("parentPromiseState");
		const source = "Promise.then";
		const UNRESOLVED = null;
		const RESOLVED = true;
		const REJECTED = false;
		const REJECTED_NO_CATCH = 0;
		function makeResolver(promise, state) {
			return (v) => {
				try {
					resolvePromise(promise, state, v);
				} catch (err) {
					resolvePromise(promise, false, err);
				}
			};
		}
		const once = function() {
			let wasCalled = false;
			return function wrapper(wrappedFunction) {
				return function() {
					if (wasCalled) return;
					wasCalled = true;
					wrappedFunction.apply(null, arguments);
				};
			};
		};
		const TYPE_ERROR = "Promise resolved with itself";
		const CURRENT_TASK_TRACE_SYMBOL = __symbol__2("currentTaskTrace");
		function resolvePromise(promise, state, value) {
			const onceWrapper = once();
			if (promise === value) throw new TypeError(TYPE_ERROR);
			if (promise[symbolState] === UNRESOLVED) {
				let then = null;
				try {
					if (typeof value === "object" || typeof value === "function") then = value && value.then;
				} catch (err) {
					onceWrapper(() => {
						resolvePromise(promise, false, err);
					})();
					return promise;
				}
				if (state !== REJECTED && value instanceof ZoneAwarePromise && value.hasOwnProperty(symbolState) && value.hasOwnProperty(symbolValue) && value[symbolState] !== UNRESOLVED) {
					clearRejectedNoCatch(value);
					resolvePromise(promise, value[symbolState], value[symbolValue]);
				} else if (state !== REJECTED && typeof then === "function") try {
					then.call(value, onceWrapper(makeResolver(promise, state)), onceWrapper(makeResolver(promise, false)));
				} catch (err) {
					onceWrapper(() => {
						resolvePromise(promise, false, err);
					})();
				}
				else {
					promise[symbolState] = state;
					const queue = promise[symbolValue];
					promise[symbolValue] = value;
					if (promise[symbolFinally] === symbolFinally) {
						if (state === RESOLVED) {
							promise[symbolState] = promise[symbolParentPromiseState];
							promise[symbolValue] = promise[symbolParentPromiseValue];
						}
					}
					if (state === REJECTED && value instanceof Error) {
						const trace = Zone4.currentTask && Zone4.currentTask.data && Zone4.currentTask.data[creationTrace];
						if (trace) ObjectDefineProperty2(value, CURRENT_TASK_TRACE_SYMBOL, {
							configurable: true,
							enumerable: false,
							writable: true,
							value: trace
						});
					}
					for (let i = 0; i < queue.length;) scheduleResolveOrReject(promise, queue[i++], queue[i++], queue[i++], queue[i++]);
					if (queue.length == 0 && state == REJECTED) {
						promise[symbolState] = REJECTED_NO_CATCH;
						let uncaughtPromiseError = value;
						try {
							throw new Error("Uncaught (in promise): " + readableObjectToString(value) + (value && value.stack ? "\n" + value.stack : ""));
						} catch (err) {
							uncaughtPromiseError = err;
						}
						if (isDisableWrappingUncaughtPromiseRejection) uncaughtPromiseError.throwOriginal = true;
						uncaughtPromiseError.rejection = value;
						uncaughtPromiseError.promise = promise;
						uncaughtPromiseError.zone = Zone4.current;
						uncaughtPromiseError.task = Zone4.currentTask;
						_uncaughtPromiseErrors.push(uncaughtPromiseError);
						api.scheduleMicroTask();
					}
				}
			}
			return promise;
		}
		const REJECTION_HANDLED_HANDLER = __symbol__2("rejectionHandledHandler");
		function clearRejectedNoCatch(promise) {
			if (promise[symbolState] === REJECTED_NO_CATCH) {
				try {
					const handler = Zone4[REJECTION_HANDLED_HANDLER];
					if (handler && typeof handler === "function") handler.call(this, {
						rejection: promise[symbolValue],
						promise
					});
				} catch (err) {}
				promise[symbolState] = REJECTED;
				for (let i = 0; i < _uncaughtPromiseErrors.length; i++) if (promise === _uncaughtPromiseErrors[i].promise) _uncaughtPromiseErrors.splice(i, 1);
			}
		}
		function scheduleResolveOrReject(promise, zone, chainPromise, onFulfilled, onRejected) {
			clearRejectedNoCatch(promise);
			const promiseState = promise[symbolState];
			const delegate = promiseState ? typeof onFulfilled === "function" ? onFulfilled : forwardResolution : typeof onRejected === "function" ? onRejected : forwardRejection;
			zone.scheduleMicroTask(source, () => {
				try {
					const parentPromiseValue = promise[symbolValue];
					const isFinallyPromise = !!chainPromise && symbolFinally === chainPromise[symbolFinally];
					if (isFinallyPromise) {
						chainPromise[symbolParentPromiseValue] = parentPromiseValue;
						chainPromise[symbolParentPromiseState] = promiseState;
					}
					resolvePromise(chainPromise, true, zone.run(delegate, void 0, isFinallyPromise && delegate !== forwardRejection && delegate !== forwardResolution ? [] : [parentPromiseValue]));
				} catch (error) {
					resolvePromise(chainPromise, false, error);
				}
			}, chainPromise);
		}
		const ZONE_AWARE_PROMISE_TO_STRING = "function ZoneAwarePromise() { [native code] }";
		const noop = function() {};
		const AggregateError = global2.AggregateError;
		class ZoneAwarePromise {
			static toString() {
				return ZONE_AWARE_PROMISE_TO_STRING;
			}
			static resolve(value) {
				if (value instanceof ZoneAwarePromise) return value;
				return resolvePromise(new this(null), RESOLVED, value);
			}
			static reject(error) {
				return resolvePromise(new this(null), REJECTED, error);
			}
			static withResolvers() {
				const result = {};
				result.promise = new ZoneAwarePromise((res, rej) => {
					result.resolve = res;
					result.reject = rej;
				});
				return result;
			}
			static any(values) {
				if (!values || typeof values[Symbol.iterator] !== "function") return Promise.reject(new AggregateError([], "All promises were rejected"));
				const promises = [];
				let count = 0;
				try {
					for (let v of values) {
						count++;
						promises.push(ZoneAwarePromise.resolve(v));
					}
				} catch (err) {
					return Promise.reject(new AggregateError([], "All promises were rejected"));
				}
				if (count === 0) return Promise.reject(new AggregateError([], "All promises were rejected"));
				let finished = false;
				const errors = [];
				return new ZoneAwarePromise((resolve, reject) => {
					for (let i = 0; i < promises.length; i++) promises[i].then((v) => {
						if (finished) return;
						finished = true;
						resolve(v);
					}, (err) => {
						errors.push(err);
						count--;
						if (count === 0) {
							finished = true;
							reject(new AggregateError(errors, "All promises were rejected"));
						}
					});
				});
			}
			static race(values) {
				let resolve;
				let reject;
				let promise = new this((res, rej) => {
					resolve = res;
					reject = rej;
				});
				function onResolve(value) {
					resolve(value);
				}
				function onReject(error) {
					reject(error);
				}
				for (let value of values) {
					if (!isThenable(value)) value = this.resolve(value);
					value.then(onResolve, onReject);
				}
				return promise;
			}
			static all(values) {
				return ZoneAwarePromise.allWithCallback(values);
			}
			static allSettled(values) {
				return (this && this.prototype instanceof ZoneAwarePromise ? this : ZoneAwarePromise).allWithCallback(values, {
					thenCallback: (value) => ({
						status: "fulfilled",
						value
					}),
					errorCallback: (err) => ({
						status: "rejected",
						reason: err
					})
				});
			}
			static allWithCallback(values, callback) {
				let resolve;
				let reject;
				let promise = new this((res, rej) => {
					resolve = res;
					reject = rej;
				});
				let unresolvedCount = 2;
				let valueIndex = 0;
				const resolvedValues = [];
				for (let value of values) {
					if (!isThenable(value)) value = this.resolve(value);
					const curValueIndex = valueIndex;
					try {
						value.then((value2) => {
							resolvedValues[curValueIndex] = callback ? callback.thenCallback(value2) : value2;
							unresolvedCount--;
							if (unresolvedCount === 0) resolve(resolvedValues);
						}, (err) => {
							if (!callback) reject(err);
							else {
								resolvedValues[curValueIndex] = callback.errorCallback(err);
								unresolvedCount--;
								if (unresolvedCount === 0) resolve(resolvedValues);
							}
						});
					} catch (thenErr) {
						reject(thenErr);
					}
					unresolvedCount++;
					valueIndex++;
				}
				unresolvedCount -= 2;
				if (unresolvedCount === 0) resolve(resolvedValues);
				return promise;
			}
			constructor(executor) {
				const promise = this;
				if (!(promise instanceof ZoneAwarePromise)) throw new Error("Must be an instanceof Promise.");
				promise[symbolState] = UNRESOLVED;
				promise[symbolValue] = [];
				try {
					const onceWrapper = once();
					executor && executor(onceWrapper(makeResolver(promise, RESOLVED)), onceWrapper(makeResolver(promise, REJECTED)));
				} catch (error) {
					resolvePromise(promise, false, error);
				}
			}
			get [Symbol.toStringTag]() {
				return "Promise";
			}
			get [Symbol.species]() {
				return ZoneAwarePromise;
			}
			then(onFulfilled, onRejected) {
				var _a;
				let C = (_a = this.constructor) == null ? void 0 : _a[Symbol.species];
				if (!C || typeof C !== "function") C = this.constructor || ZoneAwarePromise;
				const chainPromise = new C(noop);
				const zone = Zone4.current;
				if (this[symbolState] == UNRESOLVED) this[symbolValue].push(zone, chainPromise, onFulfilled, onRejected);
				else scheduleResolveOrReject(this, zone, chainPromise, onFulfilled, onRejected);
				return chainPromise;
			}
			catch(onRejected) {
				return this.then(null, onRejected);
			}
			finally(onFinally) {
				var _a;
				let C = (_a = this.constructor) == null ? void 0 : _a[Symbol.species];
				if (!C || typeof C !== "function") C = ZoneAwarePromise;
				const chainPromise = new C(noop);
				chainPromise[symbolFinally] = symbolFinally;
				const zone = Zone4.current;
				if (this[symbolState] == UNRESOLVED) this[symbolValue].push(zone, chainPromise, onFinally, onFinally);
				else scheduleResolveOrReject(this, zone, chainPromise, onFinally, onFinally);
				return chainPromise;
			}
		}
		ZoneAwarePromise["resolve"] = ZoneAwarePromise.resolve;
		ZoneAwarePromise["reject"] = ZoneAwarePromise.reject;
		ZoneAwarePromise["race"] = ZoneAwarePromise.race;
		ZoneAwarePromise["all"] = ZoneAwarePromise.all;
		const NativePromise = global2[symbolPromise] = global2["Promise"];
		global2["Promise"] = ZoneAwarePromise;
		const symbolThenPatched = __symbol__2("thenPatched");
		function patchThen(Ctor) {
			const proto = Ctor.prototype;
			const prop = ObjectGetOwnPropertyDescriptor2(proto, "then");
			if (prop && (prop.writable === false || !prop.configurable)) return;
			const originalThen = proto.then;
			proto[symbolThen] = originalThen;
			Ctor.prototype.then = function(onResolve, onReject) {
				return new ZoneAwarePromise((resolve, reject) => {
					originalThen.call(this, resolve, reject);
				}).then(onResolve, onReject);
			};
			Ctor[symbolThenPatched] = true;
		}
		api.patchThen = patchThen;
		function zoneify(fn) {
			return function(self2, args) {
				let resultPromise = fn.apply(self2, args);
				if (resultPromise instanceof ZoneAwarePromise) return resultPromise;
				let ctor = resultPromise.constructor;
				if (!ctor[symbolThenPatched]) patchThen(ctor);
				return resultPromise;
			};
		}
		if (NativePromise) {
			patchThen(NativePromise);
			const nativeTry = NativePromise["try"];
			if (nativeTry && typeof nativeTry === "function") ZoneAwarePromise["try"] = nativeTry;
			patchMethod(global2, "fetch", (delegate) => zoneify(delegate));
		}
		Promise[Zone4.__symbol__("uncaughtPromiseErrors")] = _uncaughtPromiseErrors;
		return ZoneAwarePromise;
	});
}
function patchToString(Zone3) {
	Zone3.__load_patch("toString", (global2) => {
		const originalFunctionToString = Function.prototype.toString;
		const ORIGINAL_DELEGATE_SYMBOL = zoneSymbol("OriginalDelegate");
		const PROMISE_SYMBOL = zoneSymbol("Promise");
		const ERROR_SYMBOL = zoneSymbol("Error");
		const newFunctionToString = function toString() {
			if (typeof this === "function") {
				const originalDelegate = this[ORIGINAL_DELEGATE_SYMBOL];
				if (originalDelegate) if (typeof originalDelegate === "function") return originalFunctionToString.call(originalDelegate);
				else return Object.prototype.toString.call(originalDelegate);
				if (this === Promise) {
					const nativePromise = global2[PROMISE_SYMBOL];
					if (nativePromise) return originalFunctionToString.call(nativePromise);
				}
				if (this === Error) {
					const nativeError = global2[ERROR_SYMBOL];
					if (nativeError) return originalFunctionToString.call(nativeError);
				}
			}
			return originalFunctionToString.call(this);
		};
		newFunctionToString[ORIGINAL_DELEGATE_SYMBOL] = originalFunctionToString;
		Function.prototype.toString = newFunctionToString;
		const originalObjectToString = Object.prototype.toString;
		const PROMISE_OBJECT_TO_STRING = "[object Promise]";
		Object.prototype.toString = function() {
			if (typeof Promise === "function" && this instanceof Promise) return PROMISE_OBJECT_TO_STRING;
			return originalObjectToString.call(this);
		};
	});
}
function patchCallbacks(api, target, targetName, method, callbacks) {
	const symbol = Zone.__symbol__(method);
	if (target[symbol]) return;
	const nativeDelegate = target[symbol] = target[method];
	target[method] = function(name, opts, options) {
		if (opts && opts.prototype) callbacks.forEach(function(callback) {
			const source = `${targetName}.${method}::` + callback;
			const prototype = opts.prototype;
			try {
				if (prototype.hasOwnProperty(callback)) {
					const descriptor = api.ObjectGetOwnPropertyDescriptor(prototype, callback);
					if (descriptor && descriptor.value) {
						descriptor.value = api.wrapWithCurrentZone(descriptor.value, source);
						api._redefineProperty(opts.prototype, callback, descriptor);
					} else if (prototype[callback]) prototype[callback] = api.wrapWithCurrentZone(prototype[callback], source);
				} else if (prototype[callback]) prototype[callback] = api.wrapWithCurrentZone(prototype[callback], source);
			} catch (e) {}
		});
		return nativeDelegate.call(target, name, opts, options);
	};
	api.attachOriginToPatched(target[method], nativeDelegate);
}
function patchUtil(Zone3) {
	Zone3.__load_patch("util", (global2, Zone4, api) => {
		const eventNames = getOnEventNames(global2);
		api.patchOnProperties = patchOnProperties;
		api.patchMethod = patchMethod;
		api.bindArguments = bindArguments;
		api.patchMacroTask = patchMacroTask;
		const SYMBOL_BLACK_LISTED_EVENTS = Zone4.__symbol__("BLACK_LISTED_EVENTS");
		const SYMBOL_UNPATCHED_EVENTS = Zone4.__symbol__("UNPATCHED_EVENTS");
		if (global2[SYMBOL_UNPATCHED_EVENTS]) global2[SYMBOL_BLACK_LISTED_EVENTS] = global2[SYMBOL_UNPATCHED_EVENTS];
		if (global2[SYMBOL_BLACK_LISTED_EVENTS]) Zone4[SYMBOL_BLACK_LISTED_EVENTS] = Zone4[SYMBOL_UNPATCHED_EVENTS] = global2[SYMBOL_BLACK_LISTED_EVENTS];
		api.patchEventPrototype = patchEventPrototype;
		api.patchEventTarget = patchEventTarget;
		api.ObjectDefineProperty = ObjectDefineProperty;
		api.ObjectGetOwnPropertyDescriptor = ObjectGetOwnPropertyDescriptor;
		api.ObjectCreate = ObjectCreate;
		api.ArraySlice = ArraySlice;
		api.patchClass = patchClass;
		api.wrapWithCurrentZone = wrapWithCurrentZone;
		api.filterProperties = filterProperties;
		api.attachOriginToPatched = attachOriginToPatched;
		api._redefineProperty = Object.defineProperty;
		api.patchCallbacks = patchCallbacks;
		api.getGlobalObjects = () => ({
			globalSources,
			zoneSymbolEventNames: zoneSymbolEventNames2,
			eventNames,
			isBrowser,
			isMix,
			isNode,
			TRUE_STR,
			FALSE_STR,
			ZONE_SYMBOL_PREFIX,
			ADD_EVENT_LISTENER_STR,
			REMOVE_EVENT_LISTENER_STR
		});
	});
}
function patchCommon(Zone3) {
	patchPromise(Zone3);
	patchToString(Zone3);
	patchUtil(Zone3);
}
var Zone2 = loadZone();
patchCommon(Zone2);
patchBrowser(Zone2);
//#endregion

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiem9uZV9fanMuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzL3pvbmUuanMvZmVzbTIwMTUvem9uZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHN0cmljdCc7XG4vKipcbiAqIEBsaWNlbnNlIEFuZ3VsYXJcbiAqIChjKSAyMDEwLTIwMjYgR29vZ2xlIExMQy4gaHR0cHM6Ly9hbmd1bGFyLmRldi9cbiAqIExpY2Vuc2U6IE1JVFxuICovXG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZGVmUHJvcHMgPSBPYmplY3QuZGVmaW5lUHJvcGVydGllcztcbnZhciBfX2dldE93blByb3BEZXNjcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzO1xudmFyIF9fZ2V0T3duUHJvcFN5bWJvbHMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO1xudmFyIF9faGFzT3duUHJvcCA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgX19wcm9wSXNFbnVtID0gT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcbnZhciBfX2RlZk5vcm1hbFByb3AgPSAob2JqLCBrZXksIHZhbHVlKSA9PiBrZXkgaW4gb2JqID8gX19kZWZQcm9wKG9iaiwga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUsIHZhbHVlIH0pIDogb2JqW2tleV0gPSB2YWx1ZTtcbnZhciBfX3NwcmVhZFZhbHVlcyA9IChhLCBiKSA9PiB7XG4gIGZvciAodmFyIHByb3AgaW4gYiB8fCAoYiA9IHt9KSlcbiAgICBpZiAoX19oYXNPd25Qcm9wLmNhbGwoYiwgcHJvcCkpXG4gICAgICBfX2RlZk5vcm1hbFByb3AoYSwgcHJvcCwgYltwcm9wXSk7XG4gIGlmIChfX2dldE93blByb3BTeW1ib2xzKVxuICAgIGZvciAodmFyIHByb3Agb2YgX19nZXRPd25Qcm9wU3ltYm9scyhiKSkge1xuICAgICAgaWYgKF9fcHJvcElzRW51bS5jYWxsKGIsIHByb3ApKVxuICAgICAgICBfX2RlZk5vcm1hbFByb3AoYSwgcHJvcCwgYltwcm9wXSk7XG4gICAgfVxuICByZXR1cm4gYTtcbn07XG52YXIgX19zcHJlYWRQcm9wcyA9IChhLCBiKSA9PiBfX2RlZlByb3BzKGEsIF9fZ2V0T3duUHJvcERlc2NzKGIpKTtcbnZhciBfX3B1YmxpY0ZpZWxkID0gKG9iaiwga2V5LCB2YWx1ZSkgPT4ge1xuICBfX2RlZk5vcm1hbFByb3Aob2JqLCB0eXBlb2Yga2V5ICE9PSBcInN5bWJvbFwiID8ga2V5ICsgXCJcIiA6IGtleSwgdmFsdWUpO1xuICByZXR1cm4gdmFsdWU7XG59O1xuXG4vLyBwYWNrYWdlcy96b25lLmpzL2xpYi96b25lLWltcGwuanNcbnZhciBnbG9iYWwgPSBnbG9iYWxUaGlzO1xuZnVuY3Rpb24gX19zeW1ib2xfXyhuYW1lKSB7XG4gIGNvbnN0IHN5bWJvbFByZWZpeCA9IGdsb2JhbFtcIl9fWm9uZV9zeW1ib2xfcHJlZml4XCJdIHx8IFwiX196b25lX3N5bWJvbF9fXCI7XG4gIHJldHVybiBzeW1ib2xQcmVmaXggKyBuYW1lO1xufVxuZnVuY3Rpb24gaW5pdFpvbmUoKSB7XG4gIGNvbnN0IHBlcmZvcm1hbmNlID0gZ2xvYmFsW1wicGVyZm9ybWFuY2VcIl07XG4gIGZ1bmN0aW9uIG1hcmsobmFtZSkge1xuICAgIHBlcmZvcm1hbmNlICYmIHBlcmZvcm1hbmNlW1wibWFya1wiXSAmJiBwZXJmb3JtYW5jZVtcIm1hcmtcIl0obmFtZSk7XG4gIH1cbiAgZnVuY3Rpb24gcGVyZm9ybWFuY2VNZWFzdXJlKG5hbWUsIGxhYmVsKSB7XG4gICAgcGVyZm9ybWFuY2UgJiYgcGVyZm9ybWFuY2VbXCJtZWFzdXJlXCJdICYmIHBlcmZvcm1hbmNlW1wibWVhc3VyZVwiXShuYW1lLCBsYWJlbCk7XG4gIH1cbiAgbWFyayhcIlpvbmVcIik7XG4gIGNvbnN0IF9ab25lSW1wbCA9IGNsYXNzIF9ab25lSW1wbCB7XG4gICAgY29uc3RydWN0b3IocGFyZW50LCB6b25lU3BlYykge1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9wYXJlbnRcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX25hbWVcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX3Byb3BlcnRpZXNcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX3pvbmVEZWxlZ2F0ZVwiKTtcbiAgICAgIHRoaXMuX3BhcmVudCA9IHBhcmVudDtcbiAgICAgIHRoaXMuX25hbWUgPSB6b25lU3BlYyA/IHpvbmVTcGVjLm5hbWUgfHwgXCJ1bm5hbWVkXCIgOiBcIjxyb290PlwiO1xuICAgICAgdGhpcy5fcHJvcGVydGllcyA9IHpvbmVTcGVjICYmIHpvbmVTcGVjLnByb3BlcnRpZXMgfHwge307XG4gICAgICB0aGlzLl96b25lRGVsZWdhdGUgPSBuZXcgX1pvbmVEZWxlZ2F0ZSh0aGlzLCB0aGlzLl9wYXJlbnQgJiYgdGhpcy5fcGFyZW50Ll96b25lRGVsZWdhdGUsIHpvbmVTcGVjKTtcbiAgICB9XG4gICAgc3RhdGljIGFzc2VydFpvbmVQYXRjaGVkKCkge1xuICAgICAgaWYgKGdsb2JhbFtcIlByb21pc2VcIl0gIT09IHBhdGNoZXNbXCJab25lQXdhcmVQcm9taXNlXCJdKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlpvbmUuanMgaGFzIGRldGVjdGVkIHRoYXQgWm9uZUF3YXJlUHJvbWlzZSBgKHdpbmRvd3xnbG9iYWwpLlByb21pc2VgIGhhcyBiZWVuIG92ZXJ3cml0dGVuLlxcbk1vc3QgbGlrZWx5IGNhdXNlIGlzIHRoYXQgYSBQcm9taXNlIHBvbHlmaWxsIGhhcyBiZWVuIGxvYWRlZCBhZnRlciBab25lLmpzIChQb2x5ZmlsbGluZyBQcm9taXNlIGFwaSBpcyBub3QgbmVjZXNzYXJ5IHdoZW4gem9uZS5qcyBpcyBsb2FkZWQuIElmIHlvdSBtdXN0IGxvYWQgb25lLCBkbyBzbyBiZWZvcmUgbG9hZGluZyB6b25lLmpzLilcIik7XG4gICAgICB9XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgcm9vdCgpIHtcbiAgICAgIGxldCB6b25lID0gX1pvbmVJbXBsLmN1cnJlbnQ7XG4gICAgICB3aGlsZSAoem9uZS5wYXJlbnQpIHtcbiAgICAgICAgem9uZSA9IHpvbmUucGFyZW50O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHpvbmU7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY3VycmVudCgpIHtcbiAgICAgIHJldHVybiBfY3VycmVudFpvbmVGcmFtZS56b25lO1xuICAgIH1cbiAgICBzdGF0aWMgZ2V0IGN1cnJlbnRUYXNrKCkge1xuICAgICAgcmV0dXJuIF9jdXJyZW50VGFzaztcbiAgICB9XG4gICAgc3RhdGljIF9fbG9hZF9wYXRjaChuYW1lLCBmbiwgaWdub3JlRHVwbGljYXRlID0gZmFsc2UpIHtcbiAgICAgIGlmIChwYXRjaGVzLmhhc093blByb3BlcnR5KG5hbWUpKSB7XG4gICAgICAgIGNvbnN0IGNoZWNrRHVwbGljYXRlID0gZ2xvYmFsW19fc3ltYm9sX18oXCJmb3JjZUR1cGxpY2F0ZVpvbmVDaGVja1wiKV0gPT09IHRydWU7XG4gICAgICAgIGlmICghaWdub3JlRHVwbGljYXRlICYmIGNoZWNrRHVwbGljYXRlKSB7XG4gICAgICAgICAgdGhyb3cgRXJyb3IoXCJBbHJlYWR5IGxvYWRlZCBwYXRjaDogXCIgKyBuYW1lKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICghZ2xvYmFsW1wiX19ab25lX2Rpc2FibGVfXCIgKyBuYW1lXSkge1xuICAgICAgICBjb25zdCBwZXJmTmFtZSA9IFwiWm9uZTpcIiArIG5hbWU7XG4gICAgICAgIG1hcmsocGVyZk5hbWUpO1xuICAgICAgICBwYXRjaGVzW25hbWVdID0gZm4oZ2xvYmFsLCBfWm9uZUltcGwsIF9hcGkpO1xuICAgICAgICBwZXJmb3JtYW5jZU1lYXN1cmUocGVyZk5hbWUsIHBlcmZOYW1lKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZ2V0IHBhcmVudCgpIHtcbiAgICAgIHJldHVybiB0aGlzLl9wYXJlbnQ7XG4gICAgfVxuICAgIGdldCBuYW1lKCkge1xuICAgICAgcmV0dXJuIHRoaXMuX25hbWU7XG4gICAgfVxuICAgIGdldChrZXkpIHtcbiAgICAgIGNvbnN0IHpvbmUgPSB0aGlzLmdldFpvbmVXaXRoKGtleSk7XG4gICAgICBpZiAoem9uZSlcbiAgICAgICAgcmV0dXJuIHpvbmUuX3Byb3BlcnRpZXNba2V5XTtcbiAgICB9XG4gICAgZ2V0Wm9uZVdpdGgoa2V5KSB7XG4gICAgICBsZXQgY3VycmVudCA9IHRoaXM7XG4gICAgICB3aGlsZSAoY3VycmVudCkge1xuICAgICAgICBpZiAoY3VycmVudC5fcHJvcGVydGllcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICAgICAgcmV0dXJuIGN1cnJlbnQ7XG4gICAgICAgIH1cbiAgICAgICAgY3VycmVudCA9IGN1cnJlbnQuX3BhcmVudDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBmb3JrKHpvbmVTcGVjKSB7XG4gICAgICBpZiAoIXpvbmVTcGVjKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJab25lU3BlYyByZXF1aXJlZCFcIik7XG4gICAgICByZXR1cm4gdGhpcy5fem9uZURlbGVnYXRlLmZvcmsodGhpcywgem9uZVNwZWMpO1xuICAgIH1cbiAgICB3cmFwKGNhbGxiYWNrLCBzb3VyY2UpIHtcbiAgICAgIGlmICh0eXBlb2YgY2FsbGJhY2sgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RpbmcgZnVuY3Rpb24gZ290OiBcIiArIGNhbGxiYWNrKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IF9jYWxsYmFjayA9IHRoaXMuX3pvbmVEZWxlZ2F0ZS5pbnRlcmNlcHQodGhpcywgY2FsbGJhY2ssIHNvdXJjZSk7XG4gICAgICBjb25zdCB6b25lID0gdGhpcztcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHpvbmUucnVuR3VhcmRlZChfY2FsbGJhY2ssIHRoaXMsIGFyZ3VtZW50cywgc291cmNlKTtcbiAgICAgIH07XG4gICAgfVxuICAgIHJ1bihjYWxsYmFjaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MsIHNvdXJjZSkge1xuICAgICAgX2N1cnJlbnRab25lRnJhbWUgPSB7IHBhcmVudDogX2N1cnJlbnRab25lRnJhbWUsIHpvbmU6IHRoaXMgfTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiB0aGlzLl96b25lRGVsZWdhdGUuaW52b2tlKHRoaXMsIGNhbGxiYWNrLCBhcHBseVRoaXMsIGFwcGx5QXJncywgc291cmNlKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIF9jdXJyZW50Wm9uZUZyYW1lID0gX2N1cnJlbnRab25lRnJhbWUucGFyZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBydW5HdWFyZGVkKGNhbGxiYWNrLCBhcHBseVRoaXMgPSBudWxsLCBhcHBseUFyZ3MsIHNvdXJjZSkge1xuICAgICAgX2N1cnJlbnRab25lRnJhbWUgPSB7IHBhcmVudDogX2N1cnJlbnRab25lRnJhbWUsIHpvbmU6IHRoaXMgfTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3pvbmVEZWxlZ2F0ZS5pbnZva2UodGhpcywgY2FsbGJhY2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzLCBzb3VyY2UpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGlmICh0aGlzLl96b25lRGVsZWdhdGUuaGFuZGxlRXJyb3IodGhpcywgZXJyb3IpKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIF9jdXJyZW50Wm9uZUZyYW1lID0gX2N1cnJlbnRab25lRnJhbWUucGFyZW50O1xuICAgICAgfVxuICAgIH1cbiAgICBydW5UYXNrKHRhc2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzKSB7XG4gICAgICBpZiAodGFzay56b25lICE9IHRoaXMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQSB0YXNrIGNhbiBvbmx5IGJlIHJ1biBpbiB0aGUgem9uZSBvZiBjcmVhdGlvbiEgKENyZWF0aW9uOiBcIiArICh0YXNrLnpvbmUgfHwgTk9fWk9ORSkubmFtZSArIFwiOyBFeGVjdXRpb246IFwiICsgdGhpcy5uYW1lICsgXCIpXCIpO1xuICAgICAgfVxuICAgICAgY29uc3Qgem9uZVRhc2sgPSB0YXNrO1xuICAgICAgY29uc3QgeyB0eXBlLCBkYXRhOiB7IGlzUGVyaW9kaWMgPSBmYWxzZSwgaXNSZWZyZXNoYWJsZSA9IGZhbHNlIH0gPSB7fSB9ID0gdGFzaztcbiAgICAgIGlmICh0YXNrLnN0YXRlID09PSBub3RTY2hlZHVsZWQgJiYgKHR5cGUgPT09IGV2ZW50VGFzayB8fCB0eXBlID09PSBtYWNyb1Rhc2spKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJlRW50cnlHdWFyZCA9IHRhc2suc3RhdGUgIT0gcnVubmluZztcbiAgICAgIHJlRW50cnlHdWFyZCAmJiB6b25lVGFzay5fdHJhbnNpdGlvblRvKHJ1bm5pbmcsIHNjaGVkdWxlZCk7XG4gICAgICBjb25zdCBwcmV2aW91c1Rhc2sgPSBfY3VycmVudFRhc2s7XG4gICAgICBfY3VycmVudFRhc2sgPSB6b25lVGFzaztcbiAgICAgIF9jdXJyZW50Wm9uZUZyYW1lID0geyBwYXJlbnQ6IF9jdXJyZW50Wm9uZUZyYW1lLCB6b25lOiB0aGlzIH07XG4gICAgICB0cnkge1xuICAgICAgICBpZiAodHlwZSA9PSBtYWNyb1Rhc2sgJiYgdGFzay5kYXRhICYmICFpc1BlcmlvZGljICYmICFpc1JlZnJlc2hhYmxlKSB7XG4gICAgICAgICAgdGFzay5jYW5jZWxGbiA9IHZvaWQgMDtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl96b25lRGVsZWdhdGUuaW52b2tlVGFzayh0aGlzLCB6b25lVGFzaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGlmICh0aGlzLl96b25lRGVsZWdhdGUuaGFuZGxlRXJyb3IodGhpcywgZXJyb3IpKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gdGFzay5zdGF0ZTtcbiAgICAgICAgaWYgKHN0YXRlICE9PSBub3RTY2hlZHVsZWQgJiYgc3RhdGUgIT09IHVua25vd24pIHtcbiAgICAgICAgICBpZiAodHlwZSA9PSBldmVudFRhc2sgfHwgaXNQZXJpb2RpYyB8fCBpc1JlZnJlc2hhYmxlICYmIHN0YXRlID09PSBzY2hlZHVsaW5nKSB7XG4gICAgICAgICAgICByZUVudHJ5R3VhcmQgJiYgem9uZVRhc2suX3RyYW5zaXRpb25UbyhzY2hlZHVsZWQsIHJ1bm5pbmcsIHNjaGVkdWxpbmcpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB6b25lRGVsZWdhdGVzID0gem9uZVRhc2suX3pvbmVEZWxlZ2F0ZXM7XG4gICAgICAgICAgICB0aGlzLl91cGRhdGVUYXNrQ291bnQoem9uZVRhc2ssIC0xKTtcbiAgICAgICAgICAgIHJlRW50cnlHdWFyZCAmJiB6b25lVGFzay5fdHJhbnNpdGlvblRvKG5vdFNjaGVkdWxlZCwgcnVubmluZywgbm90U2NoZWR1bGVkKTtcbiAgICAgICAgICAgIGlmIChpc1JlZnJlc2hhYmxlKSB7XG4gICAgICAgICAgICAgIHpvbmVUYXNrLl96b25lRGVsZWdhdGVzID0gem9uZURlbGVnYXRlcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgX2N1cnJlbnRab25lRnJhbWUgPSBfY3VycmVudFpvbmVGcmFtZS5wYXJlbnQ7XG4gICAgICAgIF9jdXJyZW50VGFzayA9IHByZXZpb3VzVGFzaztcbiAgICAgIH1cbiAgICB9XG4gICAgc2NoZWR1bGVUYXNrKHRhc2spIHtcbiAgICAgIGlmICh0YXNrLnpvbmUgJiYgdGFzay56b25lICE9PSB0aGlzKSB7XG4gICAgICAgIGxldCBuZXdab25lID0gdGhpcztcbiAgICAgICAgd2hpbGUgKG5ld1pvbmUpIHtcbiAgICAgICAgICBpZiAobmV3Wm9uZSA9PT0gdGFzay56b25lKSB7XG4gICAgICAgICAgICB0aHJvdyBFcnJvcihgY2FuIG5vdCByZXNjaGVkdWxlIHRhc2sgdG8gJHt0aGlzLm5hbWV9IHdoaWNoIGlzIGRlc2NlbmRhbnRzIG9mIHRoZSBvcmlnaW5hbCB6b25lICR7dGFzay56b25lLm5hbWV9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG5ld1pvbmUgPSBuZXdab25lLnBhcmVudDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGFzay5fdHJhbnNpdGlvblRvKHNjaGVkdWxpbmcsIG5vdFNjaGVkdWxlZCk7XG4gICAgICBjb25zdCB6b25lRGVsZWdhdGVzID0gW107XG4gICAgICB0YXNrLl96b25lRGVsZWdhdGVzID0gem9uZURlbGVnYXRlcztcbiAgICAgIHRhc2suX3pvbmUgPSB0aGlzO1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGFzayA9IHRoaXMuX3pvbmVEZWxlZ2F0ZS5zY2hlZHVsZVRhc2sodGhpcywgdGFzayk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGFzay5fdHJhbnNpdGlvblRvKHVua25vd24sIHNjaGVkdWxpbmcsIG5vdFNjaGVkdWxlZCk7XG4gICAgICAgIHRoaXMuX3pvbmVEZWxlZ2F0ZS5oYW5kbGVFcnJvcih0aGlzLCBlcnIpO1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgICBpZiAodGFzay5fem9uZURlbGVnYXRlcyA9PT0gem9uZURlbGVnYXRlcykge1xuICAgICAgICB0aGlzLl91cGRhdGVUYXNrQ291bnQodGFzaywgMSk7XG4gICAgICB9XG4gICAgICBpZiAodGFzay5zdGF0ZSA9PSBzY2hlZHVsaW5nKSB7XG4gICAgICAgIHRhc2suX3RyYW5zaXRpb25UbyhzY2hlZHVsZWQsIHNjaGVkdWxpbmcpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRhc2s7XG4gICAgfVxuICAgIHNjaGVkdWxlTWljcm9UYXNrKHNvdXJjZSwgY2FsbGJhY2ssIGRhdGEsIGN1c3RvbVNjaGVkdWxlKSB7XG4gICAgICByZXR1cm4gdGhpcy5zY2hlZHVsZVRhc2sobmV3IFpvbmVUYXNrKG1pY3JvVGFzaywgc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIHZvaWQgMCkpO1xuICAgIH1cbiAgICBzY2hlZHVsZU1hY3JvVGFzayhzb3VyY2UsIGNhbGxiYWNrLCBkYXRhLCBjdXN0b21TY2hlZHVsZSwgY3VzdG9tQ2FuY2VsKSB7XG4gICAgICByZXR1cm4gdGhpcy5zY2hlZHVsZVRhc2sobmV3IFpvbmVUYXNrKG1hY3JvVGFzaywgc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIGN1c3RvbUNhbmNlbCkpO1xuICAgIH1cbiAgICBzY2hlZHVsZUV2ZW50VGFzayhzb3VyY2UsIGNhbGxiYWNrLCBkYXRhLCBjdXN0b21TY2hlZHVsZSwgY3VzdG9tQ2FuY2VsKSB7XG4gICAgICByZXR1cm4gdGhpcy5zY2hlZHVsZVRhc2sobmV3IFpvbmVUYXNrKGV2ZW50VGFzaywgc291cmNlLCBjYWxsYmFjaywgZGF0YSwgY3VzdG9tU2NoZWR1bGUsIGN1c3RvbUNhbmNlbCkpO1xuICAgIH1cbiAgICBjYW5jZWxUYXNrKHRhc2spIHtcbiAgICAgIGlmICh0YXNrLnpvbmUgIT0gdGhpcylcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQSB0YXNrIGNhbiBvbmx5IGJlIGNhbmNlbGxlZCBpbiB0aGUgem9uZSBvZiBjcmVhdGlvbiEgKENyZWF0aW9uOiBcIiArICh0YXNrLnpvbmUgfHwgTk9fWk9ORSkubmFtZSArIFwiOyBFeGVjdXRpb246IFwiICsgdGhpcy5uYW1lICsgXCIpXCIpO1xuICAgICAgaWYgKHRhc2suc3RhdGUgIT09IHNjaGVkdWxlZCAmJiB0YXNrLnN0YXRlICE9PSBydW5uaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRhc2suX3RyYW5zaXRpb25UbyhjYW5jZWxpbmcsIHNjaGVkdWxlZCwgcnVubmluZyk7XG4gICAgICB0cnkge1xuICAgICAgICB0aGlzLl96b25lRGVsZWdhdGUuY2FuY2VsVGFzayh0aGlzLCB0YXNrKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB0YXNrLl90cmFuc2l0aW9uVG8odW5rbm93biwgY2FuY2VsaW5nKTtcbiAgICAgICAgdGhpcy5fem9uZURlbGVnYXRlLmhhbmRsZUVycm9yKHRoaXMsIGVycik7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICAgIHRoaXMuX3VwZGF0ZVRhc2tDb3VudCh0YXNrLCAtMSk7XG4gICAgICB0YXNrLl90cmFuc2l0aW9uVG8obm90U2NoZWR1bGVkLCBjYW5jZWxpbmcpO1xuICAgICAgdGFzay5ydW5Db3VudCA9IC0xO1xuICAgICAgcmV0dXJuIHRhc2s7XG4gICAgfVxuICAgIF91cGRhdGVUYXNrQ291bnQodGFzaywgY291bnQpIHtcbiAgICAgIGNvbnN0IHpvbmVEZWxlZ2F0ZXMgPSB0YXNrLl96b25lRGVsZWdhdGVzO1xuICAgICAgaWYgKGNvdW50ID09IC0xKSB7XG4gICAgICAgIHRhc2suX3pvbmVEZWxlZ2F0ZXMgPSBudWxsO1xuICAgICAgfVxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB6b25lRGVsZWdhdGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHpvbmVEZWxlZ2F0ZXNbaV0uX3VwZGF0ZVRhc2tDb3VudCh0YXNrLnR5cGUsIGNvdW50KTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIF9fcHVibGljRmllbGQoX1pvbmVJbXBsLCBcIl9fc3ltYm9sX19cIiwgX19zeW1ib2xfXyk7XG4gIGxldCBab25lSW1wbCA9IF9ab25lSW1wbDtcbiAgY29uc3QgREVMRUdBVEVfWlMgPSB7XG4gICAgbmFtZTogXCJcIixcbiAgICBvbkhhc1Rhc2s6IChkZWxlZ2F0ZSwgXywgdGFyZ2V0LCBoYXNUYXNrU3RhdGUpID0+IGRlbGVnYXRlLmhhc1Rhc2sodGFyZ2V0LCBoYXNUYXNrU3RhdGUpLFxuICAgIG9uU2NoZWR1bGVUYXNrOiAoZGVsZWdhdGUsIF8sIHRhcmdldCwgdGFzaykgPT4gZGVsZWdhdGUuc2NoZWR1bGVUYXNrKHRhcmdldCwgdGFzayksXG4gICAgb25JbnZva2VUYXNrOiAoZGVsZWdhdGUsIF8sIHRhcmdldCwgdGFzaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MpID0+IGRlbGVnYXRlLmludm9rZVRhc2sodGFyZ2V0LCB0YXNrLCBhcHBseVRoaXMsIGFwcGx5QXJncyksXG4gICAgb25DYW5jZWxUYXNrOiAoZGVsZWdhdGUsIF8sIHRhcmdldCwgdGFzaykgPT4gZGVsZWdhdGUuY2FuY2VsVGFzayh0YXJnZXQsIHRhc2spXG4gIH07XG4gIGNsYXNzIF9ab25lRGVsZWdhdGUge1xuICAgIGNvbnN0cnVjdG9yKHpvbmUsIHBhcmVudERlbGVnYXRlLCB6b25lU3BlYykge1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl96b25lXCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl90YXNrQ291bnRzXCIsIHtcbiAgICAgICAgXCJtaWNyb1Rhc2tcIjogMCxcbiAgICAgICAgXCJtYWNyb1Rhc2tcIjogMCxcbiAgICAgICAgXCJldmVudFRhc2tcIjogMFxuICAgICAgfSk7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2ZvcmtEbGd0XCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9mb3JrWlNcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2ZvcmtDdXJyWm9uZVwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaW50ZXJjZXB0RGxndFwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaW50ZXJjZXB0WlNcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2ludGVyY2VwdEN1cnJab25lXCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9pbnZva2VEbGd0XCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9pbnZva2VaU1wiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaW52b2tlQ3VyclpvbmVcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2hhbmRsZUVycm9yRGxndFwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaGFuZGxlRXJyb3JaU1wiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaGFuZGxlRXJyb3JDdXJyWm9uZVwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfc2NoZWR1bGVUYXNrRGxndFwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfc2NoZWR1bGVUYXNrWlNcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX3NjaGVkdWxlVGFza0N1cnJab25lXCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9pbnZva2VUYXNrRGxndFwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaW52b2tlVGFza1pTXCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9pbnZva2VUYXNrQ3VyclpvbmVcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2NhbmNlbFRhc2tEbGd0XCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9jYW5jZWxUYXNrWlNcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2NhbmNlbFRhc2tDdXJyWm9uZVwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaGFzVGFza0RsZ3RcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2hhc1Rhc2tEbGd0T3duZXJcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX2hhc1Rhc2taU1wiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfaGFzVGFza0N1cnJab25lXCIpO1xuICAgICAgdGhpcy5fem9uZSA9IHpvbmU7XG4gICAgICB0aGlzLl9mb3JrWlMgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMgJiYgem9uZVNwZWMub25Gb3JrID8gem9uZVNwZWMgOiBwYXJlbnREZWxlZ2F0ZS5fZm9ya1pTKTtcbiAgICAgIHRoaXMuX2ZvcmtEbGd0ID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uRm9yayA/IHBhcmVudERlbGVnYXRlIDogcGFyZW50RGVsZWdhdGUuX2ZvcmtEbGd0KTtcbiAgICAgIHRoaXMuX2ZvcmtDdXJyWm9uZSA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkZvcmsgPyB0aGlzLl96b25lIDogcGFyZW50RGVsZWdhdGUuX2ZvcmtDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9pbnRlcmNlcHRaUyA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkludGVyY2VwdCA/IHpvbmVTcGVjIDogcGFyZW50RGVsZWdhdGUuX2ludGVyY2VwdFpTKTtcbiAgICAgIHRoaXMuX2ludGVyY2VwdERsZ3QgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnRlcmNlcHQgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9pbnRlcmNlcHREbGd0KTtcbiAgICAgIHRoaXMuX2ludGVyY2VwdEN1cnJab25lID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSW50ZXJjZXB0ID8gdGhpcy5fem9uZSA6IHBhcmVudERlbGVnYXRlLl9pbnRlcmNlcHRDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9pbnZva2VaUyA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkludm9rZSA/IHpvbmVTcGVjIDogcGFyZW50RGVsZWdhdGUuX2ludm9rZVpTKTtcbiAgICAgIHRoaXMuX2ludm9rZURsZ3QgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnZva2UgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9pbnZva2VEbGd0KTtcbiAgICAgIHRoaXMuX2ludm9rZUN1cnJab25lID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSW52b2tlID8gdGhpcy5fem9uZSA6IHBhcmVudERlbGVnYXRlLl9pbnZva2VDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9oYW5kbGVFcnJvclpTID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSGFuZGxlRXJyb3IgPyB6b25lU3BlYyA6IHBhcmVudERlbGVnYXRlLl9oYW5kbGVFcnJvclpTKTtcbiAgICAgIHRoaXMuX2hhbmRsZUVycm9yRGxndCA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkhhbmRsZUVycm9yID8gcGFyZW50RGVsZWdhdGUgOiBwYXJlbnREZWxlZ2F0ZS5faGFuZGxlRXJyb3JEbGd0KTtcbiAgICAgIHRoaXMuX2hhbmRsZUVycm9yQ3VyclpvbmUgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25IYW5kbGVFcnJvciA/IHRoaXMuX3pvbmUgOiBwYXJlbnREZWxlZ2F0ZS5faGFuZGxlRXJyb3JDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9zY2hlZHVsZVRhc2taUyA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vblNjaGVkdWxlVGFzayA/IHpvbmVTcGVjIDogcGFyZW50RGVsZWdhdGUuX3NjaGVkdWxlVGFza1pTKTtcbiAgICAgIHRoaXMuX3NjaGVkdWxlVGFza0RsZ3QgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25TY2hlZHVsZVRhc2sgPyBwYXJlbnREZWxlZ2F0ZSA6IHBhcmVudERlbGVnYXRlLl9zY2hlZHVsZVRhc2tEbGd0KTtcbiAgICAgIHRoaXMuX3NjaGVkdWxlVGFza0N1cnJab25lID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uU2NoZWR1bGVUYXNrID8gdGhpcy5fem9uZSA6IHBhcmVudERlbGVnYXRlLl9zY2hlZHVsZVRhc2tDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9pbnZva2VUYXNrWlMgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25JbnZva2VUYXNrID8gem9uZVNwZWMgOiBwYXJlbnREZWxlZ2F0ZS5faW52b2tlVGFza1pTKTtcbiAgICAgIHRoaXMuX2ludm9rZVRhc2tEbGd0ID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uSW52b2tlVGFzayA/IHBhcmVudERlbGVnYXRlIDogcGFyZW50RGVsZWdhdGUuX2ludm9rZVRhc2tEbGd0KTtcbiAgICAgIHRoaXMuX2ludm9rZVRhc2tDdXJyWm9uZSA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkludm9rZVRhc2sgPyB0aGlzLl96b25lIDogcGFyZW50RGVsZWdhdGUuX2ludm9rZVRhc2tDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9jYW5jZWxUYXNrWlMgPSB6b25lU3BlYyAmJiAoem9uZVNwZWMub25DYW5jZWxUYXNrID8gem9uZVNwZWMgOiBwYXJlbnREZWxlZ2F0ZS5fY2FuY2VsVGFza1pTKTtcbiAgICAgIHRoaXMuX2NhbmNlbFRhc2tEbGd0ID0gem9uZVNwZWMgJiYgKHpvbmVTcGVjLm9uQ2FuY2VsVGFzayA/IHBhcmVudERlbGVnYXRlIDogcGFyZW50RGVsZWdhdGUuX2NhbmNlbFRhc2tEbGd0KTtcbiAgICAgIHRoaXMuX2NhbmNlbFRhc2tDdXJyWm9uZSA9IHpvbmVTcGVjICYmICh6b25lU3BlYy5vbkNhbmNlbFRhc2sgPyB0aGlzLl96b25lIDogcGFyZW50RGVsZWdhdGUuX2NhbmNlbFRhc2tDdXJyWm9uZSk7XG4gICAgICB0aGlzLl9oYXNUYXNrWlMgPSBudWxsO1xuICAgICAgdGhpcy5faGFzVGFza0RsZ3QgPSBudWxsO1xuICAgICAgdGhpcy5faGFzVGFza0RsZ3RPd25lciA9IG51bGw7XG4gICAgICB0aGlzLl9oYXNUYXNrQ3VyclpvbmUgPSBudWxsO1xuICAgICAgY29uc3Qgem9uZVNwZWNIYXNUYXNrID0gem9uZVNwZWMgJiYgem9uZVNwZWMub25IYXNUYXNrO1xuICAgICAgY29uc3QgcGFyZW50SGFzVGFzayA9IHBhcmVudERlbGVnYXRlICYmIHBhcmVudERlbGVnYXRlLl9oYXNUYXNrWlM7XG4gICAgICBpZiAoem9uZVNwZWNIYXNUYXNrIHx8IHBhcmVudEhhc1Rhc2spIHtcbiAgICAgICAgdGhpcy5faGFzVGFza1pTID0gem9uZVNwZWNIYXNUYXNrID8gem9uZVNwZWMgOiBERUxFR0FURV9aUztcbiAgICAgICAgdGhpcy5faGFzVGFza0RsZ3QgPSBwYXJlbnREZWxlZ2F0ZTtcbiAgICAgICAgdGhpcy5faGFzVGFza0RsZ3RPd25lciA9IHRoaXM7XG4gICAgICAgIHRoaXMuX2hhc1Rhc2tDdXJyWm9uZSA9IHRoaXMuX3pvbmU7XG4gICAgICAgIGlmICghem9uZVNwZWMub25TY2hlZHVsZVRhc2spIHtcbiAgICAgICAgICB0aGlzLl9zY2hlZHVsZVRhc2taUyA9IERFTEVHQVRFX1pTO1xuICAgICAgICAgIHRoaXMuX3NjaGVkdWxlVGFza0RsZ3QgPSBwYXJlbnREZWxlZ2F0ZTtcbiAgICAgICAgICB0aGlzLl9zY2hlZHVsZVRhc2tDdXJyWm9uZSA9IHRoaXMuX3pvbmU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF6b25lU3BlYy5vbkludm9rZVRhc2spIHtcbiAgICAgICAgICB0aGlzLl9pbnZva2VUYXNrWlMgPSBERUxFR0FURV9aUztcbiAgICAgICAgICB0aGlzLl9pbnZva2VUYXNrRGxndCA9IHBhcmVudERlbGVnYXRlO1xuICAgICAgICAgIHRoaXMuX2ludm9rZVRhc2tDdXJyWm9uZSA9IHRoaXMuX3pvbmU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF6b25lU3BlYy5vbkNhbmNlbFRhc2spIHtcbiAgICAgICAgICB0aGlzLl9jYW5jZWxUYXNrWlMgPSBERUxFR0FURV9aUztcbiAgICAgICAgICB0aGlzLl9jYW5jZWxUYXNrRGxndCA9IHBhcmVudERlbGVnYXRlO1xuICAgICAgICAgIHRoaXMuX2NhbmNlbFRhc2tDdXJyWm9uZSA9IHRoaXMuX3pvbmU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZ2V0IHpvbmUoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fem9uZTtcbiAgICB9XG4gICAgZm9yayh0YXJnZXRab25lLCB6b25lU3BlYykge1xuICAgICAgcmV0dXJuIHRoaXMuX2ZvcmtaUyA/IHRoaXMuX2ZvcmtaUy5vbkZvcmsodGhpcy5fZm9ya0RsZ3QsIHRoaXMuem9uZSwgdGFyZ2V0Wm9uZSwgem9uZVNwZWMpIDogbmV3IFpvbmVJbXBsKHRhcmdldFpvbmUsIHpvbmVTcGVjKTtcbiAgICB9XG4gICAgaW50ZXJjZXB0KHRhcmdldFpvbmUsIGNhbGxiYWNrLCBzb3VyY2UpIHtcbiAgICAgIHJldHVybiB0aGlzLl9pbnRlcmNlcHRaUyA/IHRoaXMuX2ludGVyY2VwdFpTLm9uSW50ZXJjZXB0KHRoaXMuX2ludGVyY2VwdERsZ3QsIHRoaXMuX2ludGVyY2VwdEN1cnJab25lLCB0YXJnZXRab25lLCBjYWxsYmFjaywgc291cmNlKSA6IGNhbGxiYWNrO1xuICAgIH1cbiAgICBpbnZva2UodGFyZ2V0Wm9uZSwgY2FsbGJhY2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzLCBzb3VyY2UpIHtcbiAgICAgIHJldHVybiB0aGlzLl9pbnZva2VaUyA/IHRoaXMuX2ludm9rZVpTLm9uSW52b2tlKHRoaXMuX2ludm9rZURsZ3QsIHRoaXMuX2ludm9rZUN1cnJab25lLCB0YXJnZXRab25lLCBjYWxsYmFjaywgYXBwbHlUaGlzLCBhcHBseUFyZ3MsIHNvdXJjZSkgOiBjYWxsYmFjay5hcHBseShhcHBseVRoaXMsIGFwcGx5QXJncyk7XG4gICAgfVxuICAgIGhhbmRsZUVycm9yKHRhcmdldFpvbmUsIGVycm9yKSB7XG4gICAgICByZXR1cm4gdGhpcy5faGFuZGxlRXJyb3JaUyA/IHRoaXMuX2hhbmRsZUVycm9yWlMub25IYW5kbGVFcnJvcih0aGlzLl9oYW5kbGVFcnJvckRsZ3QsIHRoaXMuX2hhbmRsZUVycm9yQ3VyclpvbmUsIHRhcmdldFpvbmUsIGVycm9yKSA6IHRydWU7XG4gICAgfVxuICAgIHNjaGVkdWxlVGFzayh0YXJnZXRab25lLCB0YXNrKSB7XG4gICAgICBsZXQgcmV0dXJuVGFzayA9IHRhc2s7XG4gICAgICBpZiAodGhpcy5fc2NoZWR1bGVUYXNrWlMpIHtcbiAgICAgICAgaWYgKHRoaXMuX2hhc1Rhc2taUykge1xuICAgICAgICAgIHJldHVyblRhc2suX3pvbmVEZWxlZ2F0ZXMucHVzaCh0aGlzLl9oYXNUYXNrRGxndE93bmVyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm5UYXNrID0gdGhpcy5fc2NoZWR1bGVUYXNrWlMub25TY2hlZHVsZVRhc2sodGhpcy5fc2NoZWR1bGVUYXNrRGxndCwgdGhpcy5fc2NoZWR1bGVUYXNrQ3VyclpvbmUsIHRhcmdldFpvbmUsIHRhc2spO1xuICAgICAgICBpZiAoIXJldHVyblRhc2spXG4gICAgICAgICAgcmV0dXJuVGFzayA9IHRhc2s7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAodGFzay5zY2hlZHVsZUZuKSB7XG4gICAgICAgICAgdGFzay5zY2hlZHVsZUZuKHRhc2spO1xuICAgICAgICB9IGVsc2UgaWYgKHRhc2sudHlwZSA9PSBtaWNyb1Rhc2spIHtcbiAgICAgICAgICBzY2hlZHVsZU1pY3JvVGFzayh0YXNrKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUYXNrIGlzIG1pc3Npbmcgc2NoZWR1bGVGbi5cIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXR1cm5UYXNrO1xuICAgIH1cbiAgICBpbnZva2VUYXNrKHRhcmdldFpvbmUsIHRhc2ssIGFwcGx5VGhpcywgYXBwbHlBcmdzKSB7XG4gICAgICByZXR1cm4gdGhpcy5faW52b2tlVGFza1pTID8gdGhpcy5faW52b2tlVGFza1pTLm9uSW52b2tlVGFzayh0aGlzLl9pbnZva2VUYXNrRGxndCwgdGhpcy5faW52b2tlVGFza0N1cnJab25lLCB0YXJnZXRab25lLCB0YXNrLCBhcHBseVRoaXMsIGFwcGx5QXJncykgOiB0YXNrLmNhbGxiYWNrLmFwcGx5KGFwcGx5VGhpcywgYXBwbHlBcmdzKTtcbiAgICB9XG4gICAgY2FuY2VsVGFzayh0YXJnZXRab25lLCB0YXNrKSB7XG4gICAgICBsZXQgdmFsdWU7XG4gICAgICBpZiAodGhpcy5fY2FuY2VsVGFza1pTKSB7XG4gICAgICAgIHZhbHVlID0gdGhpcy5fY2FuY2VsVGFza1pTLm9uQ2FuY2VsVGFzayh0aGlzLl9jYW5jZWxUYXNrRGxndCwgdGhpcy5fY2FuY2VsVGFza0N1cnJab25lLCB0YXJnZXRab25lLCB0YXNrKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICghdGFzay5jYW5jZWxGbikge1xuICAgICAgICAgIHRocm93IEVycm9yKFwiVGFzayBpcyBub3QgY2FuY2VsYWJsZVwiKTtcbiAgICAgICAgfVxuICAgICAgICB2YWx1ZSA9IHRhc2suY2FuY2VsRm4odGFzayk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGhhc1Rhc2sodGFyZ2V0Wm9uZSwgaXNFbXB0eSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy5faGFzVGFza1pTICYmIHRoaXMuX2hhc1Rhc2taUy5vbkhhc1Rhc2sodGhpcy5faGFzVGFza0RsZ3QsIHRoaXMuX2hhc1Rhc2tDdXJyWm9uZSwgdGFyZ2V0Wm9uZSwgaXNFbXB0eSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy5oYW5kbGVFcnJvcih0YXJnZXRab25lLCBlcnIpO1xuICAgICAgfVxuICAgIH1cbiAgICBfdXBkYXRlVGFza0NvdW50KHR5cGUsIGNvdW50KSB7XG4gICAgICBjb25zdCBjb3VudHMgPSB0aGlzLl90YXNrQ291bnRzO1xuICAgICAgY29uc3QgcHJldiA9IGNvdW50c1t0eXBlXTtcbiAgICAgIGNvbnN0IG5leHQgPSBjb3VudHNbdHlwZV0gPSBwcmV2ICsgY291bnQ7XG4gICAgICBpZiAobmV4dCA8IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTW9yZSB0YXNrcyBleGVjdXRlZCB0aGVuIHdlcmUgc2NoZWR1bGVkLlwiKTtcbiAgICAgIH1cbiAgICAgIGlmIChwcmV2ID09IDAgfHwgbmV4dCA9PSAwKSB7XG4gICAgICAgIGNvbnN0IGlzRW1wdHkgPSB7XG4gICAgICAgICAgbWljcm9UYXNrOiBjb3VudHNbXCJtaWNyb1Rhc2tcIl0gPiAwLFxuICAgICAgICAgIG1hY3JvVGFzazogY291bnRzW1wibWFjcm9UYXNrXCJdID4gMCxcbiAgICAgICAgICBldmVudFRhc2s6IGNvdW50c1tcImV2ZW50VGFza1wiXSA+IDAsXG4gICAgICAgICAgY2hhbmdlOiB0eXBlXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMuaGFzVGFzayh0aGlzLl96b25lLCBpc0VtcHR5KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgY2xhc3MgWm9uZVRhc2sge1xuICAgIGNvbnN0cnVjdG9yKHR5cGUsIHNvdXJjZSwgY2FsbGJhY2ssIG9wdGlvbnMsIHNjaGVkdWxlRm4sIGNhbmNlbEZuKSB7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwidHlwZVwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJzb3VyY2VcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiaW52b2tlXCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImNhbGxiYWNrXCIpO1xuICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImRhdGFcIik7XG4gICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwic2NoZWR1bGVGblwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJjYW5jZWxGblwiKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfem9uZVwiLCBudWxsKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJydW5Db3VudFwiLCAwKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfem9uZURlbGVnYXRlc1wiLCBudWxsKTtcbiAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJfc3RhdGVcIiwgXCJub3RTY2hlZHVsZWRcIik7XG4gICAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgICAgdGhpcy5zb3VyY2UgPSBzb3VyY2U7XG4gICAgICB0aGlzLmRhdGEgPSBvcHRpb25zO1xuICAgICAgdGhpcy5zY2hlZHVsZUZuID0gc2NoZWR1bGVGbjtcbiAgICAgIHRoaXMuY2FuY2VsRm4gPSBjYW5jZWxGbjtcbiAgICAgIGlmICghY2FsbGJhY2spIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY2FsbGJhY2sgaXMgbm90IGRlZmluZWRcIik7XG4gICAgICB9XG4gICAgICB0aGlzLmNhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgICBjb25zdCBzZWxmMiA9IHRoaXM7XG4gICAgICBpZiAodHlwZSA9PT0gZXZlbnRUYXNrICYmIG9wdGlvbnMgJiYgb3B0aW9ucy51c2VHKSB7XG4gICAgICAgIHRoaXMuaW52b2tlID0gWm9uZVRhc2suaW52b2tlVGFzaztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuaW52b2tlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIFpvbmVUYXNrLmludm9rZVRhc2suY2FsbChnbG9iYWwsIHNlbGYyLCB0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICBzdGF0aWMgaW52b2tlVGFzayh0YXNrLCB0YXJnZXQsIGFyZ3MpIHtcbiAgICAgIGlmICghdGFzaykge1xuICAgICAgICB0YXNrID0gdGhpcztcbiAgICAgIH1cbiAgICAgIF9udW1iZXJPZk5lc3RlZFRhc2tGcmFtZXMrKztcbiAgICAgIHRyeSB7XG4gICAgICAgIHRhc2sucnVuQ291bnQrKztcbiAgICAgICAgcmV0dXJuIHRhc2suem9uZS5ydW5UYXNrKHRhc2ssIHRhcmdldCwgYXJncyk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcyA9PT0gMSAmJiAhZ2xvYmFsW2VuYWJsZU5hdGl2ZU1pY3JvdGFza0RyYWluaW5nXSkge1xuICAgICAgICAgIGRyYWluTWljcm9UYXNrUXVldWVTeW5jaHJvbm91c2x5KCk7XG4gICAgICAgIH1cbiAgICAgICAgX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcy0tO1xuICAgICAgfVxuICAgIH1cbiAgICBnZXQgem9uZSgpIHtcbiAgICAgIHJldHVybiB0aGlzLl96b25lO1xuICAgIH1cbiAgICBnZXQgc3RhdGUoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fc3RhdGU7XG4gICAgfVxuICAgIGNhbmNlbFNjaGVkdWxlUmVxdWVzdCgpIHtcbiAgICAgIHRoaXMuX3RyYW5zaXRpb25Ubyhub3RTY2hlZHVsZWQsIHNjaGVkdWxpbmcpO1xuICAgIH1cbiAgICBfdHJhbnNpdGlvblRvKHRvU3RhdGUsIGZyb21TdGF0ZTEsIGZyb21TdGF0ZTIpIHtcbiAgICAgIGlmICh0aGlzLl9zdGF0ZSA9PT0gZnJvbVN0YXRlMSB8fCB0aGlzLl9zdGF0ZSA9PT0gZnJvbVN0YXRlMikge1xuICAgICAgICB0aGlzLl9zdGF0ZSA9IHRvU3RhdGU7XG4gICAgICAgIGlmICh0b1N0YXRlID09IG5vdFNjaGVkdWxlZCkge1xuICAgICAgICAgIHRoaXMuX3pvbmVEZWxlZ2F0ZXMgPSBudWxsO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7dGhpcy50eXBlfSAnJHt0aGlzLnNvdXJjZX0nOiBjYW4gbm90IHRyYW5zaXRpb24gdG8gJyR7dG9TdGF0ZX0nLCBleHBlY3Rpbmcgc3RhdGUgJyR7ZnJvbVN0YXRlMX0nJHtmcm9tU3RhdGUyID8gXCIgb3IgJ1wiICsgZnJvbVN0YXRlMiArIFwiJ1wiIDogXCJcIn0sIHdhcyAnJHt0aGlzLl9zdGF0ZX0nLmApO1xuICAgICAgfVxuICAgIH1cbiAgICB0b1N0cmluZygpIHtcbiAgICAgIGlmICh0aGlzLmRhdGEgJiYgdHlwZW9mIHRoaXMuZGF0YS5oYW5kbGVJZCAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICByZXR1cm4gdGhpcy5kYXRhLmhhbmRsZUlkLnRvU3RyaW5nKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHRoaXMpO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBhZGQgdG9KU09OIG1ldGhvZCB0byBwcmV2ZW50IGN5Y2xpYyBlcnJvciB3aGVuXG4gICAgLy8gY2FsbCBKU09OLnN0cmluZ2lmeSh6b25lVGFzaylcbiAgICB0b0pTT04oKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiB0aGlzLnR5cGUsXG4gICAgICAgIHN0YXRlOiB0aGlzLnN0YXRlLFxuICAgICAgICBzb3VyY2U6IHRoaXMuc291cmNlLFxuICAgICAgICB6b25lOiB0aGlzLnpvbmUubmFtZSxcbiAgICAgICAgcnVuQ291bnQ6IHRoaXMucnVuQ291bnRcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIGNvbnN0IHN5bWJvbFNldFRpbWVvdXQgPSBfX3N5bWJvbF9fKFwic2V0VGltZW91dFwiKTtcbiAgY29uc3Qgc3ltYm9sUHJvbWlzZSA9IF9fc3ltYm9sX18oXCJQcm9taXNlXCIpO1xuICBjb25zdCBzeW1ib2xUaGVuID0gX19zeW1ib2xfXyhcInRoZW5cIik7XG4gIGNvbnN0IGVuYWJsZU5hdGl2ZU1pY3JvdGFza0RyYWluaW5nID0gX19zeW1ib2xfXyhcImVuYWJsZV9uYXRpdmVfbWljcm90YXNrX2RyYWluaW5nXCIpO1xuICBsZXQgX21pY3JvVGFza1F1ZXVlID0gW107XG4gIGxldCBfaXNEcmFpbmluZ01pY3JvdGFza1F1ZXVlID0gZmFsc2U7XG4gIGxldCBuYXRpdmVNaWNyb1Rhc2tRdWV1ZVByb21pc2U7XG4gIGZ1bmN0aW9uIG5hdGl2ZVNjaGVkdWxlTWljcm9UYXNrKGZ1bmMpIHtcbiAgICB2YXIgX2E7XG4gICAgaWYgKCFuYXRpdmVNaWNyb1Rhc2tRdWV1ZVByb21pc2UgJiYgZ2xvYmFsW3N5bWJvbFByb21pc2VdKSB7XG4gICAgICBuYXRpdmVNaWNyb1Rhc2tRdWV1ZVByb21pc2UgPSBnbG9iYWxbc3ltYm9sUHJvbWlzZV0ucmVzb2x2ZSgwKTtcbiAgICB9XG4gICAgaWYgKG5hdGl2ZU1pY3JvVGFza1F1ZXVlUHJvbWlzZSkge1xuICAgICAgY29uc3QgdGhlbkZuID0gKF9hID0gbmF0aXZlTWljcm9UYXNrUXVldWVQcm9taXNlW3N5bWJvbFRoZW5dKSAhPSBudWxsID8gX2EgOiBuYXRpdmVNaWNyb1Rhc2tRdWV1ZVByb21pc2VbXCJ0aGVuXCJdO1xuICAgICAgdGhlbkZuLmNhbGwobmF0aXZlTWljcm9UYXNrUXVldWVQcm9taXNlLCBmdW5jKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ2xvYmFsW3N5bWJvbFNldFRpbWVvdXRdKGZ1bmMsIDApO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBzY2hlZHVsZU1pY3JvVGFzayh0YXNrKSB7XG4gICAgY29uc3QgaXNOYXRpdmVEcmFpbmluZ0VuYWJsZWQgPSBnbG9iYWxbZW5hYmxlTmF0aXZlTWljcm90YXNrRHJhaW5pbmddO1xuICAgIGNvbnN0IHNob3VsZERyYWluV2l0aE5hdGl2ZSA9IGlzTmF0aXZlRHJhaW5pbmdFbmFibGVkICYmIF9taWNyb1Rhc2tRdWV1ZS5sZW5ndGggPT09IDAgJiYgIV9pc0RyYWluaW5nTWljcm90YXNrUXVldWU7XG4gICAgY29uc3Qgc2hvdWxkRHJhaW5XaXRob3V0TmF0aXZlID0gIWlzTmF0aXZlRHJhaW5pbmdFbmFibGVkICYmIF9udW1iZXJPZk5lc3RlZFRhc2tGcmFtZXMgPT09IDAgJiYgX21pY3JvVGFza1F1ZXVlLmxlbmd0aCA9PT0gMDtcbiAgICBpZiAoc2hvdWxkRHJhaW5XaXRoTmF0aXZlIHx8IHNob3VsZERyYWluV2l0aG91dE5hdGl2ZSkge1xuICAgICAgbmF0aXZlU2NoZWR1bGVNaWNyb1Rhc2soZHJhaW5NaWNyb1Rhc2tRdWV1ZVN5bmNocm9ub3VzbHkpO1xuICAgIH1cbiAgICBpZiAodGFzaykge1xuICAgICAgX21pY3JvVGFza1F1ZXVlLnB1c2godGFzayk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGRyYWluTWljcm9UYXNrUXVldWVTeW5jaHJvbm91c2x5KCkge1xuICAgIGlmIChfaXNEcmFpbmluZ01pY3JvdGFza1F1ZXVlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIF9pc0RyYWluaW5nTWljcm90YXNrUXVldWUgPSB0cnVlO1xuICAgIHdoaWxlIChfbWljcm9UYXNrUXVldWUubGVuZ3RoKSB7XG4gICAgICBjb25zdCBxdWV1ZSA9IF9taWNyb1Rhc2tRdWV1ZTtcbiAgICAgIF9taWNyb1Rhc2tRdWV1ZSA9IFtdO1xuICAgICAgZm9yIChjb25zdCB0YXNrIG9mIHF1ZXVlKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgdGFzay56b25lLnJ1blRhc2sodGFzaywgbnVsbCwgbnVsbCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgX2FwaS5vblVuaGFuZGxlZEVycm9yKGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZ2xvYmFsW2VuYWJsZU5hdGl2ZU1pY3JvdGFza0RyYWluaW5nXSkge1xuICAgICAgX2lzRHJhaW5pbmdNaWNyb3Rhc2tRdWV1ZSA9IGZhbHNlO1xuICAgICAgX2FwaS5taWNyb3Rhc2tEcmFpbkRvbmUoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgX2FwaS5taWNyb3Rhc2tEcmFpbkRvbmUoKTtcbiAgICAgIF9pc0RyYWluaW5nTWljcm90YXNrUXVldWUgPSBmYWxzZTtcbiAgICB9XG4gIH1cbiAgY29uc3QgTk9fWk9ORSA9IHsgbmFtZTogXCJOTyBaT05FXCIgfTtcbiAgY29uc3Qgbm90U2NoZWR1bGVkID0gXCJub3RTY2hlZHVsZWRcIiwgc2NoZWR1bGluZyA9IFwic2NoZWR1bGluZ1wiLCBzY2hlZHVsZWQgPSBcInNjaGVkdWxlZFwiLCBydW5uaW5nID0gXCJydW5uaW5nXCIsIGNhbmNlbGluZyA9IFwiY2FuY2VsaW5nXCIsIHVua25vd24gPSBcInVua25vd25cIjtcbiAgY29uc3QgbWljcm9UYXNrID0gXCJtaWNyb1Rhc2tcIiwgbWFjcm9UYXNrID0gXCJtYWNyb1Rhc2tcIiwgZXZlbnRUYXNrID0gXCJldmVudFRhc2tcIjtcbiAgY29uc3QgcGF0Y2hlcyA9IHt9O1xuICBjb25zdCBfYXBpID0ge1xuICAgIHN5bWJvbDogX19zeW1ib2xfXyxcbiAgICBjdXJyZW50Wm9uZUZyYW1lOiAoKSA9PiBfY3VycmVudFpvbmVGcmFtZSxcbiAgICBvblVuaGFuZGxlZEVycm9yOiBub29wLFxuICAgIG1pY3JvdGFza0RyYWluRG9uZTogbm9vcCxcbiAgICBzY2hlZHVsZU1pY3JvVGFzayxcbiAgICBzaG93VW5jYXVnaHRFcnJvcjogKCkgPT4gIVpvbmVJbXBsW19fc3ltYm9sX18oXCJpZ25vcmVDb25zb2xlRXJyb3JVbmNhdWdodEVycm9yXCIpXSxcbiAgICBwYXRjaEV2ZW50VGFyZ2V0OiAoKSA9PiBbXSxcbiAgICBwYXRjaE9uUHJvcGVydGllczogbm9vcCxcbiAgICBwYXRjaE1ldGhvZDogKCkgPT4gbm9vcCxcbiAgICBiaW5kQXJndW1lbnRzOiAoKSA9PiBbXSxcbiAgICBwYXRjaFRoZW46ICgpID0+IG5vb3AsXG4gICAgcGF0Y2hNYWNyb1Rhc2s6ICgpID0+IG5vb3AsXG4gICAgcGF0Y2hFdmVudFByb3RvdHlwZTogKCkgPT4gbm9vcCxcbiAgICBnZXRHbG9iYWxPYmplY3RzOiAoKSA9PiB2b2lkIDAsXG4gICAgT2JqZWN0RGVmaW5lUHJvcGVydHk6ICgpID0+IG5vb3AsXG4gICAgT2JqZWN0R2V0T3duUHJvcGVydHlEZXNjcmlwdG9yOiAoKSA9PiB2b2lkIDAsXG4gICAgT2JqZWN0Q3JlYXRlOiAoKSA9PiB2b2lkIDAsXG4gICAgQXJyYXlTbGljZTogKCkgPT4gW10sXG4gICAgcGF0Y2hDbGFzczogKCkgPT4gbm9vcCxcbiAgICB3cmFwV2l0aEN1cnJlbnRab25lOiAoKSA9PiBub29wLFxuICAgIGZpbHRlclByb3BlcnRpZXM6ICgpID0+IFtdLFxuICAgIGF0dGFjaE9yaWdpblRvUGF0Y2hlZDogKCkgPT4gbm9vcCxcbiAgICBfcmVkZWZpbmVQcm9wZXJ0eTogKCkgPT4gbm9vcCxcbiAgICBwYXRjaENhbGxiYWNrczogKCkgPT4gbm9vcCxcbiAgICBuYXRpdmVTY2hlZHVsZU1pY3JvVGFza1xuICB9O1xuICBsZXQgX2N1cnJlbnRab25lRnJhbWUgPSB7IHBhcmVudDogbnVsbCwgem9uZTogbmV3IFpvbmVJbXBsKG51bGwsIG51bGwpIH07XG4gIGxldCBfY3VycmVudFRhc2sgPSBudWxsO1xuICBsZXQgX251bWJlck9mTmVzdGVkVGFza0ZyYW1lcyA9IDA7XG4gIGZ1bmN0aW9uIG5vb3AoKSB7XG4gIH1cbiAgcGVyZm9ybWFuY2VNZWFzdXJlKFwiWm9uZVwiLCBcIlpvbmVcIik7XG4gIHJldHVybiBab25lSW1wbDtcbn1cblxuLy8gcGFja2FnZXMvem9uZS5qcy9saWIvem9uZS5qc1xuZnVuY3Rpb24gbG9hZFpvbmUoKSB7XG4gIHZhciBfYTtcbiAgY29uc3QgZ2xvYmFsMiA9IGdsb2JhbFRoaXM7XG4gIGNvbnN0IGNoZWNrRHVwbGljYXRlID0gZ2xvYmFsMltfX3N5bWJvbF9fKFwiZm9yY2VEdXBsaWNhdGVab25lQ2hlY2tcIildID09PSB0cnVlO1xuICBpZiAoZ2xvYmFsMltcIlpvbmVcIl0gJiYgKGNoZWNrRHVwbGljYXRlIHx8IHR5cGVvZiBnbG9iYWwyW1wiWm9uZVwiXS5fX3N5bWJvbF9fICE9PSBcImZ1bmN0aW9uXCIpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiWm9uZSBhbHJlYWR5IGxvYWRlZC5cIik7XG4gIH1cbiAgKF9hID0gZ2xvYmFsMltcIlpvbmVcIl0pICE9IG51bGwgPyBfYSA6IGdsb2JhbDJbXCJab25lXCJdID0gaW5pdFpvbmUoKTtcbiAgcmV0dXJuIGdsb2JhbDJbXCJab25lXCJdO1xufVxuXG4vLyBwYWNrYWdlcy96b25lLmpzL2xpYi9jb21tb24vdXRpbHMuanNcbnZhciBPYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xudmFyIE9iamVjdERlZmluZVByb3BlcnR5ID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIE9iamVjdEdldFByb3RvdHlwZU9mID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyIE9iamVjdENyZWF0ZSA9IE9iamVjdC5jcmVhdGU7XG52YXIgQXJyYXlTbGljZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZTtcbnZhciBBRERfRVZFTlRfTElTVEVORVJfU1RSID0gXCJhZGRFdmVudExpc3RlbmVyXCI7XG52YXIgUkVNT1ZFX0VWRU5UX0xJU1RFTkVSX1NUUiA9IFwicmVtb3ZlRXZlbnRMaXN0ZW5lclwiO1xudmFyIFpPTkVfU1lNQk9MX0FERF9FVkVOVF9MSVNURU5FUiA9IF9fc3ltYm9sX18oQUREX0VWRU5UX0xJU1RFTkVSX1NUUik7XG52YXIgWk9ORV9TWU1CT0xfUkVNT1ZFX0VWRU5UX0xJU1RFTkVSID0gX19zeW1ib2xfXyhSRU1PVkVfRVZFTlRfTElTVEVORVJfU1RSKTtcbnZhciBUUlVFX1NUUiA9IFwidHJ1ZVwiO1xudmFyIEZBTFNFX1NUUiA9IFwiZmFsc2VcIjtcbnZhciBaT05FX1NZTUJPTF9QUkVGSVggPSBfX3N5bWJvbF9fKFwiXCIpO1xuZnVuY3Rpb24gd3JhcFdpdGhDdXJyZW50Wm9uZShjYWxsYmFjaywgc291cmNlKSB7XG4gIHJldHVybiBab25lLmN1cnJlbnQud3JhcChjYWxsYmFjaywgc291cmNlKTtcbn1cbmZ1bmN0aW9uIHNjaGVkdWxlTWFjcm9UYXNrV2l0aEN1cnJlbnRab25lKHNvdXJjZSwgY2FsbGJhY2ssIGRhdGEsIGN1c3RvbVNjaGVkdWxlLCBjdXN0b21DYW5jZWwpIHtcbiAgcmV0dXJuIFpvbmUuY3VycmVudC5zY2hlZHVsZU1hY3JvVGFzayhzb3VyY2UsIGNhbGxiYWNrLCBkYXRhLCBjdXN0b21TY2hlZHVsZSwgY3VzdG9tQ2FuY2VsKTtcbn1cbnZhciB6b25lU3ltYm9sID0gX19zeW1ib2xfXztcbnZhciBpc1dpbmRvd0V4aXN0cyA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCI7XG52YXIgaW50ZXJuYWxXaW5kb3cgPSBpc1dpbmRvd0V4aXN0cyA/IHdpbmRvdyA6IHZvaWQgMDtcbnZhciBfZ2xvYmFsID0gaXNXaW5kb3dFeGlzdHMgJiYgaW50ZXJuYWxXaW5kb3cgfHwgZ2xvYmFsVGhpcztcbnZhciBSRU1PVkVfQVRUUklCVVRFID0gXCJyZW1vdmVBdHRyaWJ1dGVcIjtcbmZ1bmN0aW9uIGJpbmRBcmd1bWVudHMoYXJncywgc291cmNlKSB7XG4gIGZvciAobGV0IGkgPSBhcmdzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgaWYgKHR5cGVvZiBhcmdzW2ldID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGFyZ3NbaV0gPSB3cmFwV2l0aEN1cnJlbnRab25lKGFyZ3NbaV0sIHNvdXJjZSArIFwiX1wiICsgaSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBhcmdzO1xufVxuZnVuY3Rpb24gcGF0Y2hQcm90b3R5cGUocHJvdG90eXBlLCBmbk5hbWVzKSB7XG4gIGNvbnN0IHNvdXJjZSA9IHByb3RvdHlwZS5jb25zdHJ1Y3RvcltcIm5hbWVcIl07XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZm5OYW1lcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IG5hbWUgPSBmbk5hbWVzW2ldO1xuICAgIGNvbnN0IGRlbGVnYXRlID0gcHJvdG90eXBlW25hbWVdO1xuICAgIGlmIChkZWxlZ2F0ZSkge1xuICAgICAgY29uc3QgcHJvdG90eXBlRGVzYyA9IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90b3R5cGUsIG5hbWUpO1xuICAgICAgaWYgKCFpc1Byb3BlcnR5V3JpdGFibGUocHJvdG90eXBlRGVzYykpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBwcm90b3R5cGVbbmFtZV0gPSAoKGRlbGVnYXRlMikgPT4ge1xuICAgICAgICBjb25zdCBwYXRjaGVkID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcmV0dXJuIGRlbGVnYXRlMi5hcHBseSh0aGlzLCBiaW5kQXJndW1lbnRzKGFyZ3VtZW50cywgc291cmNlICsgXCIuXCIgKyBuYW1lKSk7XG4gICAgICAgIH07XG4gICAgICAgIGF0dGFjaE9yaWdpblRvUGF0Y2hlZChwYXRjaGVkLCBkZWxlZ2F0ZTIpO1xuICAgICAgICByZXR1cm4gcGF0Y2hlZDtcbiAgICAgIH0pKGRlbGVnYXRlKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGlzUHJvcGVydHlXcml0YWJsZShwcm9wZXJ0eURlc2MpIHtcbiAgaWYgKCFwcm9wZXJ0eURlc2MpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAocHJvcGVydHlEZXNjLndyaXRhYmxlID09PSBmYWxzZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gISh0eXBlb2YgcHJvcGVydHlEZXNjLmdldCA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBwcm9wZXJ0eURlc2Muc2V0ID09PSBcInVuZGVmaW5lZFwiKTtcbn1cbnZhciBpc1dlYldvcmtlciA9IHR5cGVvZiBXb3JrZXJHbG9iYWxTY29wZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBzZWxmIGluc3RhbmNlb2YgV29ya2VyR2xvYmFsU2NvcGU7XG52YXIgaXNOb2RlID0gIShcIm53XCIgaW4gX2dsb2JhbCkgJiYgdHlwZW9mIF9nbG9iYWwucHJvY2VzcyAhPT0gXCJ1bmRlZmluZWRcIiAmJiBfZ2xvYmFsLnByb2Nlc3MudG9TdHJpbmcoKSA9PT0gXCJbb2JqZWN0IHByb2Nlc3NdXCI7XG52YXIgaXNCcm93c2VyID0gIWlzTm9kZSAmJiAhaXNXZWJXb3JrZXIgJiYgISEoaXNXaW5kb3dFeGlzdHMgJiYgaW50ZXJuYWxXaW5kb3dbXCJIVE1MRWxlbWVudFwiXSk7XG52YXIgaXNNaXggPSB0eXBlb2YgX2dsb2JhbC5wcm9jZXNzICE9PSBcInVuZGVmaW5lZFwiICYmIF9nbG9iYWwucHJvY2Vzcy50b1N0cmluZygpID09PSBcIltvYmplY3QgcHJvY2Vzc11cIiAmJiAhaXNXZWJXb3JrZXIgJiYgISEoaXNXaW5kb3dFeGlzdHMgJiYgaW50ZXJuYWxXaW5kb3dbXCJIVE1MRWxlbWVudFwiXSk7XG52YXIgem9uZVN5bWJvbEV2ZW50TmFtZXMgPSB7fTtcbnZhciBlbmFibGVCZWZvcmV1bmxvYWRTeW1ib2wgPSB6b25lU3ltYm9sKFwiZW5hYmxlX2JlZm9yZXVubG9hZFwiKTtcbnZhciB3cmFwRm4gPSBmdW5jdGlvbihldmVudCkge1xuICBldmVudCA9IGV2ZW50IHx8IF9nbG9iYWwuZXZlbnQ7XG4gIGlmICghZXZlbnQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgbGV0IGV2ZW50TmFtZVN5bWJvbCA9IHpvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50LnR5cGVdO1xuICBpZiAoIWV2ZW50TmFtZVN5bWJvbCkge1xuICAgIGV2ZW50TmFtZVN5bWJvbCA9IHpvbmVTeW1ib2xFdmVudE5hbWVzW2V2ZW50LnR5cGVdID0gem9uZVN5bWJvbChcIk9OX1BST1BFUlRZXCIgKyBldmVudC50eXBlKTtcbiAgfVxuICBjb25zdCB0YXJnZXQgPSB0aGlzIHx8IGV2ZW50LnRhcmdldCB8fCBfZ2xvYmFsO1xuICBjb25zdCBsaXN0ZW5lciA9IHRhcmdldFtldmVudE5hbWVTeW1ib2xdO1xuICBsZXQgcmVzdWx0O1xuICBpZiAoaXNCcm93c2VyICYmIHRhcmdldCA9PT0gaW50ZXJuYWxXaW5kb3cgJiYgZXZlbnQudHlwZSA9PT0gXCJlcnJvclwiKSB7XG4gICAgY29uc3QgZXJyb3JFdmVudCA9IGV2ZW50O1xuICAgIHJlc3VsdCA9IGxpc3RlbmVyICYmIGxpc3RlbmVyLmNhbGwodGhpcywgZXJyb3JFdmVudC5tZXNzYWdlLCBlcnJvckV2ZW50LmZpbGVuYW1lLCBlcnJvckV2ZW50LmxpbmVubywgZXJyb3JFdmVudC5jb2xubywgZXJyb3JFdmVudC5lcnJvcik7XG4gICAgaWYgKHJlc3VsdCA9PT0gdHJ1ZSkge1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmVzdWx0ID0gbGlzdGVuZXIgJiYgbGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICBpZiAoXG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vYW5ndWxhci9hbmd1bGFyL2lzc3Vlcy80NzU3OVxuICAgICAgLy8gaHR0cHM6Ly93d3cudzMub3JnL1RSLzIwMTEvV0QtaHRtbDUtMjAxMTA1MjUvaGlzdG9yeS5odG1sI2JlZm9yZXVubG9hZGV2ZW50XG4gICAgICAvLyBUaGlzIGlzIHRoZSBvbmx5IHNwZWNpZmljIGNhc2Ugd2Ugc2hvdWxkIGNoZWNrIGZvci4gVGhlIHNwZWMgZGVmaW5lcyB0aGF0IHRoZVxuICAgICAgLy8gYHJldHVyblZhbHVlYCBhdHRyaWJ1dGUgcmVwcmVzZW50cyB0aGUgbWVzc2FnZSB0byBzaG93IHRoZSB1c2VyLiBXaGVuIHRoZSBldmVudFxuICAgICAgLy8gaXMgY3JlYXRlZCwgdGhpcyBhdHRyaWJ1dGUgbXVzdCBiZSBzZXQgdG8gdGhlIGVtcHR5IHN0cmluZy5cbiAgICAgIGV2ZW50LnR5cGUgPT09IFwiYmVmb3JldW5sb2FkXCIgJiYgLy8gVG8gcHJldmVudCBhbnkgYnJlYWtpbmcgY2hhbmdlcyByZXN1bHRpbmcgZnJvbSB0aGlzIGNoYW5nZSwgZ2l2ZW4gdGhhdFxuICAgICAgLy8gaXQgd2FzIGFscmVhZHkgY2F1c2luZyBhIHNpZ25pZmljYW50IG51bWJlciBvZiBmYWlsdXJlcyBpbiBHMywgd2UgaGF2ZSBoaWRkZW5cbiAgICAgIC8vIHRoYXQgYmVoYXZpb3IgYmVoaW5kIGEgZ2xvYmFsIGNvbmZpZ3VyYXRpb24gZmxhZy4gQ29uc3VtZXJzIGNhbiBlbmFibGUgdGhpc1xuICAgICAgLy8gZmxhZyBleHBsaWNpdGx5IGlmIHRoZXkgd2FudCB0aGUgYGJlZm9yZXVubG9hZGAgZXZlbnQgdG8gYmUgaGFuZGxlZCBhcyBkZWZpbmVkXG4gICAgICAvLyBpbiB0aGUgc3BlY2lmaWNhdGlvbi5cbiAgICAgIF9nbG9iYWxbZW5hYmxlQmVmb3JldW5sb2FkU3ltYm9sXSAmJiAvLyBUaGUgSURMIGV2ZW50IGRlZmluaXRpb24gaXMgYGF0dHJpYnV0ZSBET01TdHJpbmcgcmV0dXJuVmFsdWVgLCBzbyB3ZSBjaGVjayB3aGV0aGVyXG4gICAgICAvLyBgdHlwZW9mIHJlc3VsdGAgaXMgYSBzdHJpbmcuXG4gICAgICB0eXBlb2YgcmVzdWx0ID09PSBcInN0cmluZ1wiXG4gICAgKSB7XG4gICAgICBldmVudC5yZXR1cm5WYWx1ZSA9IHJlc3VsdDtcbiAgICB9IGVsc2UgaWYgKHJlc3VsdCAhPSB2b2lkIDAgJiYgIXJlc3VsdCkge1xuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn07XG5mdW5jdGlvbiBwYXRjaFByb3BlcnR5KG9iaiwgcHJvcCwgcHJvdG90eXBlKSB7XG4gIGxldCBkZXNjID0gT2JqZWN0R2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iaiwgcHJvcCk7XG4gIGlmICghZGVzYyAmJiBwcm90b3R5cGUpIHtcbiAgICBjb25zdCBwcm90b3R5cGVEZXNjID0gT2JqZWN0R2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHByb3RvdHlwZSwgcHJvcCk7XG4gICAgaWYgKHByb3RvdHlwZURlc2MpIHtcbiAgICAgIGRlc2MgPSB7IGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSB9O1xuICAgIH1cbiAgfVxuICBpZiAoIWRlc2MgfHwgIWRlc2MuY29uZmlndXJhYmxlKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IG9uUHJvcFBhdGNoZWRTeW1ib2wgPSB6b25lU3ltYm9sKFwib25cIiArIHByb3AgKyBcInBhdGNoZWRcIik7XG4gIGlmIChvYmouaGFzT3duUHJvcGVydHkob25Qcm9wUGF0Y2hlZFN5bWJvbCkgJiYgb2JqW29uUHJvcFBhdGNoZWRTeW1ib2xdKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGRlbGV0ZSBkZXNjLndyaXRhYmxlO1xuICBkZWxldGUgZGVzYy52YWx1ZTtcbiAgY29uc3Qgb3JpZ2luYWxEZXNjR2V0ID0gZGVzYy5nZXQ7XG4gIGNvbnN0IG9yaWdpbmFsRGVzY1NldCA9IGRlc2Muc2V0O1xuICBjb25zdCBldmVudE5hbWUgPSBwcm9wLnNsaWNlKDIpO1xuICBsZXQgZXZlbnROYW1lU3ltYm9sID0gem9uZVN5bWJvbEV2ZW50TmFtZXNbZXZlbnROYW1lXTtcbiAgaWYgKCFldmVudE5hbWVTeW1ib2wpIHtcbiAgICBldmVudE5hbWVTeW1ib2wgPSB6b25lU3ltYm9sRXZlbnROYW1lc1tldmVudE5hbWVdID0gem9uZVN5bWJvbChcIk9OX1BST1BFUlRZXCIgKyBldmVudE5hbWUpO1xuICB9XG4gIGRlc2Muc2V0ID0gZnVuY3Rpb24obmV3VmFsdWUpIHtcbiAgICBsZXQgdGFyZ2V0ID0gdGhpcztcbiAgICBpZiAoIXRhcmdldCAmJiBvYmogPT09IF9nbG9iYWwpIHtcbiAgICAgIHRhcmdldCA9IF9nbG9iYWw7XG4gICAgfVxuICAgIGlmICghdGFyZ2V0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHByZXZpb3VzVmFsdWUgPSB0YXJnZXRbZXZlbnROYW1lU3ltYm9sXTtcbiAgICBpZiAodHlwZW9mIHByZXZpb3VzVmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCB3cmFwRm4pO1xuICAgIH1cbiAgICBvcmlnaW5hbERlc2NTZXQgPT0gbnVsbCA/IHZvaWQgMCA6IG9yaWdpbmFsRGVzY1NldC5jYWxsKHRhcmdldCwgbnVsbCk7XG4gICAgdGFyZ2V0W2V2ZW50TmFtZVN5bWJvbF0gPSBuZXdWYWx1ZTtcbiAgICBpZiAodHlwZW9mIG5ld1ZhbHVlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRhcmdldC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgd3JhcEZuLCBmYWxzZSk7XG4gICAgfVxuICB9O1xuICBkZXNjLmdldCA9IGZ1bmN0aW9uKCkge1xuICAgIGxldCB0YXJnZXQgPSB0aGlzO1xuICAgIGlmICghdGFyZ2V0ICYmIG9iaiA9PT0gX2dsb2JhbCkge1xuICAgICAgdGFyZ2V0ID0gX2dsb2JhbDtcbiAgICB9XG4gICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBsaXN0ZW5lciA9IHRhcmdldFtldmVudE5hbWVTeW1ib2xdO1xuICAgIGlmIChsaXN0ZW5lcikge1xuICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgIH0gZWxzZSBpZiAob3JpZ2luYWxEZXNjR2V0KSB7XG4gICAgICBsZXQgdmFsdWUgPSBvcmlnaW5hbERlc2NHZXQuY2FsbCh0aGlzKTtcbiAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICBkZXNjLnNldC5jYWxsKHRoaXMsIHZhbHVlKTtcbiAgICAgICAgaWYgKHR5cGVvZiB0YXJnZXRbUkVNT1ZFX0FUVFJJQlVURV0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIHRhcmdldC5yZW1vdmVBdHRyaWJ1dGUocHJvcCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcbiAgT2JqZWN0RGVmaW5lUHJvcGVydHkob2JqLCBwcm9wLCBkZXNjKTtcbiAgb2JqW29uUHJvcFBhdGNoZWRTeW1ib2xdID0gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHBhdGNoT25Qcm9wZXJ0aWVzKG9iaiwgcHJvcGVydGllcywgcHJvdG90eXBlKSB7XG4gIGlmIChwcm9wZXJ0aWVzKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9wZXJ0aWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBwYXRjaFByb3BlcnR5KG9iaiwgXCJvblwiICsgcHJvcGVydGllc1tpXSwgcHJvdG90eXBlKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgY29uc3Qgb25Qcm9wZXJ0aWVzID0gW107XG4gICAgZm9yIChjb25zdCBwcm9wIGluIG9iaikge1xuICAgICAgaWYgKHByb3Auc2xpY2UoMCwgMikgPT0gXCJvblwiKSB7XG4gICAgICAgIG9uUHJvcGVydGllcy5wdXNoKHByb3ApO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGxldCBqID0gMDsgaiA8IG9uUHJvcGVydGllcy5sZW5ndGg7IGorKykge1xuICAgICAgcGF0Y2hQcm9wZXJ0eShvYmosIG9uUHJvcGVydGllc1tqXSwgcHJvdG90eXBlKTtcbiAgICB9XG4gIH1cbn1cbnZhciBvcmlnaW5hbEluc3RhbmNlS2V5ID0gem9uZVN5bWJvbChcIm9yaWdpbmFsSW5zdGFuY2VcIik7XG5mdW5jdGlvbiBwYXRjaENsYXNzKGNsYXNzTmFtZSkge1xuICBjb25zdCBPcmlnaW5hbENsYXNzID0gX2dsb2JhbFtjbGFzc05hbWVdO1xuICBpZiAoIU9yaWdpbmFsQ2xhc3MpXG4gICAgcmV0dXJuO1xuICBfZ2xvYmFsW3pvbmVTeW1ib2woY2xhc3NOYW1lKV0gPSBPcmlnaW5hbENsYXNzO1xuICBfZ2xvYmFsW2NsYXNzTmFtZV0gPSBmdW5jdGlvbigpIHtcbiAgICBjb25zdCBhID0gYmluZEFyZ3VtZW50cyhhcmd1bWVudHMsIGNsYXNzTmFtZSk7XG4gICAgc3dpdGNoIChhLmxlbmd0aCkge1xuICAgICAgY2FzZSAwOlxuICAgICAgICB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldID0gbmV3IE9yaWdpbmFsQ2xhc3MoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDE6XG4gICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcyhhWzBdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDI6XG4gICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcyhhWzBdLCBhWzFdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDM6XG4gICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcyhhWzBdLCBhWzFdLCBhWzJdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDQ6XG4gICAgICAgIHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV0gPSBuZXcgT3JpZ2luYWxDbGFzcyhhWzBdLCBhWzFdLCBhWzJdLCBhWzNdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJBcmcgbGlzdCB0b28gbG9uZy5cIik7XG4gICAgfVxuICB9O1xuICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQoX2dsb2JhbFtjbGFzc05hbWVdLCBPcmlnaW5hbENsYXNzKTtcbiAgY29uc3QgaW5zdGFuY2UgPSBuZXcgT3JpZ2luYWxDbGFzcyhmdW5jdGlvbigpIHtcbiAgfSk7XG4gIGxldCBwcm9wO1xuICBmb3IgKHByb3AgaW4gaW5zdGFuY2UpIHtcbiAgICBpZiAoY2xhc3NOYW1lID09PSBcIlhNTEh0dHBSZXF1ZXN0XCIgJiYgcHJvcCA9PT0gXCJyZXNwb25zZUJsb2JcIilcbiAgICAgIGNvbnRpbnVlO1xuICAgIChmdW5jdGlvbihwcm9wMikge1xuICAgICAgaWYgKHR5cGVvZiBpbnN0YW5jZVtwcm9wMl0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBfZ2xvYmFsW2NsYXNzTmFtZV0ucHJvdG90eXBlW3Byb3AyXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHJldHVybiB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldW3Byb3AyXS5hcHBseSh0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldLCBhcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgT2JqZWN0RGVmaW5lUHJvcGVydHkoX2dsb2JhbFtjbGFzc05hbWVdLnByb3RvdHlwZSwgcHJvcDIsIHtcbiAgICAgICAgICBzZXQ6IGZ1bmN0aW9uKGZuKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGZuID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgdGhpc1tvcmlnaW5hbEluc3RhbmNlS2V5XVtwcm9wMl0gPSB3cmFwV2l0aEN1cnJlbnRab25lKGZuLCBjbGFzc05hbWUgKyBcIi5cIiArIHByb3AyKTtcbiAgICAgICAgICAgICAgYXR0YWNoT3JpZ2luVG9QYXRjaGVkKHRoaXNbb3JpZ2luYWxJbnN0YW5jZUtleV1bcHJvcDJdLCBmbik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldW3Byb3AyXSA9IGZuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzW29yaWdpbmFsSW5zdGFuY2VLZXldW3Byb3AyXTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pKHByb3ApO1xuICB9XG4gIGZvciAocHJvcCBpbiBPcmlnaW5hbENsYXNzKSB7XG4gICAgaWYgKHByb3AgIT09IFwicHJvdG90eXBlXCIgJiYgT3JpZ2luYWxDbGFzcy5oYXNPd25Qcm9wZXJ0eShwcm9wKSkge1xuICAgICAgX2dsb2JhbFtjbGFzc05hbWVdW3Byb3BdID0gT3JpZ2luYWxDbGFzc1twcm9wXTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGNvcHlTeW1ib2xQcm9wZXJ0aWVzKHNyYywgZGVzdCkge1xuICBpZiAodHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgIT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzeW1ib2xzID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzcmMpO1xuICBzeW1ib2xzLmZvckVhY2goKHN5bWJvbCkgPT4ge1xuICAgIGNvbnN0IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHNyYywgc3ltYm9sKTtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZGVzdCwgc3ltYm9sLCB7XG4gICAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gc3JjW3N5bWJvbF07XG4gICAgICB9LFxuICAgICAgc2V0OiBmdW5jdGlvbih2YWx1ZSkge1xuICAgICAgICBpZiAoZGVzYyAmJiAoIWRlc2Mud3JpdGFibGUgfHwgdHlwZW9mIGRlc2Muc2V0ICE9PSBcImZ1bmN0aW9uXCIpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNyY1tzeW1ib2xdID0gdmFsdWU7XG4gICAgICB9LFxuICAgICAgZW51bWVyYWJsZTogZGVzYyA/IGRlc2MuZW51bWVyYWJsZSA6IHRydWUsXG4gICAgICBjb25maWd1cmFibGU6IGRlc2MgPyBkZXNjLmNvbmZpZ3VyYWJsZSA6IHRydWVcbiAgICB9KTtcbiAgfSk7XG59XG52YXIgc2hvdWxkQ29weVN5bWJvbFByb3BlcnRpZXMgPSBmYWxzZTtcbmZ1bmN0aW9uIHBhdGNoTWV0aG9kKHRhcmdldCwgbmFtZSwgcGF0Y2hGbikge1xuICBsZXQgcHJvdG8gPSB0YXJnZXQ7XG4gIHdoaWxlIChwcm90byAmJiAhcHJvdG8uaGFzT3duUHJvcGVydHkobmFtZSkpIHtcbiAgICBwcm90byA9IE9iamVjdEdldFByb3RvdHlwZU9mKHByb3RvKTtcbiAgfVxuICBpZiAoIXByb3RvICYmIHRhcmdldFtuYW1lXSkge1xuICAgIHByb3RvID0gdGFyZ2V0O1xuICB9XG4gIGNvbnN0IGRlbGVnYXRlTmFtZSA9IHpvbmVTeW1ib2wobmFtZSk7XG4gIGxldCBkZWxlZ2F0ZSA9IG51bGw7XG4gIGlmIChwcm90byAmJiAoIShkZWxlZ2F0ZSA9IHByb3RvW2RlbGVnYXRlTmFtZV0pIHx8ICFwcm90by5oYXNPd25Qcm9wZXJ0eShkZWxlZ2F0ZU5hbWUpKSkge1xuICAgIGRlbGVnYXRlID0gcHJvdG9bZGVsZWdhdGVOYW1lXSA9IHByb3RvW25hbWVdO1xuICAgIGNvbnN0IGRlc2MgPSBwcm90byAmJiBPYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IocHJvdG8sIG5hbWUpO1xuICAgIGlmIChpc1Byb3BlcnR5V3JpdGFibGUoZGVzYykpIHtcbiAgICAgIGNvbnN0IHBhdGNoRGVsZWdhdGUgPSBwYXRjaEZuKGRlbGVnYXRlLCBkZWxlZ2F0ZU5hbWUsIG5hbWUpO1xuICAgICAgcHJvdG9bbmFtZV0gPSBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHBhdGNoRGVsZWdhdGUodGhpcywgYXJndW1lbnRzKTtcbiAgICAgIH07XG4gICAgICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQocHJvdG9bbmFtZV0sIGRlbGVnYXRlKTtcbiAgICAgIGlmIChzaG91bGRDb3B5U3ltYm9sUHJvcGVydGllcykge1xuICAgICAgICBjb3B5U3ltYm9sUHJvcGVydGllcyhkZWxlZ2F0ZSwgcHJvdG9bbmFtZV0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZGVsZWdhdGU7XG59XG5mdW5jdGlvbiBwYXRjaE1hY3JvVGFzayhvYmosIGZ1bmNOYW1lLCBtZXRhQ3JlYXRvcikge1xuICBsZXQgc2V0TmF0aXZlID0gbnVsbDtcbiAgZnVuY3Rpb24gc2NoZWR1bGVUYXNrKHRhc2spIHtcbiAgICBjb25zdCBkYXRhID0gdGFzay5kYXRhO1xuICAgIGRhdGEuYXJnc1tkYXRhLmNiSWR4XSA9IGZ1bmN0aW9uKCkge1xuICAgICAgdGFzay5pbnZva2UuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9O1xuICAgIHNldE5hdGl2ZS5hcHBseShkYXRhLnRhcmdldCwgZGF0YS5hcmdzKTtcbiAgICByZXR1cm4gdGFzaztcbiAgfVxuICBzZXROYXRpdmUgPSBwYXRjaE1ldGhvZChvYmosIGZ1bmNOYW1lLCAoZGVsZWdhdGUpID0+IGZ1bmN0aW9uKHNlbGYyLCBhcmdzKSB7XG4gICAgY29uc3QgbWV0YSA9IG1ldGFDcmVhdG9yKHNlbGYyLCBhcmdzKTtcbiAgICBpZiAobWV0YS5jYklkeCA+PSAwICYmIHR5cGVvZiBhcmdzW21ldGEuY2JJZHhdID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHJldHVybiBzY2hlZHVsZU1hY3JvVGFza1dpdGhDdXJyZW50Wm9uZShtZXRhLm5hbWUsIGFyZ3NbbWV0YS5jYklkeF0sIG1ldGEsIHNjaGVkdWxlVGFzayk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBkZWxlZ2F0ZS5hcHBseShzZWxmMiwgYXJncyk7XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIGF0dGFjaE9yaWdpblRvUGF0Y2hlZChwYXRjaGVkLCBvcmlnaW5hbCkge1xuICBwYXRjaGVkW3pvbmVTeW1ib2woXCJPcmlnaW5hbERlbGVnYXRlXCIpXSA9IG9yaWdpbmFsO1xufVxuZnVuY3Rpb24gaXNGdW5jdGlvbih2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCI7XG59XG5mdW5jdGlvbiBpc051bWJlcih2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiO1xufVxuXG4vLyBwYWNrYWdlcy96b25lLmpzL2xpYi9jb21tb24vZXZlbnRzLmpzXG52YXIgT1BUSU1JWkVEX1pPTkVfRVZFTlRfVEFTS19EQVRBID0ge1xuICB1c2VHOiB0cnVlXG59O1xudmFyIHpvbmVTeW1ib2xFdmVudE5hbWVzMiA9IHt9O1xudmFyIGdsb2JhbFNvdXJjZXMgPSB7fTtcbnZhciBFVkVOVF9OQU1FX1NZTUJPTF9SRUdYID0gbmV3IFJlZ0V4cChcIl5cIiArIFpPTkVfU1lNQk9MX1BSRUZJWCArIFwiKFxcXFx3KykodHJ1ZXxmYWxzZSkkXCIpO1xudmFyIElNTUVESUFURV9QUk9QQUdBVElPTl9TWU1CT0wgPSB6b25lU3ltYm9sKFwicHJvcGFnYXRpb25TdG9wcGVkXCIpO1xuZnVuY3Rpb24gcHJlcGFyZUV2ZW50TmFtZXMoZXZlbnROYW1lLCBldmVudE5hbWVUb1N0cmluZykge1xuICBjb25zdCBmYWxzZUV2ZW50TmFtZSA9IChldmVudE5hbWVUb1N0cmluZyA/IGV2ZW50TmFtZVRvU3RyaW5nKGV2ZW50TmFtZSkgOiBldmVudE5hbWUpICsgRkFMU0VfU1RSO1xuICBjb25zdCB0cnVlRXZlbnROYW1lID0gKGV2ZW50TmFtZVRvU3RyaW5nID8gZXZlbnROYW1lVG9TdHJpbmcoZXZlbnROYW1lKSA6IGV2ZW50TmFtZSkgKyBUUlVFX1NUUjtcbiAgY29uc3Qgc3ltYm9sID0gWk9ORV9TWU1CT0xfUFJFRklYICsgZmFsc2VFdmVudE5hbWU7XG4gIGNvbnN0IHN5bWJvbENhcHR1cmUgPSBaT05FX1NZTUJPTF9QUkVGSVggKyB0cnVlRXZlbnROYW1lO1xuICB6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnROYW1lXSA9IHt9O1xuICB6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnROYW1lXVtGQUxTRV9TVFJdID0gc3ltYm9sO1xuICB6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnROYW1lXVtUUlVFX1NUUl0gPSBzeW1ib2xDYXB0dXJlO1xufVxuZnVuY3Rpb24gcGF0Y2hFdmVudFRhcmdldChfZ2xvYmFsMiwgYXBpLCBhcGlzLCBwYXRjaE9wdGlvbnMpIHtcbiAgY29uc3QgQUREX0VWRU5UX0xJU1RFTkVSID0gcGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy5hZGQgfHwgQUREX0VWRU5UX0xJU1RFTkVSX1NUUjtcbiAgY29uc3QgUkVNT1ZFX0VWRU5UX0xJU1RFTkVSID0gcGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy5ybSB8fCBSRU1PVkVfRVZFTlRfTElTVEVORVJfU1RSO1xuICBjb25zdCBMSVNURU5FUlNfRVZFTlRfTElTVEVORVIgPSBwYXRjaE9wdGlvbnMgJiYgcGF0Y2hPcHRpb25zLmxpc3RlbmVycyB8fCBcImV2ZW50TGlzdGVuZXJzXCI7XG4gIGNvbnN0IFJFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSID0gcGF0Y2hPcHRpb25zICYmIHBhdGNoT3B0aW9ucy5ybUFsbCB8fCBcInJlbW92ZUFsbExpc3RlbmVyc1wiO1xuICBjb25zdCB6b25lU3ltYm9sQWRkRXZlbnRMaXN0ZW5lciA9IHpvbmVTeW1ib2woQUREX0VWRU5UX0xJU1RFTkVSKTtcbiAgY29uc3QgQUREX0VWRU5UX0xJU1RFTkVSX1NPVVJDRSA9IFwiLlwiICsgQUREX0VWRU5UX0xJU1RFTkVSICsgXCI6XCI7XG4gIGNvbnN0IFBSRVBFTkRfRVZFTlRfTElTVEVORVIgPSBcInByZXBlbmRMaXN0ZW5lclwiO1xuICBjb25zdCBQUkVQRU5EX0VWRU5UX0xJU1RFTkVSX1NPVVJDRSA9IFwiLlwiICsgUFJFUEVORF9FVkVOVF9MSVNURU5FUiArIFwiOlwiO1xuICBjb25zdCBpbnZva2VUYXNrID0gZnVuY3Rpb24odGFzaywgdGFyZ2V0LCBldmVudCkge1xuICAgIGlmICh0YXNrLmlzUmVtb3ZlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBkZWxlZ2F0ZSA9IHRhc2suY2FsbGJhY2s7XG4gICAgaWYgKHR5cGVvZiBkZWxlZ2F0ZSA9PT0gXCJvYmplY3RcIiAmJiBkZWxlZ2F0ZS5oYW5kbGVFdmVudCkge1xuICAgICAgdGFzay5jYWxsYmFjayA9IChldmVudDIpID0+IGRlbGVnYXRlLmhhbmRsZUV2ZW50KGV2ZW50Mik7XG4gICAgICB0YXNrLm9yaWdpbmFsRGVsZWdhdGUgPSBkZWxlZ2F0ZTtcbiAgICB9XG4gICAgbGV0IGVycm9yO1xuICAgIHRyeSB7XG4gICAgICB0YXNrLmludm9rZSh0YXNrLCB0YXJnZXQsIFtldmVudF0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgZXJyb3IgPSBlcnI7XG4gICAgfVxuICAgIGNvbnN0IG9wdGlvbnMgPSB0YXNrLm9wdGlvbnM7XG4gICAgaWYgKG9wdGlvbnMgJiYgdHlwZW9mIG9wdGlvbnMgPT09IFwib2JqZWN0XCIgJiYgb3B0aW9ucy5vbmNlKSB7XG4gICAgICBjb25zdCBkZWxlZ2F0ZTIgPSB0YXNrLm9yaWdpbmFsRGVsZWdhdGUgPyB0YXNrLm9yaWdpbmFsRGVsZWdhdGUgOiB0YXNrLmNhbGxiYWNrO1xuICAgICAgdGFyZ2V0W1JFTU9WRV9FVkVOVF9MSVNURU5FUl0uY2FsbCh0YXJnZXQsIGV2ZW50LnR5cGUsIGRlbGVnYXRlMiwgb3B0aW9ucyk7XG4gICAgfVxuICAgIHJldHVybiBlcnJvcjtcbiAgfTtcbiAgZnVuY3Rpb24gZ2xvYmFsQ2FsbGJhY2soY29udGV4dCwgZXZlbnQsIGlzQ2FwdHVyZSkge1xuICAgIGV2ZW50ID0gZXZlbnQgfHwgX2dsb2JhbDIuZXZlbnQ7XG4gICAgaWYgKCFldmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXQgPSBjb250ZXh0IHx8IGV2ZW50LnRhcmdldCB8fCBfZ2xvYmFsMjtcbiAgICBjb25zdCB0YXNrcyA9IHRhcmdldFt6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnQudHlwZV1baXNDYXB0dXJlID8gVFJVRV9TVFIgOiBGQUxTRV9TVFJdXTtcbiAgICBpZiAodGFza3MpIHtcbiAgICAgIGNvbnN0IGVycm9ycyA9IFtdO1xuICAgICAgaWYgKHRhc2tzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICBjb25zdCBlcnIgPSBpbnZva2VUYXNrKHRhc2tzWzBdLCB0YXJnZXQsIGV2ZW50KTtcbiAgICAgICAgZXJyICYmIGVycm9ycy5wdXNoKGVycik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBjb3B5VGFza3MgPSB0YXNrcy5zbGljZSgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvcHlUYXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChldmVudCAmJiBldmVudFtJTU1FRElBVEVfUFJPUEFHQVRJT05fU1lNQk9MXSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGVyciA9IGludm9rZVRhc2soY29weVRhc2tzW2ldLCB0YXJnZXQsIGV2ZW50KTtcbiAgICAgICAgICBlcnIgJiYgZXJyb3JzLnB1c2goZXJyKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGVycm9ycy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgdGhyb3cgZXJyb3JzWzBdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBlcnJvcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBlcnIgPSBlcnJvcnNbaV07XG4gICAgICAgICAgYXBpLm5hdGl2ZVNjaGVkdWxlTWljcm9UYXNrKCgpID0+IHtcbiAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb25zdCBnbG9iYWxab25lQXdhcmVDYWxsYmFjayA9IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgcmV0dXJuIGdsb2JhbENhbGxiYWNrKHRoaXMsIGV2ZW50LCBmYWxzZSk7XG4gIH07XG4gIGNvbnN0IGdsb2JhbFpvbmVBd2FyZUNhcHR1cmVDYWxsYmFjayA9IGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgcmV0dXJuIGdsb2JhbENhbGxiYWNrKHRoaXMsIGV2ZW50LCB0cnVlKTtcbiAgfTtcbiAgZnVuY3Rpb24gcGF0Y2hFdmVudFRhcmdldE1ldGhvZHMob2JqLCBwYXRjaE9wdGlvbnMyKSB7XG4gICAgaWYgKCFvYmopIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbGV0IHVzZUdsb2JhbENhbGxiYWNrID0gdHJ1ZTtcbiAgICBpZiAocGF0Y2hPcHRpb25zMiAmJiBwYXRjaE9wdGlvbnMyLnVzZUcgIT09IHZvaWQgMCkge1xuICAgICAgdXNlR2xvYmFsQ2FsbGJhY2sgPSBwYXRjaE9wdGlvbnMyLnVzZUc7XG4gICAgfVxuICAgIGNvbnN0IHZhbGlkYXRlSGFuZGxlciA9IHBhdGNoT3B0aW9uczIgJiYgcGF0Y2hPcHRpb25zMi52aDtcbiAgICBsZXQgY2hlY2tEdXBsaWNhdGUgPSB0cnVlO1xuICAgIGlmIChwYXRjaE9wdGlvbnMyICYmIHBhdGNoT3B0aW9uczIuY2hrRHVwICE9PSB2b2lkIDApIHtcbiAgICAgIGNoZWNrRHVwbGljYXRlID0gcGF0Y2hPcHRpb25zMi5jaGtEdXA7XG4gICAgfVxuICAgIGxldCByZXR1cm5UYXJnZXQgPSBmYWxzZTtcbiAgICBpZiAocGF0Y2hPcHRpb25zMiAmJiBwYXRjaE9wdGlvbnMyLnJ0ICE9PSB2b2lkIDApIHtcbiAgICAgIHJldHVyblRhcmdldCA9IHBhdGNoT3B0aW9uczIucnQ7XG4gICAgfVxuICAgIGxldCBwcm90byA9IG9iajtcbiAgICB3aGlsZSAocHJvdG8gJiYgIXByb3RvLmhhc093blByb3BlcnR5KEFERF9FVkVOVF9MSVNURU5FUikpIHtcbiAgICAgIHByb3RvID0gT2JqZWN0R2V0UHJvdG90eXBlT2YocHJvdG8pO1xuICAgIH1cbiAgICBpZiAoIXByb3RvICYmIG9ialtBRERfRVZFTlRfTElTVEVORVJdKSB7XG4gICAgICBwcm90byA9IG9iajtcbiAgICB9XG4gICAgaWYgKCFwcm90bykge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAocHJvdG9bem9uZVN5bWJvbEFkZEV2ZW50TGlzdGVuZXJdKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IGV2ZW50TmFtZVRvU3RyaW5nID0gcGF0Y2hPcHRpb25zMiAmJiBwYXRjaE9wdGlvbnMyLmV2ZW50TmFtZVRvU3RyaW5nO1xuICAgIGNvbnN0IHRhc2tEYXRhID0ge307XG4gICAgY29uc3QgbmF0aXZlQWRkRXZlbnRMaXN0ZW5lciA9IHByb3RvW3pvbmVTeW1ib2xBZGRFdmVudExpc3RlbmVyXSA9IHByb3RvW0FERF9FVkVOVF9MSVNURU5FUl07XG4gICAgY29uc3QgbmF0aXZlUmVtb3ZlRXZlbnRMaXN0ZW5lciA9IHByb3RvW3pvbmVTeW1ib2woUkVNT1ZFX0VWRU5UX0xJU1RFTkVSKV0gPSBwcm90b1tSRU1PVkVfRVZFTlRfTElTVEVORVJdO1xuICAgIGNvbnN0IG5hdGl2ZUxpc3RlbmVycyA9IHByb3RvW3pvbmVTeW1ib2woTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSKV0gPSBwcm90b1tMSVNURU5FUlNfRVZFTlRfTElTVEVORVJdO1xuICAgIGNvbnN0IG5hdGl2ZVJlbW92ZUFsbExpc3RlbmVycyA9IHByb3RvW3pvbmVTeW1ib2woUkVNT1ZFX0FMTF9MSVNURU5FUlNfRVZFTlRfTElTVEVORVIpXSA9IHByb3RvW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXTtcbiAgICBsZXQgbmF0aXZlUHJlcGVuZEV2ZW50TGlzdGVuZXI7XG4gICAgaWYgKHBhdGNoT3B0aW9uczIgJiYgcGF0Y2hPcHRpb25zMi5wcmVwZW5kKSB7XG4gICAgICBuYXRpdmVQcmVwZW5kRXZlbnRMaXN0ZW5lciA9IHByb3RvW3pvbmVTeW1ib2wocGF0Y2hPcHRpb25zMi5wcmVwZW5kKV0gPSBwcm90b1twYXRjaE9wdGlvbnMyLnByZXBlbmRdO1xuICAgIH1cbiAgICBmdW5jdGlvbiBidWlsZEV2ZW50TGlzdGVuZXJPcHRpb25zKG9wdGlvbnMsIHBhc3NpdmUpIHtcbiAgICAgIGlmICghcGFzc2l2ZSkge1xuICAgICAgICByZXR1cm4gb3B0aW9ucztcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIpIHtcbiAgICAgICAgcmV0dXJuIHsgY2FwdHVyZTogb3B0aW9ucywgcGFzc2l2ZTogdHJ1ZSB9O1xuICAgICAgfVxuICAgICAgaWYgKCFvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB7IHBhc3NpdmU6IHRydWUgfTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJvYmplY3RcIiAmJiBvcHRpb25zLnBhc3NpdmUgIT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiBfX3NwcmVhZFByb3BzKF9fc3ByZWFkVmFsdWVzKHt9LCBvcHRpb25zKSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG9wdGlvbnM7XG4gICAgfVxuICAgIGNvbnN0IGN1c3RvbVNjaGVkdWxlR2xvYmFsID0gZnVuY3Rpb24odGFzaykge1xuICAgICAgaWYgKHRhc2tEYXRhLmlzRXhpc3RpbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5hdGl2ZUFkZEV2ZW50TGlzdGVuZXIuY2FsbCh0YXNrRGF0YS50YXJnZXQsIHRhc2tEYXRhLmV2ZW50TmFtZSwgdGFza0RhdGEuY2FwdHVyZSA/IGdsb2JhbFpvbmVBd2FyZUNhcHR1cmVDYWxsYmFjayA6IGdsb2JhbFpvbmVBd2FyZUNhbGxiYWNrLCB0YXNrRGF0YS5vcHRpb25zKTtcbiAgICB9O1xuICAgIGNvbnN0IGN1c3RvbUNhbmNlbEdsb2JhbCA9IGZ1bmN0aW9uKHRhc2spIHtcbiAgICAgIGlmICghdGFzay5pc1JlbW92ZWQpIHtcbiAgICAgICAgY29uc3Qgc3ltYm9sRXZlbnROYW1lcyA9IHpvbmVTeW1ib2xFdmVudE5hbWVzMlt0YXNrLmV2ZW50TmFtZV07XG4gICAgICAgIGxldCBzeW1ib2xFdmVudE5hbWU7XG4gICAgICAgIGlmIChzeW1ib2xFdmVudE5hbWVzKSB7XG4gICAgICAgICAgc3ltYm9sRXZlbnROYW1lID0gc3ltYm9sRXZlbnROYW1lc1t0YXNrLmNhcHR1cmUgPyBUUlVFX1NUUiA6IEZBTFNFX1NUUl07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZXhpc3RpbmdUYXNrcyA9IHN5bWJvbEV2ZW50TmFtZSAmJiB0YXNrLnRhcmdldFtzeW1ib2xFdmVudE5hbWVdO1xuICAgICAgICBpZiAoZXhpc3RpbmdUYXNrcykge1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZXhpc3RpbmdUYXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdUYXNrID0gZXhpc3RpbmdUYXNrc1tpXTtcbiAgICAgICAgICAgIGlmIChleGlzdGluZ1Rhc2sgPT09IHRhc2spIHtcbiAgICAgICAgICAgICAgZXhpc3RpbmdUYXNrcy5zcGxpY2UoaSwgMSk7XG4gICAgICAgICAgICAgIHRhc2suaXNSZW1vdmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgaWYgKHRhc2sucmVtb3ZlQWJvcnRMaXN0ZW5lcikge1xuICAgICAgICAgICAgICAgIHRhc2sucmVtb3ZlQWJvcnRMaXN0ZW5lcigpO1xuICAgICAgICAgICAgICAgIHRhc2sucmVtb3ZlQWJvcnRMaXN0ZW5lciA9IG51bGw7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKGV4aXN0aW5nVGFza3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgdGFzay5hbGxSZW1vdmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB0YXNrLnRhcmdldFtzeW1ib2xFdmVudE5hbWVdID0gbnVsbDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICghdGFzay5hbGxSZW1vdmVkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHJldHVybiBuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyLmNhbGwodGFzay50YXJnZXQsIHRhc2suZXZlbnROYW1lLCB0YXNrLmNhcHR1cmUgPyBnbG9iYWxab25lQXdhcmVDYXB0dXJlQ2FsbGJhY2sgOiBnbG9iYWxab25lQXdhcmVDYWxsYmFjaywgdGFzay5vcHRpb25zKTtcbiAgICB9O1xuICAgIGNvbnN0IGN1c3RvbVNjaGVkdWxlTm9uR2xvYmFsID0gZnVuY3Rpb24odGFzaykge1xuICAgICAgcmV0dXJuIG5hdGl2ZUFkZEV2ZW50TGlzdGVuZXIuY2FsbCh0YXNrRGF0YS50YXJnZXQsIHRhc2tEYXRhLmV2ZW50TmFtZSwgdGFzay5pbnZva2UsIHRhc2tEYXRhLm9wdGlvbnMpO1xuICAgIH07XG4gICAgY29uc3QgY3VzdG9tU2NoZWR1bGVQcmVwZW5kID0gZnVuY3Rpb24odGFzaykge1xuICAgICAgcmV0dXJuIG5hdGl2ZVByZXBlbmRFdmVudExpc3RlbmVyLmNhbGwodGFza0RhdGEudGFyZ2V0LCB0YXNrRGF0YS5ldmVudE5hbWUsIHRhc2suaW52b2tlLCB0YXNrRGF0YS5vcHRpb25zKTtcbiAgICB9O1xuICAgIGNvbnN0IGN1c3RvbUNhbmNlbE5vbkdsb2JhbCA9IGZ1bmN0aW9uKHRhc2spIHtcbiAgICAgIHJldHVybiBuYXRpdmVSZW1vdmVFdmVudExpc3RlbmVyLmNhbGwodGFzay50YXJnZXQsIHRhc2suZXZlbnROYW1lLCB0YXNrLmludm9rZSwgdGFzay5vcHRpb25zKTtcbiAgICB9O1xuICAgIGNvbnN0IGN1c3RvbVNjaGVkdWxlID0gdXNlR2xvYmFsQ2FsbGJhY2sgPyBjdXN0b21TY2hlZHVsZUdsb2JhbCA6IGN1c3RvbVNjaGVkdWxlTm9uR2xvYmFsO1xuICAgIGNvbnN0IGN1c3RvbUNhbmNlbCA9IHVzZUdsb2JhbENhbGxiYWNrID8gY3VzdG9tQ2FuY2VsR2xvYmFsIDogY3VzdG9tQ2FuY2VsTm9uR2xvYmFsO1xuICAgIGNvbnN0IGNvbXBhcmVUYXNrQ2FsbGJhY2tWc0RlbGVnYXRlID0gZnVuY3Rpb24odGFzaywgZGVsZWdhdGUpIHtcbiAgICAgIGNvbnN0IHR5cGVPZkRlbGVnYXRlID0gdHlwZW9mIGRlbGVnYXRlO1xuICAgICAgcmV0dXJuIHR5cGVPZkRlbGVnYXRlID09PSBcImZ1bmN0aW9uXCIgJiYgdGFzay5jYWxsYmFjayA9PT0gZGVsZWdhdGUgfHwgdHlwZU9mRGVsZWdhdGUgPT09IFwib2JqZWN0XCIgJiYgdGFzay5vcmlnaW5hbERlbGVnYXRlID09PSBkZWxlZ2F0ZTtcbiAgICB9O1xuICAgIGNvbnN0IGNvbXBhcmUgPSAocGF0Y2hPcHRpb25zMiA9PSBudWxsID8gdm9pZCAwIDogcGF0Y2hPcHRpb25zMi5kaWZmKSB8fCBjb21wYXJlVGFza0NhbGxiYWNrVnNEZWxlZ2F0ZTtcbiAgICBjb25zdCB1bnBhdGNoZWRFdmVudHMgPSBab25lW3pvbmVTeW1ib2woXCJVTlBBVENIRURfRVZFTlRTXCIpXTtcbiAgICBjb25zdCBwYXNzaXZlRXZlbnRzID0gX2dsb2JhbDJbem9uZVN5bWJvbChcIlBBU1NJVkVfRVZFTlRTXCIpXTtcbiAgICBmdW5jdGlvbiBjb3B5RXZlbnRMaXN0ZW5lck9wdGlvbnMob3B0aW9ucykge1xuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSBcIm9iamVjdFwiICYmIG9wdGlvbnMgIT09IG51bGwpIHtcbiAgICAgICAgY29uc3QgbmV3T3B0aW9ucyA9IF9fc3ByZWFkVmFsdWVzKHt9LCBvcHRpb25zKTtcbiAgICAgICAgaWYgKG9wdGlvbnMuc2lnbmFsKSB7XG4gICAgICAgICAgbmV3T3B0aW9ucy5zaWduYWwgPSBvcHRpb25zLnNpZ25hbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3T3B0aW9ucztcbiAgICAgIH1cbiAgICAgIHJldHVybiBvcHRpb25zO1xuICAgIH1cbiAgICBjb25zdCBtYWtlQWRkTGlzdGVuZXIgPSBmdW5jdGlvbihuYXRpdmVMaXN0ZW5lciwgYWRkU291cmNlLCBjdXN0b21TY2hlZHVsZUZuLCBjdXN0b21DYW5jZWxGbiwgcmV0dXJuVGFyZ2V0MiA9IGZhbHNlLCBwcmVwZW5kID0gZmFsc2UpIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gdGhpcyB8fCBfZ2xvYmFsMjtcbiAgICAgICAgbGV0IGV2ZW50TmFtZSA9IGFyZ3VtZW50c1swXTtcbiAgICAgICAgaWYgKHBhdGNoT3B0aW9uczIgJiYgcGF0Y2hPcHRpb25zMi50cmFuc2ZlckV2ZW50TmFtZSkge1xuICAgICAgICAgIGV2ZW50TmFtZSA9IHBhdGNoT3B0aW9uczIudHJhbnNmZXJFdmVudE5hbWUoZXZlbnROYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgZGVsZWdhdGUgPSBhcmd1bWVudHNbMV07XG4gICAgICAgIGlmICghZGVsZWdhdGUpIHtcbiAgICAgICAgICByZXR1cm4gbmF0aXZlTGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNOb2RlICYmIGV2ZW50TmFtZSA9PT0gXCJ1bmNhdWdodEV4Y2VwdGlvblwiKSB7XG4gICAgICAgICAgcmV0dXJuIG5hdGl2ZUxpc3RlbmVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGlzRXZlbnRMaXN0ZW5lck9iamVjdCA9IGZhbHNlO1xuICAgICAgICBpZiAodHlwZW9mIGRlbGVnYXRlICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICBpZiAoIWRlbGVnYXRlLmhhbmRsZUV2ZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gbmF0aXZlTGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaXNFdmVudExpc3RlbmVyT2JqZWN0ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsaWRhdGVIYW5kbGVyICYmICF2YWxpZGF0ZUhhbmRsZXIobmF0aXZlTGlzdGVuZXIsIGRlbGVnYXRlLCB0YXJnZXQsIGFyZ3VtZW50cykpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGFzc2l2ZSA9ICEhcGFzc2l2ZUV2ZW50cyAmJiBwYXNzaXZlRXZlbnRzLmluZGV4T2YoZXZlbnROYW1lKSAhPT0gLTE7XG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSBjb3B5RXZlbnRMaXN0ZW5lck9wdGlvbnMoYnVpbGRFdmVudExpc3RlbmVyT3B0aW9ucyhhcmd1bWVudHNbMl0sIHBhc3NpdmUpKTtcbiAgICAgICAgY29uc3Qgc2lnbmFsID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5zaWduYWw7XG4gICAgICAgIGlmIChzaWduYWwgPT0gbnVsbCA/IHZvaWQgMCA6IHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICh1bnBhdGNoZWRFdmVudHMpIHtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHVucGF0Y2hlZEV2ZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgaWYgKGV2ZW50TmFtZSA9PT0gdW5wYXRjaGVkRXZlbnRzW2ldKSB7XG4gICAgICAgICAgICAgIGlmIChwYXNzaXZlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5hdGl2ZUxpc3RlbmVyLmNhbGwodGFyZ2V0LCBldmVudE5hbWUsIGRlbGVnYXRlLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmF0aXZlTGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjYXB0dXJlID0gIW9wdGlvbnMgPyBmYWxzZSA6IHR5cGVvZiBvcHRpb25zID09PSBcImJvb2xlYW5cIiA/IHRydWUgOiBvcHRpb25zLmNhcHR1cmU7XG4gICAgICAgIGNvbnN0IG9uY2UgPSBvcHRpb25zICYmIHR5cGVvZiBvcHRpb25zID09PSBcIm9iamVjdFwiID8gb3B0aW9ucy5vbmNlIDogZmFsc2U7XG4gICAgICAgIGNvbnN0IHpvbmUgPSBab25lLmN1cnJlbnQ7XG4gICAgICAgIGxldCBzeW1ib2xFdmVudE5hbWVzID0gem9uZVN5bWJvbEV2ZW50TmFtZXMyW2V2ZW50TmFtZV07XG4gICAgICAgIGlmICghc3ltYm9sRXZlbnROYW1lcykge1xuICAgICAgICAgIHByZXBhcmVFdmVudE5hbWVzKGV2ZW50TmFtZSwgZXZlbnROYW1lVG9TdHJpbmcpO1xuICAgICAgICAgIHN5bWJvbEV2ZW50TmFtZXMgPSB6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnROYW1lXTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzeW1ib2xFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW2NhcHR1cmUgPyBUUlVFX1NUUiA6IEZBTFNFX1NUUl07XG4gICAgICAgIGxldCBleGlzdGluZ1Rhc2tzID0gdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZV07XG4gICAgICAgIGxldCBpc0V4aXN0aW5nID0gZmFsc2U7XG4gICAgICAgIGlmIChleGlzdGluZ1Rhc2tzKSB7XG4gICAgICAgICAgaXNFeGlzdGluZyA9IHRydWU7XG4gICAgICAgICAgaWYgKGNoZWNrRHVwbGljYXRlKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGV4aXN0aW5nVGFza3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgaWYgKGNvbXBhcmUoZXhpc3RpbmdUYXNrc1tpXSwgZGVsZWdhdGUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGV4aXN0aW5nVGFza3MgPSB0YXJnZXRbc3ltYm9sRXZlbnROYW1lXSA9IFtdO1xuICAgICAgICB9XG4gICAgICAgIGxldCBzb3VyY2U7XG4gICAgICAgIGNvbnN0IGNvbnN0cnVjdG9yTmFtZSA9IHRhcmdldC5jb25zdHJ1Y3RvcltcIm5hbWVcIl07XG4gICAgICAgIGNvbnN0IHRhcmdldFNvdXJjZSA9IGdsb2JhbFNvdXJjZXNbY29uc3RydWN0b3JOYW1lXTtcbiAgICAgICAgaWYgKHRhcmdldFNvdXJjZSkge1xuICAgICAgICAgIHNvdXJjZSA9IHRhcmdldFNvdXJjZVtldmVudE5hbWVdO1xuICAgICAgICB9XG4gICAgICAgIGlmICghc291cmNlKSB7XG4gICAgICAgICAgc291cmNlID0gY29uc3RydWN0b3JOYW1lICsgYWRkU291cmNlICsgKGV2ZW50TmFtZVRvU3RyaW5nID8gZXZlbnROYW1lVG9TdHJpbmcoZXZlbnROYW1lKSA6IGV2ZW50TmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGFza0RhdGEub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgICAgIGlmIChvbmNlKSB7XG4gICAgICAgICAgdGFza0RhdGEub3B0aW9ucy5vbmNlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgdGFza0RhdGEudGFyZ2V0ID0gdGFyZ2V0O1xuICAgICAgICB0YXNrRGF0YS5jYXB0dXJlID0gY2FwdHVyZTtcbiAgICAgICAgdGFza0RhdGEuZXZlbnROYW1lID0gZXZlbnROYW1lO1xuICAgICAgICB0YXNrRGF0YS5pc0V4aXN0aW5nID0gaXNFeGlzdGluZztcbiAgICAgICAgY29uc3QgZGF0YSA9IHVzZUdsb2JhbENhbGxiYWNrID8gT1BUSU1JWkVEX1pPTkVfRVZFTlRfVEFTS19EQVRBIDogdm9pZCAwO1xuICAgICAgICBpZiAoZGF0YSkge1xuICAgICAgICAgIGRhdGEudGFza0RhdGEgPSB0YXNrRGF0YTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgdGFza0RhdGEub3B0aW9ucy5zaWduYWwgPSB2b2lkIDA7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGFzayA9IHpvbmUuc2NoZWR1bGVFdmVudFRhc2soc291cmNlLCBkZWxlZ2F0ZSwgZGF0YSwgY3VzdG9tU2NoZWR1bGVGbiwgY3VzdG9tQ2FuY2VsRm4pO1xuICAgICAgICBpZiAoc2lnbmFsKSB7XG4gICAgICAgICAgdGFza0RhdGEub3B0aW9ucy5zaWduYWwgPSBzaWduYWw7XG4gICAgICAgICAgY29uc3Qgb25BYm9ydCA9ICgpID0+IHRhc2suem9uZS5jYW5jZWxUYXNrKHRhc2spO1xuICAgICAgICAgIG5hdGl2ZUxpc3RlbmVyLmNhbGwoc2lnbmFsLCBcImFib3J0XCIsIG9uQWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcbiAgICAgICAgICB0YXNrLnJlbW92ZUFib3J0TGlzdGVuZXIgPSAoKSA9PiBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQpO1xuICAgICAgICB9XG4gICAgICAgIHRhc2tEYXRhLnRhcmdldCA9IG51bGw7XG4gICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgZGF0YS50YXNrRGF0YSA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9uY2UpIHtcbiAgICAgICAgICB0YXNrRGF0YS5vcHRpb25zLm9uY2UgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgdGFzay5vcHRpb25zICE9PSBcImJvb2xlYW5cIikge1xuICAgICAgICAgIHRhc2sub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgICAgIH1cbiAgICAgICAgdGFzay50YXJnZXQgPSB0YXJnZXQ7XG4gICAgICAgIHRhc2suY2FwdHVyZSA9IGNhcHR1cmU7XG4gICAgICAgIHRhc2suZXZlbnROYW1lID0gZXZlbnROYW1lO1xuICAgICAgICBpZiAoaXNFdmVudExpc3RlbmVyT2JqZWN0KSB7XG4gICAgICAgICAgdGFzay5vcmlnaW5hbERlbGVnYXRlID0gZGVsZWdhdGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFwcmVwZW5kKSB7XG4gICAgICAgICAgZXhpc3RpbmdUYXNrcy5wdXNoKHRhc2spO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGV4aXN0aW5nVGFza3MudW5zaGlmdCh0YXNrKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmV0dXJuVGFyZ2V0Mikge1xuICAgICAgICAgIHJldHVybiB0YXJnZXQ7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfTtcbiAgICBwcm90b1tBRERfRVZFTlRfTElTVEVORVJdID0gbWFrZUFkZExpc3RlbmVyKG5hdGl2ZUFkZEV2ZW50TGlzdGVuZXIsIEFERF9FVkVOVF9MSVNURU5FUl9TT1VSQ0UsIGN1c3RvbVNjaGVkdWxlLCBjdXN0b21DYW5jZWwsIHJldHVyblRhcmdldCk7XG4gICAgaWYgKG5hdGl2ZVByZXBlbmRFdmVudExpc3RlbmVyKSB7XG4gICAgICBwcm90b1tQUkVQRU5EX0VWRU5UX0xJU1RFTkVSXSA9IG1ha2VBZGRMaXN0ZW5lcihuYXRpdmVQcmVwZW5kRXZlbnRMaXN0ZW5lciwgUFJFUEVORF9FVkVOVF9MSVNURU5FUl9TT1VSQ0UsIGN1c3RvbVNjaGVkdWxlUHJlcGVuZCwgY3VzdG9tQ2FuY2VsLCByZXR1cm5UYXJnZXQsIHRydWUpO1xuICAgIH1cbiAgICBwcm90b1tSRU1PVkVfRVZFTlRfTElTVEVORVJdID0gZnVuY3Rpb24oKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSB0aGlzIHx8IF9nbG9iYWwyO1xuICAgICAgbGV0IGV2ZW50TmFtZSA9IGFyZ3VtZW50c1swXTtcbiAgICAgIGlmIChwYXRjaE9wdGlvbnMyICYmIHBhdGNoT3B0aW9uczIudHJhbnNmZXJFdmVudE5hbWUpIHtcbiAgICAgICAgZXZlbnROYW1lID0gcGF0Y2hPcHRpb25zMi50cmFuc2ZlckV2ZW50TmFtZShldmVudE5hbWUpO1xuICAgICAgfVxuICAgICAgY29uc3Qgb3B0aW9ucyA9IGFyZ3VtZW50c1syXTtcbiAgICAgIGNvbnN0IGNhcHR1cmUgPSAhb3B0aW9ucyA/IGZhbHNlIDogdHlwZW9mIG9wdGlvbnMgPT09IFwiYm9vbGVhblwiID8gdHJ1ZSA6IG9wdGlvbnMuY2FwdHVyZTtcbiAgICAgIGNvbnN0IGRlbGVnYXRlID0gYXJndW1lbnRzWzFdO1xuICAgICAgaWYgKCFkZWxlZ2F0ZSkge1xuICAgICAgICByZXR1cm4gbmF0aXZlUmVtb3ZlRXZlbnRMaXN0ZW5lci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgfVxuICAgICAgaWYgKHZhbGlkYXRlSGFuZGxlciAmJiAhdmFsaWRhdGVIYW5kbGVyKG5hdGl2ZVJlbW92ZUV2ZW50TGlzdGVuZXIsIGRlbGVnYXRlLCB0YXJnZXQsIGFyZ3VtZW50cykpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3ltYm9sRXZlbnROYW1lcyA9IHpvbmVTeW1ib2xFdmVudE5hbWVzMltldmVudE5hbWVdO1xuICAgICAgbGV0IHN5bWJvbEV2ZW50TmFtZTtcbiAgICAgIGlmIChzeW1ib2xFdmVudE5hbWVzKSB7XG4gICAgICAgIHN5bWJvbEV2ZW50TmFtZSA9IHN5bWJvbEV2ZW50TmFtZXNbY2FwdHVyZSA/IFRSVUVfU1RSIDogRkFMU0VfU1RSXTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGV4aXN0aW5nVGFza3MgPSBzeW1ib2xFdmVudE5hbWUgJiYgdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZV07XG4gICAgICBpZiAoZXhpc3RpbmdUYXNrcykge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGV4aXN0aW5nVGFza3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBleGlzdGluZ1Rhc2sgPSBleGlzdGluZ1Rhc2tzW2ldO1xuICAgICAgICAgIGlmIChjb21wYXJlKGV4aXN0aW5nVGFzaywgZGVsZWdhdGUpKSB7XG4gICAgICAgICAgICBleGlzdGluZ1Rhc2tzLnNwbGljZShpLCAxKTtcbiAgICAgICAgICAgIGV4aXN0aW5nVGFzay5pc1JlbW92ZWQgPSB0cnVlO1xuICAgICAgICAgICAgaWYgKGV4aXN0aW5nVGFza3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgIGV4aXN0aW5nVGFzay5hbGxSZW1vdmVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZV0gPSBudWxsO1xuICAgICAgICAgICAgICBpZiAoIWNhcHR1cmUgJiYgdHlwZW9mIGV2ZW50TmFtZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgICAgIGNvbnN0IG9uUHJvcGVydHlTeW1ib2wgPSBaT05FX1NZTUJPTF9QUkVGSVggKyBcIk9OX1BST1BFUlRZXCIgKyBldmVudE5hbWU7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W29uUHJvcGVydHlTeW1ib2xdID0gbnVsbDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZXhpc3RpbmdUYXNrLnpvbmUuY2FuY2VsVGFzayhleGlzdGluZ1Rhc2spO1xuICAgICAgICAgICAgaWYgKHJldHVyblRhcmdldCkge1xuICAgICAgICAgICAgICByZXR1cm4gdGFyZ2V0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIG5hdGl2ZVJlbW92ZUV2ZW50TGlzdGVuZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICB9O1xuICAgIHByb3RvW0xJU1RFTkVSU19FVkVOVF9MSVNURU5FUl0gPSBmdW5jdGlvbigpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IHRoaXMgfHwgX2dsb2JhbDI7XG4gICAgICBsZXQgZXZlbnROYW1lID0gYXJndW1lbnRzWzBdO1xuICAgICAgaWYgKHBhdGNoT3B0aW9uczIgJiYgcGF0Y2hPcHRpb25zMi50cmFuc2ZlckV2ZW50TmFtZSkge1xuICAgICAgICBldmVudE5hbWUgPSBwYXRjaE9wdGlvbnMyLnRyYW5zZmVyRXZlbnROYW1lKGV2ZW50TmFtZSk7XG4gICAgICB9XG4gICAgICBjb25zdCBsaXN0ZW5lcnMgPSBbXTtcbiAgICAgIGNvbnN0IHRhc2tzID0gZmluZEV2ZW50VGFza3ModGFyZ2V0LCBldmVudE5hbWVUb1N0cmluZyA/IGV2ZW50TmFtZVRvU3RyaW5nKGV2ZW50TmFtZSkgOiBldmVudE5hbWUpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0YXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCB0YXNrID0gdGFza3NbaV07XG4gICAgICAgIGxldCBkZWxlZ2F0ZSA9IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA/IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA6IHRhc2suY2FsbGJhY2s7XG4gICAgICAgIGxpc3RlbmVycy5wdXNoKGRlbGVnYXRlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBsaXN0ZW5lcnM7XG4gICAgfTtcbiAgICBwcm90b1tSRU1PVkVfQUxMX0xJU1RFTkVSU19FVkVOVF9MSVNURU5FUl0gPSBmdW5jdGlvbigpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IHRoaXMgfHwgX2dsb2JhbDI7XG4gICAgICBsZXQgZXZlbnROYW1lID0gYXJndW1lbnRzWzBdO1xuICAgICAgaWYgKCFldmVudE5hbWUpIHtcbiAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHRhcmdldCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IHByb3AgPSBrZXlzW2ldO1xuICAgICAgICAgIGNvbnN0IG1hdGNoID0gRVZFTlRfTkFNRV9TWU1CT0xfUkVHWC5leGVjKHByb3ApO1xuICAgICAgICAgIGxldCBldnROYW1lID0gbWF0Y2ggJiYgbWF0Y2hbMV07XG4gICAgICAgICAgaWYgKGV2dE5hbWUgJiYgZXZ0TmFtZSAhPT0gXCJyZW1vdmVMaXN0ZW5lclwiKSB7XG4gICAgICAgICAgICB0aGlzW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXS5jYWxsKHRoaXMsIGV2dE5hbWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzW1JFTU9WRV9BTExfTElTVEVORVJTX0VWRU5UX0xJU1RFTkVSXS5jYWxsKHRoaXMsIFwicmVtb3ZlTGlzdGVuZXJcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAocGF0Y2hPcHRpb25zMiAmJiBwYXRjaE9wdGlvbnMyLnRyYW5zZmVyRXZlbnROYW1lKSB7XG4gICAgICAgICAgZXZlbnROYW1lID0gcGF0Y2hPcHRpb25zMi50cmFuc2ZlckV2ZW50TmFtZShldmVudE5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHN5bWJvbEV2ZW50TmFtZXMgPSB6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnROYW1lXTtcbiAgICAgICAgaWYgKHN5bWJvbEV2ZW50TmFtZXMpIHtcbiAgICAgICAgICBjb25zdCBzeW1ib2xFdmVudE5hbWUgPSBzeW1ib2xFdmVudE5hbWVzW0ZBTFNFX1NUUl07XG4gICAgICAgICAgY29uc3Qgc3ltYm9sQ2FwdHVyZUV2ZW50TmFtZSA9IHN5bWJvbEV2ZW50TmFtZXNbVFJVRV9TVFJdO1xuICAgICAgICAgIGNvbnN0IHRhc2tzID0gdGFyZ2V0W3N5bWJvbEV2ZW50TmFtZV07XG4gICAgICAgICAgY29uc3QgY2FwdHVyZVRhc2tzID0gdGFyZ2V0W3N5bWJvbENhcHR1cmVFdmVudE5hbWVdO1xuICAgICAgICAgIGlmICh0YXNrcykge1xuICAgICAgICAgICAgY29uc3QgcmVtb3ZlVGFza3MgPSB0YXNrcy5zbGljZSgpO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZW1vdmVUYXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICBjb25zdCB0YXNrID0gcmVtb3ZlVGFza3NbaV07XG4gICAgICAgICAgICAgIGxldCBkZWxlZ2F0ZSA9IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA/IHRhc2sub3JpZ2luYWxEZWxlZ2F0ZSA6IHRhc2suY2FsbGJhY2s7XG4gICAgICAgICAgICAgIHRoaXNbUkVNT1ZFX0VWRU5UX0xJU1RFTkVSXS5jYWxsKHRoaXMsIGV2ZW50TmFtZSwgZGVsZWdhdGUsIHRhc2sub3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChjYXB0dXJlVGFza3MpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlbW92ZVRhc2tzID0gY2FwdHVyZVRhc2tzLnNsaWNlKCk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlbW92ZVRhc2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHRhc2sgPSByZW1vdmVUYXNrc1tpXTtcbiAgICAgICAgICAgICAgbGV0IGRlbGVnYXRlID0gdGFzay5vcmlnaW5hbERlbGVnYXRlID8gdGFzay5vcmlnaW5hbERlbGVnYXRlIDogdGFzay5jYWxsYmFjaztcbiAgICAgICAgICAgICAgdGhpc1tSRU1PVkVfRVZFTlRfTElTVEVORVJdLmNhbGwodGhpcywgZXZlbnROYW1lLCBkZWxlZ2F0ZSwgdGFzay5vcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChyZXR1cm5UYXJnZXQpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9XG4gICAgfTtcbiAgICBhdHRhY2hPcmlnaW5Ub1BhdGNoZWQocHJvdG9bQUREX0VWRU5UX0xJU1RFTkVSXSwgbmF0aXZlQWRkRXZlbnRMaXN0ZW5lcik7XG4gICAgYXR0YWNoT3JpZ2luVG9QYXRjaGVkKHByb3RvW1JFTU9WRV9FVkVOVF9MSVNURU5FUl0sIG5hdGl2ZVJlbW92ZUV2ZW50TGlzdGVuZXIpO1xuICAgIGlmIChuYXRpdmVSZW1vdmVBbGxMaXN0ZW5lcnMpIHtcbiAgICAgIGF0dGFjaE9yaWdpblRvUGF0Y2hlZChwcm90b1tSRU1PVkVfQUxMX0xJU1RFTkVSU19FVkVOVF9MSVNURU5FUl0sIG5hdGl2ZVJlbW92ZUFsbExpc3RlbmVycyk7XG4gICAgfVxuICAgIGlmIChuYXRpdmVMaXN0ZW5lcnMpIHtcbiAgICAgIGF0dGFjaE9yaWdpblRvUGF0Y2hlZChwcm90b1tMSVNURU5FUlNfRVZFTlRfTElTVEVORVJdLCBuYXRpdmVMaXN0ZW5lcnMpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBsZXQgcmVzdWx0cyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGFwaXMubGVuZ3RoOyBpKyspIHtcbiAgICByZXN1bHRzW2ldID0gcGF0Y2hFdmVudFRhcmdldE1ldGhvZHMoYXBpc1tpXSwgcGF0Y2hPcHRpb25zKTtcbiAgfVxuICByZXR1cm4gcmVzdWx0cztcbn1cbmZ1bmN0aW9uIGZpbmRFdmVudFRhc2tzKHRhcmdldCwgZXZlbnROYW1lKSB7XG4gIGlmICghZXZlbnROYW1lKSB7XG4gICAgY29uc3QgZm91bmRUYXNrcyA9IFtdO1xuICAgIGZvciAobGV0IHByb3AgaW4gdGFyZ2V0KSB7XG4gICAgICBjb25zdCBtYXRjaCA9IEVWRU5UX05BTUVfU1lNQk9MX1JFR1guZXhlYyhwcm9wKTtcbiAgICAgIGxldCBldnROYW1lID0gbWF0Y2ggJiYgbWF0Y2hbMV07XG4gICAgICBpZiAoZXZ0TmFtZSAmJiAoIWV2ZW50TmFtZSB8fCBldnROYW1lID09PSBldmVudE5hbWUpKSB7XG4gICAgICAgIGNvbnN0IHRhc2tzID0gdGFyZ2V0W3Byb3BdO1xuICAgICAgICBpZiAodGFza3MpIHtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhc2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBmb3VuZFRhc2tzLnB1c2godGFza3NbaV0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZm91bmRUYXNrcztcbiAgfVxuICBsZXQgc3ltYm9sRXZlbnROYW1lID0gem9uZVN5bWJvbEV2ZW50TmFtZXMyW2V2ZW50TmFtZV07XG4gIGlmICghc3ltYm9sRXZlbnROYW1lKSB7XG4gICAgcHJlcGFyZUV2ZW50TmFtZXMoZXZlbnROYW1lKTtcbiAgICBzeW1ib2xFdmVudE5hbWUgPSB6b25lU3ltYm9sRXZlbnROYW1lczJbZXZlbnROYW1lXTtcbiAgfVxuICBjb25zdCBjYXB0dXJlRmFsc2VUYXNrcyA9IHRhcmdldFtzeW1ib2xFdmVudE5hbWVbRkFMU0VfU1RSXV07XG4gIGNvbnN0IGNhcHR1cmVUcnVlVGFza3MgPSB0YXJnZXRbc3ltYm9sRXZlbnROYW1lW1RSVUVfU1RSXV07XG4gIGlmICghY2FwdHVyZUZhbHNlVGFza3MpIHtcbiAgICByZXR1cm4gY2FwdHVyZVRydWVUYXNrcyA/IGNhcHR1cmVUcnVlVGFza3Muc2xpY2UoKSA6IFtdO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBjYXB0dXJlVHJ1ZVRhc2tzID8gY2FwdHVyZUZhbHNlVGFza3MuY29uY2F0KGNhcHR1cmVUcnVlVGFza3MpIDogY2FwdHVyZUZhbHNlVGFza3Muc2xpY2UoKTtcbiAgfVxufVxuZnVuY3Rpb24gcGF0Y2hFdmVudFByb3RvdHlwZShnbG9iYWwyLCBhcGkpIHtcbiAgY29uc3QgRXZlbnQgPSBnbG9iYWwyW1wiRXZlbnRcIl07XG4gIGlmIChFdmVudCAmJiBFdmVudC5wcm90b3R5cGUpIHtcbiAgICBhcGkucGF0Y2hNZXRob2QoRXZlbnQucHJvdG90eXBlLCBcInN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvblwiLCAoZGVsZWdhdGUpID0+IGZ1bmN0aW9uKHNlbGYyLCBhcmdzKSB7XG4gICAgICBzZWxmMltJTU1FRElBVEVfUFJPUEFHQVRJT05fU1lNQk9MXSA9IHRydWU7XG4gICAgICBkZWxlZ2F0ZSAmJiBkZWxlZ2F0ZS5hcHBseShzZWxmMiwgYXJncyk7XG4gICAgfSk7XG4gIH1cbn1cblxuLy8gcGFja2FnZXMvem9uZS5qcy9saWIvY29tbW9uL3F1ZXVlLW1pY3JvdGFzay5qc1xuZnVuY3Rpb24gcGF0Y2hRdWV1ZU1pY3JvdGFzayhnbG9iYWwyLCBhcGkpIHtcbiAgYXBpLnBhdGNoTWV0aG9kKGdsb2JhbDIsIFwicXVldWVNaWNyb3Rhc2tcIiwgKGRlbGVnYXRlKSA9PiB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uKHNlbGYyLCBhcmdzKSB7XG4gICAgICBab25lLmN1cnJlbnQuc2NoZWR1bGVNaWNyb1Rhc2soXCJxdWV1ZU1pY3JvdGFza1wiLCBhcmdzWzBdKTtcbiAgICB9O1xuICB9KTtcbn1cblxuLy8gcGFja2FnZXMvem9uZS5qcy9saWIvY29tbW9uL3RpbWVycy5qc1xudmFyIHRhc2tTeW1ib2wgPSB6b25lU3ltYm9sKFwiem9uZVRhc2tcIik7XG5mdW5jdGlvbiBwYXRjaFRpbWVyKHdpbmRvdzIsIHNldE5hbWUsIGNhbmNlbE5hbWUsIG5hbWVTdWZmaXgpIHtcbiAgbGV0IHNldE5hdGl2ZSA9IG51bGw7XG4gIGxldCBjbGVhck5hdGl2ZSA9IG51bGw7XG4gIHNldE5hbWUgKz0gbmFtZVN1ZmZpeDtcbiAgY2FuY2VsTmFtZSArPSBuYW1lU3VmZml4O1xuICBjb25zdCB0YXNrc0J5SGFuZGxlSWQgPSB7fTtcbiAgZnVuY3Rpb24gc2NoZWR1bGVUYXNrKHRhc2spIHtcbiAgICBjb25zdCBkYXRhID0gdGFzay5kYXRhO1xuICAgIGRhdGEuYXJnc1swXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHRhc2suaW52b2tlLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfTtcbiAgICBjb25zdCBoYW5kbGVPcklkID0gc2V0TmF0aXZlLmFwcGx5KHdpbmRvdzIsIGRhdGEuYXJncyk7XG4gICAgaWYgKGlzTnVtYmVyKGhhbmRsZU9ySWQpKSB7XG4gICAgICBkYXRhLmhhbmRsZUlkID0gaGFuZGxlT3JJZDtcbiAgICB9IGVsc2Uge1xuICAgICAgZGF0YS5oYW5kbGUgPSBoYW5kbGVPcklkO1xuICAgICAgZGF0YS5pc1JlZnJlc2hhYmxlID0gaXNGdW5jdGlvbihoYW5kbGVPcklkLnJlZnJlc2gpO1xuICAgIH1cbiAgICByZXR1cm4gdGFzaztcbiAgfVxuICBmdW5jdGlvbiBjbGVhclRhc2sodGFzaykge1xuICAgIGNvbnN0IHsgaGFuZGxlLCBoYW5kbGVJZCB9ID0gdGFzay5kYXRhO1xuICAgIHJldHVybiBjbGVhck5hdGl2ZS5jYWxsKHdpbmRvdzIsIGhhbmRsZSAhPSBudWxsID8gaGFuZGxlIDogaGFuZGxlSWQpO1xuICB9XG4gIHNldE5hdGl2ZSA9IHBhdGNoTWV0aG9kKHdpbmRvdzIsIHNldE5hbWUsIChkZWxlZ2F0ZSkgPT4gZnVuY3Rpb24oc2VsZjIsIGFyZ3MpIHtcbiAgICB2YXIgX2E7XG4gICAgaWYgKGlzRnVuY3Rpb24oYXJnc1swXSkpIHtcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgIGlzUmVmcmVzaGFibGU6IGZhbHNlLFxuICAgICAgICBpc1BlcmlvZGljOiBuYW1lU3VmZml4ID09PSBcIkludGVydmFsXCIsXG4gICAgICAgIGRlbGF5OiBuYW1lU3VmZml4ID09PSBcIlRpbWVvdXRcIiB8fCBuYW1lU3VmZml4ID09PSBcIkludGVydmFsXCIgPyBhcmdzWzFdIHx8IDAgOiB2b2lkIDAsXG4gICAgICAgIGFyZ3NcbiAgICAgIH07XG4gICAgICBjb25zdCBjYWxsYmFjayA9IGFyZ3NbMF07XG4gICAgICBhcmdzWzBdID0gZnVuY3Rpb24gdGltZXIoKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmV0dXJuIGNhbGxiYWNrLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgY29uc3QgeyBoYW5kbGU6IGhhbmRsZTIsIGhhbmRsZUlkOiBoYW5kbGVJZDIsIGlzUGVyaW9kaWM6IGlzUGVyaW9kaWMyLCBpc1JlZnJlc2hhYmxlOiBpc1JlZnJlc2hhYmxlMiB9ID0gb3B0aW9ucztcbiAgICAgICAgICBpZiAoIWlzUGVyaW9kaWMyICYmICFpc1JlZnJlc2hhYmxlMikge1xuICAgICAgICAgICAgaWYgKGhhbmRsZUlkMikge1xuICAgICAgICAgICAgICBkZWxldGUgdGFza3NCeUhhbmRsZUlkW2hhbmRsZUlkMl07XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGhhbmRsZTIpIHtcbiAgICAgICAgICAgICAgaGFuZGxlMlt0YXNrU3ltYm9sXSA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgY29uc3QgdGFzayA9IHNjaGVkdWxlTWFjcm9UYXNrV2l0aEN1cnJlbnRab25lKHNldE5hbWUsIGFyZ3NbMF0sIG9wdGlvbnMsIHNjaGVkdWxlVGFzaywgY2xlYXJUYXNrKTtcbiAgICAgIGlmICghdGFzaykge1xuICAgICAgICByZXR1cm4gdGFzaztcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgaGFuZGxlSWQsIGhhbmRsZSwgaXNSZWZyZXNoYWJsZSwgaXNQZXJpb2RpYyB9ID0gdGFzay5kYXRhO1xuICAgICAgaWYgKGhhbmRsZUlkKSB7XG4gICAgICAgIHRhc2tzQnlIYW5kbGVJZFtoYW5kbGVJZF0gPSB0YXNrO1xuICAgICAgfSBlbHNlIGlmIChoYW5kbGUpIHtcbiAgICAgICAgaGFuZGxlW3Rhc2tTeW1ib2xdID0gdGFzaztcbiAgICAgICAgaWYgKGlzUmVmcmVzaGFibGUgJiYgIWlzUGVyaW9kaWMpIHtcbiAgICAgICAgICBjb25zdCBvcmlnaW5hbFJlZnJlc2ggPSBoYW5kbGUucmVmcmVzaDtcbiAgICAgICAgICBoYW5kbGUucmVmcmVzaCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgY29uc3QgeyB6b25lLCBzdGF0ZSB9ID0gdGFzaztcbiAgICAgICAgICAgIGlmIChzdGF0ZSA9PT0gXCJub3RTY2hlZHVsZWRcIikge1xuICAgICAgICAgICAgICB0YXNrLl9zdGF0ZSA9IFwic2NoZWR1bGVkXCI7XG4gICAgICAgICAgICAgIHpvbmUuX3VwZGF0ZVRhc2tDb3VudCh0YXNrLCAxKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc3RhdGUgPT09IFwicnVubmluZ1wiKSB7XG4gICAgICAgICAgICAgIHRhc2suX3N0YXRlID0gXCJzY2hlZHVsaW5nXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gb3JpZ2luYWxSZWZyZXNoLmNhbGwodGhpcyk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIChfYSA9IGhhbmRsZSAhPSBudWxsID8gaGFuZGxlIDogaGFuZGxlSWQpICE9IG51bGwgPyBfYSA6IHRhc2s7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBkZWxlZ2F0ZS5hcHBseSh3aW5kb3cyLCBhcmdzKTtcbiAgICB9XG4gIH0pO1xuICBjbGVhck5hdGl2ZSA9IHBhdGNoTWV0aG9kKHdpbmRvdzIsIGNhbmNlbE5hbWUsIChkZWxlZ2F0ZSkgPT4gZnVuY3Rpb24oc2VsZjIsIGFyZ3MpIHtcbiAgICBjb25zdCBpZCA9IGFyZ3NbMF07XG4gICAgbGV0IHRhc2s7XG4gICAgaWYgKGlzTnVtYmVyKGlkKSkge1xuICAgICAgdGFzayA9IHRhc2tzQnlIYW5kbGVJZFtpZF07XG4gICAgICBkZWxldGUgdGFza3NCeUhhbmRsZUlkW2lkXTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGFzayA9IGlkID09IG51bGwgPyB2b2lkIDAgOiBpZFt0YXNrU3ltYm9sXTtcbiAgICAgIGlmICh0YXNrKSB7XG4gICAgICAgIGlkW3Rhc2tTeW1ib2xdID0gbnVsbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRhc2sgPSBpZDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRhc2sgPT0gbnVsbCA/IHZvaWQgMCA6IHRhc2sudHlwZSkge1xuICAgICAgaWYgKHRhc2suY2FuY2VsRm4pIHtcbiAgICAgICAgdGFzay56b25lLmNhbmNlbFRhc2sodGFzayk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGRlbGVnYXRlLmFwcGx5KHdpbmRvdzIsIGFyZ3MpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8vIHBhY2thZ2VzL3pvbmUuanMvbGliL2Jyb3dzZXIvY3VzdG9tLWVsZW1lbnRzLmpzXG5mdW5jdGlvbiBwYXRjaEN1c3RvbUVsZW1lbnRzKF9nbG9iYWwyLCBhcGkpIHtcbiAgY29uc3QgeyBpc0Jyb3dzZXI6IGlzQnJvd3NlcjIsIGlzTWl4OiBpc01peDIgfSA9IGFwaS5nZXRHbG9iYWxPYmplY3RzKCk7XG4gIGlmICghaXNCcm93c2VyMiAmJiAhaXNNaXgyIHx8ICFfZ2xvYmFsMltcImN1c3RvbUVsZW1lbnRzXCJdIHx8ICEoXCJjdXN0b21FbGVtZW50c1wiIGluIF9nbG9iYWwyKSkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjYWxsYmFja3MgPSBbXG4gICAgXCJjb25uZWN0ZWRDYWxsYmFja1wiLFxuICAgIFwiZGlzY29ubmVjdGVkQ2FsbGJhY2tcIixcbiAgICBcImFkb3B0ZWRDYWxsYmFja1wiLFxuICAgIFwiYXR0cmlidXRlQ2hhbmdlZENhbGxiYWNrXCIsXG4gICAgXCJmb3JtQXNzb2NpYXRlZENhbGxiYWNrXCIsXG4gICAgXCJmb3JtRGlzYWJsZWRDYWxsYmFja1wiLFxuICAgIFwiZm9ybVJlc2V0Q2FsbGJhY2tcIixcbiAgICBcImZvcm1TdGF0ZVJlc3RvcmVDYWxsYmFja1wiXG4gIF07XG4gIGFwaS5wYXRjaENhbGxiYWNrcyhhcGksIF9nbG9iYWwyLmN1c3RvbUVsZW1lbnRzLCBcImN1c3RvbUVsZW1lbnRzXCIsIFwiZGVmaW5lXCIsIGNhbGxiYWNrcyk7XG59XG5cbi8vIHBhY2thZ2VzL3pvbmUuanMvbGliL2Jyb3dzZXIvZXZlbnQtdGFyZ2V0LmpzXG5mdW5jdGlvbiBldmVudFRhcmdldFBhdGNoKF9nbG9iYWwyLCBhcGkpIHtcbiAgaWYgKFpvbmVbYXBpLnN5bWJvbChcInBhdGNoRXZlbnRUYXJnZXRcIildKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHsgZXZlbnROYW1lcywgem9uZVN5bWJvbEV2ZW50TmFtZXM6IHpvbmVTeW1ib2xFdmVudE5hbWVzMywgVFJVRV9TVFI6IFRSVUVfU1RSMiwgRkFMU0VfU1RSOiBGQUxTRV9TVFIyLCBaT05FX1NZTUJPTF9QUkVGSVg6IFpPTkVfU1lNQk9MX1BSRUZJWDIgfSA9IGFwaS5nZXRHbG9iYWxPYmplY3RzKCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZXZlbnROYW1lcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGV2ZW50TmFtZSA9IGV2ZW50TmFtZXNbaV07XG4gICAgY29uc3QgZmFsc2VFdmVudE5hbWUgPSBldmVudE5hbWUgKyBGQUxTRV9TVFIyO1xuICAgIGNvbnN0IHRydWVFdmVudE5hbWUgPSBldmVudE5hbWUgKyBUUlVFX1NUUjI7XG4gICAgY29uc3Qgc3ltYm9sID0gWk9ORV9TWU1CT0xfUFJFRklYMiArIGZhbHNlRXZlbnROYW1lO1xuICAgIGNvbnN0IHN5bWJvbENhcHR1cmUgPSBaT05FX1NZTUJPTF9QUkVGSVgyICsgdHJ1ZUV2ZW50TmFtZTtcbiAgICB6b25lU3ltYm9sRXZlbnROYW1lczNbZXZlbnROYW1lXSA9IHt9O1xuICAgIHpvbmVTeW1ib2xFdmVudE5hbWVzM1tldmVudE5hbWVdW0ZBTFNFX1NUUjJdID0gc3ltYm9sO1xuICAgIHpvbmVTeW1ib2xFdmVudE5hbWVzM1tldmVudE5hbWVdW1RSVUVfU1RSMl0gPSBzeW1ib2xDYXB0dXJlO1xuICB9XG4gIGNvbnN0IEVWRU5UX1RBUkdFVCA9IF9nbG9iYWwyW1wiRXZlbnRUYXJnZXRcIl07XG4gIGlmICghRVZFTlRfVEFSR0VUIHx8ICFFVkVOVF9UQVJHRVQucHJvdG90eXBlKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGFwaS5wYXRjaEV2ZW50VGFyZ2V0KF9nbG9iYWwyLCBhcGksIFtFVkVOVF9UQVJHRVQgJiYgRVZFTlRfVEFSR0VULnByb3RvdHlwZV0pO1xuICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHBhdGNoRXZlbnQoZ2xvYmFsMiwgYXBpKSB7XG4gIGFwaS5wYXRjaEV2ZW50UHJvdG90eXBlKGdsb2JhbDIsIGFwaSk7XG59XG5cbi8vIHBhY2thZ2VzL3pvbmUuanMvbGliL2Jyb3dzZXIvcHJvcGVydHktZGVzY3JpcHRvci5qc1xuZnVuY3Rpb24gZmlsdGVyUHJvcGVydGllcyh0YXJnZXQsIG9uUHJvcGVydGllcywgaWdub3JlUHJvcGVydGllcykge1xuICBpZiAoIWlnbm9yZVByb3BlcnRpZXMgfHwgaWdub3JlUHJvcGVydGllcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gb25Qcm9wZXJ0aWVzO1xuICB9XG4gIGNvbnN0IHRpcCA9IGlnbm9yZVByb3BlcnRpZXMuZmlsdGVyKChpcCkgPT4gaXAudGFyZ2V0ID09PSB0YXJnZXQpO1xuICBpZiAodGlwLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBvblByb3BlcnRpZXM7XG4gIH1cbiAgY29uc3QgdGFyZ2V0SWdub3JlUHJvcGVydGllcyA9IHRpcFswXS5pZ25vcmVQcm9wZXJ0aWVzO1xuICByZXR1cm4gb25Qcm9wZXJ0aWVzLmZpbHRlcigob3ApID0+IHRhcmdldElnbm9yZVByb3BlcnRpZXMuaW5kZXhPZihvcCkgPT09IC0xKTtcbn1cbmZ1bmN0aW9uIHBhdGNoRmlsdGVyZWRQcm9wZXJ0aWVzKHRhcmdldCwgb25Qcm9wZXJ0aWVzLCBpZ25vcmVQcm9wZXJ0aWVzLCBwcm90b3R5cGUpIHtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZmlsdGVyZWRQcm9wZXJ0aWVzID0gZmlsdGVyUHJvcGVydGllcyh0YXJnZXQsIG9uUHJvcGVydGllcywgaWdub3JlUHJvcGVydGllcyk7XG4gIHBhdGNoT25Qcm9wZXJ0aWVzKHRhcmdldCwgZmlsdGVyZWRQcm9wZXJ0aWVzLCBwcm90b3R5cGUpO1xufVxuZnVuY3Rpb24gZ2V0T25FdmVudE5hbWVzKHRhcmdldCkge1xuICByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGFyZ2V0KS5maWx0ZXIoKG5hbWUpID0+IG5hbWUuc3RhcnRzV2l0aChcIm9uXCIpICYmIG5hbWUubGVuZ3RoID4gMikubWFwKChuYW1lKSA9PiBuYW1lLnN1YnN0cmluZygyKSk7XG59XG5mdW5jdGlvbiBwcm9wZXJ0eURlc2NyaXB0b3JQYXRjaChhcGksIF9nbG9iYWwyKSB7XG4gIGlmIChpc05vZGUgJiYgIWlzTWl4KSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChab25lW2FwaS5zeW1ib2woXCJwYXRjaEV2ZW50c1wiKV0pIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgaWdub3JlUHJvcGVydGllcyA9IF9nbG9iYWwyW1wiX19ab25lX2lnbm9yZV9vbl9wcm9wZXJ0aWVzXCJdO1xuICBsZXQgcGF0Y2hUYXJnZXRzID0gW107XG4gIGlmIChpc0Jyb3dzZXIpIHtcbiAgICBjb25zdCBpbnRlcm5hbFdpbmRvdzIgPSB3aW5kb3c7XG4gICAgcGF0Y2hUYXJnZXRzID0gcGF0Y2hUYXJnZXRzLmNvbmNhdChbXG4gICAgICBcIkRvY3VtZW50XCIsXG4gICAgICBcIlNWR0VsZW1lbnRcIixcbiAgICAgIFwiRWxlbWVudFwiLFxuICAgICAgXCJIVE1MRWxlbWVudFwiLFxuICAgICAgXCJIVE1MQm9keUVsZW1lbnRcIixcbiAgICAgIFwiSFRNTE1lZGlhRWxlbWVudFwiLFxuICAgICAgXCJIVE1MRnJhbWVTZXRFbGVtZW50XCIsXG4gICAgICBcIkhUTUxGcmFtZUVsZW1lbnRcIixcbiAgICAgIFwiSFRNTElGcmFtZUVsZW1lbnRcIixcbiAgICAgIFwiSFRNTE1hcnF1ZWVFbGVtZW50XCIsXG4gICAgICBcIldvcmtlclwiXG4gICAgXSk7XG4gICAgcGF0Y2hGaWx0ZXJlZFByb3BlcnRpZXMoaW50ZXJuYWxXaW5kb3cyLCBnZXRPbkV2ZW50TmFtZXMoaW50ZXJuYWxXaW5kb3cyKSwgaWdub3JlUHJvcGVydGllcywgT2JqZWN0R2V0UHJvdG90eXBlT2YoaW50ZXJuYWxXaW5kb3cyKSk7XG4gIH1cbiAgcGF0Y2hUYXJnZXRzID0gcGF0Y2hUYXJnZXRzLmNvbmNhdChbXG4gICAgXCJYTUxIdHRwUmVxdWVzdFwiLFxuICAgIFwiWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldFwiLFxuICAgIFwiSURCSW5kZXhcIixcbiAgICBcIklEQlJlcXVlc3RcIixcbiAgICBcIklEQk9wZW5EQlJlcXVlc3RcIixcbiAgICBcIklEQkRhdGFiYXNlXCIsXG4gICAgXCJJREJUcmFuc2FjdGlvblwiLFxuICAgIFwiSURCQ3Vyc29yXCIsXG4gICAgXCJXZWJTb2NrZXRcIlxuICBdKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRjaFRhcmdldHMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCB0YXJnZXQgPSBfZ2xvYmFsMltwYXRjaFRhcmdldHNbaV1dO1xuICAgICh0YXJnZXQgPT0gbnVsbCA/IHZvaWQgMCA6IHRhcmdldC5wcm90b3R5cGUpICYmIHBhdGNoRmlsdGVyZWRQcm9wZXJ0aWVzKHRhcmdldC5wcm90b3R5cGUsIGdldE9uRXZlbnROYW1lcyh0YXJnZXQucHJvdG90eXBlKSwgaWdub3JlUHJvcGVydGllcyk7XG4gIH1cbn1cblxuLy8gcGFja2FnZXMvem9uZS5qcy9saWIvYnJvd3Nlci9icm93c2VyLmpzXG5mdW5jdGlvbiBwYXRjaEJyb3dzZXIoWm9uZTMpIHtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwidGltZXJzXCIsIChnbG9iYWwyKSA9PiB7XG4gICAgY29uc3Qgc2V0ID0gXCJzZXRcIjtcbiAgICBjb25zdCBjbGVhciA9IFwiY2xlYXJcIjtcbiAgICBwYXRjaFRpbWVyKGdsb2JhbDIsIHNldCwgY2xlYXIsIFwiVGltZW91dFwiKTtcbiAgICBwYXRjaFRpbWVyKGdsb2JhbDIsIHNldCwgY2xlYXIsIFwiSW50ZXJ2YWxcIik7XG4gICAgcGF0Y2hUaW1lcihnbG9iYWwyLCBzZXQsIGNsZWFyLCBcIkltbWVkaWF0ZVwiKTtcbiAgfSk7XG4gIFpvbmUzLl9fbG9hZF9wYXRjaChcInJlcXVlc3RBbmltYXRpb25GcmFtZVwiLCAoZ2xvYmFsMikgPT4ge1xuICAgIHBhdGNoVGltZXIoZ2xvYmFsMiwgXCJyZXF1ZXN0XCIsIFwiY2FuY2VsXCIsIFwiQW5pbWF0aW9uRnJhbWVcIik7XG4gICAgcGF0Y2hUaW1lcihnbG9iYWwyLCBcIm1velJlcXVlc3RcIiwgXCJtb3pDYW5jZWxcIiwgXCJBbmltYXRpb25GcmFtZVwiKTtcbiAgICBwYXRjaFRpbWVyKGdsb2JhbDIsIFwid2Via2l0UmVxdWVzdFwiLCBcIndlYmtpdENhbmNlbFwiLCBcIkFuaW1hdGlvbkZyYW1lXCIpO1xuICB9KTtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwiYmxvY2tpbmdcIiwgKGdsb2JhbDIsIFpvbmU0KSA9PiB7XG4gICAgY29uc3QgYmxvY2tpbmdNZXRob2RzID0gW1wiYWxlcnRcIiwgXCJwcm9tcHRcIiwgXCJjb25maXJtXCJdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYmxvY2tpbmdNZXRob2RzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBuYW1lID0gYmxvY2tpbmdNZXRob2RzW2ldO1xuICAgICAgcGF0Y2hNZXRob2QoZ2xvYmFsMiwgbmFtZSwgKGRlbGVnYXRlLCBzeW1ib2wsIG5hbWUyKSA9PiB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbihzLCBhcmdzKSB7XG4gICAgICAgICAgcmV0dXJuIFpvbmU0LmN1cnJlbnQucnVuKGRlbGVnYXRlLCBnbG9iYWwyLCBhcmdzLCBuYW1lMik7XG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuICBab25lMy5fX2xvYWRfcGF0Y2goXCJFdmVudFRhcmdldFwiLCAoZ2xvYmFsMiwgWm9uZTQsIGFwaSkgPT4ge1xuICAgIHBhdGNoRXZlbnQoZ2xvYmFsMiwgYXBpKTtcbiAgICBldmVudFRhcmdldFBhdGNoKGdsb2JhbDIsIGFwaSk7XG4gICAgY29uc3QgWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldCA9IGdsb2JhbDJbXCJYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0XCJdO1xuICAgIGlmIChYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0ICYmIFhNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQucHJvdG90eXBlKSB7XG4gICAgICBhcGkucGF0Y2hFdmVudFRhcmdldChnbG9iYWwyLCBhcGksIFtYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0LnByb3RvdHlwZV0pO1xuICAgIH1cbiAgfSk7XG4gIFpvbmUzLl9fbG9hZF9wYXRjaChcIk11dGF0aW9uT2JzZXJ2ZXJcIiwgKGdsb2JhbDIsIFpvbmU0LCBhcGkpID0+IHtcbiAgICBwYXRjaENsYXNzKFwiTXV0YXRpb25PYnNlcnZlclwiKTtcbiAgICBwYXRjaENsYXNzKFwiV2ViS2l0TXV0YXRpb25PYnNlcnZlclwiKTtcbiAgfSk7XG4gIFpvbmUzLl9fbG9hZF9wYXRjaChcIkludGVyc2VjdGlvbk9ic2VydmVyXCIsIChnbG9iYWwyLCBab25lNCwgYXBpKSA9PiB7XG4gICAgcGF0Y2hDbGFzcyhcIkludGVyc2VjdGlvbk9ic2VydmVyXCIpO1xuICB9KTtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwiRmlsZVJlYWRlclwiLCAoZ2xvYmFsMiwgWm9uZTQsIGFwaSkgPT4ge1xuICAgIHBhdGNoQ2xhc3MoXCJGaWxlUmVhZGVyXCIpO1xuICB9KTtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwib25fcHJvcGVydHlcIiwgKGdsb2JhbDIsIFpvbmU0LCBhcGkpID0+IHtcbiAgICBwcm9wZXJ0eURlc2NyaXB0b3JQYXRjaChhcGksIGdsb2JhbDIpO1xuICB9KTtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwiY3VzdG9tRWxlbWVudHNcIiwgKGdsb2JhbDIsIFpvbmU0LCBhcGkpID0+IHtcbiAgICBwYXRjaEN1c3RvbUVsZW1lbnRzKGdsb2JhbDIsIGFwaSk7XG4gIH0pO1xuICBab25lMy5fX2xvYWRfcGF0Y2goXCJYSFJcIiwgKGdsb2JhbDIsIFpvbmU0KSA9PiB7XG4gICAgcGF0Y2hYSFIoZ2xvYmFsMik7XG4gICAgY29uc3QgWEhSX1RBU0sgPSB6b25lU3ltYm9sKFwieGhyVGFza1wiKTtcbiAgICBjb25zdCBYSFJfU1lOQyA9IHpvbmVTeW1ib2woXCJ4aHJTeW5jXCIpO1xuICAgIGNvbnN0IFhIUl9MSVNURU5FUiA9IHpvbmVTeW1ib2woXCJ4aHJMaXN0ZW5lclwiKTtcbiAgICBjb25zdCBYSFJfU0NIRURVTEVEID0gem9uZVN5bWJvbChcInhoclNjaGVkdWxlZFwiKTtcbiAgICBjb25zdCBYSFJfVVJMID0gem9uZVN5bWJvbChcInhoclVSTFwiKTtcbiAgICBjb25zdCBYSFJfRVJST1JfQkVGT1JFX1NDSEVEVUxFRCA9IHpvbmVTeW1ib2woXCJ4aHJFcnJvckJlZm9yZVNjaGVkdWxlZFwiKTtcbiAgICBmdW5jdGlvbiBwYXRjaFhIUih3aW5kb3cyKSB7XG4gICAgICBjb25zdCBYTUxIdHRwUmVxdWVzdCA9IHdpbmRvdzJbXCJYTUxIdHRwUmVxdWVzdFwiXTtcbiAgICAgIGlmICghWE1MSHR0cFJlcXVlc3QpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgWE1MSHR0cFJlcXVlc3RQcm90b3R5cGUgPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGU7XG4gICAgICBmdW5jdGlvbiBmaW5kUGVuZGluZ1Rhc2sodGFyZ2V0KSB7XG4gICAgICAgIHJldHVybiB0YXJnZXRbWEhSX1RBU0tdO1xuICAgICAgfVxuICAgICAgbGV0IG9yaUFkZExpc3RlbmVyID0gWE1MSHR0cFJlcXVlc3RQcm90b3R5cGVbWk9ORV9TWU1CT0xfQUREX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgIGxldCBvcmlSZW1vdmVMaXN0ZW5lciA9IFhNTEh0dHBSZXF1ZXN0UHJvdG90eXBlW1pPTkVfU1lNQk9MX1JFTU9WRV9FVkVOVF9MSVNURU5FUl07XG4gICAgICBpZiAoIW9yaUFkZExpc3RlbmVyKSB7XG4gICAgICAgIGNvbnN0IFhNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQgPSB3aW5kb3cyW1wiWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldFwiXTtcbiAgICAgICAgaWYgKFhNTEh0dHBSZXF1ZXN0RXZlbnRUYXJnZXQpIHtcbiAgICAgICAgICBjb25zdCBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0UHJvdG90eXBlID0gWE1MSHR0cFJlcXVlc3RFdmVudFRhcmdldC5wcm90b3R5cGU7XG4gICAgICAgICAgb3JpQWRkTGlzdGVuZXIgPSBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0UHJvdG90eXBlW1pPTkVfU1lNQk9MX0FERF9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgICAgb3JpUmVtb3ZlTGlzdGVuZXIgPSBYTUxIdHRwUmVxdWVzdEV2ZW50VGFyZ2V0UHJvdG90eXBlW1pPTkVfU1lNQk9MX1JFTU9WRV9FVkVOVF9MSVNURU5FUl07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNvbnN0IFJFQURZX1NUQVRFX0NIQU5HRSA9IFwicmVhZHlzdGF0ZWNoYW5nZVwiO1xuICAgICAgY29uc3QgU0NIRURVTEVEID0gXCJzY2hlZHVsZWRcIjtcbiAgICAgIGZ1bmN0aW9uIHNjaGVkdWxlVGFzayh0YXNrKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSB0YXNrLmRhdGE7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGRhdGEudGFyZ2V0O1xuICAgICAgICB0YXJnZXRbWEhSX1NDSEVEVUxFRF0gPSBmYWxzZTtcbiAgICAgICAgdGFyZ2V0W1hIUl9FUlJPUl9CRUZPUkVfU0NIRURVTEVEXSA9IGZhbHNlO1xuICAgICAgICBjb25zdCBsaXN0ZW5lciA9IHRhcmdldFtYSFJfTElTVEVORVJdO1xuICAgICAgICBpZiAoIW9yaUFkZExpc3RlbmVyKSB7XG4gICAgICAgICAgb3JpQWRkTGlzdGVuZXIgPSB0YXJnZXRbWk9ORV9TWU1CT0xfQUREX0VWRU5UX0xJU1RFTkVSXTtcbiAgICAgICAgICBvcmlSZW1vdmVMaXN0ZW5lciA9IHRhcmdldFtaT05FX1NZTUJPTF9SRU1PVkVfRVZFTlRfTElTVEVORVJdO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsaXN0ZW5lcikge1xuICAgICAgICAgIG9yaVJlbW92ZUxpc3RlbmVyLmNhbGwodGFyZ2V0LCBSRUFEWV9TVEFURV9DSEFOR0UsIGxpc3RlbmVyKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuZXdMaXN0ZW5lciA9IHRhcmdldFtYSFJfTElTVEVORVJdID0gKCkgPT4ge1xuICAgICAgICAgIGlmICh0YXJnZXQucmVhZHlTdGF0ZSA9PT0gdGFyZ2V0LkRPTkUpIHtcbiAgICAgICAgICAgIGlmICghZGF0YS5hYm9ydGVkICYmIHRhcmdldFtYSFJfU0NIRURVTEVEXSAmJiB0YXNrLnN0YXRlID09PSBTQ0hFRFVMRUQpIHtcbiAgICAgICAgICAgICAgY29uc3QgbG9hZFRhc2tzID0gdGFyZ2V0W1pvbmU0Ll9fc3ltYm9sX18oXCJsb2FkZmFsc2VcIildO1xuICAgICAgICAgICAgICBpZiAodGFyZ2V0LnN0YXR1cyAhPT0gMCAmJiBsb2FkVGFza3MgJiYgbG9hZFRhc2tzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvcmlJbnZva2UgPSB0YXNrLmludm9rZTtcbiAgICAgICAgICAgICAgICB0YXNrLmludm9rZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgbG9hZFRhc2tzMiA9IHRhcmdldFtab25lNC5fX3N5bWJvbF9fKFwibG9hZGZhbHNlXCIpXTtcbiAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbG9hZFRhc2tzMi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBpZiAobG9hZFRhc2tzMltpXSA9PT0gdGFzaykge1xuICAgICAgICAgICAgICAgICAgICAgIGxvYWRUYXNrczIuc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoIWRhdGEuYWJvcnRlZCAmJiB0YXNrLnN0YXRlID09PSBTQ0hFRFVMRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgb3JpSW52b2tlLmNhbGwodGFzayk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBsb2FkVGFza3MucHVzaCh0YXNrKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0YXNrLmludm9rZSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCFkYXRhLmFib3J0ZWQgJiYgdGFyZ2V0W1hIUl9TQ0hFRFVMRURdID09PSBmYWxzZSkge1xuICAgICAgICAgICAgICB0YXJnZXRbWEhSX0VSUk9SX0JFRk9SRV9TQ0hFRFVMRURdID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIG9yaUFkZExpc3RlbmVyLmNhbGwodGFyZ2V0LCBSRUFEWV9TVEFURV9DSEFOR0UsIG5ld0xpc3RlbmVyKTtcbiAgICAgICAgY29uc3Qgc3RvcmVkVGFzayA9IHRhcmdldFtYSFJfVEFTS107XG4gICAgICAgIGlmICghc3RvcmVkVGFzaykge1xuICAgICAgICAgIHRhcmdldFtYSFJfVEFTS10gPSB0YXNrO1xuICAgICAgICB9XG4gICAgICAgIHNlbmROYXRpdmUuYXBwbHkodGFyZ2V0LCBkYXRhLmFyZ3MpO1xuICAgICAgICB0YXJnZXRbWEhSX1NDSEVEVUxFRF0gPSB0cnVlO1xuICAgICAgICByZXR1cm4gdGFzaztcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIHBsYWNlaG9sZGVyQ2FsbGJhY2soKSB7XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiBjbGVhclRhc2sodGFzaykge1xuICAgICAgICBjb25zdCBkYXRhID0gdGFzay5kYXRhO1xuICAgICAgICBkYXRhLmFib3J0ZWQgPSB0cnVlO1xuICAgICAgICByZXR1cm4gYWJvcnROYXRpdmUuYXBwbHkoZGF0YS50YXJnZXQsIGRhdGEuYXJncyk7XG4gICAgICB9XG4gICAgICBjb25zdCBvcGVuTmF0aXZlID0gcGF0Y2hNZXRob2QoWE1MSHR0cFJlcXVlc3RQcm90b3R5cGUsIFwib3BlblwiLCAoKSA9PiBmdW5jdGlvbihzZWxmMiwgYXJncykge1xuICAgICAgICBzZWxmMltYSFJfU1lOQ10gPSBhcmdzWzJdID09IGZhbHNlO1xuICAgICAgICBzZWxmMltYSFJfVVJMXSA9IGFyZ3NbMV07XG4gICAgICAgIHJldHVybiBvcGVuTmF0aXZlLmFwcGx5KHNlbGYyLCBhcmdzKTtcbiAgICAgIH0pO1xuICAgICAgY29uc3QgWE1MSFRUUFJFUVVFU1RfU09VUkNFID0gXCJYTUxIdHRwUmVxdWVzdC5zZW5kXCI7XG4gICAgICBjb25zdCBmZXRjaFRhc2tBYm9ydGluZyA9IHpvbmVTeW1ib2woXCJmZXRjaFRhc2tBYm9ydGluZ1wiKTtcbiAgICAgIGNvbnN0IGZldGNoVGFza1NjaGVkdWxpbmcgPSB6b25lU3ltYm9sKFwiZmV0Y2hUYXNrU2NoZWR1bGluZ1wiKTtcbiAgICAgIGNvbnN0IHNlbmROYXRpdmUgPSBwYXRjaE1ldGhvZChYTUxIdHRwUmVxdWVzdFByb3RvdHlwZSwgXCJzZW5kXCIsICgpID0+IGZ1bmN0aW9uKHNlbGYyLCBhcmdzKSB7XG4gICAgICAgIGlmIChab25lNC5jdXJyZW50W2ZldGNoVGFza1NjaGVkdWxpbmddID09PSB0cnVlKSB7XG4gICAgICAgICAgcmV0dXJuIHNlbmROYXRpdmUuYXBwbHkoc2VsZjIsIGFyZ3MpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzZWxmMltYSFJfU1lOQ10pIHtcbiAgICAgICAgICByZXR1cm4gc2VuZE5hdGl2ZS5hcHBseShzZWxmMiwgYXJncyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgICAgIHRhcmdldDogc2VsZjIsXG4gICAgICAgICAgICB1cmw6IHNlbGYyW1hIUl9VUkxdLFxuICAgICAgICAgICAgaXNQZXJpb2RpYzogZmFsc2UsXG4gICAgICAgICAgICBhcmdzLFxuICAgICAgICAgICAgYWJvcnRlZDogZmFsc2VcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IHRhc2sgPSBzY2hlZHVsZU1hY3JvVGFza1dpdGhDdXJyZW50Wm9uZShYTUxIVFRQUkVRVUVTVF9TT1VSQ0UsIHBsYWNlaG9sZGVyQ2FsbGJhY2ssIG9wdGlvbnMsIHNjaGVkdWxlVGFzaywgY2xlYXJUYXNrKTtcbiAgICAgICAgICBpZiAoc2VsZjIgJiYgc2VsZjJbWEhSX0VSUk9SX0JFRk9SRV9TQ0hFRFVMRURdID09PSB0cnVlICYmICFvcHRpb25zLmFib3J0ZWQgJiYgdGFzay5zdGF0ZSA9PT0gU0NIRURVTEVEKSB7XG4gICAgICAgICAgICB0YXNrLmludm9rZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBjb25zdCBhYm9ydE5hdGl2ZSA9IHBhdGNoTWV0aG9kKFhNTEh0dHBSZXF1ZXN0UHJvdG90eXBlLCBcImFib3J0XCIsICgpID0+IGZ1bmN0aW9uKHNlbGYyLCBhcmdzKSB7XG4gICAgICAgIGNvbnN0IHRhc2sgPSBmaW5kUGVuZGluZ1Rhc2soc2VsZjIpO1xuICAgICAgICBpZiAodGFzayAmJiB0eXBlb2YgdGFzay50eXBlID09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICBpZiAodGFzay5jYW5jZWxGbiA9PSBudWxsIHx8IHRhc2suZGF0YSAmJiB0YXNrLmRhdGEuYWJvcnRlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0YXNrLnpvbmUuY2FuY2VsVGFzayh0YXNrKTtcbiAgICAgICAgfSBlbHNlIGlmIChab25lNC5jdXJyZW50W2ZldGNoVGFza0Fib3J0aW5nXSA9PT0gdHJ1ZSkge1xuICAgICAgICAgIHJldHVybiBhYm9ydE5hdGl2ZS5hcHBseShzZWxmMiwgYXJncyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG4gIFpvbmUzLl9fbG9hZF9wYXRjaChcImdlb2xvY2F0aW9uXCIsIChnbG9iYWwyKSA9PiB7XG4gICAgaWYgKGdsb2JhbDJbXCJuYXZpZ2F0b3JcIl0gJiYgZ2xvYmFsMltcIm5hdmlnYXRvclwiXS5nZW9sb2NhdGlvbikge1xuICAgICAgcGF0Y2hQcm90b3R5cGUoZ2xvYmFsMltcIm5hdmlnYXRvclwiXS5nZW9sb2NhdGlvbiwgW1wiZ2V0Q3VycmVudFBvc2l0aW9uXCIsIFwid2F0Y2hQb3NpdGlvblwiXSk7XG4gICAgfVxuICB9KTtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwiUHJvbWlzZVJlamVjdGlvbkV2ZW50XCIsIChnbG9iYWwyLCBab25lNCkgPT4ge1xuICAgIGZ1bmN0aW9uIGZpbmRQcm9taXNlUmVqZWN0aW9uSGFuZGxlcihldnROYW1lKSB7XG4gICAgICByZXR1cm4gZnVuY3Rpb24oZSkge1xuICAgICAgICBjb25zdCBldmVudFRhc2tzID0gZmluZEV2ZW50VGFza3MoZ2xvYmFsMiwgZXZ0TmFtZSk7XG4gICAgICAgIGV2ZW50VGFza3MuZm9yRWFjaCgoZXZlbnRUYXNrKSA9PiB7XG4gICAgICAgICAgY29uc3QgUHJvbWlzZVJlamVjdGlvbkV2ZW50ID0gZ2xvYmFsMltcIlByb21pc2VSZWplY3Rpb25FdmVudFwiXTtcbiAgICAgICAgICBpZiAoUHJvbWlzZVJlamVjdGlvbkV2ZW50KSB7XG4gICAgICAgICAgICBjb25zdCBldnQgPSBuZXcgUHJvbWlzZVJlamVjdGlvbkV2ZW50KGV2dE5hbWUsIHtcbiAgICAgICAgICAgICAgcHJvbWlzZTogZS5wcm9taXNlLFxuICAgICAgICAgICAgICByZWFzb246IGUucmVqZWN0aW9uXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGV2ZW50VGFzay5pbnZva2UoZXZ0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKGdsb2JhbDJbXCJQcm9taXNlUmVqZWN0aW9uRXZlbnRcIl0pIHtcbiAgICAgIFpvbmU0W3pvbmVTeW1ib2woXCJ1bmhhbmRsZWRQcm9taXNlUmVqZWN0aW9uSGFuZGxlclwiKV0gPSBmaW5kUHJvbWlzZVJlamVjdGlvbkhhbmRsZXIoXCJ1bmhhbmRsZWRyZWplY3Rpb25cIik7XG4gICAgICBab25lNFt6b25lU3ltYm9sKFwicmVqZWN0aW9uSGFuZGxlZEhhbmRsZXJcIildID0gZmluZFByb21pc2VSZWplY3Rpb25IYW5kbGVyKFwicmVqZWN0aW9uaGFuZGxlZFwiKTtcbiAgICB9XG4gIH0pO1xuICBab25lMy5fX2xvYWRfcGF0Y2goXCJxdWV1ZU1pY3JvdGFza1wiLCAoZ2xvYmFsMiwgWm9uZTQsIGFwaSkgPT4ge1xuICAgIHBhdGNoUXVldWVNaWNyb3Rhc2soZ2xvYmFsMiwgYXBpKTtcbiAgfSk7XG59XG5cbi8vIHBhY2thZ2VzL3pvbmUuanMvbGliL2NvbW1vbi9wcm9taXNlLmpzXG5mdW5jdGlvbiBwYXRjaFByb21pc2UoWm9uZTMpIHtcbiAgWm9uZTMuX19sb2FkX3BhdGNoKFwiWm9uZUF3YXJlUHJvbWlzZVwiLCAoZ2xvYmFsMiwgWm9uZTQsIGFwaSkgPT4ge1xuICAgIGNvbnN0IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcjIgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuICAgIGNvbnN0IE9iamVjdERlZmluZVByb3BlcnR5MiA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbiAgICBmdW5jdGlvbiByZWFkYWJsZU9iamVjdFRvU3RyaW5nKG9iaikge1xuICAgICAgaWYgKG9iaiAmJiBvYmoudG9TdHJpbmcgPT09IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcpIHtcbiAgICAgICAgY29uc3QgY2xhc3NOYW1lID0gb2JqLmNvbnN0cnVjdG9yICYmIG9iai5jb25zdHJ1Y3Rvci5uYW1lO1xuICAgICAgICByZXR1cm4gKGNsYXNzTmFtZSA/IGNsYXNzTmFtZSA6IFwiXCIpICsgXCI6IFwiICsgSlNPTi5zdHJpbmdpZnkob2JqKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBvYmogPyBvYmoudG9TdHJpbmcoKSA6IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopO1xuICAgIH1cbiAgICBjb25zdCBfX3N5bWJvbF9fMiA9IGFwaS5zeW1ib2w7XG4gICAgY29uc3QgX3VuY2F1Z2h0UHJvbWlzZUVycm9ycyA9IFtdO1xuICAgIGNvbnN0IGlzRGlzYWJsZVdyYXBwaW5nVW5jYXVnaHRQcm9taXNlUmVqZWN0aW9uID0gZ2xvYmFsMltfX3N5bWJvbF9fMihcIkRJU0FCTEVfV1JBUFBJTkdfVU5DQVVHSFRfUFJPTUlTRV9SRUpFQ1RJT05cIildICE9PSBmYWxzZTtcbiAgICBjb25zdCBzeW1ib2xQcm9taXNlID0gX19zeW1ib2xfXzIoXCJQcm9taXNlXCIpO1xuICAgIGNvbnN0IHN5bWJvbFRoZW4gPSBfX3N5bWJvbF9fMihcInRoZW5cIik7XG4gICAgY29uc3QgY3JlYXRpb25UcmFjZSA9IFwiX19jcmVhdGlvblRyYWNlX19cIjtcbiAgICBhcGkub25VbmhhbmRsZWRFcnJvciA9IChlKSA9PiB7XG4gICAgICBpZiAoYXBpLnNob3dVbmNhdWdodEVycm9yKCkpIHtcbiAgICAgICAgY29uc3QgcmVqZWN0aW9uID0gZSAmJiBlLnJlamVjdGlvbjtcbiAgICAgICAgaWYgKHJlamVjdGlvbikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmhhbmRsZWQgUHJvbWlzZSByZWplY3Rpb246XCIsIHJlamVjdGlvbiBpbnN0YW5jZW9mIEVycm9yID8gcmVqZWN0aW9uLm1lc3NhZ2UgOiByZWplY3Rpb24sIFwiOyBab25lOlwiLCBlLnpvbmUubmFtZSwgXCI7IFRhc2s6XCIsIGUudGFzayAmJiBlLnRhc2suc291cmNlLCBcIjsgVmFsdWU6XCIsIHJlamVjdGlvbiwgcmVqZWN0aW9uIGluc3RhbmNlb2YgRXJyb3IgPyByZWplY3Rpb24uc3RhY2sgOiB2b2lkIDApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIGFwaS5taWNyb3Rhc2tEcmFpbkRvbmUgPSAoKSA9PiB7XG4gICAgICB3aGlsZSAoX3VuY2F1Z2h0UHJvbWlzZUVycm9ycy5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgdW5jYXVnaHRQcm9taXNlRXJyb3IgPSBfdW5jYXVnaHRQcm9taXNlRXJyb3JzLnNoaWZ0KCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgdW5jYXVnaHRQcm9taXNlRXJyb3Iuem9uZS5ydW5HdWFyZGVkKCgpID0+IHtcbiAgICAgICAgICAgIGlmICh1bmNhdWdodFByb21pc2VFcnJvci50aHJvd09yaWdpbmFsKSB7XG4gICAgICAgICAgICAgIHRocm93IHVuY2F1Z2h0UHJvbWlzZUVycm9yLnJlamVjdGlvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IHVuY2F1Z2h0UHJvbWlzZUVycm9yO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGhhbmRsZVVuaGFuZGxlZFJlamVjdGlvbihlcnJvcik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IFVOSEFORExFRF9QUk9NSVNFX1JFSkVDVElPTl9IQU5ETEVSX1NZTUJPTCA9IF9fc3ltYm9sX18yKFwidW5oYW5kbGVkUHJvbWlzZVJlamVjdGlvbkhhbmRsZXJcIik7XG4gICAgZnVuY3Rpb24gaGFuZGxlVW5oYW5kbGVkUmVqZWN0aW9uKGUpIHtcbiAgICAgIGFwaS5vblVuaGFuZGxlZEVycm9yKGUpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgaGFuZGxlciA9IFpvbmU0W1VOSEFORExFRF9QUk9NSVNFX1JFSkVDVElPTl9IQU5ETEVSX1NZTUJPTF07XG4gICAgICAgIGlmICh0eXBlb2YgaGFuZGxlciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMsIGUpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gaXNUaGVuYWJsZSh2YWx1ZSkge1xuICAgICAgcmV0dXJuIHZhbHVlICYmIHR5cGVvZiB2YWx1ZS50aGVuID09PSBcImZ1bmN0aW9uXCI7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGZvcndhcmRSZXNvbHV0aW9uKHZhbHVlKSB7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGZvcndhcmRSZWplY3Rpb24ocmVqZWN0aW9uKSB7XG4gICAgICByZXR1cm4gWm9uZUF3YXJlUHJvbWlzZS5yZWplY3QocmVqZWN0aW9uKTtcbiAgICB9XG4gICAgY29uc3Qgc3ltYm9sU3RhdGUgPSBfX3N5bWJvbF9fMihcInN0YXRlXCIpO1xuICAgIGNvbnN0IHN5bWJvbFZhbHVlID0gX19zeW1ib2xfXzIoXCJ2YWx1ZVwiKTtcbiAgICBjb25zdCBzeW1ib2xGaW5hbGx5ID0gX19zeW1ib2xfXzIoXCJmaW5hbGx5XCIpO1xuICAgIGNvbnN0IHN5bWJvbFBhcmVudFByb21pc2VWYWx1ZSA9IF9fc3ltYm9sX18yKFwicGFyZW50UHJvbWlzZVZhbHVlXCIpO1xuICAgIGNvbnN0IHN5bWJvbFBhcmVudFByb21pc2VTdGF0ZSA9IF9fc3ltYm9sX18yKFwicGFyZW50UHJvbWlzZVN0YXRlXCIpO1xuICAgIGNvbnN0IHNvdXJjZSA9IFwiUHJvbWlzZS50aGVuXCI7XG4gICAgY29uc3QgVU5SRVNPTFZFRCA9IG51bGw7XG4gICAgY29uc3QgUkVTT0xWRUQgPSB0cnVlO1xuICAgIGNvbnN0IFJFSkVDVEVEID0gZmFsc2U7XG4gICAgY29uc3QgUkVKRUNURURfTk9fQ0FUQ0ggPSAwO1xuICAgIGZ1bmN0aW9uIG1ha2VSZXNvbHZlcihwcm9taXNlLCBzdGF0ZSkge1xuICAgICAgcmV0dXJuICh2KSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgc3RhdGUsIHYpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICByZXNvbHZlUHJvbWlzZShwcm9taXNlLCBmYWxzZSwgZXJyKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3Qgb25jZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgbGV0IHdhc0NhbGxlZCA9IGZhbHNlO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uIHdyYXBwZXIod3JhcHBlZEZ1bmN0aW9uKSB7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBpZiAod2FzQ2FsbGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIHdhc0NhbGxlZCA9IHRydWU7XG4gICAgICAgICAgd3JhcHBlZEZ1bmN0aW9uLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG4gICAgICAgIH07XG4gICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgVFlQRV9FUlJPUiA9IFwiUHJvbWlzZSByZXNvbHZlZCB3aXRoIGl0c2VsZlwiO1xuICAgIGNvbnN0IENVUlJFTlRfVEFTS19UUkFDRV9TWU1CT0wgPSBfX3N5bWJvbF9fMihcImN1cnJlbnRUYXNrVHJhY2VcIik7XG4gICAgZnVuY3Rpb24gcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgc3RhdGUsIHZhbHVlKSB7XG4gICAgICBjb25zdCBvbmNlV3JhcHBlciA9IG9uY2UoKTtcbiAgICAgIGlmIChwcm9taXNlID09PSB2YWx1ZSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFRZUEVfRVJST1IpO1xuICAgICAgfVxuICAgICAgaWYgKHByb21pc2Vbc3ltYm9sU3RhdGVdID09PSBVTlJFU09MVkVEKSB7XG4gICAgICAgIGxldCB0aGVuID0gbnVsbDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICB0aGVuID0gdmFsdWUgJiYgdmFsdWUudGhlbjtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIG9uY2VXcmFwcGVyKCgpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmVQcm9taXNlKHByb21pc2UsIGZhbHNlLCBlcnIpO1xuICAgICAgICAgIH0pKCk7XG4gICAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXRlICE9PSBSRUpFQ1RFRCAmJiB2YWx1ZSBpbnN0YW5jZW9mIFpvbmVBd2FyZVByb21pc2UgJiYgdmFsdWUuaGFzT3duUHJvcGVydHkoc3ltYm9sU3RhdGUpICYmIHZhbHVlLmhhc093blByb3BlcnR5KHN5bWJvbFZhbHVlKSAmJiB2YWx1ZVtzeW1ib2xTdGF0ZV0gIT09IFVOUkVTT0xWRUQpIHtcbiAgICAgICAgICBjbGVhclJlamVjdGVkTm9DYXRjaCh2YWx1ZSk7XG4gICAgICAgICAgcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgdmFsdWVbc3ltYm9sU3RhdGVdLCB2YWx1ZVtzeW1ib2xWYWx1ZV0pO1xuICAgICAgICB9IGVsc2UgaWYgKHN0YXRlICE9PSBSRUpFQ1RFRCAmJiB0eXBlb2YgdGhlbiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoZW4uY2FsbCh2YWx1ZSwgb25jZVdyYXBwZXIobWFrZVJlc29sdmVyKHByb21pc2UsIHN0YXRlKSksIG9uY2VXcmFwcGVyKG1ha2VSZXNvbHZlcihwcm9taXNlLCBmYWxzZSkpKTtcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIG9uY2VXcmFwcGVyKCgpID0+IHtcbiAgICAgICAgICAgICAgcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgZmFsc2UsIGVycik7XG4gICAgICAgICAgICB9KSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwcm9taXNlW3N5bWJvbFN0YXRlXSA9IHN0YXRlO1xuICAgICAgICAgIGNvbnN0IHF1ZXVlID0gcHJvbWlzZVtzeW1ib2xWYWx1ZV07XG4gICAgICAgICAgcHJvbWlzZVtzeW1ib2xWYWx1ZV0gPSB2YWx1ZTtcbiAgICAgICAgICBpZiAocHJvbWlzZVtzeW1ib2xGaW5hbGx5XSA9PT0gc3ltYm9sRmluYWxseSkge1xuICAgICAgICAgICAgaWYgKHN0YXRlID09PSBSRVNPTFZFRCkge1xuICAgICAgICAgICAgICBwcm9taXNlW3N5bWJvbFN0YXRlXSA9IHByb21pc2Vbc3ltYm9sUGFyZW50UHJvbWlzZVN0YXRlXTtcbiAgICAgICAgICAgICAgcHJvbWlzZVtzeW1ib2xWYWx1ZV0gPSBwcm9taXNlW3N5bWJvbFBhcmVudFByb21pc2VWYWx1ZV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChzdGF0ZSA9PT0gUkVKRUNURUQgJiYgdmFsdWUgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgY29uc3QgdHJhY2UgPSBab25lNC5jdXJyZW50VGFzayAmJiBab25lNC5jdXJyZW50VGFzay5kYXRhICYmIFpvbmU0LmN1cnJlbnRUYXNrLmRhdGFbY3JlYXRpb25UcmFjZV07XG4gICAgICAgICAgICBpZiAodHJhY2UpIHtcbiAgICAgICAgICAgICAgT2JqZWN0RGVmaW5lUHJvcGVydHkyKHZhbHVlLCBDVVJSRU5UX1RBU0tfVFJBQ0VfU1lNQk9MLCB7XG4gICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHdyaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIHZhbHVlOiB0cmFjZVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBxdWV1ZS5sZW5ndGg7ICkge1xuICAgICAgICAgICAgc2NoZWR1bGVSZXNvbHZlT3JSZWplY3QocHJvbWlzZSwgcXVldWVbaSsrXSwgcXVldWVbaSsrXSwgcXVldWVbaSsrXSwgcXVldWVbaSsrXSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChxdWV1ZS5sZW5ndGggPT0gMCAmJiBzdGF0ZSA9PSBSRUpFQ1RFRCkge1xuICAgICAgICAgICAgcHJvbWlzZVtzeW1ib2xTdGF0ZV0gPSBSRUpFQ1RFRF9OT19DQVRDSDtcbiAgICAgICAgICAgIGxldCB1bmNhdWdodFByb21pc2VFcnJvciA9IHZhbHVlO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5jYXVnaHQgKGluIHByb21pc2UpOiBcIiArIHJlYWRhYmxlT2JqZWN0VG9TdHJpbmcodmFsdWUpICsgKHZhbHVlICYmIHZhbHVlLnN0YWNrID8gXCJcXG5cIiArIHZhbHVlLnN0YWNrIDogXCJcIikpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICAgIHVuY2F1Z2h0UHJvbWlzZUVycm9yID0gZXJyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzRGlzYWJsZVdyYXBwaW5nVW5jYXVnaHRQcm9taXNlUmVqZWN0aW9uKSB7XG4gICAgICAgICAgICAgIHVuY2F1Z2h0UHJvbWlzZUVycm9yLnRocm93T3JpZ2luYWwgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdW5jYXVnaHRQcm9taXNlRXJyb3IucmVqZWN0aW9uID0gdmFsdWU7XG4gICAgICAgICAgICB1bmNhdWdodFByb21pc2VFcnJvci5wcm9taXNlID0gcHJvbWlzZTtcbiAgICAgICAgICAgIHVuY2F1Z2h0UHJvbWlzZUVycm9yLnpvbmUgPSBab25lNC5jdXJyZW50O1xuICAgICAgICAgICAgdW5jYXVnaHRQcm9taXNlRXJyb3IudGFzayA9IFpvbmU0LmN1cnJlbnRUYXNrO1xuICAgICAgICAgICAgX3VuY2F1Z2h0UHJvbWlzZUVycm9ycy5wdXNoKHVuY2F1Z2h0UHJvbWlzZUVycm9yKTtcbiAgICAgICAgICAgIGFwaS5zY2hlZHVsZU1pY3JvVGFzaygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfVxuICAgIGNvbnN0IFJFSkVDVElPTl9IQU5ETEVEX0hBTkRMRVIgPSBfX3N5bWJvbF9fMihcInJlamVjdGlvbkhhbmRsZWRIYW5kbGVyXCIpO1xuICAgIGZ1bmN0aW9uIGNsZWFyUmVqZWN0ZWROb0NhdGNoKHByb21pc2UpIHtcbiAgICAgIGlmIChwcm9taXNlW3N5bWJvbFN0YXRlXSA9PT0gUkVKRUNURURfTk9fQ0FUQ0gpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBoYW5kbGVyID0gWm9uZTRbUkVKRUNUSU9OX0hBTkRMRURfSEFORExFUl07XG4gICAgICAgICAgaWYgKGhhbmRsZXIgJiYgdHlwZW9mIGhhbmRsZXIgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMsIHsgcmVqZWN0aW9uOiBwcm9taXNlW3N5bWJvbFZhbHVlXSwgcHJvbWlzZSB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICB9XG4gICAgICAgIHByb21pc2Vbc3ltYm9sU3RhdGVdID0gUkVKRUNURUQ7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX3VuY2F1Z2h0UHJvbWlzZUVycm9ycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChwcm9taXNlID09PSBfdW5jYXVnaHRQcm9taXNlRXJyb3JzW2ldLnByb21pc2UpIHtcbiAgICAgICAgICAgIF91bmNhdWdodFByb21pc2VFcnJvcnMuc3BsaWNlKGksIDEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBzY2hlZHVsZVJlc29sdmVPclJlamVjdChwcm9taXNlLCB6b25lLCBjaGFpblByb21pc2UsIG9uRnVsZmlsbGVkLCBvblJlamVjdGVkKSB7XG4gICAgICBjbGVhclJlamVjdGVkTm9DYXRjaChwcm9taXNlKTtcbiAgICAgIGNvbnN0IHByb21pc2VTdGF0ZSA9IHByb21pc2Vbc3ltYm9sU3RhdGVdO1xuICAgICAgY29uc3QgZGVsZWdhdGUgPSBwcm9taXNlU3RhdGUgPyB0eXBlb2Ygb25GdWxmaWxsZWQgPT09IFwiZnVuY3Rpb25cIiA/IG9uRnVsZmlsbGVkIDogZm9yd2FyZFJlc29sdXRpb24gOiB0eXBlb2Ygb25SZWplY3RlZCA9PT0gXCJmdW5jdGlvblwiID8gb25SZWplY3RlZCA6IGZvcndhcmRSZWplY3Rpb247XG4gICAgICB6b25lLnNjaGVkdWxlTWljcm9UYXNrKHNvdXJjZSwgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHBhcmVudFByb21pc2VWYWx1ZSA9IHByb21pc2Vbc3ltYm9sVmFsdWVdO1xuICAgICAgICAgIGNvbnN0IGlzRmluYWxseVByb21pc2UgPSAhIWNoYWluUHJvbWlzZSAmJiBzeW1ib2xGaW5hbGx5ID09PSBjaGFpblByb21pc2Vbc3ltYm9sRmluYWxseV07XG4gICAgICAgICAgaWYgKGlzRmluYWxseVByb21pc2UpIHtcbiAgICAgICAgICAgIGNoYWluUHJvbWlzZVtzeW1ib2xQYXJlbnRQcm9taXNlVmFsdWVdID0gcGFyZW50UHJvbWlzZVZhbHVlO1xuICAgICAgICAgICAgY2hhaW5Qcm9taXNlW3N5bWJvbFBhcmVudFByb21pc2VTdGF0ZV0gPSBwcm9taXNlU3RhdGU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHZhbHVlID0gem9uZS5ydW4oZGVsZWdhdGUsIHZvaWQgMCwgaXNGaW5hbGx5UHJvbWlzZSAmJiBkZWxlZ2F0ZSAhPT0gZm9yd2FyZFJlamVjdGlvbiAmJiBkZWxlZ2F0ZSAhPT0gZm9yd2FyZFJlc29sdXRpb24gPyBbXSA6IFtwYXJlbnRQcm9taXNlVmFsdWVdKTtcbiAgICAgICAgICByZXNvbHZlUHJvbWlzZShjaGFpblByb21pc2UsIHRydWUsIHZhbHVlKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICByZXNvbHZlUHJvbWlzZShjaGFpblByb21pc2UsIGZhbHNlLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgIH0sIGNoYWluUHJvbWlzZSk7XG4gICAgfVxuICAgIGNvbnN0IFpPTkVfQVdBUkVfUFJPTUlTRV9UT19TVFJJTkcgPSBcImZ1bmN0aW9uIFpvbmVBd2FyZVByb21pc2UoKSB7IFtuYXRpdmUgY29kZV0gfVwiO1xuICAgIGNvbnN0IG5vb3AgPSBmdW5jdGlvbigpIHtcbiAgICB9O1xuICAgIGNvbnN0IEFnZ3JlZ2F0ZUVycm9yID0gZ2xvYmFsMi5BZ2dyZWdhdGVFcnJvcjtcbiAgICBjbGFzcyBab25lQXdhcmVQcm9taXNlIHtcbiAgICAgIHN0YXRpYyB0b1N0cmluZygpIHtcbiAgICAgICAgcmV0dXJuIFpPTkVfQVdBUkVfUFJPTUlTRV9UT19TVFJJTkc7XG4gICAgICB9XG4gICAgICBzdGF0aWMgcmVzb2x2ZSh2YWx1ZSkge1xuICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBab25lQXdhcmVQcm9taXNlKSB7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNvbHZlUHJvbWlzZShuZXcgdGhpcyhudWxsKSwgUkVTT0xWRUQsIHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHN0YXRpYyByZWplY3QoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHJlc29sdmVQcm9taXNlKG5ldyB0aGlzKG51bGwpLCBSRUpFQ1RFRCwgZXJyb3IpO1xuICAgICAgfVxuICAgICAgc3RhdGljIHdpdGhSZXNvbHZlcnMoKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgICAgICByZXN1bHQucHJvbWlzZSA9IG5ldyBab25lQXdhcmVQcm9taXNlKChyZXMsIHJlaikgPT4ge1xuICAgICAgICAgIHJlc3VsdC5yZXNvbHZlID0gcmVzO1xuICAgICAgICAgIHJlc3VsdC5yZWplY3QgPSByZWo7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfVxuICAgICAgc3RhdGljIGFueSh2YWx1ZXMpIHtcbiAgICAgICAgaWYgKCF2YWx1ZXMgfHwgdHlwZW9mIHZhbHVlc1tTeW1ib2wuaXRlcmF0b3JdICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEFnZ3JlZ2F0ZUVycm9yKFtdLCBcIkFsbCBwcm9taXNlcyB3ZXJlIHJlamVjdGVkXCIpKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcm9taXNlcyA9IFtdO1xuICAgICAgICBsZXQgY291bnQgPSAwO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGZvciAobGV0IHYgb2YgdmFsdWVzKSB7XG4gICAgICAgICAgICBjb3VudCsrO1xuICAgICAgICAgICAgcHJvbWlzZXMucHVzaChab25lQXdhcmVQcm9taXNlLnJlc29sdmUodikpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBBZ2dyZWdhdGVFcnJvcihbXSwgXCJBbGwgcHJvbWlzZXMgd2VyZSByZWplY3RlZFwiKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvdW50ID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBBZ2dyZWdhdGVFcnJvcihbXSwgXCJBbGwgcHJvbWlzZXMgd2VyZSByZWplY3RlZFwiKSk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGZpbmlzaGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IGVycm9ycyA9IFtdO1xuICAgICAgICByZXR1cm4gbmV3IFpvbmVBd2FyZVByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvbWlzZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHByb21pc2VzW2ldLnRoZW4oKHYpID0+IHtcbiAgICAgICAgICAgICAgaWYgKGZpbmlzaGVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgcmVzb2x2ZSh2KTtcbiAgICAgICAgICAgIH0sIChlcnIpID0+IHtcbiAgICAgICAgICAgICAgZXJyb3JzLnB1c2goZXJyKTtcbiAgICAgICAgICAgICAgY291bnQtLTtcbiAgICAgICAgICAgICAgaWYgKGNvdW50ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgZmluaXNoZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJlamVjdChuZXcgQWdncmVnYXRlRXJyb3IoZXJyb3JzLCBcIkFsbCBwcm9taXNlcyB3ZXJlIHJlamVjdGVkXCIpKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHN0YXRpYyByYWNlKHZhbHVlcykge1xuICAgICAgICBsZXQgcmVzb2x2ZTtcbiAgICAgICAgbGV0IHJlamVjdDtcbiAgICAgICAgbGV0IHByb21pc2UgPSBuZXcgdGhpcygocmVzLCByZWopID0+IHtcbiAgICAgICAgICByZXNvbHZlID0gcmVzO1xuICAgICAgICAgIHJlamVjdCA9IHJlajtcbiAgICAgICAgfSk7XG4gICAgICAgIGZ1bmN0aW9uIG9uUmVzb2x2ZSh2YWx1ZSkge1xuICAgICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG9uUmVqZWN0KGVycm9yKSB7XG4gICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCB2YWx1ZSBvZiB2YWx1ZXMpIHtcbiAgICAgICAgICBpZiAoIWlzVGhlbmFibGUodmFsdWUpKSB7XG4gICAgICAgICAgICB2YWx1ZSA9IHRoaXMucmVzb2x2ZSh2YWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhbHVlLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgICB9XG4gICAgICBzdGF0aWMgYWxsKHZhbHVlcykge1xuICAgICAgICByZXR1cm4gWm9uZUF3YXJlUHJvbWlzZS5hbGxXaXRoQ2FsbGJhY2sodmFsdWVzKTtcbiAgICAgIH1cbiAgICAgIHN0YXRpYyBhbGxTZXR0bGVkKHZhbHVlcykge1xuICAgICAgICBjb25zdCBQID0gdGhpcyAmJiB0aGlzLnByb3RvdHlwZSBpbnN0YW5jZW9mIFpvbmVBd2FyZVByb21pc2UgPyB0aGlzIDogWm9uZUF3YXJlUHJvbWlzZTtcbiAgICAgICAgcmV0dXJuIFAuYWxsV2l0aENhbGxiYWNrKHZhbHVlcywge1xuICAgICAgICAgIHRoZW5DYWxsYmFjazogKHZhbHVlKSA9PiAoeyBzdGF0dXM6IFwiZnVsZmlsbGVkXCIsIHZhbHVlIH0pLFxuICAgICAgICAgIGVycm9yQ2FsbGJhY2s6IChlcnIpID0+ICh7IHN0YXR1czogXCJyZWplY3RlZFwiLCByZWFzb246IGVyciB9KVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHN0YXRpYyBhbGxXaXRoQ2FsbGJhY2sodmFsdWVzLCBjYWxsYmFjaykge1xuICAgICAgICBsZXQgcmVzb2x2ZTtcbiAgICAgICAgbGV0IHJlamVjdDtcbiAgICAgICAgbGV0IHByb21pc2UgPSBuZXcgdGhpcygocmVzLCByZWopID0+IHtcbiAgICAgICAgICByZXNvbHZlID0gcmVzO1xuICAgICAgICAgIHJlamVjdCA9IHJlajtcbiAgICAgICAgfSk7XG4gICAgICAgIGxldCB1bnJlc29sdmVkQ291bnQgPSAyO1xuICAgICAgICBsZXQgdmFsdWVJbmRleCA9IDA7XG4gICAgICAgIGNvbnN0IHJlc29sdmVkVmFsdWVzID0gW107XG4gICAgICAgIGZvciAobGV0IHZhbHVlIG9mIHZhbHVlcykge1xuICAgICAgICAgIGlmICghaXNUaGVuYWJsZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHZhbHVlID0gdGhpcy5yZXNvbHZlKHZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgY3VyVmFsdWVJbmRleCA9IHZhbHVlSW5kZXg7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHZhbHVlLnRoZW4oKHZhbHVlMikgPT4ge1xuICAgICAgICAgICAgICByZXNvbHZlZFZhbHVlc1tjdXJWYWx1ZUluZGV4XSA9IGNhbGxiYWNrID8gY2FsbGJhY2sudGhlbkNhbGxiYWNrKHZhbHVlMikgOiB2YWx1ZTI7XG4gICAgICAgICAgICAgIHVucmVzb2x2ZWRDb3VudC0tO1xuICAgICAgICAgICAgICBpZiAodW5yZXNvbHZlZENvdW50ID09PSAwKSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNvbHZlZFZhbHVlcyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIChlcnIpID0+IHtcbiAgICAgICAgICAgICAgaWYgKCFjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlc29sdmVkVmFsdWVzW2N1clZhbHVlSW5kZXhdID0gY2FsbGJhY2suZXJyb3JDYWxsYmFjayhlcnIpO1xuICAgICAgICAgICAgICAgIHVucmVzb2x2ZWRDb3VudC0tO1xuICAgICAgICAgICAgICAgIGlmICh1bnJlc29sdmVkQ291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzb2x2ZWRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBjYXRjaCAodGhlbkVycikge1xuICAgICAgICAgICAgcmVqZWN0KHRoZW5FcnIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB1bnJlc29sdmVkQ291bnQrKztcbiAgICAgICAgICB2YWx1ZUluZGV4Kys7XG4gICAgICAgIH1cbiAgICAgICAgdW5yZXNvbHZlZENvdW50IC09IDI7XG4gICAgICAgIGlmICh1bnJlc29sdmVkQ291bnQgPT09IDApIHtcbiAgICAgICAgICByZXNvbHZlKHJlc29sdmVkVmFsdWVzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0cnVjdG9yKGV4ZWN1dG9yKSB7XG4gICAgICAgIGNvbnN0IHByb21pc2UgPSB0aGlzO1xuICAgICAgICBpZiAoIShwcm9taXNlIGluc3RhbmNlb2YgWm9uZUF3YXJlUHJvbWlzZSkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNdXN0IGJlIGFuIGluc3RhbmNlb2YgUHJvbWlzZS5cIik7XG4gICAgICAgIH1cbiAgICAgICAgcHJvbWlzZVtzeW1ib2xTdGF0ZV0gPSBVTlJFU09MVkVEO1xuICAgICAgICBwcm9taXNlW3N5bWJvbFZhbHVlXSA9IFtdO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG9uY2VXcmFwcGVyID0gb25jZSgpO1xuICAgICAgICAgIGV4ZWN1dG9yICYmIGV4ZWN1dG9yKG9uY2VXcmFwcGVyKG1ha2VSZXNvbHZlcihwcm9taXNlLCBSRVNPTFZFRCkpLCBvbmNlV3JhcHBlcihtYWtlUmVzb2x2ZXIocHJvbWlzZSwgUkVKRUNURUQpKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgcmVzb2x2ZVByb21pc2UocHJvbWlzZSwgZmFsc2UsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgICAgICByZXR1cm4gXCJQcm9taXNlXCI7XG4gICAgICB9XG4gICAgICBnZXQgW1N5bWJvbC5zcGVjaWVzXSgpIHtcbiAgICAgICAgcmV0dXJuIFpvbmVBd2FyZVByb21pc2U7XG4gICAgICB9XG4gICAgICB0aGVuKG9uRnVsZmlsbGVkLCBvblJlamVjdGVkKSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgbGV0IEMgPSAoX2EgPSB0aGlzLmNvbnN0cnVjdG9yKSA9PSBudWxsID8gdm9pZCAwIDogX2FbU3ltYm9sLnNwZWNpZXNdO1xuICAgICAgICBpZiAoIUMgfHwgdHlwZW9mIEMgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIEMgPSB0aGlzLmNvbnN0cnVjdG9yIHx8IFpvbmVBd2FyZVByb21pc2U7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2hhaW5Qcm9taXNlID0gbmV3IEMobm9vcCk7XG4gICAgICAgIGNvbnN0IHpvbmUgPSBab25lNC5jdXJyZW50O1xuICAgICAgICBpZiAodGhpc1tzeW1ib2xTdGF0ZV0gPT0gVU5SRVNPTFZFRCkge1xuICAgICAgICAgIHRoaXNbc3ltYm9sVmFsdWVdLnB1c2goem9uZSwgY2hhaW5Qcm9taXNlLCBvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2NoZWR1bGVSZXNvbHZlT3JSZWplY3QodGhpcywgem9uZSwgY2hhaW5Qcm9taXNlLCBvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNoYWluUHJvbWlzZTtcbiAgICAgIH1cbiAgICAgIGNhdGNoKG9uUmVqZWN0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGhlbihudWxsLCBvblJlamVjdGVkKTtcbiAgICAgIH1cbiAgICAgIGZpbmFsbHkob25GaW5hbGx5KSB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgbGV0IEMgPSAoX2EgPSB0aGlzLmNvbnN0cnVjdG9yKSA9PSBudWxsID8gdm9pZCAwIDogX2FbU3ltYm9sLnNwZWNpZXNdO1xuICAgICAgICBpZiAoIUMgfHwgdHlwZW9mIEMgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIEMgPSBab25lQXdhcmVQcm9taXNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNoYWluUHJvbWlzZSA9IG5ldyBDKG5vb3ApO1xuICAgICAgICBjaGFpblByb21pc2Vbc3ltYm9sRmluYWxseV0gPSBzeW1ib2xGaW5hbGx5O1xuICAgICAgICBjb25zdCB6b25lID0gWm9uZTQuY3VycmVudDtcbiAgICAgICAgaWYgKHRoaXNbc3ltYm9sU3RhdGVdID09IFVOUkVTT0xWRUQpIHtcbiAgICAgICAgICB0aGlzW3N5bWJvbFZhbHVlXS5wdXNoKHpvbmUsIGNoYWluUHJvbWlzZSwgb25GaW5hbGx5LCBvbkZpbmFsbHkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNjaGVkdWxlUmVzb2x2ZU9yUmVqZWN0KHRoaXMsIHpvbmUsIGNoYWluUHJvbWlzZSwgb25GaW5hbGx5LCBvbkZpbmFsbHkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjaGFpblByb21pc2U7XG4gICAgICB9XG4gICAgfVxuICAgIFpvbmVBd2FyZVByb21pc2VbXCJyZXNvbHZlXCJdID0gWm9uZUF3YXJlUHJvbWlzZS5yZXNvbHZlO1xuICAgIFpvbmVBd2FyZVByb21pc2VbXCJyZWplY3RcIl0gPSBab25lQXdhcmVQcm9taXNlLnJlamVjdDtcbiAgICBab25lQXdhcmVQcm9taXNlW1wicmFjZVwiXSA9IFpvbmVBd2FyZVByb21pc2UucmFjZTtcbiAgICBab25lQXdhcmVQcm9taXNlW1wiYWxsXCJdID0gWm9uZUF3YXJlUHJvbWlzZS5hbGw7XG4gICAgY29uc3QgTmF0aXZlUHJvbWlzZSA9IGdsb2JhbDJbc3ltYm9sUHJvbWlzZV0gPSBnbG9iYWwyW1wiUHJvbWlzZVwiXTtcbiAgICBnbG9iYWwyW1wiUHJvbWlzZVwiXSA9IFpvbmVBd2FyZVByb21pc2U7XG4gICAgY29uc3Qgc3ltYm9sVGhlblBhdGNoZWQgPSBfX3N5bWJvbF9fMihcInRoZW5QYXRjaGVkXCIpO1xuICAgIGZ1bmN0aW9uIHBhdGNoVGhlbihDdG9yKSB7XG4gICAgICBjb25zdCBwcm90byA9IEN0b3IucHJvdG90eXBlO1xuICAgICAgY29uc3QgcHJvcCA9IE9iamVjdEdldE93blByb3BlcnR5RGVzY3JpcHRvcjIocHJvdG8sIFwidGhlblwiKTtcbiAgICAgIGlmIChwcm9wICYmIChwcm9wLndyaXRhYmxlID09PSBmYWxzZSB8fCAhcHJvcC5jb25maWd1cmFibGUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG9yaWdpbmFsVGhlbiA9IHByb3RvLnRoZW47XG4gICAgICBwcm90b1tzeW1ib2xUaGVuXSA9IG9yaWdpbmFsVGhlbjtcbiAgICAgIEN0b3IucHJvdG90eXBlLnRoZW4gPSBmdW5jdGlvbihvblJlc29sdmUsIG9uUmVqZWN0KSB7XG4gICAgICAgIGNvbnN0IHdyYXBwZWQgPSBuZXcgWm9uZUF3YXJlUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgb3JpZ2luYWxUaGVuLmNhbGwodGhpcywgcmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB3cmFwcGVkLnRoZW4ob25SZXNvbHZlLCBvblJlamVjdCk7XG4gICAgICB9O1xuICAgICAgQ3RvcltzeW1ib2xUaGVuUGF0Y2hlZF0gPSB0cnVlO1xuICAgIH1cbiAgICBhcGkucGF0Y2hUaGVuID0gcGF0Y2hUaGVuO1xuICAgIGZ1bmN0aW9uIHpvbmVpZnkoZm4pIHtcbiAgICAgIHJldHVybiBmdW5jdGlvbihzZWxmMiwgYXJncykge1xuICAgICAgICBsZXQgcmVzdWx0UHJvbWlzZSA9IGZuLmFwcGx5KHNlbGYyLCBhcmdzKTtcbiAgICAgICAgaWYgKHJlc3VsdFByb21pc2UgaW5zdGFuY2VvZiBab25lQXdhcmVQcm9taXNlKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3VsdFByb21pc2U7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGN0b3IgPSByZXN1bHRQcm9taXNlLmNvbnN0cnVjdG9yO1xuICAgICAgICBpZiAoIWN0b3Jbc3ltYm9sVGhlblBhdGNoZWRdKSB7XG4gICAgICAgICAgcGF0Y2hUaGVuKGN0b3IpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHRQcm9taXNlO1xuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKE5hdGl2ZVByb21pc2UpIHtcbiAgICAgIHBhdGNoVGhlbihOYXRpdmVQcm9taXNlKTtcbiAgICAgIGNvbnN0IG5hdGl2ZVRyeSA9IE5hdGl2ZVByb21pc2VbXCJ0cnlcIl07XG4gICAgICBpZiAobmF0aXZlVHJ5ICYmIHR5cGVvZiBuYXRpdmVUcnkgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBab25lQXdhcmVQcm9taXNlW1widHJ5XCJdID0gbmF0aXZlVHJ5O1xuICAgICAgfVxuICAgICAgcGF0Y2hNZXRob2QoZ2xvYmFsMiwgXCJmZXRjaFwiLCAoZGVsZWdhdGUpID0+IHpvbmVpZnkoZGVsZWdhdGUpKTtcbiAgICB9XG4gICAgUHJvbWlzZVtab25lNC5fX3N5bWJvbF9fKFwidW5jYXVnaHRQcm9taXNlRXJyb3JzXCIpXSA9IF91bmNhdWdodFByb21pc2VFcnJvcnM7XG4gICAgcmV0dXJuIFpvbmVBd2FyZVByb21pc2U7XG4gIH0pO1xufVxuXG4vLyBwYWNrYWdlcy96b25lLmpzL2xpYi9jb21tb24vdG8tc3RyaW5nLmpzXG5mdW5jdGlvbiBwYXRjaFRvU3RyaW5nKFpvbmUzKSB7XG4gIFpvbmUzLl9fbG9hZF9wYXRjaChcInRvU3RyaW5nXCIsIChnbG9iYWwyKSA9PiB7XG4gICAgY29uc3Qgb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nID0gRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nO1xuICAgIGNvbnN0IE9SSUdJTkFMX0RFTEVHQVRFX1NZTUJPTCA9IHpvbmVTeW1ib2woXCJPcmlnaW5hbERlbGVnYXRlXCIpO1xuICAgIGNvbnN0IFBST01JU0VfU1lNQk9MID0gem9uZVN5bWJvbChcIlByb21pc2VcIik7XG4gICAgY29uc3QgRVJST1JfU1lNQk9MID0gem9uZVN5bWJvbChcIkVycm9yXCIpO1xuICAgIGNvbnN0IG5ld0Z1bmN0aW9uVG9TdHJpbmcgPSBmdW5jdGlvbiB0b1N0cmluZygpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIGNvbnN0IG9yaWdpbmFsRGVsZWdhdGUgPSB0aGlzW09SSUdJTkFMX0RFTEVHQVRFX1NZTUJPTF07XG4gICAgICAgIGlmIChvcmlnaW5hbERlbGVnYXRlKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBvcmlnaW5hbERlbGVnYXRlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbEZ1bmN0aW9uVG9TdHJpbmcuY2FsbChvcmlnaW5hbERlbGVnYXRlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvcmlnaW5hbERlbGVnYXRlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMgPT09IFByb21pc2UpIHtcbiAgICAgICAgICBjb25zdCBuYXRpdmVQcm9taXNlID0gZ2xvYmFsMltQUk9NSVNFX1NZTUJPTF07XG4gICAgICAgICAgaWYgKG5hdGl2ZVByb21pc2UpIHtcbiAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbEZ1bmN0aW9uVG9TdHJpbmcuY2FsbChuYXRpdmVQcm9taXNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMgPT09IEVycm9yKSB7XG4gICAgICAgICAgY29uc3QgbmF0aXZlRXJyb3IgPSBnbG9iYWwyW0VSUk9SX1NZTUJPTF07XG4gICAgICAgICAgaWYgKG5hdGl2ZUVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4gb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nLmNhbGwobmF0aXZlRXJyb3IpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIG9yaWdpbmFsRnVuY3Rpb25Ub1N0cmluZy5jYWxsKHRoaXMpO1xuICAgIH07XG4gICAgbmV3RnVuY3Rpb25Ub1N0cmluZ1tPUklHSU5BTF9ERUxFR0FURV9TWU1CT0xdID0gb3JpZ2luYWxGdW5jdGlvblRvU3RyaW5nO1xuICAgIEZ1bmN0aW9uLnByb3RvdHlwZS50b1N0cmluZyA9IG5ld0Z1bmN0aW9uVG9TdHJpbmc7XG4gICAgY29uc3Qgb3JpZ2luYWxPYmplY3RUb1N0cmluZyA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG4gICAgY29uc3QgUFJPTUlTRV9PQkpFQ1RfVE9fU1RSSU5HID0gXCJbb2JqZWN0IFByb21pc2VdXCI7XG4gICAgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKHR5cGVvZiBQcm9taXNlID09PSBcImZ1bmN0aW9uXCIgJiYgdGhpcyBpbnN0YW5jZW9mIFByb21pc2UpIHtcbiAgICAgICAgcmV0dXJuIFBST01JU0VfT0JKRUNUX1RPX1NUUklORztcbiAgICAgIH1cbiAgICAgIHJldHVybiBvcmlnaW5hbE9iamVjdFRvU3RyaW5nLmNhbGwodGhpcyk7XG4gICAgfTtcbiAgfSk7XG59XG5cbi8vIHBhY2thZ2VzL3pvbmUuanMvbGliL2Jyb3dzZXIvYnJvd3Nlci11dGlsLmpzXG5mdW5jdGlvbiBwYXRjaENhbGxiYWNrcyhhcGksIHRhcmdldCwgdGFyZ2V0TmFtZSwgbWV0aG9kLCBjYWxsYmFja3MpIHtcbiAgY29uc3Qgc3ltYm9sID0gWm9uZS5fX3N5bWJvbF9fKG1ldGhvZCk7XG4gIGlmICh0YXJnZXRbc3ltYm9sXSkge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBuYXRpdmVEZWxlZ2F0ZSA9IHRhcmdldFtzeW1ib2xdID0gdGFyZ2V0W21ldGhvZF07XG4gIHRhcmdldFttZXRob2RdID0gZnVuY3Rpb24obmFtZSwgb3B0cywgb3B0aW9ucykge1xuICAgIGlmIChvcHRzICYmIG9wdHMucHJvdG90eXBlKSB7XG4gICAgICBjYWxsYmFja3MuZm9yRWFjaChmdW5jdGlvbihjYWxsYmFjaykge1xuICAgICAgICBjb25zdCBzb3VyY2UgPSBgJHt0YXJnZXROYW1lfS4ke21ldGhvZH06OmAgKyBjYWxsYmFjaztcbiAgICAgICAgY29uc3QgcHJvdG90eXBlID0gb3B0cy5wcm90b3R5cGU7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKHByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eShjYWxsYmFjaykpIHtcbiAgICAgICAgICAgIGNvbnN0IGRlc2NyaXB0b3IgPSBhcGkuT2JqZWN0R2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHByb3RvdHlwZSwgY2FsbGJhY2spO1xuICAgICAgICAgICAgaWYgKGRlc2NyaXB0b3IgJiYgZGVzY3JpcHRvci52YWx1ZSkge1xuICAgICAgICAgICAgICBkZXNjcmlwdG9yLnZhbHVlID0gYXBpLndyYXBXaXRoQ3VycmVudFpvbmUoZGVzY3JpcHRvci52YWx1ZSwgc291cmNlKTtcbiAgICAgICAgICAgICAgYXBpLl9yZWRlZmluZVByb3BlcnR5KG9wdHMucHJvdG90eXBlLCBjYWxsYmFjaywgZGVzY3JpcHRvcik7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHByb3RvdHlwZVtjYWxsYmFja10pIHtcbiAgICAgICAgICAgICAgcHJvdG90eXBlW2NhbGxiYWNrXSA9IGFwaS53cmFwV2l0aEN1cnJlbnRab25lKHByb3RvdHlwZVtjYWxsYmFja10sIHNvdXJjZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChwcm90b3R5cGVbY2FsbGJhY2tdKSB7XG4gICAgICAgICAgICBwcm90b3R5cGVbY2FsbGJhY2tdID0gYXBpLndyYXBXaXRoQ3VycmVudFpvbmUocHJvdG90eXBlW2NhbGxiYWNrXSwgc291cmNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBuYXRpdmVEZWxlZ2F0ZS5jYWxsKHRhcmdldCwgbmFtZSwgb3B0cywgb3B0aW9ucyk7XG4gIH07XG4gIGFwaS5hdHRhY2hPcmlnaW5Ub1BhdGNoZWQodGFyZ2V0W21ldGhvZF0sIG5hdGl2ZURlbGVnYXRlKTtcbn1cblxuLy8gcGFja2FnZXMvem9uZS5qcy9saWIvYnJvd3Nlci9hcGktdXRpbC5qc1xuZnVuY3Rpb24gcGF0Y2hVdGlsKFpvbmUzKSB7XG4gIFpvbmUzLl9fbG9hZF9wYXRjaChcInV0aWxcIiwgKGdsb2JhbDIsIFpvbmU0LCBhcGkpID0+IHtcbiAgICBjb25zdCBldmVudE5hbWVzID0gZ2V0T25FdmVudE5hbWVzKGdsb2JhbDIpO1xuICAgIGFwaS5wYXRjaE9uUHJvcGVydGllcyA9IHBhdGNoT25Qcm9wZXJ0aWVzO1xuICAgIGFwaS5wYXRjaE1ldGhvZCA9IHBhdGNoTWV0aG9kO1xuICAgIGFwaS5iaW5kQXJndW1lbnRzID0gYmluZEFyZ3VtZW50cztcbiAgICBhcGkucGF0Y2hNYWNyb1Rhc2sgPSBwYXRjaE1hY3JvVGFzaztcbiAgICBjb25zdCBTWU1CT0xfQkxBQ0tfTElTVEVEX0VWRU5UUyA9IFpvbmU0Ll9fc3ltYm9sX18oXCJCTEFDS19MSVNURURfRVZFTlRTXCIpO1xuICAgIGNvbnN0IFNZTUJPTF9VTlBBVENIRURfRVZFTlRTID0gWm9uZTQuX19zeW1ib2xfXyhcIlVOUEFUQ0hFRF9FVkVOVFNcIik7XG4gICAgaWYgKGdsb2JhbDJbU1lNQk9MX1VOUEFUQ0hFRF9FVkVOVFNdKSB7XG4gICAgICBnbG9iYWwyW1NZTUJPTF9CTEFDS19MSVNURURfRVZFTlRTXSA9IGdsb2JhbDJbU1lNQk9MX1VOUEFUQ0hFRF9FVkVOVFNdO1xuICAgIH1cbiAgICBpZiAoZ2xvYmFsMltTWU1CT0xfQkxBQ0tfTElTVEVEX0VWRU5UU10pIHtcbiAgICAgIFpvbmU0W1NZTUJPTF9CTEFDS19MSVNURURfRVZFTlRTXSA9IFpvbmU0W1NZTUJPTF9VTlBBVENIRURfRVZFTlRTXSA9IGdsb2JhbDJbU1lNQk9MX0JMQUNLX0xJU1RFRF9FVkVOVFNdO1xuICAgIH1cbiAgICBhcGkucGF0Y2hFdmVudFByb3RvdHlwZSA9IHBhdGNoRXZlbnRQcm90b3R5cGU7XG4gICAgYXBpLnBhdGNoRXZlbnRUYXJnZXQgPSBwYXRjaEV2ZW50VGFyZ2V0O1xuICAgIGFwaS5PYmplY3REZWZpbmVQcm9wZXJ0eSA9IE9iamVjdERlZmluZVByb3BlcnR5O1xuICAgIGFwaS5PYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3RHZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG4gICAgYXBpLk9iamVjdENyZWF0ZSA9IE9iamVjdENyZWF0ZTtcbiAgICBhcGkuQXJyYXlTbGljZSA9IEFycmF5U2xpY2U7XG4gICAgYXBpLnBhdGNoQ2xhc3MgPSBwYXRjaENsYXNzO1xuICAgIGFwaS53cmFwV2l0aEN1cnJlbnRab25lID0gd3JhcFdpdGhDdXJyZW50Wm9uZTtcbiAgICBhcGkuZmlsdGVyUHJvcGVydGllcyA9IGZpbHRlclByb3BlcnRpZXM7XG4gICAgYXBpLmF0dGFjaE9yaWdpblRvUGF0Y2hlZCA9IGF0dGFjaE9yaWdpblRvUGF0Y2hlZDtcbiAgICBhcGkuX3JlZGVmaW5lUHJvcGVydHkgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG4gICAgYXBpLnBhdGNoQ2FsbGJhY2tzID0gcGF0Y2hDYWxsYmFja3M7XG4gICAgYXBpLmdldEdsb2JhbE9iamVjdHMgPSAoKSA9PiAoe1xuICAgICAgZ2xvYmFsU291cmNlcyxcbiAgICAgIHpvbmVTeW1ib2xFdmVudE5hbWVzOiB6b25lU3ltYm9sRXZlbnROYW1lczIsXG4gICAgICBldmVudE5hbWVzLFxuICAgICAgaXNCcm93c2VyLFxuICAgICAgaXNNaXgsXG4gICAgICBpc05vZGUsXG4gICAgICBUUlVFX1NUUixcbiAgICAgIEZBTFNFX1NUUixcbiAgICAgIFpPTkVfU1lNQk9MX1BSRUZJWCxcbiAgICAgIEFERF9FVkVOVF9MSVNURU5FUl9TVFIsXG4gICAgICBSRU1PVkVfRVZFTlRfTElTVEVORVJfU1RSXG4gICAgfSk7XG4gIH0pO1xufVxuXG4vLyBwYWNrYWdlcy96b25lLmpzL2xpYi9icm93c2VyL3JvbGx1cC1jb21tb24uanNcbmZ1bmN0aW9uIHBhdGNoQ29tbW9uKFpvbmUzKSB7XG4gIHBhdGNoUHJvbWlzZShab25lMyk7XG4gIHBhdGNoVG9TdHJpbmcoWm9uZTMpO1xuICBwYXRjaFV0aWwoWm9uZTMpO1xufVxuXG4vLyBwYWNrYWdlcy96b25lLmpzL2xpYi9icm93c2VyL3JvbGx1cC1tYWluLmpzXG52YXIgWm9uZTIgPSBsb2FkWm9uZSgpO1xucGF0Y2hDb21tb24oWm9uZTIpO1xucGF0Y2hCcm93c2VyKFpvbmUyKTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLGFBQWEsT0FBTztBQUN4QixJQUFJLG9CQUFvQixPQUFPO0FBQy9CLElBQUksc0JBQXNCLE9BQU87QUFDakMsSUFBSSxlQUFlLE9BQU8sVUFBVTtBQUNwQyxJQUFJLGVBQWUsT0FBTyxVQUFVO0FBQ3BDLElBQUksbUJBQW1CLEtBQUssS0FBSyxVQUFVLE9BQU8sTUFBTSxVQUFVLEtBQUssS0FBSztDQUFFLFlBQVk7Q0FBTSxjQUFjO0NBQU0sVUFBVTtDQUFNO0FBQU0sQ0FBQyxJQUFJLElBQUksT0FBTztBQUMxSixJQUFJLGtCQUFrQixHQUFHLE1BQU07Q0FDN0IsS0FBSyxJQUFJLFFBQVEsTUFBTSxJQUFJLENBQUMsSUFDMUIsSUFBSSxhQUFhLEtBQUssR0FBRyxJQUFJLEdBQzNCLGdCQUFnQixHQUFHLE1BQU0sRUFBRSxLQUFLO0NBQ3BDLElBQUk7T0FDRyxJQUFJLFFBQVEsb0JBQW9CLENBQUMsR0FDcEMsSUFBSSxhQUFhLEtBQUssR0FBRyxJQUFJLEdBQzNCLGdCQUFnQixHQUFHLE1BQU0sRUFBRSxLQUFLO0NBQUE7Q0FFdEMsT0FBTztBQUNUO0FBQ0EsSUFBSSxpQkFBaUIsR0FBRyxNQUFNLFdBQVcsR0FBRyxrQkFBa0IsQ0FBQyxDQUFDO0FBQ2hFLElBQUksaUJBQWlCLEtBQUssS0FBSyxVQUFVO0NBQ3ZDLGdCQUFnQixLQUFLLE9BQU8sUUFBUSxXQUFXLE1BQU0sS0FBSyxLQUFLLEtBQUs7Q0FDcEUsT0FBTztBQUNUO0FBR0EsSUFBSSxTQUFTO0FBQ2IsU0FBUyxXQUFXLE1BQU07Q0FFeEIsUUFEcUIsT0FBTywyQkFBMkIscUJBQ2pDO0FBQ3hCO0FBQ0EsU0FBUyxXQUFXO0NBQ2xCLE1BQU0sY0FBYyxPQUFPO0NBQzNCLFNBQVMsS0FBSyxNQUFNO0VBQ2xCLGVBQWUsWUFBWSxXQUFXLFlBQVksT0FBTyxDQUFDLElBQUk7Q0FDaEU7Q0FDQSxTQUFTLG1CQUFtQixNQUFNLE9BQU87RUFDdkMsZUFBZSxZQUFZLGNBQWMsWUFBWSxVQUFVLENBQUMsTUFBTSxLQUFLO0NBQzdFO0NBQ0EsS0FBSyxNQUFNO0NBQ1gsTUFBTSxZQUFZLE1BQU0sVUFBVTtFQUNoQyxZQUFZLFFBQVEsVUFBVTtHQUM1QixjQUFjLE1BQU0sU0FBUztHQUM3QixjQUFjLE1BQU0sT0FBTztHQUMzQixjQUFjLE1BQU0sYUFBYTtHQUNqQyxjQUFjLE1BQU0sZUFBZTtHQUNuQyxLQUFLLFVBQVU7R0FDZixLQUFLLFFBQVEsV0FBVyxTQUFTLFFBQVEsWUFBWTtHQUNyRCxLQUFLLGNBQWMsWUFBWSxTQUFTLGNBQWMsQ0FBQztHQUN2RCxLQUFLLGdCQUFnQixJQUFJLGNBQWMsTUFBTSxLQUFLLFdBQVcsS0FBSyxRQUFRLGVBQWUsUUFBUTtFQUNuRztFQUNBLE9BQU8sb0JBQW9CO0dBQ3pCLElBQUksT0FBTyxlQUFlLFFBQVEscUJBQ2hDLE1BQU0sSUFBSSxNQUFNLCtSQUErUjtFQUVuVDtFQUNBLFdBQVcsT0FBTztHQUNoQixJQUFJLE9BQU8sVUFBVTtHQUNyQixPQUFPLEtBQUssUUFDVixPQUFPLEtBQUs7R0FFZCxPQUFPO0VBQ1Q7RUFDQSxXQUFXLFVBQVU7R0FDbkIsT0FBTyxrQkFBa0I7RUFDM0I7RUFDQSxXQUFXLGNBQWM7R0FDdkIsT0FBTztFQUNUO0VBQ0EsT0FBTyxhQUFhLE1BQU0sSUFBSSxrQkFBa0IsT0FBTztHQUNyRCxJQUFJLFFBQVEsZUFBZSxJQUFJLEdBQUc7SUFDaEMsTUFBTSxpQkFBaUIsT0FBTyxXQUFXLHlCQUF5QixPQUFPO0lBQ3pFLElBQUksQ0FBQyxtQkFBbUIsZ0JBQ3RCLE1BQU0sTUFBTSwyQkFBMkIsSUFBSTtHQUUvQyxPQUFPLElBQUksQ0FBQyxPQUFPLG9CQUFvQixPQUFPO0lBQzVDLE1BQU0sV0FBVyxVQUFVO0lBQzNCLEtBQUssUUFBUTtJQUNiLFFBQVEsUUFBUSxHQUFHLFFBQVEsV0FBVyxJQUFJO0lBQzFDLG1CQUFtQixVQUFVLFFBQVE7R0FDdkM7RUFDRjtFQUNBLElBQUksU0FBUztHQUNYLE9BQU8sS0FBSztFQUNkO0VBQ0EsSUFBSSxPQUFPO0dBQ1QsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxJQUFJLEtBQUs7R0FDUCxNQUFNLE9BQU8sS0FBSyxZQUFZLEdBQUc7R0FDakMsSUFBSSxNQUNGLE9BQU8sS0FBSyxZQUFZO0VBQzVCO0VBQ0EsWUFBWSxLQUFLO0dBQ2YsSUFBSSxVQUFVO0dBQ2QsT0FBTyxTQUFTO0lBQ2QsSUFBSSxRQUFRLFlBQVksZUFBZSxHQUFHLEdBQ3hDLE9BQU87SUFFVCxVQUFVLFFBQVE7R0FDcEI7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxLQUFLLFVBQVU7R0FDYixJQUFJLENBQUMsVUFDSCxNQUFNLElBQUksTUFBTSxvQkFBb0I7R0FDdEMsT0FBTyxLQUFLLGNBQWMsS0FBSyxNQUFNLFFBQVE7RUFDL0M7RUFDQSxLQUFLLFVBQVUsUUFBUTtHQUNyQixJQUFJLE9BQU8sYUFBYSxZQUN0QixNQUFNLElBQUksTUFBTSw2QkFBNkIsUUFBUTtHQUV2RCxNQUFNLFlBQVksS0FBSyxjQUFjLFVBQVUsTUFBTSxVQUFVLE1BQU07R0FDckUsTUFBTSxPQUFPO0dBQ2IsT0FBTyxXQUFXO0lBQ2hCLE9BQU8sS0FBSyxXQUFXLFdBQVcsTUFBTSxXQUFXLE1BQU07R0FDM0Q7RUFDRjtFQUNBLElBQUksVUFBVSxXQUFXLFdBQVcsUUFBUTtHQUMxQyxvQkFBb0I7SUFBRSxRQUFRO0lBQW1CLE1BQU07R0FBSztHQUM1RCxJQUFJO0lBQ0YsT0FBTyxLQUFLLGNBQWMsT0FBTyxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU07R0FDL0UsVUFBVTtJQUNSLG9CQUFvQixrQkFBa0I7R0FDeEM7RUFDRjtFQUNBLFdBQVcsVUFBVSxZQUFZLE1BQU0sV0FBVyxRQUFRO0dBQ3hELG9CQUFvQjtJQUFFLFFBQVE7SUFBbUIsTUFBTTtHQUFLO0dBQzVELElBQUk7SUFDRixJQUFJO0tBQ0YsT0FBTyxLQUFLLGNBQWMsT0FBTyxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU07SUFDL0UsU0FBUyxPQUFPO0tBQ2QsSUFBSSxLQUFLLGNBQWMsWUFBWSxNQUFNLEtBQUssR0FDNUMsTUFBTTtJQUVWO0dBQ0YsVUFBVTtJQUNSLG9CQUFvQixrQkFBa0I7R0FDeEM7RUFDRjtFQUNBLFFBQVEsTUFBTSxXQUFXLFdBQVc7R0FDbEMsSUFBSSxLQUFLLFFBQVEsTUFDZixNQUFNLElBQUksTUFBTSxpRUFBaUUsS0FBSyxRQUFRLFFBQUEsQ0FBUyxPQUFPLGtCQUFrQixLQUFLLE9BQU8sR0FBRztHQUVqSixNQUFNLFdBQVc7R0FDakIsTUFBTSxFQUFFLE1BQU0sTUFBTSxFQUFFLGFBQWEsT0FBTyxnQkFBZ0IsVUFBVSxDQUFDLE1BQU07R0FDM0UsSUFBSSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsYUFBYSxTQUFTLFlBQ2pFO0dBRUYsTUFBTSxlQUFlLEtBQUssU0FBUztHQUNuQyxnQkFBZ0IsU0FBUyxjQUFjLFNBQVMsU0FBUztHQUN6RCxNQUFNLGVBQWU7R0FDckIsZUFBZTtHQUNmLG9CQUFvQjtJQUFFLFFBQVE7SUFBbUIsTUFBTTtHQUFLO0dBQzVELElBQUk7SUFDRixJQUFJLFFBQVEsYUFBYSxLQUFLLFFBQVEsQ0FBQyxjQUFjLENBQUMsZUFDcEQsS0FBSyxXQUFXLEtBQUs7SUFFdkIsSUFBSTtLQUNGLE9BQU8sS0FBSyxjQUFjLFdBQVcsTUFBTSxVQUFVLFdBQVcsU0FBUztJQUMzRSxTQUFTLE9BQU87S0FDZCxJQUFJLEtBQUssY0FBYyxZQUFZLE1BQU0sS0FBSyxHQUM1QyxNQUFNO0lBRVY7R0FDRixVQUFVO0lBQ1IsTUFBTSxRQUFRLEtBQUs7SUFDbkIsSUFBSSxVQUFVLGdCQUFnQixVQUFVLFNBQ3RDLElBQUksUUFBUSxhQUFhLGNBQWMsaUJBQWlCLFVBQVUsWUFDaEUsZ0JBQWdCLFNBQVMsY0FBYyxXQUFXLFNBQVMsVUFBVTtTQUNoRTtLQUNMLE1BQU0sZ0JBQWdCLFNBQVM7S0FDL0IsS0FBSyxpQkFBaUIsVUFBVSxFQUFFO0tBQ2xDLGdCQUFnQixTQUFTLGNBQWMsY0FBYyxTQUFTLFlBQVk7S0FDMUUsSUFBSSxlQUNGLFNBQVMsaUJBQWlCO0lBRTlCO0lBRUYsb0JBQW9CLGtCQUFrQjtJQUN0QyxlQUFlO0dBQ2pCO0VBQ0Y7RUFDQSxhQUFhLE1BQU07R0FDakIsSUFBSSxLQUFLLFFBQVEsS0FBSyxTQUFTLE1BQU07SUFDbkMsSUFBSSxVQUFVO0lBQ2QsT0FBTyxTQUFTO0tBQ2QsSUFBSSxZQUFZLEtBQUssTUFDbkIsTUFBTSxNQUFNLDhCQUE4QixLQUFLLEtBQUssNkNBQTZDLEtBQUssS0FBSyxNQUFNO0tBRW5ILFVBQVUsUUFBUTtJQUNwQjtHQUNGO0dBQ0EsS0FBSyxjQUFjLFlBQVksWUFBWTtHQUMzQyxNQUFNLGdCQUFnQixDQUFDO0dBQ3ZCLEtBQUssaUJBQWlCO0dBQ3RCLEtBQUssUUFBUTtHQUNiLElBQUk7SUFDRixPQUFPLEtBQUssY0FBYyxhQUFhLE1BQU0sSUFBSTtHQUNuRCxTQUFTLEtBQUs7SUFDWixLQUFLLGNBQWMsU0FBUyxZQUFZLFlBQVk7SUFDcEQsS0FBSyxjQUFjLFlBQVksTUFBTSxHQUFHO0lBQ3hDLE1BQU07R0FDUjtHQUNBLElBQUksS0FBSyxtQkFBbUIsZUFDMUIsS0FBSyxpQkFBaUIsTUFBTSxDQUFDO0dBRS9CLElBQUksS0FBSyxTQUFTLFlBQ2hCLEtBQUssY0FBYyxXQUFXLFVBQVU7R0FFMUMsT0FBTztFQUNUO0VBQ0Esa0JBQWtCLFFBQVEsVUFBVSxNQUFNLGdCQUFnQjtHQUN4RCxPQUFPLEtBQUssYUFBYSxJQUFJLFNBQVMsV0FBVyxRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLENBQUM7RUFDbEc7RUFDQSxrQkFBa0IsUUFBUSxVQUFVLE1BQU0sZ0JBQWdCLGNBQWM7R0FDdEUsT0FBTyxLQUFLLGFBQWEsSUFBSSxTQUFTLFdBQVcsUUFBUSxVQUFVLE1BQU0sZ0JBQWdCLFlBQVksQ0FBQztFQUN4RztFQUNBLGtCQUFrQixRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsY0FBYztHQUN0RSxPQUFPLEtBQUssYUFBYSxJQUFJLFNBQVMsV0FBVyxRQUFRLFVBQVUsTUFBTSxnQkFBZ0IsWUFBWSxDQUFDO0VBQ3hHO0VBQ0EsV0FBVyxNQUFNO0dBQ2YsSUFBSSxLQUFLLFFBQVEsTUFDZixNQUFNLElBQUksTUFBTSx1RUFBdUUsS0FBSyxRQUFRLFFBQUEsQ0FBUyxPQUFPLGtCQUFrQixLQUFLLE9BQU8sR0FBRztHQUN2SixJQUFJLEtBQUssVUFBVSxhQUFhLEtBQUssVUFBVSxTQUM3QztHQUVGLEtBQUssY0FBYyxXQUFXLFdBQVcsT0FBTztHQUNoRCxJQUFJO0lBQ0YsS0FBSyxjQUFjLFdBQVcsTUFBTSxJQUFJO0dBQzFDLFNBQVMsS0FBSztJQUNaLEtBQUssY0FBYyxTQUFTLFNBQVM7SUFDckMsS0FBSyxjQUFjLFlBQVksTUFBTSxHQUFHO0lBQ3hDLE1BQU07R0FDUjtHQUNBLEtBQUssaUJBQWlCLE1BQU0sRUFBRTtHQUM5QixLQUFLLGNBQWMsY0FBYyxTQUFTO0dBQzFDLEtBQUssV0FBVztHQUNoQixPQUFPO0VBQ1Q7RUFDQSxpQkFBaUIsTUFBTSxPQUFPO0dBQzVCLE1BQU0sZ0JBQWdCLEtBQUs7R0FDM0IsSUFBSSxTQUFTLElBQ1gsS0FBSyxpQkFBaUI7R0FFeEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUN4QyxjQUFjLEVBQUUsQ0FBQyxpQkFBaUIsS0FBSyxNQUFNLEtBQUs7RUFFdEQ7Q0FDRjtDQUNBLGNBQWMsV0FBVyxjQUFjLFVBQVU7Q0FDakQsSUFBSSxXQUFXO0NBQ2YsTUFBTSxjQUFjO0VBQ2xCLE1BQU07RUFDTixZQUFZLFVBQVUsR0FBRyxRQUFRLGlCQUFpQixTQUFTLFFBQVEsUUFBUSxZQUFZO0VBQ3ZGLGlCQUFpQixVQUFVLEdBQUcsUUFBUSxTQUFTLFNBQVMsYUFBYSxRQUFRLElBQUk7RUFDakYsZUFBZSxVQUFVLEdBQUcsUUFBUSxNQUFNLFdBQVcsY0FBYyxTQUFTLFdBQVcsUUFBUSxNQUFNLFdBQVcsU0FBUztFQUN6SCxlQUFlLFVBQVUsR0FBRyxRQUFRLFNBQVMsU0FBUyxXQUFXLFFBQVEsSUFBSTtDQUMvRTtDQUNBLE1BQU0sY0FBYztFQUNsQixZQUFZLE1BQU0sZ0JBQWdCLFVBQVU7R0FDMUMsY0FBYyxNQUFNLE9BQU87R0FDM0IsY0FBYyxNQUFNLGVBQWU7SUFDakMsYUFBYTtJQUNiLGFBQWE7SUFDYixhQUFhO0dBQ2YsQ0FBQztHQUNELGNBQWMsTUFBTSxXQUFXO0dBQy9CLGNBQWMsTUFBTSxTQUFTO0dBQzdCLGNBQWMsTUFBTSxlQUFlO0dBQ25DLGNBQWMsTUFBTSxnQkFBZ0I7R0FDcEMsY0FBYyxNQUFNLGNBQWM7R0FDbEMsY0FBYyxNQUFNLG9CQUFvQjtHQUN4QyxjQUFjLE1BQU0sYUFBYTtHQUNqQyxjQUFjLE1BQU0sV0FBVztHQUMvQixjQUFjLE1BQU0saUJBQWlCO0dBQ3JDLGNBQWMsTUFBTSxrQkFBa0I7R0FDdEMsY0FBYyxNQUFNLGdCQUFnQjtHQUNwQyxjQUFjLE1BQU0sc0JBQXNCO0dBQzFDLGNBQWMsTUFBTSxtQkFBbUI7R0FDdkMsY0FBYyxNQUFNLGlCQUFpQjtHQUNyQyxjQUFjLE1BQU0sdUJBQXVCO0dBQzNDLGNBQWMsTUFBTSxpQkFBaUI7R0FDckMsY0FBYyxNQUFNLGVBQWU7R0FDbkMsY0FBYyxNQUFNLHFCQUFxQjtHQUN6QyxjQUFjLE1BQU0saUJBQWlCO0dBQ3JDLGNBQWMsTUFBTSxlQUFlO0dBQ25DLGNBQWMsTUFBTSxxQkFBcUI7R0FDekMsY0FBYyxNQUFNLGNBQWM7R0FDbEMsY0FBYyxNQUFNLG1CQUFtQjtHQUN2QyxjQUFjLE1BQU0sWUFBWTtHQUNoQyxjQUFjLE1BQU0sa0JBQWtCO0dBQ3RDLEtBQUssUUFBUTtHQUNiLEtBQUssVUFBVSxhQUFhLFlBQVksU0FBUyxTQUFTLFdBQVcsZUFBZTtHQUNwRixLQUFLLFlBQVksYUFBYSxTQUFTLFNBQVMsaUJBQWlCLGVBQWU7R0FDaEYsS0FBSyxnQkFBZ0IsYUFBYSxTQUFTLFNBQVMsS0FBSyxRQUFRLGVBQWU7R0FDaEYsS0FBSyxlQUFlLGFBQWEsU0FBUyxjQUFjLFdBQVcsZUFBZTtHQUNsRixLQUFLLGlCQUFpQixhQUFhLFNBQVMsY0FBYyxpQkFBaUIsZUFBZTtHQUMxRixLQUFLLHFCQUFxQixhQUFhLFNBQVMsY0FBYyxLQUFLLFFBQVEsZUFBZTtHQUMxRixLQUFLLFlBQVksYUFBYSxTQUFTLFdBQVcsV0FBVyxlQUFlO0dBQzVFLEtBQUssY0FBYyxhQUFhLFNBQVMsV0FBVyxpQkFBaUIsZUFBZTtHQUNwRixLQUFLLGtCQUFrQixhQUFhLFNBQVMsV0FBVyxLQUFLLFFBQVEsZUFBZTtHQUNwRixLQUFLLGlCQUFpQixhQUFhLFNBQVMsZ0JBQWdCLFdBQVcsZUFBZTtHQUN0RixLQUFLLG1CQUFtQixhQUFhLFNBQVMsZ0JBQWdCLGlCQUFpQixlQUFlO0dBQzlGLEtBQUssdUJBQXVCLGFBQWEsU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLGVBQWU7R0FDOUYsS0FBSyxrQkFBa0IsYUFBYSxTQUFTLGlCQUFpQixXQUFXLGVBQWU7R0FDeEYsS0FBSyxvQkFBb0IsYUFBYSxTQUFTLGlCQUFpQixpQkFBaUIsZUFBZTtHQUNoRyxLQUFLLHdCQUF3QixhQUFhLFNBQVMsaUJBQWlCLEtBQUssUUFBUSxlQUFlO0dBQ2hHLEtBQUssZ0JBQWdCLGFBQWEsU0FBUyxlQUFlLFdBQVcsZUFBZTtHQUNwRixLQUFLLGtCQUFrQixhQUFhLFNBQVMsZUFBZSxpQkFBaUIsZUFBZTtHQUM1RixLQUFLLHNCQUFzQixhQUFhLFNBQVMsZUFBZSxLQUFLLFFBQVEsZUFBZTtHQUM1RixLQUFLLGdCQUFnQixhQUFhLFNBQVMsZUFBZSxXQUFXLGVBQWU7R0FDcEYsS0FBSyxrQkFBa0IsYUFBYSxTQUFTLGVBQWUsaUJBQWlCLGVBQWU7R0FDNUYsS0FBSyxzQkFBc0IsYUFBYSxTQUFTLGVBQWUsS0FBSyxRQUFRLGVBQWU7R0FDNUYsS0FBSyxhQUFhO0dBQ2xCLEtBQUssZUFBZTtHQUNwQixLQUFLLG9CQUFvQjtHQUN6QixLQUFLLG1CQUFtQjtHQUN4QixNQUFNLGtCQUFrQixZQUFZLFNBQVM7R0FDN0MsTUFBTSxnQkFBZ0Isa0JBQWtCLGVBQWU7R0FDdkQsSUFBSSxtQkFBbUIsZUFBZTtJQUNwQyxLQUFLLGFBQWEsa0JBQWtCLFdBQVc7SUFDL0MsS0FBSyxlQUFlO0lBQ3BCLEtBQUssb0JBQW9CO0lBQ3pCLEtBQUssbUJBQW1CLEtBQUs7SUFDN0IsSUFBSSxDQUFDLFNBQVMsZ0JBQWdCO0tBQzVCLEtBQUssa0JBQWtCO0tBQ3ZCLEtBQUssb0JBQW9CO0tBQ3pCLEtBQUssd0JBQXdCLEtBQUs7SUFDcEM7SUFDQSxJQUFJLENBQUMsU0FBUyxjQUFjO0tBQzFCLEtBQUssZ0JBQWdCO0tBQ3JCLEtBQUssa0JBQWtCO0tBQ3ZCLEtBQUssc0JBQXNCLEtBQUs7SUFDbEM7SUFDQSxJQUFJLENBQUMsU0FBUyxjQUFjO0tBQzFCLEtBQUssZ0JBQWdCO0tBQ3JCLEtBQUssa0JBQWtCO0tBQ3ZCLEtBQUssc0JBQXNCLEtBQUs7SUFDbEM7R0FDRjtFQUNGO0VBQ0EsSUFBSSxPQUFPO0dBQ1QsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxLQUFLLFlBQVksVUFBVTtHQUN6QixPQUFPLEtBQUssVUFBVSxLQUFLLFFBQVEsT0FBTyxLQUFLLFdBQVcsS0FBSyxNQUFNLFlBQVksUUFBUSxJQUFJLElBQUksU0FBUyxZQUFZLFFBQVE7RUFDaEk7RUFDQSxVQUFVLFlBQVksVUFBVSxRQUFRO0dBQ3RDLE9BQU8sS0FBSyxlQUFlLEtBQUssYUFBYSxZQUFZLEtBQUssZ0JBQWdCLEtBQUssb0JBQW9CLFlBQVksVUFBVSxNQUFNLElBQUk7RUFDekk7RUFDQSxPQUFPLFlBQVksVUFBVSxXQUFXLFdBQVcsUUFBUTtHQUN6RCxPQUFPLEtBQUssWUFBWSxLQUFLLFVBQVUsU0FBUyxLQUFLLGFBQWEsS0FBSyxpQkFBaUIsWUFBWSxVQUFVLFdBQVcsV0FBVyxNQUFNLElBQUksU0FBUyxNQUFNLFdBQVcsU0FBUztFQUNuTDtFQUNBLFlBQVksWUFBWSxPQUFPO0dBQzdCLE9BQU8sS0FBSyxpQkFBaUIsS0FBSyxlQUFlLGNBQWMsS0FBSyxrQkFBa0IsS0FBSyxzQkFBc0IsWUFBWSxLQUFLLElBQUk7RUFDeEk7RUFDQSxhQUFhLFlBQVksTUFBTTtHQUM3QixJQUFJLGFBQWE7R0FDakIsSUFBSSxLQUFLLGlCQUFpQjtJQUN4QixJQUFJLEtBQUssWUFDUCxXQUFXLGVBQWUsS0FBSyxLQUFLLGlCQUFpQjtJQUV2RCxhQUFhLEtBQUssZ0JBQWdCLGVBQWUsS0FBSyxtQkFBbUIsS0FBSyx1QkFBdUIsWUFBWSxJQUFJO0lBQ3JILElBQUksQ0FBQyxZQUNILGFBQWE7R0FDakIsT0FDRSxJQUFJLEtBQUssWUFDUCxLQUFLLFdBQVcsSUFBSTtRQUNmLElBQUksS0FBSyxRQUFRLFdBQ3RCLGtCQUFrQixJQUFJO1FBRXRCLE1BQU0sSUFBSSxNQUFNLDZCQUE2QjtHQUdqRCxPQUFPO0VBQ1Q7RUFDQSxXQUFXLFlBQVksTUFBTSxXQUFXLFdBQVc7R0FDakQsT0FBTyxLQUFLLGdCQUFnQixLQUFLLGNBQWMsYUFBYSxLQUFLLGlCQUFpQixLQUFLLHFCQUFxQixZQUFZLE1BQU0sV0FBVyxTQUFTLElBQUksS0FBSyxTQUFTLE1BQU0sV0FBVyxTQUFTO0VBQ2hNO0VBQ0EsV0FBVyxZQUFZLE1BQU07R0FDM0IsSUFBSTtHQUNKLElBQUksS0FBSyxlQUNQLFFBQVEsS0FBSyxjQUFjLGFBQWEsS0FBSyxpQkFBaUIsS0FBSyxxQkFBcUIsWUFBWSxJQUFJO1FBQ25HO0lBQ0wsSUFBSSxDQUFDLEtBQUssVUFDUixNQUFNLE1BQU0sd0JBQXdCO0lBRXRDLFFBQVEsS0FBSyxTQUFTLElBQUk7R0FDNUI7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxRQUFRLFlBQVksU0FBUztHQUMzQixJQUFJO0lBQ0YsS0FBSyxjQUFjLEtBQUssV0FBVyxVQUFVLEtBQUssY0FBYyxLQUFLLGtCQUFrQixZQUFZLE9BQU87R0FDNUcsU0FBUyxLQUFLO0lBQ1osS0FBSyxZQUFZLFlBQVksR0FBRztHQUNsQztFQUNGO0VBQ0EsaUJBQWlCLE1BQU0sT0FBTztHQUM1QixNQUFNLFNBQVMsS0FBSztHQUNwQixNQUFNLE9BQU8sT0FBTztHQUNwQixNQUFNLE9BQU8sT0FBTyxRQUFRLE9BQU87R0FDbkMsSUFBSSxPQUFPLEdBQ1QsTUFBTSxJQUFJLE1BQU0sMENBQTBDO0dBRTVELElBQUksUUFBUSxLQUFLLFFBQVEsR0FBRztJQUMxQixNQUFNLFVBQVU7S0FDZCxXQUFXLE9BQU8sZUFBZTtLQUNqQyxXQUFXLE9BQU8sZUFBZTtLQUNqQyxXQUFXLE9BQU8sZUFBZTtLQUNqQyxRQUFRO0lBQ1Y7SUFDQSxLQUFLLFFBQVEsS0FBSyxPQUFPLE9BQU87R0FDbEM7RUFDRjtDQUNGO0NBQ0EsTUFBTSxTQUFTO0VBQ2IsWUFBWSxNQUFNLFFBQVEsVUFBVSxTQUFTLFlBQVksVUFBVTtHQUNqRSxjQUFjLE1BQU0sTUFBTTtHQUMxQixjQUFjLE1BQU0sUUFBUTtHQUM1QixjQUFjLE1BQU0sUUFBUTtHQUM1QixjQUFjLE1BQU0sVUFBVTtHQUM5QixjQUFjLE1BQU0sTUFBTTtHQUMxQixjQUFjLE1BQU0sWUFBWTtHQUNoQyxjQUFjLE1BQU0sVUFBVTtHQUM5QixjQUFjLE1BQU0sU0FBUyxJQUFJO0dBQ2pDLGNBQWMsTUFBTSxZQUFZLENBQUM7R0FDakMsY0FBYyxNQUFNLGtCQUFrQixJQUFJO0dBQzFDLGNBQWMsTUFBTSxVQUFVLGNBQWM7R0FDNUMsS0FBSyxPQUFPO0dBQ1osS0FBSyxTQUFTO0dBQ2QsS0FBSyxPQUFPO0dBQ1osS0FBSyxhQUFhO0dBQ2xCLEtBQUssV0FBVztHQUNoQixJQUFJLENBQUMsVUFDSCxNQUFNLElBQUksTUFBTSx5QkFBeUI7R0FFM0MsS0FBSyxXQUFXO0dBQ2hCLE1BQU0sUUFBUTtHQUNkLElBQUksU0FBUyxhQUFhLFdBQVcsUUFBUSxNQUMzQyxLQUFLLFNBQVMsU0FBUztRQUV2QixLQUFLLFNBQVMsV0FBVztJQUN2QixPQUFPLFNBQVMsV0FBVyxLQUFLLFFBQVEsT0FBTyxNQUFNLFNBQVM7R0FDaEU7RUFFSjtFQUNBLE9BQU8sV0FBVyxNQUFNLFFBQVEsTUFBTTtHQUNwQyxJQUFJLENBQUMsTUFDSCxPQUFPO0dBRVQ7R0FDQSxJQUFJO0lBQ0YsS0FBSztJQUNMLE9BQU8sS0FBSyxLQUFLLFFBQVEsTUFBTSxRQUFRLElBQUk7R0FDN0MsVUFBVTtJQUNSLElBQUksOEJBQThCLEtBQUssQ0FBQyxPQUFPLGdDQUM3QyxpQ0FBaUM7SUFFbkM7R0FDRjtFQUNGO0VBQ0EsSUFBSSxPQUFPO0dBQ1QsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxJQUFJLFFBQVE7R0FDVixPQUFPLEtBQUs7RUFDZDtFQUNBLHdCQUF3QjtHQUN0QixLQUFLLGNBQWMsY0FBYyxVQUFVO0VBQzdDO0VBQ0EsY0FBYyxTQUFTLFlBQVksWUFBWTtHQUM3QyxJQUFJLEtBQUssV0FBVyxjQUFjLEtBQUssV0FBVyxZQUFZO0lBQzVELEtBQUssU0FBUztJQUNkLElBQUksV0FBVyxjQUNiLEtBQUssaUJBQWlCO0dBRTFCLE9BQ0UsTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLEtBQUssSUFBSSxLQUFLLE9BQU8sNEJBQTRCLFFBQVEsc0JBQXNCLFdBQVcsR0FBRyxhQUFhLFVBQVUsYUFBYSxNQUFNLEdBQUcsU0FBUyxLQUFLLE9BQU8sR0FBRztFQUU5TDtFQUNBLFdBQVc7R0FDVCxJQUFJLEtBQUssUUFBUSxPQUFPLEtBQUssS0FBSyxhQUFhLGFBQzdDLE9BQU8sS0FBSyxLQUFLLFNBQVMsU0FBUztRQUVuQyxPQUFPLE9BQU8sVUFBVSxTQUFTLEtBQUssSUFBSTtFQUU5QztFQUdBLFNBQVM7R0FDUCxPQUFPO0lBQ0wsTUFBTSxLQUFLO0lBQ1gsT0FBTyxLQUFLO0lBQ1osUUFBUSxLQUFLO0lBQ2IsTUFBTSxLQUFLLEtBQUs7SUFDaEIsVUFBVSxLQUFLO0dBQ2pCO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sbUJBQW1CLFdBQVcsWUFBWTtDQUNoRCxNQUFNLGdCQUFnQixXQUFXLFNBQVM7Q0FDMUMsTUFBTSxhQUFhLFdBQVcsTUFBTTtDQUNwQyxNQUFNLGdDQUFnQyxXQUFXLGtDQUFrQztDQUNuRixJQUFJLGtCQUFrQixDQUFDO0NBQ3ZCLElBQUksNEJBQTRCO0NBQ2hDLElBQUk7Q0FDSixTQUFTLHdCQUF3QixNQUFNO0VBQ3JDLElBQUk7RUFDSixJQUFJLENBQUMsK0JBQStCLE9BQU8sZ0JBQ3pDLDhCQUE4QixPQUFPLGNBQWMsQ0FBQyxRQUFRLENBQUM7RUFFL0QsSUFBSSw2QkFFRixFQURnQixLQUFLLDRCQUE0QixnQkFBZ0IsT0FBTyxLQUFLLDRCQUE0QixRQUFBLENBQ2xHLEtBQUssNkJBQTZCLElBQUk7T0FFN0MsT0FBTyxpQkFBaUIsQ0FBQyxNQUFNLENBQUM7Q0FFcEM7Q0FDQSxTQUFTLGtCQUFrQixNQUFNO0VBQy9CLE1BQU0sMEJBQTBCLE9BQU87RUFDdkMsTUFBTSx3QkFBd0IsMkJBQTJCLGdCQUFnQixXQUFXLEtBQUssQ0FBQztFQUMxRixNQUFNLDJCQUEyQixDQUFDLDJCQUEyQiw4QkFBOEIsS0FBSyxnQkFBZ0IsV0FBVztFQUMzSCxJQUFJLHlCQUF5QiwwQkFDM0Isd0JBQXdCLGdDQUFnQztFQUUxRCxJQUFJLE1BQ0YsZ0JBQWdCLEtBQUssSUFBSTtDQUU3QjtDQUNBLFNBQVMsbUNBQW1DO0VBQzFDLElBQUksMkJBQ0Y7RUFFRiw0QkFBNEI7RUFDNUIsT0FBTyxnQkFBZ0IsUUFBUTtHQUM3QixNQUFNLFFBQVE7R0FDZCxrQkFBa0IsQ0FBQztHQUNuQixLQUFLLE1BQU0sUUFBUSxPQUNqQixJQUFJO0lBQ0YsS0FBSyxLQUFLLFFBQVEsTUFBTSxNQUFNLElBQUk7R0FDcEMsU0FBUyxPQUFPO0lBQ2QsS0FBSyxpQkFBaUIsS0FBSztHQUM3QjtFQUVKO0VBQ0EsSUFBSSxPQUFPLGdDQUFnQztHQUN6Qyw0QkFBNEI7R0FDNUIsS0FBSyxtQkFBbUI7RUFDMUIsT0FBTztHQUNMLEtBQUssbUJBQW1CO0dBQ3hCLDRCQUE0QjtFQUM5QjtDQUNGO0NBQ0EsTUFBTSxVQUFVLEVBQUUsTUFBTSxVQUFVO0NBQ2xDLE1BQU0sZUFBZSxnQkFBZ0IsYUFBYSxjQUFjLFlBQVksYUFBYSxVQUFVLFdBQVcsWUFBWSxhQUFhLFVBQVU7Q0FDakosTUFBTSxZQUFZLGFBQWEsWUFBWSxhQUFhLFlBQVk7Q0FDcEUsTUFBTSxVQUFVLENBQUM7Q0FDakIsTUFBTSxPQUFPO0VBQ1gsUUFBUTtFQUNSLHdCQUF3QjtFQUN4QixrQkFBa0I7RUFDbEIsb0JBQW9CO0VBQ3BCO0VBQ0EseUJBQXlCLENBQUMsU0FBUyxXQUFXLGlDQUFpQztFQUMvRSx3QkFBd0IsQ0FBQztFQUN6QixtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLHFCQUFxQixDQUFDO0VBQ3RCLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsMkJBQTJCO0VBQzNCLHdCQUF3QixLQUFLO0VBQzdCLDRCQUE0QjtFQUM1QixzQ0FBc0MsS0FBSztFQUMzQyxvQkFBb0IsS0FBSztFQUN6QixrQkFBa0IsQ0FBQztFQUNuQixrQkFBa0I7RUFDbEIsMkJBQTJCO0VBQzNCLHdCQUF3QixDQUFDO0VBQ3pCLDZCQUE2QjtFQUM3Qix5QkFBeUI7RUFDekIsc0JBQXNCO0VBQ3RCO0NBQ0Y7Q0FDQSxJQUFJLG9CQUFvQjtFQUFFLFFBQVE7RUFBTSxNQUFNLElBQUksU0FBUyxNQUFNLElBQUk7Q0FBRTtDQUN2RSxJQUFJLGVBQWU7Q0FDbkIsSUFBSSw0QkFBNEI7Q0FDaEMsU0FBUyxPQUFPLENBQ2hCO0NBQ0EsbUJBQW1CLFFBQVEsTUFBTTtDQUNqQyxPQUFPO0FBQ1Q7QUFHQSxTQUFTLFdBQVc7Q0FFbEIsTUFBTSxVQUFVO0NBQ2hCLE1BQU0saUJBQWlCLFFBQVEsV0FBVyx5QkFBeUIsT0FBTztDQUMxRSxJQUFJLFFBQVEsWUFBWSxrQkFBa0IsT0FBTyxRQUFRLE9BQU8sQ0FBQyxlQUFlLGFBQzlFLE1BQU0sSUFBSSxNQUFNLHNCQUFzQjtDQUV4QyxRQUFjLFdBQVksU0FBWSxRQUFRLFVBQVUsU0FBUztDQUNqRSxPQUFPLFFBQVE7QUFDakI7QUFHQSxJQUFJLGlDQUFpQyxPQUFPO0FBQzVDLElBQUksdUJBQXVCLE9BQU87QUFDbEMsSUFBSSx1QkFBdUIsT0FBTztBQUNsQyxJQUFJLGVBQWUsT0FBTztBQUMxQixJQUFJLGFBQWEsTUFBTSxVQUFVO0FBQ2pDLElBQUkseUJBQXlCO0FBQzdCLElBQUksNEJBQTRCO0FBQ2hDLElBQUksaUNBQWlDLFdBQVcsc0JBQXNCO0FBQ3RFLElBQUksb0NBQW9DLFdBQVcseUJBQXlCO0FBQzVFLElBQUksV0FBVztBQUNmLElBQUksWUFBWTtBQUNoQixJQUFJLHFCQUFxQixXQUFXLEVBQUU7QUFDdEMsU0FBUyxvQkFBb0IsVUFBVSxRQUFRO0NBQzdDLE9BQU8sS0FBSyxRQUFRLEtBQUssVUFBVSxNQUFNO0FBQzNDO0FBQ0EsU0FBUyxpQ0FBaUMsUUFBUSxVQUFVLE1BQU0sZ0JBQWdCLGNBQWM7Q0FDOUYsT0FBTyxLQUFLLFFBQVEsa0JBQWtCLFFBQVEsVUFBVSxNQUFNLGdCQUFnQixZQUFZO0FBQzVGO0FBQ0EsSUFBSSxhQUFhO0FBQ2pCLElBQUksaUJBQWlCLE9BQU8sV0FBVztBQUN2QyxJQUFJLGlCQUFpQixpQkFBaUIsU0FBUyxLQUFLO0FBQ3BELElBQUksVUFBVSxrQkFBa0Isa0JBQWtCO0FBQ2xELElBQUksbUJBQW1CO0FBQ3ZCLFNBQVMsY0FBYyxNQUFNLFFBQVE7Q0FDbkMsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQ3BDLElBQUksT0FBTyxLQUFLLE9BQU8sWUFDckIsS0FBSyxLQUFLLG9CQUFvQixLQUFLLElBQUksU0FBUyxNQUFNLENBQUM7Q0FHM0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLFdBQVcsU0FBUztDQUMxQyxNQUFNLFNBQVMsVUFBVSxZQUFZO0NBQ3JDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztFQUN2QyxNQUFNLE9BQU8sUUFBUTtFQUNyQixNQUFNLFdBQVcsVUFBVTtFQUMzQixJQUFJLFVBQVU7R0FFWixJQUFJLENBQUMsbUJBRGlCLCtCQUErQixXQUFXLElBQzVCLENBQUMsR0FDbkM7R0FFRixVQUFVLFVBQVUsY0FBYztJQUNoQyxNQUFNLFVBQVUsV0FBVztLQUN6QixPQUFPLFVBQVUsTUFBTSxNQUFNLGNBQWMsV0FBVyxTQUFTLE1BQU0sSUFBSSxDQUFDO0lBQzVFO0lBQ0Esc0JBQXNCLFNBQVMsU0FBUztJQUN4QyxPQUFPO0dBQ1QsRUFBQSxDQUFHLFFBQVE7RUFDYjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixjQUFjO0NBQ3hDLElBQUksQ0FBQyxjQUNILE9BQU87Q0FFVCxJQUFJLGFBQWEsYUFBYSxPQUM1QixPQUFPO0NBRVQsT0FBTyxFQUFFLE9BQU8sYUFBYSxRQUFRLGNBQWMsT0FBTyxhQUFhLFFBQVE7QUFDakY7QUFDQSxJQUFJLGNBQWMsT0FBTyxzQkFBc0IsZUFBZSxnQkFBZ0I7QUFDOUUsSUFBSSxTQUFTLEVBQUUsUUFBUSxZQUFZLE9BQU8sUUFBUSxZQUFZLGVBQWUsUUFBUSxRQUFRLFNBQVMsTUFBTTtBQUM1RyxJQUFJLFlBQVksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLEVBQUUsa0JBQWtCLGVBQWU7QUFDL0UsSUFBSSxRQUFRLE9BQU8sUUFBUSxZQUFZLGVBQWUsUUFBUSxRQUFRLFNBQVMsTUFBTSxzQkFBc0IsQ0FBQyxlQUFlLENBQUMsRUFBRSxrQkFBa0IsZUFBZTtBQUMvSixJQUFJLHVCQUF1QixDQUFDO0FBQzVCLElBQUksMkJBQTJCLFdBQVcscUJBQXFCO0FBQy9ELElBQUksU0FBUyxTQUFTLE9BQU87Q0FDM0IsUUFBUSxTQUFTLFFBQVE7Q0FDekIsSUFBSSxDQUFDLE9BQ0g7Q0FFRixJQUFJLGtCQUFrQixxQkFBcUIsTUFBTTtDQUNqRCxJQUFJLENBQUMsaUJBQ0gsa0JBQWtCLHFCQUFxQixNQUFNLFFBQVEsV0FBVyxnQkFBZ0IsTUFBTSxJQUFJO0NBRTVGLE1BQU0sU0FBUyxRQUFRLE1BQU0sVUFBVTtDQUN2QyxNQUFNLFdBQVcsT0FBTztDQUN4QixJQUFJO0NBQ0osSUFBSSxhQUFhLFdBQVcsa0JBQWtCLE1BQU0sU0FBUyxTQUFTO0VBQ3BFLE1BQU0sYUFBYTtFQUNuQixTQUFTLFlBQVksU0FBUyxLQUFLLE1BQU0sV0FBVyxTQUFTLFdBQVcsVUFBVSxXQUFXLFFBQVEsV0FBVyxPQUFPLFdBQVcsS0FBSztFQUN2SSxJQUFJLFdBQVcsTUFDYixNQUFNLGVBQWU7Q0FFekIsT0FBTztFQUNMLFNBQVMsWUFBWSxTQUFTLE1BQU0sTUFBTSxTQUFTO0VBQ25ELElBTUUsTUFBTSxTQUFTLGtCQUtmLFFBQVEsNkJBRVIsT0FBTyxXQUFXLFVBRWxCLE1BQU0sY0FBYztPQUNmLElBQUksVUFBVSxLQUFLLEtBQUssQ0FBQyxRQUM5QixNQUFNLGVBQWU7Q0FFekI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWMsS0FBSyxNQUFNLFdBQVc7Q0FDM0MsSUFBSSxPQUFPLCtCQUErQixLQUFLLElBQUk7Q0FDbkQsSUFBSSxDQUFDLFFBQVE7TUFDVywrQkFBK0IsV0FBVyxJQUNoRCxHQUNkLE9BQU87R0FBRSxZQUFZO0dBQU0sY0FBYztFQUFLO0NBQUE7Q0FHbEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLGNBQ2pCO0NBRUYsTUFBTSxzQkFBc0IsV0FBVyxPQUFPLE9BQU8sU0FBUztDQUM5RCxJQUFJLElBQUksZUFBZSxtQkFBbUIsS0FBSyxJQUFJLHNCQUNqRDtDQUVGLE9BQU8sS0FBSztDQUNaLE9BQU8sS0FBSztDQUNaLE1BQU0sa0JBQWtCLEtBQUs7Q0FDN0IsTUFBTSxrQkFBa0IsS0FBSztDQUM3QixNQUFNLFlBQVksS0FBSyxNQUFNLENBQUM7Q0FDOUIsSUFBSSxrQkFBa0IscUJBQXFCO0NBQzNDLElBQUksQ0FBQyxpQkFDSCxrQkFBa0IscUJBQXFCLGFBQWEsV0FBVyxnQkFBZ0IsU0FBUztDQUUxRixLQUFLLE1BQU0sU0FBUyxVQUFVO0VBQzVCLElBQUksU0FBUztFQUNiLElBQUksQ0FBQyxVQUFVLFFBQVEsU0FDckIsU0FBUztFQUVYLElBQUksQ0FBQyxRQUNIO0VBR0YsSUFBSSxPQURrQixPQUFPLHFCQUNBLFlBQzNCLE9BQU8sb0JBQW9CLFdBQVcsTUFBTTtFQUU5QyxtQkFBbUIsUUFBZ0IsZ0JBQWdCLEtBQUssUUFBUSxJQUFJO0VBQ3BFLE9BQU8sbUJBQW1CO0VBQzFCLElBQUksT0FBTyxhQUFhLFlBQ3RCLE9BQU8saUJBQWlCLFdBQVcsUUFBUSxLQUFLO0NBRXBEO0NBQ0EsS0FBSyxNQUFNLFdBQVc7RUFDcEIsSUFBSSxTQUFTO0VBQ2IsSUFBSSxDQUFDLFVBQVUsUUFBUSxTQUNyQixTQUFTO0VBRVgsSUFBSSxDQUFDLFFBQ0gsT0FBTztFQUVULE1BQU0sV0FBVyxPQUFPO0VBQ3hCLElBQUksVUFDRixPQUFPO09BQ0YsSUFBSSxpQkFBaUI7R0FDMUIsSUFBSSxRQUFRLGdCQUFnQixLQUFLLElBQUk7R0FDckMsSUFBSSxPQUFPO0lBQ1QsS0FBSyxJQUFJLEtBQUssTUFBTSxLQUFLO0lBQ3pCLElBQUksT0FBTyxPQUFPLHNCQUFzQixZQUN0QyxPQUFPLGdCQUFnQixJQUFJO0lBRTdCLE9BQU87R0FDVDtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EscUJBQXFCLEtBQUssTUFBTSxJQUFJO0NBQ3BDLElBQUksdUJBQXVCO0FBQzdCO0FBQ0EsU0FBUyxrQkFBa0IsS0FBSyxZQUFZLFdBQVc7Q0FDckQsSUFBSSxZQUNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FDckMsY0FBYyxLQUFLLE9BQU8sV0FBVyxJQUFJLFNBQVM7TUFFL0M7RUFDTCxNQUFNLGVBQWUsQ0FBQztFQUN0QixLQUFLLE1BQU0sUUFBUSxLQUNqQixJQUFJLEtBQUssTUFBTSxHQUFHLENBQUMsS0FBSyxNQUN0QixhQUFhLEtBQUssSUFBSTtFQUcxQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQ3ZDLGNBQWMsS0FBSyxhQUFhLElBQUksU0FBUztDQUVqRDtBQUNGO0FBQ0EsSUFBSSxzQkFBc0IsV0FBVyxrQkFBa0I7QUFDdkQsU0FBUyxXQUFXLFdBQVc7Q0FDN0IsTUFBTSxnQkFBZ0IsUUFBUTtDQUM5QixJQUFJLENBQUMsZUFDSDtDQUNGLFFBQVEsV0FBVyxTQUFTLEtBQUs7Q0FDakMsUUFBUSxhQUFhLFdBQVc7RUFDOUIsTUFBTSxJQUFJLGNBQWMsV0FBVyxTQUFTO0VBQzVDLFFBQVEsRUFBRSxRQUFWO0dBQ0UsS0FBSztJQUNILEtBQUssdUJBQXVCLElBQUksY0FBYztJQUM5QztHQUNGLEtBQUs7SUFDSCxLQUFLLHVCQUF1QixJQUFJLGNBQWMsRUFBRSxFQUFFO0lBQ2xEO0dBQ0YsS0FBSztJQUNILEtBQUssdUJBQXVCLElBQUksY0FBYyxFQUFFLElBQUksRUFBRSxFQUFFO0lBQ3hEO0dBQ0YsS0FBSztJQUNILEtBQUssdUJBQXVCLElBQUksY0FBYyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsRUFBRTtJQUM5RDtHQUNGLEtBQUs7SUFDSCxLQUFLLHVCQUF1QixJQUFJLGNBQWMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxFQUFFO0lBQ3BFO0dBQ0YsU0FDRSxNQUFNLElBQUksTUFBTSxvQkFBb0I7RUFDeEM7Q0FDRjtDQUNBLHNCQUFzQixRQUFRLFlBQVksYUFBYTtDQUN2RCxNQUFNLFdBQVcsSUFBSSxjQUFjLFdBQVcsQ0FDOUMsQ0FBQztDQUNELElBQUk7Q0FDSixLQUFLLFFBQVEsVUFBVTtFQUNyQixJQUFJLGNBQWMsb0JBQW9CLFNBQVMsZ0JBQzdDO0VBQ0YsQ0FBQyxTQUFTLE9BQU87R0FDZixJQUFJLE9BQU8sU0FBUyxXQUFXLFlBQzdCLFFBQVEsVUFBVSxDQUFDLFVBQVUsU0FBUyxXQUFXO0lBQy9DLE9BQU8sS0FBSyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLHNCQUFzQixTQUFTO0dBQ3BGO1FBRUEscUJBQXFCLFFBQVEsVUFBVSxDQUFDLFdBQVcsT0FBTztJQUN4RCxLQUFLLFNBQVMsSUFBSTtLQUNoQixJQUFJLE9BQU8sT0FBTyxZQUFZO01BQzVCLEtBQUssb0JBQW9CLENBQUMsU0FBUyxvQkFBb0IsSUFBSSxZQUFZLE1BQU0sS0FBSztNQUNsRixzQkFBc0IsS0FBSyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUU7S0FDNUQsT0FDRSxLQUFLLG9CQUFvQixDQUFDLFNBQVM7SUFFdkM7SUFDQSxLQUFLLFdBQVc7S0FDZCxPQUFPLEtBQUssb0JBQW9CLENBQUM7SUFDbkM7R0FDRixDQUFDO0VBRUwsRUFBQSxDQUFHLElBQUk7Q0FDVDtDQUNBLEtBQUssUUFBUSxlQUNYLElBQUksU0FBUyxlQUFlLGNBQWMsZUFBZSxJQUFJLEdBQzNELFFBQVEsVUFBVSxDQUFDLFFBQVEsY0FBYztBQUcvQztBQUNBLFNBQVMscUJBQXFCLEtBQUssTUFBTTtDQUN2QyxJQUFJLE9BQU8sT0FBTywwQkFBMEIsWUFDMUM7Q0FHRixPQUR1QixzQkFBc0IsR0FDdkMsQ0FBQyxDQUFDLFNBQVMsV0FBVztFQUMxQixNQUFNLE9BQU8sT0FBTyx5QkFBeUIsS0FBSyxNQUFNO0VBQ3hELE9BQU8sZUFBZSxNQUFNLFFBQVE7R0FDbEMsS0FBSyxXQUFXO0lBQ2QsT0FBTyxJQUFJO0dBQ2I7R0FDQSxLQUFLLFNBQVMsT0FBTztJQUNuQixJQUFJLFNBQVMsQ0FBQyxLQUFLLFlBQVksT0FBTyxLQUFLLFFBQVEsYUFDakQ7SUFFRixJQUFJLFVBQVU7R0FDaEI7R0FDQSxZQUFZLE9BQU8sS0FBSyxhQUFhO0dBQ3JDLGNBQWMsT0FBTyxLQUFLLGVBQWU7RUFDM0MsQ0FBQztDQUNILENBQUM7QUFDSDtBQUNBLElBQUksNkJBQTZCO0FBQ2pDLFNBQVMsWUFBWSxRQUFRLE1BQU0sU0FBUztDQUMxQyxJQUFJLFFBQVE7Q0FDWixPQUFPLFNBQVMsQ0FBQyxNQUFNLGVBQWUsSUFBSSxHQUN4QyxRQUFRLHFCQUFxQixLQUFLO0NBRXBDLElBQUksQ0FBQyxTQUFTLE9BQU8sT0FDbkIsUUFBUTtDQUVWLE1BQU0sZUFBZSxXQUFXLElBQUk7Q0FDcEMsSUFBSSxXQUFXO0NBQ2YsSUFBSSxVQUFVLEVBQUUsV0FBVyxNQUFNLGtCQUFrQixDQUFDLE1BQU0sZUFBZSxZQUFZLElBQUk7RUFDdkYsV0FBVyxNQUFNLGdCQUFnQixNQUFNO0VBRXZDLElBQUksbUJBRFMsU0FBUywrQkFBK0IsT0FBTyxJQUFJLENBQ3JDLEdBQUc7R0FDNUIsTUFBTSxnQkFBZ0IsUUFBUSxVQUFVLGNBQWMsSUFBSTtHQUMxRCxNQUFNLFFBQVEsV0FBVztJQUN2QixPQUFPLGNBQWMsTUFBTSxTQUFTO0dBQ3RDO0dBQ0Esc0JBQXNCLE1BQU0sT0FBTyxRQUFRO0dBQzNDLElBQUksNEJBQ0YscUJBQXFCLFVBQVUsTUFBTSxLQUFLO0VBRTlDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsS0FBSyxVQUFVLGFBQWE7Q0FDbEQsSUFBSSxZQUFZO0NBQ2hCLFNBQVMsYUFBYSxNQUFNO0VBQzFCLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLEtBQUssS0FBSyxLQUFLLFNBQVMsV0FBVztHQUNqQyxLQUFLLE9BQU8sTUFBTSxNQUFNLFNBQVM7RUFDbkM7RUFDQSxVQUFVLE1BQU0sS0FBSyxRQUFRLEtBQUssSUFBSTtFQUN0QyxPQUFPO0NBQ1Q7Q0FDQSxZQUFZLFlBQVksS0FBSyxXQUFXLGFBQWEsU0FBUyxPQUFPLE1BQU07RUFDekUsTUFBTSxPQUFPLFlBQVksT0FBTyxJQUFJO0VBQ3BDLElBQUksS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLEtBQUssV0FBVyxZQUNqRCxPQUFPLGlDQUFpQyxLQUFLLE1BQU0sS0FBSyxLQUFLLFFBQVEsTUFBTSxZQUFZO09BRXZGLE9BQU8sU0FBUyxNQUFNLE9BQU8sSUFBSTtDQUVyQyxDQUFDO0FBQ0g7QUFDQSxTQUFTLHNCQUFzQixTQUFTLFVBQVU7Q0FDaEQsUUFBUSxXQUFXLGtCQUFrQixLQUFLO0FBQzVDO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDekIsT0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxTQUFTLFNBQVMsT0FBTztDQUN2QixPQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUdBLElBQUksaUNBQWlDLEVBQ25DLE1BQU0sS0FDUjtBQUNBLElBQUksd0JBQXdCLENBQUM7QUFDN0IsSUFBSSxnQkFBZ0IsQ0FBQztBQUNyQixJQUFJLHlCQUF5QixJQUFJLE9BQU8sTUFBTSxxQkFBcUIscUJBQXFCO0FBQ3hGLElBQUksK0JBQStCLFdBQVcsb0JBQW9CO0FBQ2xFLFNBQVMsa0JBQWtCLFdBQVcsbUJBQW1CO0NBQ3ZELE1BQU0sa0JBQWtCLG9CQUFvQixrQkFBa0IsU0FBUyxJQUFJLGFBQWE7Q0FDeEYsTUFBTSxpQkFBaUIsb0JBQW9CLGtCQUFrQixTQUFTLElBQUksYUFBYTtDQUN2RixNQUFNLFNBQVMscUJBQXFCO0NBQ3BDLE1BQU0sZ0JBQWdCLHFCQUFxQjtDQUMzQyxzQkFBc0IsYUFBYSxDQUFDO0NBQ3BDLHNCQUFzQixVQUFVLENBQUMsYUFBYTtDQUM5QyxzQkFBc0IsVUFBVSxDQUFDLFlBQVk7QUFDL0M7QUFDQSxTQUFTLGlCQUFpQixVQUFVLEtBQUssTUFBTSxjQUFjO0NBQzNELE1BQU0scUJBQXFCLGdCQUFnQixhQUFhLE9BQU87Q0FDL0QsTUFBTSx3QkFBd0IsZ0JBQWdCLGFBQWEsTUFBTTtDQUNqRSxNQUFNLDJCQUEyQixnQkFBZ0IsYUFBYSxhQUFhO0NBQzNFLE1BQU0sc0NBQXNDLGdCQUFnQixhQUFhLFNBQVM7Q0FDbEYsTUFBTSw2QkFBNkIsV0FBVyxrQkFBa0I7Q0FDaEUsTUFBTSw0QkFBNEIsTUFBTSxxQkFBcUI7Q0FDN0QsTUFBTSx5QkFBeUI7Q0FDL0IsTUFBTSxnQ0FBZ0M7Q0FDdEMsTUFBTSxhQUFhLFNBQVMsTUFBTSxRQUFRLE9BQU87RUFDL0MsSUFBSSxLQUFLLFdBQ1A7RUFFRixNQUFNLFdBQVcsS0FBSztFQUN0QixJQUFJLE9BQU8sYUFBYSxZQUFZLFNBQVMsYUFBYTtHQUN4RCxLQUFLLFlBQVksV0FBVyxTQUFTLFlBQVksTUFBTTtHQUN2RCxLQUFLLG1CQUFtQjtFQUMxQjtFQUNBLElBQUk7RUFDSixJQUFJO0dBQ0YsS0FBSyxPQUFPLE1BQU0sUUFBUSxDQUFDLEtBQUssQ0FBQztFQUNuQyxTQUFTLEtBQUs7R0FDWixRQUFRO0VBQ1Y7RUFDQSxNQUFNLFVBQVUsS0FBSztFQUNyQixJQUFJLFdBQVcsT0FBTyxZQUFZLFlBQVksUUFBUSxNQUFNO0dBQzFELE1BQU0sWUFBWSxLQUFLLG1CQUFtQixLQUFLLG1CQUFtQixLQUFLO0dBQ3ZFLE9BQU8sc0JBQXNCLENBQUMsS0FBSyxRQUFRLE1BQU0sTUFBTSxXQUFXLE9BQU87RUFDM0U7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLGVBQWUsU0FBUyxPQUFPLFdBQVc7RUFDakQsUUFBUSxTQUFTLFNBQVM7RUFDMUIsSUFBSSxDQUFDLE9BQ0g7RUFFRixNQUFNLFNBQVMsV0FBVyxNQUFNLFVBQVU7RUFDMUMsTUFBTSxRQUFRLE9BQU8sc0JBQXNCLE1BQU0sS0FBSyxDQUFDLFlBQVksV0FBVztFQUM5RSxJQUFJLE9BQU87R0FDVCxNQUFNLFNBQVMsQ0FBQztHQUNoQixJQUFJLE1BQU0sV0FBVyxHQUFHO0lBQ3RCLE1BQU0sTUFBTSxXQUFXLE1BQU0sSUFBSSxRQUFRLEtBQUs7SUFDOUMsT0FBTyxPQUFPLEtBQUssR0FBRztHQUN4QixPQUFPO0lBQ0wsTUFBTSxZQUFZLE1BQU0sTUFBTTtJQUM5QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7S0FDekMsSUFBSSxTQUFTLE1BQU0sa0NBQWtDLE1BQ25EO0tBRUYsTUFBTSxNQUFNLFdBQVcsVUFBVSxJQUFJLFFBQVEsS0FBSztLQUNsRCxPQUFPLE9BQU8sS0FBSyxHQUFHO0lBQ3hCO0dBQ0Y7R0FDQSxJQUFJLE9BQU8sV0FBVyxHQUNwQixNQUFNLE9BQU87UUFFYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7SUFDdEMsTUFBTSxNQUFNLE9BQU87SUFDbkIsSUFBSSw4QkFBOEI7S0FDaEMsTUFBTTtJQUNSLENBQUM7R0FDSDtFQUVKO0NBQ0Y7Q0FDQSxNQUFNLDBCQUEwQixTQUFTLE9BQU87RUFDOUMsT0FBTyxlQUFlLE1BQU0sT0FBTyxLQUFLO0NBQzFDO0NBQ0EsTUFBTSxpQ0FBaUMsU0FBUyxPQUFPO0VBQ3JELE9BQU8sZUFBZSxNQUFNLE9BQU8sSUFBSTtDQUN6QztDQUNBLFNBQVMsd0JBQXdCLEtBQUssZUFBZTtFQUNuRCxJQUFJLENBQUMsS0FDSCxPQUFPO0VBRVQsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSSxpQkFBaUIsY0FBYyxTQUFTLEtBQUssR0FDL0Msb0JBQW9CLGNBQWM7RUFFcEMsTUFBTSxrQkFBa0IsaUJBQWlCLGNBQWM7RUFDdkQsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxpQkFBaUIsY0FBYyxXQUFXLEtBQUssR0FDakQsaUJBQWlCLGNBQWM7RUFFakMsSUFBSSxlQUFlO0VBQ25CLElBQUksaUJBQWlCLGNBQWMsT0FBTyxLQUFLLEdBQzdDLGVBQWUsY0FBYztFQUUvQixJQUFJLFFBQVE7RUFDWixPQUFPLFNBQVMsQ0FBQyxNQUFNLGVBQWUsa0JBQWtCLEdBQ3RELFFBQVEscUJBQXFCLEtBQUs7RUFFcEMsSUFBSSxDQUFDLFNBQVMsSUFBSSxxQkFDaEIsUUFBUTtFQUVWLElBQUksQ0FBQyxPQUNILE9BQU87RUFFVCxJQUFJLE1BQU0sNkJBQ1IsT0FBTztFQUVULE1BQU0sb0JBQW9CLGlCQUFpQixjQUFjO0VBQ3pELE1BQU0sV0FBVyxDQUFDO0VBQ2xCLE1BQU0seUJBQXlCLE1BQU0sOEJBQThCLE1BQU07RUFDekUsTUFBTSw0QkFBNEIsTUFBTSxXQUFXLHFCQUFxQixLQUFLLE1BQU07RUFDbkYsTUFBTSxrQkFBa0IsTUFBTSxXQUFXLHdCQUF3QixLQUFLLE1BQU07RUFDNUUsTUFBTSwyQkFBMkIsTUFBTSxXQUFXLG1DQUFtQyxLQUFLLE1BQU07RUFDaEcsSUFBSTtFQUNKLElBQUksaUJBQWlCLGNBQWMsU0FDakMsNkJBQTZCLE1BQU0sV0FBVyxjQUFjLE9BQU8sS0FBSyxNQUFNLGNBQWM7RUFFOUYsU0FBUywwQkFBMEIsU0FBUyxTQUFTO0dBQ25ELElBQUksQ0FBQyxTQUNILE9BQU87R0FFVCxJQUFJLE9BQU8sWUFBWSxXQUNyQixPQUFPO0lBQUUsU0FBUztJQUFTLFNBQVM7R0FBSztHQUUzQyxJQUFJLENBQUMsU0FDSCxPQUFPLEVBQUUsU0FBUyxLQUFLO0dBRXpCLElBQUksT0FBTyxZQUFZLFlBQVksUUFBUSxZQUFZLE9BQ3JELE9BQU8sY0FBYyxlQUFlLENBQUMsR0FBRyxPQUFPLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztHQUVyRSxPQUFPO0VBQ1Q7RUFDQSxNQUFNLHVCQUF1QixTQUFTLE1BQU07R0FDMUMsSUFBSSxTQUFTLFlBQ1g7R0FFRixPQUFPLHVCQUF1QixLQUFLLFNBQVMsUUFBUSxTQUFTLFdBQVcsU0FBUyxVQUFVLGlDQUFpQyx5QkFBeUIsU0FBUyxPQUFPO0VBQ3ZLO0VBQ0EsTUFBTSxxQkFBcUIsU0FBUyxNQUFNO0dBQ3hDLElBQUksQ0FBQyxLQUFLLFdBQVc7SUFDbkIsTUFBTSxtQkFBbUIsc0JBQXNCLEtBQUs7SUFDcEQsSUFBSTtJQUNKLElBQUksa0JBQ0Ysa0JBQWtCLGlCQUFpQixLQUFLLFVBQVUsV0FBVztJQUUvRCxNQUFNLGdCQUFnQixtQkFBbUIsS0FBSyxPQUFPO0lBQ3JELElBQUk7VUFDRyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUV4QyxJQURxQixjQUFjLE9BQ2QsTUFBTTtNQUN6QixjQUFjLE9BQU8sR0FBRyxDQUFDO01BQ3pCLEtBQUssWUFBWTtNQUNqQixJQUFJLEtBQUsscUJBQXFCO09BQzVCLEtBQUssb0JBQW9CO09BQ3pCLEtBQUssc0JBQXNCO01BQzdCO01BQ0EsSUFBSSxjQUFjLFdBQVcsR0FBRztPQUM5QixLQUFLLGFBQWE7T0FDbEIsS0FBSyxPQUFPLG1CQUFtQjtNQUNqQztNQUNBO0tBQ0Y7O0dBR047R0FDQSxJQUFJLENBQUMsS0FBSyxZQUNSO0dBRUYsT0FBTywwQkFBMEIsS0FBSyxLQUFLLFFBQVEsS0FBSyxXQUFXLEtBQUssVUFBVSxpQ0FBaUMseUJBQXlCLEtBQUssT0FBTztFQUMxSjtFQUNBLE1BQU0sMEJBQTBCLFNBQVMsTUFBTTtHQUM3QyxPQUFPLHVCQUF1QixLQUFLLFNBQVMsUUFBUSxTQUFTLFdBQVcsS0FBSyxRQUFRLFNBQVMsT0FBTztFQUN2RztFQUNBLE1BQU0sd0JBQXdCLFNBQVMsTUFBTTtHQUMzQyxPQUFPLDJCQUEyQixLQUFLLFNBQVMsUUFBUSxTQUFTLFdBQVcsS0FBSyxRQUFRLFNBQVMsT0FBTztFQUMzRztFQUNBLE1BQU0sd0JBQXdCLFNBQVMsTUFBTTtHQUMzQyxPQUFPLDBCQUEwQixLQUFLLEtBQUssUUFBUSxLQUFLLFdBQVcsS0FBSyxRQUFRLEtBQUssT0FBTztFQUM5RjtFQUNBLE1BQU0saUJBQWlCLG9CQUFvQix1QkFBdUI7RUFDbEUsTUFBTSxlQUFlLG9CQUFvQixxQkFBcUI7RUFDOUQsTUFBTSxnQ0FBZ0MsU0FBUyxNQUFNLFVBQVU7R0FDN0QsTUFBTSxpQkFBaUIsT0FBTztHQUM5QixPQUFPLG1CQUFtQixjQUFjLEtBQUssYUFBYSxZQUFZLG1CQUFtQixZQUFZLEtBQUsscUJBQXFCO0VBQ2pJO0VBQ0EsTUFBTSxXQUFXLGlCQUFpQixPQUFPLEtBQUssSUFBSSxjQUFjLFNBQVM7RUFDekUsTUFBTSxrQkFBa0IsS0FBSyxXQUFXLGtCQUFrQjtFQUMxRCxNQUFNLGdCQUFnQixTQUFTLFdBQVcsZ0JBQWdCO0VBQzFELFNBQVMseUJBQXlCLFNBQVM7R0FDekMsSUFBSSxPQUFPLFlBQVksWUFBWSxZQUFZLE1BQU07SUFDbkQsTUFBTSxhQUFhLGVBQWUsQ0FBQyxHQUFHLE9BQU87SUFDN0MsSUFBSSxRQUFRLFFBQ1YsV0FBVyxTQUFTLFFBQVE7SUFFOUIsT0FBTztHQUNUO0dBQ0EsT0FBTztFQUNUO0VBQ0EsTUFBTSxrQkFBa0IsU0FBUyxnQkFBZ0IsV0FBVyxrQkFBa0IsZ0JBQWdCLGdCQUFnQixPQUFPLFVBQVUsT0FBTztHQUNwSSxPQUFPLFdBQVc7SUFDaEIsTUFBTSxTQUFTLFFBQVE7SUFDdkIsSUFBSSxZQUFZLFVBQVU7SUFDMUIsSUFBSSxpQkFBaUIsY0FBYyxtQkFDakMsWUFBWSxjQUFjLGtCQUFrQixTQUFTO0lBRXZELElBQUksV0FBVyxVQUFVO0lBQ3pCLElBQUksQ0FBQyxVQUNILE9BQU8sZUFBZSxNQUFNLE1BQU0sU0FBUztJQUU3QyxJQUFJLFVBQVUsY0FBYyxxQkFDMUIsT0FBTyxlQUFlLE1BQU0sTUFBTSxTQUFTO0lBRTdDLElBQUksd0JBQXdCO0lBQzVCLElBQUksT0FBTyxhQUFhLFlBQVk7S0FDbEMsSUFBSSxDQUFDLFNBQVMsYUFDWixPQUFPLGVBQWUsTUFBTSxNQUFNLFNBQVM7S0FFN0Msd0JBQXdCO0lBQzFCO0lBQ0EsSUFBSSxtQkFBbUIsQ0FBQyxnQkFBZ0IsZ0JBQWdCLFVBQVUsUUFBUSxTQUFTLEdBQ2pGO0lBRUYsTUFBTSxVQUFVLENBQUMsQ0FBQyxpQkFBaUIsY0FBYyxRQUFRLFNBQVMsTUFBTTtJQUN4RSxNQUFNLFVBQVUseUJBQXlCLDBCQUEwQixVQUFVLElBQUksT0FBTyxDQUFDO0lBQ3pGLE1BQU0sU0FBUyxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVE7SUFDbEQsSUFBSSxVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU8sU0FDbkM7SUFFRixJQUFJO1VBQ0csSUFBSSxJQUFJLEdBQUcsSUFBSSxnQkFBZ0IsUUFBUSxLQUMxQyxJQUFJLGNBQWMsZ0JBQWdCLElBQ2hDLElBQUksU0FDRixPQUFPLGVBQWUsS0FBSyxRQUFRLFdBQVcsVUFBVSxPQUFPO1VBRS9ELE9BQU8sZUFBZSxNQUFNLE1BQU0sU0FBUztJQUFBO0lBS25ELE1BQU0sVUFBVSxDQUFDLFVBQVUsUUFBUSxPQUFPLFlBQVksWUFBWSxPQUFPLFFBQVE7SUFDakYsTUFBTSxPQUFPLFdBQVcsT0FBTyxZQUFZLFdBQVcsUUFBUSxPQUFPO0lBQ3JFLE1BQU0sT0FBTyxLQUFLO0lBQ2xCLElBQUksbUJBQW1CLHNCQUFzQjtJQUM3QyxJQUFJLENBQUMsa0JBQWtCO0tBQ3JCLGtCQUFrQixXQUFXLGlCQUFpQjtLQUM5QyxtQkFBbUIsc0JBQXNCO0lBQzNDO0lBQ0EsTUFBTSxrQkFBa0IsaUJBQWlCLFVBQVUsV0FBVztJQUM5RCxJQUFJLGdCQUFnQixPQUFPO0lBQzNCLElBQUksYUFBYTtJQUNqQixJQUFJLGVBQWU7S0FDakIsYUFBYTtLQUNiLElBQUk7V0FDRyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUN4QyxJQUFJLFFBQVEsY0FBYyxJQUFJLFFBQVEsR0FDcEM7S0FBQTtJQUlSLE9BQ0UsZ0JBQWdCLE9BQU8sbUJBQW1CLENBQUM7SUFFN0MsSUFBSTtJQUNKLE1BQU0sa0JBQWtCLE9BQU8sWUFBWTtJQUMzQyxNQUFNLGVBQWUsY0FBYztJQUNuQyxJQUFJLGNBQ0YsU0FBUyxhQUFhO0lBRXhCLElBQUksQ0FBQyxRQUNILFNBQVMsa0JBQWtCLGFBQWEsb0JBQW9CLGtCQUFrQixTQUFTLElBQUk7SUFFN0YsU0FBUyxVQUFVO0lBQ25CLElBQUksTUFDRixTQUFTLFFBQVEsT0FBTztJQUUxQixTQUFTLFNBQVM7SUFDbEIsU0FBUyxVQUFVO0lBQ25CLFNBQVMsWUFBWTtJQUNyQixTQUFTLGFBQWE7SUFDdEIsTUFBTSxPQUFPLG9CQUFvQixpQ0FBaUMsS0FBSztJQUN2RSxJQUFJLE1BQ0YsS0FBSyxXQUFXO0lBRWxCLElBQUksUUFDRixTQUFTLFFBQVEsU0FBUyxLQUFLO0lBRWpDLE1BQU0sT0FBTyxLQUFLLGtCQUFrQixRQUFRLFVBQVUsTUFBTSxrQkFBa0IsY0FBYztJQUM1RixJQUFJLFFBQVE7S0FDVixTQUFTLFFBQVEsU0FBUztLQUMxQixNQUFNLGdCQUFnQixLQUFLLEtBQUssV0FBVyxJQUFJO0tBQy9DLGVBQWUsS0FBSyxRQUFRLFNBQVMsU0FBUyxFQUFFLE1BQU0sS0FBSyxDQUFDO0tBQzVELEtBQUssNEJBQTRCLE9BQU8sb0JBQW9CLFNBQVMsT0FBTztJQUM5RTtJQUNBLFNBQVMsU0FBUztJQUNsQixJQUFJLE1BQ0YsS0FBSyxXQUFXO0lBRWxCLElBQUksTUFDRixTQUFTLFFBQVEsT0FBTztJQUUxQixJQUFJLE9BQU8sS0FBSyxZQUFZLFdBQzFCLEtBQUssVUFBVTtJQUVqQixLQUFLLFNBQVM7SUFDZCxLQUFLLFVBQVU7SUFDZixLQUFLLFlBQVk7SUFDakIsSUFBSSx1QkFDRixLQUFLLG1CQUFtQjtJQUUxQixJQUFJLENBQUMsU0FDSCxjQUFjLEtBQUssSUFBSTtTQUV2QixjQUFjLFFBQVEsSUFBSTtJQUU1QixJQUFJLGVBQ0YsT0FBTztHQUVYO0VBQ0Y7RUFDQSxNQUFNLHNCQUFzQixnQkFBZ0Isd0JBQXdCLDJCQUEyQixnQkFBZ0IsY0FBYyxZQUFZO0VBQ3pJLElBQUksNEJBQ0YsTUFBTSwwQkFBMEIsZ0JBQWdCLDRCQUE0QiwrQkFBK0IsdUJBQXVCLGNBQWMsY0FBYyxJQUFJO0VBRXBLLE1BQU0seUJBQXlCLFdBQVc7R0FDeEMsTUFBTSxTQUFTLFFBQVE7R0FDdkIsSUFBSSxZQUFZLFVBQVU7R0FDMUIsSUFBSSxpQkFBaUIsY0FBYyxtQkFDakMsWUFBWSxjQUFjLGtCQUFrQixTQUFTO0dBRXZELE1BQU0sVUFBVSxVQUFVO0dBQzFCLE1BQU0sVUFBVSxDQUFDLFVBQVUsUUFBUSxPQUFPLFlBQVksWUFBWSxPQUFPLFFBQVE7R0FDakYsTUFBTSxXQUFXLFVBQVU7R0FDM0IsSUFBSSxDQUFDLFVBQ0gsT0FBTywwQkFBMEIsTUFBTSxNQUFNLFNBQVM7R0FFeEQsSUFBSSxtQkFBbUIsQ0FBQyxnQkFBZ0IsMkJBQTJCLFVBQVUsUUFBUSxTQUFTLEdBQzVGO0dBRUYsTUFBTSxtQkFBbUIsc0JBQXNCO0dBQy9DLElBQUk7R0FDSixJQUFJLGtCQUNGLGtCQUFrQixpQkFBaUIsVUFBVSxXQUFXO0dBRTFELE1BQU0sZ0JBQWdCLG1CQUFtQixPQUFPO0dBQ2hELElBQUksZUFDRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUs7SUFDN0MsTUFBTSxlQUFlLGNBQWM7SUFDbkMsSUFBSSxRQUFRLGNBQWMsUUFBUSxHQUFHO0tBQ25DLGNBQWMsT0FBTyxHQUFHLENBQUM7S0FDekIsYUFBYSxZQUFZO0tBQ3pCLElBQUksY0FBYyxXQUFXLEdBQUc7TUFDOUIsYUFBYSxhQUFhO01BQzFCLE9BQU8sbUJBQW1CO01BQzFCLElBQUksQ0FBQyxXQUFXLE9BQU8sY0FBYyxVQUFVO09BQzdDLE1BQU0sbUJBQW1CLHFCQUFxQixnQkFBZ0I7T0FDOUQsT0FBTyxvQkFBb0I7TUFDN0I7S0FDRjtLQUNBLGFBQWEsS0FBSyxXQUFXLFlBQVk7S0FDekMsSUFBSSxjQUNGLE9BQU87S0FFVDtJQUNGO0dBQ0Y7R0FFRixPQUFPLDBCQUEwQixNQUFNLE1BQU0sU0FBUztFQUN4RDtFQUNBLE1BQU0sNEJBQTRCLFdBQVc7R0FDM0MsTUFBTSxTQUFTLFFBQVE7R0FDdkIsSUFBSSxZQUFZLFVBQVU7R0FDMUIsSUFBSSxpQkFBaUIsY0FBYyxtQkFDakMsWUFBWSxjQUFjLGtCQUFrQixTQUFTO0dBRXZELE1BQU0sWUFBWSxDQUFDO0dBQ25CLE1BQU0sUUFBUSxlQUFlLFFBQVEsb0JBQW9CLGtCQUFrQixTQUFTLElBQUksU0FBUztHQUNqRyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDckMsTUFBTSxPQUFPLE1BQU07SUFDbkIsSUFBSSxXQUFXLEtBQUssbUJBQW1CLEtBQUssbUJBQW1CLEtBQUs7SUFDcEUsVUFBVSxLQUFLLFFBQVE7R0FDekI7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxNQUFNLHVDQUF1QyxXQUFXO0dBQ3RELE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLElBQUksWUFBWSxVQUFVO0dBQzFCLElBQUksQ0FBQyxXQUFXO0lBQ2QsTUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNO0lBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztLQUNwQyxNQUFNLE9BQU8sS0FBSztLQUNsQixNQUFNLFFBQVEsdUJBQXVCLEtBQUssSUFBSTtLQUM5QyxJQUFJLFVBQVUsU0FBUyxNQUFNO0tBQzdCLElBQUksV0FBVyxZQUFZLGtCQUN6QixLQUFLLG9DQUFvQyxDQUFDLEtBQUssTUFBTSxPQUFPO0lBRWhFO0lBQ0EsS0FBSyxvQ0FBb0MsQ0FBQyxLQUFLLE1BQU0sZ0JBQWdCO0dBQ3ZFLE9BQU87SUFDTCxJQUFJLGlCQUFpQixjQUFjLG1CQUNqQyxZQUFZLGNBQWMsa0JBQWtCLFNBQVM7SUFFdkQsTUFBTSxtQkFBbUIsc0JBQXNCO0lBQy9DLElBQUksa0JBQWtCO0tBQ3BCLE1BQU0sa0JBQWtCLGlCQUFpQjtLQUN6QyxNQUFNLHlCQUF5QixpQkFBaUI7S0FDaEQsTUFBTSxRQUFRLE9BQU87S0FDckIsTUFBTSxlQUFlLE9BQU87S0FDNUIsSUFBSSxPQUFPO01BQ1QsTUFBTSxjQUFjLE1BQU0sTUFBTTtNQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEtBQUs7T0FDM0MsTUFBTSxPQUFPLFlBQVk7T0FDekIsSUFBSSxXQUFXLEtBQUssbUJBQW1CLEtBQUssbUJBQW1CLEtBQUs7T0FDcEUsS0FBSyxzQkFBc0IsQ0FBQyxLQUFLLE1BQU0sV0FBVyxVQUFVLEtBQUssT0FBTztNQUMxRTtLQUNGO0tBQ0EsSUFBSSxjQUFjO01BQ2hCLE1BQU0sY0FBYyxhQUFhLE1BQU07TUFDdkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLO09BQzNDLE1BQU0sT0FBTyxZQUFZO09BQ3pCLElBQUksV0FBVyxLQUFLLG1CQUFtQixLQUFLLG1CQUFtQixLQUFLO09BQ3BFLEtBQUssc0JBQXNCLENBQUMsS0FBSyxNQUFNLFdBQVcsVUFBVSxLQUFLLE9BQU87TUFDMUU7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLGNBQ0YsT0FBTztFQUVYO0VBQ0Esc0JBQXNCLE1BQU0scUJBQXFCLHNCQUFzQjtFQUN2RSxzQkFBc0IsTUFBTSx3QkFBd0IseUJBQXlCO0VBQzdFLElBQUksMEJBQ0Ysc0JBQXNCLE1BQU0sc0NBQXNDLHdCQUF3QjtFQUU1RixJQUFJLGlCQUNGLHNCQUFzQixNQUFNLDJCQUEyQixlQUFlO0VBRXhFLE9BQU87Q0FDVDtDQUNBLElBQUksVUFBVSxDQUFDO0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUMvQixRQUFRLEtBQUssd0JBQXdCLEtBQUssSUFBSSxZQUFZO0NBRTVELE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxRQUFRLFdBQVc7Q0FDekMsSUFBSSxDQUFDLFdBQVc7RUFDZCxNQUFNLGFBQWEsQ0FBQztFQUNwQixLQUFLLElBQUksUUFBUSxRQUFRO0dBQ3ZCLE1BQU0sUUFBUSx1QkFBdUIsS0FBSyxJQUFJO0dBQzlDLElBQUksVUFBVSxTQUFTLE1BQU07R0FDN0IsSUFBSSxZQUFZLENBQUMsYUFBYSxZQUFZLFlBQVk7SUFDcEQsTUFBTSxRQUFRLE9BQU87SUFDckIsSUFBSSxPQUNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDaEMsV0FBVyxLQUFLLE1BQU0sRUFBRTtHQUc5QjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxrQkFBa0Isc0JBQXNCO0NBQzVDLElBQUksQ0FBQyxpQkFBaUI7RUFDcEIsa0JBQWtCLFNBQVM7RUFDM0Isa0JBQWtCLHNCQUFzQjtDQUMxQztDQUNBLE1BQU0sb0JBQW9CLE9BQU8sZ0JBQWdCO0NBQ2pELE1BQU0sbUJBQW1CLE9BQU8sZ0JBQWdCO0NBQ2hELElBQUksQ0FBQyxtQkFDSCxPQUFPLG1CQUFtQixpQkFBaUIsTUFBTSxJQUFJLENBQUM7TUFFdEQsT0FBTyxtQkFBbUIsa0JBQWtCLE9BQU8sZ0JBQWdCLElBQUksa0JBQWtCLE1BQU07QUFFbkc7QUFDQSxTQUFTLG9CQUFvQixTQUFTLEtBQUs7Q0FDekMsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsSUFBSSxTQUFTLE1BQU0sV0FDakIsSUFBSSxZQUFZLE1BQU0sV0FBVyw2QkFBNkIsYUFBYSxTQUFTLE9BQU8sTUFBTTtFQUMvRixNQUFNLGdDQUFnQztFQUN0QyxZQUFZLFNBQVMsTUFBTSxPQUFPLElBQUk7Q0FDeEMsQ0FBQztBQUVMO0FBR0EsU0FBUyxvQkFBb0IsU0FBUyxLQUFLO0NBQ3pDLElBQUksWUFBWSxTQUFTLG1CQUFtQixhQUFhO0VBQ3ZELE9BQU8sU0FBUyxPQUFPLE1BQU07R0FDM0IsS0FBSyxRQUFRLGtCQUFrQixrQkFBa0IsS0FBSyxFQUFFO0VBQzFEO0NBQ0YsQ0FBQztBQUNIO0FBR0EsSUFBSSxhQUFhLFdBQVcsVUFBVTtBQUN0QyxTQUFTLFdBQVcsU0FBUyxTQUFTLFlBQVksWUFBWTtDQUM1RCxJQUFJLFlBQVk7Q0FDaEIsSUFBSSxjQUFjO0NBQ2xCLFdBQVc7Q0FDWCxjQUFjO0NBQ2QsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixTQUFTLGFBQWEsTUFBTTtFQUMxQixNQUFNLE9BQU8sS0FBSztFQUNsQixLQUFLLEtBQUssS0FBSyxXQUFXO0dBQ3hCLE9BQU8sS0FBSyxPQUFPLE1BQU0sTUFBTSxTQUFTO0VBQzFDO0VBQ0EsTUFBTSxhQUFhLFVBQVUsTUFBTSxTQUFTLEtBQUssSUFBSTtFQUNyRCxJQUFJLFNBQVMsVUFBVSxHQUNyQixLQUFLLFdBQVc7T0FDWDtHQUNMLEtBQUssU0FBUztHQUNkLEtBQUssZ0JBQWdCLFdBQVcsV0FBVyxPQUFPO0VBQ3BEO0VBQ0EsT0FBTztDQUNUO0NBQ0EsU0FBUyxVQUFVLE1BQU07RUFDdkIsTUFBTSxFQUFFLFFBQVEsYUFBYSxLQUFLO0VBQ2xDLE9BQU8sWUFBWSxLQUFLLFNBQVMsVUFBVSxPQUFPLFNBQVMsUUFBUTtDQUNyRTtDQUNBLFlBQVksWUFBWSxTQUFTLFVBQVUsYUFBYSxTQUFTLE9BQU8sTUFBTTtFQUM1RSxJQUFJO0VBQ0osSUFBSSxXQUFXLEtBQUssRUFBRSxHQUFHO0dBQ3ZCLE1BQU0sVUFBVTtJQUNkLGVBQWU7SUFDZixZQUFZLGVBQWU7SUFDM0IsT0FBTyxlQUFlLGFBQWEsZUFBZSxhQUFhLEtBQUssTUFBTSxJQUFJLEtBQUs7SUFDbkY7R0FDRjtHQUNBLE1BQU0sV0FBVyxLQUFLO0dBQ3RCLEtBQUssS0FBSyxTQUFTLFFBQVE7SUFDekIsSUFBSTtLQUNGLE9BQU8sU0FBUyxNQUFNLE1BQU0sU0FBUztJQUN2QyxVQUFVO0tBQ1IsTUFBTSxFQUFFLFFBQVEsU0FBUyxVQUFVLFdBQVcsWUFBWSxhQUFhLGVBQWUsbUJBQW1CO0tBQ3pHLElBQUksQ0FBQyxlQUFlLENBQUM7VUFDZixXQUNGLE9BQU8sZ0JBQWdCO1dBQ2xCLElBQUksU0FDVCxRQUFRLGNBQWM7S0FBQTtJQUc1QjtHQUNGO0dBQ0EsTUFBTSxPQUFPLGlDQUFpQyxTQUFTLEtBQUssSUFBSSxTQUFTLGNBQWMsU0FBUztHQUNoRyxJQUFJLENBQUMsTUFDSCxPQUFPO0dBRVQsTUFBTSxFQUFFLFVBQVUsUUFBUSxlQUFlLGVBQWUsS0FBSztHQUM3RCxJQUFJLFVBQ0YsZ0JBQWdCLFlBQVk7UUFDdkIsSUFBSSxRQUFRO0lBQ2pCLE9BQU8sY0FBYztJQUNyQixJQUFJLGlCQUFpQixDQUFDLFlBQVk7S0FDaEMsTUFBTSxrQkFBa0IsT0FBTztLQUMvQixPQUFPLFVBQVUsV0FBVztNQUMxQixNQUFNLEVBQUUsTUFBTSxVQUFVO01BQ3hCLElBQUksVUFBVSxnQkFBZ0I7T0FDNUIsS0FBSyxTQUFTO09BQ2QsS0FBSyxpQkFBaUIsTUFBTSxDQUFDO01BQy9CLE9BQU8sSUFBSSxVQUFVLFdBQ25CLEtBQUssU0FBUztNQUVoQixPQUFPLGdCQUFnQixLQUFLLElBQUk7S0FDbEM7SUFDRjtHQUNGO0dBQ0EsUUFBUSxLQUFLLFVBQVUsT0FBTyxTQUFTLGFBQWEsT0FBTyxLQUFLO0VBQ2xFLE9BQ0UsT0FBTyxTQUFTLE1BQU0sU0FBUyxJQUFJO0NBRXZDLENBQUM7Q0FDRCxjQUFjLFlBQVksU0FBUyxhQUFhLGFBQWEsU0FBUyxPQUFPLE1BQU07RUFDakYsTUFBTSxLQUFLLEtBQUs7RUFDaEIsSUFBSTtFQUNKLElBQUksU0FBUyxFQUFFLEdBQUc7R0FDaEIsT0FBTyxnQkFBZ0I7R0FDdkIsT0FBTyxnQkFBZ0I7RUFDekIsT0FBTztHQUNMLE9BQU8sTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHO0dBQ2hDLElBQUksTUFDRixHQUFHLGNBQWM7UUFFakIsT0FBTztFQUVYO0VBQ0EsSUFBSSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7T0FDM0IsS0FBSyxVQUNQLEtBQUssS0FBSyxXQUFXLElBQUk7RUFBQSxPQUczQixTQUFTLE1BQU0sU0FBUyxJQUFJO0NBRWhDLENBQUM7QUFDSDtBQUdBLFNBQVMsb0JBQW9CLFVBQVUsS0FBSztDQUMxQyxNQUFNLEVBQUUsV0FBVyxZQUFZLE9BQU8sV0FBVyxJQUFJLGlCQUFpQjtDQUN0RSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTLHFCQUFxQixFQUFFLG9CQUFvQixXQUNqRjtDQVlGLElBQUksZUFBZSxLQUFLLFNBQVMsZ0JBQWdCLGtCQUFrQixVQUFVO0VBVDNFO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FFbUYsQ0FBQztBQUN4RjtBQUdBLFNBQVMsaUJBQWlCLFVBQVUsS0FBSztDQUN2QyxJQUFJLEtBQUssSUFBSSxPQUFPLGtCQUFrQixJQUNwQztDQUVGLE1BQU0sRUFBRSxZQUFZLHNCQUFzQix1QkFBdUIsVUFBVSxXQUFXLFdBQVcsWUFBWSxvQkFBb0Isd0JBQXdCLElBQUksaUJBQWlCO0NBQzlLLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztFQUMxQyxNQUFNLFlBQVksV0FBVztFQUM3QixNQUFNLGlCQUFpQixZQUFZO0VBQ25DLE1BQU0sZ0JBQWdCLFlBQVk7RUFDbEMsTUFBTSxTQUFTLHNCQUFzQjtFQUNyQyxNQUFNLGdCQUFnQixzQkFBc0I7RUFDNUMsc0JBQXNCLGFBQWEsQ0FBQztFQUNwQyxzQkFBc0IsVUFBVSxDQUFDLGNBQWM7RUFDL0Msc0JBQXNCLFVBQVUsQ0FBQyxhQUFhO0NBQ2hEO0NBQ0EsTUFBTSxlQUFlLFNBQVM7Q0FDOUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsV0FDakM7Q0FFRixJQUFJLGlCQUFpQixVQUFVLEtBQUssQ0FBQyxnQkFBZ0IsYUFBYSxTQUFTLENBQUM7Q0FDNUUsT0FBTztBQUNUO0FBQ0EsU0FBUyxXQUFXLFNBQVMsS0FBSztDQUNoQyxJQUFJLG9CQUFvQixTQUFTLEdBQUc7QUFDdEM7QUFHQSxTQUFTLGlCQUFpQixRQUFRLGNBQWMsa0JBQWtCO0NBQ2hFLElBQUksQ0FBQyxvQkFBb0IsaUJBQWlCLFdBQVcsR0FDbkQsT0FBTztDQUVULE1BQU0sTUFBTSxpQkFBaUIsUUFBUSxPQUFPLEdBQUcsV0FBVyxNQUFNO0NBQ2hFLElBQUksSUFBSSxXQUFXLEdBQ2pCLE9BQU87Q0FFVCxNQUFNLHlCQUF5QixJQUFJLEVBQUUsQ0FBQztDQUN0QyxPQUFPLGFBQWEsUUFBUSxPQUFPLHVCQUF1QixRQUFRLEVBQUUsTUFBTSxFQUFFO0FBQzlFO0FBQ0EsU0FBUyx3QkFBd0IsUUFBUSxjQUFjLGtCQUFrQixXQUFXO0NBQ2xGLElBQUksQ0FBQyxRQUNIO0NBR0Ysa0JBQWtCLFFBRFMsaUJBQWlCLFFBQVEsY0FBYyxnQkFDdkIsR0FBRyxTQUFTO0FBQ3pEO0FBQ0EsU0FBUyxnQkFBZ0IsUUFBUTtDQUMvQixPQUFPLE9BQU8sb0JBQW9CLE1BQU0sQ0FBQyxDQUFDLFFBQVEsU0FBUyxLQUFLLFdBQVcsSUFBSSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsS0FBSyxVQUFVLENBQUMsQ0FBQztBQUN0STtBQUNBLFNBQVMsd0JBQXdCLEtBQUssVUFBVTtDQUM5QyxJQUFJLFVBQVUsQ0FBQyxPQUNiO0NBRUYsSUFBSSxLQUFLLElBQUksT0FBTyxhQUFhLElBQy9CO0NBRUYsTUFBTSxtQkFBbUIsU0FBUztDQUNsQyxJQUFJLGVBQWUsQ0FBQztDQUNwQixJQUFJLFdBQVc7RUFDYixNQUFNLGtCQUFrQjtFQUN4QixlQUFlLGFBQWEsT0FBTztHQUNqQztHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQztFQUNELHdCQUF3QixpQkFBaUIsZ0JBQWdCLGVBQWUsR0FBRyxrQkFBa0IscUJBQXFCLGVBQWUsQ0FBQztDQUNwSTtDQUNBLGVBQWUsYUFBYSxPQUFPO0VBQ2pDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7Q0FDRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUs7RUFDNUMsTUFBTSxTQUFTLFNBQVMsYUFBYTtFQUNyQyxVQUFXLFFBQWdCLE9BQU8sYUFBYyx3QkFBd0IsT0FBTyxXQUFXLGdCQUFnQixPQUFPLFNBQVMsR0FBRyxnQkFBZ0I7Q0FDL0k7QUFDRjtBQUdBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE1BQU0sYUFBYSxXQUFXLFlBQVk7RUFDeEMsTUFBTSxNQUFNO0VBQ1osTUFBTSxRQUFRO0VBQ2QsV0FBVyxTQUFTLEtBQUssT0FBTyxTQUFTO0VBQ3pDLFdBQVcsU0FBUyxLQUFLLE9BQU8sVUFBVTtFQUMxQyxXQUFXLFNBQVMsS0FBSyxPQUFPLFdBQVc7Q0FDN0MsQ0FBQztDQUNELE1BQU0sYUFBYSwwQkFBMEIsWUFBWTtFQUN2RCxXQUFXLFNBQVMsV0FBVyxVQUFVLGdCQUFnQjtFQUN6RCxXQUFXLFNBQVMsY0FBYyxhQUFhLGdCQUFnQjtFQUMvRCxXQUFXLFNBQVMsaUJBQWlCLGdCQUFnQixnQkFBZ0I7Q0FDdkUsQ0FBQztDQUNELE1BQU0sYUFBYSxhQUFhLFNBQVMsVUFBVTtFQUNqRCxNQUFNLGtCQUFrQjtHQUFDO0dBQVM7R0FBVTtFQUFTO0VBQ3JELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxnQkFBZ0IsUUFBUSxLQUFLO0dBQy9DLE1BQU0sT0FBTyxnQkFBZ0I7R0FDN0IsWUFBWSxTQUFTLE9BQU8sVUFBVSxRQUFRLFVBQVU7SUFDdEQsT0FBTyxTQUFTLEdBQUcsTUFBTTtLQUN2QixPQUFPLE1BQU0sUUFBUSxJQUFJLFVBQVUsU0FBUyxNQUFNLEtBQUs7SUFDekQ7R0FDRixDQUFDO0VBQ0g7Q0FDRixDQUFDO0NBQ0QsTUFBTSxhQUFhLGdCQUFnQixTQUFTLE9BQU8sUUFBUTtFQUN6RCxXQUFXLFNBQVMsR0FBRztFQUN2QixpQkFBaUIsU0FBUyxHQUFHO0VBQzdCLE1BQU0sNEJBQTRCLFFBQVE7RUFDMUMsSUFBSSw2QkFBNkIsMEJBQTBCLFdBQ3pELElBQUksaUJBQWlCLFNBQVMsS0FBSyxDQUFDLDBCQUEwQixTQUFTLENBQUM7Q0FFNUUsQ0FBQztDQUNELE1BQU0sYUFBYSxxQkFBcUIsU0FBUyxPQUFPLFFBQVE7RUFDOUQsV0FBVyxrQkFBa0I7RUFDN0IsV0FBVyx3QkFBd0I7Q0FDckMsQ0FBQztDQUNELE1BQU0sYUFBYSx5QkFBeUIsU0FBUyxPQUFPLFFBQVE7RUFDbEUsV0FBVyxzQkFBc0I7Q0FDbkMsQ0FBQztDQUNELE1BQU0sYUFBYSxlQUFlLFNBQVMsT0FBTyxRQUFRO0VBQ3hELFdBQVcsWUFBWTtDQUN6QixDQUFDO0NBQ0QsTUFBTSxhQUFhLGdCQUFnQixTQUFTLE9BQU8sUUFBUTtFQUN6RCx3QkFBd0IsS0FBSyxPQUFPO0NBQ3RDLENBQUM7Q0FDRCxNQUFNLGFBQWEsbUJBQW1CLFNBQVMsT0FBTyxRQUFRO0VBQzVELG9CQUFvQixTQUFTLEdBQUc7Q0FDbEMsQ0FBQztDQUNELE1BQU0sYUFBYSxRQUFRLFNBQVMsVUFBVTtFQUM1QyxTQUFTLE9BQU87RUFDaEIsTUFBTSxXQUFXLFdBQVcsU0FBUztFQUNyQyxNQUFNLFdBQVcsV0FBVyxTQUFTO0VBQ3JDLE1BQU0sZUFBZSxXQUFXLGFBQWE7RUFDN0MsTUFBTSxnQkFBZ0IsV0FBVyxjQUFjO0VBQy9DLE1BQU0sVUFBVSxXQUFXLFFBQVE7RUFDbkMsTUFBTSw2QkFBNkIsV0FBVyx5QkFBeUI7RUFDdkUsU0FBUyxTQUFTLFNBQVM7R0FDekIsTUFBTSxpQkFBaUIsUUFBUTtHQUMvQixJQUFJLENBQUMsZ0JBQ0g7R0FFRixNQUFNLDBCQUEwQixlQUFlO0dBQy9DLFNBQVMsZ0JBQWdCLFFBQVE7SUFDL0IsT0FBTyxPQUFPO0dBQ2hCO0dBQ0EsSUFBSSxpQkFBaUIsd0JBQXdCO0dBQzdDLElBQUksb0JBQW9CLHdCQUF3QjtHQUNoRCxJQUFJLENBQUMsZ0JBQWdCO0lBQ25CLE1BQU0sNEJBQTRCLFFBQVE7SUFDMUMsSUFBSSwyQkFBMkI7S0FDN0IsTUFBTSxxQ0FBcUMsMEJBQTBCO0tBQ3JFLGlCQUFpQixtQ0FBbUM7S0FDcEQsb0JBQW9CLG1DQUFtQztJQUN6RDtHQUNGO0dBQ0EsTUFBTSxxQkFBcUI7R0FDM0IsTUFBTSxZQUFZO0dBQ2xCLFNBQVMsYUFBYSxNQUFNO0lBQzFCLE1BQU0sT0FBTyxLQUFLO0lBQ2xCLE1BQU0sU0FBUyxLQUFLO0lBQ3BCLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU8sOEJBQThCO0lBQ3JDLE1BQU0sV0FBVyxPQUFPO0lBQ3hCLElBQUksQ0FBQyxnQkFBZ0I7S0FDbkIsaUJBQWlCLE9BQU87S0FDeEIsb0JBQW9CLE9BQU87SUFDN0I7SUFDQSxJQUFJLFVBQ0Ysa0JBQWtCLEtBQUssUUFBUSxvQkFBb0IsUUFBUTtJQUU3RCxNQUFNLGNBQWMsT0FBTyxzQkFBc0I7S0FDL0MsSUFBSSxPQUFPLGVBQWUsT0FBTztVQUMzQixDQUFDLEtBQUssV0FBVyxPQUFPLGtCQUFrQixLQUFLLFVBQVUsV0FBVztPQUN0RSxNQUFNLFlBQVksT0FBTyxNQUFNLFdBQVcsV0FBVztPQUNyRCxJQUFJLE9BQU8sV0FBVyxLQUFLLGFBQWEsVUFBVSxTQUFTLEdBQUc7UUFDNUQsTUFBTSxZQUFZLEtBQUs7UUFDdkIsS0FBSyxTQUFTLFdBQVc7U0FDdkIsTUFBTSxhQUFhLE9BQU8sTUFBTSxXQUFXLFdBQVc7U0FDdEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxLQUNyQyxJQUFJLFdBQVcsT0FBTyxNQUNwQixXQUFXLE9BQU8sR0FBRyxDQUFDO1NBRzFCLElBQUksQ0FBQyxLQUFLLFdBQVcsS0FBSyxVQUFVLFdBQ2xDLFVBQVUsS0FBSyxJQUFJO1FBRXZCO1FBQ0EsVUFBVSxLQUFLLElBQUk7T0FDckIsT0FDRSxLQUFLLE9BQU87TUFFaEIsT0FBTyxJQUFJLENBQUMsS0FBSyxXQUFXLE9BQU8sbUJBQW1CLE9BQ3BELE9BQU8sOEJBQThCO0tBQUE7SUFHM0M7SUFDQSxlQUFlLEtBQUssUUFBUSxvQkFBb0IsV0FBVztJQUUzRCxJQUFJLENBRGUsT0FBTyxXQUV4QixPQUFPLFlBQVk7SUFFckIsV0FBVyxNQUFNLFFBQVEsS0FBSyxJQUFJO0lBQ2xDLE9BQU8saUJBQWlCO0lBQ3hCLE9BQU87R0FDVDtHQUNBLFNBQVMsc0JBQXNCLENBQy9CO0dBQ0EsU0FBUyxVQUFVLE1BQU07SUFDdkIsTUFBTSxPQUFPLEtBQUs7SUFDbEIsS0FBSyxVQUFVO0lBQ2YsT0FBTyxZQUFZLE1BQU0sS0FBSyxRQUFRLEtBQUssSUFBSTtHQUNqRDtHQUNBLE1BQU0sYUFBYSxZQUFZLHlCQUF5QixjQUFjLFNBQVMsT0FBTyxNQUFNO0lBQzFGLE1BQU0sWUFBWSxLQUFLLE1BQU07SUFDN0IsTUFBTSxXQUFXLEtBQUs7SUFDdEIsT0FBTyxXQUFXLE1BQU0sT0FBTyxJQUFJO0dBQ3JDLENBQUM7R0FDRCxNQUFNLHdCQUF3QjtHQUM5QixNQUFNLG9CQUFvQixXQUFXLG1CQUFtQjtHQUN4RCxNQUFNLHNCQUFzQixXQUFXLHFCQUFxQjtHQUM1RCxNQUFNLGFBQWEsWUFBWSx5QkFBeUIsY0FBYyxTQUFTLE9BQU8sTUFBTTtJQUMxRixJQUFJLE1BQU0sUUFBUSx5QkFBeUIsTUFDekMsT0FBTyxXQUFXLE1BQU0sT0FBTyxJQUFJO0lBRXJDLElBQUksTUFBTSxXQUNSLE9BQU8sV0FBVyxNQUFNLE9BQU8sSUFBSTtTQUM5QjtLQUNMLE1BQU0sVUFBVTtNQUNkLFFBQVE7TUFDUixLQUFLLE1BQU07TUFDWCxZQUFZO01BQ1o7TUFDQSxTQUFTO0tBQ1g7S0FDQSxNQUFNLE9BQU8saUNBQWlDLHVCQUF1QixxQkFBcUIsU0FBUyxjQUFjLFNBQVM7S0FDMUgsSUFBSSxTQUFTLE1BQU0sZ0NBQWdDLFFBQVEsQ0FBQyxRQUFRLFdBQVcsS0FBSyxVQUFVLFdBQzVGLEtBQUssT0FBTztJQUVoQjtHQUNGLENBQUM7R0FDRCxNQUFNLGNBQWMsWUFBWSx5QkFBeUIsZUFBZSxTQUFTLE9BQU8sTUFBTTtJQUM1RixNQUFNLE9BQU8sZ0JBQWdCLEtBQUs7SUFDbEMsSUFBSSxRQUFRLE9BQU8sS0FBSyxRQUFRLFVBQVU7S0FDeEMsSUFBSSxLQUFLLFlBQVksUUFBUSxLQUFLLFFBQVEsS0FBSyxLQUFLLFNBQ2xEO0tBRUYsS0FBSyxLQUFLLFdBQVcsSUFBSTtJQUMzQixPQUFPLElBQUksTUFBTSxRQUFRLHVCQUF1QixNQUM5QyxPQUFPLFlBQVksTUFBTSxPQUFPLElBQUk7R0FFeEMsQ0FBQztFQUNIO0NBQ0YsQ0FBQztDQUNELE1BQU0sYUFBYSxnQkFBZ0IsWUFBWTtFQUM3QyxJQUFJLFFBQVEsZ0JBQWdCLFFBQVEsWUFBWSxDQUFDLGFBQy9DLGVBQWUsUUFBUSxZQUFZLENBQUMsYUFBYSxDQUFDLHNCQUFzQixlQUFlLENBQUM7Q0FFNUYsQ0FBQztDQUNELE1BQU0sYUFBYSwwQkFBMEIsU0FBUyxVQUFVO0VBQzlELFNBQVMsNEJBQTRCLFNBQVM7R0FDNUMsT0FBTyxTQUFTLEdBQUc7SUFFakIsZUFEa0MsU0FBUyxPQUNsQyxDQUFDLENBQUMsU0FBUyxjQUFjO0tBQ2hDLE1BQU0sd0JBQXdCLFFBQVE7S0FDdEMsSUFBSSx1QkFBdUI7TUFDekIsTUFBTSxNQUFNLElBQUksc0JBQXNCLFNBQVM7T0FDN0MsU0FBUyxFQUFFO09BQ1gsUUFBUSxFQUFFO01BQ1osQ0FBQztNQUNELFVBQVUsT0FBTyxHQUFHO0tBQ3RCO0lBQ0YsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxJQUFJLFFBQVEsMEJBQTBCO0dBQ3BDLE1BQU0sV0FBVyxrQ0FBa0MsS0FBSyw0QkFBNEIsb0JBQW9CO0dBQ3hHLE1BQU0sV0FBVyx5QkFBeUIsS0FBSyw0QkFBNEIsa0JBQWtCO0VBQy9GO0NBQ0YsQ0FBQztDQUNELE1BQU0sYUFBYSxtQkFBbUIsU0FBUyxPQUFPLFFBQVE7RUFDNUQsb0JBQW9CLFNBQVMsR0FBRztDQUNsQyxDQUFDO0FBQ0g7QUFHQSxTQUFTLGFBQWEsT0FBTztDQUMzQixNQUFNLGFBQWEscUJBQXFCLFNBQVMsT0FBTyxRQUFRO0VBQzlELE1BQU0sa0NBQWtDLE9BQU87RUFDL0MsTUFBTSx3QkFBd0IsT0FBTztFQUNyQyxTQUFTLHVCQUF1QixLQUFLO0dBQ25DLElBQUksT0FBTyxJQUFJLGFBQWEsT0FBTyxVQUFVLFVBQVU7SUFDckQsTUFBTSxZQUFZLElBQUksZUFBZSxJQUFJLFlBQVk7SUFDckQsUUFBUSxZQUFZLFlBQVksTUFBTSxPQUFPLEtBQUssVUFBVSxHQUFHO0dBQ2pFO0dBQ0EsT0FBTyxNQUFNLElBQUksU0FBUyxJQUFJLE9BQU8sVUFBVSxTQUFTLEtBQUssR0FBRztFQUNsRTtFQUNBLE1BQU0sY0FBYyxJQUFJO0VBQ3hCLE1BQU0seUJBQXlCLENBQUM7RUFDaEMsTUFBTSw0Q0FBNEMsUUFBUSxZQUFZLDZDQUE2QyxPQUFPO0VBQzFILE1BQU0sZ0JBQWdCLFlBQVksU0FBUztFQUMzQyxNQUFNLGFBQWEsWUFBWSxNQUFNO0VBQ3JDLE1BQU0sZ0JBQWdCO0VBQ3RCLElBQUksb0JBQW9CLE1BQU07R0FDNUIsSUFBSSxJQUFJLGtCQUFrQixHQUFHO0lBQzNCLE1BQU0sWUFBWSxLQUFLLEVBQUU7SUFDekIsSUFBSSxXQUNGLFFBQVEsTUFBTSxnQ0FBZ0MscUJBQXFCLFFBQVEsVUFBVSxVQUFVLFdBQVcsV0FBVyxFQUFFLEtBQUssTUFBTSxXQUFXLEVBQUUsUUFBUSxFQUFFLEtBQUssUUFBUSxZQUFZLFdBQVcscUJBQXFCLFFBQVEsVUFBVSxRQUFRLEtBQUssQ0FBQztTQUVsUCxRQUFRLE1BQU0sQ0FBQztHQUVuQjtFQUNGO0VBQ0EsSUFBSSwyQkFBMkI7R0FDN0IsT0FBTyx1QkFBdUIsUUFBUTtJQUNwQyxNQUFNLHVCQUF1Qix1QkFBdUIsTUFBTTtJQUMxRCxJQUFJO0tBQ0YscUJBQXFCLEtBQUssaUJBQWlCO01BQ3pDLElBQUkscUJBQXFCLGVBQ3ZCLE1BQU0scUJBQXFCO01BRTdCLE1BQU07S0FDUixDQUFDO0lBQ0gsU0FBUyxPQUFPO0tBQ2QseUJBQXlCLEtBQUs7SUFDaEM7R0FDRjtFQUNGO0VBQ0EsTUFBTSw2Q0FBNkMsWUFBWSxrQ0FBa0M7RUFDakcsU0FBUyx5QkFBeUIsR0FBRztHQUNuQyxJQUFJLGlCQUFpQixDQUFDO0dBQ3RCLElBQUk7SUFDRixNQUFNLFVBQVUsTUFBTTtJQUN0QixJQUFJLE9BQU8sWUFBWSxZQUNyQixRQUFRLEtBQUssTUFBTSxDQUFDO0dBRXhCLFNBQVMsS0FBSyxDQUNkO0VBQ0Y7RUFDQSxTQUFTLFdBQVcsT0FBTztHQUN6QixPQUFPLFNBQVMsT0FBTyxNQUFNLFNBQVM7RUFDeEM7RUFDQSxTQUFTLGtCQUFrQixPQUFPO0dBQ2hDLE9BQU87RUFDVDtFQUNBLFNBQVMsaUJBQWlCLFdBQVc7R0FDbkMsT0FBTyxpQkFBaUIsT0FBTyxTQUFTO0VBQzFDO0VBQ0EsTUFBTSxjQUFjLFlBQVksT0FBTztFQUN2QyxNQUFNLGNBQWMsWUFBWSxPQUFPO0VBQ3ZDLE1BQU0sZ0JBQWdCLFlBQVksU0FBUztFQUMzQyxNQUFNLDJCQUEyQixZQUFZLG9CQUFvQjtFQUNqRSxNQUFNLDJCQUEyQixZQUFZLG9CQUFvQjtFQUNqRSxNQUFNLFNBQVM7RUFDZixNQUFNLGFBQWE7RUFDbkIsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sV0FBVztFQUNqQixNQUFNLG9CQUFvQjtFQUMxQixTQUFTLGFBQWEsU0FBUyxPQUFPO0dBQ3BDLFFBQVEsTUFBTTtJQUNaLElBQUk7S0FDRixlQUFlLFNBQVMsT0FBTyxDQUFDO0lBQ2xDLFNBQVMsS0FBSztLQUNaLGVBQWUsU0FBUyxPQUFPLEdBQUc7SUFDcEM7R0FDRjtFQUNGO0VBQ0EsTUFBTSxPQUFPLFdBQVc7R0FDdEIsSUFBSSxZQUFZO0dBQ2hCLE9BQU8sU0FBUyxRQUFRLGlCQUFpQjtJQUN2QyxPQUFPLFdBQVc7S0FDaEIsSUFBSSxXQUNGO0tBRUYsWUFBWTtLQUNaLGdCQUFnQixNQUFNLE1BQU0sU0FBUztJQUN2QztHQUNGO0VBQ0Y7RUFDQSxNQUFNLGFBQWE7RUFDbkIsTUFBTSw0QkFBNEIsWUFBWSxrQkFBa0I7RUFDaEUsU0FBUyxlQUFlLFNBQVMsT0FBTyxPQUFPO0dBQzdDLE1BQU0sY0FBYyxLQUFLO0dBQ3pCLElBQUksWUFBWSxPQUNkLE1BQU0sSUFBSSxVQUFVLFVBQVU7R0FFaEMsSUFBSSxRQUFRLGlCQUFpQixZQUFZO0lBQ3ZDLElBQUksT0FBTztJQUNYLElBQUk7S0FDRixJQUFJLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxZQUNoRCxPQUFPLFNBQVMsTUFBTTtJQUUxQixTQUFTLEtBQUs7S0FDWixrQkFBa0I7TUFDaEIsZUFBZSxTQUFTLE9BQU8sR0FBRztLQUNwQyxDQUFDLENBQUMsQ0FBQztLQUNILE9BQU87SUFDVDtJQUNBLElBQUksVUFBVSxZQUFZLGlCQUFpQixvQkFBb0IsTUFBTSxlQUFlLFdBQVcsS0FBSyxNQUFNLGVBQWUsV0FBVyxLQUFLLE1BQU0saUJBQWlCLFlBQVk7S0FDMUsscUJBQXFCLEtBQUs7S0FDMUIsZUFBZSxTQUFTLE1BQU0sY0FBYyxNQUFNLFlBQVk7SUFDaEUsT0FBTyxJQUFJLFVBQVUsWUFBWSxPQUFPLFNBQVMsWUFDL0MsSUFBSTtLQUNGLEtBQUssS0FBSyxPQUFPLFlBQVksYUFBYSxTQUFTLEtBQUssQ0FBQyxHQUFHLFlBQVksYUFBYSxTQUFTLEtBQUssQ0FBQyxDQUFDO0lBQ3ZHLFNBQVMsS0FBSztLQUNaLGtCQUFrQjtNQUNoQixlQUFlLFNBQVMsT0FBTyxHQUFHO0tBQ3BDLENBQUMsQ0FBQyxDQUFDO0lBQ0w7U0FDSztLQUNMLFFBQVEsZUFBZTtLQUN2QixNQUFNLFFBQVEsUUFBUTtLQUN0QixRQUFRLGVBQWU7S0FDdkIsSUFBSSxRQUFRLG1CQUFtQjtVQUN6QixVQUFVLFVBQVU7T0FDdEIsUUFBUSxlQUFlLFFBQVE7T0FDL0IsUUFBUSxlQUFlLFFBQVE7TUFDakM7O0tBRUYsSUFBSSxVQUFVLFlBQVksaUJBQWlCLE9BQU87TUFDaEQsTUFBTSxRQUFRLE1BQU0sZUFBZSxNQUFNLFlBQVksUUFBUSxNQUFNLFlBQVksS0FBSztNQUNwRixJQUFJLE9BQ0Ysc0JBQXNCLE9BQU8sMkJBQTJCO09BQ3RELGNBQWM7T0FDZCxZQUFZO09BQ1osVUFBVTtPQUNWLE9BQU87TUFDVCxDQUFDO0tBRUw7S0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxTQUN4Qix3QkFBd0IsU0FBUyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLElBQUk7S0FFakYsSUFBSSxNQUFNLFVBQVUsS0FBSyxTQUFTLFVBQVU7TUFDMUMsUUFBUSxlQUFlO01BQ3ZCLElBQUksdUJBQXVCO01BQzNCLElBQUk7T0FDRixNQUFNLElBQUksTUFBTSw0QkFBNEIsdUJBQXVCLEtBQUssS0FBSyxTQUFTLE1BQU0sUUFBUSxPQUFPLE1BQU0sUUFBUSxHQUFHO01BQzlILFNBQVMsS0FBSztPQUNaLHVCQUF1QjtNQUN6QjtNQUNBLElBQUksMkNBQ0YscUJBQXFCLGdCQUFnQjtNQUV2QyxxQkFBcUIsWUFBWTtNQUNqQyxxQkFBcUIsVUFBVTtNQUMvQixxQkFBcUIsT0FBTyxNQUFNO01BQ2xDLHFCQUFxQixPQUFPLE1BQU07TUFDbEMsdUJBQXVCLEtBQUssb0JBQW9CO01BQ2hELElBQUksa0JBQWtCO0tBQ3hCO0lBQ0Y7R0FDRjtHQUNBLE9BQU87RUFDVDtFQUNBLE1BQU0sNEJBQTRCLFlBQVkseUJBQXlCO0VBQ3ZFLFNBQVMscUJBQXFCLFNBQVM7R0FDckMsSUFBSSxRQUFRLGlCQUFpQixtQkFBbUI7SUFDOUMsSUFBSTtLQUNGLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLElBQUksV0FBVyxPQUFPLFlBQVksWUFDaEMsUUFBUSxLQUFLLE1BQU07TUFBRSxXQUFXLFFBQVE7TUFBYztLQUFRLENBQUM7SUFFbkUsU0FBUyxLQUFLLENBQ2Q7SUFDQSxRQUFRLGVBQWU7SUFDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLHVCQUF1QixRQUFRLEtBQ2pELElBQUksWUFBWSx1QkFBdUIsRUFBRSxDQUFDLFNBQ3hDLHVCQUF1QixPQUFPLEdBQUcsQ0FBQztHQUd4QztFQUNGO0VBQ0EsU0FBUyx3QkFBd0IsU0FBUyxNQUFNLGNBQWMsYUFBYSxZQUFZO0dBQ3JGLHFCQUFxQixPQUFPO0dBQzVCLE1BQU0sZUFBZSxRQUFRO0dBQzdCLE1BQU0sV0FBVyxlQUFlLE9BQU8sZ0JBQWdCLGFBQWEsY0FBYyxvQkFBb0IsT0FBTyxlQUFlLGFBQWEsYUFBYTtHQUN0SixLQUFLLGtCQUFrQixjQUFjO0lBQ25DLElBQUk7S0FDRixNQUFNLHFCQUFxQixRQUFRO0tBQ25DLE1BQU0sbUJBQW1CLENBQUMsQ0FBQyxnQkFBZ0Isa0JBQWtCLGFBQWE7S0FDMUUsSUFBSSxrQkFBa0I7TUFDcEIsYUFBYSw0QkFBNEI7TUFDekMsYUFBYSw0QkFBNEI7S0FDM0M7S0FFQSxlQUFlLGNBQWMsTUFEZixLQUFLLElBQUksVUFBVSxLQUFLLEdBQUcsb0JBQW9CLGFBQWEsb0JBQW9CLGFBQWEsb0JBQW9CLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUNoSCxDQUFDO0lBQzFDLFNBQVMsT0FBTztLQUNkLGVBQWUsY0FBYyxPQUFPLEtBQUs7SUFDM0M7R0FDRixHQUFHLFlBQVk7RUFDakI7RUFDQSxNQUFNLCtCQUErQjtFQUNyQyxNQUFNLE9BQU8sV0FBVyxDQUN4QjtFQUNBLE1BQU0saUJBQWlCLFFBQVE7RUFDL0IsTUFBTSxpQkFBaUI7R0FDckIsT0FBTyxXQUFXO0lBQ2hCLE9BQU87R0FDVDtHQUNBLE9BQU8sUUFBUSxPQUFPO0lBQ3BCLElBQUksaUJBQWlCLGtCQUNuQixPQUFPO0lBRVQsT0FBTyxlQUFlLElBQUksS0FBSyxJQUFJLEdBQUcsVUFBVSxLQUFLO0dBQ3ZEO0dBQ0EsT0FBTyxPQUFPLE9BQU87SUFDbkIsT0FBTyxlQUFlLElBQUksS0FBSyxJQUFJLEdBQUcsVUFBVSxLQUFLO0dBQ3ZEO0dBQ0EsT0FBTyxnQkFBZ0I7SUFDckIsTUFBTSxTQUFTLENBQUM7SUFDaEIsT0FBTyxVQUFVLElBQUksa0JBQWtCLEtBQUssUUFBUTtLQUNsRCxPQUFPLFVBQVU7S0FDakIsT0FBTyxTQUFTO0lBQ2xCLENBQUM7SUFDRCxPQUFPO0dBQ1Q7R0FDQSxPQUFPLElBQUksUUFBUTtJQUNqQixJQUFJLENBQUMsVUFBVSxPQUFPLE9BQU8sT0FBTyxjQUFjLFlBQ2hELE9BQU8sUUFBUSxPQUFPLElBQUksZUFBZSxDQUFDLEdBQUcsNEJBQTRCLENBQUM7SUFFNUUsTUFBTSxXQUFXLENBQUM7SUFDbEIsSUFBSSxRQUFRO0lBQ1osSUFBSTtLQUNGLEtBQUssSUFBSSxLQUFLLFFBQVE7TUFDcEI7TUFDQSxTQUFTLEtBQUssaUJBQWlCLFFBQVEsQ0FBQyxDQUFDO0tBQzNDO0lBQ0YsU0FBUyxLQUFLO0tBQ1osT0FBTyxRQUFRLE9BQU8sSUFBSSxlQUFlLENBQUMsR0FBRyw0QkFBNEIsQ0FBQztJQUM1RTtJQUNBLElBQUksVUFBVSxHQUNaLE9BQU8sUUFBUSxPQUFPLElBQUksZUFBZSxDQUFDLEdBQUcsNEJBQTRCLENBQUM7SUFFNUUsSUFBSSxXQUFXO0lBQ2YsTUFBTSxTQUFTLENBQUM7SUFDaEIsT0FBTyxJQUFJLGtCQUFrQixTQUFTLFdBQVc7S0FDL0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUNuQyxTQUFTLEVBQUUsQ0FBQyxNQUFNLE1BQU07TUFDdEIsSUFBSSxVQUNGO01BRUYsV0FBVztNQUNYLFFBQVEsQ0FBQztLQUNYLElBQUksUUFBUTtNQUNWLE9BQU8sS0FBSyxHQUFHO01BQ2Y7TUFDQSxJQUFJLFVBQVUsR0FBRztPQUNmLFdBQVc7T0FDWCxPQUFPLElBQUksZUFBZSxRQUFRLDRCQUE0QixDQUFDO01BQ2pFO0tBQ0YsQ0FBQztJQUVMLENBQUM7R0FDSDtHQUNBLE9BQU8sS0FBSyxRQUFRO0lBQ2xCLElBQUk7SUFDSixJQUFJO0lBQ0osSUFBSSxVQUFVLElBQUksTUFBTSxLQUFLLFFBQVE7S0FDbkMsVUFBVTtLQUNWLFNBQVM7SUFDWCxDQUFDO0lBQ0QsU0FBUyxVQUFVLE9BQU87S0FDeEIsUUFBUSxLQUFLO0lBQ2Y7SUFDQSxTQUFTLFNBQVMsT0FBTztLQUN2QixPQUFPLEtBQUs7SUFDZDtJQUNBLEtBQUssSUFBSSxTQUFTLFFBQVE7S0FDeEIsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUNuQixRQUFRLEtBQUssUUFBUSxLQUFLO0tBRTVCLE1BQU0sS0FBSyxXQUFXLFFBQVE7SUFDaEM7SUFDQSxPQUFPO0dBQ1Q7R0FDQSxPQUFPLElBQUksUUFBUTtJQUNqQixPQUFPLGlCQUFpQixnQkFBZ0IsTUFBTTtHQUNoRDtHQUNBLE9BQU8sV0FBVyxRQUFRO0lBRXhCLFFBRFUsUUFBUSxLQUFLLHFCQUFxQixtQkFBbUIsT0FBTyxpQkFBQSxDQUM3RCxnQkFBZ0IsUUFBUTtLQUMvQixlQUFlLFdBQVc7TUFBRSxRQUFRO01BQWE7S0FBTTtLQUN2RCxnQkFBZ0IsU0FBUztNQUFFLFFBQVE7TUFBWSxRQUFRO0tBQUk7SUFDN0QsQ0FBQztHQUNIO0dBQ0EsT0FBTyxnQkFBZ0IsUUFBUSxVQUFVO0lBQ3ZDLElBQUk7SUFDSixJQUFJO0lBQ0osSUFBSSxVQUFVLElBQUksTUFBTSxLQUFLLFFBQVE7S0FDbkMsVUFBVTtLQUNWLFNBQVM7SUFDWCxDQUFDO0lBQ0QsSUFBSSxrQkFBa0I7SUFDdEIsSUFBSSxhQUFhO0lBQ2pCLE1BQU0saUJBQWlCLENBQUM7SUFDeEIsS0FBSyxJQUFJLFNBQVMsUUFBUTtLQUN4QixJQUFJLENBQUMsV0FBVyxLQUFLLEdBQ25CLFFBQVEsS0FBSyxRQUFRLEtBQUs7S0FFNUIsTUFBTSxnQkFBZ0I7S0FDdEIsSUFBSTtNQUNGLE1BQU0sTUFBTSxXQUFXO09BQ3JCLGVBQWUsaUJBQWlCLFdBQVcsU0FBUyxhQUFhLE1BQU0sSUFBSTtPQUMzRTtPQUNBLElBQUksb0JBQW9CLEdBQ3RCLFFBQVEsY0FBYztNQUUxQixJQUFJLFFBQVE7T0FDVixJQUFJLENBQUMsVUFDSCxPQUFPLEdBQUc7WUFDTDtRQUNMLGVBQWUsaUJBQWlCLFNBQVMsY0FBYyxHQUFHO1FBQzFEO1FBQ0EsSUFBSSxvQkFBb0IsR0FDdEIsUUFBUSxjQUFjO09BRTFCO01BQ0YsQ0FBQztLQUNILFNBQVMsU0FBUztNQUNoQixPQUFPLE9BQU87S0FDaEI7S0FDQTtLQUNBO0lBQ0Y7SUFDQSxtQkFBbUI7SUFDbkIsSUFBSSxvQkFBb0IsR0FDdEIsUUFBUSxjQUFjO0lBRXhCLE9BQU87R0FDVDtHQUNBLFlBQVksVUFBVTtJQUNwQixNQUFNLFVBQVU7SUFDaEIsSUFBSSxFQUFFLG1CQUFtQixtQkFDdkIsTUFBTSxJQUFJLE1BQU0sZ0NBQWdDO0lBRWxELFFBQVEsZUFBZTtJQUN2QixRQUFRLGVBQWUsQ0FBQztJQUN4QixJQUFJO0tBQ0YsTUFBTSxjQUFjLEtBQUs7S0FDekIsWUFBWSxTQUFTLFlBQVksYUFBYSxTQUFTLFFBQVEsQ0FBQyxHQUFHLFlBQVksYUFBYSxTQUFTLFFBQVEsQ0FBQyxDQUFDO0lBQ2pILFNBQVMsT0FBTztLQUNkLGVBQWUsU0FBUyxPQUFPLEtBQUs7SUFDdEM7R0FDRjtHQUNBLEtBQUssT0FBTyxlQUFlO0lBQ3pCLE9BQU87R0FDVDtHQUNBLEtBQUssT0FBTyxXQUFXO0lBQ3JCLE9BQU87R0FDVDtHQUNBLEtBQUssYUFBYSxZQUFZO0lBQzVCLElBQUk7SUFDSixJQUFJLEtBQUssS0FBSyxLQUFLLGdCQUFnQixPQUFPLEtBQUssSUFBSSxHQUFHLE9BQU87SUFDN0QsSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQ3JCLElBQUksS0FBSyxlQUFlO0lBRTFCLE1BQU0sZUFBZSxJQUFJLEVBQUUsSUFBSTtJQUMvQixNQUFNLE9BQU8sTUFBTTtJQUNuQixJQUFJLEtBQUssZ0JBQWdCLFlBQ3ZCLEtBQUssWUFBWSxDQUFDLEtBQUssTUFBTSxjQUFjLGFBQWEsVUFBVTtTQUVsRSx3QkFBd0IsTUFBTSxNQUFNLGNBQWMsYUFBYSxVQUFVO0lBRTNFLE9BQU87R0FDVDtHQUNBLE1BQU0sWUFBWTtJQUNoQixPQUFPLEtBQUssS0FBSyxNQUFNLFVBQVU7R0FDbkM7R0FDQSxRQUFRLFdBQVc7SUFDakIsSUFBSTtJQUNKLElBQUksS0FBSyxLQUFLLEtBQUssZ0JBQWdCLE9BQU8sS0FBSyxJQUFJLEdBQUcsT0FBTztJQUM3RCxJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFDckIsSUFBSTtJQUVOLE1BQU0sZUFBZSxJQUFJLEVBQUUsSUFBSTtJQUMvQixhQUFhLGlCQUFpQjtJQUM5QixNQUFNLE9BQU8sTUFBTTtJQUNuQixJQUFJLEtBQUssZ0JBQWdCLFlBQ3ZCLEtBQUssWUFBWSxDQUFDLEtBQUssTUFBTSxjQUFjLFdBQVcsU0FBUztTQUUvRCx3QkFBd0IsTUFBTSxNQUFNLGNBQWMsV0FBVyxTQUFTO0lBRXhFLE9BQU87R0FDVDtFQUNGO0VBQ0EsaUJBQWlCLGFBQWEsaUJBQWlCO0VBQy9DLGlCQUFpQixZQUFZLGlCQUFpQjtFQUM5QyxpQkFBaUIsVUFBVSxpQkFBaUI7RUFDNUMsaUJBQWlCLFNBQVMsaUJBQWlCO0VBQzNDLE1BQU0sZ0JBQWdCLFFBQVEsaUJBQWlCLFFBQVE7RUFDdkQsUUFBUSxhQUFhO0VBQ3JCLE1BQU0sb0JBQW9CLFlBQVksYUFBYTtFQUNuRCxTQUFTLFVBQVUsTUFBTTtHQUN2QixNQUFNLFFBQVEsS0FBSztHQUNuQixNQUFNLE9BQU8sZ0NBQWdDLE9BQU8sTUFBTTtHQUMxRCxJQUFJLFNBQVMsS0FBSyxhQUFhLFNBQVMsQ0FBQyxLQUFLLGVBQzVDO0dBRUYsTUFBTSxlQUFlLE1BQU07R0FDM0IsTUFBTSxjQUFjO0dBQ3BCLEtBQUssVUFBVSxPQUFPLFNBQVMsV0FBVyxVQUFVO0lBSWxELE9BQU8sSUFIYSxrQkFBa0IsU0FBUyxXQUFXO0tBQ3hELGFBQWEsS0FBSyxNQUFNLFNBQVMsTUFBTTtJQUN6QyxDQUNhLENBQUMsQ0FBQyxLQUFLLFdBQVcsUUFBUTtHQUN6QztHQUNBLEtBQUsscUJBQXFCO0VBQzVCO0VBQ0EsSUFBSSxZQUFZO0VBQ2hCLFNBQVMsUUFBUSxJQUFJO0dBQ25CLE9BQU8sU0FBUyxPQUFPLE1BQU07SUFDM0IsSUFBSSxnQkFBZ0IsR0FBRyxNQUFNLE9BQU8sSUFBSTtJQUN4QyxJQUFJLHlCQUF5QixrQkFDM0IsT0FBTztJQUVULElBQUksT0FBTyxjQUFjO0lBQ3pCLElBQUksQ0FBQyxLQUFLLG9CQUNSLFVBQVUsSUFBSTtJQUVoQixPQUFPO0dBQ1Q7RUFDRjtFQUNBLElBQUksZUFBZTtHQUNqQixVQUFVLGFBQWE7R0FDdkIsTUFBTSxZQUFZLGNBQWM7R0FDaEMsSUFBSSxhQUFhLE9BQU8sY0FBYyxZQUNwQyxpQkFBaUIsU0FBUztHQUU1QixZQUFZLFNBQVMsVUFBVSxhQUFhLFFBQVEsUUFBUSxDQUFDO0VBQy9EO0VBQ0EsUUFBUSxNQUFNLFdBQVcsdUJBQXVCLEtBQUs7RUFDckQsT0FBTztDQUNULENBQUM7QUFDSDtBQUdBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLE1BQU0sYUFBYSxhQUFhLFlBQVk7RUFDMUMsTUFBTSwyQkFBMkIsU0FBUyxVQUFVO0VBQ3BELE1BQU0sMkJBQTJCLFdBQVcsa0JBQWtCO0VBQzlELE1BQU0saUJBQWlCLFdBQVcsU0FBUztFQUMzQyxNQUFNLGVBQWUsV0FBVyxPQUFPO0VBQ3ZDLE1BQU0sc0JBQXNCLFNBQVMsV0FBVztHQUM5QyxJQUFJLE9BQU8sU0FBUyxZQUFZO0lBQzlCLE1BQU0sbUJBQW1CLEtBQUs7SUFDOUIsSUFBSSxrQkFDRixJQUFJLE9BQU8scUJBQXFCLFlBQzlCLE9BQU8seUJBQXlCLEtBQUssZ0JBQWdCO1NBRXJELE9BQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxnQkFBZ0I7SUFHMUQsSUFBSSxTQUFTLFNBQVM7S0FDcEIsTUFBTSxnQkFBZ0IsUUFBUTtLQUM5QixJQUFJLGVBQ0YsT0FBTyx5QkFBeUIsS0FBSyxhQUFhO0lBRXREO0lBQ0EsSUFBSSxTQUFTLE9BQU87S0FDbEIsTUFBTSxjQUFjLFFBQVE7S0FDNUIsSUFBSSxhQUNGLE9BQU8seUJBQXlCLEtBQUssV0FBVztJQUVwRDtHQUNGO0dBQ0EsT0FBTyx5QkFBeUIsS0FBSyxJQUFJO0VBQzNDO0VBQ0Esb0JBQW9CLDRCQUE0QjtFQUNoRCxTQUFTLFVBQVUsV0FBVztFQUM5QixNQUFNLHlCQUF5QixPQUFPLFVBQVU7RUFDaEQsTUFBTSwyQkFBMkI7RUFDakMsT0FBTyxVQUFVLFdBQVcsV0FBVztHQUNyQyxJQUFJLE9BQU8sWUFBWSxjQUFjLGdCQUFnQixTQUNuRCxPQUFPO0dBRVQsT0FBTyx1QkFBdUIsS0FBSyxJQUFJO0VBQ3pDO0NBQ0YsQ0FBQztBQUNIO0FBR0EsU0FBUyxlQUFlLEtBQUssUUFBUSxZQUFZLFFBQVEsV0FBVztDQUNsRSxNQUFNLFNBQVMsS0FBSyxXQUFXLE1BQU07Q0FDckMsSUFBSSxPQUFPLFNBQ1Q7Q0FFRixNQUFNLGlCQUFpQixPQUFPLFVBQVUsT0FBTztDQUMvQyxPQUFPLFVBQVUsU0FBUyxNQUFNLE1BQU0sU0FBUztFQUM3QyxJQUFJLFFBQVEsS0FBSyxXQUNmLFVBQVUsUUFBUSxTQUFTLFVBQVU7R0FDbkMsTUFBTSxTQUFTLEdBQUcsV0FBVyxHQUFHLE9BQU8sTUFBTTtHQUM3QyxNQUFNLFlBQVksS0FBSztHQUN2QixJQUFJO0lBQ0YsSUFBSSxVQUFVLGVBQWUsUUFBUSxHQUFHO0tBQ3RDLE1BQU0sYUFBYSxJQUFJLCtCQUErQixXQUFXLFFBQVE7S0FDekUsSUFBSSxjQUFjLFdBQVcsT0FBTztNQUNsQyxXQUFXLFFBQVEsSUFBSSxvQkFBb0IsV0FBVyxPQUFPLE1BQU07TUFDbkUsSUFBSSxrQkFBa0IsS0FBSyxXQUFXLFVBQVUsVUFBVTtLQUM1RCxPQUFPLElBQUksVUFBVSxXQUNuQixVQUFVLFlBQVksSUFBSSxvQkFBb0IsVUFBVSxXQUFXLE1BQU07SUFFN0UsT0FBTyxJQUFJLFVBQVUsV0FDbkIsVUFBVSxZQUFZLElBQUksb0JBQW9CLFVBQVUsV0FBVyxNQUFNO0dBRTdFLFNBQVMsR0FBRyxDQUNaO0VBQ0YsQ0FBQztFQUVILE9BQU8sZUFBZSxLQUFLLFFBQVEsTUFBTSxNQUFNLE9BQU87Q0FDeEQ7Q0FDQSxJQUFJLHNCQUFzQixPQUFPLFNBQVMsY0FBYztBQUMxRDtBQUdBLFNBQVMsVUFBVSxPQUFPO0NBQ3hCLE1BQU0sYUFBYSxTQUFTLFNBQVMsT0FBTyxRQUFRO0VBQ2xELE1BQU0sYUFBYSxnQkFBZ0IsT0FBTztFQUMxQyxJQUFJLG9CQUFvQjtFQUN4QixJQUFJLGNBQWM7RUFDbEIsSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSSxpQkFBaUI7RUFDckIsTUFBTSw2QkFBNkIsTUFBTSxXQUFXLHFCQUFxQjtFQUN6RSxNQUFNLDBCQUEwQixNQUFNLFdBQVcsa0JBQWtCO0VBQ25FLElBQUksUUFBUSwwQkFDVixRQUFRLDhCQUE4QixRQUFRO0VBRWhELElBQUksUUFBUSw2QkFDVixNQUFNLDhCQUE4QixNQUFNLDJCQUEyQixRQUFRO0VBRS9FLElBQUksc0JBQXNCO0VBQzFCLElBQUksbUJBQW1CO0VBQ3ZCLElBQUksdUJBQXVCO0VBQzNCLElBQUksaUNBQWlDO0VBQ3JDLElBQUksZUFBZTtFQUNuQixJQUFJLGFBQWE7RUFDakIsSUFBSSxhQUFhO0VBQ2pCLElBQUksc0JBQXNCO0VBQzFCLElBQUksbUJBQW1CO0VBQ3ZCLElBQUksd0JBQXdCO0VBQzVCLElBQUksb0JBQW9CLE9BQU87RUFDL0IsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSwwQkFBMEI7R0FDNUI7R0FDQSxzQkFBc0I7R0FDdEI7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7Q0FDRixDQUFDO0FBQ0g7QUFHQSxTQUFTLFlBQVksT0FBTztDQUMxQixhQUFhLEtBQUs7Q0FDbEIsY0FBYyxLQUFLO0NBQ25CLFVBQVUsS0FBSztBQUNqQjtBQUdBLElBQUksUUFBUSxTQUFTO0FBQ3JCLFlBQVksS0FBSztBQUNqQixhQUFhLEtBQUsifQ==