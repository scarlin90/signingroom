//#region node_modules/fflate/esm/browser.js
var ch2 = {};
var wk = (function(c, id, msg, transfer, cb) {
	var w = new Worker(ch2[id] || (ch2[id] = URL.createObjectURL(new Blob([c + ";addEventListener(\"error\",function(e){e=e.error;postMessage({$e$:[e.message,e.code,e.stack]})})"], { type: "text/javascript" }))));
	w.onmessage = function(e) {
		var d = e.data, ed = d.$e$;
		if (ed) {
			var err = new Error(ed[0]);
			err["code"] = ed[1];
			err.stack = ed[2];
			cb(err, null);
		} else cb(null, d);
	};
	w.postMessage(msg, transfer);
	return w;
});
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
	var x = (i & 43690) >> 1 | (i & 21845) << 1;
	x = (x & 52428) >> 2 | (x & 13107) << 2;
	x = (x & 61680) >> 4 | (x & 3855) << 4;
	rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i = 0; i < 144; ++i) flt[i] = 8;
for (var i = 144; i < 256; ++i) flt[i] = 9;
for (var i = 256; i < 280; ++i) flt[i] = 7;
for (var i = 280; i < 288; ++i) flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i) fdt[i] = 5;
var flm = /*#__PURE__*/ hMap(flt, 9, 0);
var flrm = /*#__PURE__*/ hMap(flt, 9, 1);
var fdm = /*#__PURE__*/ hMap(fdt, 5, 0);
var fdrm = /*#__PURE__*/ hMap(fdt, 5, 1);
var max = function(a) {
	var m = a[0];
	for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
	return m;
};
var bits = function(d, p, m) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
/**
* Codes for errors generated within this library
*/
var FlateErrorCode = {
	UnexpectedEOF: 0,
	InvalidBlockType: 1,
	InvalidLengthLiteral: 2,
	InvalidDistance: 3,
	StreamFinished: 4,
	NoStreamHandler: 5,
	InvalidHeader: 6,
	NoCallback: 7,
	InvalidUTF8: 8,
	ExtraFieldTooLong: 9,
	InvalidDate: 10,
	FilenameTooLong: 11,
	StreamFinishing: 12,
	InvalidZipData: 13,
	UnknownCompressionMethod: 14
};
var ec = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
];
var err = function(ind, msg, nt) {
	var e = new Error(msg || ec[ind]);
	e.code = ind;
	if (Error.captureStackTrace) Error.captureStackTrace(e, err);
	if (!nt) throw e;
	return e;
};
var inflt = function(dat, st, buf, dict) {
	var sl = dat.length, dl = dict ? dict.length : 0;
	if (!sl || st.f && !st.l) return buf || new u8(0);
	var noBuf = !buf;
	var resize = noBuf || st.i != 2;
	var noSt = st.i;
	if (noBuf) buf = new u8(sl * 3);
	var cbuf = function(l) {
		var bl = buf.length;
		if (l > bl) {
			var nbuf = new u8(Math.max(bl * 2, l));
			nbuf.set(buf);
			buf = nbuf;
		}
	};
	var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
	var tbts = sl * 8;
	do {
		if (!lm) {
			final = bits(dat, pos, 1);
			var type = bits(dat, pos + 1, 3);
			pos += 3;
			if (!type) {
				var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
				if (t > sl) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + l);
				buf.set(dat.subarray(s, t), bt);
				st.b = bt += l, st.p = pos = t * 8, st.f = final;
				continue;
			} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
			else if (type == 2) {
				var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
				var tl = hLit + bits(dat, pos + 5, 31) + 1;
				pos += 14;
				var ldt = new u8(tl);
				var clt = new u8(19);
				for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
				pos += hcLen * 3;
				var clb = max(clt), clbmsk = (1 << clb) - 1;
				var clm = hMap(clt, clb, 1);
				for (var i = 0; i < tl;) {
					var r = clm[bits(dat, pos, clbmsk)];
					pos += r & 15;
					var s = r >> 4;
					if (s < 16) ldt[i++] = s;
					else {
						var c = 0, n = 0;
						if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
						else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
						else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
						while (n--) ldt[i++] = c;
					}
				}
				var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
				lbt = max(lt);
				dbt = max(dt);
				lm = hMap(lt, lbt, 1);
				dm = hMap(dt, dbt, 1);
			} else err(1);
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
		}
		if (resize) cbuf(bt + 131072);
		var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
		var lpos = pos;
		for (;; lpos = pos) {
			var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
			pos += c & 15;
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
			if (!c) err(2);
			if (sym < 256) buf[bt++] = sym;
			else if (sym == 256) {
				lpos = pos, lm = null;
				break;
			} else {
				var add = sym - 254;
				if (sym > 264) {
					var i = sym - 257, b = fleb[i];
					add = bits(dat, pos, (1 << b) - 1) + fl[i];
					pos += b;
				}
				var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
				if (!d) err(3);
				pos += d & 15;
				var dt = fd[dsym];
				if (dsym > 3) {
					var b = fdeb[dsym];
					dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
				}
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + 131072);
				var end = bt + add;
				if (bt < dt) {
					var shift = dl - dt, dend = Math.min(dt, end);
					if (shift + bt < 0) err(3);
					for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
				}
				for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
			}
		}
		st.l = lm, st.p = lpos, st.b = bt, st.f = final;
		if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
	} while (!final);
	return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var wbits = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
	d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
	var t = [];
	for (var i = 0; i < d.length; ++i) if (d[i]) t.push({
		s: i,
		f: d[i]
	});
	var s = t.length;
	var t2 = t.slice();
	if (!s) return {
		t: et,
		l: 0
	};
	if (s == 1) {
		var v = new u8(t[0].s + 1);
		v[t[0].s] = 1;
		return {
			t: v,
			l: 1
		};
	}
	t.sort(function(a, b) {
		return a.f - b.f;
	});
	t.push({
		s: -1,
		f: 25001
	});
	var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
	t[0] = {
		s: -1,
		f: l.f + r.f,
		l,
		r
	};
	while (i1 != s - 1) {
		l = t[t[i0].f < t[i2].f ? i0++ : i2++];
		r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
		t[i1++] = {
			s: -1,
			f: l.f + r.f,
			l,
			r
		};
	}
	var maxSym = t2[0].s;
	for (var i = 1; i < s; ++i) if (t2[i].s > maxSym) maxSym = t2[i].s;
	var tr = new u16(maxSym + 1);
	var mbt = ln(t[i1 - 1], tr, 0);
	if (mbt > mb) {
		var i = 0, dt = 0;
		var lft = mbt - mb, cst = 1 << lft;
		t2.sort(function(a, b) {
			return tr[b.s] - tr[a.s] || a.f - b.f;
		});
		for (; i < s; ++i) {
			var i2_1 = t2[i].s;
			if (tr[i2_1] > mb) {
				dt += cst - (1 << mbt - tr[i2_1]);
				tr[i2_1] = mb;
			} else break;
		}
		dt >>= lft;
		while (dt > 0) {
			var i2_2 = t2[i].s;
			if (tr[i2_2] < mb) dt -= 1 << mb - tr[i2_2]++ - 1;
			else ++i;
		}
		for (; i >= 0 && dt; --i) {
			var i2_3 = t2[i].s;
			if (tr[i2_3] == mb) {
				--tr[i2_3];
				++dt;
			}
		}
		mbt = mb;
	}
	return {
		t: new u8(tr),
		l: mbt
	};
};
var ln = function(n, l, d) {
	return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
	var s = c.length;
	while (s && !c[--s]);
	var cl = new u16(++s);
	var cli = 0, cln = c[0], cls = 1;
	var w = function(v) {
		cl[cli++] = v;
	};
	for (var i = 1; i <= s; ++i) if (c[i] == cln && i != s) ++cls;
	else {
		if (!cln && cls > 2) {
			for (; cls > 138; cls -= 138) w(32754);
			if (cls > 2) {
				w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
				cls = 0;
			}
		} else if (cls > 3) {
			w(cln), --cls;
			for (; cls > 6; cls -= 6) w(8304);
			if (cls > 2) w(cls - 3 << 5 | 8208), cls = 0;
		}
		while (cls--) w(cln);
		cls = 1;
		cln = c[i];
	}
	return {
		c: cl.subarray(0, cli),
		n: s
	};
};
var clen = function(cf, cl) {
	var l = 0;
	for (var i = 0; i < cl.length; ++i) l += cf[i] * cl[i];
	return l;
};
var wfblk = function(out, pos, dat) {
	var s = dat.length;
	var o = shft(pos + 2);
	out[o] = s & 255;
	out[o + 1] = s >> 8;
	out[o + 2] = out[o] ^ 255;
	out[o + 3] = out[o + 1] ^ 255;
	for (var i = 0; i < s; ++i) out[o + i + 4] = dat[i];
	return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
	wbits(out, p++, final);
	++lf[256];
	var _a = hTree(lf, 15), dlt = _a.t, mlb = _a.l;
	var _b = hTree(df, 15), ddt = _b.t, mdb = _b.l;
	var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
	var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
	var lcfreq = new u16(19);
	for (var i = 0; i < lclt.length; ++i) ++lcfreq[lclt[i] & 31];
	for (var i = 0; i < lcdt.length; ++i) ++lcfreq[lcdt[i] & 31];
	var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
	var nlcc = 19;
	for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc);
	var flen = bl + 5 << 3;
	var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
	var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
	if (bs >= 0 && flen <= ftlen && flen <= dtlen) return wfblk(out, p, dat.subarray(bs, bs + bl));
	var lm, ll, dm, dl;
	wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
	if (dtlen < ftlen) {
		lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
		var llm = hMap(lct, mlcb, 0);
		wbits(out, p, nlc - 257);
		wbits(out, p + 5, ndc - 1);
		wbits(out, p + 10, nlcc - 4);
		p += 14;
		for (var i = 0; i < nlcc; ++i) wbits(out, p + 3 * i, lct[clim[i]]);
		p += 3 * nlcc;
		var lcts = [lclt, lcdt];
		for (var it = 0; it < 2; ++it) {
			var clct = lcts[it];
			for (var i = 0; i < clct.length; ++i) {
				var len = clct[i] & 31;
				wbits(out, p, llm[len]), p += lct[len];
				if (len > 15) wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
			}
		}
	} else lm = flm, ll = flt, dm = fdm, dl = fdt;
	for (var i = 0; i < li; ++i) {
		var sym = syms[i];
		if (sym > 255) {
			var len = sym >> 18 & 31;
			wbits16(out, p, lm[len + 257]), p += ll[len + 257];
			if (len > 7) wbits(out, p, sym >> 23 & 31), p += fleb[len];
			var dst = sym & 31;
			wbits16(out, p, dm[dst]), p += dl[dst];
			if (dst > 3) wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
		} else wbits16(out, p, lm[sym]), p += ll[sym];
	}
	wbits16(out, p, lm[256]);
	return p + ll[256];
};
var deo = /*#__PURE__*/ new i32([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]);
var et = /*#__PURE__*/ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
	var s = st.z || dat.length;
	var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
	var w = o.subarray(pre, o.length - post);
	var lst = st.l;
	var pos = (st.r || 0) & 7;
	if (lvl) {
		if (pos) w[0] = st.r >> 3;
		var opt = deo[lvl - 1];
		var n = opt >> 13, c = opt & 8191;
		var msk_1 = (1 << plvl) - 1;
		var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
		var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
		var hsh = function(i) {
			return (dat[i] ^ dat[i + 1] << bs1_1 ^ dat[i + 2] << bs2_1) & msk_1;
		};
		var syms = new i32(25e3);
		var lf = new u16(288), df = new u16(32);
		var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
		for (; i + 2 < s; ++i) {
			var hv = hsh(i);
			var imod = i & 32767, pimod = head[hv];
			prev[imod] = pimod;
			head[hv] = imod;
			if (wi <= i) {
				var rem = s - i;
				if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
					pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
					li = lc_1 = eb = 0, bs = i;
					for (var j = 0; j < 286; ++j) lf[j] = 0;
					for (var j = 0; j < 30; ++j) df[j] = 0;
				}
				var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
				if (rem > 2 && hv == hsh(i - dif)) {
					var maxn = Math.min(n, rem) - 1;
					var maxd = Math.min(32767, i);
					var ml = Math.min(258, rem);
					while (dif <= maxd && --ch_1 && imod != pimod) {
						if (dat[i + l] == dat[i + l - dif]) {
							var nl = 0;
							for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl);
							if (nl > l) {
								l = nl, d = dif;
								if (nl > maxn) break;
								var mmd = Math.min(dif, nl - 2);
								var md = 0;
								for (var j = 0; j < mmd; ++j) {
									var ti = i - dif + j & 32767;
									var cd = ti - prev[ti] & 32767;
									if (cd > md) md = cd, pimod = ti;
								}
							}
						}
						imod = pimod, pimod = prev[imod];
						dif += imod - pimod & 32767;
					}
				}
				if (d) {
					syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
					var lin = revfl[l] & 31, din = revfd[d] & 31;
					eb += fleb[lin] + fdeb[din];
					++lf[257 + lin];
					++df[din];
					wi = i + l;
					++lc_1;
				} else {
					syms[li++] = dat[i];
					++lf[dat[i]];
				}
			}
		}
		for (i = Math.max(i, wi); i < s; ++i) {
			syms[li++] = dat[i];
			++lf[dat[i]];
		}
		pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
		if (!lst) {
			st.r = pos & 7 | w[pos / 8 | 0] << 3;
			pos -= 7;
			st.h = head, st.p = prev, st.i = i, st.w = wi;
		}
	} else {
		for (var i = st.w || 0; i < s + lst; i += 65535) {
			var e = i + 65535;
			if (e >= s) {
				w[pos / 8 | 0] = lst;
				e = s;
			}
			pos = wfblk(w, pos + 1, dat.subarray(i, e));
		}
		st.i = s;
	}
	return slc(o, 0, pre + shft(pos) + post);
};
var crct = /*#__PURE__*/ (function() {
	var t = /* @__PURE__ */ new Int32Array(256);
	for (var i = 0; i < 256; ++i) {
		var c = i, k = 9;
		while (--k) c = (c & 1 && -306674912) ^ c >>> 1;
		t[i] = c;
	}
	return t;
})();
var crc = function() {
	var c = -1;
	return {
		p: function(d) {
			var cr = c;
			for (var i = 0; i < d.length; ++i) cr = crct[cr & 255 ^ d[i]] ^ cr >>> 8;
			c = cr;
		},
		d: function() {
			return ~c;
		}
	};
};
var adler = function() {
	var a = 1, b = 0;
	return {
		p: function(d) {
			var n = a, m = b;
			var l = d.length | 0;
			for (var i = 0; i != l;) {
				var e = Math.min(i + 2655, l);
				for (; i < e; ++i) m += n += d[i];
				n = (n & 65535) + 15 * (n >> 16), m = (m & 65535) + 15 * (m >> 16);
			}
			a = n, b = m;
		},
		d: function() {
			a %= 65521, b %= 65521;
			return (a & 255) << 24 | (a & 65280) << 8 | (b & 255) << 8 | b >> 8;
		}
	};
};
var dopt = function(dat, opt, pre, post, st) {
	if (!st) {
		st = { l: 1 };
		if (opt.dictionary) {
			var dict = opt.dictionary.subarray(-32768);
			var newDat = new u8(dict.length + dat.length);
			newDat.set(dict);
			newDat.set(dat, dict.length);
			dat = newDat;
			st.w = dict.length;
		}
	}
	return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var mrg = function(a, b) {
	var o = {};
	for (var k in a) o[k] = a[k];
	for (var k in b) o[k] = b[k];
	return o;
};
var wcln = function(fn, fnStr, td) {
	var dt = fn();
	var st = fn.toString();
	var ks = st.slice(st.indexOf("[") + 1, st.lastIndexOf("]")).replace(/\s+/g, "").split(",");
	for (var i = 0; i < dt.length; ++i) {
		var v = dt[i], k = ks[i];
		if (typeof v == "function") {
			fnStr += ";" + k + "=";
			var st_1 = v.toString();
			if (v.prototype) if (st_1.indexOf("[native code]") != -1) {
				var spInd = st_1.indexOf(" ", 8) + 1;
				fnStr += st_1.slice(spInd, st_1.indexOf("(", spInd));
			} else {
				fnStr += st_1;
				for (var t in v.prototype) fnStr += ";" + k + ".prototype." + t + "=" + v.prototype[t].toString();
			}
			else fnStr += st_1;
		} else td[k] = v;
	}
	return fnStr;
};
var ch = [];
var cbfs = function(v) {
	var tl = [];
	for (var k in v) if (v[k].buffer) tl.push((v[k] = new v[k].constructor(v[k])).buffer);
	return tl;
};
var wrkr = function(fns, init, id, cb) {
	if (!ch[id]) {
		var fnStr = "", td_1 = {}, m = fns.length - 1;
		for (var i = 0; i < m; ++i) fnStr = wcln(fns[i], fnStr, td_1);
		ch[id] = {
			c: wcln(fns[m], fnStr, td_1),
			e: td_1
		};
	}
	var td = mrg({}, ch[id].e);
	return wk(ch[id].c + ";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=" + init.toString() + "}", id, td, cbfs(td), cb);
};
var bInflt = function() {
	return [
		u8,
		u16,
		i32,
		fleb,
		fdeb,
		clim,
		fl,
		fd,
		flrm,
		fdrm,
		rev,
		ec,
		hMap,
		max,
		bits,
		bits16,
		shft,
		slc,
		err,
		inflt,
		inflateSync,
		pbf,
		gopt
	];
};
var bDflt = function() {
	return [
		u8,
		u16,
		i32,
		fleb,
		fdeb,
		clim,
		revfl,
		revfd,
		flm,
		flt,
		fdm,
		fdt,
		rev,
		deo,
		et,
		hMap,
		wbits,
		wbits16,
		hTree,
		ln,
		lc,
		clen,
		wfblk,
		wblk,
		shft,
		slc,
		dflt,
		dopt,
		deflateSync,
		pbf
	];
};
var gze = function() {
	return [
		gzh,
		gzhl,
		wbytes,
		crc,
		crct
	];
};
var guze = function() {
	return [gzs, gzl];
};
var zle = function() {
	return [
		zlh,
		wbytes,
		adler
	];
};
var zule = function() {
	return [zls];
};
var pbf = function(msg) {
	return postMessage(msg, [msg.buffer]);
};
var gopt = function(o) {
	return o && {
		out: o.size && new u8(o.size),
		dictionary: o.dictionary
	};
};
var cbify = function(dat, opts, fns, init, id, cb) {
	var w = wrkr(fns, init, id, function(err, dat) {
		w.terminate();
		cb(err, dat);
	});
	w.postMessage([dat, opts], opts.consume ? [dat.buffer] : []);
	return function() {
		w.terminate();
	};
};
var astrm = function(strm) {
	strm.ondata = function(dat, final) {
		return postMessage([dat, final], [dat.buffer]);
	};
	return function(ev) {
		if (ev.data[0]) {
			strm.push(ev.data[0], ev.data[1]);
			postMessage([ev.data[0].length]);
		} else strm.flush(ev.data[1]);
	};
};
var astrmify = function(fns, strm, opts, init, id, flush, ext) {
	var t;
	var w = wrkr(fns, init, id, function(err, dat) {
		if (err) w.terminate(), strm.ondata.call(strm, err);
		else if (!Array.isArray(dat)) ext(dat);
		else if (dat.length == 1) {
			strm.queuedSize -= dat[0];
			if (strm.ondrain) strm.ondrain(dat[0]);
		} else {
			if (dat[1]) w.terminate();
			strm.ondata.call(strm, err, dat[0], dat[1]);
		}
	});
	w.postMessage(opts);
	strm.queuedSize = 0;
	strm.push = function(d, f) {
		if (!strm.ondata) err(5);
		if (t) strm.ondata(err(4, 0, 1), null, !!f);
		strm.queuedSize += d.length;
		w.postMessage([d, t = f], d.buffer instanceof ArrayBuffer ? [d.buffer] : []);
	};
	strm.terminate = function() {
		w.terminate();
	};
	if (flush) strm.flush = function(sync) {
		w.postMessage([0, sync]);
	};
};
var b2 = function(d, b) {
	return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
	return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
	return b4(d, b) + b4(d, b + 4) * 4294967296;
};
var wbytes = function(d, b, v) {
	for (; v; ++b) d[b] = v, v >>>= 8;
};
var gzh = function(c, o) {
	var fn = o.filename;
	c[0] = 31, c[1] = 139, c[2] = 8, c[8] = o.level < 2 ? 4 : o.level == 9 ? 2 : 0, c[9] = 3;
	if (o.mtime != 0) wbytes(c, 4, Math.floor(new Date(o.mtime || Date.now()) / 1e3));
	if (fn) {
		c[3] = 8;
		for (var i = 0; i <= fn.length; ++i) c[i + 10] = fn.charCodeAt(i);
	}
};
var gzs = function(d) {
	if (d[0] != 31 || d[1] != 139 || d[2] != 8) err(6, "invalid gzip data");
	var flg = d[3];
	var st = 10;
	if (flg & 4) st += (d[10] | d[11] << 8) + 2;
	for (var zs = (flg >> 3 & 1) + (flg >> 4 & 1); zs > 0; zs -= !d[st++]);
	return st + (flg & 2);
};
var gzl = function(d) {
	var l = d.length;
	return (d[l - 4] | d[l - 3] << 8 | d[l - 2] << 16 | d[l - 1] << 24) >>> 0;
};
var gzhl = function(o) {
	return 10 + (o.filename ? o.filename.length + 1 : 0);
};
var zlh = function(c, o) {
	var lv = o.level, fl = lv == 0 ? 0 : lv < 6 ? 1 : lv == 9 ? 3 : 2;
	c[0] = 120, c[1] = fl << 6 | (o.dictionary && 32);
	c[1] |= 31 - (c[0] << 8 | c[1]) % 31;
	if (o.dictionary) {
		var h = adler();
		h.p(o.dictionary);
		wbytes(c, 2, h.d());
	}
};
var zls = function(d, dict) {
	if ((d[0] & 15) != 8 || d[0] >> 4 > 7 || (d[0] << 8 | d[1]) % 31) err(6, "invalid zlib data");
	if ((d[1] >> 5 & 1) == +!dict) err(6, "invalid zlib data: " + (d[1] & 32 ? "need" : "unexpected") + " dictionary");
	return (d[1] >> 3 & 4) + 2;
};
function StrmOpt(opts, cb) {
	if (typeof opts == "function") cb = opts, opts = {};
	this.ondata = cb;
	return opts;
}
/**
* Streaming DEFLATE compression
*/
var Deflate = /* @__PURE__ */ function() {
	function Deflate(opts, cb) {
		if (typeof opts == "function") cb = opts, opts = {};
		this.ondata = cb;
		this.o = opts || {};
		this.s = {
			l: 0,
			i: 32768,
			w: 32768,
			z: 32768
		};
		this.b = new u8(98304);
		if (this.o.dictionary) {
			var dict = this.o.dictionary.subarray(-32768);
			this.b.set(dict, 32768 - dict.length);
			this.s.i = 32768 - dict.length;
		}
	}
	Deflate.prototype.p = function(c, f) {
		this.ondata(dopt(c, this.o, 0, 0, this.s), f);
	};
	/**
	* Pushes a chunk to be deflated
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Deflate.prototype.push = function(chunk, final) {
		if (!this.ondata) err(5);
		if (this.s.l) err(4);
		var endLen = chunk.length + this.s.z;
		if (endLen > this.b.length) {
			if (endLen > 2 * this.b.length - 32768) {
				var newBuf = new u8(endLen & -32768);
				newBuf.set(this.b.subarray(0, this.s.z));
				this.b = newBuf;
			}
			var split = this.b.length - this.s.z;
			this.b.set(chunk.subarray(0, split), this.s.z);
			this.s.z = this.b.length;
			this.p(this.b, false);
			this.b.set(this.b.subarray(-32768));
			this.b.set(chunk.subarray(split), 32768);
			this.s.z = chunk.length - split + 32768;
			this.s.i = 32766, this.s.w = 32768;
		} else {
			this.b.set(chunk, this.s.z);
			this.s.z += chunk.length;
		}
		this.s.l = final & 1;
		if (this.s.z > this.s.w + 8191 || final) {
			this.p(this.b, final || false);
			this.s.w = this.s.i, this.s.i -= 2;
		}
		if (final) {
			this.s = this.o = {};
			this.b = et;
		}
	};
	/**
	* Flushes buffered uncompressed data. Useful to immediately retrieve the
	* deflated output for small inputs.
	* @param sync Whether to flush to a byte boundary. A sync flush takes 4-5
	*             extra bytes, but guarantees all pushed data is immediately
	*             decompressible. A separate DEFLATE stream may be concatenated
	*             with the current output after a sync flush.
	*/
	Deflate.prototype.flush = function(sync) {
		if (!this.ondata) err(5);
		if (this.s.l) err(4);
		this.p(this.b, false);
		this.s.w = this.s.i, this.s.i -= 2;
		if (sync) {
			var c = new u8(6);
			c[0] = this.s.r >> 3;
			var ep = wfblk(c, this.s.r, et);
			this.s.r = 0;
			this.ondata(c.subarray(0, ep >> 3), false);
		}
	};
	return Deflate;
}();
/**
* Asynchronous streaming DEFLATE compression
*/
var AsyncDeflate = /* @__PURE__ */ function() {
	function AsyncDeflate(opts, cb) {
		astrmify([bDflt, function() {
			return [astrm, Deflate];
		}], this, StrmOpt.call(this, opts, cb), function(ev) {
			onmessage = astrm(new Deflate(ev.data));
		}, 6, 1);
	}
	return AsyncDeflate;
}();
function deflate(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return cbify(data, opts, [bDflt], function(ev) {
		return pbf(deflateSync(ev.data[0], ev.data[1]));
	}, 0, cb);
}
/**
* Compresses data with DEFLATE without any wrapper
* @param data The data to compress
* @param opts The compression options
* @returns The deflated version of the data
*/
function deflateSync(data, opts) {
	return dopt(data, opts || {}, 0, 0);
}
/**
* Streaming DEFLATE decompression
*/
var Inflate = /* @__PURE__ */ function() {
	function Inflate(opts, cb) {
		if (typeof opts == "function") cb = opts, opts = {};
		this.ondata = cb;
		var dict = opts && opts.dictionary && opts.dictionary.subarray(-32768);
		this.s = {
			i: 0,
			b: dict ? dict.length : 0
		};
		this.o = new u8(32768);
		this.p = new u8(0);
		if (dict) this.o.set(dict);
	}
	Inflate.prototype.e = function(c) {
		if (!this.ondata) err(5);
		if (this.d) err(4);
		if (!this.p.length) this.p = c;
		else if (c.length) {
			var n = new u8(this.p.length + c.length);
			n.set(this.p), n.set(c, this.p.length), this.p = n;
		}
	};
	Inflate.prototype.c = function(final) {
		this.s.i = +(this.d = final || false);
		var bts = this.s.b;
		var dt = inflt(this.p, this.s, this.o);
		this.ondata(slc(dt, bts, this.s.b), this.d);
		this.o = slc(dt, this.s.b - 32768), this.s.b = this.o.length;
		this.p = slc(this.p, this.s.p / 8 | 0), this.s.p &= 7;
	};
	/**
	* Pushes a chunk to be inflated
	* @param chunk The chunk to push
	* @param final Whether this is the final chunk
	*/
	Inflate.prototype.push = function(chunk, final) {
		this.e(chunk), this.c(final);
	};
	return Inflate;
}();
/**
* Asynchronous streaming DEFLATE decompression
*/
var AsyncInflate = /* @__PURE__ */ function() {
	function AsyncInflate(opts, cb) {
		astrmify([bInflt, function() {
			return [astrm, Inflate];
		}], this, StrmOpt.call(this, opts, cb), function(ev) {
			onmessage = astrm(new Inflate(ev.data));
		}, 7, 0);
	}
	return AsyncInflate;
}();
function inflate(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return cbify(data, opts, [bInflt], function(ev) {
		return pbf(inflateSync(ev.data[0], gopt(ev.data[1])));
	}, 1, cb);
}
function inflateSync(data, opts) {
	return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
/**
* Streaming GZIP compression
*/
var Gzip = /* @__PURE__ */ function() {
	function Gzip(opts, cb) {
		this.c = crc();
		this.l = 0;
		this.v = 1;
		Deflate.call(this, opts, cb);
	}
	/**
	* Pushes a chunk to be GZIPped
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Gzip.prototype.push = function(chunk, final) {
		this.c.p(chunk);
		this.l += chunk.length;
		Deflate.prototype.push.call(this, chunk, final);
	};
	Gzip.prototype.p = function(c, f) {
		var raw = dopt(c, this.o, this.v && gzhl(this.o), f && 8, this.s);
		if (this.v) gzh(raw, this.o), this.v = 0;
		if (f) wbytes(raw, raw.length - 8, this.c.d()), wbytes(raw, raw.length - 4, this.l);
		this.ondata(raw, f);
	};
	/**
	* Flushes buffered uncompressed data. Useful to immediately retrieve the
	* GZIPped output for small inputs.
	* @param sync Whether to flush to a byte boundary. A sync flush takes 4-5
	*             extra bytes, but guarantees all pushed data is immediately
	*             decompressible.
	*/
	Gzip.prototype.flush = function(sync) {
		Deflate.prototype.flush.call(this, sync);
	};
	return Gzip;
}();
/**
* Asynchronous streaming GZIP compression
*/
var AsyncGzip = /* @__PURE__ */ function() {
	function AsyncGzip(opts, cb) {
		astrmify([
			bDflt,
			gze,
			function() {
				return [
					astrm,
					Deflate,
					Gzip
				];
			}
		], this, StrmOpt.call(this, opts, cb), function(ev) {
			onmessage = astrm(new Gzip(ev.data));
		}, 8, 1);
	}
	return AsyncGzip;
}();
function gzip(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return cbify(data, opts, [
		bDflt,
		gze,
		function() {
			return [gzipSync];
		}
	], function(ev) {
		return pbf(gzipSync(ev.data[0], ev.data[1]));
	}, 2, cb);
}
/**
* Compresses data with GZIP
* @param data The data to compress
* @param opts The compression options
* @returns The gzipped version of the data
*/
function gzipSync(data, opts) {
	if (!opts) opts = {};
	var c = crc(), l = data.length;
	c.p(data);
	var d = dopt(data, opts, gzhl(opts), 8), s = d.length;
	return gzh(d, opts), wbytes(d, s - 8, c.d()), wbytes(d, s - 4, l), d;
}
/**
* Streaming single or multi-member GZIP decompression
*/
var Gunzip = /* @__PURE__ */ function() {
	function Gunzip(opts, cb) {
		this.v = 1;
		this.r = 0;
		Inflate.call(this, opts, cb);
	}
	/**
	* Pushes a chunk to be GUNZIPped
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Gunzip.prototype.push = function(chunk, final) {
		Inflate.prototype.e.call(this, chunk);
		this.r += chunk.length;
		if (this.v) {
			var p = this.p.subarray(this.v - 1);
			var s = p.length > 3 ? gzs(p) : 4;
			if (s > p.length) {
				if (!final) return;
			} else if (this.v > 1 && this.onmember) this.onmember(this.r - p.length);
			this.p = p.subarray(s), this.v = 0;
		}
		Inflate.prototype.c.call(this, 0);
		if (this.s.f && !this.s.l) {
			this.v = shft(this.s.p) + 9;
			this.s = { i: 0 };
			this.o = new u8(0);
			this.push(new u8(0), final);
		} else if (final) Inflate.prototype.c.call(this, final);
	};
	return Gunzip;
}();
/**
* Asynchronous streaming single or multi-member GZIP decompression
*/
var AsyncGunzip = /* @__PURE__ */ function() {
	function AsyncGunzip(opts, cb) {
		var _this = this;
		astrmify([
			bInflt,
			guze,
			function() {
				return [
					astrm,
					Inflate,
					Gunzip
				];
			}
		], this, StrmOpt.call(this, opts, cb), function(ev) {
			var strm = new Gunzip(ev.data);
			strm.onmember = function(offset) {
				return postMessage(offset);
			};
			onmessage = astrm(strm);
		}, 9, 0, function(offset) {
			return _this.onmember && _this.onmember(offset);
		});
	}
	return AsyncGunzip;
}();
function gunzip(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return cbify(data, opts, [
		bInflt,
		guze,
		function() {
			return [gunzipSync];
		}
	], function(ev) {
		return pbf(gunzipSync(ev.data[0], ev.data[1]));
	}, 3, cb);
}
function gunzipSync(data, opts) {
	var st = gzs(data);
	if (st + 8 > data.length) err(6, "invalid gzip data");
	return inflt(data.subarray(st, -8), { i: 2 }, opts && opts.out || new u8(gzl(data)), opts && opts.dictionary);
}
/**
* Streaming Zlib compression
*/
var Zlib = /* @__PURE__ */ function() {
	function Zlib(opts, cb) {
		this.c = adler();
		this.v = 1;
		Deflate.call(this, opts, cb);
	}
	/**
	* Pushes a chunk to be zlibbed
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Zlib.prototype.push = function(chunk, final) {
		this.c.p(chunk);
		Deflate.prototype.push.call(this, chunk, final);
	};
	Zlib.prototype.p = function(c, f) {
		var raw = dopt(c, this.o, this.v && (this.o.dictionary ? 6 : 2), f && 4, this.s);
		if (this.v) zlh(raw, this.o), this.v = 0;
		if (f) wbytes(raw, raw.length - 4, this.c.d());
		this.ondata(raw, f);
	};
	/**
	* Flushes buffered uncompressed data. Useful to immediately retrieve the
	* zlibbed output for small inputs.
	* @param sync Whether to flush to a byte boundary. A sync flush takes 4-5
	*             extra bytes, but guarantees all pushed data is immediately
	*             decompressible.
	*/
	Zlib.prototype.flush = function(sync) {
		Deflate.prototype.flush.call(this, sync);
	};
	return Zlib;
}();
/**
* Asynchronous streaming Zlib compression
*/
var AsyncZlib = /* @__PURE__ */ function() {
	function AsyncZlib(opts, cb) {
		astrmify([
			bDflt,
			zle,
			function() {
				return [
					astrm,
					Deflate,
					Zlib
				];
			}
		], this, StrmOpt.call(this, opts, cb), function(ev) {
			onmessage = astrm(new Zlib(ev.data));
		}, 10, 1);
	}
	return AsyncZlib;
}();
function zlib(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return cbify(data, opts, [
		bDflt,
		zle,
		function() {
			return [zlibSync];
		}
	], function(ev) {
		return pbf(zlibSync(ev.data[0], ev.data[1]));
	}, 4, cb);
}
/**
* Compress data with Zlib
* @param data The data to compress
* @param opts The compression options
* @returns The zlib-compressed version of the data
*/
function zlibSync(data, opts) {
	if (!opts) opts = {};
	var a = adler();
	a.p(data);
	var d = dopt(data, opts, opts.dictionary ? 6 : 2, 4);
	return zlh(d, opts), wbytes(d, d.length - 4, a.d()), d;
}
/**
* Streaming Zlib decompression
*/
var Unzlib = /* @__PURE__ */ function() {
	function Unzlib(opts, cb) {
		Inflate.call(this, opts, cb);
		this.v = opts && opts.dictionary ? 2 : 1;
	}
	/**
	* Pushes a chunk to be unzlibbed
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Unzlib.prototype.push = function(chunk, final) {
		Inflate.prototype.e.call(this, chunk);
		if (this.v) {
			if (this.p.length < 6 && !final) return;
			this.p = this.p.subarray(zls(this.p, this.v - 1)), this.v = 0;
		}
		if (final) {
			if (this.p.length < 4) err(6, "invalid zlib data");
			this.p = this.p.subarray(0, -4);
		}
		Inflate.prototype.c.call(this, final);
	};
	return Unzlib;
}();
/**
* Asynchronous streaming Zlib decompression
*/
var AsyncUnzlib = /* @__PURE__ */ function() {
	function AsyncUnzlib(opts, cb) {
		astrmify([
			bInflt,
			zule,
			function() {
				return [
					astrm,
					Inflate,
					Unzlib
				];
			}
		], this, StrmOpt.call(this, opts, cb), function(ev) {
			onmessage = astrm(new Unzlib(ev.data));
		}, 11, 0);
	}
	return AsyncUnzlib;
}();
function unzlib(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return cbify(data, opts, [
		bInflt,
		zule,
		function() {
			return [unzlibSync];
		}
	], function(ev) {
		return pbf(unzlibSync(ev.data[0], gopt(ev.data[1])));
	}, 5, cb);
}
function unzlibSync(data, opts) {
	return inflt(data.subarray(zls(data, opts && opts.dictionary), -4), { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
/**
* Streaming GZIP, Zlib, or raw DEFLATE decompression
*/
var Decompress = /* @__PURE__ */ function() {
	function Decompress(opts, cb) {
		this.o = StrmOpt.call(this, opts, cb) || {};
		this.G = Gunzip;
		this.I = Inflate;
		this.Z = Unzlib;
	}
	Decompress.prototype.i = function() {
		var _this = this;
		this.s.ondata = function(dat, final) {
			_this.ondata(dat, final);
		};
	};
	/**
	* Pushes a chunk to be decompressed
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Decompress.prototype.push = function(chunk, final) {
		if (!this.ondata) err(5);
		if (!this.s) {
			if (this.p && this.p.length) {
				var n = new u8(this.p.length + chunk.length);
				n.set(this.p), n.set(chunk, this.p.length);
			} else this.p = chunk;
			if (this.p.length > 2) {
				this.s = this.p[0] == 31 && this.p[1] == 139 && this.p[2] == 8 ? new this.G(this.o) : (this.p[0] & 15) != 8 || this.p[0] >> 4 > 7 || (this.p[0] << 8 | this.p[1]) % 31 ? new this.I(this.o) : new this.Z(this.o);
				this.i();
				this.s.push(this.p, final);
				this.p = null;
			}
		} else this.s.push(chunk, final);
	};
	return Decompress;
}();
/**
* Asynchronous streaming GZIP, Zlib, or raw DEFLATE decompression
*/
var AsyncDecompress = /* @__PURE__ */ function() {
	function AsyncDecompress(opts, cb) {
		Decompress.call(this, opts, cb);
		this.queuedSize = 0;
		this.G = AsyncGunzip;
		this.I = AsyncInflate;
		this.Z = AsyncUnzlib;
	}
	AsyncDecompress.prototype.i = function() {
		var _this = this;
		this.s.ondata = function(err, dat, final) {
			_this.ondata(err, dat, final);
		};
		this.s.ondrain = function(size) {
			_this.queuedSize -= size;
			if (_this.ondrain) _this.ondrain(size);
		};
	};
	/**
	* Pushes a chunk to be decompressed
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	AsyncDecompress.prototype.push = function(chunk, final) {
		this.queuedSize += chunk.length;
		Decompress.prototype.push.call(this, chunk, final);
	};
	return AsyncDecompress;
}();
function decompress(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	return data[0] == 31 && data[1] == 139 && data[2] == 8 ? gunzip(data, opts, cb) : (data[0] & 15) != 8 || data[0] >> 4 > 7 || (data[0] << 8 | data[1]) % 31 ? inflate(data, opts, cb) : unzlib(data, opts, cb);
}
/**
* Expands compressed GZIP, Zlib, or raw DEFLATE data, automatically detecting the format
* @param data The data to decompress
* @param opts The decompression options
* @returns The decompressed version of the data
*/
function decompressSync(data, opts) {
	return data[0] == 31 && data[1] == 139 && data[2] == 8 ? gunzipSync(data, opts) : (data[0] & 15) != 8 || data[0] >> 4 > 7 || (data[0] << 8 | data[1]) % 31 ? inflateSync(data, opts) : unzlibSync(data, opts);
}
var fltn = function(d, p, t, o) {
	for (var k in d) {
		var val = d[k], n = p + k, op = o;
		if (Array.isArray(val)) op = mrg(o, val[1]), val = val[0];
		if (ArrayBuffer.isView(val)) t[n] = [val, op];
		else {
			t[n += "/"] = [new u8(0), op];
			fltn(val, n, t, o);
		}
	}
};
var te = typeof TextEncoder != "undefined" && /*#__PURE__*/ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /*#__PURE__*/ new TextDecoder();
var tds = 0;
try {
	td.decode(et, { stream: true });
	tds = 1;
} catch (e) {}
var dutf8 = function(d) {
	for (var r = "", i = 0;;) {
		var c = d[i++];
		var eb = (c > 127) + (c > 223) + (c > 239);
		if (i + eb > d.length) return {
			s: r,
			r: slc(d, i - 1)
		};
		if (!eb) r += String.fromCharCode(c);
		else if (eb == 3) c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
		else if (eb & 1) r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
		else r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
	}
};
/**
* Streaming UTF-8 decoding
*/
var DecodeUTF8 = /* @__PURE__ */ function() {
	/**
	* Creates a UTF-8 decoding stream
	* @param cb The callback to call whenever data is decoded
	*/
	function DecodeUTF8(cb) {
		this.ondata = cb;
		if (tds) this.t = new TextDecoder();
		else this.p = et;
	}
	/**
	* Pushes a chunk to be decoded from UTF-8 binary
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	DecodeUTF8.prototype.push = function(chunk, final) {
		if (!this.ondata) err(5);
		final = !!final;
		if (this.t) {
			this.ondata(this.t.decode(chunk, { stream: true }), final);
			if (final) {
				if (this.t.decode().length) err(8);
				this.t = null;
			}
			return;
		}
		if (!this.p) err(4);
		var dat = new u8(this.p.length + chunk.length);
		dat.set(this.p);
		dat.set(chunk, this.p.length);
		var _a = dutf8(dat), s = _a.s, r = _a.r;
		if (final) {
			if (r.length) err(8);
			this.p = null;
		} else this.p = r;
		this.ondata(s, final);
	};
	return DecodeUTF8;
}();
/**
* Streaming UTF-8 encoding
*/
var EncodeUTF8 = /* @__PURE__ */ function() {
	/**
	* Creates a UTF-8 decoding stream
	* @param cb The callback to call whenever data is encoded
	*/
	function EncodeUTF8(cb) {
		this.ondata = cb;
	}
	/**
	* Pushes a chunk to be encoded to UTF-8
	* @param chunk The string data to push
	* @param final Whether this is the last chunk
	*/
	EncodeUTF8.prototype.push = function(chunk, final) {
		if (!this.ondata) err(5);
		if (this.d) err(4);
		this.ondata(strToU8(chunk), this.d = final || false);
	};
	return EncodeUTF8;
}();
/**
* Converts a string into a Uint8Array for use with compression/decompression methods
* @param str The string to encode
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless decoding a binary string.
* @returns The string encoded in UTF-8/Latin-1 binary
*/
function strToU8(str, latin1) {
	if (latin1) {
		var ar_1 = new u8(str.length);
		for (var i = 0; i < str.length; ++i) ar_1[i] = str.charCodeAt(i);
		return ar_1;
	}
	if (te) return te.encode(str);
	var l = str.length;
	var ar = new u8(str.length + (str.length >> 1));
	var ai = 0;
	var w = function(v) {
		ar[ai++] = v;
	};
	for (var i = 0; i < l; ++i) {
		if (ai + 5 > ar.length) {
			var n = new u8(ai + 8 + (l - i << 1));
			n.set(ar);
			ar = n;
		}
		var c = str.charCodeAt(i);
		if (c < 128 || latin1) w(c);
		else if (c < 2048) w(192 | c >> 6), w(128 | c & 63);
		else if (c > 55295 && c < 57344) c = 65536 + (c & 1047552) | str.charCodeAt(++i) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
		else w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
	}
	return slc(ar, 0, ai);
}
/**
* Converts a Uint8Array to a string
* @param dat The data to decode to string
* @param latin1 Whether or not to interpret the data as Latin-1. This should
*               not need to be true unless encoding to binary string.
* @returns The original UTF-8/Latin-1 string
*/
function strFromU8(dat, latin1) {
	if (latin1) {
		var r = "";
		for (var i = 0; i < dat.length; i += 16384) r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
		return r;
	} else if (td) return td.decode(dat);
	else {
		var _a = dutf8(dat), s = _a.s, r = _a.r;
		if (r.length) err(8);
		return s;
	}
}
var dbf = function(l) {
	return l == 1 ? 3 : l < 6 ? 2 : l == 9 ? 1 : 0;
};
var slzh = function(d, b) {
	return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
	var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
	var _a = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a[0], su = _a[1], off = _a[2];
	return [
		b2(d, b + 10),
		sc,
		su,
		fn,
		es + efl + b2(d, b + 32),
		off
	];
};
var z64hs = function(d, b, l, z, sc, su, off) {
	var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
	var nf = nsc + nsu + noff;
	if (z && nf) {
		for (; b + 4 < e; b += 4 + b2(d, b + 2)) if (b2(d, b) == 1) return [
			nsc ? b8(d, b + 4 + 8 * nsu) : sc,
			nsu ? b8(d, b + 4) : su,
			noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
			1
		];
		if (z < 2) err(13);
	}
	return [
		sc,
		su,
		off,
		0
	];
};
var exfl = function(ex) {
	var le = 0;
	if (ex) for (var k in ex) {
		var l = ex[k].length;
		if (l > 65535) err(9);
		le += l + 4;
	}
	return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
	var fl = fn.length, ex = f.extra, col = co && co.length;
	var exl = exfl(ex);
	wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
	if (ce != null) d[b++] = 20, d[b++] = f.os;
	d[b] = 20, b += 2;
	d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
	d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
	var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
	if (y < 0 || y > 119) err(10);
	wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
	if (c != -1) {
		wbytes(d, b, f.crc);
		wbytes(d, b + 4, c < 0 ? -c - 2 : c);
		wbytes(d, b + 8, f.size);
	}
	wbytes(d, b + 12, fl);
	wbytes(d, b + 14, exl), b += 16;
	if (ce != null) {
		wbytes(d, b, col);
		wbytes(d, b + 6, f.attrs);
		wbytes(d, b + 10, ce), b += 14;
	}
	d.set(fn, b);
	b += fl;
	if (exl) for (var k in ex) {
		var exf = ex[k], l = exf.length;
		wbytes(d, b, +k);
		wbytes(d, b + 2, l);
		d.set(exf, b + 4), b += 4 + l;
	}
	if (col) d.set(co, b), b += col;
	return b;
};
var wzf = function(o, b, c, d, e) {
	wbytes(o, b, 101010256);
	wbytes(o, b + 8, c);
	wbytes(o, b + 10, c);
	wbytes(o, b + 12, d);
	wbytes(o, b + 16, e);
};
/**
* A pass-through stream to keep data uncompressed in a ZIP archive.
*/
var ZipPassThrough = /* @__PURE__ */ function() {
	/**
	* Creates a pass-through stream that can be added to ZIP archives
	* @param filename The filename to associate with this data stream
	*/
	function ZipPassThrough(filename) {
		this.filename = filename;
		this.c = crc();
		this.size = 0;
		this.compression = 0;
	}
	/**
	* Processes a chunk and pushes to the output stream. You can override this
	* method in a subclass for custom behavior, but by default this passes
	* the data through. You must call this.ondata(err, chunk, final) at some
	* point in this method.
	* @param chunk The chunk to process
	* @param final Whether this is the last chunk
	*/
	ZipPassThrough.prototype.process = function(chunk, final) {
		this.ondata(null, chunk, final);
	};
	/**
	* Pushes a chunk to be added. If you are subclassing this with a custom
	* compression algorithm, note that you must push data from the source
	* file only, pre-compression.
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	ZipPassThrough.prototype.push = function(chunk, final) {
		if (!this.ondata) err(5);
		this.c.p(chunk);
		this.size += chunk.length;
		if (final) this.crc = this.c.d();
		this.process(chunk, final || false);
	};
	return ZipPassThrough;
}();
/**
* Streaming DEFLATE compression for ZIP archives. Prefer using AsyncZipDeflate
* for better performance
*/
var ZipDeflate = /* @__PURE__ */ function() {
	/**
	* Creates a DEFLATE stream that can be added to ZIP archives
	* @param filename The filename to associate with this data stream
	* @param opts The compression options
	*/
	function ZipDeflate(filename, opts) {
		var _this = this;
		if (!opts) opts = {};
		ZipPassThrough.call(this, filename);
		this.d = new Deflate(opts, function(dat, final) {
			_this.ondata(null, dat, final);
		});
		this.compression = 8;
		this.flag = dbf(opts.level);
	}
	ZipDeflate.prototype.process = function(chunk, final) {
		try {
			this.d.push(chunk, final);
		} catch (e) {
			this.ondata(e, null, final);
		}
	};
	/**
	* Pushes a chunk to be deflated
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	ZipDeflate.prototype.push = function(chunk, final) {
		ZipPassThrough.prototype.push.call(this, chunk, final);
	};
	return ZipDeflate;
}();
/**
* Asynchronous streaming DEFLATE compression for ZIP archives
*/
var AsyncZipDeflate = /* @__PURE__ */ function() {
	/**
	* Creates an asynchronous DEFLATE stream that can be added to ZIP archives
	* @param filename The filename to associate with this data stream
	* @param opts The compression options
	*/
	function AsyncZipDeflate(filename, opts) {
		var _this = this;
		if (!opts) opts = {};
		ZipPassThrough.call(this, filename);
		this.d = new AsyncDeflate(opts, function(err, dat, final) {
			_this.ondata(err, dat, final);
		});
		this.compression = 8;
		this.flag = dbf(opts.level);
		this.terminate = this.d.terminate;
	}
	AsyncZipDeflate.prototype.process = function(chunk, final) {
		this.d.push(chunk, final);
	};
	/**
	* Pushes a chunk to be deflated
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	AsyncZipDeflate.prototype.push = function(chunk, final) {
		ZipPassThrough.prototype.push.call(this, chunk, final);
	};
	return AsyncZipDeflate;
}();
/**
* A zippable archive to which files can incrementally be added
*/
var Zip = /* @__PURE__ */ function() {
	/**
	* Creates an empty ZIP archive to which files can be added
	* @param cb The callback to call whenever data for the generated ZIP archive
	*           is available
	*/
	function Zip(cb) {
		this.ondata = cb;
		this.u = [];
		this.d = 1;
	}
	/**
	* Adds a file to the ZIP archive
	* @param file The file stream to add
	*/
	Zip.prototype.add = function(file) {
		var _this = this;
		if (!this.ondata) err(5);
		if (this.d & 2) this.ondata(err(4 + (this.d & 1) * 8, 0, 1), null, false);
		else {
			var f = strToU8(file.filename), fl_1 = f.length;
			var com = file.comment, o = com && strToU8(com);
			var u = fl_1 != file.filename.length || o && com.length != o.length;
			var hl_1 = fl_1 + exfl(file.extra) + 30;
			if (fl_1 > 65535) this.ondata(err(11, 0, 1), null, false);
			var header = new u8(hl_1);
			wzh(header, 0, file, f, u, -1);
			var chks_1 = [header];
			var pAll_1 = function() {
				for (var _i = 0, chks_2 = chks_1; _i < chks_2.length; _i++) {
					var chk = chks_2[_i];
					_this.ondata(null, chk, false);
				}
				chks_1 = [];
			};
			var tr_1 = this.d;
			this.d = 0;
			var ind_1 = this.u.length;
			var uf_1 = mrg(file, {
				f,
				u,
				o,
				t: function() {
					if (file.terminate) file.terminate();
				},
				r: function() {
					pAll_1();
					if (tr_1) {
						var nxt = _this.u[ind_1 + 1];
						if (nxt) nxt.r();
						else _this.d = 1;
					}
					tr_1 = 1;
				}
			});
			var cl_1 = 0;
			file.ondata = function(err, dat, final) {
				if (err) {
					_this.ondata(err, dat, final);
					_this.terminate();
				} else {
					cl_1 += dat.length;
					chks_1.push(dat);
					if (final) {
						var dd = new u8(16);
						wbytes(dd, 0, 134695760);
						wbytes(dd, 4, file.crc);
						wbytes(dd, 8, cl_1);
						wbytes(dd, 12, file.size);
						chks_1.push(dd);
						uf_1.c = cl_1, uf_1.b = hl_1 + cl_1 + 16, uf_1.crc = file.crc, uf_1.size = file.size;
						if (tr_1) uf_1.r();
						tr_1 = 1;
					} else if (tr_1) pAll_1();
				}
			};
			this.u.push(uf_1);
		}
	};
	/**
	* Ends the process of adding files and prepares to emit the final chunks.
	* This *must* be called after adding all desired files for the resulting
	* ZIP file to work properly.
	*/
	Zip.prototype.end = function() {
		var _this = this;
		if (this.d & 2) {
			this.ondata(err(4 + (this.d & 1) * 8, 0, 1), null, true);
			return;
		}
		if (this.d) this.e();
		else this.u.push({
			r: function() {
				if (!(_this.d & 1)) return;
				_this.u.splice(-1, 1);
				_this.e();
			},
			t: function() {}
		});
		this.d = 3;
	};
	Zip.prototype.e = function() {
		var bt = 0, l = 0, tl = 0;
		for (var _i = 0, _a = this.u; _i < _a.length; _i++) {
			var f = _a[_i];
			tl += 46 + f.f.length + exfl(f.extra) + (f.o ? f.o.length : 0);
		}
		var out = new u8(tl + 22);
		for (var _b = 0, _c = this.u; _b < _c.length; _b++) {
			var f = _c[_b];
			wzh(out, bt, f, f.f, f.u, -f.c - 2, l, f.o);
			bt += 46 + f.f.length + exfl(f.extra) + (f.o ? f.o.length : 0), l += f.b;
		}
		wzf(out, bt, this.u.length, tl, l);
		this.ondata(null, out, true);
		this.d = 2;
	};
	/**
	* A method to terminate any internal workers used by the stream. Subsequent
	* calls to add() will fail.
	*/
	Zip.prototype.terminate = function() {
		for (var _i = 0, _a = this.u; _i < _a.length; _i++) _a[_i].t();
		this.d = 2;
	};
	return Zip;
}();
function zip(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	var r = {};
	fltn(data, "", r, opts);
	var k = Object.keys(r);
	var lft = k.length, o = 0, tot = 0;
	var slft = lft, files = new Array(lft);
	var term = [];
	var tAll = function() {
		for (var i = 0; i < term.length; ++i) term[i]();
	};
	var cbd = function(a, b) {
		mt(function() {
			cb(a, b);
		});
	};
	mt(function() {
		cbd = cb;
	});
	var cbf = function() {
		var out = new u8(tot + 22), oe = o, cdl = tot - o;
		tot = 0;
		for (var i = 0; i < slft; ++i) {
			var f = files[i];
			try {
				var l = f.c.length;
				wzh(out, tot, f, f.f, f.u, l);
				var badd = 30 + f.f.length + exfl(f.extra);
				var loc = tot + badd;
				out.set(f.c, loc);
				wzh(out, o, f, f.f, f.u, l, tot, f.m), o += 16 + badd + (f.m ? f.m.length : 0), tot = loc + l;
			} catch (e) {
				return cbd(e, null);
			}
		}
		wzf(out, o, files.length, cdl, oe);
		cbd(null, out);
	};
	if (!lft) cbf();
	var _loop_1 = function(i) {
		var fn = k[i];
		var _a = r[fn], file = _a[0], p = _a[1];
		var c = crc(), size = file.length;
		c.p(file);
		var f = strToU8(fn), s = f.length;
		var com = p.comment, m = com && strToU8(com), ms = m && m.length;
		var exl = exfl(p.extra);
		var compression = p.level == 0 ? 0 : 8;
		var cbl = function(e, d) {
			if (e) {
				tAll();
				cbd(e, null);
			} else {
				var l = d.length;
				files[i] = mrg(p, {
					size,
					crc: c.d(),
					c: d,
					f,
					m,
					u: s != fn.length || m && com.length != ms,
					compression
				});
				o += 30 + s + exl + l;
				tot += 76 + 2 * (s + exl) + (ms || 0) + l;
				if (!--lft) cbf();
			}
		};
		if (s > 65535) cbl(err(11, 0, 1), null);
		if (!compression) cbl(null, file);
		else if (size < 16e4) try {
			cbl(null, deflateSync(file, p));
		} catch (e) {
			cbl(e, null);
		}
		else term.push(deflate(file, p, cbl));
	};
	for (var i = 0; i < slft; ++i) _loop_1(i);
	return tAll;
}
/**
* Synchronously creates a ZIP file. Prefer using `zip` for better performance
* with more than one file.
* @param data The directory structure for the ZIP archive
* @param opts The main options, merged with per-file options
* @returns The generated ZIP archive
*/
function zipSync(data, opts) {
	if (!opts) opts = {};
	var r = {};
	var files = [];
	fltn(data, "", r, opts);
	var o = 0;
	var tot = 0;
	for (var fn in r) {
		var _a = r[fn], file = _a[0], p = _a[1];
		var compression = p.level == 0 ? 0 : 8;
		var f = strToU8(fn), s = f.length;
		var com = p.comment, m = com && strToU8(com), ms = m && m.length;
		var exl = exfl(p.extra);
		if (s > 65535) err(11);
		var d = compression ? deflateSync(file, p) : file, l = d.length;
		var c = crc();
		c.p(file);
		files.push(mrg(p, {
			size: file.length,
			crc: c.d(),
			c: d,
			f,
			m,
			u: s != fn.length || m && com.length != ms,
			o,
			compression
		}));
		o += 30 + s + exl + l;
		tot += 76 + 2 * (s + exl) + (ms || 0) + l;
	}
	var out = new u8(tot + 22), oe = o, cdl = tot - o;
	for (var i = 0; i < files.length; ++i) {
		var f = files[i];
		wzh(out, f.o, f, f.f, f.u, f.c.length);
		var badd = 30 + f.f.length + exfl(f.extra);
		out.set(f.c, f.o + badd);
		wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
	}
	wzf(out, o, files.length, cdl, oe);
	return out;
}
/**
* Streaming pass-through decompression for ZIP archives
*/
var UnzipPassThrough = /* @__PURE__ */ function() {
	function UnzipPassThrough() {}
	UnzipPassThrough.prototype.push = function(chunk, final) {
		this.ondata(null, chunk, final);
	};
	UnzipPassThrough.compression = 0;
	return UnzipPassThrough;
}();
/**
* Streaming DEFLATE decompression for ZIP archives. Prefer AsyncZipInflate for
* better performance.
*/
var UnzipInflate = /* @__PURE__ */ function() {
	/**
	* Creates a DEFLATE decompression that can be used in ZIP archives
	*/
	function UnzipInflate() {
		var _this = this;
		this.i = new Inflate(function(dat, final) {
			_this.ondata(null, dat, final);
		});
	}
	UnzipInflate.prototype.push = function(chunk, final) {
		try {
			this.i.push(chunk, final);
		} catch (e) {
			this.ondata(e, null, final);
		}
	};
	UnzipInflate.compression = 8;
	return UnzipInflate;
}();
/**
* Asynchronous streaming DEFLATE decompression for ZIP archives
*/
var AsyncUnzipInflate = /* @__PURE__ */ function() {
	/**
	* Creates a DEFLATE decompression that can be used in ZIP archives
	*/
	function AsyncUnzipInflate(_, sz) {
		var _this = this;
		if (sz < 32e4) this.i = new Inflate(function(dat, final) {
			_this.ondata(null, dat, final);
		});
		else {
			this.i = new AsyncInflate(function(err, dat, final) {
				_this.ondata(err, dat, final);
			});
			this.terminate = this.i.terminate;
		}
	}
	AsyncUnzipInflate.prototype.push = function(chunk, final) {
		if (this.i.terminate) chunk = slc(chunk, 0);
		this.i.push(chunk, final);
	};
	AsyncUnzipInflate.compression = 8;
	return AsyncUnzipInflate;
}();
/**
* A ZIP archive decompression stream that emits files as they are discovered
*/
var Unzip = /* @__PURE__ */ function() {
	/**
	* Creates a ZIP decompression stream
	* @param cb The callback to call whenever a file in the ZIP archive is found
	*/
	function Unzip(cb) {
		this.onfile = cb;
		this.k = [];
		this.o = { 0: UnzipPassThrough };
		this.p = et;
	}
	/**
	* Pushes a chunk to be unzipped
	* @param chunk The chunk to push
	* @param final Whether this is the last chunk
	*/
	Unzip.prototype.push = function(chunk, final) {
		var _this = this;
		if (!this.onfile) err(5);
		if (!this.p) err(4);
		if (this.c > 0) {
			var len = Math.min(this.c, chunk.length);
			var toAdd = chunk.subarray(0, len);
			this.c -= len;
			if (this.d) this.d.push(toAdd, !this.c);
			else this.k[0].push(toAdd);
			chunk = chunk.subarray(len);
			if (chunk.length) return this.push(chunk, final);
		} else {
			var f = 0, i = 0, is = void 0, buf = void 0;
			if (!this.p.length) buf = chunk;
			else if (!chunk.length) buf = this.p;
			else {
				buf = new u8(this.p.length + chunk.length);
				buf.set(this.p), buf.set(chunk, this.p.length);
			}
			var l = buf.length, oc = this.c, add = oc && this.d;
			var _loop_2 = function() {
				var sig = b4(buf, i);
				if (sig == 67324752) {
					f = 1, is = i;
					this_1.d = null;
					this_1.c = 0;
					var bf = b2(buf, i + 6), cmp_1 = b2(buf, i + 8), u = bf & 2048, dd = bf & 8, fnl = b2(buf, i + 26), es = b2(buf, i + 28);
					if (l > i + 30 + fnl + es) {
						var chks_3 = [];
						this_1.k.unshift(chks_3);
						f = 2;
						var lsc = b4(buf, i + 18), lsu = b4(buf, i + 22);
						var fn_1 = strFromU8(buf.subarray(i + 30, i += 30 + fnl), !u);
						var _a = z64hs(buf, i, es, 2, lsc, lsu, 0), sc_1 = _a[0], su_1 = _a[1], z64 = _a[3];
						if (dd) sc_1 = -1 - z64;
						i += es;
						this_1.c = sc_1;
						var d_1;
						var file_1 = {
							name: fn_1,
							compression: cmp_1,
							start: function() {
								if (!file_1.ondata) err(5);
								if (!sc_1) file_1.ondata(null, et, true);
								else {
									var ctr = _this.o[cmp_1];
									if (!ctr) file_1.ondata(err(14, "unknown compression type " + cmp_1, 1), null, false);
									d_1 = sc_1 < 0 ? new ctr(fn_1) : new ctr(fn_1, sc_1, su_1);
									d_1.ondata = function(err, dat, final) {
										file_1.ondata(err, dat, final);
									};
									for (var _i = 0, chks_4 = chks_3; _i < chks_4.length; _i++) {
										var dat = chks_4[_i];
										d_1.push(dat, false);
									}
									if (_this.k[0] == chks_3 && _this.c) _this.d = d_1;
									else d_1.push(et, true);
								}
							},
							terminate: function() {
								if (d_1 && d_1.terminate) d_1.terminate();
							}
						};
						if (sc_1 >= 0) file_1.size = sc_1, file_1.originalSize = su_1;
						this_1.onfile(file_1);
					}
					return "break";
				} else if (oc) {
					if (sig == 134695760) {
						is = i += 12 + (oc == -2 && 8), f = 3, this_1.c = 0;
						return "break";
					} else if (sig == 33639248) {
						is = i -= 4, f = 3, this_1.c = 0;
						return "break";
					}
				}
			};
			var this_1 = this;
			for (; i < l - 4; ++i) if (_loop_2() === "break") break;
			this.p = et;
			if (oc < 0) {
				var dat = f ? buf.subarray(0, is - 12 - (oc == -2 && 8) - (b4(buf, is - 16) == 134695760 && 4)) : buf.subarray(0, i);
				if (add) add.push(dat, !!f);
				else this.k[+(f == 2)].push(dat);
			}
			if (f & 2) return this.push(buf.subarray(i), final);
			this.p = buf.subarray(i);
		}
		if (final) {
			if (this.c) err(13);
			this.p = null;
		}
	};
	/**
	* Registers a decoder with the stream, allowing for files compressed with
	* the compression type provided to be expanded correctly
	* @param decoder The decoder constructor
	*/
	Unzip.prototype.register = function(decoder) {
		this.o[decoder.compression] = decoder;
	};
	return Unzip;
}();
var mt = typeof queueMicrotask == "function" ? queueMicrotask : typeof setTimeout == "function" ? setTimeout : function(fn) {
	fn();
};
function unzip(data, opts, cb) {
	if (!cb) cb = opts, opts = {};
	if (typeof cb != "function") err(7);
	var term = [];
	var tAll = function() {
		for (var i = 0; i < term.length; ++i) term[i]();
	};
	var files = {};
	var cbd = function(a, b) {
		mt(function() {
			cb(a, b);
		});
	};
	mt(function() {
		cbd = cb;
	});
	var e = data.length - 22;
	for (; b4(data, e) != 101010256; --e) if (!e || data.length - e > 65558) {
		cbd(err(13, 0, 1), null);
		return tAll;
	}
	var lft = b2(data, e + 8);
	if (lft) {
		var c = lft;
		var o = b4(data, e + 16);
		var z = b4(data, e - 20) == 117853008;
		if (z) {
			var ze = b4(data, e - 12);
			z = b4(data, ze) == 101075792;
			if (z) {
				c = lft = b4(data, ze + 32);
				o = b4(data, ze + 48);
			}
		}
		var fltr = opts && opts.filter;
		var _loop_3 = function(i) {
			var _a = zh(data, o, z), c_1 = _a[0], sc = _a[1], su = _a[2], fn = _a[3], no = _a[4], off = _a[5], b = slzh(data, off);
			o = no;
			var cbl = function(e, d) {
				if (e) {
					tAll();
					cbd(e, null);
				} else {
					if (d) files[fn] = d;
					if (!--lft) cbd(null, files);
				}
			};
			if (!fltr || fltr({
				name: fn,
				size: sc,
				originalSize: su,
				compression: c_1
			})) if (!c_1) cbl(null, slc(data, b, b + sc));
			else if (c_1 == 8) {
				var infl = data.subarray(b, b + sc);
				if (su < 524288 || sc > .8 * su) try {
					cbl(null, inflateSync(infl, { out: new u8(su) }));
				} catch (e) {
					cbl(e, null);
				}
				else term.push(inflate(infl, { size: su }, cbl));
			} else cbl(err(14, "unknown compression type " + c_1, 1), null);
			else cbl(null, null);
		};
		for (var i = 0; i < c; ++i) _loop_3(i);
	} else cbd(null, {});
	return tAll;
}
/**
* Synchronously decompresses a ZIP archive. Prefer using `unzip` for better
* performance with more than one file.
* @param data The raw compressed ZIP file
* @param opts The ZIP extraction options
* @returns The decompressed files
*/
function unzipSync(data, opts) {
	var files = {};
	var e = data.length - 22;
	for (; b4(data, e) != 101010256; --e) if (!e || data.length - e > 65558) err(13);
	var c = b2(data, e + 8);
	if (!c) return {};
	var o = b4(data, e + 16);
	var z = b4(data, e - 20) == 117853008;
	if (z) {
		var ze = b4(data, e - 12);
		z = b4(data, ze) == 101075792;
		if (z) {
			c = b4(data, ze + 32);
			o = b4(data, ze + 48);
		}
	}
	var fltr = opts && opts.filter;
	for (var i = 0; i < c; ++i) {
		var _a = zh(data, o, z), c_2 = _a[0], sc = _a[1], su = _a[2], fn = _a[3], no = _a[4], off = _a[5], b = slzh(data, off);
		o = no;
		if (!fltr || fltr({
			name: fn,
			size: sc,
			originalSize: su,
			compression: c_2
		})) if (!c_2) files[fn] = slc(data, b, b + sc);
		else if (c_2 == 8) files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
		else err(14, "unknown compression type " + c_2);
	}
	return files;
}
//#endregion
export { AsyncGzip as AsyncCompress, AsyncGzip, AsyncDecompress, AsyncDeflate, AsyncGunzip, AsyncInflate, AsyncUnzipInflate, AsyncUnzlib, AsyncZipDeflate, AsyncZlib, Gzip as Compress, Gzip, DecodeUTF8, Decompress, Deflate, EncodeUTF8, FlateErrorCode, Gunzip, Inflate, Unzip, UnzipInflate, UnzipPassThrough, Unzlib, Zip, ZipDeflate, ZipPassThrough, Zlib, gzip as compress, gzip, gzipSync as compressSync, gzipSync, decompress, decompressSync, deflate, deflateSync, gunzip, gunzipSync, inflate, inflateSync, strFromU8, strToU8, unzip, unzipSync, unzlib, unzlibSync, zip, zipSync, zlib, zlibSync };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmZsYXRlLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9mZmxhdGUvZXNtL2Jyb3dzZXIuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gREVGTEFURSBpcyBhIGNvbXBsZXggZm9ybWF0OyB0byByZWFkIHRoaXMgY29kZSwgeW91IHNob3VsZCBwcm9iYWJseSBjaGVjayB0aGUgUkZDIGZpcnN0OlxuLy8gaHR0cHM6Ly90b29scy5pZXRmLm9yZy9odG1sL3JmYzE5NTFcbi8vIFlvdSBtYXkgYWxzbyB3aXNoIHRvIHRha2UgYSBsb29rIGF0IHRoZSBndWlkZSBJIG1hZGUgYWJvdXQgdGhpcyBwcm9ncmFtOlxuLy8gaHR0cHM6Ly9naXN0LmdpdGh1Yi5jb20vMTAxYXJyb3d6LzI1M2YzMWViNWFiYzNkOTI3NWFiOTQzMDAzZmZlY2FkXG4vLyBTb21lIG9mIHRoZSBmb2xsb3dpbmcgY29kZSBpcyBzaW1pbGFyIHRvIHRoYXQgb2YgVVpJUC5qczpcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9waG90b3BlYS9VWklQLmpzXG4vLyBIb3dldmVyLCB0aGUgdmFzdCBtYWpvcml0eSBvZiB0aGUgY29kZWJhc2UgaGFzIGRpdmVyZ2VkIGZyb20gVVpJUC5qcyB0byBpbmNyZWFzZSBwZXJmb3JtYW5jZSBhbmQgcmVkdWNlIGJ1bmRsZSBzaXplLlxuLy8gU29tZXRpbWVzIDAgd2lsbCBhcHBlYXIgd2hlcmUgLTEgd291bGQgYmUgbW9yZSBhcHByb3ByaWF0ZS4gVGhpcyBpcyBiZWNhdXNlIHVzaW5nIGEgdWludFxuLy8gaXMgYmV0dGVyIGZvciBtZW1vcnkgaW4gbW9zdCBlbmdpbmVzIChJICp0aGluayopLlxudmFyIGNoMiA9IHt9O1xudmFyIHdrID0gKGZ1bmN0aW9uIChjLCBpZCwgbXNnLCB0cmFuc2ZlciwgY2IpIHtcbiAgICB2YXIgdyA9IG5ldyBXb3JrZXIoY2gyW2lkXSB8fCAoY2gyW2lkXSA9IFVSTC5jcmVhdGVPYmplY3RVUkwobmV3IEJsb2IoW1xuICAgICAgICBjICsgJzthZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIixmdW5jdGlvbihlKXtlPWUuZXJyb3I7cG9zdE1lc3NhZ2UoeyRlJDpbZS5tZXNzYWdlLGUuY29kZSxlLnN0YWNrXX0pfSknXG4gICAgXSwgeyB0eXBlOiAndGV4dC9qYXZhc2NyaXB0JyB9KSkpKTtcbiAgICB3Lm9ubWVzc2FnZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIHZhciBkID0gZS5kYXRhLCBlZCA9IGQuJGUkO1xuICAgICAgICBpZiAoZWQpIHtcbiAgICAgICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoZWRbMF0pO1xuICAgICAgICAgICAgZXJyWydjb2RlJ10gPSBlZFsxXTtcbiAgICAgICAgICAgIGVyci5zdGFjayA9IGVkWzJdO1xuICAgICAgICAgICAgY2IoZXJyLCBudWxsKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICBjYihudWxsLCBkKTtcbiAgICB9O1xuICAgIHcucG9zdE1lc3NhZ2UobXNnLCB0cmFuc2Zlcik7XG4gICAgcmV0dXJuIHc7XG59KTtcblxuLy8gYWxpYXNlcyBmb3Igc2hvcnRlciBjb21wcmVzc2VkIGNvZGUgKG1vc3QgbWluaWZlcnMgZG9uJ3QgZG8gdGhpcylcbnZhciB1OCA9IFVpbnQ4QXJyYXksIHUxNiA9IFVpbnQxNkFycmF5LCBpMzIgPSBJbnQzMkFycmF5O1xuLy8gZml4ZWQgbGVuZ3RoIGV4dHJhIGJpdHNcbnZhciBmbGViID0gbmV3IHU4KFswLCAwLCAwLCAwLCAwLCAwLCAwLCAwLCAxLCAxLCAxLCAxLCAyLCAyLCAyLCAyLCAzLCAzLCAzLCAzLCA0LCA0LCA0LCA0LCA1LCA1LCA1LCA1LCAwLCAvKiB1bnVzZWQgKi8gMCwgMCwgLyogaW1wb3NzaWJsZSAqLyAwXSk7XG4vLyBmaXhlZCBkaXN0YW5jZSBleHRyYSBiaXRzXG52YXIgZmRlYiA9IG5ldyB1OChbMCwgMCwgMCwgMCwgMSwgMSwgMiwgMiwgMywgMywgNCwgNCwgNSwgNSwgNiwgNiwgNywgNywgOCwgOCwgOSwgOSwgMTAsIDEwLCAxMSwgMTEsIDEyLCAxMiwgMTMsIDEzLCAvKiB1bnVzZWQgKi8gMCwgMF0pO1xuLy8gY29kZSBsZW5ndGggaW5kZXggbWFwXG52YXIgY2xpbSA9IG5ldyB1OChbMTYsIDE3LCAxOCwgMCwgOCwgNywgOSwgNiwgMTAsIDUsIDExLCA0LCAxMiwgMywgMTMsIDIsIDE0LCAxLCAxNV0pO1xuLy8gZ2V0IGJhc2UsIHJldmVyc2UgaW5kZXggbWFwIGZyb20gZXh0cmEgYml0c1xudmFyIGZyZWIgPSBmdW5jdGlvbiAoZWIsIHN0YXJ0KSB7XG4gICAgdmFyIGIgPSBuZXcgdTE2KDMxKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IDMxOyArK2kpIHtcbiAgICAgICAgYltpXSA9IHN0YXJ0ICs9IDEgPDwgZWJbaSAtIDFdO1xuICAgIH1cbiAgICAvLyBudW1iZXJzIGhlcmUgYXJlIGF0IG1heCAxOCBiaXRzXG4gICAgdmFyIHIgPSBuZXcgaTMyKGJbMzBdKTtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IDMwOyArK2kpIHtcbiAgICAgICAgZm9yICh2YXIgaiA9IGJbaV07IGogPCBiW2kgKyAxXTsgKytqKSB7XG4gICAgICAgICAgICByW2pdID0gKChqIC0gYltpXSkgPDwgNSkgfCBpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IGI6IGIsIHI6IHIgfTtcbn07XG52YXIgX2EgPSBmcmViKGZsZWIsIDIpLCBmbCA9IF9hLmIsIHJldmZsID0gX2Eucjtcbi8vIHdlIGNhbiBpZ25vcmUgdGhlIGZhY3QgdGhhdCB0aGUgb3RoZXIgbnVtYmVycyBhcmUgd3Jvbmc7IHRoZXkgbmV2ZXIgaGFwcGVuIGFueXdheVxuZmxbMjhdID0gMjU4LCByZXZmbFsyNThdID0gMjg7XG52YXIgX2IgPSBmcmViKGZkZWIsIDApLCBmZCA9IF9iLmIsIHJldmZkID0gX2Iucjtcbi8vIG1hcCBvZiB2YWx1ZSB0byByZXZlcnNlIChhc3N1bWluZyAxNiBiaXRzKVxudmFyIHJldiA9IG5ldyB1MTYoMzI3NjgpO1xuZm9yICh2YXIgaSA9IDA7IGkgPCAzMjc2ODsgKytpKSB7XG4gICAgLy8gcmV2ZXJzZSB0YWJsZSBhbGdvcml0aG0gZnJvbSBTT1xuICAgIHZhciB4ID0gKChpICYgMHhBQUFBKSA+PiAxKSB8ICgoaSAmIDB4NTU1NSkgPDwgMSk7XG4gICAgeCA9ICgoeCAmIDB4Q0NDQykgPj4gMikgfCAoKHggJiAweDMzMzMpIDw8IDIpO1xuICAgIHggPSAoKHggJiAweEYwRjApID4+IDQpIHwgKCh4ICYgMHgwRjBGKSA8PCA0KTtcbiAgICByZXZbaV0gPSAoKCh4ICYgMHhGRjAwKSA+PiA4KSB8ICgoeCAmIDB4MDBGRikgPDwgOCkpID4+IDE7XG59XG4vLyBjcmVhdGUgaHVmZm1hbiB0cmVlIGZyb20gdTggXCJtYXBcIjogaW5kZXggLT4gY29kZSBsZW5ndGggZm9yIGNvZGUgaW5kZXhcbi8vIG1iIChtYXggYml0cykgbXVzdCBiZSBhdCBtb3N0IDE1XG4vLyBUT0RPOiBvcHRpbWl6ZS9zcGxpdCB1cD9cbnZhciBoTWFwID0gKGZ1bmN0aW9uIChjZCwgbWIsIHIpIHtcbiAgICB2YXIgcyA9IGNkLmxlbmd0aDtcbiAgICAvLyBpbmRleFxuICAgIHZhciBpID0gMDtcbiAgICAvLyB1MTYgXCJtYXBcIjogaW5kZXggLT4gIyBvZiBjb2RlcyB3aXRoIGJpdCBsZW5ndGggPSBpbmRleFxuICAgIHZhciBsID0gbmV3IHUxNihtYik7XG4gICAgLy8gbGVuZ3RoIG9mIGNkIG11c3QgYmUgMjg4ICh0b3RhbCAjIG9mIGNvZGVzKVxuICAgIGZvciAoOyBpIDwgczsgKytpKSB7XG4gICAgICAgIGlmIChjZFtpXSlcbiAgICAgICAgICAgICsrbFtjZFtpXSAtIDFdO1xuICAgIH1cbiAgICAvLyB1MTYgXCJtYXBcIjogaW5kZXggLT4gbWluaW11bSBjb2RlIGZvciBiaXQgbGVuZ3RoID0gaW5kZXhcbiAgICB2YXIgbGUgPSBuZXcgdTE2KG1iKTtcbiAgICBmb3IgKGkgPSAxOyBpIDwgbWI7ICsraSkge1xuICAgICAgICBsZVtpXSA9IChsZVtpIC0gMV0gKyBsW2kgLSAxXSkgPDwgMTtcbiAgICB9XG4gICAgdmFyIGNvO1xuICAgIGlmIChyKSB7XG4gICAgICAgIC8vIHUxNiBcIm1hcFwiOiBpbmRleCAtPiBudW1iZXIgb2YgYWN0dWFsIGJpdHMsIHN5bWJvbCBmb3IgY29kZVxuICAgICAgICBjbyA9IG5ldyB1MTYoMSA8PCBtYik7XG4gICAgICAgIC8vIGJpdHMgdG8gcmVtb3ZlIGZvciByZXZlcnNlclxuICAgICAgICB2YXIgcnZiID0gMTUgLSBtYjtcbiAgICAgICAgZm9yIChpID0gMDsgaSA8IHM7ICsraSkge1xuICAgICAgICAgICAgLy8gaWdub3JlIDAgbGVuZ3Roc1xuICAgICAgICAgICAgaWYgKGNkW2ldKSB7XG4gICAgICAgICAgICAgICAgLy8gbnVtIGVuY29kaW5nIGJvdGggc3ltYm9sIGFuZCBiaXRzIHJlYWRcbiAgICAgICAgICAgICAgICB2YXIgc3YgPSAoaSA8PCA0KSB8IGNkW2ldO1xuICAgICAgICAgICAgICAgIC8vIGZyZWUgYml0c1xuICAgICAgICAgICAgICAgIHZhciByXzEgPSBtYiAtIGNkW2ldO1xuICAgICAgICAgICAgICAgIC8vIHN0YXJ0IHZhbHVlXG4gICAgICAgICAgICAgICAgdmFyIHYgPSBsZVtjZFtpXSAtIDFdKysgPDwgcl8xO1xuICAgICAgICAgICAgICAgIC8vIG0gaXMgZW5kIHZhbHVlXG4gICAgICAgICAgICAgICAgZm9yICh2YXIgbSA9IHYgfCAoKDEgPDwgcl8xKSAtIDEpOyB2IDw9IG07ICsrdikge1xuICAgICAgICAgICAgICAgICAgICAvLyBldmVyeSAxNiBiaXQgdmFsdWUgc3RhcnRpbmcgd2l0aCB0aGUgY29kZSB5aWVsZHMgdGhlIHNhbWUgcmVzdWx0XG4gICAgICAgICAgICAgICAgICAgIGNvW3Jldlt2XSA+PiBydmJdID0gc3Y7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjbyA9IG5ldyB1MTYocyk7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBzOyArK2kpIHtcbiAgICAgICAgICAgIGlmIChjZFtpXSkge1xuICAgICAgICAgICAgICAgIGNvW2ldID0gcmV2W2xlW2NkW2ldIC0gMV0rK10gPj4gKDE1IC0gY2RbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjbztcbn0pO1xuLy8gZml4ZWQgbGVuZ3RoIHRyZWVcbnZhciBmbHQgPSBuZXcgdTgoMjg4KTtcbmZvciAodmFyIGkgPSAwOyBpIDwgMTQ0OyArK2kpXG4gICAgZmx0W2ldID0gODtcbmZvciAodmFyIGkgPSAxNDQ7IGkgPCAyNTY7ICsraSlcbiAgICBmbHRbaV0gPSA5O1xuZm9yICh2YXIgaSA9IDI1NjsgaSA8IDI4MDsgKytpKVxuICAgIGZsdFtpXSA9IDc7XG5mb3IgKHZhciBpID0gMjgwOyBpIDwgMjg4OyArK2kpXG4gICAgZmx0W2ldID0gODtcbi8vIGZpeGVkIGRpc3RhbmNlIHRyZWVcbnZhciBmZHQgPSBuZXcgdTgoMzIpO1xuZm9yICh2YXIgaSA9IDA7IGkgPCAzMjsgKytpKVxuICAgIGZkdFtpXSA9IDU7XG4vLyBmaXhlZCBsZW5ndGggbWFwXG52YXIgZmxtID0gLyojX19QVVJFX18qLyBoTWFwKGZsdCwgOSwgMCksIGZscm0gPSAvKiNfX1BVUkVfXyovIGhNYXAoZmx0LCA5LCAxKTtcbi8vIGZpeGVkIGRpc3RhbmNlIG1hcFxudmFyIGZkbSA9IC8qI19fUFVSRV9fKi8gaE1hcChmZHQsIDUsIDApLCBmZHJtID0gLyojX19QVVJFX18qLyBoTWFwKGZkdCwgNSwgMSk7XG4vLyBmaW5kIG1heCBvZiBhcnJheVxudmFyIG1heCA9IGZ1bmN0aW9uIChhKSB7XG4gICAgdmFyIG0gPSBhWzBdO1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYS5sZW5ndGg7ICsraSkge1xuICAgICAgICBpZiAoYVtpXSA+IG0pXG4gICAgICAgICAgICBtID0gYVtpXTtcbiAgICB9XG4gICAgcmV0dXJuIG07XG59O1xuLy8gcmVhZCBkLCBzdGFydGluZyBhdCBiaXQgcCBhbmQgbWFzayB3aXRoIG1cbnZhciBiaXRzID0gZnVuY3Rpb24gKGQsIHAsIG0pIHtcbiAgICB2YXIgbyA9IChwIC8gOCkgfCAwO1xuICAgIHJldHVybiAoKGRbb10gfCAoZFtvICsgMV0gPDwgOCkpID4+IChwICYgNykpICYgbTtcbn07XG4vLyByZWFkIGQsIHN0YXJ0aW5nIGF0IGJpdCBwIGNvbnRpbnVpbmcgZm9yIGF0IGxlYXN0IDE2IGJpdHNcbnZhciBiaXRzMTYgPSBmdW5jdGlvbiAoZCwgcCkge1xuICAgIHZhciBvID0gKHAgLyA4KSB8IDA7XG4gICAgcmV0dXJuICgoZFtvXSB8IChkW28gKyAxXSA8PCA4KSB8IChkW28gKyAyXSA8PCAxNikpID4+IChwICYgNykpO1xufTtcbi8vIGdldCBlbmQgb2YgYnl0ZVxudmFyIHNoZnQgPSBmdW5jdGlvbiAocCkgeyByZXR1cm4gKChwICsgNykgLyA4KSB8IDA7IH07XG4vLyB0eXBlZCBhcnJheSBzbGljZSAtIGFsbG93cyBnYXJiYWdlIGNvbGxlY3RvciB0byBmcmVlIG9yaWdpbmFsIHJlZmVyZW5jZSxcbi8vIHdoaWxlIGJlaW5nIG1vcmUgY29tcGF0aWJsZSB0aGFuIC5zbGljZVxudmFyIHNsYyA9IGZ1bmN0aW9uICh2LCBzLCBlKSB7XG4gICAgaWYgKHMgPT0gbnVsbCB8fCBzIDwgMClcbiAgICAgICAgcyA9IDA7XG4gICAgaWYgKGUgPT0gbnVsbCB8fCBlID4gdi5sZW5ndGgpXG4gICAgICAgIGUgPSB2Lmxlbmd0aDtcbiAgICAvLyBjYW4ndCB1c2UgLmNvbnN0cnVjdG9yIGluIGNhc2UgdXNlci1zdXBwbGllZFxuICAgIHJldHVybiBuZXcgdTgodi5zdWJhcnJheShzLCBlKSk7XG59O1xuLyoqXG4gKiBDb2RlcyBmb3IgZXJyb3JzIGdlbmVyYXRlZCB3aXRoaW4gdGhpcyBsaWJyYXJ5XG4gKi9cbmV4cG9ydCB2YXIgRmxhdGVFcnJvckNvZGUgPSB7XG4gICAgVW5leHBlY3RlZEVPRjogMCxcbiAgICBJbnZhbGlkQmxvY2tUeXBlOiAxLFxuICAgIEludmFsaWRMZW5ndGhMaXRlcmFsOiAyLFxuICAgIEludmFsaWREaXN0YW5jZTogMyxcbiAgICBTdHJlYW1GaW5pc2hlZDogNCxcbiAgICBOb1N0cmVhbUhhbmRsZXI6IDUsXG4gICAgSW52YWxpZEhlYWRlcjogNixcbiAgICBOb0NhbGxiYWNrOiA3LFxuICAgIEludmFsaWRVVEY4OiA4LFxuICAgIEV4dHJhRmllbGRUb29Mb25nOiA5LFxuICAgIEludmFsaWREYXRlOiAxMCxcbiAgICBGaWxlbmFtZVRvb0xvbmc6IDExLFxuICAgIFN0cmVhbUZpbmlzaGluZzogMTIsXG4gICAgSW52YWxpZFppcERhdGE6IDEzLFxuICAgIFVua25vd25Db21wcmVzc2lvbk1ldGhvZDogMTRcbn07XG4vLyBlcnJvciBjb2Rlc1xudmFyIGVjID0gW1xuICAgICd1bmV4cGVjdGVkIEVPRicsXG4gICAgJ2ludmFsaWQgYmxvY2sgdHlwZScsXG4gICAgJ2ludmFsaWQgbGVuZ3RoL2xpdGVyYWwnLFxuICAgICdpbnZhbGlkIGRpc3RhbmNlJyxcbiAgICAnc3RyZWFtIGZpbmlzaGVkJyxcbiAgICAnbm8gc3RyZWFtIGhhbmRsZXInLFxuICAgICwgLy8gZGV0ZXJtaW5lZCBieSBjb21wcmVzc2lvbiBmdW5jdGlvblxuICAgICdubyBjYWxsYmFjaycsXG4gICAgJ2ludmFsaWQgVVRGLTggZGF0YScsXG4gICAgJ2V4dHJhIGZpZWxkIHRvbyBsb25nJyxcbiAgICAnZGF0ZSBub3QgaW4gcmFuZ2UgMTk4MC0yMDk5JyxcbiAgICAnZmlsZW5hbWUgdG9vIGxvbmcnLFxuICAgICdzdHJlYW0gZmluaXNoaW5nJyxcbiAgICAnaW52YWxpZCB6aXAgZGF0YSdcbiAgICAvLyBkZXRlcm1pbmVkIGJ5IHVua25vd24gY29tcHJlc3Npb24gbWV0aG9kXG5dO1xuO1xudmFyIGVyciA9IGZ1bmN0aW9uIChpbmQsIG1zZywgbnQpIHtcbiAgICB2YXIgZSA9IG5ldyBFcnJvcihtc2cgfHwgZWNbaW5kXSk7XG4gICAgZS5jb2RlID0gaW5kO1xuICAgIGlmIChFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSlcbiAgICAgICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UoZSwgZXJyKTtcbiAgICBpZiAoIW50KVxuICAgICAgICB0aHJvdyBlO1xuICAgIHJldHVybiBlO1xufTtcbi8vIGV4cGFuZHMgcmF3IERFRkxBVEUgZGF0YVxudmFyIGluZmx0ID0gZnVuY3Rpb24gKGRhdCwgc3QsIGJ1ZiwgZGljdCkge1xuICAgIC8vIHNvdXJjZSBsZW5ndGggICAgICAgZGljdCBsZW5ndGhcbiAgICB2YXIgc2wgPSBkYXQubGVuZ3RoLCBkbCA9IGRpY3QgPyBkaWN0Lmxlbmd0aCA6IDA7XG4gICAgaWYgKCFzbCB8fCBzdC5mICYmICFzdC5sKVxuICAgICAgICByZXR1cm4gYnVmIHx8IG5ldyB1OCgwKTtcbiAgICB2YXIgbm9CdWYgPSAhYnVmO1xuICAgIC8vIGhhdmUgdG8gZXN0aW1hdGUgc2l6ZVxuICAgIHZhciByZXNpemUgPSBub0J1ZiB8fCBzdC5pICE9IDI7XG4gICAgLy8gbm8gc3RhdGVcbiAgICB2YXIgbm9TdCA9IHN0Lmk7XG4gICAgLy8gQXNzdW1lcyByb3VnaGx5IDMzJSBjb21wcmVzc2lvbiByYXRpbyBhdmVyYWdlXG4gICAgaWYgKG5vQnVmKVxuICAgICAgICBidWYgPSBuZXcgdTgoc2wgKiAzKTtcbiAgICAvLyBlbnN1cmUgYnVmZmVyIGNhbiBmaXQgYXQgbGVhc3QgbCBlbGVtZW50c1xuICAgIHZhciBjYnVmID0gZnVuY3Rpb24gKGwpIHtcbiAgICAgICAgdmFyIGJsID0gYnVmLmxlbmd0aDtcbiAgICAgICAgLy8gbmVlZCB0byBpbmNyZWFzZSBzaXplIHRvIGZpdFxuICAgICAgICBpZiAobCA+IGJsKSB7XG4gICAgICAgICAgICAvLyBEb3VibGUgb3Igc2V0IHRvIG5lY2Vzc2FyeSwgd2hpY2hldmVyIGlzIGdyZWF0ZXJcbiAgICAgICAgICAgIHZhciBuYnVmID0gbmV3IHU4KE1hdGgubWF4KGJsICogMiwgbCkpO1xuICAgICAgICAgICAgbmJ1Zi5zZXQoYnVmKTtcbiAgICAgICAgICAgIGJ1ZiA9IG5idWY7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vICBsYXN0IGNodW5rICAgICAgICAgYml0cG9zICAgICAgICAgICBieXRlc1xuICAgIHZhciBmaW5hbCA9IHN0LmYgfHwgMCwgcG9zID0gc3QucCB8fCAwLCBidCA9IHN0LmIgfHwgMCwgbG0gPSBzdC5sLCBkbSA9IHN0LmQsIGxidCA9IHN0Lm0sIGRidCA9IHN0Lm47XG4gICAgLy8gdG90YWwgYml0c1xuICAgIHZhciB0YnRzID0gc2wgKiA4O1xuICAgIGRvIHtcbiAgICAgICAgaWYgKCFsbSkge1xuICAgICAgICAgICAgLy8gQkZJTkFMIC0gdGhpcyBpcyBvbmx5IDEgd2hlbiBsYXN0IGNodW5rIGlzIG5leHRcbiAgICAgICAgICAgIGZpbmFsID0gYml0cyhkYXQsIHBvcywgMSk7XG4gICAgICAgICAgICAvLyB0eXBlOiAwID0gbm8gY29tcHJlc3Npb24sIDEgPSBmaXhlZCBodWZmbWFuLCAyID0gZHluYW1pYyBodWZmbWFuXG4gICAgICAgICAgICB2YXIgdHlwZSA9IGJpdHMoZGF0LCBwb3MgKyAxLCAzKTtcbiAgICAgICAgICAgIHBvcyArPSAzO1xuICAgICAgICAgICAgaWYgKCF0eXBlKSB7XG4gICAgICAgICAgICAgICAgLy8gZ28gdG8gZW5kIG9mIGJ5dGUgYm91bmRhcnlcbiAgICAgICAgICAgICAgICB2YXIgcyA9IHNoZnQocG9zKSArIDQsIGwgPSBkYXRbcyAtIDRdIHwgKGRhdFtzIC0gM10gPDwgOCksIHQgPSBzICsgbDtcbiAgICAgICAgICAgICAgICBpZiAodCA+IHNsKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChub1N0KVxuICAgICAgICAgICAgICAgICAgICAgICAgZXJyKDApO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gZW5zdXJlIHNpemVcbiAgICAgICAgICAgICAgICBpZiAocmVzaXplKVxuICAgICAgICAgICAgICAgICAgICBjYnVmKGJ0ICsgbCk7XG4gICAgICAgICAgICAgICAgLy8gQ29weSBvdmVyIHVuY29tcHJlc3NlZCBkYXRhXG4gICAgICAgICAgICAgICAgYnVmLnNldChkYXQuc3ViYXJyYXkocywgdCksIGJ0KTtcbiAgICAgICAgICAgICAgICAvLyBHZXQgbmV3IGJpdHBvcywgdXBkYXRlIGJ5dGUgY291bnRcbiAgICAgICAgICAgICAgICBzdC5iID0gYnQgKz0gbCwgc3QucCA9IHBvcyA9IHQgKiA4LCBzdC5mID0gZmluYWw7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlID09IDEpXG4gICAgICAgICAgICAgICAgbG0gPSBmbHJtLCBkbSA9IGZkcm0sIGxidCA9IDksIGRidCA9IDU7XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlID09IDIpIHtcbiAgICAgICAgICAgICAgICAvLyAgbGl0ZXJhbCAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZW5ndGhzXG4gICAgICAgICAgICAgICAgdmFyIGhMaXQgPSBiaXRzKGRhdCwgcG9zLCAzMSkgKyAyNTcsIGhjTGVuID0gYml0cyhkYXQsIHBvcyArIDEwLCAxNSkgKyA0O1xuICAgICAgICAgICAgICAgIHZhciB0bCA9IGhMaXQgKyBiaXRzKGRhdCwgcG9zICsgNSwgMzEpICsgMTtcbiAgICAgICAgICAgICAgICBwb3MgKz0gMTQ7XG4gICAgICAgICAgICAgICAgLy8gbGVuZ3RoK2Rpc3RhbmNlIHRyZWVcbiAgICAgICAgICAgICAgICB2YXIgbGR0ID0gbmV3IHU4KHRsKTtcbiAgICAgICAgICAgICAgICAvLyBjb2RlIGxlbmd0aCB0cmVlXG4gICAgICAgICAgICAgICAgdmFyIGNsdCA9IG5ldyB1OCgxOSk7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBoY0xlbjsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIHVzZSBpbmRleCBtYXAgdG8gZ2V0IHJlYWwgY29kZVxuICAgICAgICAgICAgICAgICAgICBjbHRbY2xpbVtpXV0gPSBiaXRzKGRhdCwgcG9zICsgaSAqIDMsIDcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBwb3MgKz0gaGNMZW4gKiAzO1xuICAgICAgICAgICAgICAgIC8vIGNvZGUgbGVuZ3RocyBiaXRzXG4gICAgICAgICAgICAgICAgdmFyIGNsYiA9IG1heChjbHQpLCBjbGJtc2sgPSAoMSA8PCBjbGIpIC0gMTtcbiAgICAgICAgICAgICAgICAvLyBjb2RlIGxlbmd0aHMgbWFwXG4gICAgICAgICAgICAgICAgdmFyIGNsbSA9IGhNYXAoY2x0LCBjbGIsIDEpO1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGw7KSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByID0gY2xtW2JpdHMoZGF0LCBwb3MsIGNsYm1zayldO1xuICAgICAgICAgICAgICAgICAgICAvLyBiaXRzIHJlYWRcbiAgICAgICAgICAgICAgICAgICAgcG9zICs9IHIgJiAxNTtcbiAgICAgICAgICAgICAgICAgICAgLy8gc3ltYm9sXG4gICAgICAgICAgICAgICAgICAgIHZhciBzID0gciA+PiA0O1xuICAgICAgICAgICAgICAgICAgICAvLyBjb2RlIGxlbmd0aCB0byBjb3B5XG4gICAgICAgICAgICAgICAgICAgIGlmIChzIDwgMTYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxkdFtpKytdID0gcztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICBjb3B5ICAgY291bnRcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjID0gMCwgbiA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocyA9PSAxNilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuID0gMyArIGJpdHMoZGF0LCBwb3MsIDMpLCBwb3MgKz0gMiwgYyA9IGxkdFtpIC0gMV07XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChzID09IDE3KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG4gPSAzICsgYml0cyhkYXQsIHBvcywgNyksIHBvcyArPSAzO1xuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAocyA9PSAxOClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuID0gMTEgKyBiaXRzKGRhdCwgcG9zLCAxMjcpLCBwb3MgKz0gNztcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlIChuLS0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGR0W2krK10gPSBjO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vICAgIGxlbmd0aCB0cmVlICAgICAgICAgICAgICAgICBkaXN0YW5jZSB0cmVlXG4gICAgICAgICAgICAgICAgdmFyIGx0ID0gbGR0LnN1YmFycmF5KDAsIGhMaXQpLCBkdCA9IGxkdC5zdWJhcnJheShoTGl0KTtcbiAgICAgICAgICAgICAgICAvLyBtYXggbGVuZ3RoIGJpdHNcbiAgICAgICAgICAgICAgICBsYnQgPSBtYXgobHQpO1xuICAgICAgICAgICAgICAgIC8vIG1heCBkaXN0IGJpdHNcbiAgICAgICAgICAgICAgICBkYnQgPSBtYXgoZHQpO1xuICAgICAgICAgICAgICAgIGxtID0gaE1hcChsdCwgbGJ0LCAxKTtcbiAgICAgICAgICAgICAgICBkbSA9IGhNYXAoZHQsIGRidCwgMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgZXJyKDEpO1xuICAgICAgICAgICAgaWYgKHBvcyA+IHRidHMpIHtcbiAgICAgICAgICAgICAgICBpZiAobm9TdClcbiAgICAgICAgICAgICAgICAgICAgZXJyKDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIE1ha2Ugc3VyZSB0aGUgYnVmZmVyIGNhbiBob2xkIHRoaXMgKyB0aGUgbGFyZ2VzdCBwb3NzaWJsZSBhZGRpdGlvblxuICAgICAgICAvLyBNYXhpbXVtIGNodW5rIHNpemUgKHByYWN0aWNhbGx5LCB0aGVvcmV0aWNhbGx5IGluZmluaXRlKSBpcyAyXjE3XG4gICAgICAgIGlmIChyZXNpemUpXG4gICAgICAgICAgICBjYnVmKGJ0ICsgMTMxMDcyKTtcbiAgICAgICAgdmFyIGxtcyA9ICgxIDw8IGxidCkgLSAxLCBkbXMgPSAoMSA8PCBkYnQpIC0gMTtcbiAgICAgICAgdmFyIGxwb3MgPSBwb3M7XG4gICAgICAgIGZvciAoOzsgbHBvcyA9IHBvcykge1xuICAgICAgICAgICAgLy8gYml0cyByZWFkLCBjb2RlXG4gICAgICAgICAgICB2YXIgYyA9IGxtW2JpdHMxNihkYXQsIHBvcykgJiBsbXNdLCBzeW0gPSBjID4+IDQ7XG4gICAgICAgICAgICBwb3MgKz0gYyAmIDE1O1xuICAgICAgICAgICAgaWYgKHBvcyA+IHRidHMpIHtcbiAgICAgICAgICAgICAgICBpZiAobm9TdClcbiAgICAgICAgICAgICAgICAgICAgZXJyKDApO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFjKVxuICAgICAgICAgICAgICAgIGVycigyKTtcbiAgICAgICAgICAgIGlmIChzeW0gPCAyNTYpXG4gICAgICAgICAgICAgICAgYnVmW2J0KytdID0gc3ltO1xuICAgICAgICAgICAgZWxzZSBpZiAoc3ltID09IDI1Nikge1xuICAgICAgICAgICAgICAgIGxwb3MgPSBwb3MsIGxtID0gbnVsbDtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHZhciBhZGQgPSBzeW0gLSAyNTQ7XG4gICAgICAgICAgICAgICAgLy8gbm8gZXh0cmEgYml0cyBuZWVkZWQgaWYgbGVzc1xuICAgICAgICAgICAgICAgIGlmIChzeW0gPiAyNjQpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gaW5kZXhcbiAgICAgICAgICAgICAgICAgICAgdmFyIGkgPSBzeW0gLSAyNTcsIGIgPSBmbGViW2ldO1xuICAgICAgICAgICAgICAgICAgICBhZGQgPSBiaXRzKGRhdCwgcG9zLCAoMSA8PCBiKSAtIDEpICsgZmxbaV07XG4gICAgICAgICAgICAgICAgICAgIHBvcyArPSBiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBkaXN0XG4gICAgICAgICAgICAgICAgdmFyIGQgPSBkbVtiaXRzMTYoZGF0LCBwb3MpICYgZG1zXSwgZHN5bSA9IGQgPj4gNDtcbiAgICAgICAgICAgICAgICBpZiAoIWQpXG4gICAgICAgICAgICAgICAgICAgIGVycigzKTtcbiAgICAgICAgICAgICAgICBwb3MgKz0gZCAmIDE1O1xuICAgICAgICAgICAgICAgIHZhciBkdCA9IGZkW2RzeW1dO1xuICAgICAgICAgICAgICAgIGlmIChkc3ltID4gMykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYiA9IGZkZWJbZHN5bV07XG4gICAgICAgICAgICAgICAgICAgIGR0ICs9IGJpdHMxNihkYXQsIHBvcykgJiAoMSA8PCBiKSAtIDEsIHBvcyArPSBiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocG9zID4gdGJ0cykge1xuICAgICAgICAgICAgICAgICAgICBpZiAobm9TdClcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycigwKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChyZXNpemUpXG4gICAgICAgICAgICAgICAgICAgIGNidWYoYnQgKyAxMzEwNzIpO1xuICAgICAgICAgICAgICAgIHZhciBlbmQgPSBidCArIGFkZDtcbiAgICAgICAgICAgICAgICBpZiAoYnQgPCBkdCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgc2hpZnQgPSBkbCAtIGR0LCBkZW5kID0gTWF0aC5taW4oZHQsIGVuZCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzaGlmdCArIGJ0IDwgMClcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycigzKTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICg7IGJ0IDwgZGVuZDsgKytidClcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1ZltidF0gPSBkaWN0W3NoaWZ0ICsgYnRdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBmb3IgKDsgYnQgPCBlbmQ7ICsrYnQpXG4gICAgICAgICAgICAgICAgICAgIGJ1ZltidF0gPSBidWZbYnQgLSBkdF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgc3QubCA9IGxtLCBzdC5wID0gbHBvcywgc3QuYiA9IGJ0LCBzdC5mID0gZmluYWw7XG4gICAgICAgIGlmIChsbSlcbiAgICAgICAgICAgIGZpbmFsID0gMSwgc3QubSA9IGxidCwgc3QuZCA9IGRtLCBzdC5uID0gZGJ0O1xuICAgIH0gd2hpbGUgKCFmaW5hbCk7XG4gICAgLy8gZG9uJ3QgcmVhbGxvY2F0ZSBmb3Igc3RyZWFtcyBvciB1c2VyIGJ1ZmZlcnNcbiAgICByZXR1cm4gYnQgIT0gYnVmLmxlbmd0aCAmJiBub0J1ZiA/IHNsYyhidWYsIDAsIGJ0KSA6IGJ1Zi5zdWJhcnJheSgwLCBidCk7XG59O1xuLy8gc3RhcnRpbmcgYXQgcCwgd3JpdGUgdGhlIG1pbmltdW0gbnVtYmVyIG9mIGJpdHMgdGhhdCBjYW4gaG9sZCB2IHRvIGRcbnZhciB3Yml0cyA9IGZ1bmN0aW9uIChkLCBwLCB2KSB7XG4gICAgdiA8PD0gcCAmIDc7XG4gICAgdmFyIG8gPSAocCAvIDgpIHwgMDtcbiAgICBkW29dIHw9IHY7XG4gICAgZFtvICsgMV0gfD0gdiA+PiA4O1xufTtcbi8vIHN0YXJ0aW5nIGF0IHAsIHdyaXRlIHRoZSBtaW5pbXVtIG51bWJlciBvZiBiaXRzICg+OCkgdGhhdCBjYW4gaG9sZCB2IHRvIGRcbnZhciB3Yml0czE2ID0gZnVuY3Rpb24gKGQsIHAsIHYpIHtcbiAgICB2IDw8PSBwICYgNztcbiAgICB2YXIgbyA9IChwIC8gOCkgfCAwO1xuICAgIGRbb10gfD0gdjtcbiAgICBkW28gKyAxXSB8PSB2ID4+IDg7XG4gICAgZFtvICsgMl0gfD0gdiA+PiAxNjtcbn07XG4vLyBjcmVhdGVzIGNvZGUgbGVuZ3RocyBmcm9tIGEgZnJlcXVlbmN5IHRhYmxlXG52YXIgaFRyZWUgPSBmdW5jdGlvbiAoZCwgbWIpIHtcbiAgICAvLyBOZWVkIGV4dHJhIGluZm8gdG8gbWFrZSBhIHRyZWVcbiAgICB2YXIgdCA9IFtdO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZC5sZW5ndGg7ICsraSkge1xuICAgICAgICBpZiAoZFtpXSlcbiAgICAgICAgICAgIHQucHVzaCh7IHM6IGksIGY6IGRbaV0gfSk7XG4gICAgfVxuICAgIHZhciBzID0gdC5sZW5ndGg7XG4gICAgdmFyIHQyID0gdC5zbGljZSgpO1xuICAgIGlmICghcylcbiAgICAgICAgcmV0dXJuIHsgdDogZXQsIGw6IDAgfTtcbiAgICBpZiAocyA9PSAxKSB7XG4gICAgICAgIHZhciB2ID0gbmV3IHU4KHRbMF0ucyArIDEpO1xuICAgICAgICB2W3RbMF0uc10gPSAxO1xuICAgICAgICByZXR1cm4geyB0OiB2LCBsOiAxIH07XG4gICAgfVxuICAgIHQuc29ydChmdW5jdGlvbiAoYSwgYikgeyByZXR1cm4gYS5mIC0gYi5mOyB9KTtcbiAgICAvLyBhZnRlciBpMiByZWFjaGVzIGxhc3QgaW5kLCB3aWxsIGJlIHN0b3BwZWRcbiAgICAvLyBmcmVxIG11c3QgYmUgZ3JlYXRlciB0aGFuIGxhcmdlc3QgcG9zc2libGUgbnVtYmVyIG9mIHN5bWJvbHNcbiAgICB0LnB1c2goeyBzOiAtMSwgZjogMjUwMDEgfSk7XG4gICAgdmFyIGwgPSB0WzBdLCByID0gdFsxXSwgaTAgPSAwLCBpMSA9IDEsIGkyID0gMjtcbiAgICB0WzBdID0geyBzOiAtMSwgZjogbC5mICsgci5mLCBsOiBsLCByOiByIH07XG4gICAgLy8gZWZmaWNpZW50IGFsZ29yaXRobSBmcm9tIFVaSVAuanNcbiAgICAvLyBpMCBpcyBsb29rYmVoaW5kLCBpMiBpcyBsb29rYWhlYWQgLSBhZnRlciBwcm9jZXNzaW5nIHR3byBsb3ctZnJlcVxuICAgIC8vIHN5bWJvbHMgdGhhdCBjb21iaW5lZCBoYXZlIGhpZ2ggZnJlcSwgd2lsbCBzdGFydCBwcm9jZXNzaW5nIGkyIChoaWdoLWZyZXEsXG4gICAgLy8gbm9uLWNvbXBvc2l0ZSkgc3ltYm9scyBpbnN0ZWFkXG4gICAgLy8gc2VlIGh0dHBzOi8vcmVkZGl0LmNvbS9yL3Bob3RvcGVhL2NvbW1lbnRzL2lrZWtodC91emlwanNfcXVlc3Rpb25zL1xuICAgIHdoaWxlIChpMSAhPSBzIC0gMSkge1xuICAgICAgICBsID0gdFt0W2kwXS5mIDwgdFtpMl0uZiA/IGkwKysgOiBpMisrXTtcbiAgICAgICAgciA9IHRbaTAgIT0gaTEgJiYgdFtpMF0uZiA8IHRbaTJdLmYgPyBpMCsrIDogaTIrK107XG4gICAgICAgIHRbaTErK10gPSB7IHM6IC0xLCBmOiBsLmYgKyByLmYsIGw6IGwsIHI6IHIgfTtcbiAgICB9XG4gICAgdmFyIG1heFN5bSA9IHQyWzBdLnM7XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBzOyArK2kpIHtcbiAgICAgICAgaWYgKHQyW2ldLnMgPiBtYXhTeW0pXG4gICAgICAgICAgICBtYXhTeW0gPSB0MltpXS5zO1xuICAgIH1cbiAgICAvLyBjb2RlIGxlbmd0aHNcbiAgICB2YXIgdHIgPSBuZXcgdTE2KG1heFN5bSArIDEpO1xuICAgIC8vIG1heCBiaXRzIGluIHRyZWVcbiAgICB2YXIgbWJ0ID0gbG4odFtpMSAtIDFdLCB0ciwgMCk7XG4gICAgaWYgKG1idCA+IG1iKSB7XG4gICAgICAgIC8vIG1vcmUgYWxnb3JpdGhtcyBmcm9tIFVaSVAuanNcbiAgICAgICAgLy8gVE9ETzogZmluZCBvdXQgaG93IHRoaXMgY29kZSB3b3JrcyAoZGVidClcbiAgICAgICAgLy8gIGluZCAgICBkZWJ0XG4gICAgICAgIHZhciBpID0gMCwgZHQgPSAwO1xuICAgICAgICAvLyAgICBsZWZ0ICAgICAgICAgICAgY29zdFxuICAgICAgICB2YXIgbGZ0ID0gbWJ0IC0gbWIsIGNzdCA9IDEgPDwgbGZ0O1xuICAgICAgICB0Mi5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiB0cltiLnNdIC0gdHJbYS5zXSB8fCBhLmYgLSBiLmY7IH0pO1xuICAgICAgICBmb3IgKDsgaSA8IHM7ICsraSkge1xuICAgICAgICAgICAgdmFyIGkyXzEgPSB0MltpXS5zO1xuICAgICAgICAgICAgaWYgKHRyW2kyXzFdID4gbWIpIHtcbiAgICAgICAgICAgICAgICBkdCArPSBjc3QgLSAoMSA8PCAobWJ0IC0gdHJbaTJfMV0pKTtcbiAgICAgICAgICAgICAgICB0cltpMl8xXSA9IG1iO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGR0ID4+PSBsZnQ7XG4gICAgICAgIHdoaWxlIChkdCA+IDApIHtcbiAgICAgICAgICAgIHZhciBpMl8yID0gdDJbaV0ucztcbiAgICAgICAgICAgIGlmICh0cltpMl8yXSA8IG1iKVxuICAgICAgICAgICAgICAgIGR0IC09IDEgPDwgKG1iIC0gdHJbaTJfMl0rKyAtIDEpO1xuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICsraTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKDsgaSA+PSAwICYmIGR0OyAtLWkpIHtcbiAgICAgICAgICAgIHZhciBpMl8zID0gdDJbaV0ucztcbiAgICAgICAgICAgIGlmICh0cltpMl8zXSA9PSBtYikge1xuICAgICAgICAgICAgICAgIC0tdHJbaTJfM107XG4gICAgICAgICAgICAgICAgKytkdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtYnQgPSBtYjtcbiAgICB9XG4gICAgcmV0dXJuIHsgdDogbmV3IHU4KHRyKSwgbDogbWJ0IH07XG59O1xuLy8gZ2V0IHRoZSBtYXggbGVuZ3RoIGFuZCBhc3NpZ24gbGVuZ3RoIGNvZGVzXG52YXIgbG4gPSBmdW5jdGlvbiAobiwgbCwgZCkge1xuICAgIHJldHVybiBuLnMgPT0gLTFcbiAgICAgICAgPyBNYXRoLm1heChsbihuLmwsIGwsIGQgKyAxKSwgbG4obi5yLCBsLCBkICsgMSkpXG4gICAgICAgIDogKGxbbi5zXSA9IGQpO1xufTtcbi8vIGxlbmd0aCBjb2RlcyBnZW5lcmF0aW9uXG52YXIgbGMgPSBmdW5jdGlvbiAoYykge1xuICAgIHZhciBzID0gYy5sZW5ndGg7XG4gICAgLy8gTm90ZSB0aGF0IHRoZSBzZW1pY29sb24gd2FzIGludGVudGlvbmFsXG4gICAgd2hpbGUgKHMgJiYgIWNbLS1zXSlcbiAgICAgICAgO1xuICAgIHZhciBjbCA9IG5ldyB1MTYoKytzKTtcbiAgICAvLyAgaW5kICAgICAgbnVtICAgICAgICAgc3RyZWFrXG4gICAgdmFyIGNsaSA9IDAsIGNsbiA9IGNbMF0sIGNscyA9IDE7XG4gICAgdmFyIHcgPSBmdW5jdGlvbiAodikgeyBjbFtjbGkrK10gPSB2OyB9O1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDw9IHM7ICsraSkge1xuICAgICAgICBpZiAoY1tpXSA9PSBjbG4gJiYgaSAhPSBzKVxuICAgICAgICAgICAgKytjbHM7XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgaWYgKCFjbG4gJiYgY2xzID4gMikge1xuICAgICAgICAgICAgICAgIGZvciAoOyBjbHMgPiAxMzg7IGNscyAtPSAxMzgpXG4gICAgICAgICAgICAgICAgICAgIHcoMzI3NTQpO1xuICAgICAgICAgICAgICAgIGlmIChjbHMgPiAyKSB7XG4gICAgICAgICAgICAgICAgICAgIHcoY2xzID4gMTAgPyAoKGNscyAtIDExKSA8PCA1KSB8IDI4NjkwIDogKChjbHMgLSAzKSA8PCA1KSB8IDEyMzA1KTtcbiAgICAgICAgICAgICAgICAgICAgY2xzID0gMDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjbHMgPiAzKSB7XG4gICAgICAgICAgICAgICAgdyhjbG4pLCAtLWNscztcbiAgICAgICAgICAgICAgICBmb3IgKDsgY2xzID4gNjsgY2xzIC09IDYpXG4gICAgICAgICAgICAgICAgICAgIHcoODMwNCk7XG4gICAgICAgICAgICAgICAgaWYgKGNscyA+IDIpXG4gICAgICAgICAgICAgICAgICAgIHcoKChjbHMgLSAzKSA8PCA1KSB8IDgyMDgpLCBjbHMgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgd2hpbGUgKGNscy0tKVxuICAgICAgICAgICAgICAgIHcoY2xuKTtcbiAgICAgICAgICAgIGNscyA9IDE7XG4gICAgICAgICAgICBjbG4gPSBjW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IGM6IGNsLnN1YmFycmF5KDAsIGNsaSksIG46IHMgfTtcbn07XG4vLyBjYWxjdWxhdGUgdGhlIGxlbmd0aCBvZiBvdXRwdXQgZnJvbSB0cmVlLCBjb2RlIGxlbmd0aHNcbnZhciBjbGVuID0gZnVuY3Rpb24gKGNmLCBjbCkge1xuICAgIHZhciBsID0gMDtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGNsLmxlbmd0aDsgKytpKVxuICAgICAgICBsICs9IGNmW2ldICogY2xbaV07XG4gICAgcmV0dXJuIGw7XG59O1xuLy8gd3JpdGVzIGEgZml4ZWQgYmxvY2tcbi8vIHJldHVybnMgdGhlIG5ldyBiaXQgcG9zXG52YXIgd2ZibGsgPSBmdW5jdGlvbiAob3V0LCBwb3MsIGRhdCkge1xuICAgIC8vIG5vIG5lZWQgdG8gd3JpdGUgMDAgYXMgdHlwZTogVHlwZWRBcnJheSBkZWZhdWx0cyB0byAwXG4gICAgdmFyIHMgPSBkYXQubGVuZ3RoO1xuICAgIHZhciBvID0gc2hmdChwb3MgKyAyKTtcbiAgICBvdXRbb10gPSBzICYgMjU1O1xuICAgIG91dFtvICsgMV0gPSBzID4+IDg7XG4gICAgb3V0W28gKyAyXSA9IG91dFtvXSBeIDI1NTtcbiAgICBvdXRbbyArIDNdID0gb3V0W28gKyAxXSBeIDI1NTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHM7ICsraSlcbiAgICAgICAgb3V0W28gKyBpICsgNF0gPSBkYXRbaV07XG4gICAgcmV0dXJuIChvICsgNCArIHMpICogODtcbn07XG4vLyB3cml0ZXMgYSBibG9ja1xudmFyIHdibGsgPSBmdW5jdGlvbiAoZGF0LCBvdXQsIGZpbmFsLCBzeW1zLCBsZiwgZGYsIGViLCBsaSwgYnMsIGJsLCBwKSB7XG4gICAgd2JpdHMob3V0LCBwKyssIGZpbmFsKTtcbiAgICArK2xmWzI1Nl07XG4gICAgdmFyIF9hID0gaFRyZWUobGYsIDE1KSwgZGx0ID0gX2EudCwgbWxiID0gX2EubDtcbiAgICB2YXIgX2IgPSBoVHJlZShkZiwgMTUpLCBkZHQgPSBfYi50LCBtZGIgPSBfYi5sO1xuICAgIHZhciBfYyA9IGxjKGRsdCksIGxjbHQgPSBfYy5jLCBubGMgPSBfYy5uO1xuICAgIHZhciBfZCA9IGxjKGRkdCksIGxjZHQgPSBfZC5jLCBuZGMgPSBfZC5uO1xuICAgIHZhciBsY2ZyZXEgPSBuZXcgdTE2KDE5KTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxjbHQubGVuZ3RoOyArK2kpXG4gICAgICAgICsrbGNmcmVxW2xjbHRbaV0gJiAzMV07XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsY2R0Lmxlbmd0aDsgKytpKVxuICAgICAgICArK2xjZnJlcVtsY2R0W2ldICYgMzFdO1xuICAgIHZhciBfZSA9IGhUcmVlKGxjZnJlcSwgNyksIGxjdCA9IF9lLnQsIG1sY2IgPSBfZS5sO1xuICAgIHZhciBubGNjID0gMTk7XG4gICAgZm9yICg7IG5sY2MgPiA0ICYmICFsY3RbY2xpbVtubGNjIC0gMV1dOyAtLW5sY2MpXG4gICAgICAgIDtcbiAgICB2YXIgZmxlbiA9IChibCArIDUpIDw8IDM7XG4gICAgdmFyIGZ0bGVuID0gY2xlbihsZiwgZmx0KSArIGNsZW4oZGYsIGZkdCkgKyBlYjtcbiAgICB2YXIgZHRsZW4gPSBjbGVuKGxmLCBkbHQpICsgY2xlbihkZiwgZGR0KSArIGViICsgMTQgKyAzICogbmxjYyArIGNsZW4obGNmcmVxLCBsY3QpICsgMiAqIGxjZnJlcVsxNl0gKyAzICogbGNmcmVxWzE3XSArIDcgKiBsY2ZyZXFbMThdO1xuICAgIGlmIChicyA+PSAwICYmIGZsZW4gPD0gZnRsZW4gJiYgZmxlbiA8PSBkdGxlbilcbiAgICAgICAgcmV0dXJuIHdmYmxrKG91dCwgcCwgZGF0LnN1YmFycmF5KGJzLCBicyArIGJsKSk7XG4gICAgdmFyIGxtLCBsbCwgZG0sIGRsO1xuICAgIHdiaXRzKG91dCwgcCwgMSArIChkdGxlbiA8IGZ0bGVuKSksIHAgKz0gMjtcbiAgICBpZiAoZHRsZW4gPCBmdGxlbikge1xuICAgICAgICBsbSA9IGhNYXAoZGx0LCBtbGIsIDApLCBsbCA9IGRsdCwgZG0gPSBoTWFwKGRkdCwgbWRiLCAwKSwgZGwgPSBkZHQ7XG4gICAgICAgIHZhciBsbG0gPSBoTWFwKGxjdCwgbWxjYiwgMCk7XG4gICAgICAgIHdiaXRzKG91dCwgcCwgbmxjIC0gMjU3KTtcbiAgICAgICAgd2JpdHMob3V0LCBwICsgNSwgbmRjIC0gMSk7XG4gICAgICAgIHdiaXRzKG91dCwgcCArIDEwLCBubGNjIC0gNCk7XG4gICAgICAgIHAgKz0gMTQ7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbmxjYzsgKytpKVxuICAgICAgICAgICAgd2JpdHMob3V0LCBwICsgMyAqIGksIGxjdFtjbGltW2ldXSk7XG4gICAgICAgIHAgKz0gMyAqIG5sY2M7XG4gICAgICAgIHZhciBsY3RzID0gW2xjbHQsIGxjZHRdO1xuICAgICAgICBmb3IgKHZhciBpdCA9IDA7IGl0IDwgMjsgKytpdCkge1xuICAgICAgICAgICAgdmFyIGNsY3QgPSBsY3RzW2l0XTtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2xjdC5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgIHZhciBsZW4gPSBjbGN0W2ldICYgMzE7XG4gICAgICAgICAgICAgICAgd2JpdHMob3V0LCBwLCBsbG1bbGVuXSksIHAgKz0gbGN0W2xlbl07XG4gICAgICAgICAgICAgICAgaWYgKGxlbiA+IDE1KVxuICAgICAgICAgICAgICAgICAgICB3Yml0cyhvdXQsIHAsIChjbGN0W2ldID4+IDUpICYgMTI3KSwgcCArPSBjbGN0W2ldID4+IDEyO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBsbSA9IGZsbSwgbGwgPSBmbHQsIGRtID0gZmRtLCBkbCA9IGZkdDtcbiAgICB9XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsaTsgKytpKSB7XG4gICAgICAgIHZhciBzeW0gPSBzeW1zW2ldO1xuICAgICAgICBpZiAoc3ltID4gMjU1KSB7XG4gICAgICAgICAgICB2YXIgbGVuID0gKHN5bSA+PiAxOCkgJiAzMTtcbiAgICAgICAgICAgIHdiaXRzMTYob3V0LCBwLCBsbVtsZW4gKyAyNTddKSwgcCArPSBsbFtsZW4gKyAyNTddO1xuICAgICAgICAgICAgaWYgKGxlbiA+IDcpXG4gICAgICAgICAgICAgICAgd2JpdHMob3V0LCBwLCAoc3ltID4+IDIzKSAmIDMxKSwgcCArPSBmbGViW2xlbl07XG4gICAgICAgICAgICB2YXIgZHN0ID0gc3ltICYgMzE7XG4gICAgICAgICAgICB3Yml0czE2KG91dCwgcCwgZG1bZHN0XSksIHAgKz0gZGxbZHN0XTtcbiAgICAgICAgICAgIGlmIChkc3QgPiAzKVxuICAgICAgICAgICAgICAgIHdiaXRzMTYob3V0LCBwLCAoc3ltID4+IDUpICYgODE5MSksIHAgKz0gZmRlYltkc3RdO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgd2JpdHMxNihvdXQsIHAsIGxtW3N5bV0pLCBwICs9IGxsW3N5bV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgd2JpdHMxNihvdXQsIHAsIGxtWzI1Nl0pO1xuICAgIHJldHVybiBwICsgbGxbMjU2XTtcbn07XG4vLyBkZWZsYXRlIG9wdGlvbnMgKG5pY2UgPDwgMTMpIHwgY2hhaW5cbnZhciBkZW8gPSAvKiNfX1BVUkVfXyovIG5ldyBpMzIoWzY1NTQwLCAxMzEwODAsIDEzMTA4OCwgMTMxMTA0LCAyNjIxNzYsIDEwNDg3MDQsIDEwNDg4MzIsIDIxMTQ1NjAsIDIxMTc2MzJdKTtcbi8vIGVtcHR5XG52YXIgZXQgPSAvKiNfX1BVUkVfXyovIG5ldyB1OCgwKTtcbi8vIGNvbXByZXNzZXMgZGF0YSBpbnRvIGEgcmF3IERFRkxBVEUgYnVmZmVyXG52YXIgZGZsdCA9IGZ1bmN0aW9uIChkYXQsIGx2bCwgcGx2bCwgcHJlLCBwb3N0LCBzdCkge1xuICAgIHZhciBzID0gc3QueiB8fCBkYXQubGVuZ3RoO1xuICAgIHZhciBvID0gbmV3IHU4KHByZSArIHMgKyA1ICogKDEgKyBNYXRoLmNlaWwocyAvIDcwMDApKSArIHBvc3QpO1xuICAgIC8vIHdyaXRpbmcgdG8gdGhpcyB3cml0ZXMgdG8gdGhlIG91dHB1dCBidWZmZXJcbiAgICB2YXIgdyA9IG8uc3ViYXJyYXkocHJlLCBvLmxlbmd0aCAtIHBvc3QpO1xuICAgIHZhciBsc3QgPSBzdC5sO1xuICAgIHZhciBwb3MgPSAoc3QuciB8fCAwKSAmIDc7XG4gICAgaWYgKGx2bCkge1xuICAgICAgICBpZiAocG9zKVxuICAgICAgICAgICAgd1swXSA9IHN0LnIgPj4gMztcbiAgICAgICAgdmFyIG9wdCA9IGRlb1tsdmwgLSAxXTtcbiAgICAgICAgdmFyIG4gPSBvcHQgPj4gMTMsIGMgPSBvcHQgJiA4MTkxO1xuICAgICAgICB2YXIgbXNrXzEgPSAoMSA8PCBwbHZsKSAtIDE7XG4gICAgICAgIC8vICAgIHByZXYgMi1ieXRlIHZhbCBtYXAgICAgY3VyciAyLWJ5dGUgdmFsIG1hcFxuICAgICAgICB2YXIgcHJldiA9IHN0LnAgfHwgbmV3IHUxNigzMjc2OCksIGhlYWQgPSBzdC5oIHx8IG5ldyB1MTYobXNrXzEgKyAxKTtcbiAgICAgICAgdmFyIGJzMV8xID0gTWF0aC5jZWlsKHBsdmwgLyAzKSwgYnMyXzEgPSAyICogYnMxXzE7XG4gICAgICAgIHZhciBoc2ggPSBmdW5jdGlvbiAoaSkgeyByZXR1cm4gKGRhdFtpXSBeIChkYXRbaSArIDFdIDw8IGJzMV8xKSBeIChkYXRbaSArIDJdIDw8IGJzMl8xKSkgJiBtc2tfMTsgfTtcbiAgICAgICAgLy8gMjQ1NzYgaXMgYW4gYXJiaXRyYXJ5IG51bWJlciBvZiBtYXhpbXVtIHN5bWJvbHMgcGVyIGJsb2NrXG4gICAgICAgIC8vIDQyNCBidWZmZXIgZm9yIGxhc3QgYmxvY2tcbiAgICAgICAgdmFyIHN5bXMgPSBuZXcgaTMyKDI1MDAwKTtcbiAgICAgICAgLy8gbGVuZ3RoL2xpdGVyYWwgZnJlcSAgIGRpc3RhbmNlIGZyZXFcbiAgICAgICAgdmFyIGxmID0gbmV3IHUxNigyODgpLCBkZiA9IG5ldyB1MTYoMzIpO1xuICAgICAgICAvLyAgbC9sY250ICBleGJpdHMgIGluZGV4ICAgICAgICAgIGwvbGluZCAgd2FpdGR4ICAgICAgICAgIGJsa3Bvc1xuICAgICAgICB2YXIgbGNfMSA9IDAsIGViID0gMCwgaSA9IHN0LmkgfHwgMCwgbGkgPSAwLCB3aSA9IHN0LncgfHwgMCwgYnMgPSAwO1xuICAgICAgICBmb3IgKDsgaSArIDIgPCBzOyArK2kpIHtcbiAgICAgICAgICAgIC8vIGhhc2ggdmFsdWVcbiAgICAgICAgICAgIHZhciBodiA9IGhzaChpKTtcbiAgICAgICAgICAgIC8vIGluZGV4IG1vZCAzMjc2OCAgICBwcmV2aW91cyBpbmRleCBtb2RcbiAgICAgICAgICAgIHZhciBpbW9kID0gaSAmIDMyNzY3LCBwaW1vZCA9IGhlYWRbaHZdO1xuICAgICAgICAgICAgcHJldltpbW9kXSA9IHBpbW9kO1xuICAgICAgICAgICAgaGVhZFtodl0gPSBpbW9kO1xuICAgICAgICAgICAgLy8gV2UgYWx3YXlzIHNob3VsZCBtb2RpZnkgaGVhZCBhbmQgcHJldiwgYnV0IG9ubHkgYWRkIHN5bWJvbHMgaWZcbiAgICAgICAgICAgIC8vIHRoaXMgZGF0YSBpcyBub3QgeWV0IHByb2Nlc3NlZCAoXCJ3YWl0XCIgZm9yIHdhaXQgaW5kZXgpXG4gICAgICAgICAgICBpZiAod2kgPD0gaSkge1xuICAgICAgICAgICAgICAgIC8vIGJ5dGVzIHJlbWFpbmluZ1xuICAgICAgICAgICAgICAgIHZhciByZW0gPSBzIC0gaTtcbiAgICAgICAgICAgICAgICBpZiAoKGxjXzEgPiA3MDAwIHx8IGxpID4gMjQ1NzYpICYmIChyZW0gPiA0MjMgfHwgIWxzdCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zID0gd2JsayhkYXQsIHcsIDAsIHN5bXMsIGxmLCBkZiwgZWIsIGxpLCBicywgaSAtIGJzLCBwb3MpO1xuICAgICAgICAgICAgICAgICAgICBsaSA9IGxjXzEgPSBlYiA9IDAsIGJzID0gaTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCAyODY7ICsrailcbiAgICAgICAgICAgICAgICAgICAgICAgIGxmW2pdID0gMDtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCAzMDsgKytqKVxuICAgICAgICAgICAgICAgICAgICAgICAgZGZbal0gPSAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyAgbGVuICAgIGRpc3QgICBjaGFpblxuICAgICAgICAgICAgICAgIHZhciBsID0gMiwgZCA9IDAsIGNoXzEgPSBjLCBkaWYgPSBpbW9kIC0gcGltb2QgJiAzMjc2NztcbiAgICAgICAgICAgICAgICBpZiAocmVtID4gMiAmJiBodiA9PSBoc2goaSAtIGRpZikpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG1heG4gPSBNYXRoLm1pbihuLCByZW0pIC0gMTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG1heGQgPSBNYXRoLm1pbigzMjc2NywgaSk7XG4gICAgICAgICAgICAgICAgICAgIC8vIG1heCBwb3NzaWJsZSBsZW5ndGhcbiAgICAgICAgICAgICAgICAgICAgLy8gbm90IGNhcHBlZCBhdCBkaWYgYmVjYXVzZSBkZWNvbXByZXNzb3JzIGltcGxlbWVudCBcInJvbGxpbmdcIiBpbmRleCBwb3B1bGF0aW9uXG4gICAgICAgICAgICAgICAgICAgIHZhciBtbCA9IE1hdGgubWluKDI1OCwgcmVtKTtcbiAgICAgICAgICAgICAgICAgICAgd2hpbGUgKGRpZiA8PSBtYXhkICYmIC0tY2hfMSAmJiBpbW9kICE9IHBpbW9kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGF0W2kgKyBsXSA9PSBkYXRbaSArIGwgLSBkaWZdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG5sID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKDsgbmwgPCBtbCAmJiBkYXRbaSArIG5sXSA9PSBkYXRbaSArIG5sIC0gZGlmXTsgKytubClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChubCA+IGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbCA9IG5sLCBkID0gZGlmO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBicmVhayBvdXQgZWFybHkgd2hlbiB3ZSByZWFjaCBcIm5pY2VcIiAod2UgYXJlIHNhdGlzZmllZCBlbm91Z2gpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChubCA+IG1heG4pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbm93LCBmaW5kIHRoZSByYXJlc3QgMi1ieXRlIHNlcXVlbmNlIHdpdGhpbiB0aGlzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxlbmd0aCBvZiBsaXRlcmFscyBhbmQgc2VhcmNoIGZvciB0aGF0IGluc3RlYWQuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE11Y2ggZmFzdGVyIHRoYW4ganVzdCB1c2luZyB0aGUgc3RhcnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1tZCA9IE1hdGgubWluKGRpZiwgbmwgLSAyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1kID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBtbWQ7ICsraikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRpID0gaSAtIGRpZiArIGogJiAzMjc2NztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwdGkgPSBwcmV2W3RpXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjZCA9IHRpIC0gcHRpICYgMzI3Njc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY2QgPiBtZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZCA9IGNkLCBwaW1vZCA9IHRpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgdGhlIHByZXZpb3VzIG1hdGNoXG4gICAgICAgICAgICAgICAgICAgICAgICBpbW9kID0gcGltb2QsIHBpbW9kID0gcHJldltpbW9kXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpZiArPSBpbW9kIC0gcGltb2QgJiAzMjc2NztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBkIHdpbGwgYmUgbm9uemVybyBvbmx5IHdoZW4gYSBtYXRjaCB3YXMgZm91bmRcbiAgICAgICAgICAgICAgICBpZiAoZCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSBib3RoIGRpc3QgYW5kIGxlbiBkYXRhIGluIG9uZSBpbnQzMlxuICAgICAgICAgICAgICAgICAgICAvLyBNYWtlIHN1cmUgdGhpcyBpcyByZWNvZ25pemVkIGFzIGEgbGVuL2Rpc3Qgd2l0aCAyOHRoIGJpdCAoMl4yOClcbiAgICAgICAgICAgICAgICAgICAgc3ltc1tsaSsrXSA9IDI2ODQzNTQ1NiB8IChyZXZmbFtsXSA8PCAxOCkgfCByZXZmZFtkXTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGxpbiA9IHJldmZsW2xdICYgMzEsIGRpbiA9IHJldmZkW2RdICYgMzE7XG4gICAgICAgICAgICAgICAgICAgIGViICs9IGZsZWJbbGluXSArIGZkZWJbZGluXTtcbiAgICAgICAgICAgICAgICAgICAgKytsZlsyNTcgKyBsaW5dO1xuICAgICAgICAgICAgICAgICAgICArK2RmW2Rpbl07XG4gICAgICAgICAgICAgICAgICAgIHdpID0gaSArIGw7XG4gICAgICAgICAgICAgICAgICAgICsrbGNfMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHN5bXNbbGkrK10gPSBkYXRbaV07XG4gICAgICAgICAgICAgICAgICAgICsrbGZbZGF0W2ldXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChpID0gTWF0aC5tYXgoaSwgd2kpOyBpIDwgczsgKytpKSB7XG4gICAgICAgICAgICBzeW1zW2xpKytdID0gZGF0W2ldO1xuICAgICAgICAgICAgKytsZltkYXRbaV1dO1xuICAgICAgICB9XG4gICAgICAgIHBvcyA9IHdibGsoZGF0LCB3LCBsc3QsIHN5bXMsIGxmLCBkZiwgZWIsIGxpLCBicywgaSAtIGJzLCBwb3MpO1xuICAgICAgICBpZiAoIWxzdCkge1xuICAgICAgICAgICAgc3QuciA9IChwb3MgJiA3KSB8IHdbKHBvcyAvIDgpIHwgMF0gPDwgMztcbiAgICAgICAgICAgIC8vIHNoZnQocG9zKSBub3cgMSBsZXNzIGlmIHBvcyAmIDcgIT0gMFxuICAgICAgICAgICAgcG9zIC09IDc7XG4gICAgICAgICAgICBzdC5oID0gaGVhZCwgc3QucCA9IHByZXYsIHN0LmkgPSBpLCBzdC53ID0gd2k7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGZvciAodmFyIGkgPSBzdC53IHx8IDA7IGkgPCBzICsgbHN0OyBpICs9IDY1NTM1KSB7XG4gICAgICAgICAgICAvLyBlbmRcbiAgICAgICAgICAgIHZhciBlID0gaSArIDY1NTM1O1xuICAgICAgICAgICAgaWYgKGUgPj0gcykge1xuICAgICAgICAgICAgICAgIC8vIHdyaXRlIGZpbmFsIGJsb2NrXG4gICAgICAgICAgICAgICAgd1socG9zIC8gOCkgfCAwXSA9IGxzdDtcbiAgICAgICAgICAgICAgICBlID0gcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHBvcyA9IHdmYmxrKHcsIHBvcyArIDEsIGRhdC5zdWJhcnJheShpLCBlKSk7XG4gICAgICAgIH1cbiAgICAgICAgc3QuaSA9IHM7XG4gICAgfVxuICAgIHJldHVybiBzbGMobywgMCwgcHJlICsgc2hmdChwb3MpICsgcG9zdCk7XG59O1xuLy8gQ1JDMzIgdGFibGVcbnZhciBjcmN0ID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIHZhciB0ID0gbmV3IEludDMyQXJyYXkoMjU2KTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IDI1NjsgKytpKSB7XG4gICAgICAgIHZhciBjID0gaSwgayA9IDk7XG4gICAgICAgIHdoaWxlICgtLWspXG4gICAgICAgICAgICBjID0gKChjICYgMSkgJiYgLTMwNjY3NDkxMikgXiAoYyA+Pj4gMSk7XG4gICAgICAgIHRbaV0gPSBjO1xuICAgIH1cbiAgICByZXR1cm4gdDtcbn0pKCk7XG4vLyBDUkMzMlxudmFyIGNyYyA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgYyA9IC0xO1xuICAgIHJldHVybiB7XG4gICAgICAgIHA6IGZ1bmN0aW9uIChkKSB7XG4gICAgICAgICAgICAvLyBjbG9zdXJlcyBoYXZlIGF3ZnVsIHBlcmZvcm1hbmNlXG4gICAgICAgICAgICB2YXIgY3IgPSBjO1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBkLmxlbmd0aDsgKytpKVxuICAgICAgICAgICAgICAgIGNyID0gY3JjdFsoY3IgJiAyNTUpIF4gZFtpXV0gXiAoY3IgPj4+IDgpO1xuICAgICAgICAgICAgYyA9IGNyO1xuICAgICAgICB9LFxuICAgICAgICBkOiBmdW5jdGlvbiAoKSB7IHJldHVybiB+YzsgfVxuICAgIH07XG59O1xuLy8gQWRsZXIzMlxudmFyIGFkbGVyID0gZnVuY3Rpb24gKCkge1xuICAgIHZhciBhID0gMSwgYiA9IDA7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcDogZnVuY3Rpb24gKGQpIHtcbiAgICAgICAgICAgIC8vIGNsb3N1cmVzIGhhdmUgYXdmdWwgcGVyZm9ybWFuY2VcbiAgICAgICAgICAgIHZhciBuID0gYSwgbSA9IGI7XG4gICAgICAgICAgICB2YXIgbCA9IGQubGVuZ3RoIHwgMDtcbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpICE9IGw7KSB7XG4gICAgICAgICAgICAgICAgdmFyIGUgPSBNYXRoLm1pbihpICsgMjY1NSwgbCk7XG4gICAgICAgICAgICAgICAgZm9yICg7IGkgPCBlOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIG0gKz0gbiArPSBkW2ldO1xuICAgICAgICAgICAgICAgIG4gPSAobiAmIDY1NTM1KSArIDE1ICogKG4gPj4gMTYpLCBtID0gKG0gJiA2NTUzNSkgKyAxNSAqIChtID4+IDE2KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGEgPSBuLCBiID0gbTtcbiAgICAgICAgfSxcbiAgICAgICAgZDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgYSAlPSA2NTUyMSwgYiAlPSA2NTUyMTtcbiAgICAgICAgICAgIHJldHVybiAoYSAmIDI1NSkgPDwgMjQgfCAoYSAmIDB4RkYwMCkgPDwgOCB8IChiICYgMjU1KSA8PCA4IHwgKGIgPj4gOCk7XG4gICAgICAgIH1cbiAgICB9O1xufTtcbjtcbi8vIGRlZmxhdGUgd2l0aCBvcHRzXG52YXIgZG9wdCA9IGZ1bmN0aW9uIChkYXQsIG9wdCwgcHJlLCBwb3N0LCBzdCkge1xuICAgIGlmICghc3QpIHtcbiAgICAgICAgc3QgPSB7IGw6IDEgfTtcbiAgICAgICAgaWYgKG9wdC5kaWN0aW9uYXJ5KSB7XG4gICAgICAgICAgICB2YXIgZGljdCA9IG9wdC5kaWN0aW9uYXJ5LnN1YmFycmF5KC0zMjc2OCk7XG4gICAgICAgICAgICB2YXIgbmV3RGF0ID0gbmV3IHU4KGRpY3QubGVuZ3RoICsgZGF0Lmxlbmd0aCk7XG4gICAgICAgICAgICBuZXdEYXQuc2V0KGRpY3QpO1xuICAgICAgICAgICAgbmV3RGF0LnNldChkYXQsIGRpY3QubGVuZ3RoKTtcbiAgICAgICAgICAgIGRhdCA9IG5ld0RhdDtcbiAgICAgICAgICAgIHN0LncgPSBkaWN0Lmxlbmd0aDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZGZsdChkYXQsIG9wdC5sZXZlbCA9PSBudWxsID8gNiA6IG9wdC5sZXZlbCwgb3B0Lm1lbSA9PSBudWxsID8gKHN0LmwgPyBNYXRoLmNlaWwoTWF0aC5tYXgoOCwgTWF0aC5taW4oMTMsIE1hdGgubG9nKGRhdC5sZW5ndGgpKSkgKiAxLjUpIDogMjApIDogKDEyICsgb3B0Lm1lbSksIHByZSwgcG9zdCwgc3QpO1xufTtcbi8vIFdhbG1hcnQgb2JqZWN0IHNwcmVhZFxudmFyIG1yZyA9IGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgdmFyIG8gPSB7fTtcbiAgICBmb3IgKHZhciBrIGluIGEpXG4gICAgICAgIG9ba10gPSBhW2tdO1xuICAgIGZvciAodmFyIGsgaW4gYilcbiAgICAgICAgb1trXSA9IGJba107XG4gICAgcmV0dXJuIG87XG59O1xuLy8gd29ya2VyIGNsb25lXG4vLyBUaGlzIGlzIHBvc3NpYmx5IHRoZSBjcmF6aWVzdCBwYXJ0IG9mIHRoZSBlbnRpcmUgY29kZWJhc2UsIGRlc3BpdGUgaG93IHNpbXBsZSBpdCBtYXkgc2VlbS5cbi8vIFRoZSBvbmx5IHBhcmFtZXRlciB0byB0aGlzIGZ1bmN0aW9uIGlzIGEgY2xvc3VyZSB0aGF0IHJldHVybnMgYW4gYXJyYXkgb2YgdmFyaWFibGVzIG91dHNpZGUgb2YgdGhlIGZ1bmN0aW9uIHNjb3BlLlxuLy8gV2UncmUgZ29pbmcgdG8gdHJ5IHRvIGZpZ3VyZSBvdXQgdGhlIHZhcmlhYmxlIG5hbWVzIHVzZWQgaW4gdGhlIGNsb3N1cmUgYXMgc3RyaW5ncyBiZWNhdXNlIHRoYXQgaXMgY3J1Y2lhbCBmb3Igd29ya2VyaXphdGlvbi5cbi8vIFdlIHdpbGwgcmV0dXJuIGFuIG9iamVjdCBtYXBwaW5nIG9mIHRydWUgdmFyaWFibGUgbmFtZSB0byB2YWx1ZSAoYmFzaWNhbGx5LCB0aGUgY3VycmVudCBzY29wZSBhcyBhIEpTIG9iamVjdCkuXG4vLyBUaGUgcmVhc29uIHdlIGNhbid0IGp1c3QgdXNlIHRoZSBvcmlnaW5hbCB2YXJpYWJsZSBuYW1lcyBpcyBtaW5pZmllcnMgbWFuZ2xpbmcgdGhlIHRvcGxldmVsIHNjb3BlLlxuLy8gVGhpcyB0b29rIG1lIHRocmVlIHdlZWtzIHRvIGZpZ3VyZSBvdXQgaG93IHRvIGRvLlxudmFyIHdjbG4gPSBmdW5jdGlvbiAoZm4sIGZuU3RyLCB0ZCkge1xuICAgIHZhciBkdCA9IGZuKCk7XG4gICAgdmFyIHN0ID0gZm4udG9TdHJpbmcoKTtcbiAgICB2YXIga3MgPSBzdC5zbGljZShzdC5pbmRleE9mKCdbJykgKyAxLCBzdC5sYXN0SW5kZXhPZignXScpKS5yZXBsYWNlKC9cXHMrL2csICcnKS5zcGxpdCgnLCcpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZHQubGVuZ3RoOyArK2kpIHtcbiAgICAgICAgdmFyIHYgPSBkdFtpXSwgayA9IGtzW2ldO1xuICAgICAgICBpZiAodHlwZW9mIHYgPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgZm5TdHIgKz0gJzsnICsgayArICc9JztcbiAgICAgICAgICAgIHZhciBzdF8xID0gdi50b1N0cmluZygpO1xuICAgICAgICAgICAgaWYgKHYucHJvdG90eXBlKSB7XG4gICAgICAgICAgICAgICAgLy8gZm9yIGdsb2JhbCBvYmplY3RzXG4gICAgICAgICAgICAgICAgaWYgKHN0XzEuaW5kZXhPZignW25hdGl2ZSBjb2RlXScpICE9IC0xKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzcEluZCA9IHN0XzEuaW5kZXhPZignICcsIDgpICsgMTtcbiAgICAgICAgICAgICAgICAgICAgZm5TdHIgKz0gc3RfMS5zbGljZShzcEluZCwgc3RfMS5pbmRleE9mKCcoJywgc3BJbmQpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGZuU3RyICs9IHN0XzE7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIHQgaW4gdi5wcm90b3R5cGUpXG4gICAgICAgICAgICAgICAgICAgICAgICBmblN0ciArPSAnOycgKyBrICsgJy5wcm90b3R5cGUuJyArIHQgKyAnPScgKyB2LnByb3RvdHlwZVt0XS50b1N0cmluZygpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBmblN0ciArPSBzdF8xO1xuICAgICAgICB9XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHRkW2tdID0gdjtcbiAgICB9XG4gICAgcmV0dXJuIGZuU3RyO1xufTtcbnZhciBjaCA9IFtdO1xuLy8gY2xvbmUgYnVmc1xudmFyIGNiZnMgPSBmdW5jdGlvbiAodikge1xuICAgIHZhciB0bCA9IFtdO1xuICAgIGZvciAodmFyIGsgaW4gdikge1xuICAgICAgICBpZiAodltrXS5idWZmZXIpIHtcbiAgICAgICAgICAgIHRsLnB1c2goKHZba10gPSBuZXcgdltrXS5jb25zdHJ1Y3Rvcih2W2tdKSkuYnVmZmVyKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGw7XG59O1xuLy8gdXNlIGEgd29ya2VyIHRvIGV4ZWN1dGUgY29kZVxudmFyIHdya3IgPSBmdW5jdGlvbiAoZm5zLCBpbml0LCBpZCwgY2IpIHtcbiAgICBpZiAoIWNoW2lkXSkge1xuICAgICAgICB2YXIgZm5TdHIgPSAnJywgdGRfMSA9IHt9LCBtID0gZm5zLmxlbmd0aCAtIDE7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbTsgKytpKVxuICAgICAgICAgICAgZm5TdHIgPSB3Y2xuKGZuc1tpXSwgZm5TdHIsIHRkXzEpO1xuICAgICAgICBjaFtpZF0gPSB7IGM6IHdjbG4oZm5zW21dLCBmblN0ciwgdGRfMSksIGU6IHRkXzEgfTtcbiAgICB9XG4gICAgdmFyIHRkID0gbXJnKHt9LCBjaFtpZF0uZSk7XG4gICAgcmV0dXJuIHdrKGNoW2lkXS5jICsgJztvbm1lc3NhZ2U9ZnVuY3Rpb24oZSl7Zm9yKHZhciBrIGluIGUuZGF0YSlzZWxmW2tdPWUuZGF0YVtrXTtvbm1lc3NhZ2U9JyArIGluaXQudG9TdHJpbmcoKSArICd9JywgaWQsIHRkLCBjYmZzKHRkKSwgY2IpO1xufTtcbi8vIGJhc2UgYXN5bmMgaW5mbGF0ZSBmblxudmFyIGJJbmZsdCA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFt1OCwgdTE2LCBpMzIsIGZsZWIsIGZkZWIsIGNsaW0sIGZsLCBmZCwgZmxybSwgZmRybSwgcmV2LCBlYywgaE1hcCwgbWF4LCBiaXRzLCBiaXRzMTYsIHNoZnQsIHNsYywgZXJyLCBpbmZsdCwgaW5mbGF0ZVN5bmMsIHBiZiwgZ29wdF07IH07XG52YXIgYkRmbHQgPSBmdW5jdGlvbiAoKSB7IHJldHVybiBbdTgsIHUxNiwgaTMyLCBmbGViLCBmZGViLCBjbGltLCByZXZmbCwgcmV2ZmQsIGZsbSwgZmx0LCBmZG0sIGZkdCwgcmV2LCBkZW8sIGV0LCBoTWFwLCB3Yml0cywgd2JpdHMxNiwgaFRyZWUsIGxuLCBsYywgY2xlbiwgd2ZibGssIHdibGssIHNoZnQsIHNsYywgZGZsdCwgZG9wdCwgZGVmbGF0ZVN5bmMsIHBiZl07IH07XG4vLyBnemlwIGV4dHJhXG52YXIgZ3plID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gW2d6aCwgZ3pobCwgd2J5dGVzLCBjcmMsIGNyY3RdOyB9O1xuLy8gZ3VuemlwIGV4dHJhXG52YXIgZ3V6ZSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIFtnenMsIGd6bF07IH07XG4vLyB6bGliIGV4dHJhXG52YXIgemxlID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gW3psaCwgd2J5dGVzLCBhZGxlcl07IH07XG4vLyB1bnpsaWIgZXh0cmFcbnZhciB6dWxlID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gW3psc107IH07XG4vLyBwb3N0IGJ1ZlxudmFyIHBiZiA9IGZ1bmN0aW9uIChtc2cpIHsgcmV0dXJuIHBvc3RNZXNzYWdlKG1zZywgW21zZy5idWZmZXJdKTsgfTtcbi8vIGdldCBvcHRzXG52YXIgZ29wdCA9IGZ1bmN0aW9uIChvKSB7IHJldHVybiBvICYmIHtcbiAgICBvdXQ6IG8uc2l6ZSAmJiBuZXcgdTgoby5zaXplKSxcbiAgICBkaWN0aW9uYXJ5OiBvLmRpY3Rpb25hcnlcbn07IH07XG4vLyBhc3luYyBoZWxwZXJcbnZhciBjYmlmeSA9IGZ1bmN0aW9uIChkYXQsIG9wdHMsIGZucywgaW5pdCwgaWQsIGNiKSB7XG4gICAgdmFyIHcgPSB3cmtyKGZucywgaW5pdCwgaWQsIGZ1bmN0aW9uIChlcnIsIGRhdCkge1xuICAgICAgICB3LnRlcm1pbmF0ZSgpO1xuICAgICAgICBjYihlcnIsIGRhdCk7XG4gICAgfSk7XG4gICAgdy5wb3N0TWVzc2FnZShbZGF0LCBvcHRzXSwgb3B0cy5jb25zdW1lID8gW2RhdC5idWZmZXJdIDogW10pO1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7IHcudGVybWluYXRlKCk7IH07XG59O1xuLy8gYXV0byBzdHJlYW1cbnZhciBhc3RybSA9IGZ1bmN0aW9uIChzdHJtKSB7XG4gICAgc3RybS5vbmRhdGEgPSBmdW5jdGlvbiAoZGF0LCBmaW5hbCkgeyByZXR1cm4gcG9zdE1lc3NhZ2UoW2RhdCwgZmluYWxdLCBbZGF0LmJ1ZmZlcl0pOyB9O1xuICAgIHJldHVybiBmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgaWYgKGV2LmRhdGFbMF0pIHtcbiAgICAgICAgICAgIHN0cm0ucHVzaChldi5kYXRhWzBdLCBldi5kYXRhWzFdKTtcbiAgICAgICAgICAgIHBvc3RNZXNzYWdlKFtldi5kYXRhWzBdLmxlbmd0aF0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHN0cm0uZmx1c2goZXYuZGF0YVsxXSk7XG4gICAgfTtcbn07XG4vLyBhc3luYyBzdHJlYW0gYXR0YWNoXG52YXIgYXN0cm1pZnkgPSBmdW5jdGlvbiAoZm5zLCBzdHJtLCBvcHRzLCBpbml0LCBpZCwgZmx1c2gsIGV4dCkge1xuICAgIHZhciB0O1xuICAgIHZhciB3ID0gd3JrcihmbnMsIGluaXQsIGlkLCBmdW5jdGlvbiAoZXJyLCBkYXQpIHtcbiAgICAgICAgaWYgKGVycilcbiAgICAgICAgICAgIHcudGVybWluYXRlKCksIHN0cm0ub25kYXRhLmNhbGwoc3RybSwgZXJyKTtcbiAgICAgICAgZWxzZSBpZiAoIUFycmF5LmlzQXJyYXkoZGF0KSlcbiAgICAgICAgICAgIGV4dChkYXQpO1xuICAgICAgICBlbHNlIGlmIChkYXQubGVuZ3RoID09IDEpIHtcbiAgICAgICAgICAgIHN0cm0ucXVldWVkU2l6ZSAtPSBkYXRbMF07XG4gICAgICAgICAgICBpZiAoc3RybS5vbmRyYWluKVxuICAgICAgICAgICAgICAgIHN0cm0ub25kcmFpbihkYXRbMF0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgaWYgKGRhdFsxXSlcbiAgICAgICAgICAgICAgICB3LnRlcm1pbmF0ZSgpO1xuICAgICAgICAgICAgc3RybS5vbmRhdGEuY2FsbChzdHJtLCBlcnIsIGRhdFswXSwgZGF0WzFdKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHcucG9zdE1lc3NhZ2Uob3B0cyk7XG4gICAgc3RybS5xdWV1ZWRTaXplID0gMDtcbiAgICBzdHJtLnB1c2ggPSBmdW5jdGlvbiAoZCwgZikge1xuICAgICAgICBpZiAoIXN0cm0ub25kYXRhKVxuICAgICAgICAgICAgZXJyKDUpO1xuICAgICAgICBpZiAodClcbiAgICAgICAgICAgIHN0cm0ub25kYXRhKGVycig0LCAwLCAxKSwgbnVsbCwgISFmKTtcbiAgICAgICAgc3RybS5xdWV1ZWRTaXplICs9IGQubGVuZ3RoO1xuICAgICAgICAvLyBjYW4gZmFpbCBmb3IgY3Jvc3MtcmVhbG0gVWludDhBcnJheSwgYnV0IG9rIC0gb25seSBhIHNtYWxsIHBlcmZvcm1hbmNlIHBlbmFsdHlcbiAgICAgICAgdy5wb3N0TWVzc2FnZShbZCwgdCA9IGZdLCBkLmJ1ZmZlciBpbnN0YW5jZW9mIEFycmF5QnVmZmVyID8gW2QuYnVmZmVyXSA6IFtdKTtcbiAgICB9O1xuICAgIHN0cm0udGVybWluYXRlID0gZnVuY3Rpb24gKCkgeyB3LnRlcm1pbmF0ZSgpOyB9O1xuICAgIGlmIChmbHVzaCkge1xuICAgICAgICBzdHJtLmZsdXNoID0gZnVuY3Rpb24gKHN5bmMpIHsgdy5wb3N0TWVzc2FnZShbMCwgc3luY10pOyB9O1xuICAgIH1cbn07XG4vLyByZWFkIDIgYnl0ZXNcbnZhciBiMiA9IGZ1bmN0aW9uIChkLCBiKSB7IHJldHVybiBkW2JdIHwgKGRbYiArIDFdIDw8IDgpOyB9O1xuLy8gcmVhZCA0IGJ5dGVzXG52YXIgYjQgPSBmdW5jdGlvbiAoZCwgYikgeyByZXR1cm4gKGRbYl0gfCAoZFtiICsgMV0gPDwgOCkgfCAoZFtiICsgMl0gPDwgMTYpIHwgKGRbYiArIDNdIDw8IDI0KSkgPj4+IDA7IH07XG4vLyByZWFkIDggYnl0ZXNcbnZhciBiOCA9IGZ1bmN0aW9uIChkLCBiKSB7IHJldHVybiBiNChkLCBiKSArIChiNChkLCBiICsgNCkgKiA0Mjk0OTY3Mjk2KTsgfTtcbi8vIHdyaXRlIGJ5dGVzXG52YXIgd2J5dGVzID0gZnVuY3Rpb24gKGQsIGIsIHYpIHtcbiAgICBmb3IgKDsgdjsgKytiKVxuICAgICAgICBkW2JdID0gdiwgdiA+Pj49IDg7XG59O1xuLy8gZ3ppcCBoZWFkZXJcbnZhciBnemggPSBmdW5jdGlvbiAoYywgbykge1xuICAgIHZhciBmbiA9IG8uZmlsZW5hbWU7XG4gICAgY1swXSA9IDMxLCBjWzFdID0gMTM5LCBjWzJdID0gOCwgY1s4XSA9IG8ubGV2ZWwgPCAyID8gNCA6IG8ubGV2ZWwgPT0gOSA/IDIgOiAwLCBjWzldID0gMzsgLy8gYXNzdW1lIFVuaXhcbiAgICBpZiAoby5tdGltZSAhPSAwKVxuICAgICAgICB3Ynl0ZXMoYywgNCwgTWF0aC5mbG9vcihuZXcgRGF0ZShvLm10aW1lIHx8IERhdGUubm93KCkpIC8gMTAwMCkpO1xuICAgIGlmIChmbikge1xuICAgICAgICBjWzNdID0gODtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPD0gZm4ubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICBjW2kgKyAxMF0gPSBmbi5jaGFyQ29kZUF0KGkpO1xuICAgIH1cbn07XG4vLyBnemlwIGZvb3RlcjogLTggdG8gLTQgPSBDUkMsIC00IHRvIC0wIGlzIGxlbmd0aFxuLy8gZ3ppcCBzdGFydFxudmFyIGd6cyA9IGZ1bmN0aW9uIChkKSB7XG4gICAgaWYgKGRbMF0gIT0gMzEgfHwgZFsxXSAhPSAxMzkgfHwgZFsyXSAhPSA4KVxuICAgICAgICBlcnIoNiwgJ2ludmFsaWQgZ3ppcCBkYXRhJyk7XG4gICAgdmFyIGZsZyA9IGRbM107XG4gICAgdmFyIHN0ID0gMTA7XG4gICAgaWYgKGZsZyAmIDQpXG4gICAgICAgIHN0ICs9IChkWzEwXSB8IGRbMTFdIDw8IDgpICsgMjtcbiAgICBmb3IgKHZhciB6cyA9IChmbGcgPj4gMyAmIDEpICsgKGZsZyA+PiA0ICYgMSk7IHpzID4gMDsgenMgLT0gIWRbc3QrK10pXG4gICAgICAgIDtcbiAgICByZXR1cm4gc3QgKyAoZmxnICYgMik7XG59O1xuLy8gZ3ppcCBsZW5ndGhcbnZhciBnemwgPSBmdW5jdGlvbiAoZCkge1xuICAgIHZhciBsID0gZC5sZW5ndGg7XG4gICAgcmV0dXJuIChkW2wgLSA0XSB8IGRbbCAtIDNdIDw8IDggfCBkW2wgLSAyXSA8PCAxNiB8IGRbbCAtIDFdIDw8IDI0KSA+Pj4gMDtcbn07XG4vLyBnemlwIGhlYWRlciBsZW5ndGhcbnZhciBnemhsID0gZnVuY3Rpb24gKG8pIHsgcmV0dXJuIDEwICsgKG8uZmlsZW5hbWUgPyBvLmZpbGVuYW1lLmxlbmd0aCArIDEgOiAwKTsgfTtcbi8vIHpsaWIgaGVhZGVyXG52YXIgemxoID0gZnVuY3Rpb24gKGMsIG8pIHtcbiAgICB2YXIgbHYgPSBvLmxldmVsLCBmbCA9IGx2ID09IDAgPyAwIDogbHYgPCA2ID8gMSA6IGx2ID09IDkgPyAzIDogMjtcbiAgICBjWzBdID0gMTIwLCBjWzFdID0gKGZsIDw8IDYpIHwgKG8uZGljdGlvbmFyeSAmJiAzMik7XG4gICAgY1sxXSB8PSAzMSAtICgoY1swXSA8PCA4KSB8IGNbMV0pICUgMzE7XG4gICAgaWYgKG8uZGljdGlvbmFyeSkge1xuICAgICAgICB2YXIgaCA9IGFkbGVyKCk7XG4gICAgICAgIGgucChvLmRpY3Rpb25hcnkpO1xuICAgICAgICB3Ynl0ZXMoYywgMiwgaC5kKCkpO1xuICAgIH1cbn07XG4vLyB6bGliIHN0YXJ0XG52YXIgemxzID0gZnVuY3Rpb24gKGQsIGRpY3QpIHtcbiAgICBpZiAoKGRbMF0gJiAxNSkgIT0gOCB8fCAoZFswXSA+PiA0KSA+IDcgfHwgKChkWzBdIDw8IDggfCBkWzFdKSAlIDMxKSlcbiAgICAgICAgZXJyKDYsICdpbnZhbGlkIHpsaWIgZGF0YScpO1xuICAgIGlmICgoZFsxXSA+PiA1ICYgMSkgPT0gKyFkaWN0KVxuICAgICAgICBlcnIoNiwgJ2ludmFsaWQgemxpYiBkYXRhOiAnICsgKGRbMV0gJiAzMiA/ICduZWVkJyA6ICd1bmV4cGVjdGVkJykgKyAnIGRpY3Rpb25hcnknKTtcbiAgICByZXR1cm4gKGRbMV0gPj4gMyAmIDQpICsgMjtcbn07XG5mdW5jdGlvbiBTdHJtT3B0KG9wdHMsIGNiKSB7XG4gICAgaWYgKHR5cGVvZiBvcHRzID09ICdmdW5jdGlvbicpXG4gICAgICAgIGNiID0gb3B0cywgb3B0cyA9IHt9O1xuICAgIHRoaXMub25kYXRhID0gY2I7XG4gICAgcmV0dXJuIG9wdHM7XG59XG4vKipcbiAqIFN0cmVhbWluZyBERUZMQVRFIGNvbXByZXNzaW9uXG4gKi9cbnZhciBEZWZsYXRlID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIERlZmxhdGUob3B0cywgY2IpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBvcHRzID09ICdmdW5jdGlvbicpXG4gICAgICAgICAgICBjYiA9IG9wdHMsIG9wdHMgPSB7fTtcbiAgICAgICAgdGhpcy5vbmRhdGEgPSBjYjtcbiAgICAgICAgdGhpcy5vID0gb3B0cyB8fCB7fTtcbiAgICAgICAgdGhpcy5zID0geyBsOiAwLCBpOiAzMjc2OCwgdzogMzI3NjgsIHo6IDMyNzY4IH07XG4gICAgICAgIC8vIEJ1ZmZlciBsZW5ndGggbXVzdCBhbHdheXMgYmUgMCBtb2QgMzI3NjggZm9yIGluZGV4IGNhbGN1bGF0aW9ucyB0byBiZSBjb3JyZWN0IHdoZW4gbW9kaWZ5aW5nIGhlYWQgYW5kIHByZXZcbiAgICAgICAgLy8gOTgzMDQgPSAzMjc2OCAobG9va2JhY2spICsgNjU1MzYgKGNvbW1vbiBjaHVuayBzaXplKVxuICAgICAgICB0aGlzLmIgPSBuZXcgdTgoOTgzMDQpO1xuICAgICAgICBpZiAodGhpcy5vLmRpY3Rpb25hcnkpIHtcbiAgICAgICAgICAgIHZhciBkaWN0ID0gdGhpcy5vLmRpY3Rpb25hcnkuc3ViYXJyYXkoLTMyNzY4KTtcbiAgICAgICAgICAgIHRoaXMuYi5zZXQoZGljdCwgMzI3NjggLSBkaWN0Lmxlbmd0aCk7XG4gICAgICAgICAgICB0aGlzLnMuaSA9IDMyNzY4IC0gZGljdC5sZW5ndGg7XG4gICAgICAgIH1cbiAgICB9XG4gICAgRGVmbGF0ZS5wcm90b3R5cGUucCA9IGZ1bmN0aW9uIChjLCBmKSB7XG4gICAgICAgIHRoaXMub25kYXRhKGRvcHQoYywgdGhpcy5vLCAwLCAwLCB0aGlzLnMpLCBmKTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFB1c2hlcyBhIGNodW5rIHRvIGJlIGRlZmxhdGVkXG4gICAgICogQHBhcmFtIGNodW5rIFRoZSBjaHVuayB0byBwdXNoXG4gICAgICogQHBhcmFtIGZpbmFsIFdoZXRoZXIgdGhpcyBpcyB0aGUgbGFzdCBjaHVua1xuICAgICAqL1xuICAgIERlZmxhdGUucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIGlmICghdGhpcy5vbmRhdGEpXG4gICAgICAgICAgICBlcnIoNSk7XG4gICAgICAgIGlmICh0aGlzLnMubClcbiAgICAgICAgICAgIGVycig0KTtcbiAgICAgICAgdmFyIGVuZExlbiA9IGNodW5rLmxlbmd0aCArIHRoaXMucy56O1xuICAgICAgICBpZiAoZW5kTGVuID4gdGhpcy5iLmxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKGVuZExlbiA+IDIgKiB0aGlzLmIubGVuZ3RoIC0gMzI3NjgpIHtcbiAgICAgICAgICAgICAgICB2YXIgbmV3QnVmID0gbmV3IHU4KGVuZExlbiAmIC0zMjc2OCk7XG4gICAgICAgICAgICAgICAgbmV3QnVmLnNldCh0aGlzLmIuc3ViYXJyYXkoMCwgdGhpcy5zLnopKTtcbiAgICAgICAgICAgICAgICB0aGlzLmIgPSBuZXdCdWY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgc3BsaXQgPSB0aGlzLmIubGVuZ3RoIC0gdGhpcy5zLno7XG4gICAgICAgICAgICB0aGlzLmIuc2V0KGNodW5rLnN1YmFycmF5KDAsIHNwbGl0KSwgdGhpcy5zLnopO1xuICAgICAgICAgICAgdGhpcy5zLnogPSB0aGlzLmIubGVuZ3RoO1xuICAgICAgICAgICAgdGhpcy5wKHRoaXMuYiwgZmFsc2UpO1xuICAgICAgICAgICAgdGhpcy5iLnNldCh0aGlzLmIuc3ViYXJyYXkoLTMyNzY4KSk7XG4gICAgICAgICAgICB0aGlzLmIuc2V0KGNodW5rLnN1YmFycmF5KHNwbGl0KSwgMzI3NjgpO1xuICAgICAgICAgICAgdGhpcy5zLnogPSBjaHVuay5sZW5ndGggLSBzcGxpdCArIDMyNzY4O1xuICAgICAgICAgICAgdGhpcy5zLmkgPSAzMjc2NiwgdGhpcy5zLncgPSAzMjc2ODtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuYi5zZXQoY2h1bmssIHRoaXMucy56KTtcbiAgICAgICAgICAgIHRoaXMucy56ICs9IGNodW5rLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnMubCA9IGZpbmFsICYgMTtcbiAgICAgICAgaWYgKHRoaXMucy56ID4gdGhpcy5zLncgKyA4MTkxIHx8IGZpbmFsKSB7XG4gICAgICAgICAgICB0aGlzLnAodGhpcy5iLCBmaW5hbCB8fCBmYWxzZSk7XG4gICAgICAgICAgICB0aGlzLnMudyA9IHRoaXMucy5pLCB0aGlzLnMuaSAtPSAyO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmaW5hbCkge1xuICAgICAgICAgICAgLy8gY2xlYW51cCB1bm5lZWRlZCBidWZmZXJzL3N0YXRlIHRvIHJlZHVjZSBtZW1vcnkgdXNhZ2VcbiAgICAgICAgICAgIHRoaXMucyA9IHRoaXMubyA9IHt9O1xuICAgICAgICAgICAgdGhpcy5iID0gZXQ7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEZsdXNoZXMgYnVmZmVyZWQgdW5jb21wcmVzc2VkIGRhdGEuIFVzZWZ1bCB0byBpbW1lZGlhdGVseSByZXRyaWV2ZSB0aGVcbiAgICAgKiBkZWZsYXRlZCBvdXRwdXQgZm9yIHNtYWxsIGlucHV0cy5cbiAgICAgKiBAcGFyYW0gc3luYyBXaGV0aGVyIHRvIGZsdXNoIHRvIGEgYnl0ZSBib3VuZGFyeS4gQSBzeW5jIGZsdXNoIHRha2VzIDQtNVxuICAgICAqICAgICAgICAgICAgIGV4dHJhIGJ5dGVzLCBidXQgZ3VhcmFudGVlcyBhbGwgcHVzaGVkIGRhdGEgaXMgaW1tZWRpYXRlbHlcbiAgICAgKiAgICAgICAgICAgICBkZWNvbXByZXNzaWJsZS4gQSBzZXBhcmF0ZSBERUZMQVRFIHN0cmVhbSBtYXkgYmUgY29uY2F0ZW5hdGVkXG4gICAgICogICAgICAgICAgICAgd2l0aCB0aGUgY3VycmVudCBvdXRwdXQgYWZ0ZXIgYSBzeW5jIGZsdXNoLlxuICAgICAqL1xuICAgIERlZmxhdGUucHJvdG90eXBlLmZsdXNoID0gZnVuY3Rpb24gKHN5bmMpIHtcbiAgICAgICAgaWYgKCF0aGlzLm9uZGF0YSlcbiAgICAgICAgICAgIGVycig1KTtcbiAgICAgICAgaWYgKHRoaXMucy5sKVxuICAgICAgICAgICAgZXJyKDQpO1xuICAgICAgICB0aGlzLnAodGhpcy5iLCBmYWxzZSk7XG4gICAgICAgIHRoaXMucy53ID0gdGhpcy5zLmksIHRoaXMucy5pIC09IDI7XG4gICAgICAgIC8vIGNvdWxkIHRlY2huaWNhbGx5IHNraXAgd3JpdGluZyB0aGUgdHlwZS0wIGJsb2NrIGZvciAodGhpcy5zLnIgJiA3KSA9PSAwLFxuICAgICAgICAvLyBidXQgdGhlIGRldGVybWluaXN0aWMgdHJhaWxlciAoMDAgMDAgRkYgRkYpIGlzIHVzZWZ1bCBpbiBzb21lIHNpdHVhdGlvbnNcbiAgICAgICAgaWYgKHN5bmMpIHtcbiAgICAgICAgICAgIHZhciBjID0gbmV3IHU4KDYpO1xuICAgICAgICAgICAgY1swXSA9IHRoaXMucy5yID4+IDM7XG4gICAgICAgICAgICAvLyB3cml0ZSBlbXB0eSwgbm9uLWZpbmFsIHR5cGUtMCBibG9ja1xuICAgICAgICAgICAgdmFyIGVwID0gd2ZibGsoYywgdGhpcy5zLnIsIGV0KTtcbiAgICAgICAgICAgIHRoaXMucy5yID0gMDtcbiAgICAgICAgICAgIHRoaXMub25kYXRhKGMuc3ViYXJyYXkoMCwgZXAgPj4gMyksIGZhbHNlKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIERlZmxhdGU7XG59KCkpO1xuZXhwb3J0IHsgRGVmbGF0ZSB9O1xuLyoqXG4gKiBBc3luY2hyb25vdXMgc3RyZWFtaW5nIERFRkxBVEUgY29tcHJlc3Npb25cbiAqL1xudmFyIEFzeW5jRGVmbGF0ZSA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBBc3luY0RlZmxhdGUob3B0cywgY2IpIHtcbiAgICAgICAgYXN0cm1pZnkoW1xuICAgICAgICAgICAgYkRmbHQsXG4gICAgICAgICAgICBmdW5jdGlvbiAoKSB7IHJldHVybiBbYXN0cm0sIERlZmxhdGVdOyB9XG4gICAgICAgIF0sIHRoaXMsIFN0cm1PcHQuY2FsbCh0aGlzLCBvcHRzLCBjYiksIGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgdmFyIHN0cm0gPSBuZXcgRGVmbGF0ZShldi5kYXRhKTtcbiAgICAgICAgICAgIG9ubWVzc2FnZSA9IGFzdHJtKHN0cm0pO1xuICAgICAgICB9LCA2LCAxKTtcbiAgICB9XG4gICAgcmV0dXJuIEFzeW5jRGVmbGF0ZTtcbn0oKSk7XG5leHBvcnQgeyBBc3luY0RlZmxhdGUgfTtcbmV4cG9ydCBmdW5jdGlvbiBkZWZsYXRlKGRhdGEsIG9wdHMsIGNiKSB7XG4gICAgaWYgKCFjYilcbiAgICAgICAgY2IgPSBvcHRzLCBvcHRzID0ge307XG4gICAgaWYgKHR5cGVvZiBjYiAhPSAnZnVuY3Rpb24nKVxuICAgICAgICBlcnIoNyk7XG4gICAgcmV0dXJuIGNiaWZ5KGRhdGEsIG9wdHMsIFtcbiAgICAgICAgYkRmbHQsXG4gICAgXSwgZnVuY3Rpb24gKGV2KSB7IHJldHVybiBwYmYoZGVmbGF0ZVN5bmMoZXYuZGF0YVswXSwgZXYuZGF0YVsxXSkpOyB9LCAwLCBjYik7XG59XG4vKipcbiAqIENvbXByZXNzZXMgZGF0YSB3aXRoIERFRkxBVEUgd2l0aG91dCBhbnkgd3JhcHBlclxuICogQHBhcmFtIGRhdGEgVGhlIGRhdGEgdG8gY29tcHJlc3NcbiAqIEBwYXJhbSBvcHRzIFRoZSBjb21wcmVzc2lvbiBvcHRpb25zXG4gKiBAcmV0dXJucyBUaGUgZGVmbGF0ZWQgdmVyc2lvbiBvZiB0aGUgZGF0YVxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVmbGF0ZVN5bmMoZGF0YSwgb3B0cykge1xuICAgIHJldHVybiBkb3B0KGRhdGEsIG9wdHMgfHwge30sIDAsIDApO1xufVxuLyoqXG4gKiBTdHJlYW1pbmcgREVGTEFURSBkZWNvbXByZXNzaW9uXG4gKi9cbnZhciBJbmZsYXRlID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEluZmxhdGUob3B0cywgY2IpIHtcbiAgICAgICAgLy8gbm8gU3RybU9wdCBoZXJlIHRvIGF2b2lkIGFkZGluZyB0byB3b3JrZXJpemVyXG4gICAgICAgIGlmICh0eXBlb2Ygb3B0cyA9PSAnZnVuY3Rpb24nKVxuICAgICAgICAgICAgY2IgPSBvcHRzLCBvcHRzID0ge307XG4gICAgICAgIHRoaXMub25kYXRhID0gY2I7XG4gICAgICAgIHZhciBkaWN0ID0gb3B0cyAmJiBvcHRzLmRpY3Rpb25hcnkgJiYgb3B0cy5kaWN0aW9uYXJ5LnN1YmFycmF5KC0zMjc2OCk7XG4gICAgICAgIHRoaXMucyA9IHsgaTogMCwgYjogZGljdCA/IGRpY3QubGVuZ3RoIDogMCB9O1xuICAgICAgICB0aGlzLm8gPSBuZXcgdTgoMzI3NjgpO1xuICAgICAgICB0aGlzLnAgPSBuZXcgdTgoMCk7XG4gICAgICAgIGlmIChkaWN0KVxuICAgICAgICAgICAgdGhpcy5vLnNldChkaWN0KTtcbiAgICB9XG4gICAgSW5mbGF0ZS5wcm90b3R5cGUuZSA9IGZ1bmN0aW9uIChjKSB7XG4gICAgICAgIGlmICghdGhpcy5vbmRhdGEpXG4gICAgICAgICAgICBlcnIoNSk7XG4gICAgICAgIGlmICh0aGlzLmQpXG4gICAgICAgICAgICBlcnIoNCk7XG4gICAgICAgIGlmICghdGhpcy5wLmxlbmd0aClcbiAgICAgICAgICAgIHRoaXMucCA9IGM7XG4gICAgICAgIGVsc2UgaWYgKGMubGVuZ3RoKSB7XG4gICAgICAgICAgICB2YXIgbiA9IG5ldyB1OCh0aGlzLnAubGVuZ3RoICsgYy5sZW5ndGgpO1xuICAgICAgICAgICAgbi5zZXQodGhpcy5wKSwgbi5zZXQoYywgdGhpcy5wLmxlbmd0aCksIHRoaXMucCA9IG47XG4gICAgICAgIH1cbiAgICB9O1xuICAgIEluZmxhdGUucHJvdG90eXBlLmMgPSBmdW5jdGlvbiAoZmluYWwpIHtcbiAgICAgICAgdGhpcy5zLmkgPSArKHRoaXMuZCA9IGZpbmFsIHx8IGZhbHNlKTtcbiAgICAgICAgdmFyIGJ0cyA9IHRoaXMucy5iO1xuICAgICAgICB2YXIgZHQgPSBpbmZsdCh0aGlzLnAsIHRoaXMucywgdGhpcy5vKTtcbiAgICAgICAgdGhpcy5vbmRhdGEoc2xjKGR0LCBidHMsIHRoaXMucy5iKSwgdGhpcy5kKTtcbiAgICAgICAgdGhpcy5vID0gc2xjKGR0LCB0aGlzLnMuYiAtIDMyNzY4KSwgdGhpcy5zLmIgPSB0aGlzLm8ubGVuZ3RoO1xuICAgICAgICB0aGlzLnAgPSBzbGModGhpcy5wLCAodGhpcy5zLnAgLyA4KSB8IDApLCB0aGlzLnMucCAmPSA3O1xuICAgIH07XG4gICAgLyoqXG4gICAgICogUHVzaGVzIGEgY2h1bmsgdG8gYmUgaW5mbGF0ZWRcbiAgICAgKiBAcGFyYW0gY2h1bmsgVGhlIGNodW5rIHRvIHB1c2hcbiAgICAgKiBAcGFyYW0gZmluYWwgV2hldGhlciB0aGlzIGlzIHRoZSBmaW5hbCBjaHVua1xuICAgICAqL1xuICAgIEluZmxhdGUucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIHRoaXMuZShjaHVuayksIHRoaXMuYyhmaW5hbCk7XG4gICAgfTtcbiAgICByZXR1cm4gSW5mbGF0ZTtcbn0oKSk7XG5leHBvcnQgeyBJbmZsYXRlIH07XG4vKipcbiAqIEFzeW5jaHJvbm91cyBzdHJlYW1pbmcgREVGTEFURSBkZWNvbXByZXNzaW9uXG4gKi9cbnZhciBBc3luY0luZmxhdGUgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQXN5bmNJbmZsYXRlKG9wdHMsIGNiKSB7XG4gICAgICAgIGFzdHJtaWZ5KFtcbiAgICAgICAgICAgIGJJbmZsdCxcbiAgICAgICAgICAgIGZ1bmN0aW9uICgpIHsgcmV0dXJuIFthc3RybSwgSW5mbGF0ZV07IH1cbiAgICAgICAgXSwgdGhpcywgU3RybU9wdC5jYWxsKHRoaXMsIG9wdHMsIGNiKSwgZnVuY3Rpb24gKGV2KSB7XG4gICAgICAgICAgICB2YXIgc3RybSA9IG5ldyBJbmZsYXRlKGV2LmRhdGEpO1xuICAgICAgICAgICAgb25tZXNzYWdlID0gYXN0cm0oc3RybSk7XG4gICAgICAgIH0sIDcsIDApO1xuICAgIH1cbiAgICByZXR1cm4gQXN5bmNJbmZsYXRlO1xufSgpKTtcbmV4cG9ydCB7IEFzeW5jSW5mbGF0ZSB9O1xuZXhwb3J0IGZ1bmN0aW9uIGluZmxhdGUoZGF0YSwgb3B0cywgY2IpIHtcbiAgICBpZiAoIWNiKVxuICAgICAgICBjYiA9IG9wdHMsIG9wdHMgPSB7fTtcbiAgICBpZiAodHlwZW9mIGNiICE9ICdmdW5jdGlvbicpXG4gICAgICAgIGVycig3KTtcbiAgICByZXR1cm4gY2JpZnkoZGF0YSwgb3B0cywgW1xuICAgICAgICBiSW5mbHRcbiAgICBdLCBmdW5jdGlvbiAoZXYpIHsgcmV0dXJuIHBiZihpbmZsYXRlU3luYyhldi5kYXRhWzBdLCBnb3B0KGV2LmRhdGFbMV0pKSk7IH0sIDEsIGNiKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpbmZsYXRlU3luYyhkYXRhLCBvcHRzKSB7XG4gICAgcmV0dXJuIGluZmx0KGRhdGEsIHsgaTogMiB9LCBvcHRzICYmIG9wdHMub3V0LCBvcHRzICYmIG9wdHMuZGljdGlvbmFyeSk7XG59XG4vLyBiZWZvcmUgeW91IHllbGwgYXQgbWUgZm9yIG5vdCBqdXN0IHVzaW5nIGV4dGVuZHMsIG15IHJlYXNvbiBpcyB0aGF0IFRTIGluaGVyaXRhbmNlIGlzIGhhcmQgdG8gd29ya2VyaXplLlxuLyoqXG4gKiBTdHJlYW1pbmcgR1pJUCBjb21wcmVzc2lvblxuICovXG52YXIgR3ppcCA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBHemlwKG9wdHMsIGNiKSB7XG4gICAgICAgIHRoaXMuYyA9IGNyYygpO1xuICAgICAgICB0aGlzLmwgPSAwO1xuICAgICAgICB0aGlzLnYgPSAxO1xuICAgICAgICBEZWZsYXRlLmNhbGwodGhpcywgb3B0cywgY2IpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQdXNoZXMgYSBjaHVuayB0byBiZSBHWklQcGVkXG4gICAgICogQHBhcmFtIGNodW5rIFRoZSBjaHVuayB0byBwdXNoXG4gICAgICogQHBhcmFtIGZpbmFsIFdoZXRoZXIgdGhpcyBpcyB0aGUgbGFzdCBjaHVua1xuICAgICAqL1xuICAgIEd6aXAucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIHRoaXMuYy5wKGNodW5rKTtcbiAgICAgICAgdGhpcy5sICs9IGNodW5rLmxlbmd0aDtcbiAgICAgICAgRGVmbGF0ZS5wcm90b3R5cGUucHVzaC5jYWxsKHRoaXMsIGNodW5rLCBmaW5hbCk7XG4gICAgfTtcbiAgICBHemlwLnByb3RvdHlwZS5wID0gZnVuY3Rpb24gKGMsIGYpIHtcbiAgICAgICAgdmFyIHJhdyA9IGRvcHQoYywgdGhpcy5vLCB0aGlzLnYgJiYgZ3pobCh0aGlzLm8pLCBmICYmIDgsIHRoaXMucyk7XG4gICAgICAgIGlmICh0aGlzLnYpXG4gICAgICAgICAgICBnemgocmF3LCB0aGlzLm8pLCB0aGlzLnYgPSAwO1xuICAgICAgICBpZiAoZilcbiAgICAgICAgICAgIHdieXRlcyhyYXcsIHJhdy5sZW5ndGggLSA4LCB0aGlzLmMuZCgpKSwgd2J5dGVzKHJhdywgcmF3Lmxlbmd0aCAtIDQsIHRoaXMubCk7XG4gICAgICAgIHRoaXMub25kYXRhKHJhdywgZik7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBGbHVzaGVzIGJ1ZmZlcmVkIHVuY29tcHJlc3NlZCBkYXRhLiBVc2VmdWwgdG8gaW1tZWRpYXRlbHkgcmV0cmlldmUgdGhlXG4gICAgICogR1pJUHBlZCBvdXRwdXQgZm9yIHNtYWxsIGlucHV0cy5cbiAgICAgKiBAcGFyYW0gc3luYyBXaGV0aGVyIHRvIGZsdXNoIHRvIGEgYnl0ZSBib3VuZGFyeS4gQSBzeW5jIGZsdXNoIHRha2VzIDQtNVxuICAgICAqICAgICAgICAgICAgIGV4dHJhIGJ5dGVzLCBidXQgZ3VhcmFudGVlcyBhbGwgcHVzaGVkIGRhdGEgaXMgaW1tZWRpYXRlbHlcbiAgICAgKiAgICAgICAgICAgICBkZWNvbXByZXNzaWJsZS5cbiAgICAgKi9cbiAgICBHemlwLnByb3RvdHlwZS5mbHVzaCA9IGZ1bmN0aW9uIChzeW5jKSB7XG4gICAgICAgIERlZmxhdGUucHJvdG90eXBlLmZsdXNoLmNhbGwodGhpcywgc3luYyk7XG4gICAgfTtcbiAgICByZXR1cm4gR3ppcDtcbn0oKSk7XG5leHBvcnQgeyBHemlwIH07XG4vKipcbiAqIEFzeW5jaHJvbm91cyBzdHJlYW1pbmcgR1pJUCBjb21wcmVzc2lvblxuICovXG52YXIgQXN5bmNHemlwID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEFzeW5jR3ppcChvcHRzLCBjYikge1xuICAgICAgICBhc3RybWlmeShbXG4gICAgICAgICAgICBiRGZsdCxcbiAgICAgICAgICAgIGd6ZSxcbiAgICAgICAgICAgIGZ1bmN0aW9uICgpIHsgcmV0dXJuIFthc3RybSwgRGVmbGF0ZSwgR3ppcF07IH1cbiAgICAgICAgXSwgdGhpcywgU3RybU9wdC5jYWxsKHRoaXMsIG9wdHMsIGNiKSwgZnVuY3Rpb24gKGV2KSB7XG4gICAgICAgICAgICB2YXIgc3RybSA9IG5ldyBHemlwKGV2LmRhdGEpO1xuICAgICAgICAgICAgb25tZXNzYWdlID0gYXN0cm0oc3RybSk7XG4gICAgICAgIH0sIDgsIDEpO1xuICAgIH1cbiAgICByZXR1cm4gQXN5bmNHemlwO1xufSgpKTtcbmV4cG9ydCB7IEFzeW5jR3ppcCB9O1xuZXhwb3J0IGZ1bmN0aW9uIGd6aXAoZGF0YSwgb3B0cywgY2IpIHtcbiAgICBpZiAoIWNiKVxuICAgICAgICBjYiA9IG9wdHMsIG9wdHMgPSB7fTtcbiAgICBpZiAodHlwZW9mIGNiICE9ICdmdW5jdGlvbicpXG4gICAgICAgIGVycig3KTtcbiAgICByZXR1cm4gY2JpZnkoZGF0YSwgb3B0cywgW1xuICAgICAgICBiRGZsdCxcbiAgICAgICAgZ3plLFxuICAgICAgICBmdW5jdGlvbiAoKSB7IHJldHVybiBbZ3ppcFN5bmNdOyB9XG4gICAgXSwgZnVuY3Rpb24gKGV2KSB7IHJldHVybiBwYmYoZ3ppcFN5bmMoZXYuZGF0YVswXSwgZXYuZGF0YVsxXSkpOyB9LCAyLCBjYik7XG59XG4vKipcbiAqIENvbXByZXNzZXMgZGF0YSB3aXRoIEdaSVBcbiAqIEBwYXJhbSBkYXRhIFRoZSBkYXRhIHRvIGNvbXByZXNzXG4gKiBAcGFyYW0gb3B0cyBUaGUgY29tcHJlc3Npb24gb3B0aW9uc1xuICogQHJldHVybnMgVGhlIGd6aXBwZWQgdmVyc2lvbiBvZiB0aGUgZGF0YVxuICovXG5leHBvcnQgZnVuY3Rpb24gZ3ppcFN5bmMoZGF0YSwgb3B0cykge1xuICAgIGlmICghb3B0cylcbiAgICAgICAgb3B0cyA9IHt9O1xuICAgIHZhciBjID0gY3JjKCksIGwgPSBkYXRhLmxlbmd0aDtcbiAgICBjLnAoZGF0YSk7XG4gICAgdmFyIGQgPSBkb3B0KGRhdGEsIG9wdHMsIGd6aGwob3B0cyksIDgpLCBzID0gZC5sZW5ndGg7XG4gICAgcmV0dXJuIGd6aChkLCBvcHRzKSwgd2J5dGVzKGQsIHMgLSA4LCBjLmQoKSksIHdieXRlcyhkLCBzIC0gNCwgbCksIGQ7XG59XG4vKipcbiAqIFN0cmVhbWluZyBzaW5nbGUgb3IgbXVsdGktbWVtYmVyIEdaSVAgZGVjb21wcmVzc2lvblxuICovXG52YXIgR3VuemlwID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIEd1bnppcChvcHRzLCBjYikge1xuICAgICAgICB0aGlzLnYgPSAxO1xuICAgICAgICB0aGlzLnIgPSAwO1xuICAgICAgICBJbmZsYXRlLmNhbGwodGhpcywgb3B0cywgY2IpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQdXNoZXMgYSBjaHVuayB0byBiZSBHVU5aSVBwZWRcbiAgICAgKiBAcGFyYW0gY2h1bmsgVGhlIGNodW5rIHRvIHB1c2hcbiAgICAgKiBAcGFyYW0gZmluYWwgV2hldGhlciB0aGlzIGlzIHRoZSBsYXN0IGNodW5rXG4gICAgICovXG4gICAgR3VuemlwLnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBmaW5hbCkge1xuICAgICAgICBJbmZsYXRlLnByb3RvdHlwZS5lLmNhbGwodGhpcywgY2h1bmspO1xuICAgICAgICB0aGlzLnIgKz0gY2h1bmsubGVuZ3RoO1xuICAgICAgICBpZiAodGhpcy52KSB7XG4gICAgICAgICAgICB2YXIgcCA9IHRoaXMucC5zdWJhcnJheSh0aGlzLnYgLSAxKTtcbiAgICAgICAgICAgIHZhciBzID0gcC5sZW5ndGggPiAzID8gZ3pzKHApIDogNDtcbiAgICAgICAgICAgIGlmIChzID4gcC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWZpbmFsKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0aGlzLnYgPiAxICYmIHRoaXMub25tZW1iZXIpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9ubWVtYmVyKHRoaXMuciAtIHAubGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMucCA9IHAuc3ViYXJyYXkocyksIHRoaXMudiA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgLy8gbmVjZXNzYXJ5IHRvIHByZXZlbnQgVFMgZnJvbSB1c2luZyB0aGUgY2xvc3VyZSB2YWx1ZVxuICAgICAgICAvLyBUaGlzIGFsbG93cyBmb3Igd29ya2VyaXphdGlvbiB0byBmdW5jdGlvbiBjb3JyZWN0bHlcbiAgICAgICAgSW5mbGF0ZS5wcm90b3R5cGUuYy5jYWxsKHRoaXMsIDApO1xuICAgICAgICAvLyBwcm9jZXNzIGNvbmNhdGVuYXRlZCBHWklQXG4gICAgICAgIGlmICh0aGlzLnMuZiAmJiAhdGhpcy5zLmwpIHtcbiAgICAgICAgICAgIHRoaXMudiA9IHNoZnQodGhpcy5zLnApICsgOTtcbiAgICAgICAgICAgIHRoaXMucyA9IHsgaTogMCB9O1xuICAgICAgICAgICAgdGhpcy5vID0gbmV3IHU4KDApO1xuICAgICAgICAgICAgdGhpcy5wdXNoKG5ldyB1OCgwKSwgZmluYWwpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGZpbmFsKSB7XG4gICAgICAgICAgICBJbmZsYXRlLnByb3RvdHlwZS5jLmNhbGwodGhpcywgZmluYWwpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICByZXR1cm4gR3VuemlwO1xufSgpKTtcbmV4cG9ydCB7IEd1bnppcCB9O1xuLyoqXG4gKiBBc3luY2hyb25vdXMgc3RyZWFtaW5nIHNpbmdsZSBvciBtdWx0aS1tZW1iZXIgR1pJUCBkZWNvbXByZXNzaW9uXG4gKi9cbnZhciBBc3luY0d1bnppcCA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBBc3luY0d1bnppcChvcHRzLCBjYikge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBhc3RybWlmeShbXG4gICAgICAgICAgICBiSW5mbHQsXG4gICAgICAgICAgICBndXplLFxuICAgICAgICAgICAgZnVuY3Rpb24gKCkgeyByZXR1cm4gW2FzdHJtLCBJbmZsYXRlLCBHdW56aXBdOyB9XG4gICAgICAgIF0sIHRoaXMsIFN0cm1PcHQuY2FsbCh0aGlzLCBvcHRzLCBjYiksIGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgdmFyIHN0cm0gPSBuZXcgR3VuemlwKGV2LmRhdGEpO1xuICAgICAgICAgICAgc3RybS5vbm1lbWJlciA9IGZ1bmN0aW9uIChvZmZzZXQpIHsgcmV0dXJuIHBvc3RNZXNzYWdlKG9mZnNldCk7IH07XG4gICAgICAgICAgICBvbm1lc3NhZ2UgPSBhc3RybShzdHJtKTtcbiAgICAgICAgfSwgOSwgMCwgZnVuY3Rpb24gKG9mZnNldCkgeyByZXR1cm4gX3RoaXMub25tZW1iZXIgJiYgX3RoaXMub25tZW1iZXIob2Zmc2V0KTsgfSk7XG4gICAgfVxuICAgIHJldHVybiBBc3luY0d1bnppcDtcbn0oKSk7XG5leHBvcnQgeyBBc3luY0d1bnppcCB9O1xuZXhwb3J0IGZ1bmN0aW9uIGd1bnppcChkYXRhLCBvcHRzLCBjYikge1xuICAgIGlmICghY2IpXG4gICAgICAgIGNiID0gb3B0cywgb3B0cyA9IHt9O1xuICAgIGlmICh0eXBlb2YgY2IgIT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgZXJyKDcpO1xuICAgIHJldHVybiBjYmlmeShkYXRhLCBvcHRzLCBbXG4gICAgICAgIGJJbmZsdCxcbiAgICAgICAgZ3V6ZSxcbiAgICAgICAgZnVuY3Rpb24gKCkgeyByZXR1cm4gW2d1bnppcFN5bmNdOyB9XG4gICAgXSwgZnVuY3Rpb24gKGV2KSB7IHJldHVybiBwYmYoZ3VuemlwU3luYyhldi5kYXRhWzBdLCBldi5kYXRhWzFdKSk7IH0sIDMsIGNiKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBndW56aXBTeW5jKGRhdGEsIG9wdHMpIHtcbiAgICB2YXIgc3QgPSBnenMoZGF0YSk7XG4gICAgaWYgKHN0ICsgOCA+IGRhdGEubGVuZ3RoKVxuICAgICAgICBlcnIoNiwgJ2ludmFsaWQgZ3ppcCBkYXRhJyk7XG4gICAgcmV0dXJuIGluZmx0KGRhdGEuc3ViYXJyYXkoc3QsIC04KSwgeyBpOiAyIH0sIG9wdHMgJiYgb3B0cy5vdXQgfHwgbmV3IHU4KGd6bChkYXRhKSksIG9wdHMgJiYgb3B0cy5kaWN0aW9uYXJ5KTtcbn1cbi8qKlxuICogU3RyZWFtaW5nIFpsaWIgY29tcHJlc3Npb25cbiAqL1xudmFyIFpsaWIgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gWmxpYihvcHRzLCBjYikge1xuICAgICAgICB0aGlzLmMgPSBhZGxlcigpO1xuICAgICAgICB0aGlzLnYgPSAxO1xuICAgICAgICBEZWZsYXRlLmNhbGwodGhpcywgb3B0cywgY2IpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQdXNoZXMgYSBjaHVuayB0byBiZSB6bGliYmVkXG4gICAgICogQHBhcmFtIGNodW5rIFRoZSBjaHVuayB0byBwdXNoXG4gICAgICogQHBhcmFtIGZpbmFsIFdoZXRoZXIgdGhpcyBpcyB0aGUgbGFzdCBjaHVua1xuICAgICAqL1xuICAgIFpsaWIucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIHRoaXMuYy5wKGNodW5rKTtcbiAgICAgICAgRGVmbGF0ZS5wcm90b3R5cGUucHVzaC5jYWxsKHRoaXMsIGNodW5rLCBmaW5hbCk7XG4gICAgfTtcbiAgICBabGliLnByb3RvdHlwZS5wID0gZnVuY3Rpb24gKGMsIGYpIHtcbiAgICAgICAgdmFyIHJhdyA9IGRvcHQoYywgdGhpcy5vLCB0aGlzLnYgJiYgKHRoaXMuby5kaWN0aW9uYXJ5ID8gNiA6IDIpLCBmICYmIDQsIHRoaXMucyk7XG4gICAgICAgIGlmICh0aGlzLnYpXG4gICAgICAgICAgICB6bGgocmF3LCB0aGlzLm8pLCB0aGlzLnYgPSAwO1xuICAgICAgICBpZiAoZilcbiAgICAgICAgICAgIHdieXRlcyhyYXcsIHJhdy5sZW5ndGggLSA0LCB0aGlzLmMuZCgpKTtcbiAgICAgICAgdGhpcy5vbmRhdGEocmF3LCBmKTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIEZsdXNoZXMgYnVmZmVyZWQgdW5jb21wcmVzc2VkIGRhdGEuIFVzZWZ1bCB0byBpbW1lZGlhdGVseSByZXRyaWV2ZSB0aGVcbiAgICAgKiB6bGliYmVkIG91dHB1dCBmb3Igc21hbGwgaW5wdXRzLlxuICAgICAqIEBwYXJhbSBzeW5jIFdoZXRoZXIgdG8gZmx1c2ggdG8gYSBieXRlIGJvdW5kYXJ5LiBBIHN5bmMgZmx1c2ggdGFrZXMgNC01XG4gICAgICogICAgICAgICAgICAgZXh0cmEgYnl0ZXMsIGJ1dCBndWFyYW50ZWVzIGFsbCBwdXNoZWQgZGF0YSBpcyBpbW1lZGlhdGVseVxuICAgICAqICAgICAgICAgICAgIGRlY29tcHJlc3NpYmxlLlxuICAgICAqL1xuICAgIFpsaWIucHJvdG90eXBlLmZsdXNoID0gZnVuY3Rpb24gKHN5bmMpIHtcbiAgICAgICAgRGVmbGF0ZS5wcm90b3R5cGUuZmx1c2guY2FsbCh0aGlzLCBzeW5jKTtcbiAgICB9O1xuICAgIHJldHVybiBabGliO1xufSgpKTtcbmV4cG9ydCB7IFpsaWIgfTtcbi8qKlxuICogQXN5bmNocm9ub3VzIHN0cmVhbWluZyBabGliIGNvbXByZXNzaW9uXG4gKi9cbnZhciBBc3luY1psaWIgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQXN5bmNabGliKG9wdHMsIGNiKSB7XG4gICAgICAgIGFzdHJtaWZ5KFtcbiAgICAgICAgICAgIGJEZmx0LFxuICAgICAgICAgICAgemxlLFxuICAgICAgICAgICAgZnVuY3Rpb24gKCkgeyByZXR1cm4gW2FzdHJtLCBEZWZsYXRlLCBabGliXTsgfVxuICAgICAgICBdLCB0aGlzLCBTdHJtT3B0LmNhbGwodGhpcywgb3B0cywgY2IpLCBmdW5jdGlvbiAoZXYpIHtcbiAgICAgICAgICAgIHZhciBzdHJtID0gbmV3IFpsaWIoZXYuZGF0YSk7XG4gICAgICAgICAgICBvbm1lc3NhZ2UgPSBhc3RybShzdHJtKTtcbiAgICAgICAgfSwgMTAsIDEpO1xuICAgIH1cbiAgICByZXR1cm4gQXN5bmNabGliO1xufSgpKTtcbmV4cG9ydCB7IEFzeW5jWmxpYiB9O1xuZXhwb3J0IGZ1bmN0aW9uIHpsaWIoZGF0YSwgb3B0cywgY2IpIHtcbiAgICBpZiAoIWNiKVxuICAgICAgICBjYiA9IG9wdHMsIG9wdHMgPSB7fTtcbiAgICBpZiAodHlwZW9mIGNiICE9ICdmdW5jdGlvbicpXG4gICAgICAgIGVycig3KTtcbiAgICByZXR1cm4gY2JpZnkoZGF0YSwgb3B0cywgW1xuICAgICAgICBiRGZsdCxcbiAgICAgICAgemxlLFxuICAgICAgICBmdW5jdGlvbiAoKSB7IHJldHVybiBbemxpYlN5bmNdOyB9XG4gICAgXSwgZnVuY3Rpb24gKGV2KSB7IHJldHVybiBwYmYoemxpYlN5bmMoZXYuZGF0YVswXSwgZXYuZGF0YVsxXSkpOyB9LCA0LCBjYik7XG59XG4vKipcbiAqIENvbXByZXNzIGRhdGEgd2l0aCBabGliXG4gKiBAcGFyYW0gZGF0YSBUaGUgZGF0YSB0byBjb21wcmVzc1xuICogQHBhcmFtIG9wdHMgVGhlIGNvbXByZXNzaW9uIG9wdGlvbnNcbiAqIEByZXR1cm5zIFRoZSB6bGliLWNvbXByZXNzZWQgdmVyc2lvbiBvZiB0aGUgZGF0YVxuICovXG5leHBvcnQgZnVuY3Rpb24gemxpYlN5bmMoZGF0YSwgb3B0cykge1xuICAgIGlmICghb3B0cylcbiAgICAgICAgb3B0cyA9IHt9O1xuICAgIHZhciBhID0gYWRsZXIoKTtcbiAgICBhLnAoZGF0YSk7XG4gICAgdmFyIGQgPSBkb3B0KGRhdGEsIG9wdHMsIG9wdHMuZGljdGlvbmFyeSA/IDYgOiAyLCA0KTtcbiAgICByZXR1cm4gemxoKGQsIG9wdHMpLCB3Ynl0ZXMoZCwgZC5sZW5ndGggLSA0LCBhLmQoKSksIGQ7XG59XG4vKipcbiAqIFN0cmVhbWluZyBabGliIGRlY29tcHJlc3Npb25cbiAqL1xudmFyIFVuemxpYiA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBVbnpsaWIob3B0cywgY2IpIHtcbiAgICAgICAgSW5mbGF0ZS5jYWxsKHRoaXMsIG9wdHMsIGNiKTtcbiAgICAgICAgdGhpcy52ID0gb3B0cyAmJiBvcHRzLmRpY3Rpb25hcnkgPyAyIDogMTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHVzaGVzIGEgY2h1bmsgdG8gYmUgdW56bGliYmVkXG4gICAgICogQHBhcmFtIGNodW5rIFRoZSBjaHVuayB0byBwdXNoXG4gICAgICogQHBhcmFtIGZpbmFsIFdoZXRoZXIgdGhpcyBpcyB0aGUgbGFzdCBjaHVua1xuICAgICAqL1xuICAgIFVuemxpYi5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgSW5mbGF0ZS5wcm90b3R5cGUuZS5jYWxsKHRoaXMsIGNodW5rKTtcbiAgICAgICAgaWYgKHRoaXMudikge1xuICAgICAgICAgICAgaWYgKHRoaXMucC5sZW5ndGggPCA2ICYmICFmaW5hbClcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB0aGlzLnAgPSB0aGlzLnAuc3ViYXJyYXkoemxzKHRoaXMucCwgdGhpcy52IC0gMSkpLCB0aGlzLnYgPSAwO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmaW5hbCkge1xuICAgICAgICAgICAgaWYgKHRoaXMucC5sZW5ndGggPCA0KVxuICAgICAgICAgICAgICAgIGVycig2LCAnaW52YWxpZCB6bGliIGRhdGEnKTtcbiAgICAgICAgICAgIHRoaXMucCA9IHRoaXMucC5zdWJhcnJheSgwLCAtNCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gbmVjZXNzYXJ5IHRvIHByZXZlbnQgVFMgZnJvbSB1c2luZyB0aGUgY2xvc3VyZSB2YWx1ZVxuICAgICAgICAvLyBUaGlzIGFsbG93cyBmb3Igd29ya2VyaXphdGlvbiB0byBmdW5jdGlvbiBjb3JyZWN0bHlcbiAgICAgICAgSW5mbGF0ZS5wcm90b3R5cGUuYy5jYWxsKHRoaXMsIGZpbmFsKTtcbiAgICB9O1xuICAgIHJldHVybiBVbnpsaWI7XG59KCkpO1xuZXhwb3J0IHsgVW56bGliIH07XG4vKipcbiAqIEFzeW5jaHJvbm91cyBzdHJlYW1pbmcgWmxpYiBkZWNvbXByZXNzaW9uXG4gKi9cbnZhciBBc3luY1VuemxpYiA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBBc3luY1VuemxpYihvcHRzLCBjYikge1xuICAgICAgICBhc3RybWlmeShbXG4gICAgICAgICAgICBiSW5mbHQsXG4gICAgICAgICAgICB6dWxlLFxuICAgICAgICAgICAgZnVuY3Rpb24gKCkgeyByZXR1cm4gW2FzdHJtLCBJbmZsYXRlLCBVbnpsaWJdOyB9XG4gICAgICAgIF0sIHRoaXMsIFN0cm1PcHQuY2FsbCh0aGlzLCBvcHRzLCBjYiksIGZ1bmN0aW9uIChldikge1xuICAgICAgICAgICAgdmFyIHN0cm0gPSBuZXcgVW56bGliKGV2LmRhdGEpO1xuICAgICAgICAgICAgb25tZXNzYWdlID0gYXN0cm0oc3RybSk7XG4gICAgICAgIH0sIDExLCAwKTtcbiAgICB9XG4gICAgcmV0dXJuIEFzeW5jVW56bGliO1xufSgpKTtcbmV4cG9ydCB7IEFzeW5jVW56bGliIH07XG5leHBvcnQgZnVuY3Rpb24gdW56bGliKGRhdGEsIG9wdHMsIGNiKSB7XG4gICAgaWYgKCFjYilcbiAgICAgICAgY2IgPSBvcHRzLCBvcHRzID0ge307XG4gICAgaWYgKHR5cGVvZiBjYiAhPSAnZnVuY3Rpb24nKVxuICAgICAgICBlcnIoNyk7XG4gICAgcmV0dXJuIGNiaWZ5KGRhdGEsIG9wdHMsIFtcbiAgICAgICAgYkluZmx0LFxuICAgICAgICB6dWxlLFxuICAgICAgICBmdW5jdGlvbiAoKSB7IHJldHVybiBbdW56bGliU3luY107IH1cbiAgICBdLCBmdW5jdGlvbiAoZXYpIHsgcmV0dXJuIHBiZih1bnpsaWJTeW5jKGV2LmRhdGFbMF0sIGdvcHQoZXYuZGF0YVsxXSkpKTsgfSwgNSwgY2IpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVuemxpYlN5bmMoZGF0YSwgb3B0cykge1xuICAgIHJldHVybiBpbmZsdChkYXRhLnN1YmFycmF5KHpscyhkYXRhLCBvcHRzICYmIG9wdHMuZGljdGlvbmFyeSksIC00KSwgeyBpOiAyIH0sIG9wdHMgJiYgb3B0cy5vdXQsIG9wdHMgJiYgb3B0cy5kaWN0aW9uYXJ5KTtcbn1cbi8vIERlZmF1bHQgYWxnb3JpdGhtIGZvciBjb21wcmVzc2lvbiAodXNlZCBiZWNhdXNlIGhhdmluZyBhIGtub3duIG91dHB1dCBzaXplIGFsbG93cyBmYXN0ZXIgZGVjb21wcmVzc2lvbilcbmV4cG9ydCB7IGd6aXAgYXMgY29tcHJlc3MsIEFzeW5jR3ppcCBhcyBBc3luY0NvbXByZXNzIH07XG5leHBvcnQgeyBnemlwU3luYyBhcyBjb21wcmVzc1N5bmMsIEd6aXAgYXMgQ29tcHJlc3MgfTtcbi8qKlxuICogU3RyZWFtaW5nIEdaSVAsIFpsaWIsIG9yIHJhdyBERUZMQVRFIGRlY29tcHJlc3Npb25cbiAqL1xudmFyIERlY29tcHJlc3MgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gRGVjb21wcmVzcyhvcHRzLCBjYikge1xuICAgICAgICB0aGlzLm8gPSBTdHJtT3B0LmNhbGwodGhpcywgb3B0cywgY2IpIHx8IHt9O1xuICAgICAgICB0aGlzLkcgPSBHdW56aXA7XG4gICAgICAgIHRoaXMuSSA9IEluZmxhdGU7XG4gICAgICAgIHRoaXMuWiA9IFVuemxpYjtcbiAgICB9XG4gICAgLy8gaW5pdCBzdWJzdHJlYW1cbiAgICAvLyBvdmVycmlkZW4gYnkgQXN5bmNEZWNvbXByZXNzXG4gICAgRGVjb21wcmVzcy5wcm90b3R5cGUuaSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgdGhpcy5zLm9uZGF0YSA9IGZ1bmN0aW9uIChkYXQsIGZpbmFsKSB7XG4gICAgICAgICAgICBfdGhpcy5vbmRhdGEoZGF0LCBmaW5hbCk7XG4gICAgICAgIH07XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBQdXNoZXMgYSBjaHVuayB0byBiZSBkZWNvbXByZXNzZWRcbiAgICAgKiBAcGFyYW0gY2h1bmsgVGhlIGNodW5rIHRvIHB1c2hcbiAgICAgKiBAcGFyYW0gZmluYWwgV2hldGhlciB0aGlzIGlzIHRoZSBsYXN0IGNodW5rXG4gICAgICovXG4gICAgRGVjb21wcmVzcy5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgaWYgKCF0aGlzLm9uZGF0YSlcbiAgICAgICAgICAgIGVycig1KTtcbiAgICAgICAgaWYgKCF0aGlzLnMpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnAgJiYgdGhpcy5wLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHZhciBuID0gbmV3IHU4KHRoaXMucC5sZW5ndGggKyBjaHVuay5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIG4uc2V0KHRoaXMucCksIG4uc2V0KGNodW5rLCB0aGlzLnAubGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICB0aGlzLnAgPSBjaHVuaztcbiAgICAgICAgICAgIGlmICh0aGlzLnAubGVuZ3RoID4gMikge1xuICAgICAgICAgICAgICAgIHRoaXMucyA9ICh0aGlzLnBbMF0gPT0gMzEgJiYgdGhpcy5wWzFdID09IDEzOSAmJiB0aGlzLnBbMl0gPT0gOClcbiAgICAgICAgICAgICAgICAgICAgPyBuZXcgdGhpcy5HKHRoaXMubylcbiAgICAgICAgICAgICAgICAgICAgOiAoKHRoaXMucFswXSAmIDE1KSAhPSA4IHx8ICh0aGlzLnBbMF0gPj4gNCkgPiA3IHx8ICgodGhpcy5wWzBdIDw8IDggfCB0aGlzLnBbMV0pICUgMzEpKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgdGhpcy5JKHRoaXMubylcbiAgICAgICAgICAgICAgICAgICAgICAgIDogbmV3IHRoaXMuWih0aGlzLm8pO1xuICAgICAgICAgICAgICAgIHRoaXMuaSgpO1xuICAgICAgICAgICAgICAgIHRoaXMucy5wdXNoKHRoaXMucCwgZmluYWwpO1xuICAgICAgICAgICAgICAgIHRoaXMucCA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgdGhpcy5zLnB1c2goY2h1bmssIGZpbmFsKTtcbiAgICB9O1xuICAgIHJldHVybiBEZWNvbXByZXNzO1xufSgpKTtcbmV4cG9ydCB7IERlY29tcHJlc3MgfTtcbi8qKlxuICogQXN5bmNocm9ub3VzIHN0cmVhbWluZyBHWklQLCBabGliLCBvciByYXcgREVGTEFURSBkZWNvbXByZXNzaW9uXG4gKi9cbnZhciBBc3luY0RlY29tcHJlc3MgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgZnVuY3Rpb24gQXN5bmNEZWNvbXByZXNzKG9wdHMsIGNiKSB7XG4gICAgICAgIERlY29tcHJlc3MuY2FsbCh0aGlzLCBvcHRzLCBjYik7XG4gICAgICAgIHRoaXMucXVldWVkU2l6ZSA9IDA7XG4gICAgICAgIHRoaXMuRyA9IEFzeW5jR3VuemlwO1xuICAgICAgICB0aGlzLkkgPSBBc3luY0luZmxhdGU7XG4gICAgICAgIHRoaXMuWiA9IEFzeW5jVW56bGliO1xuICAgIH1cbiAgICBBc3luY0RlY29tcHJlc3MucHJvdG90eXBlLmkgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIHRoaXMucy5vbmRhdGEgPSBmdW5jdGlvbiAoZXJyLCBkYXQsIGZpbmFsKSB7XG4gICAgICAgICAgICBfdGhpcy5vbmRhdGEoZXJyLCBkYXQsIGZpbmFsKTtcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5zLm9uZHJhaW4gPSBmdW5jdGlvbiAoc2l6ZSkge1xuICAgICAgICAgICAgX3RoaXMucXVldWVkU2l6ZSAtPSBzaXplO1xuICAgICAgICAgICAgaWYgKF90aGlzLm9uZHJhaW4pXG4gICAgICAgICAgICAgICAgX3RoaXMub25kcmFpbihzaXplKTtcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFB1c2hlcyBhIGNodW5rIHRvIGJlIGRlY29tcHJlc3NlZFxuICAgICAqIEBwYXJhbSBjaHVuayBUaGUgY2h1bmsgdG8gcHVzaFxuICAgICAqIEBwYXJhbSBmaW5hbCBXaGV0aGVyIHRoaXMgaXMgdGhlIGxhc3QgY2h1bmtcbiAgICAgKi9cbiAgICBBc3luY0RlY29tcHJlc3MucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIHRoaXMucXVldWVkU2l6ZSArPSBjaHVuay5sZW5ndGg7XG4gICAgICAgIERlY29tcHJlc3MucHJvdG90eXBlLnB1c2guY2FsbCh0aGlzLCBjaHVuaywgZmluYWwpO1xuICAgIH07XG4gICAgcmV0dXJuIEFzeW5jRGVjb21wcmVzcztcbn0oKSk7XG5leHBvcnQgeyBBc3luY0RlY29tcHJlc3MgfTtcbmV4cG9ydCBmdW5jdGlvbiBkZWNvbXByZXNzKGRhdGEsIG9wdHMsIGNiKSB7XG4gICAgaWYgKCFjYilcbiAgICAgICAgY2IgPSBvcHRzLCBvcHRzID0ge307XG4gICAgaWYgKHR5cGVvZiBjYiAhPSAnZnVuY3Rpb24nKVxuICAgICAgICBlcnIoNyk7XG4gICAgcmV0dXJuIChkYXRhWzBdID09IDMxICYmIGRhdGFbMV0gPT0gMTM5ICYmIGRhdGFbMl0gPT0gOClcbiAgICAgICAgPyBndW56aXAoZGF0YSwgb3B0cywgY2IpXG4gICAgICAgIDogKChkYXRhWzBdICYgMTUpICE9IDggfHwgKGRhdGFbMF0gPj4gNCkgPiA3IHx8ICgoZGF0YVswXSA8PCA4IHwgZGF0YVsxXSkgJSAzMSkpXG4gICAgICAgICAgICA/IGluZmxhdGUoZGF0YSwgb3B0cywgY2IpXG4gICAgICAgICAgICA6IHVuemxpYihkYXRhLCBvcHRzLCBjYik7XG59XG4vKipcbiAqIEV4cGFuZHMgY29tcHJlc3NlZCBHWklQLCBabGliLCBvciByYXcgREVGTEFURSBkYXRhLCBhdXRvbWF0aWNhbGx5IGRldGVjdGluZyB0aGUgZm9ybWF0XG4gKiBAcGFyYW0gZGF0YSBUaGUgZGF0YSB0byBkZWNvbXByZXNzXG4gKiBAcGFyYW0gb3B0cyBUaGUgZGVjb21wcmVzc2lvbiBvcHRpb25zXG4gKiBAcmV0dXJucyBUaGUgZGVjb21wcmVzc2VkIHZlcnNpb24gb2YgdGhlIGRhdGFcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY29tcHJlc3NTeW5jKGRhdGEsIG9wdHMpIHtcbiAgICByZXR1cm4gKGRhdGFbMF0gPT0gMzEgJiYgZGF0YVsxXSA9PSAxMzkgJiYgZGF0YVsyXSA9PSA4KVxuICAgICAgICA/IGd1bnppcFN5bmMoZGF0YSwgb3B0cylcbiAgICAgICAgOiAoKGRhdGFbMF0gJiAxNSkgIT0gOCB8fCAoZGF0YVswXSA+PiA0KSA+IDcgfHwgKChkYXRhWzBdIDw8IDggfCBkYXRhWzFdKSAlIDMxKSlcbiAgICAgICAgICAgID8gaW5mbGF0ZVN5bmMoZGF0YSwgb3B0cylcbiAgICAgICAgICAgIDogdW56bGliU3luYyhkYXRhLCBvcHRzKTtcbn1cbi8vIGZsYXR0ZW4gYSBkaXJlY3Rvcnkgc3RydWN0dXJlXG52YXIgZmx0biA9IGZ1bmN0aW9uIChkLCBwLCB0LCBvKSB7XG4gICAgZm9yICh2YXIgayBpbiBkKSB7XG4gICAgICAgIHZhciB2YWwgPSBkW2tdLCBuID0gcCArIGssIG9wID0gbztcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsKSlcbiAgICAgICAgICAgIG9wID0gbXJnKG8sIHZhbFsxXSksIHZhbCA9IHZhbFswXTtcbiAgICAgICAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyh2YWwpKVxuICAgICAgICAgICAgdFtuXSA9IFt2YWwsIG9wXTtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0W24gKz0gJy8nXSA9IFtuZXcgdTgoMCksIG9wXTtcbiAgICAgICAgICAgIGZsdG4odmFsLCBuLCB0LCBvKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG4vLyB0ZXh0IGVuY29kZXJcbnZhciB0ZSA9IHR5cGVvZiBUZXh0RW5jb2RlciAhPSAndW5kZWZpbmVkJyAmJiAvKiNfX1BVUkVfXyovIG5ldyBUZXh0RW5jb2RlcigpO1xuLy8gdGV4dCBkZWNvZGVyXG52YXIgdGQgPSB0eXBlb2YgVGV4dERlY29kZXIgIT0gJ3VuZGVmaW5lZCcgJiYgLyojX19QVVJFX18qLyBuZXcgVGV4dERlY29kZXIoKTtcbi8vIHRleHQgZGVjb2RlciBzdHJlYW1cbnZhciB0ZHMgPSAwO1xudHJ5IHtcbiAgICB0ZC5kZWNvZGUoZXQsIHsgc3RyZWFtOiB0cnVlIH0pO1xuICAgIHRkcyA9IDE7XG59XG5jYXRjaCAoZSkgeyB9XG4vLyBkZWNvZGUgVVRGOFxudmFyIGR1dGY4ID0gZnVuY3Rpb24gKGQpIHtcbiAgICBmb3IgKHZhciByID0gJycsIGkgPSAwOzspIHtcbiAgICAgICAgdmFyIGMgPSBkW2krK107XG4gICAgICAgIHZhciBlYiA9IChjID4gMTI3KSArIChjID4gMjIzKSArIChjID4gMjM5KTtcbiAgICAgICAgaWYgKGkgKyBlYiA+IGQubGVuZ3RoKVxuICAgICAgICAgICAgcmV0dXJuIHsgczogciwgcjogc2xjKGQsIGkgLSAxKSB9O1xuICAgICAgICBpZiAoIWViKVxuICAgICAgICAgICAgciArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGMpO1xuICAgICAgICBlbHNlIGlmIChlYiA9PSAzKSB7XG4gICAgICAgICAgICBjID0gKChjICYgMTUpIDw8IDE4IHwgKGRbaSsrXSAmIDYzKSA8PCAxMiB8IChkW2krK10gJiA2MykgPDwgNiB8IChkW2krK10gJiA2MykpIC0gNjU1MzYsXG4gICAgICAgICAgICAgICAgciArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKDU1Mjk2IHwgKGMgPj4gMTApLCA1NjMyMCB8IChjICYgMTAyMykpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGViICYgMSlcbiAgICAgICAgICAgIHIgKz0gU3RyaW5nLmZyb21DaGFyQ29kZSgoYyAmIDMxKSA8PCA2IHwgKGRbaSsrXSAmIDYzKSk7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHIgKz0gU3RyaW5nLmZyb21DaGFyQ29kZSgoYyAmIDE1KSA8PCAxMiB8IChkW2krK10gJiA2MykgPDwgNiB8IChkW2krK10gJiA2MykpO1xuICAgIH1cbn07XG4vKipcbiAqIFN0cmVhbWluZyBVVEYtOCBkZWNvZGluZ1xuICovXG52YXIgRGVjb2RlVVRGOCA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgVVRGLTggZGVjb2Rpbmcgc3RyZWFtXG4gICAgICogQHBhcmFtIGNiIFRoZSBjYWxsYmFjayB0byBjYWxsIHdoZW5ldmVyIGRhdGEgaXMgZGVjb2RlZFxuICAgICAqL1xuICAgIGZ1bmN0aW9uIERlY29kZVVURjgoY2IpIHtcbiAgICAgICAgdGhpcy5vbmRhdGEgPSBjYjtcbiAgICAgICAgaWYgKHRkcylcbiAgICAgICAgICAgIHRoaXMudCA9IG5ldyBUZXh0RGVjb2RlcigpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgICB0aGlzLnAgPSBldDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHVzaGVzIGEgY2h1bmsgdG8gYmUgZGVjb2RlZCBmcm9tIFVURi04IGJpbmFyeVxuICAgICAqIEBwYXJhbSBjaHVuayBUaGUgY2h1bmsgdG8gcHVzaFxuICAgICAqIEBwYXJhbSBmaW5hbCBXaGV0aGVyIHRoaXMgaXMgdGhlIGxhc3QgY2h1bmtcbiAgICAgKi9cbiAgICBEZWNvZGVVVEY4LnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBmaW5hbCkge1xuICAgICAgICBpZiAoIXRoaXMub25kYXRhKVxuICAgICAgICAgICAgZXJyKDUpO1xuICAgICAgICBmaW5hbCA9ICEhZmluYWw7XG4gICAgICAgIGlmICh0aGlzLnQpIHtcbiAgICAgICAgICAgIHRoaXMub25kYXRhKHRoaXMudC5kZWNvZGUoY2h1bmssIHsgc3RyZWFtOiB0cnVlIH0pLCBmaW5hbCk7XG4gICAgICAgICAgICBpZiAoZmluYWwpIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy50LmRlY29kZSgpLmxlbmd0aClcbiAgICAgICAgICAgICAgICAgICAgZXJyKDgpO1xuICAgICAgICAgICAgICAgIHRoaXMudCA9IG51bGw7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0aGlzLnApXG4gICAgICAgICAgICBlcnIoNCk7XG4gICAgICAgIHZhciBkYXQgPSBuZXcgdTgodGhpcy5wLmxlbmd0aCArIGNodW5rLmxlbmd0aCk7XG4gICAgICAgIGRhdC5zZXQodGhpcy5wKTtcbiAgICAgICAgZGF0LnNldChjaHVuaywgdGhpcy5wLmxlbmd0aCk7XG4gICAgICAgIHZhciBfYSA9IGR1dGY4KGRhdCksIHMgPSBfYS5zLCByID0gX2EucjtcbiAgICAgICAgaWYgKGZpbmFsKSB7XG4gICAgICAgICAgICBpZiAoci5sZW5ndGgpXG4gICAgICAgICAgICAgICAgZXJyKDgpO1xuICAgICAgICAgICAgdGhpcy5wID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICB0aGlzLnAgPSByO1xuICAgICAgICB0aGlzLm9uZGF0YShzLCBmaW5hbCk7XG4gICAgfTtcbiAgICByZXR1cm4gRGVjb2RlVVRGODtcbn0oKSk7XG5leHBvcnQgeyBEZWNvZGVVVEY4IH07XG4vKipcbiAqIFN0cmVhbWluZyBVVEYtOCBlbmNvZGluZ1xuICovXG52YXIgRW5jb2RlVVRGOCA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgVVRGLTggZGVjb2Rpbmcgc3RyZWFtXG4gICAgICogQHBhcmFtIGNiIFRoZSBjYWxsYmFjayB0byBjYWxsIHdoZW5ldmVyIGRhdGEgaXMgZW5jb2RlZFxuICAgICAqL1xuICAgIGZ1bmN0aW9uIEVuY29kZVVURjgoY2IpIHtcbiAgICAgICAgdGhpcy5vbmRhdGEgPSBjYjtcbiAgICB9XG4gICAgLyoqXG4gICAgICogUHVzaGVzIGEgY2h1bmsgdG8gYmUgZW5jb2RlZCB0byBVVEYtOFxuICAgICAqIEBwYXJhbSBjaHVuayBUaGUgc3RyaW5nIGRhdGEgdG8gcHVzaFxuICAgICAqIEBwYXJhbSBmaW5hbCBXaGV0aGVyIHRoaXMgaXMgdGhlIGxhc3QgY2h1bmtcbiAgICAgKi9cbiAgICBFbmNvZGVVVEY4LnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBmaW5hbCkge1xuICAgICAgICBpZiAoIXRoaXMub25kYXRhKVxuICAgICAgICAgICAgZXJyKDUpO1xuICAgICAgICBpZiAodGhpcy5kKVxuICAgICAgICAgICAgZXJyKDQpO1xuICAgICAgICB0aGlzLm9uZGF0YShzdHJUb1U4KGNodW5rKSwgdGhpcy5kID0gZmluYWwgfHwgZmFsc2UpO1xuICAgIH07XG4gICAgcmV0dXJuIEVuY29kZVVURjg7XG59KCkpO1xuZXhwb3J0IHsgRW5jb2RlVVRGOCB9O1xuLyoqXG4gKiBDb252ZXJ0cyBhIHN0cmluZyBpbnRvIGEgVWludDhBcnJheSBmb3IgdXNlIHdpdGggY29tcHJlc3Npb24vZGVjb21wcmVzc2lvbiBtZXRob2RzXG4gKiBAcGFyYW0gc3RyIFRoZSBzdHJpbmcgdG8gZW5jb2RlXG4gKiBAcGFyYW0gbGF0aW4xIFdoZXRoZXIgb3Igbm90IHRvIGludGVycHJldCB0aGUgZGF0YSBhcyBMYXRpbi0xLiBUaGlzIHNob3VsZFxuICogICAgICAgICAgICAgICBub3QgbmVlZCB0byBiZSB0cnVlIHVubGVzcyBkZWNvZGluZyBhIGJpbmFyeSBzdHJpbmcuXG4gKiBAcmV0dXJucyBUaGUgc3RyaW5nIGVuY29kZWQgaW4gVVRGLTgvTGF0aW4tMSBiaW5hcnlcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHN0clRvVTgoc3RyLCBsYXRpbjEpIHtcbiAgICBpZiAobGF0aW4xKSB7XG4gICAgICAgIHZhciBhcl8xID0gbmV3IHU4KHN0ci5sZW5ndGgpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHN0ci5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgIGFyXzFbaV0gPSBzdHIuY2hhckNvZGVBdChpKTtcbiAgICAgICAgcmV0dXJuIGFyXzE7XG4gICAgfVxuICAgIGlmICh0ZSlcbiAgICAgICAgcmV0dXJuIHRlLmVuY29kZShzdHIpO1xuICAgIHZhciBsID0gc3RyLmxlbmd0aDtcbiAgICB2YXIgYXIgPSBuZXcgdTgoc3RyLmxlbmd0aCArIChzdHIubGVuZ3RoID4+IDEpKTtcbiAgICB2YXIgYWkgPSAwO1xuICAgIHZhciB3ID0gZnVuY3Rpb24gKHYpIHsgYXJbYWkrK10gPSB2OyB9O1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbDsgKytpKSB7XG4gICAgICAgIGlmIChhaSArIDUgPiBhci5sZW5ndGgpIHtcbiAgICAgICAgICAgIHZhciBuID0gbmV3IHU4KGFpICsgOCArICgobCAtIGkpIDw8IDEpKTtcbiAgICAgICAgICAgIG4uc2V0KGFyKTtcbiAgICAgICAgICAgIGFyID0gbjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgYyA9IHN0ci5jaGFyQ29kZUF0KGkpO1xuICAgICAgICBpZiAoYyA8IDEyOCB8fCBsYXRpbjEpXG4gICAgICAgICAgICB3KGMpO1xuICAgICAgICBlbHNlIGlmIChjIDwgMjA0OClcbiAgICAgICAgICAgIHcoMTkyIHwgKGMgPj4gNikpLCB3KDEyOCB8IChjICYgNjMpKTtcbiAgICAgICAgZWxzZSBpZiAoYyA+IDU1Mjk1ICYmIGMgPCA1NzM0NClcbiAgICAgICAgICAgIGMgPSA2NTUzNiArIChjICYgMTAyMyA8PCAxMCkgfCAoc3RyLmNoYXJDb2RlQXQoKytpKSAmIDEwMjMpLFxuICAgICAgICAgICAgICAgIHcoMjQwIHwgKGMgPj4gMTgpKSwgdygxMjggfCAoKGMgPj4gMTIpICYgNjMpKSwgdygxMjggfCAoKGMgPj4gNikgJiA2MykpLCB3KDEyOCB8IChjICYgNjMpKTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgdygyMjQgfCAoYyA+PiAxMikpLCB3KDEyOCB8ICgoYyA+PiA2KSAmIDYzKSksIHcoMTI4IHwgKGMgJiA2MykpO1xuICAgIH1cbiAgICByZXR1cm4gc2xjKGFyLCAwLCBhaSk7XG59XG4vKipcbiAqIENvbnZlcnRzIGEgVWludDhBcnJheSB0byBhIHN0cmluZ1xuICogQHBhcmFtIGRhdCBUaGUgZGF0YSB0byBkZWNvZGUgdG8gc3RyaW5nXG4gKiBAcGFyYW0gbGF0aW4xIFdoZXRoZXIgb3Igbm90IHRvIGludGVycHJldCB0aGUgZGF0YSBhcyBMYXRpbi0xLiBUaGlzIHNob3VsZFxuICogICAgICAgICAgICAgICBub3QgbmVlZCB0byBiZSB0cnVlIHVubGVzcyBlbmNvZGluZyB0byBiaW5hcnkgc3RyaW5nLlxuICogQHJldHVybnMgVGhlIG9yaWdpbmFsIFVURi04L0xhdGluLTEgc3RyaW5nXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzdHJGcm9tVTgoZGF0LCBsYXRpbjEpIHtcbiAgICBpZiAobGF0aW4xKSB7XG4gICAgICAgIHZhciByID0gJyc7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZGF0Lmxlbmd0aDsgaSArPSAxNjM4NClcbiAgICAgICAgICAgIHIgKz0gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBkYXQuc3ViYXJyYXkoaSwgaSArIDE2Mzg0KSk7XG4gICAgICAgIHJldHVybiByO1xuICAgIH1cbiAgICBlbHNlIGlmICh0ZCkge1xuICAgICAgICByZXR1cm4gdGQuZGVjb2RlKGRhdCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB2YXIgX2EgPSBkdXRmOChkYXQpLCBzID0gX2EucywgciA9IF9hLnI7XG4gICAgICAgIGlmIChyLmxlbmd0aClcbiAgICAgICAgICAgIGVycig4KTtcbiAgICAgICAgcmV0dXJuIHM7XG4gICAgfVxufVxuO1xuLy8gZGVmbGF0ZSBiaXQgZmxhZ1xudmFyIGRiZiA9IGZ1bmN0aW9uIChsKSB7IHJldHVybiBsID09IDEgPyAzIDogbCA8IDYgPyAyIDogbCA9PSA5ID8gMSA6IDA7IH07XG4vLyBza2lwIGxvY2FsIHppcCBoZWFkZXJcbnZhciBzbHpoID0gZnVuY3Rpb24gKGQsIGIpIHsgcmV0dXJuIGIgKyAzMCArIGIyKGQsIGIgKyAyNikgKyBiMihkLCBiICsgMjgpOyB9O1xuLy8gcmVhZCB6aXAgaGVhZGVyXG52YXIgemggPSBmdW5jdGlvbiAoZCwgYiwgeikge1xuICAgIHZhciBmbmwgPSBiMihkLCBiICsgMjgpLCBlZmwgPSBiMihkLCBiICsgMzApLCBmbiA9IHN0ckZyb21VOChkLnN1YmFycmF5KGIgKyA0NiwgYiArIDQ2ICsgZm5sKSwgIShiMihkLCBiICsgOCkgJiAyMDQ4KSksIGVzID0gYiArIDQ2ICsgZm5sO1xuICAgIHZhciBfYSA9IHo2NGhzKGQsIGVzLCBlZmwsIHosIGI0KGQsIGIgKyAyMCksIGI0KGQsIGIgKyAyNCksIGI0KGQsIGIgKyA0MikpLCBzYyA9IF9hWzBdLCBzdSA9IF9hWzFdLCBvZmYgPSBfYVsyXTtcbiAgICByZXR1cm4gW2IyKGQsIGIgKyAxMCksIHNjLCBzdSwgZm4sIGVzICsgZWZsICsgYjIoZCwgYiArIDMyKSwgb2ZmXTtcbn07XG4vLyByZWFkIHppcDY0IGhlYWRlciBzaXplc1xudmFyIHo2NGhzID0gZnVuY3Rpb24gKGQsIGIsIGwsIHosIHNjLCBzdSwgb2ZmKSB7XG4gICAgdmFyIG5zYyA9IHNjID09IDQyOTQ5NjcyOTUsIG5zdSA9IHN1ID09IDQyOTQ5NjcyOTUsIG5vZmYgPSBvZmYgPT0gNDI5NDk2NzI5NSwgZSA9IGIgKyBsO1xuICAgIHZhciBuZiA9IG5zYyArIG5zdSArIG5vZmY7XG4gICAgaWYgKHogJiYgbmYpIHtcbiAgICAgICAgZm9yICg7IGIgKyA0IDwgZTsgYiArPSA0ICsgYjIoZCwgYiArIDIpKSB7XG4gICAgICAgICAgICBpZiAoYjIoZCwgYikgPT0gMSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgICAgIG5zYyA/IGI4KGQsIGIgKyA0ICsgOCAqIG5zdSkgOiBzYyxcbiAgICAgICAgICAgICAgICAgICAgbnN1ID8gYjgoZCwgYiArIDQpIDogc3UsXG4gICAgICAgICAgICAgICAgICAgIG5vZmYgPyBiOChkLCBiICsgNCArIDggKiAobnN1ICsgbnNjKSkgOiBvZmYsXG4gICAgICAgICAgICAgICAgICAgIDFcbiAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIHogPT0gMiBmb3IgdW5rbm93biB3aGV0aGVyIG9yIG5vdCB6aXA2NFxuICAgICAgICBpZiAoeiA8IDIpXG4gICAgICAgICAgICBlcnIoMTMpO1xuICAgIH1cbiAgICByZXR1cm4gW3NjLCBzdSwgb2ZmLCAwXTtcbn07XG4vLyBleHRyYSBmaWVsZCBsZW5ndGhcbnZhciBleGZsID0gZnVuY3Rpb24gKGV4KSB7XG4gICAgdmFyIGxlID0gMDtcbiAgICBpZiAoZXgpIHtcbiAgICAgICAgZm9yICh2YXIgayBpbiBleCkge1xuICAgICAgICAgICAgdmFyIGwgPSBleFtrXS5sZW5ndGg7XG4gICAgICAgICAgICBpZiAobCA+IDY1NTM1KVxuICAgICAgICAgICAgICAgIGVycig5KTtcbiAgICAgICAgICAgIGxlICs9IGwgKyA0O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBsZTtcbn07XG4vLyB3cml0ZSB6aXAgaGVhZGVyXG52YXIgd3poID0gZnVuY3Rpb24gKGQsIGIsIGYsIGZuLCB1LCBjLCBjZSwgY28pIHtcbiAgICB2YXIgZmwgPSBmbi5sZW5ndGgsIGV4ID0gZi5leHRyYSwgY29sID0gY28gJiYgY28ubGVuZ3RoO1xuICAgIHZhciBleGwgPSBleGZsKGV4KTtcbiAgICB3Ynl0ZXMoZCwgYiwgY2UgIT0gbnVsbCA/IDB4MjAxNEI1MCA6IDB4NDAzNEI1MCksIGIgKz0gNDtcbiAgICBpZiAoY2UgIT0gbnVsbClcbiAgICAgICAgZFtiKytdID0gMjAsIGRbYisrXSA9IGYub3M7XG4gICAgZFtiXSA9IDIwLCBiICs9IDI7IC8vIHNwZWMgY29tcGxpYW5jZT8gd2hhdCdzIHRoYXQ/XG4gICAgZFtiKytdID0gKGYuZmxhZyA8PCAxKSB8IChjIDwgMCAmJiA4KSwgZFtiKytdID0gdSAmJiA4O1xuICAgIGRbYisrXSA9IGYuY29tcHJlc3Npb24gJiAyNTUsIGRbYisrXSA9IGYuY29tcHJlc3Npb24gPj4gODtcbiAgICB2YXIgZHQgPSBuZXcgRGF0ZShmLm10aW1lID09IG51bGwgPyBEYXRlLm5vdygpIDogZi5tdGltZSksIHkgPSBkdC5nZXRGdWxsWWVhcigpIC0gMTk4MDtcbiAgICBpZiAoeSA8IDAgfHwgeSA+IDExOSlcbiAgICAgICAgZXJyKDEwKTtcbiAgICB3Ynl0ZXMoZCwgYiwgKHkgPDwgMjUpIHwgKChkdC5nZXRNb250aCgpICsgMSkgPDwgMjEpIHwgKGR0LmdldERhdGUoKSA8PCAxNikgfCAoZHQuZ2V0SG91cnMoKSA8PCAxMSkgfCAoZHQuZ2V0TWludXRlcygpIDw8IDUpIHwgKGR0LmdldFNlY29uZHMoKSA+PiAxKSksIGIgKz0gNDtcbiAgICBpZiAoYyAhPSAtMSkge1xuICAgICAgICB3Ynl0ZXMoZCwgYiwgZi5jcmMpO1xuICAgICAgICB3Ynl0ZXMoZCwgYiArIDQsIGMgPCAwID8gLWMgLSAyIDogYyk7XG4gICAgICAgIHdieXRlcyhkLCBiICsgOCwgZi5zaXplKTtcbiAgICB9XG4gICAgd2J5dGVzKGQsIGIgKyAxMiwgZmwpO1xuICAgIHdieXRlcyhkLCBiICsgMTQsIGV4bCksIGIgKz0gMTY7XG4gICAgaWYgKGNlICE9IG51bGwpIHtcbiAgICAgICAgd2J5dGVzKGQsIGIsIGNvbCk7XG4gICAgICAgIHdieXRlcyhkLCBiICsgNiwgZi5hdHRycyk7XG4gICAgICAgIHdieXRlcyhkLCBiICsgMTAsIGNlKSwgYiArPSAxNDtcbiAgICB9XG4gICAgZC5zZXQoZm4sIGIpO1xuICAgIGIgKz0gZmw7XG4gICAgaWYgKGV4bCkge1xuICAgICAgICBmb3IgKHZhciBrIGluIGV4KSB7XG4gICAgICAgICAgICB2YXIgZXhmID0gZXhba10sIGwgPSBleGYubGVuZ3RoO1xuICAgICAgICAgICAgd2J5dGVzKGQsIGIsICtrKTtcbiAgICAgICAgICAgIHdieXRlcyhkLCBiICsgMiwgbCk7XG4gICAgICAgICAgICBkLnNldChleGYsIGIgKyA0KSwgYiArPSA0ICsgbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoY29sKVxuICAgICAgICBkLnNldChjbywgYiksIGIgKz0gY29sO1xuICAgIHJldHVybiBiO1xufTtcbi8vIHdyaXRlIHppcCBmb290ZXIgKGVuZCBvZiBjZW50cmFsIGRpcmVjdG9yeSlcbnZhciB3emYgPSBmdW5jdGlvbiAobywgYiwgYywgZCwgZSkge1xuICAgIHdieXRlcyhvLCBiLCAweDYwNTRCNTApOyAvLyBza2lwIGRpc2tcbiAgICB3Ynl0ZXMobywgYiArIDgsIGMpO1xuICAgIHdieXRlcyhvLCBiICsgMTAsIGMpO1xuICAgIHdieXRlcyhvLCBiICsgMTIsIGQpO1xuICAgIHdieXRlcyhvLCBiICsgMTYsIGUpO1xufTtcbi8qKlxuICogQSBwYXNzLXRocm91Z2ggc3RyZWFtIHRvIGtlZXAgZGF0YSB1bmNvbXByZXNzZWQgaW4gYSBaSVAgYXJjaGl2ZS5cbiAqL1xudmFyIFppcFBhc3NUaHJvdWdoID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBwYXNzLXRocm91Z2ggc3RyZWFtIHRoYXQgY2FuIGJlIGFkZGVkIHRvIFpJUCBhcmNoaXZlc1xuICAgICAqIEBwYXJhbSBmaWxlbmFtZSBUaGUgZmlsZW5hbWUgdG8gYXNzb2NpYXRlIHdpdGggdGhpcyBkYXRhIHN0cmVhbVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIFppcFBhc3NUaHJvdWdoKGZpbGVuYW1lKSB7XG4gICAgICAgIHRoaXMuZmlsZW5hbWUgPSBmaWxlbmFtZTtcbiAgICAgICAgdGhpcy5jID0gY3JjKCk7XG4gICAgICAgIHRoaXMuc2l6ZSA9IDA7XG4gICAgICAgIHRoaXMuY29tcHJlc3Npb24gPSAwO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQcm9jZXNzZXMgYSBjaHVuayBhbmQgcHVzaGVzIHRvIHRoZSBvdXRwdXQgc3RyZWFtLiBZb3UgY2FuIG92ZXJyaWRlIHRoaXNcbiAgICAgKiBtZXRob2QgaW4gYSBzdWJjbGFzcyBmb3IgY3VzdG9tIGJlaGF2aW9yLCBidXQgYnkgZGVmYXVsdCB0aGlzIHBhc3Nlc1xuICAgICAqIHRoZSBkYXRhIHRocm91Z2guIFlvdSBtdXN0IGNhbGwgdGhpcy5vbmRhdGEoZXJyLCBjaHVuaywgZmluYWwpIGF0IHNvbWVcbiAgICAgKiBwb2ludCBpbiB0aGlzIG1ldGhvZC5cbiAgICAgKiBAcGFyYW0gY2h1bmsgVGhlIGNodW5rIHRvIHByb2Nlc3NcbiAgICAgKiBAcGFyYW0gZmluYWwgV2hldGhlciB0aGlzIGlzIHRoZSBsYXN0IGNodW5rXG4gICAgICovXG4gICAgWmlwUGFzc1Rocm91Z2gucHJvdG90eXBlLnByb2Nlc3MgPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIHRoaXMub25kYXRhKG51bGwsIGNodW5rLCBmaW5hbCk7XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBQdXNoZXMgYSBjaHVuayB0byBiZSBhZGRlZC4gSWYgeW91IGFyZSBzdWJjbGFzc2luZyB0aGlzIHdpdGggYSBjdXN0b21cbiAgICAgKiBjb21wcmVzc2lvbiBhbGdvcml0aG0sIG5vdGUgdGhhdCB5b3UgbXVzdCBwdXNoIGRhdGEgZnJvbSB0aGUgc291cmNlXG4gICAgICogZmlsZSBvbmx5LCBwcmUtY29tcHJlc3Npb24uXG4gICAgICogQHBhcmFtIGNodW5rIFRoZSBjaHVuayB0byBwdXNoXG4gICAgICogQHBhcmFtIGZpbmFsIFdoZXRoZXIgdGhpcyBpcyB0aGUgbGFzdCBjaHVua1xuICAgICAqL1xuICAgIFppcFBhc3NUaHJvdWdoLnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBmaW5hbCkge1xuICAgICAgICBpZiAoIXRoaXMub25kYXRhKVxuICAgICAgICAgICAgZXJyKDUpO1xuICAgICAgICB0aGlzLmMucChjaHVuayk7XG4gICAgICAgIHRoaXMuc2l6ZSArPSBjaHVuay5sZW5ndGg7XG4gICAgICAgIGlmIChmaW5hbClcbiAgICAgICAgICAgIHRoaXMuY3JjID0gdGhpcy5jLmQoKTtcbiAgICAgICAgLy8gd2Ugc2hvdWxkbid0IHJlYWxseSBkbyB0aGlzIGNhc3QsIGJ1dCBwcm9wZXJseSBoYW5kbGluZyBBcnJheUJ1ZmZlckxpa2VcbiAgICAgICAgLy8gbWFrZXMgdGhlIEFQSSB1bmVyZ29ub21pYyB3aXRoIEJ1ZmZlclxuICAgICAgICB0aGlzLnByb2Nlc3MoY2h1bmssIGZpbmFsIHx8IGZhbHNlKTtcbiAgICB9O1xuICAgIHJldHVybiBaaXBQYXNzVGhyb3VnaDtcbn0oKSk7XG5leHBvcnQgeyBaaXBQYXNzVGhyb3VnaCB9O1xuLy8gSSBkb24ndCBleHRlbmQgYmVjYXVzZSBUeXBlU2NyaXB0IGV4dGVuc2lvbiBhZGRzIDFrQiBvZiBydW50aW1lIGJsb2F0XG4vKipcbiAqIFN0cmVhbWluZyBERUZMQVRFIGNvbXByZXNzaW9uIGZvciBaSVAgYXJjaGl2ZXMuIFByZWZlciB1c2luZyBBc3luY1ppcERlZmxhdGVcbiAqIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2VcbiAqL1xudmFyIFppcERlZmxhdGUgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIERFRkxBVEUgc3RyZWFtIHRoYXQgY2FuIGJlIGFkZGVkIHRvIFpJUCBhcmNoaXZlc1xuICAgICAqIEBwYXJhbSBmaWxlbmFtZSBUaGUgZmlsZW5hbWUgdG8gYXNzb2NpYXRlIHdpdGggdGhpcyBkYXRhIHN0cmVhbVxuICAgICAqIEBwYXJhbSBvcHRzIFRoZSBjb21wcmVzc2lvbiBvcHRpb25zXG4gICAgICovXG4gICAgZnVuY3Rpb24gWmlwRGVmbGF0ZShmaWxlbmFtZSwgb3B0cykge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBpZiAoIW9wdHMpXG4gICAgICAgICAgICBvcHRzID0ge307XG4gICAgICAgIFppcFBhc3NUaHJvdWdoLmNhbGwodGhpcywgZmlsZW5hbWUpO1xuICAgICAgICB0aGlzLmQgPSBuZXcgRGVmbGF0ZShvcHRzLCBmdW5jdGlvbiAoZGF0LCBmaW5hbCkge1xuICAgICAgICAgICAgX3RoaXMub25kYXRhKG51bGwsIGRhdCwgZmluYWwpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5jb21wcmVzc2lvbiA9IDg7XG4gICAgICAgIHRoaXMuZmxhZyA9IGRiZihvcHRzLmxldmVsKTtcbiAgICB9XG4gICAgWmlwRGVmbGF0ZS5wcm90b3R5cGUucHJvY2VzcyA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHRoaXMuZC5wdXNoKGNodW5rLCBmaW5hbCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHRoaXMub25kYXRhKGUsIG51bGwsIGZpbmFsKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqXG4gICAgICogUHVzaGVzIGEgY2h1bmsgdG8gYmUgZGVmbGF0ZWRcbiAgICAgKiBAcGFyYW0gY2h1bmsgVGhlIGNodW5rIHRvIHB1c2hcbiAgICAgKiBAcGFyYW0gZmluYWwgV2hldGhlciB0aGlzIGlzIHRoZSBsYXN0IGNodW5rXG4gICAgICovXG4gICAgWmlwRGVmbGF0ZS5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgWmlwUGFzc1Rocm91Z2gucHJvdG90eXBlLnB1c2guY2FsbCh0aGlzLCBjaHVuaywgZmluYWwpO1xuICAgIH07XG4gICAgcmV0dXJuIFppcERlZmxhdGU7XG59KCkpO1xuZXhwb3J0IHsgWmlwRGVmbGF0ZSB9O1xuLyoqXG4gKiBBc3luY2hyb25vdXMgc3RyZWFtaW5nIERFRkxBVEUgY29tcHJlc3Npb24gZm9yIFpJUCBhcmNoaXZlc1xuICovXG52YXIgQXN5bmNaaXBEZWZsYXRlID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYW4gYXN5bmNocm9ub3VzIERFRkxBVEUgc3RyZWFtIHRoYXQgY2FuIGJlIGFkZGVkIHRvIFpJUCBhcmNoaXZlc1xuICAgICAqIEBwYXJhbSBmaWxlbmFtZSBUaGUgZmlsZW5hbWUgdG8gYXNzb2NpYXRlIHdpdGggdGhpcyBkYXRhIHN0cmVhbVxuICAgICAqIEBwYXJhbSBvcHRzIFRoZSBjb21wcmVzc2lvbiBvcHRpb25zXG4gICAgICovXG4gICAgZnVuY3Rpb24gQXN5bmNaaXBEZWZsYXRlKGZpbGVuYW1lLCBvcHRzKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIGlmICghb3B0cylcbiAgICAgICAgICAgIG9wdHMgPSB7fTtcbiAgICAgICAgWmlwUGFzc1Rocm91Z2guY2FsbCh0aGlzLCBmaWxlbmFtZSk7XG4gICAgICAgIHRoaXMuZCA9IG5ldyBBc3luY0RlZmxhdGUob3B0cywgZnVuY3Rpb24gKGVyciwgZGF0LCBmaW5hbCkge1xuICAgICAgICAgICAgX3RoaXMub25kYXRhKGVyciwgZGF0LCBmaW5hbCk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNvbXByZXNzaW9uID0gODtcbiAgICAgICAgdGhpcy5mbGFnID0gZGJmKG9wdHMubGV2ZWwpO1xuICAgICAgICB0aGlzLnRlcm1pbmF0ZSA9IHRoaXMuZC50ZXJtaW5hdGU7XG4gICAgfVxuICAgIEFzeW5jWmlwRGVmbGF0ZS5wcm90b3R5cGUucHJvY2VzcyA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgdGhpcy5kLnB1c2goY2h1bmssIGZpbmFsKTtcbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFB1c2hlcyBhIGNodW5rIHRvIGJlIGRlZmxhdGVkXG4gICAgICogQHBhcmFtIGNodW5rIFRoZSBjaHVuayB0byBwdXNoXG4gICAgICogQHBhcmFtIGZpbmFsIFdoZXRoZXIgdGhpcyBpcyB0aGUgbGFzdCBjaHVua1xuICAgICAqL1xuICAgIEFzeW5jWmlwRGVmbGF0ZS5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgWmlwUGFzc1Rocm91Z2gucHJvdG90eXBlLnB1c2guY2FsbCh0aGlzLCBjaHVuaywgZmluYWwpO1xuICAgIH07XG4gICAgcmV0dXJuIEFzeW5jWmlwRGVmbGF0ZTtcbn0oKSk7XG5leHBvcnQgeyBBc3luY1ppcERlZmxhdGUgfTtcbi8vIFRPRE86IEJldHRlciB0cmVlIHNoYWtpbmdcbi8qKlxuICogQSB6aXBwYWJsZSBhcmNoaXZlIHRvIHdoaWNoIGZpbGVzIGNhbiBpbmNyZW1lbnRhbGx5IGJlIGFkZGVkXG4gKi9cbnZhciBaaXAgPSAvKiNfX1BVUkVfXyovIChmdW5jdGlvbiAoKSB7XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbiBlbXB0eSBaSVAgYXJjaGl2ZSB0byB3aGljaCBmaWxlcyBjYW4gYmUgYWRkZWRcbiAgICAgKiBAcGFyYW0gY2IgVGhlIGNhbGxiYWNrIHRvIGNhbGwgd2hlbmV2ZXIgZGF0YSBmb3IgdGhlIGdlbmVyYXRlZCBaSVAgYXJjaGl2ZVxuICAgICAqICAgICAgICAgICBpcyBhdmFpbGFibGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBaaXAoY2IpIHtcbiAgICAgICAgdGhpcy5vbmRhdGEgPSBjYjtcbiAgICAgICAgdGhpcy51ID0gW107XG4gICAgICAgIHRoaXMuZCA9IDE7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFkZHMgYSBmaWxlIHRvIHRoZSBaSVAgYXJjaGl2ZVxuICAgICAqIEBwYXJhbSBmaWxlIFRoZSBmaWxlIHN0cmVhbSB0byBhZGRcbiAgICAgKi9cbiAgICBaaXAucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChmaWxlKSB7XG4gICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgIGlmICghdGhpcy5vbmRhdGEpXG4gICAgICAgICAgICBlcnIoNSk7XG4gICAgICAgIC8vIGZpbmlzaGluZyBvciBmaW5pc2hlZFxuICAgICAgICBpZiAodGhpcy5kICYgMilcbiAgICAgICAgICAgIHRoaXMub25kYXRhKGVycig0ICsgKHRoaXMuZCAmIDEpICogOCwgMCwgMSksIG51bGwsIGZhbHNlKTtcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YXIgZiA9IHN0clRvVTgoZmlsZS5maWxlbmFtZSksIGZsXzEgPSBmLmxlbmd0aDtcbiAgICAgICAgICAgIHZhciBjb20gPSBmaWxlLmNvbW1lbnQsIG8gPSBjb20gJiYgc3RyVG9VOChjb20pO1xuICAgICAgICAgICAgdmFyIHUgPSBmbF8xICE9IGZpbGUuZmlsZW5hbWUubGVuZ3RoIHx8IChvICYmIChjb20ubGVuZ3RoICE9IG8ubGVuZ3RoKSk7XG4gICAgICAgICAgICB2YXIgaGxfMSA9IGZsXzEgKyBleGZsKGZpbGUuZXh0cmEpICsgMzA7XG4gICAgICAgICAgICBpZiAoZmxfMSA+IDY1NTM1KVxuICAgICAgICAgICAgICAgIHRoaXMub25kYXRhKGVycigxMSwgMCwgMSksIG51bGwsIGZhbHNlKTtcbiAgICAgICAgICAgIHZhciBoZWFkZXIgPSBuZXcgdTgoaGxfMSk7XG4gICAgICAgICAgICB3emgoaGVhZGVyLCAwLCBmaWxlLCBmLCB1LCAtMSk7XG4gICAgICAgICAgICB2YXIgY2hrc18xID0gW2hlYWRlcl07XG4gICAgICAgICAgICB2YXIgcEFsbF8xID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGZvciAodmFyIF9pID0gMCwgY2hrc18yID0gY2hrc18xOyBfaSA8IGNoa3NfMi5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNoayA9IGNoa3NfMltfaV07XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLm9uZGF0YShudWxsLCBjaGssIGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2hrc18xID0gW107XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdmFyIHRyXzEgPSB0aGlzLmQ7XG4gICAgICAgICAgICB0aGlzLmQgPSAwO1xuICAgICAgICAgICAgdmFyIGluZF8xID0gdGhpcy51Lmxlbmd0aDtcbiAgICAgICAgICAgIHZhciB1Zl8xID0gbXJnKGZpbGUsIHtcbiAgICAgICAgICAgICAgICBmOiBmLFxuICAgICAgICAgICAgICAgIHU6IHUsXG4gICAgICAgICAgICAgICAgbzogbyxcbiAgICAgICAgICAgICAgICB0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWxlLnRlcm1pbmF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGUudGVybWluYXRlKCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICByOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIHBBbGxfMSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodHJfMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG54dCA9IF90aGlzLnVbaW5kXzEgKyAxXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChueHQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbnh0LnIoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5kID0gMTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB0cl8xID0gMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHZhciBjbF8xID0gMDtcbiAgICAgICAgICAgIGZpbGUub25kYXRhID0gZnVuY3Rpb24gKGVyciwgZGF0LCBmaW5hbCkge1xuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgX3RoaXMub25kYXRhKGVyciwgZGF0LCBmaW5hbCk7XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLnRlcm1pbmF0ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY2xfMSArPSBkYXQubGVuZ3RoO1xuICAgICAgICAgICAgICAgICAgICBjaGtzXzEucHVzaChkYXQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZmluYWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkZCA9IG5ldyB1OCgxNik7XG4gICAgICAgICAgICAgICAgICAgICAgICB3Ynl0ZXMoZGQsIDAsIDB4ODA3NEI1MCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB3Ynl0ZXMoZGQsIDQsIGZpbGUuY3JjKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdieXRlcyhkZCwgOCwgY2xfMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB3Ynl0ZXMoZGQsIDEyLCBmaWxlLnNpemUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hrc18xLnB1c2goZGQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdWZfMS5jID0gY2xfMSwgdWZfMS5iID0gaGxfMSArIGNsXzEgKyAxNiwgdWZfMS5jcmMgPSBmaWxlLmNyYywgdWZfMS5zaXplID0gZmlsZS5zaXplO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRyXzEpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdWZfMS5yKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cl8xID0gMTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0cl8xKVxuICAgICAgICAgICAgICAgICAgICAgICAgcEFsbF8xKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMudS5wdXNoKHVmXzEpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICAvKipcbiAgICAgKiBFbmRzIHRoZSBwcm9jZXNzIG9mIGFkZGluZyBmaWxlcyBhbmQgcHJlcGFyZXMgdG8gZW1pdCB0aGUgZmluYWwgY2h1bmtzLlxuICAgICAqIFRoaXMgKm11c3QqIGJlIGNhbGxlZCBhZnRlciBhZGRpbmcgYWxsIGRlc2lyZWQgZmlsZXMgZm9yIHRoZSByZXN1bHRpbmdcbiAgICAgKiBaSVAgZmlsZSB0byB3b3JrIHByb3Blcmx5LlxuICAgICAqL1xuICAgIFppcC5wcm90b3R5cGUuZW5kID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBpZiAodGhpcy5kICYgMikge1xuICAgICAgICAgICAgdGhpcy5vbmRhdGEoZXJyKDQgKyAodGhpcy5kICYgMSkgKiA4LCAwLCAxKSwgbnVsbCwgdHJ1ZSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuZClcbiAgICAgICAgICAgIHRoaXMuZSgpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgICB0aGlzLnUucHVzaCh7XG4gICAgICAgICAgICAgICAgcjogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIShfdGhpcy5kICYgMSkpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLnUuc3BsaWNlKC0xLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgX3RoaXMuZSgpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgdDogZnVuY3Rpb24gKCkgeyB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5kID0gMztcbiAgICB9O1xuICAgIFppcC5wcm90b3R5cGUuZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGJ0ID0gMCwgbCA9IDAsIHRsID0gMDtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMudTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHZhciBmID0gX2FbX2ldO1xuICAgICAgICAgICAgdGwgKz0gNDYgKyBmLmYubGVuZ3RoICsgZXhmbChmLmV4dHJhKSArIChmLm8gPyBmLm8ubGVuZ3RoIDogMCk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG91dCA9IG5ldyB1OCh0bCArIDIyKTtcbiAgICAgICAgZm9yICh2YXIgX2IgPSAwLCBfYyA9IHRoaXMudTsgX2IgPCBfYy5sZW5ndGg7IF9iKyspIHtcbiAgICAgICAgICAgIHZhciBmID0gX2NbX2JdO1xuICAgICAgICAgICAgd3poKG91dCwgYnQsIGYsIGYuZiwgZi51LCAtZi5jIC0gMiwgbCwgZi5vKTtcbiAgICAgICAgICAgIGJ0ICs9IDQ2ICsgZi5mLmxlbmd0aCArIGV4ZmwoZi5leHRyYSkgKyAoZi5vID8gZi5vLmxlbmd0aCA6IDApLCBsICs9IGYuYjtcbiAgICAgICAgfVxuICAgICAgICB3emYob3V0LCBidCwgdGhpcy51Lmxlbmd0aCwgdGwsIGwpO1xuICAgICAgICB0aGlzLm9uZGF0YShudWxsLCBvdXQsIHRydWUpO1xuICAgICAgICB0aGlzLmQgPSAyO1xuICAgIH07XG4gICAgLyoqXG4gICAgICogQSBtZXRob2QgdG8gdGVybWluYXRlIGFueSBpbnRlcm5hbCB3b3JrZXJzIHVzZWQgYnkgdGhlIHN0cmVhbS4gU3Vic2VxdWVudFxuICAgICAqIGNhbGxzIHRvIGFkZCgpIHdpbGwgZmFpbC5cbiAgICAgKi9cbiAgICBaaXAucHJvdG90eXBlLnRlcm1pbmF0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZm9yICh2YXIgX2kgPSAwLCBfYSA9IHRoaXMudTsgX2kgPCBfYS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIHZhciBmID0gX2FbX2ldO1xuICAgICAgICAgICAgZi50KCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5kID0gMjtcbiAgICB9O1xuICAgIHJldHVybiBaaXA7XG59KCkpO1xuZXhwb3J0IHsgWmlwIH07XG5leHBvcnQgZnVuY3Rpb24gemlwKGRhdGEsIG9wdHMsIGNiKSB7XG4gICAgaWYgKCFjYilcbiAgICAgICAgY2IgPSBvcHRzLCBvcHRzID0ge307XG4gICAgaWYgKHR5cGVvZiBjYiAhPSAnZnVuY3Rpb24nKVxuICAgICAgICBlcnIoNyk7XG4gICAgdmFyIHIgPSB7fTtcbiAgICBmbHRuKGRhdGEsICcnLCByLCBvcHRzKTtcbiAgICB2YXIgayA9IE9iamVjdC5rZXlzKHIpO1xuICAgIHZhciBsZnQgPSBrLmxlbmd0aCwgbyA9IDAsIHRvdCA9IDA7XG4gICAgdmFyIHNsZnQgPSBsZnQsIGZpbGVzID0gbmV3IEFycmF5KGxmdCk7XG4gICAgdmFyIHRlcm0gPSBbXTtcbiAgICB2YXIgdEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0ZXJtLmxlbmd0aDsgKytpKVxuICAgICAgICAgICAgdGVybVtpXSgpO1xuICAgIH07XG4gICAgdmFyIGNiZCA9IGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgIG10KGZ1bmN0aW9uICgpIHsgY2IoYSwgYik7IH0pO1xuICAgIH07XG4gICAgbXQoZnVuY3Rpb24gKCkgeyBjYmQgPSBjYjsgfSk7XG4gICAgdmFyIGNiZiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIG91dCA9IG5ldyB1OCh0b3QgKyAyMiksIG9lID0gbywgY2RsID0gdG90IC0gbztcbiAgICAgICAgdG90ID0gMDtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzbGZ0OyArK2kpIHtcbiAgICAgICAgICAgIHZhciBmID0gZmlsZXNbaV07XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHZhciBsID0gZi5jLmxlbmd0aDtcbiAgICAgICAgICAgICAgICB3emgob3V0LCB0b3QsIGYsIGYuZiwgZi51LCBsKTtcbiAgICAgICAgICAgICAgICB2YXIgYmFkZCA9IDMwICsgZi5mLmxlbmd0aCArIGV4ZmwoZi5leHRyYSk7XG4gICAgICAgICAgICAgICAgdmFyIGxvYyA9IHRvdCArIGJhZGQ7XG4gICAgICAgICAgICAgICAgb3V0LnNldChmLmMsIGxvYyk7XG4gICAgICAgICAgICAgICAgd3poKG91dCwgbywgZiwgZi5mLCBmLnUsIGwsIHRvdCwgZi5tKSwgbyArPSAxNiArIGJhZGQgKyAoZi5tID8gZi5tLmxlbmd0aCA6IDApLCB0b3QgPSBsb2MgKyBsO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY2JkKGUsIG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHd6ZihvdXQsIG8sIGZpbGVzLmxlbmd0aCwgY2RsLCBvZSk7XG4gICAgICAgIGNiZChudWxsLCBvdXQpO1xuICAgIH07XG4gICAgaWYgKCFsZnQpXG4gICAgICAgIGNiZigpO1xuICAgIHZhciBfbG9vcF8xID0gZnVuY3Rpb24gKGkpIHtcbiAgICAgICAgdmFyIGZuID0ga1tpXTtcbiAgICAgICAgdmFyIF9hID0gcltmbl0sIGZpbGUgPSBfYVswXSwgcCA9IF9hWzFdO1xuICAgICAgICB2YXIgYyA9IGNyYygpLCBzaXplID0gZmlsZS5sZW5ndGg7XG4gICAgICAgIGMucChmaWxlKTtcbiAgICAgICAgdmFyIGYgPSBzdHJUb1U4KGZuKSwgcyA9IGYubGVuZ3RoO1xuICAgICAgICB2YXIgY29tID0gcC5jb21tZW50LCBtID0gY29tICYmIHN0clRvVTgoY29tKSwgbXMgPSBtICYmIG0ubGVuZ3RoO1xuICAgICAgICB2YXIgZXhsID0gZXhmbChwLmV4dHJhKTtcbiAgICAgICAgdmFyIGNvbXByZXNzaW9uID0gcC5sZXZlbCA9PSAwID8gMCA6IDg7XG4gICAgICAgIHZhciBjYmwgPSBmdW5jdGlvbiAoZSwgZCkge1xuICAgICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgICAgICB0QWxsKCk7XG4gICAgICAgICAgICAgICAgY2JkKGUsIG51bGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdmFyIGwgPSBkLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBmaWxlc1tpXSA9IG1yZyhwLCB7XG4gICAgICAgICAgICAgICAgICAgIHNpemU6IHNpemUsXG4gICAgICAgICAgICAgICAgICAgIGNyYzogYy5kKCksXG4gICAgICAgICAgICAgICAgICAgIGM6IGQsXG4gICAgICAgICAgICAgICAgICAgIGY6IGYsXG4gICAgICAgICAgICAgICAgICAgIG06IG0sXG4gICAgICAgICAgICAgICAgICAgIHU6IHMgIT0gZm4ubGVuZ3RoIHx8IChtICYmIChjb20ubGVuZ3RoICE9IG1zKSksXG4gICAgICAgICAgICAgICAgICAgIGNvbXByZXNzaW9uOiBjb21wcmVzc2lvblxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIG8gKz0gMzAgKyBzICsgZXhsICsgbDtcbiAgICAgICAgICAgICAgICB0b3QgKz0gNzYgKyAyICogKHMgKyBleGwpICsgKG1zIHx8IDApICsgbDtcbiAgICAgICAgICAgICAgICBpZiAoIS0tbGZ0KVxuICAgICAgICAgICAgICAgICAgICBjYmYoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgaWYgKHMgPiA2NTUzNSlcbiAgICAgICAgICAgIGNibChlcnIoMTEsIDAsIDEpLCBudWxsKTtcbiAgICAgICAgaWYgKCFjb21wcmVzc2lvbilcbiAgICAgICAgICAgIGNibChudWxsLCBmaWxlKTtcbiAgICAgICAgZWxzZSBpZiAoc2l6ZSA8IDE2MDAwMCkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjYmwobnVsbCwgZGVmbGF0ZVN5bmMoZmlsZSwgcCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjYmwoZSwgbnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgdGVybS5wdXNoKGRlZmxhdGUoZmlsZSwgcCwgY2JsKSk7XG4gICAgfTtcbiAgICAvLyBDYW5ub3QgdXNlIGxmdCBiZWNhdXNlIGl0IGNhbiBkZWNyZWFzZVxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2xmdDsgKytpKSB7XG4gICAgICAgIF9sb29wXzEoaSk7XG4gICAgfVxuICAgIHJldHVybiB0QWxsO1xufVxuLyoqXG4gKiBTeW5jaHJvbm91c2x5IGNyZWF0ZXMgYSBaSVAgZmlsZS4gUHJlZmVyIHVzaW5nIGB6aXBgIGZvciBiZXR0ZXIgcGVyZm9ybWFuY2VcbiAqIHdpdGggbW9yZSB0aGFuIG9uZSBmaWxlLlxuICogQHBhcmFtIGRhdGEgVGhlIGRpcmVjdG9yeSBzdHJ1Y3R1cmUgZm9yIHRoZSBaSVAgYXJjaGl2ZVxuICogQHBhcmFtIG9wdHMgVGhlIG1haW4gb3B0aW9ucywgbWVyZ2VkIHdpdGggcGVyLWZpbGUgb3B0aW9uc1xuICogQHJldHVybnMgVGhlIGdlbmVyYXRlZCBaSVAgYXJjaGl2ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gemlwU3luYyhkYXRhLCBvcHRzKSB7XG4gICAgaWYgKCFvcHRzKVxuICAgICAgICBvcHRzID0ge307XG4gICAgdmFyIHIgPSB7fTtcbiAgICB2YXIgZmlsZXMgPSBbXTtcbiAgICBmbHRuKGRhdGEsICcnLCByLCBvcHRzKTtcbiAgICB2YXIgbyA9IDA7XG4gICAgdmFyIHRvdCA9IDA7XG4gICAgZm9yICh2YXIgZm4gaW4gcikge1xuICAgICAgICB2YXIgX2EgPSByW2ZuXSwgZmlsZSA9IF9hWzBdLCBwID0gX2FbMV07XG4gICAgICAgIHZhciBjb21wcmVzc2lvbiA9IHAubGV2ZWwgPT0gMCA/IDAgOiA4O1xuICAgICAgICB2YXIgZiA9IHN0clRvVTgoZm4pLCBzID0gZi5sZW5ndGg7XG4gICAgICAgIHZhciBjb20gPSBwLmNvbW1lbnQsIG0gPSBjb20gJiYgc3RyVG9VOChjb20pLCBtcyA9IG0gJiYgbS5sZW5ndGg7XG4gICAgICAgIHZhciBleGwgPSBleGZsKHAuZXh0cmEpO1xuICAgICAgICBpZiAocyA+IDY1NTM1KVxuICAgICAgICAgICAgZXJyKDExKTtcbiAgICAgICAgdmFyIGQgPSBjb21wcmVzc2lvbiA/IGRlZmxhdGVTeW5jKGZpbGUsIHApIDogZmlsZSwgbCA9IGQubGVuZ3RoO1xuICAgICAgICB2YXIgYyA9IGNyYygpO1xuICAgICAgICBjLnAoZmlsZSk7XG4gICAgICAgIGZpbGVzLnB1c2gobXJnKHAsIHtcbiAgICAgICAgICAgIHNpemU6IGZpbGUubGVuZ3RoLFxuICAgICAgICAgICAgY3JjOiBjLmQoKSxcbiAgICAgICAgICAgIGM6IGQsXG4gICAgICAgICAgICBmOiBmLFxuICAgICAgICAgICAgbTogbSxcbiAgICAgICAgICAgIHU6IHMgIT0gZm4ubGVuZ3RoIHx8IChtICYmIChjb20ubGVuZ3RoICE9IG1zKSksXG4gICAgICAgICAgICBvOiBvLFxuICAgICAgICAgICAgY29tcHJlc3Npb246IGNvbXByZXNzaW9uXG4gICAgICAgIH0pKTtcbiAgICAgICAgbyArPSAzMCArIHMgKyBleGwgKyBsO1xuICAgICAgICB0b3QgKz0gNzYgKyAyICogKHMgKyBleGwpICsgKG1zIHx8IDApICsgbDtcbiAgICB9XG4gICAgdmFyIG91dCA9IG5ldyB1OCh0b3QgKyAyMiksIG9lID0gbywgY2RsID0gdG90IC0gbztcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGZpbGVzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgIHZhciBmID0gZmlsZXNbaV07XG4gICAgICAgIHd6aChvdXQsIGYubywgZiwgZi5mLCBmLnUsIGYuYy5sZW5ndGgpO1xuICAgICAgICB2YXIgYmFkZCA9IDMwICsgZi5mLmxlbmd0aCArIGV4ZmwoZi5leHRyYSk7XG4gICAgICAgIG91dC5zZXQoZi5jLCBmLm8gKyBiYWRkKTtcbiAgICAgICAgd3poKG91dCwgbywgZiwgZi5mLCBmLnUsIGYuYy5sZW5ndGgsIGYubywgZi5tKSwgbyArPSAxNiArIGJhZGQgKyAoZi5tID8gZi5tLmxlbmd0aCA6IDApO1xuICAgIH1cbiAgICB3emYob3V0LCBvLCBmaWxlcy5sZW5ndGgsIGNkbCwgb2UpO1xuICAgIHJldHVybiBvdXQ7XG59XG4vKipcbiAqIFN0cmVhbWluZyBwYXNzLXRocm91Z2ggZGVjb21wcmVzc2lvbiBmb3IgWklQIGFyY2hpdmVzXG4gKi9cbnZhciBVbnppcFBhc3NUaHJvdWdoID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIFVuemlwUGFzc1Rocm91Z2goKSB7XG4gICAgfVxuICAgIFVuemlwUGFzc1Rocm91Z2gucHJvdG90eXBlLnB1c2ggPSBmdW5jdGlvbiAoY2h1bmssIGZpbmFsKSB7XG4gICAgICAgIC8vIHNhbWUgYXMgWmlwUGFzc1Rocm91Z2g6IGNhc3QgdG8gcmV0YWluIEJ1ZmZlciBlcmdvbm9taWNzXG4gICAgICAgIHRoaXMub25kYXRhKG51bGwsIGNodW5rLCBmaW5hbCk7XG4gICAgfTtcbiAgICBVbnppcFBhc3NUaHJvdWdoLmNvbXByZXNzaW9uID0gMDtcbiAgICByZXR1cm4gVW56aXBQYXNzVGhyb3VnaDtcbn0oKSk7XG5leHBvcnQgeyBVbnppcFBhc3NUaHJvdWdoIH07XG4vKipcbiAqIFN0cmVhbWluZyBERUZMQVRFIGRlY29tcHJlc3Npb24gZm9yIFpJUCBhcmNoaXZlcy4gUHJlZmVyIEFzeW5jWmlwSW5mbGF0ZSBmb3JcbiAqIGJldHRlciBwZXJmb3JtYW5jZS5cbiAqL1xudmFyIFVuemlwSW5mbGF0ZSA9IC8qI19fUFVSRV9fKi8gKGZ1bmN0aW9uICgpIHtcbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgREVGTEFURSBkZWNvbXByZXNzaW9uIHRoYXQgY2FuIGJlIHVzZWQgaW4gWklQIGFyY2hpdmVzXG4gICAgICovXG4gICAgZnVuY3Rpb24gVW56aXBJbmZsYXRlKCkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICB0aGlzLmkgPSBuZXcgSW5mbGF0ZShmdW5jdGlvbiAoZGF0LCBmaW5hbCkge1xuICAgICAgICAgICAgX3RoaXMub25kYXRhKG51bGwsIGRhdCwgZmluYWwpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgVW56aXBJbmZsYXRlLnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBmaW5hbCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdGhpcy5pLnB1c2goY2h1bmssIGZpbmFsKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgdGhpcy5vbmRhdGEoZSwgbnVsbCwgZmluYWwpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBVbnppcEluZmxhdGUuY29tcHJlc3Npb24gPSA4O1xuICAgIHJldHVybiBVbnppcEluZmxhdGU7XG59KCkpO1xuZXhwb3J0IHsgVW56aXBJbmZsYXRlIH07XG4vKipcbiAqIEFzeW5jaHJvbm91cyBzdHJlYW1pbmcgREVGTEFURSBkZWNvbXByZXNzaW9uIGZvciBaSVAgYXJjaGl2ZXNcbiAqL1xudmFyIEFzeW5jVW56aXBJbmZsYXRlID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBERUZMQVRFIGRlY29tcHJlc3Npb24gdGhhdCBjYW4gYmUgdXNlZCBpbiBaSVAgYXJjaGl2ZXNcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBBc3luY1VuemlwSW5mbGF0ZShfLCBzeikge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBpZiAoc3ogPCAzMjAwMDApIHtcbiAgICAgICAgICAgIHRoaXMuaSA9IG5ldyBJbmZsYXRlKGZ1bmN0aW9uIChkYXQsIGZpbmFsKSB7XG4gICAgICAgICAgICAgICAgX3RoaXMub25kYXRhKG51bGwsIGRhdCwgZmluYWwpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmkgPSBuZXcgQXN5bmNJbmZsYXRlKGZ1bmN0aW9uIChlcnIsIGRhdCwgZmluYWwpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5vbmRhdGEoZXJyLCBkYXQsIGZpbmFsKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy50ZXJtaW5hdGUgPSB0aGlzLmkudGVybWluYXRlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEFzeW5jVW56aXBJbmZsYXRlLnByb3RvdHlwZS5wdXNoID0gZnVuY3Rpb24gKGNodW5rLCBmaW5hbCkge1xuICAgICAgICBpZiAodGhpcy5pLnRlcm1pbmF0ZSlcbiAgICAgICAgICAgIGNodW5rID0gc2xjKGNodW5rLCAwKTtcbiAgICAgICAgdGhpcy5pLnB1c2goY2h1bmssIGZpbmFsKTtcbiAgICB9O1xuICAgIEFzeW5jVW56aXBJbmZsYXRlLmNvbXByZXNzaW9uID0gODtcbiAgICByZXR1cm4gQXN5bmNVbnppcEluZmxhdGU7XG59KCkpO1xuZXhwb3J0IHsgQXN5bmNVbnppcEluZmxhdGUgfTtcbi8qKlxuICogQSBaSVAgYXJjaGl2ZSBkZWNvbXByZXNzaW9uIHN0cmVhbSB0aGF0IGVtaXRzIGZpbGVzIGFzIHRoZXkgYXJlIGRpc2NvdmVyZWRcbiAqL1xudmFyIFVuemlwID0gLyojX19QVVJFX18qLyAoZnVuY3Rpb24gKCkge1xuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSBaSVAgZGVjb21wcmVzc2lvbiBzdHJlYW1cbiAgICAgKiBAcGFyYW0gY2IgVGhlIGNhbGxiYWNrIHRvIGNhbGwgd2hlbmV2ZXIgYSBmaWxlIGluIHRoZSBaSVAgYXJjaGl2ZSBpcyBmb3VuZFxuICAgICAqL1xuICAgIGZ1bmN0aW9uIFVuemlwKGNiKSB7XG4gICAgICAgIHRoaXMub25maWxlID0gY2I7XG4gICAgICAgIHRoaXMuayA9IFtdO1xuICAgICAgICB0aGlzLm8gPSB7XG4gICAgICAgICAgICAwOiBVbnppcFBhc3NUaHJvdWdoXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMucCA9IGV0O1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBQdXNoZXMgYSBjaHVuayB0byBiZSB1bnppcHBlZFxuICAgICAqIEBwYXJhbSBjaHVuayBUaGUgY2h1bmsgdG8gcHVzaFxuICAgICAqIEBwYXJhbSBmaW5hbCBXaGV0aGVyIHRoaXMgaXMgdGhlIGxhc3QgY2h1bmtcbiAgICAgKi9cbiAgICBVbnppcC5wcm90b3R5cGUucHVzaCA9IGZ1bmN0aW9uIChjaHVuaywgZmluYWwpIHtcbiAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgaWYgKCF0aGlzLm9uZmlsZSlcbiAgICAgICAgICAgIGVycig1KTtcbiAgICAgICAgaWYgKCF0aGlzLnApXG4gICAgICAgICAgICBlcnIoNCk7XG4gICAgICAgIGlmICh0aGlzLmMgPiAwKSB7XG4gICAgICAgICAgICB2YXIgbGVuID0gTWF0aC5taW4odGhpcy5jLCBjaHVuay5sZW5ndGgpO1xuICAgICAgICAgICAgdmFyIHRvQWRkID0gY2h1bmsuc3ViYXJyYXkoMCwgbGVuKTtcbiAgICAgICAgICAgIHRoaXMuYyAtPSBsZW47XG4gICAgICAgICAgICBpZiAodGhpcy5kKVxuICAgICAgICAgICAgICAgIHRoaXMuZC5wdXNoKHRvQWRkLCAhdGhpcy5jKTtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICB0aGlzLmtbMF0ucHVzaCh0b0FkZCk7XG4gICAgICAgICAgICBjaHVuayA9IGNodW5rLnN1YmFycmF5KGxlbik7XG4gICAgICAgICAgICBpZiAoY2h1bmsubGVuZ3RoKVxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnB1c2goY2h1bmssIGZpbmFsKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhciBmID0gMCwgaSA9IDAsIGlzID0gdm9pZCAwLCBidWYgPSB2b2lkIDA7XG4gICAgICAgICAgICBpZiAoIXRoaXMucC5sZW5ndGgpXG4gICAgICAgICAgICAgICAgYnVmID0gY2h1bms7XG4gICAgICAgICAgICBlbHNlIGlmICghY2h1bmsubGVuZ3RoKVxuICAgICAgICAgICAgICAgIGJ1ZiA9IHRoaXMucDtcbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJ1ZiA9IG5ldyB1OCh0aGlzLnAubGVuZ3RoICsgY2h1bmsubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBidWYuc2V0KHRoaXMucCksIGJ1Zi5zZXQoY2h1bmssIHRoaXMucC5sZW5ndGgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGwgPSBidWYubGVuZ3RoLCBvYyA9IHRoaXMuYywgYWRkID0gb2MgJiYgdGhpcy5kO1xuICAgICAgICAgICAgdmFyIF9sb29wXzIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgdmFyIHNpZyA9IGI0KGJ1ZiwgaSk7XG4gICAgICAgICAgICAgICAgaWYgKHNpZyA9PSAweDQwMzRCNTApIHtcbiAgICAgICAgICAgICAgICAgICAgZiA9IDEsIGlzID0gaTtcbiAgICAgICAgICAgICAgICAgICAgdGhpc18xLmQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB0aGlzXzEuYyA9IDA7XG4gICAgICAgICAgICAgICAgICAgIHZhciBiZiA9IGIyKGJ1ZiwgaSArIDYpLCBjbXBfMSA9IGIyKGJ1ZiwgaSArIDgpLCB1ID0gYmYgJiAyMDQ4LCBkZCA9IGJmICYgOCwgZm5sID0gYjIoYnVmLCBpICsgMjYpLCBlcyA9IGIyKGJ1ZiwgaSArIDI4KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGwgPiBpICsgMzAgKyBmbmwgKyBlcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGNoa3NfMyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpc18xLmsudW5zaGlmdChjaGtzXzMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZiA9IDI7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbHNjID0gYjQoYnVmLCBpICsgMTgpLCBsc3UgPSBiNChidWYsIGkgKyAyMik7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZm5fMSA9IHN0ckZyb21VOChidWYuc3ViYXJyYXkoaSArIDMwLCBpICs9IDMwICsgZm5sKSwgIXUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF9hID0gejY0aHMoYnVmLCBpLCBlcywgMiwgbHNjLCBsc3UsIDApLCBzY18xID0gX2FbMF0sIHN1XzEgPSBfYVsxXSwgejY0ID0gX2FbM107XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NfMSA9IC0xIC0gejY0O1xuICAgICAgICAgICAgICAgICAgICAgICAgaSArPSBlcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNfMS5jID0gc2NfMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBkXzE7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgZmlsZV8xID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IGZuXzEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcHJlc3Npb246IGNtcF8xLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZmlsZV8xLm9uZGF0YSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVycig1KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFzY18xKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsZV8xLm9uZGF0YShudWxsLCBldCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGN0ciA9IF90aGlzLm9bY21wXzFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFjdHIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsZV8xLm9uZGF0YShlcnIoMTQsICd1bmtub3duIGNvbXByZXNzaW9uIHR5cGUgJyArIGNtcF8xLCAxKSwgbnVsbCwgZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZF8xID0gc2NfMSA8IDAgPyBuZXcgY3RyKGZuXzEpIDogbmV3IGN0cihmbl8xLCBzY18xLCBzdV8xKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRfMS5vbmRhdGEgPSBmdW5jdGlvbiAoZXJyLCBkYXQsIGZpbmFsKSB7IGZpbGVfMS5vbmRhdGEoZXJyLCBkYXQsIGZpbmFsKTsgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9pID0gMCwgY2hrc180ID0gY2hrc18zOyBfaSA8IGNoa3NfNC5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGF0ID0gY2hrc180W19pXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkXzEucHVzaChkYXQsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfdGhpcy5rWzBdID09IGNoa3NfMyAmJiBfdGhpcy5jKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmQgPSBkXzE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZF8xLnB1c2goZXQsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXJtaW5hdGU6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRfMSAmJiBkXzEudGVybWluYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZF8xLnRlcm1pbmF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc2NfMSA+PSAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVfMS5zaXplID0gc2NfMSwgZmlsZV8xLm9yaWdpbmFsU2l6ZSA9IHN1XzE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzXzEub25maWxlKGZpbGVfMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiYnJlYWtcIjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAob2MpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNpZyA9PSAweDgwNzRCNTApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzID0gaSArPSAxMiArIChvYyA9PSAtMiAmJiA4KSwgZiA9IDMsIHRoaXNfMS5jID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcImJyZWFrXCI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoc2lnID09IDB4MjAxNEI1MCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaXMgPSBpIC09IDQsIGYgPSAzLCB0aGlzXzEuYyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJicmVha1wiO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHZhciB0aGlzXzEgPSB0aGlzO1xuICAgICAgICAgICAgZm9yICg7IGkgPCBsIC0gNDsgKytpKSB7XG4gICAgICAgICAgICAgICAgdmFyIHN0YXRlXzEgPSBfbG9vcF8yKCk7XG4gICAgICAgICAgICAgICAgaWYgKHN0YXRlXzEgPT09IFwiYnJlYWtcIilcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnAgPSBldDtcbiAgICAgICAgICAgIGlmIChvYyA8IDApIHtcbiAgICAgICAgICAgICAgICB2YXIgZGF0ID0gZiA/IGJ1Zi5zdWJhcnJheSgwLCBpcyAtIDEyIC0gKG9jID09IC0yICYmIDgpIC0gKGI0KGJ1ZiwgaXMgLSAxNikgPT0gMHg4MDc0QjUwICYmIDQpKSA6IGJ1Zi5zdWJhcnJheSgwLCBpKTtcbiAgICAgICAgICAgICAgICBpZiAoYWRkKVxuICAgICAgICAgICAgICAgICAgICBhZGQucHVzaChkYXQsICEhZik7XG4gICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmtbKyhmID09IDIpXS5wdXNoKGRhdCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoZiAmIDIpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucHVzaChidWYuc3ViYXJyYXkoaSksIGZpbmFsKTtcbiAgICAgICAgICAgIHRoaXMucCA9IGJ1Zi5zdWJhcnJheShpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZmluYWwpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLmMpXG4gICAgICAgICAgICAgICAgZXJyKDEzKTtcbiAgICAgICAgICAgIHRoaXMucCA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFJlZ2lzdGVycyBhIGRlY29kZXIgd2l0aCB0aGUgc3RyZWFtLCBhbGxvd2luZyBmb3IgZmlsZXMgY29tcHJlc3NlZCB3aXRoXG4gICAgICogdGhlIGNvbXByZXNzaW9uIHR5cGUgcHJvdmlkZWQgdG8gYmUgZXhwYW5kZWQgY29ycmVjdGx5XG4gICAgICogQHBhcmFtIGRlY29kZXIgVGhlIGRlY29kZXIgY29uc3RydWN0b3JcbiAgICAgKi9cbiAgICBVbnppcC5wcm90b3R5cGUucmVnaXN0ZXIgPSBmdW5jdGlvbiAoZGVjb2Rlcikge1xuICAgICAgICB0aGlzLm9bZGVjb2Rlci5jb21wcmVzc2lvbl0gPSBkZWNvZGVyO1xuICAgIH07XG4gICAgcmV0dXJuIFVuemlwO1xufSgpKTtcbmV4cG9ydCB7IFVuemlwIH07XG52YXIgbXQgPSB0eXBlb2YgcXVldWVNaWNyb3Rhc2sgPT0gJ2Z1bmN0aW9uJyA/IHF1ZXVlTWljcm90YXNrIDogdHlwZW9mIHNldFRpbWVvdXQgPT0gJ2Z1bmN0aW9uJyA/IHNldFRpbWVvdXQgOiBmdW5jdGlvbiAoZm4pIHsgZm4oKTsgfTtcbmV4cG9ydCBmdW5jdGlvbiB1bnppcChkYXRhLCBvcHRzLCBjYikge1xuICAgIGlmICghY2IpXG4gICAgICAgIGNiID0gb3B0cywgb3B0cyA9IHt9O1xuICAgIGlmICh0eXBlb2YgY2IgIT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgZXJyKDcpO1xuICAgIHZhciB0ZXJtID0gW107XG4gICAgdmFyIHRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGVybS5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgIHRlcm1baV0oKTtcbiAgICB9O1xuICAgIHZhciBmaWxlcyA9IHt9O1xuICAgIHZhciBjYmQgPSBmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICBtdChmdW5jdGlvbiAoKSB7IGNiKGEsIGIpOyB9KTtcbiAgICB9O1xuICAgIG10KGZ1bmN0aW9uICgpIHsgY2JkID0gY2I7IH0pO1xuICAgIHZhciBlID0gZGF0YS5sZW5ndGggLSAyMjtcbiAgICBmb3IgKDsgYjQoZGF0YSwgZSkgIT0gMHg2MDU0QjUwOyAtLWUpIHtcbiAgICAgICAgaWYgKCFlIHx8IGRhdGEubGVuZ3RoIC0gZSA+IDY1NTU4KSB7XG4gICAgICAgICAgICBjYmQoZXJyKDEzLCAwLCAxKSwgbnVsbCk7XG4gICAgICAgICAgICByZXR1cm4gdEFsbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICA7XG4gICAgdmFyIGxmdCA9IGIyKGRhdGEsIGUgKyA4KTtcbiAgICBpZiAobGZ0KSB7XG4gICAgICAgIHZhciBjID0gbGZ0O1xuICAgICAgICB2YXIgbyA9IGI0KGRhdGEsIGUgKyAxNik7XG4gICAgICAgIHZhciB6ID0gYjQoZGF0YSwgZSAtIDIwKSA9PSAweDcwNjRCNTA7XG4gICAgICAgIGlmICh6KSB7XG4gICAgICAgICAgICB2YXIgemUgPSBiNChkYXRhLCBlIC0gMTIpO1xuICAgICAgICAgICAgeiA9IGI0KGRhdGEsIHplKSA9PSAweDYwNjRCNTA7XG4gICAgICAgICAgICBpZiAoeikge1xuICAgICAgICAgICAgICAgIGMgPSBsZnQgPSBiNChkYXRhLCB6ZSArIDMyKTtcbiAgICAgICAgICAgICAgICBvID0gYjQoZGF0YSwgemUgKyA0OCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGZsdHIgPSBvcHRzICYmIG9wdHMuZmlsdGVyO1xuICAgICAgICB2YXIgX2xvb3BfMyA9IGZ1bmN0aW9uIChpKSB7XG4gICAgICAgICAgICB2YXIgX2EgPSB6aChkYXRhLCBvLCB6KSwgY18xID0gX2FbMF0sIHNjID0gX2FbMV0sIHN1ID0gX2FbMl0sIGZuID0gX2FbM10sIG5vID0gX2FbNF0sIG9mZiA9IF9hWzVdLCBiID0gc2x6aChkYXRhLCBvZmYpO1xuICAgICAgICAgICAgbyA9IG5vO1xuICAgICAgICAgICAgdmFyIGNibCA9IGZ1bmN0aW9uIChlLCBkKSB7XG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgdEFsbCgpO1xuICAgICAgICAgICAgICAgICAgICBjYmQoZSwgbnVsbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZClcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVzW2ZuXSA9IGQ7XG4gICAgICAgICAgICAgICAgICAgIGlmICghLS1sZnQpXG4gICAgICAgICAgICAgICAgICAgICAgICBjYmQobnVsbCwgZmlsZXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIWZsdHIgfHwgZmx0cih7XG4gICAgICAgICAgICAgICAgbmFtZTogZm4sXG4gICAgICAgICAgICAgICAgc2l6ZTogc2MsXG4gICAgICAgICAgICAgICAgb3JpZ2luYWxTaXplOiBzdSxcbiAgICAgICAgICAgICAgICBjb21wcmVzc2lvbjogY18xXG4gICAgICAgICAgICB9KSkge1xuICAgICAgICAgICAgICAgIGlmICghY18xKVxuICAgICAgICAgICAgICAgICAgICBjYmwobnVsbCwgc2xjKGRhdGEsIGIsIGIgKyBzYykpO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGNfMSA9PSA4KSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBpbmZsID0gZGF0YS5zdWJhcnJheShiLCBiICsgc2MpO1xuICAgICAgICAgICAgICAgICAgICAvLyBTeW5jaHJvbm91c2x5IGRlY29tcHJlc3MgdW5kZXIgNTEyS0IsIG9yIGJhcmVseS1jb21wcmVzc2VkIGRhdGFcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN1IDwgNTI0Mjg4IHx8IHNjID4gMC44ICogc3UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2JsKG51bGwsIGluZmxhdGVTeW5jKGluZmwsIHsgb3V0OiBuZXcgdTgoc3UpIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2JsKGUsIG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlcm0ucHVzaChpbmZsYXRlKGluZmwsIHsgc2l6ZTogc3UgfSwgY2JsKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgY2JsKGVycigxNCwgJ3Vua25vd24gY29tcHJlc3Npb24gdHlwZSAnICsgY18xLCAxKSwgbnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgY2JsKG51bGwsIG51bGwpO1xuICAgICAgICB9O1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGM7ICsraSkge1xuICAgICAgICAgICAgX2xvb3BfMyhpKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlXG4gICAgICAgIGNiZChudWxsLCB7fSk7XG4gICAgcmV0dXJuIHRBbGw7XG59XG4vKipcbiAqIFN5bmNocm9ub3VzbHkgZGVjb21wcmVzc2VzIGEgWklQIGFyY2hpdmUuIFByZWZlciB1c2luZyBgdW56aXBgIGZvciBiZXR0ZXJcbiAqIHBlcmZvcm1hbmNlIHdpdGggbW9yZSB0aGFuIG9uZSBmaWxlLlxuICogQHBhcmFtIGRhdGEgVGhlIHJhdyBjb21wcmVzc2VkIFpJUCBmaWxlXG4gKiBAcGFyYW0gb3B0cyBUaGUgWklQIGV4dHJhY3Rpb24gb3B0aW9uc1xuICogQHJldHVybnMgVGhlIGRlY29tcHJlc3NlZCBmaWxlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gdW56aXBTeW5jKGRhdGEsIG9wdHMpIHtcbiAgICB2YXIgZmlsZXMgPSB7fTtcbiAgICB2YXIgZSA9IGRhdGEubGVuZ3RoIC0gMjI7XG4gICAgZm9yICg7IGI0KGRhdGEsIGUpICE9IDB4NjA1NEI1MDsgLS1lKSB7XG4gICAgICAgIGlmICghZSB8fCBkYXRhLmxlbmd0aCAtIGUgPiA2NTU1OClcbiAgICAgICAgICAgIGVycigxMyk7XG4gICAgfVxuICAgIDtcbiAgICB2YXIgYyA9IGIyKGRhdGEsIGUgKyA4KTtcbiAgICBpZiAoIWMpXG4gICAgICAgIHJldHVybiB7fTtcbiAgICB2YXIgbyA9IGI0KGRhdGEsIGUgKyAxNik7XG4gICAgdmFyIHogPSBiNChkYXRhLCBlIC0gMjApID09IDB4NzA2NEI1MDtcbiAgICBpZiAoeikge1xuICAgICAgICB2YXIgemUgPSBiNChkYXRhLCBlIC0gMTIpO1xuICAgICAgICB6ID0gYjQoZGF0YSwgemUpID09IDB4NjA2NEI1MDtcbiAgICAgICAgaWYgKHopIHtcbiAgICAgICAgICAgIGMgPSBiNChkYXRhLCB6ZSArIDMyKTtcbiAgICAgICAgICAgIG8gPSBiNChkYXRhLCB6ZSArIDQ4KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB2YXIgZmx0ciA9IG9wdHMgJiYgb3B0cy5maWx0ZXI7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjOyArK2kpIHtcbiAgICAgICAgdmFyIF9hID0gemgoZGF0YSwgbywgeiksIGNfMiA9IF9hWzBdLCBzYyA9IF9hWzFdLCBzdSA9IF9hWzJdLCBmbiA9IF9hWzNdLCBubyA9IF9hWzRdLCBvZmYgPSBfYVs1XSwgYiA9IHNsemgoZGF0YSwgb2ZmKTtcbiAgICAgICAgbyA9IG5vO1xuICAgICAgICBpZiAoIWZsdHIgfHwgZmx0cih7XG4gICAgICAgICAgICBuYW1lOiBmbixcbiAgICAgICAgICAgIHNpemU6IHNjLFxuICAgICAgICAgICAgb3JpZ2luYWxTaXplOiBzdSxcbiAgICAgICAgICAgIGNvbXByZXNzaW9uOiBjXzJcbiAgICAgICAgfSkpIHtcbiAgICAgICAgICAgIGlmICghY18yKVxuICAgICAgICAgICAgICAgIGZpbGVzW2ZuXSA9IHNsYyhkYXRhLCBiLCBiICsgc2MpO1xuICAgICAgICAgICAgZWxzZSBpZiAoY18yID09IDgpXG4gICAgICAgICAgICAgICAgZmlsZXNbZm5dID0gaW5mbGF0ZVN5bmMoZGF0YS5zdWJhcnJheShiLCBiICsgc2MpLCB7IG91dDogbmV3IHU4KHN1KSB9KTtcbiAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICBlcnIoMTQsICd1bmtub3duIGNvbXByZXNzaW9uIHR5cGUgJyArIGNfMik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZpbGVzO1xufVxuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7QUFTQSxJQUFJLE1BQU0sQ0FBQztBQUNYLElBQUksTUFBTSxTQUFVLEdBQUcsSUFBSSxLQUFLLFVBQVUsSUFBSTtDQUMxQyxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksUUFBUSxJQUFJLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSSxLQUFLLENBQ2xFLElBQUksbUdBQ1IsR0FBRyxFQUFFLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxFQUFFO0NBQ2pDLEVBQUUsWUFBWSxTQUFVLEdBQUc7RUFDdkIsSUFBSSxJQUFJLEVBQUUsTUFBTSxLQUFLLEVBQUU7RUFDdkIsSUFBSSxJQUFJO0dBQ0osSUFBSSxNQUFNLElBQUksTUFBTSxHQUFHLEVBQUU7R0FDekIsSUFBSSxVQUFVLEdBQUc7R0FDakIsSUFBSSxRQUFRLEdBQUc7R0FDZixHQUFHLEtBQUssSUFBSTtFQUNoQixPQUVJLEdBQUcsTUFBTSxDQUFDO0NBQ2xCO0NBQ0EsRUFBRSxZQUFZLEtBQUssUUFBUTtDQUMzQixPQUFPO0FBQ1g7QUFHQSxJQUFJLEtBQUs7SUFBWSxNQUFNO0lBQWEsTUFBTTtBQUU5QyxJQUFJLE9BQU8sSUFBSSxHQUFHO0NBQUM7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFnQjtDQUFHO0NBQW9CO0FBQUMsQ0FBQztBQUVoSixJQUFJLE9BQU8sSUFBSSxHQUFHO0NBQUM7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBRztDQUFJO0NBQUk7Q0FBSTtDQUFJO0NBQUk7Q0FBSTtDQUFJO0NBQWlCO0NBQUc7QUFBQyxDQUFDO0FBRXZJLElBQUksT0FBTyxJQUFJLEdBQUc7Q0FBQztDQUFJO0NBQUk7Q0FBSTtDQUFHO0NBQUc7Q0FBRztDQUFHO0NBQUc7Q0FBSTtDQUFHO0NBQUk7Q0FBRztDQUFJO0NBQUc7Q0FBSTtDQUFHO0NBQUk7Q0FBRztBQUFFLENBQUM7QUFFcEYsSUFBSSxPQUFPLFNBQVUsSUFBSSxPQUFPO0NBQzVCLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtDQUNsQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQ3RCLEVBQUUsS0FBSyxTQUFTLEtBQUssR0FBRyxJQUFJO0NBR2hDLElBQUksSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHO0NBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsR0FDdEIsS0FBSyxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxHQUMvQixFQUFFLEtBQU8sSUFBSSxFQUFFLE1BQU8sSUFBSztDQUduQyxPQUFPO0VBQUs7RUFBTTtDQUFFO0FBQ3hCO0FBQ0EsSUFBSSxLQUFLLEtBQUssTUFBTSxDQUFDO0lBQUcsS0FBSyxHQUFHO0lBQUcsUUFBUSxHQUFHO0FBRTlDLEdBQUcsTUFBTSxLQUFLLE1BQU0sT0FBTztBQUMzQixJQUFJLEtBQUssS0FBSyxNQUFNLENBQUM7SUFBRyxLQUFLLEdBQUc7SUFBRyxRQUFRLEdBQUc7QUFFOUMsSUFBSSxNQUFNLElBQUksSUFBSSxLQUFLO0FBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLEVBQUUsR0FBRztDQUU1QixJQUFJLEtBQU0sSUFBSSxVQUFXLEtBQU8sSUFBSSxVQUFXO0NBQy9DLEtBQU0sSUFBSSxVQUFXLEtBQU8sSUFBSSxVQUFXO0NBQzNDLEtBQU0sSUFBSSxVQUFXLEtBQU8sSUFBSSxTQUFXO0NBQzNDLElBQUksT0FBUSxJQUFJLFVBQVcsS0FBTyxJQUFJLFFBQVcsTUFBTztBQUM1RDtBQUlBLElBQUksUUFBUSxTQUFVLElBQUksSUFBSSxHQUFHO0NBQzdCLElBQUksSUFBSSxHQUFHO0NBRVgsSUFBSSxJQUFJO0NBRVIsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0NBRWxCLE9BQU8sSUFBSSxHQUFHLEVBQUUsR0FDWixJQUFJLEdBQUcsSUFDSCxFQUFFLEVBQUUsR0FBRyxLQUFLO0NBR3BCLElBQUksS0FBSyxJQUFJLElBQUksRUFBRTtDQUNuQixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxHQUNsQixHQUFHLEtBQU0sR0FBRyxJQUFJLEtBQUssRUFBRSxJQUFJLE1BQU87Q0FFdEMsSUFBSTtDQUNKLElBQUksR0FBRztFQUVILEtBQUssSUFBSSxJQUFJLEtBQUssRUFBRTtFQUVwQixJQUFJLE1BQU0sS0FBSztFQUNmLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBRWpCLElBQUksR0FBRyxJQUFJO0dBRVAsSUFBSSxLQUFNLEtBQUssSUFBSyxHQUFHO0dBRXZCLElBQUksTUFBTSxLQUFLLEdBQUc7R0FFbEIsSUFBSSxJQUFJLEdBQUcsR0FBRyxLQUFLLEVBQUUsTUFBTTtHQUUzQixLQUFLLElBQUksSUFBSSxLQUFNLEtBQUssT0FBTyxHQUFJLEtBQUssR0FBRyxFQUFFLEdBRXpDLEdBQUcsSUFBSSxNQUFNLE9BQU87RUFFNUI7Q0FFUixPQUNLO0VBQ0QsS0FBSyxJQUFJLElBQUksQ0FBQztFQUNkLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQ2pCLElBQUksR0FBRyxJQUNILEdBQUcsS0FBSyxJQUFJLEdBQUcsR0FBRyxLQUFLLEVBQUUsT0FBUSxLQUFLLEdBQUc7Q0FHckQ7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxJQUFJLE1BQU0sSUFBSSxHQUFHLEdBQUc7QUFDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRSxHQUN2QixJQUFJLEtBQUs7QUFDYixLQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLEdBQ3pCLElBQUksS0FBSztBQUNiLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLEVBQUUsR0FDekIsSUFBSSxLQUFLO0FBQ2IsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxHQUN6QixJQUFJLEtBQUs7QUFFYixJQUFJLE1BQU0sSUFBSSxHQUFHLEVBQUU7QUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxHQUN0QixJQUFJLEtBQUs7QUFFYixJQUFJLE1BQW9CLG1CQUFLLEtBQUssR0FBRyxDQUFDO0lBQUcsT0FBcUIsbUJBQUssS0FBSyxHQUFHLENBQUM7QUFFNUUsSUFBSSxNQUFvQixtQkFBSyxLQUFLLEdBQUcsQ0FBQztJQUFHLE9BQXFCLG1CQUFLLEtBQUssR0FBRyxDQUFDO0FBRTVFLElBQUksTUFBTSxTQUFVLEdBQUc7Q0FDbkIsSUFBSSxJQUFJLEVBQUU7Q0FDVixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEVBQUUsR0FDNUIsSUFBSSxFQUFFLEtBQUssR0FDUCxJQUFJLEVBQUU7Q0FFZCxPQUFPO0FBQ1g7QUFFQSxJQUFJLE9BQU8sU0FBVSxHQUFHLEdBQUcsR0FBRztDQUMxQixJQUFJLElBQUssSUFBSSxJQUFLO0NBQ2xCLFFBQVMsRUFBRSxLQUFNLEVBQUUsSUFBSSxNQUFNLE9BQVEsSUFBSSxLQUFNO0FBQ25EO0FBRUEsSUFBSSxTQUFTLFNBQVUsR0FBRyxHQUFHO0NBQ3pCLElBQUksSUFBSyxJQUFJLElBQUs7Q0FDbEIsUUFBUyxFQUFFLEtBQU0sRUFBRSxJQUFJLE1BQU0sSUFBTSxFQUFFLElBQUksTUFBTSxRQUFTLElBQUk7QUFDaEU7QUFFQSxJQUFJLE9BQU8sU0FBVSxHQUFHO0NBQUUsUUFBUyxJQUFJLEtBQUssSUFBSztBQUFHO0FBR3BELElBQUksTUFBTSxTQUFVLEdBQUcsR0FBRyxHQUFHO0NBQ3pCLElBQUksS0FBSyxRQUFRLElBQUksR0FDakIsSUFBSTtDQUNSLElBQUksS0FBSyxRQUFRLElBQUksRUFBRSxRQUNuQixJQUFJLEVBQUU7Q0FFVixPQUFPLElBQUksR0FBRyxFQUFFLFNBQVMsR0FBRyxDQUFDLENBQUM7QUFDbEM7Ozs7QUFJQSxJQUFXLGlCQUFpQjtDQUN4QixlQUFlO0NBQ2Ysa0JBQWtCO0NBQ2xCLHNCQUFzQjtDQUN0QixpQkFBaUI7Q0FDakIsZ0JBQWdCO0NBQ2hCLGlCQUFpQjtDQUNqQixlQUFlO0NBQ2YsWUFBWTtDQUNaLGFBQWE7Q0FDYixtQkFBbUI7Q0FDbkIsYUFBYTtDQUNiLGlCQUFpQjtDQUNqQixpQkFBaUI7Q0FDakIsZ0JBQWdCO0NBQ2hCLDBCQUEwQjtBQUM5QjtBQUVBLElBQUksS0FBSztDQUNMO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTs7Q0FFQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUVKO0FBRUEsSUFBSSxNQUFNLFNBQVUsS0FBSyxLQUFLLElBQUk7Q0FDOUIsSUFBSSxJQUFJLElBQUksTUFBTSxPQUFPLEdBQUcsSUFBSTtDQUNoQyxFQUFFLE9BQU87Q0FDVCxJQUFJLE1BQU0sbUJBQ04sTUFBTSxrQkFBa0IsR0FBRyxHQUFHO0NBQ2xDLElBQUksQ0FBQyxJQUNELE1BQU07Q0FDVixPQUFPO0FBQ1g7QUFFQSxJQUFJLFFBQVEsU0FBVSxLQUFLLElBQUksS0FBSyxNQUFNO0NBRXRDLElBQUksS0FBSyxJQUFJLFFBQVEsS0FBSyxPQUFPLEtBQUssU0FBUztDQUMvQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxHQUFHLEdBQ25CLE9BQU8sT0FBTyxJQUFJLEdBQUcsQ0FBQztDQUMxQixJQUFJLFFBQVEsQ0FBQztDQUViLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSztDQUU5QixJQUFJLE9BQU8sR0FBRztDQUVkLElBQUksT0FDQSxNQUFNLElBQUksR0FBRyxLQUFLLENBQUM7Q0FFdkIsSUFBSSxPQUFPLFNBQVUsR0FBRztFQUNwQixJQUFJLEtBQUssSUFBSTtFQUViLElBQUksSUFBSSxJQUFJO0dBRVIsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztHQUNyQyxLQUFLLElBQUksR0FBRztHQUNaLE1BQU07RUFDVjtDQUNKO0NBRUEsSUFBSSxRQUFRLEdBQUcsS0FBSyxHQUFHLE1BQU0sR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsR0FBRyxLQUFLLEdBQUcsR0FBRyxNQUFNLEdBQUcsR0FBRyxNQUFNLEdBQUc7Q0FFbkcsSUFBSSxPQUFPLEtBQUs7Q0FDaEIsR0FBRztFQUNDLElBQUksQ0FBQyxJQUFJO0dBRUwsUUFBUSxLQUFLLEtBQUssS0FBSyxDQUFDO0dBRXhCLElBQUksT0FBTyxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUM7R0FDL0IsT0FBTztHQUNQLElBQUksQ0FBQyxNQUFNO0lBRVAsSUFBSSxJQUFJLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUksS0FBTSxJQUFJLElBQUksTUFBTSxHQUFJLElBQUksSUFBSTtJQUNuRSxJQUFJLElBQUksSUFBSTtLQUNSLElBQUksTUFDQSxJQUFJLENBQUM7S0FDVDtJQUNKO0lBRUEsSUFBSSxRQUNBLEtBQUssS0FBSyxDQUFDO0lBRWYsSUFBSSxJQUFJLElBQUksU0FBUyxHQUFHLENBQUMsR0FBRyxFQUFFO0lBRTlCLEdBQUcsSUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sSUFBSSxHQUFHLEdBQUcsSUFBSTtJQUMzQztHQUNKLE9BQ0ssSUFBSSxRQUFRLEdBQ2IsS0FBSyxNQUFNLEtBQUssTUFBTSxNQUFNLEdBQUcsTUFBTTtRQUNwQyxJQUFJLFFBQVEsR0FBRztJQUVoQixJQUFJLE9BQU8sS0FBSyxLQUFLLEtBQUssRUFBRSxJQUFJLEtBQUssUUFBUSxLQUFLLEtBQUssTUFBTSxJQUFJLEVBQUUsSUFBSTtJQUN2RSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSTtJQUN6QyxPQUFPO0lBRVAsSUFBSSxNQUFNLElBQUksR0FBRyxFQUFFO0lBRW5CLElBQUksTUFBTSxJQUFJLEdBQUcsRUFBRTtJQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxFQUFFLEdBRXpCLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSyxNQUFNLElBQUksR0FBRyxDQUFDO0lBRTNDLE9BQU8sUUFBUTtJQUVmLElBQUksTUFBTSxJQUFJLEdBQUcsR0FBRyxVQUFVLEtBQUssT0FBTztJQUUxQyxJQUFJLE1BQU0sS0FBSyxLQUFLLEtBQUssQ0FBQztJQUMxQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSztLQUNyQixJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxNQUFNO0tBRWpDLE9BQU8sSUFBSTtLQUVYLElBQUksSUFBSSxLQUFLO0tBRWIsSUFBSSxJQUFJLElBQ0osSUFBSSxPQUFPO1VBRVY7TUFFRCxJQUFJLElBQUksR0FBRyxJQUFJO01BQ2YsSUFBSSxLQUFLLElBQ0wsSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLENBQUMsR0FBRyxPQUFPLEdBQUcsSUFBSSxJQUFJLElBQUk7V0FDaEQsSUFBSSxLQUFLLElBQ1YsSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLENBQUMsR0FBRyxPQUFPO1dBQ2pDLElBQUksS0FBSyxJQUNWLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHLEdBQUcsT0FBTztNQUN6QyxPQUFPLEtBQ0gsSUFBSSxPQUFPO0tBQ25CO0lBQ0o7SUFFQSxJQUFJLEtBQUssSUFBSSxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUssSUFBSSxTQUFTLElBQUk7SUFFdEQsTUFBTSxJQUFJLEVBQUU7SUFFWixNQUFNLElBQUksRUFBRTtJQUNaLEtBQUssS0FBSyxJQUFJLEtBQUssQ0FBQztJQUNwQixLQUFLLEtBQUssSUFBSSxLQUFLLENBQUM7R0FDeEIsT0FFSSxJQUFJLENBQUM7R0FDVCxJQUFJLE1BQU0sTUFBTTtJQUNaLElBQUksTUFDQSxJQUFJLENBQUM7SUFDVDtHQUNKO0VBQ0o7RUFHQSxJQUFJLFFBQ0EsS0FBSyxLQUFLLE1BQU07RUFDcEIsSUFBSSxPQUFPLEtBQUssT0FBTyxHQUFHLE9BQU8sS0FBSyxPQUFPO0VBQzdDLElBQUksT0FBTztFQUNYLFFBQVEsT0FBTyxLQUFLO0dBRWhCLElBQUksSUFBSSxHQUFHLE9BQU8sS0FBSyxHQUFHLElBQUksTUFBTSxNQUFNLEtBQUs7R0FDL0MsT0FBTyxJQUFJO0dBQ1gsSUFBSSxNQUFNLE1BQU07SUFDWixJQUFJLE1BQ0EsSUFBSSxDQUFDO0lBQ1Q7R0FDSjtHQUNBLElBQUksQ0FBQyxHQUNELElBQUksQ0FBQztHQUNULElBQUksTUFBTSxLQUNOLElBQUksUUFBUTtRQUNYLElBQUksT0FBTyxLQUFLO0lBQ2pCLE9BQU8sS0FBSyxLQUFLO0lBQ2pCO0dBQ0osT0FDSztJQUNELElBQUksTUFBTSxNQUFNO0lBRWhCLElBQUksTUFBTSxLQUFLO0tBRVgsSUFBSSxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUs7S0FDNUIsTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQyxJQUFJLEdBQUc7S0FDeEMsT0FBTztJQUNYO0lBRUEsSUFBSSxJQUFJLEdBQUcsT0FBTyxLQUFLLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSztJQUNoRCxJQUFJLENBQUMsR0FDRCxJQUFJLENBQUM7SUFDVCxPQUFPLElBQUk7SUFDWCxJQUFJLEtBQUssR0FBRztJQUNaLElBQUksT0FBTyxHQUFHO0tBQ1YsSUFBSSxJQUFJLEtBQUs7S0FDYixNQUFNLE9BQU8sS0FBSyxHQUFHLEtBQUssS0FBSyxLQUFLLEdBQUcsT0FBTztJQUNsRDtJQUNBLElBQUksTUFBTSxNQUFNO0tBQ1osSUFBSSxNQUNBLElBQUksQ0FBQztLQUNUO0lBQ0o7SUFDQSxJQUFJLFFBQ0EsS0FBSyxLQUFLLE1BQU07SUFDcEIsSUFBSSxNQUFNLEtBQUs7SUFDZixJQUFJLEtBQUssSUFBSTtLQUNULElBQUksUUFBUSxLQUFLLElBQUksT0FBTyxLQUFLLElBQUksSUFBSSxHQUFHO0tBQzVDLElBQUksUUFBUSxLQUFLLEdBQ2IsSUFBSSxDQUFDO0tBQ1QsT0FBTyxLQUFLLE1BQU0sRUFBRSxJQUNoQixJQUFJLE1BQU0sS0FBSyxRQUFRO0lBQy9CO0lBQ0EsT0FBTyxLQUFLLEtBQUssRUFBRSxJQUNmLElBQUksTUFBTSxJQUFJLEtBQUs7R0FDM0I7RUFDSjtFQUNBLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSTtFQUMxQyxJQUFJLElBQ0EsUUFBUSxHQUFHLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEdBQUcsSUFBSTtDQUNqRCxTQUFTLENBQUM7Q0FFVixPQUFPLE1BQU0sSUFBSSxVQUFVLFFBQVEsSUFBSSxLQUFLLEdBQUcsRUFBRSxJQUFJLElBQUksU0FBUyxHQUFHLEVBQUU7QUFDM0U7QUFFQSxJQUFJLFFBQVEsU0FBVSxHQUFHLEdBQUcsR0FBRztDQUMzQixNQUFNLElBQUk7Q0FDVixJQUFJLElBQUssSUFBSSxJQUFLO0NBQ2xCLEVBQUUsTUFBTTtDQUNSLEVBQUUsSUFBSSxNQUFNLEtBQUs7QUFDckI7QUFFQSxJQUFJLFVBQVUsU0FBVSxHQUFHLEdBQUcsR0FBRztDQUM3QixNQUFNLElBQUk7Q0FDVixJQUFJLElBQUssSUFBSSxJQUFLO0NBQ2xCLEVBQUUsTUFBTTtDQUNSLEVBQUUsSUFBSSxNQUFNLEtBQUs7Q0FDakIsRUFBRSxJQUFJLE1BQU0sS0FBSztBQUNyQjtBQUVBLElBQUksUUFBUSxTQUFVLEdBQUcsSUFBSTtDQUV6QixJQUFJLElBQUksQ0FBQztDQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUM1QixJQUFJLEVBQUUsSUFDRixFQUFFLEtBQUs7RUFBRSxHQUFHO0VBQUcsR0FBRyxFQUFFO0NBQUcsQ0FBQztDQUVoQyxJQUFJLElBQUksRUFBRTtDQUNWLElBQUksS0FBSyxFQUFFLE1BQU07Q0FDakIsSUFBSSxDQUFDLEdBQ0QsT0FBTztFQUFFLEdBQUc7RUFBSSxHQUFHO0NBQUU7Q0FDekIsSUFBSSxLQUFLLEdBQUc7RUFDUixJQUFJLElBQUksSUFBSSxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQztFQUN6QixFQUFFLEVBQUUsRUFBRSxDQUFDLEtBQUs7RUFDWixPQUFPO0dBQUUsR0FBRztHQUFHLEdBQUc7RUFBRTtDQUN4QjtDQUNBLEVBQUUsS0FBSyxTQUFVLEdBQUcsR0FBRztFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUU7Q0FBRyxDQUFDO0NBRzVDLEVBQUUsS0FBSztFQUFFLEdBQUc7RUFBSSxHQUFHO0NBQU0sQ0FBQztDQUMxQixJQUFJLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSztDQUM3QyxFQUFFLEtBQUs7RUFBRSxHQUFHO0VBQUksR0FBRyxFQUFFLElBQUksRUFBRTtFQUFNO0VBQU07Q0FBRTtDQU16QyxPQUFPLE1BQU0sSUFBSSxHQUFHO0VBQ2hCLElBQUksRUFBRSxFQUFFLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksT0FBTztFQUNqQyxJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxPQUFPO0VBQzdDLEVBQUUsUUFBUTtHQUFFLEdBQUc7R0FBSSxHQUFHLEVBQUUsSUFBSSxFQUFFO0dBQU07R0FBTTtFQUFFO0NBQ2hEO0NBQ0EsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDO0NBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FDckIsSUFBSSxHQUFHLEVBQUUsQ0FBQyxJQUFJLFFBQ1YsU0FBUyxHQUFHLEVBQUUsQ0FBQztDQUd2QixJQUFJLEtBQUssSUFBSSxJQUFJLFNBQVMsQ0FBQztDQUUzQixJQUFJLE1BQU0sR0FBRyxFQUFFLEtBQUssSUFBSSxJQUFJLENBQUM7Q0FDN0IsSUFBSSxNQUFNLElBQUk7RUFJVixJQUFJLElBQUksR0FBRyxLQUFLO0VBRWhCLElBQUksTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0VBQy9CLEdBQUcsS0FBSyxTQUFVLEdBQUcsR0FBRztHQUFFLE9BQU8sR0FBRyxFQUFFLEtBQUssR0FBRyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUU7RUFBRyxDQUFDO0VBQ2xFLE9BQU8sSUFBSSxHQUFHLEVBQUUsR0FBRztHQUNmLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztHQUNqQixJQUFJLEdBQUcsUUFBUSxJQUFJO0lBQ2YsTUFBTSxPQUFPLEtBQU0sTUFBTSxHQUFHO0lBQzVCLEdBQUcsUUFBUTtHQUNmLE9BRUk7RUFDUjtFQUNBLE9BQU87RUFDUCxPQUFPLEtBQUssR0FBRztHQUNYLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztHQUNqQixJQUFJLEdBQUcsUUFBUSxJQUNYLE1BQU0sS0FBTSxLQUFLLEdBQUcsS0FBSyxLQUFLO1FBRTlCLEVBQUU7RUFDVjtFQUNBLE9BQU8sS0FBSyxLQUFLLElBQUksRUFBRSxHQUFHO0dBQ3RCLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztHQUNqQixJQUFJLEdBQUcsU0FBUyxJQUFJO0lBQ2hCLEVBQUUsR0FBRztJQUNMLEVBQUU7R0FDTjtFQUNKO0VBQ0EsTUFBTTtDQUNWO0NBQ0EsT0FBTztFQUFFLEdBQUcsSUFBSSxHQUFHLEVBQUU7RUFBRyxHQUFHO0NBQUk7QUFDbkM7QUFFQSxJQUFJLEtBQUssU0FBVSxHQUFHLEdBQUcsR0FBRztDQUN4QixPQUFPLEVBQUUsS0FBSyxLQUNSLEtBQUssSUFBSSxHQUFHLEVBQUUsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEdBQUcsRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFDNUMsRUFBRSxFQUFFLEtBQUs7QUFDcEI7QUFFQSxJQUFJLEtBQUssU0FBVSxHQUFHO0NBQ2xCLElBQUksSUFBSSxFQUFFO0NBRVYsT0FBTyxLQUFLLENBQUMsRUFBRSxFQUFFO0NBRWpCLElBQUksS0FBSyxJQUFJLElBQUksRUFBRSxDQUFDO0NBRXBCLElBQUksTUFBTSxHQUFHLE1BQU0sRUFBRSxJQUFJLE1BQU07Q0FDL0IsSUFBSSxJQUFJLFNBQVUsR0FBRztFQUFFLEdBQUcsU0FBUztDQUFHO0NBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsR0FDdEIsSUFBSSxFQUFFLE1BQU0sT0FBTyxLQUFLLEdBQ3BCLEVBQUU7TUFDRDtFQUNELElBQUksQ0FBQyxPQUFPLE1BQU0sR0FBRztHQUNqQixPQUFPLE1BQU0sS0FBSyxPQUFPLEtBQ3JCLEVBQUUsS0FBSztHQUNYLElBQUksTUFBTSxHQUFHO0lBQ1QsRUFBRSxNQUFNLEtBQU8sTUFBTSxNQUFPLElBQUssUUFBVSxNQUFNLEtBQU0sSUFBSyxLQUFLO0lBQ2pFLE1BQU07R0FDVjtFQUNKLE9BQ0ssSUFBSSxNQUFNLEdBQUc7R0FDZCxFQUFFLEdBQUcsR0FBRyxFQUFFO0dBQ1YsT0FBTyxNQUFNLEdBQUcsT0FBTyxHQUNuQixFQUFFLElBQUk7R0FDVixJQUFJLE1BQU0sR0FDTixFQUFJLE1BQU0sS0FBTSxJQUFLLElBQUksR0FBRyxNQUFNO0VBQzFDO0VBQ0EsT0FBTyxPQUNILEVBQUUsR0FBRztFQUNULE1BQU07RUFDTixNQUFNLEVBQUU7Q0FDWjtDQUVKLE9BQU87RUFBRSxHQUFHLEdBQUcsU0FBUyxHQUFHLEdBQUc7RUFBRyxHQUFHO0NBQUU7QUFDMUM7QUFFQSxJQUFJLE9BQU8sU0FBVSxJQUFJLElBQUk7Q0FDekIsSUFBSSxJQUFJO0NBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsUUFBUSxFQUFFLEdBQzdCLEtBQUssR0FBRyxLQUFLLEdBQUc7Q0FDcEIsT0FBTztBQUNYO0FBR0EsSUFBSSxRQUFRLFNBQVUsS0FBSyxLQUFLLEtBQUs7Q0FFakMsSUFBSSxJQUFJLElBQUk7Q0FDWixJQUFJLElBQUksS0FBSyxNQUFNLENBQUM7Q0FDcEIsSUFBSSxLQUFLLElBQUk7Q0FDYixJQUFJLElBQUksS0FBSyxLQUFLO0NBQ2xCLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztDQUN0QixJQUFJLElBQUksS0FBSyxJQUFJLElBQUksS0FBSztDQUMxQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQ3JCLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSTtDQUN6QixRQUFRLElBQUksSUFBSSxLQUFLO0FBQ3pCO0FBRUEsSUFBSSxPQUFPLFNBQVUsS0FBSyxLQUFLLE9BQU8sTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHO0NBQ25FLE1BQU0sS0FBSyxLQUFLLEtBQUs7Q0FDckIsRUFBRSxHQUFHO0NBQ0wsSUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFLEdBQUcsTUFBTSxHQUFHLEdBQUcsTUFBTSxHQUFHO0NBQzdDLElBQUksS0FBSyxNQUFNLElBQUksRUFBRSxHQUFHLE1BQU0sR0FBRyxHQUFHLE1BQU0sR0FBRztDQUM3QyxJQUFJLEtBQUssR0FBRyxHQUFHLEdBQUcsT0FBTyxHQUFHLEdBQUcsTUFBTSxHQUFHO0NBQ3hDLElBQUksS0FBSyxHQUFHLEdBQUcsR0FBRyxPQUFPLEdBQUcsR0FBRyxNQUFNLEdBQUc7Q0FDeEMsSUFBSSxTQUFTLElBQUksSUFBSSxFQUFFO0NBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsRUFBRSxHQUMvQixFQUFFLE9BQU8sS0FBSyxLQUFLO0NBQ3ZCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsRUFBRSxHQUMvQixFQUFFLE9BQU8sS0FBSyxLQUFLO0NBQ3ZCLElBQUksS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHLE1BQU0sR0FBRyxHQUFHLE9BQU8sR0FBRztDQUNqRCxJQUFJLE9BQU87Q0FDWCxPQUFPLE9BQU8sS0FBSyxDQUFDLElBQUksS0FBSyxPQUFPLEtBQUssRUFBRTtDQUUzQyxJQUFJLE9BQVEsS0FBSyxLQUFNO0NBQ3ZCLElBQUksUUFBUSxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUk7Q0FDNUMsSUFBSSxRQUFRLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssSUFBSSxPQUFPLEtBQUssUUFBUSxHQUFHLElBQUksSUFBSSxPQUFPLE1BQU0sSUFBSSxPQUFPLE1BQU0sSUFBSSxPQUFPO0NBQ2xJLElBQUksTUFBTSxLQUFLLFFBQVEsU0FBUyxRQUFRLE9BQ3BDLE9BQU8sTUFBTSxLQUFLLEdBQUcsSUFBSSxTQUFTLElBQUksS0FBSyxFQUFFLENBQUM7Q0FDbEQsSUFBSSxJQUFJLElBQUksSUFBSTtDQUNoQixNQUFNLEtBQUssR0FBRyxLQUFLLFFBQVEsTUFBTSxHQUFHLEtBQUs7Q0FDekMsSUFBSSxRQUFRLE9BQU87RUFDZixLQUFLLEtBQUssS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSztFQUMvRCxJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU0sQ0FBQztFQUMzQixNQUFNLEtBQUssR0FBRyxNQUFNLEdBQUc7RUFDdkIsTUFBTSxLQUFLLElBQUksR0FBRyxNQUFNLENBQUM7RUFDekIsTUFBTSxLQUFLLElBQUksSUFBSSxPQUFPLENBQUM7RUFDM0IsS0FBSztFQUNMLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUUsR0FDeEIsTUFBTSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxHQUFHO0VBQ3RDLEtBQUssSUFBSTtFQUNULElBQUksT0FBTyxDQUFDLE1BQU0sSUFBSTtFQUN0QixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssR0FBRyxFQUFFLElBQUk7R0FDM0IsSUFBSSxPQUFPLEtBQUs7R0FDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxFQUFFLEdBQUc7SUFDbEMsSUFBSSxNQUFNLEtBQUssS0FBSztJQUNwQixNQUFNLEtBQUssR0FBRyxJQUFJLElBQUksR0FBRyxLQUFLLElBQUk7SUFDbEMsSUFBSSxNQUFNLElBQ04sTUFBTSxLQUFLLEdBQUksS0FBSyxNQUFNLElBQUssR0FBRyxHQUFHLEtBQUssS0FBSyxNQUFNO0dBQzdEO0VBQ0o7Q0FDSixPQUVJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FFdkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxHQUFHO0VBQ3pCLElBQUksTUFBTSxLQUFLO0VBQ2YsSUFBSSxNQUFNLEtBQUs7R0FDWCxJQUFJLE1BQU8sT0FBTyxLQUFNO0dBQ3hCLFFBQVEsS0FBSyxHQUFHLEdBQUcsTUFBTSxJQUFJLEdBQUcsS0FBSyxHQUFHLE1BQU07R0FDOUMsSUFBSSxNQUFNLEdBQ04sTUFBTSxLQUFLLEdBQUksT0FBTyxLQUFNLEVBQUUsR0FBRyxLQUFLLEtBQUs7R0FDL0MsSUFBSSxNQUFNLE1BQU07R0FDaEIsUUFBUSxLQUFLLEdBQUcsR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHO0dBQ2xDLElBQUksTUFBTSxHQUNOLFFBQVEsS0FBSyxHQUFJLE9BQU8sSUFBSyxJQUFJLEdBQUcsS0FBSyxLQUFLO0VBQ3RELE9BRUksUUFBUSxLQUFLLEdBQUcsR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHO0NBRTFDO0NBQ0EsUUFBUSxLQUFLLEdBQUcsR0FBRyxJQUFJO0NBQ3ZCLE9BQU8sSUFBSSxHQUFHO0FBQ2xCO0FBRUEsSUFBSSxvQkFBb0IsSUFBSSxJQUFJO0NBQUM7Q0FBTztDQUFRO0NBQVE7Q0FBUTtDQUFRO0NBQVM7Q0FBUztDQUFTO0FBQU8sQ0FBQztBQUUzRyxJQUFJLG1CQUFtQixJQUFJLEdBQUcsQ0FBQztBQUUvQixJQUFJLE9BQU8sU0FBVSxLQUFLLEtBQUssTUFBTSxLQUFLLE1BQU0sSUFBSTtDQUNoRCxJQUFJLElBQUksR0FBRyxLQUFLLElBQUk7Q0FDcEIsSUFBSSxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLEdBQUksS0FBSyxJQUFJO0NBRTdELElBQUksSUFBSSxFQUFFLFNBQVMsS0FBSyxFQUFFLFNBQVMsSUFBSTtDQUN2QyxJQUFJLE1BQU0sR0FBRztDQUNiLElBQUksT0FBTyxHQUFHLEtBQUssS0FBSztDQUN4QixJQUFJLEtBQUs7RUFDTCxJQUFJLEtBQ0EsRUFBRSxLQUFLLEdBQUcsS0FBSztFQUNuQixJQUFJLE1BQU0sSUFBSSxNQUFNO0VBQ3BCLElBQUksSUFBSSxPQUFPLElBQUksSUFBSSxNQUFNO0VBQzdCLElBQUksU0FBUyxLQUFLLFFBQVE7RUFFMUIsSUFBSSxPQUFPLEdBQUcsS0FBSyxJQUFJLElBQUksS0FBSyxHQUFHLE9BQU8sR0FBRyxLQUFLLElBQUksSUFBSSxRQUFRLENBQUM7RUFDbkUsSUFBSSxRQUFRLEtBQUssS0FBSyxPQUFPLENBQUMsR0FBRyxRQUFRLElBQUk7RUFDN0MsSUFBSSxNQUFNLFNBQVUsR0FBRztHQUFFLFFBQVEsSUFBSSxLQUFNLElBQUksSUFBSSxNQUFNLFFBQVUsSUFBSSxJQUFJLE1BQU0sU0FBVTtFQUFPO0VBR2xHLElBQUksT0FBTyxJQUFJLElBQUksSUFBSztFQUV4QixJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUcsR0FBRyxLQUFLLElBQUksSUFBSSxFQUFFO0VBRXRDLElBQUksT0FBTyxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDbEUsT0FBTyxJQUFJLElBQUksR0FBRyxFQUFFLEdBQUc7R0FFbkIsSUFBSSxLQUFLLElBQUksQ0FBQztHQUVkLElBQUksT0FBTyxJQUFJLE9BQU8sUUFBUSxLQUFLO0dBQ25DLEtBQUssUUFBUTtHQUNiLEtBQUssTUFBTTtHQUdYLElBQUksTUFBTSxHQUFHO0lBRVQsSUFBSSxNQUFNLElBQUk7SUFDZCxLQUFLLE9BQU8sT0FBUSxLQUFLLFdBQVcsTUFBTSxPQUFPLENBQUMsTUFBTTtLQUNwRCxNQUFNLEtBQUssS0FBSyxHQUFHLEdBQUcsTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUc7S0FDM0QsS0FBSyxPQUFPLEtBQUssR0FBRyxLQUFLO0tBQ3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEVBQUUsR0FDdkIsR0FBRyxLQUFLO0tBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxHQUN0QixHQUFHLEtBQUs7SUFDaEI7SUFFQSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTyxHQUFHLE1BQU0sT0FBTyxRQUFRO0lBQ2pELElBQUksTUFBTSxLQUFLLE1BQU0sSUFBSSxJQUFJLEdBQUcsR0FBRztLQUMvQixJQUFJLE9BQU8sS0FBSyxJQUFJLEdBQUcsR0FBRyxJQUFJO0tBQzlCLElBQUksT0FBTyxLQUFLLElBQUksT0FBTyxDQUFDO0tBRzVCLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHO0tBQzFCLE9BQU8sT0FBTyxRQUFRLEVBQUUsUUFBUSxRQUFRLE9BQU87TUFDM0MsSUFBSSxJQUFJLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxNQUFNO09BQ2hDLElBQUksS0FBSztPQUNULE9BQU8sS0FBSyxNQUFNLElBQUksSUFBSSxPQUFPLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRTtPQUV0RCxJQUFJLEtBQUssR0FBRztRQUNSLElBQUksSUFBSSxJQUFJO1FBRVosSUFBSSxLQUFLLE1BQ0w7UUFJSixJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxDQUFDO1FBQzlCLElBQUksS0FBSztRQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEVBQUUsR0FBRztTQUMxQixJQUFJLEtBQUssSUFBSSxNQUFNLElBQUk7U0FFdkIsSUFBSSxLQUFLLEtBREMsS0FBSyxNQUNLO1NBQ3BCLElBQUksS0FBSyxJQUNMLEtBQUssSUFBSSxRQUFRO1FBQ3pCO09BQ0o7TUFDSjtNQUVBLE9BQU8sT0FBTyxRQUFRLEtBQUs7TUFDM0IsT0FBTyxPQUFPLFFBQVE7S0FDMUI7SUFDSjtJQUVBLElBQUksR0FBRztLQUdILEtBQUssUUFBUSxZQUFhLE1BQU0sTUFBTSxLQUFNLE1BQU07S0FDbEQsSUFBSSxNQUFNLE1BQU0sS0FBSyxJQUFJLE1BQU0sTUFBTSxLQUFLO0tBQzFDLE1BQU0sS0FBSyxPQUFPLEtBQUs7S0FDdkIsRUFBRSxHQUFHLE1BQU07S0FDWCxFQUFFLEdBQUc7S0FDTCxLQUFLLElBQUk7S0FDVCxFQUFFO0lBQ04sT0FDSztLQUNELEtBQUssUUFBUSxJQUFJO0tBQ2pCLEVBQUUsR0FBRyxJQUFJO0lBQ2I7R0FDSjtFQUNKO0VBQ0EsS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUUsR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUFHO0dBQ2xDLEtBQUssUUFBUSxJQUFJO0dBQ2pCLEVBQUUsR0FBRyxJQUFJO0VBQ2I7RUFDQSxNQUFNLEtBQUssS0FBSyxHQUFHLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUc7RUFDN0QsSUFBSSxDQUFDLEtBQUs7R0FDTixHQUFHLElBQUssTUFBTSxJQUFLLEVBQUcsTUFBTSxJQUFLLE1BQU07R0FFdkMsT0FBTztHQUNQLEdBQUcsSUFBSSxNQUFNLEdBQUcsSUFBSSxNQUFNLEdBQUcsSUFBSSxHQUFHLEdBQUcsSUFBSTtFQUMvQztDQUNKLE9BQ0s7RUFDRCxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSyxLQUFLLE9BQU87R0FFN0MsSUFBSSxJQUFJLElBQUk7R0FDWixJQUFJLEtBQUssR0FBRztJQUVSLEVBQUcsTUFBTSxJQUFLLEtBQUs7SUFDbkIsSUFBSTtHQUNSO0dBQ0EsTUFBTSxNQUFNLEdBQUcsTUFBTSxHQUFHLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztFQUM5QztFQUNBLEdBQUcsSUFBSTtDQUNYO0NBQ0EsT0FBTyxJQUFJLEdBQUcsR0FBRyxNQUFNLEtBQUssR0FBRyxJQUFJLElBQUk7QUFDM0M7QUFFQSxJQUFJLE9BQXFCLGVBQUMsV0FBWTtDQUNsQyxJQUFJLG9CQUFJLElBQUksV0FBVyxHQUFHO0NBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEVBQUUsR0FBRztFQUMxQixJQUFJLElBQUksR0FBRyxJQUFJO0VBQ2YsT0FBTyxFQUFFLEdBQ0wsS0FBTSxJQUFJLEtBQU0sY0FBZSxNQUFNO0VBQ3pDLEVBQUUsS0FBSztDQUNYO0NBQ0EsT0FBTztBQUNYLEVBQUEsQ0FBRztBQUVILElBQUksTUFBTSxXQUFZO0NBQ2xCLElBQUksSUFBSTtDQUNSLE9BQU87RUFDSCxHQUFHLFNBQVUsR0FBRztHQUVaLElBQUksS0FBSztHQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUM1QixLQUFLLEtBQU0sS0FBSyxNQUFPLEVBQUUsTUFBTyxPQUFPO0dBQzNDLElBQUk7RUFDUjtFQUNBLEdBQUcsV0FBWTtHQUFFLE9BQU8sQ0FBQztFQUFHO0NBQ2hDO0FBQ0o7QUFFQSxJQUFJLFFBQVEsV0FBWTtDQUNwQixJQUFJLElBQUksR0FBRyxJQUFJO0NBQ2YsT0FBTztFQUNILEdBQUcsU0FBVSxHQUFHO0dBRVosSUFBSSxJQUFJLEdBQUcsSUFBSTtHQUNmLElBQUksSUFBSSxFQUFFLFNBQVM7R0FDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLElBQUk7SUFDckIsSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLE1BQU0sQ0FBQztJQUM1QixPQUFPLElBQUksR0FBRyxFQUFFLEdBQ1osS0FBSyxLQUFLLEVBQUU7SUFDaEIsS0FBSyxJQUFJLFNBQVMsTUFBTSxLQUFLLEtBQUssS0FBSyxJQUFJLFNBQVMsTUFBTSxLQUFLO0dBQ25FO0dBQ0EsSUFBSSxHQUFHLElBQUk7RUFDZjtFQUNBLEdBQUcsV0FBWTtHQUNYLEtBQUssT0FBTyxLQUFLO0dBQ2pCLFFBQVEsSUFBSSxRQUFRLE1BQU0sSUFBSSxVQUFXLEtBQUssSUFBSSxRQUFRLElBQUssS0FBSztFQUN4RTtDQUNKO0FBQ0o7QUFHQSxJQUFJLE9BQU8sU0FBVSxLQUFLLEtBQUssS0FBSyxNQUFNLElBQUk7Q0FDMUMsSUFBSSxDQUFDLElBQUk7RUFDTCxLQUFLLEVBQUUsR0FBRyxFQUFFO0VBQ1osSUFBSSxJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPLElBQUksV0FBVyxTQUFTLE1BQU07R0FDekMsSUFBSSxTQUFTLElBQUksR0FBRyxLQUFLLFNBQVMsSUFBSSxNQUFNO0dBQzVDLE9BQU8sSUFBSSxJQUFJO0dBQ2YsT0FBTyxJQUFJLEtBQUssS0FBSyxNQUFNO0dBQzNCLE1BQU07R0FDTixHQUFHLElBQUksS0FBSztFQUNoQjtDQUNKO0NBQ0EsT0FBTyxLQUFLLEtBQUssSUFBSSxTQUFTLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxPQUFPLE9BQVEsR0FBRyxJQUFJLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxLQUFPLEtBQUssSUFBSSxLQUFNLEtBQUssTUFBTSxFQUFFO0FBQ3hMO0FBRUEsSUFBSSxNQUFNLFNBQVUsR0FBRyxHQUFHO0NBQ3RCLElBQUksSUFBSSxDQUFDO0NBQ1QsS0FBSyxJQUFJLEtBQUssR0FDVixFQUFFLEtBQUssRUFBRTtDQUNiLEtBQUssSUFBSSxLQUFLLEdBQ1YsRUFBRSxLQUFLLEVBQUU7Q0FDYixPQUFPO0FBQ1g7QUFRQSxJQUFJLE9BQU8sU0FBVSxJQUFJLE9BQU8sSUFBSTtDQUNoQyxJQUFJLEtBQUssR0FBRztDQUNaLElBQUksS0FBSyxHQUFHLFNBQVM7Q0FDckIsSUFBSSxLQUFLLEdBQUcsTUFBTSxHQUFHLFFBQVEsR0FBRyxJQUFJLEdBQUcsR0FBRyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxRQUFRLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRztDQUN6RixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLEVBQUUsR0FBRztFQUNoQyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksR0FBRztFQUN0QixJQUFJLE9BQU8sS0FBSyxZQUFZO0dBQ3hCLFNBQVMsTUFBTSxJQUFJO0dBQ25CLElBQUksT0FBTyxFQUFFLFNBQVM7R0FDdEIsSUFBSSxFQUFFLFdBRUYsSUFBSSxLQUFLLFFBQVEsZUFBZSxLQUFLLElBQUk7SUFDckMsSUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLLENBQUMsSUFBSTtJQUNuQyxTQUFTLEtBQUssTUFBTSxPQUFPLEtBQUssUUFBUSxLQUFLLEtBQUssQ0FBQztHQUN2RCxPQUNLO0lBQ0QsU0FBUztJQUNULEtBQUssSUFBSSxLQUFLLEVBQUUsV0FDWixTQUFTLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSSxNQUFNLEVBQUUsVUFBVSxFQUFFLENBQUMsU0FBUztHQUM3RTtRQUdBLFNBQVM7RUFDakIsT0FFSSxHQUFHLEtBQUs7Q0FDaEI7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxJQUFJLEtBQUssQ0FBQztBQUVWLElBQUksT0FBTyxTQUFVLEdBQUc7Q0FDcEIsSUFBSSxLQUFLLENBQUM7Q0FDVixLQUFLLElBQUksS0FBSyxHQUNWLElBQUksRUFBRSxFQUFFLENBQUMsUUFDTCxHQUFHLE1BQU0sRUFBRSxLQUFLLElBQUksRUFBRSxFQUFFLENBQUMsWUFBWSxFQUFFLEVBQUUsRUFBQSxDQUFHLE1BQU07Q0FHMUQsT0FBTztBQUNYO0FBRUEsSUFBSSxPQUFPLFNBQVUsS0FBSyxNQUFNLElBQUksSUFBSTtDQUNwQyxJQUFJLENBQUMsR0FBRyxLQUFLO0VBQ1QsSUFBSSxRQUFRLElBQUksT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLFNBQVM7RUFDNUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUNyQixRQUFRLEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSTtFQUNwQyxHQUFHLE1BQU07R0FBRSxHQUFHLEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSTtHQUFHLEdBQUc7RUFBSztDQUNyRDtDQUNBLElBQUksS0FBSyxJQUFJLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0NBQ3pCLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLDRFQUE0RSxLQUFLLFNBQVMsSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLEVBQUUsR0FBRyxFQUFFO0FBQ2hKO0FBRUEsSUFBSSxTQUFTLFdBQVk7Q0FBRSxPQUFPO0VBQUM7RUFBSTtFQUFLO0VBQUs7RUFBTTtFQUFNO0VBQU07RUFBSTtFQUFJO0VBQU07RUFBTTtFQUFLO0VBQUk7RUFBTTtFQUFLO0VBQU07RUFBUTtFQUFNO0VBQUs7RUFBSztFQUFPO0VBQWE7RUFBSztDQUFJO0FBQUc7QUFDekssSUFBSSxRQUFRLFdBQVk7Q0FBRSxPQUFPO0VBQUM7RUFBSTtFQUFLO0VBQUs7RUFBTTtFQUFNO0VBQU07RUFBTztFQUFPO0VBQUs7RUFBSztFQUFLO0VBQUs7RUFBSztFQUFLO0VBQUk7RUFBTTtFQUFPO0VBQVM7RUFBTztFQUFJO0VBQUk7RUFBTTtFQUFPO0VBQU07RUFBTTtFQUFLO0VBQU07RUFBTTtFQUFhO0NBQUc7QUFBRztBQUVwTixJQUFJLE1BQU0sV0FBWTtDQUFFLE9BQU87RUFBQztFQUFLO0VBQU07RUFBUTtFQUFLO0NBQUk7QUFBRztBQUUvRCxJQUFJLE9BQU8sV0FBWTtDQUFFLE9BQU8sQ0FBQyxLQUFLLEdBQUc7QUFBRztBQUU1QyxJQUFJLE1BQU0sV0FBWTtDQUFFLE9BQU87RUFBQztFQUFLO0VBQVE7Q0FBSztBQUFHO0FBRXJELElBQUksT0FBTyxXQUFZO0NBQUUsT0FBTyxDQUFDLEdBQUc7QUFBRztBQUV2QyxJQUFJLE1BQU0sU0FBVSxLQUFLO0NBQUUsT0FBTyxZQUFZLEtBQUssQ0FBQyxJQUFJLE1BQU0sQ0FBQztBQUFHO0FBRWxFLElBQUksT0FBTyxTQUFVLEdBQUc7Q0FBRSxPQUFPLEtBQUs7RUFDbEMsS0FBSyxFQUFFLFFBQVEsSUFBSSxHQUFHLEVBQUUsSUFBSTtFQUM1QixZQUFZLEVBQUU7Q0FDbEI7QUFBRztBQUVILElBQUksUUFBUSxTQUFVLEtBQUssTUFBTSxLQUFLLE1BQU0sSUFBSSxJQUFJO0NBQ2hELElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJLFNBQVUsS0FBSyxLQUFLO0VBQzVDLEVBQUUsVUFBVTtFQUNaLEdBQUcsS0FBSyxHQUFHO0NBQ2YsQ0FBQztDQUNELEVBQUUsWUFBWSxDQUFDLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVSxDQUFDLElBQUksTUFBTSxJQUFJLENBQUMsQ0FBQztDQUMzRCxPQUFPLFdBQVk7RUFBRSxFQUFFLFVBQVU7Q0FBRztBQUN4QztBQUVBLElBQUksUUFBUSxTQUFVLE1BQU07Q0FDeEIsS0FBSyxTQUFTLFNBQVUsS0FBSyxPQUFPO0VBQUUsT0FBTyxZQUFZLENBQUMsS0FBSyxLQUFLLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQztDQUFHO0NBQ3RGLE9BQU8sU0FBVSxJQUFJO0VBQ2pCLElBQUksR0FBRyxLQUFLLElBQUk7R0FDWixLQUFLLEtBQUssR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLEVBQUU7R0FDaEMsWUFBWSxDQUFDLEdBQUcsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDO0VBQ25DLE9BRUksS0FBSyxNQUFNLEdBQUcsS0FBSyxFQUFFO0NBQzdCO0FBQ0o7QUFFQSxJQUFJLFdBQVcsU0FBVSxLQUFLLE1BQU0sTUFBTSxNQUFNLElBQUksT0FBTyxLQUFLO0NBQzVELElBQUk7Q0FDSixJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxTQUFVLEtBQUssS0FBSztFQUM1QyxJQUFJLEtBQ0EsRUFBRSxVQUFVLEdBQUcsS0FBSyxPQUFPLEtBQUssTUFBTSxHQUFHO09BQ3hDLElBQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxHQUN2QixJQUFJLEdBQUc7T0FDTixJQUFJLElBQUksVUFBVSxHQUFHO0dBQ3RCLEtBQUssY0FBYyxJQUFJO0dBQ3ZCLElBQUksS0FBSyxTQUNMLEtBQUssUUFBUSxJQUFJLEVBQUU7RUFDM0IsT0FDSztHQUNELElBQUksSUFBSSxJQUNKLEVBQUUsVUFBVTtHQUNoQixLQUFLLE9BQU8sS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLElBQUksRUFBRTtFQUM5QztDQUNKLENBQUM7Q0FDRCxFQUFFLFlBQVksSUFBSTtDQUNsQixLQUFLLGFBQWE7Q0FDbEIsS0FBSyxPQUFPLFNBQVUsR0FBRyxHQUFHO0VBQ3hCLElBQUksQ0FBQyxLQUFLLFFBQ04sSUFBSSxDQUFDO0VBQ1QsSUFBSSxHQUNBLEtBQUssT0FBTyxJQUFJLEdBQUcsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUN2QyxLQUFLLGNBQWMsRUFBRTtFQUVyQixFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsa0JBQWtCLGNBQWMsQ0FBQyxFQUFFLE1BQU0sSUFBSSxDQUFDLENBQUM7Q0FDL0U7Q0FDQSxLQUFLLFlBQVksV0FBWTtFQUFFLEVBQUUsVUFBVTtDQUFHO0NBQzlDLElBQUksT0FDQSxLQUFLLFFBQVEsU0FBVSxNQUFNO0VBQUUsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUM7Q0FBRztBQUVqRTtBQUVBLElBQUksS0FBSyxTQUFVLEdBQUcsR0FBRztDQUFFLE9BQU8sRUFBRSxLQUFNLEVBQUUsSUFBSSxNQUFNO0FBQUk7QUFFMUQsSUFBSSxLQUFLLFNBQVUsR0FBRyxHQUFHO0NBQUUsUUFBUSxFQUFFLEtBQU0sRUFBRSxJQUFJLE1BQU0sSUFBTSxFQUFFLElBQUksTUFBTSxLQUFPLEVBQUUsSUFBSSxNQUFNLFFBQVM7QUFBRztBQUV4RyxJQUFJLEtBQUssU0FBVSxHQUFHLEdBQUc7Q0FBRSxPQUFPLEdBQUcsR0FBRyxDQUFDLElBQUssR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJO0FBQWE7QUFFMUUsSUFBSSxTQUFTLFNBQVUsR0FBRyxHQUFHLEdBQUc7Q0FDNUIsT0FBTyxHQUFHLEVBQUUsR0FDUixFQUFFLEtBQUssR0FBRyxPQUFPO0FBQ3pCO0FBRUEsSUFBSSxNQUFNLFNBQVUsR0FBRyxHQUFHO0NBQ3RCLElBQUksS0FBSyxFQUFFO0NBQ1gsRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLEtBQUssRUFBRSxLQUFLLEdBQUcsRUFBRSxLQUFLLEVBQUUsUUFBUSxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksSUFBSSxHQUFHLEVBQUUsS0FBSztDQUN2RixJQUFJLEVBQUUsU0FBUyxHQUNYLE9BQU8sR0FBRyxHQUFHLEtBQUssTUFBTSxJQUFJLEtBQUssRUFBRSxTQUFTLEtBQUssSUFBSSxDQUFDLElBQUksR0FBSSxDQUFDO0NBQ25FLElBQUksSUFBSTtFQUNKLEVBQUUsS0FBSztFQUNQLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxHQUFHLFFBQVEsRUFBRSxHQUM5QixFQUFFLElBQUksTUFBTSxHQUFHLFdBQVcsQ0FBQztDQUNuQztBQUNKO0FBR0EsSUFBSSxNQUFNLFNBQVUsR0FBRztDQUNuQixJQUFJLEVBQUUsTUFBTSxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsTUFBTSxHQUNyQyxJQUFJLEdBQUcsbUJBQW1CO0NBQzlCLElBQUksTUFBTSxFQUFFO0NBQ1osSUFBSSxLQUFLO0NBQ1QsSUFBSSxNQUFNLEdBQ04sT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEtBQUs7Q0FDakMsS0FBSyxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU0sT0FBTyxJQUFJLElBQUksS0FBSyxHQUFHLE1BQU0sQ0FBQyxFQUFFO0NBRWhFLE9BQU8sTUFBTSxNQUFNO0FBQ3ZCO0FBRUEsSUFBSSxNQUFNLFNBQVUsR0FBRztDQUNuQixJQUFJLElBQUksRUFBRTtDQUNWLFFBQVEsRUFBRSxJQUFJLEtBQUssRUFBRSxJQUFJLE1BQU0sSUFBSSxFQUFFLElBQUksTUFBTSxLQUFLLEVBQUUsSUFBSSxNQUFNLFFBQVE7QUFDNUU7QUFFQSxJQUFJLE9BQU8sU0FBVSxHQUFHO0NBQUUsT0FBTyxNQUFNLEVBQUUsV0FBVyxFQUFFLFNBQVMsU0FBUyxJQUFJO0FBQUk7QUFFaEYsSUFBSSxNQUFNLFNBQVUsR0FBRyxHQUFHO0NBQ3RCLElBQUksS0FBSyxFQUFFLE9BQU8sS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLElBQUksSUFBSTtDQUNoRSxFQUFFLEtBQUssS0FBSyxFQUFFLEtBQU0sTUFBTSxLQUFNLEVBQUUsY0FBYztDQUNoRCxFQUFFLE1BQU0sTUFBTyxFQUFFLE1BQU0sSUFBSyxFQUFFLE1BQU07Q0FDcEMsSUFBSSxFQUFFLFlBQVk7RUFDZCxJQUFJLElBQUksTUFBTTtFQUNkLEVBQUUsRUFBRSxFQUFFLFVBQVU7RUFDaEIsT0FBTyxHQUFHLEdBQUcsRUFBRSxFQUFFLENBQUM7Q0FDdEI7QUFDSjtBQUVBLElBQUksTUFBTSxTQUFVLEdBQUcsTUFBTTtDQUN6QixLQUFLLEVBQUUsS0FBSyxPQUFPLEtBQU0sRUFBRSxNQUFNLElBQUssTUFBTyxFQUFFLE1BQU0sSUFBSSxFQUFFLE1BQU0sSUFDN0QsSUFBSSxHQUFHLG1CQUFtQjtDQUM5QixLQUFLLEVBQUUsTUFBTSxJQUFJLE1BQU0sQ0FBQyxDQUFDLE1BQ3JCLElBQUksR0FBRyx5QkFBeUIsRUFBRSxLQUFLLEtBQUssU0FBUyxnQkFBZ0IsYUFBYTtDQUN0RixRQUFRLEVBQUUsTUFBTSxJQUFJLEtBQUs7QUFDN0I7QUFDQSxTQUFTLFFBQVEsTUFBTSxJQUFJO0NBQ3ZCLElBQUksT0FBTyxRQUFRLFlBQ2YsS0FBSyxNQUFNLE9BQU8sQ0FBQztDQUN2QixLQUFLLFNBQVM7Q0FDZCxPQUFPO0FBQ1g7Ozs7QUFJQSxJQUFJLFVBQXlCLDJCQUFZO0NBQ3JDLFNBQVMsUUFBUSxNQUFNLElBQUk7RUFDdkIsSUFBSSxPQUFPLFFBQVEsWUFDZixLQUFLLE1BQU0sT0FBTyxDQUFDO0VBQ3ZCLEtBQUssU0FBUztFQUNkLEtBQUssSUFBSSxRQUFRLENBQUM7RUFDbEIsS0FBSyxJQUFJO0dBQUUsR0FBRztHQUFHLEdBQUc7R0FBTyxHQUFHO0dBQU8sR0FBRztFQUFNO0VBRzlDLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSztFQUNyQixJQUFJLEtBQUssRUFBRSxZQUFZO0dBQ25CLElBQUksT0FBTyxLQUFLLEVBQUUsV0FBVyxTQUFTLE1BQU07R0FDNUMsS0FBSyxFQUFFLElBQUksTUFBTSxRQUFRLEtBQUssTUFBTTtHQUNwQyxLQUFLLEVBQUUsSUFBSSxRQUFRLEtBQUs7RUFDNUI7Q0FDSjtDQUNBLFFBQVEsVUFBVSxJQUFJLFNBQVUsR0FBRyxHQUFHO0VBQ2xDLEtBQUssT0FBTyxLQUFLLEdBQUcsS0FBSyxHQUFHLEdBQUcsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO0NBQ2hEOzs7Ozs7Q0FNQSxRQUFRLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUM3QyxJQUFJLENBQUMsS0FBSyxRQUNOLElBQUksQ0FBQztFQUNULElBQUksS0FBSyxFQUFFLEdBQ1AsSUFBSSxDQUFDO0VBQ1QsSUFBSSxTQUFTLE1BQU0sU0FBUyxLQUFLLEVBQUU7RUFDbkMsSUFBSSxTQUFTLEtBQUssRUFBRSxRQUFRO0dBQ3hCLElBQUksU0FBUyxJQUFJLEtBQUssRUFBRSxTQUFTLE9BQU87SUFDcEMsSUFBSSxTQUFTLElBQUksR0FBRyxTQUFTLE1BQU07SUFDbkMsT0FBTyxJQUFJLEtBQUssRUFBRSxTQUFTLEdBQUcsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUN2QyxLQUFLLElBQUk7R0FDYjtHQUNBLElBQUksUUFBUSxLQUFLLEVBQUUsU0FBUyxLQUFLLEVBQUU7R0FDbkMsS0FBSyxFQUFFLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDO0dBQzdDLEtBQUssRUFBRSxJQUFJLEtBQUssRUFBRTtHQUNsQixLQUFLLEVBQUUsS0FBSyxHQUFHLEtBQUs7R0FDcEIsS0FBSyxFQUFFLElBQUksS0FBSyxFQUFFLFNBQVMsTUFBTSxDQUFDO0dBQ2xDLEtBQUssRUFBRSxJQUFJLE1BQU0sU0FBUyxLQUFLLEdBQUcsS0FBSztHQUN2QyxLQUFLLEVBQUUsSUFBSSxNQUFNLFNBQVMsUUFBUTtHQUNsQyxLQUFLLEVBQUUsSUFBSSxPQUFPLEtBQUssRUFBRSxJQUFJO0VBQ2pDLE9BQ0s7R0FDRCxLQUFLLEVBQUUsSUFBSSxPQUFPLEtBQUssRUFBRSxDQUFDO0dBQzFCLEtBQUssRUFBRSxLQUFLLE1BQU07RUFDdEI7RUFDQSxLQUFLLEVBQUUsSUFBSSxRQUFRO0VBQ25CLElBQUksS0FBSyxFQUFFLElBQUksS0FBSyxFQUFFLElBQUksUUFBUSxPQUFPO0dBQ3JDLEtBQUssRUFBRSxLQUFLLEdBQUcsU0FBUyxLQUFLO0dBQzdCLEtBQUssRUFBRSxJQUFJLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxLQUFLO0VBQ3JDO0VBQ0EsSUFBSSxPQUFPO0dBRVAsS0FBSyxJQUFJLEtBQUssSUFBSSxDQUFDO0dBQ25CLEtBQUssSUFBSTtFQUNiO0NBQ0o7Ozs7Ozs7OztDQVNBLFFBQVEsVUFBVSxRQUFRLFNBQVUsTUFBTTtFQUN0QyxJQUFJLENBQUMsS0FBSyxRQUNOLElBQUksQ0FBQztFQUNULElBQUksS0FBSyxFQUFFLEdBQ1AsSUFBSSxDQUFDO0VBQ1QsS0FBSyxFQUFFLEtBQUssR0FBRyxLQUFLO0VBQ3BCLEtBQUssRUFBRSxJQUFJLEtBQUssRUFBRSxHQUFHLEtBQUssRUFBRSxLQUFLO0VBR2pDLElBQUksTUFBTTtHQUNOLElBQUksSUFBSSxJQUFJLEdBQUcsQ0FBQztHQUNoQixFQUFFLEtBQUssS0FBSyxFQUFFLEtBQUs7R0FFbkIsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLEVBQUUsR0FBRyxFQUFFO0dBQzlCLEtBQUssRUFBRSxJQUFJO0dBQ1gsS0FBSyxPQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sQ0FBQyxHQUFHLEtBQUs7RUFDN0M7Q0FDSjtDQUNBLE9BQU87QUFDWCxFQUFFOzs7O0FBS0YsSUFBSSxlQUE4QiwyQkFBWTtDQUMxQyxTQUFTLGFBQWEsTUFBTSxJQUFJO0VBQzVCLFNBQVMsQ0FDTCxPQUNBLFdBQVk7R0FBRSxPQUFPLENBQUMsT0FBTyxPQUFPO0VBQUcsQ0FDM0MsR0FBRyxNQUFNLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxHQUFHLFNBQVUsSUFBSTtHQUVqRCxZQUFZLE1BQU0sSUFESCxRQUFRLEdBQUcsSUFDTCxDQUFDO0VBQzFCLEdBQUcsR0FBRyxDQUFDO0NBQ1g7Q0FDQSxPQUFPO0FBQ1gsRUFBRTtBQUVGLFNBQWdCLFFBQVEsTUFBTSxNQUFNLElBQUk7Q0FDcEMsSUFBSSxDQUFDLElBQ0QsS0FBSyxNQUFNLE9BQU8sQ0FBQztDQUN2QixJQUFJLE9BQU8sTUFBTSxZQUNiLElBQUksQ0FBQztDQUNULE9BQU8sTUFBTSxNQUFNLE1BQU0sQ0FDckIsS0FDSixHQUFHLFNBQVUsSUFBSTtFQUFFLE9BQU8sSUFBSSxZQUFZLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxFQUFFLENBQUM7Q0FBRyxHQUFHLEdBQUcsRUFBRTtBQUNoRjs7Ozs7OztBQU9BLFNBQWdCLFlBQVksTUFBTSxNQUFNO0NBQ3BDLE9BQU8sS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQztBQUN0Qzs7OztBQUlBLElBQUksVUFBeUIsMkJBQVk7Q0FDckMsU0FBUyxRQUFRLE1BQU0sSUFBSTtFQUV2QixJQUFJLE9BQU8sUUFBUSxZQUNmLEtBQUssTUFBTSxPQUFPLENBQUM7RUFDdkIsS0FBSyxTQUFTO0VBQ2QsSUFBSSxPQUFPLFFBQVEsS0FBSyxjQUFjLEtBQUssV0FBVyxTQUFTLE1BQU07RUFDckUsS0FBSyxJQUFJO0dBQUUsR0FBRztHQUFHLEdBQUcsT0FBTyxLQUFLLFNBQVM7RUFBRTtFQUMzQyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUs7RUFDckIsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDO0VBQ2pCLElBQUksTUFDQSxLQUFLLEVBQUUsSUFBSSxJQUFJO0NBQ3ZCO0NBQ0EsUUFBUSxVQUFVLElBQUksU0FBVSxHQUFHO0VBQy9CLElBQUksQ0FBQyxLQUFLLFFBQ04sSUFBSSxDQUFDO0VBQ1QsSUFBSSxLQUFLLEdBQ0wsSUFBSSxDQUFDO0VBQ1QsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUNSLEtBQUssSUFBSTtPQUNSLElBQUksRUFBRSxRQUFRO0dBQ2YsSUFBSSxJQUFJLElBQUksR0FBRyxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU07R0FDdkMsRUFBRSxJQUFJLEtBQUssQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUFHLEtBQUssRUFBRSxNQUFNLEdBQUcsS0FBSyxJQUFJO0VBQ3JEO0NBQ0o7Q0FDQSxRQUFRLFVBQVUsSUFBSSxTQUFVLE9BQU87RUFDbkMsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLElBQUksU0FBUztFQUMvQixJQUFJLE1BQU0sS0FBSyxFQUFFO0VBQ2pCLElBQUksS0FBSyxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3JDLEtBQUssT0FBTyxJQUFJLElBQUksS0FBSyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQztFQUMxQyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRSxJQUFJLEtBQUssR0FBRyxLQUFLLEVBQUUsSUFBSSxLQUFLLEVBQUU7RUFDdEQsS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLEtBQUssRUFBRSxJQUFJLElBQUssQ0FBQyxHQUFHLEtBQUssRUFBRSxLQUFLO0NBQzFEOzs7Ozs7Q0FNQSxRQUFRLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUM3QyxLQUFLLEVBQUUsS0FBSyxHQUFHLEtBQUssRUFBRSxLQUFLO0NBQy9CO0NBQ0EsT0FBTztBQUNYLEVBQUU7Ozs7QUFLRixJQUFJLGVBQThCLDJCQUFZO0NBQzFDLFNBQVMsYUFBYSxNQUFNLElBQUk7RUFDNUIsU0FBUyxDQUNMLFFBQ0EsV0FBWTtHQUFFLE9BQU8sQ0FBQyxPQUFPLE9BQU87RUFBRyxDQUMzQyxHQUFHLE1BQU0sUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLEdBQUcsU0FBVSxJQUFJO0dBRWpELFlBQVksTUFBTSxJQURILFFBQVEsR0FBRyxJQUNMLENBQUM7RUFDMUIsR0FBRyxHQUFHLENBQUM7Q0FDWDtDQUNBLE9BQU87QUFDWCxFQUFFO0FBRUYsU0FBZ0IsUUFBUSxNQUFNLE1BQU0sSUFBSTtDQUNwQyxJQUFJLENBQUMsSUFDRCxLQUFLLE1BQU0sT0FBTyxDQUFDO0NBQ3ZCLElBQUksT0FBTyxNQUFNLFlBQ2IsSUFBSSxDQUFDO0NBQ1QsT0FBTyxNQUFNLE1BQU0sTUFBTSxDQUNyQixNQUNKLEdBQUcsU0FBVSxJQUFJO0VBQUUsT0FBTyxJQUFJLFlBQVksR0FBRyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7Q0FBRyxHQUFHLEdBQUcsRUFBRTtBQUN0RjtBQUNBLFNBQWdCLFlBQVksTUFBTSxNQUFNO0NBQ3BDLE9BQU8sTUFBTSxNQUFNLEVBQUUsR0FBRyxFQUFFLEdBQUcsUUFBUSxLQUFLLEtBQUssUUFBUSxLQUFLLFVBQVU7QUFDMUU7Ozs7QUFLQSxJQUFJLE9BQXNCLDJCQUFZO0NBQ2xDLFNBQVMsS0FBSyxNQUFNLElBQUk7RUFDcEIsS0FBSyxJQUFJLElBQUk7RUFDYixLQUFLLElBQUk7RUFDVCxLQUFLLElBQUk7RUFDVCxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUU7Q0FDL0I7Ozs7OztDQU1BLEtBQUssVUFBVSxPQUFPLFNBQVUsT0FBTyxPQUFPO0VBQzFDLEtBQUssRUFBRSxFQUFFLEtBQUs7RUFDZCxLQUFLLEtBQUssTUFBTTtFQUNoQixRQUFRLFVBQVUsS0FBSyxLQUFLLE1BQU0sT0FBTyxLQUFLO0NBQ2xEO0NBQ0EsS0FBSyxVQUFVLElBQUksU0FBVSxHQUFHLEdBQUc7RUFDL0IsSUFBSSxNQUFNLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztFQUNoRSxJQUFJLEtBQUssR0FDTCxJQUFJLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxJQUFJO0VBQy9CLElBQUksR0FDQSxPQUFPLEtBQUssSUFBSSxTQUFTLEdBQUcsS0FBSyxFQUFFLEVBQUUsQ0FBQyxHQUFHLE9BQU8sS0FBSyxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUM7RUFDL0UsS0FBSyxPQUFPLEtBQUssQ0FBQztDQUN0Qjs7Ozs7Ozs7Q0FRQSxLQUFLLFVBQVUsUUFBUSxTQUFVLE1BQU07RUFDbkMsUUFBUSxVQUFVLE1BQU0sS0FBSyxNQUFNLElBQUk7Q0FDM0M7Q0FDQSxPQUFPO0FBQ1gsRUFBRTs7OztBQUtGLElBQUksWUFBMkIsMkJBQVk7Q0FDdkMsU0FBUyxVQUFVLE1BQU0sSUFBSTtFQUN6QixTQUFTO0dBQ0w7R0FDQTtHQUNBLFdBQVk7SUFBRSxPQUFPO0tBQUM7S0FBTztLQUFTO0lBQUk7R0FBRztFQUNqRCxHQUFHLE1BQU0sUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLEdBQUcsU0FBVSxJQUFJO0dBRWpELFlBQVksTUFBTSxJQURILEtBQUssR0FBRyxJQUNGLENBQUM7RUFDMUIsR0FBRyxHQUFHLENBQUM7Q0FDWDtDQUNBLE9BQU87QUFDWCxFQUFFO0FBRUYsU0FBZ0IsS0FBSyxNQUFNLE1BQU0sSUFBSTtDQUNqQyxJQUFJLENBQUMsSUFDRCxLQUFLLE1BQU0sT0FBTyxDQUFDO0NBQ3ZCLElBQUksT0FBTyxNQUFNLFlBQ2IsSUFBSSxDQUFDO0NBQ1QsT0FBTyxNQUFNLE1BQU0sTUFBTTtFQUNyQjtFQUNBO0VBQ0EsV0FBWTtHQUFFLE9BQU8sQ0FBQyxRQUFRO0VBQUc7Q0FDckMsR0FBRyxTQUFVLElBQUk7RUFBRSxPQUFPLElBQUksU0FBUyxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxDQUFDO0NBQUcsR0FBRyxHQUFHLEVBQUU7QUFDN0U7Ozs7Ozs7QUFPQSxTQUFnQixTQUFTLE1BQU0sTUFBTTtDQUNqQyxJQUFJLENBQUMsTUFDRCxPQUFPLENBQUM7Q0FDWixJQUFJLElBQUksSUFBSSxHQUFHLElBQUksS0FBSztDQUN4QixFQUFFLEVBQUUsSUFBSTtDQUNSLElBQUksSUFBSSxLQUFLLE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxFQUFFO0NBQy9DLE9BQU8sSUFBSSxHQUFHLElBQUksR0FBRyxPQUFPLEdBQUcsSUFBSSxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsT0FBTyxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUc7QUFDdkU7Ozs7QUFJQSxJQUFJLFNBQXdCLDJCQUFZO0NBQ3BDLFNBQVMsT0FBTyxNQUFNLElBQUk7RUFDdEIsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0VBQ1QsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFO0NBQy9COzs7Ozs7Q0FNQSxPQUFPLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUM1QyxRQUFRLFVBQVUsRUFBRSxLQUFLLE1BQU0sS0FBSztFQUNwQyxLQUFLLEtBQUssTUFBTTtFQUNoQixJQUFJLEtBQUssR0FBRztHQUNSLElBQUksSUFBSSxLQUFLLEVBQUUsU0FBUyxLQUFLLElBQUksQ0FBQztHQUNsQyxJQUFJLElBQUksRUFBRSxTQUFTLElBQUksSUFBSSxDQUFDLElBQUk7R0FDaEMsSUFBSSxJQUFJLEVBQUU7UUFDRixDQUFDLE9BQ0Q7R0FBQSxPQUVILElBQUksS0FBSyxJQUFJLEtBQUssS0FBSyxVQUN4QixLQUFLLFNBQVMsS0FBSyxJQUFJLEVBQUUsTUFBTTtHQUVuQyxLQUFLLElBQUksRUFBRSxTQUFTLENBQUMsR0FBRyxLQUFLLElBQUk7RUFDckM7RUFHQSxRQUFRLFVBQVUsRUFBRSxLQUFLLE1BQU0sQ0FBQztFQUVoQyxJQUFJLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxFQUFFLEdBQUc7R0FDdkIsS0FBSyxJQUFJLEtBQUssS0FBSyxFQUFFLENBQUMsSUFBSTtHQUMxQixLQUFLLElBQUksRUFBRSxHQUFHLEVBQUU7R0FDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDO0dBQ2pCLEtBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEtBQUs7RUFDOUIsT0FDSyxJQUFJLE9BQ0wsUUFBUSxVQUFVLEVBQUUsS0FBSyxNQUFNLEtBQUs7Q0FFNUM7Q0FDQSxPQUFPO0FBQ1gsRUFBRTs7OztBQUtGLElBQUksY0FBNkIsMkJBQVk7Q0FDekMsU0FBUyxZQUFZLE1BQU0sSUFBSTtFQUMzQixJQUFJLFFBQVE7RUFDWixTQUFTO0dBQ0w7R0FDQTtHQUNBLFdBQVk7SUFBRSxPQUFPO0tBQUM7S0FBTztLQUFTO0lBQU07R0FBRztFQUNuRCxHQUFHLE1BQU0sUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLEdBQUcsU0FBVSxJQUFJO0dBQ2pELElBQUksT0FBTyxJQUFJLE9BQU8sR0FBRyxJQUFJO0dBQzdCLEtBQUssV0FBVyxTQUFVLFFBQVE7SUFBRSxPQUFPLFlBQVksTUFBTTtHQUFHO0dBQ2hFLFlBQVksTUFBTSxJQUFJO0VBQzFCLEdBQUcsR0FBRyxHQUFHLFNBQVUsUUFBUTtHQUFFLE9BQU8sTUFBTSxZQUFZLE1BQU0sU0FBUyxNQUFNO0VBQUcsQ0FBQztDQUNuRjtDQUNBLE9BQU87QUFDWCxFQUFFO0FBRUYsU0FBZ0IsT0FBTyxNQUFNLE1BQU0sSUFBSTtDQUNuQyxJQUFJLENBQUMsSUFDRCxLQUFLLE1BQU0sT0FBTyxDQUFDO0NBQ3ZCLElBQUksT0FBTyxNQUFNLFlBQ2IsSUFBSSxDQUFDO0NBQ1QsT0FBTyxNQUFNLE1BQU0sTUFBTTtFQUNyQjtFQUNBO0VBQ0EsV0FBWTtHQUFFLE9BQU8sQ0FBQyxVQUFVO0VBQUc7Q0FDdkMsR0FBRyxTQUFVLElBQUk7RUFBRSxPQUFPLElBQUksV0FBVyxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxDQUFDO0NBQUcsR0FBRyxHQUFHLEVBQUU7QUFDL0U7QUFDQSxTQUFnQixXQUFXLE1BQU0sTUFBTTtDQUNuQyxJQUFJLEtBQUssSUFBSSxJQUFJO0NBQ2pCLElBQUksS0FBSyxJQUFJLEtBQUssUUFDZCxJQUFJLEdBQUcsbUJBQW1CO0NBQzlCLE9BQU8sTUFBTSxLQUFLLFNBQVMsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxRQUFRLEtBQUssT0FBTyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxRQUFRLEtBQUssVUFBVTtBQUNoSDs7OztBQUlBLElBQUksT0FBc0IsMkJBQVk7Q0FDbEMsU0FBUyxLQUFLLE1BQU0sSUFBSTtFQUNwQixLQUFLLElBQUksTUFBTTtFQUNmLEtBQUssSUFBSTtFQUNULFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRTtDQUMvQjs7Ozs7O0NBTUEsS0FBSyxVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDMUMsS0FBSyxFQUFFLEVBQUUsS0FBSztFQUNkLFFBQVEsVUFBVSxLQUFLLEtBQUssTUFBTSxPQUFPLEtBQUs7Q0FDbEQ7Q0FDQSxLQUFLLFVBQVUsSUFBSSxTQUFVLEdBQUcsR0FBRztFQUMvQixJQUFJLE1BQU0sS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLE1BQU0sS0FBSyxFQUFFLGFBQWEsSUFBSSxJQUFJLEtBQUssR0FBRyxLQUFLLENBQUM7RUFDL0UsSUFBSSxLQUFLLEdBQ0wsSUFBSSxLQUFLLEtBQUssQ0FBQyxHQUFHLEtBQUssSUFBSTtFQUMvQixJQUFJLEdBQ0EsT0FBTyxLQUFLLElBQUksU0FBUyxHQUFHLEtBQUssRUFBRSxFQUFFLENBQUM7RUFDMUMsS0FBSyxPQUFPLEtBQUssQ0FBQztDQUN0Qjs7Ozs7Ozs7Q0FRQSxLQUFLLFVBQVUsUUFBUSxTQUFVLE1BQU07RUFDbkMsUUFBUSxVQUFVLE1BQU0sS0FBSyxNQUFNLElBQUk7Q0FDM0M7Q0FDQSxPQUFPO0FBQ1gsRUFBRTs7OztBQUtGLElBQUksWUFBMkIsMkJBQVk7Q0FDdkMsU0FBUyxVQUFVLE1BQU0sSUFBSTtFQUN6QixTQUFTO0dBQ0w7R0FDQTtHQUNBLFdBQVk7SUFBRSxPQUFPO0tBQUM7S0FBTztLQUFTO0lBQUk7R0FBRztFQUNqRCxHQUFHLE1BQU0sUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLEdBQUcsU0FBVSxJQUFJO0dBRWpELFlBQVksTUFBTSxJQURILEtBQUssR0FBRyxJQUNGLENBQUM7RUFDMUIsR0FBRyxJQUFJLENBQUM7Q0FDWjtDQUNBLE9BQU87QUFDWCxFQUFFO0FBRUYsU0FBZ0IsS0FBSyxNQUFNLE1BQU0sSUFBSTtDQUNqQyxJQUFJLENBQUMsSUFDRCxLQUFLLE1BQU0sT0FBTyxDQUFDO0NBQ3ZCLElBQUksT0FBTyxNQUFNLFlBQ2IsSUFBSSxDQUFDO0NBQ1QsT0FBTyxNQUFNLE1BQU0sTUFBTTtFQUNyQjtFQUNBO0VBQ0EsV0FBWTtHQUFFLE9BQU8sQ0FBQyxRQUFRO0VBQUc7Q0FDckMsR0FBRyxTQUFVLElBQUk7RUFBRSxPQUFPLElBQUksU0FBUyxHQUFHLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxDQUFDO0NBQUcsR0FBRyxHQUFHLEVBQUU7QUFDN0U7Ozs7Ozs7QUFPQSxTQUFnQixTQUFTLE1BQU0sTUFBTTtDQUNqQyxJQUFJLENBQUMsTUFDRCxPQUFPLENBQUM7Q0FDWixJQUFJLElBQUksTUFBTTtDQUNkLEVBQUUsRUFBRSxJQUFJO0NBQ1IsSUFBSSxJQUFJLEtBQUssTUFBTSxNQUFNLEtBQUssYUFBYSxJQUFJLEdBQUcsQ0FBQztDQUNuRCxPQUFPLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTyxHQUFHLEVBQUUsU0FBUyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUc7QUFDekQ7Ozs7QUFJQSxJQUFJLFNBQXdCLDJCQUFZO0NBQ3BDLFNBQVMsT0FBTyxNQUFNLElBQUk7RUFDdEIsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFO0VBQzNCLEtBQUssSUFBSSxRQUFRLEtBQUssYUFBYSxJQUFJO0NBQzNDOzs7Ozs7Q0FNQSxPQUFPLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUM1QyxRQUFRLFVBQVUsRUFBRSxLQUFLLE1BQU0sS0FBSztFQUNwQyxJQUFJLEtBQUssR0FBRztHQUNSLElBQUksS0FBSyxFQUFFLFNBQVMsS0FBSyxDQUFDLE9BQ3RCO0dBQ0osS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLElBQUksS0FBSyxHQUFHLEtBQUssSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLElBQUk7RUFDaEU7RUFDQSxJQUFJLE9BQU87R0FDUCxJQUFJLEtBQUssRUFBRSxTQUFTLEdBQ2hCLElBQUksR0FBRyxtQkFBbUI7R0FDOUIsS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLEdBQUcsRUFBRTtFQUNsQztFQUdBLFFBQVEsVUFBVSxFQUFFLEtBQUssTUFBTSxLQUFLO0NBQ3hDO0NBQ0EsT0FBTztBQUNYLEVBQUU7Ozs7QUFLRixJQUFJLGNBQTZCLDJCQUFZO0NBQ3pDLFNBQVMsWUFBWSxNQUFNLElBQUk7RUFDM0IsU0FBUztHQUNMO0dBQ0E7R0FDQSxXQUFZO0lBQUUsT0FBTztLQUFDO0tBQU87S0FBUztJQUFNO0dBQUc7RUFDbkQsR0FBRyxNQUFNLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxHQUFHLFNBQVUsSUFBSTtHQUVqRCxZQUFZLE1BQU0sSUFESCxPQUFPLEdBQUcsSUFDSixDQUFDO0VBQzFCLEdBQUcsSUFBSSxDQUFDO0NBQ1o7Q0FDQSxPQUFPO0FBQ1gsRUFBRTtBQUVGLFNBQWdCLE9BQU8sTUFBTSxNQUFNLElBQUk7Q0FDbkMsSUFBSSxDQUFDLElBQ0QsS0FBSyxNQUFNLE9BQU8sQ0FBQztDQUN2QixJQUFJLE9BQU8sTUFBTSxZQUNiLElBQUksQ0FBQztDQUNULE9BQU8sTUFBTSxNQUFNLE1BQU07RUFDckI7RUFDQTtFQUNBLFdBQVk7R0FBRSxPQUFPLENBQUMsVUFBVTtFQUFHO0NBQ3ZDLEdBQUcsU0FBVSxJQUFJO0VBQUUsT0FBTyxJQUFJLFdBQVcsR0FBRyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7Q0FBRyxHQUFHLEdBQUcsRUFBRTtBQUNyRjtBQUNBLFNBQWdCLFdBQVcsTUFBTSxNQUFNO0NBQ25DLE9BQU8sTUFBTSxLQUFLLFNBQVMsSUFBSSxNQUFNLFFBQVEsS0FBSyxVQUFVLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsUUFBUSxLQUFLLEtBQUssUUFBUSxLQUFLLFVBQVU7QUFDM0g7Ozs7QUFPQSxJQUFJLGFBQTRCLDJCQUFZO0NBQ3hDLFNBQVMsV0FBVyxNQUFNLElBQUk7RUFDMUIsS0FBSyxJQUFJLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxLQUFLLENBQUM7RUFDMUMsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0NBQ2I7Q0FHQSxXQUFXLFVBQVUsSUFBSSxXQUFZO0VBQ2pDLElBQUksUUFBUTtFQUNaLEtBQUssRUFBRSxTQUFTLFNBQVUsS0FBSyxPQUFPO0dBQ2xDLE1BQU0sT0FBTyxLQUFLLEtBQUs7RUFDM0I7Q0FDSjs7Ozs7O0NBTUEsV0FBVyxVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDaEQsSUFBSSxDQUFDLEtBQUssUUFDTixJQUFJLENBQUM7RUFDVCxJQUFJLENBQUMsS0FBSyxHQUFHO0dBQ1QsSUFBSSxLQUFLLEtBQUssS0FBSyxFQUFFLFFBQVE7SUFDekIsSUFBSSxJQUFJLElBQUksR0FBRyxLQUFLLEVBQUUsU0FBUyxNQUFNLE1BQU07SUFDM0MsRUFBRSxJQUFJLEtBQUssQ0FBQyxHQUFHLEVBQUUsSUFBSSxPQUFPLEtBQUssRUFBRSxNQUFNO0dBQzdDLE9BRUksS0FBSyxJQUFJO0dBQ2IsSUFBSSxLQUFLLEVBQUUsU0FBUyxHQUFHO0lBQ25CLEtBQUssSUFBSyxLQUFLLEVBQUUsTUFBTSxNQUFNLEtBQUssRUFBRSxNQUFNLE9BQU8sS0FBSyxFQUFFLE1BQU0sSUFDeEQsSUFBSSxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQ2YsS0FBSyxFQUFFLEtBQUssT0FBTyxLQUFNLEtBQUssRUFBRSxNQUFNLElBQUssTUFBTyxLQUFLLEVBQUUsTUFBTSxJQUFJLEtBQUssRUFBRSxNQUFNLEtBQzlFLElBQUksS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUNqQixJQUFJLEtBQUssRUFBRSxLQUFLLENBQUM7SUFDM0IsS0FBSyxFQUFFO0lBQ1AsS0FBSyxFQUFFLEtBQUssS0FBSyxHQUFHLEtBQUs7SUFDekIsS0FBSyxJQUFJO0dBQ2I7RUFDSixPQUVJLEtBQUssRUFBRSxLQUFLLE9BQU8sS0FBSztDQUNoQztDQUNBLE9BQU87QUFDWCxFQUFFOzs7O0FBS0YsSUFBSSxrQkFBaUMsMkJBQVk7Q0FDN0MsU0FBUyxnQkFBZ0IsTUFBTSxJQUFJO0VBQy9CLFdBQVcsS0FBSyxNQUFNLE1BQU0sRUFBRTtFQUM5QixLQUFLLGFBQWE7RUFDbEIsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0VBQ1QsS0FBSyxJQUFJO0NBQ2I7Q0FDQSxnQkFBZ0IsVUFBVSxJQUFJLFdBQVk7RUFDdEMsSUFBSSxRQUFRO0VBQ1osS0FBSyxFQUFFLFNBQVMsU0FBVSxLQUFLLEtBQUssT0FBTztHQUN2QyxNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUs7RUFDaEM7RUFDQSxLQUFLLEVBQUUsVUFBVSxTQUFVLE1BQU07R0FDN0IsTUFBTSxjQUFjO0dBQ3BCLElBQUksTUFBTSxTQUNOLE1BQU0sUUFBUSxJQUFJO0VBQzFCO0NBQ0o7Ozs7OztDQU1BLGdCQUFnQixVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDckQsS0FBSyxjQUFjLE1BQU07RUFDekIsV0FBVyxVQUFVLEtBQUssS0FBSyxNQUFNLE9BQU8sS0FBSztDQUNyRDtDQUNBLE9BQU87QUFDWCxFQUFFO0FBRUYsU0FBZ0IsV0FBVyxNQUFNLE1BQU0sSUFBSTtDQUN2QyxJQUFJLENBQUMsSUFDRCxLQUFLLE1BQU0sT0FBTyxDQUFDO0NBQ3ZCLElBQUksT0FBTyxNQUFNLFlBQ2IsSUFBSSxDQUFDO0NBQ1QsT0FBUSxLQUFLLE1BQU0sTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFDaEQsT0FBTyxNQUFNLE1BQU0sRUFBRSxLQUNuQixLQUFLLEtBQUssT0FBTyxLQUFNLEtBQUssTUFBTSxJQUFLLE1BQU8sS0FBSyxNQUFNLElBQUksS0FBSyxNQUFNLEtBQ3RFLFFBQVEsTUFBTSxNQUFNLEVBQUUsSUFDdEIsT0FBTyxNQUFNLE1BQU0sRUFBRTtBQUNuQzs7Ozs7OztBQU9BLFNBQWdCLGVBQWUsTUFBTSxNQUFNO0NBQ3ZDLE9BQVEsS0FBSyxNQUFNLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFNLElBQ2hELFdBQVcsTUFBTSxJQUFJLEtBQ25CLEtBQUssS0FBSyxPQUFPLEtBQU0sS0FBSyxNQUFNLElBQUssTUFBTyxLQUFLLE1BQU0sSUFBSSxLQUFLLE1BQU0sS0FDdEUsWUFBWSxNQUFNLElBQUksSUFDdEIsV0FBVyxNQUFNLElBQUk7QUFDbkM7QUFFQSxJQUFJLE9BQU8sU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQzdCLEtBQUssSUFBSSxLQUFLLEdBQUc7RUFDYixJQUFJLE1BQU0sRUFBRSxJQUFJLElBQUksSUFBSSxHQUFHLEtBQUs7RUFDaEMsSUFBSSxNQUFNLFFBQVEsR0FBRyxHQUNqQixLQUFLLElBQUksR0FBRyxJQUFJLEVBQUUsR0FBRyxNQUFNLElBQUk7RUFDbkMsSUFBSSxZQUFZLE9BQU8sR0FBRyxHQUN0QixFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUU7T0FDZDtHQUNELEVBQUUsS0FBSyxPQUFPLENBQUMsSUFBSSxHQUFHLENBQUMsR0FBRyxFQUFFO0dBQzVCLEtBQUssS0FBSyxHQUFHLEdBQUcsQ0FBQztFQUNyQjtDQUNKO0FBQ0o7QUFFQSxJQUFJLEtBQUssT0FBTyxlQUFlLDZCQUE2QixJQUFJLFlBQVk7QUFFNUUsSUFBSSxLQUFLLE9BQU8sZUFBZSw2QkFBNkIsSUFBSSxZQUFZO0FBRTVFLElBQUksTUFBTTtBQUNWLElBQUk7Q0FDQSxHQUFHLE9BQU8sSUFBSSxFQUFFLFFBQVEsS0FBSyxDQUFDO0NBQzlCLE1BQU07QUFDVixTQUNPLEdBQUcsQ0FBRTtBQUVaLElBQUksUUFBUSxTQUFVLEdBQUc7Q0FDckIsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUs7RUFDdEIsSUFBSSxJQUFJLEVBQUU7RUFDVixJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksUUFBUSxJQUFJO0VBQ3RDLElBQUksSUFBSSxLQUFLLEVBQUUsUUFDWCxPQUFPO0dBQUUsR0FBRztHQUFHLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztFQUFFO0VBQ3BDLElBQUksQ0FBQyxJQUNELEtBQUssT0FBTyxhQUFhLENBQUM7T0FDekIsSUFBSSxNQUFNLEdBQ1gsTUFBTSxJQUFJLE9BQU8sTUFBTSxFQUFFLE9BQU8sT0FBTyxNQUFNLEVBQUUsT0FBTyxPQUFPLElBQUssRUFBRSxPQUFPLE1BQU8sT0FDOUUsS0FBSyxPQUFPLGFBQWEsUUFBUyxLQUFLLElBQUssUUFBUyxJQUFJLElBQUs7T0FFakUsSUFBSSxLQUFLLEdBQ1YsS0FBSyxPQUFPLGNBQWMsSUFBSSxPQUFPLElBQUssRUFBRSxPQUFPLEVBQUc7T0FFdEQsS0FBSyxPQUFPLGNBQWMsSUFBSSxPQUFPLE1BQU0sRUFBRSxPQUFPLE9BQU8sSUFBSyxFQUFFLE9BQU8sRUFBRztDQUNwRjtBQUNKOzs7O0FBSUEsSUFBSSxhQUE0QiwyQkFBWTs7Ozs7Q0FLeEMsU0FBUyxXQUFXLElBQUk7RUFDcEIsS0FBSyxTQUFTO0VBQ2QsSUFBSSxLQUNBLEtBQUssSUFBSSxJQUFJLFlBQVk7T0FFekIsS0FBSyxJQUFJO0NBQ2pCOzs7Ozs7Q0FNQSxXQUFXLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUNoRCxJQUFJLENBQUMsS0FBSyxRQUNOLElBQUksQ0FBQztFQUNULFFBQVEsQ0FBQyxDQUFDO0VBQ1YsSUFBSSxLQUFLLEdBQUc7R0FDUixLQUFLLE9BQU8sS0FBSyxFQUFFLE9BQU8sT0FBTyxFQUFFLFFBQVEsS0FBSyxDQUFDLEdBQUcsS0FBSztHQUN6RCxJQUFJLE9BQU87SUFDUCxJQUFJLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxRQUNoQixJQUFJLENBQUM7SUFDVCxLQUFLLElBQUk7R0FDYjtHQUNBO0VBQ0o7RUFDQSxJQUFJLENBQUMsS0FBSyxHQUNOLElBQUksQ0FBQztFQUNULElBQUksTUFBTSxJQUFJLEdBQUcsS0FBSyxFQUFFLFNBQVMsTUFBTSxNQUFNO0VBQzdDLElBQUksSUFBSSxLQUFLLENBQUM7RUFDZCxJQUFJLElBQUksT0FBTyxLQUFLLEVBQUUsTUFBTTtFQUM1QixJQUFJLEtBQUssTUFBTSxHQUFHLEdBQUcsSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHO0VBQ3RDLElBQUksT0FBTztHQUNQLElBQUksRUFBRSxRQUNGLElBQUksQ0FBQztHQUNULEtBQUssSUFBSTtFQUNiLE9BRUksS0FBSyxJQUFJO0VBQ2IsS0FBSyxPQUFPLEdBQUcsS0FBSztDQUN4QjtDQUNBLE9BQU87QUFDWCxFQUFFOzs7O0FBS0YsSUFBSSxhQUE0QiwyQkFBWTs7Ozs7Q0FLeEMsU0FBUyxXQUFXLElBQUk7RUFDcEIsS0FBSyxTQUFTO0NBQ2xCOzs7Ozs7Q0FNQSxXQUFXLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUNoRCxJQUFJLENBQUMsS0FBSyxRQUNOLElBQUksQ0FBQztFQUNULElBQUksS0FBSyxHQUNMLElBQUksQ0FBQztFQUNULEtBQUssT0FBTyxRQUFRLEtBQUssR0FBRyxLQUFLLElBQUksU0FBUyxLQUFLO0NBQ3ZEO0NBQ0EsT0FBTztBQUNYLEVBQUU7Ozs7Ozs7O0FBU0YsU0FBZ0IsUUFBUSxLQUFLLFFBQVE7Q0FDakMsSUFBSSxRQUFRO0VBQ1IsSUFBSSxPQUFPLElBQUksR0FBRyxJQUFJLE1BQU07RUFDNUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxFQUFFLEdBQzlCLEtBQUssS0FBSyxJQUFJLFdBQVcsQ0FBQztFQUM5QixPQUFPO0NBQ1g7Q0FDQSxJQUFJLElBQ0EsT0FBTyxHQUFHLE9BQU8sR0FBRztDQUN4QixJQUFJLElBQUksSUFBSTtDQUNaLElBQUksS0FBSyxJQUFJLEdBQUcsSUFBSSxVQUFVLElBQUksVUFBVSxFQUFFO0NBQzlDLElBQUksS0FBSztDQUNULElBQUksSUFBSSxTQUFVLEdBQUc7RUFBRSxHQUFHLFFBQVE7Q0FBRztDQUNyQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUc7RUFDeEIsSUFBSSxLQUFLLElBQUksR0FBRyxRQUFRO0dBQ3BCLElBQUksSUFBSSxJQUFJLEdBQUcsS0FBSyxLQUFNLElBQUksS0FBTSxFQUFFO0dBQ3RDLEVBQUUsSUFBSSxFQUFFO0dBQ1IsS0FBSztFQUNUO0VBQ0EsSUFBSSxJQUFJLElBQUksV0FBVyxDQUFDO0VBQ3hCLElBQUksSUFBSSxPQUFPLFFBQ1gsRUFBRSxDQUFDO09BQ0YsSUFBSSxJQUFJLE1BQ1QsRUFBRSxNQUFPLEtBQUssQ0FBRSxHQUFHLEVBQUUsTUFBTyxJQUFJLEVBQUc7T0FDbEMsSUFBSSxJQUFJLFNBQVMsSUFBSSxPQUN0QixJQUFJLFNBQVMsSUFBSSxXQUFlLElBQUksV0FBVyxFQUFFLENBQUMsSUFBSSxNQUNsRCxFQUFFLE1BQU8sS0FBSyxFQUFHLEdBQUcsRUFBRSxNQUFRLEtBQUssS0FBTSxFQUFHLEdBQUcsRUFBRSxNQUFRLEtBQUssSUFBSyxFQUFHLEdBQUcsRUFBRSxNQUFPLElBQUksRUFBRztPQUU3RixFQUFFLE1BQU8sS0FBSyxFQUFHLEdBQUcsRUFBRSxNQUFRLEtBQUssSUFBSyxFQUFHLEdBQUcsRUFBRSxNQUFPLElBQUksRUFBRztDQUN0RTtDQUNBLE9BQU8sSUFBSSxJQUFJLEdBQUcsRUFBRTtBQUN4Qjs7Ozs7Ozs7QUFRQSxTQUFnQixVQUFVLEtBQUssUUFBUTtDQUNuQyxJQUFJLFFBQVE7RUFDUixJQUFJLElBQUk7RUFDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUssT0FDakMsS0FBSyxPQUFPLGFBQWEsTUFBTSxNQUFNLElBQUksU0FBUyxHQUFHLElBQUksS0FBSyxDQUFDO0VBQ25FLE9BQU87Q0FDWCxPQUNLLElBQUksSUFDTCxPQUFPLEdBQUcsT0FBTyxHQUFHO01BRW5CO0VBQ0QsSUFBSSxLQUFLLE1BQU0sR0FBRyxHQUFHLElBQUksR0FBRyxHQUFHLElBQUksR0FBRztFQUN0QyxJQUFJLEVBQUUsUUFDRixJQUFJLENBQUM7RUFDVCxPQUFPO0NBQ1g7QUFDSjtBQUdBLElBQUksTUFBTSxTQUFVLEdBQUc7Q0FBRSxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJO0FBQUc7QUFFekUsSUFBSSxPQUFPLFNBQVUsR0FBRyxHQUFHO0NBQUUsT0FBTyxJQUFJLEtBQUssR0FBRyxHQUFHLElBQUksRUFBRSxJQUFJLEdBQUcsR0FBRyxJQUFJLEVBQUU7QUFBRztBQUU1RSxJQUFJLEtBQUssU0FBVSxHQUFHLEdBQUcsR0FBRztDQUN4QixJQUFJLE1BQU0sR0FBRyxHQUFHLElBQUksRUFBRSxHQUFHLE1BQU0sR0FBRyxHQUFHLElBQUksRUFBRSxHQUFHLEtBQUssVUFBVSxFQUFFLFNBQVMsSUFBSSxJQUFJLElBQUksS0FBSyxHQUFHLEdBQUcsRUFBRSxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksS0FBSyxHQUFHLEtBQUssSUFBSSxLQUFLO0NBQ3RJLElBQUksS0FBSyxNQUFNLEdBQUcsSUFBSSxLQUFLLEdBQUcsR0FBRyxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQUcsSUFBSSxFQUFFLENBQUMsR0FBRyxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxNQUFNLEdBQUc7Q0FDN0csT0FBTztFQUFDLEdBQUcsR0FBRyxJQUFJLEVBQUU7RUFBRztFQUFJO0VBQUk7RUFBSSxLQUFLLE1BQU0sR0FBRyxHQUFHLElBQUksRUFBRTtFQUFHO0NBQUc7QUFDcEU7QUFFQSxJQUFJLFFBQVEsU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksSUFBSSxLQUFLO0NBQzNDLElBQUksTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLFlBQVksT0FBTyxPQUFPLFlBQVksSUFBSSxJQUFJO0NBQ3RGLElBQUksS0FBSyxNQUFNLE1BQU07Q0FDckIsSUFBSSxLQUFLLElBQUk7RUFDVCxPQUFPLElBQUksSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQ2xDLElBQUksR0FBRyxHQUFHLENBQUMsS0FBSyxHQUNaLE9BQU87R0FDSCxNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLElBQUk7R0FDL0IsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUk7R0FDckIsT0FBTyxHQUFHLEdBQUcsSUFBSSxJQUFJLEtBQUssTUFBTSxJQUFJLElBQUk7R0FDeEM7RUFDSjtFQUlSLElBQUksSUFBSSxHQUNKLElBQUksRUFBRTtDQUNkO0NBQ0EsT0FBTztFQUFDO0VBQUk7RUFBSTtFQUFLO0NBQUM7QUFDMUI7QUFFQSxJQUFJLE9BQU8sU0FBVSxJQUFJO0NBQ3JCLElBQUksS0FBSztDQUNULElBQUksSUFDQSxLQUFLLElBQUksS0FBSyxJQUFJO0VBQ2QsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO0VBQ2QsSUFBSSxJQUFJLE9BQ0osSUFBSSxDQUFDO0VBQ1QsTUFBTSxJQUFJO0NBQ2Q7Q0FFSixPQUFPO0FBQ1g7QUFFQSxJQUFJLE1BQU0sU0FBVSxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxJQUFJLElBQUk7Q0FDM0MsSUFBSSxLQUFLLEdBQUcsUUFBUSxLQUFLLEVBQUUsT0FBTyxNQUFNLE1BQU0sR0FBRztDQUNqRCxJQUFJLE1BQU0sS0FBSyxFQUFFO0NBQ2pCLE9BQU8sR0FBRyxHQUFHLE1BQU0sT0FBTyxXQUFZLFFBQVMsR0FBRyxLQUFLO0NBQ3ZELElBQUksTUFBTSxNQUNOLEVBQUUsT0FBTyxJQUFJLEVBQUUsT0FBTyxFQUFFO0NBQzVCLEVBQUUsS0FBSyxJQUFJLEtBQUs7Q0FDaEIsRUFBRSxPQUFRLEVBQUUsUUFBUSxLQUFNLElBQUksS0FBSyxJQUFJLEVBQUUsT0FBTyxLQUFLO0NBQ3JELEVBQUUsT0FBTyxFQUFFLGNBQWMsS0FBSyxFQUFFLE9BQU8sRUFBRSxlQUFlO0NBQ3hELElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxTQUFTLE9BQU8sS0FBSyxJQUFJLElBQUksRUFBRSxLQUFLLEdBQUcsSUFBSSxHQUFHLFlBQVksSUFBSTtDQUNsRixJQUFJLElBQUksS0FBSyxJQUFJLEtBQ2IsSUFBSSxFQUFFO0NBQ1YsT0FBTyxHQUFHLEdBQUksS0FBSyxLQUFRLEdBQUcsU0FBUyxJQUFJLEtBQU0sS0FBTyxHQUFHLFFBQVEsS0FBSyxLQUFPLEdBQUcsU0FBUyxLQUFLLEtBQU8sR0FBRyxXQUFXLEtBQUssSUFBTSxHQUFHLFdBQVcsS0FBSyxDQUFFLEdBQUcsS0FBSztDQUM3SixJQUFJLEtBQUssSUFBSTtFQUNULE9BQU8sR0FBRyxHQUFHLEVBQUUsR0FBRztFQUNsQixPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDO0VBQ25DLE9BQU8sR0FBRyxJQUFJLEdBQUcsRUFBRSxJQUFJO0NBQzNCO0NBQ0EsT0FBTyxHQUFHLElBQUksSUFBSSxFQUFFO0NBQ3BCLE9BQU8sR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLEtBQUs7Q0FDN0IsSUFBSSxNQUFNLE1BQU07RUFDWixPQUFPLEdBQUcsR0FBRyxHQUFHO0VBQ2hCLE9BQU8sR0FBRyxJQUFJLEdBQUcsRUFBRSxLQUFLO0VBQ3hCLE9BQU8sR0FBRyxJQUFJLElBQUksRUFBRSxHQUFHLEtBQUs7Q0FDaEM7Q0FDQSxFQUFFLElBQUksSUFBSSxDQUFDO0NBQ1gsS0FBSztDQUNMLElBQUksS0FDQSxLQUFLLElBQUksS0FBSyxJQUFJO0VBQ2QsSUFBSSxNQUFNLEdBQUcsSUFBSSxJQUFJLElBQUk7RUFDekIsT0FBTyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0VBQ2YsT0FBTyxHQUFHLElBQUksR0FBRyxDQUFDO0VBQ2xCLEVBQUUsSUFBSSxLQUFLLElBQUksQ0FBQyxHQUFHLEtBQUssSUFBSTtDQUNoQztDQUVKLElBQUksS0FDQSxFQUFFLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSztDQUN2QixPQUFPO0FBQ1g7QUFFQSxJQUFJLE1BQU0sU0FBVSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUc7Q0FDL0IsT0FBTyxHQUFHLEdBQUcsU0FBUztDQUN0QixPQUFPLEdBQUcsSUFBSSxHQUFHLENBQUM7Q0FDbEIsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDO0NBQ25CLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQztDQUNuQixPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUM7QUFDdkI7Ozs7QUFJQSxJQUFJLGlCQUFnQywyQkFBWTs7Ozs7Q0FLNUMsU0FBUyxlQUFlLFVBQVU7RUFDOUIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssSUFBSSxJQUFJO0VBQ2IsS0FBSyxPQUFPO0VBQ1osS0FBSyxjQUFjO0NBQ3ZCOzs7Ozs7Ozs7Q0FTQSxlQUFlLFVBQVUsVUFBVSxTQUFVLE9BQU8sT0FBTztFQUN2RCxLQUFLLE9BQU8sTUFBTSxPQUFPLEtBQUs7Q0FDbEM7Ozs7Ozs7O0NBUUEsZUFBZSxVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDcEQsSUFBSSxDQUFDLEtBQUssUUFDTixJQUFJLENBQUM7RUFDVCxLQUFLLEVBQUUsRUFBRSxLQUFLO0VBQ2QsS0FBSyxRQUFRLE1BQU07RUFDbkIsSUFBSSxPQUNBLEtBQUssTUFBTSxLQUFLLEVBQUUsRUFBRTtFQUd4QixLQUFLLFFBQVEsT0FBTyxTQUFTLEtBQUs7Q0FDdEM7Q0FDQSxPQUFPO0FBQ1gsRUFBRTs7Ozs7QUFPRixJQUFJLGFBQTRCLDJCQUFZOzs7Ozs7Q0FNeEMsU0FBUyxXQUFXLFVBQVUsTUFBTTtFQUNoQyxJQUFJLFFBQVE7RUFDWixJQUFJLENBQUMsTUFDRCxPQUFPLENBQUM7RUFDWixlQUFlLEtBQUssTUFBTSxRQUFRO0VBQ2xDLEtBQUssSUFBSSxJQUFJLFFBQVEsTUFBTSxTQUFVLEtBQUssT0FBTztHQUM3QyxNQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUs7RUFDakMsQ0FBQztFQUNELEtBQUssY0FBYztFQUNuQixLQUFLLE9BQU8sSUFBSSxLQUFLLEtBQUs7Q0FDOUI7Q0FDQSxXQUFXLFVBQVUsVUFBVSxTQUFVLE9BQU8sT0FBTztFQUNuRCxJQUFJO0dBQ0EsS0FBSyxFQUFFLEtBQUssT0FBTyxLQUFLO0VBQzVCLFNBQ08sR0FBRztHQUNOLEtBQUssT0FBTyxHQUFHLE1BQU0sS0FBSztFQUM5QjtDQUNKOzs7Ozs7Q0FNQSxXQUFXLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUNoRCxlQUFlLFVBQVUsS0FBSyxLQUFLLE1BQU0sT0FBTyxLQUFLO0NBQ3pEO0NBQ0EsT0FBTztBQUNYLEVBQUU7Ozs7QUFLRixJQUFJLGtCQUFpQywyQkFBWTs7Ozs7O0NBTTdDLFNBQVMsZ0JBQWdCLFVBQVUsTUFBTTtFQUNyQyxJQUFJLFFBQVE7RUFDWixJQUFJLENBQUMsTUFDRCxPQUFPLENBQUM7RUFDWixlQUFlLEtBQUssTUFBTSxRQUFRO0VBQ2xDLEtBQUssSUFBSSxJQUFJLGFBQWEsTUFBTSxTQUFVLEtBQUssS0FBSyxPQUFPO0dBQ3ZELE1BQU0sT0FBTyxLQUFLLEtBQUssS0FBSztFQUNoQyxDQUFDO0VBQ0QsS0FBSyxjQUFjO0VBQ25CLEtBQUssT0FBTyxJQUFJLEtBQUssS0FBSztFQUMxQixLQUFLLFlBQVksS0FBSyxFQUFFO0NBQzVCO0NBQ0EsZ0JBQWdCLFVBQVUsVUFBVSxTQUFVLE9BQU8sT0FBTztFQUN4RCxLQUFLLEVBQUUsS0FBSyxPQUFPLEtBQUs7Q0FDNUI7Ozs7OztDQU1BLGdCQUFnQixVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDckQsZUFBZSxVQUFVLEtBQUssS0FBSyxNQUFNLE9BQU8sS0FBSztDQUN6RDtDQUNBLE9BQU87QUFDWCxFQUFFOzs7O0FBTUYsSUFBSSxNQUFxQiwyQkFBWTs7Ozs7O0NBTWpDLFNBQVMsSUFBSSxJQUFJO0VBQ2IsS0FBSyxTQUFTO0VBQ2QsS0FBSyxJQUFJLENBQUM7RUFDVixLQUFLLElBQUk7Q0FDYjs7Ozs7Q0FLQSxJQUFJLFVBQVUsTUFBTSxTQUFVLE1BQU07RUFDaEMsSUFBSSxRQUFRO0VBQ1osSUFBSSxDQUFDLEtBQUssUUFDTixJQUFJLENBQUM7RUFFVCxJQUFJLEtBQUssSUFBSSxHQUNULEtBQUssT0FBTyxJQUFJLEtBQUssS0FBSyxJQUFJLEtBQUssR0FBRyxHQUFHLENBQUMsR0FBRyxNQUFNLEtBQUs7T0FDdkQ7R0FDRCxJQUFJLElBQUksUUFBUSxLQUFLLFFBQVEsR0FBRyxPQUFPLEVBQUU7R0FDekMsSUFBSSxNQUFNLEtBQUssU0FBUyxJQUFJLE9BQU8sUUFBUSxHQUFHO0dBQzlDLElBQUksSUFBSSxRQUFRLEtBQUssU0FBUyxVQUFXLEtBQU0sSUFBSSxVQUFVLEVBQUU7R0FDL0QsSUFBSSxPQUFPLE9BQU8sS0FBSyxLQUFLLEtBQUssSUFBSTtHQUNyQyxJQUFJLE9BQU8sT0FDUCxLQUFLLE9BQU8sSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE1BQU0sS0FBSztHQUMxQyxJQUFJLFNBQVMsSUFBSSxHQUFHLElBQUk7R0FDeEIsSUFBSSxRQUFRLEdBQUcsTUFBTSxHQUFHLEdBQUcsRUFBRTtHQUM3QixJQUFJLFNBQVMsQ0FBQyxNQUFNO0dBQ3BCLElBQUksU0FBUyxXQUFZO0lBQ3JCLEtBQUssSUFBSSxLQUFLLEdBQUcsU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLE1BQU07S0FDeEQsSUFBSSxNQUFNLE9BQU87S0FDakIsTUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLO0lBQ2pDO0lBQ0EsU0FBUyxDQUFDO0dBQ2Q7R0FDQSxJQUFJLE9BQU8sS0FBSztHQUNoQixLQUFLLElBQUk7R0FDVCxJQUFJLFFBQVEsS0FBSyxFQUFFO0dBQ25CLElBQUksT0FBTyxJQUFJLE1BQU07SUFDZDtJQUNBO0lBQ0E7SUFDSCxHQUFHLFdBQVk7S0FDWCxJQUFJLEtBQUssV0FDTCxLQUFLLFVBQVU7SUFDdkI7SUFDQSxHQUFHLFdBQVk7S0FDWCxPQUFPO0tBQ1AsSUFBSSxNQUFNO01BQ04sSUFBSSxNQUFNLE1BQU0sRUFBRSxRQUFRO01BQzFCLElBQUksS0FDQSxJQUFJLEVBQUU7V0FFTixNQUFNLElBQUk7S0FDbEI7S0FDQSxPQUFPO0lBQ1g7R0FDSixDQUFDO0dBQ0QsSUFBSSxPQUFPO0dBQ1gsS0FBSyxTQUFTLFNBQVUsS0FBSyxLQUFLLE9BQU87SUFDckMsSUFBSSxLQUFLO0tBQ0wsTUFBTSxPQUFPLEtBQUssS0FBSyxLQUFLO0tBQzVCLE1BQU0sVUFBVTtJQUNwQixPQUNLO0tBQ0QsUUFBUSxJQUFJO0tBQ1osT0FBTyxLQUFLLEdBQUc7S0FDZixJQUFJLE9BQU87TUFDUCxJQUFJLEtBQUssSUFBSSxHQUFHLEVBQUU7TUFDbEIsT0FBTyxJQUFJLEdBQUcsU0FBUztNQUN2QixPQUFPLElBQUksR0FBRyxLQUFLLEdBQUc7TUFDdEIsT0FBTyxJQUFJLEdBQUcsSUFBSTtNQUNsQixPQUFPLElBQUksSUFBSSxLQUFLLElBQUk7TUFDeEIsT0FBTyxLQUFLLEVBQUU7TUFDZCxLQUFLLElBQUksTUFBTSxLQUFLLElBQUksT0FBTyxPQUFPLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFLLE9BQU8sS0FBSztNQUNoRixJQUFJLE1BQ0EsS0FBSyxFQUFFO01BQ1gsT0FBTztLQUNYLE9BQ0ssSUFBSSxNQUNMLE9BQU87SUFDZjtHQUNKO0dBQ0EsS0FBSyxFQUFFLEtBQUssSUFBSTtFQUNwQjtDQUNKOzs7Ozs7Q0FNQSxJQUFJLFVBQVUsTUFBTSxXQUFZO0VBQzVCLElBQUksUUFBUTtFQUNaLElBQUksS0FBSyxJQUFJLEdBQUc7R0FDWixLQUFLLE9BQU8sSUFBSSxLQUFLLEtBQUssSUFBSSxLQUFLLEdBQUcsR0FBRyxDQUFDLEdBQUcsTUFBTSxJQUFJO0dBQ3ZEO0VBQ0o7RUFDQSxJQUFJLEtBQUssR0FDTCxLQUFLLEVBQUU7T0FFUCxLQUFLLEVBQUUsS0FBSztHQUNSLEdBQUcsV0FBWTtJQUNYLElBQUksRUFBRSxNQUFNLElBQUksSUFDWjtJQUNKLE1BQU0sRUFBRSxPQUFPLElBQUksQ0FBQztJQUNwQixNQUFNLEVBQUU7R0FDWjtHQUNBLEdBQUcsV0FBWSxDQUFFO0VBQ3JCLENBQUM7RUFDTCxLQUFLLElBQUk7Q0FDYjtDQUNBLElBQUksVUFBVSxJQUFJLFdBQVk7RUFDMUIsSUFBSSxLQUFLLEdBQUcsSUFBSSxHQUFHLEtBQUs7RUFDeEIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUFNO0dBQ2hELElBQUksSUFBSSxHQUFHO0dBQ1gsTUFBTSxLQUFLLEVBQUUsRUFBRSxTQUFTLEtBQUssRUFBRSxLQUFLLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRSxTQUFTO0VBQ2hFO0VBQ0EsSUFBSSxNQUFNLElBQUksR0FBRyxLQUFLLEVBQUU7RUFDeEIsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsUUFBUSxNQUFNO0dBQ2hELElBQUksSUFBSSxHQUFHO0dBQ1gsSUFBSSxLQUFLLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7R0FDMUMsTUFBTSxLQUFLLEVBQUUsRUFBRSxTQUFTLEtBQUssRUFBRSxLQUFLLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRSxTQUFTLElBQUksS0FBSyxFQUFFO0VBQzNFO0VBQ0EsSUFBSSxLQUFLLElBQUksS0FBSyxFQUFFLFFBQVEsSUFBSSxDQUFDO0VBQ2pDLEtBQUssT0FBTyxNQUFNLEtBQUssSUFBSTtFQUMzQixLQUFLLElBQUk7Q0FDYjs7Ozs7Q0FLQSxJQUFJLFVBQVUsWUFBWSxXQUFZO0VBQ2xDLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLFFBQVEsTUFFMUMsR0FEVyxHQUNWLENBQUMsRUFBRTtFQUVSLEtBQUssSUFBSTtDQUNiO0NBQ0EsT0FBTztBQUNYLEVBQUU7QUFFRixTQUFnQixJQUFJLE1BQU0sTUFBTSxJQUFJO0NBQ2hDLElBQUksQ0FBQyxJQUNELEtBQUssTUFBTSxPQUFPLENBQUM7Q0FDdkIsSUFBSSxPQUFPLE1BQU0sWUFDYixJQUFJLENBQUM7Q0FDVCxJQUFJLElBQUksQ0FBQztDQUNULEtBQUssTUFBTSxJQUFJLEdBQUcsSUFBSTtDQUN0QixJQUFJLElBQUksT0FBTyxLQUFLLENBQUM7Q0FDckIsSUFBSSxNQUFNLEVBQUUsUUFBUSxJQUFJLEdBQUcsTUFBTTtDQUNqQyxJQUFJLE9BQU8sS0FBSyxRQUFRLElBQUksTUFBTSxHQUFHO0NBQ3JDLElBQUksT0FBTyxDQUFDO0NBQ1osSUFBSSxPQUFPLFdBQVk7RUFDbkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxFQUFFLEdBQy9CLEtBQUssRUFBRSxDQUFDO0NBQ2hCO0NBQ0EsSUFBSSxNQUFNLFNBQVUsR0FBRyxHQUFHO0VBQ3RCLEdBQUcsV0FBWTtHQUFFLEdBQUcsR0FBRyxDQUFDO0VBQUcsQ0FBQztDQUNoQztDQUNBLEdBQUcsV0FBWTtFQUFFLE1BQU07Q0FBSSxDQUFDO0NBQzVCLElBQUksTUFBTSxXQUFZO0VBQ2xCLElBQUksTUFBTSxJQUFJLEdBQUcsTUFBTSxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU0sTUFBTTtFQUNoRCxNQUFNO0VBQ04sS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sRUFBRSxHQUFHO0dBQzNCLElBQUksSUFBSSxNQUFNO0dBQ2QsSUFBSTtJQUNBLElBQUksSUFBSSxFQUFFLEVBQUU7SUFDWixJQUFJLEtBQUssS0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztJQUM1QixJQUFJLE9BQU8sS0FBSyxFQUFFLEVBQUUsU0FBUyxLQUFLLEVBQUUsS0FBSztJQUN6QyxJQUFJLE1BQU0sTUFBTTtJQUNoQixJQUFJLElBQUksRUFBRSxHQUFHLEdBQUc7SUFDaEIsSUFBSSxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsS0FBSyxFQUFFLENBQUMsR0FBRyxLQUFLLEtBQUssUUFBUSxFQUFFLElBQUksRUFBRSxFQUFFLFNBQVMsSUFBSSxNQUFNLE1BQU07R0FDaEcsU0FDTyxHQUFHO0lBQ04sT0FBTyxJQUFJLEdBQUcsSUFBSTtHQUN0QjtFQUNKO0VBQ0EsSUFBSSxLQUFLLEdBQUcsTUFBTSxRQUFRLEtBQUssRUFBRTtFQUNqQyxJQUFJLE1BQU0sR0FBRztDQUNqQjtDQUNBLElBQUksQ0FBQyxLQUNELElBQUk7Q0FDUixJQUFJLFVBQVUsU0FBVSxHQUFHO0VBQ3ZCLElBQUksS0FBSyxFQUFFO0VBQ1gsSUFBSSxLQUFLLEVBQUUsS0FBSyxPQUFPLEdBQUcsSUFBSSxJQUFJLEdBQUc7RUFDckMsSUFBSSxJQUFJLElBQUksR0FBRyxPQUFPLEtBQUs7RUFDM0IsRUFBRSxFQUFFLElBQUk7RUFDUixJQUFJLElBQUksUUFBUSxFQUFFLEdBQUcsSUFBSSxFQUFFO0VBQzNCLElBQUksTUFBTSxFQUFFLFNBQVMsSUFBSSxPQUFPLFFBQVEsR0FBRyxHQUFHLEtBQUssS0FBSyxFQUFFO0VBQzFELElBQUksTUFBTSxLQUFLLEVBQUUsS0FBSztFQUN0QixJQUFJLGNBQWMsRUFBRSxTQUFTLElBQUksSUFBSTtFQUNyQyxJQUFJLE1BQU0sU0FBVSxHQUFHLEdBQUc7R0FDdEIsSUFBSSxHQUFHO0lBQ0gsS0FBSztJQUNMLElBQUksR0FBRyxJQUFJO0dBQ2YsT0FDSztJQUNELElBQUksSUFBSSxFQUFFO0lBQ1YsTUFBTSxLQUFLLElBQUksR0FBRztLQUNSO0tBQ04sS0FBSyxFQUFFLEVBQUU7S0FDVCxHQUFHO0tBQ0E7S0FDQTtLQUNILEdBQUcsS0FBSyxHQUFHLFVBQVcsS0FBTSxJQUFJLFVBQVU7S0FDN0I7SUFDakIsQ0FBQztJQUNELEtBQUssS0FBSyxJQUFJLE1BQU07SUFDcEIsT0FBTyxLQUFLLEtBQUssSUFBSSxRQUFRLE1BQU0sS0FBSztJQUN4QyxJQUFJLENBQUMsRUFBRSxLQUNILElBQUk7R0FDWjtFQUNKO0VBQ0EsSUFBSSxJQUFJLE9BQ0osSUFBSSxJQUFJLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSTtFQUMzQixJQUFJLENBQUMsYUFDRCxJQUFJLE1BQU0sSUFBSTtPQUNiLElBQUksT0FBTyxNQUNaLElBQUk7R0FDQSxJQUFJLE1BQU0sWUFBWSxNQUFNLENBQUMsQ0FBQztFQUNsQyxTQUNPLEdBQUc7R0FDTixJQUFJLEdBQUcsSUFBSTtFQUNmO09BR0EsS0FBSyxLQUFLLFFBQVEsTUFBTSxHQUFHLEdBQUcsQ0FBQztDQUN2QztDQUVBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUUsR0FDeEIsUUFBUSxDQUFDO0NBRWIsT0FBTztBQUNYOzs7Ozs7OztBQVFBLFNBQWdCLFFBQVEsTUFBTSxNQUFNO0NBQ2hDLElBQUksQ0FBQyxNQUNELE9BQU8sQ0FBQztDQUNaLElBQUksSUFBSSxDQUFDO0NBQ1QsSUFBSSxRQUFRLENBQUM7Q0FDYixLQUFLLE1BQU0sSUFBSSxHQUFHLElBQUk7Q0FDdEIsSUFBSSxJQUFJO0NBQ1IsSUFBSSxNQUFNO0NBQ1YsS0FBSyxJQUFJLE1BQU0sR0FBRztFQUNkLElBQUksS0FBSyxFQUFFLEtBQUssT0FBTyxHQUFHLElBQUksSUFBSSxHQUFHO0VBQ3JDLElBQUksY0FBYyxFQUFFLFNBQVMsSUFBSSxJQUFJO0VBQ3JDLElBQUksSUFBSSxRQUFRLEVBQUUsR0FBRyxJQUFJLEVBQUU7RUFDM0IsSUFBSSxNQUFNLEVBQUUsU0FBUyxJQUFJLE9BQU8sUUFBUSxHQUFHLEdBQUcsS0FBSyxLQUFLLEVBQUU7RUFDMUQsSUFBSSxNQUFNLEtBQUssRUFBRSxLQUFLO0VBQ3RCLElBQUksSUFBSSxPQUNKLElBQUksRUFBRTtFQUNWLElBQUksSUFBSSxjQUFjLFlBQVksTUFBTSxDQUFDLElBQUksTUFBTSxJQUFJLEVBQUU7RUFDekQsSUFBSSxJQUFJLElBQUk7RUFDWixFQUFFLEVBQUUsSUFBSTtFQUNSLE1BQU0sS0FBSyxJQUFJLEdBQUc7R0FDZCxNQUFNLEtBQUs7R0FDWCxLQUFLLEVBQUUsRUFBRTtHQUNULEdBQUc7R0FDQTtHQUNBO0dBQ0gsR0FBRyxLQUFLLEdBQUcsVUFBVyxLQUFNLElBQUksVUFBVTtHQUN2QztHQUNVO0VBQ2pCLENBQUMsQ0FBQztFQUNGLEtBQUssS0FBSyxJQUFJLE1BQU07RUFDcEIsT0FBTyxLQUFLLEtBQUssSUFBSSxRQUFRLE1BQU0sS0FBSztDQUM1QztDQUNBLElBQUksTUFBTSxJQUFJLEdBQUcsTUFBTSxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU0sTUFBTTtDQUNoRCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEVBQUUsR0FBRztFQUNuQyxJQUFJLElBQUksTUFBTTtFQUNkLElBQUksS0FBSyxFQUFFLEdBQUcsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxNQUFNO0VBQ3JDLElBQUksT0FBTyxLQUFLLEVBQUUsRUFBRSxTQUFTLEtBQUssRUFBRSxLQUFLO0VBQ3pDLElBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLElBQUk7RUFDdkIsSUFBSSxLQUFLLEdBQUcsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUMsR0FBRyxLQUFLLEtBQUssUUFBUSxFQUFFLElBQUksRUFBRSxFQUFFLFNBQVM7Q0FDekY7Q0FDQSxJQUFJLEtBQUssR0FBRyxNQUFNLFFBQVEsS0FBSyxFQUFFO0NBQ2pDLE9BQU87QUFDWDs7OztBQUlBLElBQUksbUJBQWtDLDJCQUFZO0NBQzlDLFNBQVMsbUJBQW1CLENBQzVCO0NBQ0EsaUJBQWlCLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUV0RCxLQUFLLE9BQU8sTUFBTSxPQUFPLEtBQUs7Q0FDbEM7Q0FDQSxpQkFBaUIsY0FBYztDQUMvQixPQUFPO0FBQ1gsRUFBRTs7Ozs7QUFNRixJQUFJLGVBQThCLDJCQUFZOzs7O0NBSTFDLFNBQVMsZUFBZTtFQUNwQixJQUFJLFFBQVE7RUFDWixLQUFLLElBQUksSUFBSSxRQUFRLFNBQVUsS0FBSyxPQUFPO0dBQ3ZDLE1BQU0sT0FBTyxNQUFNLEtBQUssS0FBSztFQUNqQyxDQUFDO0NBQ0w7Q0FDQSxhQUFhLFVBQVUsT0FBTyxTQUFVLE9BQU8sT0FBTztFQUNsRCxJQUFJO0dBQ0EsS0FBSyxFQUFFLEtBQUssT0FBTyxLQUFLO0VBQzVCLFNBQ08sR0FBRztHQUNOLEtBQUssT0FBTyxHQUFHLE1BQU0sS0FBSztFQUM5QjtDQUNKO0NBQ0EsYUFBYSxjQUFjO0NBQzNCLE9BQU87QUFDWCxFQUFFOzs7O0FBS0YsSUFBSSxvQkFBbUMsMkJBQVk7Ozs7Q0FJL0MsU0FBUyxrQkFBa0IsR0FBRyxJQUFJO0VBQzlCLElBQUksUUFBUTtFQUNaLElBQUksS0FBSyxNQUNMLEtBQUssSUFBSSxJQUFJLFFBQVEsU0FBVSxLQUFLLE9BQU87R0FDdkMsTUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLO0VBQ2pDLENBQUM7T0FFQTtHQUNELEtBQUssSUFBSSxJQUFJLGFBQWEsU0FBVSxLQUFLLEtBQUssT0FBTztJQUNqRCxNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUs7R0FDaEMsQ0FBQztHQUNELEtBQUssWUFBWSxLQUFLLEVBQUU7RUFDNUI7Q0FDSjtDQUNBLGtCQUFrQixVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDdkQsSUFBSSxLQUFLLEVBQUUsV0FDUCxRQUFRLElBQUksT0FBTyxDQUFDO0VBQ3hCLEtBQUssRUFBRSxLQUFLLE9BQU8sS0FBSztDQUM1QjtDQUNBLGtCQUFrQixjQUFjO0NBQ2hDLE9BQU87QUFDWCxFQUFFOzs7O0FBS0YsSUFBSSxRQUF1QiwyQkFBWTs7Ozs7Q0FLbkMsU0FBUyxNQUFNLElBQUk7RUFDZixLQUFLLFNBQVM7RUFDZCxLQUFLLElBQUksQ0FBQztFQUNWLEtBQUssSUFBSSxFQUNMLEdBQUcsaUJBQ1A7RUFDQSxLQUFLLElBQUk7Q0FDYjs7Ozs7O0NBTUEsTUFBTSxVQUFVLE9BQU8sU0FBVSxPQUFPLE9BQU87RUFDM0MsSUFBSSxRQUFRO0VBQ1osSUFBSSxDQUFDLEtBQUssUUFDTixJQUFJLENBQUM7RUFDVCxJQUFJLENBQUMsS0FBSyxHQUNOLElBQUksQ0FBQztFQUNULElBQUksS0FBSyxJQUFJLEdBQUc7R0FDWixJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUssR0FBRyxNQUFNLE1BQU07R0FDdkMsSUFBSSxRQUFRLE1BQU0sU0FBUyxHQUFHLEdBQUc7R0FDakMsS0FBSyxLQUFLO0dBQ1YsSUFBSSxLQUFLLEdBQ0wsS0FBSyxFQUFFLEtBQUssT0FBTyxDQUFDLEtBQUssQ0FBQztRQUUxQixLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssS0FBSztHQUN4QixRQUFRLE1BQU0sU0FBUyxHQUFHO0dBQzFCLElBQUksTUFBTSxRQUNOLE9BQU8sS0FBSyxLQUFLLE9BQU8sS0FBSztFQUNyQyxPQUNLO0dBQ0QsSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUssS0FBSyxHQUFHLE1BQU0sS0FBSztHQUMxQyxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQ1IsTUFBTTtRQUNMLElBQUksQ0FBQyxNQUFNLFFBQ1osTUFBTSxLQUFLO1FBQ1Y7SUFDRCxNQUFNLElBQUksR0FBRyxLQUFLLEVBQUUsU0FBUyxNQUFNLE1BQU07SUFDekMsSUFBSSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksSUFBSSxPQUFPLEtBQUssRUFBRSxNQUFNO0dBQ2pEO0dBQ0EsSUFBSSxJQUFJLElBQUksUUFBUSxLQUFLLEtBQUssR0FBRyxNQUFNLE1BQU0sS0FBSztHQUNsRCxJQUFJLFVBQVUsV0FBWTtJQUN0QixJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDbkIsSUFBSSxPQUFPLFVBQVc7S0FDbEIsSUFBSSxHQUFHLEtBQUs7S0FDWixPQUFPLElBQUk7S0FDWCxPQUFPLElBQUk7S0FDWCxJQUFJLEtBQUssR0FBRyxLQUFLLElBQUksQ0FBQyxHQUFHLFFBQVEsR0FBRyxLQUFLLElBQUksQ0FBQyxHQUFHLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSyxHQUFHLE1BQU0sR0FBRyxLQUFLLElBQUksRUFBRSxHQUFHLEtBQUssR0FBRyxLQUFLLElBQUksRUFBRTtLQUN2SCxJQUFJLElBQUksSUFBSSxLQUFLLE1BQU0sSUFBSTtNQUN2QixJQUFJLFNBQVMsQ0FBQztNQUNkLE9BQU8sRUFBRSxRQUFRLE1BQU07TUFDdkIsSUFBSTtNQUNKLElBQUksTUFBTSxHQUFHLEtBQUssSUFBSSxFQUFFLEdBQUcsTUFBTSxHQUFHLEtBQUssSUFBSSxFQUFFO01BQy9DLElBQUksT0FBTyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksS0FBSyxLQUFLLEdBQUcsR0FBRyxDQUFDLENBQUM7TUFDNUQsSUFBSSxLQUFLLE1BQU0sS0FBSyxHQUFHLElBQUksR0FBRyxLQUFLLEtBQUssQ0FBQyxHQUFHLE9BQU8sR0FBRyxJQUFJLE9BQU8sR0FBRyxJQUFJLE1BQU0sR0FBRztNQUNqRixJQUFJLElBQ0EsT0FBTyxLQUFLO01BQ2hCLEtBQUs7TUFDTCxPQUFPLElBQUk7TUFDWCxJQUFJO01BQ0osSUFBSSxTQUFTO09BQ1QsTUFBTTtPQUNOLGFBQWE7T0FDYixPQUFPLFdBQVk7UUFDZixJQUFJLENBQUMsT0FBTyxRQUNSLElBQUksQ0FBQztRQUNULElBQUksQ0FBQyxNQUNELE9BQU8sT0FBTyxNQUFNLElBQUksSUFBSTthQUMzQjtTQUNELElBQUksTUFBTSxNQUFNLEVBQUU7U0FDbEIsSUFBSSxDQUFDLEtBQ0QsT0FBTyxPQUFPLElBQUksSUFBSSw4QkFBOEIsT0FBTyxDQUFDLEdBQUcsTUFBTSxLQUFLO1NBQzlFLE1BQU0sT0FBTyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLE1BQU0sTUFBTSxJQUFJO1NBQ3pELElBQUksU0FBUyxTQUFVLEtBQUssS0FBSyxPQUFPO1VBQUUsT0FBTyxPQUFPLEtBQUssS0FBSyxLQUFLO1NBQUc7U0FDMUUsS0FBSyxJQUFJLEtBQUssR0FBRyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsTUFBTTtVQUN4RCxJQUFJLE1BQU0sT0FBTztVQUNqQixJQUFJLEtBQUssS0FBSyxLQUFLO1NBQ3ZCO1NBQ0EsSUFBSSxNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sR0FDOUIsTUFBTSxJQUFJO2NBRVYsSUFBSSxLQUFLLElBQUksSUFBSTtRQUN6QjtPQUNKO09BQ0EsV0FBVyxXQUFZO1FBQ25CLElBQUksT0FBTyxJQUFJLFdBQ1gsSUFBSSxVQUFVO09BQ3RCO01BQ0o7TUFDQSxJQUFJLFFBQVEsR0FDUixPQUFPLE9BQU8sTUFBTSxPQUFPLGVBQWU7TUFDOUMsT0FBTyxPQUFPLE1BQU07S0FDeEI7S0FDQSxPQUFPO0lBQ1gsT0FDSyxJQUFJO1NBQ0QsT0FBTyxXQUFXO01BQ2xCLEtBQUssS0FBSyxNQUFNLE1BQU0sTUFBTSxJQUFJLElBQUksR0FBRyxPQUFPLElBQUk7TUFDbEQsT0FBTztLQUNYLE9BQ0ssSUFBSSxPQUFPLFVBQVc7TUFDdkIsS0FBSyxLQUFLLEdBQUcsSUFBSSxHQUFHLE9BQU8sSUFBSTtNQUMvQixPQUFPO0tBQ1g7O0dBRVI7R0FDQSxJQUFJLFNBQVM7R0FDYixPQUFPLElBQUksSUFBSSxHQUFHLEVBQUUsR0FFaEIsSUFEYyxRQUNKLE1BQU0sU0FDWjtHQUVSLEtBQUssSUFBSTtHQUNULElBQUksS0FBSyxHQUFHO0lBQ1IsSUFBSSxNQUFNLElBQUksSUFBSSxTQUFTLEdBQUcsS0FBSyxNQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsS0FBSyxLQUFLLEVBQUUsS0FBSyxhQUFhLEVBQUUsSUFBSSxJQUFJLFNBQVMsR0FBRyxDQUFDO0lBQ25ILElBQUksS0FDQSxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQztTQUVqQixLQUFLLEVBQUUsRUFBRSxLQUFLLEdBQUcsQ0FBQyxLQUFLLEdBQUc7R0FDbEM7R0FDQSxJQUFJLElBQUksR0FDSixPQUFPLEtBQUssS0FBSyxJQUFJLFNBQVMsQ0FBQyxHQUFHLEtBQUs7R0FDM0MsS0FBSyxJQUFJLElBQUksU0FBUyxDQUFDO0VBQzNCO0VBQ0EsSUFBSSxPQUFPO0dBQ1AsSUFBSSxLQUFLLEdBQ0wsSUFBSSxFQUFFO0dBQ1YsS0FBSyxJQUFJO0VBQ2I7Q0FDSjs7Ozs7O0NBTUEsTUFBTSxVQUFVLFdBQVcsU0FBVSxTQUFTO0VBQzFDLEtBQUssRUFBRSxRQUFRLGVBQWU7Q0FDbEM7Q0FDQSxPQUFPO0FBQ1gsRUFBRTtBQUVGLElBQUksS0FBSyxPQUFPLGtCQUFrQixhQUFhLGlCQUFpQixPQUFPLGNBQWMsYUFBYSxhQUFhLFNBQVUsSUFBSTtDQUFFLEdBQUc7QUFBRztBQUNySSxTQUFnQixNQUFNLE1BQU0sTUFBTSxJQUFJO0NBQ2xDLElBQUksQ0FBQyxJQUNELEtBQUssTUFBTSxPQUFPLENBQUM7Q0FDdkIsSUFBSSxPQUFPLE1BQU0sWUFDYixJQUFJLENBQUM7Q0FDVCxJQUFJLE9BQU8sQ0FBQztDQUNaLElBQUksT0FBTyxXQUFZO0VBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsRUFBRSxHQUMvQixLQUFLLEVBQUUsQ0FBQztDQUNoQjtDQUNBLElBQUksUUFBUSxDQUFDO0NBQ2IsSUFBSSxNQUFNLFNBQVUsR0FBRyxHQUFHO0VBQ3RCLEdBQUcsV0FBWTtHQUFFLEdBQUcsR0FBRyxDQUFDO0VBQUcsQ0FBQztDQUNoQztDQUNBLEdBQUcsV0FBWTtFQUFFLE1BQU07Q0FBSSxDQUFDO0NBQzVCLElBQUksSUFBSSxLQUFLLFNBQVM7Q0FDdEIsT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLFdBQVcsRUFBRSxHQUMvQixJQUFJLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxPQUFPO0VBQy9CLElBQUksSUFBSSxJQUFJLEdBQUcsQ0FBQyxHQUFHLElBQUk7RUFDdkIsT0FBTztDQUNYO0NBR0osSUFBSSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUM7Q0FDeEIsSUFBSSxLQUFLO0VBQ0wsSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUU7RUFDdkIsSUFBSSxJQUFJLEdBQUcsTUFBTSxJQUFJLEVBQUUsS0FBSztFQUM1QixJQUFJLEdBQUc7R0FDSCxJQUFJLEtBQUssR0FBRyxNQUFNLElBQUksRUFBRTtHQUN4QixJQUFJLEdBQUcsTUFBTSxFQUFFLEtBQUs7R0FDcEIsSUFBSSxHQUFHO0lBQ0gsSUFBSSxNQUFNLEdBQUcsTUFBTSxLQUFLLEVBQUU7SUFDMUIsSUFBSSxHQUFHLE1BQU0sS0FBSyxFQUFFO0dBQ3hCO0VBQ0o7RUFDQSxJQUFJLE9BQU8sUUFBUSxLQUFLO0VBQ3hCLElBQUksVUFBVSxTQUFVLEdBQUc7R0FDdkIsSUFBSSxLQUFLLEdBQUcsTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxNQUFNLEdBQUcsSUFBSSxJQUFJLEtBQUssTUFBTSxHQUFHO0dBQ3JILElBQUk7R0FDSixJQUFJLE1BQU0sU0FBVSxHQUFHLEdBQUc7SUFDdEIsSUFBSSxHQUFHO0tBQ0gsS0FBSztLQUNMLElBQUksR0FBRyxJQUFJO0lBQ2YsT0FDSztLQUNELElBQUksR0FDQSxNQUFNLE1BQU07S0FDaEIsSUFBSSxDQUFDLEVBQUUsS0FDSCxJQUFJLE1BQU0sS0FBSztJQUN2QjtHQUNKO0dBQ0EsSUFBSSxDQUFDLFFBQVEsS0FBSztJQUNkLE1BQU07SUFDTixNQUFNO0lBQ04sY0FBYztJQUNkLGFBQWE7R0FDakIsQ0FBQyxHQUNHLElBQUksQ0FBQyxLQUNELElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxJQUFJLEVBQUUsQ0FBQztRQUM3QixJQUFJLE9BQU8sR0FBRztJQUNmLElBQUksT0FBTyxLQUFLLFNBQVMsR0FBRyxJQUFJLEVBQUU7SUFFbEMsSUFBSSxLQUFLLFVBQVUsS0FBSyxLQUFNLElBQzFCLElBQUk7S0FDQSxJQUFJLE1BQU0sWUFBWSxNQUFNLEVBQUUsS0FBSyxJQUFJLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNwRCxTQUNPLEdBQUc7S0FDTixJQUFJLEdBQUcsSUFBSTtJQUNmO1NBR0EsS0FBSyxLQUFLLFFBQVEsTUFBTSxFQUFFLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUNsRCxPQUVJLElBQUksSUFBSSxJQUFJLDhCQUE4QixLQUFLLENBQUMsR0FBRyxJQUFJO1FBRzNELElBQUksTUFBTSxJQUFJO0VBQ3RCO0VBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUNyQixRQUFRLENBQUM7Q0FFakIsT0FFSSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0NBQ2hCLE9BQU87QUFDWDs7Ozs7Ozs7QUFRQSxTQUFnQixVQUFVLE1BQU0sTUFBTTtDQUNsQyxJQUFJLFFBQVEsQ0FBQztDQUNiLElBQUksSUFBSSxLQUFLLFNBQVM7Q0FDdEIsT0FBTyxHQUFHLE1BQU0sQ0FBQyxLQUFLLFdBQVcsRUFBRSxHQUMvQixJQUFJLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxPQUN4QixJQUFJLEVBQUU7Q0FHZCxJQUFJLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQztDQUN0QixJQUFJLENBQUMsR0FDRCxPQUFPLENBQUM7Q0FDWixJQUFJLElBQUksR0FBRyxNQUFNLElBQUksRUFBRTtDQUN2QixJQUFJLElBQUksR0FBRyxNQUFNLElBQUksRUFBRSxLQUFLO0NBQzVCLElBQUksR0FBRztFQUNILElBQUksS0FBSyxHQUFHLE1BQU0sSUFBSSxFQUFFO0VBQ3hCLElBQUksR0FBRyxNQUFNLEVBQUUsS0FBSztFQUNwQixJQUFJLEdBQUc7R0FDSCxJQUFJLEdBQUcsTUFBTSxLQUFLLEVBQUU7R0FDcEIsSUFBSSxHQUFHLE1BQU0sS0FBSyxFQUFFO0VBQ3hCO0NBQ0o7Q0FDQSxJQUFJLE9BQU8sUUFBUSxLQUFLO0NBQ3hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBRztFQUN4QixJQUFJLEtBQUssR0FBRyxNQUFNLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssR0FBRyxJQUFJLE1BQU0sR0FBRyxJQUFJLElBQUksS0FBSyxNQUFNLEdBQUc7RUFDckgsSUFBSTtFQUNKLElBQUksQ0FBQyxRQUFRLEtBQUs7R0FDZCxNQUFNO0dBQ04sTUFBTTtHQUNOLGNBQWM7R0FDZCxhQUFhO0VBQ2pCLENBQUMsR0FDRyxJQUFJLENBQUMsS0FDRCxNQUFNLE1BQU0sSUFBSSxNQUFNLEdBQUcsSUFBSSxFQUFFO09BQzlCLElBQUksT0FBTyxHQUNaLE1BQU0sTUFBTSxZQUFZLEtBQUssU0FBUyxHQUFHLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxJQUFJLEdBQUcsRUFBRSxFQUFFLENBQUM7T0FFckUsSUFBSSxJQUFJLDhCQUE4QixHQUFHO0NBRXJEO0NBQ0EsT0FBTztBQUNYIn0=